package com.example.di

import android.content.Context
import android.media.AudioManager
import android.os.BatteryManager
import android.app.ActivityManager
import android.net.wifi.WifiManager
import android.net.ConnectivityManager
import android.content.pm.PackageManager
import android.content.pm.ApplicationInfo
import android.provider.Settings
import androidx.core.content.ContextCompat
import android.Manifest
import androidx.room.Room
import com.example.data.local.CompanionDatabase
import com.example.data.remote.RealtimeWebSocketClient
import com.example.data.remote.RealtimeWebSocketClientStub
import com.example.data.repository.CompanionRepositoryImpl
import com.example.audio.AudioCaptureEngine
import com.example.domain.repository.CompanionRepository
import com.example.domain.usecase.GetCompanionConfigUseCase
import com.example.domain.usecase.GetSessionHistoryUseCase
import com.example.domain.usecase.GetSessionStateUseCase
import com.example.domain.usecase.SaveCompanionConfigUseCase
import com.example.domain.usecase.SendMessageUseCase
import com.example.domain.usecase.ToggleStreamConnectionUseCase
import com.example.util.AndroidLogger
import com.example.util.AppLogger
import com.example.util.ConfigurationManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking

/**
 * Service Locator container for manual dependency injection in Phase 1.
 * Provides guaranteed, thread-safe, compile-time dependency instantiation.
 */
class AppContainer(private val context: Context) {

    val logger: AppLogger = AndroidLogger()
    
    val configManager: ConfigurationManager by lazy {
        ConfigurationManager(context)
    }

    val applicationScope: CoroutineScope by lazy {
        CoroutineScope(SupervisorJob() + Dispatchers.Main)
    }

    val database: CompanionDatabase by lazy {
        Room.databaseBuilder(
            context,
            CompanionDatabase::class.java,
            "companion_database"
        ).fallbackToDestructiveMigration().build()
    }

    val okHttpClient: okhttp3.OkHttpClient by lazy {
        okhttp3.OkHttpClient.Builder()
            .connectTimeout(5, java.util.concurrent.TimeUnit.SECONDS)
            .readTimeout(10, java.util.concurrent.TimeUnit.SECONDS)
            .writeTimeout(10, java.util.concurrent.TimeUnit.SECONDS)
            .pingInterval(10, java.util.concurrent.TimeUnit.SECONDS)
            .retryOnConnectionFailure(true)
            .build()
    }

    val sessionRepository: com.example.domain.repository.SessionRepository by lazy {
        com.example.data.repository.SessionRepositoryImpl(context)
    }

    val networkStateRepository: com.example.domain.repository.NetworkStateRepository by lazy {
        com.example.data.repository.NetworkStateRepositoryImpl(context, applicationScope)
    }

    val httpRepository: com.example.domain.repository.HttpRepository by lazy {
        com.example.data.repository.HttpRepositoryImpl(okHttpClient)
    }

    val webSocketRepository: com.example.domain.repository.WebSocketRepository by lazy {
        com.example.data.repository.WebSocketRepositoryImpl(okHttpClient, logger, applicationScope)
    }

    val webSocketClient: RealtimeWebSocketClient by lazy {
        RealtimeWebSocketClientStub(logger, applicationScope)
    }

    val audioCaptureEngine: AudioCaptureEngine by lazy {
        AudioCaptureEngine(context, logger, applicationScope)
    }

    val companionRepository: CompanionRepository by lazy {
        CompanionRepositoryImpl(
            database.companionDao(),
            webSocketClient,
            logger,
            applicationScope
        )
    }

    val transcriptRepository: com.example.domain.repository.TranscriptRepository by lazy {
        com.example.data.repository.TranscriptRepositoryImpl()
    }

    val sessionTranscriptRepository: com.example.domain.repository.SessionTranscriptRepository by lazy {
        com.example.data.repository.SessionTranscriptRepositoryImpl(database.companionDao(), applicationScope)
    }

    val speechRepository: com.example.domain.repository.SpeechRepository by lazy {
        com.example.data.repository.SpeechRepositoryImpl(
            webSocketRepository,
            transcriptRepository,
            sessionTranscriptRepository,
            sessionRepository,
            applicationScope
        )
    }

    val brainDao by lazy { database.brainDao() }

    val llmProvider: com.example.domain.repository.LlmProvider by lazy {
        com.example.data.repository.MockLlmProvider()
    }

    val promptRepository: com.example.domain.repository.PromptRepository by lazy {
        com.example.data.repository.PromptRepositoryImpl(brainDao)
    }

    val aiResponseRepository: com.example.domain.repository.AiResponseRepository by lazy {
        com.example.data.repository.AiResponseRepositoryImpl()
    }

    val permissionManager: com.example.capabilities.permissions.PermissionManager by lazy {
        com.example.capabilities.permissions.PermissionManager(context)
    }

    val permissionEventBus: com.example.capabilities.permissions.PermissionEventBus by lazy {
        com.example.capabilities.permissions.PermissionEventBus()
    }

    val backgroundCameraCaptureEngine: com.example.camera.BackgroundCameraCaptureEngine by lazy {
        com.example.camera.BackgroundCameraCaptureEngine(context)
    }

    val notificationRepository: com.example.capabilities.notifications.NotificationRepository by lazy {
        com.example.capabilities.notifications.NotificationRepositoryImpl(context)
    }

    val clipboardRepository: com.example.capabilities.clipboard.ClipboardRepository by lazy {
        com.example.capabilities.clipboard.ClipboardRepositoryImpl(context)
    }

    val deviceInfoRepository: com.example.capabilities.info.DeviceInfoRepository by lazy {
        com.example.capabilities.info.DeviceInfoRepositoryImpl(context)
    }

    val batteryRepository: com.example.capabilities.battery.BatteryRepository by lazy {
        com.example.capabilities.battery.BatteryRepositoryImpl(context)
    }

    val locationRepository: com.example.capabilities.gps.LocationRepository by lazy {
        com.example.capabilities.gps.LocationRepositoryImpl(context)
    }

    val mediaEngine: com.example.media.MediaEngine by lazy {
        com.example.media.MediaEngine(context)
    }

    val accessibilityRepository: com.example.accessibility.AccessibilityRepository by lazy {
        com.example.accessibility.AccessibilityRepositoryImpl()
    }

    val brainConversationRepository: com.example.domain.repository.ConversationRepository by lazy {
        com.example.data.repository.ConversationRepositoryImpl(brainDao, applicationScope)
    }

    // AIOS Core Architecture Singletons
    val agentManager: com.example.aios.core.AgentManager by lazy {
        com.example.aios.core.AgentManager()
    }

    val metricsTracker: com.example.aios.observability.MetricsTracker by lazy {
        com.example.aios.observability.MetricsTracker()
    }

    val taskPlanner: com.example.aios.planning.TaskPlanner by lazy {
        com.example.aios.planning.TaskPlanner(agentManager, metricsTracker)
    }

    val eventBus: com.example.aios.communication.EventBus by lazy {
        com.example.aios.communication.EventBus()
    }

    val workflowEngine: com.example.aios.workflows.WorkflowEngine by lazy {
        com.example.aios.workflows.WorkflowEngine(taskPlanner)
    }

    val scheduler: com.example.aios.scheduler.Scheduler by lazy {
        com.example.aios.scheduler.Scheduler(workflowEngine)
    }

    // UseCases
    val getCompanionConfigUseCase by lazy { GetCompanionConfigUseCase(companionRepository) }
    val saveCompanionConfigUseCase by lazy { SaveCompanionConfigUseCase(companionRepository) }
    val getSessionHistoryUseCase by lazy { GetSessionHistoryUseCase(companionRepository) }
    val sendMessageUseCase by lazy { SendMessageUseCase(companionRepository) }
    val getSessionStateUseCase by lazy { GetSessionStateUseCase(companionRepository) }
    val toggleStreamConnectionUseCase by lazy { ToggleStreamConnectionUseCase(companionRepository) }

    private var textToSpeech: android.speech.tts.TextToSpeech? = null

    val toastCustomizer: com.example.ui.overlay.ToastCustomizer by lazy {
        com.example.ui.overlay.ToastCustomizer(context)
    }

    val floatingOverlayManager: com.example.ui.overlay.FloatingOverlayManager by lazy {
        com.example.ui.overlay.FloatingOverlayManager(context)
    }

    val hapticsManager: com.example.hardware.HapticsManager by lazy {
        com.example.hardware.HapticsManager(context)
    }

    val soundPlayerManager: com.example.hardware.SoundPlayerManager by lazy {
        com.example.hardware.SoundPlayerManager(context)
    }

    val volumeManager: com.example.hardware.VolumeManager by lazy {
        com.example.hardware.VolumeManager(context)
    }

    val appLauncherManager: com.example.hardware.AppLauncherManager by lazy {
        com.example.hardware.AppLauncherManager(context)
    }

    val sensorHubManager: com.example.hardware.SensorHubManager by lazy {
        com.example.hardware.SensorHubManager(context)
    }

    val displayPowerManager: com.example.hardware.DisplayPowerManager by lazy {
        com.example.hardware.DisplayPowerManager(context)
    }

    val networkTelemetryManager: com.example.hardware.NetworkTelemetryManager by lazy {
        com.example.hardware.NetworkTelemetryManager(context)
    }

    val deviceDetailsManager: com.example.hardware.DeviceDetailsManager by lazy {
        com.example.hardware.DeviceDetailsManager(context)
    }

    val aeroShareManager: com.example.aeroshare.AeroShareManager by lazy {
        com.example.aeroshare.AeroShareManager(context, applicationScope)
    }

    val httpServer: com.example.server.AuraHttpServer by lazy {
        com.example.server.AuraHttpServer(
            scope = applicationScope,
            port = 8080,
            onApiRequest = { endpoint, jsonPayload ->
                handleHttpRestApi(endpoint, jsonPayload)
            }
        )
    }

    init {
        try {
            textToSpeech = android.speech.tts.TextToSpeech(context) { status ->
                if (status == android.speech.tts.TextToSpeech.SUCCESS) {
                    textToSpeech?.language = java.util.Locale.getDefault()
                }
            }
        } catch (e: Exception) {
            logger.e("AppContainer", "Failed to init TextToSpeech", e)
        }

        // Start embedded HTTP documentation and capabilities endpoint server on port 8080
        try {
            httpServer.start()
        } catch (e: Exception) {
            logger.e("AppContainer", "Failed to start AuraHttpServer", e)
        }

        applicationScope.launch {
            webSocketRepository.incomingMessages.collect { message ->
                applicationScope.launch(Dispatchers.IO) {
                    try {
                        handleGlobalIncomingMessage(message)
                    } catch (e: Throwable) {
                        logger.e("AppContainer", "Error processing incoming message ${message::class.simpleName}: ${e.message}", e)
                    }
                }
            }
        }

        applicationScope.launch {
            webSocketRepository.incomingRawMessages.collect { rawText ->
                applicationScope.launch(Dispatchers.IO) {
                    try {
                        handleRawIncomingWebSocketMessage(rawText)
                    } catch (e: Throwable) {
                        logger.e("AppContainer", "Error processing raw WebSocket message: ${e.message}", e)
                    }
                }
            }
        }
    }

    private suspend fun handleGlobalIncomingMessage(message: com.example.domain.model.NetworkMessage) {
        when (message) {
            is com.example.domain.model.CapabilityManifestMessage -> {
                logger.i("AppContainer", "Received Capability Manifest request")
                val manifestJson = com.example.server.AuraManifestProvider.generateManifestJson()
                val response = com.example.domain.model.CapabilityManifestResultMessage(
                    timestamp = System.currentTimeMillis(),
                    sessionId = message.sessionId,
                    requestId = message.requestId,
                    manifestJson = manifestJson
                )
                webSocketRepository.sendMessage(response)
                webSocketRepository.addLog("MANIFEST: Dispatched capabilities documentation manifest to Termux")
            }
            is com.example.domain.model.TtsSpeakMessage -> {
                logger.i("AppContainer", "Received TTS speak request: '${message.text}'")
                webSocketRepository.addLog("TTS: Speaking '${message.text}'")
                val tts = textToSpeech
                if (tts != null) {
                    tts.setPitch(message.pitch)
                    tts.setSpeechRate(message.speechRate)
                    val queueMode = if (message.queueMode == 1) android.speech.tts.TextToSpeech.QUEUE_ADD else android.speech.tts.TextToSpeech.QUEUE_FLUSH
                    tts.speak(message.text, queueMode, null, message.requestId)
                    val response = com.example.domain.model.TtsSpeakResultMessage(
                        timestamp = System.currentTimeMillis(),
                        sessionId = message.sessionId,
                        requestId = message.requestId,
                        success = true
                    )
                    webSocketRepository.sendMessage(response)
                } else {
                    val response = com.example.domain.model.TtsSpeakResultMessage(
                        timestamp = System.currentTimeMillis(),
                        sessionId = message.sessionId,
                        requestId = message.requestId,
                        success = false,
                        errorMessage = "TextToSpeech engine not initialized"
                    )
                    webSocketRepository.sendMessage(response)
                }
            }
            is com.example.domain.model.NotificationPostMessage -> {
                logger.i("AppContainer", "Received remote notification post: title='${message.title}'")
                webSocketRepository.addLog("NOTIF: Posting notification '${message.title}'")
                val result = notificationRepository.showNotification(message.title, message.message)
                val success = result is com.example.capabilities.CapabilityResult.Success
                val response = com.example.domain.model.NotificationPostResultMessage(
                    timestamp = System.currentTimeMillis(),
                    sessionId = message.sessionId,
                    requestId = message.requestId,
                    success = success,
                    errorMessage = if (result is com.example.capabilities.CapabilityResult.Error) result.message else null
                )
                webSocketRepository.sendMessage(response)
            }
            is com.example.domain.model.ClipboardGetMessage -> {
                val result = clipboardRepository.readClipboard()
                val text = (result as? com.example.capabilities.CapabilityResult.Success)?.data ?: ""
                val response = com.example.domain.model.ClipboardGetResultMessage(
                    timestamp = System.currentTimeMillis(),
                    sessionId = message.sessionId,
                    requestId = message.requestId,
                    text = text,
                    success = true
                )
                webSocketRepository.sendMessage(response)
                webSocketRepository.addLog("CLIPBOARD: Read clipboard contents")
            }
            is com.example.domain.model.ClipboardSetMessage -> {
                val result = clipboardRepository.writeClipboard(message.text)
                val success = result is com.example.capabilities.CapabilityResult.Success
                val response = com.example.domain.model.ClipboardSetResultMessage(
                    timestamp = System.currentTimeMillis(),
                    sessionId = message.sessionId,
                    requestId = message.requestId,
                    success = success,
                    errorMessage = if (result is com.example.capabilities.CapabilityResult.Error) result.message else null
                )
                webSocketRepository.sendMessage(response)
                webSocketRepository.addLog("CLIPBOARD: Updated clipboard contents")
            }
            is com.example.domain.model.DeviceInfoGetMessage -> {
                val devInfoRes = deviceInfoRepository.getDeviceInfo()
                val devInfo = (devInfoRes as? com.example.capabilities.CapabilityResult.Success)?.data
                val batteryRes = batteryRepository.getBatteryInfo()
                val battery = (batteryRes as? com.example.capabilities.CapabilityResult.Success)?.data

                val actManager = context.getSystemService(Context.ACTIVITY_SERVICE) as? android.app.ActivityManager
                val memInfo = android.app.ActivityManager.MemoryInfo()
                actManager?.getMemoryInfo(memInfo)
                val availMb = memInfo.availMem / (1024 * 1024)
                val totalMb = memInfo.totalMem / (1024 * 1024)

                val response = com.example.domain.model.DeviceInfoResultMessage(
                    timestamp = System.currentTimeMillis(),
                    sessionId = message.sessionId,
                    requestId = message.requestId,
                    model = devInfo?.model ?: android.os.Build.MODEL,
                    manufacturer = devInfo?.manufacturer ?: android.os.Build.MANUFACTURER,
                    androidVersion = devInfo?.androidVersion ?: android.os.Build.VERSION.RELEASE,
                    sdkVersion = devInfo?.sdkVersion ?: android.os.Build.VERSION.SDK_INT,
                    batteryPercentage = battery?.percentage ?: 0f,
                    isCharging = battery?.isCharging ?: false,
                    batteryTemperature = battery?.temperature ?: 0f,
                    cpuAbi = devInfo?.cpuAbi ?: (android.os.Build.SUPPORTED_ABIS.firstOrNull() ?: "unknown"),
                    availableMemoryMb = availMb,
                    totalMemoryMb = totalMb
                )
                webSocketRepository.sendMessage(response)
                webSocketRepository.addLog("DEVICE: Dispatched telemetry (${response.model}, Battery: ${response.batteryPercentage}%)")
            }
            is com.example.domain.model.TorchSetMessage -> {
                applicationScope.launch(Dispatchers.IO) {
                    try {
                        val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as? android.hardware.camera2.CameraManager
                        val cameraId = cameraManager?.cameraIdList?.firstOrNull { id ->
                            val chars = cameraManager.getCameraCharacteristics(id)
                            chars.get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
                        }
                        if (cameraManager != null && cameraId != null) {
                            cameraManager.setTorchMode(cameraId, message.enabled)
                            val response = com.example.domain.model.TorchSetResultMessage(
                                timestamp = System.currentTimeMillis(),
                                sessionId = message.sessionId,
                                requestId = message.requestId,
                                enabled = message.enabled,
                                success = true
                            )
                            webSocketRepository.sendMessage(response)
                            webSocketRepository.addLog("TORCH: Flashlight set to ${if (message.enabled) "ON" else "OFF"}")
                        } else {
                            val response = com.example.domain.model.TorchSetResultMessage(
                                timestamp = System.currentTimeMillis(),
                                sessionId = message.sessionId,
                                requestId = message.requestId,
                                enabled = message.enabled,
                                success = false,
                                errorMessage = "No camera with flash unit available"
                            )
                            webSocketRepository.sendMessage(response)
                        }
                    } catch (e: Exception) {
                        val response = com.example.domain.model.TorchSetResultMessage(
                            timestamp = System.currentTimeMillis(),
                            sessionId = message.sessionId,
                            requestId = message.requestId,
                            enabled = message.enabled,
                            success = false,
                            errorMessage = e.message ?: "Torch control error"
                        )
                        webSocketRepository.sendMessage(response)
                    }
                }
            }
            is com.example.domain.model.LocationGetMessage -> {
                applicationScope.launch(Dispatchers.IO) {
                    val hasLocPermission = permissionManager.hasPermission(android.Manifest.permission.ACCESS_FINE_LOCATION) ||
                            permissionManager.hasPermission(android.Manifest.permission.ACCESS_COARSE_LOCATION)
                    if (!hasLocPermission) {
                        permissionEventBus.postAlert(
                            permission = android.Manifest.permission.ACCESS_FINE_LOCATION,
                            featureName = "Location (Termux)",
                            reasonMessage = "A location query was requested via script, but location permission is not granted."
                        )
                        val response = com.example.domain.model.LocationGetResultMessage(
                            timestamp = System.currentTimeMillis(),
                            sessionId = message.sessionId,
                            requestId = message.requestId,
                            success = false,
                            errorMessage = "PERMISSION_DENIED: Location permission required. Showing prompt on device."
                        )
                        webSocketRepository.sendMessage(response)
                        return@launch
                    }

                    val locResult = locationRepository.getCurrentLocation()
                    if (locResult is com.example.capabilities.CapabilityResult.Success) {
                        val loc = locResult.data
                        val response = com.example.domain.model.LocationGetResultMessage(
                            timestamp = System.currentTimeMillis(),
                            sessionId = message.sessionId,
                            requestId = message.requestId,
                            success = true,
                            latitude = loc.latitude,
                            longitude = loc.longitude,
                            altitude = loc.altitude,
                            accuracy = loc.accuracy,
                            speed = loc.speed
                        )
                        webSocketRepository.sendMessage(response)
                        webSocketRepository.addLog("LOCATION: Lat=${loc.latitude}, Lon=${loc.longitude}")
                    } else {
                        val response = com.example.domain.model.LocationGetResultMessage(
                            timestamp = System.currentTimeMillis(),
                            sessionId = message.sessionId,
                            requestId = message.requestId,
                            success = false,
                            errorMessage = "Location unavailable or GPS disabled"
                        )
                        webSocketRepository.sendMessage(response)
                    }
                }
            }
            is com.example.domain.model.MediaProbeRequestMessage -> {
                applicationScope.launch(Dispatchers.IO) {
                    try {
                        val uri = android.net.Uri.parse(message.mediaUri)
                        val info = mediaEngine.probe(uri)
                        if (info != null) {
                            val response = com.example.domain.model.MediaProbeResultMessage(
                                timestamp = System.currentTimeMillis(),
                                sessionId = message.sessionId,
                                requestId = message.requestId,
                                success = true,
                                container = info.container,
                                durationMs = (info.durationSeconds * 1000).toLong(),
                                videoCodec = info.videoStream?.codec,
                                audioCodec = info.audioStream?.codec,
                                width = info.videoStream?.width ?: 0,
                                height = info.videoStream?.height ?: 0,
                                bitrate = info.videoStream?.bitrate ?: 0L
                            )
                            webSocketRepository.sendMessage(response)
                            webSocketRepository.addLog("MEDIA PROBE: ${info.container} (${info.videoStream?.codec ?: "no video"}/${info.audioStream?.codec ?: "no audio"})")
                        } else {
                            val response = com.example.domain.model.MediaProbeResultMessage(
                                timestamp = System.currentTimeMillis(),
                                sessionId = message.sessionId,
                                requestId = message.requestId,
                                success = false,
                                errorMessage = "Failed to probe media file with FFprobe"
                            )
                            webSocketRepository.sendMessage(response)
                        }
                    } catch (e: Exception) {
                        val response = com.example.domain.model.MediaProbeResultMessage(
                            timestamp = System.currentTimeMillis(),
                            sessionId = message.sessionId,
                            requestId = message.requestId,
                            success = false,
                            errorMessage = e.message ?: "Media probe exception"
                        )
                        webSocketRepository.sendMessage(response)
                    }
                }
            }
            is com.example.domain.model.MediaConvertRequestMessage -> {
                applicationScope.launch(Dispatchers.IO) {
                    try {
                        val uri = android.net.Uri.parse(message.inputUri)
                        when (message.action) {
                            "thumbnail" -> {
                                val thumbPath = mediaEngine.generateThumbnail(uri, message.timestampSeconds)
                                val response = com.example.domain.model.MediaConvertResultMessage(
                                    timestamp = System.currentTimeMillis(),
                                    sessionId = message.sessionId,
                                    requestId = message.requestId,
                                    success = thumbPath != null,
                                    outputPath = thumbPath,
                                    errorMessage = if (thumbPath == null) "Thumbnail generation failed" else null
                                )
                                webSocketRepository.sendMessage(response)
                            }
                            "extract_audio" -> {
                                val audioPath = mediaEngine.extractAudio(uri)
                                val response = com.example.domain.model.MediaConvertResultMessage(
                                    timestamp = System.currentTimeMillis(),
                                    sessionId = message.sessionId,
                                    requestId = message.requestId,
                                    success = audioPath != null,
                                    outputPath = audioPath,
                                    errorMessage = if (audioPath == null) "Audio extraction failed" else null
                                )
                                webSocketRepository.sendMessage(response)
                            }
                            "remux" -> {
                                val result = mediaEngine.remux(uri)
                                val success = result is com.example.media.MediaConversionResult.Success
                                val outputPath = (result as? com.example.media.MediaConversionResult.Success)?.outputUri
                                val errorMessage = when (result) {
                                    is com.example.media.MediaConversionResult.Failure -> result.error
                                    is com.example.media.MediaConversionResult.Cancelled -> "Cancelled"
                                    else -> null
                                }
                                val response = com.example.domain.model.MediaConvertResultMessage(
                                    timestamp = System.currentTimeMillis(),
                                    sessionId = message.sessionId,
                                    requestId = message.requestId,
                                    success = success,
                                    outputPath = outputPath,
                                    errorMessage = errorMessage
                                )
                                webSocketRepository.sendMessage(response)
                            }
                            "transcode" -> {
                                val req = com.example.media.MediaConversionRequest(
                                    inputUri = message.inputUri,
                                    outputUri = message.outputUri,
                                    videoCodec = message.videoCodec ?: "libx264",
                                    audioCodec = message.audioCodec ?: "aac"
                                )
                                val result = mediaEngine.transcode(req)
                                val success = result is com.example.media.MediaConversionResult.Success
                                val outputPath = (result as? com.example.media.MediaConversionResult.Success)?.outputUri
                                val errorMessage = when (result) {
                                    is com.example.media.MediaConversionResult.Failure -> result.error
                                    is com.example.media.MediaConversionResult.Cancelled -> "Cancelled"
                                    else -> null
                                }
                                val response = com.example.domain.model.MediaConvertResultMessage(
                                    timestamp = System.currentTimeMillis(),
                                    sessionId = message.sessionId,
                                    requestId = message.requestId,
                                    success = success,
                                    outputPath = outputPath,
                                    errorMessage = errorMessage
                                )
                                webSocketRepository.sendMessage(response)
                            }
                        }
                    } catch (e: Exception) {
                        val response = com.example.domain.model.MediaConvertResultMessage(
                            timestamp = System.currentTimeMillis(),
                            sessionId = message.sessionId,
                            requestId = message.requestId,
                            success = false,
                            errorMessage = e.message ?: "Media conversion failed"
                        )
                        webSocketRepository.sendMessage(response)
                    }
                }
            }
            is com.example.domain.model.AccessibilityGestureMessage -> {
                logger.i("AppContainer", "Received remote accessibility gesture: ID=${message.gestureId}, Type=${message.gestureType}")
                val request = com.example.accessibility.models.GestureRequestModel(
                    id = message.gestureId,
                    type = message.gestureType,
                    startX = message.startX,
                    startY = message.startY,
                    endX = message.endX,
                    endY = message.endY,
                    durationMs = message.durationMs
                )
                accessibilityRepository.triggerGesture(request) { success ->
                    webSocketRepository.addLog("Gesture (${message.gestureType}) executed: success=$success")
                    if (!success) {
                        webSocketRepository.addLog("NOTE: Accessibility Service is disabled in Android Settings. Enable 'Termux Assistant' under Settings -> Accessibility.")
                    }
                }
            }
            is com.example.domain.model.AccessibilityInspectMessage -> {
                logger.i("AppContainer", "Received remote accessibility screen inspection request")
                applicationScope.launch {
                    try {
                        val isServiceActive = com.example.accessibility.AccessibilityServiceRegistry.activeService != null
                        val results = if (isServiceActive) {
                            if (message.searchByText != null || message.searchByDesc != null || message.searchById != null) {
                                accessibilityRepository.searchNodes(
                                    text = message.searchByText,
                                    contentDescription = message.searchByDesc,
                                    viewId = message.searchById
                                )
                            } else {
                                accessibilityRepository.getFullNodeTree()
                            }
                        } else {
                            webSocketRepository.addLog("INSPECT WARNING: Accessibility Service is not active. Enable 'Termux Assistant' in Settings -> Accessibility.")
                            emptyList()
                        }

                        val response = com.example.domain.model.AccessibilityInspectResultMessage(
                            timestamp = System.currentTimeMillis(),
                            sessionId = message.sessionId,
                            nodes = results,
                            queryExecuted = if (isServiceActive) "active_window" else "service_not_enabled"
                        )
                        webSocketRepository.sendMessage(response)
                        webSocketRepository.addLog("Dispatched inspection result back to Termux (${results.size} nodes).")
                    } catch (e: Exception) {
                        logger.e("AppContainer", "Failed to run accessibility node query remotely", e)
                    }
                }
            }
            is com.example.domain.model.CameraCaptureMessage -> {
                logger.i("AppContainer", "Received silent background camera capture request: lens=${message.lens}")
                webSocketRepository.addLog("CAMERA: Triggering silent background capture (${message.lens} lens)...")
                applicationScope.launch(Dispatchers.IO) {
                    try {
                        val hasCameraPermission = permissionManager.hasPermission(android.Manifest.permission.CAMERA)
                        if (!hasCameraPermission) {
                            logger.w("AppContainer", "Camera permission is NOT granted for silent photo capture! Posting alert to UI.")
                            webSocketRepository.addLog("CAMERA WARNING: Camera permission not granted. Showing permission prompt on device.")
                            permissionEventBus.postAlert(
                                permission = android.Manifest.permission.CAMERA,
                                featureName = "Camera Capture (Termux)",
                                reasonMessage = "A background photo capture task was requested via script, but the Camera permission has not been granted."
                            )
                            val errorResponse = com.example.domain.model.CameraCaptureResultMessage(
                                timestamp = System.currentTimeMillis(),
                                sessionId = message.sessionId,
                                requestId = message.requestId,
                                success = false,
                                errorMessage = "PERMISSION_DENIED: Camera permission is required for taking photos. A permission request popup has been triggered on the app."
                            )
                            webSocketRepository.sendMessage(errorResponse)
                            return@launch
                        }

                        val lensFacing = if (message.lens.equals("front", ignoreCase = true)) {
                            android.hardware.camera2.CameraCharacteristics.LENS_FACING_FRONT
                        } else {
                            android.hardware.camera2.CameraCharacteristics.LENS_FACING_BACK
                        }
                        val captureResult = backgroundCameraCaptureEngine.capturePhoto(lensFacing)
                        if (captureResult != null) {
                            val response = com.example.domain.model.CameraCaptureResultMessage(
                                timestamp = System.currentTimeMillis(),
                                sessionId = message.sessionId,
                                requestId = message.requestId,
                                success = true,
                                filePath = captureResult.filePath,
                                fileSize = captureResult.fileSize,
                                imageBase64 = captureResult.base64Data,
                                errorMessage = null
                            )
                            webSocketRepository.sendMessage(response)
                            webSocketRepository.addLog("CAMERA: Captured photo saved to ${captureResult.filePath} (${captureResult.fileSize / 1024} KB)")
                        } else {
                            val errorResponse = com.example.domain.model.CameraCaptureResultMessage(
                                timestamp = System.currentTimeMillis(),
                                sessionId = message.sessionId,
                                requestId = message.requestId,
                                success = false,
                                errorMessage = "Camera2 background capture failed. Ensure Camera permission is granted to the app."
                            )
                            webSocketRepository.sendMessage(errorResponse)
                            webSocketRepository.addLog("CAMERA ERROR: Failed to capture background photo.")
                        }
                    } catch (e: Exception) {
                        logger.e("AppContainer", "Background camera capture exception", e)
                        val errorResponse = com.example.domain.model.CameraCaptureResultMessage(
                            timestamp = System.currentTimeMillis(),
                            sessionId = message.sessionId,
                            requestId = message.requestId,
                            success = false,
                            errorMessage = e.localizedMessage ?: "Unknown Camera Error"
                        )
                        webSocketRepository.sendMessage(errorResponse)
                    }
                }
            }
            is com.example.domain.model.ToastShowMessage -> {
                logger.i("AppContainer", "Received Toast Show request: '${message.message}'")
                try {
                    toastCustomizer.showToast(
                        com.example.ui.overlay.ToastCustomizer.ToastOptions(
                            message = message.message,
                            duration = message.duration,
                            durationMs = message.durationMs,
                            gravity = message.gravity,
                            xOffset = message.xOffset,
                            yOffset = message.yOffset,
                            backgroundColor = message.backgroundColor,
                            textColor = message.textColor,
                            textSize = message.textSize,
                            cornerRadius = message.cornerRadius,
                            icon = message.icon,
                            alpha = message.alpha,
                            useOverlay = message.useOverlay
                        )
                    )
                    val response = com.example.domain.model.ToastShowResultMessage(
                        timestamp = System.currentTimeMillis(),
                        sessionId = message.sessionId,
                        requestId = message.requestId,
                        success = true
                    )
                    webSocketRepository.sendMessage(response)
                    webSocketRepository.addLog("TOAST: Displayed toast '${message.message.take(30)}'")
                } catch (e: Exception) {
                    val response = com.example.domain.model.ToastShowResultMessage(
                        timestamp = System.currentTimeMillis(),
                        sessionId = message.sessionId,
                        requestId = message.requestId,
                        success = false,
                        errorMessage = e.message ?: "Toast display error"
                    )
                    webSocketRepository.sendMessage(response)
                }
            }
            is com.example.domain.model.FloatingShowMessage -> {
                logger.i("AppContainer", "Received Floating Show request for '${message.floatingId}'")
                val hasPerm = floatingOverlayManager.hasPermission()
                if (!hasPerm) {
                    val response = com.example.domain.model.FloatingResultMessage(
                        timestamp = System.currentTimeMillis(),
                        sessionId = message.sessionId,
                        requestId = message.requestId,
                        success = false,
                        floatingId = message.floatingId,
                        permissionRequired = true,
                        errorMessage = "SYSTEM_ALERT_WINDOW (Display over other apps) permission not granted. Please enable in Settings."
                    )
                    webSocketRepository.sendMessage(response)
                    webSocketRepository.addLog("FLOATING ERROR: Overlay permission required")
                } else {
                    val shown = floatingOverlayManager.showFloating(
                        com.example.ui.overlay.FloatingOverlayManager.FloatingOptions(
                            floatingId = message.floatingId,
                            title = message.title,
                            text = message.text,
                            subText = message.subText,
                            type = message.overlayType,
                            backgroundColor = message.backgroundColor,
                            textColor = message.textColor,
                            accentColor = message.accentColor,
                            textSize = message.textSize,
                            cornerRadius = message.cornerRadius,
                            alpha = message.alpha,
                            gravity = message.gravity,
                            x = message.x,
                            y = message.y,
                            widthDp = message.widthDp,
                            heightDp = message.heightDp,
                            isDraggable = message.isDraggable,
                            showCloseButton = message.showCloseButton,
                            autoDismissSeconds = message.autoDismissSeconds
                        )
                    )
                    val response = com.example.domain.model.FloatingResultMessage(
                        timestamp = System.currentTimeMillis(),
                        sessionId = message.sessionId,
                        requestId = message.requestId,
                        success = shown,
                        floatingId = message.floatingId
                    )
                    webSocketRepository.sendMessage(response)
                    webSocketRepository.addLog("FLOATING: Displayed floating overlay '${message.floatingId}' (${message.type})")
                }
            }
            is com.example.domain.model.FloatingUpdateMessage -> {
                logger.i("AppContainer", "Received Floating Update request for '${message.floatingId}'")
                val updated = floatingOverlayManager.updateFloating(
                    floatingId = message.floatingId,
                    text = message.text,
                    title = message.title,
                    subText = message.subText,
                    backgroundColor = message.backgroundColor,
                    textColor = message.textColor
                )
                val response = com.example.domain.model.FloatingResultMessage(
                    timestamp = System.currentTimeMillis(),
                    sessionId = message.sessionId,
                    requestId = message.requestId,
                    success = updated,
                    floatingId = message.floatingId,
                    errorMessage = if (!updated) "Floating overlay '${message.floatingId}' not found or update failed" else null
                )
                webSocketRepository.sendMessage(response)
                webSocketRepository.addLog("FLOATING: Updated overlay '${message.floatingId}' (success=$updated)")
            }
            is com.example.domain.model.FloatingHideMessage -> {
                logger.i("AppContainer", "Received Floating Hide request")
                if (message.floatingId != null) {
                    val hidden = floatingOverlayManager.hideFloating(message.floatingId)
                    val response = com.example.domain.model.FloatingResultMessage(
                        timestamp = System.currentTimeMillis(),
                        sessionId = message.sessionId,
                        requestId = message.requestId,
                        success = hidden,
                        floatingId = message.floatingId
                    )
                    webSocketRepository.sendMessage(response)
                    webSocketRepository.addLog("FLOATING: Dismissed overlay '${message.floatingId}'")
                } else {
                    floatingOverlayManager.hideAllFloating()
                    val response = com.example.domain.model.FloatingResultMessage(
                        timestamp = System.currentTimeMillis(),
                        sessionId = message.sessionId,
                        requestId = message.requestId,
                        success = true
                    )
                    webSocketRepository.sendMessage(response)
                    webSocketRepository.addLog("FLOATING: Dismissed all active floating overlays")
                }
            }
            is com.example.domain.model.VibrateTriggerMessage -> {
                logger.i("AppContainer", "Received Vibrate Trigger request (preset=${message.preset}, dur=${message.durationMs}ms)")
                val ok = hapticsManager.vibrate(
                    durationMs = message.durationMs,
                    preset = message.preset,
                    pattern = message.patternMs,
                    amplitude = message.amplitude
                )
                val response = com.example.domain.model.VibrateTriggerResultMessage(
                    timestamp = System.currentTimeMillis(),
                    sessionId = message.sessionId,
                    requestId = message.requestId,
                    success = ok,
                    errorMessage = if (!ok) "Vibration not supported or hardware failed" else null
                )
                webSocketRepository.sendMessage(response)
                webSocketRepository.addLog("VIBRATE: Triggered haptic (success=$ok)")
            }
            is com.example.domain.model.AudioPlayMessage -> {
                logger.i("AppContainer", "Received Audio Play request (type=${message.soundType})")
                val ok = when (message.soundType?.lowercase()) {
                    "beep" -> soundPlayerManager.playBeep(toneType = message.beepTone)
                    "file" -> message.audioPath?.let { soundPlayerManager.playAudioFile(it, loop = message.loop) } ?: false
                    else -> soundPlayerManager.playSystemSound(type = message.soundType ?: "notification", loop = message.loop)
                }
                val response = com.example.domain.model.AudioPlayResultMessage(
                    timestamp = System.currentTimeMillis(),
                    sessionId = message.sessionId,
                    requestId = message.requestId,
                    success = ok,
                    errorMessage = if (!ok) "Failed to play audio resource" else null
                )
                webSocketRepository.sendMessage(response)
                webSocketRepository.addLog("AUDIO: Play sound type '${message.soundType}' (success=$ok)")
            }
            is com.example.domain.model.AudioStopMessage -> {
                soundPlayerManager.stop()
                val response = com.example.domain.model.AudioStopResultMessage(
                    timestamp = System.currentTimeMillis(),
                    sessionId = message.sessionId,
                    requestId = message.requestId,
                    success = true
                )
                webSocketRepository.sendMessage(response)
                webSocketRepository.addLog("AUDIO: Stopped audio playback")
            }
            is com.example.domain.model.VolumeGetMessage -> {
                logger.i("AppContainer", "Received Volume Get request")
                val status = volumeManager.getAudioStatus()
                val streamData = status.streams.map {
                    com.example.domain.model.StreamVolumeData(
                        stream = it.stream,
                        currentVolume = it.currentVolume,
                        maxVolume = it.maxVolume,
                        minVolume = it.minVolume,
                        percentage = it.percentage
                    )
                }
                val response = com.example.domain.model.VolumeGetResultMessage(
                    timestamp = System.currentTimeMillis(),
                    sessionId = message.sessionId,
                    requestId = message.requestId,
                    ringerMode = status.ringerMode,
                    isMusicActive = status.isMusicActive,
                    isSpeakerphoneOn = status.isSpeakerphoneOn,
                    streams = streamData
                )
                webSocketRepository.sendMessage(response)
                webSocketRepository.addLog("VOLUME: Fetched volume status (mode=${status.ringerMode})")
            }
            is com.example.domain.model.VolumeSetMessage -> {
                logger.i("AppContainer", "Received Volume Set request (stream=${message.stream}, vol=${message.volume})")
                var ok = true
                if (message.volume != null) {
                    ok = volumeManager.setStreamVolume(message.stream, message.volume, message.showUi)
                }
                if (message.ringerMode != null) {
                    ok = volumeManager.setRingerMode(message.ringerMode) && ok
                }
                val response = com.example.domain.model.VolumeSetResultMessage(
                    timestamp = System.currentTimeMillis(),
                    sessionId = message.sessionId,
                    requestId = message.requestId,
                    success = ok,
                    errorMessage = if (!ok) "Failed to set volume/ringer settings" else null
                )
                webSocketRepository.sendMessage(response)
                webSocketRepository.addLog("VOLUME: Set volume for ${message.stream} (success=$ok)")
            }
            is com.example.domain.model.AppListMessage -> {
                logger.i("AppContainer", "Received App List request")
                val list = appLauncherManager.getInstalledApps(message.includeSystem)
                val appData = list.map {
                    com.example.domain.model.AppEntryData(
                        appName = it.appName,
                        packageName = it.packageName,
                        versionName = it.versionName,
                        isSystemApp = it.isSystemApp
                    )
                }
                val response = com.example.domain.model.AppListResultMessage(
                    timestamp = System.currentTimeMillis(),
                    sessionId = message.sessionId,
                    requestId = message.requestId,
                    totalApps = appData.size,
                    apps = appData
                )
                webSocketRepository.sendMessage(response)
                webSocketRepository.addLog("APPS: Returned ${appData.size} installed applications")
            }
            is com.example.domain.model.AppLaunchMessage -> {
                logger.i("AppContainer", "Received App Launch request")
                val (ok, target) = when {
                    !message.packageName.isNullOrBlank() -> {
                        Pair(appLauncherManager.launchApp(message.packageName), message.packageName)
                    }
                    !message.url.isNullOrBlank() -> {
                        Pair(appLauncherManager.openUrl(message.url), message.url)
                    }
                    else -> Pair(false, null)
                }
                val response = com.example.domain.model.AppLaunchResultMessage(
                    timestamp = System.currentTimeMillis(),
                    sessionId = message.sessionId,
                    requestId = message.requestId,
                    success = ok,
                    launchedTarget = target,
                    errorMessage = if (!ok) "Target not found or launch failed" else null
                )
                webSocketRepository.sendMessage(response)
                webSocketRepository.addLog("APPS: Launched '$target' (success=$ok)")
            }
            is com.example.domain.model.MediaTrimMessage -> {
                applicationScope.launch(Dispatchers.IO) {
                    try {
                        val uri = android.net.Uri.parse(message.mediaUri)
                        val out = mediaEngine.trimVideo(uri, message.startSeconds, message.durationSeconds, message.exact)
                        val response = com.example.domain.model.MediaTrimResultMessage(
                            timestamp = System.currentTimeMillis(),
                            sessionId = message.sessionId,
                            requestId = message.requestId,
                            success = out != null,
                            outputPath = out,
                            errorMessage = if (out == null) "Trim operation failed" else null
                        )
                        webSocketRepository.sendMessage(response)
                        webSocketRepository.addLog("FFMPEG: Trimmed video (out: $out)")
                    } catch (e: Exception) {
                        val response = com.example.domain.model.MediaTrimResultMessage(
                            timestamp = System.currentTimeMillis(),
                            sessionId = message.sessionId,
                            requestId = message.requestId,
                            success = false,
                            errorMessage = e.message ?: "Trim failed"
                        )
                        webSocketRepository.sendMessage(response)
                    }
                }
            }
            is com.example.domain.model.MediaGifMessage -> {
                applicationScope.launch(Dispatchers.IO) {
                    try {
                        val uri = android.net.Uri.parse(message.mediaUri)
                        val out = mediaEngine.generateGif(uri, message.startSeconds, message.durationSeconds, message.fps, message.width)
                        val response = com.example.domain.model.MediaGifResultMessage(
                            timestamp = System.currentTimeMillis(),
                            sessionId = message.sessionId,
                            requestId = message.requestId,
                            success = out != null,
                            outputPath = out,
                            errorMessage = if (out == null) "GIF generation failed" else null
                        )
                        webSocketRepository.sendMessage(response)
                        webSocketRepository.addLog("FFMPEG: Created GIF (out: $out)")
                    } catch (e: Exception) {
                        val response = com.example.domain.model.MediaGifResultMessage(
                            timestamp = System.currentTimeMillis(),
                            sessionId = message.sessionId,
                            requestId = message.requestId,
                            success = false,
                            errorMessage = e.message ?: "GIF generation failed"
                        )
                        webSocketRepository.sendMessage(response)
                    }
                }
            }
            is com.example.domain.model.MediaSpeedMessage -> {
                applicationScope.launch(Dispatchers.IO) {
                    try {
                        val uri = android.net.Uri.parse(message.mediaUri)
                        val out = mediaEngine.changeSpeed(uri, message.speedFactor)
                        val response = com.example.domain.model.MediaSpeedResultMessage(
                            timestamp = System.currentTimeMillis(),
                            sessionId = message.sessionId,
                            requestId = message.requestId,
                            success = out != null,
                            outputPath = out,
                            errorMessage = if (out == null) "Speed change failed" else null
                        )
                        webSocketRepository.sendMessage(response)
                        webSocketRepository.addLog("FFMPEG: Changed speed x${message.speedFactor} (out: $out)")
                    } catch (e: Exception) {
                        val response = com.example.domain.model.MediaSpeedResultMessage(
                            timestamp = System.currentTimeMillis(),
                            sessionId = message.sessionId,
                            requestId = message.requestId,
                            success = false,
                            errorMessage = e.message ?: "Speed change failed"
                        )
                        webSocketRepository.sendMessage(response)
                    }
                }
            }
            is com.example.domain.model.MediaMuteMessage -> {
                applicationScope.launch(Dispatchers.IO) {
                    try {
                        val uri = android.net.Uri.parse(message.mediaUri)
                        val out = mediaEngine.muteVideo(uri)
                        val response = com.example.domain.model.MediaMuteResultMessage(
                            timestamp = System.currentTimeMillis(),
                            sessionId = message.sessionId,
                            requestId = message.requestId,
                            success = out != null,
                            outputPath = out,
                            errorMessage = if (out == null) "Mute operation failed" else null
                        )
                        webSocketRepository.sendMessage(response)
                        webSocketRepository.addLog("FFMPEG: Stripped audio (out: $out)")
                    } catch (e: Exception) {
                        val response = com.example.domain.model.MediaMuteResultMessage(
                            timestamp = System.currentTimeMillis(),
                            sessionId = message.sessionId,
                            requestId = message.requestId,
                            success = false,
                            errorMessage = e.message ?: "Mute failed"
                        )
                        webSocketRepository.sendMessage(response)
                    }
                }
            }
            is com.example.domain.model.SensorGetMessage -> {
                applicationScope.launch(Dispatchers.IO) {
                    val snap = sensorHubManager.getSnapshot()
                    val response = com.example.domain.model.SensorGetResultMessage(
                        timestamp = System.currentTimeMillis(),
                        sessionId = message.sessionId,
                        requestId = message.requestId,
                        accelerometer = snap.accelerometer?.let { com.example.domain.model.SensorVectorData(it.x, it.y, it.z) },
                        gyroscope = snap.gyroscope?.let { com.example.domain.model.SensorVectorData(it.x, it.y, it.z) },
                        magneticField = snap.magneticField?.let { com.example.domain.model.SensorVectorData(it.x, it.y, it.z) },
                        compassHeadingDegrees = snap.compassHeadingDegrees,
                        compassCardinal = snap.compassCardinal,
                        ambientLightLux = snap.ambientLightLux,
                        proximityCm = snap.proximityCm,
                        isNear = snap.isNear,
                        pressureHpa = snap.pressureHpa,
                        ambientTemperatureC = snap.ambientTemperatureC,
                        relativeHumidityPct = snap.relativeHumidityPct,
                        stepCount = snap.stepCount,
                        availableSensors = snap.availableSensorNames
                    )
                    webSocketRepository.sendMessage(response)
                    webSocketRepository.addLog("SENSOR: Dispatched snapshot (${snap.availableSensorNames.size} sensors)")
                }
            }
            is com.example.domain.model.DisplayGetMessage -> {
                val disp = displayPowerManager.getDisplayDetails()
                val response = com.example.domain.model.DisplayGetResultMessage(
                    timestamp = System.currentTimeMillis(),
                    sessionId = message.sessionId,
                    requestId = message.requestId,
                    widthPixels = disp.widthPixels,
                    heightPixels = disp.heightPixels,
                    densityDpi = disp.densityDpi,
                    densityScale = disp.densityScale,
                    refreshRateHz = disp.refreshRateHz,
                    orientation = disp.orientation,
                    isHdr = disp.isHdr,
                    currentBrightness = disp.currentBrightness,
                    isAutoBrightness = disp.isAutoBrightness,
                    screenTimeoutMs = disp.screenTimeoutMs,
                    isInteractive = disp.isInteractive,
                    isPowerSaveMode = disp.isPowerSaveMode
                )
                webSocketRepository.sendMessage(response)
                webSocketRepository.addLog("DISPLAY: Dispatched info (${disp.widthPixels}x${disp.heightPixels}, bright=${disp.currentBrightness})")
            }
            is com.example.domain.model.DisplaySetMessage -> {
                var ok = true
                var err: String? = null
                if (message.brightness != null) {
                    val brightOk = displayPowerManager.setBrightness(message.brightness)
                    if (!brightOk) {
                        ok = false
                        err = "Failed to set brightness (requires WRITE_SETTINGS permission)"
                    }
                }
                if (message.autoBrightness != null) {
                    val autoOk = displayPowerManager.setAutoBrightness(message.autoBrightness)
                    if (!autoOk) {
                        ok = false
                        err = "Failed to set auto-brightness"
                    }
                }
                if (message.keepScreenOn != null) {
                    if (message.keepScreenOn) {
                        displayPowerManager.acquireWakeLock()
                    } else {
                        displayPowerManager.releaseWakeLock()
                    }
                }
                val response = com.example.domain.model.DisplaySetResultMessage(
                    timestamp = System.currentTimeMillis(),
                    sessionId = message.sessionId,
                    requestId = message.requestId,
                    success = ok,
                    errorMessage = err
                )
                webSocketRepository.sendMessage(response)
                webSocketRepository.addLog("DISPLAY: Updated settings (success=$ok)")
            }
            is com.example.domain.model.NetworkTelemetryGetMessage -> {
                val net = networkTelemetryManager.getTelemetry()
                val response = com.example.domain.model.NetworkTelemetryGetResultMessage(
                    timestamp = System.currentTimeMillis(),
                    sessionId = message.sessionId,
                    requestId = message.requestId,
                    activeTransport = net.activeTransport,
                    isConnected = net.isConnected,
                    isMetered = net.isMetered,
                    wifi = net.wifi?.let {
                        com.example.domain.model.WifiInfoData(
                            ssid = it.ssid,
                            bssid = it.bssid,
                            rssiDbm = it.rssiDbm,
                            signalLevel = it.signalLevel,
                            linkSpeedMbps = it.linkSpeedMbps,
                            frequencyMhz = it.frequencyMhz,
                            wifiStandard = it.wifiStandard,
                            ipAddress = it.ipAddress
                        )
                    },
                    cellular = net.cellular?.let {
                        com.example.domain.model.CellularInfoData(
                            carrierName = it.carrierName,
                            networkType = it.networkType,
                            isRoaming = it.isRoaming,
                            simState = it.simState
                        )
                    },
                    localIpv4Addresses = net.localIpv4Addresses
                )
                webSocketRepository.sendMessage(response)
                webSocketRepository.addLog("NETWORK: Dispatched telemetry (transport=${net.activeTransport})")
            }
            is com.example.domain.model.DeviceDetailsGetMessage -> {
                val dev = deviceDetailsManager.getDeviceInfo()
                val response = com.example.domain.model.DeviceDetailsGetResultMessage(
                    timestamp = System.currentTimeMillis(),
                    sessionId = message.sessionId,
                    requestId = message.requestId,
                    manufacturer = dev.manufacturer,
                    model = dev.model,
                    brand = dev.brand,
                    board = dev.board,
                    hardware = dev.hardware,
                    androidVersion = dev.androidVersion,
                    sdkInt = dev.sdkInt,
                    securityPatch = dev.securityPatch,
                    primaryAbi = dev.primaryAbi,
                    supportedAbis = dev.supportedAbis,
                    cpuCores = dev.cpuCores,
                    ramTotalGb = dev.ramTotalGb,
                    ramAvailableGb = dev.ramAvailableGb,
                    ramUsedPct = dev.ramUsedPct,
                    storageTotalGb = dev.storageTotalGb,
                    storageFreeGb = dev.storageFreeGb,
                    storageUsedPct = dev.storageUsedPct,
                    uptimeSeconds = dev.uptimeSeconds,
                    batteryPct = dev.batteryPct,
                    isCharging = dev.isCharging,
                    batteryTempC = dev.batteryTempC,
                    isThermalThrottling = dev.isThermalThrottling
                )
                webSocketRepository.sendMessage(response)
                webSocketRepository.addLog("DEVICE: Dispatched detailed specs (${dev.manufacturer} ${dev.model})")
            }
            is com.example.domain.model.AiStreamMessage -> {
                if (message.action != null) {
                    val jsonObj = if (!message.rawJson.isNullOrBlank()) {
                        try { org.json.JSONObject(message.rawJson) } catch (e: Exception) { org.json.JSONObject() }
                    } else {
                        org.json.JSONObject().apply {
                            put("action", message.action)
                            put("text", message.text ?: message.textChunk)
                            put("message", message.message ?: message.textChunk)
                        }
                    }
                    handleAiStreamCommand(jsonObj)
                } else if (message.textChunk.isNotBlank()) {
                    webSocketRepository.addLog("Termux message: ${message.textChunk.trim()}")
                    try {
                        android.os.Handler(android.os.Looper.getMainLooper()).post {
                            android.widget.Toast.makeText(context, "Termux: ${message.textChunk.trim()}", android.widget.Toast.LENGTH_SHORT).show()
                        }
                    } catch (ignored: Exception) {}
                }
            }
            else -> {
                // Handled elsewhere
            }
        }
    }

    private fun handleRawIncomingWebSocketMessage(rawText: String) {
        val data = try { org.json.JSONObject(rawText) } catch (e: Exception) { return }
        val type = data.optString("type", "").uppercase()

        when (type) {
            "AI_STREAM" -> handleAiStreamCommand(data)
            "ACCESSIBILITY_GESTURE" -> handleAccessibilityGestureRaw(data)
            "ACCESSIBILITY_INSPECT" -> handleAccessibilityInspectRaw(data)
        }
    }

    fun sendAiResponse(action: String, data: Map<String, Any?>) {
        val json = org.json.JSONObject()
        json.put("type", "AI_STREAM_RESULT")
        json.put("action", action)
        json.put("success", data["success"] as? Boolean ?: true)
        for ((k, v) in data) {
            if (k != "success") {
                if (v is Map<*, *>) {
                    val subObj = org.json.JSONObject()
                    for ((subK, subV) in v) {
                        subObj.put(subK.toString(), subV)
                    }
                    json.put(k, subObj)
                } else if (v is List<*>) {
                    val arr = org.json.JSONArray()
                    for (item in v) {
                        if (item is Map<*, *>) {
                            val subObj = org.json.JSONObject()
                            for ((subK, subV) in item) {
                                subObj.put(subK.toString(), subV)
                            }
                            arr.put(subObj)
                        } else {
                            arr.put(item)
                        }
                    }
                    json.put(k, arr)
                } else {
                    json.put(k, v)
                }
            }
        }
        applicationScope.launch {
            webSocketRepository.sendRaw(json.toString())
            webSocketRepository.addLog("AI_STREAM_RESULT [$action]: success=${json.optBoolean("success")}")
        }
    }

    private fun checkPermissionStatus(permission: String): String {
        return if (ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED) {
            "AVAILABLE"
        } else {
            "PERMISSION_REQUIRED"
        }
    }

    private fun handleAiStreamCommand(data: org.json.JSONObject) {
        val action = data.optString("action", "").uppercase()
        if (action.isBlank()) {
            val textChunk = data.optString("textChunk", data.optString("text", data.optString("message", "")))
            if (textChunk.isNotBlank()) {
                webSocketRepository.addLog("Termux message: ${textChunk.trim()}")
                try {
                    android.os.Handler(android.os.Looper.getMainLooper()).post {
                        android.widget.Toast.makeText(context, "Termux: ${textChunk.trim()}", android.widget.Toast.LENGTH_SHORT).show()
                    }
                } catch (ignored: Exception) {}
            }
            return
        }

        logger.i("AppContainer", "Handling AI_STREAM command action: $action")
        webSocketRepository.addLog("AI_STREAM action: $action")

        try {
            when (action) {
                "TTS" -> {
                    val text = data.optString("text", data.optString("message", ""))
                    val pitch = data.optDouble("pitch", 1.0).toFloat()
                    val rate = data.optDouble("rate", 1.0).toFloat()
                    val tts = textToSpeech
                    if (tts != null) {
                        tts.setPitch(pitch)
                        tts.setSpeechRate(rate)
                        tts.speak(text, android.speech.tts.TextToSpeech.QUEUE_FLUSH, null, "acagent_tts")
                        sendAiResponse("TTS", mapOf("success" to true, "text" to text))
                    } else {
                        sendAiResponse("TTS", mapOf("success" to false, "error" to "TTS not initialized"))
                    }
                }
                "TOAST" -> {
                    val message = data.optString("message", data.optString("text", "Aura Alert"))
                    val icon = data.optString("icon", "info")
                    android.os.Handler(android.os.Looper.getMainLooper()).post {
                        toastCustomizer.showToast(
                            com.example.ui.overlay.ToastCustomizer.ToastOptions(
                                message = message,
                                icon = icon
                            )
                        )
                    }
                    sendAiResponse("TOAST", mapOf("success" to true, "message" to message))
                }
                "VIBRATE" -> {
                    val ok = if (data.has("durationMs")) {
                        val ms = data.optLong("durationMs", 100)
                        hapticsManager.vibrate(durationMs = ms)
                    } else {
                        val preset = data.optString("preset", "TICK")
                        hapticsManager.vibrate(preset = preset)
                    }
                    sendAiResponse("VIBRATE", mapOf("success" to ok))
                }
                "TORCH" -> {
                    val enabled = data.optBoolean("enabled", true)
                    val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as? android.hardware.camera2.CameraManager
                    var ok = false
                    var errorMsg: String? = null
                    try {
                        val cameraId = cameraManager?.cameraIdList?.firstOrNull { id ->
                            val chars = cameraManager.getCameraCharacteristics(id)
                            chars.get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
                        }
                        if (cameraManager != null && cameraId != null) {
                            cameraManager.setTorchMode(cameraId, enabled)
                            ok = true
                        } else {
                            errorMsg = "No flash unit available on device"
                        }
                    } catch (e: Exception) {
                        errorMsg = e.message
                    }
                    if (ok) {
                        sendAiResponse("TORCH", mapOf("success" to true, "enabled" to enabled))
                    } else {
                        sendAiResponse("TORCH", mapOf("success" to false, "error" to (errorMsg ?: "Failed to set torch")))
                    }
                }
                "AUDIO_PLAY" -> {
                    val type = data.optString("type", "notification")
                    val ok = soundPlayerManager.playSystemSound(type)
                    sendAiResponse("AUDIO_PLAY", mapOf("success" to ok, "type" to type))
                }
                "AUDIO_STOP" -> {
                    soundPlayerManager.stop()
                    sendAiResponse("AUDIO_STOP", mapOf("success" to true))
                }
                "VOLUME_GET" -> {
                    val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
                    sendAiResponse("VOLUME_GET", mapOf(
                        "success" to true,
                        "mediaVolume" to am.getStreamVolume(AudioManager.STREAM_MUSIC),
                        "mediaMax" to am.getStreamMaxVolume(AudioManager.STREAM_MUSIC),
                        "notifVolume" to am.getStreamVolume(AudioManager.STREAM_NOTIFICATION),
                        "ringVolume" to am.getStreamVolume(AudioManager.STREAM_RING),
                        "alarmVolume" to am.getStreamVolume(AudioManager.STREAM_ALARM),
                        "ringerMode" to when (am.ringerMode) {
                            AudioManager.RINGER_MODE_NORMAL -> "NORMAL"
                            AudioManager.RINGER_MODE_VIBRATE -> "VIBRATE"
                            AudioManager.RINGER_MODE_SILENT -> "SILENT"
                            else -> "UNKNOWN"
                        }
                    ))
                }
                "VOLUME_SET" -> {
                    val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
                    if (data.has("ringerMode")) {
                        volumeManager.setRingerMode(data.optString("ringerMode").uppercase())
                    } else {
                        val stream = data.optString("stream", "MEDIA")
                        val volume = data.optInt("volume", 5)
                        volumeManager.setStreamVolume(stream, volume)
                    }
                    sendAiResponse("VOLUME_SET", mapOf("success" to true))
                }
                "FLOATING_SHOW" -> {
                    val id = data.optString("floatingId", "default_floating")
                    val title = data.optString("title", "Aura System HUD")
                    val text = data.optString("text", "")
                    val subText = if (data.has("subText")) data.optString("subText") else null
                    val type = data.optString("type", "HUD")
                    val isDraggable = data.optBoolean("isDraggable", true)
                    val ok = floatingOverlayManager.showFloating(
                        com.example.ui.overlay.FloatingOverlayManager.FloatingOptions(
                            floatingId = id,
                            title = title,
                            text = text,
                            subText = subText,
                            type = type,
                            isDraggable = isDraggable
                        )
                    )
                    sendAiResponse("FLOATING_SHOW", mapOf("success" to ok, "floatingId" to id))
                }
                "FLOATING_HIDE" -> {
                    val id = data.optString("floatingId", "default_floating")
                    val ok = floatingOverlayManager.hideFloating(id)
                    sendAiResponse("FLOATING_HIDE", mapOf("success" to ok, "floatingId" to id))
                }
                "SENSORS" -> {
                    val snap = sensorHubManager.getSnapshot()
                    sendAiResponse("SENSORS", mapOf(
                        "success" to true,
                        "ambientLightLux" to (snap.ambientLightLux ?: 0f),
                        "pressureHpa" to (snap.pressureHpa ?: 1013.25f),
                        "compassHeadingDegrees" to (snap.compassHeadingDegrees ?: 0f),
                        "compassCardinal" to (snap.compassCardinal ?: "N"),
                        "proximityCm" to (snap.proximityCm ?: 5.0f),
                        "isNear" to (snap.isNear ?: false),
                        "accelerometer" to mapOf(
                            "x" to (snap.accelerometer?.x ?: 0f),
                            "y" to (snap.accelerometer?.y ?: 0f),
                            "z" to (snap.accelerometer?.z ?: 0f)
                        ),
                        "gyroscope" to mapOf(
                            "x" to (snap.gyroscope?.x ?: 0f),
                            "y" to (snap.gyroscope?.y ?: 0f),
                            "z" to (snap.gyroscope?.z ?: 0f)
                        )
                    ))
                }
                "DEVICE_INFO" -> {
                    val dev = deviceDetailsManager.getDeviceInfo()
                    sendAiResponse("DEVICE_INFO", mapOf(
                        "success" to true,
                        "manufacturer" to dev.manufacturer,
                        "model" to dev.model,
                        "androidVersion" to dev.androidVersion,
                        "sdkInt" to dev.sdkInt,
                        "cpuCores" to dev.cpuCores,
                        "ramTotalGb" to dev.ramTotalGb,
                        "ramAvailableGb" to dev.ramAvailableGb,
                        "ramUsedPct" to dev.ramUsedPct,
                        "storageTotalGb" to dev.storageTotalGb,
                        "storageFreeGb" to dev.storageFreeGb,
                        "batteryPct" to dev.batteryPct,
                        "batteryTempC" to dev.batteryTempC,
                        "isCharging" to dev.isCharging,
                        "isThermalThrottling" to dev.isThermalThrottling
                    ))
                }
                "NETWORK_INFO" -> {
                    val net = networkTelemetryManager.getTelemetry()
                    val wifiMap = net.wifi?.let {
                        mapOf(
                            "ssid" to it.ssid,
                            "rssiDbm" to it.rssiDbm,
                            "signalLevel" to it.signalLevel,
                            "linkSpeedMbps" to it.linkSpeedMbps,
                            "wifiStandard" to it.wifiStandard
                        )
                    } ?: emptyMap<String, Any>()
                    sendAiResponse("NETWORK_INFO", mapOf(
                        "success" to true,
                        "isConnected" to net.isConnected,
                        "activeTransport" to net.activeTransport,
                        "isMetered" to net.isMetered,
                        "localIpv4Addresses" to net.localIpv4Addresses,
                        "wifi" to wifiMap
                    ))
                }
                "APP_LIST" -> {
                    val includeSystem = data.optBoolean("includeSystem", false)
                    val filter = data.optString("filter", data.optString("query", ""))
                    var apps = appLauncherManager.getInstalledApps(includeSystem)
                    if (filter.isNotBlank()) {
                        apps = apps.filter { it.appName.contains(filter, ignoreCase = true) || it.packageName.contains(filter, ignoreCase = true) }
                    }
                    val appMaps = apps.map {
                        mapOf(
                            "label" to it.appName,
                            "appName" to it.appName,
                            "packageName" to it.packageName,
                            "versionName" to (it.versionName ?: ""),
                            "isSystemApp" to it.isSystemApp
                        )
                    }
                    sendAiResponse("APP_LIST", mapOf("success" to true, "totalApps" to appMaps.size, "apps" to appMaps))
                }
                "APP_LAUNCH" -> {
                    val pkg = data.optString("packageName", data.optString("app", data.optString("target", data.optString("query", ""))))
                    val url = data.optString("url", "")
                    val target = if (pkg.isNotBlank()) pkg else url
                    val ok = if (pkg.isNotBlank()) appLauncherManager.launchApp(pkg) else if (url.isNotBlank()) appLauncherManager.openUrl(url) else false
                    if (ok) {
                        sendAiResponse("APP_LAUNCH", mapOf("success" to true, "launchedTarget" to target))
                    } else {
                        sendAiResponse("APP_LAUNCH", mapOf("success" to false, "error" to "Could not find or launch target '$target'"))
                    }
                }
                "NOTIFICATION" -> {
                    val title = data.optString("title", "Aura Alert")
                    val message = data.optString("message", data.optString("text", ""))
                    val res = notificationRepository.showNotification(title, message)
                    sendAiResponse("NOTIFICATION", mapOf("success" to (res is com.example.capabilities.CapabilityResult.Success)))
                }
                "CLIPBOARD_SET" -> {
                    val text = data.optString("text", "")
                    val res = clipboardRepository.writeClipboard(text)
                    sendAiResponse("CLIPBOARD_SET", mapOf("success" to (res is com.example.capabilities.CapabilityResult.Success)))
                }
                "CLIPBOARD_GET" -> {
                    val res = clipboardRepository.readClipboard()
                    val text = (res as? com.example.capabilities.CapabilityResult.Success)?.data ?: ""
                    sendAiResponse("CLIPBOARD_GET", mapOf("success" to true, "text" to text))
                }
                "BRIGHTNESS" -> {
                    val level = data.optInt("brightness", 128)
                    val ok = displayPowerManager.setBrightness(level)
                    sendAiResponse("BRIGHTNESS", mapOf("success" to ok, "brightness" to level))
                }
                "CAPABILITIES" -> {
                    val isAccessibility = com.example.accessibility.AccessibilityServiceRegistry.activeService != null
                    val canOverlay = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) Settings.canDrawOverlays(context) else true
                    val caps = listOf(
                        mapOf("name" to "TTS", "category" to "AUDIO", "status" to "AVAILABLE"),
                        mapOf("name" to "MICROPHONE", "category" to "AUDIO", "status" to checkPermissionStatus(Manifest.permission.RECORD_AUDIO)),
                        mapOf("name" to "CAMERA", "category" to "CAMERA", "status" to checkPermissionStatus(Manifest.permission.CAMERA)),
                        mapOf("name" to "TORCH", "category" to "CAMERA", "status" to "AVAILABLE"),
                        mapOf("name" to "VIBRATOR", "category" to "HAPTICS", "status" to "AVAILABLE"),
                        mapOf("name" to "ACCELEROMETER", "category" to "SENSORS", "status" to "AVAILABLE"),
                        mapOf("name" to "GYROSCOPE", "category" to "SENSORS", "status" to "AVAILABLE"),
                        mapOf("name" to "LIGHT_SENSOR", "category" to "SENSORS", "status" to "AVAILABLE"),
                        mapOf("name" to "GPS", "category" to "LOCATION", "status" to checkPermissionStatus(Manifest.permission.ACCESS_FINE_LOCATION)),
                        mapOf("name" to "WIFI", "category" to "NETWORK", "status" to "AVAILABLE"),
                        mapOf("name" to "NOTIFICATIONS", "category" to "NOTIFICATIONS", "status" to if (android.os.Build.VERSION.SDK_INT >= 33) checkPermissionStatus(Manifest.permission.POST_NOTIFICATIONS) else "AVAILABLE"),
                        mapOf("name" to "CLIPBOARD", "category" to "STORAGE", "status" to "AVAILABLE"),
                        mapOf("name" to "ACCESSIBILITY", "category" to "ACCESSIBILITY", "status" to if (isAccessibility) "AVAILABLE" else "PERMISSION_REQUIRED"),
                        mapOf("name" to "FLOATING_HUD", "category" to "DISPLAY", "status" to if (canOverlay) "AVAILABLE" else "PERMISSION_REQUIRED"),
                        mapOf("name" to "FFMPEG_MEDIA", "category" to "MEDIA", "status" to "AVAILABLE"),
                        mapOf("name" to "APP_LAUNCHER", "category" to "SYSTEM", "status" to "AVAILABLE"),
                        mapOf("name" to "VOLUME_CONTROL", "category" to "AUDIO", "status" to "AVAILABLE"),
                        mapOf("name" to "BATTERY_MONITOR", "category" to "HARDWARE", "status" to "AVAILABLE")
                    )
                    sendAiResponse("CAPABILITIES", mapOf("success" to true, "totalCapabilities" to caps.size, "capabilities" to caps))
                }
                "LOCATION", "GPS" -> {
                    applicationScope.launch {
                        val loc = locationRepository.getCurrentLocation()
                        if (loc is com.example.capabilities.CapabilityResult.Success && loc.data != null) {
                            sendAiResponse("LOCATION", mapOf(
                                "success" to true,
                                "latitude" to loc.data.latitude,
                                "longitude" to loc.data.longitude,
                                "altitude" to loc.data.altitude,
                                "speed" to loc.data.speed,
                                "heading" to loc.data.heading,
                                "accuracy" to loc.data.accuracy
                            ))
                        } else {
                            sendAiResponse("LOCATION", mapOf("success" to false, "error" to "Location unavailable"))
                        }
                    }
                }
                "CAMERA_CAPTURE", "PHOTO" -> {
                    applicationScope.launch {
                        val res = backgroundCameraCaptureEngine.takePicture()
                        if (res is com.example.capabilities.CapabilityResult.Success && res.data != null) {
                            sendAiResponse("CAMERA_CAPTURE", mapOf("success" to true, "filePath" to res.data))
                        } else {
                            sendAiResponse("CAMERA_CAPTURE", mapOf("success" to false, "error" to "Camera capture unavailable"))
                        }
                    }
                }
                "DISPLAY_INFO" -> {
                    val disp = displayPowerManager.getDisplayDetails()
                    sendAiResponse("DISPLAY_INFO", mapOf(
                        "success" to true,
                        "widthPx" to disp.widthPixels,
                        "heightPx" to disp.heightPixels,
                        "densityDpi" to disp.densityDpi,
                        "refreshRateHz" to disp.refreshRateHz,
                        "orientation" to disp.orientation,
                        "isHdr" to disp.isHdr,
                        "brightness" to disp.currentBrightness,
                        "isInteractive" to disp.isInteractive,
                        "isPowerSaveMode" to disp.isPowerSaveMode
                    ))
                }
                "MEDIA_PROBE" -> {
                    val uriStr = data.optString("uri", data.optString("path", ""))
                    if (uriStr.isNotBlank()) {
                        applicationScope.launch {
                            val probe = mediaEngine.probe(android.net.Uri.parse(uriStr))
                            if (probe != null) {
                                sendAiResponse("MEDIA_PROBE", mapOf(
                                    "success" to true,
                                    "durationSeconds" to probe.durationSeconds,
                                    "container" to (probe.container ?: "unknown"),
                                    "bitrate" to (probe.videoStream?.bitrate ?: probe.audioStream?.bitrate ?: 0L),
                                    "width" to (probe.videoStream?.width ?: 0),
                                    "height" to (probe.videoStream?.height ?: 0),
                                    "codec" to (probe.videoStream?.codec ?: "unknown")
                                ))
                            } else {
                                sendAiResponse("MEDIA_PROBE", mapOf("success" to false, "error" to "Probe failed"))
                            }
                        }
                    } else {
                        sendAiResponse("MEDIA_PROBE", mapOf("success" to false, "error" to "Missing uri"))
                    }
                }
                "MEDIA_TRIM" -> {
                    val uriStr = data.optString("uri", "")
                    val startSec = data.optDouble("startSeconds", 0.0)
                    val durSec = data.optDouble("durationSeconds", 5.0)
                    applicationScope.launch {
                        val outPath = mediaEngine.trimVideo(android.net.Uri.parse(uriStr), startSec, durSec)
                        sendAiResponse("MEDIA_TRIM", mapOf("success" to (outPath != null), "outputPath" to (outPath ?: "")))
                    }
                }
                "MEDIA_GIF" -> {
                    val uriStr = data.optString("uri", "")
                    val startSec = data.optDouble("startSeconds", 0.0)
                    val durSec = data.optDouble("durationSeconds", 3.0)
                    applicationScope.launch {
                        val outPath = mediaEngine.generateGif(android.net.Uri.parse(uriStr), startSec, durSec)
                        sendAiResponse("MEDIA_GIF", mapOf("success" to (outPath != null), "outputPath" to (outPath ?: "")))
                    }
                }
                "MEDIA_MUTE" -> {
                    val uriStr = data.optString("uri", "")
                    applicationScope.launch {
                        val outPath = mediaEngine.muteVideo(android.net.Uri.parse(uriStr))
                        sendAiResponse("MEDIA_MUTE", mapOf("success" to (outPath != null), "outputPath" to (outPath ?: "")))
                    }
                }
                "MEDIA_SPEED" -> {
                    val uriStr = data.optString("uri", "")
                    val speed = data.optDouble("speedFactor", 1.5)
                    applicationScope.launch {
                        val outPath = mediaEngine.changeSpeed(android.net.Uri.parse(uriStr), speed)
                        sendAiResponse("MEDIA_SPEED", mapOf("success" to (outPath != null), "outputPath" to (outPath ?: "")))
                    }
                }
                "WAKE_LOCK" -> {
                    val acquire = data.optBoolean("acquire", true)
                    val ok = if (acquire) displayPowerManager.acquireWakeLock() else { displayPowerManager.releaseWakeLock(); true }
                    sendAiResponse("WAKE_LOCK", mapOf("success" to ok, "acquired" to acquire))
                }
                else -> {
                    sendAiResponse("ERROR", mapOf("success" to false, "error" to "Unknown action: $action"))
                }
            }
        } catch (e: Exception) {
            logger.e("AppContainer", "Error handling AI_STREAM action $action: ${e.message}", e)
            sendAiResponse(action, mapOf("success" to false, "error" to (e.message ?: "Execution failed")))
        }
    }

    private fun handleAccessibilityGestureRaw(data: org.json.JSONObject) {
        val action = data.optString("action", data.optString("gestureType", "CLICK")).uppercase()
        val durationMs = data.optLong("durationMs", 100L)
        val serviceActive = com.example.accessibility.AccessibilityServiceRegistry.activeService != null

        if (!serviceActive) {
            webSocketRepository.addLog("ACCESSIBILITY WARNING: Accessibility Service not active. Enable Termux Assistant in Settings.")
            return
        }

        when (action) {
            "TAP", "CLICK" -> {
                if (data.has("text") || data.has("label")) {
                    val searchLabel = data.optString("text", data.optString("label", ""))
                    accessibilityRepository.clickNodeByText(searchLabel) { ok ->
                        webSocketRepository.addLog("ACCESSIBILITY TAP text='$searchLabel': success=$ok")
                    }
                } else {
                    val x = data.optDouble("x", data.optDouble("startX", 0.0)).toFloat()
                    val y = data.optDouble("y", data.optDouble("startY", 0.0)).toFloat()
                    val req = com.example.accessibility.models.GestureRequestModel(
                        id = "tap-" + System.currentTimeMillis(),
                        type = "CLICK",
                        startX = x,
                        startY = y,
                        durationMs = durationMs
                    )
                    accessibilityRepository.triggerGesture(req) { ok ->
                        webSocketRepository.addLog("ACCESSIBILITY TAP at ($x, $y): success=$ok")
                    }
                }
            }
            "SWIPE", "DRAG" -> {
                val startX = data.optDouble("startX", 500.0).toFloat()
                val startY = data.optDouble("startY", 1500.0).toFloat()
                val endX = data.optDouble("endX", 500.0).toFloat()
                val endY = data.optDouble("endY", 300.0).toFloat()
                val req = com.example.accessibility.models.GestureRequestModel(
                    id = "swipe-" + System.currentTimeMillis(),
                    type = "SWIPE",
                    startX = startX,
                    startY = startY,
                    endX = endX,
                    endY = endY,
                    durationMs = durationMs
                )
                accessibilityRepository.triggerGesture(req) { ok ->
                    webSocketRepository.addLog("ACCESSIBILITY SWIPE from ($startX, $startY) to ($endX, $endY): success=$ok")
                }
            }
            "BACK" -> {
                val req = com.example.accessibility.models.GestureRequestModel(id = "back", type = "BACK", startX = 0f, startY = 0f)
                accessibilityRepository.triggerGesture(req) { }
            }
            "HOME" -> {
                val req = com.example.accessibility.models.GestureRequestModel(id = "home", type = "HOME", startX = 0f, startY = 0f)
                accessibilityRepository.triggerGesture(req) { }
            }
            "RECENTS" -> {
                val req = com.example.accessibility.models.GestureRequestModel(id = "recents", type = "RECENTS", startX = 0f, startY = 0f)
                accessibilityRepository.triggerGesture(req) { }
            }
            "NOTIFICATIONS" -> {
                val req = com.example.accessibility.models.GestureRequestModel(id = "notif", type = "NOTIFICATIONS", startX = 0f, startY = 0f)
                accessibilityRepository.triggerGesture(req) { }
            }
            "NEXT", "SCROLL_DOWN", "SCROLL_FORWARD" -> {
                accessibilityRepository.performScroll(forward = true) { ok ->
                    webSocketRepository.addLog("ACCESSIBILITY SCROLL_DOWN: success=$ok")
                }
            }
            "SCROLL_UP", "SCROLL_BACKWARD" -> {
                accessibilityRepository.performScroll(forward = false) { ok ->
                    webSocketRepository.addLog("ACCESSIBILITY SCROLL_UP: success=$ok")
                }
            }
        }
    }

    private fun handleAccessibilityInspectRaw(data: org.json.JSONObject) {
        val isServiceActive = com.example.accessibility.AccessibilityServiceRegistry.activeService != null
        val searchByText = if (data.has("searchByText")) data.optString("searchByText") else if (data.has("text")) data.optString("text") else null
        val searchByDesc = if (data.has("searchByDesc")) data.optString("searchByDesc") else if (data.has("desc")) data.optString("desc") else null
        val searchById = if (data.has("searchById")) data.optString("searchById") else if (data.has("viewId")) data.optString("viewId") else null

        val results = if (isServiceActive) {
            if (searchByText != null || searchByDesc != null || searchById != null) {
                accessibilityRepository.searchNodes(
                    text = searchByText,
                    contentDescription = searchByDesc,
                    viewId = searchById
                )
            } else {
                accessibilityRepository.getFullNodeTree()
            }
        } else {
            emptyList()
        }

        val respJson = org.json.JSONObject()
        respJson.put("type", "ACCESSIBILITY_INSPECT_RESULT")
        respJson.put("timestamp", System.currentTimeMillis())
        respJson.put("sessionId", data.optString("sessionId", "inspect"))
        respJson.put("success", isServiceActive)
        val arr = org.json.JSONArray()
        fun nodeToJson(node: com.example.accessibility.models.AccessibilityNodeModel): org.json.JSONObject {
            return org.json.JSONObject().apply {
                put("className", node.className ?: "")
                put("text", node.text ?: "")
                put("contentDescription", node.contentDescription ?: "")
                put("viewId", node.viewId ?: "")
                put("isClickable", node.isClickable)
                put("isScrollable", node.isScrollable)
                put("bounds", node.bounds)
                put("boundsInScreen", node.bounds)
                val cArr = org.json.JSONArray()
                for (child in node.children) {
                    cArr.put(nodeToJson(child))
                }
                put("children", cArr)
            }
        }
        for (rootNode in results) {
            arr.put(nodeToJson(rootNode))
        }
        respJson.put("nodes", arr)

        applicationScope.launch {
            webSocketRepository.sendRaw(respJson.toString())
            webSocketRepository.addLog("INSPECT: Returned ${results.size} root UI node(s)")
        }
    }

    private fun handleHttpRestApi(endpoint: String, json: org.json.JSONObject): org.json.JSONObject {
        val result = org.json.JSONObject()
        try {
            when (endpoint) {
                "/api/tts" -> {
                    val text = json.optString("text", json.optString("message", "Hello from Aura"))
                    val pitch = json.optDouble("pitch", 1.0).toFloat()
                    val rate = json.optDouble("rate", 1.0).toFloat()
                    textToSpeech?.setPitch(pitch)
                    textToSpeech?.setSpeechRate(rate)
                    textToSpeech?.speak(text, android.speech.tts.TextToSpeech.QUEUE_FLUSH, null, "aura_http_tts")
                    result.put("success", true)
                    result.put("spokenText", text)
                }
                "/api/toast" -> {
                    val msg = json.optString("message", json.optString("text", "Aura Alert"))
                    val icon = json.optString("icon", "info")
                    val gravity = json.optString("gravity", "BOTTOM")
                    toastCustomizer.showToast(
                        com.example.ui.overlay.ToastCustomizer.ToastOptions(
                            message = msg,
                            icon = icon,
                            gravity = gravity,
                            backgroundColor = json.optString("backgroundColor", null),
                            textColor = json.optString("textColor", null)
                        )
                    )
                    result.put("success", true)
                    result.put("message", msg)
                }
                "/api/vibrate" -> {
                    val preset = json.optString("preset", null)
                    val dur = json.optLong("durationMs", 100L)
                    val ok = hapticsManager.vibrate(durationMs = dur, preset = preset)
                    result.put("success", ok)
                }
                "/api/audio/play" -> {
                    val type = json.optString("type", "notification")
                    val ok = soundPlayerManager.playSystemSound(type)
                    result.put("success", ok)
                }
                "/api/audio/stop" -> {
                    soundPlayerManager.stop()
                    result.put("success", true)
                }
                "/api/volume" -> {
                    if (json.has("stream") || json.has("volume") || json.has("ringerMode")) {
                        val stream = json.optString("stream", "MEDIA")
                        val vol = if (json.has("volume")) json.optInt("volume") else null
                        val rMode = json.optString("ringerMode", null)
                        if (vol != null) volumeManager.setStreamVolume(stream, vol)
                        if (rMode != null) volumeManager.setRingerMode(rMode)
                        result.put("success", true)
                    } else {
                        val status = volumeManager.getAudioStatus()
                        result.put("success", true)
                        result.put("ringerMode", status.ringerMode)
                        val arr = org.json.JSONArray()
                        status.streams.forEach {
                            arr.put(org.json.JSONObject().apply {
                                put("stream", it.stream)
                                put("volume", it.currentVolume)
                                put("max", it.maxVolume)
                                put("percentage", it.percentage)
                            })
                        }
                        result.put("streams", arr)
                    }
                }
                "/api/app/list" -> {
                    val includeSystem = json.optBoolean("includeSystem", false) || json.optBoolean("system", false) || json.optString("system", "").equals("true", ignoreCase = true)
                    val filter = json.optString("filter", "").ifBlank { json.optString("query", "").ifBlank { json.optString("search", "") } }
                    var apps = appLauncherManager.getInstalledApps(includeSystem)
                    if (filter.isNotBlank()) {
                        apps = apps.filter { it.appName.contains(filter, ignoreCase = true) || it.packageName.contains(filter, ignoreCase = true) }
                    }
                    val arr = org.json.JSONArray()
                    apps.forEach {
                        arr.put(org.json.JSONObject().apply {
                            put("appName", it.appName)
                            put("packageName", it.packageName)
                            put("versionName", it.versionName)
                            put("isSystemApp", it.isSystemApp)
                        })
                    }
                    result.put("success", true)
                    result.put("totalApps", apps.size)
                    result.put("apps", arr)
                }
                "/api/app/launch" -> {
                    val pkg = json.optString("packageName", "").ifBlank { json.optString("app", "").ifBlank { json.optString("query", "").ifBlank { json.optString("target", "") } } }
                    val url = json.optString("url", "")
                    val target = if (pkg.isNotBlank()) pkg else url
                    val ok = if (pkg.isNotBlank()) appLauncherManager.launchApp(pkg) else if (url.isNotBlank()) appLauncherManager.openUrl(url) else false
                    result.put("success", ok)
                    result.put("target", target)
                    if (!ok) {
                        result.put("error", if (target.isBlank()) "No app name or package specified" else "Could not find or launch '$target'")
                    }
                }
                "/api/torch" -> {
                    val enable = json.optBoolean("enabled", true)
                    var ok = false
                    try {
                        val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as? android.hardware.camera2.CameraManager
                        val cameraId = cameraManager?.cameraIdList?.firstOrNull { id ->
                            val chars = cameraManager.getCameraCharacteristics(id)
                            chars.get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
                        }
                        if (cameraManager != null && cameraId != null) {
                            cameraManager.setTorchMode(cameraId, enable)
                            ok = true
                        }
                    } catch (e: Exception) {
                        logger.e("AppContainer", "HTTP torch toggle failed", e)
                    }
                    result.put("success", ok)
                    result.put("torchEnabled", enable)
                }
                "/api/floating" -> {
                    val title = json.optString("title", "⚡ Aura Remote")
                    val text = json.optString("text", "Aura Floating HUD")
                    val subText = if (json.has("subText")) json.optString("subText") else null
                    val type = json.optString("type", "HUD")
                    val floatingId = json.optString("floatingId", "http_float")
                    val isDraggable = json.optBoolean("isDraggable", true)
                    val gravity = json.optString("gravity", "TOP_RIGHT")
                    val autoDismiss = json.optInt("autoDismiss", json.optInt("autoDismissSeconds", 0))

                    if (!floatingOverlayManager.hasPermission()) {
                        // Display as toast so user receives instant visual feedback
                        android.os.Handler(android.os.Looper.getMainLooper()).post {
                            toastCustomizer.showToast(
                                com.example.ui.overlay.ToastCustomizer.ToastOptions(
                                    message = "[$title] $text",
                                    icon = "layers"
                                )
                            )
                        }
                        result.put("success", false)
                        result.put("displayedAsToast", true)
                        result.put("error", "SYSTEM_ALERT_WINDOW permission required for persistent floating overlay. Enable 'Display over other apps' in Android Settings -> Apps -> Aura.")
                    } else {
                        val shown = floatingOverlayManager.showFloating(
                            com.example.ui.overlay.FloatingOverlayManager.FloatingOptions(
                                floatingId = floatingId,
                                title = title,
                                text = text,
                                subText = subText,
                                type = type,
                                gravity = gravity,
                                isDraggable = isDraggable,
                                autoDismissSeconds = autoDismiss
                            )
                        )
                        result.put("success", shown)
                        result.put("floatingId", floatingId)
                    }
                }
                "/api/notification" -> {
                    val title = json.optString("title", "Aura Notification")
                    val body = json.optString("message", json.optString("text", "Hello from HTTP API"))
                    val notifResult = notificationRepository.showNotification(title, body)
                    val ok = notifResult is com.example.capabilities.CapabilityResult.Success
                    result.put("success", ok)
                }
                "/api/sensors" -> {
                    val snap = sensorHubManager.getSnapshot()
                    result.put("success", true)
                    result.put("availableSensors", org.json.JSONArray(snap.availableSensorNames))
                    snap.ambientLightLux?.let { result.put("ambientLightLux", it.toDouble()) }
                    snap.proximityCm?.let { result.put("proximityCm", it.toDouble()) }
                    snap.isNear?.let { result.put("isNear", it) }
                    snap.pressureHpa?.let { result.put("pressureHpa", it.toDouble()) }
                    snap.compassHeadingDegrees?.let { result.put("compassHeadingDegrees", it.toDouble()) }
                    snap.compassCardinal?.let { result.put("compassCardinal", it) }
                    snap.stepCount?.let { result.put("stepCount", it.toDouble()) }
                    snap.accelerometer?.let {
                        result.put("accelerometer", org.json.JSONObject().apply {
                            put("x", it.x.toDouble())
                            put("y", it.y.toDouble())
                            put("z", it.z.toDouble())
                        })
                    }
                    snap.gyroscope?.let {
                        result.put("gyroscope", org.json.JSONObject().apply {
                            put("x", it.x.toDouble())
                            put("y", it.y.toDouble())
                            put("z", it.z.toDouble())
                        })
                    }
                }
                "/api/display" -> {
                    if (json.has("brightness") || json.has("autoBrightness") || json.has("keepScreenOn")) {
                        if (json.has("brightness")) displayPowerManager.setBrightness(json.optInt("brightness"))
                        if (json.has("autoBrightness")) displayPowerManager.setAutoBrightness(json.optBoolean("autoBrightness"))
                        if (json.has("keepScreenOn")) {
                            if (json.optBoolean("keepScreenOn")) {
                                displayPowerManager.acquireWakeLock()
                            } else {
                                displayPowerManager.releaseWakeLock()
                            }
                        }
                        result.put("success", true)
                    } else {
                        val disp = displayPowerManager.getDisplayDetails()
                        result.put("success", true)
                        result.put("widthPixels", disp.widthPixels)
                        result.put("heightPixels", disp.heightPixels)
                        result.put("densityDpi", disp.densityDpi)
                        result.put("refreshRateHz", disp.refreshRateHz.toDouble())
                        result.put("orientation", disp.orientation)
                        result.put("currentBrightness", disp.currentBrightness)
                        result.put("isAutoBrightness", disp.isAutoBrightness)
                        result.put("screenTimeoutMs", disp.screenTimeoutMs)
                        result.put("isInteractive", disp.isInteractive)
                        result.put("isPowerSaveMode", disp.isPowerSaveMode)
                    }
                }
                "/api/network" -> {
                    val net = networkTelemetryManager.getTelemetry()
                    result.put("success", true)
                    result.put("activeTransport", net.activeTransport)
                    result.put("isConnected", net.isConnected)
                    result.put("isMetered", net.isMetered)
                    result.put("localIpv4Addresses", org.json.JSONArray(net.localIpv4Addresses))
                    net.wifi?.let {
                        result.put("wifi", org.json.JSONObject().apply {
                            put("ssid", it.ssid)
                            put("rssiDbm", it.rssiDbm)
                            put("signalLevel", it.signalLevel)
                            put("linkSpeedMbps", it.linkSpeedMbps)
                            put("wifiStandard", it.wifiStandard)
                            put("ipAddress", it.ipAddress ?: "")
                        })
                    }
                    net.cellular?.let {
                        result.put("cellular", org.json.JSONObject().apply {
                            put("carrierName", it.carrierName)
                            put("networkType", it.networkType)
                            put("isRoaming", it.isRoaming)
                        })
                    }
                }
                "/api/device" -> {
                    val dev = deviceDetailsManager.getDeviceInfo()
                    result.put("success", true)
                    result.put("manufacturer", dev.manufacturer)
                    result.put("model", dev.model)
                    result.put("androidVersion", dev.androidVersion)
                    result.put("sdkInt", dev.sdkInt)
                    result.put("cpuCores", dev.cpuCores)
                    result.put("ramTotalGb", dev.ramTotalGb)
                    result.put("ramAvailableGb", dev.ramAvailableGb)
                    result.put("ramUsedPct", dev.ramUsedPct)
                    result.put("storageTotalGb", dev.storageTotalGb)
                    result.put("storageFreeGb", dev.storageFreeGb)
                    result.put("storageUsedPct", dev.storageUsedPct)
                    result.put("uptimeSeconds", dev.uptimeSeconds)
                    result.put("batteryPct", dev.batteryPct)
                    result.put("isCharging", dev.isCharging)
                    result.put("batteryTempC", dev.batteryTempC)
                    result.put("isThermalThrottling", dev.isThermalThrottling)
                }
                "/api/clipboard" -> {
                    if (json.has("text") && json.optString("text").isNotBlank()) {
                        val text = json.optString("text")
                        val res = clipboardRepository.writeClipboard(text)
                        result.put("success", res is com.example.capabilities.CapabilityResult.Success)
                    } else {
                        val res = clipboardRepository.readClipboard()
                        val text = (res as? com.example.capabilities.CapabilityResult.Success)?.data ?: ""
                        result.put("success", true)
                        result.put("text", text)
                    }
                }
                "/api/screen/brightness" -> {
                    val level = json.optInt("brightness", 128)
                    val ok = displayPowerManager.setBrightness(level)
                    result.put("success", ok)
                    result.put("brightness", level)
                }
                "/api/capabilities" -> {
                    val isAccessibility = com.example.accessibility.AccessibilityServiceRegistry.activeService != null
                    val canOverlay = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) Settings.canDrawOverlays(context) else true
                    val caps = listOf(
                        mapOf("name" to "TTS", "category" to "AUDIO", "status" to "AVAILABLE"),
                        mapOf("name" to "MICROPHONE", "category" to "AUDIO", "status" to checkPermissionStatus(Manifest.permission.RECORD_AUDIO)),
                        mapOf("name" to "CAMERA", "category" to "CAMERA", "status" to checkPermissionStatus(Manifest.permission.CAMERA)),
                        mapOf("name" to "TORCH", "category" to "CAMERA", "status" to "AVAILABLE"),
                        mapOf("name" to "VIBRATOR", "category" to "HAPTICS", "status" to "AVAILABLE"),
                        mapOf("name" to "ACCELEROMETER", "category" to "SENSORS", "status" to "AVAILABLE"),
                        mapOf("name" to "GYROSCOPE", "category" to "SENSORS", "status" to "AVAILABLE"),
                        mapOf("name" to "LIGHT_SENSOR", "category" to "SENSORS", "status" to "AVAILABLE"),
                        mapOf("name" to "GPS", "category" to "LOCATION", "status" to checkPermissionStatus(Manifest.permission.ACCESS_FINE_LOCATION)),
                        mapOf("name" to "WIFI", "category" to "NETWORK", "status" to "AVAILABLE"),
                        mapOf("name" to "NOTIFICATIONS", "category" to "NOTIFICATIONS", "status" to if (android.os.Build.VERSION.SDK_INT >= 33) checkPermissionStatus(Manifest.permission.POST_NOTIFICATIONS) else "AVAILABLE"),
                        mapOf("name" to "CLIPBOARD", "category" to "STORAGE", "status" to "AVAILABLE"),
                        mapOf("name" to "ACCESSIBILITY", "category" to "ACCESSIBILITY", "status" to if (isAccessibility) "AVAILABLE" else "PERMISSION_REQUIRED"),
                        mapOf("name" to "FLOATING_HUD", "category" to "DISPLAY", "status" to if (canOverlay) "AVAILABLE" else "PERMISSION_REQUIRED")
                    )
                    val arr = org.json.JSONArray()
                    for (c in caps) arr.put(org.json.JSONObject(c))
                    result.put("success", true)
                    result.put("capabilities", arr)
                }
                "/api/accessibility/tap" -> {
                    if (json.has("text") || json.has("label")) {
                        val text = json.optString("text", json.optString("label", ""))
                        accessibilityRepository.clickNodeByText(text) { }
                        result.put("success", true)
                        result.put("target", text)
                    } else {
                        val x = json.optDouble("x", 500.0).toFloat()
                        val y = json.optDouble("y", 1000.0).toFloat()
                        val req = com.example.accessibility.models.GestureRequestModel(
                            id = "http_tap",
                            type = "CLICK",
                            startX = x,
                            startY = y,
                            durationMs = 100
                        )
                        accessibilityRepository.triggerGesture(req) { }
                        result.put("success", true)
                    }
                }
                "/api/accessibility/swipe" -> {
                    val startX = json.optDouble("startX", 500.0).toFloat()
                    val startY = json.optDouble("startY", 1500.0).toFloat()
                    val endX = json.optDouble("endX", 500.0).toFloat()
                    val endY = json.optDouble("endY", 300.0).toFloat()
                    val dur = json.optLong("durationMs", 250L)
                    val req = com.example.accessibility.models.GestureRequestModel(
                        id = "http_swipe",
                        type = "SWIPE",
                        startX = startX,
                        startY = startY,
                        endX = endX,
                        endY = endY,
                        durationMs = dur
                    )
                    accessibilityRepository.triggerGesture(req) { }
                    result.put("success", true)
                }
                "/api/accessibility/key" -> {
                    val key = json.optString("key", json.optString("action", "BACK")).uppercase()
                    val req = com.example.accessibility.models.GestureRequestModel(
                        id = "http_key",
                        type = key,
                        startX = 0f,
                        startY = 0f
                    )
                    accessibilityRepository.triggerGesture(req) { }
                    result.put("success", true)
                    result.put("key", key)
                }
                "/api/accessibility/inspect" -> {
                    val isServiceActive = com.example.accessibility.AccessibilityServiceRegistry.activeService != null
                    val searchByText = if (json.has("text")) json.optString("text") else null
                    val results = if (isServiceActive) {
                        if (searchByText != null) {
                            accessibilityRepository.searchNodes(searchByText, null, null)
                        } else {
                            accessibilityRepository.getFullNodeTree()
                        }
                    } else {
                        emptyList()
                    }
                    result.put("success", isServiceActive)
                    val arr = org.json.JSONArray()
                    fun nodeToJson(node: com.example.accessibility.models.AccessibilityNodeModel): org.json.JSONObject {
                        return org.json.JSONObject().apply {
                            put("className", node.className ?: "")
                            put("text", node.text ?: "")
                            put("contentDescription", node.contentDescription ?: "")
                            put("viewId", node.viewId ?: "")
                            put("isClickable", node.isClickable)
                            put("bounds", node.bounds)
                            put("boundsInScreen", node.bounds)
                            val cArr = org.json.JSONArray()
                            for (child in node.children) {
                                cArr.put(nodeToJson(child))
                            }
                            put("children", cArr)
                        }
                    }
                    for (rootNode in results) {
                        arr.put(nodeToJson(rootNode))
                    }
                    result.put("nodes", arr)
                }
                "/api/share/devices" -> {
                    val devices = aeroShareManager.discoveredDevices.value
                    result.put("success", true)
                    result.put("count", devices.size)
                    result.put("localDeviceName", aeroShareManager.localDeviceName)
                    result.put("localIp", aeroShareManager.getLocalIpAddress() ?: "127.0.0.1")
                    result.put("isRadarActive", aeroShareManager.isRadarActive.value)
                    val arr = org.json.JSONArray()
                    devices.forEach { dev ->
                        arr.put(org.json.JSONObject().apply {
                            put("id", dev.id)
                            put("name", dev.name)
                            put("ip", dev.ip)
                            put("port", dev.port)
                            put("deviceType", dev.deviceType.name)
                            put("rssi", dev.rssi)
                            put("isSecure", dev.isSecure)
                        })
                    }
                    result.put("devices", arr)
                }
                "/api/share/radar" -> {
                    val enable = json.optBoolean("enabled", !aeroShareManager.isRadarActive.value)
                    if (enable) aeroShareManager.startDiscovery() else aeroShareManager.stopDiscovery()
                    result.put("success", true)
                    result.put("isRadarActive", aeroShareManager.isRadarActive.value)
                }
                "/api/share/send" -> {
                    val targetIp = json.optString("ip", json.optString("target", "")).ifBlank {
                        aeroShareManager.discoveredDevices.value.firstOrNull()?.ip ?: "127.0.0.1"
                    }
                    val targetPort = json.optInt("port", 8080)
                    val peerName = json.optString("peerName", "Peer Device")
                    val filePath = json.optString("filePath", json.optString("path", ""))
                    val textContent = json.optString("text", "")

                    if (filePath.isNotBlank()) {
                        val file = java.io.File(filePath)
                        if (file.exists() && file.isFile) {
                            val txId = aeroShareManager.sendFile(file, targetIp, targetPort, peerName)
                            result.put("success", true)
                            result.put("transferId", txId)
                            result.put("fileName", file.name)
                            result.put("sizeBytes", file.length())
                            result.put("targetIp", targetIp)
                        } else {
                            result.put("success", false)
                            result.put("error", "File does not exist at path: $filePath")
                        }
                    } else if (textContent.isNotBlank()) {
                        val ok = aeroShareManager.sendTextSnippet(textContent, targetIp, targetPort)
                        result.put("success", ok)
                        result.put("text", textContent)
                        result.put("targetIp", targetIp)
                    } else {
                        result.put("success", false)
                        result.put("error", "Must provide either filePath or text")
                    }
                }
                "/api/share/clip" -> {
                    val text = json.optString("text", "")
                    val sender = json.optString("sender", "Nearby Aero Device")
                    if (text.isNotBlank()) {
                        clipboardRepository.writeClipboard(text)
                        android.os.Handler(android.os.Looper.getMainLooper()).post {
                            toastCustomizer.showToast(
                                com.example.ui.overlay.ToastCustomizer.ToastOptions(
                                    message = "AeroShare: Snippet from $sender",
                                    icon = "content_copy"
                                )
                            )
                        }
                        result.put("success", true)
                        result.put("receivedText", text)
                    } else {
                        val currentText = (clipboardRepository.readClipboard() as? com.example.capabilities.CapabilityResult.Success)?.data ?: ""
                        result.put("success", true)
                        result.put("clipboardText", currentText)
                    }
                }
                "/api/share/transfers" -> {
                    val active = aeroShareManager.activeTransfers.value
                    result.put("success", true)
                    result.put("count", active.size)
                    val arr = org.json.JSONArray()
                    active.forEach { tx ->
                        arr.put(org.json.JSONObject().apply {
                            put("id", tx.id)
                            put("fileName", tx.fileName)
                            put("sizeBytes", tx.sizeBytes)
                            put("transferredBytes", tx.transferredBytes)
                            put("progressPct", (tx.progressPct * 100).toInt())
                            put("speedBytesPerSec", tx.speedBytesPerSec)
                            put("etaSeconds", tx.etaSeconds)
                            put("status", tx.status.name)
                            put("direction", tx.direction.name)
                            put("peerName", tx.peerName)
                            put("peerIp", tx.peerIp)
                        })
                    }
                    result.put("transfers", arr)
                }
                "/api/share/history" -> {
                    val history = aeroShareManager.transferHistory.value
                    result.put("success", true)
                    result.put("count", history.size)
                    val arr = org.json.JSONArray()
                    history.forEach { tx ->
                        arr.put(org.json.JSONObject().apply {
                            put("id", tx.id)
                            put("fileName", tx.fileName)
                            put("sizeBytes", tx.sizeBytes)
                            put("status", tx.status.name)
                            put("direction", tx.direction.name)
                            put("peerName", tx.peerName)
                            put("completedAt", tx.completedAt ?: tx.createdAt)
                            put("error", tx.errorMessage ?: "")
                        })
                    }
                    result.put("history", arr)
                }
                "/api/share/cancel" -> {
                    val txId = json.optString("id", json.optString("transferId", ""))
                    val ok = if (txId.isNotBlank()) aeroShareManager.cancelTransfer(txId) else false
                    result.put("success", ok)
                    result.put("transferId", txId)
                }
                "/api/open" -> {
                    val target = json.optString("url", json.optString("uri", json.optString("target", "")))
                    val action = json.optString("action", android.content.Intent.ACTION_VIEW)
                    val mimeType = if (json.has("mimeType") || json.has("type")) json.optString("mimeType", json.optString("type", null)) else null
                    var ok = false
                    try {
                        val uri = if (target.startsWith("http://") || target.startsWith("https://") || target.startsWith("tel:") || target.startsWith("mailto:") || target.startsWith("geo:")) {
                            android.net.Uri.parse(target)
                        } else if (target.startsWith("/")) {
                            android.net.Uri.fromFile(java.io.File(target))
                        } else {
                            android.net.Uri.parse(target)
                        }
                        val intent = android.content.Intent(action).apply {
                            if (mimeType != null) {
                                setDataAndType(uri, mimeType)
                            } else {
                                data = uri
                            }
                            addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                        context.startActivity(intent)
                        ok = true
                    } catch (e: Exception) {
                        logger.e("AppContainer", "Failed to open target: $target", e)
                    }
                    result.put("success", ok)
                    result.put("target", target)
                }
                "/api/audio/tone" -> {
                    val freqHz = json.optInt("frequency", json.optInt("freq", 440))
                    val durationMs = json.optInt("durationMs", json.optInt("duration", 500))
                    var ok = false
                    try {
                        applicationScope.launch(kotlinx.coroutines.Dispatchers.Default) {
                            val sampleRate = 44100
                            val numSamples = (durationMs * sampleRate) / 1000
                            val sample = DoubleArray(numSamples)
                            val generatedSnd = ByteArray(2 * numSamples)
                            for (i in 0 until numSamples) {
                                sample[i] = kotlin.math.sin(2.0 * Math.PI * i.toDouble() / (sampleRate.toDouble() / freqHz.toDouble()))
                            }
                            var idx = 0
                            for (dVal in sample) {
                                val d = kotlin.math.max(-1.0, kotlin.math.min(1.0, dVal))
                                val `val` = (d * 32767).toInt().toShort()
                                generatedSnd[idx++] = (`val`.toInt() and 0x00ff).toByte()
                                generatedSnd[idx++] = ((`val`.toInt() and 0xff00) ushr 8).toByte()
                            }
                            val audioTrack = android.media.AudioTrack(
                                android.media.AudioManager.STREAM_MUSIC,
                                sampleRate,
                                android.media.AudioFormat.CHANNEL_OUT_MONO,
                                android.media.AudioFormat.ENCODING_PCM_16BIT,
                                generatedSnd.size,
                                android.media.AudioTrack.MODE_STATIC
                            )
                            audioTrack.write(generatedSnd, 0, generatedSnd.size)
                            audioTrack.play()
                            kotlinx.coroutines.delay(durationMs.toLong() + 50)
                            audioTrack.release()
                        }
                        ok = true
                    } catch (e: Exception) {
                        logger.e("AppContainer", "Failed to generate tone", e)
                    }
                    result.put("success", ok)
                    result.put("frequencyHz", freqHz)
                    result.put("durationMs", durationMs)
                }
                "/api/battery" -> {
                    val dev = deviceDetailsManager.getDeviceInfo()
                    result.put("success", true)
                    result.put("batteryPct", dev.batteryPct)
                    result.put("isCharging", dev.isCharging)
                    result.put("batteryTempC", dev.batteryTempC)
                    result.put("isThermalThrottling", dev.isThermalThrottling)
                    result.put("uptimeSeconds", dev.uptimeSeconds)
                }
                "/api/system/action" -> {
                    val actionName = json.optString("action", json.optString("key", "HOME")).uppercase()
                    val req = com.example.accessibility.models.GestureRequestModel(
                        id = "http_sys_action",
                        type = actionName,
                        startX = 0f,
                        startY = 0f
                    )
                    accessibilityRepository.triggerGesture(req) { }
                    result.put("success", true)
                    result.put("action", actionName)
                }
                "/api/media/control" -> {
                    val cmd = json.optString("command", json.optString("action", "PLAY_PAUSE")).uppercase()
                    val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? android.media.AudioManager
                    val keyEventCode = when (cmd) {
                        "PLAY", "PAUSE", "PLAY_PAUSE", "TOGGLE" -> android.view.KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE
                        "NEXT", "SKIP" -> android.view.KeyEvent.KEYCODE_MEDIA_NEXT
                        "PREV", "PREVIOUS" -> android.view.KeyEvent.KEYCODE_MEDIA_PREVIOUS
                        "STOP" -> android.view.KeyEvent.KEYCODE_MEDIA_STOP
                        else -> android.view.KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE
                    }
                    var ok = false
                    try {
                        if (audioManager != null) {
                            val down = android.view.KeyEvent(android.view.KeyEvent.ACTION_DOWN, keyEventCode)
                            val up = android.view.KeyEvent(android.view.KeyEvent.ACTION_UP, keyEventCode)
                            audioManager.dispatchMediaKeyEvent(down)
                            audioManager.dispatchMediaKeyEvent(up)
                            ok = true
                        }
                    } catch (e: Exception) {
                        logger.e("AppContainer", "Failed to dispatch media key event", e)
                    }
                    result.put("success", ok)
                    result.put("command", cmd)
                }
                "/api/storage/files" -> {
                    val folderName = json.optString("folder", json.optString("dir", "DOWNLOADS")).uppercase()
                    val dir = when (folderName) {
                        "DOWNLOADS", "DOWNLOAD" -> android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOWNLOADS)
                        "DCIM", "CAMERA", "PHOTOS" -> android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DCIM)
                        "DOCUMENTS", "DOCS" -> android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOCUMENTS)
                        "MOVIES", "VIDEO" -> android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_MOVIES)
                        "MUSIC", "AUDIO" -> android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_MUSIC)
                        else -> {
                            val customPath = json.optString("folder", "")
                            if (customPath.startsWith("/")) java.io.File(customPath) else android.os.Environment.getExternalStorageDirectory()
                        }
                    }
                    val limit = json.optInt("limit", 50)
                    val filesArr = org.json.JSONArray()
                    if (dir != null && dir.exists() && dir.isDirectory) {
                        val list = dir.listFiles()?.sortedByDescending { it.lastModified() }?.take(limit) ?: emptyList()
                        for (f in list) {
                            filesArr.put(org.json.JSONObject().apply {
                                put("name", f.name)
                                put("path", f.absolutePath)
                                put("sizeBytes", f.length())
                                put("isDirectory", f.isDirectory)
                                put("lastModified", f.lastModified())
                            })
                        }
                    }
                    result.put("success", true)
                    result.put("directory", dir?.absolutePath ?: "")
                    result.put("totalFiles", filesArr.length())
                    result.put("files", filesArr)
                }
                "/api/sms/compose" -> {
                    val phone = json.optString("phone", json.optString("to", json.optString("number", "")))
                    val body = json.optString("message", json.optString("body", json.optString("text", "")))
                    var ok = false
                    try {
                        val uri = android.net.Uri.parse("smsto:${phone.trim()}")
                        val intent = android.content.Intent(android.content.Intent.ACTION_SENDTO, uri).apply {
                            if (body.isNotBlank()) {
                                putExtra("sms_body", body)
                            }
                            addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                        context.startActivity(intent)
                        ok = true
                    } catch (e: Exception) {
                        logger.e("AppContainer", "Failed to launch SMS composer", e)
                    }
                    result.put("success", ok)
                    result.put("phone", phone)
                }
                else -> {
                    result.put("success", false)
                    result.put("error", "Unknown API endpoint: $endpoint")
                }
            }
        } catch (e: Exception) {
            result.put("success", false)
            result.put("error", e.message ?: "Exception in API handler")
        }
        return result
    }
}
