import 'package:flutter/material.dart';
import '../providers/downloader_provider.dart';

class ConsoleWidget extends StatelessWidget {
  final List<LogMessage> logs;
  const ConsoleWidget({super.key, required this.logs});

  Color _getColor(String type) {
    switch (type) {
      case "SUCCESS": return Colors.greenAccent;
      case "ERROR": return Colors.redAccent;
      case "WARNING": return Colors.orangeAccent;
      case "INFO": return Colors.lightBlueAccent;
      default: return Colors.white70;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: const Color(0xFF121212),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.grey.shade800),
      ),
      padding: const EdgeInsets.all(12),
      child: ListView.builder(
        itemCount: logs.length,
        reverse: true, // Auto-scrolls to bottom
        itemBuilder: (context, i) {
          final log = logs[i];
          return Padding(
            padding: const EdgeInsets.symmetric(vertical: 2),
            child: RichText(
              text: TextSpan(
                style: const TextStyle(fontFamily: 'monospace', fontSize: 12),
                children: [
                  TextSpan(text: "[${log.time}] ", style: const TextStyle(color: Colors.grey)),
                  TextSpan(text: "[${log.type}] ", style: TextStyle(color: _getColor(log.type), fontWeight: FontWeight.bold)),
                  TextSpan(text: log.text, style: const TextStyle(color: Colors.white70)),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
