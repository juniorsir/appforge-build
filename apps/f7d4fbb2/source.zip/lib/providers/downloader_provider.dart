import 'package:flutter/material.dart';
import '../services/yt_dlp_service.dart';

class DownloaderProvider extends ChangeNotifier {
  final YtDlpService _engine = YtDlpService();
  YtDlpService get engine => _engine;

  bool isEngineReady = false;
  bool isInstalling = false;
  double installProgress = 0.0;
  String errorMsg = '';

  Future<void> initEngine() async {
    isEngineReady = await _engine.isInstalled();
    notifyListeners();
  }

  Future<void> setupEngine() async {
    isInstalling = true;
    errorMsg = '';
    notifyListeners();

    try {
      await for (final progress in _engine.installBinary()) {
        installProgress = progress;
        notifyListeners();
      }
      // Test the binary
      final test = await _engine.runCommand(['--version']);
      debugPrint("Engine Version: ${test.stdout}");
      
      isEngineReady = true;
    } catch (e) {
      errorMsg = e.toString();
    } finally {
      isInstalling = false;
      notifyListeners();
    }
  }
}
