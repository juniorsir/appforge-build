import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../services/yt_dlp_service.dart';

class LogMessage {
  final String time;
  final String type; // SUCCESS, ERROR, WARNING, INFO
  final String text;

  LogMessage(this.type, this.text) : time = DateFormat('HH:mm:ss').format(DateTime.now());
}

class DownloaderProvider extends ChangeNotifier {
  final YtDlpService engine = YtDlpService();
  bool isEngineReady = false;
  bool isInstalling = false;
  double installProgress = 0.0;
  
  final List<LogMessage> consoleLogs = [];

  void addLog(String type, String text) {
    consoleLogs.insert(0, LogMessage(type, text));
    notifyListeners();
  }

  void clearLogs() {
    consoleLogs.clear();
    notifyListeners();
  }

  Future<void> initEngine() async {
    isEngineReady = await engine.isInstalled();
    if (isEngineReady) {
      addLog("SUCCESS", "Engine is ready and installed.");
    } else {
      addLog("WARNING", "Engine not found. Please install it.");
    }
    notifyListeners();
  }

  Future<void> setupEngine() async {
    isInstalling = true;
    installProgress = 0.0;
    notifyListeners();

    try {
      await for (final progress in engine.installBinary(addLog)) {
        installProgress = progress;
        notifyListeners();
      }
      isEngineReady = true;
      addLog("SUCCESS", "Installation completed successfully.");
    } catch (e) {
      addLog("ERROR", e.toString());
    } finally {
      isInstalling = false;
      notifyListeners();
    }
  }
}
