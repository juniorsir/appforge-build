import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../main.dart';

class EngineManagerScreen extends StatefulWidget {
  const EngineManagerScreen({super.key});

  @override
  State<EngineManagerScreen> createState() => _EngineManagerScreenState();
}

class _EngineManagerScreenState extends State<EngineManagerScreen> {
  final List<String> logs = [];

  void addLog(String type, String message) {
    final time = TimeOfDay.now().format(context);
    setState(() {
      logs.insert(0, "[$time] [$type] $message");
    });
  }

  Color getLogColor(String log) {
    if (log.contains("[ERROR]")) return Colors.redAccent;
    if (log.contains("[SUCCESS]")) return Colors.greenAccent;
    if (log.contains("[WARNING]")) return Colors.orangeAccent;
    return Colors.blueAccent;
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final engine = context.read<AppState>().engine;

    return Scaffold(
      appBar: AppBar(title: const Text("Engine Manager")),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            // 🔥 STATUS ICON
            AnimatedContainer(
              duration: const Duration(milliseconds: 500),
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: state.isInstalled
                    ? Colors.green.withOpacity(0.1)
                    : Colors.red.withOpacity(0.1),
              ),
              child: Icon(
                state.isInstalled
                    ? Icons.check_circle_rounded
                    : Icons.error_rounded,
                size: 80,
                color: state.isInstalled ? Colors.green : Colors.red,
              ),
            ),

            const SizedBox(height: 20),

            Text(
              state.isInstalled ? "Engine Ready" : "Engine Missing",
              style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),

            const SizedBox(height: 30),

            // 🔥 INSTALL BUTTON / PROGRESS
            if (state.isBusy) ...[
              LinearProgressIndicator(value: state.installProgress),
              const SizedBox(height: 10),
              Text("${(state.installProgress * 100).toStringAsFixed(1)}%"),
            ] else ...[
              ElevatedButton.icon(
                icon: const Icon(Icons.download_for_offline),
                label: Text(
                    state.isInstalled ? "Update Engine" : "Install Engine"),
                onPressed: () async {
                  addLog("INFO", "Starting installation...");
                  await state.install();
                  addLog("SUCCESS", "Installation finished");
                },
              ),
            ],

            const SizedBox(height: 30),

            // 🔥 ADVANCED TOOLS
            const Align(
              alignment: Alignment.centerLeft,
              child: Text(
                "⚙️ Advanced Fix Tools",
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
            ),

            const SizedBox(height: 10),

            Card(
              color: Colors.white.withOpacity(0.05),
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  children: [
                    ElevatedButton(
                      onPressed: () async {
                        addLog("INFO", "Applying chmod...");
                        await engine.manualChmod(addLog);
                      },
                      child: const Text("Fix Permission (chmod)"),
                    ),
                    ElevatedButton(
                      onPressed: () async {
                        addLog("INFO", "Importing binary...");
                        await engine.importBinary(addLog);
                      },
                      child: const Text("Import yt-dlp Manually"),
                    ),
                    ElevatedButton(
                      onPressed: () async {
                        addLog("INFO", "Verifying binary...");
                        await engine.verifyBinary(addLog);
                      },
                      child: const Text("Verify Binary"),
                    ),
                  ],
                ),
              ),
            ),

            const SizedBox(height: 30),

            // 🔥 CONSOLE LOGS
            const Align(
              alignment: Alignment.centerLeft,
              child: Text(
                "📜 Console Logs",
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
            ),

            const SizedBox(height: 10),

            Container(
              height: 200,
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: Colors.black,
                borderRadius: BorderRadius.circular(12),
              ),
              child: ListView.builder(
                reverse: true,
                itemCount: logs.length,
                itemBuilder: (_, i) {
                  return Text(
                    logs[i],
                    style: TextStyle(
                      color: getLogColor(logs[i]),
                      fontSize: 12,
                      fontFamily: 'monospace',
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
