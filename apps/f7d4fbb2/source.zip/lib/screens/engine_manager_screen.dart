import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../main.dart';

class EngineManagerScreen extends StatelessWidget {
  const EngineManagerScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();

    return Scaffold(
      appBar: AppBar(title: const Text("Engine Manager")),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            AnimatedContainer(
              duration: const Duration(milliseconds: 500),
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: state.isInstalled ? Colors.green.withOpacity(0.1) : Colors.red.withOpacity(0.1),
              ),
              child: Icon(
                state.isInstalled ? Icons.check_circle_rounded : Icons.error_rounded,
                size: 80,
                color: state.isInstalled ? Colors.green : Colors.red,
              ),
            ),
            const SizedBox(height: 20),
            Text(state.isInstalled ? "Engine Ready" : "Engine Missing", style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
            const SizedBox(height: 40),
            if (state.isBusy) ...[
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 40),
                child: LinearProgressIndicator(value: state.installProgress),
              ),
              const SizedBox(height: 10),
              Text("${(state.installProgress * 100).toStringAsFixed(1)}%"),
            ] else
              ElevatedButton.icon(
                icon: const Icon(Icons.download_for_offline),
                label: Text(state.isInstalled ? "Update Engine" : "Install Engine"),
                onPressed: state.install,
              ),
          ],
        ),
      ),
    );
  }
}
