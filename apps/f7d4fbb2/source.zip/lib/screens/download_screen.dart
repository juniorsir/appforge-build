import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../main.dart';

class DownloadScreen extends StatefulWidget {
  final String url, formatId;
  const DownloadScreen({super.key, required this.url, required this.formatId});

  @override
  State<DownloadScreen> createState() => _DownloadScreenState();
}

class _DownloadScreenState extends State<DownloadScreen> {
  double _progress = 0.0;
  String _stats = "Connecting...";
  final List<String> _logs = [];

  @override
  void initState() {
    super.initState();
    _initDownload();
  }

  void _initDownload() {
    context.read<AppState>().engine.downloadVideo(widget.url, widget.formatId).listen((event) {
      setState(() {
        _progress = event.percentage;
        if (event.speed.isNotEmpty) _stats = "Speed: ${event.speed} | ETA: ${event.eta}";
        _logs.insert(0, event.rawLog);
      });
    }, onDone: () {
      setState(() => _stats = "✅ Download Finished!");
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Downloading")),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(10),
              child: LinearProgressIndicator(value: _progress, minHeight: 12, color: Colors.blueAccent),
            ),
            const SizedBox(height: 12),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text("${(_progress * 100).toStringAsFixed(1)}%", style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
                Text(_stats, style: const TextStyle(color: Colors.greenAccent)),
              ],
            ),
            const SizedBox(height: 30),
            Expanded(
              child: Container(
                decoration: BoxDecoration(color: Colors.black, borderRadius: BorderRadius.circular(12)),
                padding: const EdgeInsets.all(12),
                child: ListView.builder(
                  itemCount: _logs.length,
                  itemBuilder: (_, i) => Text(_logs[i], style: const TextStyle(color: Colors.white70, fontSize: 11, fontFamily: 'monospace')),
                ),
              ),
            ),
            const SizedBox(height: 20),
            SizedBox(
              width: double.infinity,
              child: OutlinedButton(
                onPressed: () {
                  context.read<AppState>().engine.cancel();
                  Navigator.pop(context);
                },
                child: const Text("Cancel & Go Back"),
              ),
            )
          ],
        ),
      ),
    );
  }
}
