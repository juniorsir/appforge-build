import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:permission_handler/permission_handler.dart';
import 'download_screen.dart';

class InfoScreen extends StatelessWidget {
  final Map<String, dynamic> info;
  final String url;
  const InfoScreen({super.key, required this.info, required this.url});

  @override
  Widget build(BuildContext context) {
    final formats = (info['formats'] as List).reversed.where((f) => f['vcodec'] != 'none').toList();

    return Scaffold(
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            expandedHeight: 250,
            pinned: true,
            flexibleSpace: FlexibleSpaceBar(
              background: CachedNetworkImage(
                imageUrl: info['thumbnail'],
                fit: BoxFit.cover,
                errorWidget: (_, __, ___) => const Icon(Icons.error),
              ),
            ),
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(info['title'], style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  Text("Duration: ${info['duration_string'] ?? 'Unknown'}", style: const TextStyle(color: Colors.grey)),
                  const SizedBox(height: 16),
                  const Text("Select Quality", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.blueAccent)),
                ],
              ),
            ),
          ),
          SliverList(
            delegate: SliverChildBuilderDelegate(
              (context, i) {
                final f = formats[i];
                final size = (f['filesize'] ?? f['filesize_approx'] ?? 0) / 1000000;
                return Card(
                  margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                  child: ListTile(
                    leading: const Icon(Icons.video_collection_rounded, color: Colors.blueAccent),
                    title: Text("${f['resolution']} - ${f['ext'].toString().toUpperCase()}"),
                    subtitle: Text("${size.toStringAsFixed(1)} MB • ${f['vcodec']}"),
                    trailing: const Icon(Icons.download_rounded),
                    onPressed: () => _checkPermsAndDownload(context, f['format_id']),
                  ),
                );
              },
              childCount: formats.length,
            ),
          ),
        ],
      ),
    );
  }

  void _checkPermsAndDownload(BuildContext context, String formatId) async {
    if (await Permission.manageExternalStorage.request().isGranted || await Permission.storage.request().isGranted) {
      if (!context.mounted) return;
      Navigator.push(context, MaterialPageRoute(builder: (_) => DownloadScreen(url: url, formatId: formatId)));
    }
  }
}
