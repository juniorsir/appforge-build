import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../main.dart';
import 'info_screen.dart';
import 'engine_manager_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _urlController = TextEditingController();
  bool _isFetching = false;

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();

    return Scaffold(
      appBar: AppBar(
        title: const Text("Vault", style: TextStyle(fontWeight: FontWeight.bold)),
        backgroundColor: Colors.transparent,
        actions: [
          // Change this line (around line 28)
          IconButton(
            icon: const Icon(Icons.terminal), // <--- CHANGED FROM Icons.Terminal
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const EngineManagerScreen())),
          )
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.shield_rounded, size: 100, color: Colors.blueAccent),
            const SizedBox(height: 10),
            const Text("Sovereign Downloader", style: TextStyle(fontSize: 16, color: Colors.grey)),
            const SizedBox(height: 40),
            TextField(
              controller: _urlController,
              decoration: InputDecoration(
                hintText: "Paste video URL here...",
                filled: true,
                fillColor: Colors.white.withOpacity(0.05),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
                suffixIcon: IconButton(icon: const Icon(Icons.paste), onPressed: () {}),
              ),
            ),
            const SizedBox(height: 20),
            SizedBox(
              width: double.infinity,
              height: 56,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.blueAccent,
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                ),
                onPressed: state.isInstalled && !_isFetching ? _handleFetch : null,
                child: _isFetching 
                  ? const CircularProgressIndicator(color: Colors.white) 
                  : const Text("Fetch Metadata", style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
              ),
            ),
            if (!state.isInstalled)
              Padding(
                padding: const EdgeInsets.only(top: 20),
                child: TextButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const EngineManagerScreen())), 
                child: const Text("⚠️ Engine setup required", style: TextStyle(color: Colors.orangeAccent))),
              )
          ],
        ),
      ),
    );
  }

  void _handleFetch() async {
    setState(() => _isFetching = true);
    try {
      final info = await context.read<AppState>().engine.getVideoInfo(_urlController.text);
      if (!mounted) return;
      Navigator.push(context, MaterialPageRoute(builder: (_) => InfoScreen(info: info, url: _urlController.text)));
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Error: $e")));
    } finally {
      setState(() => _isFetching = false);
    }
  }
}
