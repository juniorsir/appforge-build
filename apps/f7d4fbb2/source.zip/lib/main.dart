import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'services/yt_dlp_service.dart';
import 'providers/downloader_provider.dart';

void main() {
  runApp(
    MultiProvider(
      providers: [ChangeNotifierProvider(create: (_) => DownloaderProvider()..initEngine())],
      child: const MainApp(),
    ),
  );
}

class MainApp extends StatelessWidget {
  const MainApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Vault Downloader',
      theme: ThemeData(brightness: Brightness.dark, colorSchemeSeed: Colors.blueAccent, useMaterial3: true),
      home: const HomeScreen(),
      debugShowCheckedModeBanner: false,
    );
  }
}

// --- 1. HOME SCREEN ---
class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _urlCtrl = TextEditingController();
  bool _isFetching = false;

  Future<void> _fetchInfo(DownloaderProvider provider) async {
    if (_urlCtrl.text.isEmpty) return;
    
    setState(() => _isFetching = true);
    try {
      final info = await provider.engine.getVideoInfo(_urlCtrl.text.trim());
      if (!mounted) return;
      Navigator.push(context, MaterialPageRoute(builder: (_) => InfoScreen(videoInfo: info, url: _urlCtrl.text.trim())));
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Error: $e')));
    } finally {
      setState(() => _isFetching = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<DownloaderProvider>();

    return Scaffold(
      appBar: AppBar(title: const Text('Vault Downloader')),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.video_library, size: 80, color: Colors.blueAccent),
            const SizedBox(height: 30),
            
            if (!provider.isEngineReady) ...[
              const Text('Engine Setup Required', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
              const SizedBox(height: 10),
              if (provider.isInstalling) ...[
                LinearProgressIndicator(value: provider.installProgress),
                const SizedBox(height: 10),
                Text('${(provider.installProgress * 100).toStringAsFixed(1)}%'),
              ] else
                ElevatedButton.icon(
                  icon: const Icon(Icons.download),
                  label: const Text('Download Core Engine'),
                  onPressed: provider.setupEngine,
                ),
              if (provider.errorMsg.isNotEmpty) Text(provider.errorMsg, style: const TextStyle(color: Colors.red)),
            ] else ...[
              TextField(
                controller: _urlCtrl,
                decoration: const InputDecoration(labelText: 'Paste Video URL', border: OutlineInputBorder()),
              ),
              const SizedBox(height: 20),
              SizedBox(
                width: double.infinity, height: 50,
                child: ElevatedButton(
                  onPressed: _isFetching ? null : () => _fetchInfo(provider),
                  child: _isFetching ? const CircularProgressIndicator() : const Text('Fetch Info', style: TextStyle(fontSize: 18)),
                ),
              ),
            ]
          ],
        ),
      ),
    );
  }
}

// --- 2. INFO SCREEN ---
class InfoScreen extends StatelessWidget {
  final Map<String, dynamic> videoInfo;
  final String url;

  const InfoScreen({super.key, required this.videoInfo, required this.url});

  @override
  Widget build(BuildContext context) {
    final title = videoInfo['title'] ?? 'Unknown';
    final thumbnail = videoInfo['thumbnail'] ?? '';
    final duration = videoInfo['duration_string'] ?? '--:--';
    final formats = (videoInfo['formats'] as List?)?.reversed.toList() ?? [];

    return Scaffold(
      appBar: AppBar(title: const Text('Select Quality')),
      body: Column(
        children: [
          if (thumbnail.isNotEmpty) CachedNetworkImage(imageUrl: thumbnail, height: 200, width: double.infinity, fit: BoxFit.cover),
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold), maxLines: 2),
                Text('Duration: $duration', style: const TextStyle(color: Colors.grey)),
              ],
            ),
          ),
          const Divider(),
          Expanded(
            child: ListView.builder(
              itemCount: formats.length,
              itemBuilder: (context, index) {
                final f = formats[index];
                if (f['format_id'] == null) return const SizedBox();
                final size = f['filesize'] ?? f['filesize_approx'];
                final sizeStr = size != null ? '${(size / 1024 / 1024).toStringAsFixed(1)} MB' : 'Unknown Size';

                return ListTile(
                  leading: Icon(f['vcodec'] == 'none' ? Icons.audiotrack : Icons.video_file, color: Colors.blueAccent),
                  title: Text('${f['resolution'] ?? 'Audio'} - ${f['ext']}'),
                  subtitle: Text(sizeStr),
                  trailing: IconButton(
                    icon: const Icon(Icons.download),
                    onPressed: () => _startDownload(context, f['format_id']),
                  ),
                );
              },
            ),
          )
        ],
      ),
    );
  }

  Future<void> _startDownload(BuildContext context, String formatId) async {
    // Android 11+ requires Manage External Storage to write binaries to public /Download
    if (await Permission.manageExternalStorage.request().isGranted || await Permission.storage.request().isGranted) {
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => DownloadScreen(url: url, formatId: formatId)));
    } else {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Storage permission required!')));
    }
  }
}

// --- 3. DOWNLOAD SCREEN ---
class DownloadScreen extends StatefulWidget {
  final String url;
  final String formatId;
  const DownloadScreen({super.key, required this.url, required this.formatId});

  @override
  State<DownloadScreen> createState() => _DownloadScreenState();
}

class _DownloadScreenState extends State<DownloadScreen> {
  double _progress = 0.0;
  String _speed = '--';
  String _eta = '--';
  final List<String> _logs = [];

  @override
  void initState() {
    super.initState();
    final provider = context.read<DownloaderProvider>();
    provider.engine.downloadVideo(widget.url, widget.formatId).listen((data) {
      setState(() {
        if (data.percentage > 0) _progress = data.percentage;
        if (data.speed.isNotEmpty) _speed = data.speed;
        if (data.eta.isNotEmpty) _eta = data.eta;
        _logs.insert(0, data.rawLog);
      });
    }, onDone: () {
      setState(() => _logs.insert(0, '✅ Download Complete! Saved to /Download/VideoDownloader'));
    });
  }

  @override
  void dispose() {
    context.read<DownloaderProvider>().engine.cancelDownload();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Downloading...')),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          children: [
            LinearProgressIndicator(value: _progress, minHeight: 10),
            const SizedBox(height: 10),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('${(_progress * 100).toStringAsFixed(1)}%'),
                Text('Speed: $_speed | ETA: $_eta', style: const TextStyle(color: Colors.green)),
              ],
            ),
            const SizedBox(height: 30),
            ElevatedButton.icon(
              icon: const Icon(Icons.cancel),
              label: const Text('Cancel'),
              style: ElevatedButton.styleFrom(backgroundColor: Colors.redAccent, foregroundColor: Colors.white),
              onPressed: () => Navigator.pop(context),
            ),
            const Divider(height: 40),
            Expanded(
              child: Container(
                color: Colors.black45,
                padding: const EdgeInsets.all(8),
                child: ListView.builder(
                  itemCount: _logs.length,
                  itemBuilder: (c, i) => Text(_logs[i], style: const TextStyle(fontFamily: 'monospace', fontSize: 10)),
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}
