import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'providers/downloader_provider.dart';
import 'widgets/console_widget.dart';

void main() {
  runApp(
    MultiProvider(
      providers: [ChangeNotifierProvider(create: (_) => DownloaderProvider()..initEngine())],
      child: const VaultApp(),
    ),
  );
}

class VaultApp extends StatelessWidget {
  const VaultApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Vault Downloader',
      theme: ThemeData.dark(useMaterial3: true).copyWith(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurpleAccent, brightness: Brightness.dark),
        scaffoldBackgroundColor: const Color(0xFF0A0A0A),
        cardTheme: CardThemeData(color: const Color(0xFF1E1E1E), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))),
      ),
      home: const HomeScreen(),
      debugShowCheckedModeBanner: false,
    );
  }
}

// --- 1. HOME SCREEN ---
class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}
class _HomeScreenState extends State<HomeScreen> {
  final _urlCtrl = TextEditingController();
  bool _isLoading = false;

  void _fetch() async {
    final provider = context.read<DownloaderProvider>();
    if (_urlCtrl.text.isEmpty) return;
    
    setState(() => _isLoading = true);
    provider.clearLogs();
    provider.addLog("INFO", "Fetching metadata for: ${_urlCtrl.text}");
    
    try {
      final info = await provider.engine.getVideoInfo(_urlCtrl.text);
      provider.addLog("SUCCESS", "Metadata fetched successfully.");
      if (!mounted) return;
      Navigator.push(context, MaterialPageRoute(builder: (_) => InfoScreen(info: info, url: _urlCtrl.text)));
    } catch (e) {
      provider.addLog("ERROR", e.toString());
    } finally {
      setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<DownloaderProvider>();
    return Scaffold(
      appBar: AppBar(title: const Text('Vault Downloader'), actions: [
        IconButton(icon: const Icon(Icons.settings), onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const EngineScreen()))),
      ]),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            TextField(
              controller: _urlCtrl,
              decoration: InputDecoration(
                labelText: "Video URL",
                prefixIcon: const Icon(Icons.link),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
              ),
            ),
            const SizedBox(height: 20),
            SizedBox(
              width: double.infinity, height: 50,
              child: ElevatedButton(
                onPressed: state.isEngineReady && !_isLoading ? _fetch : null,
                style: ElevatedButton.styleFrom(backgroundColor: Colors.deepPurpleAccent, foregroundColor: Colors.white),
                child: _isLoading ? const CircularProgressIndicator(color: Colors.white) : const Text("Fetch Info", style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
              ),
            ),
            const SizedBox(height: 20),
            if (!state.isEngineReady)
              const Text("⚠️ Engine missing. Go to Settings to install yt-dlp.", style: TextStyle(color: Colors.orangeAccent)),
            const Expanded(child: SizedBox()),
            SizedBox(height: 200, child: ConsoleWidget(logs: state.consoleLogs)),
          ],
        ),
      ),
    );
  }
}

// --- 2. INFO SCREEN ---
class InfoScreen extends StatelessWidget {
  final Map<String, dynamic> info;
  final String url;
  const InfoScreen({super.key, required this.info, required this.url});

  @override
  Widget build(BuildContext context) {
    final formats = (info['formats'] as List).reversed.where((f) => f['vcodec'] != 'none' || f['acodec'] != 'none').toList();
    return Scaffold(
      appBar: AppBar(title: const Text('Select Format')),
      body: Column(
        children: [
          if (info['thumbnail'] != null) CachedNetworkImage(imageUrl: info['thumbnail'], height: 200, width: double.infinity, fit: BoxFit.cover),
          Padding(
            padding: const EdgeInsets.all(16),
            child: Text(info['title'] ?? 'Unknown', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold), maxLines: 2),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: formats.length,
              itemBuilder: (c, i) {
                final f = formats[i];
                if (f['format_id'] == null) return const SizedBox();
                final size = (f['filesize'] ?? f['filesize_approx'] ?? 0) / 1048576;
                final isAudio = f['vcodec'] == 'none';
                return Card(
                  margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                  child: ListTile(
                    leading: Icon(isAudio ? Icons.audiotrack : Icons.video_file, color: Colors.deepPurpleAccent),
                    title: Text("${f['resolution'] ?? 'Audio'} - ${f['ext']}"),
                    subtitle: Text("${size.toStringAsFixed(1)} MB"),
                    trailing: IconButton(
                      icon: const Icon(Icons.download),
                      onPressed: () async {
                        if (await Permission.manageExternalStorage.request().isGranted || await Permission.storage.request().isGranted) {
                          Navigator.push(context, MaterialPageRoute(builder: (_) => DownloadScreen(url: url, formatId: f['format_id'])));
                        }
                      },
                    ),
                  ),
                );
              },
            ),
          )
        ],
      ),
    );
  }
}

// --- 3. DOWNLOAD SCREEN ---
class DownloadScreen extends StatefulWidget {
  final String url, formatId;
  const DownloadScreen({super.key, required this.url, required this.formatId});
  @override
  State<DownloadScreen> createState() => _DownloadScreenState();
}
class _DownloadScreenState extends State<DownloadScreen> {
  double _prog = 0.0;
  String _speed = '--', _eta = '--';
  final List<LogMessage> _logs = [];

  @override
  void initState() {
    super.initState();
    _logs.add(LogMessage("INFO", "Initializing download engine..."));
    context.read<DownloaderProvider>().engine.downloadVideo(widget.url, widget.formatId).listen((e) {
      setState(() {
        if (e.percentage > 0) _prog = e.percentage;
        if (e.speed.isNotEmpty) _speed = e.speed;
        if (e.eta.isNotEmpty) _eta = e.eta;
        if (e.rawLog.isNotEmpty) {
           _logs.insert(0, LogMessage(e.rawLog.contains("ERROR") ? "ERROR" : "INFO", e.rawLog));
        }
      });
    }, onDone: () {
      setState(() => _logs.insert(0, LogMessage("SUCCESS", "Download Saved to /Download/VaultDownloader")));
    });
  }

  @override
  void dispose() {
    context.read<DownloaderProvider>().engine.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Downloading")),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            LinearProgressIndicator(value: _prog, minHeight: 12, borderRadius: BorderRadius.circular(6)),
            const SizedBox(height: 12),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text("${(_prog * 100).toStringAsFixed(1)}%", style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                Text("Speed: $_speed | ETA: $_eta", style: const TextStyle(color: Colors.greenAccent)),
              ],
            ),
            const SizedBox(height: 20),
            Expanded(child: ConsoleWidget(logs: _logs)),
            const SizedBox(height: 20),
            SizedBox(
              width: double.infinity, height: 50,
              child: ElevatedButton.icon(
                icon: const Icon(Icons.cancel), label: const Text("Cancel"),
                style: ElevatedButton.styleFrom(backgroundColor: Colors.redAccent, foregroundColor: Colors.white),
                onPressed: () {
                  context.read<DownloaderProvider>().engine.cancel();
                  Navigator.pop(context);
                },
              ),
            )
          ],
        ),
      ),
    );
  }
}

// --- 4. ENGINE MANAGER SCREEN ---
class EngineScreen extends StatelessWidget {
  const EngineScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final state = context.watch<DownloaderProvider>();
    return Scaffold(
      appBar: AppBar(title: const Text("Engine Manager")),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            Icon(state.isEngineReady ? Icons.check_circle : Icons.error, size: 80, color: state.isEngineReady ? Colors.green : Colors.red),
            const SizedBox(height: 10),
            Text(state.isEngineReady ? "Engine is Ready" : "Engine is Missing", style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 30),
            if (state.isInstalling) ...[
              LinearProgressIndicator(value: state.installProgress),
              Text("${(state.installProgress * 100).toStringAsFixed(1)}%"),
            ] else
              SizedBox(
                width: double.infinity, height: 50,
                child: ElevatedButton.icon(
                  icon: const Icon(Icons.download),
                  label: const Text("Install / Update Engine"),
                  onPressed: state.setupEngine,
                ),
              ),
            const SizedBox(height: 20),
            Expanded(child: ConsoleWidget(logs: state.consoleLogs)),
          ],
        ),
      ),
    );
  }
}
