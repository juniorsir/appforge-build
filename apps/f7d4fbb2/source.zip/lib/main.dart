import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'services/yt_dlp_service.dart';
import 'screens/home_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(
    ChangeNotifierProvider(
      create: (_) => AppState()..checkInstallation(),
      child: const VaultDownloaderApp(),
    ),
  );
}

class AppState extends ChangeNotifier {
  final engine = YtDlpService();
  bool isInstalled = false;
  bool isBusy = false;
  double installProgress = 0.0;

  Future<void> checkInstallation() async {
    isInstalled = await engine.isInstalled();
    notifyListeners();
  }

  Future<void> install() async {
    isBusy = true;
    installProgress = 0.0;
    notifyListeners();

    try {
      await for (var p in engine.installBinary()) {
        installProgress = p;
        notifyListeners();
      }
      isInstalled = true;
    } finally {
      isBusy = false;
      notifyListeners();
    }
  }
}

class VaultDownloaderApp extends StatelessWidget {
  const VaultDownloaderApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Vault Downloader',
      debugShowCheckedModeBanner: false,
      themeMode: ThemeMode.dark,
      // Change this block (around line 59)
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        colorSchemeSeed: Colors.blueAccent,
        scaffoldBackgroundColor: const Color(0xFF0F0F0F),
        cardTheme: CardThemeData( // <--- CHANGED FROM CardTheme
          color: const Color(0xFF1E1E1E),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        ),
      ),
      home: const HomeScreen(),
    );
  }
}
