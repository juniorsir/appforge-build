import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'yt_dlp_service.dart';

void main() => runApp(const YtDlpManagerApp());

class YtDlpManagerApp extends StatelessWidget {
  const YtDlpManagerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'yt-dlp Engine Manager',
      theme: ThemeData(brightness: Brightness.dark, colorSchemeSeed: Colors.green),
      home: const EngineManagerScreen(),
    );
  }
}

class EngineManagerScreen extends StatefulWidget {
  const EngineManagerScreen({super.key});

  @override
  State<EngineManagerScreen> createState() => _EngineManagerScreenState();
}

class _EngineManagerScreenState extends State<EngineManagerScreen> {
  bool _isInstalled = false;
  String _currentVersion = 'Unknown';
  bool _isChecking = false;
  bool _isUpdating = false;
  double _progress = 0.0;
  
  YtDlpUpdateInfo? _pendingUpdate;
  final List<String> _logs = [];

  @override
  void initState() {
    super.initState();
    _initEngineState();
  }

  void _log(String msg) => setState(() => _logs.insert(0, msg));

  Future<void> _initEngineState() async {
    final installed = await YtDlpService.isInstalled();
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _isInstalled = installed;
      _currentVersion = prefs.getString('yt_dlp_current_version') ?? 'None';
    });
    _log('System: Engine installed = $installed (v: $_currentVersion)');
  }

  Future<void> _checkForUpdates() async {
    setState(() => _isChecking = true);
    _log('API: Checking GitHub for latest aarch64 release...');
    
    try {
      final info = await YtDlpService.checkForUpdate();
      setState(() => _pendingUpdate = info);
      
      if (info.updateAvailable) {
        _log('API: Update needed! Latest is ${info.latestVersion}');
      } else {
        _log('API: You are already on the latest version (${info.latestVersion}).');
      }
    } catch (e) {
      _log('Error: $e');
    } finally {
      setState(() => _isChecking = false);
    }
  }

  Future<void> _performUpdate() async {
    if (_pendingUpdate == null) return;
    
    setState(() {
      _isUpdating = true;
      _progress = 0.0;
    });

    try {
      _log('System: Starting atomic download...');
      await for (final p in YtDlpService.downloadBinary(_pendingUpdate!.downloadUrl, _pendingUpdate!.latestVersion)) {
        setState(() => _progress = p);
      }
      _log('System: Download verified and executable rights granted.');
      await _initEngineState(); // Refresh UI state
      setState(() => _pendingUpdate = null);
    } catch (e) {
      _log('Error: Failed to update engine. $e');
    } finally {
      setState(() => _isUpdating = false);
    }
  }

  Future<void> _testEngine() async {
    _log('Testing: Running "yt-dlp --version"...');
    try {
      final result = await YtDlpService.runCommand(['--version']);
      _log('Output: ${result.stdout.toString().trim()}');
      if (result.stderr.toString().isNotEmpty) {
        _log('Stderr: ${result.stderr.toString().trim()}');
      }
    } catch (e) {
      _log('Error: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Engine Manager')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  children: [
                    Text('Status: ${_isInstalled ? "INSTALLED" : "NOT INSTALLED"}', 
                      style: TextStyle(color: _isInstalled ? Colors.green : Colors.red, fontWeight: FontWeight.bold, fontSize: 18)),
                    Text('Local Version: $_currentVersion'),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),
            
            if (_isUpdating) ...[
              const Text('Downloading Update...'),
              const SizedBox(height: 8),
              LinearProgressIndicator(value: _progress, minHeight: 10),
              Text('${(_progress * 100).toStringAsFixed(1)}%'),
            ] else ...[
              ElevatedButton.icon(
                icon: const Icon(Icons.sync),
                label: Text(_isChecking ? 'Checking...' : 'Check For Updates'),
                onPressed: _isChecking || _isUpdating ? null : _checkForUpdates,
              ),
              if (_pendingUpdate != null && _pendingUpdate!.updateAvailable)
                ElevatedButton.icon(
                  icon: const Icon(Icons.download),
                  label: Text('Install Version ${_pendingUpdate!.latestVersion}'),
                  style: ElevatedButton.styleFrom(backgroundColor: Colors.green, foregroundColor: Colors.black),
                  onPressed: _performUpdate,
                ),
              const SizedBox(height: 16),
              ElevatedButton.icon(
                icon: const Icon(Icons.terminal),
                label: const Text('Test Engine (--version)'),
                onPressed: !_isInstalled || _isUpdating ? null : _testEngine,
              ),
            ],
            
            const Divider(height: 32),
            const Text('System Logs:'),
            Expanded(
              child: Container(
                color: Colors.black45,
                padding: const EdgeInsets.all(8),
                child: ListView.builder(
                  itemCount: _logs.length,
                  itemBuilder: (c, i) => Text(_logs[i], style: const TextStyle(fontFamily: 'monospace', fontSize: 12, color: Colors.greenAccent)),
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}
