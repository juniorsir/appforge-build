import 'dart:convert';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';

class DownloadProgress {
  final double percentage;
  final String totalSize;
  final String speed;
  final String eta;
  final String rawLog;

  DownloadProgress({this.percentage = 0.0, this.totalSize = '', this.speed = '', this.eta = '', required this.rawLog});
}

class YtDlpService {
  static const String _githubApiUrl = 'https://api.github.com/repos/yt-dlp/yt-dlp/releases/latest';
  static const String _fallbackUrl = 'https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp_linux_aarch64';
  
  String? _binaryPath;
  Process? _currentProcess;

  /// 1. Get correct directory for executable binaries
  Future<String> getBinaryPath() async {
    if (_binaryPath != null) return _binaryPath!;
    // Use Support Directory for executable binaries (safer than Documents on newer Android)
    final dir = await getApplicationSupportDirectory();
    _binaryPath = '${dir.path}/yt-dlp';
    return _binaryPath!;
  }

  /// 2. Check if installed, valid size, and valid ELF binary
  Future<bool> isInstalled() async {
    final path = await getBinaryPath();
    final file = File(path);
    
    if (!await file.exists()) return false;
    
    // Validate size (>1MB)
    if (await file.length() < 1024 * 1024) return false;

    // Validate ELF Magic Bytes (0x7F 'E' 'L' 'F')
    final bytes = await file.openRead(0, 4).first;
    if (bytes.length < 4 || bytes[0] != 0x7F || bytes[1] != 0x45 || bytes[2] != 0x4C || bytes[3] != 0x46) {
      debugPrint("yt-dlp: Corrupted binary detected (Not an ELF file).");
      await file.delete();
      return false;
    }
    return true;
  }

  /// 3. Dynamic Download & Install
  Stream<double> installBinary() async* {
    String downloadUrl = _fallbackUrl;
    
    // Fetch dynamic URL from GitHub API
    try {
      final res = await http.get(Uri.parse(_githubApiUrl)).timeout(const Duration(seconds: 10));
      if (res.statusCode == 200) {
        final assets = jsonDecode(res.body)['assets'] as List;
        for (var asset in assets) {
          final name = asset['name'].toString().toLowerCase();
          if (name.contains('linux') && (name.contains('aarch64') || name.contains('arm64'))) {
            downloadUrl = asset['browser_download_url'];
            break;
          }
        }
      }
    } catch (e) {
      debugPrint("yt-dlp API Error: $e. Using fallback URL.");
    }

    final finalPath = await getBinaryPath();
    final tempFile = File('$finalPath.tmp');
    bool success = false;
    int retries = 3;

    // Retry System
    while (retries > 0 && !success) {
      try {
        final request = http.Request('GET', Uri.parse(downloadUrl));
        final response = await http.Client().send(request).timeout(const Duration(seconds: 30));

        if (response.statusCode != 200) throw Exception('HTTP ${response.statusCode}');

        final total = response.contentLength ?? 0;
        int received = 0;
        final sink = tempFile.openWrite();

        await for (final chunk in response.stream) {
          sink.add(chunk);
          received += chunk.length;
          if (total > 0) yield received / total;
        }
        await sink.close();

        if (await tempFile.length() > 1024 * 1024) {
          success = true;
        } else {
          throw Exception("Downloaded file too small.");
        }
      } catch (e) {
        retries--;
        debugPrint("Download failed: $e. Retries left: $retries");
        if (retries == 0) throw Exception("Failed to download binary after 3 attempts.");
        await Future.delayed(const Duration(seconds: 2));
      }
    }

    // Atomic Swap & Execution Rights
    if (success) {
      final finalFile = File(finalPath);
      if (await finalFile.exists()) await finalFile.delete();
      await tempFile.rename(finalPath);
      await makeExecutable();
    }
  }

  /// 4. Apply and Verify execution permissions
  Future<void> makeExecutable() async {
    final path = await getBinaryPath();
    await Process.run('chmod', ['+x', path]);
    
    // Verify permissions using ls -l
    final lsResult = await Process.run('ls', ['-l', path]);
    debugPrint("Permission Check: ${lsResult.stdout}");
  }

  /// 5. Safe Execution with Fallback
  Future<ProcessResult> runCommand(List<String> args) async {
    final path = await getBinaryPath();
    try {
      return await Process.run(path, args);
    } catch (e) {
      debugPrint("Direct execution failed: $e. Trying shell fallback...");
      // Shell fallback (as requested, though normally native Process.run is required for ELF)
      return await Process.run('/system/bin/sh', ['-c', '$path ${args.join(" ")}']);
    }
  }

  /// 6. Fetch Metadata (-J)
  Future<Map<String, dynamic>> getVideoInfo(String url) async {
    final result = await runCommand(['-J', '--no-warnings', url]);
    if (result.exitCode != 0) throw Exception(result.stderr);
    return jsonDecode(result.stdout.toString());
  }

  /// 7. Download Video
  Stream<DownloadProgress> downloadVideo(String url, String formatId) async* {
    final path = await getBinaryPath();
    const outputDir = '/storage/emulated/0/Download/VideoDownloader';
    final dir = Directory(outputDir);
    if (!await dir.exists()) await dir.create(recursive: true);

    final outputPath = '$outputDir/%(title)s.%(ext)s';

    _currentProcess = await Process.start(path, [
      '-f', formatId,
      '--newline',
      '--no-warnings',
      '-o', outputPath,
      url
    ]);

    // Parse: [download]  10.0% of 50.0MiB at 1.2MiB/s ETA 00:30
    final regex = RegExp(r'\[download\]\s+([\d\.]+)%\s+of\s+~?([\d\.\w]+)\s+at\s+([\d\.\w\/]+)\s+ETA\s+([\d:]+)');

    await for (final line in _currentProcess!.stdout.transform(utf8.decoder)) {
      final match = regex.firstMatch(line);
      if (match != null) {
        yield DownloadProgress(
          percentage: double.parse(match.group(1)!) / 100,
          totalSize: match.group(2)!,
          speed: match.group(3)!,
          eta: match.group(4)!,
          rawLog: line.trim(),
        );
      } else {
        yield DownloadProgress(rawLog: line.trim());
      }
    }
  }

  void cancelDownload() {
    _currentProcess?.kill();
    _currentProcess = null;
  }
}
