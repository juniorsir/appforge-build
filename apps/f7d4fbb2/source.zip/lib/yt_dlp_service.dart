import 'dart:convert';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

class YtDlpUpdateInfo {
  final bool updateAvailable;
  final String latestVersion;
  final String downloadUrl;

  YtDlpUpdateInfo({
    required this.updateAvailable,
    required this.latestVersion,
    required this.downloadUrl,
  });
}

class YtDlpService {
  static const String _githubApiUrl = 'https://api.github.com/repos/yt-dlp/yt-dlp/releases/latest';
  static const String _fallbackUrl = 'https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp_linux_aarch64';
  static const String _versionKey = 'yt_dlp_current_version';
  
  static String? _binaryPath;

  /// Returns the absolute path to the binary in the app's internal storage
  static Future<String> getBinaryPath() async {
    if (_binaryPath != null) return _binaryPath!;
    final dir = await getApplicationDocumentsDirectory();
    _binaryPath = '${dir.path}/yt-dlp';
    return _binaryPath!;
  }

  /// Checks if the binary exists, is executable, and is larger than 1MB (prevents corrupted 0kb files)
  static Future<bool> isInstalled() async {
    final path = await getBinaryPath();
    final file = File(path);
    
    if (await file.exists()) {
      final size = await file.length();
      if (size > 1024 * 1024) { // > 1MB
        return true;
      } else {
        debugPrint('yt-dlp: File exists but is too small (${size}b). Considered corrupted.');
        await deleteOldBinary();
      }
    }
    return false;
  }

  /// Deletes the binary if corrupted or before a clean install
  static Future<void> deleteOldBinary() async {
    final path = await getBinaryPath();
    final file = File(path);
    if (await file.exists()) {
      await file.delete();
      debugPrint('yt-dlp: Old binary deleted.');
    }
  }

  /// Gives the Linux binary execution rights required by Android
  static Future<void> makeExecutable() async {
    final path = await getBinaryPath();
    final result = await Process.run('chmod', ['+x', path]);
    if (result.exitCode == 0) {
      debugPrint('yt-dlp: Successfully made executable (chmod +x).');
    } else {
      throw Exception('Failed to make executable: ${result.stderr}');
    }
  }

  /// Fetches the latest release from GitHub, parses assets, and checks local cache
  static Future<YtDlpUpdateInfo> checkForUpdate() async {
    debugPrint('yt-dlp: Checking for updates via GitHub API...');
    try {
      final response = await http.get(Uri.parse(_githubApiUrl)).timeout(const Duration(seconds: 10));
      
      if (response.statusCode == 200) {
        final json = jsonDecode(response.body);
        final String latestVersion = json['tag_name'] ?? 'unknown';
        final List assets = json['assets'] ?? [];
        
        String? targetUrl;
        
        // Dynamic Asset Matching Logic
        for (var asset in assets) {
          final name = asset['name'].toString().toLowerCase();
          // Must be linux AND (aarch64 OR arm64)
          if (name.contains('linux') && (name.contains('aarch64') || name.contains('arm64'))) {
            targetUrl = asset['browser_download_url'];
            debugPrint('yt-dlp: Found matching asset: $name -> $targetUrl');
            break;
          }
        }

        if (targetUrl == null) {
          throw Exception('No compatible linux_aarch64 asset found in latest release.');
        }

        // Version Caching Check
        final prefs = await SharedPreferences.getInstance();
        final currentVersion = prefs.getString(_versionKey) ?? 'none';
        final isInstalledNow = await isInstalled();

        final needsUpdate = !isInstalledNow || (currentVersion != latestVersion);
        
        debugPrint('yt-dlp: Local v: $currentVersion | Remote v: $latestVersion | Update Needed: $needsUpdate');
        
        return YtDlpUpdateInfo(
          updateAvailable: needsUpdate,
          latestVersion: latestVersion,
          downloadUrl: targetUrl,
        );
      } else {
        throw Exception('GitHub API returned ${response.statusCode}');
      }
    } catch (e) {
      debugPrint('yt-dlp: API check failed ($e). Falling back to default URL.');
      // Fallback System: If API fails (rate limits, no internet), assume update needed and use fallback.
      return YtDlpUpdateInfo(
        updateAvailable: true,
        latestVersion: 'fallback_latest',
        downloadUrl: _fallbackUrl,
      );
    }
  }

  /// Downloads the binary using Atomic File swapping and streams progress
  static Stream<double> downloadBinary(String url, String targetVersion) async* {
    final finalPath = await getBinaryPath();
    // Use a .tmp file so if internet drops, the main binary isn't corrupted
    final tempFile = File('$finalPath.tmp'); 
    
    int retries = 3;
    bool success = false;

    while (retries > 0 && !success) {
      try {
        debugPrint('yt-dlp: Starting download from $url (Attempts left: $retries)...');
        final request = http.Request('GET', Uri.parse(url));
        final response = await http.Client().send(request).timeout(const Duration(seconds: 30));

        if (response.statusCode != 200) {
          throw Exception('Download HTTP error: ${response.statusCode}');
        }

        final totalBytes = response.contentLength ?? 0;
        int receivedBytes = 0;
        final sink = tempFile.openWrite();

        await for (final chunk in response.stream) {
          sink.add(chunk);
          receivedBytes += chunk.length;
          if (totalBytes > 0) {
            yield receivedBytes / totalBytes;
          }
        }
        await sink.close();

        // Safety Validation: Check size > 1MB
        final downloadedSize = await tempFile.length();
        if (downloadedSize < 1024 * 1024) {
          throw Exception('Downloaded file is too small (${downloadedSize}b). Suspected corruption.');
        }

        success = true;
        debugPrint('yt-dlp: Download verified successfully.');
      } catch (e) {
        debugPrint('yt-dlp: Download attempt failed: $e');
        retries--;
        if (retries == 0) throw Exception('Failed to download yt-dlp after 3 attempts.');
        await Future.delayed(const Duration(seconds: 2)); // Wait before retry
      }
    }

    if (success) {
      // Atomic Swap: Delete old, rename temp to final
      await deleteOldBinary();
      await tempFile.rename(finalPath);
      
      // Make it executable
      await makeExecutable();
      
      // Save the new version to cache
      if (targetVersion != 'fallback_latest') {
        final prefs = await SharedPreferences.getInstance();
        await prefs.setString(_versionKey, targetVersion);
      }
      
      debugPrint('yt-dlp: Update complete and cached to version $targetVersion.');
    }
  }

  /// General wrapper to execute yt-dlp commands safely
  static Future<ProcessResult> runCommand(List<String> args) async {
    if (!(await isInstalled())) {
      throw Exception('yt-dlp is not installed. Call updateBinary() first.');
    }
    final path = await getBinaryPath();
    debugPrint('yt-dlp: Executing command: $path ${args.join(' ')}');
    return await Process.run(path, args);
  }
}
