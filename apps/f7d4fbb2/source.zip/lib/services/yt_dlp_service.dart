import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';

class DownloadProgress {
  final double percentage;
  final String speed;
  final String eta;
  final String rawLog;
  DownloadProgress({this.percentage = 0.0, this.speed = '', this.eta = '', required this.rawLog});
}

class YtDlpService {
  static const String _githubApi = 'https://api.github.com/repos/yt-dlp/yt-dlp/releases/latest';
  static const String _fallbackUrl = 'https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp_linux';
  Process? _currentProcess;

  Future<String> getBinaryPath() async {
    final dir = await getApplicationSupportDirectory();
    return '${dir.path}/yt-dlp';
  }

  Future<bool> isInstalled() async {
    final file = File(await getBinaryPath());
    return await file.exists() && await file.length() > 1048576; // > 1MB
  }

  Future<void> makeExecutable() async {
    final path = await getBinaryPath();

    await Process.run('/system/bin/sh', ['-c', 'chmod +x "$path"']);

    final perm = await Process.run('/system/bin/sh', ['-c', 'ls -l "$path"']);
    print("PERMISSION: ${perm.stdout}");
  }

  /// CRITICAL FIX: Executes the binary via shell to bypass 'Permission Denied'
  Future<ProcessResult> runYtDlp(List<String> args) async {
    final path = await getBinaryPath();
    // Wrap arguments in quotes to prevent shell injection errors
    final safeArgs = args.map((a) => '"${a.replaceAll('"', '\\"')}"').join(' ');
    return await Process.run('/system/bin/sh', ['-c', '"$path" $safeArgs']);
  }

  Stream<double> installBinary(Function(String, String) onLog) async* {
    String downloadUrl = _fallbackUrl;
    
    onLog("INFO", "Fetching latest release from GitHub API...");
    try {
      final res = await http.get(Uri.parse(_githubApi)).timeout(const Duration(seconds: 10));
      if (res.statusCode == 200) {
        final assets = jsonDecode(res.body)['assets'] as List;
        for (var asset in assets) {
          final name = asset['name'].toString().toLowerCase();
          // STRICT MATCH: Must be linux AND arm64/aarch64 (Prevents python script download)
          if (name == 'yt-dlp_linux') {
            downloadUrl = asset['browser_download_url'];
            onLog("SUCCESS", "Found correct binary: $name");
            break;
          }
        }
      }
    } catch (e) {
      onLog("WARNING", "GitHub API failed. Using fallback URL.");
    }

    final finalPath = await getBinaryPath();
    final tempFile = File('$finalPath.tmp');
    bool success = false;
    int retries = 3;

    while (retries > 0 && !success) {
      try {
        onLog("INFO", "Downloading binary... (Attempt ${4 - retries}/3)");
        final request = http.Request('GET', Uri.parse(downloadUrl));
        final response = await http.Client().send(request).timeout(const Duration(seconds: 30));

        if (response.statusCode != 200) throw Exception('HTTP ${response.statusCode}');

        final total = response.contentLength ?? 0;
        int received = 0;
        final sink = tempFile.openWrite();

        await for (var chunk in response.stream) {
          sink.add(chunk);
          received += chunk.length;
          if (total > 0) yield received / total;
        }
        await sink.close();

        if (await tempFile.length() > 1048576) {
          success = true;
          onLog("SUCCESS", "Download verified (>1MB).");
        } else {
          throw Exception("File too small. Corrupted download.");
        }
      } catch (e) {
        retries--;
        onLog("ERROR", "Download failed: $e");
        if (retries == 0) throw Exception("Failed after 3 attempts.");
        await Future.delayed(const Duration(seconds: 2));
      }
    }

    if (success) {
      final finalFile = File(finalPath);
      if (await finalFile.exists()) await finalFile.delete();
      await tempFile.rename(finalPath);
      await makeExecutable();
      onLog("SUCCESS", "Engine installed and made executable.");
    }
  }

  Future<Map<String, dynamic>> getVideoInfo(String url) async {
    final res = await runYtDlp(['-J', '--no-warnings', '--no-playlist', url]);
    if (res.exitCode != 0) throw Exception(res.stderr.toString().isNotEmpty ? res.stderr : res.stdout);
    if (res.stdout.toString().trim().isEmpty) throw Exception("Received empty JSON from yt-dlp");
    return jsonDecode(res.stdout);
  }

  Stream<DownloadProgress> downloadVideo(String url, String formatId) async* {
    final path = await getBinaryPath();
    const outputDir = '/storage/emulated/0/Download/VaultDownloader';
    final dir = Directory(outputDir);
    if (!await dir.exists()) await dir.create(recursive: true);

    final outputPath = '$outputDir/%(title)s.%(ext)s';
    
    // Execute via shell
    _currentProcess = await Process.start('/system/bin/sh', [
      '-c', '"$path" --newline -f "$formatId" -o "$outputPath" "$url"'
    ]);

    final regex = RegExp(r'\[download\]\s+([\d\.]+)%\s+of\s+~?([\d\.\w]+)\s+at\s+([\d\.\w\/]+)\s+ETA\s+([\d:]+)');

    await for (var line in _currentProcess!.stdout.transform(utf8.decoder)) {
      final match = regex.firstMatch(line);
      if (match != null) {
        yield DownloadProgress(
          percentage: double.parse(match.group(1)!) / 100,
          speed: match.group(3)!,
          eta: match.group(4)!,
          rawLog: line.trim()
        );
      } else {
        yield DownloadProgress(rawLog: line.trim());
      }
    }
    
    // Check stderr for errors
    final stderrLog = await _currentProcess!.stderr.transform(utf8.decoder).join();
    if (stderrLog.isNotEmpty) {
      yield DownloadProgress(rawLog: "ERROR: $stderrLog");
    }
    _currentProcess = null;
  }

  void cancel() => _currentProcess?.kill();
}
