import 'dart:convert';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';

class DownloadProgress {
  final double percentage;
  final String speed;
  final String eta;
  final String rawLog;
  DownloadProgress({this.percentage = 0.0, this.speed = '', this.eta = '', required this.rawLog});
}

class YtDlpService {
  static const String _githubApi = 'https://api.github.com/repos/yt-dlp/yt-dlp/releases/latest';
  static const String _fallbackUrl = 'https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp_linux_aarch64';
  
  Process? _currentProcess;

  Future<String> getBinaryPath() async {
    final dir = await getApplicationDocumentsDirectory();
    return '${dir.path}/yt-dlp';
  }

  // --- CRITICAL FIX: SHELL EXECUTION WRAPPER ---
  Future<ProcessResult> runYtDlp(List<String> args) async {
    final path = await getBinaryPath();
    debugPrint("Executing: /system/bin/sh $path ${args.join(' ')}");
    
    // We execute via shell to bypass Android binary execution restrictions
    return await Process.run('/system/bin/sh', [path, ...args]);
  }

  Future<bool> isInstalled() async {
    final file = File(await getBinaryPath());
    return await file.exists() && await file.length() > 1000000;
  }

  Future<void> makeExecutable() async {
    final path = await getBinaryPath();
    await Process.run('chmod', ['+x', path]);
  }

  Stream<double> installBinary() async* {
    String downloadUrl = _fallbackUrl;
    try {
      final res = await http.get(Uri.parse(_githubApi));
      if (res.statusCode == 200) {
        final assets = jsonDecode(res.body)['assets'] as List;
        downloadUrl = assets.firstWhere((a) => 
          a['name'].toString().contains('linux') && 
          (a['name'].toString().contains('aarch64') || a['name'].toString().contains('arm64'))
        )['browser_download_url'];
      }
    } catch (e) { debugPrint("API Error: $e"); }

    final path = await getBinaryPath();
    final file = File(path);
    final request = http.Request('GET', Uri.parse(downloadUrl));
    final response = await http.Client().send(request);
    
    int downloaded = 0;
    final sink = file.openWrite();
    await for (var chunk in response.stream) {
      sink.add(chunk);
      downloaded += chunk.length;
      if (response.contentLength != null) yield downloaded / response.contentLength!;
    }
    await sink.close();
    await makeExecutable();
  }

  Future<Map<String, dynamic>> getVideoInfo(String url) async {
    final res = await runYtDlp(['-J', '--no-warnings', url]);
    if (res.exitCode != 0) throw Exception(res.stderr);
    return jsonDecode(res.stdout);
  }

  Stream<DownloadProgress> downloadVideo(String url, String formatId) async* {
    final path = await getBinaryPath();
    final savePath = '/storage/emulated/0/Download/VaultDownloader/%(title)s.%(ext)s';
    
    // Use Process.start via shell for streaming stdout
    _currentProcess = await Process.start('/system/bin/sh', [
      path, '-f', formatId, '--newline', '--no-warnings', '-o', savePath, url
    ]);

    final regex = RegExp(r'\[download\]\s+([\d\.]+)%\s+at\s+([\d\.\w\/]+)\s+ETA\s+([\d:]+)');

    await for (var line in _currentProcess!.stdout.transform(utf8.decoder)) {
      final match = regex.firstMatch(line);
      if (match != null) {
        yield DownloadProgress(
          percentage: double.parse(match.group(1)!) / 100,
          speed: match.group(2)!,
          eta: match.group(3)!,
          rawLog: line.trim()
        );
      } else {
        yield DownloadProgress(rawLog: line.trim());
      }
    }
  }

  void cancel() => _currentProcess?.kill();
}
