import 'dart:convert';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';

class DownloadProgress {
  final double percentage;
  final String speed;
  final String eta;
  final String rawLog;
  DownloadProgress({this.percentage = 0.0, this.speed = '', this.eta = '', required this.rawLog});
}

class YtDlpService {
  static const String _githubApi = 'https://api.github.com/repos/yt-dlp/yt-dlp/releases/latest';
  static const String _fallbackUrl = 'https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp_linux';
  
  Process? _currentProcess;

  Future<String> getBinaryPath() async {
    final dir = await getApplicationDocumentsDirectory();
    return '${dir.path}/yt-dlp';
  }

  // --- CRITICAL FIX: SHELL EXECUTION WRAPPER ---
  Future<ProcessResult> runYtDlp(List<String> args) async {
    final path = await getBinaryPath();
    debugPrint("Executing: /system/bin/sh $path ${args.join(' ')}");
    
    // We execute via shell to bypass Android binary execution restrictions
    return await Process.run('/system/bin/sh', [path, ...args]);
  }

  Future<bool> isInstalled() async {
    final file = File(await getBinaryPath());
    return await file.exists() && await file.length() > 1000000;
  }

  Future<void> makeExecutable() async {
    final path = await getBinaryPath();
    await Process.run('chmod', ['+x', path]);
  }

  Stream<double> installBinary() async* {
    final path = await getBinaryPath();
    final file = File(path);

    // 🔥 DELETE OLD FILE
    if (await file.exists()) {
      await file.delete();
    }

    String downloadUrl = _fallbackUrl;

    // 🔥 TRY GITHUB API
    try {
      final res = await http.get(Uri.parse(_githubApi));

      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        final assets = data['assets'] as List;

        // ✅ STRICT MATCH ONLY
        final asset = assets.firstWhere(
          (a) => a['name'].toString().toLowerCase() == 'yt-dlp_linux',
          orElse: () => null,
        );

        if (asset != null) {
          downloadUrl = asset['browser_download_url'];
        }
      }
    } catch (e) {
      debugPrint("API Error: $e");
    }

    debugPrint("Downloading from: $downloadUrl");

    // 🔥 DOWNLOAD STREAM
    final request = await http.Client().send(
      http.Request('GET', Uri.parse(downloadUrl)),
    );

    final total = request.contentLength ?? 0;
    int received = 0;
    final bytes = <int>[];

    await for (final chunk in request.stream) {
      bytes.addAll(chunk);
      received += chunk.length;

      if (total != 0) {
        yield received / total;
      }
    }

    await file.writeAsBytes(bytes);

    // 🚨 VALIDATE SIZE
    if (await file.length() < 1000000) {
      await file.delete();
      throw Exception("Invalid yt-dlp download (too small)");
    }

    // 🔥 CHMOD
    await Process.run('chmod', ['+x', file.path]);

    // 🔥 VERIFY BINARY
    final check = await Process.run('/system/bin/sh', ['file', file.path]);
    final output = check.stdout.toString();

    if (!output.contains('ELF')) {
      await file.delete();
      throw Exception("Downloaded file is not a valid binary");
    }

    debugPrint("yt-dlp installed successfully");

    yield 1.0;
  }

  Stream<DownloadProgress> downloadVideo(String url, String formatId) async* {
    final path = await getBinaryPath();
    final savePath = '/storage/emulated/0/Download/VaultDownloader/%(title)s.%(ext)s';
    
    // Use Process.start via shell for streaming stdout
    _currentProcess = await Process.start('/system/bin/sh', [
      path, '-f', formatId, '--newline', '--no-warnings', '-o', savePath, url
    ]);

    final regex = RegExp(r'\[download\]\s+([\d\.]+)%\s+at\s+([\d\.\w\/]+)\s+ETA\s+([\d:]+)');

    await for (var line in _currentProcess!.stdout.transform(utf8.decoder)) {
      final match = regex.firstMatch(line);
      if (match != null) {
        yield DownloadProgress(
          percentage: double.parse(match.group(1)!) / 100,
          speed: match.group(2)!,
          eta: match.group(3)!,
          rawLog: line.trim()
        );
      } else {
        yield DownloadProgress(rawLog: line.trim());
      }
    }
  }

  void cancel() => _currentProcess?.kill();
}
