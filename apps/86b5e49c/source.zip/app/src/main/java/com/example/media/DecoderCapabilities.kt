package com.example.media

enum class DecoderClassification {
    HARDWARE,
    SOFTWARE,
    EXTENSION,
    UNKNOWN
}

data class CodecCapabilitiesInfo(
    val name: String,
    val mimeType: String,
    val isEncoder: Boolean,
    val classification: DecoderClassification,
    val maxSupportedWidth: Int = 0,
    val maxSupportedHeight: Int = 0,
    val maxSupportedFrameRate: Int = 0,
    val maxSupportedBitrate: Int = 0,
    val maxSupportedChannels: Int = 0,
    val maxSupportedSampleRate: Int = 0,
    val profiles: List<String> = emptyList()
)

data class CodecSupportStatus(
    val displayName: String,
    val mimeType: String,
    val hardwareAvailable: Boolean,
    val softwareAvailable: Boolean,
    val extensionAvailable: Boolean = false,
    val hardwareDecoders: List<String> = emptyList(),
    val softwareDecoders: List<String> = emptyList(),
    val extensionDecoders: List<String> = emptyList()
)

data class VideoDecoderCapabilityAssessment(
    val trackIndex: Int = 0,
    val codec: String,
    val mimeType: String,
    val requestedProfile: String? = null,
    val requestedLevel: String? = null,
    val requestedWidth: Int = 0,
    val requestedHeight: Int = 0,
    val requestedFrameRate: Float = 0f,
    val deviceDecoderName: String? = null,
    val decoderType: String? = null,
    val profileSupported: Boolean? = null,
    val levelSupported: Boolean? = null,
    val resolutionSupported: Boolean? = null,
    val frameRateSupported: Boolean? = null,
    val supportedProfilesList: List<String> = emptyList(),
    val supportedLevelsList: List<String> = emptyList(),
    val maxWidth: Int? = null,
    val maxHeight: Int? = null,
    val maxFrameRate: Int? = null,
    val isSupported: Boolean = false
)

data class AudioDecoderCapabilityAssessment(
    val trackIndex: Int = 0,
    val codec: String,
    val mimeType: String,
    val requestedChannels: Int = 0,
    val requestedSampleRate: Int = 0,
    val deviceDecoderName: String? = null,
    val decoderType: String? = null,
    val isSupported: Boolean = false,
    val channelsSupported: Boolean? = null,
    val sampleRateSupported: Boolean? = null,
    val maxChannels: Int? = null
)

data class AndroidDecoderCapabilityReport(
    val videoAssessments: List<VideoDecoderCapabilityAssessment> = emptyList(),
    val audioAssessments: List<AudioDecoderCapabilityAssessment> = emptyList()
) {
    fun toFormattedReport(): String {
        val sb = StringBuilder()
        sb.appendLine("# ANDROID DECODER CAPABILITY")

        for (v in videoAssessments) {
            sb.appendLine("\nVIDEO")
            val codecName = when (v.codec.lowercase().trim()) {
                "h264", "avc" -> "H.264"
                "hevc", "h265" -> "HEVC"
                "vp9" -> "VP9"
                "vp8" -> "VP8"
                "av1" -> "AV1"
                else -> v.codec.uppercase()
            }
            sb.appendLine("Codec: $codecName")
            if (!v.requestedProfile.isNullOrBlank()) {
                sb.appendLine("Requested Profile: ${v.requestedProfile}")
            }
            if (!v.requestedLevel.isNullOrBlank()) {
                sb.appendLine("Requested Level: ${v.requestedLevel}")
            }
            sb.appendLine("Device Decoder: ${v.deviceDecoderName ?: "None"}")
            if (v.decoderType != null) {
                sb.appendLine("Type: ${v.decoderType}")
            }
            if (!v.requestedProfile.isNullOrBlank()) {
                val profSup = if (v.deviceDecoderName == null) "NO" else if (v.profileSupported == true) "YES" else "NO"
                sb.appendLine("Profile Supported: $profSup")
            }
            if (!v.requestedLevel.isNullOrBlank()) {
                val lvlSup = if (v.deviceDecoderName == null) "NO" else if (v.levelSupported == true) "YES" else "NO"
                sb.appendLine("Level Supported: $lvlSup")
            }
            if (v.deviceDecoderName != null && v.resolutionSupported != null && v.requestedWidth > 0 && v.requestedHeight > 0) {
                sb.appendLine("Resolution Supported: ${if (v.resolutionSupported) "YES" else "NO"}")
            }
            if (v.deviceDecoderName != null && v.frameRateSupported != null && v.requestedFrameRate > 0f) {
                sb.appendLine("Frame Rate Supported: ${if (v.frameRateSupported) "YES" else "NO"}")
            }
            sb.appendLine("Supported: ${if (v.isSupported) "YES" else "NO"}")
        }

        for (a in audioAssessments) {
            sb.appendLine("\nAUDIO")
            val codecName = when (a.codec.lowercase().trim()) {
                "eac3", "e-ac-3", "eac-3" -> "E-AC-3"
                "ac3", "ac-3" -> "AC-3"
                "truehd", "true-hd" -> "TrueHD"
                else -> a.codec.uppercase()
            }
            sb.appendLine("Codec: $codecName")
            sb.appendLine("Device Decoder: ${a.deviceDecoderName ?: "None"}")
            if (a.decoderType != null) {
                sb.appendLine("Type: ${a.decoderType}")
            }
            sb.appendLine("Supported: ${if (a.isSupported) "YES" else "NO"}")
        }

        return sb.toString().trimEnd()
    }
}

