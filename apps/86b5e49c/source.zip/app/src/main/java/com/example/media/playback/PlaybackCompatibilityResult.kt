package com.example.media.playback

enum class PlaybackStrategy {
    DIRECT_HARDWARE,
    REMUX_REQUIRED,
    TARGETED_AUDIO_TRANSCODE,
    TARGETED_VIDEO_TRANSCODE,
    TRANSCODE_REQUIRED,
    FULL_TRANSCODE_REQUIRED,
    UNSUPPORTED
}

data class PlaybackCompatibilityResult(
    val strategy: PlaybackStrategy,
    val reason: String,
    val containerFormat: String,
    val videoCodec: String,
    val audioCodec: String,
    val requiresRemux: Boolean = false,
    val requiresTranscode: Boolean = false,
    val isVideoSupported: Boolean = true,
    val isAudioSupported: Boolean = true,
    val isContainerSupported: Boolean = true,
    val videoAction: String = "direct", // "direct", "copy", "transcode", "none"
    val audioAction: String = "direct", // "direct", "copy", "transcode", "none"
    val qualityImpact: String = "None (Direct Hardware Playback)",
    val estimatedSpeed: String = "Instant"
)
