package com.example.ui.settings

import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForwardIos
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.FloatingBubbleService
import com.example.data.DownloadEntity
import com.example.player.gestures.PlayerGestureAction
import com.example.ui.*
import com.example.ui.theme.*
import java.io.File
import java.util.Locale

/**
 * Main Hierarchical Settings Entry Composable for DOWNLY.
 * Seamlessly manages Parent Category Menu, Child Category Views, Search Index, and Adaptive Tablet Dual-Pane.
 */
@Composable
fun HierarchicalSettingsScreen(
    downloads: List<DownloadEntity>,
    onClearAllDownloads: () -> Unit,
    viewModel: VideoDownloaderViewModel,
    modifier: Modifier = Modifier
) {
    var selectedCategory by remember { mutableStateOf<SettingsCategory?>(null) }
    var searchQuery by remember { mutableStateOf("") }
    val view = LocalView.current

    // Observe key settings to build live dynamic summaries on parent category cards
    val themeSettings by viewModel.appThemeSettings.collectAsStateWithLifecycle()
    val gestureSettings by viewModel.playerGestureSettings.collectAsStateWithLifecycle()
    val activeGesturesCount = gestureSettings.mappings.count { it.value != PlayerGestureAction.NONE }
    val playerDecoderMode by viewModel.playerDecoderMode.collectAsStateWithLifecycle()
    val pipModePreference by viewModel.pipModePreference.collectAsStateWithLifecycle()
    val defaultDownloadQuality by viewModel.defaultDownloadQuality.collectAsStateWithLifecycle()
    val preferredAudioFormat by viewModel.preferredAudioFormat.collectAsStateWithLifecycle()
    val isStudentMode by viewModel.isStudentMode.collectAsStateWithLifecycle()
    val isOverlayActive = FloatingBubbleService.isRunning
    val youtubeBgPlay by viewModel.youtubeBackgroundPlayEnabled.collectAsStateWithLifecycle()
    val persistentForegroundNotifications by viewModel.persistentForegroundNotifications.collectAsStateWithLifecycle()
    val autoCleanSettings by viewModel.autoCleanSettings.collectAsStateWithLifecycle()

    val totalBytes = remember(downloads) {
        downloads.sumOf { item ->
            val f = File(item.localPath)
            if (f.exists()) f.length() else 0L
        }
    }
    val sizeInMb = totalBytes / (1024.0 * 1024.0)
    val sizeFormatted = if (sizeInMb > 1024) String.format(Locale.US, "%.2f GB", sizeInMb / 1024.0) else String.format(Locale.US, "%.1f MB", sizeInMb)

    fun getCategorySummary(category: SettingsCategory): String {
        return when (category) {
            SettingsCategory.APPEARANCE -> "${themeSettings.themeMode.name.lowercase().replaceFirstChar { it.uppercase() }} · ${themeSettings.accentPalette.name.lowercase().replaceFirstChar { it.uppercase() }}"
            SettingsCategory.PLAYER -> "PiP: ${pipModePreference.take(12)} · Gestures ($activeGesturesCount) · ${playerDecoderMode.take(10)}"
            SettingsCategory.DOWNLOADS -> "Wi-Fi & Mobile · $defaultDownloadQuality · $preferredAudioFormat"
            SettingsCategory.LIBRARY -> "${if (isStudentMode) "Safe Search" else "Standard"}"
            SettingsCategory.NETWORK -> "${if (isOverlayActive) "Overlay ON" else "Overlay OFF"} · CLI Ready"
            SettingsCategory.NOTIFICATIONS -> "${if (youtubeBgPlay) "Bg Audio ON" else "Bg Audio OFF"} · ${if (persistentForegroundNotifications) "Foreground ON" else "Foreground OFF"}"
            SettingsCategory.STORAGE -> "$sizeFormatted used · Auto-clean: ${autoCleanSettings.period.displayName}"
            SettingsCategory.ABOUT -> "v${com.example.BuildConfig.VERSION_NAME} STABLE · JuniorSir · Terms & Privacy"
        }
    }

    // Intercept back button when in a child category or searching
    BackHandler(enabled = selectedCategory != null || searchQuery.isNotBlank()) {
        if (searchQuery.isNotBlank()) {
            searchQuery = ""
        } else {
            selectedCategory = null
        }
    }

    BoxWithConstraints(
        modifier = modifier
            .fillMaxSize()
            .background(SleekBg)
            .statusBarsPadding()
            .padding(top = 16.dp)
    ) {
        val isTabletLayout = maxWidth >= 720.dp

        if (isTabletLayout) {
            // Adaptive Master-Detail Split Pane Layout for Tablets
            val tabletSelectedCategory = selectedCategory ?: SettingsCategory.APPEARANCE
            Row(modifier = Modifier.fillMaxSize()) {
                // Left Column: Navigation Menu & Search
                Column(
                    modifier = Modifier
                        .width(340.dp)
                        .fillMaxHeight()
                        .background(SleekCardDark)
                        .border(BorderStroke(0.5.dp, SleekBorderColor.copy(alpha = 0.3f)))
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Header
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = "Settings",
                            tint = SleekPurpleLight,
                            modifier = Modifier.size(24.dp)
                        )
                        Text(
                            text = "Settings",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Bold,
                                fontSize = 20.sp
                            ),
                            color = SleekTextPrimary
                        )
                    }

                    // Search Field
                    SettingsSearchBar(
                        query = searchQuery,
                        onQueryChange = { searchQuery = it }
                    )

                    if (searchQuery.isNotBlank()) {
                        // Search Results in Tablet pane
                        val searchResults = remember(searchQuery) { SettingsSearchIndex.search(searchQuery) }
                        SearchResultsView(
                            results = searchResults,
                            onItemClick = { item ->
                                triggerClickHaptic(view)
                                selectedCategory = item.category
                                searchQuery = ""
                            }
                        )
                    } else {
                        // Category Cards List
                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                            contentPadding = PaddingValues(bottom = 120.dp)
                        ) {
                            items(SettingsCategory.entries) { category ->
                                val isSelected = tabletSelectedCategory == category
                                ParentCategoryCard(
                                    category = category,
                                    summary = getCategorySummary(category),
                                    isSelected = isSelected,
                                    onClick = {
                                        triggerClickHaptic(view)
                                        selectedCategory = category
                                    }
                                )
                            }
                        }
                    }
                }

                // Right Column: Active Category Content
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .background(SleekBg)
                ) {
                    // Top header for right pane
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 20.dp, vertical = 16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .background(SleekPurpleLight.copy(alpha = 0.15f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = tabletSelectedCategory.icon,
                                contentDescription = null,
                                tint = SleekPurpleLight,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Text(
                            text = tabletSelectedCategory.title,
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Bold,
                                fontSize = 20.sp
                            ),
                            color = SleekTextPrimary
                        )
                    }

                    HorizontalDivider(color = SleekBorderColor.copy(alpha = 0.3f))

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .verticalScroll(rememberScrollState())
                            .padding(bottom = 120.dp)
                    ) {
                        CategoryContentRouter(
                            category = tabletSelectedCategory,
                            downloads = downloads,
                            onClearAllDownloads = onClearAllDownloads,
                            viewModel = viewModel
                        )
                    }
                }
            }
        } else {
            // Phone Single-Column Layout with Slide + Fade Hierarchical Transitions
            AnimatedContent(
                targetState = selectedCategory,
                transitionSpec = {
                    if (targetState != null) {
                        (slideInHorizontally(
                            animationSpec = tween(220),
                            initialOffsetX = { fullWidth -> fullWidth }
                        ) + fadeIn(animationSpec = tween(220)))
                            .togetherWith(
                                slideOutHorizontally(
                                    animationSpec = tween(220),
                                    targetOffsetX = { fullWidth -> -fullWidth / 3 }
                                ) + fadeOut(animationSpec = tween(220))
                            )
                    } else {
                        (slideInHorizontally(
                            animationSpec = tween(220),
                            initialOffsetX = { fullWidth -> -fullWidth / 3 }
                        ) + fadeIn(animationSpec = tween(220)))
                            .togetherWith(
                                slideOutHorizontally(
                                    animationSpec = tween(220),
                                    targetOffsetX = { fullWidth -> fullWidth }
                                ) + fadeOut(animationSpec = tween(220))
                            )
                    }
                },
                label = "SettingsNavigationTransition"
            ) { category ->
                if (category == null) {
                    // PARENT SETTINGS PAGE
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 16.dp)
                    ) {
                        // Header
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 16.dp, bottom = 12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Settings,
                                contentDescription = "Settings",
                                tint = SleekPurpleLight,
                                modifier = Modifier.size(26.dp)
                            )
                            Text(
                                text = "Settings",
                                style = MaterialTheme.typography.headlineSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 22.sp
                                ),
                                color = SleekTextPrimary
                            )
                        }

                        // Search Bar
                        SettingsSearchBar(
                            query = searchQuery,
                            onQueryChange = { searchQuery = it },
                            modifier = Modifier.padding(bottom = 12.dp)
                        )

                        if (searchQuery.isNotBlank()) {
                            // Search Results View
                            val searchResults = remember(searchQuery) { SettingsSearchIndex.search(searchQuery) }
                            SearchResultsView(
                                results = searchResults,
                                onItemClick = { item ->
                                    triggerClickHaptic(view)
                                    selectedCategory = item.category
                                    searchQuery = ""
                                }
                            )
                        } else {
                            // 8 High-Level Categories List
                            LazyColumn(
                                modifier = Modifier.fillMaxSize(),
                                verticalArrangement = Arrangement.spacedBy(10.dp),
                                contentPadding = PaddingValues(bottom = 140.dp)
                            ) {
                                items(SettingsCategory.entries) { cat ->
                                    ParentCategoryCard(
                                        category = cat,
                                        summary = getCategorySummary(cat),
                                        isSelected = false,
                                        onClick = {
                                            triggerClickHaptic(view)
                                            selectedCategory = cat
                                        }
                                    )
                                }
                            }
                        }
                    }
                } else {
                    // CHILD CATEGORY PAGE
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                    ) {
                        // Category Header with Back Button
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(SleekCardDark)
                                .padding(horizontal = 12.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            IconButton(
                                onClick = {
                                    triggerClickHaptic(view)
                                    selectedCategory = null
                                },
                                modifier = Modifier.size(40.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                    contentDescription = "Back to Settings",
                                    tint = SleekTextPrimary
                                )
                            }

                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(32.dp)
                                        .background(SleekPurpleLight.copy(alpha = 0.15f), CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = category.icon,
                                        contentDescription = null,
                                        tint = SleekPurpleLight,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                                Text(
                                    text = category.title,
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 18.sp
                                    ),
                                    color = SleekTextPrimary
                                )
                            }
                        }

                        HorizontalDivider(color = SleekBorderColor.copy(alpha = 0.3f))

                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .verticalScroll(rememberScrollState())
                                .padding(bottom = 140.dp)
                        ) {
                            CategoryContentRouter(
                                category = category,
                                downloads = downloads,
                                onClearAllDownloads = onClearAllDownloads,
                                viewModel = viewModel
                            )
                        }
                    }
                }
            }
        }
    }
}

/**
 * Modern Search Bar with Clear Button
 */
@Composable
fun SettingsSearchBar(
    query: String,
    onQueryChange: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    OutlinedTextField(
        value = query,
        onValueChange = onQueryChange,
        placeholder = {
            Text(
                "Search settings...",
                color = SleekTextSecondary.copy(alpha = 0.6f),
                fontSize = 14.sp
            )
        },
        leadingIcon = {
            Icon(
                imageVector = Icons.Default.Search,
                contentDescription = "Search",
                tint = SleekPurpleLight,
                modifier = Modifier.size(20.dp)
            )
        },
        trailingIcon = {
            if (query.isNotEmpty()) {
                IconButton(onClick = { onQueryChange("") }) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Clear search",
                        tint = SleekTextSecondary,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        },
        singleLine = true,
        shape = RoundedCornerShape(16.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedContainerColor = SleekCardDark,
            unfocusedContainerColor = SleekCardDark,
            focusedBorderColor = SleekPurpleLight.copy(alpha = 0.6f),
            unfocusedBorderColor = SleekBorderColor.copy(alpha = 0.4f),
            focusedTextColor = SleekTextPrimary,
            unfocusedTextColor = SleekTextPrimary
        ),
        modifier = modifier
            .fillMaxWidth()
            .testTag("settings_search_field")
    )
}

/**
 * Parent Category Card matching DOWNLY's Dark Premium aesthetic.
 */
@Composable
fun ParentCategoryCard(
    category: SettingsCategory,
    summary: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        onClick = onClick,
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) SleekPurpleLight.copy(alpha = 0.12f) else SleekCard
        ),
        shape = RoundedCornerShape(22.dp),
        border = BorderStroke(
            1.dp,
            if (isSelected) SleekPurpleLight.copy(alpha = 0.6f) else SleekBorderColor.copy(alpha = 0.35f)
        ),
        modifier = modifier
            .fillMaxWidth()
            .testTag("category_card_${category.id}")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Icon Container (48dp x 48dp)
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(
                        if (isSelected) SleekPurpleLight.copy(alpha = 0.25f)
                        else SleekPurpleContainer.copy(alpha = 0.25f)
                    )
                    .border(
                        1.dp,
                        if (isSelected) SleekPurpleLight.copy(alpha = 0.4f)
                        else SleekPurpleLight.copy(alpha = 0.15f),
                        RoundedCornerShape(14.dp)
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = category.icon,
                    contentDescription = category.title,
                    tint = SleekPurpleLight,
                    modifier = Modifier.size(24.dp)
                )
            }

            Spacer(modifier = Modifier.width(14.dp))

            // Center Column: Title, Short Description, Dynamic Live Summary
            Column(
                modifier = Modifier
                    .weight(1f)
                    .padding(end = 8.dp),
                verticalArrangement = Arrangement.spacedBy(3.dp)
            ) {
                Text(
                    text = category.title,
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    ),
                    color = SleekTextPrimary
                )

                Text(
                    text = category.description,
                    style = MaterialTheme.typography.bodySmall.copy(
                        fontSize = 11.sp,
                        lineHeight = 14.sp
                    ),
                    color = SleekTextSecondary,
                    maxLines = 1
                )

                // Dynamic Live Summary Badge
                Surface(
                    color = Color.White.copy(alpha = 0.05f),
                    shape = RoundedCornerShape(6.dp),
                    border = BorderStroke(0.5.dp, SleekBorderColor.copy(alpha = 0.25f)),
                    modifier = Modifier.padding(top = 2.dp)
                ) {
                    Text(
                        text = summary,
                        color = SleekPurpleLight,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Medium,
                        maxLines = 1,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            // Right Chevron
            Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowForwardIos,
                contentDescription = null,
                tint = if (isSelected) SleekPurpleLight else SleekTextSecondary.copy(alpha = 0.5f),
                modifier = Modifier.size(16.dp)
            )
        }
    }
}

/**
 * Real-Time Search Results View
 */
@Composable
fun SearchResultsView(
    results: List<SettingsSearchItem>,
    onItemClick: (SettingsSearchItem) -> Unit,
    modifier: Modifier = Modifier
) {
    if (results.isEmpty()) {
        Box(
            modifier = modifier
                .fillMaxWidth()
                .padding(vertical = 40.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.SearchOff,
                    contentDescription = null,
                    tint = SleekTextSecondary,
                    modifier = Modifier.size(36.dp)
                )
                Text(
                    text = "No matching settings found",
                    color = SleekTextSecondary,
                    fontSize = 13.sp
                )
            }
        }
    } else {
        LazyColumn(
            modifier = modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(bottom = 120.dp)
        ) {
            items(results) { item ->
                Card(
                    onClick = { onItemClick(item) },
                    colors = CardDefaults.cardColors(containerColor = SleekCard),
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, SleekBorderColor.copy(alpha = 0.3f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .background(SleekPurpleContainer.copy(alpha = 0.3f), CircleShape)
                                .border(1.dp, SleekPurpleLight.copy(alpha = 0.2f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = item.icon,
                                contentDescription = null,
                                tint = SleekPurpleLight,
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = item.breadcrumb,
                                color = SleekPurpleLight,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = item.title,
                                color = SleekTextPrimary,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = item.description,
                                color = SleekTextSecondary,
                                fontSize = 11.sp,
                                maxLines = 1
                            )
                        }

                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowForwardIos,
                            contentDescription = null,
                            tint = SleekTextSecondary.copy(alpha = 0.5f),
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }
            }
        }
    }
}

/**
 * Route content for each Child Category Page
 */
@Composable
fun CategoryContentRouter(
    category: SettingsCategory,
    downloads: List<DownloadEntity>,
    onClearAllDownloads: () -> Unit,
    viewModel: VideoDownloaderViewModel
) {
    when (category) {
        SettingsCategory.APPEARANCE -> AppearanceSettingsPage(viewModel = viewModel)
        SettingsCategory.PLAYER -> PlayerSettingsPage(viewModel = viewModel)
        SettingsCategory.DOWNLOADS -> DownloadsSettingsPage(viewModel = viewModel)
        SettingsCategory.LIBRARY -> LibrarySettingsPage(viewModel = viewModel)
        SettingsCategory.NETWORK -> NetworkSettingsPage(viewModel = viewModel)
        SettingsCategory.NOTIFICATIONS -> NotificationsSettingsPage(viewModel = viewModel)
        SettingsCategory.STORAGE -> StorageSettingsPage(
            downloads = downloads,
            onClearAllDownloads = onClearAllDownloads,
            viewModel = viewModel
        )
        SettingsCategory.ABOUT -> AboutSettingsPage()
    }
}
