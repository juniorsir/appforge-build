package com.example.media.playback

import android.content.Context
import android.net.Uri
import androidx.media3.common.Format
import androidx.media3.common.ParserException
import androidx.media3.common.PlaybackException
import androidx.media3.datasource.HttpDataSource
import androidx.media3.exoplayer.ExoPlaybackException
import androidx.media3.exoplayer.mediacodec.MediaCodecRenderer
import androidx.media3.exoplayer.source.UnrecognizedInputFormatException
import com.example.media.DecoderCapabilityManager
import com.example.media.probe.MediaProbeInfo
import java.io.IOException

object PlaybackDiagnosticEngine {

    fun analyzePlayback(
        context: Context? = null,
        error: PlaybackException? = null,
        probeInfo: MediaProbeInfo? = null,
        mediaUri: Uri? = null,
        activeFormat: Format? = null,
        activeRendererName: String? = null
    ): PlaybackAnalysisReport {
        if (error == null) {
            return analyzeSuccess(probeInfo, activeFormat)
        }
        return analyzeFailure(context, error, probeInfo, mediaUri, activeFormat, activeRendererName)
    }

    private fun analyzeSuccess(
        probeInfo: MediaProbeInfo?,
        activeFormat: Format?
    ): PlaybackAnalysisReport {
        val containerFmt = probeInfo?.format ?: "MP4"
        val primaryVideo = probeInfo?.primaryVideo
        val primaryAudio = probeInfo?.primaryAudio

        val videoInfo = if (primaryVideo != null) {
            VideoAnalysisInfo(
                codec = primaryVideo.codec,
                profile = primaryVideo.profile,
                level = primaryVideo.level,
                pixelFormat = primaryVideo.pixelFormat,
                bitDepth = primaryVideo.bitDepth,
                width = primaryVideo.width,
                height = primaryVideo.height,
                frameRate = primaryVideo.frameRate
            )
        } else if (activeFormat != null && activeFormat.sampleMimeType?.startsWith("video/") == true) {
            VideoAnalysisInfo(
                codec = activeFormat.sampleMimeType?.substringAfter("/") ?: "unknown",
                profile = activeFormat.codecs,
                width = activeFormat.width,
                height = activeFormat.height,
                frameRate = activeFormat.frameRate
            )
        } else null

        val audioInfo = if (primaryAudio != null) {
            AudioAnalysisInfo(
                codec = primaryAudio.codec,
                profile = primaryAudio.profile,
                channels = primaryAudio.channels,
                sampleRate = primaryAudio.sampleRate,
                bitrate = primaryAudio.bitrate
            )
        } else if (activeFormat != null && activeFormat.sampleMimeType?.startsWith("audio/") == true) {
            AudioAnalysisInfo(
                codec = activeFormat.sampleMimeType?.substringAfter("/") ?: "unknown",
                channels = activeFormat.channelCount,
                sampleRate = activeFormat.sampleRate,
                bitrate = activeFormat.bitrate.toLong()
            )
        } else null

        val vAssessment = probeInfo?.androidDecoderCapability?.videoAssessments?.firstOrNull()
            ?: (videoInfo?.let {
                try {
                    DecoderCapabilityManager.assessVideoDecoder(
                        codec = it.codec,
                        requestedProfile = it.profile,
                        requestedLevel = it.level,
                        width = it.width,
                        height = it.height,
                        frameRate = it.frameRate
                    )
                } catch (_: Throwable) { null }
            })

        val deviceDecoder = if (vAssessment != null) {
            DeviceDecoderAnalysis(
                decoderName = vAssessment.deviceDecoderName ?: "Hardware MediaCodec",
                decoderType = vAssessment.decoderType ?: "Hardware",
                isSupported = vAssessment.isSupported,
                profileSupported = vAssessment.profileSupported,
                resolutionSupported = vAssessment.resolutionSupported,
                levelSupported = vAssessment.levelSupported
            )
        } else {
            DeviceDecoderAnalysis(
                decoderName = "c2.android.avc.decoder",
                decoderType = "Hardware",
                isSupported = true
            )
        }

        return PlaybackAnalysisReport(
            result = PlaybackAnalysisResult.SUCCESS,
            player = "Media3 / ExoPlayer",
            failure = null,
            containerFormat = containerFmt,
            video = videoInfo,
            audio = audioInfo,
            deviceDecoder = deviceDecoder,
            analysis = "Media container and codecs are fully compatible with Media3 extractors and device decoders.",
            recommendedAction = "Direct playback operational. No remux or transcoding required."
        )
    }

    private fun analyzeFailure(
        context: Context?,
        error: PlaybackException,
        probeInfo: MediaProbeInfo?,
        mediaUri: Uri?,
        activeFormat: Format?,
        activeRendererName: String?
    ): PlaybackAnalysisReport {
        var current: Throwable? = error
        var rootCause: Throwable = error
        var decoderInitEx: MediaCodecRenderer.DecoderInitializationException? = null
        var codecEx: android.media.MediaCodec.CodecException? = null
        var parserEx: ParserException? = null
        var unrecogInputEx: UnrecognizedInputFormatException? = null
        var httpEx: HttpDataSource.HttpDataSourceException? = null
        var ioEx: IOException? = null
        var exoPlaybackEx: ExoPlaybackException? = null

        while (current != null) {
            rootCause = current
            if (current is MediaCodecRenderer.DecoderInitializationException && decoderInitEx == null) {
                decoderInitEx = current
            }
            if (current is android.media.MediaCodec.CodecException && codecEx == null) {
                codecEx = current
            }
            if (current is ParserException && parserEx == null) {
                parserEx = current
            }
            if (current is UnrecognizedInputFormatException && unrecogInputEx == null) {
                unrecogInputEx = current
            }
            if (current is HttpDataSource.HttpDataSourceException && httpEx == null) {
                httpEx = current
            }
            if (current is IOException && ioEx == null) {
                ioEx = current
            }
            if (current is ExoPlaybackException && exoPlaybackEx == null) {
                exoPlaybackEx = current
            }
            current = current.cause
        }

        val failureClass = when {
            decoderInitEx != null -> "DecoderInitializationException"
            codecEx != null -> "MediaCodec.CodecException"
            unrecogInputEx != null -> "UnrecognizedInputFormatException"
            parserEx != null -> "ParserException"
            httpEx != null -> "HttpDataSourceException"
            ioEx != null -> ioEx.javaClass.simpleName
            exoPlaybackEx != null -> "ExoPlaybackException"
            error.cause != null -> error.cause!!.javaClass.simpleName
            else -> error.javaClass.simpleName
        }

        val failedFormat = exoPlaybackEx?.rendererFormat ?: activeFormat

        val failureDetails = PlaybackFailureDetails(
            exceptionClass = failureClass,
            errorCode = error.errorCode,
            errorCodeName = error.errorCodeName,
            rootCauseClass = rootCause.javaClass.simpleName,
            rootCauseMessage = rootCause.message ?: error.message ?: "",
            rendererName = activeRendererName ?: (decoderInitEx?.mimeType ?: exoPlaybackEx?.rendererFormat?.sampleMimeType),
            diagnosticInfo = decoderInitEx?.diagnosticInfo ?: codecEx?.diagnosticInfo,
            isDecoderInit = decoderInitEx != null || error.errorCode == PlaybackException.ERROR_CODE_DECODER_INIT_FAILED,
            isMediaCodecException = codecEx != null,
            isParserException = parserEx != null || unrecogInputEx != null,
            isSourceException = httpEx != null || ioEx != null,
            failedFormat = failedFormat?.toString() ?: decoderInitEx?.mimeType
        )

        // 1. Gather Container & Stream Info (from FFprobe probeInfo first, then fallback to format)
        val containerFmt = probeInfo?.format ?: run {
            val uriStr = mediaUri?.toString() ?: ""
            when {
                uriStr.contains(".mkv", ignoreCase = true) -> "matroska,webm"
                uriStr.contains(".mp4", ignoreCase = true) || uriStr.contains(".m4v", ignoreCase = true) -> "mov,mp4"
                uriStr.contains(".webm", ignoreCase = true) -> "webm"
                uriStr.contains(".avi", ignoreCase = true) -> "avi"
                else -> "unknown"
            }
        }

        val primaryVideo = probeInfo?.primaryVideo
        val primaryAudio = probeInfo?.primaryAudio

        val decMime = decoderInitEx?.mimeType
        val videoInfo = if (primaryVideo != null) {
            VideoAnalysisInfo(
                codec = primaryVideo.codec,
                profile = primaryVideo.profile,
                level = primaryVideo.level,
                pixelFormat = primaryVideo.pixelFormat,
                bitDepth = primaryVideo.bitDepth,
                width = primaryVideo.width,
                height = primaryVideo.height,
                frameRate = primaryVideo.frameRate
            )
        } else if (failedFormat != null && failedFormat.sampleMimeType?.startsWith("video/") == true) {
            val mime = failedFormat.sampleMimeType ?: "video/unknown"
            val rawCodec = mime.substringAfter("/")
            val parsedProfile = failedFormat.codecs
            VideoAnalysisInfo(
                codec = rawCodec,
                profile = parsedProfile,
                width = failedFormat.width,
                height = failedFormat.height,
                frameRate = failedFormat.frameRate
            )
        } else if (decMime != null && decMime.startsWith("video/")) {
            val rawCodec = decMime.substringAfter("/")
            VideoAnalysisInfo(
                codec = rawCodec,
                profile = null
            )
        } else null

        val audioInfo = if (primaryAudio != null) {
            AudioAnalysisInfo(
                codec = primaryAudio.codec,
                profile = primaryAudio.profile,
                channels = primaryAudio.channels,
                sampleRate = primaryAudio.sampleRate,
                bitrate = primaryAudio.bitrate
            )
        } else if (failedFormat != null && failedFormat.sampleMimeType?.startsWith("audio/") == true) {
            AudioAnalysisInfo(
                codec = failedFormat.sampleMimeType?.substringAfter("/") ?: "unknown",
                channels = failedFormat.channelCount,
                sampleRate = failedFormat.sampleRate,
                bitrate = failedFormat.bitrate.toLong()
            )
        } else null

        // 2. Correlate with Android Decoder Capabilities
        val vAssessment = probeInfo?.androidDecoderCapability?.videoAssessments?.firstOrNull()
            ?: (videoInfo?.let {
                try {
                    DecoderCapabilityManager.assessVideoDecoder(
                        codec = it.codec,
                        requestedProfile = it.profile,
                        requestedLevel = it.level,
                        width = it.width,
                        height = it.height,
                        frameRate = it.frameRate
                    )
                } catch (_: Throwable) { null }
            })

        val aAssessment = probeInfo?.androidDecoderCapability?.audioAssessments?.firstOrNull()
            ?: (audioInfo?.let {
                try {
                    DecoderCapabilityManager.assessAudioDecoder(
                        codec = it.codec,
                        channels = it.channels,
                        sampleRate = it.sampleRate
                    )
                } catch (_: Throwable) { null }
            })

        val deviceDecoder = if (vAssessment != null) {
            val maxResStr = if (vAssessment.requestedWidth > 0 && vAssessment.requestedHeight > 0) {
                "${vAssessment.requestedWidth}x${vAssessment.requestedHeight}"
            } else null
            DeviceDecoderAnalysis(
                decoderName = decoderInitEx?.codecInfo?.name ?: vAssessment.deviceDecoderName,
                decoderType = vAssessment.decoderType ?: if (decoderInitEx?.codecInfo?.name?.contains("c2.android") == true) "Software" else "Hardware",
                supportedProfiles = emptyList(),
                maxResolution = maxResStr,
                isSupported = vAssessment.isSupported,
                profileSupported = vAssessment.profileSupported,
                resolutionSupported = vAssessment.resolutionSupported,
                levelSupported = vAssessment.levelSupported
            )
        } else if (decoderInitEx != null) {
            DeviceDecoderAnalysis(
                decoderName = decoderInitEx.codecInfo?.name ?: "c2.android.hevc.decoder",
                decoderType = "Software",
                isSupported = false,
                profileSupported = false
            )
        } else null

        // 3. Evidence-Based Analysis & Recommendation Synthesis
        val (analysisText, recommendedActionText) = evaluateFailureEvidence(
            failureDetails = failureDetails,
            video = videoInfo,
            audio = audioInfo,
            vAssessment = vAssessment,
            aAssessment = aAssessment,
            containerFormat = containerFmt
        )

        return PlaybackAnalysisReport(
            result = PlaybackAnalysisResult.FAILED,
            player = "Media3 / ExoPlayer",
            failure = failureDetails,
            containerFormat = containerFmt,
            video = videoInfo,
            audio = audioInfo,
            deviceDecoder = deviceDecoder,
            analysis = analysisText,
            recommendedAction = recommendedActionText
        )
    }

    private fun evaluateFailureEvidence(
        failureDetails: PlaybackFailureDetails,
        video: VideoAnalysisInfo?,
        audio: AudioAnalysisInfo?,
        vAssessment: com.example.media.VideoDecoderCapabilityAssessment?,
        aAssessment: com.example.media.AudioDecoderCapabilityAssessment?,
        containerFormat: String
    ): Pair<String, String> {
        // Evidence 1: Container Parser / Demuxer failure
        if (failureDetails.isParserException ||
            failureDetails.errorCode == PlaybackException.ERROR_CODE_PARSING_CONTAINER_UNSUPPORTED ||
            failureDetails.errorCode == PlaybackException.ERROR_CODE_PARSING_CONTAINER_MALFORMED
        ) {
            val videoCodec = video?.codec?.lowercase() ?: ""
            val isStandardVideo = videoCodec in setOf("h264", "avc", "hevc", "h265", "vp8", "vp9", "")
            if (isStandardVideo) {
                return Pair(
                    "The media container could not be parsed by the player extractors, but underlying stream codecs appear supported by device decoders.",
                    "Codecs are compatible. Remuxing to MP4 container may resolve the container/parser incompatibility without transcoding."
                )
            } else {
                return Pair(
                    "The media container and bitstream could not be parsed by the player extractors.",
                    "Check media source file integrity. Remuxing will fail if bitstream data is corrupted."
                )
            }
        }

        // Evidence 2: Decoder initialization error with unsupported profile or codec
        if (failureDetails.isDecoderInit || failureDetails.errorCode == PlaybackException.ERROR_CODE_DECODER_INIT_FAILED) {
            // Check if profile mismatch was detected (e.g. 10-bit profile Main 10, or vAssessment.profileSupported == false)
            if (vAssessment?.profileSupported == false || video?.bitDepth == 10 || video?.pixelFormat?.contains("10") == true || video?.profile?.contains("10") == true) {
                return Pair(
                    "The requested video profile is not supported by\nthe available decoder.",
                    "Remux will NOT fix codec incompatibility.\nTranscoding may be required."
                )
            }
            if (vAssessment?.resolutionSupported == false && video != null) {
                return Pair(
                    "The requested video resolution (${video.width}x${video.height}) exceeds the available decoder's maximum supported dimensions.",
                    "Remux will NOT fix codec incompatibility.\nTranscoding may be required."
                )
            }
            if (vAssessment != null && !vAssessment.isSupported && vAssessment.deviceDecoderName == null) {
                return Pair(
                    "No hardware or software decoder found on device for video codec (${vAssessment.codec}).",
                    "Remux will NOT fix codec incompatibility.\nTranscoding may be required."
                )
            }
            // If decoder exists but init threw an exception
            val diag = failureDetails.diagnosticInfo ?: failureDetails.rootCauseMessage
            return Pair(
                "Hardware decoder initialization failed (diagnostic: $diag). Codec resource limits or device security constraints may have prevented initialization.",
                "Retry playback with software decoding safe mode or verify available system memory."
            )
        }

        // Evidence 3: Audio Decoder Failure
        if (aAssessment != null && !aAssessment.isSupported && aAssessment.deviceDecoderName == null) {
            return Pair(
                "The requested audio codec (${aAssessment.codec.uppercase()}) is not supported by device decoders.",
                "Remux will NOT fix audio codec incompatibility. Transcoding audio to a supported format (e.g. AAC) or software extension decoding is required."
            )
        }

        // Evidence 4: Source / IO failure
        if (failureDetails.isSourceException ||
            failureDetails.errorCode in setOf(
                PlaybackException.ERROR_CODE_IO_UNSPECIFIED,
                PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED,
                PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_TIMEOUT,
                PlaybackException.ERROR_CODE_IO_FILE_NOT_FOUND,
                PlaybackException.ERROR_CODE_IO_NO_PERMISSION
            )
        ) {
            return Pair(
                "Media source could not be read or opened: ${failureDetails.rootCauseMessage.ifBlank { "Network or storage access failure" }}",
                "Verify media URI accessibility, network connection, or storage permissions. Remux and transcode are not applicable."
            )
        }

        // Evidence 5: Unclassified / General failure
        val reason = failureDetails.rootCauseMessage.ifBlank { failureDetails.errorCodeName }
        return Pair(
            "Playback encountered an unclassified failure (${failureDetails.exceptionClass}: $reason).",
            "Inspect system logcat or retry with software decoder safe mode."
        )
    }
}
