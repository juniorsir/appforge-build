package com.example

import org.junit.Assert.*
import org.junit.Test
import com.yausername.youtubedl_android.mapper.VideoInfo

class ExampleUnitTest {
  @Test
  fun addition_isCorrect() {
    assertEquals(4, 2 + 2)
  }

  @Test
  fun testFFmpegExtension() {
      println("--- FFMPEG EXTENSION AUDIT ---")
      try {
          val isAvailable = androidx.media3.decoder.ffmpeg.FfmpegLibrary.isAvailable()
          println("FfmpegLibrary.isAvailable(): $isAvailable")
          if (isAvailable) {
              val version = androidx.media3.decoder.ffmpeg.FfmpegLibrary.getVersion()
              println("FfmpegLibrary.getVersion(): $version")
          }
      } catch (e: Throwable) {
          println("FfmpegLibrary error: ${e.message}")
      }

      val mimesToTest = listOf(
          "audio/ac3", "audio/eac3", "audio/dts", "audio/flac", "audio/opus",
          "audio/vorbis", "audio/true-hd", "audio/alac", "audio/mp4a-latm", "audio/mpeg"
      )
      for (mime in mimesToTest) {
          val supported = try {
              androidx.media3.decoder.ffmpeg.FfmpegLibrary.supportsFormat(mime)
          } catch (e: Throwable) {
              false
          }
          println("Supports $mime: $supported")
      }
  }

  @Test
  fun testDeviceCodecReport() {
      try {
          val report = com.example.media.DecoderCapabilityManager.generateDeviceCodecReport()
          println("\n--- DEVICE CODEC REPORT ---")
          println(report)
      } catch (t: Throwable) {
          println("Device codec report handled gracefully on host JVM: ${t.message}")
      }
  }

  @Test
  fun testAudioEffectConfig() {
      val defaultCfg = com.example.ui.AudioEffectConfig()
      assertEquals(com.example.ui.AudioEffectPreset.OFF, defaultCfg.preset)
      assertEquals(0.0f, defaultCfg.intensity, 0.001f)
      assertFalse(defaultCfg.isEnabled)

      val smallRoomCfg = com.example.ui.AudioEffectConfig(
          preset = com.example.ui.AudioEffectPreset.SMALL_ROOM,
          intensity = 0.5f
      )
      assertTrue(smallRoomCfg.isEnabled)
      assertEquals("Small Room", smallRoomCfg.preset.displayName)
      assertEquals(0.5f, smallRoomCfg.intensity, 0.001f)

      val cathedralCfg = com.example.ui.AudioEffectConfig(
          preset = com.example.ui.AudioEffectPreset.CATHEDRAL,
          intensity = 1.0f
      )
      assertTrue(cathedralCfg.isEnabled)
      assertEquals("Cathedral", cathedralCfg.preset.displayName)
  }

  @Test
  fun testVideoColorAdjustments() {
      val defaultAdjustments = com.example.ui.VideoColorAdjustments()
      assertTrue(defaultAdjustments.isDefault)
      assertEquals(0.0f, defaultAdjustments.brightness, 0.001f)
      assertEquals(1.0f, defaultAdjustments.contrast, 0.001f)
      assertEquals(1.0f, defaultAdjustments.saturation, 0.001f)
      assertEquals(1.0f, defaultAdjustments.gamma, 0.001f)
      assertEquals(0.0f, defaultAdjustments.sharpness, 0.001f)
      assertEquals(0.0f, defaultAdjustments.temperature, 0.001f)
      assertEquals(0.0f, defaultAdjustments.highlights, 0.001f)
      assertEquals(0.0f, defaultAdjustments.shadows, 0.001f)
      assertEquals(1.0f, defaultAdjustments.vibrance, 0.001f)
      assertEquals(0.0f, defaultAdjustments.tint, 0.001f)

      val custom = defaultAdjustments.copy(brightness = 0.2f)
      assertFalse(custom.isDefault)
  }

  @Test
  fun testVocalReductionConfig() {
      val defaultCfg = com.example.ui.VocalReductionConfig()
      assertEquals(com.example.ui.VocalReductionMode.OFF, defaultCfg.mode)
      assertEquals(0.0f, defaultCfg.strength, 0.001f)
      assertFalse(defaultCfg.isEnabled)

      val lowCfg = com.example.ui.VocalReductionConfig(
          mode = com.example.ui.VocalReductionMode.LOW,
          strength = 0.25f
      )
      assertTrue(lowCfg.isEnabled)
      assertEquals("Low", lowCfg.mode.displayName)
      assertEquals(0.25f, lowCfg.strength, 0.001f)

      val strongCfg = com.example.ui.VocalReductionConfig(
          mode = com.example.ui.VocalReductionMode.STRONG,
          strength = 0.85f
      )
      assertTrue(strongCfg.isEnabled)
      assertEquals("Strong", strongCfg.mode.displayName)
  }

  @Test
  fun testVocalReductionAudioProcessorMath() {
      val processor = com.example.media.audiofx.VocalReductionAudioProcessor()
      processor.strength = 0.5f
      assertEquals(0.5f, processor.strength, 0.001f)

      // Test configuration with Stereo 16-bit PCM
      val stereoFormat = androidx.media3.common.audio.AudioProcessor.AudioFormat(
          44100,
          2,
          androidx.media3.common.C.ENCODING_PCM_16BIT
      )
      val outputFormat = processor.configure(stereoFormat)
      assertTrue(processor.isStereoCompatible)
      assertEquals(stereoFormat.sampleRate, outputFormat.sampleRate)
      assertEquals(2, outputFormat.channelCount)

      // Test configuration with Mono (should gracefully mark incompatible)
      val monoFormat = androidx.media3.common.audio.AudioProcessor.AudioFormat(
          44100,
          1,
          androidx.media3.common.C.ENCODING_PCM_16BIT
      )
      processor.configure(monoFormat)
      assertFalse(processor.isStereoCompatible)
  }

  @Test
  fun test0ByteFileDetection() {
      val tempFile = java.io.File.createTempFile("test_zero_byte", ".mp4")
      try {
          val result = com.example.download.recovery.DownloadValidator.validateFile(tempFile, expectedSize = 1000L)
          assertTrue(result is com.example.download.recovery.DownloadValidator.ValidationResult.ZeroByte)
      } finally {
          tempFile.delete()
      }
  }

  @Test
  fun testMissingFileDetection() {
      val nonExistent = java.io.File("/tmp/non_existent_file_${System.currentTimeMillis()}.mp4")
      val result = com.example.download.recovery.DownloadValidator.validateFile(nonExistent, expectedSize = 5000L)
      assertTrue(result is com.example.download.recovery.DownloadValidator.ValidationResult.MissingFile)
  }

  @Test
  fun testTruncatedIncompleteFileDetection() {
      val tempFile = java.io.File.createTempFile("test_partial", ".mp4")
      try {
          tempFile.writeBytes(ByteArray(500))
          val result = com.example.download.recovery.DownloadValidator.validateFile(tempFile, expectedSize = 10000L)
          assertTrue(result is com.example.download.recovery.DownloadValidator.ValidationResult.Incomplete)
          val incomplete = result as com.example.download.recovery.DownloadValidator.ValidationResult.Incomplete
          assertEquals(500L, incomplete.bytesDownloaded)
          assertEquals(10000L, incomplete.expectedBytes)
          assertTrue(incomplete.isResumable)
      } finally {
          tempFile.delete()
      }
  }

  @Test
  fun testMp4ContainerMagicBytesValidation() {
      val tempFile = java.io.File.createTempFile("test_mp4_magic", ".mp4")
      try {
          // Construct minimal MP4 header: 4 bytes length + 'ftyp' + 4 bytes brand
          val mp4Header = byteArrayOf(
              0x00, 0x00, 0x00, 0x18,
              'f'.code.toByte(), 't'.code.toByte(), 'y'.code.toByte(), 'p'.code.toByte(),
              'i'.code.toByte(), 's'.code.toByte(), 'o'.code.toByte(), 'm'.code.toByte()
          ) + ByteArray(10000)
          tempFile.writeBytes(mp4Header)
          val isValidMagic = com.example.download.recovery.DownloadValidator.checkHeaderMagic(tempFile)
          assertTrue(isValidMagic)
      } finally {
          tempFile.delete()
      }
  }

  @Test
  fun testWebmEbmlMagicBytesValidation() {
      val tempFile = java.io.File.createTempFile("test_webm_magic", ".webm")
      try {
          // EBML header: 0x1A 0x45 0xDF 0xA3
          val ebmlHeader = byteArrayOf(
              0x1A.toByte(), 0x45.toByte(), 0xDF.toByte(), 0xA3.toByte()
          ) + ByteArray(10000)
          tempFile.writeBytes(ebmlHeader)
          val isValidMagic = com.example.download.recovery.DownloadValidator.checkHeaderMagic(tempFile)
          assertTrue(isValidMagic)
      } finally {
          tempFile.delete()
      }
  }

  @Test
  fun testDownloadStatusEnumValues() {
      val statuses = com.example.ui.DownloadStatus.values().map { it.name }
      assertTrue(statuses.contains("QUEUED"))
      assertTrue(statuses.contains("DOWNLOADING"))
      assertTrue(statuses.contains("PAUSED"))
      assertTrue(statuses.contains("COMPLETED"))
      assertTrue(statuses.contains("FAILED"))
      assertTrue(statuses.contains("INCOMPLETE"))
      assertTrue(statuses.contains("CORRUPTED"))
      assertTrue(statuses.contains("RECOVERABLE"))
  }

  @Test
  fun testRecoveryPreservesOriginalMetadata() {
      val entity = com.example.data.DownloadEntity(
          id = "test_vid_1080",
          title = "Sample Presentation",
          author = "Creator",
          durationText = "03:45",
          thumbnailUrl = "https://example.com/thumb.jpg",
          localPath = "/data/sample.mp4",
          fileSize = 1024L,
          expectedSize = 50000L,
          originalUrl = "https://example.com/watch?v=12345",
          formatId = "137+140",
          formatQuality = "1080p",
          formatExt = "mp4",
          downloadStatus = "RECOVERABLE",
          statusMessage = "Interrupted (1024 bytes)"
      )
      assertEquals("https://example.com/watch?v=12345", entity.originalUrl)
      assertEquals("137+140", entity.formatId)
      assertEquals("1080p", entity.formatQuality)
      assertEquals("RECOVERABLE", entity.downloadStatus)
      assertEquals(50000L, entity.expectedSize)
  }

  @Test
  fun testAutoCleanDefaultSettings() {
      val defaultSettings = com.example.storage.cleanup.AutoCleanSettings()
      assertEquals(com.example.storage.cleanup.AutoCleanPeriod.OFF, defaultSettings.period)
      assertTrue(defaultSettings.keepFavorites)
      assertTrue(defaultSettings.keepPlaylistItems)
      assertTrue(defaultSettings.keepMarkedItems)
      assertFalse(defaultSettings.onlyCleanWhenStorageLow)
  }

  @Test
  fun testAutoCleanPeriodDurations() {
      assertEquals(0L, com.example.storage.cleanup.AutoCleanPeriod.OFF.durationMs)
      assertEquals(1 * 86400000L, com.example.storage.cleanup.AutoCleanPeriod.ONE_DAY.durationMs)
      assertEquals(3 * 86400000L, com.example.storage.cleanup.AutoCleanPeriod.THREE_DAYS.durationMs)
      assertEquals(7 * 86400000L, com.example.storage.cleanup.AutoCleanPeriod.SEVEN_DAYS.durationMs)
      assertEquals(14 * 86400000L, com.example.storage.cleanup.AutoCleanPeriod.FOURTEEN_DAYS.durationMs)
      assertEquals(30 * 86400000L, com.example.storage.cleanup.AutoCleanPeriod.THIRTY_DAYS.durationMs)
  }

  @Test
  fun testCompletionEligibilityRules() {
      val now = System.currentTimeMillis()
      val completedAgo10Days = now - (10 * 86400000L)
      val completedAgo2Days = now - (2 * 86400000L)

      // 7-day policy
      val period7Days = com.example.storage.cleanup.AutoCleanPeriod.SEVEN_DAYS

      // Item watched 10 days ago (more than 7 days) -> should be eligible
      val scheduled10Days = completedAgo10Days + period7Days.durationMs
      assertTrue(now >= scheduled10Days)

      // Item watched 2 days ago (less than 7 days) -> should NOT be eligible yet
      val scheduled2Days = completedAgo2Days + period7Days.durationMs
      assertFalse(now >= scheduled2Days)
  }

  @Test
  fun testCompletionThresholdEvaluation() {
      // Test media completion conditions (last 2-5% or <=5 seconds remaining)
      val durationMs = 100_000L // 100 seconds

      // 90 seconds (90%) -> NOT complete
      val pos90 = 90_000L
      val isComplete90 = (pos90.toDouble() / durationMs.toDouble() >= 0.95) || (durationMs - pos90 <= 5000L)
      assertFalse(isComplete90)

      // 96 seconds (96%) -> Complete
      val pos96 = 96_000L
      val isComplete96 = (pos96.toDouble() / durationMs.toDouble() >= 0.95) || (durationMs - pos96 <= 5000L)
      assertTrue(isComplete96)

      // 98 seconds (2s left) -> Complete
      val pos98 = 98_000L
      val isComplete98 = (pos98.toDouble() / durationMs.toDouble() >= 0.95) || (durationMs - pos98 <= 5000L)
      assertTrue(isComplete98)
  }

  @Test
  fun testProtectedMediaNeverEligible() {
      val downloadKept = com.example.data.DownloadEntity(
          id = "vid_keep_1",
          title = "Special Concert",
          author = "Artist",
          durationText = "1:00:00",
          thumbnailUrl = "",
          localPath = "/data/concert.mp4",
          fileSize = 1024L,
          isKept = true
      )
      assertTrue(downloadKept.isKept)

      val downloadFav = com.example.data.DownloadEntity(
          id = "vid_fav_1",
          title = "Favorite Documentary",
          author = "Director",
          durationText = "45:00",
          thumbnailUrl = "",
          localPath = "/data/doc.mp4",
          fileSize = 2048L,
          isFavorite = true
      )
      assertTrue(downloadFav.isFavorite)

      val downloadExplicitlyProtected = com.example.data.DownloadEntity(
          id = "vid_prot_1",
          title = "Protected Lecture",
          author = "Prof",
          durationText = "50:00",
          thumbnailUrl = "",
          localPath = "/data/lecture.mp4",
          fileSize = 4096L,
          isProtected = true
      )
      assertTrue(downloadExplicitlyProtected.isProtected)
  }

  @Test
  fun testCloudBackupSettingsAndConstraints() {
      val defaultSettings = com.example.backup.cloud.CloudBackupSettings()
      assertFalse(defaultSettings.includeDownloadedMedia)
      assertTrue(defaultSettings.wifiOnly)
      assertFalse(defaultSettings.chargingOnly)
      assertEquals(com.example.backup.cloud.AutoBackupFrequency.OFF, defaultSettings.autoBackupFrequency)
      assertEquals("Never", defaultSettings.lastBackupTime)

      val customSettings = defaultSettings.copy(
          includeDownloadedMedia = true,
          wifiOnly = false,
          autoBackupFrequency = com.example.backup.cloud.AutoBackupFrequency.DAILY
      )
      assertTrue(customSettings.includeDownloadedMedia)
      assertFalse(customSettings.wifiOnly)
      assertEquals(com.example.backup.cloud.AutoBackupFrequency.DAILY, customSettings.autoBackupFrequency)
  }

  @Test
  fun testBuiltInThemesResolution() {
      // AMOLED Black must resolve to true black #000000
      val amoledSettings = com.example.ui.theme.AppThemeSettings(
          themeMode = com.example.ui.theme.AppThemeMode.AMOLED_BLACK
      )
      assertTrue(amoledSettings.isAmoled)
      val amoledColors = com.example.ui.theme.resolveSleekColorsFromSettings(amoledSettings)
      assertEquals(androidx.compose.ui.graphics.Color(0xFF000000), amoledColors.bg)

      // Obsidian Dark Theme
      val obsidianSettings = com.example.ui.theme.AppThemeSettings(
          themeMode = com.example.ui.theme.AppThemeMode.OBSIDIAN
      )
      val obsidianColors = com.example.ui.theme.resolveSleekColorsFromSettings(obsidianSettings)
      assertEquals(androidx.compose.ui.graphics.Color(0xFF09090C), obsidianColors.bg)

      // Midnight Dark Theme
      val midnightSettings = com.example.ui.theme.AppThemeSettings(
          themeMode = com.example.ui.theme.AppThemeMode.MIDNIGHT
      )
      val midnightColors = com.example.ui.theme.resolveSleekColorsFromSettings(midnightSettings)
      assertEquals(androidx.compose.ui.graphics.Color(0xFF070B14), midnightColors.bg)

      // Graphite Dark Theme
      val graphiteSettings = com.example.ui.theme.AppThemeSettings(
          themeMode = com.example.ui.theme.AppThemeMode.GRAPHITE
      )
      val graphiteColors = com.example.ui.theme.resolveSleekColorsFromSettings(graphiteSettings)
      assertEquals(androidx.compose.ui.graphics.Color(0xFF121316), graphiteColors.bg)
  }

  @Test
  fun testAccentPaletteAndCustomColors() {
      // Test Purple (Default)
      val purpleSettings = com.example.ui.theme.AppThemeSettings(
          accentPalette = com.example.ui.theme.AccentPalette.PURPLE
      )
      val purpleColors = com.example.ui.theme.resolveSleekColorsFromSettings(purpleSettings)
      assertEquals(androidx.compose.ui.graphics.Color(0xFF8B5CF6), purpleColors.primary)

      // Test Orange
      val orangeSettings = com.example.ui.theme.AppThemeSettings(
          accentPalette = com.example.ui.theme.AccentPalette.ORANGE
      )
      val orangeColors = com.example.ui.theme.resolveSleekColorsFromSettings(orangeSettings)
      assertEquals(androidx.compose.ui.graphics.Color(0xFFFF6D00), orangeColors.primary)

      // Test Cyan
      val cyanSettings = com.example.ui.theme.AppThemeSettings(
          accentPalette = com.example.ui.theme.AccentPalette.CYAN
      )
      val cyanColors = com.example.ui.theme.resolveSleekColorsFromSettings(cyanSettings)
      assertEquals(androidx.compose.ui.graphics.Color(0xFF06B6D4), cyanColors.primary)

      // Test Custom Accent
      val customColorHex = 0xFFFF0055L
      val customSettings = com.example.ui.theme.AppThemeSettings(
          accentPalette = com.example.ui.theme.AccentPalette.CUSTOM,
          customAccentColor = customColorHex
      )
      val customColors = com.example.ui.theme.resolveSleekColorsFromSettings(customSettings)
      assertEquals(androidx.compose.ui.graphics.Color(customColorHex), customColors.primary)
  }

  @Test
  fun testThemeSafeFallback() {
      assertEquals(com.example.ui.theme.AppThemeMode.OBSIDIAN, com.example.ui.theme.AppThemeMode.fromId("INVALID_MODE_XYZ"))
      assertEquals(com.example.ui.theme.AppThemeMode.AMOLED_BLACK, com.example.ui.theme.AppThemeMode.fromId("AMOLED Black"))
      assertEquals(com.example.ui.theme.AppThemeMode.MIDNIGHT, com.example.ui.theme.AppThemeMode.fromId("Midnight"))
      assertEquals(com.example.ui.theme.AccentPalette.PURPLE, com.example.ui.theme.AccentPalette.fromId("UNKNOWN_COLOR"))
  }

  @Test
  fun testColorUtilsAndAccessibilityContrast() {
      // White background requires dark text
      val textOnWhite = com.example.ui.theme.ThemeColorUtils.getReadableTextColorForBackground(androidx.compose.ui.graphics.Color.White)
      assertEquals(androidx.compose.ui.graphics.Color(0xFF1A1A1A), textOnWhite)

      // Black background requires light text
      val textOnBlack = com.example.ui.theme.ThemeColorUtils.getReadableTextColorForBackground(androidx.compose.ui.graphics.Color.Black)
      assertEquals(androidx.compose.ui.graphics.Color.White, textOnBlack)

      // Color lighten / darken
      val baseColor = androidx.compose.ui.graphics.Color(0xFF8B5CF6)
      val lightened = com.example.ui.theme.ThemeColorUtils.lightenColor(baseColor, 0.3f)
      assertTrue(com.example.ui.theme.ThemeColorUtils.calculateLuminance(lightened) > com.example.ui.theme.ThemeColorUtils.calculateLuminance(baseColor))
  }

  @Test
  fun testPlayerGestureDefaultsAndFallback() {
      val settings = com.example.player.gestures.PlayerGestureSettings()
      
      // Default for TWO_FINGER_DOUBLE_TAP should be PLAY_PAUSE
      assertEquals(
          com.example.player.gestures.PlayerGestureAction.PLAY_PAUSE,
          settings.getActionFor(com.example.player.gestures.PlayerGesture.TWO_FINGER_DOUBLE_TAP)
      )

      // Other gestures should default to NONE
      assertEquals(
          com.example.player.gestures.PlayerGestureAction.NONE,
          settings.getActionFor(com.example.player.gestures.PlayerGesture.THREE_FINGER_TAP)
      )
      assertEquals(
          com.example.player.gestures.PlayerGestureAction.NONE,
          settings.getActionFor(com.example.player.gestures.PlayerGesture.TWO_FINGER_SWIPE_UP)
      )
      assertEquals(
          com.example.player.gestures.PlayerGestureAction.NONE,
          settings.getActionFor(com.example.player.gestures.PlayerGesture.TWO_FINGER_SWIPE_DOWN)
      )
      assertEquals(
          com.example.player.gestures.PlayerGestureAction.NONE,
          settings.getActionFor(com.example.player.gestures.PlayerGesture.LEFT_EDGE_SWIPE)
      )
      assertEquals(
          com.example.player.gestures.PlayerGestureAction.NONE,
          settings.getActionFor(com.example.player.gestures.PlayerGesture.RIGHT_EDGE_SWIPE)
      )
      assertEquals(
          com.example.player.gestures.PlayerGestureAction.NONE,
          settings.getActionFor(com.example.player.gestures.PlayerGesture.LONG_PRESS)
      )
  }

  @Test
  fun testPlayerGestureActionMapping() {
      var settings = com.example.player.gestures.PlayerGestureSettings()
      
      // Assign custom actions
      settings = settings.withAction(
          com.example.player.gestures.PlayerGesture.THREE_FINGER_TAP,
          com.example.player.gestures.PlayerGestureAction.MUTE_UNMUTE
      )
      settings = settings.withAction(
          com.example.player.gestures.PlayerGesture.TWO_FINGER_SWIPE_UP,
          com.example.player.gestures.PlayerGestureAction.NEXT_MEDIA
      )
      settings = settings.withAction(
          com.example.player.gestures.PlayerGesture.LONG_PRESS,
          com.example.player.gestures.PlayerGestureAction.SCREENSHOT
      )

      assertEquals(
          com.example.player.gestures.PlayerGestureAction.MUTE_UNMUTE,
          settings.getActionFor(com.example.player.gestures.PlayerGesture.THREE_FINGER_TAP)
      )
      assertEquals(
          com.example.player.gestures.PlayerGestureAction.NEXT_MEDIA,
          settings.getActionFor(com.example.player.gestures.PlayerGesture.TWO_FINGER_SWIPE_UP)
      )
      assertEquals(
          com.example.player.gestures.PlayerGestureAction.SCREENSHOT,
          settings.getActionFor(com.example.player.gestures.PlayerGesture.LONG_PRESS)
      )
  }

  @Test
  fun testPlayerGestureEnumLookup() {
      assertEquals(
          com.example.player.gestures.PlayerGesture.TWO_FINGER_DOUBLE_TAP,
          com.example.player.gestures.PlayerGesture.fromId("two_finger_double_tap")
      )
      assertEquals(
          com.example.player.gestures.PlayerGesture.LONG_PRESS,
          com.example.player.gestures.PlayerGesture.fromId("long_press")
      )
      assertNull(com.example.player.gestures.PlayerGesture.fromId("non_existent_gesture"))

      assertEquals(
          com.example.player.gestures.PlayerGestureAction.PLAY_PAUSE,
          com.example.player.gestures.PlayerGestureAction.fromId("play_pause")
      )
      assertEquals(
          com.example.player.gestures.PlayerGestureAction.SCREENSHOT,
          com.example.player.gestures.PlayerGestureAction.fromId("screenshot")
      )
      assertEquals(
          com.example.player.gestures.PlayerGestureAction.NONE,
          com.example.player.gestures.PlayerGestureAction.fromId("invalid_action_id")
      )
  }

  @Test
  fun testExtractValidUrl_ValidHttpAndHttps() {
      val httpsUrl = "https://www.youtube.com/watch?v=dQw4w9WgXcQ"
      assertEquals(httpsUrl, MainActivity.extractValidUrl(httpsUrl))

      val httpUrl = "http://example.com/media/sample.mp4"
      assertEquals(httpUrl, MainActivity.extractValidUrl(httpUrl))
  }

  @Test
  fun testExtractValidUrl_WithPunctuationAndQuotes() {
      val quotedUrl = "\"https://instagram.com/reel/C12345/\""
      assertEquals("https://instagram.com/reel/C12345/", MainActivity.extractValidUrl(quotedUrl))

      val trailingPeriod = "Check out https://tiktok.com/@user/video/987654321."
      assertEquals("https://tiktok.com/@user/video/987654321", MainActivity.extractValidUrl(trailingPeriod))

      val bracketed = "<https://twitter.com/i/status/123456789>"
      assertEquals("https://twitter.com/i/status/123456789", MainActivity.extractValidUrl(bracketed))
  }

  @Test
  fun testExtractValidUrl_FromShareText() {
      val shareText = "Look at this video https://vimeo.com/123456 shared via App"
      assertEquals("https://vimeo.com/123456", MainActivity.extractValidUrl(shareText))
  }

  @Test
  fun testExtractValidUrl_RejectsContentAndFileSchemes() {
      assertNull(MainActivity.extractValidUrl("content://media/external/images/media/123"))
      assertNull(MainActivity.extractValidUrl("file:///sdcard/Download/video.mp4"))
      assertNull(MainActivity.extractValidUrl("javascript:alert(1)"))
      assertNull(MainActivity.extractValidUrl("data:text/plain;base64,SGVsbG8="))
  }

  @Test
  fun testExtractValidUrl_RejectsMalformedAndEmpty() {
      assertNull(MainActivity.extractValidUrl(null))
      assertNull(MainActivity.extractValidUrl(""))
      assertNull(MainActivity.extractValidUrl("   "))
      assertNull(MainActivity.extractValidUrl("http://"))
      assertNull(MainActivity.extractValidUrl("https://"))
      assertNull(MainActivity.extractValidUrl("Just ordinary plain text without links"))
  }

  @Test
  fun testAndroidDecoderCapabilityDetection_PlayableMp4() {
      val normalMp4 = com.example.media.probe.MediaProbeInfo(
          pathOrUri = "file:///storage/emulated/0/Movies/sample_video.mp4",
          format = "mov,mp4,m4a,3gp,3g2,mj2",
          durationMs = 60000,
          sizeBytes = 15000000,
          overallBitrate = 2000000,
          streamCount = 2,
          videoStreams = listOf(
              com.example.media.probe.VideoStreamInfo(
                  index = 0,
                  codec = "h264",
                  profile = "High",
                  level = "4.0",
                  width = 1920,
                  height = 1080,
                  frameRate = 60f,
                  isDefault = true
              )
          ),
          audioStreams = listOf(
              com.example.media.probe.AudioStreamInfo(
                  index = 1,
                  codec = "aac",
                  sampleRate = 48000,
                  channels = 2,
                  isDefault = true
              )
          )
      )

      val report = normalMp4.toDecoderCapabilityReport()
      println("\n=== TEST 1: NORMAL PLAYABLE MP4 ===")
      println(report)
      assertTrue(report.contains("# ANDROID DECODER CAPABILITY"))
      assertTrue(report.contains("VIDEO"))
      assertTrue(report.contains("Codec: H.264"))
      assertTrue(report.contains("Requested Profile: High"))
      assertTrue(report.contains("Requested Level: 4.0"))
      assertTrue(report.contains("AUDIO"))
      assertTrue(report.contains("Codec: AAC"))
  }

  @Test
  fun testAndroidDecoderCapabilityDetection_PlayableMkv() {
      val playableMkv = com.example.media.probe.MediaProbeInfo(
          pathOrUri = "file:///storage/emulated/0/Movies/playable_sample.mkv",
          format = "matroska,webm",
          durationMs = 120000,
          sizeBytes = 45000000,
          overallBitrate = 3000000,
          streamCount = 2,
          videoStreams = listOf(
              com.example.media.probe.VideoStreamInfo(
                  index = 0,
                  codec = "h264",
                  profile = "High",
                  level = "4.1",
                  width = 1920,
                  height = 1080,
                  frameRate = 30f,
                  isDefault = true
              )
          ),
          audioStreams = listOf(
              com.example.media.probe.AudioStreamInfo(
                  index = 1,
                  codec = "aac",
                  sampleRate = 48000,
                  channels = 2,
                  isDefault = true
              )
          )
      )

      val report = playableMkv.toDecoderCapabilityReport()
      println("\n=== TEST 2: PLAYABLE MKV ===")
      println(report)
      assertTrue(report.contains("# ANDROID DECODER CAPABILITY"))
      assertTrue(report.contains("VIDEO"))
      assertTrue(report.contains("Codec: H.264"))
      assertTrue(report.contains("AUDIO"))
      assertTrue(report.contains("Codec: AAC"))
  }

  @Test
  fun testAndroidDecoderCapabilityDetection_FailingMkv() {
      val failingMkv = com.example.media.probe.MediaProbeInfo(
          pathOrUri = "file:///storage/emulated/0/Movies/failing_hevc_eac3.mkv",
          format = "matroska,webm",
          durationMs = 154000,
          sizeBytes = 125000000,
          overallBitrate = 6500000,
          streamCount = 2,
          videoStreams = listOf(
              com.example.media.probe.VideoStreamInfo(
                  index = 0,
                  codec = "hevc",
                  profile = "Main 10",
                  level = "5.1",
                  width = 3840,
                  height = 2160,
                  frameRate = 60f,
                  isDefault = true
              )
          ),
          audioStreams = listOf(
              com.example.media.probe.AudioStreamInfo(
                  index = 1,
                  codec = "eac3",
                  sampleRate = 48000,
                  channels = 6,
                  isDefault = true
              )
          )
      )

      val report = failingMkv.toDecoderCapabilityReport()
      println("\n=== TEST 3: FAILING MKV (HEVC Main 10 + E-AC-3) ===")
      println(report)
      assertTrue(report.contains("# ANDROID DECODER CAPABILITY"))
      assertTrue(report.contains("VIDEO"))
      assertTrue(report.contains("Codec: HEVC"))
      assertTrue(report.contains("Requested Profile: Main 10"))
      assertTrue(report.contains("Requested Level: 5.1"))
      assertTrue(report.contains("AUDIO"))
      assertTrue(report.contains("Codec: E-AC-3"))
  }

  @Test
  fun testPlaybackAnalysis_WorkingMp4() {
      val normalMp4 = com.example.media.probe.MediaProbeInfo(
          pathOrUri = "file:///storage/emulated/0/Movies/sample_video.mp4",
          format = "mov,mp4,m4a,3gp,3g2,mj2",
          durationMs = 60000,
          sizeBytes = 15000000,
          overallBitrate = 2000000,
          streamCount = 2,
          videoStreams = listOf(
              com.example.media.probe.VideoStreamInfo(
                  index = 0,
                  codec = "h264",
                  profile = "High",
                  level = "4.0",
                  width = 1920,
                  height = 1080,
                  frameRate = 60f,
                  bitDepth = 8,
                  isDefault = true
              )
          ),
          audioStreams = listOf(
              com.example.media.probe.AudioStreamInfo(
                  index = 1,
                  codec = "aac",
                  sampleRate = 48000,
                  channels = 2,
                  isDefault = true
              )
          )
      )

      val report = com.example.media.playback.PlaybackDiagnosticEngine.analyzePlayback(
          probeInfo = normalMp4
      )
      val formatted = report.toFormattedReport()
      println("\n=== PHASE 4 TEST: WORKING MP4 ===")
      println(formatted)

      assertEquals(com.example.media.playback.PlaybackAnalysisResult.SUCCESS, report.result)
      assertEquals("Media3 / ExoPlayer", report.player)
      assertNull(report.failure)
      assertTrue(formatted.contains("# PLAYBACK ANALYSIS"))
      assertTrue(formatted.contains("Result:\nSUCCESS"))
      assertTrue(formatted.contains("Player:\nMedia3 / ExoPlayer"))
      assertTrue(formatted.contains("Container:\nMP4"))
      assertTrue(formatted.contains("Video:\nH.264"))
      assertTrue(formatted.contains("Profile:\nHigh"))
      assertTrue(formatted.contains("Pixel Format:\n8-bit"))
      assertTrue(formatted.contains("Audio:\nAAC"))
      assertTrue(formatted.contains("Media container and codecs are fully compatible"))
      assertTrue(formatted.contains("Direct playback operational"))
  }

  @Test
  fun testPlaybackAnalysis_WorkingMkv() {
      val playableMkv = com.example.media.probe.MediaProbeInfo(
          pathOrUri = "file:///storage/emulated/0/Movies/compatible_feature.mkv",
          format = "matroska,webm",
          durationMs = 120000,
          sizeBytes = 35000000,
          overallBitrate = 2300000,
          streamCount = 2,
          videoStreams = listOf(
              com.example.media.probe.VideoStreamInfo(
                  index = 0,
                  codec = "h264",
                  profile = "High",
                  level = "4.1",
                  width = 1920,
                  height = 1080,
                  frameRate = 30f,
                  bitDepth = 8,
                  isDefault = true
              )
          ),
          audioStreams = listOf(
              com.example.media.probe.AudioStreamInfo(
                  index = 1,
                  codec = "aac",
                  sampleRate = 48000,
                  channels = 2,
                  isDefault = true
              )
          )
      )

      val report = com.example.media.playback.PlaybackDiagnosticEngine.analyzePlayback(
          probeInfo = playableMkv
      )
      val formatted = report.toFormattedReport()
      println("\n=== PHASE 4 TEST: WORKING MKV ===")
      println(formatted)

      assertEquals(com.example.media.playback.PlaybackAnalysisResult.SUCCESS, report.result)
      assertEquals("Media3 / ExoPlayer", report.player)
      assertNull(report.failure)
      assertTrue(formatted.contains("# PLAYBACK ANALYSIS"))
      assertTrue(formatted.contains("Result:\nSUCCESS"))
      assertTrue(formatted.contains("Container:\nMatroska / WebM"))
      assertTrue(formatted.contains("Video:\nH.264"))
      assertTrue(formatted.contains("Audio:\nAAC"))
      // Must NOT say MKV is unsupported merely because the file extension is MKV
      assertFalse(formatted.contains("unsupported", ignoreCase = true))
      assertTrue(formatted.contains("Direct playback operational"))
  }

  @Test
  fun testPlaybackAnalysis_FailingMkv_DecoderInitException() {
      val failingMkv = com.example.media.probe.MediaProbeInfo(
          pathOrUri = "file:///storage/emulated/0/Movies/failing_hevc_eac3.mkv",
          format = "matroska,webm",
          durationMs = 154000,
          sizeBytes = 125000000,
          overallBitrate = 6500000,
          streamCount = 2,
          videoStreams = listOf(
              com.example.media.probe.VideoStreamInfo(
                  index = 0,
                  codec = "hevc",
                  profile = "Main 10",
                  level = "5.1",
                  width = 3840,
                  height = 2160,
                  pixelFormat = "yuv420p10le",
                  bitDepth = 10,
                  frameRate = 60f,
                  isDefault = true
              )
          ),
          audioStreams = listOf(
              com.example.media.probe.AudioStreamInfo(
                  index = 1,
                  codec = "eac3",
                  sampleRate = 48000,
                  channels = 6,
                  isDefault = true
              )
          )
      )

      val hevcFormat = androidx.media3.common.Format.Builder()
          .setSampleMimeType("video/hevc")
          .setCodecs("hev1.2.4.L153.B0")
          .setWidth(3840)
          .setHeight(2160)
          .build()

      val decoderInitEx = androidx.media3.exoplayer.mediacodec.MediaCodecRenderer.DecoderInitializationException(
          hevcFormat,
          java.lang.IllegalStateException("Profile not supported by device decoder"),
          false,
          androidx.media3.common.PlaybackException.ERROR_CODE_DECODER_INIT_FAILED
      )

      val playbackEx = androidx.media3.common.PlaybackException(
          "Decoder init failed for video/hevc",
          decoderInitEx,
          androidx.media3.common.PlaybackException.ERROR_CODE_DECODER_INIT_FAILED
      )

      val report = com.example.media.playback.PlaybackDiagnosticEngine.analyzePlayback(
          error = playbackEx,
          probeInfo = failingMkv
      )
      val formatted = report.toFormattedReport()
      println("\n=== PHASE 4 TEST: FAILING MKV (HEVC Main 10 + E-AC-3) ===")
      println(formatted)

      assertEquals(com.example.media.playback.PlaybackAnalysisResult.FAILED, report.result)
      assertEquals("Media3 / ExoPlayer", report.player)
      assertNotNull(report.failure)
      assertEquals("DecoderInitializationException", report.failure?.exceptionClass)

      assertTrue(formatted.contains("# PLAYBACK ANALYSIS"))
      assertTrue(formatted.contains("Result:\nFAILED"))
      assertTrue(formatted.contains("Player:\nMedia3 / ExoPlayer"))
      assertTrue(formatted.contains("Failure:\nDecoderInitializationException"))
      assertTrue(formatted.contains("Container:\nMatroska / WebM"))
      assertTrue(formatted.contains("Video:\nHEVC"))
      assertTrue(formatted.contains("Profile:\nMain 10"))
      assertTrue(formatted.contains("Pixel Format:\n10-bit"))
      assertTrue(formatted.contains("Audio:\nE-AC-3"))
      assertTrue(formatted.contains("The requested video profile is not supported by\nthe available decoder."))
      assertTrue(formatted.contains("Remux will NOT fix codec incompatibility.\nTranscoding may be required."))
  }

  @Test
  fun testPlaybackAnalysis_ParserException_DemuxFailureWithStandardCodecs() {
      val aviFile = com.example.media.probe.MediaProbeInfo(
          pathOrUri = "file:///storage/emulated/0/Movies/old_format.avi",
          format = "avi",
          durationMs = 90000,
          sizeBytes = 25000000,
          overallBitrate = 2200000,
          streamCount = 2,
          videoStreams = listOf(
              com.example.media.probe.VideoStreamInfo(
                  index = 0,
                  codec = "h264",
                  profile = "Main",
                  level = "3.1",
                  width = 1280,
                  height = 720,
                  frameRate = 25f,
                  isDefault = true
              )
          ),
          audioStreams = listOf(
              com.example.media.probe.AudioStreamInfo(
                  index = 1,
                  codec = "aac",
                  sampleRate = 44100,
                  channels = 2,
                  isDefault = true
              )
          )
      )

      val parserEx = androidx.media3.common.ParserException.createForMalformedContainer(
          "Unrecognized or unsupported AVI header",
          null
      )
      val playbackEx = androidx.media3.common.PlaybackException(
          "Parser error",
          parserEx,
          androidx.media3.common.PlaybackException.ERROR_CODE_PARSING_CONTAINER_UNSUPPORTED
      )

      val report = com.example.media.playback.PlaybackDiagnosticEngine.analyzePlayback(
          error = playbackEx,
          probeInfo = aviFile
      )
      val formatted = report.toFormattedReport()
      println("\n=== PHASE 4 TEST: PARSER EXCEPTION WITH COMPATIBLE CODECS ===")
      println(formatted)

      assertEquals(com.example.media.playback.PlaybackAnalysisResult.FAILED, report.result)
      assertTrue(formatted.contains("Failure:\nParserException"))
      assertTrue(formatted.contains("Remuxing to MP4 container may resolve the container/parser incompatibility without transcoding."))
  }
}
