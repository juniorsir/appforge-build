import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.appforge.generated',
  appName: 'Generated App',
  webDir: '.',
  server: {
    androidScheme: 'https'
  }
};

export default config;
