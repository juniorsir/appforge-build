package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "downloads")
data class DownloadEntity(
    @PrimaryKey val id: String, // videoId
    val title: String,
    val author: String,
    val durationText: String,
    val thumbnailUrl: String,
    val localPath: String,
    val fileSize: Long,
    val downloadedAt: Long = System.currentTimeMillis()
)
