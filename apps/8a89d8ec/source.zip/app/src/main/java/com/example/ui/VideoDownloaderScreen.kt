package com.example.ui

import android.content.Context
import android.util.Log
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.animation.core.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.example.data.DownloadEntity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.IntOffset
import kotlin.math.roundToInt
import androidx.compose.ui.graphics.graphicsLayer

// Theme Palette - Noir Minimalist (Strictly Black & White)
val SleekBg = Color(0xFF000000) // Pitch Black
val SleekCard = Color(0xFF161616) // Solid dark charcoal cards
val SleekCardDark = Color(0xFF0A0A0A) // Deeper pure obsidian contrast
val SleekPurpleDark = Color(0xFFFFFFFF) // Pure High-Contrast White Accent
val SleekPurpleLight = Color(0xFFD4D4D4) // Clean soft white-grey
val SleekPurpleContainer = Color(0xFF262626) // Medium charcoal grey containers
val SleekTextPrimary = Color(0xFFFFFFFF) // High-contrast crisp white
val SleekTextSecondary = Color(0xFFE5E5E5) // Clean light slate grey for superior reading comfort
val SleekTextMuted = Color(0xFF8A8A8A) // Graphite grey for informative hints/placeholders
val SleekBorderColor = Color(0xFF2E2E2E) // Sharp ultra-thin graphite border lines
val CrimsonFailure = Color(0xFFFFFFFF) // Noir style white-accent alert
val EmeraldSuccess = Color(0xFFFFFFFF) // Noir style white-accent success

// Backwards compatibility mappings for existing layouts
val SlateBg = SleekBg
val SlateCard = SleekCard
val SlateCardDark = SleekCardDark
val AmberAccent = SleekPurpleDark
val AmberAccentLight = SleekPurpleDark
val SilverText = SleekTextSecondary
val WhiteText = SleekTextPrimary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VideoDownloaderScreen(
    viewModel: VideoDownloaderViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current

    val urlInput by viewModel.videoUrlInput.collectAsStateWithLifecycle()
    val isAnalyzing by viewModel.isAnalyzing.collectAsStateWithLifecycle()
    val analyzedVideo by viewModel.analyzedVideo.collectAsStateWithLifecycle()
    val analysisError by viewModel.analysisError.collectAsStateWithLifecycle()
    val activeDownloads by viewModel.activeDownloads.collectAsStateWithLifecycle()
    val downloadHistory by viewModel.downloadHistory.collectAsStateWithLifecycle()
    val executionLogs by viewModel.executionLogs.collectAsStateWithLifecycle()
    val isAudioOnly by viewModel.isAudioOnlyMode.collectAsStateWithLifecycle()
    val searchResults by viewModel.searchResults.collectAsStateWithLifecycle()
    val isSearching by viewModel.isSearching.collectAsStateWithLifecycle()

    var selectedTabIndex by remember { mutableStateOf(0) }
    var playingDownload by remember { mutableStateOf<DownloadEntity?>(null) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                brush = Brush.linearGradient(
                    colors = listOf(
                        Color(0xFF000000),
                        Color(0xFF0E0E0E),
                        Color(0xFF000000)
                    )
                )
            )
    ) {
        val infiniteTransition = androidx.compose.animation.core.rememberInfiniteTransition()
        val colorOffset by infiniteTransition.animateFloat(
            initialValue = 0f,
            targetValue = 1000f,
            animationSpec = androidx.compose.animation.core.infiniteRepeatable(
                animation = androidx.compose.animation.core.tween(15000, easing = androidx.compose.animation.core.LinearEasing),
                repeatMode = androidx.compose.animation.core.RepeatMode.Reverse
            ), label = "background_offset"
        )
        
        Canvas(modifier = Modifier.fillMaxSize()) {
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(Color(0x1EFFFFFF), Color.Transparent),
                    center = androidx.compose.ui.geometry.Offset(size.width / 4, colorOffset),
                    radius = size.width
                )
            )
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(Color(0x0CFFFFFF), Color.Transparent),
                    center = androidx.compose.ui.geometry.Offset(size.width * 0.8f, size.height - colorOffset),
                    radius = size.width * 0.8f
                )
            )
        }
        
        Scaffold(
            modifier = Modifier.fillMaxSize(),
            containerColor = Color.Transparent,
            topBar = {
            Column {
                CenterAlignedTopAppBar(
                    title = {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            // DL/TubeStream icon box
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .background(SleekPurpleLight, shape = RoundedCornerShape(10.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "DL",
                                    color = SleekPurpleDark,
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.Black,
                                        fontFamily = FontFamily.SansSerif
                                    )
                                )
                            }
                            Column {
                                Text(
                                    text = "TubeStream",
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.ExtraBold,
                                        color = SleekTextPrimary,
                                        letterSpacing = (-0.5).sp
                                    )
                                )
                                Text(
                                    text = "POWERED BY TUBESTREAM",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 8.sp,
                                        color = SleekTextSecondary.copy(alpha = 0.8f),
                                        letterSpacing = 1.2.sp
                                    )
                                )
                            }
                        }
                    },
                    actions = {
                        val isTestMode by viewModel.isTestModeActive.collectAsStateWithLifecycle()
                        IconButton(onClick = { viewModel.toggleTestMode() }) {
                            Icon(
                                imageVector = Icons.Default.Build,
                                contentDescription = "Test Mode Toggle",
                                tint = if (isTestMode) EmeraldSuccess else SleekTextSecondary
                            )
                        }
                    },
                    colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                        containerColor = SleekBg,
                        titleContentColor = SleekTextPrimary
                    )
                )
                Divider(color = SleekBorderColor.copy(alpha = 0.5f), thickness = 1.dp)
            }
        },
        bottomBar = {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(SleekBg)
            ) {
                Divider(color = SleekBorderColor.copy(alpha = 0.5f), thickness = 1.dp, modifier = Modifier.align(Alignment.TopCenter))
                NavigationBar(
                    containerColor = Color.Transparent,
                    contentColor = SleekPurpleDark,
                    tonalElevation = 0.dp,
                    modifier = Modifier.padding(top = 1.dp)
                ) {
                    NavigationBarItem(
                        selected = selectedTabIndex == 0,
                        onClick = { selectedTabIndex = 0 },
                        icon = { Icon(Icons.Default.Add, contentDescription = null) },
                        label = { Text("DOWNLOAD", fontWeight = FontWeight.SemiBold, fontSize = 10.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = SleekTextPrimary,
                            selectedTextColor = SleekPurpleDark,
                            indicatorColor = SleekPurpleContainer.copy(alpha = 0.8f),
                            unselectedIconColor = SleekTextSecondary,
                            unselectedTextColor = SleekTextSecondary
                        )
                    )
                    NavigationBarItem(
                        selected = selectedTabIndex == 1,
                        onClick = { selectedTabIndex = 1 },
                        icon = { Icon(Icons.Default.Info, contentDescription = null) },
                        label = { Text("LIBRARY", fontWeight = FontWeight.SemiBold, fontSize = 10.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = SleekTextPrimary,
                            selectedTextColor = SleekPurpleDark,
                            indicatorColor = SleekPurpleContainer.copy(alpha = 0.8f),
                            unselectedIconColor = SleekTextSecondary,
                            unselectedTextColor = SleekTextSecondary
                        )
                    )
                    NavigationBarItem(
                        selected = selectedTabIndex == 2,
                        onClick = { selectedTabIndex = 2 },
                        icon = { Icon(Icons.Default.Settings, contentDescription = null) },
                        label = { Text("SETTINGS", fontWeight = FontWeight.SemiBold, fontSize = 10.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = SleekTextPrimary,
                            selectedTextColor = SleekPurpleDark,
                            indicatorColor = SleekPurpleContainer.copy(alpha = 0.8f),
                            unselectedIconColor = SleekTextSecondary,
                            unselectedTextColor = SleekTextSecondary
                        )
                    )
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
        ) {
            AnimatedContent(
                targetState = selectedTabIndex,
                transitionSpec = {
                    if (targetState > initialState) {
                        slideInHorizontally { width -> width } + fadeIn() togetherWith
                                slideOutHorizontally { width -> -width } + fadeOut()
                    } else {
                        slideInHorizontally { width -> -width } + fadeIn() togetherWith
                                slideOutHorizontally { width -> width } + fadeOut()
                    }.using(SizeTransform(clip = false))
                },
                label = "TabTransition",
                modifier = Modifier.weight(1f)
            ) { targetTab ->
                when (targetTab) {
                    0 -> DownloadTab(
                        urlInput = urlInput,
                        urlHistory = viewModel.urlHistory.collectAsStateWithLifecycle().value,
                        isAnalyzing = isAnalyzing,
                        analyzedVideo = analyzedVideo,
                        analysisError = analysisError,
                        activeDownloads = activeDownloads,
                        executionLogs = executionLogs,
                        isAudioOnly = isAudioOnly,
                        searchResults = searchResults,
                        isSearching = isSearching,
                        onToggleAudioOnly = { viewModel.toggleAudioOnlyMode() },
                        onClearLogs = { viewModel.clearLogs() },
                        onUrlChange = { viewModel.updateUrlInput(it) },
                        onClearUrlHistory = { viewModel.clearUrlHistory() },
                        onPasteClick = {
                            clipboardManager.getText()?.text?.let { viewModel.updateUrlInput(it) }
                        },
                        onClearClick = { viewModel.updateUrlInput("") },
                        onAnalyzeClick = { viewModel.analyzeVideo() },
                        onDownloadFormat = { format ->
                            analyzedVideo?.let { video ->
                                viewModel.startDownload(video, format)
                            }
                        },
                        onCancelActiveTask = { taskId ->
                            viewModel.removeActiveTask(taskId)
                        },
                        onSearchResultClick = { result ->
                            viewModel.updateUrlInput(result.originalUrl)
                            viewModel.analyzeVideo()
                        }
                    )
                    1 -> LibraryTab(
                        downloads = downloadHistory,
                        onPlayClick = { playingDownload = it },
                        onShareClick = { viewModel.shareVideo(context, it) },
                        onDeleteClick = { viewModel.deleteDownload(it) },
                        onConvertAudio = { viewModel.convertAudio(it) }
                    )
                    2 -> SettingsTab(
                        downloads = downloadHistory,
                        onClearAllDownloads = { viewModel.clearAllDownloads() },
                        viewModel = viewModel
                    )
                }
            }
        }
    }

    if (playingDownload != null) {
        val path = playingDownload!!.localPath.lowercase()
        val isAudio = path.endsWith(".mp3") ||
                      path.endsWith(".m4a") ||
                      path.endsWith(".opus") ||
                      path.endsWith(".wav") ||
                      path.endsWith(".ogg") ||
                      path.endsWith(".aac") ||
                      path.endsWith(".flac") ||
                      path.contains("/audios/") ||
                      path.contains("audio")
        
        if (isAudio) {
            AudioPlayerDialog(
                download = playingDownload!!,
                onDismiss = { playingDownload = null }
            )
        } else {
            VideoPlayerDialog(
                download = playingDownload!!,
                onDismiss = { playingDownload = null }
            )
        }
    }

    val showFloatingWidget by viewModel.showFloatingWidget.collectAsStateWithLifecycle()
    if (showFloatingWidget) {
        FloatingSearchWidget(
            viewModel = viewModel,
            onClose = { viewModel.triggerFloatingWidget(false) }
        )
    }
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DownloadTab(
    urlInput: String,
    urlHistory: List<String>,
    isAnalyzing: Boolean,
    analyzedVideo: AnalyzedVideo?,
    analysisError: String?,
    activeDownloads: Map<String, ActiveDownloadTask>,
    executionLogs: List<String>,
    isAudioOnly: Boolean,
    searchResults: List<YtdlpPipelineManager.SearchResult>,
    isSearching: Boolean,
    onToggleAudioOnly: () -> Unit,
    onClearLogs: () -> Unit,
    onUrlChange: (String) -> Unit,
    onClearUrlHistory: () -> Unit,
    onPasteClick: () -> Unit,
    onClearClick: () -> Unit,
    onAnalyzeClick: () -> Unit,
    onDownloadFormat: (VideoFormatUi) -> Unit,
    onCancelActiveTask: (String) -> Unit,
    onSearchResultClick: (YtdlpPipelineManager.SearchResult) -> Unit
) {
    var showDownloadSheet by remember { mutableStateOf(false) }

    Box(modifier = Modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
        // Welcome and link parsing card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.Transparent),
                shape = RoundedCornerShape(28.dp),
                border = BorderStroke(1.dp, SleekBorderColor.copy(alpha = 0.3f)),
                elevation = CardDefaults.cardElevation(defaultElevation = 12.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.linearGradient(
                                colors = listOf(SleekCard, SleekCardDark)
                            )
                        )
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Text(
                            text = "Universal Downloader",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.ExtraBold,
                                color = SleekPurpleDark,
                                letterSpacing = 0.5.sp
                            )
                        )
                        Text(
                            text = "Paste any streaming video, direct download link, or YouTube URL below to extract and download instantly.",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = SleekTextSecondary.copy(alpha = 0.9f),
                                lineHeight = 20.sp
                            )
                        )

                        // URL Input Field
                        var historyExpanded by remember { mutableStateOf(false) }
                        val focusManager = androidx.compose.ui.platform.LocalFocusManager.current

                        ExposedDropdownMenuBox(
                            expanded = historyExpanded,
                            onExpandedChange = { historyExpanded = false } // Don't Auto Expand on click without focus logic, we'll manage manually on click
                        ) {
                            OutlinedTextField(
                                value = urlInput,
                                onValueChange = { 
                                    onUrlChange(it) 
                                    historyExpanded = false 
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .menuAnchor()
                                    .onFocusChanged { state ->
                                        if (state.isFocused && urlHistory.isNotEmpty() && urlInput.isEmpty()) {
                                            historyExpanded = true
                                        }
                                    }
                                    .testTag("url_input_field"),
                                textStyle = MaterialTheme.typography.bodyLarge.copy(color = SleekTextPrimary),
                                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                                keyboardActions = KeyboardActions(onSearch = { 
                                    focusManager.clearFocus()
                                    historyExpanded = false
                                    onAnalyzeClick() 
                                }),
                                placeholder = { Text("Paste video URL here...", color = SleekTextMuted, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                                trailingIcon = {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.padding(end = 6.dp)
                                    ) {
                                        if (urlInput.isNotEmpty()) {
                                            IconButton(
                                                onClick = onClearClick,
                                                modifier = Modifier.size(36.dp)
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.Clear,
                                                    contentDescription = "Clear",
                                                    tint = SleekTextSecondary,
                                                    modifier = Modifier.size(18.dp)
                                                )
                                            }
                                        } else {
                                            TextButton(
                                                onClick = onPasteClick,
                                                colors = ButtonDefaults.textButtonColors(contentColor = SleekPurpleDark),
                                                modifier = Modifier.testTag("paste_button")
                                            ) {
                                                Text("PASTE", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                            }
                                        }

                                        Spacer(modifier = Modifier.width(4.dp))

                                        // Beautiful, rounded search/action button inside
                                        val buttonAlpha by animateFloatAsState(targetValue = if (urlInput.trim().isNotEmpty() && !isAnalyzing) 1f else 0.4f, label = "ButtonAlpha")
                                        Box(
                                            modifier = Modifier
                                                .size(44.dp)
                                                .clip(CircleShape)
                                                .background(SleekPurpleDark.copy(alpha = buttonAlpha))
                                                .clickable(
                                                    enabled = urlInput.trim().isNotEmpty() && !isAnalyzing,
                                                    onClick = {
                                                        focusManager.clearFocus()
                                                        historyExpanded = false
                                                        onAnalyzeClick()
                                                    }
                                                )
                                                .testTag("analyze_button"),
                                             contentAlignment = Alignment.Center
                                        ) {
                                            if (isAnalyzing) {
                                                CircularProgressIndicator(
                                                    modifier = Modifier.size(20.dp),
                                                    color = SleekBg,
                                                    strokeWidth = 2.dp
                                                )
                                            } else {
                                                Icon(
                                                    imageVector = Icons.Default.Search,
                                                    contentDescription = "Search & Analyze",
                                                    tint = SleekBg.copy(alpha = buttonAlpha),
                                                    modifier = Modifier.size(22.dp)
                                                )
                                            }
                                        }
                                    }
                                },
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedContainerColor = SleekCardDark.copy(alpha = 0.5f),
                                    unfocusedContainerColor = SleekCardDark.copy(alpha = 0.5f),
                                    focusedBorderColor = SleekPurpleDark,
                                    unfocusedBorderColor = SleekBorderColor,
                                    focusedTextColor = SleekTextPrimary,
                                    unfocusedTextColor = SleekTextPrimary,
                                    cursorColor = SleekPurpleDark
                                ),
                                shape = RoundedCornerShape(24.dp),
                                singleLine = true
                            )
                            
                            ExposedDropdownMenu(
                                expanded = historyExpanded,
                                onDismissRequest = { historyExpanded = false },
                                modifier = Modifier.background(SleekCardDark)
                            ) {
                                if (urlHistory.isNotEmpty()) {
                                    urlHistory.forEach { historyUrl ->
                                        DropdownMenuItem(
                                            text = { Text(historyUrl, color = SleekTextPrimary, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                                            onClick = {
                                                onUrlChange(historyUrl)
                                                historyExpanded = false
                                                focusManager.clearFocus()
                                            },
                                            leadingIcon = { Icon(Icons.Default.History, contentDescription = null, tint = SleekTextSecondary) }
                                        )
                                    }
                                    HorizontalDivider(color = SleekBorderColor)
                                    DropdownMenuItem(
                                        text = { Text("Clear History", color = CrimsonFailure) },
                                        onClick = {
                                            onClearUrlHistory()
                                            historyExpanded = false
                                        },
                                        leadingIcon = { Icon(Icons.Default.Delete, contentDescription = null, tint = CrimsonFailure) }
                                    )
                                }
                            }
                        }

                        // Quick Action Chips
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            FilterChip(
                                selected = isAudioOnly,
                                onClick = onToggleAudioOnly,
                                label = { Text("Audio Only (MP3)", fontWeight = FontWeight.Bold, fontSize = 12.sp) },
                                leadingIcon = {
                                    Icon(
                                        imageVector = if (isAudioOnly) Icons.Default.CheckCircle else Icons.Default.PlayArrow,
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp)
                                    )
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = EmeraldSuccess.copy(alpha = 0.2f),
                                    selectedLabelColor = EmeraldSuccess,
                                    selectedLeadingIconColor = EmeraldSuccess,
                                    containerColor = SleekCardDark.copy(alpha = 0.5f),
                                    labelColor = SleekTextSecondary,
                                    iconColor = SleekTextSecondary
                                ),
                                border = FilterChipDefaults.filterChipBorder(
                                    borderColor = if (isAudioOnly) EmeraldSuccess else SleekBorderColor,
                                    enabled = true,
                                    selected = isAudioOnly
                                )
                            )
                        }
                    }
                }
            }
        }

        // 🔍 Keyword Search Progress Indicator
        if (isSearching) {
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    CircularProgressIndicator(
                        color = SleekPurpleDark,
                        modifier = Modifier.size(36.dp)
                    )
                    Text(
                        text = "Searching YouTube keywords via JNI...",
                        color = SleekTextSecondary,
                        style = MaterialTheme.typography.bodyMedium.copy(
                            fontWeight = FontWeight.Medium
                        )
                    )
                }
            }
        }

        // 🔍 Keyword Search Results Display
        if (!isSearching && searchResults.isNotEmpty()) {
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 4.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "SEARCH RESULTS",
                        style = MaterialTheme.typography.titleSmall.copy(
                            color = SleekPurpleDark,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            letterSpacing = 1.sp
                        )
                    )
                    
                    Text(
                        text = "Found ${searchResults.size}",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = SleekTextMuted,
                            fontWeight = FontWeight.SemiBold
                        )
                    )
                }
            }

            items(searchResults) { result ->
                SearchResultItemRow(
                    result = result,
                    onClick = { onSearchResultClick(result) },
                    modifier = Modifier.animateItem()
                )
            }
        }

        // Active Diagnostics / Error Info
        if (analysisError != null) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = CrimsonFailure.copy(alpha = 0.15f)),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, CrimsonFailure.copy(alpha = 0.3f))
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Warning, contentDescription = "Error", tint = CrimsonFailure, modifier = Modifier.size(24.dp))
                        Text(
                            text = analysisError,
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = CrimsonFailure,
                                fontWeight = FontWeight.Medium
                            )
                        )
                    }
                }
            }
        }

        // Active Downloads section
        if (activeDownloads.isNotEmpty()) {
            item {
                Text(
                    text = "ACTIVE DOWNLOADS",
                    style = MaterialTheme.typography.titleSmall.copy(
                        color = AmberAccent,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    ),
                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                )
            }

            items(activeDownloads.values.toList(), key = { it.id }) { task ->
                ActiveDownloadCard(
                    task = task, 
                    onCancelClick = { onCancelActiveTask(task.id) },
                    modifier = Modifier.animateItem()
                )
            }
        }

        // Analyzed Video details card
        if (isAnalyzing) {
            item {
                SkeletonAnalyzedVideoCard()
            }
        } else if (analyzedVideo != null) {
            item {
                AnalyzedVideoCard(
                    video = analyzedVideo,
                    onOpenDownloadOptions = {
                        showDownloadSheet = true
                    }
                )
            }
        }
    }

    if (showDownloadSheet && analyzedVideo != null) {
        val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = false)
        ModalBottomSheet(
            onDismissRequest = { showDownloadSheet = false },
            sheetState = sheetState,
            containerColor = SleekCardDark,
            dragHandle = { BottomSheetDefaults.DragHandle(color = SleekTextSecondary) }
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
                    .padding(bottom = 32.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    text = "DOWNLOAD OPTIONS",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = SleekPurpleDark,
                        letterSpacing = 1.sp
                    )
                )
                
                val videoFormats = analyzedVideo.formats.filter { it.type == "combined" || it.type == "video_only" }
                val audioFormats = analyzedVideo.formats.filter { it.type == "audio" }

                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    if (videoFormats.isNotEmpty()) {
                        item {
                            Text(
                                text = "VIDEO",
                                style = MaterialTheme.typography.labelSmall.copy(color = SleekTextSecondary),
                                modifier = Modifier.padding(bottom = 4.dp)
                            )
                        }
                        items(videoFormats) { format ->
                            FormatRowItem(
                                format = format, 
                                modifier = Modifier.animateItem(),
                                onDownloadClick = {
                                    onDownloadFormat(format)
                                    showDownloadSheet = false
                                }
                            )
                        }
                    }

                    if (audioFormats.isNotEmpty()) {
                        item {
                            Spacer(Modifier.height(8.dp))
                            Text(
                                text = "AUDIO",
                                style = MaterialTheme.typography.labelSmall.copy(color = SleekTextSecondary),
                                modifier = Modifier.padding(bottom = 4.dp)
                            )
                        }
                        items(audioFormats) { format ->
                            FormatRowItem(
                                format = format,
                                modifier = Modifier.animateItem(),
                                onDownloadClick = {
                                    onDownloadFormat(format)
                                    showDownloadSheet = false
                                }
                            )
                        }
                    }
                }
            }
        }
    }
  }
}

@Composable
fun ActiveDownloadCard(
    task: ActiveDownloadTask,
    onCancelClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = androidx.compose.animation.core.rememberInfiniteTransition()
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.5f,
        targetValue = 1f,
        animationSpec = androidx.compose.animation.core.infiniteRepeatable(
            animation = androidx.compose.animation.core.tween(1000, easing = androidx.compose.animation.core.FastOutSlowInEasing),
            repeatMode = androidx.compose.animation.core.RepeatMode.Reverse
        ), label = "PulseAlpha"
    )

    val borderColor = when (task.status) {
        DownloadStatus.FAILED -> CrimsonFailure.copy(alpha = 0.6f)
        DownloadStatus.DOWNLOADING -> SleekPurpleLight.copy(alpha = pulseAlpha)
        DownloadStatus.COMPLETED -> EmeraldSuccess.copy(alpha = 0.8f)
        DownloadStatus.PENDING -> SleekTextSecondary.copy(alpha = 0.5f)
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .animateContentSize(animationSpec = androidx.compose.animation.core.spring(dampingRatio = androidx.compose.animation.core.Spring.DampingRatioMediumBouncy, stiffness = androidx.compose.animation.core.Spring.StiffnessLow)),
        colors = CardDefaults.cardColors(containerColor = SleekCard),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, borderColor)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = task.title,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        color = SleekTextPrimary,
                        style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold)
                    )
                    Text(
                        text = "Format: .${task.ext.uppercase()}  |  ${task.speedText}",
                        color = SleekTextSecondary,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
                
                IconButton(onClick = onCancelClick) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Cancel",
                        tint = if (task.status == DownloadStatus.FAILED) CrimsonFailure else SleekTextSecondary
                    )
                }
            }

            if (task.status == DownloadStatus.FAILED) {
                Text(
                    text = task.error ?: "Download terminated unexpectedly.",
                    color = CrimsonFailure,
                    style = MaterialTheme.typography.bodySmall,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            } else {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    val progressPercent = (task.progress * 100).toInt()
                    
                    LinearProgressIndicator(
                        progress = { task.progress },
                        modifier = Modifier
                            .weight(1f)
                            .height(6.dp)
                            .clip(RoundedCornerShape(3.dp)),
                        color = if (task.status == DownloadStatus.COMPLETED) EmeraldSuccess else SleekPurpleDark,
                        trackColor = SleekCardDark
                    )

                    Text(
                        text = "$progressPercent%",
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = SleekPurpleDark,
                            fontFamily = FontFamily.Monospace
                        )
                    )
                }
            }
        }
    }
}

@Composable
fun SkeletonAnalyzedVideoCard() {
    val infiniteTransition = rememberInfiniteTransition(label = "skeleton")
    val alpha by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 0.8f,
        animationSpec = infiniteRepeatable(
            animation = tween(800, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "skeleton_alpha"
    )
    val skeletonColor = SleekCardDark.copy(alpha = alpha)

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(130.dp)
            .testTag("analyzed_video_card_skeleton"),
        colors = CardDefaults.cardColors(containerColor = SleekPurpleContainer.copy(alpha = 0.5f)),
        shape = RoundedCornerShape(20.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxSize().padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Thumbnail Skeleton
            Box(
                modifier = Modifier
                    .fillMaxHeight()
                    .aspectRatio(16f/9f)
                    .clip(RoundedCornerShape(12.dp))
                    .background(skeletonColor)
            )

            // Info Column
            Column(
                modifier = Modifier.weight(1f).fillMaxHeight(),
                verticalArrangement = Arrangement.Center
            ) {
                Box(modifier = Modifier.fillMaxWidth().height(18.dp).background(skeletonColor, RoundedCornerShape(4.dp)))
                Spacer(modifier = Modifier.height(8.dp))
                Box(modifier = Modifier.fillMaxWidth(0.7f).height(18.dp).background(skeletonColor, RoundedCornerShape(4.dp)))
                Spacer(modifier = Modifier.height(16.dp))
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Box(modifier = Modifier.size(16.dp).background(skeletonColor, CircleShape))
                    Box(modifier = Modifier.width(80.dp).height(12.dp).background(skeletonColor, RoundedCornerShape(4.dp)))
                }
            }

            // Button skeleton
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .background(skeletonColor, CircleShape)
            )
        }
    }
}

@Composable
fun AnalyzedVideoCard(
    video: AnalyzedVideo,
    onOpenDownloadOptions: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(130.dp)
            .animateContentSize(animationSpec = androidx.compose.animation.core.spring(dampingRatio = androidx.compose.animation.core.Spring.DampingRatioMediumBouncy, stiffness = androidx.compose.animation.core.Spring.StiffnessLow))
            .testTag("analyzed_video_card"),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        shape = RoundedCornerShape(20.dp),
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.2f))
    ) {
        Box(modifier = Modifier.fillMaxSize().background(
            brush = Brush.linearGradient(
                colors = listOf(SleekPurpleContainer.copy(alpha = 0.4f), Color.White.copy(alpha = 0.05f))
            )
        )) {
            Row(
                modifier = Modifier.fillMaxSize().padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
            // Thumbnail
            Box(
                modifier = Modifier
                    .fillMaxHeight()
                    .aspectRatio(16f/9f)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color.Black)
            ) {
                AsyncImage(
                    model = video.thumbnailUrl,
                    contentDescription = "Video Thumbnail",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop,
                    alpha = 0.9f
                )
                // Duration Badge
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(6.dp)
                        .background(Color.Black.copy(alpha = 0.7f), shape = RoundedCornerShape(4.dp))
                        .padding(horizontal = 4.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = video.durationText,
                        color = Color.White,
                        style = MaterialTheme.typography.bodySmall.copy(
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 9.sp
                        )
                    )
                }
            }

            // Details
            Column(
                modifier = Modifier.weight(1f).fillMaxHeight(),
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    text = video.title,
                    color = SleekTextPrimary,
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(Icons.Default.Person, contentDescription = "Channel", tint = SleekTextSecondary, modifier = Modifier.size(14.dp))
                    Text(
                        text = video.author,
                        color = SleekTextSecondary,
                        style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            // Download Button
            IconButton(
                onClick = onOpenDownloadOptions,
                modifier = Modifier
                    .size(48.dp)
                    .background(SleekPurpleDark, CircleShape)
            ) {
                Icon(Icons.Default.KeyboardArrowDown, contentDescription = "Download Options", tint = SleekTextPrimary)
            }
        }
      }
    }
}

@Composable
fun FormatRowItem(
    format: VideoFormatUi,
    onDownloadClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(
                brush = Brush.linearGradient(
                    colors = listOf(Color.White.copy(alpha = 0.1f), Color.White.copy(alpha = 0.02f))
                )
            )
            .border(1.dp, Color.White.copy(alpha = 0.2f), shape = RoundedCornerShape(16.dp))
            .padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .background(SleekPurpleContainer, shape = RoundedCornerShape(10.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.PlayArrow,
                    contentDescription = null,
                    tint = SleekPurpleDark,
                    modifier = Modifier.size(18.dp)
                )
            }
            Column {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = format.quality,
                        color = SleekTextPrimary,
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Box(
                        modifier = Modifier
                            .background(SleekPurpleLight.copy(alpha = 0.5f), shape = RoundedCornerShape(6.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = format.ext.uppercase(),
                            color = SleekPurpleDark,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                    if (format.type == "video_only") {
                        Box(
                            modifier = Modifier
                                .background(SleekPurpleLight, shape = RoundedCornerShape(6.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "⚡ MERGING",
                                color = SleekTextPrimary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
                Text(
                    text = format.sizeText,
                    color = SleekTextSecondary,
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }

        Button(
            onClick = onDownloadClick,
            colors = ButtonDefaults.buttonColors(
                containerColor = SleekPurpleDark,
                contentColor = SleekBg
            ),
            shape = RoundedCornerShape(50),
            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
            modifier = Modifier.height(36.dp)
        ) {
            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(14.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("GET", fontWeight = FontWeight.Bold, fontSize = 12.sp)
        }
    }
}

@Composable
fun SearchResultItemRow(
    result: YtdlpPipelineManager.SearchResult,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = SleekCard),
        border = BorderStroke(1.dp, SleekBorderColor.copy(alpha = 0.3f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(width = 110.dp, height = 70.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color.Black)
            ) {
                AsyncImage(
                    model = result.thumbnailUrl,
                    contentDescription = result.title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                
                if (result.duration.isNotBlank()) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .padding(4.dp)
                            .background(Color.Black.copy(alpha = 0.75f), RoundedCornerShape(4.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = result.duration,
                            color = Color.White,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 10.sp
                            )
                        )
                    }
                }
            }

            Column(
                modifier = Modifier
                    .weight(1f)
                    .align(Alignment.CenterVertically),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text = result.title,
                    color = SleekTextPrimary,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        fontWeight = FontWeight.Bold,
                        lineHeight = 18.sp
                    ),
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                
                Text(
                    text = result.author,
                    color = SleekTextSecondary,
                    style = MaterialTheme.typography.bodySmall.copy(
                        fontWeight = FontWeight.Medium
                    ),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            
            Box(
                modifier = Modifier
                    .align(Alignment.CenterVertically)
                    .size(36.dp)
                    .background(SleekPurpleDark.copy(alpha = 0.1f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.PlayArrow,
                    contentDescription = "Select & Analyze",
                    tint = SleekPurpleDark,
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}

@OptIn(com.google.accompanist.permissions.ExperimentalPermissionsApi::class)
@Composable
fun LibraryTab(
    downloads: List<DownloadEntity>,
    onPlayClick: (DownloadEntity) -> Unit,
    onShareClick: (DownloadEntity) -> Unit,
    onDeleteClick: (DownloadEntity) -> Unit,
    onConvertAudio: (DownloadEntity) -> Unit
) {
    val permissionState = if (android.os.Build.VERSION.SDK_INT >= 33) {
        com.google.accompanist.permissions.rememberMultiplePermissionsState(listOf(
            android.Manifest.permission.READ_MEDIA_VIDEO,
            android.Manifest.permission.READ_MEDIA_AUDIO
        ))
    } else {
        com.google.accompanist.permissions.rememberMultiplePermissionsState(listOf(
            android.Manifest.permission.READ_EXTERNAL_STORAGE,
            android.Manifest.permission.WRITE_EXTERNAL_STORAGE
        ))
    }

    var selectedFilter by remember { mutableStateOf("All") }
    val filters = listOf("All", "Videos", "Audio")
    
    val filteredDownloads = downloads.filter {
        when (selectedFilter) {
            "Videos" -> it.localPath.endsWith(".mp4", true) || it.localPath.endsWith(".webm", true) || it.localPath.endsWith(".mkv", true)
            "Audio" -> it.localPath.endsWith(".mp3", true) || it.localPath.endsWith(".m4a", true) || it.localPath.endsWith(".opus", true) || it.localPath.endsWith(".wav", true)
            else -> true
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                filters.forEach { filter ->
                    FilterChip(
                        selected = selectedFilter == filter,
                        onClick = { selectedFilter = filter },
                        label = { Text(filter, fontWeight = FontWeight.Bold, fontSize = 12.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = SleekPurpleLight.copy(alpha = 0.2f),
                            selectedLabelColor = SleekPurpleDark,
                            containerColor = SleekBg,
                            labelColor = SleekTextSecondary
                        ),
                        border = FilterChipDefaults.filterChipBorder(
                            borderColor = SleekBorderColor,
                            enabled = true,
                            selected = selectedFilter == filter
                        )
                    )
                }
            }
            if (!permissionState.allPermissionsGranted) {
                IconButton(onClick = { permissionState.launchMultiplePermissionRequest() }) {
                    Icon(Icons.Default.Folder, contentDescription = "Request Storage", tint = SleekPurpleDark)
                }
            }
        }

        if (filteredDownloads.isEmpty()) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(
                    imageVector = Icons.Default.Info,
                    contentDescription = "Empty",
                    tint = SleekTextMuted.copy(alpha = 0.5f),
                    modifier = Modifier.size(80.dp)
                )
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "NO COMPATIBLE MEDIA",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = SleekTextPrimary,
                        letterSpacing = 1.sp
                    )
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = if (!permissionState.allPermissionsGranted) "Grant storage access to see your device media, or download content." else "No media matches the currently selected filter.",
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = SleekTextSecondary,
                        textAlign = TextAlign.Center
                    )
                )
                if (!permissionState.allPermissionsGranted) {
                    Spacer(modifier = Modifier.height(16.dp))
                    Button(onClick = { permissionState.launchMultiplePermissionRequest() }) {
                        Text("Grant Permissions")
                    }
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Text(
                        text = "DOWNLOAD HISTORY (${filteredDownloads.size})",
                        style = MaterialTheme.typography.titleSmall.copy(
                            color = SleekPurpleDark,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            letterSpacing = 1.sp
                        ),
                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 4.dp)
                    )
                }

                items(filteredDownloads, key = { it.id }) { item ->
                    LibraryItemCard(
                        item = item,
                        onPlayClick = { onPlayClick(item) },
                        onShareClick = { onShareClick(item) },
                        onDeleteClick = { onDeleteClick(item) },
                        onConvertAudio = { onConvertAudio(item) },
                        modifier = Modifier.animateItem()
                    )
                }
            }
        }
    }
}

@Composable
fun LibraryItemCard(
    item: DownloadEntity,
    onPlayClick: () -> Unit,
    onShareClick: () -> Unit,
    onDeleteClick: () -> Unit,
    onConvertAudio: () -> Unit,
    modifier: Modifier = Modifier
) {
    var showDeleteConfirmDialog by remember { mutableStateOf(false) }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .animateContentSize(animationSpec = androidx.compose.animation.core.spring(dampingRatio = androidx.compose.animation.core.Spring.DampingRatioMediumBouncy, stiffness = androidx.compose.animation.core.Spring.StiffnessLow))
            .testTag("library_item_card"),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.2f))
    ) {
        Column(modifier = Modifier.background(
            brush = Brush.linearGradient(
                colors = listOf(Color.White.copy(alpha = 0.15f), Color.White.copy(alpha = 0.05f))
            )
        )) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Mini Thumbnail
                Box(
                    modifier = Modifier
                        .size(width = 110.dp, height = 75.dp)
                        .clip(RoundedCornerShape(10.dp))
                ) {
                    AsyncImage(
                        model = item.thumbnailUrl,
                        contentDescription = "Cover",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                    // Length badge
                    Box(
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .padding(4.dp)
                            .background(Color.Black.copy(alpha = 0.7f), shape = RoundedCornerShape(4.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = item.durationText,
                            color = Color.White,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }

                // Info details
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .height(75.dp),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(
                            text = item.title,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            color = SleekTextPrimary,
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Text(
                            text = item.author,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            color = SleekTextSecondary,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // File size formatted
                        val formattedSize = String.format(Locale.getDefault(), "%.1f MB", item.fileSize.toFloat() / (1024 * 1024))
                        val isAudio = item.localPath.endsWith(".mp3") || item.localPath.endsWith(".m4a")
                        
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.PlayArrow,
                                contentDescription = null,
                                tint = SleekTextMuted,
                                modifier = Modifier.size(14.dp)
                            )
                            Text(
                                text = "$formattedSize  •  ${SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(item.downloadedAt))}",
                                color = SleekTextSecondary,
                                style = MaterialTheme.typography.labelSmall
                            )
                        }
                    }
                }
            }

            // Quick actions line
            Divider(color = SleekBorderColor.copy(alpha = 0.4f))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    // Play action (Sleek dark purple pill button)
                    Button(
                        onClick = onPlayClick,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = SleekPurpleDark,
                            contentColor = SleekBg
                        ),
                        shape = RoundedCornerShape(50),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                        modifier = Modifier.height(32.dp)
                    ) {
                        Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("PLAY", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }

                    // Share action (Sleek outline border pill button)
                    OutlinedButton(
                        onClick = onShareClick,
                        border = BorderStroke(1.dp, SleekBorderColor),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = SleekTextSecondary),
                        shape = RoundedCornerShape(50),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                        modifier = Modifier.height(32.dp)
                    ) {
                        Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("SHARE", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }

                    // Convert action if it is a video
                    val isVideo = item.localPath.endsWith(".mp4", true) || item.localPath.endsWith(".mkv", true) || item.localPath.endsWith(".webm", true)
                    if (isVideo) {
                        OutlinedButton(
                            onClick = onConvertAudio,
                            border = BorderStroke(1.dp, SleekBorderColor),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = SleekPurpleLight),
                            shape = RoundedCornerShape(50),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                            modifier = Modifier.height(32.dp)
                        ) {
                            Icon(Icons.Default.MusicNote, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("TO MP3", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                }

                // Delete action
                IconButton(
                    onClick = { showDeleteConfirmDialog = true },
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = "Delete",
                        tint = CrimsonFailure,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }

    if (showDeleteConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirmDialog = false },
            title = { Text("Delete downloaded file?", color = SleekTextPrimary, fontWeight = FontWeight.Bold) },
            text = { Text("This will permanently delete this video from your device storage and library cache.", color = SleekTextSecondary) },
            confirmButton = {
                TextButton(
                    onClick = {
                        showDeleteConfirmDialog = false
                        onDeleteClick()
                    }
                ) {
                    Text("DELETE", color = CrimsonFailure, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirmDialog = false }) {
                    Text("CANCEL", color = SleekTextSecondary, fontWeight = FontWeight.Bold)
                }
            },
            containerColor = SleekCard,
            titleContentColor = SleekTextPrimary,
            textContentColor = SleekTextSecondary
        )
    }
}

@Composable
fun SmoothToggle(
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    val offset by animateFloatAsState(
        targetValue = if (checked) 24f else 4f,
        animationSpec = tween(durationMillis = 250),
        label = "toggle_offset"
    )
    
    val trackColor = if (checked) SleekPurpleDark else SleekCardDark.copy(alpha = 0.5f)
    val thumbColor = if (checked) SleekBg else SleekTextSecondary.copy(alpha = 0.7f)

    Box(
        modifier = modifier
            .size(width = 50.dp, height = 28.dp)
            .clip(RoundedCornerShape(50))
            .background(trackColor)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null
            ) {
                onCheckedChange(!checked)
            }
    ) {
        Box(
            modifier = Modifier
                .offset(x = offset.dp)
                .align(Alignment.CenterStart)
                .size(20.dp)
                .clip(CircleShape)
                .background(thumbColor)
        )
    }
}

@Composable
fun SettingsTab(
    downloads: List<com.example.data.DownloadEntity>,
    onClearAllDownloads: () -> Unit,
    viewModel: VideoDownloaderViewModel
) {
    val context = LocalContext.current
    var showConfirmClear by remember { mutableStateOf(false) }
    var wifiOnly by remember { mutableStateOf(true) }
    var backgroundDownloads by remember { mutableStateOf(true) }
    var autoConvertAudio by remember { mutableStateOf(false) }

    val downloadCount = downloads.size
    val totalBytes = downloads.sumOf { it.fileSize }
    val totalMb = totalBytes / (1024.0 * 1024.0)
    val sizeFormatted = if (totalMb > 1024) String.format(java.util.Locale.US, "%.2f GB", totalMb / 1024.0) else String.format(java.util.Locale.US, "%.1f MB", totalMb)

    val customCommandInput by viewModel.customCommandInput.collectAsStateWithLifecycle()
    val ytdlpVerificationStatus by viewModel.ytdlpVerificationStatus.collectAsStateWithLifecycle()
    val isYtdlpLoading by viewModel.isYtdlpLoading.collectAsStateWithLifecycle()
    val usePublicDownloads by viewModel.usePublicDownloads.collectAsStateWithLifecycle()
    val defaultDownloadQuality by viewModel.defaultDownloadQuality.collectAsStateWithLifecycle()

    if (showConfirmClear) {
        AlertDialog(
            onDismissRequest = { showConfirmClear = false },
            title = { Text("Delete Library & Files?", fontWeight = FontWeight.Bold, color = SleekTextPrimary) },
            text = { Text("This will permanently delete all $downloadCount downloaded videos and media from your device memory. This action cannot be undone.", color = SleekTextSecondary) },
            confirmButton = {
                TextButton(
                    onClick = {
                        showConfirmClear = false
                        onClearAllDownloads()
                    }
                ) {
                    Text("DELETE ALL", color = CrimsonFailure, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showConfirmClear = false }) {
                    Text("CANCEL", color = SleekTextSecondary, fontWeight = FontWeight.Bold)
                }
            },
            containerColor = SleekCard,
            titleContentColor = SleekTextPrimary,
            textContentColor = SleekTextSecondary,
            shape = RoundedCornerShape(24.dp)
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 24.dp, vertical = 20.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(24.dp)
    ) {
        // Preferences Block
        Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Text("PREFERENCES", style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold, color = SleekPurpleDark))
            
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f).padding(end = 16.dp)) {
                    Text("Download over Wi-Fi only", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold), color = SleekTextPrimary)
                    Text("Pause downloads on cellular data", style = MaterialTheme.typography.bodyMedium, color = SleekTextSecondary)
                }
                SmoothToggle(
                    checked = wifiOnly,
                    onCheckedChange = { wifiOnly = it }
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f).padding(end = 16.dp)) {
                    Text("Background downloads", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold), color = SleekTextPrimary)
                    Text("Continue downloading when app is closed", style = MaterialTheme.typography.bodyMedium, color = SleekTextSecondary)
                }
                SmoothToggle(
                    checked = backgroundDownloads,
                    onCheckedChange = { backgroundDownloads = it }
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f).padding(end = 16.dp)) {
                    Text("Save as Audio by Default", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold), color = SleekTextPrimary)
                    Text("Always extract MP3 format if available", style = MaterialTheme.typography.bodyMedium, color = SleekTextSecondary)
                }
                SmoothToggle(
                    checked = autoConvertAudio,
                    onCheckedChange = { autoConvertAudio = it }
                )
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f).padding(end = 16.dp)) {
                    Text("Save to Public Downloads", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold), color = SleekTextPrimary)
                    Text("Store files in main Downloads folder", style = MaterialTheme.typography.bodyMedium, color = SleekTextSecondary)
                }
                SmoothToggle(
                    checked = usePublicDownloads,
                    onCheckedChange = { viewModel.updateUsePublicDownloads(it) }
                )
            }

            var qualityExpanded by remember { mutableStateOf(false) }
            val options = listOf("Ask Every Time", "Audio Only", "1080p", "720p", "480p", "360p", "144p")

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f).padding(end = 16.dp)) {
                    Text("Default Download Quality", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold), color = SleekTextPrimary)
                    Text("Automatically skip format selection if available", style = MaterialTheme.typography.bodyMedium, color = SleekTextSecondary)
                }
                Box {
                    TextButton(
                        onClick = { qualityExpanded = true },
                        colors = ButtonDefaults.textButtonColors(contentColor = SleekPurpleLight)
                    ) {
                        Text(defaultDownloadQuality, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.width(4.dp))
                        Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                    }
                    DropdownMenu(
                        expanded = qualityExpanded,
                        onDismissRequest = { qualityExpanded = false },
                        modifier = Modifier.background(SleekCardDark)
                    ) {
                        options.forEach { selectionOption ->
                            DropdownMenuItem(
                                text = { Text(selectionOption, color = SleekTextPrimary) },
                                onClick = {
                                    viewModel.updateDefaultDownloadQuality(selectionOption)
                                    qualityExpanded = false
                                }
                            )
                        }
                    }
                }
            }
        }

        HorizontalDivider(color = SleekBorderColor.copy(alpha = 0.4f))

        // Storage location block
        Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            Text("STORAGE PATH", style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold, color = SleekPurpleDark))
            Text(
                if (usePublicDownloads) "Files are saved to your public folder:\nInternal Storage/Download/"
                else "Files are saved privately to guarantee playback security:\nInternal Storage/Android/data/\ncom.example/files/Movies/",
                style = MaterialTheme.typography.bodyMedium.copy(fontFamily = FontFamily.Monospace),
                color = SleekTextSecondary
            )
        }

        HorizontalDivider(color = SleekBorderColor.copy(alpha = 0.4f))

        // Storage Analyzer Block
        Card(
            colors = CardDefaults.cardColors(containerColor = SleekCard),
            shape = RoundedCornerShape(24.dp),
            border = BorderStroke(1.dp, SleekBorderColor.copy(alpha = 0.5f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    text = "STORAGE ANALYZER",
                    style = MaterialTheme.typography.labelMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = SleekPurpleDark,
                        letterSpacing = 1.sp
                    )
                )

                Row(verticalAlignment = Alignment.Bottom) {
                    Text(
                        text = sizeFormatted,
                        style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Black),
                        color = SleekTextPrimary
                    )
                    Text(
                        text = " used by downloaded media",
                        style = MaterialTheme.typography.bodyMedium,
                        color = SleekTextSecondary,
                        modifier = Modifier.padding(bottom = 5.dp, start = 8.dp)
                    )
                }

                // Visualizer Bar
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .clip(RoundedCornerShape(50))
                        .background(SleekPurpleLight.copy(alpha = 0.2f))
                ) {
                    val targetProgress = if (downloads.isNotEmpty()) 1f else 0.05f
                    val animatedProgress by androidx.compose.animation.core.animateFloatAsState(
                        targetValue = targetProgress,
                        animationSpec = androidx.compose.animation.core.tween(1500)
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(animatedProgress)
                            .height(8.dp)
                            .background(
                                brush = androidx.compose.ui.graphics.Brush.horizontalGradient(
                                    colors = listOf(SleekPurpleDark, EmeraldSuccess)
                                )
                            )
                    )
                }
            }
        }

        HorizontalDivider(color = SleekBorderColor.copy(alpha = 0.4f))

        // Diagnostics
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text("LIBRARY ITEMS", style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold, color = SleekPurpleDark))
                Text("$downloadCount items cached offline", style = MaterialTheme.typography.bodyMedium, color = SleekTextSecondary)
            }
            if (downloadCount > 0) {
                Button(
                    onClick = { showConfirmClear = true },
                    colors = ButtonDefaults.buttonColors(containerColor = CrimsonFailure, contentColor = SleekBg),
                    shape = RoundedCornerShape(50),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                    modifier = Modifier.height(40.dp)
                ) {
                    Text("CLEAR ALL", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }
        }

        HorizontalDivider(color = SleekBorderColor.copy(alpha = 0.4f))

        // Custom CLI Runner Block
        Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            Text(
                "CUSTOM CLI TERMINAL RUNNER", 
                style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold, color = SleekPurpleDark)
            )
            OutlinedTextField(
                value = customCommandInput,
                onValueChange = { viewModel.updateCustomCommandInput(it) },
                placeholder = { Text("e.g. --version or --help", color = SleekTextSecondary.copy(alpha = 0.6f)) },
                leadingIcon = {
                    Text(
                        " ./engine ",
                        color = SleekPurpleDark,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(start = 12.dp)
                    )
                },
                textStyle = LocalTextStyle.current.copy(fontFamily = FontFamily.Monospace, fontSize = 13.sp),
                modifier = Modifier.fillMaxWidth().testTag("custom_command_input"),
                shape = RoundedCornerShape(12.dp),
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = SleekTextPrimary,
                    unfocusedTextColor = SleekTextPrimary,
                    focusedBorderColor = SleekPurpleDark,
                    unfocusedBorderColor = SleekBorderColor,
                    focusedContainerColor = SleekCardDark,
                    unfocusedContainerColor = SleekCardDark
                )
            )
            
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Button(
                    onClick = { viewModel.verifyYtdlp(context) },
                    colors = ButtonDefaults.buttonColors(containerColor = SleekCardDark, contentColor = SleekPurpleDark),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.weight(1f).testTag("verify_ytdlp_btn"),
                    enabled = !isYtdlpLoading,
                    border = BorderStroke(1.dp, SleekPurpleLight)
                ) {
                    Text("VERIFY", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
                
                Button(
                    onClick = { viewModel.executeCustomYtdlpCommand(context) },
                    colors = ButtonDefaults.buttonColors(containerColor = SleekPurpleDark, contentColor = SleekBg),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.weight(1f).testTag("run_custom_command_btn"),
                    enabled = !isYtdlpLoading
                ) {
                    Text("RUN", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }
            
            // Terminal Output
            if (ytdlpVerificationStatus.isNotEmpty()) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = SleekCardDark),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
                ) {
                    SelectionContainer {
                        Text(
                            text = ytdlpVerificationStatus,
                            color = EmeraldSuccess,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp,
                            modifier = Modifier.padding(12.dp).fillMaxWidth()
                        )
                    }
                }
            }
        }

        HorizontalDivider(color = SleekBorderColor.copy(alpha = 0.4f))

        // 🚀 LIVE CONSOLE LOGS TERMINAL
        Card(
            colors = CardDefaults.cardColors(containerColor = SleekCard),
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(1.dp, SleekPurpleDark.copy(alpha = 0.15f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            val executionLogs by viewModel.executionLogs.collectAsStateWithLifecycle()
            
            Column(
                modifier = Modifier.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .background(EmeraldSuccess, shape = CircleShape)
                        )
                        Text(
                            text = "LIVE CONSOLE LOGS",
                            color = SleekTextSecondary,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                letterSpacing = 0.5.sp
                            )
                        )
                    }
                    
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val clipboardManager = androidx.compose.ui.platform.LocalClipboardManager.current
                        val currentContext = androidx.compose.ui.platform.LocalContext.current
                        TextButton(
                            onClick = {
                                val logsText = executionLogs.joinToString("\n")
                                clipboardManager.setText(androidx.compose.ui.text.AnnotatedString(logsText))
                                android.widget.Toast.makeText(currentContext, "Logs copied!", android.widget.Toast.LENGTH_SHORT).show()
                            },
                            colors = ButtonDefaults.textButtonColors(contentColor = SleekPurpleDark),
                            modifier = Modifier.height(28.dp)
                        ) {
                            Text("COPY", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                        TextButton(
                            onClick = { viewModel.clearLogs() },
                            colors = ButtonDefaults.textButtonColors(contentColor = SleekPurpleDark),
                            modifier = Modifier.height(28.dp)
                        ) {
                            Text("CLEAR", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
                
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(220.dp)
                        .background(SleekCardDark, shape = RoundedCornerShape(8.dp))
                        .border(1.dp, SleekBorderColor, shape = RoundedCornerShape(8.dp))
                        .padding(10.dp)
                ) {
                    val scrollState = rememberLazyListState()
                    LaunchedEffect(executionLogs.size) {
                        if (executionLogs.isNotEmpty()) {
                            scrollState.animateScrollToItem(executionLogs.size - 1)
                        }
                    }
                    
                    LazyColumn(
                        state = scrollState,
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        items(executionLogs) { logLine ->
                            val logColor = when {
                                logLine.contains("❌") || logLine.contains("💀") -> CrimsonFailure
                                logLine.contains("✔") || logLine.contains("🎉") -> EmeraldSuccess
                                logLine.contains("⚠️") -> SleekPurpleLight
                                logLine.contains("📡") || logLine.contains("🎬") -> SleekPurpleLight
                                else -> SleekTextSecondary
                            }
                            Text(
                                text = logLine,
                                color = logColor,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 11.sp,
                                lineHeight = 15.sp
                            )
                        }
                    }
                }
            }
        }

        HorizontalDivider(color = SleekBorderColor.copy(alpha = 0.4f))

        // About block
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("ABOUT TUBESTREAM", style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold, color = SleekPurpleDark))
            Text(
                "TubeStream is a high-speed local downloader client powered by a robust media extraction engine. Segment extraction downloads stream parts simultaneously to maximize your bandwidth speed.",
                style = MaterialTheme.typography.bodyMedium,
                color = SleekTextSecondary
            )
        }
        
        Spacer(modifier = Modifier.height(32.dp))
    }
}

@OptIn(androidx.compose.ui.ExperimentalComposeUiApi::class)
@Composable
fun VideoPlayerDialog(
    download: DownloadEntity,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    var isBoosted by remember { mutableStateOf(false) }
    
    val exoPlayer = remember(download.localPath) {
        com.example.ui.PlayerHolder.initialize(context).apply {
            val mediaItem = androidx.media3.common.MediaItem.fromUri(Uri.fromFile(java.io.File(download.localPath)))
            setMediaItem(mediaItem)
            prepare()
            playWhenReady = true
            repeatMode = androidx.media3.common.Player.REPEAT_MODE_ONE
        }
    }
    
    val loudnessEnhancer = com.example.ui.PlayerHolder.loudnessEnhancer!!

    DisposableEffect(Unit) {
        val sessionToken = androidx.media3.session.SessionToken(context, android.content.ComponentName(context, com.example.PlaybackService::class.java))
        val controllerFuture = androidx.media3.session.MediaController.Builder(context, sessionToken).buildAsync()
        
        onDispose {
            androidx.media3.session.MediaController.releaseFuture(controllerFuture)
            com.example.ui.PlayerHolder.player?.stop()
            // Do not release the player, so PlaybackService can keep reusing it.
        }
    }

    var isPlaying by remember { mutableStateOf(exoPlayer.isPlaying) }
    var currentPosition by remember { mutableLongStateOf(0L) }
    var duration by remember { mutableLongStateOf(0L) }
    var showControls by remember { mutableStateOf(true) }

    DisposableEffect(exoPlayer) {
        val listener = object : androidx.media3.common.Player.Listener {
            override fun onIsPlayingChanged(isPlaying_: Boolean) {
                isPlaying = isPlaying_
            }
            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == androidx.media3.common.Player.STATE_READY) {
                    duration = exoPlayer.duration.coerceAtLeast(0L)
                }
            }
        }
        exoPlayer.addListener(listener)
        onDispose { exoPlayer.removeListener(listener) }
    }

    LaunchedEffect(isPlaying) {
        while (isPlaying) {
            currentPosition = exoPlayer.currentPosition.coerceAtLeast(0L)
            kotlinx.coroutines.delay(100)
        }
    }

    LaunchedEffect(showControls, isPlaying) {
        if (showControls && isPlaying) {
            kotlinx.coroutines.delay(3000)
            showControls = false
        }
    }

    androidx.compose.ui.window.Dialog(
        onDismissRequest = onDismiss,
        properties = androidx.compose.ui.window.DialogProperties(
            usePlatformDefaultWidth = false,
            decorFitsSystemWindows = false
        )
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black)
                .clickable(
                    interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() },
                    indication = null
                ) {
                    showControls = !showControls
                }
        ) {
            // Video Layer
            androidx.compose.ui.viewinterop.AndroidView(
                factory = { ctx ->
                    androidx.media3.ui.PlayerView(ctx).apply {
                        player = exoPlayer
                        useController = false
                        resizeMode = androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FIT
                    }
                },
                modifier = Modifier.fillMaxSize()
            )

            // Animated Controls Overlay
            androidx.compose.animation.AnimatedVisibility(
                visible = showControls,
                enter = androidx.compose.animation.fadeIn(),
                exit = androidx.compose.animation.fadeOut(),
                modifier = Modifier.fillMaxSize()
            ) {
                Box(modifier = Modifier.fillMaxSize()) {
                    // Top Bar (Liquid Glass)
                    Row(
                        modifier = Modifier
                            .align(Alignment.TopCenter)
                            .fillMaxWidth()
                            .padding(top = 48.dp, start = 16.dp, end = 16.dp)
                            .background(
                                Brush.linearGradient(
                                    colors = listOf(Color.White.copy(alpha = 0.15f), Color.White.copy(alpha = 0.05f))
                                ),
                                shape = RoundedCornerShape(24.dp)
                            )
                            .border(1.dp, Color.White.copy(alpha = 0.2f), RoundedCornerShape(24.dp))
                            .padding(horizontal = 8.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        IconButton(onClick = onDismiss) {
                            Icon(Icons.Default.KeyboardArrowDown, contentDescription = "Close", tint = Color.White)
                        }
                        Text(
                            text = download.title,
                            color = Color.White,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f).padding(horizontal = 8.dp)
                        )
                    }

                    // Center Play/Pause Button
                    Box(
                        modifier = Modifier
                            .align(Alignment.Center)
                            .size(80.dp)
                            .clip(androidx.compose.foundation.shape.CircleShape)
                            .background(
                                Brush.radialGradient(
                                    colors = listOf(Color.White.copy(alpha = 0.2f), Color.White.copy(alpha = 0.05f))
                                )
                            )
                            .border(1.dp, Color.White.copy(alpha = 0.3f), androidx.compose.foundation.shape.CircleShape)
                            .clickable {
                                if (isPlaying) exoPlayer.pause() else exoPlayer.play()
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        androidx.compose.animation.AnimatedContent(
                            targetState = isPlaying,
                            transitionSpec = { androidx.compose.animation.scaleIn() togetherWith androidx.compose.animation.scaleOut() }
                        ) { playing ->
                            if (playing) {
                                Icon(Icons.Default.Pause, contentDescription = "Pause", modifier = Modifier.size(40.dp), tint = Color.White)
                            } else {
                                Icon(Icons.Default.PlayArrow, contentDescription = "Play", modifier = Modifier.size(40.dp), tint = Color.White)
                            }
                        }
                    }

                    // Bottom Bar (Slider and Boost)
                    Column(
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .fillMaxWidth()
                            .padding(bottom = 32.dp, start = 16.dp, end = 16.dp)
                            .background(
                                Brush.linearGradient(
                                    colors = listOf(Color.White.copy(alpha = 0.15f), Color.White.copy(alpha = 0.05f))
                                ),
                                shape = RoundedCornerShape(24.dp)
                            )
                            .border(1.dp, Color.White.copy(alpha = 0.2f), RoundedCornerShape(24.dp))
                            .padding(horizontal = 16.dp, vertical = 12.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            val currentMin = currentPosition / 60000
                            val currentSec = (currentPosition % 60000) / 1000
                            Text(String.format(java.util.Locale.US, "%02d:%02d", currentMin, currentSec), color = Color.White)
                            
                            Slider(
                                value = if (duration > 0) currentPosition.toFloat() else 0f,
                                onValueChange = { currentPosition = it.toLong(); exoPlayer.seekTo(currentPosition) },
                                valueRange = 0f..(if (duration > 0) duration.toFloat() else 1f),
                                modifier = Modifier.weight(1f).padding(horizontal = 12.dp),
                                colors = SliderDefaults.colors(
                                    thumbColor = Color.White,
                                    activeTrackColor = EmeraldSuccess,
                                    inactiveTrackColor = Color.White.copy(alpha = 0.3f)
                                )
                            )
                            
                            val durMin = duration / 60000
                            val durSec = (duration % 60000) / 1000
                            Text(String.format(java.util.Locale.US, "%02d:%02d", durMin, durSec), color = Color.White)
                        }
                        
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            FilterChip(
                                selected = isBoosted,
                                onClick = { 
                                    isBoosted = !isBoosted
                                    loudnessEnhancer.enabled = isBoosted
                                },
                                label = { Text("Volume Boost +20dB", color = if (isBoosted) Color.Black else Color.White, fontWeight = FontWeight.Bold) },
                                leadingIcon = { 
                                    Icon(
                                        Icons.Default.KeyboardArrowUp, 
                                        contentDescription = "Boost",
                                        tint = if (isBoosted) Color.Black else EmeraldSuccess
                                    ) 
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = EmeraldSuccess,
                                    selectedLabelColor = Color.Black,
                                    containerColor = Color.Transparent,
                                    labelColor = Color.White
                                ),
                                border = FilterChipDefaults.filterChipBorder(
                                    borderColor = if (isBoosted) Color.Transparent else EmeraldSuccess,
                                    enabled = true,
                                    selected = isBoosted
                                ),
                                shape = RoundedCornerShape(50)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun YtdlpTab(
    viewModel: VideoDownloaderViewModel
) {
    val context = LocalContext.current
    
    val ytdlpLocalVersion by viewModel.ytdlpLocalVersion.collectAsStateWithLifecycle()
    val ytdlpOnlineVersion by viewModel.ytdlpOnlineVersion.collectAsStateWithLifecycle()
    val ytdlpVerificationStatus by viewModel.ytdlpVerificationStatus.collectAsStateWithLifecycle()
    val isYtdlpLoading by viewModel.isYtdlpLoading.collectAsStateWithLifecycle()
    val ytdlpProgress by viewModel.ytdlpProgress.collectAsStateWithLifecycle()

    // Setup Document Picker for raw uploads
    val systemUploadLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let {
            try {
                context.contentResolver.openInputStream(it)?.use { inputStream ->
                    val bytes = inputStream.readBytes()
                    viewModel.uploadYtdlpBytes(bytes, context)
                }
            } catch (e: Exception) {
                Log.e("YtdlpTab", "Failed to upload file stream bytes.", e)
            }
        }
    }

    // Auto-run verification on compose startup so they immediately see status
    LaunchedEffect(Unit) {
        viewModel.verifyYtdlp(context)
        viewModel.fetchLatestYtdlpVersionOnline()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Explanatory Card
        Card(
            colors = CardDefaults.cardColors(containerColor = SleekCard),
            shape = RoundedCornerShape(24.dp),
            border = BorderStroke(1.dp, SleekBorderColor.copy(alpha = 0.5f)),
            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = null,
                        tint = SleekPurpleDark
                    )
                    Text(
                        text = "Core Engine Controller",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = SleekPurpleDark
                        )
                    )
                }
                Text(
                    text = "Manage and verify the core downloader engine executable in the local sandboxed application environment.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = SleekTextSecondary
                )
            }
        }

        // Diagnostics Card
        Card(
            colors = CardDefaults.cardColors(containerColor = SleekCard),
            shape = RoundedCornerShape(24.dp),
            border = BorderStroke(1.dp, SleekBorderColor.copy(alpha = 0.5f)),
            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    text = "ENGINE DIAGNOSTICS",
                    style = MaterialTheme.typography.labelMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = SleekPurpleDark,
                        letterSpacing = 1.sp
                    )
                )

                // Online/Offline version rows
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Default GitHub Release", style = MaterialTheme.typography.titleSmall, color = SleekTextPrimary)
                        Text(ytdlpOnlineVersion, style = MaterialTheme.typography.bodyMedium, color = SleekTextSecondary)
                    }
                    Button(
                        onClick = { viewModel.fetchLatestYtdlpVersionOnline() },
                        colors = ButtonDefaults.buttonColors(containerColor = SleekPurpleDark, contentColor = SleekBg),
                        shape = RoundedCornerShape(50)
                    ) {
                        Text("CHECK", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }

                HorizontalDivider(color = SleekBorderColor.copy(alpha = 0.2f))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Local Installed Version", style = MaterialTheme.typography.titleSmall, color = SleekTextPrimary)
                        Text(ytdlpLocalVersion, style = MaterialTheme.typography.bodyMedium, color = SleekTextSecondary)
                    }
                    
                    val isPending = ytdlpLocalVersion.contains("Not") || ytdlpLocalVersion.isEmpty()
                    val hasUpdate = !isPending && 
                        ytdlpOnlineVersion.isNotEmpty() && 
                        !ytdlpOnlineVersion.contains("Checking") && 
                        !ytdlpOnlineVersion.contains("Error") && 
                        !ytdlpOnlineVersion.contains("Failed") &&
                        !ytdlpLocalVersion.contains(ytdlpOnlineVersion)

                    Box(
                        modifier = Modifier
                            .background(
                                color = if (isPending) SleekPurpleLight.copy(alpha = 0.1f) else if (hasUpdate) SleekPurpleLight.copy(alpha = 0.25f) else SleekPurpleLight.copy(alpha = 0.1f),
                                shape = RoundedCornerShape(12.dp)
                            )
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = if (isPending) "PENDING" else if (hasUpdate) "UPDATE AVAILABLE" else "UP TO DATE",
                            color = if (isPending) SleekTextMuted else if (hasUpdate) SleekPurpleDark else SleekTextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        )
                    }
                }
            }
        }

        // Action Panel Card
        Card(
            colors = CardDefaults.cardColors(containerColor = SleekCard),
            shape = RoundedCornerShape(24.dp),
            border = BorderStroke(1.dp, SleekBorderColor.copy(alpha = 0.5f)),
            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    text = "CONTROLS & COMPILING",
                    style = MaterialTheme.typography.labelMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = SleekPurpleDark,
                        letterSpacing = 1.sp
                    )
                )

                if (isYtdlpLoading) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        LinearProgressIndicator(
                            progress = { ytdlpProgress },
                            modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
                            color = SleekPurpleDark,
                            trackColor = SleekPurpleLight.copy(alpha = 0.3f)
                        )
                        Text(
                            text = String.format(Locale.getDefault(), "Processing: %.1f%%", ytdlpProgress * 100),
                            style = MaterialTheme.typography.bodySmall,
                            color = SleekTextSecondary
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Button(
                        onClick = { viewModel.updateYtdlpBinaries(context) },
                        colors = ButtonDefaults.buttonColors(containerColor = SleekPurpleDark),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.weight(1f).testTag("update_ytdlp_btn"),
                        enabled = !isYtdlpLoading
                    ) {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                            Text("UPDATE", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Button(
                        onClick = { systemUploadLauncher.launch("*/*") },
                        colors = ButtonDefaults.buttonColors(containerColor = SleekPurpleDark),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.weight(1f).testTag("upload_ytdlp_btn"),
                        enabled = !isYtdlpLoading
                    ) {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                            Text("UPLOAD", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Button(
                    onClick = { viewModel.verifyYtdlp(context) },
                    colors = ButtonDefaults.buttonColors(containerColor = SleekCardDark, contentColor = SleekPurpleDark),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth().testTag("verify_ytdlp_btn"),
                    enabled = !isYtdlpLoading,
                    border = BorderStroke(1.dp, SleekPurpleLight)
                ) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Check, contentDescription = null)
                        Text("VERIFY & TEST ENVIRONMENT", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }

                // Dynamic Adaptive Pipeline Diagnostics Hud Panel
                val report = remember(context) { YtdlpPipelineManager.runDiagnostics(context) }
                Card(
                    colors = CardDefaults.cardColors(containerColor = SleekPurpleLight.copy(alpha = 0.08f)),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth(),
                    border = BorderStroke(1.dp, SleekPurpleLight.copy(alpha = 0.2f))
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = "ACTIVE PIPELINE STATE",
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = SleekPurpleDark,
                                letterSpacing = 1.sp
                            )
                        )
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Selected Route:", style = MaterialTheme.typography.bodyMedium, color = SleekTextSecondary)
                            Box(
                                modifier = Modifier
                                    .background(SleekPurpleDark, shape = RoundedCornerShape(8.dp))
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = report.activeBackend.displayName.replace("Fallback 2: ", "").replace("Fallback 3: ", "").replace("Final Bypass: ", ""),
                                    color = SleekBg,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                        
                        HorizontalDivider(color = SleekBorderColor.copy(alpha = 0.15f))
                        
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("CPU / Architecture:", style = MaterialTheme.typography.bodySmall, color = SleekTextSecondary)
                            Text(report.systemArchitecture.split("[").first().trim(), style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold), color = SleekTextPrimary)
                        }
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Android OS Constraints:", style = MaterialTheme.typography.bodySmall, color = SleekTextSecondary)
                            Text("API ${report.sdkInt} (Android ${report.releaseVersion})", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold), color = SleekTextPrimary)
                        }
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("SELinux / W^X restriction:", style = MaterialTheme.typography.bodySmall, color = SleekTextSecondary)
                            Text(
                                text = if (report.wExRestricted) "ELIMINATED VIA FAILSURGE" else "NONE",
                                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                                color = if (report.wExRestricted) CrimsonFailure else EmeraldSuccess
                            )
                        }
                    }
                }

                HorizontalDivider(color = SleekBorderColor.copy(alpha = 0.2f))

                val customCommandInput by viewModel.customCommandInput.collectAsStateWithLifecycle()

                Column(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "CUSTOM CLI TERMINAL RUNNER",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = SleekPurpleDark,
                            letterSpacing = 1.sp
                        )
                    )
                    OutlinedTextField(
                        value = customCommandInput,
                        onValueChange = { viewModel.updateCustomCommandInput(it) },
                        placeholder = { Text("e.g. --version or --help", color = SleekTextSecondary.copy(alpha = 0.6f)) },
                        leadingIcon = {
                            Text(
                                " ./engine ",
                                color = SleekPurpleDark,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(start = 12.dp)
                            )
                        },
                        textStyle = LocalTextStyle.current.copy(fontFamily = FontFamily.Monospace, fontSize = 13.sp),
                        modifier = Modifier.fillMaxWidth().testTag("custom_command_input"),
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = SleekTextPrimary,
                            unfocusedTextColor = SleekTextPrimary,
                            focusedBorderColor = SleekPurpleDark,
                            unfocusedBorderColor = SleekBorderColor,
                            focusedContainerColor = SleekCardDark,
                            unfocusedContainerColor = SleekCardDark
                        )
                    )
                    Button(
                        onClick = { viewModel.executeCustomYtdlpCommand(context) },
                        colors = ButtonDefaults.buttonColors(containerColor = SleekPurpleDark, contentColor = SleekBg),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth().testTag("run_custom_command_btn"),
                        enabled = !isYtdlpLoading
                    ) {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                            Text("RUN CUSTOM COMMAND", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                }
            }
        }

        // Terminal Console Logs output block
        Card(
            colors = CardDefaults.cardColors(containerColor = SleekCardDark),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "CONSOLE STDOUT / VERIFICATION OUTPUT",
                        color = SleekTextSecondary,
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    )
                    Box(
                        modifier = Modifier
                            .background(SleekPurpleLight, shape = RoundedCornerShape(4.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "terminal",
                            color = EmeraldSuccess,
                            fontSize = 8.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
                
                SelectionContainer {
                    Text(
                        text = ytdlpVerificationStatus,
                        color = SleekTextSecondary,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                    )
                }
            }
        }
    }
}

enum class FloatingWidgetState {
    COLLAPSED,
    URL_INPUT,
    SHOW_RESULT
}

@Composable
fun FloatingSearchWidget(
    viewModel: VideoDownloaderViewModel,
    onClose: () -> Unit
) {
    val clipboardManager = LocalClipboardManager.current
    val context = LocalContext.current
    
    val isAnalyzing by viewModel.isAnalyzing.collectAsStateWithLifecycle()
    val analyzedVideo by viewModel.analyzedVideo.collectAsStateWithLifecycle()
    val activeDownloads by viewModel.activeDownloads.collectAsStateWithLifecycle()
    
    var widgetState by remember { mutableStateOf(FloatingWidgetState.COLLAPSED) }
    var enteredUrl by remember { mutableStateOf("") }
    
    var lastIsAnalyzing by remember { mutableStateOf(false) }
    LaunchedEffect(isAnalyzing) {
        if (lastIsAnalyzing && !isAnalyzing) {
            if (analyzedVideo != null) {
                widgetState = FloatingWidgetState.SHOW_RESULT
            }
        }
        if (isAnalyzing) {
            widgetState = FloatingWidgetState.COLLAPSED
        }
        lastIsAnalyzing = isAnalyzing
    }
    
    val activeTasksCount = activeDownloads.size
    var lastActiveTasksCount by remember { mutableStateOf(0) }
    LaunchedEffect(activeDownloads) {
        if (activeDownloads.size > lastActiveTasksCount) {
            if (widgetState == FloatingWidgetState.SHOW_RESULT) {
                widgetState = FloatingWidgetState.COLLAPSED
            }
        }
        lastActiveTasksCount = activeDownloads.size
    }

    val activeTask = activeDownloads.values.firstOrNull {
        it.status == DownloadStatus.DOWNLOADING || it.status == DownloadStatus.PENDING
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val maxWidthPx = constraints.maxWidth.toFloat()
        val maxHeightPx = constraints.maxHeight.toFloat()
        
        var isPosInitialized by remember { mutableStateOf(false) }
        var offsetX by remember { mutableStateOf(0f) }
        var offsetY by remember { mutableStateOf(0f) }
        
        if (!isPosInitialized && maxWidthPx > 0) {
            offsetX = maxWidthPx * 0.15f
            offsetY = maxHeightPx * 0.6f
            isPosInitialized = true
        }
        
        val cardWidth by animateDpAsState(
            targetValue = when (widgetState) {
                FloatingWidgetState.COLLAPSED -> 64.dp
                FloatingWidgetState.URL_INPUT -> 280.dp
                FloatingWidgetState.SHOW_RESULT -> 300.dp
            },
            animationSpec = spring(dampingRatio = Spring.DampingRatioLowBouncy, stiffness = Spring.StiffnessMedium),
            label = "width"
        )
        
        val cardHeight by animateDpAsState(
            targetValue = when (widgetState) {
                FloatingWidgetState.COLLAPSED -> 64.dp
                FloatingWidgetState.URL_INPUT -> 140.dp
                FloatingWidgetState.SHOW_RESULT -> 200.dp
            },
            animationSpec = spring(dampingRatio = Spring.DampingRatioLowBouncy, stiffness = Spring.StiffnessMedium),
            label = "height"
        )

        Card(
            modifier = Modifier
                .offset { IntOffset(offsetX.roundToInt(), offsetY.roundToInt()) }
                .size(width = cardWidth, height = cardHeight)
                .pointerInput(Unit) {
                    detectDragGestures { change, dragAmount ->
                        change.consume()
                        offsetX = (offsetX + dragAmount.x).coerceIn(0f, maxOf(0f, maxWidthPx - 100f))
                        offsetY = (offsetY + dragAmount.y).coerceIn(0f, maxOf(0f, maxHeightPx - 150f))
                    }
                }
                .shadow(elevation = 12.dp, shape = RoundedCornerShape(18.dp))
                .border(1.dp, SleekBorderColor, RoundedCornerShape(18.dp)),
            colors = CardDefaults.cardColors(containerColor = SleekCard),
            shape = RoundedCornerShape(18.dp)
        ) {
            AnimatedContent(
                targetState = widgetState,
                transitionSpec = {
                    fadeIn(animationSpec = tween(150)) togetherWith fadeOut(animationSpec = tween(150))
                },
                modifier = Modifier.fillMaxSize(),
                label = "widget_anim"
            ) { state ->
                when (state) {
                    FloatingWidgetState.COLLAPSED -> {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .clickable {
                                    widgetState = FloatingWidgetState.URL_INPUT
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            if (activeTask != null) {
                                Box(contentAlignment = Alignment.Center, modifier = Modifier.size(52.dp)) {
                                    CircularProgressIndicator(
                                        progress = { activeTask.progress },
                                        color = Color.White,
                                        strokeWidth = 3.dp,
                                        modifier = Modifier.fillMaxSize()
                                    )
                                    Text(
                                        text = "${(activeTask.progress * 100).roundToInt()}%",
                                        color = Color.White,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            } else if (isAnalyzing) {
                                CircularProgressIndicator(
                                    color = Color.White,
                                    strokeWidth = 3.dp,
                                    modifier = Modifier.size(28.dp)
                                )
                            } else {
                                Icon(
                                    imageVector = Icons.Default.Search,
                                    contentDescription = "Search Floating",
                                    tint = Color.White,
                                    modifier = Modifier.size(28.dp)
                                )
                            }
                        }
                    }
                    FloatingWidgetState.URL_INPUT -> {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(12.dp),
                            verticalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "QUICK SEARCH",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = SleekTextSecondary
                                    )
                                )
                                IconButton(
                                    onClick = { 
                                        onClose()
                                    },
                                    modifier = Modifier.size(24.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Close,
                                        contentDescription = "Close",
                                        tint = SleekTextMuted,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                            
                            OutlinedTextField(
                                value = enteredUrl,
                                onValueChange = { enteredUrl = it },
                                placeholder = {
                                    Text("Paste/type URL...", color = SleekTextMuted, fontSize = 11.sp)
                                },
                                textStyle = MaterialTheme.typography.bodySmall.copy(color = Color.White),
                                maxLines = 1,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp),
                                shape = RoundedCornerShape(8.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = Color.White,
                                    unfocusedBorderColor = SleekBorderColor,
                                    focusedContainerColor = SleekCardDark,
                                    unfocusedContainerColor = SleekCardDark
                                ),
                                trailingIcon = {
                                    IconButton(
                                        onClick = {
                                            clipboardManager.getText()?.text?.let { enteredUrl = it }
                                        },
                                        modifier = Modifier.size(24.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.ContentPaste,
                                            contentDescription = "Paste",
                                            tint = Color.White,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                            )

                            Button(
                                onClick = {
                                    if (enteredUrl.isNotBlank()) {
                                        viewModel.updateUrlInput(enteredUrl)
                                        viewModel.analyzeVideo()
                                    }
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(32.dp),
                                shape = RoundedCornerShape(6.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = Color.White,
                                    contentColor = Color.Black
                                ),
                                contentPadding = PaddingValues(0.dp)
                            ) {
                                Text("Inspect Link", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                    FloatingWidgetState.SHOW_RESULT -> {
                        val video = analyzedVideo
                        if (video != null) {
                            Column(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(12.dp),
                                verticalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "READY",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = EmeraldSuccess
                                        )
                                    )
                                    IconButton(
                                        onClick = { 
                                            onClose()
                                        },
                                        modifier = Modifier.size(24.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Close,
                                            contentDescription = "Close",
                                            tint = SleekTextMuted,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    AsyncImage(
                                        model = video.thumbnailUrl,
                                        contentDescription = null,
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier
                                            .size(width = 56.dp, height = 42.dp)
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(SleekCardDark)
                                    )
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = video.title,
                                            color = Color.White,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Text(
                                            text = video.author,
                                            color = SleekTextSecondary,
                                            fontSize = 9.sp,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                }

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    val videoFormat = video.formats.firstOrNull { it.type == "combined" } 
                                        ?: video.formats.firstOrNull { it.type == "video_only" }
                                    
                                    val audioFormat = video.formats.firstOrNull { it.type == "audio" }

                                    if (videoFormat != null) {
                                        Button(
                                            onClick = {
                                                viewModel.startDownload(video, videoFormat)
                                            },
                                            modifier = Modifier
                                                .weight(1f)
                                                .height(34.dp),
                                            shape = RoundedCornerShape(8.dp),
                                            colors = ButtonDefaults.buttonColors(
                                                containerColor = Color.White,
                                                contentColor = Color.Black
                                            ),
                                            contentPadding = PaddingValues(horizontal = 4.dp)
                                        ) {
                                            Text(
                                                text = "Video (${videoFormat.quality})",
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }
                                    }

                                    if (audioFormat != null) {
                                        Button(
                                            onClick = {
                                                viewModel.startDownload(video, audioFormat)
                                            },
                                            modifier = Modifier
                                                .weight(1.0f)
                                                .height(34.dp),
                                            shape = RoundedCornerShape(8.dp),
                                            colors = ButtonDefaults.buttonColors(
                                                containerColor = SleekPurpleContainer,
                                                contentColor = Color.White
                                            ),
                                            contentPadding = PaddingValues(horizontal = 4.dp),
                                            border = BorderStroke(1.dp, SleekBorderColor)
                                        ) {
                                            Text(
                                                text = "Audio",
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }
                                    }
                                }
                            }
                        } else {
                            Box(
                                modifier = Modifier.fillMaxSize(),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("No video loaded", color = SleekTextMuted, fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AudioPlayerDialog(
    download: DownloadEntity,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    var isBoosted by remember { mutableStateOf(false) }
    var currentSpeed by remember { mutableFloatStateOf(1.0f) }
    
    val exoPlayer = remember(download.localPath) {
        com.example.ui.PlayerHolder.initialize(context).apply {
            val mediaItem = androidx.media3.common.MediaItem.fromUri(Uri.fromFile(java.io.File(download.localPath)))
            setMediaItem(mediaItem)
            prepare()
            playWhenReady = true
            repeatMode = androidx.media3.common.Player.REPEAT_MODE_ONE
        }
    }
    
    val loudnessEnhancer = com.example.ui.PlayerHolder.loudnessEnhancer!!

    DisposableEffect(Unit) {
        val sessionToken = androidx.media3.session.SessionToken(context, android.content.ComponentName(context, com.example.PlaybackService::class.java))
        val controllerFuture = androidx.media3.session.MediaController.Builder(context, sessionToken).buildAsync()
        
        onDispose {
            androidx.media3.session.MediaController.releaseFuture(controllerFuture)
            com.example.ui.PlayerHolder.player?.stop()
        }
    }

    var isPlaying by remember { mutableStateOf(exoPlayer.isPlaying) }
    var currentPosition by remember { mutableLongStateOf(0L) }
    var duration by remember { mutableLongStateOf(0L) }

    DisposableEffect(exoPlayer) {
        val listener = object : androidx.media3.common.Player.Listener {
            override fun onIsPlayingChanged(isPlaying_: Boolean) {
                isPlaying = isPlaying_
            }
            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == androidx.media3.common.Player.STATE_READY) {
                    duration = exoPlayer.duration.coerceAtLeast(0L)
                }
            }
        }
        exoPlayer.addListener(listener)
        // Sync initial state
        isPlaying = exoPlayer.isPlaying
        if (exoPlayer.playbackState == androidx.media3.common.Player.STATE_READY) {
            duration = exoPlayer.duration.coerceAtLeast(0L)
        }
        onDispose { exoPlayer.removeListener(listener) }
    }

    // Set speed on startup or parameter change
    LaunchedEffect(currentSpeed, exoPlayer) {
        try {
            exoPlayer.setPlaybackSpeed(currentSpeed)
        } catch (e: Exception) {
            try {
                exoPlayer.playbackParameters = androidx.media3.common.PlaybackParameters(currentSpeed)
            } catch (ex: Exception) {}
        }
    }

    // Track position progress updates
    LaunchedEffect(isPlaying) {
        if (isPlaying) {
            while (true) {
                currentPosition = exoPlayer.currentPosition.coerceAtLeast(0L)
                kotlinx.coroutines.delay(100)
            }
        }
    }

    // Gentle rotation counter for the vinyl
    var currentAngle by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(isPlaying) {
        if (isPlaying) {
            while (true) {
                currentAngle = (currentAngle + 1.2f) % 360f
                kotlinx.coroutines.delay(16) // ~60fps
            }
        }
    }

    // Animated bar height states for audio visualizer spectrum
    val visualizerHeights = remember { List(16) { mutableStateOf(4f) } }
    LaunchedEffect(isPlaying) {
        if (isPlaying) {
            while (true) {
                for (i in visualizerHeights.indices) {
                    // Random fluctuation between 6dp and 48dp for lively visual impact
                    visualizerHeights[i].value = (6..48).random().toFloat()
                }
                kotlinx.coroutines.delay(100)
            }
        } else {
            for (i in visualizerHeights.indices) {
                visualizerHeights[i].value = 4f
            }
        }
    }

    androidx.compose.ui.window.Dialog(
        onDismissRequest = onDismiss,
        properties = androidx.compose.ui.window.DialogProperties(
            usePlatformDefaultWidth = false,
            decorFitsSystemWindows = false
        )
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            Color(0xFF0F0F12), // Deep velvet black-grey
                            Color(0xFF020202)  // Infinite pure pitch black
                        )
                    )
                )
        ) {
            // Elegant background ambient glows
            Box(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .fillMaxWidth()
                    .height(300.dp)
                    .background(
                        Brush.radialGradient(
                            colors = listOf(
                                Color.White.copy(alpha = 0.04f),
                                Color.Transparent
                            )
                        )
                    )
            )

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 24.dp)
                    .navigationBarsPadding()
                    .statusBarsPadding(),
                verticalArrangement = Arrangement.SpaceBetween,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // 1. Top Bar Navigation
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .background(Color.White.copy(alpha = 0.05f), CircleShape)
                            .border(1.dp, Color.White.copy(alpha = 0.1f), CircleShape)
                    ) {
                        Icon(
                            imageVector = Icons.Default.KeyboardArrowDown,
                            contentDescription = "Collapse Player",
                            tint = Color.White
                        )
                    }

                    Text(
                        text = "NOW PLAYING",
                        color = Color.White.copy(alpha = 0.6f),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 2.sp,
                        fontFamily = FontFamily.Monospace
                    )

                    IconButton(
                        onClick = {
                            isBoosted = !isBoosted
                            loudnessEnhancer.enabled = isBoosted
                        },
                        modifier = Modifier
                            .background(
                                if (isBoosted) Color.White else Color.White.copy(alpha = 0.05f),
                                CircleShape
                            )
                            .border(
                                1.dp,
                                if (isBoosted) Color.White else Color.White.copy(alpha = 0.1f),
                                CircleShape
                            )
                    ) {
                        Icon(
                            imageVector = Icons.Default.VolumeUp,
                            contentDescription = "Volume Boost",
                            tint = if (isBoosted) Color.Black else Color.White
                        )
                    }
                }

                // 2. Vinyl Rotating Record Player Block
                Box(
                    modifier = Modifier
                        .padding(vertical = 24.dp)
                        .size(260.dp)
                        .shadow(24.dp, CircleShape)
                        .background(Color(0xFF121214), CircleShape)
                        .border(6.dp, Color(0xFF1E1E22), CircleShape)
                        .graphicsLayer(rotationZ = currentAngle),
                    contentAlignment = Alignment.Center
                ) {
                    // Outer Vinyl Grooves (Drawn via Canvas)
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val stroke = 1.5f
                        val centerOffset = size.width / 2
                        // Simple elegant microgrooves on vinyl
                        drawCircle(
                            color = Color.Black.copy(alpha = 0.65f),
                            radius = centerOffset - 24f,
                            style = androidx.compose.ui.graphics.drawscope.Stroke(width = stroke)
                        )
                        drawCircle(
                            color = Color.Black.copy(alpha = 0.45f),
                            radius = centerOffset - 48f,
                            style = androidx.compose.ui.graphics.drawscope.Stroke(width = stroke)
                        )
                        drawCircle(
                            color = Color.Black.copy(alpha = 0.35f),
                            radius = centerOffset - 72f,
                            style = androidx.compose.ui.graphics.drawscope.Stroke(width = stroke)
                        )
                        drawCircle(
                            color = Color.Black.copy(alpha = 0.25f),
                            radius = centerOffset - 96f,
                            style = androidx.compose.ui.graphics.drawscope.Stroke(width = stroke)
                        )
                    }

                    // Rotating Inner Album Label Image
                    Box(
                        modifier = Modifier
                            .size(110.dp)
                            .clip(CircleShape)
                            .background(Color.DarkGray)
                            .border(3.dp, Color.Black, CircleShape)
                    ) {
                        AsyncImage(
                            model = download.thumbnailUrl,
                            contentDescription = "Album Thumbnail",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                        
                        // Centered spindle hole decoration
                        Box(
                            modifier = Modifier
                                .align(Alignment.Center)
                                .size(14.dp)
                                .background(Color.Black, CircleShape)
                                .border(1.5.dp, Color.White.copy(alpha = 0.6f), CircleShape)
                        )
                    }
                }

                // 3. Audio Metadata and Animated Wave Visualizer
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = download.title,
                        color = Color.White,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.fillMaxWidth()
                    )
                    
                    Spacer(modifier = Modifier.height(4.dp))
                    
                    Text(
                        text = if (download.author.isNotBlank()) download.author else "Local Audio File",
                        color = Color.White.copy(alpha = 0.5f),
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium,
                        textAlign = TextAlign.Center,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )

                    Spacer(modifier = Modifier.height(18.dp))

                    // Animated Visualizer Row (Breathes and fluctuates in rhythm)
                    Row(
                        modifier = Modifier
                            .height(52.dp)
                            .fillMaxWidth(0.8f),
                        horizontalArrangement = Arrangement.spacedBy(4.dp, Alignment.CenterHorizontally),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        visualizerHeights.forEach { heightState ->
                            val animatedHeight by animateDpAsState(
                                targetValue = heightState.value.dp,
                                animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
                                label = "bar_height"
                            )
                            Box(
                                modifier = Modifier
                                    .width(3.dp)
                                    .height(animatedHeight)
                                    .background(
                                        brush = Brush.verticalGradient(
                                            colors = listOf(Color.White, Color.White.copy(alpha = 0.2f))
                                        ),
                                        shape = RoundedCornerShape(50)
                                    )
                            )
                        }
                    }
                }

                // 4. Progress Control Panel (Slider, Speed chips and Timers)
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 12.dp)
                ) {
                    // Time indicators row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val currentMin = currentPosition / 60000
                        val currentSec = (currentPosition % 60000) / 1000
                        Text(
                            text = String.format(Locale.US, "%02d:%02d", currentMin, currentSec),
                            color = Color.White.copy(alpha = 0.6f),
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace
                        )

                        val durMin = duration / 60000
                        val durSec = (duration % 60000) / 1000
                        Text(
                            text = String.format(Locale.US, "%02d:%02d", durMin, durSec),
                            color = Color.White.copy(alpha = 0.6f),
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    // Sliding seek bar progress tracker
                    Slider(
                        value = if (duration > 0) currentPosition.toFloat() else 0f,
                        onValueChange = {
                            currentPosition = it.toLong()
                            exoPlayer.seekTo(currentPosition)
                        },
                        valueRange = 0f..(if (duration > 0) duration.toFloat() else 1f),
                        modifier = Modifier.fillMaxWidth(),
                        colors = SliderDefaults.colors(
                            thumbColor = Color.White,
                            activeTrackColor = Color.White,
                            inactiveTrackColor = Color.White.copy(alpha = 0.15f)
                        )
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Playback Speed Options Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val speeds = listOf(0.5f, 1.0f, 1.25f, 1.5f, 2.0f)
                        speeds.forEach { speed ->
                            val isSelected = currentSpeed == speed
                            Box(
                                modifier = Modifier
                                    .background(
                                        if (isSelected) Color.White else Color.White.copy(alpha = 0.05f),
                                        RoundedCornerShape(8.dp)
                                    )
                                    .border(
                                        1.dp,
                                        if (isSelected) Color.White else Color.White.copy(alpha = 0.1f),
                                        RoundedCornerShape(8.dp)
                                    )
                                    .clickable {
                                        currentSpeed = speed
                                    }
                                    .padding(horizontal = 10.dp, vertical = 4.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "${speed}x",
                                    color = if (isSelected) Color.Black else Color.White.copy(alpha = 0.7f),
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }

                // 5. Ultimate Playback Command Panel (Rewind, Play/Pause, Forward)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 32.dp),
                    horizontalArrangement = Arrangement.spacedBy(28.dp, Alignment.CenterHorizontally),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Rewind 10 Seconds
                    IconButton(
                        onClick = {
                            val target = (exoPlayer.currentPosition - 10000).coerceAtLeast(0L)
                            exoPlayer.seekTo(target)
                            currentPosition = target
                        },
                        modifier = Modifier
                            .size(52.dp)
                            .background(Color.White.copy(alpha = 0.05f), CircleShape)
                            .border(1.dp, Color.White.copy(alpha = 0.1f), CircleShape)
                    ) {
                        Icon(
                            imageVector = Icons.Default.FastRewind,
                            contentDescription = "Rewind 10 Seconds",
                            tint = Color.White,
                            modifier = Modifier.size(24.dp)
                        )
                    }

                    // Play / Pause glowing tactile circle
                    Box(
                        modifier = Modifier
                            .size(76.dp)
                            .shadow(8.dp, CircleShape)
                            .background(Color.White, CircleShape)
                            .clickable {
                                if (isPlaying) exoPlayer.pause() else exoPlayer.play()
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        AnimatedContent(
                            targetState = isPlaying,
                            transitionSpec = {
                                scaleIn() togetherWith scaleOut()
                            },
                            label = "play_pause_transition"
                        ) { playing ->
                            Icon(
                                imageVector = if (playing) Icons.Default.Pause else Icons.Default.PlayArrow,
                                contentDescription = if (playing) "Pause" else "Play",
                                tint = Color.Black,
                                modifier = Modifier.size(38.dp)
                            )
                        }
                    }

                    // Fast Forward 10 Seconds
                    IconButton(
                        onClick = {
                            val target = (exoPlayer.currentPosition + 10000).coerceAtMost(duration)
                            exoPlayer.seekTo(target)
                            currentPosition = target
                        },
                        modifier = Modifier
                            .size(52.dp)
                            .background(Color.White.copy(alpha = 0.05f), CircleShape)
                            .border(1.dp, Color.White.copy(alpha = 0.1f), CircleShape)
                    ) {
                        Icon(
                            imageVector = Icons.Default.FastForward,
                            contentDescription = "Forward 10 Seconds",
                            tint = Color.White,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }
            }
        }
    }
}
