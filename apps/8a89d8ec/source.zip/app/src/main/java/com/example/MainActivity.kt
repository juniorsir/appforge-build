package com.example

import android.app.StatusBarManager
import android.content.ComponentName
import android.content.Intent
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.ui.Modifier
import com.example.ui.VideoDownloaderScreen
import com.example.ui.VideoDownloaderViewModel
import com.example.ui.theme.MyApplicationTheme
import java.util.concurrent.Executors

class MainActivity : ComponentActivity() {
  
  private val viewModel: VideoDownloaderViewModel by viewModels()

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    handleIntent(intent)
    
    setContent {
      MyApplicationTheme {
        VideoDownloaderScreen(
            viewModel = viewModel,
            modifier = Modifier.fillMaxSize()
        )
      }
    }
  }

  override fun onNewIntent(intent: Intent) {
      super.onNewIntent(intent)
      handleIntent(intent)
  }

  private fun handleIntent(intent: Intent?) {
      if (intent?.getBooleanExtra("launch_floating_widget", false) == true) {
          viewModel.triggerFloatingWidget(true)
          intent.removeExtra("launch_floating_widget")
      }
      if (intent?.action == Intent.ACTION_SEND && intent.type == "text/plain") {
          val sharedText = intent.getStringExtra(Intent.EXTRA_TEXT)
          intent.action = Intent.ACTION_MAIN // consume intent
          if (sharedText != null) {
              val urlRegex = "(?i)\\b((?:https?://|www\\d{0,3}[.]|[a-z0-9.\\-]+[.][a-z]{2,4}/)(?:[^\\s()<>]+|\\(([^\\s()<>]+|(\\([^\\s()<>]+\\)))*\\))+(?:\\(([^\\s()<>]+|(\\([^\\s()<>]+\\)))*\\)|[^\\s`!()\\[\\]{};:'\".,<>?«»“”‘’]))".toRegex()
              val match = urlRegex.find(sharedText)
              if (match != null) {
                  val url = match.value
                  viewModel.updateUrlInput(url)
                  viewModel.analyzeVideo()
                  promptAddQuickTile()
              }
          }
      }
  }

  private fun promptAddQuickTile() {
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
          val statusBarManager = getSystemService(StatusBarManager::class.java)
          statusBarManager?.requestAddTileService(
              ComponentName(this, QuickTileService::class.java),
              "TubeStream",
              Icon.createWithResource(this, R.drawable.ic_launcher_foreground),
              Executors.newSingleThreadExecutor()
          ) { result ->
              // handle result
          }
      }
  }
}
