package com.example.ui

import android.content.Context
import androidx.media3.exoplayer.ExoPlayer
import android.media.audiofx.LoudnessEnhancer

object PlayerHolder {
    var player: ExoPlayer? = null
    var loudnessEnhancer: LoudnessEnhancer? = null

    fun initialize(context: Context): ExoPlayer {
        if (player == null) {
            player = ExoPlayer.Builder(context.applicationContext).build()
            loudnessEnhancer = LoudnessEnhancer(player!!.audioSessionId).apply {
                setTargetGain(2000) // +20dB boost
            }
        }
        return player!!
    }
}
