package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val KeyboardBackground = Color(0xFFFFF0F5) // Soft slate obsidian navy background
val KeyCaps = Color(0xFFFFFFFF) // Comfortable slate-navy containers
val KeyText = Color(0xFF261026) // High-contrast clean text
val AccentOrange = Color(0xFFE91E63) // Gorgeous neon cyber turquoise accent highlight

val SecondaryText = Color(0xFF705072) // Comfortable reading silver-slate
val SubduedCaps = Color(0xFFBA68C8) // Glowing subtle turquoise borders
