import sys
file_path = "/app/applet/app/src/main/java/com/example/media/playback/PlaybackFallbackEngine.kt"
with open(file_path, "r") as f:
    content = f.read()

target = """            PlaybackStrategy.UNSUPPORTED -> {
                throw IllegalStateException("Cannot execute fix for UNSUPPORTED strategy")
            }
        }
    }"""
replace = """            PlaybackStrategy.UNSUPPORTED -> {
                throw IllegalStateException("Cannot execute fix for UNSUPPORTED strategy")
            }
            else -> {
                throw IllegalStateException("Unhandled strategy: ${plan.strategy}")
            }
        }
    }"""

content = content.replace(target, replace)
with open(file_path, "w") as f:
    f.write(content)
