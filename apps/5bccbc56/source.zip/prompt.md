# Phase 17.33 — Background Smart Transcoding, Progressive Playback & Performance Hardening

## Objective

Make the existing fallback transcoding system significantly smarter and smoother.

Current behavior:

`unsupported source`
→ fallback required
→ FFmpeg transcodes
→ wait for full output
→ playback

Desired behavior:

`unsupported source`
→ start fallback transcoding in background
→ keep UI/player responsive
→ allow playback as soon as a sufficiently valid playable fallback is available
→ continue transcoding in background
→ user can inspect logs/progress if desired
→ automatically transition to the completed validated fallback when appropriate

The system must intelligently balance:

* playback responsiveness
* transcoding speed
* device resources
* storage
* player smoothness
* background execution
* cancellation
* request isolation
* output integrity

## CRITICAL UI CONSTRAINT

Do NOT redesign the UI.

Do NOT create a new screen.

Do NOT move existing controls.

Do NOT change colors, layout, typography, navigation, player appearance, or unrelated UI.

Do NOT add a new visible UI component unless the existing implementation already has a logical place for the existing Logs/transcoding status control.

The existing Logs button is currently not visible.

Fix only the underlying visibility/state/routing problem so the EXISTING Logs control becomes visible where it was already intended to exist.

The Logs control must remain optional:

* transcoding works without opening logs
* user does not need to watch transcoding
* tapping Logs reveals the existing diagnostic/progress information
* automatically opening a large log panel is NOT required

---

# 1. First Audit — Do Not Implement Blindly

Before changing code, trace the complete current path:

`fallback decision`

→ `FFmpegEngine`

→ `FFmpeg session`

→ `temp output`

→ `progress`

→ `validation`

→ `Media3`

→ `player`

→ `UI state`

Also inspect:

* existing coroutine/executor
* FFmpegKit session handling
* current progress callback
* current log callback
* existing Logs button
* existing transcoding state
* existing player state
* fallback cache
* lifecycle handling
* cancellation
* request ID guards
* player instance guards

Do not create parallel implementations if an existing mechanism can be extended.

---

# 2. Separate Transcoding Lifecycle From Playback Lifecycle

Do not make playback block on the entire transcoding job.

Introduce/repair a clear separation between:

### Playback

`PLAYBACK_REQUESTED`

`DIRECT_ATTEMPT`

`FALLBACK_REQUIRED`

`FALLBACK_PLAYABLE_AVAILABLE`

`PLAYING`

`PLAYBACK_SUCCESS`

### Transcoding

`NOT_STARTED`

`QUEUED`

`STARTING`

`RUNNING`

`PARTIAL_OUTPUT_AVAILABLE`

`COMPLETED`

`VALIDATING`

`VALIDATED`

`FAILED`

`CANCELLED`

These are related but must not be the same state.

A transcoding state of:

`RUNNING`

must NOT imply:

`PLAYBACK_BLOCKED`

---

# 3. Background Transcoding

Run FFmpeg using the existing background execution mechanism.

Never execute encoding work on:

* main/UI thread
* Compose recomposition
* Media3 callback thread

Use the existing executor/coroutine architecture.

Do not create an unlimited thread pool.

Encoding is CPU-intensive.

Prefer one active heavy transcode job per device/request policy unless the existing architecture explicitly supports more.

---

# 4. Keep UI Responsive

While transcoding:

* UI must remain responsive
* player controls must remain responsive
* scrolling must remain responsive
* Logs control must remain responsive
* Compose must not recompose excessively because FFmpeg emits many log lines

Do NOT publish every FFmpeg log line as a high-frequency UI state update.

Use two layers:

### Internal diagnostic stream

Can receive every log/event.

### UI-visible state

Throttle/coalesce updates.

For example:

* progress UI updates several times per second at most
* log UI batches incoming messages
* diagnostics retain detailed information internally

Do not lose important errors.

---

# 5. Fix the Invisible Logs Button

Find exactly why the existing Logs button is not visible.

Audit:

* `visible` condition
* `enabled` condition
* `AnimatedVisibility`
* `if` conditions
* `transcodingState`
* fallback state
* Compose state observation
* state initialization
* parent clipping
* layout constraints
* z-order
* conditional composition
* navigation destination
* stale state
* wrong ViewModel instance
* request ID mismatch

Do NOT redesign the Logs UI.

The existing button must become visible whenever:

`transcodingState ∈ {QUEUED, STARTING, RUNNING, PARTIAL_OUTPUT_AVAILABLE, COMPLETED, VALIDATING, VALIDATED, FAILED, CANCELLED}`

or according to the existing intended visibility policy.

It should NOT require the user to manually trigger transcoding.

Add diagnostics:

`[TRANSCODING_LOG_UI_VISIBILITY]`

`[TRANSCODING_LOG_UI_CLICK]`

`[TRANSCODING_LOG_UI_STATE]`

---

# 6. Logs Must Be Optional

Do not automatically force the user into the logs.

The normal experience should be:

`Fallback required`

→ background transcode

→ player becomes usable when possible

The user can choose:

`Logs`

to inspect:

* current encoder
* progress
* speed
* elapsed time
* current FFmpeg status
* errors
* validation
* cache state

Do not change the existing UI design.

---

# 7. Major Performance Audit

The current 1080p HEVC → H.264 conversion is reported as too slow.

Do not blindly reduce quality.

First determine where the time is spent.

Measure:

* FFmpeg startup time
* decoder initialization
* HEVC software decoding time
* H.264 encoding time
* filter/scaling time
* audio processing
* muxing
* storage I/O
* logging overhead
* progress callback overhead

Add:

`[TRANSCODE_PERF_START]`

`[TRANSCODE_PERF_INPUT_OPEN]`

`[TRANSCODE_PERF_ENCODER_INIT]`

`[TRANSCODE_PERF_FIRST_FRAME]`

`[TRANSCODE_PERF_ENCODING]`

`[TRANSCODE_PERF_MUXING]`

`[TRANSCODE_PERF_COMPLETE]`

---

# 8. Do Not Waste CPU on Unnecessary Work

Audit the FFmpeg command.

For the current source:

`1920x1080`

`23.98 fps`

`HEVC 10-bit`

the fallback requires conversion to:

`H.264 8-bit`

`yuv420p`

Avoid unnecessary:

* scaling
* frame-rate conversion
* audio re-encoding
* subtitle rendering
* filters
* format conversions beyond what is required for 8-bit H.264

If no scaling is required:

DO NOT add a scale filter.

If AAC is compatible:

use:

`-c:a copy`

Do not re-encode AAC.

---

# 9. libopenh264 Performance Audit

The current available encoder is:

`libopenh264`

Do not replace it in this phase unless the existing encoder-discovery system proves another usable encoder is materially better and compatible.

Inspect the actual encoder options supported by the installed FFmpeg build.

Determine:

* bitrate control
* quality control
* threading
* complexity settings
* profile support
* pixel format
* frame threading

Do not pass `libx264`-specific parameters to `libopenh264`.

Do not invent unsupported options.

---

# 10. Optimize for Mobile Encoding

The target device is:

`Realme RMP2105`

`Android 11`

`arm64-v8a`

The fallback should prioritize:

`reasonable encoding speed + Android compatibility`

over unnecessary compression efficiency.

Do not optimize for smallest possible file.

The objective is:

**fast enough to become playable while maintaining the required H.264 compatibility.**

Inspect whether the encoder supports a speed/complexity control.

If supported, select a faster valid mode.

Do NOT sacrifice:

* H.264 compatibility
* 8-bit output
* yuv420p
* valid profile
* valid level
* playback reliability

---

# 11. Do Not Use Fake Parallelism

Do NOT:

* run multiple encoders for the same file
* encode multiple copies
* decode the same source twice
* create a second FFmpeg process just for preview
* repeatedly restart FFmpeg

This would make mobile performance worse.

One authoritative transcode job per request.

---

# 12. Smart Progressive Playback

This is the most important feature.

Do NOT simply wait for the complete 23:42 output if there is a safe way to begin playback earlier.

However:

**Never expose an incomplete/corrupt MP4 as a normal completed fallback file.**

The implementation must determine whether the current MP4 output can safely support progressive playback while FFmpeg is still writing.

First inspect whether the existing output/muxer configuration produces a progressively playable MP4.

If the MP4 is not safely playable while being written, do NOT force partial playback.

Instead use:

`background transcode`

→ finish

→ validate

→ atomic commit

→ Media3 playback

This is preferable to corrupting or intermittently seeking a partial file.

---

# 13. If Progressive Playback Is Technically Safe

If the existing FFmpeg/MP4 pipeline can safely expose an actively growing output to Media3, implement it carefully.

Requirements:

* no final cache file is treated as validated before completion
* player receives only a deliberately designated progressive source
* Media3 must not read beyond currently available media
* additional data becoming available must not cause player crashes
* EOF must not be mistaken for true end-of-file
* player must recover as more data becomes available
* final completed output must still undergo FFprobe validation
* final validated output must replace the temporary/progressive source atomically

Do NOT assume Media3 can automatically play an arbitrary `.mp4.tmp` file while FFmpeg writes it.

Verify actual behavior.

---

# 14. Preferred Smart Strategy If Partial MP4 Playback Is Unsafe

If progressive playback cannot be made reliable with the current architecture:

Use intelligent background transcoding instead.

The behavior becomes:

`start transcode immediately`

→ keep UI/player responsive

→ display normal player/loading state

→ continuously calculate transcoding progress

→ when complete:

`FFprobe`

→ validate

→ atomic commit

→ immediately hand validated fallback to Media3

The user does NOT need to remain on the logs screen.

This still satisfies background transcoding and smooth UX without introducing fragile partial-file playback.

---

# 15. Smart Cache Reuse

Before starting a new transcode:

check the existing fallback cache.

If a valid cached fallback exists:

DO NOT transcode again.

Flow:

`cache lookup`

→ `exists`

→ `FFprobe validation`

→ `valid`

→ immediate Media3 handoff

If invalid:

discard/repair according to existing cache policy.

Do not trust existence alone.

---

# 16. Smart Transcoding Deduplication

If the same media is requested again while a transcode is already running:

DO NOT start another FFmpeg process.

Attach the new playback request to the existing job if the architecture permits.

Conceptually:

`MediaIdentity`

→ `TranscodeJob`

→ multiple observers

But preserve the existing request ID guards.

A request must not receive results from an unrelated source.

---

# 17. Rapid Media Switching

Example:

User starts:

`A`

then immediately:

`B`

then:

`C`

Do not allow old FFmpeg callbacks to update C's UI/player state.

Each job must have:

* PlaybackRequestId
* FFmpegJobId
* source identity

Use existing concurrency infrastructure.

Old job events become:

`STALE`

and cannot mutate the active playback state.

---

# 18. Cancellation Policy

Do not automatically cancel a background transcode merely because the Logs panel is closed.

Logs visibility and transcoding execution are independent.

Closing Logs means:

`hide diagnostics`

NOT:

`cancel FFmpeg`

Cancellation should occur only according to the existing playback/lifecycle policy.

If the user starts another unrelated media request, follow the existing resource policy.

If safe, allow the old job to finish for cache reuse.

If resource pressure requires cancellation, cancel explicitly and classify it as:

`TRANSCODING_CANCELLED`

not failure.

---

# 19. Lifecycle

Audit:

* Activity recreation
* Compose recomposition
* screen navigation
* background/foreground
* player recreation

The transcoding job must not accidentally restart because:

* Compose recomposed
* UI recreated
* Logs opened/closed
* player recreated

The job must be identified independently of the UI instance.

If the existing app architecture supports background execution beyond the Activity lifecycle, preserve it.

Do NOT introduce a new Android Service/WorkManager architecture unless the existing implementation genuinely requires it and the project already permits such a change.

The objective is to avoid architectural expansion.

---

# 20. Progress Must Represent Real Encoding

Use the actual source duration:

`1422.004 seconds`

for the current Solo Leveling file.

Progress should derive from actual FFmpeg progress such as:

* `out_time_ms`
* `out_time`
* equivalent existing FFmpegKit statistics

Normalize:

`0.0 ≤ progress ≤ 1.0`

Clamp invalid values.

Progress must be monotonic for the same job.

Do not use:

* elapsed-time percentage
* arbitrary timers
* estimated percentage pretending to be actual
* frame counters unrelated to duration

If FFmpeg has started but no measurable progress exists:

show an indeterminate/running state rather than fake `0%`.

---

# 21. Reduce Log Overhead

The current FFmpeg logs are very verbose.

Do not push the entire FFmpeg stderr stream into Compose state for every line.

Instead:

### Internal

retain detailed logs.

### UI

batch logs.

For example:

* append incoming messages to a thread-safe buffer
* publish batches at a limited frequency
* preserve the latest important error
* preserve start/completion information

This can materially reduce UI overhead.

Do not suppress actual FFmpeg errors.

---

# 22. Transcoding Priority

If the player is currently active, prioritize responsive playback/UI behavior.

Do not starve the main application thread.

If the device is under CPU pressure, avoid launching unrelated CPU-heavy work.

Do not change unrelated application behavior.

---

# 23. Storage Efficiency

Avoid unnecessary copies.

Current pipeline should ideally be:

`source`

→ `FFmpeg`

→ `temporary output`

→ `FFprobe`

→ `atomic final output`

Do not:

`source`

→ copy entire source

→ another temporary copy

→ FFmpeg

unless required by URI/file-access constraints already established in Phase 17.14.

Do not load the complete video into RAM.

---

# 24. Smooth Player Handoff

When fallback validation succeeds:

Do not abruptly recreate the entire player unless required.

Use the existing Phase 17.25 handoff mechanism.

Verify:

`PlaybackSource.sourceType = FALLBACK`

`PlaybackSource.uri = validated fallback URI`

Then:

`new/updated MediaItem`

→ MediaSource

→ prepare

→ play

The transition should avoid unnecessary UI flicker.

Preserve existing:

* playWhenReady
* playback position where meaningful
* selected audio policy where possible

Do not introduce unrelated UI changes.

---

# 25. Avoid Restarting From Zero When Appropriate

If playback begins after fallback preparation and the user had already requested playback, preserve the intended playback position.

For a newly started fallback:

start at:

`0`

unless the existing request contains a meaningful seek position.

For fallback handoff after direct playback failure:

attempt to preserve the current logical playback position if safe.

Do not blindly reuse a position from an incompatible source when timestamps differ.

---

# 26. Background State Must Not Look Like Playback Failure

While transcoding:

Do NOT report:

`PLAYBACK_FAILED`

simply because fallback is still processing.

Use distinct state:

`FALLBACK_TRANSCODING`

or equivalent existing state.

The final report must distinguish:

* fallback required
* transcoding running
* fallback validated
* playback started
* playback successful
* fallback failed

---

# 27. Automatic Completion Handling

When FFmpeg finishes:

1. verify request/job is still current
2. verify FFmpeg return code
3. verify output exists
4. verify output is non-zero
5. FFprobe output
6. normalize metadata
7. validate fallback contract
8. atomic commit
9. mark fallback validated
10. hand off to Media3
11. verify actual playback

Do not jump directly from:

`FFmpeg completed`

to:

`PLAYBACK_SUCCESS`

---

# 28. Failure Handling

If FFmpeg fails:

* preserve useful logs
* show failure through existing diagnostics
* do not crash
* do not retry indefinitely
* do not fallback again
* do not mutate unrelated playback requests

If validation fails:

`FALLBACK_VALIDATION_FAILED`

not:

`FFMPEG_FAILED`

If Media3 fails after fallback:

`FALLBACK_RUNTIME_PLAYBACK_FAILED`

and do not recursively transcode again.

---

# 29. Required Diagnostics

Add/preserve:

`[BACKGROUND_TRANSCODE_START]`

`[TRANSCODE_JOB_CREATED]`

`[TRANSCODE_JOB_REUSED]`

`[TRANSCODE_PERF_START]`

`[TRANSCODE_PERF_INPUT_OPEN]`

`[TRANSCODE_PERF_ENCODER_INIT]`

`[TRANSCODE_PERF_FIRST_FRAME]`

`[TRANSCODE_PERF_ENCODING]`

`[TRANSCODE_PERF_COMPLETE]`

`[TRANSCODE_UI_UPDATE]`

`[TRANSCODE_LOG_BATCH]`

`[TRANSCODING_LOG_UI_VISIBILITY]`

`[TRANSCODING_LOG_UI_CLICK]`

`[TRANSCODING_PROGRESS_RECEIVED]`

`[TRANSCODING_PROGRESS_PUBLISHED]`

`[TRANSCODING_PROGRESS_STALE]`

`[TRANSCODING_CACHE_HIT]`

`[TRANSCODING_CACHE_MISS]`

`[TRANSCODING_CANCELLED]`

`[TRANSCODING_FAILED]`

`[PROGRESSIVE_PLAYBACK_CHECK]`

`[PROGRESSIVE_PLAYBACK_ENABLED]`

`[PROGRESSIVE_PLAYBACK_DISABLED]`

`[FALLBACK_READY_FOR_PLAYBACK]`

`[FALLBACK_MEDIA3_HANDOFF]`

---

# 30. Required Performance Metrics

For every real transcode, record:

* source duration
* source size
* output size
* encoder
* resolution
* FPS
* elapsed time
* average FPS
* final encoding speed
* CPU-related metrics if already available
* FFmpeg startup latency
* time to first encoded frame
* time to playable fallback
* validation duration

Most importantly calculate:

`transcode_speed_ratio = encoded_media_seconds / wall_clock_seconds`

For example:

`0.5x`

means 1 second of video takes approximately 2 seconds to encode.

Do not display this as fake progress.

---

# 31. Speed Optimization Decision

After measuring performance, determine the actual bottleneck.

Possible results:

### Encoder bottleneck

Optimize supported `libopenh264` speed/complexity settings.

### Decoder bottleneck

Inspect HEVC software decoding cost.

### Conversion bottleneck

Remove unnecessary pixel-format/scaling/filter operations.

### Audio bottleneck

Ensure AAC stream copy is working.

### Storage bottleneck

Reduce unnecessary copies/I/O.

### Logging bottleneck

Batch logs and progress updates.

### UI bottleneck

Reduce state publication frequency.

Do not make speculative optimizations without evidence.

---

# 32. Solo Leveling Acceptance Scenario

Use:

`Solo Leveling...mkv`

`1920x1080`

`23.98 fps`

`HEVC Main10`

`yuv420p10le`

`AAC`

Expected:

1. Direct compatibility identifies Main10 as unsupported.
2. Fallback decision occurs.
3. Cache checked.
4. If no valid cache exists, background transcode starts.
5. UI remains responsive.
6. Logs button becomes visible through the existing UI mechanism.
7. User does not need to open Logs.
8. FFmpeg uses the discovered H.264 encoder.
9. MP4 muxer is explicitly specified.
10. Encoding runs off the UI thread.
11. Real progress is published.
12. Progress leaves 0%.
13. No fake progress.
14. No duplicate FFmpeg job.
15. Logs can be opened while encoding.
16. Closing Logs does not cancel encoding.
17. FFmpeg completes.
18. Output is FFprobe validated.
19. Validated fallback is atomically committed.
20. Media3 receives the validated fallback.
21. Actual playback starts.
22. Playback position advances.
23. Final result becomes `FALLBACK_SUCCESS`.
24. Original MKV remains untouched.

---

# 33. H.264 Regression

Use:

`VID_20260825_175610_104.mp4`

Expected:

* H.264 High 8-bit
* direct playback
* no FFmpeg
* no background transcode
* no Logs/transcoding state required merely because the player exists

---

# 34. VP9 Regression

Expected:

* existing compatibility logic unchanged
* direct attempt
* no unnecessary FFmpeg
* runtime failure may use existing controlled fallback escalation
* no duplicate transcoding

---

# 35. Rapid Switching Test

Run:

`A → B → C`

while A is transcoding.

Expected:

* no stale A progress displayed as C
* no stale A completion handed to C
* no player corruption
* no UI crash
* job identity remains correct
* stale callbacks ignored

---

# 36. Logs Test

Test:

1. Start fallback.
2. Do not open Logs.
3. Transcoding continues.
4. Logs button is visible.
5. Open Logs.
6. Current logs/progress appear.
7. Close Logs.
8. Transcoding continues.
9. Reopen Logs.
10. Current state remains accurate.

---

# 37. Lifecycle Test

Test:

* Compose recomposition
* screen re-entry
* player recreation
* Activity recreation if supported
* background → foreground

Expected:

* no duplicate FFmpeg process
* no lost job identity
* no stale progress
* no crash
* completed fallback remains usable

---

# 38. Important Restrictions

DO NOT:

* redesign the UI
* replace the player UI
* add a new Logs screen
* change unrelated navigation
* add a second FFmpeg engine
* add a second transcoder
* run multiple encoders for one source
* fake progressive playback
* expose corrupt/incomplete MP4 as a completed fallback
* fake progress
* block the main thread
* re-encode AAC unnecessarily
* scale unnecessarily
* change H.264 compatibility requirements
* reintroduce libx264
* change the unified decision engine
* bypass fallback validation
* mark FFmpeg completion as playback success
* cancel transcoding when Logs is closed
* create infinite retry loops

---

# Final Acceptance Criteria

The phase is complete only when:

1. Transcoding runs independently from UI visibility.
2. Transcoding runs in the background.
3. Player/UI remains responsive.
4. Existing Logs button becomes visible without redesigning the UI.
5. Logs remain optional.
6. Opening/closing Logs does not control FFmpeg execution.
7. Real FFmpeg progress is propagated.
8. Progress is throttled for UI performance but not lost internally.
9. Transcoding does not run on the main thread.
10. Duplicate jobs are prevented.
11. Cache hits avoid unnecessary transcoding.
12. Current encoder remains runtime-selected.
13. `libopenh264` is used correctly when selected.
14. MP4 output format is explicitly specified.
15. AAC stream copy remains enabled when valid.
16. No unnecessary scaling/filtering/audio encoding occurs.
17. Actual transcoding speed is measured.
18. The real performance bottleneck is identified.
19. Supported encoder speed options are optimized only where verified.
20. Background transcoding survives normal UI recomposition/recreation according to existing lifecycle architecture.
21. Stale callbacks cannot affect a newer request.
22. Cancellation remains distinct from failure.
23. Output is never considered valid before FFprobe validation.
24. Original media is never overwritten.
25. Media3 receives only the validated fallback for normal playback.
26. Actual playback verification remains authoritative.
27. If progressive playback is technically unsafe, the implementation explicitly disables it rather than attempting unsafe partial-file playback.
28. Solo Leveling successfully follows the background fallback pipeline when the encoder can complete.
29. H.264 direct playback remains unaffected.
30. VP9 behavior remains unaffected.
31. No unrelated UI, playback, cache, or architecture behavior changes.

## Final Required Report

Provide:

* exact reason transcoding was slow
* measured transcoding speed
* encoder used
* encoder settings actually used
* whether any unnecessary processing was removed
* whether audio was copied
* whether progressive playback was technically safe
* if enabled, exactly how it was made safe
* if disabled, why
* Logs button root cause
* Logs visibility fix
* background execution mechanism used
* progress propagation path
* cache behavior
* cancellation behavior
* lifecycle behavior
* concurrency behavior
* Solo Leveling result
* actual time to playable fallback
* final FFprobe validation
* actual Media3 playback result
* files modified
* tests executed
* any remaining blocker

STOP after this phase.
