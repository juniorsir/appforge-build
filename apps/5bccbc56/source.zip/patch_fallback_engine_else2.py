import sys
file_path = "/app/applet/app/src/main/java/com/example/media/playback/PlaybackFallbackEngine.kt"
with open(file_path, "r") as f:
    content = f.read()

target = """            PlaybackStrategy.DIRECT_HARDWARE, PlaybackStrategy.UNSUPPORTED -> {
                // If direct hardware was requested as a fix, perform standard stream-copy remux as safety fallback
                RemuxEngine.remuxToMp4(
                    context = context,
                    inputUri = inputUri,
                    outputFile = outputFile
                )
            }
        }
    }"""
replace = """            PlaybackStrategy.DIRECT_HARDWARE, PlaybackStrategy.UNSUPPORTED -> {
                RemuxEngine.remuxToMp4(
                    context = context,
                    inputUri = inputUri,
                    outputFile = outputFile
                )
            }
            else -> {
                throw IllegalStateException("Unhandled strategy: ${plan.strategy}")
            }
        }
    }"""

content = content.replace(target, replace)
with open(file_path, "w") as f:
    f.write(content)
