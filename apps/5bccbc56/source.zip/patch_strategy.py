import sys

file_path = "/app/applet/app/src/main/java/com/example/media/playback/PlaybackDecisionEngine.kt"
with open(file_path, "r") as f:
    content = f.read()

# Let's find where PlaybackStrategy is defined and add isDirect
target = """enum class PlaybackStrategy {
    DIRECT_PLAY,
    REMUX_REQUIRED,
    TRANSCODE_REQUIRED
}"""
replace = """enum class PlaybackStrategy(val isDirect: Boolean = false) {
    DIRECT_PLAY(isDirect = true),
    REMUX_REQUIRED(isDirect = false),
    TRANSCODE_REQUIRED(isDirect = false)
}"""

content = content.replace(target, replace)
with open(file_path, "w") as f:
    f.write(content)

