import sys
file_path = "/app/applet/app/src/main/java/com/example/media/progressive/NativeMediaCodecProbe.kt"
with open(file_path, "r") as f:
    content = f.read()

target = "widthRange=${vCaps.supportedWidths.lower}-${vCaps.supportedWidths.upper} heightRange=${vCaps.supportedHeights.lower}-${vCaps.supportedHeights.upper}"
replace = "widthRange=${vCaps?.supportedWidths?.lower}-${vCaps?.supportedWidths?.upper} heightRange=${vCaps?.supportedHeights?.lower}-${vCaps?.supportedHeights?.upper}"

content = content.replace(target, replace)
with open(file_path, "w") as f:
    f.write(content)
