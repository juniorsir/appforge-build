import sys

file_path = "/app/applet/app/src/main/java/com/example/ui/VideoDownloaderScreen.kt"
with open(file_path, "r") as f:
    lines = f.readlines()

out = []
skip = False
for i, line in enumerate(lines):
    if "var showConvertCodecDialog by remember { mutableStateOf(false) }" in line:
        if any("var showConvertCodecDialog" in out_line for out_line in out[-10:]):
            continue
    if "var selectedCodec by remember { mutableStateOf(\"mp3\") }" in line:
        if any("var selectedCodec" in out_line for out_line in out[-10:]):
            continue
    out.append(line)

with open(file_path, "w") as f:
    f.writelines(out)
