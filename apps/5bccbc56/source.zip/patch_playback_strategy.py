import sys
file_path = "/app/applet/app/src/main/java/com/example/media/playback/PlaybackCompatibilityResult.kt"
with open(file_path, "r") as f:
    content = f.read()

target = """enum class PlaybackStrategy {
    DIRECT_HARDWARE,
    REMUX_REQUIRED,
    TARGETED_AUDIO_TRANSCODE,
    TARGETED_VIDEO_TRANSCODE,
    TRANSCODE_REQUIRED,
    FULL_TRANSCODE_REQUIRED,
    UNSUPPORTED
}"""

replace = """enum class PlaybackStrategy(val isDirect: Boolean = false) {
    DIRECT_HARDWARE(isDirect = true),
    DIRECT_SAFE(isDirect = true),
    DIRECT_ATTEMPT(isDirect = true),
    REMUX_REQUIRED(isDirect = false),
    TARGETED_AUDIO_TRANSCODE(isDirect = false),
    TARGETED_VIDEO_TRANSCODE(isDirect = false),
    TRANSCODE_REQUIRED(isDirect = false),
    FULL_TRANSCODE_REQUIRED(isDirect = false),
    UNSUPPORTED(isDirect = false)
}"""

content = content.replace(target, replace)
with open(file_path, "w") as f:
    f.write(content)

