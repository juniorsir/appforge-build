import sys

file_path = "/app/applet/app/src/main/java/com/example/ui/VideoDownloaderScreen.kt"

with open(file_path, "r") as f:
    content = f.read()

# 1. Add onConvertAudioClick to DownlyFuturisticControlsOverlay
target_1 = """    onOpenMarkerList: () -> Unit = {},
    onOpenVideoAdjustments: () -> Unit = {},
    colorAdjustments: VideoColorAdjustments = VideoColorAdjustments(),"""
replace_1 = """    onOpenMarkerList: () -> Unit = {},
    onOpenVideoAdjustments: () -> Unit = {},
    onConvertAudioClick: () -> Unit = {},
    colorAdjustments: VideoColorAdjustments = VideoColorAdjustments(),"""
content = content.replace(target_1, replace_1)

# 2. Add IconButton in SleekVideoPlayerHeader
target_2 = """                            if (hasTranscodingLogs) {
                                IconButton("""
replace_2 = """                            IconButton(
                                onClick = onConvertAudioClick,
                                modifier = Modifier.size(headerIconBtnSize).testTag("header_convert_audio_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.MusicNote,
                                    contentDescription = "Convert Audio",
                                    tint = Color.White,
                                    modifier = Modifier.size(headerIconSize)
                                )
                            }
                            if (hasTranscodingLogs) {
                                IconButton("""
content = content.replace(target_2, replace_2)

# 3. Add state variables to SleekVideoPlayerOverlay
target_3 = """    val scope = rememberCoroutineScope()
    var isPaused by remember(media.id, media.localPath) { mutableStateOf(false) }"""
replace_3 = """    val scope = rememberCoroutineScope()
    var isPaused by remember(media.id, media.localPath) { mutableStateOf(false) }
    var showConvertCodecDialog by remember { mutableStateOf(false) }
    var selectedCodec by remember { mutableStateOf("mp3") }"""
content = content.replace(target_3, replace_3)

# 4. Add onConvertAudioClick = { showConvertCodecDialog = true } to DownlyFuturisticControlsOverlay invocation
target_4 = """                        onOpenVideoAdjustments = {
                            showVideoAdjustmentsMenu = true
                            registerUserActivity()
                        },"""
replace_4 = """                        onOpenVideoAdjustments = {
                            showVideoAdjustmentsMenu = true
                            registerUserActivity()
                        },
                        onConvertAudioClick = {
                            showConvertCodecDialog = true
                            registerUserActivity()
                        },"""
content = content.replace(target_4, replace_4)

# 5. Add AlertDialog at the end of SleekVideoPlayerOverlay
target_5 = """                    }
                }
            }
        }
    }
}

@Composable
fun AdvancedPlayerSettingsSheetContent("""
replace_5 = """                    }
                }
            }
        }
    }

    if (showConvertCodecDialog) {
        AlertDialog(
            onDismissRequest = { showConvertCodecDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(imageVector = Icons.Default.MusicNote, contentDescription = null, tint = SleekPurpleLight)
                    Text("Convert / Extract Audio", color = SleekTextPrimary, fontWeight = FontWeight.Bold)
                }
            },
            text = {
                Column(
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "Extract and convert the audio stream from this file into your preferred container / codec format:",
                        color = SleekTextSecondary,
                        fontSize = 13.sp,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                    val codecs = listOf(
                        "mp3" to "MP3 (Lame - High Compatibility)",
                        "m4a" to "M4A (AAC - Compact Quality)",
                        "aac" to "AAC (Native Audio Stream)",
                        "flac" to "FLAC (Lossless Quality)",
                        "wav" to "WAV (Uncompressed Audio)"
                    )
                    codecs.forEach { (key, label) ->
                        val isSelected = (selectedCodec == key)
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = if (isSelected) SleekPurpleDark.copy(alpha = 0.2f) else Color.Transparent,
                            border = BorderStroke(1.dp, if (isSelected) SleekPurpleLight else Color.Transparent),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { selectedCodec = key }
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                            ) {
                                RadioButton(
                                    selected = isSelected,
                                    onClick = { selectedCodec = key },
                                    colors = RadioButtonDefaults.colors(
                                        selectedColor = SleekPurpleLight,
                                        unselectedColor = SleekTextSecondary
                                    )
                                )
                                Text(
                                    text = label,
                                    color = if (isSelected) SleekPurpleLight else SleekTextPrimary,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    fontSize = 14.sp
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showConvertCodecDialog = false
                        viewModel?.convertAudio(media, selectedCodec)
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color.White,
                        contentColor = Color.Black
                    )
                ) {
                    Text("START CONVERSION", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showConvertCodecDialog = false }) {
                    Text("CANCEL", color = SleekTextSecondary, fontWeight = FontWeight.Bold)
                }
            },
            containerColor = SleekCard,
            titleContentColor = SleekTextPrimary,
            textContentColor = SleekTextSecondary,
            shape = RoundedCornerShape(24.dp)
        )
    }
}

@Composable
fun AdvancedPlayerSettingsSheetContent("""
content = content.replace(target_5, replace_5)


with open(file_path, "w") as f:
    f.write(content)

print("Patched VideoDownloaderScreen.kt successfully.")
