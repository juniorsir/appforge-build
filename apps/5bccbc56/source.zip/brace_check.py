import sys

def check_braces(filename):
    with open(filename, 'r') as f:
        content = f.read()

    stack = []
    i = 0
    n = len(content)
    line_no = 1

    while i < n:
        char = content[i]
        if char == '\n':
            line_no += 1
            i += 1
            continue

        # Line comment
        if char == '/' and i + 1 < n and content[i + 1] == '/':
            i += 2
            while i < n and content[i] != '\n':
                i += 1
            continue

        # Block comment
        if char == '/' and i + 1 < n and content[i + 1] == '*':
            i += 2
            while i + 1 < n and not (content[i] == '*' and content[i + 1] == '/'):
                if content[i] == '\n':
                    line_no += 1
                i += 1
            i += 2
            continue

        # Triple quote string
        if char == '"' and i + 2 < n and content[i + 1] == '"' and content[i + 2] == '"':
            i += 3
            while i + 2 < n and not (content[i] == '"' and content[i + 1] == '"' and content[i + 2] == '"'):
                if content[i] == '\n':
                    line_no += 1
                i += 1
            i += 3
            continue

        # Single quote char literal
        if char == "'":
            i += 1
            while i < n and content[i] != "'":
                if content[i] == '\\':
                    i += 1
                i += 1
            i += 1
            continue

        # Normal string literal
        if char == '"':
            i += 1
            while i < n and content[i] != '"':
                if content[i] == '\\':
                    i += 1
                elif content[i] == '\n':
                    break
                i += 1
            i += 1
            continue

        if char == '{':
            stack.append(line_no)
        elif char == '}':
            if not stack:
                print(f"Unmatched closing brace at line {line_no}")
                return
            stack.pop()

        i += 1

    if stack:
        print(f"Unmatched opening braces (count {len(stack)}):")
        for l in stack[-10:]:
            print(f"Line {l}")
    else:
        print("Braces are balanced.")

check_braces('app/src/main/java/com/example/ui/VideoDownloaderScreen.kt')
