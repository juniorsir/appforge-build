import sys

file_path = "/app/applet/app/src/main/java/com/example/media/ffmpeg/FFmpegProgress.kt"
with open(file_path, "r") as f:
    content = f.read()

target = """enum class FFmpegState {
    IDLE,
    STARTING,
    RUNNING,
    COMPLETED,
    FAILED,
    CANCELLED
}

data class FFmpegProgress(
    val sessionId: Long = 0L,
    val state: FFmpegState = FFmpegState.IDLE,
    val progressPercentage: Float = 0f,
    val currentTimestampMs: Long = 0L,
    val totalDurationMs: Long = 0L,
    val speed: Double = 0.0,
    val bitrateKbps: Double = 0.0,
    val estimatedRemainingTimeMs: Long = 0L,
    val error: Throwable? = null,
    val logOutput: String? = null
)"""
replace = """enum class FFmpegState {
    IDLE,
    STARTING,
    RUNNING,
    COMPLETED,
    FAILED,
    CANCELLED,
    VALIDATING
}

data class FFmpegProgress(
    val sessionId: Long = 0L,
    val state: FFmpegState = FFmpegState.IDLE,
    val progressPercentage: Float? = 0f,
    val currentTimestampMs: Long = 0L,
    val totalDurationMs: Long = 0L,
    val speed: Double = 0.0,
    val fps: Double = 0.0,
    val outputSizeBytes: Long = 0L,
    val latestLogLine: String? = null,
    val bitrateKbps: Double = 0.0,
    val estimatedRemainingTimeMs: Long = 0L,
    val error: Throwable? = null,
    val logOutput: String? = null
)"""

content = content.replace(target, replace)
with open(file_path, "w") as f:
    f.write(content)

