import sys
file_path = "/app/applet/app/src/main/java/com/example/media/playback/PlaybackFallbackEngine.kt"
with open(file_path, "r") as f:
    content = f.read()

target = """            PlaybackStrategy.DIRECT_HARDWARE -> {
                throw IllegalStateException("DIRECT_HARDWARE should not enter executeFix")
            }"""

replace = """            PlaybackStrategy.DIRECT_HARDWARE, PlaybackStrategy.DIRECT_SAFE, PlaybackStrategy.DIRECT_ATTEMPT -> {
                throw IllegalStateException("DIRECT strategy should not enter executeFix")
            }"""

content = content.replace(target, replace)
with open(file_path, "w") as f:
    f.write(content)

