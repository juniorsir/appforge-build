import sys
file_path = "/app/applet/app/src/main/java/com/example/media/playback/PlaybackAnalysisReport.kt"
with open(file_path, "r") as f:
    content = f.read()

target = "val authoritativeError: String? = null"
replace = "val authoritativeError: PlaybackError? = null"

content = content.replace(target, replace)
with open(file_path, "w") as f:
    f.write(content)
