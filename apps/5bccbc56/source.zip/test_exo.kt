import androidx.media3.exoplayer.ExoPlaybackException

fun check(e: ExoPlaybackException) {
    val r = e.rendererName
    val f = e.rendererFormat
}
