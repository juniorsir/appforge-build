import sys

file_path = "/app/applet/app/src/main/java/com/example/media/MediaEngine.kt"
with open(file_path, "r") as f:
    content = f.read()

target1 = "fun prepareMedia(uriString: String, audioUriString: String? = null, subtitleUriString: String? = null)"
replace1 = """fun prepareMedia(uriString: String, audioUriString: String? = null, subtitleUriString: String? = null)
    fun preparePlaybackSource(source: com.example.media.playback.PlaybackSource, audioUriString: String? = null, subtitleUriString: String? = null, startPositionMs: Long = 0L, activeRequestIdProvider: () -> String)"""
content = content.replace(target1, replace1)

target2 = """    override fun prepareMedia(uriString: String, audioUriString: String?, subtitleUriString: String?) {
        this.currentUriString = uriString
        val mediaItemBuilder = MediaItem.Builder()
            .setUri(android.net.Uri.parse(uriString))"""
replace2 = """    override fun preparePlaybackSource(source: com.example.media.playback.PlaybackSource, audioUriString: String?, subtitleUriString: String?, startPositionMs: Long, activeRequestIdProvider: () -> String) {
        this.currentUriString = source.uri.toString()
        val mediaItemBuilder = MediaItem.Builder().setUri(source.uri)
        if (subtitleUriString != null) {
            val subUri = android.net.Uri.parse(subtitleUriString)
            val subConfig = MediaItem.SubtitleConfiguration.Builder(subUri)
                .setMimeType("text/vtt")
                .setLanguage("en")
                .setSelectionFlags(androidx.media3.common.C.SELECTION_FLAG_DEFAULT)
                .build()
            mediaItemBuilder.setSubtitleConfigurations(listOf(subConfig))
        }
        val mediaItem = mediaItemBuilder.build()
        if (audioUriString != null) {
            // Placeholder: Handle audio URI merging if necessary, similar to prepareMedia.
        }
        exoPlayer.setMediaItem(mediaItem, startPositionMs)
        exoPlayer.prepare()
        exoPlayer.playWhenReady = true
    }

    override fun prepareMedia(uriString: String, audioUriString: String?, subtitleUriString: String?) {
        this.currentUriString = uriString
        val mediaItemBuilder = MediaItem.Builder()
            .setUri(android.net.Uri.parse(uriString))"""

content = content.replace(target2, replace2)

with open(file_path, "w") as f:
    f.write(content)
