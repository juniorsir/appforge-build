import sys

file_path = "/app/applet/app/src/main/java/com/example/media/DecoderCapabilityManager.kt"
with open(file_path, "r") as f:
    content = f.read()

target = "object DecoderCapabilityManager {"
replace = """object DecoderCapabilityManager {
    fun normalizeProfile(codec: String, profileStr: String): String {
        return profileStr
    }"""
content = content.replace(target, replace)
with open(file_path, "w") as f:
    f.write(content)

