import os
import shutil

downloads_dir = "/app/applet/downloads"
app_dir = "/app/applet"

for root, dirs, files in os.walk(downloads_dir):
    for file in files:
        if file.startswith("old_"):
            src_path = os.path.join(root, file)
            # Determine the relative path
            rel_path = os.path.relpath(src_path, downloads_dir)
            # Remove "old_" from the filename
            new_name = file[4:]
            
            # The destination path is the same relative path in the app_dir, 
            # but with the filename replaced
            dest_dir = os.path.join(app_dir, os.path.dirname(rel_path))
            dest_path = os.path.join(dest_dir, new_name)
            
            os.makedirs(dest_dir, exist_ok=True)
            print(f"Copying {src_path} to {dest_path}")
            shutil.copy2(src_path, dest_path)

