import sys

file_path = "/app/applet/app/src/main/java/com/example/media/MediaEngine.kt"
with open(file_path, "r") as f:
    content = f.read()

target = """    override fun prepareMedia(uriString: String, audioUriString: String?, subtitleUriString: String?) {"""
replace = """    override fun preparePlaybackSource(source: com.example.media.playback.PlaybackSource, audioUriString: String?, subtitleUriString: String?, startPositionMs: Long, activeRequestIdProvider: () -> String) {
        this.currentUriString = source.uri.toString()
        val mediaItemBuilder = MediaItem.Builder().setUri(source.uri)
        if (subtitleUriString != null) {
            val subUri = android.net.Uri.parse(subtitleUriString)
            val subConfig = MediaItem.SubtitleConfiguration.Builder(subUri)
                .setMimeType("text/vtt")
                .setLanguage("en")
                .setSelectionFlags(androidx.media3.common.C.SELECTION_FLAG_DEFAULT)
                .build()
            mediaItemBuilder.setSubtitleConfigurations(listOf(subConfig))
        }
        val mediaItem = mediaItemBuilder.build()
        exoPlayer.setMediaItem(mediaItem, startPositionMs)
        exoPlayer.prepare()
        exoPlayer.playWhenReady = true
    }

    override fun prepareMedia(uriString: String, audioUriString: String?, subtitleUriString: String?) {"""

content = content.replace(target, replace)
with open(file_path, "w") as f:
    f.write(content)

