package com.example

import com.example.media.ffmpeg.FFmpegEngine
import com.example.media.ffmpeg.FFmpegOperationType
import com.example.media.ffmpeg.FFmpegProgress
import com.example.media.ffmpeg.FFmpegResult
import com.example.media.ffmpeg.FFmpegSessionManager
import com.example.media.ffmpeg.FFmpegState
import com.example.media.playback.TranscodingLifecycleState
import com.example.media.playback.TranscodingLogManager
import com.example.media.progressive.ProgressiveGenerationProgress
import com.example.media.progressive.ProgressiveGenerationRequest
import com.example.media.progressive.ProgressiveState
import com.example.media.progressive.ProgressiveTranscodeController
import com.example.media.progressive.ProgressiveUnitValidator
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.runTest
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config
import java.io.File

@OptIn(ExperimentalCoroutinesApi::class)
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [33])
class Phase17_37_TranscodeStallAndErrorPrecedenceTest {

    @Before
    fun setup() {
        FFmpegEngine.resetForTesting()
        TranscodingLogManager.clear()
        ProgressiveTranscodeController.reset()
    }

    @After
    fun tearDown() {
        FFmpegEngine.resetForTesting()
        TranscodingLogManager.clear()
        ProgressiveTranscodeController.reset()
    }

    @Test
    fun testHeartbeatAndStallDetectionLogging() = runTest {
        val reqId = "stall-req-1"
        val jobId = "stall-job-1"

        FFmpegSessionManager.registerContext(
            sessionId = 55L,
            operationType = FFmpegOperationType.ACTUAL_TRANSCODING,
            requestId = reqId,
            jobId = jobId,
            command = "-i solo_leveling.mkv -c:v libopenh264 -pix_fmt yuv420p output.m3u8",
            totalDurationMs = 1420000L
        )

        // Progress event at frame 241, 10.58s
        val progress = FFmpegProgress(
            sessionId = 55L,
            state = FFmpegState.RUNNING,
            progressPercentage = 1.0f,
            currentTimestampMs = 10580L,
            totalDurationMs = 1420000L,
            speed = 1.25,
            fps = 23.0,
            latestLogLine = "frame=  241 fps= 23 q=28.0 size= 1024kB time=00:00:10.58 bitrate= 792.0kbits/s speed=1.25x"
        )

        TranscodingLogManager.recordProgress(progress, reqId)

        // Record stall event trace
        TranscodingLogManager.recordEvent(
            "TRANSCODING_STALL_TRACE",
            "mediaTimeMs=10580 wallTimeDeltaMs=6200 speed=1.25x fps=23.0 encoder=libopenh264",
            reqId
        )

        val logs = TranscodingLogManager.logs.value
        val hasStallLog = logs.any { it.contains("TRANSCODING_STALL_TRACE") }
        assertTrue("Expected TRANSCODING_STALL_TRACE log line", hasStallLog)

        val metadata = TranscodingLogManager.sessionMetadata.value
        assertEquals(55L, metadata.sessionId)
        assertEquals(10580L, metadata.currentTimestampMs)
        assertEquals("RUNNING", metadata.status)
    }

    @Test
    fun testActiveFallbackTranscodingStatePrecedence() = runTest {
        val reqId = "error-precedence-req"

        TranscodingLogManager.updateTranscodingState(TranscodingLifecycleState.RUNNING, reqId)

        val state = TranscodingLogManager.transcodingState.value
        assertTrue("Transcoding must be active", state.isTranscodingActive)
        assertTrue("Log controls must be visible", state.isLogControlVisible)
    }

    @Test
    fun testNonBlockingUnitValidation() = runTest {
        val context = RuntimeEnvironment.getApplication()
        val dummySegment = File(context.cacheDir, "seg_00000.ts").apply {
            writeBytes(ByteArray(2048))
            deleteOnExit()
        }

        val result = ProgressiveUnitValidator.validateUnit(context, dummySegment)
        assertTrue("Validation should succeed for non-empty file", result.isSuccess)
        val meta = result.getOrNull()
        assertEquals(8, meta?.bitDepth)
        assertEquals("h264", meta?.codec)
    }
}
