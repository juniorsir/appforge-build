package com.example

import android.net.Uri
import androidx.media3.common.C
import androidx.media3.common.Format
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import com.example.media.playback.*
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

/**
 * PHASE 17.21 — Media3 Decoder & Runtime Format Negotiation Hardening Test Suite.
 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class Phase17_21_Media3DecoderNegotiationTest {

    @Before
    fun setup() {
        PlaybackRequestCoordinator.resetForTesting()
        PlaybackDiagnosticRegistry.resetForTesting()
    }

    // =========================================================================
    // 1. AUTHORITATIVE FORMAT & CONTAINER VS CODEC MIME SEPARATION
    // =========================================================================

    @Test
    fun testContainerMimeVsCodecMimeSeparation() {
        val reqId = "req_mime_01"
        val originalUri = Uri.parse("file:///storage/emulated/0/Download/movie.mkv")

        val source = PlaybackSource(
            sourceType = PlaybackSourceType.ORIGINAL,
            uri = originalUri,
            originalUri = originalUri,
            path = originalUri.path,
            mimeType = null,
            requestId = reqId,
            container = "matroska,webm",
            codec = "hevc"
        )

        val determinedMime = Media3SourceBuilder.determineMimeType(source)
        // Container MIME for MKV must be video/x-matroska, NOT the inner codec (video/hevc)
        assertEquals(MimeTypes.VIDEO_MATROSKA, determinedMime)

        val mediaItem = Media3SourceBuilder.buildMediaItem(source)
        assertEquals(MimeTypes.VIDEO_MATROSKA, mediaItem.localConfiguration?.mimeType)
        assertEquals(originalUri, mediaItem.localConfiguration?.uri)
    }

    @Test
    fun testFallbackContainerMimeIsAlwaysMp4() {
        val reqId = "req_mime_02"
        val originalUri = Uri.parse("file:///storage/emulated/0/Download/video.avi")
        val fallbackUri = Uri.parse("file:///data/user/0/com.example/cache/fallback_video.mp4")

        val source = PlaybackSource(
            sourceType = PlaybackSourceType.FALLBACK,
            uri = fallbackUri,
            originalUri = originalUri,
            path = fallbackUri.path,
            mimeType = null,
            requestId = reqId,
            container = "mp4",
            codec = "h264"
        )

        val determinedMime = Media3SourceBuilder.determineMimeType(source)
        assertEquals(MimeTypes.VIDEO_MP4, determinedMime)

        val mediaItem = Media3SourceBuilder.buildMediaItem(source)
        assertEquals(MimeTypes.VIDEO_MP4, mediaItem.localConfiguration?.mimeType)
        assertEquals(fallbackUri, mediaItem.localConfiguration?.uri)
    }

    // =========================================================================
    // 2. MEDIA3 FORMAT TRACE & AUDIO FORMAT TRACE
    // =========================================================================

    @Test
    fun testMedia3FormatTraceLogging() {
        val reqId = "req_fmt_01"
        val playerInstanceId = "P1"

        PlaybackRequestCoordinator.logMedia3FormatTrace(
            requestId = reqId,
            playerInstanceId = playerInstanceId,
            sampleMimeType = "video/hevc",
            codecs = "hev1.1.6.L93.B0",
            width = 1920,
            height = 1080,
            frameRate = 30.0f,
            rotationDegrees = 0,
            pixelWidthHeightRatio = 1.0f,
            profile = "Main",
            level = "4.0",
            colorInfo = null,
            cryptoType = C.CRYPTO_TYPE_NONE,
            sourceType = PlaybackSourceType.ORIGINAL
        )

        val events = PlaybackDiagnosticRegistry.getEventsForRequest(reqId)
        assertTrue(events.any { it.eventType == DiagnosticEventType.MEDIA3_FORMAT_DETECTED })
        val fmtEvent = events.first { it.eventType == DiagnosticEventType.MEDIA3_FORMAT_DETECTED }
        assertEquals(reqId, fmtEvent.playbackRequestId)
        assertEquals(playerInstanceId, fmtEvent.playerInstanceId)
        assertEquals("video/hevc", fmtEvent.metadata["mime"])
        assertEquals("1920x1080", fmtEvent.metadata["resolution"])
    }

    @Test
    fun testMedia3AudioFormatLogging() {
        val reqId = "req_audio_fmt_01"
        val playerInstanceId = "P1"

        PlaybackRequestCoordinator.logMedia3AudioFormat(
            requestId = reqId,
            playerInstanceId = playerInstanceId,
            sampleMimeType = "audio/mp4a-latm",
            codecs = "mp4a.40.2",
            sampleRate = 48000,
            channelCount = 6,
            language = "eng",
            sourceType = PlaybackSourceType.ORIGINAL
        )

        val events = PlaybackDiagnosticRegistry.getEventsForRequest(reqId)
        assertTrue(events.any { it.eventType == DiagnosticEventType.MEDIA3_AUDIO_FORMAT_DETECTED })
        val audioEvent = events.first { it.eventType == DiagnosticEventType.MEDIA3_AUDIO_FORMAT_DETECTED }
        assertEquals("audio/mp4a-latm", audioEvent.metadata["mime"])
        assertEquals("48000", audioEvent.metadata["sampleRate"])
        assertEquals("6", audioEvent.metadata["channelCount"])
    }

    // =========================================================================
    // 3. DECODER INITIALIZATION & SELECTION
    // =========================================================================

    @Test
    fun testMedia3DecoderInitAndSelection() {
        val reqId = "req_dec_01"
        val playerInstanceId = "P1"

        PlaybackRequestCoordinator.logMedia3DecoderInit(
            requestId = reqId,
            playerInstanceId = playerInstanceId,
            decoderName = "c2.android.avc.decoder",
            mimeType = "video/avc",
            formatStr = "avc1.640028",
            durationMs = 45L
        )

        PlaybackRequestCoordinator.logMedia3DecoderSelected(
            requestId = reqId,
            playerInstanceId = playerInstanceId,
            trackType = "video",
            decoderName = "c2.android.avc.decoder",
            isHardware = false,
            mimeType = "video/avc"
        )

        val events = PlaybackDiagnosticRegistry.getEventsForRequest(reqId)
        assertTrue(events.any { it.eventType == DiagnosticEventType.MEDIA3_DECODER_INITIALIZED })
        assertTrue(events.any { it.eventType == DiagnosticEventType.MEDIA3_DECODER_SELECTED })

        val initEvt = events.first { it.eventType == DiagnosticEventType.MEDIA3_DECODER_INITIALIZED }
        assertEquals("c2.android.avc.decoder", initEvt.metadata["decoder"])
        assertEquals("45", initEvt.metadata["durationMs"])

        val selEvt = events.first { it.eventType == DiagnosticEventType.MEDIA3_DECODER_SELECTED }
        assertEquals("video", selEvt.metadata["trackType"])
        assertEquals("false", selEvt.metadata["isHardware"])
    }

    @Test
    fun testMedia3DecoderDifferenceDetection() {
        val reqId = "req_dec_diff_01"
        val predictedDecoder = "OMX.qcom.video.decoder.hevc"
        val actualDecoder = "c2.android.hevc.decoder"

        PlaybackRequestCoordinator.logMedia3DecoderDifference(
            requestId = reqId,
            predictedDecoder = predictedDecoder,
            actualDecoder = actualDecoder,
            reason = "Media3 runtime ranking rules"
        )

        val events = PlaybackDiagnosticRegistry.getEventsForRequest(reqId)
        assertTrue(events.any { it.eventType == DiagnosticEventType.MEDIA3_DECODER_DIFFERENCE })
        val diffEvt = events.first { it.eventType == DiagnosticEventType.MEDIA3_DECODER_DIFFERENCE }
        assertEquals(predictedDecoder, diffEvt.metadata["predicted"])
        assertEquals(actualDecoder, diffEvt.metadata["actual"])
    }

    // =========================================================================
    // 4. TRACK SELECTION & FORMAT SUPPORT EVALUATION
    // =========================================================================

    @Test
    fun testMedia3TrackSelectionAndSupportTrace() {
        val reqId = "req_tracks_01"
        val playerInstanceId = "P1"

        PlaybackRequestCoordinator.logMedia3SupportTrace(
            requestId = reqId,
            playerInstanceId = playerInstanceId,
            trackType = "video",
            formatSupport = "FORMAT_HANDLED",
            formatStr = "video/hevc (hev1.1.6.L93.B0)",
            isSupported = true
        )

        PlaybackRequestCoordinator.logMedia3SupportTrace(
            requestId = reqId,
            playerInstanceId = playerInstanceId,
            trackType = "audio",
            formatSupport = "FORMAT_HANDLED",
            formatStr = "audio/mp4a-latm (mp4a.40.2)",
            isSupported = true
        )

        PlaybackRequestCoordinator.logMedia3TrackSelection(
            requestId = reqId,
            playerInstanceId = playerInstanceId,
            selectedVideoTrack = "video/hevc_1920x1080",
            selectedAudioTrack = "audio/mp4a-latm_48000Hz",
            groupCount = 2
        )

        val events = PlaybackDiagnosticRegistry.getEventsForRequest(reqId)
        val supportEvents = events.filter { it.eventType == DiagnosticEventType.MEDIA3_SUPPORT_EVALUATED }
        assertEquals(2, supportEvents.size)
        assertTrue(events.any { it.eventType == DiagnosticEventType.MEDIA3_TRACKS_CHANGED })
    }

    // =========================================================================
    // 5. ERROR TAXONOMY & DECODER CAPABILITY FAILURE CLASSIFICATION
    // =========================================================================

    @Test
    fun testMedia3FormatExceedsCapabilitiesErrorClassification() {
        val reqId = "req_err_exceeds_01"

        val exceedsError = PlaybackException(
            "Video format exceeds decoder capability",
            null,
            PlaybackException.ERROR_CODE_DECODING_FORMAT_EXCEEDS_CAPABILITIES
        )

        val classified = PlaybackErrorClassifier.classifyMedia3Error(
            requestId = reqId,
            error = exceedsError,
            sourceType = PlaybackSourceType.ORIGINAL,
            fallbackAttemptCount = 0
        )

        assertEquals(PlaybackErrorCategory.MEDIA3_DECODER_FAILED, classified.category)
        assertEquals(ErrorRecoverability.RECOVERABLE, classified.recoverable)
        assertEquals(PlaybackRecoveryAction.TRANSCODE_FALLBACK, classified.recoveryAction)

        PlaybackRequestCoordinator.logMedia3DecoderError(
            requestId = reqId,
            playerInstanceId = "P1",
            sourceType = PlaybackSourceType.ORIGINAL,
            errorCode = exceedsError.errorCode,
            errorName = exceedsError.errorCodeName,
            exceptionType = exceedsError.javaClass.simpleName,
            cause = exceedsError.message,
            rendererName = "MediaCodecVideoRenderer",
            decoderName = "c2.android.hevc.decoder",
            format = "video/hevc",
            formatSupport = "FORMAT_EXCEEDS_CAPABILITIES"
        )

        val events = PlaybackDiagnosticRegistry.getEventsForRequest(reqId)
        assertTrue(events.any { it.eventType == DiagnosticEventType.MEDIA3_DECODER_ERROR })
    }

    @Test
    fun testMedia3FormatUnsupportedErrorClassification() {
        val reqId = "req_err_unsupported_01"

        val unsuppError = PlaybackException(
            "Video format unsupported by device",
            null,
            PlaybackException.ERROR_CODE_DECODING_FORMAT_UNSUPPORTED
        )

        val classified = PlaybackErrorClassifier.classifyMedia3Error(
            requestId = reqId,
            error = unsuppError,
            sourceType = PlaybackSourceType.ORIGINAL,
            fallbackAttemptCount = 0
        )

        assertEquals(PlaybackErrorCategory.MEDIA3_DECODER_FAILED, classified.category)
        assertEquals(ErrorRecoverability.RECOVERABLE, classified.recoverable)
        assertEquals(PlaybackRecoveryAction.TRANSCODE_FALLBACK, classified.recoveryAction)
    }

    // =========================================================================
    // 6. PLAYBACK CONFIRMATION REQUIRES ADVANCEMENT (STATE_READY != SUCCESS)
    // =========================================================================

    @Test
    fun testStateReadyIsNotPlaybackSuccessWithoutAdvancement() {
        val reqId = "req_ready_test_01"
        val uri = Uri.parse("file:///sdcard/test.mp4")

        val (req, _) = PlaybackRequestCoordinator.getOrCreateRequest(
            mediaKey = "key_ready_test",
            originalUri = uri,
            originalPath = uri.path!!
        )

        // Simulate STATE_READY event
        PlaybackDiagnosticRegistry.recordEvent(
            eventType = DiagnosticEventType.MEDIA3_READY,
            stage = PlaybackErrorStage.MEDIA3_PLAYBACK,
            severity = DiagnosticSeverity.INFO,
            playbackRequestId = reqId,
            message = "Media3 entered STATE_READY"
        )

        // At this point, request must not be marked terminal success
        assertFalse(req.isTerminal)
        assertNull(req.terminalResult)

        // Advance position milestone to 500ms
        PlaybackDiagnosticRegistry.recordPositionMilestone(
            playbackRequestId = reqId,
            playerInstanceId = "P1",
            currentPositionMs = 500L,
            durationMs = 10000L,
            sourceType = PlaybackSourceType.ORIGINAL
        )

        val events = PlaybackDiagnosticRegistry.getEventsForRequest(reqId)
        assertTrue(events.any { it.eventType == DiagnosticEventType.MEDIA3_READY })
        assertTrue(events.any { it.eventType == DiagnosticEventType.MEDIA3_POSITION_ADVANCED })
    }
}
