package com.example

import com.example.media.CapabilityStatus
import com.example.media.DecoderCapabilityManager
import com.example.media.IncompatibilityReason
import com.example.media.probe.AudioStreamInfo
import com.example.media.probe.SubtitleStreamInfo
import com.example.media.probe.VideoStreamInfo
import org.junit.Assert.*
import org.junit.Test

/**
 * PHASE 17.20 — Codec & Container Compatibility Matrix Hardening Test Suite.
 */
class Phase17_20_CodecContainerCompatibilityMatrixTest {

    // =========================================================================
    // 1. CONTAINER VS CODEC SEPARATION TESTS
    // =========================================================================

    @Test
    fun testContainerNeverTreatedAsCodec() {
        val containers = listOf("mkv", "matroska", "mp4", "mov", "webm", "avi", "ts", "flv", "m4v", "3gp")
        for (container in containers) {
            val videoMime = DecoderCapabilityManager.resolveMimeType(container, isVideo = true)
            val audioMime = DecoderCapabilityManager.resolveMimeType(container, isVideo = false)
            assertNull("Container '$container' must never resolve as a video MIME type", videoMime)
            assertNull("Container '$container' must never resolve as an audio MIME type", audioMime)
        }
    }

    @Test
    fun testCodecMimeTypeResolution_Video() {
        assertEquals("video/avc", DecoderCapabilityManager.resolveMimeType("h264", isVideo = true))
        assertEquals("video/avc", DecoderCapabilityManager.resolveMimeType("avc", isVideo = true))
        assertEquals("video/avc", DecoderCapabilityManager.resolveMimeType("avc1", isVideo = true))
        assertEquals("video/avc", DecoderCapabilityManager.resolveMimeType("H.264", isVideo = true))
        assertEquals("video/avc", DecoderCapabilityManager.resolveMimeType("x264", isVideo = true))

        assertEquals("video/hevc", DecoderCapabilityManager.resolveMimeType("hevc", isVideo = true))
        assertEquals("video/hevc", DecoderCapabilityManager.resolveMimeType("h265", isVideo = true))
        assertEquals("video/hevc", DecoderCapabilityManager.resolveMimeType("H.265", isVideo = true))
        assertEquals("video/hevc", DecoderCapabilityManager.resolveMimeType("hev1", isVideo = true))
        assertEquals("video/hevc", DecoderCapabilityManager.resolveMimeType("hvc1", isVideo = true))

        assertEquals("video/x-vnd.on2.vp9", DecoderCapabilityManager.resolveMimeType("vp9", isVideo = true))
        assertEquals("video/x-vnd.on2.vp9", DecoderCapabilityManager.resolveMimeType("vp09", isVideo = true))

        assertEquals("video/x-vnd.on2.vp8", DecoderCapabilityManager.resolveMimeType("vp8", isVideo = true))
        assertEquals("video/av01", DecoderCapabilityManager.resolveMimeType("av1", isVideo = true))
        assertEquals("video/av01", DecoderCapabilityManager.resolveMimeType("av01", isVideo = true))
    }

    @Test
    fun testCodecMimeTypeResolution_Audio() {
        assertEquals("audio/mp4a-latm", DecoderCapabilityManager.resolveMimeType("aac", isVideo = false))
        assertEquals("audio/mp4a-latm", DecoderCapabilityManager.resolveMimeType("mp4a", isVideo = false))
        assertEquals("audio/mpeg", DecoderCapabilityManager.resolveMimeType("mp3", isVideo = false))
        assertEquals("audio/ac3", DecoderCapabilityManager.resolveMimeType("ac3", isVideo = false))
        assertEquals("audio/eac3", DecoderCapabilityManager.resolveMimeType("eac3", isVideo = false))
        assertEquals("audio/eac3", DecoderCapabilityManager.resolveMimeType("e-ac-3", isVideo = false))
        assertEquals("audio/vnd.dts", DecoderCapabilityManager.resolveMimeType("dts", isVideo = false))
        assertEquals("audio/vnd.dts.hd", DecoderCapabilityManager.resolveMimeType("dts-hd", isVideo = false))
        assertEquals("audio/true-hd", DecoderCapabilityManager.resolveMimeType("truehd", isVideo = false))
        assertEquals("audio/flac", DecoderCapabilityManager.resolveMimeType("flac", isVideo = false))
        assertEquals("audio/opus", DecoderCapabilityManager.resolveMimeType("opus", isVideo = false))
        assertEquals("audio/vorbis", DecoderCapabilityManager.resolveMimeType("vorbis", isVideo = false))
        assertEquals("audio/raw", DecoderCapabilityManager.resolveMimeType("pcm_s16le", isVideo = false))
    }

    // =========================================================================
    // 2. BIT DEPTH RESOLUTION TESTS
    // =========================================================================

    @Test
    fun testBitDepthResolution_Standard8Bit() {
        val formats8Bit = listOf(
            "yuv420p", "nv12", "nv21", "yuvj420p", "yuv422p", "yuvj422p",
            "yuv444p", "yuvj444p", "rgb24", "bgr24", "rgba", "bgra", "argb",
            "yuyv422", "uyvy422", "yuv411p", "yuv410p", "gray"
        )
        for (fmt in formats8Bit) {
            assertEquals("Format '$fmt' must resolve to 8-bit", 8, DecoderCapabilityManager.resolveBitDepth(fmt))
            assertFalse("Format '$fmt' must not be 10-bit", DecoderCapabilityManager.is10BitPixelFormat(fmt))
        }
    }

    @Test
    fun testBitDepthResolution_10BitAndHigher() {
        val formats10Bit = listOf("yuv420p10le", "yuv420p10be", "yuv422p10le", "yuv444p10le", "p010le", "p010")
        for (fmt in formats10Bit) {
            assertEquals("Format '$fmt' must resolve to 10-bit", 10, DecoderCapabilityManager.resolveBitDepth(fmt))
            assertTrue("Format '$fmt' must be 10-bit", DecoderCapabilityManager.is10BitPixelFormat(fmt))
        }

        assertEquals(12, DecoderCapabilityManager.resolveBitDepth("yuv420p12le"))
        assertEquals(14, DecoderCapabilityManager.resolveBitDepth("yuv420p14le"))
        assertEquals(16, DecoderCapabilityManager.resolveBitDepth("yuv420p16le"))
    }

    @Test
    fun testBitDepthResolution_UnknownsRemainUnknown() {
        assertEquals(-1, DecoderCapabilityManager.resolveBitDepth(null))
        assertEquals(-1, DecoderCapabilityManager.resolveBitDepth(""))
        assertEquals(-1, DecoderCapabilityManager.resolveBitDepth("   "))
        assertEquals(-1, DecoderCapabilityManager.resolveBitDepth("custom_unknown_fmt"))
    }

    // =========================================================================
    // 3. PROFILE & LEVEL NORMALIZATION TESTS
    // =========================================================================

    @Test
    fun testProfileNormalization_H264() {
        assertEquals("High", DecoderCapabilityManager.normalizeProfile("video/avc", "High"))
        assertEquals("High", DecoderCapabilityManager.normalizeProfile("video/avc", "100"))
        assertEquals("High", DecoderCapabilityManager.normalizeProfile("video/avc", "profile100"))
        assertEquals("High 10", DecoderCapabilityManager.normalizeProfile("video/avc", "High 10"))
        assertEquals("High 10", DecoderCapabilityManager.normalizeProfile("video/avc", "110"))
        assertEquals("High 10", DecoderCapabilityManager.normalizeProfile("video/avc", "profile110"))
        assertEquals("Main", DecoderCapabilityManager.normalizeProfile("video/avc", "Main"))
        assertEquals("Baseline", DecoderCapabilityManager.normalizeProfile("video/avc", "Baseline"))
        assertEquals("Constrained Baseline", DecoderCapabilityManager.normalizeProfile("video/avc", "Constrained Baseline"))
    }

    @Test
    fun testProfileNormalization_HEVC() {
        assertEquals("Main", DecoderCapabilityManager.normalizeProfile("video/hevc", "Main"))
        assertEquals("Main", DecoderCapabilityManager.normalizeProfile("video/hevc", "1"))
        assertEquals("Main 10", DecoderCapabilityManager.normalizeProfile("video/hevc", "Main 10"))
        assertEquals("Main 10", DecoderCapabilityManager.normalizeProfile("video/hevc", "2"))
        assertEquals("Main 10", DecoderCapabilityManager.normalizeProfile("video/hevc", "profile2"))
        assertEquals("Main 10 HDR10", DecoderCapabilityManager.normalizeProfile("video/hevc", "Main 10 HDR10"))
        assertEquals("Main 10 HDR10", DecoderCapabilityManager.normalizeProfile("video/hevc", "4096"))
        assertEquals("Main 10 HDR10+", DecoderCapabilityManager.normalizeProfile("video/hevc", "Main 10 HDR10+"))
        assertEquals("Main 10 HDR10+", DecoderCapabilityManager.normalizeProfile("video/hevc", "8192"))
    }

    @Test
    fun testProfileNormalization_VP9() {
        assertEquals("Profile 0", DecoderCapabilityManager.normalizeProfile("video/x-vnd.on2.vp9", "0"))
        assertEquals("Profile 0", DecoderCapabilityManager.normalizeProfile("video/x-vnd.on2.vp9", "Profile 0"))
        assertEquals("Profile 2", DecoderCapabilityManager.normalizeProfile("video/x-vnd.on2.vp9", "2"))
        assertEquals("Profile 2", DecoderCapabilityManager.normalizeProfile("video/x-vnd.on2.vp9", "Profile 2"))
    }

    @Test
    fun testProfileNormalization_UnknownRemainsUnknown() {
        assertEquals("UNKNOWN", DecoderCapabilityManager.normalizeProfile("video/avc", null))
        assertEquals("UNKNOWN", DecoderCapabilityManager.normalizeProfile("video/avc", ""))
        assertEquals("UNKNOWN", DecoderCapabilityManager.normalizeProfile("video/avc", "N/A"))
        assertEquals("UNKNOWN", DecoderCapabilityManager.normalizeProfile("video/avc", "unknown"))
    }

    @Test
    fun testLevelNormalization_AllCodecs() {
        assertEquals("4.1", DecoderCapabilityManager.normalizeLevel("video/avc", "41"))
        assertEquals("4.1", DecoderCapabilityManager.normalizeLevel("video/avc", "4.1"))
        assertEquals("5.1", DecoderCapabilityManager.normalizeLevel("video/avc", "51"))
        assertEquals("5.1", DecoderCapabilityManager.normalizeLevel("video/hevc", "153"))
        assertEquals("5.1", DecoderCapabilityManager.normalizeLevel("video/hevc", "5.1"))
        assertEquals("5.1", DecoderCapabilityManager.normalizeLevel("video/x-vnd.on2.vp9", "51"))
        assertEquals("5.1", DecoderCapabilityManager.normalizeLevel("video/x-vnd.on2.vp9", "5.1"))

        assertEquals("UNKNOWN", DecoderCapabilityManager.normalizeLevel("video/avc", null))
        assertEquals("UNKNOWN", DecoderCapabilityManager.normalizeLevel("video/avc", "-99"))
        assertEquals("UNKNOWN", DecoderCapabilityManager.normalizeLevel("video/avc", "0"))
        assertEquals("UNKNOWN", DecoderCapabilityManager.normalizeLevel("video/avc", "unknown"))
    }

    // =========================================================================
    // 4. PROFILE & PIXEL FORMAT MISMATCH DETECTION
    // =========================================================================

    @Test
    fun testProfilePixelFormatMismatch_H264HighWith10BitPixelFormat() {
        val hasMismatch = DecoderCapabilityManager.checkProfilePixelFormatMismatch(
            mimeType = "video/avc",
            profileStr = "High",
            pixelFormat = "yuv420p10le",
            resolvedBitDepth = 10
        )
        assertTrue("H.264 High (8-bit profile) with yuv420p10le (10-bit) must flag mismatch", hasMismatch)
    }

    @Test
    fun testProfilePixelFormatMismatch_H264HighWith8BitPixelFormat_NoMismatch() {
        val hasMismatch = DecoderCapabilityManager.checkProfilePixelFormatMismatch(
            mimeType = "video/avc",
            profileStr = "High",
            pixelFormat = "yuv420p",
            resolvedBitDepth = 8
        )
        assertFalse("H.264 High with yuv420p must NOT flag mismatch", hasMismatch)
    }

    @Test
    fun testProfilePixelFormatMismatch_HEVCMainWith10BitPixelFormat() {
        val hasMismatch = DecoderCapabilityManager.checkProfilePixelFormatMismatch(
            mimeType = "video/hevc",
            profileStr = "Main",
            pixelFormat = "yuv420p10le",
            resolvedBitDepth = 10
        )
        assertTrue("HEVC Main (8-bit profile) with yuv420p10le (10-bit) must flag mismatch", hasMismatch)
    }

    @Test
    fun testProfilePixelFormatMismatch_HEVCMain10With10BitPixelFormat_NoMismatch() {
        val hasMismatch = DecoderCapabilityManager.checkProfilePixelFormatMismatch(
            mimeType = "video/hevc",
            profileStr = "Main 10",
            pixelFormat = "yuv420p10le",
            resolvedBitDepth = 10
        )
        assertFalse("HEVC Main 10 with yuv420p10le must NOT flag mismatch", hasMismatch)
    }

    // =========================================================================
    // 5. ORIENTATION & RESOLUTION DETERMINATION TESTS
    // =========================================================================

    @Test
    fun testOrientationDetermination() {
        assertEquals("portrait", DecoderCapabilityManager.determineOrientation(1080, 1920))
        assertEquals("landscape", DecoderCapabilityManager.determineOrientation(1920, 1080))
        assertEquals("square", DecoderCapabilityManager.determineOrientation(1080, 1080))
        assertEquals("unknown", DecoderCapabilityManager.determineOrientation(0, 0))
        assertEquals("unknown", DecoderCapabilityManager.determineOrientation(-1, 1080))
    }

    // =========================================================================
    // 6. VIDEO DECODER ASSESSMENT COMPATIBILITY MATRIX TESTS
    // =========================================================================

    @Test
    fun testAssessVideoDecoder_H264High8Bit_StandardProfile() {
        val assessment = DecoderCapabilityManager.assessVideoDecoder(
            trackIndex = 0,
            codec = "h264",
            requestedProfile = "High",
            requestedLevel = "4.1",
            bitDepth = 8,
            pixelFormat = "yuv420p",
            width = 1920,
            height = 1080,
            frameRate = 30f
        )

        assertEquals("video/avc", assessment.mimeType)
        assertEquals("High", assessment.requestedProfile)
        assertEquals("4.1", assessment.requestedLevel)
        assertEquals(8, assessment.requestedBitDepth)
        assertFalse(assessment.hasProfileMismatch)
        assertTrue("H.264 8-bit standard stream should be supported", assessment.isSupported)
        assertEquals(CapabilityStatus.COMPATIBLE, assessment.capabilityStatus)
        assertEquals(IncompatibilityReason.NONE, assessment.primaryReason)
    }

    @Test
    fun testAssessVideoDecoder_HEVCMain10_10Bit() {
        val assessment = DecoderCapabilityManager.assessVideoDecoder(
            trackIndex = 0,
            codec = "hevc",
            requestedProfile = "Main 10",
            requestedLevel = "5.1",
            bitDepth = 10,
            pixelFormat = "yuv420p10le",
            width = 3840,
            height = 2160,
            frameRate = 60f
        )

        assertEquals("video/hevc", assessment.mimeType)
        assertEquals("Main 10", assessment.requestedProfile)
        assertEquals("5.1", assessment.requestedLevel)
        assertEquals(10, assessment.requestedBitDepth)
        assertFalse(assessment.hasProfileMismatch)
    }

    @Test
    fun testAssessVideoDecoder_UnknownCodec_Incompatible() {
        val assessment = DecoderCapabilityManager.assessVideoDecoder(
            trackIndex = 0,
            codec = "non_existent_custom_codec",
            width = 1280,
            height = 720
        )

        assertFalse(assessment.isSupported)
        assertEquals(CapabilityStatus.INCOMPATIBLE, assessment.capabilityStatus)
        assertEquals(IncompatibilityReason.CODEC_UNSUPPORTED, assessment.primaryReason)
    }

    // =========================================================================
    // 7. AUDIO DECODER ASSESSMENT COMPATIBILITY MATRIX TESTS
    // =========================================================================

    @Test
    fun testAssessAudioDecoder_AAC() {
        val assessment = DecoderCapabilityManager.assessAudioDecoder(
            trackIndex = 1,
            codec = "aac",
            channels = 2,
            sampleRate = 48000
        )

        assertEquals("audio/mp4a-latm", assessment.mimeType)
        assertEquals(2, assessment.requestedChannels)
        assertEquals(48000, assessment.requestedSampleRate)
    }

    @Test
    fun testAssessAudioDecoder_UnknownAudioCodec_Incompatible() {
        val assessment = DecoderCapabilityManager.assessAudioDecoder(
            trackIndex = 1,
            codec = "unknown_super_audio_codec",
            channels = 6,
            sampleRate = 96000
        )

        assertFalse(assessment.isSupported)
        assertEquals(CapabilityStatus.INCOMPATIBLE, assessment.capabilityStatus)
        assertEquals(IncompatibilityReason.AUDIO_UNSUPPORTED, assessment.primaryReason)
    }

    // =========================================================================
    // 8. INDEPENDENCE OF VIDEO, AUDIO, AND SUBTITLES
    // =========================================================================

    @Test
    fun testStreamAssessmentsIndependent() {
        val videoStreams = listOf(
            VideoStreamInfo(
                index = 0,
                codec = "h264",
                codecLongName = "H.264 / AVC",
                profile = "High",
                level = "4.1",
                bitDepth = 8,
                pixelFormat = "yuv420p",
                width = 1920,
                height = 1080,
                frameRate = 30f,
                isDefault = true
            )
        )

        val audioStreams = listOf(
            AudioStreamInfo(
                index = 1,
                codec = "unknown_codec",
                sampleRate = 48000,
                channels = 6,
                isDefault = true
            )
        )

        val report = DecoderCapabilityManager.detectAndroidDecoderCapabilities(videoStreams, audioStreams)
        assertEquals(1, report.videoAssessments.size)
        assertEquals(1, report.audioAssessments.size)

        val vAss = report.videoAssessments[0]
        val aAss = report.audioAssessments[0]

        // Video assessment should be evaluated on video properties alone
        assertTrue("Video should be supported independently of audio", vAss.isSupported)
        // Audio is unsupported because codec is unknown
        assertFalse("Audio should be unsupported independently of video", aAss.isSupported)
    }

    // =========================================================================
    // 9. FORMATTED REPORT VALIDATION
    // =========================================================================

    @Test
    fun testFormattedReport_ContainsStructuredSections() {
        val videoStreams = listOf(
            VideoStreamInfo(
                index = 0,
                codec = "h264",
                codecLongName = "H.264 / AVC",
                profile = "High",
                level = "4.1",
                bitDepth = 8,
                pixelFormat = "yuv420p",
                width = 1920,
                height = 1080,
                frameRate = 30f,
                isDefault = true
            )
        )

        val audioStreams = listOf(
            AudioStreamInfo(
                index = 1,
                codec = "aac",
                sampleRate = 48000,
                channels = 2,
                isDefault = true
            )
        )

        val report = DecoderCapabilityManager.detectAndroidDecoderCapabilities(videoStreams, audioStreams)
        val text = report.toFormattedReport()

        assertTrue(text.contains("# ANDROID DECODER CAPABILITY"))
        assertTrue(text.contains("VIDEO"))
        assertTrue(text.contains("AUDIO"))
        assertTrue(text.contains("Codec: H.264"))
        assertTrue(text.contains("Codec: AAC"))
    }
}
