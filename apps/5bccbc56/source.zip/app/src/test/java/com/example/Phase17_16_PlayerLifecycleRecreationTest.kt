package com.example

import android.content.Context
import android.net.Uri
import androidx.media3.common.MimeTypes
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.example.media.DefaultMediaEngine
import com.example.media.playback.AuthoritativePlaybackResult
import com.example.media.playback.PlaybackRequestCoordinator
import com.example.media.playback.PlaybackSource
import com.example.media.playback.PlaybackSourceType
import kotlinx.coroutines.test.runTest
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.annotation.Config
import java.io.File

@RunWith(AndroidJUnit4::class)
@Config(sdk = [34])
class Phase17_16_PlayerLifecycleRecreationTest {

    private lateinit var context: Context

    @Before
    fun setup() {
        context = ApplicationProvider.getApplicationContext()
        PlaybackRequestCoordinator.resetForTesting()
    }

    @After
    fun tearDown() {
        PlaybackRequestCoordinator.resetForTesting()
    }

    @Test
    fun test1_H264_DirectPlayback_PlayerRecreation_PreservesRequestIdAndSource() = runTest {
        val mediaKey = "media_h264_001"
        val originalUri = Uri.parse("file:///storage/emulated/0/Movies/sample_h264.mp4")

        // 1. Initial Player Instance
        val mediaEngine1 = DefaultMediaEngine(context)
        val playerInstance1 = mediaEngine1.playerInstanceId
        PlaybackRequestCoordinator.setActivePlayerInstanceId(playerInstance1)

        val (req1, isNew1) = PlaybackRequestCoordinator.getOrCreateRequest(
            mediaKey = mediaKey,
            originalUri = originalUri,
            originalPath = originalUri.path!!
        )
        assertTrue("First request must be newly created", isNew1)
        val initialReqId = req1.requestId

        val directSource = PlaybackSource(
            sourceType = PlaybackSourceType.ORIGINAL,
            uri = originalUri,
            originalUri = originalUri,
            path = originalUri.path,
            requestId = initialReqId,
            container = "mp4",
            codec = "h264"
        )
        PlaybackRequestCoordinator.updateActiveSource(initialReqId, directSource)

        val prepared1 = mediaEngine1.preparePlaybackSource(
            source = directSource,
            activeRequestIdProvider = { initialReqId }
        )
        assertTrue("MediaEngine1 must prepare direct source", prepared1)
        assertEquals(originalUri, mediaEngine1.player.currentMediaItem?.localConfiguration?.uri)

        // Save progress before recreation (e.g., config change / rotation)
        PlaybackRequestCoordinator.savePosition(initialReqId, 12500L)
        PlaybackRequestCoordinator.savePlayWhenReady(initialReqId, true)

        // Simulate recreation: Engine 1 released
        mediaEngine1.release()
        PlaybackRequestCoordinator.setActivePlayerInstanceId(null)

        // 2. Recreated Player Instance
        val mediaEngine2 = DefaultMediaEngine(context)
        val playerInstance2 = mediaEngine2.playerInstanceId
        assertNotEquals("New player instance must have a new instance ID", playerInstance1, playerInstance2)
        PlaybackRequestCoordinator.setActivePlayerInstanceId(playerInstance2)

        // Recreated UI queries for request with same mediaKey
        val (req2, isNew2) = PlaybackRequestCoordinator.getOrCreateRequest(
            mediaKey = mediaKey,
            originalUri = originalUri,
            originalPath = originalUri.path!!
        )
        assertFalse("Recreated player must NOT mint a new request", isNew2)
        assertEquals("Request ID must be identical across recreation", initialReqId, req2.requestId)
        assertEquals("Authoritative source must be direct source", PlaybackSourceType.ORIGINAL, req2.activeSource?.sourceType)

        // Restore playback source into player 2
        val restored = mediaEngine2.restorePlaybackSource(req2, req2.requestId)
        assertTrue("MediaEngine2 must restore authoritative playback source", restored)
        assertEquals(originalUri, mediaEngine2.player.currentMediaItem?.localConfiguration?.uri)
        assertEquals("Restored position must match saved position", 12500L, req2.savedPositionMs)

        mediaEngine2.release()
    }

    @Test
    fun test2_FallbackPlayback_PlayerRecreation_PreservesValidatedFallbackSource() = runTest {
        val mediaKey = "media_hevc_10bit_002"
        val originalUri = Uri.parse("content://media/external/video/media/10bit_sample")
        val fallbackFile = File(context.cacheDir, "test_validated_fallback.mp4")
        fallbackFile.writeText("valid_fallback_bytes")
        val fallbackUri = Uri.fromFile(fallbackFile)

        // 1. Initial Player Instance
        val mediaEngine1 = DefaultMediaEngine(context)
        val playerInstance1 = mediaEngine1.playerInstanceId
        PlaybackRequestCoordinator.setActivePlayerInstanceId(playerInstance1)

        val (req1, _) = PlaybackRequestCoordinator.getOrCreateRequest(
            mediaKey = mediaKey,
            originalUri = originalUri,
            originalPath = "content://media/external/video/media/10bit_sample"
        )
        val reqId = req1.requestId

        // Fallback transcode completed and validated
        val fallbackSource = PlaybackSource(
            sourceType = PlaybackSourceType.FALLBACK,
            uri = fallbackUri,
            originalUri = originalUri,
            path = fallbackFile.absolutePath,
            mimeType = MimeTypes.VIDEO_MP4,
            requestId = reqId,
            container = "mp4",
            codec = "h264"
        )
        PlaybackRequestCoordinator.updateActiveSource(reqId, fallbackSource)
        PlaybackRequestCoordinator.markFallbackCompleted(
            requestId = reqId,
            fallbackUri = fallbackUri,
            fallbackPath = fallbackFile.absolutePath,
            ffmpegSuccess = true
        )

        val prepared1 = mediaEngine1.preparePlaybackSource(
            source = fallbackSource,
            startPositionMs = 30000L,
            activeRequestIdProvider = { reqId }
        )
        assertTrue(prepared1)
        assertEquals(fallbackUri, mediaEngine1.player.currentMediaItem?.localConfiguration?.uri)

        // Save position and release player 1
        PlaybackRequestCoordinator.savePosition(reqId, 45000L)
        PlaybackRequestCoordinator.savePlayWhenReady(reqId, true)
        mediaEngine1.release()
        PlaybackRequestCoordinator.setActivePlayerInstanceId(null)

        // 2. Recreated Player Instance
        val mediaEngine2 = DefaultMediaEngine(context)
        PlaybackRequestCoordinator.setActivePlayerInstanceId(mediaEngine2.playerInstanceId)

        val (req2, isNew2) = PlaybackRequestCoordinator.getOrCreateRequest(
            mediaKey = mediaKey,
            originalUri = originalUri,
            originalPath = "content://media/external/video/media/10bit_sample"
        )
        assertFalse("Recreated player must reuse existing request", isNew2)
        assertEquals("Request ID must be preserved", reqId, req2.requestId)
        assertNotNull("Authoritative source must be present", req2.activeSource)
        assertEquals("Source must remain FALLBACK", PlaybackSourceType.FALLBACK, req2.activeSource?.sourceType)
        assertEquals("URI must remain validated fallback URI (no revert to original)", fallbackUri, req2.activeSource?.uri)

        // Restore into new player
        val restored = mediaEngine2.restorePlaybackSource(req2, req2.requestId)
        assertTrue("MediaEngine2 must restore fallback source", restored)
        assertEquals("MediaEngine2 player must play fallback URI", fallbackUri, mediaEngine2.player.currentMediaItem?.localConfiguration?.uri)
        assertEquals(45000L, req2.savedPositionMs)

        mediaEngine2.release()
        fallbackFile.delete()
    }

    @Test
    fun test3_StalePlayerCallbackSuppression() = runTest {
        val mediaKey = "media_stale_test"
        val originalUri = Uri.parse("file:///storage/emulated/0/sample.mp4")

        val mediaEngine1 = DefaultMediaEngine(context)
        val playerInstance1 = mediaEngine1.playerInstanceId
        PlaybackRequestCoordinator.setActivePlayerInstanceId(playerInstance1)

        val (req, _) = PlaybackRequestCoordinator.getOrCreateRequest(
            mediaKey = mediaKey,
            originalUri = originalUri,
            originalPath = originalUri.path!!
        )
        val reqId = req.requestId

        // Now recreate player: instance 2 becomes active
        val mediaEngine2 = DefaultMediaEngine(context)
        val playerInstance2 = mediaEngine2.playerInstanceId
        PlaybackRequestCoordinator.setActivePlayerInstanceId(playerInstance2)

        // Old player callback guard check
        val acceptedOldInstance = PlaybackRequestCoordinator.isCallbackAccepted(
            requestId = reqId,
            callbackPlayerInstanceId = playerInstance1,
            event = "onPlaybackStateChanged"
        )
        assertFalse("Callbacks from old player instance must be suppressed", acceptedOldInstance)

        // New player callback guard check
        val acceptedNewInstance = PlaybackRequestCoordinator.isCallbackAccepted(
            requestId = reqId,
            callbackPlayerInstanceId = playerInstance2,
            event = "onPlaybackStateChanged"
        )
        assertTrue("Callbacks from active player instance must be accepted", acceptedNewInstance)

        // Old request ID callback guard check
        val acceptedStaleReq = PlaybackRequestCoordinator.isCallbackAccepted(
            requestId = "stale_unknown_req",
            callbackPlayerInstanceId = playerInstance2,
            event = "onPlaybackStateChanged"
        )
        assertFalse("Callbacks with unknown/stale requestId must be suppressed", acceptedStaleReq)

        mediaEngine1.release()
        mediaEngine2.release()
    }

    @Test
    fun test4_DuplicatePreparationGuard() = runTest {
        val mediaEngine = DefaultMediaEngine(context)
        val originalUri = Uri.parse("file:///storage/emulated/0/dup_test.mp4")
        val reqId = "req_dup_001"

        val source = PlaybackSource(
            sourceType = PlaybackSourceType.ORIGINAL,
            uri = originalUri,
            originalUri = originalUri,
            path = originalUri.path,
            requestId = reqId,
            container = "mp4",
            codec = "h264"
        )

        // First preparation
        val prepared1 = mediaEngine.preparePlaybackSource(
            source = source,
            activeRequestIdProvider = { reqId }
        )
        assertTrue("First prepare call must succeed", prepared1)
        assertNotNull(mediaEngine.player.currentMediaItem)

        // Second duplicate preparation on same engine & same request
        val prepared2 = mediaEngine.preparePlaybackSource(
            source = source,
            activeRequestIdProvider = { reqId }
        )
        assertFalse("Duplicate prepare call on same player instance and request must be a no-op", prepared2)

        mediaEngine.release()
    }

    @Test
    fun test5_TerminalStatePreservedAcrossPlayerRecreations() = runTest {
        val mediaKey = "media_terminal_test"
        val originalUri = Uri.parse("file:///storage/emulated/0/terminal.mp4")

        val mediaEngine1 = DefaultMediaEngine(context)
        PlaybackRequestCoordinator.setActivePlayerInstanceId(mediaEngine1.playerInstanceId)

        val (req, _) = PlaybackRequestCoordinator.getOrCreateRequest(
            mediaKey = mediaKey,
            originalUri = originalUri,
            originalPath = originalUri.path!!
        )
        val reqId = req.requestId

        // Mark terminal
        PlaybackRequestCoordinator.markTerminal(
            requestId = reqId,
            state = "DIRECT_SUCCESS",
            terminalResult = AuthoritativePlaybackResult.DIRECT_SUCCESS
        )

        assertTrue("Request must be marked terminal", req.isTerminal)
        assertEquals("DIRECT_SUCCESS", req.currentPlaybackState)
        assertEquals(AuthoritativePlaybackResult.DIRECT_SUCCESS, req.terminalResult)

        // Recreate player
        mediaEngine1.release()
        val mediaEngine2 = DefaultMediaEngine(context)
        PlaybackRequestCoordinator.setActivePlayerInstanceId(mediaEngine2.playerInstanceId)

        val (reqAfterRecreate, _) = PlaybackRequestCoordinator.getOrCreateRequest(
            mediaKey = mediaKey,
            originalUri = originalUri,
            originalPath = originalUri.path!!
        )

        assertTrue("Terminal status must persist across recreation", reqAfterRecreate.isTerminal)
        assertEquals("Terminal state must be preserved", "DIRECT_SUCCESS", reqAfterRecreate.currentPlaybackState)
        assertEquals(AuthoritativePlaybackResult.DIRECT_SUCCESS, reqAfterRecreate.terminalResult)

        mediaEngine2.release()
    }
}
