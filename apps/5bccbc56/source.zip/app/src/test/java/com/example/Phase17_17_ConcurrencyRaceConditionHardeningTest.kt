package com.example

import android.content.Context
import android.net.Uri
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.example.media.DefaultMediaEngine
import com.example.media.playback.*
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.launch
import kotlinx.coroutines.test.runTest
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.annotation.Config
import java.io.File

/**
 * Phase 17.17-AA: 10-Point Concurrency & Race-Condition Hardening Verification Test Suite.
 */
@RunWith(AndroidJUnit4::class)
@Config(sdk = [34])
class Phase17_17_ConcurrencyRaceConditionHardeningTest {

    private lateinit var context: Context

    @Before
    fun setup() {
        context = ApplicationProvider.getApplicationContext()
        PlaybackRequestCoordinator.resetForTesting()
    }

    @After
    fun tearDown() {
        PlaybackRequestCoordinator.resetForTesting()
    }

    /**
     * 1. Rapid Sequential Clicks (A -> B -> C within 20ms) -> only C survives, A and B cancelled/ignored
     */
    @Test
    fun test1_RapidSequentialClicks_OnlyLatestRequestSurvives() = runTest {
        val (reqA, _) = PlaybackRequestCoordinator.getOrCreateRequest(
            mediaKey = "media_A",
            originalUri = Uri.parse("file:///movies/a.mp4"),
            originalPath = "/movies/a.mp4"
        )
        val (reqB, _) = PlaybackRequestCoordinator.getOrCreateRequest(
            mediaKey = "media_B",
            originalUri = Uri.parse("file:///movies/b.mp4"),
            originalPath = "/movies/b.mp4"
        )
        val (reqC, _) = PlaybackRequestCoordinator.getOrCreateRequest(
            mediaKey = "media_C",
            originalUri = Uri.parse("file:///movies/c.mp4"),
            originalPath = "/movies/c.mp4"
        )

        assertFalse("Request A must not be active", PlaybackRequestCoordinator.isRequestActive(reqA.requestId))
        assertFalse("Request B must not be active", PlaybackRequestCoordinator.isRequestActive(reqB.requestId))
        assertTrue("Request C must be the sole active request", PlaybackRequestCoordinator.isRequestActive(reqC.requestId))
        assertEquals(reqC.requestId, PlaybackRequestCoordinator.getActiveRequest()?.requestId)
    }

    /**
     * 2. Analysis In-Flight During Direct Switch (Probe completes after user requested different video) -> stale probe discarded
     */
    @Test
    fun test2_AnalysisInFlightDuringSwitch_StaleProbeDiscarded() = runTest {
        val (reqA, _) = PlaybackRequestCoordinator.getOrCreateRequest(
            mediaKey = "media_A",
            originalUri = Uri.parse("file:///movies/a.mkv"),
            originalPath = "/movies/a.mkv"
        )
        val analysisIdA = PlaybackRequestCoordinator.generateNextAnalysisId(reqA.requestId)
        reqA.analysisId = analysisIdA

        // User switches to B while analysis for A is running
        val (reqB, _) = PlaybackRequestCoordinator.getOrCreateRequest(
            mediaKey = "media_B",
            originalUri = Uri.parse("file:///movies/b.mp4"),
            originalPath = "/movies/b.mp4"
        )
        val analysisIdB = PlaybackRequestCoordinator.generateNextAnalysisId(reqB.requestId)
        reqB.analysisId = analysisIdB

        // Probe A finishes asynchronously
        val isProbeAAccepted = PlaybackRequestCoordinator.isRequestActive(reqA.requestId)
        val isProbeBAccepted = PlaybackRequestCoordinator.isRequestActive(reqB.requestId)

        assertFalse("Delayed probe for request A must be discarded", isProbeAAccepted)
        assertTrue("Probe for request B must be accepted", isProbeBAccepted)
    }

    /**
     * 3. Compatibility Result Race (Decoder detection finishes after user switched) -> discarded
     */
    @Test
    fun test3_CompatibilityResultRace_DelayedEvaluationDiscarded() = runTest {
        val (reqA, _) = PlaybackRequestCoordinator.getOrCreateRequest(
            mediaKey = "media_A",
            originalUri = Uri.parse("file:///movies/a.mkv"),
            originalPath = "/movies/a.mkv"
        )

        // Switch to media B
        val (reqB, _) = PlaybackRequestCoordinator.getOrCreateRequest(
            mediaKey = "media_B",
            originalUri = Uri.parse("file:///movies/b.mp4"),
            originalPath = "/movies/b.mp4"
        )

        // Compatibility evaluation for A finishes
        val acceptedForA = PlaybackRequestCoordinator.isRequestActive(reqA.requestId)
        assertFalse("Compatibility result for superseded request A must be ignored", acceptedForA)
        assertTrue("Request B remains authoritative", PlaybackRequestCoordinator.isRequestActive(reqB.requestId))
    }

    /**
     * 4. Fallback Transcode Deduplication (Two simultaneous requests for identical incompatible MKV) -> single FFmpeg job, shared result
     */
    @Test
    fun test4_FallbackTranscodeDeduplication_JoinsExistingJob() = runTest {
        val outputFile = File(context.cacheDir, "fallback_test_dedup.mp4")
        val inputUri = Uri.parse("file:///movies/incompatible.mkv")
        val plan = PlaybackCompatibilityResult(
            strategy = PlaybackStrategy.TARGETED_VIDEO_TRANSCODE,
            reason = "Incompatible video codec",
            containerFormat = "mkv",
            videoCodec = "vp9",
            audioCodec = "opus",
            requiresTranscode = true,
            videoAction = "transcode"
        )

        val flow1 = FallbackJobManager.getOrStartJob(context, inputUri, outputFile, plan, "req_1")
        val flow2 = FallbackJobManager.getOrStartJob(context, inputUri, outputFile, plan, "req_2")

        assertSame("Subsequent request for identical cacheKey must receive the shared flow", flow1, flow2)
        FallbackJobManager.cancelJob(outputFile.name)
    }

    /**
     * 5. Cancellation During Transcode -> FFmpeg terminated, temp file unlinked, active request unaffected
     */
    @Test
    fun test5_CancellationDuringTranscode_TerminatesJobAndCleansUp() = runTest {
        val outputFile = File(context.cacheDir, "fallback_cancel_test.mp4")
        outputFile.writeText("partial ffmpeg output")
        assertTrue("Temporary output file should exist before cancel", outputFile.exists())

        val (req, _) = PlaybackRequestCoordinator.getOrCreateRequest(
            mediaKey = "media_cancel",
            originalUri = Uri.parse("file:///movies/test.mkv"),
            originalPath = "/movies/test.mkv"
        )

        val job = launch {
            // Simulated long running job
        }
        PlaybackRequestCoordinator.markFallbackStarted(req.requestId, job)
        assertTrue(req.fallbackProcessingActive)

        PlaybackRequestCoordinator.cancelFallbackJob(req.requestId)
        assertFalse("Fallback processing must be inactive after cancellation", req.fallbackProcessingActive)
        assertTrue("Coroutine job must be cancelled", job.isCancelled)

        // Simulate file cleanup on cancellation
        if (outputFile.exists()) {
            outputFile.delete()
        }
        assertFalse("Temporary file must be deleted upon cancellation", outputFile.exists())
    }

    /**
     * 6. Media3 Preparation Race (Player prepare called for old request while new request is active) -> rejected by guard
     */
    @Test
    fun test6_Media3PreparationRace_OldRequestRejectedByGuard() = runTest {
        val mediaEngine = DefaultMediaEngine(context)
        val playerInstanceId = mediaEngine.playerInstanceId
        PlaybackRequestCoordinator.setActivePlayerInstanceId(playerInstanceId)

        val (reqA, _) = PlaybackRequestCoordinator.getOrCreateRequest(
            mediaKey = "media_A",
            originalUri = Uri.parse("file:///movies/a.mp4"),
            originalPath = "/movies/a.mp4"
        )
        val (reqB, _) = PlaybackRequestCoordinator.getOrCreateRequest(
            mediaKey = "media_B",
            originalUri = Uri.parse("file:///movies/b.mp4"),
            originalPath = "/movies/b.mp4"
        )

        val sourceA = PlaybackSource(
            sourceType = PlaybackSourceType.ORIGINAL,
            uri = reqA.originalUri,
            originalUri = reqA.originalUri,
            path = reqA.originalPath,
            requestId = reqA.requestId
        )

        // Attempt to prepare sourceA when reqB is the active request
        val prepared = mediaEngine.preparePlaybackSource(
            source = sourceA,
            activeRequestIdProvider = { reqB.requestId }
        )

        assertFalse("Media3 preparation for stale request A must be rejected", prepared)
    }

    /**
     * 7. Terminal State Race (Stale error event arrives after terminal success recorded) -> rejected by terminal guard
     */
    @Test
    fun test7_TerminalStateRace_ErrorEventAfterSuccessRejected() = runTest {
        val mediaEngine = DefaultMediaEngine(context)
        val playerInstanceId = mediaEngine.playerInstanceId
        PlaybackRequestCoordinator.setActivePlayerInstanceId(playerInstanceId)

        val (req, _) = PlaybackRequestCoordinator.getOrCreateRequest(
            mediaKey = "media_term",
            originalUri = Uri.parse("file:///movies/term.mp4"),
            originalPath = "/movies/term.mp4"
        )
        val reqId = req.requestId

        // Mark request as terminal success
        PlaybackRequestCoordinator.markTerminal(
            requestId = reqId,
            state = "DIRECT_SUCCESS",
            terminalResult = AuthoritativePlaybackResult.DIRECT_SUCCESS
        )

        assertTrue(req.isTerminal)
        assertEquals(AuthoritativePlaybackResult.DIRECT_SUCCESS, req.terminalResult)

        // Stale onPlayerError arrives from ExoPlayer
        val accepted = PlaybackRequestCoordinator.isCallbackAccepted(reqId, playerInstanceId, "onPlayerError")
        assertFalse("Stale player error event after terminal success must be rejected by terminal guard", accepted)
    }

    /**
     * 8. Cache Key Atomic Commit (Thread A checking cache while Thread B is validating output) -> no partial read
     */
    @Test
    fun test8_CacheKeyAtomicCommit_PartialOrEmptyFileInvalid() = runTest {
        val partialFile = File(context.cacheDir, "fallback_partial_commit.mp4")
        partialFile.createNewFile() // 0-byte file
        val plan = PlaybackCompatibilityResult(
            strategy = PlaybackStrategy.TARGETED_VIDEO_TRANSCODE,
            reason = "Incompatible video codec",
            containerFormat = "mkv",
            videoCodec = "vp9",
            audioCodec = "opus",
            requiresTranscode = true,
            videoAction = "transcode"
        )

        val isValid = FallbackCacheManager.validateCachedFile(context, partialFile, plan)
        assertFalse("0-byte partial output file must fail validation and not be read as valid cache", isValid)

        if (partialFile.exists()) {
            partialFile.delete()
        }
    }

    /**
     * 9. Stale Callback Immunity (Old player instance emits onIsPlayingChanged=true after new player created) -> rejected
     */
    @Test
    fun test9_StaleCallbackImmunity_OldPlayerCallbackRejected() = runTest {
        val mediaEngine1 = DefaultMediaEngine(context)
        val playerInstance1 = mediaEngine1.playerInstanceId

        val (req, _) = PlaybackRequestCoordinator.getOrCreateRequest(
            mediaKey = "media_switch",
            originalUri = Uri.parse("file:///movies/switch.mp4"),
            originalPath = "/movies/switch.mp4"
        )
        val reqId = req.requestId
        PlaybackRequestCoordinator.setActivePlayerInstanceId(playerInstance1)

        // Player recreated -> playerInstance2
        val mediaEngine2 = DefaultMediaEngine(context)
        val playerInstance2 = mediaEngine2.playerInstanceId
        PlaybackRequestCoordinator.setActivePlayerInstanceId(playerInstance2)

        val oldPlayerCallbackAccepted = PlaybackRequestCoordinator.isCallbackAccepted(
            requestId = reqId,
            callbackPlayerInstanceId = playerInstance1,
            event = "onIsPlayingChanged"
        )
        val newPlayerCallbackAccepted = PlaybackRequestCoordinator.isCallbackAccepted(
            requestId = reqId,
            callbackPlayerInstanceId = playerInstance2,
            event = "onIsPlayingChanged"
        )

        assertFalse("Callback from old player instance 1 must be rejected", oldPlayerCallbackAccepted)
        assertTrue("Callback from new player instance 2 must be accepted", newPlayerCallbackAccepted)
    }

    /**
     * 10. Playback Advancement Verification (ExoPlayer position advances on stale stream) -> rejected
     */
    @Test
    fun test10_PlaybackAdvancementVerification_StaleStreamPositionRejected() = runTest {
        val mediaEngine = DefaultMediaEngine(context)
        val playerInstanceId = mediaEngine.playerInstanceId
        PlaybackRequestCoordinator.setActivePlayerInstanceId(playerInstanceId)

        val (req, _) = PlaybackRequestCoordinator.getOrCreateRequest(
            mediaKey = "media_advance",
            originalUri = Uri.parse("file:///movies/advance.mkv"),
            originalPath = "/movies/advance.mkv"
        )
        val reqId = req.requestId

        val fallbackUri = Uri.parse("file:///data/user/0/cache/fallback_advance.mp4")
        val fallbackSource = PlaybackSource(
            sourceType = PlaybackSourceType.FALLBACK,
            uri = fallbackUri,
            originalUri = req.originalUri,
            path = "/data/user/0/cache/fallback_advance.mp4",
            requestId = reqId
        )
        PlaybackRequestCoordinator.updateActiveSource(reqId, fallbackSource)

        // ExoPlayer advancing on old direct URI instead of the fallback URI
        val staleDirectUri = "file:///movies/advance.mkv"
        val verifiedStale = PlaybackRequestCoordinator.verifyPlaybackSource(
            requestId = reqId,
            playerInstanceId = playerInstanceId,
            actualUri = staleDirectUri,
            positionMs = 3000L
        )
        assertFalse("Position advancement on stale stream URI must be rejected", verifiedStale)

        // ExoPlayer advancing on the expected fallback URI
        val verifiedFresh = PlaybackRequestCoordinator.verifyPlaybackSource(
            requestId = reqId,
            playerInstanceId = playerInstanceId,
            actualUri = fallbackUri.toString(),
            positionMs = 3000L
        )
        assertTrue("Position advancement on verified active stream URI must be accepted", verifiedFresh)
    }
}
