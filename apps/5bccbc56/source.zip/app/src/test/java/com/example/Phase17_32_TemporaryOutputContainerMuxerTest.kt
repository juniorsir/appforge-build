package com.example

import android.content.Context
import android.net.Uri
import androidx.test.core.app.ApplicationProvider
import com.example.media.DecoderCapabilityManager
import com.example.media.ffmpeg.FFmpegProgress
import com.example.media.ffmpeg.FFmpegState
import com.example.media.operations.MediaConversionRequest
import com.example.media.playback.PlaybackErrorClassifier
import com.example.media.playback.PlaybackErrorCategory
import com.example.media.probe.AudioStreamInfo
import com.example.media.probe.VideoStreamInfo
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [33])
class Phase17_32_TemporaryOutputContainerMuxerTest {

    private lateinit var context: Context
    private lateinit var tempDir: File

    @Before
    fun setup() {
        context = ApplicationProvider.getApplicationContext()
        tempDir = File(context.cacheDir, "test_muxer_phase32").apply { mkdirs() }
    }

    @Test
    fun testExplicitMp4Muxer_ContainerSelectionForTemporaryExtensions() {
        val finalFile = File(tempDir, "fallback_12345.mp4")

        val request = MediaConversionRequest(
            inputUri = Uri.parse("file:///dummy.mkv"),
            outputFile = finalFile,
            videoCodec = "h264",
            audioCodec = "copy",
            container = "mp4"
        )

        // Verify request validation passes with container = "mp4"
        assertTrue("Request with container=mp4 must be valid", request.validate().isSuccess)

        // Verify container format inference logic
        val containerFormat = request.container ?: when {
            request.outputFile.name.contains(".mp4", ignoreCase = true) || request.outputFile.name.endsWith(".tmp", ignoreCase = true) -> "mp4"
            request.outputFile.name.contains(".mkv", ignoreCase = true) -> "matroska"
            request.outputFile.name.contains(".webm", ignoreCase = true) -> "webm"
            else -> "mp4"
        }

        assertEquals("Container format must be explicitly mp4", "mp4", containerFormat)
    }

    @Test
    fun testNegativeTest_ArbitraryTemporaryExtension_ResolvesToExplicitMp4Muxer() {
        val finalFile = File(tempDir, "fallback_test.randomtemporaryextension")

        val request = MediaConversionRequest(
            inputUri = Uri.parse("file:///dummy.mkv"),
            outputFile = finalFile,
            videoCodec = "h264",
            audioCodec = "copy",
            container = "mp4"
        )

        assertTrue(request.validate().isSuccess)
        val containerFormat = request.container ?: "mp4"
        assertEquals("Even with random extension, explicit container must be mp4", "mp4", containerFormat)
    }

    @Test
    fun testClassification_OutputFormatUndeterminedError() {
        val ffmpegError = IllegalStateException("Unable to choose an output format for 'fallback_123.mp4.tmp'; use a standard extension for the try or set -f")
        val progress = FFmpegProgress(
            sessionId = 123L,
            state = FFmpegState.FAILED,
            error = ffmpegError,
            logOutput = ffmpegError.message ?: ""
        )
        val classified = PlaybackErrorClassifier.classifyFfmpegProgress("req_123", "job_123", progress)

        assertNotNull(classified)
        assertEquals(
            "Must classify output format error as FFMPEG_OUTPUT_FORMAT_UNDETERMINED",
            PlaybackErrorCategory.FFMPEG_OUTPUT_FORMAT_UNDETERMINED,
            classified!!.category
        )
        assertTrue(
            "User message must mention output format",
            classified.userMessage.contains("Output format could not be determined", ignoreCase = true)
        )
    }

    @Test
    fun testMediaConversionRequest_ContainerValidation() {
        val validReq = MediaConversionRequest(
            inputUri = Uri.parse("file:///input.mkv"),
            outputFile = File(tempDir, "output.mp4"),
            videoCodec = "h264",
            container = "mp4"
        )
        assertTrue(validReq.validate().isSuccess)

        val invalidContainerReq = MediaConversionRequest(
            inputUri = Uri.parse("file:///input.mkv"),
            outputFile = File(tempDir, "output.xyz"),
            videoCodec = "h264",
            container = "unsupported_container_xyz"
        )
        assertTrue(invalidContainerReq.validate().isFailure)
    }

    @Test
    fun testRegression_H264DirectCapabilityAssessment() {
        val videoStreams = listOf(
            VideoStreamInfo(
                index = 0,
                codec = "h264",
                bitDepth = 8,
                pixelFormat = "yuv420p",
                width = 1920,
                height = 1080,
                frameRate = 30f,
                isDefault = true
            )
        )
        val audioStreams = listOf(
            AudioStreamInfo(
                index = 1,
                codec = "aac",
                sampleRate = 48000,
                channels = 2,
                isDefault = true
            )
        )

        val report = DecoderCapabilityManager.detectAndroidDecoderCapabilities(videoStreams, audioStreams)
        assertTrue("H.264 8-bit video should be natively supported", report.videoAssessments.first().isSupported)
        assertEquals(1, report.audioAssessments.size)
    }

    @Test
    fun testRegression_HEVCMain10_CapabilityAssessment() {
        val videoStreams = listOf(
            VideoStreamInfo(
                index = 0,
                codec = "hevc",
                profile = "Main 10",
                bitDepth = 10,
                pixelFormat = "yuv420p10le",
                width = 1920,
                height = 1080,
                frameRate = 24f,
                isDefault = true
            )
        )
        val audioStreams = listOf(
            AudioStreamInfo(
                index = 1,
                codec = "aac",
                sampleRate = 48000,
                channels = 2,
                isDefault = true
            )
        )

        val report = DecoderCapabilityManager.detectAndroidDecoderCapabilities(videoStreams, audioStreams)
        assertNotNull("Assessment report should exist", report)
        assertEquals(1, report.videoAssessments.size)
    }
}
