package com.example

import androidx.test.ext.junit.runners.AndroidJUnit4
import com.example.media.progressive.NativeMediaCodecProbe
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.annotation.Config

@RunWith(AndroidJUnit4::class)
@Config(sdk = [33])
class Phase17_44_NativeEncoderProbeTest {

    @Test
    fun testNativeEncoderProbe() {
        // Run the probe
        val result = NativeMediaCodecProbe.probeNativeH264Encoder()
        println("Probe Result: $result")
    }
}
