package com.example

import android.content.Context
import android.net.Uri
import androidx.test.core.app.ApplicationProvider
import com.example.media.AndroidEncoderInfo
import com.example.media.EncoderCapabilityManager
import com.example.media.EncoderProbeResult
import com.example.media.EncoderProbeStage
import com.example.media.ffmpeg.EncoderCandidate
import com.example.media.ffmpeg.H264EncoderSelector
import com.example.media.ffmpeg.SelectedH264Encoder
import com.example.media.operations.MediaConversionRequest
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [33])
class Phase17_31_H264EncoderSelectionTest {

    private lateinit var context: Context
    private lateinit var tempDir: File

    @Before
    fun setup() {
        context = ApplicationProvider.getApplicationContext()
        tempDir = File(context.cacheDir, "test_h264_encoder").apply { mkdirs() }
        H264EncoderSelector.resetCacheForTesting()
        EncoderCapabilityManager.resetCacheForTesting()
    }

    @After
    fun tearDown() {
        H264EncoderSelector.resetCacheForTesting()
        EncoderCapabilityManager.resetCacheForTesting()
    }

    @Test
    fun testH264EncoderDiscovery_ReturnsListWithoutCrashing() = runBlocking {
        val candidates = H264EncoderSelector.discoverH264Encoders()
        assertNotNull("Candidates list should not be null", candidates)
        for (candidate in candidates) {
            assertNotNull(candidate.name)
            assertNotNull(candidate.canonicalCodec)
            assertNotNull(candidate.description)
        }
    }

    @Test
    fun testSelectBestH264Encoder_ReturnsCandidateOrNullGracefully() = runBlocking {
        val best = H264EncoderSelector.selectBestH264Encoder(context)
        if (best != null) {
            assertTrue(
                "Selected encoder must be one of the known H.264 encoders, was: ${best.name}",
                best.name in listOf("libopenh264", "libx264", "h264_mediacodec", "h264_v4l2m2m")
            )
            assertTrue("Default profile must not be empty", best.defaultProfile.isNotEmpty())
            assertTrue("Default level must not be empty", best.defaultLevel.isNotEmpty())
            assertTrue("Recommended GOP must be >= 24", best.recommendedGop >= 24)
        }
    }

    @Test
    fun testSelectBestH264Encoder_WithMockAndFallback() = runBlocking {
        H264EncoderSelector.mockEncodersForTesting = listOf(
            EncoderCandidate("h264_mediacodec", true, "h264", "MediaCodec"),
            EncoderCandidate("libopenh264", false, "h264", "OpenH264"),
            EncoderCandidate("libx264", false, "h264", "x264")
        )
        // Force fail h264_mediacodec and libopenh264 to verify fallback down to libx264
        H264EncoderSelector.forceFailEncodersForTesting = setOf("h264_mediacodec", "libopenh264")

        val selected = H264EncoderSelector.selectBestH264Encoder(context)
        if (selected != null) {
            assertNotEquals("h264_mediacodec", selected.name)
            assertNotEquals("libopenh264", selected.name)
        }
    }

    @Test
    fun testQuarantineEncoder_BlocksSubsequentSelection() = runBlocking {
        H264EncoderSelector.mockEncodersForTesting = listOf(
            EncoderCandidate("h264_mediacodec", true, "h264", "MediaCodec"),
            EncoderCandidate("libopenh264", false, "h264", "OpenH264")
        )
        // Quarantine h264_mediacodec
        H264EncoderSelector.quarantineEncoder("h264_mediacodec", "Hardware encoder init failure in test")
        assertTrue(H264EncoderSelector.isQuarantined("h264_mediacodec"))
        assertEquals("Hardware encoder init failure in test", H264EncoderSelector.getQuarantineReason("h264_mediacodec"))

        // When selecting, it should bypass h264_mediacodec and evaluate libopenh264
        val selected = H264EncoderSelector.selectBestH264Encoder(context)
        if (selected != null) {
            assertNotEquals("h264_mediacodec", selected.name)
        }
    }

    @Test
    fun testEncoderCapabilityManager_DetectionAndHeuristics() {
        val mockQcomHw = AndroidEncoderInfo(
            name = "c2.qcom.avc.encoder",
            isHardware = true,
            isSoftware = false,
            maxWidth = 3840,
            maxHeight = 2160,
            supportedProfiles = listOf("Baseline", "Main", "High"),
            supportedLevels = listOf("4.0", "4.1", "5.1", "5.2"),
            colorFormatNames = listOf("COLOR_FormatYUV420Flexible", "COLOR_FormatSurface")
        )
        val mockGoogleSw = AndroidEncoderInfo(
            name = "c2.android.avc.encoder",
            isHardware = false,
            isSoftware = true,
            maxWidth = 1920,
            maxHeight = 1080,
            supportedProfiles = listOf("Baseline", "Main"),
            supportedLevels = listOf("4.0", "4.1")
        )

        EncoderCapabilityManager.mockEncodersForTesting = listOf(mockQcomHw, mockGoogleSw)

        val report = EncoderCapabilityManager.getEncoderCapabilityReport()
        assertTrue("Should detect hardware AVC encoder", report.hasHardwareAvcEncoder)
        assertEquals("c2.qcom.avc.encoder", report.preferredHwEncoderName)
        assertEquals("c2.android.avc.encoder", report.preferredSwEncoderName)

        val formatted = report.toFormattedReport()
        assertTrue(formatted.contains("ANDROID H.264 ENCODER CAPABILITIES"))
        assertTrue(formatted.contains("c2.qcom.avc.encoder"))

        assertTrue("Should support 1080p resolution", EncoderCapabilityManager.isResolutionSupportedByHwEncoder(1920, 1080))
        assertTrue("Should support 4K resolution", EncoderCapabilityManager.isResolutionSupportedByHwEncoder(3840, 2160))
        assertTrue("Should support High profile", EncoderCapabilityManager.isProfileSupportedByHwEncoder("high"))
        assertEquals("high", EncoderCapabilityManager.getPreferredHardwareProfile())
        assertEquals("4.1", EncoderCapabilityManager.getPreferredHardwareLevel("4.1"))
    }

    @Test
    fun testRecommendedGopCalculation() {
        assertEquals(48, H264EncoderSelector.calculateRecommendedGop(24f))
        assertEquals(47, H264EncoderSelector.calculateRecommendedGop(23.98f))
        assertEquals(60, H264EncoderSelector.calculateRecommendedGop(30f))
        assertEquals(120, H264EncoderSelector.calculateRecommendedGop(60f))
        assertEquals(48, H264EncoderSelector.calculateRecommendedGop(0f)) // Default safe fallback
    }

    @Test
    fun testH264LevelSanitization() {
        assertEquals("4.1", H264EncoderSelector.sanitizeH264Level("4.1"))
        assertEquals("4.1", H264EncoderSelector.sanitizeH264Level("41"))
        assertEquals("4.0", H264EncoderSelector.sanitizeH264Level("40"))
        assertEquals("4.0", H264EncoderSelector.sanitizeH264Level("4"))
        assertEquals("3.1", H264EncoderSelector.sanitizeH264Level("31"))
        assertEquals("5.1", H264EncoderSelector.sanitizeH264Level("51"))
        assertEquals("4.1", H264EncoderSelector.sanitizeH264Level(null))
        assertEquals("4.1", H264EncoderSelector.sanitizeH264Level(""))
    }

    @Test
    fun testBitrateCalculation_ProducesSensibleDefaults() {
        val bitrate1080p = H264EncoderSelector.calculateDefaultBitrateKbps(1920, 1080, 24f)
        val bitrate720p = H264EncoderSelector.calculateDefaultBitrateKbps(1280, 720, 30f)
        val bitrate480p = H264EncoderSelector.calculateDefaultBitrateKbps(854, 480, 30f)
        val bitrate4k = H264EncoderSelector.calculateDefaultBitrateKbps(3840, 2160, 60f)

        assertTrue("1080p bitrate should be between 2500 and 7000 kbps, was $bitrate1080p", bitrate1080p in 2500..7000)
        assertTrue("720p bitrate should be between 1200 and 4000 kbps, was $bitrate720p", bitrate720p in 1200..4000)
        assertTrue("480p bitrate should be between 500 and 2000 kbps, was $bitrate480p", bitrate480p in 500..2000)
        assertTrue("4K bitrate should be >= 10000 kbps, was $bitrate4k", bitrate4k >= 10000)
        assertTrue("1080p bitrate should be greater than 720p", bitrate1080p > bitrate720p)
    }

    @Test
    fun testMediaConversionRequest_ValidatesH264Codec() {
        val dummyInput = Uri.parse("content://dummy/video.mkv")
        val dummyOutput = File(tempDir, "output.mp4")

        val reqGenericH264 = MediaConversionRequest(
            inputUri = dummyInput,
            outputFile = dummyOutput,
            videoCodec = "h264",
            audioCodec = "copy"
        )
        val validationGeneric = reqGenericH264.validate()
        assertTrue("h264 should be a valid videoCodec", validationGeneric.isSuccess)

        val reqOpenH264 = MediaConversionRequest(
            inputUri = dummyInput,
            outputFile = dummyOutput,
            videoCodec = "libopenh264",
            audioCodec = "aac"
        )
        val validationOpen = reqOpenH264.validate()
        assertTrue("libopenh264 should be a valid videoCodec", validationOpen.isSuccess)

        val reqMediacodec = MediaConversionRequest(
            inputUri = dummyInput,
            outputFile = dummyOutput,
            videoCodec = "h264_mediacodec",
            audioCodec = "copy"
        )
        val validationMediacodec = reqMediacodec.validate()
        assertTrue("h264_mediacodec should be a valid videoCodec", validationMediacodec.isSuccess)
    }
}
