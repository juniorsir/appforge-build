package com.example

import android.content.Context
import android.net.Uri
import androidx.test.core.app.ApplicationProvider
import com.example.media.operations.FallbackValidator
import com.example.media.operations.MediaConversionRequest
import com.example.media.probe.AudioStreamInfo
import com.example.media.probe.MediaProbeInfo
import com.example.media.probe.VideoStreamInfo
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [33])
class Phase17_24_FallbackValidationTest {

    private lateinit var context: Context
    private lateinit var tempDir: File
    private lateinit var tempFile: File

    @Before
    fun setup() {
        context = ApplicationProvider.getApplicationContext()
        tempDir = File(context.cacheDir, "test_validation").apply { mkdirs() }
        tempFile = File(tempDir, "test_output.mp4").apply {
            writeText("dummy content so file size is > 0")
        }
    }

    private fun mockProbe(info: MediaProbeInfo?): suspend (Context, Uri) -> Result<MediaProbeInfo> {
        return { _, _ ->
            if (info == null) Result.failure(Exception("FFprobe failed")) else Result.success(info)
        }
    }

    private fun createMockInfo(
        format: String = "mp4",
        durationMs: Long = 5000L,
        videoCodec: String = "h264",
        videoProfile: String? = "High",
        pixFmt: String? = "yuv420p",
        bitDepth: Int = 8,
        width: Int = 1920,
        height: Int = 1080,
        fps: Float = 30f,
        audioCodec: String? = "aac",
        extraVideoStreams: Int = 0,
        extraAudioStreams: Int = 0
    ): MediaProbeInfo {
        val vStreams = mutableListOf<VideoStreamInfo>()
        vStreams.add(
            VideoStreamInfo(
                index = 0,
                codec = videoCodec,
                codecLongName = videoCodec,
                codecTag = null,
                profile = videoProfile,
                level = null,
                profileId = null,
                levelId = null,
                bitDepth = bitDepth,
                chromaSubsampling = "",
                hdrFormat = null,
                width = width,
                height = height,
                frameRate = fps,
                averageFrameRate = fps,
                bitrate = 1000L,
                durationMs = durationMs,
                pixelFormat = pixFmt,
                colorSpace = null,
                colorPrimaries = null,
                transferCharacteristics = null,
                rotation = 0,
                language = "und",
                isDefault = true,
                isForced = false
            )
        )
        for (i in 1..extraVideoStreams) {
            vStreams.add(vStreams.first().copy(index = i))
        }

        val aStreams = mutableListOf<AudioStreamInfo>()
        if (audioCodec != null) {
            aStreams.add(
                AudioStreamInfo(
                    index = 1,
                    codec = audioCodec,
                    codecLongName = audioCodec,
                    codecTag = null,
                    profile = null,
                    sampleRate = 44100,
                    channels = 2,
                    channelLayout = "stereo",
                    sampleFormat = "fltp",
                    bitrate = 128L,
                    durationMs = durationMs,
                    language = "und",
                    title = null,
                    isDefault = true,
                    isForced = false
                )
            )
            for (i in 1..extraAudioStreams) {
                aStreams.add(aStreams.first().copy(index = 1 + i))
            }
        }

        return MediaProbeInfo(
            pathOrUri = tempFile.absolutePath,
            format = format,
            formatLongName = format,
            durationMs = durationMs,
            sizeBytes = 1000L,
            overallBitrate = 1000L,
            streamCount = vStreams.size + aStreams.size,
            videoStreams = vStreams,
            audioStreams = aStreams,
            subtitleStreams = emptyList(),
            otherStreams = emptyList(),
            metadataTags = emptyMap(),
            rawProperties = null,
            androidDecoderCapability = null
        )
    }

    private val defaultRequest = MediaConversionRequest(
        inputUri = Uri.parse("content://dummy"),
        outputFile = File("dummy"),
        videoCodec = "libx264",
        audioCodec = "aac"
    )

    @Test
    fun testValidOutput() = runBlocking {
        // 1. H264 High + yuv420p + 8-bit + AAC
        val info1 = createMockInfo(videoProfile = "High", pixFmt = "yuv420p", bitDepth = 8)
        var result = FallbackValidator.validateFallbackOutput(context, tempFile, defaultRequest, false, mockProbe(info1))
        assertTrue(result.isSuccess)

        // 2. H264 Main + yuv420p + 8-bit + AAC
        val info2 = createMockInfo(videoProfile = "Main", pixFmt = "yuv420p", bitDepth = 8)
        result = FallbackValidator.validateFallbackOutput(context, tempFile, defaultRequest, false, mockProbe(info2))
        assertTrue(result.isSuccess)

        // 3. portrait H264 1080x1920
        val info3 = createMockInfo(width = 1080, height = 1920)
        result = FallbackValidator.validateFallbackOutput(context, tempFile, defaultRequest, false, mockProbe(info3))
        assertTrue(result.isSuccess)

        // 4. fractional FPS
        val info4 = createMockInfo(fps = 23.976f)
        result = FallbackValidator.validateFallbackOutput(context, tempFile, defaultRequest, false, mockProbe(info4))
        assertTrue(result.isSuccess)

        // 5. valid short-duration video
        val info5 = createMockInfo(durationMs = 100L)
        result = FallbackValidator.validateFallbackOutput(context, tempFile, defaultRequest, false, mockProbe(info5))
        assertTrue(result.isSuccess)
    }

    @Test
    fun testInvalidVideoProfileAndFormat() = runBlocking {
        // 6. H264 High10
        val info6 = createMockInfo(videoProfile = "High 10", pixFmt = "yuv420p10le", bitDepth = 10)
        var result = FallbackValidator.validateFallbackOutput(context, tempFile, defaultRequest, false, mockProbe(info6))
        assertTrue(result.isFailure)
        assertTrue(result.exceptionOrNull()?.message?.contains("VIDEO_PIXEL_FORMAT_INVALID") == true || result.exceptionOrNull()?.message?.contains("METADATA_INCONSISTENT") == true || result.exceptionOrNull()?.message?.contains("VIDEO_BIT_DEPTH_INVALID") == true)

        // 7. H264 + yuv420p10le (contradiction if bitDepth is 8)
        val info7 = createMockInfo(videoProfile = "High", pixFmt = "yuv420p10le", bitDepth = 8)
        result = FallbackValidator.validateFallbackOutput(context, tempFile, defaultRequest, false, mockProbe(info7))
        assertTrue(result.isFailure)
        assertTrue(result.exceptionOrNull()?.message?.contains("METADATA_INCONSISTENT") == true)
        
        // 8. H264 + yuv422p
        val info8 = createMockInfo(videoProfile = "High 4:2:2", pixFmt = "yuv422p", bitDepth = 8)
        result = FallbackValidator.validateFallbackOutput(context, tempFile, defaultRequest, false, mockProbe(info8))
        assertTrue(result.isFailure)
        assertTrue(result.exceptionOrNull()?.message?.contains("VIDEO_PIXEL_FORMAT_INVALID") == true)

        // 9. H264 + yuv444p
        val info9 = createMockInfo(videoProfile = "High 4:4:4", pixFmt = "yuv444p", bitDepth = 8)
        result = FallbackValidator.validateFallbackOutput(context, tempFile, defaultRequest, false, mockProbe(info9))
        assertTrue(result.isFailure)
        assertTrue(result.exceptionOrNull()?.message?.contains("VIDEO_PIXEL_FORMAT_INVALID") == true)
    }

    @Test
    fun testInvalidCodecs() = runBlocking {
        // 10. HEVC output
        val info10 = createMockInfo(videoCodec = "hevc")
        var result = FallbackValidator.validateFallbackOutput(context, tempFile, defaultRequest, false, mockProbe(info10))
        assertTrue(result.isFailure)
        assertTrue(result.exceptionOrNull()?.message?.contains("VIDEO_CODEC_INVALID") == true)

        // 11. VP9 output
        val info11 = createMockInfo(videoCodec = "vp9")
        result = FallbackValidator.validateFallbackOutput(context, tempFile, defaultRequest, false, mockProbe(info11))
        assertTrue(result.isFailure)
        assertTrue(result.exceptionOrNull()?.message?.contains("VIDEO_CODEC_INVALID") == true)
    }

    @Test
    fun testStreamMappingIssues() = runBlocking {
        // 12. missing video stream
        // (mocking an info with no video streams)
        val info12 = createMockInfo().copy(videoStreams = emptyList())
        var result = FallbackValidator.validateFallbackOutput(context, tempFile, defaultRequest, false, mockProbe(info12))
        assertTrue(result.isFailure)
        assertTrue(result.exceptionOrNull()?.message?.contains("OUTPUT_MISSING") == true)

        // 13. missing required audio
        val info13 = createMockInfo(audioCodec = null)
        result = FallbackValidator.validateFallbackOutput(context, tempFile, defaultRequest, false, mockProbe(info13))
        assertTrue(result.isFailure)
        assertTrue(result.exceptionOrNull()?.message?.contains("AUDIO_MISSING") == true)

        // 14. invalid AAC (expected aac but got mp3)
        val info14 = createMockInfo(audioCodec = "mp3")
        result = FallbackValidator.validateFallbackOutput(context, tempFile, defaultRequest, false, mockProbe(info14))
        assertTrue(result.isFailure)
        assertTrue(result.exceptionOrNull()?.message?.contains("AUDIO_CODEC_INVALID") == true)

        // 22. wrong stream mapping (extra video stream)
        val info22 = createMockInfo(extraVideoStreams = 1)
        result = FallbackValidator.validateFallbackOutput(context, tempFile, defaultRequest, false, mockProbe(info22))
        assertTrue(result.isFailure)
        assertTrue(result.exceptionOrNull()?.message?.contains("STREAM_MAPPING_INVALID") == true)
    }

    @Test
    fun testContainerAndDurationIssues() = runBlocking {
        // 15. & 16. missing/zero duration
        val info15 = createMockInfo(durationMs = 0L)
        var result = FallbackValidator.validateFallbackOutput(context, tempFile, defaultRequest, false, mockProbe(info15))
        assertTrue(result.isFailure)
        assertTrue(result.exceptionOrNull()?.message?.contains("VIDEO_DURATION_INVALID") == true)

        // 17. FFprobe failure
        result = FallbackValidator.validateFallbackOutput(context, tempFile, defaultRequest, false, mockProbe(null))
        assertTrue(result.isFailure)
        assertTrue(result.exceptionOrNull()?.message?.contains("FFPROBE_FAILED") == true)

        // 18. missing output
        val missingFile = File(tempDir, "does_not_exist.mp4")
        result = FallbackValidator.validateFallbackOutput(context, missingFile, defaultRequest, false, mockProbe(createMockInfo()))
        assertTrue(result.isFailure)
        assertTrue(result.exceptionOrNull()?.message?.contains("OUTPUT_MISSING") == true)

        // 19. zero-byte output
        val zeroFile = File(tempDir, "zero.mp4").apply { createNewFile() }
        result = FallbackValidator.validateFallbackOutput(context, zeroFile, defaultRequest, false, mockProbe(createMockInfo()))
        assertTrue(result.isFailure)
        assertTrue(result.exceptionOrNull()?.message?.contains("OUTPUT_EMPTY") == true)

        // 21. wrong container
        val info21 = createMockInfo(format = "matroska")
        result = FallbackValidator.validateFallbackOutput(context, tempFile, defaultRequest, false, mockProbe(info21))
        assertTrue(result.isFailure)
        assertTrue(result.exceptionOrNull()?.message?.contains("CONTAINER_INVALID") == true)
    }

    @Test
    fun testContradictoryMetadata() = runBlocking {
        // 20. contradictory profile/pixel-format metadata
        // e.g. bitDepth = 10 but pixFmt = yuv420p
        val info20 = createMockInfo(videoProfile = "High", pixFmt = "yuv420p", bitDepth = 10)
        val result = FallbackValidator.validateFallbackOutput(context, tempFile, defaultRequest, false, mockProbe(info20))
        assertTrue(result.isFailure)
        assertTrue(result.exceptionOrNull()?.message?.contains("METADATA_INCONSISTENT") == true)
    }
}
