package com.example

import androidx.media3.common.PlaybackException
import com.example.media.playback.*
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner

@RunWith(RobolectricTestRunner::class)
class Phase17_27_DecisionEngineTest {

    private fun createCompat(strategy: PlaybackStrategy): PlaybackCompatibilityResult {
        return PlaybackCompatibilityResult(
            strategy = strategy,
            reason = "test",
            containerFormat = "mp4",
            videoCodec = "h264",
            audioCodec = "aac"
        )
    }

    private fun createRuntimeError(code: Int): PlaybackException {
        return PlaybackException("Error", null, code)
    }

    private fun testMatrix(
        sourceType: PlaybackSourceType,
        strategy: PlaybackStrategy,
        errorCode: Int?,
        isCancelled: Boolean,
        isStale: Boolean,
        expectedAction: PlaybackAction
    ) {
        val decision = PlaybackDecisionEngine.makeDecision(
            requestId = "1",
            sourceType = sourceType,
            probeInfo = null,
            compatibilityResult = createCompat(strategy),
            runtimeException = errorCode?.let { createRuntimeError(it) },
            isCancelled = isCancelled,
            isStale = isStale
        )
        assertEquals(expectedAction, decision.action)
    }

    // ORIGINAL SOURCE TESTS (1-18)
    @Test fun t01() = testMatrix(PlaybackSourceType.ORIGINAL, PlaybackStrategy.DIRECT_HARDWARE, null, false, false, PlaybackAction.DIRECT)
    @Test fun t02() = testMatrix(PlaybackSourceType.ORIGINAL, PlaybackStrategy.DIRECT_SAFE, null, false, false, PlaybackAction.DIRECT)
    @Test fun t03() = testMatrix(PlaybackSourceType.ORIGINAL, PlaybackStrategy.DIRECT_ATTEMPT, null, false, false, PlaybackAction.DIRECT_ATTEMPT)
    @Test fun t04() = testMatrix(PlaybackSourceType.ORIGINAL, PlaybackStrategy.REMUX_REQUIRED, null, false, false, PlaybackAction.REMUX)
    @Test fun t05() = testMatrix(PlaybackSourceType.ORIGINAL, PlaybackStrategy.FULL_TRANSCODE_REQUIRED, null, false, false, PlaybackAction.FALLBACK)
    @Test fun t06() = testMatrix(PlaybackSourceType.ORIGINAL, PlaybackStrategy.DIRECT_HARDWARE, PlaybackException.ERROR_CODE_DECODER_INIT_FAILED, false, false, PlaybackAction.FALLBACK)
    @Test fun t07() = testMatrix(PlaybackSourceType.ORIGINAL, PlaybackStrategy.DIRECT_SAFE, PlaybackException.ERROR_CODE_DECODING_FAILED, false, false, PlaybackAction.FALLBACK)
    @Test fun t08() = testMatrix(PlaybackSourceType.ORIGINAL, PlaybackStrategy.DIRECT_ATTEMPT, PlaybackException.ERROR_CODE_DECODER_INIT_FAILED, false, false, PlaybackAction.FALLBACK)
    @Test fun t09() = testMatrix(PlaybackSourceType.ORIGINAL, PlaybackStrategy.DIRECT_HARDWARE, PlaybackException.ERROR_CODE_IO_FILE_NOT_FOUND, false, false, PlaybackAction.FAIL)
    @Test fun t10() = testMatrix(PlaybackSourceType.ORIGINAL, PlaybackStrategy.DIRECT_ATTEMPT, PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED, false, false, PlaybackAction.FAIL)
    
    // CANCELLATION & STALE TESTS (11-20)
    @Test fun t11() = testMatrix(PlaybackSourceType.ORIGINAL, PlaybackStrategy.DIRECT_HARDWARE, null, true, false, PlaybackAction.CANCELLED)
    @Test fun t12() = testMatrix(PlaybackSourceType.ORIGINAL, PlaybackStrategy.DIRECT_ATTEMPT, null, true, false, PlaybackAction.CANCELLED)
    @Test fun t13() = testMatrix(PlaybackSourceType.ORIGINAL, PlaybackStrategy.FULL_TRANSCODE_REQUIRED, null, true, false, PlaybackAction.CANCELLED)
    @Test fun t14() = testMatrix(PlaybackSourceType.ORIGINAL, PlaybackStrategy.DIRECT_HARDWARE, PlaybackException.ERROR_CODE_DECODER_INIT_FAILED, true, false, PlaybackAction.CANCELLED)
    @Test fun t15() = testMatrix(PlaybackSourceType.ORIGINAL, PlaybackStrategy.DIRECT_HARDWARE, null, false, true, PlaybackAction.STALE)
    @Test fun t16() = testMatrix(PlaybackSourceType.ORIGINAL, PlaybackStrategy.DIRECT_ATTEMPT, null, false, true, PlaybackAction.STALE)
    @Test fun t17() = testMatrix(PlaybackSourceType.ORIGINAL, PlaybackStrategy.FULL_TRANSCODE_REQUIRED, null, false, true, PlaybackAction.STALE)
    @Test fun t18() = testMatrix(PlaybackSourceType.ORIGINAL, PlaybackStrategy.DIRECT_HARDWARE, PlaybackException.ERROR_CODE_DECODER_INIT_FAILED, false, true, PlaybackAction.STALE)
    @Test fun t19() = testMatrix(PlaybackSourceType.ORIGINAL, PlaybackStrategy.DIRECT_HARDWARE, null, true, true, PlaybackAction.CANCELLED)
    @Test fun t20() = testMatrix(PlaybackSourceType.FALLBACK, PlaybackStrategy.DIRECT_HARDWARE, null, true, false, PlaybackAction.CANCELLED)

    // FALLBACK SOURCE TESTS (21-30)
    @Test fun t21() = testMatrix(PlaybackSourceType.FALLBACK, PlaybackStrategy.DIRECT_HARDWARE, null, false, false, PlaybackAction.DIRECT)
    @Test fun t22() = testMatrix(PlaybackSourceType.FALLBACK, PlaybackStrategy.DIRECT_ATTEMPT, null, false, false, PlaybackAction.DIRECT)
    @Test fun t23() = testMatrix(PlaybackSourceType.FALLBACK, PlaybackStrategy.FULL_TRANSCODE_REQUIRED, null, false, false, PlaybackAction.DIRECT) // Assuming static compat doesn't override fallback success
    @Test fun t24() = testMatrix(PlaybackSourceType.FALLBACK, PlaybackStrategy.DIRECT_HARDWARE, PlaybackException.ERROR_CODE_DECODER_INIT_FAILED, false, false, PlaybackAction.FAIL)
    @Test fun t25() = testMatrix(PlaybackSourceType.FALLBACK, PlaybackStrategy.DIRECT_ATTEMPT, PlaybackException.ERROR_CODE_DECODER_INIT_FAILED, false, false, PlaybackAction.FAIL)
    @Test fun t26() = testMatrix(PlaybackSourceType.FALLBACK, PlaybackStrategy.FULL_TRANSCODE_REQUIRED, PlaybackException.ERROR_CODE_DECODER_INIT_FAILED, false, false, PlaybackAction.FAIL)
    @Test fun t27() = testMatrix(PlaybackSourceType.FALLBACK, PlaybackStrategy.DIRECT_HARDWARE, PlaybackException.ERROR_CODE_IO_FILE_NOT_FOUND, false, false, PlaybackAction.FAIL)
    @Test fun t28() = testMatrix(PlaybackSourceType.FALLBACK, PlaybackStrategy.DIRECT_HARDWARE, null, false, true, PlaybackAction.STALE)
    @Test fun t29() = testMatrix(PlaybackSourceType.FALLBACK, PlaybackStrategy.DIRECT_HARDWARE, PlaybackException.ERROR_CODE_DECODER_INIT_FAILED, false, true, PlaybackAction.STALE)
    @Test fun t30() = testMatrix(PlaybackSourceType.FALLBACK, PlaybackStrategy.DIRECT_HARDWARE, PlaybackException.ERROR_CODE_DECODER_INIT_FAILED, true, false, PlaybackAction.CANCELLED)
    
    // EDGE CASES (31-35)
    @Test fun t31() = testMatrix(PlaybackSourceType.ORIGINAL, PlaybackStrategy.REMUX_REQUIRED, PlaybackException.ERROR_CODE_DECODER_INIT_FAILED, false, false, PlaybackAction.FALLBACK)
    @Test fun t32() = testMatrix(PlaybackSourceType.ORIGINAL, PlaybackStrategy.REMUX_REQUIRED, PlaybackException.ERROR_CODE_IO_FILE_NOT_FOUND, false, false, PlaybackAction.FAIL)
    @Test fun t33() = testMatrix(PlaybackSourceType.ORIGINAL, PlaybackStrategy.FULL_TRANSCODE_REQUIRED, PlaybackException.ERROR_CODE_DECODER_INIT_FAILED, false, false, PlaybackAction.FALLBACK)
    @Test fun t34() = testMatrix(PlaybackSourceType.ORIGINAL, PlaybackStrategy.FULL_TRANSCODE_REQUIRED, PlaybackException.ERROR_CODE_IO_FILE_NOT_FOUND, false, false, PlaybackAction.FAIL)
}
