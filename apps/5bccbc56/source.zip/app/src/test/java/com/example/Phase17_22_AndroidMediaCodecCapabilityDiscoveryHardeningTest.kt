package com.example

import com.example.media.*
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

/**
 * PHASE 17.22 — Android MediaCodec Capability Discovery Hardening Test Suite.
 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class Phase17_22_AndroidMediaCodecCapabilityDiscoveryHardeningTest {

    // =========================================================================
    // 1. CODEC MIME TYPE NORMALIZATION & RESOLUTION
    // =========================================================================

    @Test
    fun testCodecMimeTypeNormalization() {
        assertEquals("video/avc", DecoderCapabilityManager.resolveMimeType("h264", isVideo = true))
        assertEquals("video/avc", DecoderCapabilityManager.resolveMimeType("avc1", isVideo = true))
        assertEquals("video/hevc", DecoderCapabilityManager.resolveMimeType("h265", isVideo = true))
        assertEquals("video/hevc", DecoderCapabilityManager.resolveMimeType("hevc", isVideo = true))
        assertEquals("video/hevc", DecoderCapabilityManager.resolveMimeType("hev1", isVideo = true))
        assertEquals("video/x-vnd.on2.vp9", DecoderCapabilityManager.resolveMimeType("vp9", isVideo = true))
        assertEquals("video/x-vnd.on2.vp8", DecoderCapabilityManager.resolveMimeType("vp8", isVideo = true))
        assertEquals("video/av01", DecoderCapabilityManager.resolveMimeType("av1", isVideo = true))
        assertEquals("audio/mp4a-latm", DecoderCapabilityManager.resolveMimeType("aac", isVideo = false))
        assertEquals("audio/mpeg", DecoderCapabilityManager.resolveMimeType("mp3", isVideo = false))
        assertEquals("audio/opus", DecoderCapabilityManager.resolveMimeType("opus", isVideo = false))
    }

    // =========================================================================
    // 2. PROFILE & LEVEL NORMALIZATION AND CONSTANT MAPPING
    // =========================================================================

    @Test
    fun testProfileNormalizationAndConstantMapping() {
        val h264Mime = "video/avc"
        assertEquals("High", DecoderCapabilityManager.normalizeProfile(h264Mime, "High"))
        assertEquals("Constrained Baseline", DecoderCapabilityManager.normalizeProfile(h264Mime, "Constrained Baseline"))
        assertEquals("Baseline", DecoderCapabilityManager.normalizeProfile(h264Mime, "Baseline"))
        assertEquals("Main", DecoderCapabilityManager.normalizeProfile(h264Mime, "Main"))
        assertEquals("High 10", DecoderCapabilityManager.normalizeProfile(h264Mime, "High 10"))

        val hevcMime = "video/hevc"
        assertEquals("Main 10", DecoderCapabilityManager.normalizeProfile(hevcMime, "Main 10"))
        assertEquals("Main", DecoderCapabilityManager.normalizeProfile(hevcMime, "Main"))

        val vp9Mime = "video/x-vnd.on2.vp9"
        assertEquals("Profile 0", DecoderCapabilityManager.normalizeProfile(vp9Mime, "Profile 0"))
        assertEquals("Profile 2", DecoderCapabilityManager.normalizeProfile(vp9Mime, "Profile 2"))

        // Level normalization
        assertEquals("4.1", DecoderCapabilityManager.normalizeLevel(h264Mime, "4.1"))
        assertEquals("5.1", DecoderCapabilityManager.normalizeLevel(hevcMime, "5.1"))
    }

    // =========================================================================
    // 3. BIT-DEPTH DERIVATION & 8-BIT VS 10-BIT SEPARATION
    // =========================================================================

    @Test
    fun testBitDepthDerivationFromPixelFormat() {
        assertEquals(8, DecoderCapabilityManager.resolveBitDepth("yuv420p"))
        assertEquals(8, DecoderCapabilityManager.resolveBitDepth("yuvj420p"))
        assertEquals(8, DecoderCapabilityManager.resolveBitDepth("nv12"))
        assertEquals(8, DecoderCapabilityManager.resolveBitDepth("nv21"))
        assertEquals(10, DecoderCapabilityManager.resolveBitDepth("yuv420p10le"))
        assertEquals(10, DecoderCapabilityManager.resolveBitDepth("yuv422p10le"))
        assertEquals(10, DecoderCapabilityManager.resolveBitDepth("p010le"))
        assertEquals(12, DecoderCapabilityManager.resolveBitDepth("yuv420p12le"))
    }

    @Test
    fun testH264High8BitDoesNotReportFalse10BitIncompatibility() {
        // H.264 High profile with 8-bit pixel format (yuv420p) must be assessed as 8-bit compatible
        val assessment = DecoderCapabilityManager.assessVideoDecoder(
            trackIndex = 0,
            codec = "h264",
            requestedProfile = "High",
            requestedLevel = "4.1",
            bitDepth = 8,
            pixelFormat = "yuv420p",
            width = 1920,
            height = 1080,
            frameRate = 30f
        )

        assertEquals("video/avc", assessment.mimeType)
        assertEquals(8, assessment.requestedBitDepth)
        assertFalse(assessment.hasProfileMismatch)
        // Must not be flagged as BIT_DEPTH_UNSUPPORTED
        assertNotEquals(IncompatibilityReason.BIT_DEPTH_UNSUPPORTED, assessment.primaryReason)
    }

    @Test
    fun testH264High10BitIdentifies10BitConstraint() {
        val assessment = DecoderCapabilityManager.assessVideoDecoder(
            trackIndex = 0,
            codec = "h264",
            requestedProfile = "High 10",
            requestedLevel = "5.1",
            bitDepth = 10,
            pixelFormat = "yuv420p10le",
            width = 1920,
            height = 1080,
            frameRate = 30f
        )

        assertEquals("video/avc", assessment.mimeType)
        assertEquals(10, assessment.requestedBitDepth)
    }

    // =========================================================================
    // 4. ORIENTATION & RESOLUTION CAPABILITY DISCOVERY
    // =========================================================================

    @Test
    fun testOrientationDetermination() {
        assertEquals("landscape", DecoderCapabilityManager.determineOrientation(1920, 1080))
        assertEquals("portrait", DecoderCapabilityManager.determineOrientation(1080, 1920))
        assertEquals("square", DecoderCapabilityManager.determineOrientation(1080, 1080))
        assertEquals("unknown", DecoderCapabilityManager.determineOrientation(0, 0))
    }

    @Test
    fun testPortraitResolutionAssessmentPreservesCompatibility() {
        // A vertical video (1080x1920) should not fail purely due to width/height orientation inversion
        val assessment = DecoderCapabilityManager.assessVideoDecoder(
            trackIndex = 0,
            codec = "hevc",
            requestedProfile = "Main",
            requestedLevel = "4.0",
            bitDepth = 8,
            pixelFormat = "yuv420p",
            width = 1080,
            height = 1920,
            frameRate = 30f
        )

        assertEquals("video/hevc", assessment.mimeType)
        assertEquals(8, assessment.requestedBitDepth)
        // Orientation swap must not trigger false RESOLUTION_UNSUPPORTED
        assertNotEquals(IncompatibilityReason.RESOLUTION_UNSUPPORTED, assessment.primaryReason)
    }

    // =========================================================================
    // 5. CANDIDATE DECODER DISCOVERY & ENUMERATION
    // =========================================================================

    @Test
    fun testCandidateDecoderEnumeration() {
        val assessment = DecoderCapabilityManager.assessVideoDecoder(
            trackIndex = 0,
            codec = "h264",
            requestedProfile = "High",
            requestedLevel = "4.1",
            bitDepth = 8,
            pixelFormat = "yuv420p",
            width = 1280,
            height = 720,
            frameRate = 30f
        )

        assertNotNull(assessment.candidateDecoders)
        // All candidate decoders should have the correct MIME type
        for (candidate in assessment.candidateDecoders) {
            assertEquals("video/avc", candidate.mimeType)
            assertNotNull(candidate.classification)
        }
    }

    // =========================================================================
    // 6. UNKNOWN VS UNSUPPORTED SEMANTICS
    // =========================================================================

    @Test
    fun testUnknownCodecProducesUnsupportedStatus() {
        val assessment = DecoderCapabilityManager.assessVideoDecoder(
            trackIndex = 0,
            codec = "custom_unknown_codec_xyz",
            requestedProfile = null,
            requestedLevel = null,
            bitDepth = -1,
            pixelFormat = null,
            width = 0,
            height = 0,
            frameRate = 0f
        )

        assertEquals("video/unknown", assessment.mimeType)
        assertFalse(assessment.isSupported)
        assertEquals(CapabilityStatus.INCOMPATIBLE, assessment.capabilityStatus)
        assertEquals(IncompatibilityReason.CODEC_UNSUPPORTED, assessment.primaryReason)
    }
}
