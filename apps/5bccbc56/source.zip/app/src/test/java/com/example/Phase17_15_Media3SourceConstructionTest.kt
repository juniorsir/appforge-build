package com.example

import android.content.Context
import android.net.Uri
import androidx.media3.common.MimeTypes
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.example.media.DefaultMediaEngine
import com.example.media.playback.Media3SourceBuilder
import com.example.media.playback.PlaybackSource
import com.example.media.playback.PlaybackSourceType
import kotlinx.coroutines.test.runTest
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.annotation.Config
import java.io.File

@RunWith(AndroidJUnit4::class)
@Config(sdk = [34])
class Phase17_15_Media3SourceConstructionTest {

    private lateinit var context: Context

    @Before
    fun setup() {
        context = ApplicationProvider.getApplicationContext()
    }

    @Test
    fun test1_H264_MP4_DirectPlaybackSourceConstruction() = runTest {
        val originalUri = Uri.parse("file:///storage/emulated/0/Download/sample_h264.mp4")
        val source = PlaybackSource(
            sourceType = PlaybackSourceType.ORIGINAL,
            uri = originalUri,
            originalUri = originalUri,
            path = originalUri.path,
            requestId = "req_test_1",
            container = "mp4",
            codec = "h264"
        )

        val mediaItem = Media3SourceBuilder.buildMediaItem(source)

        // Invariant 1: DIRECT -> MediaItem URI == original URI
        assertEquals(originalUri, mediaItem.localConfiguration?.uri)
        assertEquals(MimeTypes.VIDEO_MP4, mediaItem.localConfiguration?.mimeType)
    }

    @Test
    fun test2_H264_MKV_DirectPlaybackSourceConstruction() = runTest {
        val mkvUri = Uri.parse("file:///storage/emulated/0/Download/sample_h264.mkv")
        val source = PlaybackSource(
            sourceType = PlaybackSourceType.ORIGINAL,
            uri = mkvUri,
            originalUri = mkvUri,
            path = mkvUri.path,
            requestId = "req_test_2",
            container = "matroska",
            codec = "h264"
        )

        val mediaItem = Media3SourceBuilder.buildMediaItem(source)

        // Invariant 1: DIRECT -> MediaItem URI == original URI
        assertEquals(mkvUri, mediaItem.localConfiguration?.uri)
        assertEquals(MimeTypes.VIDEO_MATROSKA, mediaItem.localConfiguration?.mimeType)
    }

    @Test
    fun test3_VP9_WebM_DirectPlaybackSourceConstruction() = runTest {
        val webmUri = Uri.parse("file:///storage/emulated/0/Download/sample_vp9.webm")
        val source = PlaybackSource(
            sourceType = PlaybackSourceType.ORIGINAL,
            uri = webmUri,
            originalUri = webmUri,
            path = webmUri.path,
            requestId = "req_test_3",
            container = "webm",
            codec = "vp9"
        )

        val mediaItem = Media3SourceBuilder.buildMediaItem(source)

        // Invariant 1: DIRECT -> MediaItem URI == original URI
        assertEquals(webmUri, mediaItem.localConfiguration?.uri)
        assertEquals(MimeTypes.VIDEO_WEBM, mediaItem.localConfiguration?.mimeType)
    }

    @Test
    fun test4_HEVC_Main10_Fallback_MP4_SourceConstruction_NoMkvMimeContamination() = runTest {
        val originalMkvUri = Uri.parse("content://com.android.providers.media.documents/document/video%3A101")
        val fallbackFile = File(context.cacheDir, "fallback_test_hevc_output.mp4")
        fallbackFile.writeText("dummy_media_bytes")
        val fallbackUri = Uri.fromFile(fallbackFile)

        val fallbackSource = PlaybackSource(
            sourceType = PlaybackSourceType.FALLBACK,
            uri = fallbackUri,
            originalUri = originalMkvUri,
            path = fallbackFile.absolutePath,
            mimeType = MimeTypes.VIDEO_MP4,
            requestId = "req_test_4",
            container = "mp4",
            codec = "h264"
        )

        val mediaItem = Media3SourceBuilder.buildMediaItem(fallbackSource)

        // Invariant 2: FALLBACK -> MediaItem URI == validated fallback URI
        assertEquals(fallbackUri, mediaItem.localConfiguration?.uri)
        assertNotEquals(originalMkvUri, mediaItem.localConfiguration?.uri)

        // Invariant 8: Fallback MP4 must not inherit an MKV MIME type
        assertEquals(MimeTypes.VIDEO_MP4, mediaItem.localConfiguration?.mimeType)
        assertNotEquals(MimeTypes.VIDEO_MATROSKA, mediaItem.localConfiguration?.mimeType)

        fallbackFile.delete()
    }

    @Test
    fun test5_RapidPlaybackRequests_RequestGuardIsolation() = runTest {
        val mediaEngine = DefaultMediaEngine(context)
        var activeRequestId = "request_B"

        val staleFileA = File(context.cacheDir, "stale_fallback_A.mp4")
        staleFileA.writeText("dummy_stale_a")
        val staleSourceA = PlaybackSource(
            sourceType = PlaybackSourceType.FALLBACK,
            uri = Uri.fromFile(staleFileA),
            originalUri = Uri.parse("content://media/external/video/media/999"),
            path = staleFileA.absolutePath,
            requestId = "request_A",
            container = "mp4",
            codec = "h264"
        )

        val freshFileB = File(context.cacheDir, "direct_video_B.mp4")
        freshFileB.writeText("dummy_fresh_b")
        val freshSourceB = PlaybackSource(
            sourceType = PlaybackSourceType.ORIGINAL,
            uri = Uri.fromFile(freshFileB),
            originalUri = Uri.fromFile(freshFileB),
            path = freshFileB.absolutePath,
            requestId = "request_B",
            container = "mp4",
            codec = "h264"
        )

        // Request A tries to set MediaItem when activeRequestId is "request_B"
        val acceptedA = mediaEngine.preparePlaybackSource(
            source = staleSourceA,
            activeRequestIdProvider = { activeRequestId }
        )

        // Invariant 6: Stale request cannot modify active Media3 source
        assertFalse("Stale request A must be rejected by request guard", acceptedA)
        assertNull("Player must not have media item set from rejected request A", mediaEngine.player.currentMediaItem)

        // Request B (active request) sets MediaItem
        val acceptedB = mediaEngine.preparePlaybackSource(
            source = freshSourceB,
            activeRequestIdProvider = { activeRequestId }
        )

        assertTrue("Active request B must be accepted", acceptedB)
        assertEquals(
            "Player active media item must belong to request B",
            Uri.fromFile(freshFileB),
            mediaEngine.player.currentMediaItem?.localConfiguration?.uri
        )

        mediaEngine.release()
        staleFileA.delete()
        freshFileB.delete()
    }

    @Test
    fun test6_UriSemanticsPreservation() = runTest {
        // Content URI
        val contentRaw = "content://media/external/video/media/4242"
        val contentUri = PlaybackSource.parseMediaUri(contentRaw)
        assertEquals("content", contentUri.scheme)
        assertEquals("media", contentUri.authority)
        assertEquals("/external/video/media/4242", contentUri.path)

        val contentSource = PlaybackSource(
            sourceType = PlaybackSourceType.ORIGINAL,
            uri = contentUri,
            originalUri = contentUri,
            requestId = "req_content"
        )
        val contentMediaItem = Media3SourceBuilder.buildMediaItem(contentSource)
        // Invariant 10: Content URI semantics must not be destroyed
        assertEquals("content", contentMediaItem.localConfiguration?.uri?.scheme)
        assertEquals(contentUri, contentMediaItem.localConfiguration?.uri)

        // File URI
        val fileRaw = "file:///storage/emulated/0/Movies/sample.mp4"
        val fileUri = PlaybackSource.parseMediaUri(fileRaw)
        assertEquals("file", fileUri.scheme)
        assertEquals("/storage/emulated/0/Movies/sample.mp4", fileUri.path)

        val fileSource = PlaybackSource(
            sourceType = PlaybackSourceType.ORIGINAL,
            uri = fileUri,
            originalUri = fileUri,
            requestId = "req_file"
        )
        val fileMediaItem = Media3SourceBuilder.buildMediaItem(fileSource)
        assertEquals(fileUri, fileMediaItem.localConfiguration?.uri)
    }

    @Test
    fun test7_MimeTypeInferencePreservationWhenUnknown() = runTest {
        val customSource = PlaybackSource(
            sourceType = PlaybackSourceType.ORIGINAL,
            uri = Uri.parse("file:///custom/video/stream.xyz"),
            originalUri = Uri.parse("file:///custom/video/stream.xyz"),
            requestId = "req_unknown_container",
            container = "custom_unknown_muxer",
            codec = "custom_codec"
        )

        val mime = Media3SourceBuilder.determineMimeType(customSource)
        // When container is unknown, return null to preserve Media3 native inference
        assertNull(mime)

        val mediaItem = Media3SourceBuilder.buildMediaItem(customSource)
        assertNull(mediaItem.localConfiguration?.mimeType)
    }
}
