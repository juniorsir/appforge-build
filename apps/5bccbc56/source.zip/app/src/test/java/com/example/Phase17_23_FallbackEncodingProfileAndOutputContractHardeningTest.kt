package com.example

import android.content.Context
import android.net.Uri
import androidx.test.core.app.ApplicationProvider
import com.example.media.ffmpeg.FFmpegEngine
import com.example.media.ffmpeg.FFmpegState
import com.example.media.operations.MediaConversionRequest
import com.example.media.operations.MediaConverter
import com.example.media.playback.PlaybackCompatibilityResult
import com.example.media.playback.PlaybackFallbackEngine
import com.example.media.playback.PlaybackStrategy
import com.example.media.probe.MediaProbeEngine
import kotlinx.coroutines.flow.toList
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File
import java.io.FileOutputStream

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [33])
class Phase17_23_FallbackEncodingProfileAndOutputContractHardeningTest {

    private lateinit var context: Context
    private lateinit var tempDir: File

    @Before
    fun setup() {
        context = ApplicationProvider.getApplicationContext()
        tempDir = File(context.cacheDir, "test_fallback").apply { mkdirs() }
    }

    private fun createDummyVideoFile(name: String): File {
        val file = File(tempDir, name)
        file.writeText("dummy video content")
        return file
    }
    
    private fun createDummyPortraitVideoFile(name: String): File {
        val file = File(tempDir, name)
        file.writeText("dummy portrait video content")
        return file
    }
    
    private fun createDummyHighBitDepthVideoFile(name: String): File {
        val file = File(tempDir, name)
        file.writeText("dummy high bit depth video content")
        return file
    }

    @Test
    fun testFallbackOutputContract_GeneratesValidMp4() = runBlocking {
        val inputFile = createDummyHighBitDepthVideoFile("high_bit_depth_input.mp4")
        val outputFile = File(tempDir, "fallback_output.mp4")

        val plan = PlaybackCompatibilityResult(
            strategy = PlaybackStrategy.TARGETED_VIDEO_TRANSCODE,
            reason = "Test",
            containerFormat = "mp4",
            videoCodec = "h264",
            audioCodec = "none",
            originalWidth = 1920,
            originalHeight = 1080,
            originalFps = 24f
        )

        val flow = PlaybackFallbackEngine.executeFix(context, Uri.fromFile(inputFile), outputFile, plan)
        val events = flow.toList()

        val terminalEvent = events.lastOrNull()
        assertNotNull("Flow should emit events", terminalEvent)
        assertTrue("Expected FAILED or COMPLETED state, got ${terminalEvent?.state}", terminalEvent?.state == FFmpegState.COMPLETED || terminalEvent?.state == FFmpegState.FAILED)
        
        if (terminalEvent?.state == FFmpegState.COMPLETED) {
             assertTrue("Output file must exist", outputFile.exists())
             val probe = MediaProbeEngine.probeMedia(context, Uri.fromFile(outputFile)).getOrNull()
             assertNotNull(probe)
             val v = probe!!.primaryVideo!!
             assertEquals("h264", v.codec)
             assertEquals(8, v.bitDepth)
             assertTrue("Should contain yuv420p", v.pixelFormat!!.contains("yuv420p"))
        }
    }

    @Test
    fun testMisleadingFilenameDoesNotAffectValidation() = runBlocking {
        val inputFile = createDummyVideoFile("video.10bit.x265.mkv")
        val outputFile = File(tempDir, "fallback_misleading.mp4")

        val plan = PlaybackCompatibilityResult(
            strategy = PlaybackStrategy.TARGETED_VIDEO_TRANSCODE,
            reason = "Test",
            containerFormat = "mkv",
            videoCodec = "h264",
            audioCodec = "none",
            originalWidth = 640,
            originalHeight = 480,
            originalFps = 30f
        )

        val flow = PlaybackFallbackEngine.executeFix(context, Uri.fromFile(inputFile), outputFile, plan)
        val events = flow.toList()

        val terminalEvent = events.last()
        if (terminalEvent.state == FFmpegState.COMPLETED) {
            val probe = MediaProbeEngine.probeMedia(context, Uri.fromFile(outputFile)).getOrNull()
            assertNotNull(probe)
            assertEquals("h264", probe!!.primaryVideo!!.codec)
        }
    }
    
    @Test
    fun testPortraitVideoOrientationPreserved() = runBlocking {
        val inputFile = createDummyPortraitVideoFile("portrait.mp4")
        val outputFile = File(tempDir, "fallback_portrait.mp4")

        val plan = PlaybackCompatibilityResult(
            strategy = PlaybackStrategy.TARGETED_VIDEO_TRANSCODE,
            reason = "Test",
            containerFormat = "mp4",
            videoCodec = "h264",
            audioCodec = "none",
            originalWidth = 1080,
            originalHeight = 1920,
            originalFps = 30f
        )

        val flow = PlaybackFallbackEngine.executeFix(context, Uri.fromFile(inputFile), outputFile, plan)
        val events = flow.toList()

        val terminalEvent = events.last()
        if (terminalEvent.state == FFmpegState.COMPLETED) {
            val probe = MediaProbeEngine.probeMedia(context, Uri.fromFile(outputFile)).getOrNull()
            assertNotNull(probe)
            val v = probe!!.primaryVideo!!
            // Dimensions should be scaled if > limits, but orientation (aspect ratio) preserved.
            assertTrue("Width should be less than height for portrait", v.width < v.height)
        }
    }

    @Test
    fun testFailureTaxonomy_InvalidCodecOutputsError() = runBlocking {
        val request = MediaConversionRequest(
            inputUri = Uri.parse("content://fake"),
            outputFile = File(tempDir, "fake.mp4"),
            videoCodec = "fake_codec_xyz"
        )
        
        val events = MediaConverter.convertMedia(context, request).toList()
        val terminal = events.last()
        assertEquals(FFmpegState.FAILED, terminal.state)
        assertTrue(terminal.error is IllegalArgumentException)
        val errMessage = terminal.error?.message ?: ""
        assertTrue("Error should mention invalid video codec", errMessage.contains("invalid video codec", ignoreCase = true))
    }
}
