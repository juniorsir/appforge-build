package com.example

import com.example.media.progressive.*
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class Phase17_37_SmartBufferingStallPreventionTest {

    @Before
    fun setUp() {
        SmartPlaybackController.reset()
    }

    @After
    fun tearDown() {
        SmartPlaybackController.reset()
    }

    /**
     * Test A: Fast Transcoding (productionRate > consumptionRate)
     * Progressive lead grows, smart buffer state evaluates to HEALTHY.
     */
    @Test
    fun testA_fastTranscoding_maintainsHealthyBufferState() {
        val reqId = "req_fast_01"
        SmartPlaybackController.startTracking(
            playbackRequestId = reqId,
            playerInstanceId = "player_1",
            sourceDurationMs = 120_000L
        )

        // Production rate = 1.8x, consumption rate = 1.0x, playable = 20s, playback pos = 5s (lead = 15s)
        SmartPlaybackController.updateTranscodeProgress(
            playableDurationMs = 20_000L,
            productionRate = 1.8f,
            fps = 48.0,
            generatedUnitsCount = 5,
            isCompleted = false
        )
        SmartPlaybackController.updatePlaybackMetrics(
            playbackPositionMs = 5_000L,
            internalBufferedPositionMs = 5_000L,
            consumptionRate = 1.0f,
            isPlaying = true,
            isBuffering = false
        )

        val metrics = SmartPlaybackController.metrics.value
        assertEquals(SmartBufferState.HEALTHY, metrics.state)
        assertEquals(15_000L, metrics.progressiveLeadMs)
        assertEquals(1.8f, metrics.productionRate, 0.01f)
        assertEquals(1.0f, metrics.consumptionRate, 0.01f)
        assertNull(metrics.timeToDepletionSeconds) // Production exceeds consumption, no depletion
    }

    /**
     * Test B: Slow Transcoding (productionRate < consumptionRate)
     * Evaluates LOW_BUFFER or STALL_RISK and calculates timeToDepletion.
     */
    @Test
    fun testB_slowTranscoding_detectsStallRiskAndDepletion() {
        val reqId = "req_slow_01"
        SmartPlaybackController.startTracking(
            playbackRequestId = reqId,
            playerInstanceId = "player_1",
            sourceDurationMs = 120_000L
        )

        // Production rate = 0.5x, consumption rate = 1.0x (rateDiff = 0.5x), playable = 5s, playback = 3.5s (lead = 1.5s)
        SmartPlaybackController.updateTranscodeProgress(
            playableDurationMs = 5_000L,
            productionRate = 0.5f,
            fps = 12.0,
            generatedUnitsCount = 2,
            isCompleted = false
        )
        SmartPlaybackController.updatePlaybackMetrics(
            playbackPositionMs = 3_500L,
            internalBufferedPositionMs = 3_500L,
            consumptionRate = 1.0f,
            isPlaying = true,
            isBuffering = false
        )

        val metrics = SmartPlaybackController.metrics.value
        assertEquals(SmartBufferState.STALL_RISK, metrics.state)
        assertEquals(1_500L, metrics.progressiveLeadMs)
        assertNotNull(metrics.timeToDepletionSeconds)
        assertEquals(3.0, metrics.timeToDepletionSeconds!!, 0.5)
    }

    /**
     * Test C: Buffer Recovery & Hysteresis
     * Tests transitions from LOW_BUFFER / STALL_RISK to HEALTHY requiring recovery lead.
     */
    @Test
    fun testC_bufferRecoveryWithHysteresis() {
        val (initialState, _) = SmartPlaybackController.evaluateBufferState(
            playableDurationMs = 3_000L,
            playbackPositionMs = 1_000L, // lead = 2000ms
            internalBufferedMs = 1_000L,
            productionRate = 0.8f,
            consumptionRate = 1.0f,
            isTranscodeCompleted = false,
            isWaiting = false,
            previousState = SmartBufferState.HEALTHY
        )
        assertEquals(SmartBufferState.STALL_RISK, initialState)

        // With small lead increase (3500ms), still in LOW_BUFFER / STALL_RISK, not jumping immediately to HEALTHY
        val (midState, _) = SmartPlaybackController.evaluateBufferState(
            playableDurationMs = 4_500L,
            playbackPositionMs = 1_000L, // lead = 3500ms
            internalBufferedMs = 1_000L,
            productionRate = 1.2f,
            consumptionRate = 1.0f,
            isTranscodeCompleted = false,
            isWaiting = false,
            previousState = initialState
        )
        assertEquals(SmartBufferState.LOW_BUFFER, midState)

        // With lead reaching 6500ms and production >= consumption, recovers to HEALTHY
        val (recoveredState, _) = SmartPlaybackController.evaluateBufferState(
            playableDurationMs = 7_500L,
            playbackPositionMs = 1_000L, // lead = 6500ms
            internalBufferedMs = 1_000L,
            productionRate = 1.5f,
            consumptionRate = 1.0f,
            isTranscodeCompleted = false,
            isWaiting = false,
            previousState = midState
        )
        assertEquals(SmartBufferState.HEALTHY, recoveredState)
    }

    /**
     * Test D: 2.0x Playback Speed
     * Updates consumption rate and reflects accelerated depletion.
     */
    @Test
    fun testD_doubleSpeedPlayback_adjustsConsumptionRate() {
        val reqId = "req_2x_01"
        SmartPlaybackController.startTracking(reqId, "p1", sourceDurationMs = 60_000L)
        SmartPlaybackController.updateTranscodeProgress(
            playableDurationMs = 10_000L,
            productionRate = 1.0f,
            fps = 24.0,
            generatedUnitsCount = 3,
            isCompleted = false
        )

        // Set 2.0x speed
        SmartPlaybackController.setPlaybackSpeed(2.0f, reqId)

        val metrics = SmartPlaybackController.metrics.value
        assertEquals(2.0f, metrics.consumptionRate, 0.01f)
        // At 2x consumption vs 1x production, depletion rate is 1.0x
        assertNotNull(metrics.timeToDepletionSeconds)
    }

    /**
     * Test E: Manual Pause
     * Transcoding continues in background while playback is paused, growing buffer lead.
     */
    @Test
    fun testE_manualPause_preservesTranscodingAndGrowsBufferLead() {
        val reqId = "req_pause_01"
        SmartPlaybackController.startTracking(reqId, "p1", sourceDurationMs = 60_000L)
        SmartPlaybackController.updatePlaybackMetrics(
            playbackPositionMs = 4_000L,
            internalBufferedPositionMs = 4_000L,
            consumptionRate = 1.0f,
            isPlaying = true,
            isBuffering = false
        )
        SmartPlaybackController.onUserPause(reqId)
        assertTrue(SmartPlaybackController.metrics.value.isPausedByUser)

        // Background transcoding continues generating units while paused
        SmartPlaybackController.updateTranscodeProgress(
            playableDurationMs = 24_000L,
            productionRate = 1.5f,
            fps = 30.0,
            generatedUnitsCount = 6,
            isCompleted = false
        )

        val metrics = SmartPlaybackController.metrics.value
        assertEquals(20_000L, metrics.progressiveLeadMs) // 24s - 4s = 20s
        assertEquals(SmartBufferState.HEALTHY, metrics.state)
    }

    /**
     * Test F: Seek Inside Generated Media
     * Target <= playableDuration executes immediately as COMPLETED.
     */
    @Test
    fun testF_seekInsideGeneratedMedia_executesImmediately() {
        val reqId = "req_seek_01"
        SmartPlaybackController.startTracking(reqId, "p1", sourceDurationMs = 60_000L)
        SmartPlaybackController.updateTranscodeProgress(
            playableDurationMs = 20_000L,
            productionRate = 1.5f,
            fps = 30.0,
            generatedUnitsCount = 5,
            isCompleted = false
        )

        val seek = SmartPlaybackController.requestSeek(
            targetPositionMs = 12_000L,
            playbackRequestId = reqId
        )

        assertEquals(SeekStatus.COMPLETED, seek.status)
        assertEquals(12_000L, seek.targetPositionMs)
        assertEquals(12_000L, SmartPlaybackController.metrics.value.playbackPositionMs)
        assertEquals(8_000L, SmartPlaybackController.metrics.value.progressiveLeadMs)
    }

    /**
     * Test G: Seek Beyond Generated Media
     * Target > playableDuration enters WAITING state, then auto-completes when transcoding reaches target.
     */
    @Test
    fun testG_seekBeyondGeneratedMedia_waitsAndCompletesWhenReady() {
        val reqId = "req_seek_02"
        SmartPlaybackController.startTracking(reqId, "p1", sourceDurationMs = 60_000L)
        SmartPlaybackController.updateTranscodeProgress(
            playableDurationMs = 10_000L,
            productionRate = 1.0f,
            fps = 24.0,
            generatedUnitsCount = 3,
            isCompleted = false
        )

        val seek = SmartPlaybackController.requestSeek(
            targetPositionMs = 25_000L,
            playbackRequestId = reqId
        )

        assertEquals(SeekStatus.WAITING, seek.status)
        assertTrue(SmartPlaybackController.metrics.value.isWaitingForTranscode)

        // Transcode reaches 28_000L
        SmartPlaybackController.updateTranscodeProgress(
            playableDurationMs = 28_000L,
            productionRate = 1.2f,
            fps = 28.0,
            generatedUnitsCount = 7,
            isCompleted = false
        )

        val updatedSeek = SmartPlaybackController.metrics.value.activeSeekRequest
        assertNotNull(updatedSeek)
        assertEquals(SeekStatus.COMPLETED, updatedSeek!!.status)
        assertFalse(SmartPlaybackController.metrics.value.isWaitingForTranscode)
    }

    /**
     * Test H: Rapid Seeking & Superseding
     * Newest seek supersedes pending stale seek requests.
     */
    @Test
    fun testH_rapidSeeking_supersedesStaleRequests() {
        val reqId = "req_rapid_01"
        SmartPlaybackController.startTracking(reqId, "p1", sourceDurationMs = 100_000L)
        SmartPlaybackController.updateTranscodeProgress(
            playableDurationMs = 10_000L,
            productionRate = 1.0f,
            fps = 24.0,
            generatedUnitsCount = 3,
            isCompleted = false
        )

        val seek1 = SmartPlaybackController.requestSeek(40_000L, reqId)
        assertEquals(SeekStatus.WAITING, seek1.status)

        val seek2 = SmartPlaybackController.requestSeek(70_000L, reqId)
        assertEquals(SeekStatus.WAITING, seek2.status)

        val seek3 = SmartPlaybackController.requestSeek(8_000L, reqId)
        // 8_000L <= 10_000L -> Completed immediately
        assertEquals(SeekStatus.COMPLETED, seek3.status)
        assertEquals(seek3.seekId, SmartPlaybackController.metrics.value.activeSeekRequest?.seekId)
    }

    /**
     * Test I: Transcoding Completion Transition
     * Seamless transition to COMPLETED without resetting playback position.
     */
    @Test
    fun testI_transcodeCompletion_transitionsSeamlessly() {
        val reqId = "req_comp_01"
        SmartPlaybackController.startTracking(reqId, "p1", sourceDurationMs = 30_000L)
        SmartPlaybackController.updatePlaybackMetrics(
            playbackPositionMs = 15_000L,
            internalBufferedPositionMs = 15_000L,
            consumptionRate = 1.0f,
            isPlaying = true,
            isBuffering = false
        )

        SmartPlaybackController.updateTranscodeProgress(
            playableDurationMs = 30_000L,
            productionRate = 1.5f,
            fps = 30.0,
            generatedUnitsCount = 8,
            isCompleted = true
        )

        val metrics = SmartPlaybackController.metrics.value
        assertEquals(SmartBufferState.COMPLETED, metrics.state)
        assertTrue(metrics.isTranscodeCompleted)
        assertEquals(15_000L, metrics.playbackPositionMs)
    }

    /**
     * Test J: Request Switch Concurrency Guard
     * Switching request id initializes clean state and ignores stale references.
     */
    @Test
    fun testJ_requestSwitch_isolatesState() {
        SmartPlaybackController.startTracking("req_old", "p1", sourceDurationMs = 50_000L)
        SmartPlaybackController.updateTranscodeProgress(
            playableDurationMs = 20_000L,
            productionRate = 1.5f,
            fps = 30.0,
            generatedUnitsCount = 5,
            isCompleted = false
        )

        // Switch to new request
        SmartPlaybackController.startTracking("req_new", "p2", sourceDurationMs = 90_000L)
        val metrics = SmartPlaybackController.metrics.value
        assertEquals("req_new", metrics.playbackRequestId)
        assertEquals("p2", metrics.playerInstanceId)
        assertEquals(0L, metrics.playableDurationMs)
        assertEquals(SmartBufferState.STARTING, metrics.state)
    }

    /**
     * Test K: Adaptive Startup Target Formula
     * Deterministic calculation for various production vs consumption ratios.
     */
    @Test
    fun testK_adaptiveStartupTarget_computesDeterministicBounds() {
        // Fast transcoding (1.8x prod / 1.0x cons) -> 6s
        val fastTarget = SmartPlaybackController.calculateAdaptiveStartupTarget(100_000L, 1.8f, 1.0f)
        assertEquals(6_000L, fastTarget)

        // Near real-time (1.0x prod / 1.0x cons) -> 10s
        val realTimeTarget = SmartPlaybackController.calculateAdaptiveStartupTarget(100_000L, 1.0f, 1.0f)
        assertEquals(10_000L, realTimeTarget)

        // Slow transcoding (0.6x prod / 1.0x cons) -> 16s
        val slowTarget = SmartPlaybackController.calculateAdaptiveStartupTarget(100_000L, 0.6f, 1.0f)
        assertEquals(16_000L, slowTarget)

        // Short media (3s total) -> capped at source duration 3s
        val shortTarget = SmartPlaybackController.calculateAdaptiveStartupTarget(3_000L, 1.0f, 1.0f)
        assertEquals(3_000L, shortTarget)
    }

    /**
     * Test L: Missing / Zero Metrics Handling
     * Unknown values do not throw exceptions or produce invalid predictions.
     */
    @Test
    fun testL_missingMetrics_producesSafeDefaults() {
        val (state, depletion) = SmartPlaybackController.evaluateBufferState(
            playableDurationMs = 0L,
            playbackPositionMs = null,
            internalBufferedMs = 0L,
            productionRate = 0.0f,
            consumptionRate = 0.0f,
            isTranscodeCompleted = false,
            isWaiting = false,
            previousState = SmartBufferState.UNKNOWN
        )

        assertEquals(SmartBufferState.UNKNOWN, state)
        assertNull(depletion)
    }
}
