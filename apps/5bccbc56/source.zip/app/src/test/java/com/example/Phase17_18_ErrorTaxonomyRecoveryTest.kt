package com.example

import android.content.Context
import android.net.Uri
import androidx.media3.common.PlaybackException
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.example.media.ffmpeg.FFmpegProgress
import com.example.media.ffmpeg.FFmpegState
import com.example.media.playback.*
import com.example.media.probe.MediaProbeInfo
import com.example.media.probe.VideoStreamInfo
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.annotation.Config
import java.io.File
import java.io.FileNotFoundException

/**
 * Phase 17.18-AC: 12-Point Authoritative Error Taxonomy & Recovery Architecture Test Suite.
 */
@RunWith(AndroidJUnit4::class)
@Config(sdk = [34])
class Phase17_18_ErrorTaxonomyRecoveryTest {

    private lateinit var context: Context

    @Before
    fun setup() {
        context = ApplicationProvider.getApplicationContext()
        PlaybackRequestCoordinator.resetForTesting()
    }

    @After
    fun tearDown() {
        PlaybackRequestCoordinator.resetForTesting()
    }

    /**
     * 1. Non-existent input path -> INPUT / INPUT_NOT_FOUND -> NON_RECOVERABLE, STOP
     */
    @Test
    fun test1_NonExistentInputPath_ClassifiedAsInputNotFound() {
        val requestId = "REQ_1"
        val error = PlaybackErrorClassifier.classifyInputException(
            requestId = requestId,
            throwable = FileNotFoundException("File not found: /movies/ghost.mp4"),
            uri = Uri.parse("file:///movies/ghost.mp4"),
            operationId = "OP_1"
        )

        assertEquals(PlaybackErrorStage.INPUT, error.stage)
        assertEquals(PlaybackErrorCategory.INPUT_NOT_FOUND, error.category)
        assertEquals(ErrorRecoverability.NON_RECOVERABLE, error.recoverable)
        assertEquals(PlaybackRecoveryAction.STOP, error.recoveryAction)
        assertEquals(PlaybackSourceType.ORIGINAL, error.sourceType)
    }

    /**
     * 2. Corrupt media / no streams -> ANALYSIS / FFPROBE_NO_STREAMS -> NON_RECOVERABLE, STOP
     */
    @Test
    fun test2_NoStreams_ClassifiedAsNoStreams() {
        val error = PlaybackErrorClassifier.classifyProbeFailure(
            requestId = "REQ_2",
            throwable = RuntimeException("Input file contains no streams"),
            uri = Uri.parse("file:///movies/empty.mp4"),
            operationId = "OP_2"
        )

        assertEquals(PlaybackErrorStage.ANALYSIS, error.stage)
        assertEquals(PlaybackErrorCategory.FFPROBE_NO_STREAMS, error.category)
        assertEquals(ErrorRecoverability.NON_RECOVERABLE, error.recoverable)
        assertEquals(PlaybackRecoveryAction.STOP, error.recoveryAction)
    }

    /**
     * 3. Probe execution failure -> ANALYSIS / FFPROBE_EXECUTION_FAILED -> RETRYABLE, DIRECT_ATTEMPT
     */
    @Test
    fun test3_ProbeExecutionFailed_ClassifiedAsFfprobeExecutionFailed() {
        val error = PlaybackErrorClassifier.classifyProbeFailure(
            requestId = "REQ_3",
            throwable = RuntimeException("FFprobe process exited with code 1"),
            uri = Uri.parse("file:///movies/probe_err.mp4"),
            operationId = "OP_3"
        )

        assertEquals(PlaybackErrorStage.ANALYSIS, error.stage)
        assertEquals(PlaybackErrorCategory.FFPROBE_EXECUTION_FAILED, error.category)
        assertEquals(ErrorRecoverability.RETRYABLE, error.recoverable)
        assertEquals(PlaybackRecoveryAction.DIRECT_ATTEMPT, error.recoveryAction)
    }

    /**
     * 4. Probe timeout -> ANALYSIS / FFPROBE_TIMEOUT -> RETRYABLE, DIRECT_ATTEMPT
     */
    @Test
    fun test4_ProbeTimeout_ClassifiedAsFfprobeTimeout() {
        val error = PlaybackErrorClassifier.classifyProbeFailure(
            requestId = "REQ_4",
            throwable = RuntimeException("FFprobe timeout after 5000ms"),
            uri = Uri.parse("file:///movies/timeout.mp4"),
            operationId = "OP_4"
        )

        assertEquals(PlaybackErrorStage.ANALYSIS, error.stage)
        assertEquals(PlaybackErrorCategory.FFPROBE_TIMEOUT, error.category)
        assertEquals(ErrorRecoverability.RETRYABLE, error.recoverable)
        assertEquals(PlaybackRecoveryAction.DIRECT_ATTEMPT, error.recoveryAction)
    }

    /**
     * 5. MKV container with H.264 video -> COMPATIBILITY / COMPATIBILITY_UNSUPPORTED -> RECOVERABLE, REMUX_FALLBACK
     */
    @Test
    fun test5_ContainerUnsupported_ClassifiedAsRemuxFallback() {
        val probeInfo = MediaProbeInfo(
            pathOrUri = "/movies/video.mkv",
            format = "matroska,webm",
            durationMs = 120000L,
            sizeBytes = 50000000L,
            videoStreams = listOf(
                VideoStreamInfo(
                    index = 0,
                    codec = "h264",
                    profile = "High",
                    level = "4.1",
                    width = 1920,
                    height = 1080,
                    bitDepth = 8,
                    pixelFormat = "yuv420p"
                )
            ),
            streamCount = 1
        )

        val error = PlaybackErrorClassifier.classifyCompatibility(
            requestId = "REQ_5",
            strategy = PlaybackStrategy.REMUX_REQUIRED,
            probeInfo = probeInfo,
            operationId = "OP_5"
        )

        assertNotNull(error)
        assertEquals(PlaybackErrorStage.COMPATIBILITY, error?.stage)
        assertEquals(PlaybackErrorCategory.COMPATIBILITY_UNSUPPORTED, error?.category)
        assertEquals(ErrorRecoverability.RECOVERABLE, error?.recoverable)
        assertEquals(PlaybackRecoveryAction.REMUX_FALLBACK, error?.recoveryAction)
    }

    /**
     * 6. HEVC 10-bit video on device without decoder -> COMPATIBILITY / COMPATIBILITY_UNSUPPORTED -> RECOVERABLE, TRANSCODE_FALLBACK
     */
    @Test
    fun test6_VideoCodecUnsupported_ClassifiedAsTranscodeFallback() {
        val probeInfo = MediaProbeInfo(
            pathOrUri = "/movies/hevc10.mp4",
            format = "mp4",
            durationMs = 60000L,
            sizeBytes = 25000000L,
            videoStreams = listOf(
                VideoStreamInfo(
                    index = 0,
                    codec = "hevc",
                    profile = "Main 10",
                    level = "5.1",
                    width = 3840,
                    height = 2160,
                    bitDepth = 10,
                    pixelFormat = "yuv420p10le"
                )
            ),
            streamCount = 1
        )

        val error = PlaybackErrorClassifier.classifyCompatibility(
            requestId = "REQ_6",
            strategy = PlaybackStrategy.TRANSCODE_REQUIRED,
            probeInfo = probeInfo,
            operationId = "OP_6"
        )

        assertNotNull(error)
        assertEquals(PlaybackErrorStage.COMPATIBILITY, error?.stage)
        assertEquals(PlaybackErrorCategory.COMPATIBILITY_UNSUPPORTED, error?.category)
        assertEquals(ErrorRecoverability.RECOVERABLE, error?.recoverable)
        assertEquals(PlaybackRecoveryAction.TRANSCODE_FALLBACK, error?.recoveryAction)
    }

    /**
     * 7. Corrupt cached fallback file -> CACHE / CACHE_CORRUPTED -> RETRYABLE, REGENERATE_CACHE_ONCE
     */
    @Test
    fun test7_CorruptCache_ClassifiedAsRegenerateCacheOnce() {
        val invalidCacheFile = File(context.cacheDir, "invalid_cache.mp4")
        invalidCacheFile.writeText("corrupted partial cache data")

        val error = PlaybackErrorClassifier.classifyCacheResult(
            requestId = "REQ_7",
            cacheKey = "fallback_cache_123",
            cachedFile = invalidCacheFile,
            isValid = false
        )

        assertNotNull(error)
        assertEquals(PlaybackErrorStage.CACHE, error?.stage)
        assertEquals(PlaybackErrorCategory.CACHE_CORRUPTED, error?.category)
        assertEquals(ErrorRecoverability.RETRYABLE, error?.recoverable)
        assertEquals(PlaybackRecoveryAction.REGENERATE_CACHE_ONCE, error?.recoveryAction)

        invalidCacheFile.delete()
    }

    /**
     * 8. FFmpeg transcode fails -> FALLBACK_PROCESSING / FFMPEG_ENCODING_FAILED or FFMPEG_EXECUTION_FAILED -> NON_RECOVERABLE, FALLBACK_FAILED
     */
    @Test
    fun test8_FfmpegExecutionFailed_ClassifiedAsFallbackFailed() {
        val progress = FFmpegProgress(
            sessionId = 123L,
            state = FFmpegState.FAILED,
            progressPercentage = 42f,
            currentTimestampMs = 12000L,
            totalDurationMs = 30000L,
            error = RuntimeException("Encoder 'libx264' initialization failed (rc=-1)")
        )

        val error = PlaybackErrorClassifier.classifyFfmpegProgress(
            requestId = "REQ_8",
            ffmpegJobId = "FFMPEG_8",
            progress = progress
        )

        assertNotNull(error)
        assertEquals(PlaybackErrorStage.FALLBACK_PROCESSING, error?.stage)
        assertEquals(PlaybackErrorCategory.FFMPEG_ENCODING_FAILED, error?.category)
        assertEquals(ErrorRecoverability.NON_RECOVERABLE, error?.recoverable)
        assertEquals(PlaybackRecoveryAction.FALLBACK_FAILED, error?.recoveryAction)
        assertEquals(PlaybackSourceType.FALLBACK, error?.sourceType)
    }

    /**
     * 9. Output validation fails (empty file) -> FALLBACK_VALIDATION / OUTPUT_EMPTY -> NON_RECOVERABLE, FALLBACK_FAILED
     */
    @Test
    fun test9_OutputValidationEmpty_ClassifiedAsOutputEmpty() {
        val emptyOutput = File(context.cacheDir, "out_empty.mp4")
        emptyOutput.writeBytes(ByteArray(0))

        val error = PlaybackErrorClassifier.classifyValidationFailure(
            requestId = "REQ_9",
            outputFile = emptyOutput,
            probeInfo = null,
            operationId = "VAL_9"
        )

        assertEquals(PlaybackErrorStage.FALLBACK_VALIDATION, error.stage)
        assertEquals(PlaybackErrorCategory.OUTPUT_EMPTY, error.category)
        assertEquals(ErrorRecoverability.NON_RECOVERABLE, error.recoverable)
        assertEquals(PlaybackRecoveryAction.FALLBACK_FAILED, error.recoveryAction)
        assertEquals(PlaybackSourceType.FALLBACK, error.sourceType)

        emptyOutput.delete()
    }

    /**
     * 10. Media3 decoder failure on ORIGINAL source -> MEDIA3_PLAYBACK / MEDIA3_DECODER_FAILED -> RECOVERABLE, TRANSCODE_FALLBACK
     */
    @Test
    fun test10_Media3DecoderFailureOriginalSource_TriggersTranscodeFallback() {
        val originalSource = PlaybackSource(
            sourceType = PlaybackSourceType.ORIGINAL,
            uri = Uri.parse("file:///movies/hevc_unsupported.mp4"),
            originalUri = Uri.parse("file:///movies/hevc_unsupported.mp4"),
            path = "/movies/hevc_unsupported.mp4",
            requestId = "REQ_10"
        )

        val exception = PlaybackException(
            "Decoder init failed: c2.goldfish.hevc.decoder",
            null,
            PlaybackException.ERROR_CODE_DECODER_INIT_FAILED
        )

        val error = PlaybackErrorClassifier.classifyMedia3Error(
            requestId = "REQ_10",
            error = exception,
            sourceType = PlaybackSourceType.ORIGINAL,
            fallbackAttemptCount = 0
        )

        assertEquals(PlaybackErrorStage.MEDIA3_PLAYBACK, error.stage)
        assertEquals(PlaybackErrorCategory.MEDIA3_DECODER_FAILED, error.category)
        assertEquals(ErrorRecoverability.RECOVERABLE, error.recoverable)
        assertEquals(PlaybackRecoveryAction.TRANSCODE_FALLBACK, error.recoveryAction)
        assertEquals(PlaybackSourceType.ORIGINAL, error.sourceType)
    }

    /**
     * 11. Media3 decoder failure on FALLBACK source (PROHIBITED RECURSION) -> MEDIA3_PLAYBACK / MEDIA3_DECODER_FAILED -> NON_RECOVERABLE, PLAYBACK_FAILED
     * Invariant 9: No second fallback conversion is permitted.
     */
    @Test
    fun test11_Media3DecoderFailureFallbackSource_ProhibitsRecursiveFallback() {
        val fallbackSource = PlaybackSource(
            sourceType = PlaybackSourceType.FALLBACK,
            uri = Uri.parse("file:///cache/fallback_out.mp4"),
            originalUri = Uri.parse("file:///movies/original.mkv"),
            path = "/cache/fallback_out.mp4",
            requestId = "REQ_11",
            mimeType = androidx.media3.common.MimeTypes.VIDEO_MP4
        )

        val exception = PlaybackException(
            "Decoder failed on fallback: c2.android.avc.decoder",
            null,
            PlaybackException.ERROR_CODE_DECODER_INIT_FAILED
        )

        val error = PlaybackErrorClassifier.classifyMedia3Error(
            requestId = "REQ_11",
            error = exception,
            sourceType = PlaybackSourceType.FALLBACK,
            fallbackAttemptCount = 1
        )

        assertEquals(PlaybackErrorStage.MEDIA3_PLAYBACK, error.stage)
        assertEquals(PlaybackErrorCategory.MEDIA3_DECODER_FAILED, error.category)
        // INVARIANT 9: Fallback source failure must NOT be recoverable via another fallback!
        assertEquals(ErrorRecoverability.NON_RECOVERABLE, error.recoverable)
        assertEquals(PlaybackRecoveryAction.PLAYBACK_FAILED, error.recoveryAction)
        assertEquals(PlaybackSourceType.FALLBACK, error.sourceType)
    }

    /**
     * 12. User cancellation during FFmpeg processing -> CANCELLATION / PLAYBACK_CANCELLED -> USER_CANCELLED, STOP
     * Invariant 1: Cancellation is NOT classified as a playback failure.
     */
    @Test
    fun test12_UserCancellation_ClassifiedAsCancellationNotFailure() {
        val error = PlaybackErrorClassifier.classifyCancellation(
            requestId = "REQ_12",
            operationId = "FFMPEG_12",
            reason = "user_cancelled_fallback"
        )

        assertEquals(PlaybackErrorStage.CANCELLATION, error.stage)
        assertEquals(PlaybackErrorCategory.PLAYBACK_CANCELLED, error.category)
        assertEquals(ErrorRecoverability.USER_CANCELLED, error.recoverable)
        assertEquals(PlaybackRecoveryAction.STOP, error.recoveryAction)
        assertFalse("Cancellation must not be treated as a playback failure", error.category == PlaybackErrorCategory.UNKNOWN_ERROR)
    }

    /**
     * Invariant 10: Input/IO errors on original source must NOT trigger codec fallback.
     */
    @Test
    fun test_Invariant10_InputIoErrorDoesNotTriggerFallback() {
        val originalSource = PlaybackSource(
            sourceType = PlaybackSourceType.ORIGINAL,
            uri = Uri.parse("file:///storage/deleted_media.mp4"),
            originalUri = Uri.parse("file:///storage/deleted_media.mp4"),
            path = "/storage/deleted_media.mp4",
            requestId = "REQ_INV10"
        )

        val ioException = PlaybackException(
            "Source error: file does not exist",
            null,
            PlaybackException.ERROR_CODE_IO_FILE_NOT_FOUND
        )

        val error = PlaybackErrorClassifier.classifyMedia3Error(
            requestId = "REQ_INV10",
            error = ioException,
            sourceType = PlaybackSourceType.ORIGINAL,
            fallbackAttemptCount = 0
        )

        assertEquals(PlaybackErrorStage.INPUT, error.stage)
        assertEquals(PlaybackErrorCategory.INPUT_NOT_FOUND, error.category)
        assertEquals(ErrorRecoverability.NON_RECOVERABLE, error.recoverable)
        assertEquals(PlaybackRecoveryAction.STOP, error.recoveryAction)
        assertNotEquals(PlaybackRecoveryAction.TRANSCODE_FALLBACK, error.recoveryAction)
    }

    /**
     * Test structured logging formatted tags [ERROR_CLASSIFICATION] and [ERROR_RECOVERY].
     */
    @Test
    fun test_StructuredLogging_FormattedTraces() {
        val (req, _) = PlaybackRequestCoordinator.getOrCreateRequest(
            mediaKey = "KEY_LOG_1",
            originalUri = Uri.parse("file:///movies/sample.mp4"),
            originalPath = "/movies/sample.mp4",
            forceNew = true
        )

        val classified = PlaybackError(
            requestId = req.requestId,
            operationId = "OP_TEST",
            stage = PlaybackErrorStage.MEDIA3_PLAYBACK,
            category = PlaybackErrorCategory.MEDIA3_DECODER_FAILED,
            code = 3001,
            technicalMessage = "Decoder initialization failed for AVC",
            userMessage = "Hardware video decoder failed.",
            cause = null,
            sourceType = PlaybackSourceType.ORIGINAL,
            recoverable = ErrorRecoverability.RECOVERABLE,
            recoveryAction = PlaybackRecoveryAction.TRANSCODE_FALLBACK
        )

        PlaybackRequestCoordinator.setAuthoritativeError(req.requestId, classified)
        val retrieved = PlaybackRequestCoordinator.getAuthoritativeError(req.requestId)

        assertNotNull(retrieved)
        assertEquals(PlaybackErrorCategory.MEDIA3_DECODER_FAILED, retrieved?.category)
        assertEquals(PlaybackRecoveryAction.TRANSCODE_FALLBACK, retrieved?.recoveryAction)
    }
}
