package com.example

import com.example.ui.VideoPostProcessingHelper
import com.example.ui.calculateVideoColorMatrix
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class VideoPostProcessingTest {

    @Test
    fun testCleanColorMatrixHasNoSharpnessColorDistortion() {
        // Neutral baseline
        val cmNeutral = VideoPostProcessingHelper.calculateCleanColorMatrix(
            brightness = 0.0f,
            contrast = 1.0f,
            saturation = 1.0f,
            gamma = 1.0f
        )
        val neutralArray = cmNeutral.array

        // In a clean color matrix, Red, Green, and Blue channels have NO cross-talk (off-diagonals are 0)
        // Array layout is 4 rows x 5 columns:
        // [0..4]   = R row: [R_r, R_g, R_b, R_a, offset]
        // [5..9]   = G row: [G_r, G_g, G_b, G_a, offset]
        // [10..14] = B row: [B_r, B_g, B_b, B_a, offset]
        
        // R channel does not bleed into G or B
        assertEquals("R_g cross-talk must be 0", 0.0f, neutralArray[1], 0.001f)
        assertEquals("R_b cross-talk must be 0", 0.0f, neutralArray[2], 0.001f)

        // G channel does not bleed into R or B
        assertEquals("G_r cross-talk must be 0", 0.0f, neutralArray[5], 0.001f)
        assertEquals("G_b cross-talk must be 0", 0.0f, neutralArray[7], 0.001f)

        // B channel does not bleed into R or G
        assertEquals("B_r cross-talk must be 0", 0.0f, neutralArray[10], 0.001f)
        assertEquals("B_g cross-talk must be 0", 0.0f, neutralArray[11], 0.001f)
    }

    @Test
    fun testCalculateVideoColorMatrixDoesNotChangeWithSharpness() {
        val cmSharpness0 = calculateVideoColorMatrix(
            brightness = 0.1f,
            contrast = 1.2f,
            saturation = 1.1f,
            gamma = 1.0f,
            sharpness = 0.0f
        )

        val cmSharpnessMax = calculateVideoColorMatrix(
            brightness = 0.1f,
            contrast = 1.2f,
            saturation = 1.1f,
            gamma = 1.0f,
            sharpness = 2.0f
        )

        // The ColorMatrix must be identical regardless of sharpness,
        // because sharpness is processed spatially as an unsharp mask in the GPU shader!
        assertArrayEquals(
            "Sharpness must not corrupt the color matrix",
            cmSharpness0.array,
            cmSharpnessMax.array,
            0.0001f
        )
    }

    @Test
    fun testSpatialSharpenAgslShaderDefinition() {
        val agsl = VideoPostProcessingHelper.SPATIAL_SHARPEN_AGSL
        assertTrue("AGSL must define contents uniform", agsl.contains("uniform shader contents;"))
        assertTrue("AGSL must define sharpness uniform", agsl.contains("uniform float sharpness;"))
        assertTrue("AGSL must define resolution uniform", agsl.contains("uniform float2 resolution;"))
        assertTrue("AGSL must contain Rec. 709 luminance weights", agsl.contains("0.2126") && agsl.contains("0.7152") && agsl.contains("0.0722"))
        assertTrue("AGSL must perform spatial neighbor sampling", agsl.contains("stepX") && agsl.contains("stepY"))
    }
}
