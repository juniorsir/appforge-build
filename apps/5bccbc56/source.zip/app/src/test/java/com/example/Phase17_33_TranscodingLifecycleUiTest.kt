package com.example

import com.example.media.playback.PlaybackLifecycleState
import com.example.media.playback.TranscodingLifecycleState
import com.example.media.playback.TranscodingLogManager
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

class Phase17_33_TranscodingLifecycleUiTest {

    @Before
    fun setUp() {
        TranscodingLogManager.clear()
        TranscodingLogManager.updateTranscodingState(TranscodingLifecycleState.NOT_STARTED)
        TranscodingLogManager.updatePlaybackState(PlaybackLifecycleState.IDLE)
    }

    @Test
    fun testLifecycleStateTransitionsAndVisibility() {
        // Initially NOT_STARTED -> isLogControlVisible is false
        assertEquals(TranscodingLifecycleState.NOT_STARTED, TranscodingLogManager.transcodingState.value)
        assertFalse(TranscodingLogManager.transcodingState.value.isLogControlVisible)

        // QUEUED -> isLogControlVisible is true
        TranscodingLogManager.updateTranscodingState(TranscodingLifecycleState.QUEUED, "test_req_1")
        assertEquals(TranscodingLifecycleState.QUEUED, TranscodingLogManager.transcodingState.value)
        assertTrue(TranscodingLogManager.transcodingState.value.isLogControlVisible)
        assertTrue(TranscodingLogManager.transcodingState.value.isTranscodingActive)

        // STARTING -> isLogControlVisible is true
        TranscodingLogManager.updateTranscodingState(TranscodingLifecycleState.STARTING, "test_req_1")
        assertTrue(TranscodingLogManager.transcodingState.value.isLogControlVisible)

        // RUNNING -> isLogControlVisible is true
        TranscodingLogManager.updateTranscodingState(TranscodingLifecycleState.RUNNING, "test_req_1")
        assertTrue(TranscodingLogManager.transcodingState.value.isLogControlVisible)

        // PARTIAL_OUTPUT_AVAILABLE -> isLogControlVisible is true
        TranscodingLogManager.updateTranscodingState(TranscodingLifecycleState.PARTIAL_OUTPUT_AVAILABLE, "test_req_1")
        assertTrue(TranscodingLogManager.transcodingState.value.isLogControlVisible)

        // COMPLETED -> isLogControlVisible is true, but no longer active
        TranscodingLogManager.updateTranscodingState(TranscodingLifecycleState.COMPLETED, "test_req_1")
        assertTrue(TranscodingLogManager.transcodingState.value.isLogControlVisible)
        assertFalse(TranscodingLogManager.transcodingState.value.isTranscodingActive)

        // VALIDATING & VALIDATED
        TranscodingLogManager.updateTranscodingState(TranscodingLifecycleState.VALIDATING, "test_req_1")
        assertTrue(TranscodingLogManager.transcodingState.value.isLogControlVisible)
        TranscodingLogManager.updateTranscodingState(TranscodingLifecycleState.VALIDATED, "test_req_1")
        assertTrue(TranscodingLogManager.transcodingState.value.isLogControlVisible)

        // FAILED & CANCELLED
        TranscodingLogManager.updateTranscodingState(TranscodingLifecycleState.FAILED, "test_req_1")
        assertTrue(TranscodingLogManager.transcodingState.value.isLogControlVisible)
        TranscodingLogManager.updateTranscodingState(TranscodingLifecycleState.CANCELLED, "test_req_1")
        assertTrue(TranscodingLogManager.transcodingState.value.isLogControlVisible)
    }

    @Test
    fun testPlaybackStateDecouplingFromTranscoding() {
        // Decoupled playback state verification
        TranscodingLogManager.updateTranscodingState(TranscodingLifecycleState.RUNNING, "test_req_2")
        TranscodingLogManager.updatePlaybackState(PlaybackLifecycleState.PLAYING, "test_req_2")

        assertEquals(TranscodingLifecycleState.RUNNING, TranscodingLogManager.transcodingState.value)
        assertEquals(PlaybackLifecycleState.PLAYING, TranscodingLogManager.playbackState.value)
        assertTrue(TranscodingLogManager.transcodingState.value.isLogControlVisible)
    }

    @Test
    fun testLogManagerRecording() {
        TranscodingLogManager.recordEvent("TRANSCODE_JOB_CREATED", "jobId=123", "req_abc")
        TranscodingLogManager.recordEvent("TRANSCODING_LOG_UI_CLICK", "clicked=SHOW_LOGS", "req_abc")

        val logs = TranscodingLogManager.logs.value
        assertTrue(logs.any { it.contains("TRANSCODE_JOB_CREATED") })
        assertTrue(logs.any { it.contains("TRANSCODING_LOG_UI_CLICK") })
    }
}
