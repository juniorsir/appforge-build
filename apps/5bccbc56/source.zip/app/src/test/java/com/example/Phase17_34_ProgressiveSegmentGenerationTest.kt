package com.example

import android.content.Context
import android.net.Uri
import androidx.test.core.app.ApplicationProvider
import com.example.media.ffmpeg.*
import com.example.media.playback.PlaybackErrorCategory
import com.example.media.probe.*
import com.example.media.progressive.*
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class Phase17_34_ProgressiveSegmentGenerationTest {

    private lateinit var context: Context
    private lateinit var testCacheDir: File

    @Before
    fun setUp() {
        context = ApplicationProvider.getApplicationContext()
        testCacheDir = File(context.cacheDir, "test_progressive_${System.currentTimeMillis()}").apply { mkdirs() }
        FFmpegEngine.resetForTesting()
        H264EncoderSelector.resetCacheForTesting()
        ProgressiveMediaGenerator.mockProbeFuncForTesting = null
    }

    @After
    fun tearDown() {
        testCacheDir.deleteRecursively()
        FFmpegEngine.resetForTesting()
        H264EncoderSelector.resetCacheForTesting()
        ProgressiveMediaGenerator.mockProbeFuncForTesting = null
    }

    @Test
    fun testProgressiveRequestValidation() {
        val validRequest = ProgressiveGenerationRequest(
            inputUri = Uri.parse("file:///dummy/video.mkv"),
            outputDir = testCacheDir,
            playbackRequestId = "req_101",
            transcodeJobId = "job_101",
            segmentDurationSec = 4,
            bitDepth = 8,
            pixelFormat = "yuv420p"
        )
        assertTrue(validRequest.validate().isSuccess)

        // Invalid 10-bit request must fail validation
        val invalidBitDepth = validRequest.copy(bitDepth = 10)
        assertTrue(invalidBitDepth.validate().isFailure)

        // Invalid pixel format
        val invalidPixFmt = validRequest.copy(pixelFormat = "yuv422p")
        assertTrue(invalidPixFmt.validate().isFailure)

        // Invalid segment duration
        val invalidDuration = validRequest.copy(segmentDurationSec = 0)
        assertTrue(invalidDuration.validate().isFailure)
    }

    @Test
    fun testUnitValidatorRejectsInvalidCodecsOr10Bit() = runBlocking {
        val dummyFile = File(testCacheDir, "test_unit.ts").apply {
            writeBytes(ByteArray(1024))
        }

        // Test 1: Valid 8-bit H.264
        val validProbe = MediaProbeInfo(
            pathOrUri = "file://${dummyFile.absolutePath}",
            format = "mpegts",
            durationMs = 4000L,
            videoStreams = listOf(
                VideoStreamInfo(
                    index = 0,
                    codec = "h264",
                    width = 1920,
                    height = 1080,
                    frameRate = 30f,
                    bitDepth = 8,
                    pixelFormat = "yuv420p",
                    profile = "High"
                )
            ),
            audioStreams = listOf(
                AudioStreamInfo(
                    index = 1,
                    codec = "aac",
                    sampleRate = 48000,
                    channels = 2
                )
            )
        )
        val validResult = ProgressiveUnitValidator.validateUnit(
            context = context,
            file = dummyFile,
            probeFunc = { _, _ -> Result.success(validProbe) }
        )
        assertTrue("Valid 8-bit unit must pass", validResult.isSuccess)
        assertEquals(4000L, validResult.getOrNull()?.durationMs)

        // Test 2: Invalid 10-bit unit must be rejected
        val invalid10BitProbe = validProbe.copy(
            videoStreams = listOf(
                VideoStreamInfo(
                    index = 0,
                    codec = "h264",
                    width = 1920,
                    height = 1080,
                    frameRate = 30f,
                    bitDepth = 10,
                    pixelFormat = "yuv420p10le",
                    profile = "High 10"
                )
            )
        )
        val invalidResult = ProgressiveUnitValidator.validateUnit(
            context = context,
            file = dummyFile,
            probeFunc = { _, _ -> Result.success(invalid10BitProbe) }
        )
        assertTrue("10-bit unit must fail validation", invalidResult.isFailure)
        assertTrue(invalidResult.exceptionOrNull()?.message?.contains("10") == true)
    }

    @Test
    fun testAtomicPublishingAndPlayableDurationTracking() = runBlocking {
        File(testCacheDir, "input.mkv").apply { writeBytes(ByteArray(1024)) }

        val mockProbe = MediaProbeInfo(
            pathOrUri = "file://${testCacheDir.absolutePath}/dummy.ts",
            format = "mpegts",
            durationMs = 4000L,
            videoStreams = listOf(
                VideoStreamInfo(
                    index = 0,
                    codec = "h264",
                    width = 1280,
                    height = 720,
                    frameRate = 24f,
                    bitDepth = 8,
                    pixelFormat = "yuv420p",
                    profile = "High"
                )
            ),
            audioStreams = listOf(
                AudioStreamInfo(
                    index = 1,
                    codec = "aac",
                    sampleRate = 44100,
                    channels = 2
                )
            )
        )
        ProgressiveMediaGenerator.mockProbeFuncForTesting = { _, _ -> Result.success(mockProbe) }

        // Configure mock encoder & FFmpeg
        H264EncoderSelector.mockEncodersForTesting = listOf(
            EncoderCandidate("libopenh264", false, "h264", "OpenH264")
        )
        H264EncoderSelector.mockUsabilityForTesting = true
        FFmpegEngine.mockExecutionResult = FFmpegResult(
            sessionId = 101L,
            isSuccess = true,
            returnCode = 0,
            output = "Transcoding finished successfully",
            executionDurationMs = 250L
        )

        // Create initial segment tmp files to simulate FFmpeg streaming
        val seg0Tmp = File(testCacheDir, "seg_00000.ts.tmp").apply { writeBytes(ByteArray(2048)) }
        val seg1Tmp = File(testCacheDir, "seg_00001.ts.tmp").apply { writeBytes(ByteArray(2048)) }

        val request = ProgressiveGenerationRequest(
            inputUri = Uri.parse("file://${testCacheDir.absolutePath}/input.mkv"),
            outputDir = testCacheDir,
            playbackRequestId = "req_cuj",
            transcodeJobId = "job_cuj",
            segmentDurationSec = 4,
            totalEstimatedDurationMs = 8000L
        )

        val (progressFlow, eventFlow) = ProgressiveMediaGenerator.startProgressiveGeneration(
            context = context,
            request = request
        )

        // Wait until completion
        var finalProgress = progressFlow.value
        for (i in 1..40) {
            finalProgress = progressFlow.value
            if (finalProgress.state == ProgressiveState.COMPLETED || finalProgress.state == ProgressiveState.FAILED) break
            kotlinx.coroutines.delay(50)
        }

        assertEquals(ProgressiveState.COMPLETED, finalProgress.state)
        assertEquals(2, finalProgress.publishedUnitsCount)
        assertEquals(8000L, finalProgress.playableDurationMs)

        // Verify published files exist and .tmp files were renamed atomically
        val published0 = File(testCacheDir, "seg_00000.ts")
        val published1 = File(testCacheDir, "seg_00001.ts")
        assertTrue("seg_00000.ts must exist", published0.exists())
        assertTrue("seg_00001.ts must exist", published1.exists())
        assertFalse("seg_00000.ts.tmp must not exist", seg0Tmp.exists())
        assertFalse("seg_00001.ts.tmp must not exist", seg1Tmp.exists())
    }

    @Test
    fun testJobCancellationCleansTemporaryFilesAndNeverReports100Percent() = runBlocking {
        File(testCacheDir, "input.mkv").apply { writeBytes(ByteArray(1024)) }

        H264EncoderSelector.mockEncodersForTesting = listOf(
            EncoderCandidate("libopenh264", false, "h264", "OpenH264")
        )
        H264EncoderSelector.mockUsabilityForTesting = true
        // FFmpegEngine in mock mode
        FFmpegEngine.mockExecutionResult = null
        FFmpegEngine.mockAsyncSessionId = 999L

        val seg0Tmp = File(testCacheDir, "seg_00000.ts.tmp").apply { writeBytes(ByteArray(1024)) }

        val request = ProgressiveGenerationRequest(
            inputUri = Uri.parse("file://${testCacheDir.absolutePath}/input.mkv"),
            outputDir = testCacheDir,
            playbackRequestId = "req_cancel",
            transcodeJobId = "job_cancel",
            segmentDurationSec = 4,
            totalEstimatedDurationMs = 60000L
        )

        val (progressFlow, _) = ProgressiveMediaGenerator.startProgressiveGeneration(
            context = context,
            request = request
        )

        // Cancel job
        val cancelled = ProgressiveMediaGenerator.cancelJob("job_cancel")
        assertTrue(cancelled)

        // Verify .tmp files cleaned up
        assertFalse("Temporary .tmp files must be deleted on cancellation", seg0Tmp.exists())
        assertNotEquals("Cancelled job must never report 100%", 100.0f, progressFlow.value.progressPercentage, 0.01f)
    }

    @Test
    fun testLibOpenH264ArgumentsDoNotContainInvalidSliceMode() = runBlocking {
        File(testCacheDir, "input.mkv").apply { writeBytes(ByteArray(1024)) }

        H264EncoderSelector.mockEncodersForTesting = listOf(
            EncoderCandidate("libopenh264", false, "h264", "OpenH264")
        )
        H264EncoderSelector.mockUsabilityForTesting = true
        FFmpegEngine.mockExecutionResult = FFmpegResult(
            sessionId = 105L,
            isSuccess = true,
            returnCode = 0,
            output = "Transcoding finished successfully",
            executionDurationMs = 150L
        )

        val request = ProgressiveGenerationRequest(
            inputUri = Uri.parse("file://${testCacheDir.absolutePath}/input.mkv"),
            outputDir = testCacheDir,
            playbackRequestId = "req_slice_test",
            transcodeJobId = "job_slice_test",
            segmentDurationSec = 4,
            totalEstimatedDurationMs = 10000L
        )

        val (progressFlow, _) = ProgressiveMediaGenerator.startProgressiveGeneration(
            context = context,
            request = request
        )

        for (i in 1..40) {
            val cmd = com.example.media.playback.TranscodingLogManager.sessionMetadata.value.command
            if (!cmd.isNullOrEmpty() && com.example.media.playback.TranscodingLogManager.sessionMetadata.value.requestId == request.playbackRequestId) break
            kotlinx.coroutines.delay(50)
        }

        val recordedCommand = com.example.media.playback.TranscodingLogManager.sessionMetadata.value.command ?: ""
        assertFalse("Command must not contain unrecognized -slice_mode", recordedCommand.contains("-slice_mode"))
        assertFalse("Command must not contain fixed_slice", recordedCommand.contains("fixed_slice"))
        assertTrue("Command must specify -c:v libopenh264", recordedCommand.contains("-c:v libopenh264"))
        assertFalse("Command must not contain invalid profile 'baseline'", recordedCommand.contains("-profile:v baseline"))
        assertTrue("Command must contain 'constrained_baseline' for libopenh264", recordedCommand.contains("-profile:v constrained_baseline"))
        assertFalse("Command must not pass unsupported -level:v to libopenh264", recordedCommand.contains("-level:v"))
    }

    @Test
    fun testLibOpenH264MapsRequestedBaselineProfileToConstrainedBaseline() = runBlocking {
        File(testCacheDir, "input2.mkv").apply { writeBytes(ByteArray(1024)) }

        H264EncoderSelector.mockEncodersForTesting = listOf(
            EncoderCandidate("libopenh264", false, "h264", "OpenH264")
        )
        H264EncoderSelector.mockUsabilityForTesting = true
        FFmpegEngine.mockExecutionResult = FFmpegResult(
            sessionId = 106L,
            isSuccess = true,
            returnCode = 0,
            output = "Transcoding finished successfully",
            executionDurationMs = 150L
        )

        val request = ProgressiveGenerationRequest(
            inputUri = Uri.parse("file://${testCacheDir.absolutePath}/input2.mkv"),
            outputDir = testCacheDir,
            playbackRequestId = "req_profile_map_test",
            transcodeJobId = "job_profile_map_test",
            targetProfile = "baseline",
            segmentDurationSec = 4,
            totalEstimatedDurationMs = 10000L
        )

        val (progressFlow, _) = ProgressiveMediaGenerator.startProgressiveGeneration(
            context = context,
            request = request
        )

        for (i in 1..40) {
            val cmd = com.example.media.playback.TranscodingLogManager.sessionMetadata.value.command
            if (!cmd.isNullOrEmpty() && com.example.media.playback.TranscodingLogManager.sessionMetadata.value.requestId == request.playbackRequestId) break
            kotlinx.coroutines.delay(50)
        }

        val recordedCommand = com.example.media.playback.TranscodingLogManager.sessionMetadata.value.command ?: ""
        assertFalse("Command must not contain literal 'baseline'", recordedCommand.contains("-profile:v baseline"))
        assertTrue("Command must map 'baseline' to 'constrained_baseline'. Was: $recordedCommand", recordedCommand.contains("-profile:v constrained_baseline"))
        assertFalse("Command must not contain -level:v for libopenh264", recordedCommand.contains("-level:v"))
    }
}
