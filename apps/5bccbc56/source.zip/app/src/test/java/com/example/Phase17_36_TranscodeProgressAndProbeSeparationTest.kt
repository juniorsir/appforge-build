package com.example

import com.example.media.ffmpeg.FFmpegEngine
import com.example.media.ffmpeg.FFmpegOperationType
import com.example.media.ffmpeg.FFmpegProgress
import com.example.media.ffmpeg.FFmpegResult
import com.example.media.ffmpeg.FFmpegSessionManager
import com.example.media.ffmpeg.FFmpegState
import com.example.media.playback.TranscodingLifecycleState
import com.example.media.playback.TranscodingLogManager
import com.example.media.progressive.ProgressiveGenerationProgress
import com.example.media.progressive.ProgressiveGenerationRequest
import com.example.media.progressive.ProgressiveState
import com.example.media.progressive.ProgressiveTranscodeController
import com.example.media.progressive.ProgressiveTranscodeStatus
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.runTest
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config
import java.io.File

@OptIn(ExperimentalCoroutinesApi::class)
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [33])
class Phase17_36_TranscodeProgressAndProbeSeparationTest {

    @Before
    fun setup() {
        FFmpegEngine.resetForTesting()
        TranscodingLogManager.clear()
        ProgressiveTranscodeController.reset()
    }

    @After
    fun tearDown() {
        FFmpegEngine.resetForTesting()
        TranscodingLogManager.clear()
        ProgressiveTranscodeController.reset()
    }

    @Test
    fun testProbeLogsDoNotPolluteTranscodingLogManager() = runTest {
        // Simulate probe session scope
        FFmpegSessionManager.withOperationScope(FFmpegOperationType.ENCODER_PROBE) {
            FFmpegSessionManager.registerContext(
                sessionId = 2L,
                operationType = FFmpegOperationType.ENCODER_PROBE,
                command = "-hide_banner -encoders"
            )
        }

        // Verify context registration
        val ctx = FFmpegSessionManager.getSessionContext(2L)
        assertEquals(FFmpegOperationType.ENCODER_PROBE, ctx?.operationType)
        assertFalse(ctx?.isTranscoding ?: true)

        // Ensure TranscodingLogManager has no logs from probe
        assertEquals(0, TranscodingLogManager.logs.value.size)
        assertFalse(TranscodingLogManager.hasLogs.value)
    }

    @Test
    fun testTranscodingSessionMetadataAndProgress() = runTest {
        val reqId = "test-req-123"
        val jobId = "test-job-456"

        FFmpegSessionManager.registerContext(
            sessionId = 10L,
            operationType = FFmpegOperationType.ACTUAL_TRANSCODING,
            requestId = reqId,
            jobId = jobId,
            command = "-i test.mkv -c:v libopenh264 test.m3u8",
            totalDurationMs = 60_000L
        )

        val ctx = FFmpegSessionManager.getSessionContext(10L)
        assertEquals(FFmpegOperationType.ACTUAL_TRANSCODING, ctx?.operationType)
        assertTrue(ctx?.isTranscoding == true)

        // Simulate progress emission
        val progress = FFmpegProgress(
            sessionId = 10L,
            state = FFmpegState.RUNNING,
            progressPercentage = 35.5f,
            currentTimestampMs = 21_300L,
            totalDurationMs = 60_000L,
            speed = 1.85,
            fps = 24.0,
            latestLogLine = "frame= 510 fps=24 q=28.0 size= 1024kB time=00:00:21.30 bitrate= 393.5kbits/s speed=1.85x"
        )

        TranscodingLogManager.recordProgress(progress, reqId)

        val metadata = TranscodingLogManager.sessionMetadata.value
        assertEquals(10L, metadata.sessionId)
        assertEquals(reqId, metadata.requestId)
        assertEquals("RUNNING", metadata.status)
        assertEquals(35.5f, metadata.progressPercentage ?: 0f, 0.01f)
        assertEquals(21_300L, metadata.currentTimestampMs)
        assertEquals(60_000L, metadata.totalDurationMs)
        assertEquals(1.85, metadata.speed, 0.01)
        assertTrue(metadata.isActive)
    }

    @Test
    fun testProgressiveTranscodeControllerTracksTranscodedDuration() = runTest {
        val context = RuntimeEnvironment.getApplication()
        val tempFile = File.createTempFile("test_source", ".mp4").apply {
            writeBytes(ByteArray(1024))
            deleteOnExit()
        }

        FFmpegEngine.mockExecutionResult = FFmpegResult(
            sessionId = 100L,
            isSuccess = true,
            returnCode = 0,
            output = "Mock progressive transcode completed"
        )

        val request = ProgressiveGenerationRequest(
            playbackRequestId = "test-req-xyz",
            transcodeJobId = "test-job-xyz",
            inputUri = android.net.Uri.fromFile(tempFile),
            outputDir = context.cacheDir,
            totalEstimatedDurationMs = 120_000L
        )

        val stateFlow = ProgressiveTranscodeController.startTranscoding(context, request)
        val initial = stateFlow.first()
        assertEquals(ProgressiveTranscodeStatus.STARTING, initial.status)

        // Simulate a progress update with 30s transcoded
        val progress = ProgressiveGenerationProgress(
            playbackRequestId = request.playbackRequestId,
            transcodeJobId = request.transcodeJobId,
            state = ProgressiveState.GENERATING,
            progressPercentage = 25.0f,
            transcodedDurationMs = 30_000L,
            playableDurationMs = 14_000L,
            sourceDurationMs = 120_000L,
            transcodingSpeed = 2.0f,
            fps = 30.0,
            publishedUnitsCount = 2,
            sessionId = 100L
        )

        TranscodingLogManager.recordProgressiveProgress(progress, request.playbackRequestId)

        val meta = TranscodingLogManager.sessionMetadata.value
        assertEquals(25.0f, meta.progressPercentage ?: 0f, 0.01f)
        assertEquals(30_000L, meta.currentTimestampMs)
        assertEquals(120_000L, meta.totalDurationMs)
    }
}
