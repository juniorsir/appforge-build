package com.example

import android.content.Context
import android.net.Uri
import androidx.test.core.app.ApplicationProvider
import com.example.media.progressive.*
import com.example.media.playback.PlaybackRequestCoordinator
import kotlinx.coroutines.*
import kotlinx.coroutines.test.runTest
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class Phase17_38_ProgressivePlaybackLifecycleHardeningTest {

    private lateinit var context: Context
    private lateinit var testCacheDir: File

    @Before
    fun setUp() {
        context = ApplicationProvider.getApplicationContext()
        testCacheDir = context.cacheDir
        SmartPlaybackController.reset()
        ProgressivePlaybackCoordinator.reset()
        ProgressiveJobManager.resetForTesting()
        ProgressiveCacheManager.resetForTesting()
        PlaybackRequestCoordinator.resetForTesting()
    }

    @After
    fun tearDown() {
        SmartPlaybackController.reset()
        ProgressivePlaybackCoordinator.reset()
        ProgressiveJobManager.resetForTesting()
        ProgressiveCacheManager.resetForTesting()
        PlaybackRequestCoordinator.resetForTesting()
        testCacheDir.listFiles()?.forEach { file ->
            if (file.name.startsWith("test_") || file.name.startsWith("progressive_")) {
                file.deleteRecursively()
            }
        }
    }

    /**
     * Test 1: Lifecycle Ownership & Player Reconnection
     * Screen recreation or player recreation for the same requestId updates playerInstanceId
     * and reconnects to the active progressive session without creating a duplicate job.
     */
    @Test
    fun test1_playerRecreation_reconnectsWithoutDuplicateJob() = runTest {
        val initialPlayerId = "player_inst_01"
        val recreatedPlayerId = "player_inst_02"

        val (req, _) = PlaybackRequestCoordinator.getOrCreateRequest("media_rec_01", Uri.parse("file:///dummy.mkv"), "/dummy.mkv")
        val reqId = req.requestId
        PlaybackRequestCoordinator.setActivePlayerInstanceId(initialPlayerId)

        SmartPlaybackController.startTracking(
            playbackRequestId = reqId,
            playerInstanceId = initialPlayerId,
            transcodeJobId = "P_$reqId",
            sourceDurationMs = 60_000L
        )

        SmartPlaybackController.updateTranscodeProgress(
            playableDurationMs = 12_000L,
            productionRate = 1.5f,
            fps = 30.0,
            generatedUnitsCount = 3,
            isCompleted = false
        )

        // Verify initial state
        val initialMetrics = SmartPlaybackController.metrics.value
        assertEquals(initialPlayerId, initialMetrics.playerInstanceId)
        assertEquals(12_000L, initialMetrics.playableDurationMs)

        // Simulate Player Recreation (e.g. Activity rotation / Screen recreation)
        // Reconnect new player instance to the same active request
        SmartPlaybackController.reconnectPlayer(recreatedPlayerId, reqId)
        PlaybackRequestCoordinator.setActivePlayerInstanceId(recreatedPlayerId)

        val reconnectedMetrics = SmartPlaybackController.metrics.value
        assertEquals(recreatedPlayerId, reconnectedMetrics.playerInstanceId)
        assertEquals(12_000L, reconnectedMetrics.playableDurationMs) // Transcode progress retained
        assertEquals(recreatedPlayerId, PlaybackRequestCoordinator.getActivePlayerInstanceId())
    }

    /**
     * Test 2: Safe Background Policy
     * App background transition pauses the player while background transcoding continues safely.
     * When returning to foreground, buffer lead is increased and playback can resume.
     */
    @Test
    fun test2_backgroundPolicy_preservesTranscodeProgress() = runTest {
        val reqId = "req_bg_01"
        SmartPlaybackController.startTracking(
            playbackRequestId = reqId,
            playerInstanceId = "player_bg",
            sourceDurationMs = 100_000L
        )

        // Starting transcode: 10s playable, pos = 4s (lead = 6s)
        SmartPlaybackController.updateTranscodeProgress(
            playableDurationMs = 10_000L,
            productionRate = 1.2f,
            fps = 24.0,
            generatedUnitsCount = 2,
            isCompleted = false
        )
        SmartPlaybackController.updatePlaybackMetrics(
            playbackPositionMs = 4_000L,
            internalBufferedPositionMs = 4_000L,
            consumptionRate = 1.0f,
            isPlaying = true,
            isBuffering = false
        )

        assertEquals(6_000L, SmartPlaybackController.metrics.value.progressiveLeadMs)

        // App transitions to background
        SmartPlaybackController.onAppBackground(reqId)
        ProgressivePlaybackCoordinator.onAppBackgrounded(reqId)

        // While in background, background transcode advances from 10s to 30s
        SmartPlaybackController.updateTranscodeProgress(
            playableDurationMs = 30_000L,
            productionRate = 1.4f,
            fps = 28.0,
            generatedUnitsCount = 6,
            isCompleted = false
        )

        // App transitions back to foreground: position is still 4s, playable is now 30s (lead = 26s)
        ProgressivePlaybackCoordinator.onAppForegrounded(reqId)
        SmartPlaybackController.onAppForeground(reqId)

        SmartPlaybackController.updatePlaybackMetrics(
            playbackPositionMs = 4_000L,
            internalBufferedPositionMs = 4_000L,
            consumptionRate = 1.0f,
            isPlaying = false, // paused during background
            isBuffering = false
        )

        val fgMetrics = SmartPlaybackController.metrics.value
        assertEquals(30_000L, fgMetrics.playableDurationMs)
        assertEquals(26_000L, fgMetrics.progressiveLeadMs)
        assertEquals(SmartBufferState.HEALTHY, fgMetrics.state)
    }

    /**
     * Test 3: Process Death & Startup Sanitation
     * Startup sanitation purges incomplete directories from crashed runs and deletes stray .tmp files,
     * while preserving valid completed progressive caches.
     */
    @Test
    fun test3_processDeath_startupSanitationCleansIncompleteArtifacts() {
        // 1. Create a stale incomplete working directory (simulating dead process mid-transcode)
        val staleWorkingDir = File(testCacheDir, "progressive_dead_req_123").apply { mkdirs() }
        File(staleWorkingDir, "live_playlist.m3u8").writeText("#EXTM3U\n#EXTINF:4.000,\nseg_00000.ts\n") // No #EXT-X-ENDLIST
        File(staleWorkingDir, "seg_00000.ts").writeText("data")
        File(staleWorkingDir, "seg_00001.ts.tmp").writeText("partial") // Stray tmp file

        // 2. Create orphaned tmp files in cacheDir
        val orphanTmpFile1 = File(testCacheDir, "fallback_abandoned.tmp").apply { writeText("trash") }
        val orphanTmpFile2 = File(testCacheDir, "media_orphaned.tmp").apply { writeText("trash") }

        // 3. Create a valid complete progressive cache directory
        val validCacheDir = File(testCacheDir, "progressive_cache_valid_media_99").apply { mkdirs() }
        File(validCacheDir, "live_playlist.m3u8").writeText("#EXTM3U\n#EXTINF:4.000,\nseg_00000.ts\n#EXT-X-ENDLIST\n")
        File(validCacheDir, "seg_00000.ts").writeText("valid_ts_content")

        assertTrue(staleWorkingDir.exists())
        assertTrue(orphanTmpFile1.exists())
        assertTrue(orphanTmpFile2.exists())
        assertTrue(validCacheDir.exists())

        // Run startup sanitation
        ProgressiveRecoveryManager.performStartupSanitation(context)

        // Incomplete working dir must be purged
        assertFalse("Stale incomplete working dir should be deleted", staleWorkingDir.exists())
        // Orphaned tmp files must be purged
        assertFalse("Orphaned tmp file 1 should be deleted", orphanTmpFile1.exists())
        assertFalse("Orphaned tmp file 2 should be deleted", orphanTmpFile2.exists())
        // Valid complete cache must be preserved!
        assertTrue("Valid complete cache must be preserved", validCacheDir.exists())
        assertTrue(File(validCacheDir, "live_playlist.m3u8").exists())
    }

    /**
     * Test 4: Rapid Media Switching Discipline
     * Switching rapidly A -> B -> C cancels previous requests, drops stale callbacks,
     * and keeps active request isolated.
     */
    @Test
    fun test4_rapidMediaSwitching_isolatesActiveRequest() = runTest {
        // Request A starts
        val (reqAObj, _) = PlaybackRequestCoordinator.getOrCreateRequest("mediaA", Uri.parse("file:///mediaA.mkv"), "/mediaA.mkv")
        val reqA = reqAObj.requestId
        SmartPlaybackController.startTracking(reqA, "player_A", "P_$reqA", 100_000L)

        // Rapid switch to Request B
        val (reqBObj, _) = PlaybackRequestCoordinator.getOrCreateRequest("mediaB", Uri.parse("file:///mediaB.mkv"), "/mediaB.mkv")
        val reqB = reqBObj.requestId
        SmartPlaybackController.startTracking(reqB, "player_B", "P_$reqB", 100_000L)

        // Rapid switch to Request C
        val (reqCObj, _) = PlaybackRequestCoordinator.getOrCreateRequest("mediaC", Uri.parse("file:///mediaC.mkv"), "/mediaC.mkv")
        val reqC = reqCObj.requestId
        SmartPlaybackController.startTracking(reqC, "player_C", "P_$reqC", 100_000L)

        assertEquals(reqC, PlaybackRequestCoordinator.getActiveRequestId())
        assertEquals(reqC, SmartPlaybackController.metrics.value.playbackRequestId)

        // Simulate a late callback arriving from Request A (should be rejected/dropped)
        SmartPlaybackController.updateTranscodeProgress(
            playableDurationMs = 50_000L,
            productionRate = 2.0f,
            fps = 60.0,
            generatedUnitsCount = 10,
            isCompleted = false
        )
        // Notice: SmartPlaybackController tracks reqC, so state updates without reqId matching reqC are not affecting reqC
        assertEquals(reqC, SmartPlaybackController.metrics.value.playbackRequestId)
    }

    /**
     * Test 5: Cache Validation & Finalization Contract
     * Strict contract: Only streams containing #EXT-X-ENDLIST, zero .tmp files, and valid segments
     * are accepted as cache entries. Incomplete streams are rejected.
     */
    @Test
    fun test5_cacheValidation_enforcesCompletenessContract() {
        val testDirComplete = File(testCacheDir, "test_cache_complete").apply { mkdirs() }
        File(testDirComplete, "live_playlist.m3u8").writeText("#EXTM3U\n#EXTINF:4.000,\nseg_00000.ts\n#EXT-X-ENDLIST\n")
        File(testDirComplete, "seg_00000.ts").writeText("segment_bytes")

        val isValidComplete = ProgressiveCacheManager.isCacheValid(testDirComplete)
        assertTrue("Complete stream with #EXT-X-ENDLIST and segment must be valid", isValidComplete)

        // Incomplete: missing #EXT-X-ENDLIST
        val testDirIncomplete = File(testCacheDir, "test_cache_incomplete").apply { mkdirs() }
        File(testDirIncomplete, "live_playlist.m3u8").writeText("#EXTM3U\n#EXTINF:4.000,\nseg_00000.ts\n")
        File(testDirIncomplete, "seg_00000.ts").writeText("segment_bytes")

        val isValidIncomplete = ProgressiveCacheManager.isCacheValid(testDirIncomplete)
        assertFalse("Incomplete stream missing #EXT-X-ENDLIST must be rejected", isValidIncomplete)

        // Invalid: contains .tmp file
        val testDirWithTmp = File(testCacheDir, "test_cache_with_tmp").apply { mkdirs() }
        File(testDirWithTmp, "live_playlist.m3u8").writeText("#EXTM3U\n#EXTINF:4.000,\nseg_00000.ts\n#EXT-X-ENDLIST\n")
        File(testDirWithTmp, "seg_00000.ts").writeText("segment_bytes")
        File(testDirWithTmp, "seg_00001.ts.tmp").writeText("partial")

        val isValidWithTmp = ProgressiveCacheManager.isCacheValid(testDirWithTmp)
        assertFalse("Stream containing .tmp files must be rejected", isValidWithTmp)

        // Invalid: missing referenced segment
        val testDirMissingSeg = File(testCacheDir, "test_cache_missing_seg").apply { mkdirs() }
        File(testDirMissingSeg, "live_playlist.m3u8").writeText("#EXTM3U\n#EXTINF:4.000,\nseg_00000.ts\n#EXT-X-ENDLIST\n")

        val isValidMissingSeg = ProgressiveCacheManager.isCacheValid(testDirMissingSeg)
        assertFalse("Stream missing referenced segment file must be rejected", isValidMissingSeg)
    }

    /**
     * Test 6: Cache Registration & Instant Cache Hit Reuse
     * Registering a validated complete output allows instant retrieval on subsequent playback
     * of the same media key without running FFmpeg.
     */
    @Test
    fun test6_cacheRegistration_enablesInstantReuse() {
        val mediaKey = "sololeveling_ep01"
        val outputDir = File(testCacheDir, "progressive_cache_$mediaKey").apply { mkdirs() }
        File(outputDir, "live_playlist.m3u8").writeText("#EXTM3U\n#EXTINF:10.000,\nseg_00000.ts\n#EXT-X-ENDLIST\n")
        File(outputDir, "seg_00000.ts").writeText("valid_video_data")

        val registered = ProgressiveCacheManager.registerCompletedCache(
            context = context,
            requestId = "req_100",
            mediaKey = mediaKey,
            outputDir = outputDir,
            expectedDurationMs = 10_000L
        )
        assertTrue("Registration must succeed for complete output", registered)

        // Subsequent playback query
        val cachedDir = ProgressiveCacheManager.getCompletedCache(context, mediaKey, 10_000L)
        assertNotNull("Must return cached directory on hit", cachedDir)
        assertEquals(outputDir.absolutePath, cachedDir!!.absolutePath)
    }

    /**
     * Test 7: Hardened Cancellation & Temporary File Cleaning
     * Cancelling progressive playback purges all .tmp files and resets tracking state.
     */
    @Test
    fun test7_cancelPlayback_cleansTemporaryFilesAndResetsState() = runTest {
        val reqId = "req_cancel_01"
        val workingDir = File(testCacheDir, "progressive_$reqId").apply { mkdirs() }
        val tmp1 = File(workingDir, "seg_00000.ts.tmp").apply { writeText("temp1") }
        val tmp2 = File(workingDir, "seg_00001.ts.tmp").apply { writeText("temp2") }
        val stable = File(workingDir, "live_playlist.m3u8").apply { writeText("#EXTM3U") }

        SmartPlaybackController.startTracking(reqId, "player_cancel", "P_$reqId", 50_000L)

        // Cancel playback
        ProgressivePlaybackCoordinator.cancelPlayback(reqId, context = context)

        // Verify .tmp files were cleaned
        assertFalse("tmp1 should be deleted", tmp1.exists())
        assertFalse("tmp2 should be deleted", tmp2.exists())
        // Tracking should be reset
        assertEquals(SmartBufferState.UNKNOWN, SmartPlaybackController.metrics.value.state)
        assertNull(SmartPlaybackController.metrics.value.playbackRequestId)
    }

    /**
     * Test 8: Stale Working Directory Cleanup during Media Switching
     * Ensures abandoned working directories from older requests are cleaned up.
     */
    @Test
    fun test8_cleanStaleWorkingDirectories_purgesUnreferencedDirectories() {
        val activeReqId = "req_active_today"
        val staleReqId = "req_abandoned_yesterday"

        val activeDir = File(testCacheDir, "progressive_$activeReqId").apply { mkdirs() }
        File(activeDir, "live_playlist.m3u8").writeText("#EXTM3U")

        val staleDir = File(testCacheDir, "progressive_$staleReqId").apply { mkdirs() }
        File(staleDir, "live_playlist.m3u8").writeText("#EXTM3U") // incomplete, no ENDLIST

        ProgressiveRecoveryManager.cleanStaleWorkingDirectories(context, setOf(activeReqId))

        assertTrue("Active directory must be retained", activeDir.exists())
        assertFalse("Stale unreferenced incomplete directory must be purged", staleDir.exists())
    }
}
