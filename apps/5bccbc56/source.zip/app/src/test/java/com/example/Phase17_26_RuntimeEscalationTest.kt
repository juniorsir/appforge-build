package com.example

import android.net.Uri
import androidx.media3.common.PlaybackException
import androidx.media3.exoplayer.ExoPlaybackException
import androidx.media3.common.C
import androidx.media3.common.Format
import com.example.media.playback.PlaybackErrorClassifier
import com.example.media.playback.PlaybackErrorCategory
import com.example.media.playback.PlaybackErrorStage
import com.example.media.playback.PlaybackRecoveryAction
import com.example.media.playback.PlaybackSourceType
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Assert.assertFalse
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import java.io.IOException

@RunWith(RobolectricTestRunner::class)
class Phase17_26_RuntimeEscalationTest {

    @Test
    fun test_direct_decoder_failure_escalates() {
        val reqId = "req_escalate"
        val error = PlaybackException(
            "Decoder init failed", null, PlaybackException.ERROR_CODE_DECODER_INIT_FAILED
        )

        val classified = PlaybackErrorClassifier.classifyMedia3Error(
            requestId = reqId,
            error = error,
            sourceType = PlaybackSourceType.ORIGINAL,
            fallbackAttemptCount = 0
        )

        assertEquals(PlaybackErrorCategory.MEDIA3_DECODER_FAILED, classified.category)
        assertEquals(PlaybackRecoveryAction.TRANSCODE_FALLBACK, classified.recoveryAction)
    }

    @Test
    fun test_audio_renderer_failure_no_fallback() {
        val reqId = "req_audio"
        
        val format = Format.Builder().setSampleMimeType("audio/mp4a-latm").build()
        val error = ExoPlaybackException.createForRenderer(
            IllegalArgumentException("Audio decode failed"),
            "audio_decoder",
            0,
            format,
            C.FORMAT_EXCEEDS_CAPABILITIES,
            false,
            PlaybackException.ERROR_CODE_DECODING_FORMAT_EXCEEDS_CAPABILITIES
        )

        val classified = PlaybackErrorClassifier.classifyMedia3Error(
            requestId = reqId,
            error = error,
            sourceType = PlaybackSourceType.ORIGINAL,
            fallbackAttemptCount = 0
        )

        assertEquals(PlaybackErrorCategory.MEDIA3_DECODER_FAILED, classified.category)
        assertEquals(PlaybackRecoveryAction.PLAYBACK_FAILED, classified.recoveryAction)
    }

    @Test
    fun test_video_renderer_failure_escalates() {
        val reqId = "req_video"
        
        val format = Format.Builder().setSampleMimeType("video/avc").build()
        val error = ExoPlaybackException.createForRenderer(
            IllegalArgumentException("Video decode failed"),
            "video_decoder",
            0,
            format,
            C.FORMAT_EXCEEDS_CAPABILITIES,
            false,
            PlaybackException.ERROR_CODE_DECODING_FORMAT_EXCEEDS_CAPABILITIES
        )

        val classified = PlaybackErrorClassifier.classifyMedia3Error(
            requestId = reqId,
            error = error,
            sourceType = PlaybackSourceType.ORIGINAL,
            fallbackAttemptCount = 0
        )

        assertEquals(PlaybackErrorCategory.MEDIA3_DECODER_FAILED, classified.category)
        assertEquals(PlaybackRecoveryAction.TRANSCODE_FALLBACK, classified.recoveryAction)
    }

    @Test
    fun test_non_codec_failure_no_fallback() {
        val reqId = "req_io"
        val error = PlaybackException(
            "File not found", null, PlaybackException.ERROR_CODE_IO_FILE_NOT_FOUND
        )

        val classified = PlaybackErrorClassifier.classifyMedia3Error(
            requestId = reqId,
            error = error,
            sourceType = PlaybackSourceType.ORIGINAL,
            fallbackAttemptCount = 0
        )

        assertEquals(PlaybackErrorCategory.INPUT_NOT_FOUND, classified.category)
        assertEquals(PlaybackRecoveryAction.STOP, classified.recoveryAction)
    }

    @Test
    fun test_fallback_decoder_failure_is_terminal() {
        val reqId = "req_fallback_fail"
        val error = PlaybackException(
            "Decoder failed", null, PlaybackException.ERROR_CODE_DECODING_FAILED
        )

        val classified = PlaybackErrorClassifier.classifyMedia3Error(
            requestId = reqId,
            error = error,
            sourceType = PlaybackSourceType.FALLBACK,
            fallbackAttemptCount = 1
        )

        assertEquals(PlaybackErrorCategory.MEDIA3_DECODER_FAILED, classified.category)
        assertEquals(PlaybackRecoveryAction.PLAYBACK_FAILED, classified.recoveryAction)
    }
}
