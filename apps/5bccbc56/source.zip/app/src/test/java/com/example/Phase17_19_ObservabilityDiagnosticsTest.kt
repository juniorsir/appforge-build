package com.example

import com.example.media.playback.*
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger

/**
 * PHASE 17.19 — Observability & Structured Diagnostics Verification Test Suite.
 */
class Phase17_19_ObservabilityDiagnosticsTest {

    @Before
    fun setUp() {
        PlaybackDiagnosticRegistry.resetForTesting()
        PlaybackRequestCoordinator.resetForTesting()
    }

    // =========================================================================
    // 1. CORRELATION MODEL TESTS
    // =========================================================================

    @Test
    fun testCorrelationModel_AllIdsMappedCorrectly() {
        val reqId = "req-1719"
        val playerInstanceId = PlaybackRequestCoordinator.generateNextPlayerInstanceId()
        val analysisId = PlaybackRequestCoordinator.generateNextAnalysisId(reqId)
        val ffmpegJobId = PlaybackRequestCoordinator.generateNextFfmpegJobId(reqId)
        val operationId = "OP_PROBE_01"

        assertTrue(playerInstanceId.startsWith("P"))
        assertTrue(analysisId.contains(reqId))
        assertTrue(ffmpegJobId.contains(reqId))

        val event = PlaybackDiagnosticRegistry.recordEvent(
            eventType = DiagnosticEventType.ANALYSIS_STARTED,
            stage = PlaybackErrorStage.ANALYSIS,
            severity = DiagnosticSeverity.INFO,
            playbackRequestId = reqId,
            operationId = operationId,
            playerInstanceId = playerInstanceId,
            analysisJobId = analysisId,
            ffmpegJobId = ffmpegJobId,
            sourceType = PlaybackSourceType.ORIGINAL,
            rawUriOrPath = "https://example.com/video.mkv?token=secret123",
            message = "Starting media probe analysis"
        )

        assertEquals(reqId, event.playbackRequestId)
        assertEquals(playerInstanceId, event.playerInstanceId)
        assertEquals(analysisId, event.analysisJobId)
        assertEquals(ffmpegJobId, event.ffmpegJobId)
        assertEquals(operationId, event.operationId)
        assertEquals(PlaybackSourceType.ORIGINAL, event.sourceType)
        assertFalse(event.sourceUriIdentity!!.contains("secret123"))
    }

    // =========================================================================
    // 2. STRUCTURED DIAGNOSTIC EVENT & SEVERITY TESTS
    // =========================================================================

    @Test
    fun testDiagnosticEventTypes_AllCovered() {
        val reqId = "req-event-types"
        val types = DiagnosticEventType.values()
        assertTrue(types.size >= 25)

        for (type in types) {
            val event = PlaybackDiagnosticRegistry.recordEvent(
                eventType = type,
                stage = PlaybackErrorStage.MEDIA3_PLAYBACK,
                severity = DiagnosticSeverity.DEBUG,
                playbackRequestId = reqId,
                message = "Testing event type ${type.name}"
            )
            assertEquals(type, event.eventType)
        }

        val events = PlaybackDiagnosticRegistry.getEventsForRequest(reqId)
        assertEquals(types.size, events.size)
    }

    @Test
    fun testDiagnosticSeverityLevels() {
        val reqId = "req-severity"
        val debugEvent = PlaybackDiagnosticRegistry.recordEvent(
            eventType = DiagnosticEventType.INPUT_RECEIVED,
            stage = PlaybackErrorStage.INPUT,
            severity = DiagnosticSeverity.DEBUG,
            playbackRequestId = reqId,
            message = "Debug level"
        )
        val infoEvent = PlaybackDiagnosticRegistry.recordEvent(
            eventType = DiagnosticEventType.MEDIA3_READY,
            stage = PlaybackErrorStage.MEDIA3_PLAYBACK,
            severity = DiagnosticSeverity.INFO,
            playbackRequestId = reqId,
            message = "Info level"
        )
        val warnEvent = DiagnosticEvent(
            sequenceNumber = 3,
            eventType = DiagnosticEventType.STALE_EVENT,
            stage = PlaybackErrorStage.MEDIA3_PLAYBACK,
            severity = DiagnosticSeverity.WARN,
            playbackRequestId = reqId,
            message = "Warn level"
        )
        val errorEvent = PlaybackDiagnosticRegistry.recordEvent(
            eventType = DiagnosticEventType.MEDIA3_ERROR,
            stage = PlaybackErrorStage.MEDIA3_PLAYBACK,
            severity = DiagnosticSeverity.ERROR,
            playbackRequestId = reqId,
            message = "Error level"
        )

        assertEquals(DiagnosticSeverity.DEBUG, debugEvent.severity)
        assertEquals(DiagnosticSeverity.INFO, infoEvent.severity)
        assertEquals(DiagnosticSeverity.WARN, warnEvent.severity)
        assertEquals(DiagnosticSeverity.ERROR, errorEvent.severity)
    }

    // =========================================================================
    // 3. SAFE URI SANITIZATION & ANONYMIZATION TESTS
    // =========================================================================

    @Test
    fun testSafeUriSanitization_RemoteUrlWithAuthTokens() {
        val rawUrl = "https://cdn.example.com/stream/video.mp4?auth_token=supersecret123&sig=abcdef#fragment"
        val safeUri = PlaybackDiagnosticRegistry.toSafeUriIdentity(rawUrl)

        assertFalse("Safe URI must not contain auth token", safeUri.contains("supersecret123"))
        assertFalse("Safe URI must not contain signature", safeUri.contains("sig="))
        assertTrue("Safe URI must identify host", safeUri.contains("cdn.example.com"))
        assertTrue("Safe URI must use source scheme", safeUri.startsWith("source://https/"))
    }

    @Test
    fun testSafeUriSanitization_LocalPrivateStorage() {
        val rawPath = "/data/user/0/com.example.app/cache/fallback_output_123.mp4"
        val safeUri = PlaybackDiagnosticRegistry.toSafeUriIdentity(rawPath)

        assertFalse("Safe URI must not contain internal user sandbox path", safeUri.contains("/data/user/0"))
        assertTrue("Safe URI must indicate cache/fallback and filename", safeUri.contains("fallback_output_123.mp4"))
        assertTrue("Safe URI must start with source://cache/", safeUri.startsWith("source://cache/"))
    }

    @Test
    fun testSafeUriSanitization_ContentUri() {
        val rawContent = "content://media/external/video/media/42"
        val safeUri = PlaybackDiagnosticRegistry.toSafeUriIdentity(rawContent)

        assertTrue(safeUri.startsWith("source://content/media/42"))
    }

    // =========================================================================
    // 4. EVENT ORDERING, SEQUENCE MONOTONICITY & THREAD SAFETY
    // =========================================================================

    @Test
    fun testEventOrdering_SequenceNumbersMonotonicallyIncreasing() {
        val reqId = "req-seq"
        val e1 = PlaybackDiagnosticRegistry.recordEvent(DiagnosticEventType.INPUT_RECEIVED, PlaybackErrorStage.INPUT, DiagnosticSeverity.INFO, reqId, message = "1")
        val e2 = PlaybackDiagnosticRegistry.recordEvent(DiagnosticEventType.ANALYSIS_STARTED, PlaybackErrorStage.ANALYSIS, DiagnosticSeverity.INFO, reqId, message = "2")
        val e3 = PlaybackDiagnosticRegistry.recordEvent(DiagnosticEventType.METADATA_NORMALIZED, PlaybackErrorStage.ANALYSIS, DiagnosticSeverity.INFO, reqId, message = "3")

        assertTrue(e2.sequenceNumber > e1.sequenceNumber)
        assertTrue(e3.sequenceNumber > e2.sequenceNumber)
    }

    @Test
    fun testThreadSafety_ConcurrentLogging() {
        val reqId = "req-concurrent"
        val threads = 8
        val eventsPerThread = 50
        val latch = CountDownLatch(threads)

        for (i in 0 until threads) {
            Thread {
                for (j in 0 until eventsPerThread) {
                    PlaybackDiagnosticRegistry.recordEvent(
                        eventType = DiagnosticEventType.FFMPEG_JOB_PROGRESS,
                        stage = PlaybackErrorStage.FALLBACK_PROCESSING,
                        severity = DiagnosticSeverity.DEBUG,
                        playbackRequestId = reqId,
                        message = "Progress thread $i step $j"
                    )
                }
                latch.countDown()
            }.start()
        }

        assertTrue(latch.await(5, TimeUnit.SECONDS))
        val events = PlaybackDiagnosticRegistry.getEventsForRequest(reqId)
        assertTrue(events.isNotEmpty())
        assertTrue("Ring buffer limits events to maximum per request", events.size <= 150)
    }

    // =========================================================================
    // 5. TERMINAL RESULT UNIQUENESS & STATE INVARIANTS
    // =========================================================================

    @Test
    fun testTerminalResultUniqueness_OnlyFirstTerminalRecorded() {
        val reqId = "req-terminal-unique"

        PlaybackStateTracker.logFinalResult(
            requestId = reqId,
            result = AuthoritativePlaybackResult.DIRECT_SUCCESS,
            playbackPath = "/storage/video.mp4",
            fallbackUsed = false,
            decoder = "c2.android.avc.decoder"
        )

        assertEquals(AuthoritativePlaybackResult.DIRECT_SUCCESS, PlaybackDiagnosticRegistry.getTerminalResult(reqId))

        // Attempt duplicate / conflicting terminal result
        PlaybackStateTracker.logFinalResult(
            requestId = reqId,
            result = AuthoritativePlaybackResult.DIRECT_FAILED,
            playbackPath = "/storage/video.mp4",
            fallbackUsed = false,
            decoder = "c2.android.avc.decoder"
        )

        // Must still remain DIRECT_SUCCESS
        assertEquals(AuthoritativePlaybackResult.DIRECT_SUCCESS, PlaybackDiagnosticRegistry.getTerminalResult(reqId))
    }

    // =========================================================================
    // 6. PIPELINE TRACE & SOURCE DISTINCTION (DIRECT VS. FALLBACK)
    // =========================================================================

    @Test
    fun testPipelineTrace_DirectPlaybackEndToEnd() {
        val reqId = "req-direct-pipeline"
        val player = "P1"

        PlaybackDiagnosticRegistry.recordEvent(DiagnosticEventType.INPUT_RECEIVED, PlaybackErrorStage.INPUT, DiagnosticSeverity.INFO, reqId, message = "Input")
        PlaybackDiagnosticRegistry.recordEvent(DiagnosticEventType.ANALYSIS_COMPLETED, PlaybackErrorStage.ANALYSIS, DiagnosticSeverity.INFO, reqId, message = "Analysis")
        PlaybackDiagnosticRegistry.recordEvent(DiagnosticEventType.DECODER_CAPABILITY_ANALYZED, PlaybackErrorStage.COMPATIBILITY, DiagnosticSeverity.INFO, reqId, message = "Decoder")
        PlaybackDiagnosticRegistry.recordEvent(DiagnosticEventType.COMPATIBILITY_EVALUATED, PlaybackErrorStage.COMPATIBILITY, DiagnosticSeverity.INFO, reqId, message = "Direct compatible")
        PlaybackDiagnosticRegistry.recordEvent(DiagnosticEventType.PLAYBACK_DECISION, PlaybackErrorStage.MEDIA3_PLAYBACK, DiagnosticSeverity.INFO, reqId, message = "Decision: DIRECT")
        PlaybackDiagnosticRegistry.recordEvent(DiagnosticEventType.MEDIA3_PREPARE_STARTED, PlaybackErrorStage.MEDIA3_PLAYBACK, DiagnosticSeverity.INFO, reqId, playerInstanceId = player, sourceType = PlaybackSourceType.ORIGINAL, message = "Prepare")
        PlaybackDiagnosticRegistry.recordEvent(DiagnosticEventType.MEDIA3_READY, PlaybackErrorStage.MEDIA3_PLAYBACK, DiagnosticSeverity.INFO, reqId, playerInstanceId = player, message = "Ready")
        PlaybackDiagnosticRegistry.recordEvent(DiagnosticEventType.MEDIA3_PLAYBACK_STARTED, PlaybackErrorStage.MEDIA3_PLAYBACK, DiagnosticSeverity.INFO, reqId, playerInstanceId = player, sourceType = PlaybackSourceType.ORIGINAL, message = "Playing")
        PlaybackDiagnosticRegistry.recordEvent(DiagnosticEventType.PLAYBACK_FINAL_RESULT, PlaybackErrorStage.MEDIA3_PLAYBACK, DiagnosticSeverity.INFO, reqId, newState = AuthoritativePlaybackResult.DIRECT_SUCCESS.name, message = "Final result")

        val events = PlaybackDiagnosticRegistry.getEventsForRequest(reqId)
        assertEquals(9, events.size)
        assertEquals(AuthoritativePlaybackResult.DIRECT_SUCCESS, PlaybackDiagnosticRegistry.getTerminalResult(reqId))
    }

    @Test
    fun testPipelineTrace_FallbackPlaybackEndToEnd() {
        val reqId = "req-fallback-pipeline"
        val player = "P2"
        val ffmpegJob = "F1_req-fallback-pipeline"

        PlaybackDiagnosticRegistry.recordEvent(DiagnosticEventType.INPUT_RECEIVED, PlaybackErrorStage.INPUT, DiagnosticSeverity.INFO, reqId, message = "Input")
        PlaybackDiagnosticRegistry.recordEvent(DiagnosticEventType.COMPATIBILITY_EVALUATED, PlaybackErrorStage.COMPATIBILITY, DiagnosticSeverity.WARN, reqId, message = "HEVC 10-bit incompatible")
        PlaybackDiagnosticRegistry.recordEvent(DiagnosticEventType.PLAYBACK_DECISION, PlaybackErrorStage.MEDIA3_PLAYBACK, DiagnosticSeverity.INFO, reqId, message = "Decision: FALLBACK_REQUIRED")
        PlaybackDiagnosticRegistry.recordEvent(DiagnosticEventType.FFMPEG_JOB_STARTED, PlaybackErrorStage.FALLBACK_PROCESSING, DiagnosticSeverity.INFO, reqId, ffmpegJobId = ffmpegJob, message = "FFmpeg transcode")
        PlaybackDiagnosticRegistry.recordEvent(DiagnosticEventType.FFMPEG_JOB_COMPLETED, PlaybackErrorStage.FALLBACK_PROCESSING, DiagnosticSeverity.INFO, reqId, ffmpegJobId = ffmpegJob, message = "FFmpeg transcode success")
        PlaybackDiagnosticRegistry.recordEvent(DiagnosticEventType.FALLBACK_VALIDATION_STARTED, PlaybackErrorStage.FALLBACK_VALIDATION, DiagnosticSeverity.INFO, reqId, message = "Validate fallback output")
        PlaybackDiagnosticRegistry.recordEvent(DiagnosticEventType.FALLBACK_VALIDATION_COMPLETED, PlaybackErrorStage.FALLBACK_VALIDATION, DiagnosticSeverity.INFO, reqId, message = "Validated MP4")
        PlaybackDiagnosticRegistry.recordEvent(DiagnosticEventType.MEDIA3_PREPARE_STARTED, PlaybackErrorStage.MEDIA3_PLAYBACK, DiagnosticSeverity.INFO, reqId, playerInstanceId = player, sourceType = PlaybackSourceType.FALLBACK, message = "Prepare fallback")
        PlaybackDiagnosticRegistry.recordEvent(DiagnosticEventType.MEDIA3_READY, PlaybackErrorStage.MEDIA3_PLAYBACK, DiagnosticSeverity.INFO, reqId, playerInstanceId = player, message = "Ready")
        PlaybackDiagnosticRegistry.recordEvent(DiagnosticEventType.MEDIA3_PLAYBACK_STARTED, PlaybackErrorStage.MEDIA3_PLAYBACK, DiagnosticSeverity.INFO, reqId, playerInstanceId = player, sourceType = PlaybackSourceType.FALLBACK, message = "Playing")
        PlaybackDiagnosticRegistry.recordEvent(DiagnosticEventType.PLAYBACK_FINAL_RESULT, PlaybackErrorStage.MEDIA3_PLAYBACK, DiagnosticSeverity.INFO, reqId, newState = AuthoritativePlaybackResult.FALLBACK_SUCCESS.name, message = "Final result")

        val events = PlaybackDiagnosticRegistry.getEventsForRequest(reqId)
        assertEquals(11, events.size)
        assertEquals(AuthoritativePlaybackResult.FALLBACK_SUCCESS, PlaybackDiagnosticRegistry.getTerminalResult(reqId))
    }

    // =========================================================================
    // 7. STALE / RACE CONDITION EVENTS
    // =========================================================================

    @Test
    fun testStaleEvents_TaggedProperlyWithoutMutatingState() {
        val reqId = "req-stale-test"

        PlaybackDiagnosticRegistry.recordEvent(
            eventType = DiagnosticEventType.STALE_PLAYER_CALLBACK,
            stage = PlaybackErrorStage.MEDIA3_PLAYBACK,
            severity = DiagnosticSeverity.WARN,
            playbackRequestId = reqId,
            playerInstanceId = "P1_OLD",
            message = "Stale callback from P1_OLD rejected"
        )

        val events = PlaybackDiagnosticRegistry.getEventsForRequest(reqId)
        assertEquals(1, events.size)
        assertEquals(DiagnosticEventType.STALE_PLAYER_CALLBACK, events[0].eventType)
        assertEquals(DiagnosticSeverity.WARN, events[0].severity)
        assertNull("Stale event must not create terminal result", PlaybackDiagnosticRegistry.getTerminalResult(reqId))
    }

    // =========================================================================
    // 8. POSITION MILESTONE THROTTLING
    // =========================================================================

    @Test
    fun testPositionMilestoneThrottling() {
        val reqId = "req-pos-throttle"

        // First event at 0ms should be recorded
        PlaybackDiagnosticRegistry.recordPositionMilestone(reqId, "P1", 0L, 60000L, PlaybackSourceType.ORIGINAL)
        assertEquals(1, PlaybackDiagnosticRegistry.getEventsForRequest(reqId).size)

        // Immediate subsequent call (< 5000ms elapsed) should be throttled
        PlaybackDiagnosticRegistry.recordPositionMilestone(reqId, "P1", 100L, 60000L, PlaybackSourceType.ORIGINAL)
        assertEquals(1, PlaybackDiagnosticRegistry.getEventsForRequest(reqId).size)
    }

    // =========================================================================
    // 9. DIAGNOSTIC SNAPSHOT GENERATION
    // =========================================================================

    @Test
    fun testDiagnosticSnapshotGeneration() {
        val reqId = "req-snapshot"
        PlaybackDiagnosticRegistry.recordEvent(
            eventType = DiagnosticEventType.INPUT_RECEIVED,
            stage = PlaybackErrorStage.INPUT,
            severity = DiagnosticSeverity.INFO,
            playbackRequestId = reqId,
            message = "Input received"
        )

        val dummyReport = PlaybackAnalysisReport(
            result = PlaybackAnalysisResult.SUCCESS,
            containerFormat = "Matroska / WebM",
            video = VideoAnalysisInfo(codec = "hevc", profile = "Main 10", bitDepth = 10, width = 3840, height = 2160, frameRate = 60f),
            audio = AudioAnalysisInfo(codec = "eac3", channels = 6, sampleRate = 48000),
            deviceDecoder = DeviceDecoderAnalysis(decoderName = "c2.android.hevc.decoder", decoderType = "Hardware", isSupported = true),
            directPlaybackCompatibility = true,
            fallbackUsed = false,
            actualPlaybackConfirmed = true,
            analysis = "Direct hardware playback operational",
            recommendedAction = "None",
            terminalResult = AuthoritativePlaybackResult.DIRECT_SUCCESS,
            playbackPath = "/storage/emulated/0/Movies/sample_4k.mkv"
        )

        val snapshot = PlaybackDiagnosticRegistry.getSnapshot(
            requestId = reqId,
            request = null,
            report = dummyReport
        )

        assertEquals(reqId, snapshot.playbackRequestId)
        assertEquals("hevc", snapshot.videoCodec)
        assertEquals("Main 10", snapshot.videoProfile)
        assertEquals(10, snapshot.bitDepth)
        assertEquals("3840x2160", snapshot.resolution)
        assertEquals("eac3", snapshot.audioCodec)
        assertEquals(AuthoritativePlaybackResult.DIRECT_SUCCESS, snapshot.terminalResult)

        val summary = snapshot.toFormattedSummary()
        assertTrue(summary.contains("=== PLAYBACK DIAGNOSTIC SNAPSHOT ==="))
        assertTrue(summary.contains("Request ID: $reqId"))
        assertTrue(summary.contains("3840x2160"))
    }

    // =========================================================================
    // 10. STRUCTURED TRACE FORMATTING TESTS
    // =========================================================================

    @Test
    fun testStructuredTraceOutput() {
        val event = DiagnosticEvent(
            sequenceNumber = 42,
            eventType = DiagnosticEventType.COMPATIBILITY_EVALUATED,
            stage = PlaybackErrorStage.COMPATIBILITY,
            severity = DiagnosticSeverity.INFO,
            playbackRequestId = "req-trace-test",
            operationId = "OP_COMPAT",
            sourceType = PlaybackSourceType.ORIGINAL,
            sourceUriIdentity = "source://local/test.mp4",
            previousState = "ANALYZING",
            newState = "DIRECT_PREPARING",
            message = "Compatibility evaluation finished"
        )

        val trace = event.toStructuredTrace()
        assertTrue(trace.contains("[COMPATIBILITY_INPUT_TRACE][id=req-trace-test]"))
        assertTrue(trace.contains("op=OP_COMPAT"))
        assertTrue(trace.contains("src=ORIGINAL"))
        assertTrue(trace.contains("uriId=source://local/test.mp4"))
        assertTrue(trace.contains("ANALYZING -> DIRECT_PREPARING"))
        assertTrue(trace.contains("msg=\"Compatibility evaluation finished\""))
    }
}
