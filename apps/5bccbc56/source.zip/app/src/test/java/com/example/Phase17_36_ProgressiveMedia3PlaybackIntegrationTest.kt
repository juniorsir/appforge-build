package com.example

import android.content.Context
import android.net.Uri
import androidx.media3.common.MimeTypes
import androidx.test.core.app.ApplicationProvider
import com.example.media.DefaultMediaEngine
import com.example.media.ffmpeg.EncoderCandidate
import com.example.media.ffmpeg.FFmpegEngine
import com.example.media.ffmpeg.FFmpegResult
import com.example.media.ffmpeg.H264EncoderSelector
import com.example.media.playback.Media3SourceBuilder
import com.example.media.playback.PlaybackRequestCoordinator
import com.example.media.playback.PlaybackSource
import com.example.media.playback.PlaybackSourceType
import com.example.media.probe.AudioStreamInfo
import com.example.media.probe.MediaProbeInfo
import com.example.media.probe.VideoStreamInfo
import com.example.media.progressive.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.runner.RunWith
import org.robolectric.annotation.Config
import java.io.File

@RunWith(AndroidJUnit4::class)
@Config(sdk = [33])
class Phase17_36_ProgressiveMedia3PlaybackIntegrationTest {

    private lateinit var context: Context
    private lateinit var testCacheDir: File
    private lateinit var mediaEngine: DefaultMediaEngine

    @Before
    fun setUp() {
        context = ApplicationProvider.getApplicationContext()
        testCacheDir = File(context.cacheDir, "test_p1736_${System.currentTimeMillis()}").apply { mkdirs() }
        File(testCacheDir, "input.mkv").apply { writeBytes(ByteArray(1024)) }

        FFmpegEngine.resetForTesting()
        H264EncoderSelector.resetCacheForTesting()
        ProgressiveMediaGenerator.mockProbeFuncForTesting = null
        ProgressiveJobManager.resetForTesting()
        ProgressiveMediaGenerator.resetForTesting()
        ProgressiveTranscodeController.reset()
        ProgressivePlaybackCoordinator.reset()

        mediaEngine = DefaultMediaEngine(context)
    }

    @After
    fun tearDown() {
        testCacheDir.deleteRecursively()
        FFmpegEngine.resetForTesting()
        H264EncoderSelector.resetCacheForTesting()
        ProgressiveMediaGenerator.mockProbeFuncForTesting = null
        ProgressiveJobManager.resetForTesting()
        ProgressiveMediaGenerator.resetForTesting()
        ProgressiveTranscodeController.reset()
        ProgressivePlaybackCoordinator.reset()
        mediaEngine.release()
    }

    private fun configureMocks(durationMs: Long = 60_000L) {
        val mockProbe = MediaProbeInfo(
            pathOrUri = "file://${testCacheDir.absolutePath}/dummy.ts",
            format = "mpegts",
            durationMs = 4000L,
            videoStreams = listOf(
                VideoStreamInfo(
                    index = 0,
                    codec = "h264",
                    width = 1280,
                    height = 720,
                    frameRate = 24f,
                    bitDepth = 8,
                    pixelFormat = "yuv420p",
                    profile = "High"
                )
            ),
            audioStreams = listOf(
                AudioStreamInfo(
                    index = 1,
                    codec = "aac",
                    sampleRate = 44100,
                    channels = 2
                )
            )
        )

        ProgressiveMediaGenerator.mockProbeFuncForTesting = { _, _ -> Result.success(mockProbe) }

        H264EncoderSelector.mockEncodersForTesting = listOf(
            EncoderCandidate("libopenh264", false, "h264", "OpenH264")
        )
        H264EncoderSelector.mockUsabilityForTesting = true

        FFmpegEngine.mockExecutionResult = FFmpegResult(
            sessionId = 201L,
            isSuccess = true,
            returnCode = 0,
            output = "Transcoding success",
            executionDurationMs = 200L
        )
    }

    @Test
    fun testA_ProgressiveReadinessTriggersMedia3Preparation() = runBlocking {
        configureMocks(60_000L)
        val inputUri = Uri.parse("file://${testCacheDir.absolutePath}/input.mkv")
        val reqId = "req_test_a"
        val (req, _) = PlaybackRequestCoordinator.getOrCreateRequest("media_a", inputUri, inputUri.path ?: "", forceNew = true)
        PlaybackRequestCoordinator.setActivePlayerInstanceId(mediaEngine.playerInstanceId)

        val outDir = File(context.cacheDir, "progressive_${req.requestId}").apply { mkdirs() }
        File(outDir, "seg_00000.ts.tmp").writeBytes(ByteArray(2048))
        File(outDir, "seg_00001.ts.tmp").writeBytes(ByteArray(2048))

        val job = ProgressivePlaybackCoordinator.startProgressivePlayback(
            context = context,
            mediaEngine = mediaEngine,
            inputUri = inputUri,
            requestId = req.requestId,
            sourceDurationMs = 60_000L,
            scope = this
        )

        for (i in 1..40) {
            val state = ProgressiveTranscodeController.state.value
            if (state.isReadyForPlayback) break
            delay(50L)
        }

        val controllerState = ProgressiveTranscodeController.state.value
        assertTrue("Controller should be ready for playback after 2 segments", controllerState.isReadyForPlayback)
        assertEquals(2, controllerState.generatedUnitsCount)
        assertEquals(8000L, controllerState.playableDurationMs)

        val activeSource = mediaEngine.getActivePlaybackSource()
        assertNotNull("Active playback source should be attached to media engine", activeSource)
        assertEquals(PlaybackSourceType.PROGRESSIVE_FALLBACK, activeSource?.sourceType)
        assertTrue(activeSource?.uri.toString().endsWith("live_playlist.m3u8"))

        job.cancel()
    }

    @Test
    fun testB_ActualPlaybackStartsBeforeTranscodingFinishes() = runBlocking {
        configureMocks(120_000L)
        val inputUri = Uri.parse("file://${testCacheDir.absolutePath}/input.mkv")
        val (req, _) = PlaybackRequestCoordinator.getOrCreateRequest("media_b", inputUri, inputUri.path ?: "", forceNew = true)
        PlaybackRequestCoordinator.setActivePlayerInstanceId(mediaEngine.playerInstanceId)

        val outDir = File(context.cacheDir, "progressive_${req.requestId}").apply { mkdirs() }
        File(outDir, "seg_00000.ts.tmp").writeBytes(ByteArray(2048))
        File(outDir, "seg_00001.ts.tmp").writeBytes(ByteArray(2048))

        val job = ProgressivePlaybackCoordinator.startProgressivePlayback(
            context = context,
            mediaEngine = mediaEngine,
            inputUri = inputUri,
            requestId = req.requestId,
            sourceDurationMs = 120_000L,
            scope = this
        )

        for (i in 1..40) {
            val state = ProgressiveTranscodeController.state.value
            if (state.isReadyForPlayback) break
            delay(50L)
        }

        val state = ProgressiveTranscodeController.state.value
        assertTrue("Ready for playback while transcode is still at partial progress", state.isReadyForPlayback)
        assertEquals(8000L, state.playableDurationMs)

        val activeSource = mediaEngine.getActivePlaybackSource()
        assertNotNull(activeSource)
        assertEquals(PlaybackSourceType.PROGRESSIVE_FALLBACK, activeSource?.sourceType)

        job.cancel()
    }

    @Test
    fun testC_ProgressiveContinuationAppendsSegments() = runBlocking {
        configureMocks(60_000L)
        val inputUri = Uri.parse("file://${testCacheDir.absolutePath}/input.mkv")
        val (req, _) = PlaybackRequestCoordinator.getOrCreateRequest("media_c", inputUri, inputUri.path ?: "", forceNew = true)
        PlaybackRequestCoordinator.setActivePlayerInstanceId(mediaEngine.playerInstanceId)

        val outDir = File(context.cacheDir, "progressive_${req.requestId}").apply { mkdirs() }
        File(outDir, "seg_00000.ts.tmp").writeBytes(ByteArray(2048))
        File(outDir, "seg_00001.ts.tmp").writeBytes(ByteArray(2048))

        val job = ProgressivePlaybackCoordinator.startProgressivePlayback(
            context = context,
            mediaEngine = mediaEngine,
            inputUri = inputUri,
            requestId = req.requestId,
            sourceDurationMs = 60_000L,
            scope = this
        )

        for (i in 1..40) {
            val state = ProgressiveTranscodeController.state.value
            if (state.isReadyForPlayback) break
            delay(50L)
        }

        assertEquals(2, ProgressiveTranscodeController.state.value.generatedUnitsCount)

        // Verify live_playlist.m3u8 has published segments and no ENDLIST
        val playlist = File(outDir, "live_playlist.m3u8")
        assertTrue(playlist.exists())
        val text = playlist.readText()
        assertTrue(text.contains("seg_00000.ts"))
        assertTrue(text.contains("seg_00001.ts"))
        assertFalse("Live playlist must not have ENDLIST while running", text.contains("#EXT-X-ENDLIST"))

        job.cancel()
    }

    @Test
    fun testD_StallRecoveryAndBufferLeadCalculation() = runBlocking {
        configureMocks(60_000L)
        val inputUri = Uri.parse("file://${testCacheDir.absolutePath}/input.mkv")
        val (req, _) = PlaybackRequestCoordinator.getOrCreateRequest("media_d", inputUri, inputUri.path ?: "", forceNew = true)
        PlaybackRequestCoordinator.setActivePlayerInstanceId(mediaEngine.playerInstanceId)

        val outDir = File(context.cacheDir, "progressive_${req.requestId}").apply { mkdirs() }
        File(outDir, "seg_00000.ts.tmp").writeBytes(ByteArray(2048))
        File(outDir, "seg_00001.ts.tmp").writeBytes(ByteArray(2048))

        val job = ProgressivePlaybackCoordinator.startProgressivePlayback(
            context = context,
            mediaEngine = mediaEngine,
            inputUri = inputUri,
            requestId = req.requestId,
            sourceDurationMs = 60_000L,
            scope = this
        )

        for (i in 1..40) {
            val state = ProgressiveTranscodeController.state.value
            if (state.isReadyForPlayback) break
            delay(50L)
        }

        // Player position advances to 7500ms (buffer lead is only 500ms -> STALL_RISK)
        ProgressiveTranscodeController.updatePlaybackPosition(7500L)
        val highRiskState = ProgressiveTranscodeController.state.value
        assertEquals(500L, highRiskState.bufferLeadMs)
        assertEquals(StallRisk.STALL_RISK, highRiskState.stallRisk)

        // Player position is at 1000ms (buffer lead is 7000ms -> SAFE)
        ProgressiveTranscodeController.updatePlaybackPosition(1000L)
        val lowRiskState = ProgressiveTranscodeController.state.value
        assertEquals(7000L, lowRiskState.bufferLeadMs)
        assertEquals(StallRisk.SAFE, lowRiskState.stallRisk)

        job.cancel()
    }

    @Test
    fun testE_CleanEndOfStreamTransition() = runBlocking {
        configureMocks(8_000L)
        val inputUri = Uri.parse("file://${testCacheDir.absolutePath}/input.mkv")
        val (req, _) = PlaybackRequestCoordinator.getOrCreateRequest("media_e", inputUri, inputUri.path ?: "", forceNew = true)
        PlaybackRequestCoordinator.setActivePlayerInstanceId(mediaEngine.playerInstanceId)

        val outDir = File(context.cacheDir, "progressive_${req.requestId}").apply { mkdirs() }
        File(outDir, "seg_00000.ts.tmp").writeBytes(ByteArray(2048))
        File(outDir, "seg_00001.ts.tmp").writeBytes(ByteArray(2048))

        val job = ProgressivePlaybackCoordinator.startProgressivePlayback(
            context = context,
            mediaEngine = mediaEngine,
            inputUri = inputUri,
            requestId = req.requestId,
            sourceDurationMs = 8_000L,
            scope = this
        )

        for (i in 1..40) {
            val state = ProgressiveTranscodeController.state.value
            if (state.status == ProgressiveTranscodeStatus.COMPLETED) break
            delay(50L)
        }

        val state = ProgressiveTranscodeController.state.value
        assertEquals(2, state.generatedUnitsCount)

        val playlist = File(outDir, "live_playlist.m3u8")
        assertTrue("Playlist must exist", playlist.exists())
        val text = playlist.readText()
        assertTrue("Final playlist must contain #EXT-X-ENDLIST", text.contains("#EXT-X-ENDLIST"))

        job.cancel()
    }

    @Test
    fun testF_StaleRequestGuardDropsLateCallbacks() = runBlocking {
        configureMocks(60_000L)
        val inputUri = Uri.parse("file://${testCacheDir.absolutePath}/input.mkv")
        val (reqOld, _) = PlaybackRequestCoordinator.getOrCreateRequest("media_old", inputUri, inputUri.path ?: "", forceNew = true)

        val oldJob = ProgressivePlaybackCoordinator.startProgressivePlayback(
            context = context,
            mediaEngine = mediaEngine,
            inputUri = inputUri,
            requestId = reqOld.requestId,
            sourceDurationMs = 60_000L,
            scope = this
        )

        delay(50L)

        // Shift active request
        val (reqNew, _) = PlaybackRequestCoordinator.getOrCreateRequest("media_new", inputUri, inputUri.path ?: "", forceNew = true)
        assertNotEquals(reqOld.requestId, reqNew.requestId)

        delay(100L)

        // Controller state for old request is dropped by concurrency guard
        oldJob.cancel()
    }

    @Test
    fun testG_CancellationTerminatesTranscodeAndCleansFiles() = runBlocking {
        configureMocks(60_000L)
        val inputUri = Uri.parse("file://${testCacheDir.absolutePath}/input.mkv")
        val (req, _) = PlaybackRequestCoordinator.getOrCreateRequest("media_g", inputUri, inputUri.path ?: "", forceNew = true)
        PlaybackRequestCoordinator.setActivePlayerInstanceId(mediaEngine.playerInstanceId)

        val outDir = File(context.cacheDir, "progressive_${req.requestId}").apply { mkdirs() }
        File(outDir, "seg_00000.ts.tmp").writeBytes(ByteArray(2048))

        val job = ProgressivePlaybackCoordinator.startProgressivePlayback(
            context = context,
            mediaEngine = mediaEngine,
            inputUri = inputUri,
            requestId = req.requestId,
            sourceDurationMs = 60_000L,
            scope = this
        )

        delay(100L)

        ProgressivePlaybackCoordinator.cancelPlayback(req.requestId, mediaEngine)

        delay(100L)

        val state = ProgressiveTranscodeController.state.value
        assertEquals(ProgressiveTranscodeStatus.CANCELLED, state.status)

        // Verify tmp files in outDir are deleted
        val tmpFiles = outDir.listFiles { _, name -> name.endsWith(".tmp") } ?: emptyArray()
        assertEquals(0, tmpFiles.size)

        job.cancel()
    }

    @Test
    fun testH_SoloLevelingHEVCMain10ProgressiveVerification() = runBlocking {
        configureMocks(180_000L) // 3 minute 4K HEVC 10-bit file
        val inputUri = Uri.parse("file://${testCacheDir.absolutePath}/input.mkv")
        val (req, _) = PlaybackRequestCoordinator.getOrCreateRequest("solo_leveling_hevc10", inputUri, inputUri.path ?: "", forceNew = true)
        PlaybackRequestCoordinator.setActivePlayerInstanceId(mediaEngine.playerInstanceId)

        val outDir = File(context.cacheDir, "progressive_${req.requestId}").apply { mkdirs() }
        File(outDir, "seg_00000.ts.tmp").writeBytes(ByteArray(4096))
        File(outDir, "seg_00001.ts.tmp").writeBytes(ByteArray(4096))

        val job = ProgressivePlaybackCoordinator.startProgressivePlayback(
            context = context,
            mediaEngine = mediaEngine,
            inputUri = inputUri,
            requestId = req.requestId,
            sourceDurationMs = 180_000L,
            scope = this
        )

        for (i in 1..40) {
            val state = ProgressiveTranscodeController.state.value
            if (state.isReadyForPlayback) break
            delay(50L)
        }

        val state = ProgressiveTranscodeController.state.value
        assertTrue("Ready for playback on Solo Leveling HEVC 10-bit", state.isReadyForPlayback)
        assertEquals(8000L, state.playableDurationMs)
        assertEquals(2, state.generatedUnitsCount)

        val activeSource = mediaEngine.getActivePlaybackSource()
        assertNotNull(activeSource)
        assertEquals(PlaybackSourceType.PROGRESSIVE_FALLBACK, activeSource?.sourceType)

        val mediaItem = Media3SourceBuilder.buildMediaItem(activeSource!!)
        assertEquals(MimeTypes.APPLICATION_M3U8, mediaItem.localConfiguration?.mimeType)

        job.cancel()
    }

    @Test
    fun testI_InvariantVerificationContract() = runBlocking {
        val progressiveUri = Uri.parse("file:///storage/emulated/0/Download/progressive/live_playlist.m3u8")
        val source = PlaybackSource(
            sourceType = PlaybackSourceType.PROGRESSIVE_FALLBACK,
            uri = progressiveUri,
            originalUri = Uri.parse("file:///storage/emulated/0/Download/sample.mkv"),
            requestId = "req_test_i"
        )

        val mediaItem = Media3SourceBuilder.buildMediaItem(source)
        assertEquals(progressiveUri, mediaItem.localConfiguration?.uri)
        assertEquals(MimeTypes.APPLICATION_M3U8, mediaItem.localConfiguration?.mimeType)

        val determinedMime = Media3SourceBuilder.determineMimeType(source)
        assertEquals(MimeTypes.APPLICATION_M3U8, determinedMime)
    }
}
