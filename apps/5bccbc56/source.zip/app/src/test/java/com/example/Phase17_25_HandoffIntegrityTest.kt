package com.example

import android.net.Uri
import com.example.media.playback.PlaybackRequestCoordinator
import com.example.media.playback.PlaybackSource
import com.example.media.playback.PlaybackSourceType
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [33])
class Phase17_25_HandoffIntegrityTest {

    @Before
    fun setup() {
        PlaybackRequestCoordinator.resetForTesting()
    }

    @Test
    fun test_handoff_integrity_uri_mismatch_rejected() {
        val playerInstanceId = "player_456"
        
        val (req, _) = PlaybackRequestCoordinator.getOrCreateRequest("fake_media_key", Uri.parse("file:///fake"), "fake_path", null)
        val reqId = req.requestId
        PlaybackRequestCoordinator.setActivePlayerInstanceId(playerInstanceId)
        
        val source = PlaybackSource(
            sourceType = PlaybackSourceType.FALLBACK,
            uri = Uri.parse("file:///data/user/0/com.example/cache/video_fallback.mp4"),
            requestId = reqId,
            container = "mp4",
            codec = "h264"
        )
        PlaybackRequestCoordinator.updateActiveSource(reqId, source)
        
        // Simulating ExoPlayer reporting a different URI (e.g. stale original source)
        val actualPlayerUri = "file:///data/user/0/com.example/cache/original_video.mkv"
        
        val verified = PlaybackRequestCoordinator.verifyPlaybackSource(
            requestId = reqId,
            playerInstanceId = playerInstanceId,
            actualUri = actualPlayerUri,
            positionMs = 1000L
        )
        
        assertFalse("Handoff MUST be rejected if URIs do not exactly match.", verified)
    }

    @Test
    fun test_handoff_integrity_uri_substring_mismatch_rejected() {
        val playerInstanceId = "player_456"
        
        val (req, _) = PlaybackRequestCoordinator.getOrCreateRequest("fake_media_key", Uri.parse("file:///fake"), "fake_path", null)
        val reqId = req.requestId
        PlaybackRequestCoordinator.setActivePlayerInstanceId(playerInstanceId)
        
        val source = PlaybackSource(
            sourceType = PlaybackSourceType.FALLBACK,
            uri = Uri.parse("file:///data/user/0/com.example/cache/video_fallback.mp4"),
            requestId = reqId,
            container = "mp4",
            codec = "h264"
        )
        PlaybackRequestCoordinator.updateActiveSource(reqId, source)
        
        // Simulating heuristic match (which should now be rejected)
        val actualPlayerUri = "file:///data/user/0/com.example/cache/other_folder/video_fallback.mp4"
        
        val verified = PlaybackRequestCoordinator.verifyPlaybackSource(
            requestId = reqId,
            playerInstanceId = playerInstanceId,
            actualUri = actualPlayerUri,
            positionMs = 1000L
        )
        
        assertFalse("Handoff MUST be rejected if URIs only partially match.", verified)
    }

    @Test
    fun test_handoff_integrity_uri_exact_match_accepted() {
        val playerInstanceId = "player_456"
        
        val (req, _) = PlaybackRequestCoordinator.getOrCreateRequest("fake_media_key", Uri.parse("file:///fake"), "fake_path", null)
        val reqId = req.requestId
        PlaybackRequestCoordinator.setActivePlayerInstanceId(playerInstanceId)
        
        val uriStr = "file:///data/user/0/com.example/cache/video_fallback.mp4"
        val source = PlaybackSource(
            sourceType = PlaybackSourceType.FALLBACK,
            uri = Uri.parse(uriStr),
            requestId = reqId,
            container = "mp4",
            codec = "h264"
        )
        PlaybackRequestCoordinator.updateActiveSource(reqId, source)
        
        val verified = PlaybackRequestCoordinator.verifyPlaybackSource(
            requestId = reqId,
            playerInstanceId = playerInstanceId,
            actualUri = uriStr,
            positionMs = 1000L
        )
        
        assertTrue("Handoff MUST be accepted if URIs exactly match.", verified)
    }

    @Test
    fun test_is_active_source_fallback_authoritative() {
        val (req, _) = PlaybackRequestCoordinator.getOrCreateRequest("fake_media_key", Uri.parse("file:///fake"), "fake_path", null)
        val reqId = req.requestId
        
        val sourceOrig = PlaybackSource(
            sourceType = PlaybackSourceType.ORIGINAL,
            uri = Uri.parse("file:///data/user/0/com.example/cache/fallback_in_name.mp4"), // Name implies fallback but type is original
            requestId = reqId,
            container = "mp4",
            codec = "h264"
        )
        PlaybackRequestCoordinator.updateActiveSource(reqId, sourceOrig)
        
        assertFalse("Source must NOT be fallback if sourceType is ORIGINAL, despite naming heuristics.", PlaybackRequestCoordinator.isActiveSourceFallback(reqId))
        
        val sourceFall = PlaybackSource(
            sourceType = PlaybackSourceType.FALLBACK,
            uri = Uri.parse("file:///data/user/0/com.example/cache/my_video.mp4"), // Name lacks fallback but type is fallback
            requestId = reqId,
            container = "mp4",
            codec = "h264"
        )
        PlaybackRequestCoordinator.updateActiveSource(reqId, sourceFall)
        
        assertTrue("Source MUST be fallback if sourceType is FALLBACK, regardless of naming.", PlaybackRequestCoordinator.isActiveSourceFallback(reqId))
    }
}
