package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.media.AndroidEncoderInfo
import com.example.media.DeviceThermalState
import com.example.media.EncoderCapabilityManager
import com.example.media.ThermalStateManager
import com.example.media.TranscodingWorkloadState
import com.example.media.ffmpeg.EncoderCandidate
import com.example.media.ffmpeg.H264EncoderSelector
import com.example.media.ffmpeg.SelectedH264Encoder
import com.example.media.playback.TranscodingLogManager
import com.example.media.progressive.NativeMediaCodecProbe
import com.example.media.progressive.SmartBufferState
import com.example.media.progressive.SmartPlaybackController
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [33])
class Phase17_40_FastSmoothHardwareTranscodingTest {

    private lateinit var context: Context

    @Before
    fun setup() {
        context = ApplicationProvider.getApplicationContext()
        H264EncoderSelector.resetCacheForTesting()
        EncoderCapabilityManager.resetCacheForTesting()
        NativeMediaCodecProbe.resetCacheForTesting()
        ThermalStateManager.resetForTesting()
        TranscodingLogManager.clear()
        SmartPlaybackController.reset()
    }

    @After
    fun tearDown() {
        H264EncoderSelector.resetCacheForTesting()
        EncoderCapabilityManager.resetCacheForTesting()
        NativeMediaCodecProbe.resetCacheForTesting()
        ThermalStateManager.resetForTesting()
        TranscodingLogManager.clear()
        SmartPlaybackController.reset()
    }

    @Test
    fun testEncoderCapabilityDiscovery_HardwareSoftwareClassification() {
        val mockQcomHw = AndroidEncoderInfo(
            name = "c2.qcom.avc.encoder",
            isHardware = true,
            isSoftware = false,
            isVendor = true,
            maxWidth = 3840,
            maxHeight = 2160,
            supportedProfiles = listOf("Baseline", "Main", "High"),
            supportedLevels = listOf("4.1", "5.1"),
            colorFormatNames = listOf("COLOR_FormatSurface", "COLOR_FormatYUV420Flexible")
        )
        val mockAndroidSw = AndroidEncoderInfo(
            name = "c2.android.avc.encoder",
            isHardware = false,
            isSoftware = true,
            isVendor = false,
            maxWidth = 1920,
            maxHeight = 1080,
            supportedProfiles = listOf("Baseline", "Main"),
            supportedLevels = listOf("4.1")
        )

        EncoderCapabilityManager.mockEncodersForTesting = listOf(mockQcomHw, mockAndroidSw)
        val encoders = EncoderCapabilityManager.getSystemAvcEncoders()

        assertEquals(2, encoders.size)
        assertTrue(encoders.any { it.isHardware && it.name == "c2.qcom.avc.encoder" })
        assertTrue(encoders.any { it.isSoftware && it.name == "c2.android.avc.encoder" })

        val report = EncoderCapabilityManager.getEncoderCapabilityReport()
        assertTrue(report.hasHardwareAvcEncoder)
        assertEquals("c2.qcom.avc.encoder", report.preferredHwEncoderName)
    }

    @Test
    fun testNativeMediaCodecProbe_ExecutionAndCaching() {
        // Probe execution should return without crashing
        val probeResult = NativeMediaCodecProbe.probeNativeH264Encoder(
            width = 320,
            height = 240,
            fps = 24.0f,
            bitrateKbps = 1000,
            requestId = "test_req_01"
        )

        // Subsequent probe should use cached result
        val secondResult = NativeMediaCodecProbe.probeNativeH264Encoder(
            width = 320,
            height = 240,
            requestId = "test_req_01"
        )
        assertEquals(probeResult, secondResult)
    }

    @Test
    fun testH264EncoderSelection_HardwareFirstSelectionAndFallback() = runBlocking {
        H264EncoderSelector.mockUsabilityForTesting = true
        H264EncoderSelector.mockEncodersForTesting = listOf(
            EncoderCandidate("h264_mediacodec", true, "h264", "MediaCodec"),
            EncoderCandidate("libopenh264", false, "h264", "OpenH264")
        )

        // Select best encoder when both are available
        val selected = H264EncoderSelector.selectBestH264Encoder(context)
        assertNotNull(selected)
        assertEquals("h264_mediacodec", selected?.name)
        assertTrue(selected?.isHardware ?: false)

        // If hardware encoder fails / is quarantined, should seamlessly select libopenh264
        H264EncoderSelector.resetCacheForTesting()
        H264EncoderSelector.mockUsabilityForTesting = true
        H264EncoderSelector.mockEncodersForTesting = listOf(
            EncoderCandidate("h264_mediacodec", true, "h264", "MediaCodec"),
            EncoderCandidate("libopenh264", false, "h264", "OpenH264")
        )
        H264EncoderSelector.quarantineEncoder("h264_mediacodec", "Hardware initialization timeout")
        val fallbackSelected = H264EncoderSelector.selectBestH264Encoder(context)
        assertNotNull(fallbackSelected)
        assertEquals("libopenh264", fallbackSelected?.name)
        assertFalse(fallbackSelected?.isHardware ?: true)
    }

    @Test
    fun testEncoderThreadingDecision_CalculatesBalancedThreads() {
        val openH264Threads = H264EncoderSelector.calculateOptimalThreads("libopenh264")
        val x264Threads = H264EncoderSelector.calculateOptimalThreads("libx264")
        val mediacodecThreads = H264EncoderSelector.calculateOptimalThreads("h264_mediacodec")

        assertTrue("libopenh264 threads must be between 2 and 4", openH264Threads in 2..4)
        assertTrue("libx264 threads must be between 2 and 4", x264Threads in 2..4)
        assertEquals("MediaCodec handles threading internally", 0, mediacodecThreads)
    }

    @Test
    fun testThermalStateManager_AdaptiveWorkloadTransitions() {
        // Initial normal state
        ThermalStateManager.mockThermalStateForTesting = DeviceThermalState.NORMAL
        val workloadNormal = ThermalStateManager.evaluateWorkload(bufferLeadMs = 8000L, requestId = "test_req_02")
        assertEquals(TranscodingWorkloadState.NORMAL, workloadNormal)

        // Low buffer lead triggers FAST workload when thermal is safe
        val workloadFast = ThermalStateManager.evaluateWorkload(bufferLeadMs = 3000L, requestId = "test_req_02")
        assertEquals(TranscodingWorkloadState.FAST, workloadFast)

        // Severe thermal status triggers SAFE workload
        ThermalStateManager.mockThermalStateForTesting = DeviceThermalState.SEVERE
        val workloadSafe = ThermalStateManager.evaluateWorkload(bufferLeadMs = 3000L, requestId = "test_req_02")
        assertEquals(TranscodingWorkloadState.SAFE, workloadSafe)
    }

    @Test
    fun testTranscodingLogManager_DeduplicationThrottlingAndMetrics() {
        TranscodingLogManager.clear()

        // Ingest duplicate lines
        TranscodingLogManager.addLogLine("frame=10 time=00:00:01.00", requestId = "req_1")
        TranscodingLogManager.addLogLine("frame=10 time=00:00:01.00", requestId = "req_1")
        TranscodingLogManager.addLogLine("frame=10 time=00:00:01.00", requestId = "req_1")
        TranscodingLogManager.addLogLine("frame=20 time=00:00:02.00", requestId = "req_1")

        assertEquals(4L, TranscodingLogManager.countReceived.get())
        assertEquals(2L, TranscodingLogManager.countDeduplicated.get())
        assertEquals(2L, TranscodingLogManager.countPublished.get())
    }

    @Test
    fun testSmartPlaybackController_BufferAndPriorityTracking() {
        SmartPlaybackController.startTracking(
            playbackRequestId = "req_smart_01",
            playerInstanceId = "player_01",
            transcodeJobId = "job_01",
            sourceDurationMs = 60_000L
        )

        SmartPlaybackController.updateTranscodeProgress(
            playableDurationMs = 12_000L,
            productionRate = 1.2f,
            fps = 24.0,
            generatedUnitsCount = 3,
            isCompleted = false
        )

        SmartPlaybackController.updatePlaybackMetrics(
            playbackPositionMs = 2_000L,
            internalBufferedPositionMs = 6_000L,
            consumptionRate = 1.0f,
            isPlaying = true,
            isBuffering = false
        )

        val metrics = SmartPlaybackController.metrics.value
        assertEquals("req_smart_01", metrics.playbackRequestId)
        assertEquals(10_000L, metrics.progressiveLeadMs)
        assertEquals(SmartBufferState.HEALTHY, metrics.state)
    }
}
