package com.example.media

import android.media.MediaCodecInfo
import android.media.MediaCodecList
import android.os.Build
import android.util.Log

object EncoderCapabilityManager {
    private const val TAG = "EncoderCapabilityManager"
    private const val MIME_AVC = "video/avc"

    @Volatile
    private var cachedEncoders: List<AndroidEncoderInfo>? = null

    @Volatile
    private var cachedEncoderReport: AndroidEncoderCapabilityReport? = null

    // Testing hooks
    @Volatile
    var mockEncodersForTesting: List<AndroidEncoderInfo>? = null

    fun resetCacheForTesting() {
        cachedEncoders = null
        cachedEncoderReport = null
        mockEncodersForTesting = null
    }

    fun getSystemAvcEncoders(): List<AndroidEncoderInfo> {
        mockEncodersForTesting?.let { mockList ->
            val hwEncoder = mockList.firstOrNull { it.isHardware }?.name
            val swEncoder = mockList.firstOrNull { it.isSoftware }?.name
            val report = AndroidEncoderCapabilityReport(
                encoders = mockList,
                hasHardwareAvcEncoder = hwEncoder != null,
                preferredHwEncoderName = hwEncoder,
                preferredSwEncoderName = swEncoder
            )
            cachedEncoderReport = report
            cachedEncoders = mockList
            return mockList
        }
        cachedEncoders?.let { return it }

        val encoders = mutableListOf<AndroidEncoderInfo>()
        try {
            val codecList = MediaCodecList(MediaCodecList.ALL_CODECS)
            val infos = codecList.codecInfos ?: emptyArray()

            for (info in infos) {
                if (info == null || !info.isEncoder) continue

                val supportedTypes = info.supportedTypes ?: emptyArray()
                val isAvc = supportedTypes.any { it != null && it.equals(MIME_AVC, ignoreCase = true) }
                if (!isAvc) continue

                val isSw = isSoftwareEncoder(info)
                val isHw = isHardwareEncoder(info)
                val isVendor = isVendorEncoder(info)

                var minW = 16
                var maxW = 1920
                var minH = 16
                var maxH = 1080
                var widthAlign = 2
                var heightAlign = 2
                var minBitrate = 0
                var maxBitrate = 0
                var minFps = 0.0
                var maxFps = 60.0
                val profileList = mutableListOf<String>()
                val levelList = mutableListOf<String>()
                val colorFormatInts = mutableListOf<Int>()
                val colorFormatNames = mutableListOf<String>()

                try {
                    val caps = info.getCapabilitiesForType(MIME_AVC)
                    caps?.colorFormats?.forEach { cf ->
                        colorFormatInts.add(cf)
                        colorFormatNames.add(mapColorFormatToString(cf))
                    }

                    caps?.profileLevels?.forEach { pl ->
                        if (pl != null) {
                            val profName = mapAvcProfileToString(pl.profile)
                            val levelName = mapAvcLevelToString(pl.level)
                            if (!profileList.contains(profName)) profileList.add(profName)
                            if (!levelList.contains(levelName)) levelList.add(levelName)
                        }
                    }

                    val vc = caps?.videoCapabilities
                    if (vc != null) {
                        minW = vc.supportedWidths?.lower?.toInt() ?: 16
                        maxW = vc.supportedWidths?.upper?.toInt() ?: 1920
                        minH = vc.supportedHeights?.lower?.toInt() ?: 16
                        maxH = vc.supportedHeights?.upper?.toInt() ?: 1080
                        widthAlign = vc.widthAlignment
                        heightAlign = vc.heightAlignment
                        minFps = vc.supportedFrameRates?.lower?.toDouble() ?: 0.0
                        maxFps = vc.supportedFrameRates?.upper?.toDouble() ?: 60.0
                        minBitrate = vc.bitrateRange?.lower?.toInt() ?: 0
                        maxBitrate = vc.bitrateRange?.upper?.toInt() ?: 0
                    }
                } catch (t: Throwable) {
                    Log.w("FALLBACK_TRACE", "[ENCODER_CAPABILITY_READ_ERROR] Error reading caps for ${info.name}: ${t.message}")
                }

                val encoderInfo = AndroidEncoderInfo(
                    name = info.name ?: "UnknownEncoder",
                    mimeType = MIME_AVC,
                    isEncoder = true,
                    isHardware = isHw,
                    isSoftware = isSw,
                    isVendor = isVendor,
                    minWidth = minW,
                    maxWidth = maxW,
                    minHeight = minH,
                    maxHeight = maxH,
                    widthAlignment = widthAlign,
                    heightAlignment = heightAlign,
                    supportedColorFormats = colorFormatInts,
                    colorFormatNames = colorFormatNames,
                    minBitrate = minBitrate,
                    maxBitrate = maxBitrate,
                    minFps = minFps,
                    maxFps = maxFps,
                    supportedProfiles = profileList,
                    supportedLevels = levelList
                )
                encoders.add(encoderInfo)

                // Log machine-readable capability traces
                val profilesJoined = encoderInfo.supportedProfiles.joinToString(",")
                val levelsJoined = encoderInfo.supportedLevels.joinToString(",")
                val colorsJoined = encoderInfo.colorFormatNames.joinToString(",")
                Log.i(
                    "FALLBACK_TRACE",
                    "[ENCODER_DISCOVERY] candidate=${encoderInfo.name} mime=${encoderInfo.mimeType} isEncoder=true hardware=${encoderInfo.isHardware} software=${encoderInfo.isSoftware} vendor=${encoderInfo.isVendor} maxWidth=${encoderInfo.maxWidth} maxHeight=${encoderInfo.maxHeight} profiles=$profilesJoined levels=$levelsJoined colorFormats=$colorsJoined"
                )
                Log.i("FALLBACK_TRACE", "[ENCODER_CAPABILITY] name=${encoderInfo.name} mime=${encoderInfo.mimeType} isEncoder=true hardware=${encoderInfo.isHardware} software=${encoderInfo.isSoftware}")
                Log.i("FALLBACK_TRACE", "[ENCODER_RESOLUTION_CAPABILITY] encoder=${encoderInfo.name} width=${encoderInfo.maxWidth} height=${encoderInfo.maxHeight} supported=true")
                for (p in encoderInfo.supportedProfiles) {
                    Log.i("FALLBACK_TRACE", "[ENCODER_PROFILE_CAPABILITY] encoder=${encoderInfo.name} profile=$p supported=true")
                }
            }
        } catch (t: Throwable) {
            Log.e("FALLBACK_TRACE", "[ENCODER_CAPABILITY_DISCOVERY_ERROR] Failed to query MediaCodecList: ${t.message}")
        }

        val hwEncoder = encoders.firstOrNull { it.isHardware }?.name
        val swEncoder = encoders.firstOrNull { it.isSoftware }?.name
        val report = AndroidEncoderCapabilityReport(
            encoders = encoders,
            hasHardwareAvcEncoder = hwEncoder != null,
            preferredHwEncoderName = hwEncoder,
            preferredSwEncoderName = swEncoder
        )
        cachedEncoderReport = report
        cachedEncoders = encoders
        return encoders
    }

    fun getEncoderCapabilityReport(): AndroidEncoderCapabilityReport {
        getSystemAvcEncoders()
        return cachedEncoderReport ?: AndroidEncoderCapabilityReport()
    }

    fun isSoftwareEncoder(info: MediaCodecInfo): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            if (info.isSoftwareOnly) return true
        }
        val name = info.name.lowercase()
        return name.startsWith("omx.google.") ||
                name.startsWith("c2.android.") ||
                name.contains(".sw.") ||
                name.startsWith("sw") ||
                name.contains("google")
    }

    fun isHardwareEncoder(info: MediaCodecInfo): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            if (info.isHardwareAccelerated) return true
        }
        if (isSoftwareEncoder(info)) return false

        val name = info.name.lowercase()
        return name.startsWith("omx.qcom.") ||
                name.startsWith("omx.exynos.") ||
                name.startsWith("omx.mtk.") ||
                name.startsWith("omx.intel.") ||
                name.startsWith("omx.nvidia.") ||
                name.startsWith("omx.hisilicon.") ||
                name.startsWith("omx.sec.") ||
                name.startsWith("omx.sprd.") ||
                name.startsWith("c2.qcom.") ||
                name.startsWith("c2.exynos.") ||
                name.startsWith("c2.mediatek.") ||
                name.startsWith("c2.mtk.") ||
                name.startsWith("c2.hisilicon.") ||
                name.startsWith("c2.sec.") ||
                name.startsWith("c2.sprd.")
    }

    fun isVendorEncoder(info: MediaCodecInfo): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            return info.isVendor
        }
        val name = info.name.lowercase()
        return !name.startsWith("omx.google.") && !name.startsWith("c2.android.") && !name.contains(".sw.") && !name.startsWith("sw")
    }

    fun isResolutionSupportedByHwEncoder(width: Int, height: Int): Boolean {
        val hwEncoders = getSystemAvcEncoders().filter { it.isHardware }
        if (hwEncoders.isEmpty()) return false
        return hwEncoders.any { encoder ->
            val maxW = encoder.maxWidth
            val maxH = encoder.maxHeight
            val minW = encoder.minWidth
            val minH = encoder.minHeight
            // Handle both landscape and portrait bounding checks
            ((width in minW..maxW && height in minH..maxH) ||
             (height in minW..maxW && width in minH..maxH))
        }
    }

    fun isProfileSupportedByHwEncoder(profileName: String): Boolean {
        val hwEncoders = getSystemAvcEncoders().filter { it.isHardware }
        if (hwEncoders.isEmpty()) return false
        val target = profileName.trim().lowercase().replace(" ", "").replace(":", "").replace("-", "")
        return hwEncoders.any { encoder ->
            encoder.supportedProfiles.any { p ->
                val pClean = p.trim().lowercase().replace(" ", "").replace(":", "").replace("-", "")
                pClean == target || pClean.contains(target) || target.contains(pClean)
            }
        }
    }

    fun getPreferredHardwareProfile(): String {
        val hwEncoders = getSystemAvcEncoders().filter { it.isHardware }
        if (hwEncoders.isEmpty()) return "baseline"

        val allProfiles = hwEncoders.flatMap { it.supportedProfiles }.map { it.lowercase() }
        return when {
            allProfiles.any { it.contains("high") && !it.contains("10") && !it.contains("422") && !it.contains("444") } -> "high"
            allProfiles.any { it.contains("main") } -> "main"
            allProfiles.any { it.contains("constrained") } -> "constrained_baseline"
            allProfiles.any { it.contains("baseline") } -> "baseline"
            else -> "baseline"
        }
    }

    fun getPreferredHardwareLevel(requestedLevel: String = "4.1"): String {
        val hwEncoders = getSystemAvcEncoders().filter { it.isHardware }
        if (hwEncoders.isEmpty()) return "4.1"

        val allLevels = hwEncoders.flatMap { it.supportedLevels }
        if (allLevels.isEmpty()) return requestedLevel

        // If requested level is directly supported
        if (allLevels.any { it == requestedLevel || it.startsWith(requestedLevel) }) {
            return requestedLevel
        }
        // Return the highest supported level or sanitized fallback
        return allLevels.lastOrNull() ?: requestedLevel
    }

    fun mapAvcProfileToString(profile: Int): String {
        return when (profile) {
            MediaCodecInfo.CodecProfileLevel.AVCProfileBaseline -> "Baseline"
            MediaCodecInfo.CodecProfileLevel.AVCProfileConstrainedBaseline -> "Constrained Baseline"
            MediaCodecInfo.CodecProfileLevel.AVCProfileMain -> "Main"
            MediaCodecInfo.CodecProfileLevel.AVCProfileExtended -> "Extended"
            MediaCodecInfo.CodecProfileLevel.AVCProfileHigh -> "High"
            MediaCodecInfo.CodecProfileLevel.AVCProfileHigh10 -> "High 10"
            MediaCodecInfo.CodecProfileLevel.AVCProfileHigh422 -> "High 4:2:2"
            MediaCodecInfo.CodecProfileLevel.AVCProfileHigh444 -> "High 4:4:4"
            else -> "Profile $profile"
        }
    }

    fun mapAvcLevelToString(level: Int): String {
        return when (level) {
            MediaCodecInfo.CodecProfileLevel.AVCLevel1 -> "1.0"
            MediaCodecInfo.CodecProfileLevel.AVCLevel1b -> "1b"
            MediaCodecInfo.CodecProfileLevel.AVCLevel11 -> "1.1"
            MediaCodecInfo.CodecProfileLevel.AVCLevel12 -> "1.2"
            MediaCodecInfo.CodecProfileLevel.AVCLevel13 -> "1.3"
            MediaCodecInfo.CodecProfileLevel.AVCLevel2 -> "2.0"
            MediaCodecInfo.CodecProfileLevel.AVCLevel21 -> "2.1"
            MediaCodecInfo.CodecProfileLevel.AVCLevel22 -> "2.2"
            MediaCodecInfo.CodecProfileLevel.AVCLevel3 -> "3.0"
            MediaCodecInfo.CodecProfileLevel.AVCLevel31 -> "3.1"
            MediaCodecInfo.CodecProfileLevel.AVCLevel32 -> "3.2"
            MediaCodecInfo.CodecProfileLevel.AVCLevel4 -> "4.0"
            MediaCodecInfo.CodecProfileLevel.AVCLevel41 -> "4.1"
            MediaCodecInfo.CodecProfileLevel.AVCLevel42 -> "4.2"
            MediaCodecInfo.CodecProfileLevel.AVCLevel5 -> "5.0"
            MediaCodecInfo.CodecProfileLevel.AVCLevel51 -> "5.1"
            MediaCodecInfo.CodecProfileLevel.AVCLevel52 -> "5.2"
            else -> if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                when (level) {
                    MediaCodecInfo.CodecProfileLevel.AVCLevel6 -> "6.0"
                    MediaCodecInfo.CodecProfileLevel.AVCLevel61 -> "6.1"
                    MediaCodecInfo.CodecProfileLevel.AVCLevel62 -> "6.2"
                    else -> "Level $level"
                }
            } else "Level $level"
        }
    }

    fun mapColorFormatToString(colorFormat: Int): String {
        return when (colorFormat) {
            19 -> "COLOR_FormatYUV420Planar"
            21 -> "COLOR_FormatYUV420SemiPlanar"
            2130706433 -> "COLOR_FormatSurface"
            2135033992 -> "COLOR_FormatYUV420Flexible"
            20 -> "COLOR_FormatYUV420PackedPlanar"
            25 -> "COLOR_FormatYUV422SemiPlanar"
            else -> "ColorFormat(0x${Integer.toHexString(colorFormat)})"
        }
    }
}
