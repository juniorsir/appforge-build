package com.example.ui.settings

import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.FloatingBubbleService
import com.example.MainActivity
import com.example.data.DownloadEntity
import com.example.player.gestures.PlayerGestureAction
import com.example.player.gestures.PlayerGestureSettingsDialog
import com.example.storage.cleanup.AutoCleanPeriod
import com.example.ui.*
import com.example.ui.theme.*
import java.io.File
import java.util.Locale

/**
 * 1. APPEARANCE SETTINGS PAGE
 * Themes, Accent Colors, Dynamic Palette, Typography, and Glassmorphism
 */
@Composable
fun AppearanceSettingsPage(
    viewModel: VideoDownloaderViewModel,
    modifier: Modifier = Modifier
) {
    val currentThemeSettings by viewModel.appThemeSettings.collectAsStateWithLifecycle()

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        SettingsSectionCard(title = "THEME & VISUAL PERSONALIZATION") {
            Box(modifier = Modifier.padding(16.dp)) {
                ThemePersonalizationSection(
                    themeSettings = currentThemeSettings,
                    onUpdateThemeSettings = { updated ->
                        viewModel.updateAppThemeSettings(updated)
                    }
                )
            }
        }
    }
}

/**
 * 2. PLAYER SETTINGS PAGE
 * Decoder Mode, Hardware Acceleration, Audio Output, PiP Settings, Gestures Config
 */
@Composable
fun PlayerSettingsPage(
    viewModel: VideoDownloaderViewModel,
    modifier: Modifier = Modifier
) {
    var showPlayerGesturesDialog by remember { mutableStateOf(false) }
    val gestureSettings by viewModel.playerGestureSettings.collectAsStateWithLifecycle()
    val activeGesturesCount = gestureSettings.mappings.count { it.value != PlayerGestureAction.NONE }

    val playerDecoderMode by viewModel.playerDecoderMode.collectAsStateWithLifecycle()
    val hardwareAcceleration by viewModel.hardwareAcceleration.collectAsStateWithLifecycle()
    val audioOutputMode by viewModel.audioOutputMode.collectAsStateWithLifecycle()
    val autoDimScreenOnInactivity by viewModel.autoDimScreenOnInactivity.collectAsStateWithLifecycle()
    val autoDimInactivitySeconds by viewModel.autoDimInactivitySeconds.collectAsStateWithLifecycle()

    val pipModePreference by viewModel.pipModePreference.collectAsStateWithLifecycle()
    val autoSystemPipOnLeave by viewModel.autoSystemPipOnLeave.collectAsStateWithLifecycle()
    val showPipControlsOnPlayer by viewModel.showPipControlsOnPlayer.collectAsStateWithLifecycle()

    var decoderMenuExpanded by remember { mutableStateOf(false) }
    val decoderOptions = listOf("Auto (HW + SW Fallback)", "Hardware First", "Software (FFmpeg) Force")

    var audioOutputExpanded by remember { mutableStateOf(false) }
    val audioOutputOptions = listOf("Auto (PCM/Passthrough)", "PCM Downmix", "Passthrough (Direct)")

    var pipDropdownExpanded by remember { mutableStateOf(false) }
    val pipOptions = listOf(
        "Both (Smart Dual PiP)",
        "Custom In-App Floating PiP",
        "Default Android System PiP",
        "Disabled"
    )

    if (showPlayerGesturesDialog) {
        PlayerGestureSettingsDialog(
            currentSettings = gestureSettings,
            onSaveSettings = { updated ->
                viewModel.updatePlayerGestureSettings(updated)
            },
            onDismiss = { showPlayerGesturesDialog = false }
        )
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Player & Decoder Engine Card
        SettingsSectionCard(title = "PLAYER & DECODER ENGINE") {
            SettingRow(
                icon = Icons.Default.Gesture,
                title = "Player Gestures",
                description = "Player gesture areas:\nBrightness: Left 30%\nGeneral gestures: Center 40%\nVolume: Right 30%",
                onClick = { showPlayerGesturesDialog = true },
                showDivider = true
            ) {
                Box(
                    modifier = Modifier
                        .background(SleekPurpleLight.copy(alpha = 0.12f), RoundedCornerShape(10.dp))
                        .border(1.dp, SleekPurpleLight.copy(alpha = 0.3f), RoundedCornerShape(10.dp))
                        .clickable { showPlayerGesturesDialog = true }
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = "Configure",
                            color = SleekPurpleLight,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                        Icon(
                            imageVector = Icons.Default.ChevronRight,
                            contentDescription = null,
                            tint = SleekPurpleLight,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }

            SettingRow(
                icon = Icons.Default.Memory,
                title = "Decoder Preference",
                description = "Choose codec engine priority for video/audio streams",
                onClick = { decoderMenuExpanded = true },
                showDivider = true
            ) {
                Box {
                    Box(
                        modifier = Modifier
                            .background(Color.White.copy(alpha = 0.05f), RoundedCornerShape(10.dp))
                            .border(1.dp, Color.White.copy(alpha = 0.12f), RoundedCornerShape(10.dp))
                            .clickable { decoderMenuExpanded = true }
                            .padding(horizontal = 12.dp, vertical = 6.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                text = playerDecoderMode,
                                color = SleekPurpleLight,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                            Icon(
                                imageVector = Icons.Default.ArrowDropDown,
                                contentDescription = null,
                                tint = SleekPurpleLight,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                    DropdownMenu(
                        expanded = decoderMenuExpanded,
                        onDismissRequest = { decoderMenuExpanded = false },
                        modifier = Modifier.background(SleekCardDark)
                    ) {
                        decoderOptions.forEach { opt ->
                            DropdownMenuItem(
                                text = { Text(opt, color = SleekTextPrimary, fontSize = 13.sp) },
                                onClick = {
                                    viewModel.updatePlayerDecoderMode(opt)
                                    decoderMenuExpanded = false
                                }
                            )
                        }
                    }
                }
            }

            SettingRow(
                icon = Icons.Default.Speed,
                title = "Hardware Acceleration",
                description = "Enable GPU/MediaCodec hardware decoding for battery efficiency",
                showDivider = true
            ) {
                SmoothToggle(
                    checked = hardwareAcceleration,
                    onCheckedChange = { viewModel.updateHardwareAcceleration(it) }
                )
            }

            SettingRow(
                icon = Icons.Default.SurroundSound,
                title = "Audio Output Mode",
                description = "Passthrough multi-channel AC3/E-AC3/DTS to receiver or downmix to PCM",
                onClick = { audioOutputExpanded = true },
                showDivider = true
            ) {
                Box {
                    Box(
                        modifier = Modifier
                            .background(Color.White.copy(alpha = 0.05f), RoundedCornerShape(10.dp))
                            .border(1.dp, Color.White.copy(alpha = 0.12f), RoundedCornerShape(10.dp))
                            .clickable { audioOutputExpanded = true }
                            .padding(horizontal = 12.dp, vertical = 6.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                text = audioOutputMode,
                                color = SleekPurpleLight,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                            Icon(
                                imageVector = Icons.Default.ArrowDropDown,
                                contentDescription = null,
                                tint = SleekPurpleLight,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                    DropdownMenu(
                        expanded = audioOutputExpanded,
                        onDismissRequest = { audioOutputExpanded = false },
                        modifier = Modifier.background(SleekCardDark)
                    ) {
                        audioOutputOptions.forEach { opt ->
                            DropdownMenuItem(
                                text = { Text(opt, color = SleekTextPrimary, fontSize = 13.sp) },
                                onClick = {
                                    viewModel.updateAudioOutputMode(opt)
                                    audioOutputExpanded = false
                                }
                            )
                        }
                    }
                }
            }

            SettingRow(
                icon = Icons.Default.BatterySaver,
                title = "Auto-Dim Inactivity (Battery Saver)",
                description = "Automatically dims screen brightness after ${autoDimInactivitySeconds}s of video inactivity to save battery",
                showDivider = false
            ) {
                SmoothToggle(
                    checked = autoDimScreenOnInactivity,
                    onCheckedChange = { viewModel.updateAutoDimScreenOnInactivity(it) }
                )
            }
        }

        // FFmpeg Native Engine Interactive Console & Self-Check Subsystem
        FFmpegConsoleCard()

        // Picture-In-Picture (PiP) Settings Block
        SettingsSectionCard(title = "PICTURE-IN-PICTURE (PiP) PLAYBACK") {
            SettingRow(
                icon = Icons.Default.PictureInPictureAlt,
                title = "PiP Mode Preference",
                description = when (pipModePreference) {
                    "Both (Smart Dual PiP)" -> "Custom floating player inside app + System PiP on exit"
                    "Custom In-App Floating PiP" -> "Floating glass window inside app while browsing tabs"
                    "Default Android System PiP" -> "Native Android OS Picture-in-Picture window"
                    else -> "Picture-in-Picture disabled"
                },
                onClick = { pipDropdownExpanded = true },
                showDivider = true
            ) {
                Box {
                    Box(
                        modifier = Modifier
                            .background(Color.White.copy(alpha = 0.05f), RoundedCornerShape(10.dp))
                            .border(1.dp, Color.White.copy(alpha = 0.12f), RoundedCornerShape(10.dp))
                            .clickable { pipDropdownExpanded = true }
                            .padding(horizontal = 12.dp, vertical = 6.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                text = pipModePreference,
                                color = SleekPurpleLight,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                            Icon(
                                imageVector = Icons.Default.ArrowDropDown,
                                contentDescription = null,
                                tint = SleekPurpleLight,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                    DropdownMenu(
                        expanded = pipDropdownExpanded,
                        onDismissRequest = { pipDropdownExpanded = false },
                        modifier = Modifier.background(SleekCardDark)
                    ) {
                        pipOptions.forEach { option ->
                            DropdownMenuItem(
                                text = { Text(option, color = SleekTextPrimary) },
                                onClick = {
                                    viewModel.updatePipModePreference(option)
                                    pipDropdownExpanded = false
                                }
                            )
                        }
                    }
                }
            }

            if (pipModePreference == "Both (Smart Dual PiP)" || pipModePreference == "Default Android System PiP") {
                SettingRow(
                    icon = Icons.Default.OpenInNew,
                    title = "Auto-Enter System PiP on App Exit",
                    description = "Seamlessly shrink to System OS PiP when pressing Home or switching apps",
                    showDivider = true
                ) {
                    SmoothToggle(
                        checked = autoSystemPipOnLeave,
                        onCheckedChange = { viewModel.updateAutoSystemPipOnLeave(it) }
                    )
                }
            }

            SettingRow(
                icon = Icons.Default.FeaturedVideo,
                title = "Show PiP Action Controls on Player",
                description = "Display dedicated Picture-in-Picture buttons on video player header",
                showDivider = false
            ) {
                SmoothToggle(
                    checked = showPipControlsOnPlayer,
                    onCheckedChange = { viewModel.updateShowPipControlsOnPlayer(it) }
                )
            }
        }
    }
}

/**
 * 3. DOWNLOADS SETTINGS PAGE
 * Preferred quality/format, Codecs, Subtitles, Audio Streams, Battery Optimization
 */
@Composable
fun DownloadsSettingsPage(
    viewModel: VideoDownloaderViewModel,
    modifier: Modifier = Modifier
) {
    var wifiOnly by remember { mutableStateOf(true) }
    var backgroundDownloads by remember { mutableStateOf(true) }
    var autoConvertAudio by remember { mutableStateOf(false) }

    val usePublicDownloads by viewModel.usePublicDownloads.collectAsStateWithLifecycle()
    val showAdvancedFormats by viewModel.showAdvancedFormats.collectAsStateWithLifecycle()
    val defaultDownloadQuality by viewModel.defaultDownloadQuality.collectAsStateWithLifecycle()
    val preferredAudioFormat by viewModel.preferredAudioFormat.collectAsStateWithLifecycle()
    val preferredAudioQuality by viewModel.preferredAudioQuality.collectAsStateWithLifecycle()

    val embedSubtitles by viewModel.embedSubtitles.collectAsStateWithLifecycle()
    val embedAutoSubtitles by viewModel.embedAutoSubtitles.collectAsStateWithLifecycle()
    val subtitleLanguages by viewModel.subtitleLanguages.collectAsStateWithLifecycle()
    val embedAudioMetadata by viewModel.embedAudioMetadata.collectAsStateWithLifecycle()
    val audioMultistreams by viewModel.audioMultistreams.collectAsStateWithLifecycle()

    val batteryInfo by viewModel.batteryInfo.collectAsStateWithLifecycle()
    val autoPauseBattery by viewModel.autoPauseOnLowBatteryOrDischarging.collectAsStateWithLifecycle()
    val batterySaverThreshold by viewModel.batterySaverThreshold.collectAsStateWithLifecycle()
    val pauseIfNotCharging by viewModel.pauseIfNotCharging.collectAsStateWithLifecycle()
    val largeFileThresholdMb by viewModel.largeFileThresholdMb.collectAsStateWithLifecycle()
    val autoResumeOnPower by viewModel.autoResumeOnPowerConnected.collectAsStateWithLifecycle()

    var qualityExpanded by remember { mutableStateOf(false) }
    val qualityOptions = listOf("Ask Every Time", "Audio Only", "1080p", "720p", "480p", "360p", "144p")

    var audioFormatExpanded by remember { mutableStateOf(false) }
    val audioFormatOptions = listOf("MP3", "M4A", "OPUS", "FLAC", "WAV", "OGG")

    var audioQualityExpanded by remember { mutableStateOf(false) }
    val audioQualityOptions = listOf("320 kbps (Best)", "256 kbps (High)", "192 kbps (Standard)", "128 kbps (Compact)")

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Core Download Preferences
        SettingsSectionCard(title = "DOWNLOAD PREFERENCES") {
            SettingRow(
                icon = Icons.Default.Wifi,
                title = "Download over Wi-Fi only",
                description = "Pause downloads on cellular data",
                showDivider = true
            ) {
                SmoothToggle(
                    checked = wifiOnly,
                    onCheckedChange = { wifiOnly = it }
                )
            }

            SettingRow(
                icon = Icons.Default.CloudDownload,
                title = "Background downloads",
                description = "Continue downloading when app is closed",
                showDivider = true
            ) {
                SmoothToggle(
                    checked = backgroundDownloads,
                    onCheckedChange = { backgroundDownloads = it }
                )
            }

            SettingRow(
                icon = Icons.Default.MusicNote,
                title = "Save as Audio by Default",
                description = "Always extract MP3 format if available",
                showDivider = true
            ) {
                SmoothToggle(
                    checked = autoConvertAudio,
                    onCheckedChange = { autoConvertAudio = it }
                )
            }

            SettingRow(
                icon = Icons.Default.Folder,
                title = "Save to Public Downloads",
                description = "Store files in main Downloads folder",
                showDivider = true
            ) {
                SmoothToggle(
                    checked = usePublicDownloads,
                    onCheckedChange = { viewModel.updateUsePublicDownloads(it) }
                )
            }

            SettingRow(
                icon = Icons.Default.Tune,
                title = "Allow All Codecs & Advanced Formats",
                description = "Show all raw audio/video codec options provided by yt-dlp",
                showDivider = true
            ) {
                SmoothToggle(
                    checked = showAdvancedFormats,
                    onCheckedChange = { viewModel.updateShowAdvancedFormats(it) }
                )
            }

            SettingRow(
                icon = Icons.Default.HighQuality,
                title = "Default Download Quality",
                description = "Automatically skip format selection if available",
                onClick = { qualityExpanded = true },
                showDivider = false
            ) {
                Box {
                    Box(
                        modifier = Modifier
                            .background(Color.White.copy(alpha = 0.05f), RoundedCornerShape(10.dp))
                            .border(1.dp, Color.White.copy(alpha = 0.12f), RoundedCornerShape(10.dp))
                            .clickable { qualityExpanded = true }
                            .padding(horizontal = 12.dp, vertical = 6.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                text = defaultDownloadQuality,
                                color = SleekPurpleLight,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                            Icon(
                                imageVector = Icons.Default.ArrowDropDown,
                                contentDescription = null,
                                tint = SleekPurpleLight,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                    DropdownMenu(
                        expanded = qualityExpanded,
                        onDismissRequest = { qualityExpanded = false },
                        modifier = Modifier.background(SleekCardDark)
                    ) {
                        qualityOptions.forEach { opt ->
                            DropdownMenuItem(
                                text = { Text(opt, color = SleekTextPrimary) },
                                onClick = {
                                    viewModel.updateDefaultDownloadQuality(opt)
                                    qualityExpanded = false
                                }
                            )
                        }
                    }
                }
            }
        }

        // Subtitles & Audio Stream Extraction
        SettingsSectionCard(title = "SUBTITLES & AUDIO ENCODING") {
            SettingRow(
                icon = Icons.Default.Subtitles,
                title = "Embed Subtitles",
                description = "Mux official subtitles directly into MP4/MKV video containers",
                showDivider = true
            ) {
                SmoothToggle(
                    checked = embedSubtitles,
                    onCheckedChange = { viewModel.updateEmbedSubtitles(it) }
                )
            }

            SettingRow(
                icon = Icons.Default.ClosedCaption,
                title = "Embed Auto-Generated Subtitles",
                description = "Include platform auto-generated captions if available",
                showDivider = true
            ) {
                SmoothToggle(
                    checked = embedAutoSubtitles,
                    onCheckedChange = { viewModel.updateEmbedAutoSubtitles(it) }
                )
            }

            SettingRow(
                icon = Icons.Default.Translate,
                title = "Subtitle Languages",
                description = "Comma-separated language codes (e.g. en, es, fr, de, ja)",
                showDivider = true
            ) {
                Surface(
                    color = Color.White.copy(alpha = 0.05f),
                    shape = RoundedCornerShape(8.dp),
                    border = BorderStroke(1.dp, SleekBorderColor.copy(alpha = 0.3f))
                ) {
                    Text(
                        text = subtitleLanguages,
                        color = SleekPurpleLight,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            SettingRow(
                icon = Icons.Default.Audiotrack,
                title = "Embed ID3 Metadata & Album Art",
                description = "Add artist, album cover, and release metadata into extracted audio",
                showDivider = true
            ) {
                SmoothToggle(
                    checked = embedAudioMetadata,
                    onCheckedChange = { viewModel.updateEmbedAudioMetadata(it) }
                )
            }

            SettingRow(
                icon = Icons.Default.Layers,
                title = "Preserve Multi-Language Audio Streams",
                description = "Download all secondary audio tracks for multi-dub media",
                showDivider = true
            ) {
                SmoothToggle(
                    checked = audioMultistreams,
                    onCheckedChange = { viewModel.updateAudioMultistreams(it) }
                )
            }

            SettingRow(
                icon = Icons.Default.GraphicEq,
                title = "Preferred Audio Extraction Format",
                description = "Target format when extracting audio tracks",
                onClick = { audioFormatExpanded = true },
                showDivider = true
            ) {
                Box {
                    Box(
                        modifier = Modifier
                            .background(Color.White.copy(alpha = 0.05f), RoundedCornerShape(10.dp))
                            .border(1.dp, Color.White.copy(alpha = 0.12f), RoundedCornerShape(10.dp))
                            .clickable { audioFormatExpanded = true }
                            .padding(horizontal = 12.dp, vertical = 6.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                text = preferredAudioFormat,
                                color = SleekPurpleLight,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                            Icon(
                                imageVector = Icons.Default.ArrowDropDown,
                                contentDescription = null,
                                tint = SleekPurpleLight,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                    DropdownMenu(
                        expanded = audioFormatExpanded,
                        onDismissRequest = { audioFormatExpanded = false },
                        modifier = Modifier.background(SleekCardDark)
                    ) {
                        audioFormatOptions.forEach { opt ->
                            DropdownMenuItem(
                                text = { Text(opt, color = SleekTextPrimary) },
                                onClick = {
                                    viewModel.updatePreferredAudioFormat(opt)
                                    audioFormatExpanded = false
                                }
                            )
                        }
                    }
                }
            }

            SettingRow(
                icon = Icons.Default.SurroundSound,
                title = "Audio Bitrate / Quality",
                description = "Target audio compression bitrate for output files",
                onClick = { audioQualityExpanded = true },
                showDivider = false
            ) {
                Box {
                    Box(
                        modifier = Modifier
                            .background(Color.White.copy(alpha = 0.05f), RoundedCornerShape(10.dp))
                            .border(1.dp, Color.White.copy(alpha = 0.12f), RoundedCornerShape(10.dp))
                            .clickable { audioQualityExpanded = true }
                            .padding(horizontal = 12.dp, vertical = 6.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                text = preferredAudioQuality,
                                color = SleekPurpleLight,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                            Icon(
                                imageVector = Icons.Default.ArrowDropDown,
                                contentDescription = null,
                                tint = SleekPurpleLight,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                    DropdownMenu(
                        expanded = audioQualityExpanded,
                        onDismissRequest = { audioQualityExpanded = false },
                        modifier = Modifier.background(SleekCardDark)
                    ) {
                        audioQualityOptions.forEach { opt ->
                            DropdownMenuItem(
                                text = { Text(opt, color = SleekTextPrimary) },
                                onClick = {
                                    viewModel.updatePreferredAudioQuality(opt)
                                    audioQualityExpanded = false
                                }
                            )
                        }
                    }
                }
            }
        }

        // Battery & System Resource Optimization
        SettingsSectionCard(title = "BATTERY & SYSTEM OPTIMIZATION") {
            // Live Battery HUD Card
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp)
                    .background(
                        brush = Brush.horizontalGradient(
                            colors = if (batteryInfo.isCharging) {
                                listOf(EmeraldSuccess.copy(alpha = 0.2f), Color(0xFF1B2A22))
                            } else if (batteryInfo.isLowBattery) {
                                listOf(CrimsonFailure.copy(alpha = 0.25f), Color(0xFF2E1A1A))
                            } else {
                                listOf(SleekPurpleLight.copy(alpha = 0.18f), Color(0xFF1D1B28))
                            }
                        ),
                        shape = RoundedCornerShape(16.dp)
                    )
                    .border(
                        1.dp,
                        if (batteryInfo.isCharging) EmeraldSuccess.copy(alpha = 0.4f)
                        else if (batteryInfo.isLowBattery) CrimsonFailure.copy(alpha = 0.4f)
                        else SleekPurpleLight.copy(alpha = 0.3f),
                        RoundedCornerShape(16.dp)
                    )
                    .padding(14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        modifier = Modifier.weight(1f),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .background(
                                    if (batteryInfo.isCharging) EmeraldSuccess.copy(alpha = 0.2f)
                                    else if (batteryInfo.isLowBattery) CrimsonFailure.copy(alpha = 0.25f)
                                    else SleekPurpleLight.copy(alpha = 0.2f),
                                    CircleShape
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (batteryInfo.isCharging) Icons.Default.BatteryChargingFull
                                else if (batteryInfo.isLowBattery) Icons.Default.BatteryAlert
                                else Icons.Default.BatteryStd,
                                contentDescription = null,
                                tint = if (batteryInfo.isCharging) EmeraldSuccess
                                else if (batteryInfo.isLowBattery) CrimsonFailure
                                else SleekPurpleLight,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text(
                                    text = "Battery: ${batteryInfo.batteryPercentage}%",
                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                    color = SleekTextPrimary
                                )
                                if (batteryInfo.isCharging) {
                                    Box(
                                        modifier = Modifier
                                            .background(EmeraldSuccess.copy(alpha = 0.25f), RoundedCornerShape(4.dp))
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text(
                                            "CHARGING",
                                            color = EmeraldSuccess,
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 9.sp
                                            )
                                        )
                                    }
                                }
                            }
                            Text(
                                text = if (batteryInfo.isCharging) {
                                    "Power Connected • Maximum download speed"
                                } else if (batteryInfo.isBatterySaverTriggered) {
                                    "⚠️ Eco-Saver active: Large downloads (>= ${largeFileThresholdMb}MB) paused"
                                } else {
                                    "Running on battery • Auto-pause threshold at <= ${batterySaverThreshold}%"
                                },
                                style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                                color = if (batteryInfo.isBatterySaverTriggered && !batteryInfo.isCharging) CrimsonFailure else SleekTextSecondary,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }

            SettingRow(
                icon = Icons.Default.BatterySaver,
                title = "Auto-Pause on Low Battery or Unplugged",
                description = "Automatically pause large downloads (>= ${largeFileThresholdMb}MB) when battery is low",
                showDivider = true
            ) {
                SmoothToggle(
                    checked = autoPauseBattery,
                    onCheckedChange = { viewModel.setAutoPauseOnLowBatteryOrDischarging(it) }
                )
            }

            SettingRow(
                icon = Icons.Default.PowerOff,
                title = "Pause Large Downloads When Not Charging",
                description = "Preserve system resources by only processing large downloads while plugged into power",
                showDivider = true
            ) {
                SmoothToggle(
                    checked = pauseIfNotCharging,
                    onCheckedChange = { viewModel.setPauseIfNotCharging(it) }
                )
            }

            SettingRow(
                icon = Icons.Default.FlashOn,
                title = "Auto-Resume When Plugged into Power",
                description = "Instantly resume paused downloads when device connects to charger",
                showDivider = true
            ) {
                SmoothToggle(
                    checked = autoResumeOnPower,
                    onCheckedChange = { viewModel.setAutoResumeOnPowerConnected(it) }
                )
            }

            // Low Battery Cutoff Threshold Picker
            SettingRow(
                icon = Icons.Default.BatteryAlert,
                title = "Low Battery Cutoff Percentage",
                description = "Threshold level: ${batterySaverThreshold}%",
                showDivider = true
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    listOf(15, 20, 25, 30).forEach { threshold ->
                        val isSelected = batterySaverThreshold == threshold
                        Box(
                            modifier = Modifier
                                .clickable { viewModel.setBatterySaverThreshold(threshold) }
                                .background(
                                    if (isSelected) SleekPurpleLight else SleekCardDark,
                                    RoundedCornerShape(8.dp)
                                )
                                .border(
                                    1.dp,
                                    if (isSelected) SleekPurpleLight else SleekBorderColor,
                                    RoundedCornerShape(8.dp)
                                )
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "$threshold%",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isSelected) Color.White else SleekTextSecondary
                                )
                            )
                        }
                    }
                }
            }

            // Large File Size Threshold Picker
            SettingRow(
                icon = Icons.Default.DataUsage,
                title = "Large File Size Threshold",
                description = "Threshold trigger: ${largeFileThresholdMb}MB",
                showDivider = false
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    listOf(25, 50, 100, 250, 500).forEach { mb ->
                        val isSelected = largeFileThresholdMb == mb
                        Box(
                            modifier = Modifier
                                .clickable { viewModel.setLargeFileThresholdMb(mb) }
                                .background(
                                    if (isSelected) SleekPurpleLight else SleekCardDark,
                                    RoundedCornerShape(8.dp)
                                )
                                .border(
                                    1.dp,
                                    if (isSelected) SleekPurpleLight else SleekBorderColor,
                                    RoundedCornerShape(8.dp)
                                )
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "${mb}MB",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isSelected) Color.White else SleekTextSecondary
                                )
                            )
                        }
                    }
                }
            }
        }
    }
}

/**
 * 4. LIBRARY SETTINGS PAGE
 * Folders, Safe Search, Cloud Sync & Backup, Metadata Scraper
 */
@Composable
fun LibrarySettingsPage(
    viewModel: VideoDownloaderViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val isStudentMode by viewModel.isStudentMode.collectAsStateWithLifecycle()
    val showRecommendations by viewModel.showRecommendations.collectAsStateWithLifecycle()
    val saveSearchHistory by viewModel.saveSearchHistory.collectAsStateWithLifecycle()

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Discovery & Safe Mode
        SettingsSectionCard(title = "CONTENT & DISCOVERY") {
            SettingRow(
                icon = Icons.Default.School,
                title = "Safe Search & Student Mode",
                description = "Filter mature content and strictly lock safe search filters",
                showDivider = true
            ) {
                SmoothToggle(
                    checked = isStudentMode,
                    onCheckedChange = { viewModel.updateStudentMode(it) }
                )
            }

            SettingRow(
                icon = Icons.Default.Explore,
                title = "Show Content Recommendations",
                description = "Display trending search topics and discovery recommendations",
                showDivider = true
            ) {
                SmoothToggle(
                    checked = showRecommendations,
                    onCheckedChange = { viewModel.updateShowRecommendations(it) }
                )
            }

            SettingRow(
                icon = Icons.Default.History,
                title = "Save Search History",
                description = "Store recent searches locally on device for quick re-use",
                showDivider = false
            ) {
                SmoothToggle(
                    checked = saveSearchHistory,
                    onCheckedChange = { viewModel.updateSaveSearchHistory(it) }
                )
            }
        }
    }
}

/**
 * 5. NETWORK & TRANSFER SETTINGS PAGE
 * Cellular downloads, Floating Bubble Overlay, yt-dlp CLI Executor
 */
@Composable
fun NetworkSettingsPage(
    viewModel: VideoDownloaderViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    var isOverlayActive by remember { mutableStateOf(FloatingBubbleService.isRunning) }

    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                isOverlayActive = FloatingBubbleService.isRunning
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    val customCommandInput by viewModel.customCommandInput.collectAsStateWithLifecycle()
    val ytdlpVerificationStatus by viewModel.ytdlpVerificationStatus.collectAsStateWithLifecycle()
    val isYtdlpLoading by viewModel.isYtdlpLoading.collectAsStateWithLifecycle()

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Floating Bubble & System Overlay
        SettingsSectionCard(title = "SYSTEM OVERLAY & FLOATING BUBBLE") {
            SettingRow(
                icon = Icons.Default.Layers,
                title = "Floating Bubble Search",
                description = "Show quick URL downloader bubble over other apps",
                showDivider = false
            ) {
                SmoothToggle(
                    checked = isOverlayActive,
                    onCheckedChange = { active ->
                        if (active) {
                            if (!FloatingBubbleService.canDrawOverlaysSafe(context)) {
                                var currentContext: Context? = context
                                while (currentContext is ContextWrapper) {
                                    if (currentContext is MainActivity) {
                                        currentContext.setSentToOverlaySettings(true)
                                        break
                                    }
                                    currentContext = currentContext.baseContext
                                }
                                Toast.makeText(context, "Please enable 'Draw over other apps' to use the floating search bubble", Toast.LENGTH_LONG).show()
                                val intent = Intent(
                                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                    Uri.parse("package:${context.packageName}")
                                )
                                context.startActivity(intent)
                            } else {
                                isOverlayActive = true
                                val serviceIntent = Intent(context, FloatingBubbleService::class.java)
                                context.startService(serviceIntent)
                            }
                        } else {
                            isOverlayActive = false
                            val serviceIntent = Intent(context, FloatingBubbleService::class.java)
                            context.stopService(serviceIntent)
                        }
                    }
                )
            }
        }

        // YT-DLP CLI Terminal & Engine Verification
        SettingsSectionCard(title = "CUSTOM CLI TERMINAL RUNNER") {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedTextField(
                    value = customCommandInput,
                    onValueChange = { viewModel.updateCustomCommandInput(it) },
                    placeholder = { Text("e.g. --version or --help", color = SleekTextSecondary.copy(alpha = 0.6f)) },
                    leadingIcon = {
                        Text(
                            " ./engine ",
                            color = SleekPurpleDark,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(start = 12.dp)
                        )
                    },
                    textStyle = LocalTextStyle.current.copy(fontFamily = FontFamily.Monospace, fontSize = 13.sp),
                    modifier = Modifier.fillMaxWidth().testTag("custom_command_input"),
                    shape = RoundedCornerShape(12.dp),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = SleekTextPrimary,
                        unfocusedTextColor = SleekTextPrimary,
                        focusedBorderColor = SleekPurpleDark,
                        unfocusedBorderColor = SleekBorderColor,
                        focusedContainerColor = SleekCardDark,
                        unfocusedContainerColor = SleekCardDark
                    )
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Button(
                        onClick = { viewModel.verifyYtdlp(context) },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color.Black,
                            contentColor = Color.White,
                            disabledContainerColor = Color.Black.copy(alpha = 0.5f),
                            disabledContentColor = Color.White.copy(alpha = 0.5f)
                        ),
                        shape = RoundedCornerShape(16.dp),
                        contentPadding = PaddingValues(0.dp),
                        modifier = Modifier.weight(1f).height(48.dp).testTag("verify_ytdlp_btn"),
                        enabled = !isYtdlpLoading,
                        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.3f))
                    ) {
                        Icon(Icons.Default.CheckCircle, contentDescription = "Verify", modifier = Modifier.size(20.dp))
                    }

                    Button(
                        onClick = { viewModel.executeCustomYtdlpCommand(context) },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color.White,
                            contentColor = Color.Black,
                            disabledContainerColor = Color.White.copy(alpha = 0.5f),
                            disabledContentColor = Color.Black.copy(alpha = 0.5f)
                        ),
                        shape = RoundedCornerShape(16.dp),
                        contentPadding = PaddingValues(0.dp),
                        modifier = Modifier.weight(1f).height(48.dp).testTag("run_custom_command_btn"),
                        enabled = !isYtdlpLoading
                    ) {
                        Icon(Icons.Default.PlayArrow, contentDescription = "Run", modifier = Modifier.size(20.dp))
                    }
                }

                // Terminal Output Console Box
                if (ytdlpVerificationStatus.isNotEmpty()) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = SleekCardDark),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
                    ) {
                        SelectionContainer {
                            Text(
                                text = ytdlpVerificationStatus,
                                color = if (ytdlpVerificationStatus.contains("Error", true) || ytdlpVerificationStatus.contains("Failed", true)) CrimsonFailure else EmeraldSuccess,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 12.sp,
                                modifier = Modifier.padding(14.dp)
                            )
                        }
                    }
                }
            }
        }

        // Dedicated FFmpeg Engine CLI Console Runner & Verification
        FFmpegConsoleCard()

        // Live Console Logs & Engine Output
        val executionLogs by viewModel.executionLogs.collectAsStateWithLifecycle()
        val clipboardManager = androidx.compose.ui.platform.LocalClipboardManager.current

        SettingsSectionCard(title = "LIVE CONSOLE LOGS & ENGINE OUTPUT") {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(if (executionLogs.isNotEmpty()) EmeraldSuccess else SleekTextMuted)
                        )
                        Text(
                            text = "${executionLogs.size} Log Entries",
                            style = MaterialTheme.typography.labelMedium.copy(
                                color = SleekTextSecondary,
                                fontFamily = FontFamily.Monospace
                            )
                        )
                    }

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedButton(
                            onClick = {
                                if (executionLogs.isNotEmpty()) {
                                    val fullLog = executionLogs.joinToString("\n")
                                    clipboardManager.setText(androidx.compose.ui.text.AnnotatedString(fullLog))
                                    Toast.makeText(context, "Copied ${executionLogs.size} log lines to clipboard", Toast.LENGTH_SHORT).show()
                                } else {
                                    Toast.makeText(context, "No logs to copy", Toast.LENGTH_SHORT).show()
                                }
                            },
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(1.dp, SleekBorderColor),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                            modifier = Modifier.testTag("copy_logs_btn")
                        ) {
                            Icon(
                                Icons.Default.ContentCopy,
                                contentDescription = "Copy Logs",
                                modifier = Modifier.size(16.dp),
                                tint = SleekTextPrimary
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                "Copy Logs",
                                style = MaterialTheme.typography.labelMedium.copy(
                                    color = SleekTextPrimary,
                                    fontWeight = FontWeight.SemiBold
                                )
                            )
                        }

                        IconButton(
                            onClick = {
                                viewModel.clearLogs()
                                Toast.makeText(context, "Logs cleared", Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier.size(36.dp).testTag("clear_logs_btn")
                        ) {
                            Icon(
                                Icons.Default.DeleteSweep,
                                contentDescription = "Clear Logs",
                                modifier = Modifier.size(20.dp),
                                tint = CrimsonFailure.copy(alpha = 0.8f)
                            )
                        }
                    }
                }

                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.Black),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, Color.White.copy(alpha = 0.1f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 120.dp, max = 320.dp)
                ) {
                    if (executionLogs.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "No log output recorded yet.\nStart a download or run engine verification to view logs.",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = SleekTextMuted,
                                    fontFamily = FontFamily.Monospace,
                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                )
                            )
                        }
                    } else {
                        SelectionContainer {
                            LazyColumn(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                items(executionLogs) { logLine ->
                                    val logColor = when {
                                        logLine.contains("ERROR", ignoreCase = true) || logLine.contains("FAIL", ignoreCase = true) || logLine.contains("Exception", ignoreCase = true) -> CrimsonFailure
                                        logLine.contains("WARN", ignoreCase = true) || logLine.contains("⚠️") -> AmberAccent
                                        logLine.contains("SUCCESS", ignoreCase = true) || logLine.contains("COMPLETED", ignoreCase = true) || logLine.contains("100%") -> EmeraldSuccess
                                        logLine.startsWith("[download]") -> SleekPurpleLight
                                        else -> SleekTextSecondary
                                    }
                                    Text(
                                        text = logLine,
                                        color = logColor,
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = 11.sp,
                                        lineHeight = 15.sp
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * 6. NOTIFICATIONS & BACKGROUND CONTROLS SETTINGS PAGE
 * Audio background playback, Download notifications, Haptic feedback
 */
@Composable
fun NotificationsSettingsPage(
    viewModel: VideoDownloaderViewModel,
    modifier: Modifier = Modifier
) {
    val persistentForegroundNotifications by viewModel.persistentForegroundNotifications.collectAsStateWithLifecycle()
    val enableHapticFeedback by viewModel.enableHapticFeedback.collectAsStateWithLifecycle()
    val youtubeBgPlay by viewModel.youtubeBackgroundPlayEnabled.collectAsStateWithLifecycle()

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        SettingsSectionCard(title = "NOTIFICATIONS & BACKGROUND PLAY") {
            SettingRow(
                icon = Icons.Default.Headset,
                title = "YouTube Background Audio Playback",
                description = "Keep listening to media audio when screen is turned off, app is minimized, or browsing other tabs without opening any floating PiP window",
                showDivider = true
            ) {
                SmoothToggle(
                    checked = youtubeBgPlay,
                    onCheckedChange = { viewModel.updateYoutubeBackgroundPlayEnabled(it) }
                )
            }

            SettingRow(
                icon = Icons.Default.NotificationsActive,
                title = "Persistent Foreground Notifications",
                description = "Show ongoing download progress notifications in system tray",
                showDivider = true
            ) {
                SmoothToggle(
                    checked = persistentForegroundNotifications,
                    onCheckedChange = { viewModel.updatePersistentForegroundNotifications(it) }
                )
            }

            SettingRow(
                icon = Icons.Default.Vibration,
                title = "Haptic Tactile Feedback",
                description = "Vibrate on key actions and download completion events",
                showDivider = false
            ) {
                SmoothToggle(
                    checked = enableHapticFeedback,
                    onCheckedChange = { viewModel.updateEnableHapticFeedback(it) }
                )
            }
        }
    }
}

/**
 * 7. STORAGE SETTINGS PAGE
 * Storage breakdown, Auto-clean watched media (Phase 3B), Cache clear, Delete Library
 */
@Composable
fun StorageSettingsPage(
    downloads: List<DownloadEntity>,
    onClearAllDownloads: () -> Unit,
    viewModel: VideoDownloaderViewModel,
    modifier: Modifier = Modifier
) {
    val autoCleanSettings by viewModel.autoCleanSettings.collectAsStateWithLifecycle()
    val watchedCleanupItems by viewModel.watchedCleanupItems.collectAsStateWithLifecycle()
    var showReviewCleanupDialog by remember { mutableStateOf(false) }
    var showUnwantedFilesDialog by remember { mutableStateOf(false) }
    var showConfirmClear by remember { mutableStateOf(false) }
    var periodDropdownExpanded by remember { mutableStateOf(false) }

    val downloadCount = downloads.size
    val totalBytes = remember(downloads) {
        downloads.sumOf { item ->
            val f = File(item.localPath)
            if (f.exists()) f.length() else 0L
        }
    }
    val totalMb = totalBytes / (1024.0 * 1024.0)
    val sizeFormatted = if (totalMb > 1024) String.format(Locale.US, "%.2f GB", totalMb / 1024.0) else String.format(Locale.US, "%.1f MB", totalMb)

    val eligibleItems = remember(watchedCleanupItems) { watchedCleanupItems.filter { it.isEligibleNow } }
    val eligibleBytes = remember(eligibleItems) { eligibleItems.sumOf { it.fileSize } }
    val eligibleMb = eligibleBytes / (1024.0 * 1024.0)
    val eligibleFormatted = if (eligibleMb > 1024) String.format(Locale.US, "%.2f GB", eligibleMb / 1024.0) else String.format(Locale.US, "%.1f MB", eligibleMb)

    if (showReviewCleanupDialog) {
        WatchedMediaReviewDialog(
            viewModel = viewModel,
            onDismiss = { showReviewCleanupDialog = false }
        )
    }

    if (showUnwantedFilesDialog) {
        UnwantedFilesCleanerDialog(
            onDismiss = { showUnwantedFilesDialog = false },
            onFilesRemoved = { _, _ ->
                viewModel.refreshWatchedCleanupList()
            }
        )
    }

    if (showConfirmClear) {
        AlertDialog(
            onDismissRequest = { showConfirmClear = false },
            title = { Text("Delete Library & Files?", fontWeight = FontWeight.Bold, color = SleekTextPrimary) },
            text = { Text("This will permanently delete all $downloadCount downloaded videos and media from your device memory. This action cannot be undone.", color = SleekTextSecondary) },
            confirmButton = {
                Button(
                    onClick = {
                        showConfirmClear = false
                        onClearAllDownloads()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CrimsonFailure)
                ) {
                    Text("Delete All", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { showConfirmClear = false }) {
                    Text("Cancel", color = SleekTextSecondary)
                }
            },
            containerColor = SleekCardDark,
            shape = RoundedCornerShape(24.dp)
        )
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Storage Breakdown Card
        SettingsSectionCard(title = "STORAGE OVERVIEW") {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "DOWNLY Storage Usage",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = SleekTextPrimary
                        )
                        Text(
                            text = "$downloadCount downloaded files saved",
                            style = MaterialTheme.typography.bodySmall,
                            color = SleekTextSecondary
                        )
                    }

                    Text(
                        text = sizeFormatted,
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.ExtraBold),
                        color = SleekPurpleLight
                    )
                }

                // Storage progress bar
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(Color.White.copy(alpha = 0.1f))
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(0.45f)
                            .height(8.dp)
                            .background(Brush.horizontalGradient(listOf(SleekPurpleDark, SleekPurpleLight)))
                    )
                }
            }
        }

        // Unwanted Files & Storage Cleaner
        SettingsSectionCard(title = "UNWANTED FILES & STORAGE CLEANER") {
            SettingRow(
                icon = Icons.Default.CleaningServices,
                title = "Scan & Clean Unwanted Files",
                description = "Find and remove temporary files, transcode cache, broken fragments & watched media with checkboxes",
                onClick = { showUnwantedFilesDialog = true },
                showDivider = false
            ) {
                Button(
                    onClick = { showUnwantedFilesDialog = true },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = SleekPurpleLight,
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp)
                ) {
                    Icon(Icons.Default.CleaningServices, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Clean Files", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        // Auto-Clean Watched Downloads (Phase 3B)
        SettingsSectionCard(title = "AUTO-CLEAN WATCHED DOWNLOADS") {
            SettingRow(
                icon = Icons.Default.AutoDelete,
                title = "Auto-clean watched downloads",
                description = "Automatically delete downloads after playback completion",
                onClick = { periodDropdownExpanded = true },
                showDivider = true
            ) {
                Box {
                    Box(
                        modifier = Modifier
                            .background(Color.White.copy(alpha = 0.05f), RoundedCornerShape(10.dp))
                            .border(1.dp, Color.White.copy(alpha = 0.12f), RoundedCornerShape(10.dp))
                            .clickable { periodDropdownExpanded = true }
                            .padding(horizontal = 12.dp, vertical = 6.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                text = autoCleanSettings.period.displayName,
                                color = if (autoCleanSettings.period == AutoCleanPeriod.OFF) SleekTextSecondary else SleekPurpleLight,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                            Icon(
                                imageVector = Icons.Default.ArrowDropDown,
                                contentDescription = null,
                                tint = SleekPurpleLight,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                    DropdownMenu(
                        expanded = periodDropdownExpanded,
                        onDismissRequest = { periodDropdownExpanded = false },
                        modifier = Modifier.background(SleekCardDark)
                    ) {
                        AutoCleanPeriod.entries.forEach { opt ->
                            DropdownMenuItem(
                                text = {
                                    Text(
                                        text = opt.displayName,
                                        color = if (autoCleanSettings.period == opt) SleekPurpleLight else Color.White,
                                        fontWeight = if (autoCleanSettings.period == opt) FontWeight.Bold else FontWeight.Normal
                                    )
                                },
                                onClick = {
                                    periodDropdownExpanded = false
                                    viewModel.updateAutoCleanPeriod(opt)
                                }
                            )
                        }
                    }
                }
            }

            SettingRow(
                icon = Icons.Default.Favorite,
                title = "Keep favorites",
                description = "Never auto-delete media in your Favorites collection",
                showDivider = true
            ) {
                SmoothToggle(
                    checked = autoCleanSettings.keepFavorites,
                    onCheckedChange = { viewModel.updateKeepFavorites(it) }
                )
            }

            SettingRow(
                icon = Icons.Default.PlaylistPlay,
                title = "Keep playlist items",
                description = "Never auto-delete media saved to any playlist",
                showDivider = true
            ) {
                SmoothToggle(
                    checked = autoCleanSettings.keepPlaylistItems,
                    onCheckedChange = { viewModel.updateKeepPlaylistItems(it) }
                )
            }

            SettingRow(
                icon = Icons.Default.Bookmark,
                title = "Keep items marked \"Keep\"",
                description = "Protect downloaded media explicitly marked Keep",
                showDivider = true
            ) {
                SmoothToggle(
                    checked = autoCleanSettings.keepMarkedItems,
                    onCheckedChange = { viewModel.updateKeepMarkedItems(it) }
                )
            }

            SettingRow(
                icon = Icons.Default.Storage,
                title = "Only clean when storage is low",
                description = "Only delete watched files when free storage falls below 15%",
                showDivider = true
            ) {
                SmoothToggle(
                    checked = autoCleanSettings.onlyCleanWhenStorageLow,
                    onCheckedChange = { viewModel.updateOnlyCleanWhenStorageLow(it) }
                )
            }

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (autoCleanSettings.period == AutoCleanPeriod.OFF) "Auto-clean: OFF" else "Auto-clean: ${autoCleanSettings.period.displayName}",
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                            color = if (autoCleanSettings.period == AutoCleanPeriod.OFF) SleekTextSecondary else EmeraldSuccess
                        )
                        Text(
                            text = "${eligibleItems.size} watched files · $eligibleFormatted eligible",
                            style = MaterialTheme.typography.bodySmall,
                            color = SleekTextSecondary
                        )
                    }

                    Button(
                        onClick = {
                            viewModel.refreshWatchedCleanupList()
                            showReviewCleanupDialog = true
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = SleekPurpleLight.copy(alpha = 0.2f),
                            contentColor = SleekPurpleLight
                        ),
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp)
                    ) {
                        Icon(Icons.Default.ManageSearch, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Review", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Danger Zone: Delete All Media
        SettingsSectionCard(title = "DANGER ZONE") {
            SettingRow(
                icon = Icons.Default.DeleteSweep,
                title = "Clear All Downloaded Media",
                description = "Permanently remove all $downloadCount downloaded videos and audio",
                onClick = { showConfirmClear = true },
                showDivider = false
            ) {
                Button(
                    onClick = { showConfirmClear = true },
                    colors = ButtonDefaults.buttonColors(containerColor = CrimsonFailure.copy(alpha = 0.2f), contentColor = CrimsonFailure),
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text("Clear All", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

/**
 * 8. ABOUT SETTINGS PAGE
 * Version info, Developer credits, Legal & Policies, Open Source
 */
@Composable
fun AboutSettingsPage(
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var showTermsDialog by remember { mutableStateOf(false) }
    var showPrivacyDialog by remember { mutableStateOf(false) }

    if (showTermsDialog) {
        TermsAndConditionsDialog(onDismiss = { showTermsDialog = false })
    }

    if (showPrivacyDialog) {
        PrivacyPolicyDialog(onDismiss = { showPrivacyDialog = false })
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // App Version Card
        SettingsSectionCard(title = "APP INFORMATION") {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(
                            text = "DOWNLY",
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.ExtraBold),
                            color = SleekPurpleLight
                        )
                        Text(
                            text = "Version ${com.example.BuildConfig.VERSION_NAME} (Build ${com.example.BuildConfig.VERSION_CODE}) STABLE",
                            style = MaterialTheme.typography.bodySmall,
                            color = SleekTextSecondary
                        )
                    }

                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = EmeraldSuccess.copy(alpha = 0.15f),
                        border = BorderStroke(1.dp, EmeraldSuccess.copy(alpha = 0.3f))
                    ) {
                        Text(
                            text = "OFFICIAL RELEASE",
                            color = EmeraldSuccess,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }
            }
        }

        // Developer & Credits
        SettingsSectionCard(title = "DEVELOPER & CREDITS") {
            Surface(
                onClick = {
                    openInstagramProfile(context, "_junior_sir_")
                },
                shape = RoundedCornerShape(16.dp),
                color = SleekCardDark,
                border = BorderStroke(1.dp, Color(0xFFE1306C).copy(alpha = 0.35f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(14.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .background(
                                    Brush.linearGradient(
                                        listOf(
                                            Color(0xFF833AB4).copy(alpha = 0.25f),
                                            Color(0xFFFD1D1D).copy(alpha = 0.25f),
                                            Color(0xFFFCB045).copy(alpha = 0.25f)
                                        )
                                    ),
                                    CircleShape
                                )
                                .border(1.dp, Color(0xFFFD1D1D).copy(alpha = 0.5f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            InstagramIcon(modifier = Modifier.size(24.dp), useGradient = true)
                        }
                        Column {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text(
                                    text = "Lead Developer",
                                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold, color = SleekPurpleDark)
                                )
                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = Color(0xFFFD1D1D).copy(alpha = 0.2f),
                                    border = BorderStroke(0.5.dp, Color(0xFFFD1D1D).copy(alpha = 0.4f))
                                ) {
                                    Text(
                                        "INSTAGRAM",
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = Color(0xFFFCB045),
                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                    )
                                }
                            }
                            Text(
                                text = "JuniorSir",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = SleekTextPrimary)
                            )
                            Text(
                                text = "Tap to open Instagram profile",
                                style = MaterialTheme.typography.bodySmall,
                                color = SleekTextSecondary
                            )
                        }
                    }

                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .background(Color(0xFFFD1D1D).copy(alpha = 0.15f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.ArrowForward,
                            contentDescription = "Open Instagram Profile",
                            tint = Color(0xFFFCAF45),
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }

        // Legal & Policies
        SettingsSectionCard(title = "LEGAL & POLICIES") {
            SettingRow(
                icon = Icons.Default.Security,
                title = "Terms & Conditions",
                description = "Terms of service, fair use policy, and copyright compliance",
                onClick = { showTermsDialog = true },
                showDivider = true
            ) {
                Icon(
                    imageVector = Icons.Default.ArrowForward,
                    contentDescription = "Open Terms",
                    tint = SleekPurpleLight,
                    modifier = Modifier.size(18.dp)
                )
            }

            SettingRow(
                icon = Icons.Default.Lock,
                title = "Privacy Policy",
                description = "Zero telemetry tracking, 100% on-device local storage and offline privacy",
                onClick = { showPrivacyDialog = true },
                showDivider = false
            ) {
                Icon(
                    imageVector = Icons.Default.ArrowForward,
                    contentDescription = "Open Privacy Policy",
                    tint = SleekPurpleLight,
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}
