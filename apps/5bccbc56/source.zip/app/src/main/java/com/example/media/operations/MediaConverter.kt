package com.example.media.operations

import android.content.Context
import android.util.Log
import com.example.media.ffmpeg.FFmpegEngine
import com.example.media.ffmpeg.FFmpegProgress
import com.example.media.ffmpeg.FFmpegState
import com.example.media.probe.MediaProbeEngine
import com.example.media.storage.MediaUriResolver
import com.example.media.storage.TemporaryMediaManager
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow

object MediaConverter {
    private const val TAG = "MediaConverter"

    fun convertMedia(
        context: Context,
        request: MediaConversionRequest
    ): Flow<FFmpegProgress> = callbackFlow {
        val validation = request.validate()
        if (validation.isFailure) {
            val err = validation.exceptionOrNull() ?: IllegalArgumentException("Invalid conversion request")
            trySend(FFmpegProgress(state = FFmpegState.FAILED, error = err))
            close(err)
            return@callbackFlow
        }

        var resolvedSource: com.example.media.storage.ResolvedMediaSource? = null
        var activeSessionId: Long = 0L

        try {
            val probeResult = MediaProbeEngine.probeMedia(context, request.inputUri)
            val probeInfo = probeResult.getOrNull()
            val totalDurationMs = probeInfo?.durationMs ?: 0L

            resolvedSource = MediaUriResolver.resolveUriForFFmpeg(context, request.inputUri, preferDirectSaf = true)
            val inputPath = resolvedSource.pathOrSaf

            val inputThreads = minOf(Runtime.getRuntime().availableProcessors(), 4).coerceAtLeast(2)
            val argsList = mutableListOf("-threads", inputThreads.toString(), "-i", inputPath)

            // Video encoding options
            if (request.videoCodec == "copy") {
                argsList.addAll(listOf("-c:v", "copy"))
            } else if (request.videoCodec != null) {
                argsList.addAll(listOf("-c:v", request.videoCodec))
                val isX264 = request.videoCodec.contains("libx264")
                val isOpenH264 = request.videoCodec.contains("libopenh264")
                if (isX264) {
                    if (request.crf != null) {
                        argsList.addAll(listOf("-crf", request.crf.toString()))
                    }
                    val preset = request.preset ?: "ultrafast"
                    argsList.addAll(listOf("-preset", preset, "-tune", "zerolatency"))
                }
                if (request.videoBitrateKbps != null) {
                    argsList.addAll(listOf("-b:v", "${request.videoBitrateKbps}k"))
                } else if (!isX264) {
                    argsList.addAll(listOf("-b:v", "3500k"))
                }
                if (request.frameRate != null && request.frameRate > 0) {
                    argsList.addAll(listOf("-r", request.frameRate.toString()))
                }
                if (request.targetWidth != null && request.targetHeight != null) {
                    argsList.addAll(listOf("-vf", "scale=${request.targetWidth}:${request.targetHeight}:force_original_aspect_ratio=decrease,pad=${request.targetWidth}:${request.targetHeight}:(ow-iw)/2:(oh-ih)/2"))
                } else if (request.targetWidth != null) {
                    argsList.addAll(listOf("-vf", "scale=${request.targetWidth}:-2"))
                } else if (request.targetHeight != null) {
                    argsList.addAll(listOf("-vf", "scale=-2:${request.targetHeight}"))
                }
                argsList.addAll(listOf("-pix_fmt", "yuv420p"))
            } else {
                argsList.add("-vn")
            }

            // Audio encoding options
            if (request.audioCodec == "copy") {
                argsList.addAll(listOf("-c:a", "copy"))
            } else if (request.audioCodec != null) {
                argsList.addAll(listOf("-c:a", request.audioCodec))
                if (request.audioBitrateKbps != null) {
                    argsList.addAll(listOf("-b:a", "${request.audioBitrateKbps}k"))
                }
            } else {
                argsList.add("-an")
            }

            if (request.fastStart && request.outputFile.name.endsWith(".mp4", ignoreCase = true)) {
                argsList.addAll(listOf("-movflags", "+faststart"))
            }
            if (request.outputFile.name.endsWith(".mp4", ignoreCase = true)) {
                argsList.addAll(listOf("-f", "mp4"))
            }

            argsList.addAll(listOf("-y", request.outputFile.absolutePath))

            val cmdStr = argsList.joinToString(" ")
            Log.i(TAG, "Starting media conversion: $cmdStr")
            com.example.media.playback.TranscodingLogManager.recordCommand(cmdStr)
            com.example.media.playback.TranscodingLogManager.updateTranscodingState(com.example.media.playback.TranscodingLifecycleState.RUNNING)

            activeSessionId = FFmpegEngine.executeAsyncWithArguments(
                arguments = argsList.toTypedArray(),
                totalDurationMs = totalDurationMs,
                operationType = com.example.media.ffmpeg.FFmpegOperationType.ACTUAL_TRANSCODING,
                onProgress = { progress ->
                    com.example.media.playback.TranscodingLogManager.recordProgress(progress)
                    trySend(progress)
                },
                onComplete = { result ->
                    if (!result.isSuccess) {
                        com.example.media.playback.TranscodingLogManager.updateTranscodingState(com.example.media.playback.TranscodingLifecycleState.FAILED)
                        trySend(
                            FFmpegProgress(
                                sessionId = result.sessionId,
                                state = FFmpegState.FAILED,
                                error = IllegalStateException(result.failStackTrace ?: result.output),
                                logOutput = result.output
                            )
                        )
                    } else {
                        com.example.media.playback.TranscodingLogManager.updateTranscodingState(com.example.media.playback.TranscodingLifecycleState.COMPLETED)
                    }
                    close()
                }
            )

        } catch (e: Exception) {
            Log.e(TAG, "Conversion error: ${e.message}", e)
            trySend(
                FFmpegProgress(
                    state = FFmpegState.FAILED,
                    error = e
                )
            )
            close(e)
        }

        awaitClose {
            if (activeSessionId > 0L) {
                FFmpegEngine.cancel(activeSessionId)
            }
            if (resolvedSource?.isTemporaryFile == true) {
                TemporaryMediaManager.deleteSilently(resolvedSource?.temporaryFile)
            }
        }
    }
}
