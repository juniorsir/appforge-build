package com.example.media.playback

enum class PlaybackStrategy(val isDirect: Boolean = false) {
    DIRECT_HARDWARE(isDirect = true),
    DIRECT_SAFE(isDirect = true),
    DIRECT_ATTEMPT(isDirect = true),
    REMUX_REQUIRED(isDirect = false),
    TARGETED_AUDIO_TRANSCODE(isDirect = false),
    TARGETED_VIDEO_TRANSCODE(isDirect = false),
    TRANSCODE_REQUIRED(isDirect = false),
    FULL_TRANSCODE_REQUIRED(isDirect = false),
    UNSUPPORTED(isDirect = false)
}

data class PlaybackCompatibilityResult(
    val strategy: PlaybackStrategy,
    val reason: String,
    val containerFormat: String,
    val videoCodec: String,
    val audioCodec: String,
    val requiresRemux: Boolean = false,
    val requiresTranscode: Boolean = false,
    val isVideoSupported: Boolean = true,
    val isAudioSupported: Boolean = true,
    val isContainerSupported: Boolean = true,
    val videoAction: String = "direct", // "direct", "copy", "transcode", "none"
    val audioAction: String = "direct", // "direct", "copy", "transcode", "none"
    val qualityImpact: String = "None (Direct Hardware Playback)",
    val estimatedSpeed: String = "Instant"
)
