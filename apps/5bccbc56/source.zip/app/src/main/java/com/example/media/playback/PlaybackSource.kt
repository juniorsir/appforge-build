package com.example.media.playback

import android.net.Uri
import android.util.Log
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import java.io.File

enum class PlaybackSourceType {
    ORIGINAL,
    FALLBACK,
    PROGRESSIVE_FALLBACK
}

data class PlaybackSource(
    val sourceType: PlaybackSourceType,
    val uri: Uri,
    val originalUri: Uri? = null,
    val path: String? = null,
    val mimeType: String? = null,
    val requestId: String,
    val container: String? = null,
    val codec: String? = null
) {
    companion object {
        fun parseMediaUri(raw: String): Uri {
            return when {
                raw.startsWith("content://") || raw.startsWith("file://") || raw.startsWith("http://") || raw.startsWith("https://") -> {
                    Uri.parse(raw)
                }
                raw.startsWith("/") -> {
                    val f = File(raw)
                    if (f.exists()) Uri.fromFile(f) else Uri.parse(raw)
                }
                else -> Uri.parse(raw)
            }
        }
    }
}

object Media3SourceBuilder {
    private const val TAG = "Media3SourceBuilder"

    fun determineMimeType(source: PlaybackSource): String? {
        if (source.sourceType == PlaybackSourceType.PROGRESSIVE_FALLBACK) {
            return MimeTypes.APPLICATION_M3U8
        }

        // Fallback is strictly validated MP4 container
        if (source.sourceType == PlaybackSourceType.FALLBACK) {
            return MimeTypes.VIDEO_MP4
        }

        // If explicit authoritative MIME is provided
        if (!source.mimeType.isNullOrBlank()) {
            return source.mimeType
        }

        // Check container format for original sources
        val container = source.container?.lowercase() ?: ""
        return when {
            container.contains("matroska") -> MimeTypes.VIDEO_MATROSKA
            container.contains("webm") -> MimeTypes.VIDEO_WEBM
            container.contains("mp4") || container.contains("mov") || container.contains("m4a") || container.contains("3gp") -> MimeTypes.VIDEO_MP4
            container.contains("mpegts") || container.contains("ts") -> MimeTypes.VIDEO_MP2T
            container.contains("mp3") -> MimeTypes.AUDIO_MPEG
            container.contains("aac") -> MimeTypes.AUDIO_AAC
            container.contains("flac") -> MimeTypes.AUDIO_FLAC
            container.contains("ogg") -> MimeTypes.AUDIO_OGG
            container.contains("wav") -> MimeTypes.AUDIO_WAV
            else -> null // Preserve Media3 DefaultMediaSourceFactory inference
        }
    }

    fun buildMediaItem(
        source: PlaybackSource,
        subtitleUriString: String? = null
    ): MediaItem {
        val assignedMime = determineMimeType(source)

        Log.i(
            "MEDIA3_MIME_TRACE",
            "[MEDIA3_MIME_TRACE] requestId=${source.requestId} sourceType=${source.sourceType} container=${source.container ?: "unknown"} codec=${source.codec ?: "unknown"} authoritativeMime=${source.mimeType ?: "unknown"} assignedMime=${assignedMime ?: "inferred"}"
        )

        val mediaItemBuilder = MediaItem.Builder().setUri(source.uri)
        if (assignedMime != null) {
            mediaItemBuilder.setMimeType(assignedMime)
        }

        if (!subtitleUriString.isNullOrBlank()) {
            val subUri = PlaybackSource.parseMediaUri(subtitleUriString)
            val subExt = subtitleUriString.substringAfterLast('.').lowercase()
            val subMimeType = when (subExt) {
                "srt" -> MimeTypes.APPLICATION_SUBRIP
                "vtt" -> MimeTypes.TEXT_VTT
                "ass", "ssa" -> MimeTypes.TEXT_SSA
                "ttml" -> MimeTypes.APPLICATION_TTML
                else -> MimeTypes.APPLICATION_SUBRIP
            }
            val subtitleConfig = MediaItem.SubtitleConfiguration.Builder(subUri)
                .setMimeType(subMimeType)
                .setLanguage("en")
                .setSelectionFlags(C.SELECTION_FLAG_DEFAULT)
                .build()
            mediaItemBuilder.setSubtitleConfigurations(listOf(subtitleConfig))
        }

        val mediaItem = mediaItemBuilder.build()
        val mediaItemUri = mediaItem.localConfiguration?.uri

        Log.i(
            "MEDIA3_SOURCE_CONSTRUCTION",
            "[MEDIA3_SOURCE_CONSTRUCTION] requestId=${source.requestId} sourceType=${source.sourceType} authoritativeUri=${source.uri} mediaItemUri=$mediaItemUri mimeType=${mediaItem.localConfiguration?.mimeType ?: "inferred"}"
        )

        if (source.sourceType == PlaybackSourceType.PROGRESSIVE_FALLBACK) {
            Log.i(
                "PROGRESSIVE_MEDIAITEM_CREATED",
                "[PROGRESSIVE_MEDIAITEM_CREATED] requestId=${source.requestId} uri=${source.uri} mimeType=${assignedMime ?: MimeTypes.APPLICATION_M3U8}"
            )
            require(mediaItemUri == source.uri) {
                "Invariant violation: progressive MediaItem URI ($mediaItemUri) != authoritative progressive URI (${source.uri})"
            }
        } else if (source.sourceType == PlaybackSourceType.FALLBACK) {
            Log.i(
                "MEDIA3_FALLBACK_SOURCE",
                "[MEDIA3_FALLBACK_SOURCE] requestId=${source.requestId} originalUri=${source.originalUri ?: "unknown"} fallbackUri=${source.uri} selectedUri=$mediaItemUri"
            )
            require(mediaItemUri == source.uri) {
                "Invariant 2 violation: fallback MediaItem URI ($mediaItemUri) != authoritative fallback URI (${source.uri})"
            }
        } else {
            require(mediaItemUri == source.uri) {
                "Invariant 1 violation: direct MediaItem URI ($mediaItemUri) != authoritative original URI (${source.uri})"
            }
        }

        return mediaItem
    }
}
