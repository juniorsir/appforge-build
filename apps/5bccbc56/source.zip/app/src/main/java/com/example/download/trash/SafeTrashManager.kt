package com.example.download.trash

import android.content.Context
import android.media.MediaScannerConnection
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import com.example.data.AppDatabase
import com.example.data.DownloadEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.zip.Deflater
import java.util.zip.DeflaterOutputStream
import java.util.zip.Inflater
import java.util.zip.InflaterInputStream

/**
 * Manages ultra-safe 30-day file trash storage with extreme compression.
 * When files are moved to Safe Trash, they are compressed using maximum zlib deflater
 * compression and stored in a secure trash repository for 30 days before automatic purge.
 * Users can recover and decompress files back to their exact original state anytime within 30 days.
 */
object SafeTrashManager {

    private const val TAG = "SafeTrashManager"
    const val RETENTION_PERIOD_DAYS = 30L
    const val RETENTION_PERIOD_MS = RETENTION_PERIOD_DAYS * 24L * 60L * 60L * 1000L
    private const val BUFFER_SIZE = 128 * 1024 // 128 KB stream buffer

    /**
     * Locate or create the dedicated Safe Trash storage directory.
     * Prefers external app-specific storage to avoid consuming internal memory.
     */
    fun getTrashDir(context: Context): File {
        val externalDir = context.getExternalFilesDir(null)
        val trashDir = if (externalDir != null && (Environment.getExternalStorageState() == Environment.MEDIA_MOUNTED)) {
            File(externalDir, "safe_trash")
        } else {
            File(context.filesDir, "safe_trash")
        }
        if (!trashDir.exists()) {
            trashDir.mkdirs()
        }
        return trashDir
    }

    /**
     * Extremely compresses an active media download into the Safe Trash vault.
     * Once compressed and verified, the original uncompressed file is safely removed.
     */
    suspend fun compressToTrash(
        context: Context,
        entity: DownloadEntity,
        onProgress: (Float) -> Unit = {}
    ): Result<File> = withContext(Dispatchers.IO) {
        try {
            val sourceFile = File(entity.localPath)
            val trashDir = getTrashDir(context)
            val targetCompressedFile = File(trashDir, "${entity.id}.zcmp")
            val tempCompressedFile = File(trashDir, "${entity.id}.zcmp.tmp")

            if (tempCompressedFile.exists()) tempCompressedFile.delete()

            val originalSize = if (sourceFile.exists()) sourceFile.length() else entity.fileSize

            if (sourceFile.exists() && sourceFile.length() > 0) {
                val totalBytes = sourceFile.length()
                var bytesReadTotal = 0L
                val buffer = ByteArray(BUFFER_SIZE)

                // Extreme zlib compression using BEST_COMPRESSION
                val deflater = Deflater(Deflater.BEST_COMPRESSION, false)

                FileInputStream(sourceFile).use { fis ->
                    BufferedOutputStream(FileOutputStream(tempCompressedFile), BUFFER_SIZE).use { fos ->
                        DeflaterOutputStream(fos, deflater, BUFFER_SIZE).use { dos ->
                            var bytesRead: Int
                            while (fis.read(buffer).also { bytesRead = it } != -1) {
                                dos.write(buffer, 0, bytesRead)
                                bytesReadTotal += bytesRead
                                if (totalBytes > 0) {
                                    val progress = (bytesReadTotal.toFloat() / totalBytes.toFloat()).coerceIn(0f, 1f)
                                    onProgress(progress)
                                }
                            }
                            dos.finish()
                        }
                    }
                }
                deflater.end()

                if (!tempCompressedFile.exists() || tempCompressedFile.length() == 0L) {
                    tempCompressedFile.delete()
                    return@withContext Result.failure(IllegalStateException("Compression produced empty output"))
                }

                if (targetCompressedFile.exists()) targetCompressedFile.delete()
                val renamed = tempCompressedFile.renameTo(targetCompressedFile)
                if (!renamed) {
                    tempCompressedFile.copyTo(targetCompressedFile, overwrite = true)
                    tempCompressedFile.delete()
                }

                // Safely remove the original uncompressed file from active media folder
                try {
                    if (sourceFile.exists()) {
                        sourceFile.delete()
                    }
                    val partFile = File("${sourceFile.absolutePath}.part")
                    if (partFile.exists()) {
                        partFile.delete()
                    }
                } catch (e: Exception) {
                    Log.w(TAG, "Failed to delete original source after compression: ${e.message}")
                }

                // Purge from MediaStore so external galleries don't show phantom entries
                try {
                    val cr = context.contentResolver
                    cr.delete(
                        MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                        "${MediaStore.Video.Media.DATA} = ?",
                        arrayOf(entity.localPath)
                    )
                    cr.delete(
                        MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                        "${MediaStore.Audio.Media.DATA} = ?",
                        arrayOf(entity.localPath)
                    )
                } catch (e: Exception) {
                    Log.w(TAG, "MediaStore cleanup warning: ${e.message}")
                }

                Log.d(TAG, "Compressed ${entity.title}: Original $originalSize B -> Compressed ${targetCompressedFile.length()} B")
                Result.success(targetCompressedFile)
            } else {
                // If source file was already removed or missing, create an empty placeholder archive
                targetCompressedFile.writeText("MISSING_PAYLOAD")
                Result.success(targetCompressedFile)
            }
        } catch (e: Throwable) {
            Log.e(TAG, "Safe trash compression failed for ${entity.title}", e)
            Result.failure(e)
        }
    }

    /**
     * Decompresses and restores a previously trashed file back to its active storage path.
     * Byte-for-byte exact fidelity is restored.
     */
    suspend fun decompressFromTrash(
        context: Context,
        entity: DownloadEntity,
        onProgress: (Float) -> Unit = {}
    ): Result<File> = withContext(Dispatchers.IO) {
        try {
            val trashDir = getTrashDir(context)
            val compressedFile = if (entity.trashCompressedPath.isNotBlank() && File(entity.trashCompressedPath).exists()) {
                File(entity.trashCompressedPath)
            } else {
                File(trashDir, "${entity.id}.zcmp")
            }

            if (!compressedFile.exists()) {
                return@withContext Result.failure(java.io.FileNotFoundException("Compressed trash file not found: ${compressedFile.absolutePath}"))
            }

            // Determine target restored destination path
            val targetRestoreFile: File = if (entity.originalLocalPath.isNotBlank()) {
                val candidate = File(entity.originalLocalPath)
                if (candidate.parentFile?.exists() == true || candidate.parentFile?.mkdirs() == true) {
                    candidate
                } else {
                    val fallbackDir = context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: context.filesDir
                    File(fallbackDir, candidate.name)
                }
            } else if (entity.localPath.isNotBlank()) {
                val candidate = File(entity.localPath)
                if (candidate.parentFile?.exists() == true || candidate.parentFile?.mkdirs() == true) {
                    candidate
                } else {
                    val fallbackDir = context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: context.filesDir
                    File(fallbackDir, candidate.name)
                }
            } else {
                val ext = if (entity.formatExt.isNotBlank()) entity.formatExt else if (entity.isAudioOnly) "mp3" else "mp4"
                val sanitizedTitle = entity.title.replace(Regex("[^a-zA-Z0-9._-]"), "_").take(40)
                val fallbackDir = context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: context.filesDir
                File(fallbackDir, "${sanitizedTitle}_${entity.id}.$ext")
            }

            targetRestoreFile.parentFile?.mkdirs()
            val tempRestoreFile = File(targetRestoreFile.parentFile, "${targetRestoreFile.name}.restore_tmp")
            if (tempRestoreFile.exists()) tempRestoreFile.delete()

            val compressedLength = compressedFile.length()
            val buffer = ByteArray(BUFFER_SIZE)
            val inflater = Inflater(false)

            BufferedInputStream(FileInputStream(compressedFile), BUFFER_SIZE).use { bis ->
                InflaterInputStream(bis, inflater, BUFFER_SIZE).use { iis ->
                    BufferedOutputStream(FileOutputStream(tempRestoreFile), BUFFER_SIZE).use { fos ->
                        var bytesRead: Int
                        while (iis.read(buffer).also { bytesRead = it } != -1) {
                            fos.write(buffer, 0, bytesRead)
                        }
                    }
                }
            }
            inflater.end()

            if (!tempRestoreFile.exists() || tempRestoreFile.length() == 0L) {
                tempRestoreFile.delete()
                return@withContext Result.failure(IllegalStateException("Restoration produced an empty file"))
            }

            if (targetRestoreFile.exists()) targetRestoreFile.delete()
            val renamed = tempRestoreFile.renameTo(targetRestoreFile)
            if (!renamed) {
                tempRestoreFile.copyTo(targetRestoreFile, overwrite = true)
                tempRestoreFile.delete()
            }

            // Remove the compressed trash file now that the file is safely decompressed
            if (compressedFile.exists()) {
                compressedFile.delete()
            }

            // Index with Android MediaScanner so media gallery apps detect it immediately
            try {
                MediaScannerConnection.scanFile(
                    context,
                    arrayOf(targetRestoreFile.absolutePath),
                    null,
                    null
                )
            } catch (e: Exception) {
                Log.w(TAG, "MediaScanner error after restoration: ${e.message}")
            }

            Log.d(TAG, "Successfully restored ${entity.title} to ${targetRestoreFile.absolutePath}")
            Result.success(targetRestoreFile)
        } catch (e: Throwable) {
            Log.e(TAG, "Safe trash recovery failed for ${entity.title}", e)
            Result.failure(e)
        }
    }

    /**
     * Permanently purges a trashed item from disk.
     */
    suspend fun deleteCompressedTrashFile(context: Context, entity: DownloadEntity) = withContext(Dispatchers.IO) {
        try {
            val trashDir = getTrashDir(context)
            if (entity.trashCompressedPath.isNotBlank()) {
                val f = File(entity.trashCompressedPath)
                if (f.exists()) f.delete()
            }
            val fallback = File(trashDir, "${entity.id}.zcmp")
            if (fallback.exists()) fallback.delete()
            val tmp = File(trashDir, "${entity.id}.zcmp.tmp")
            if (tmp.exists()) tmp.delete()
        } catch (e: Exception) {
            Log.w(TAG, "Error deleting compressed trash file: ${e.message}")
        }
    }

    /**
     * Auto-purges items whose retention period (> 30 days) has expired.
     */
    suspend fun purgeExpiredTrash(context: Context, database: AppDatabase): Int = withContext(Dispatchers.IO) {
        var purgedCount = 0
        try {
            val trashedItems = database.downloadDao().getTrashedDownloadsSync()
            val now = System.currentTimeMillis()
            for (item in trashedItems) {
                val age = now - item.trashedAt
                if (item.trashedAt > 0L && age >= RETENTION_PERIOD_MS) {
                    deleteCompressedTrashFile(context, item)
                    database.downloadDao().deleteDownloadById(item.id)
                    purgedCount++
                    Log.d(TAG, "Auto-purged expired trashed download: ${item.title} (Age: ${age / (24 * 60 * 60 * 1000)} days)")
                }
            }
        } catch (e: Throwable) {
            Log.e(TAG, "Failed during expired trash purge: ${e.message}")
        }
        purgedCount
    }

    /**
     * Permanently clears all items currently in Safe Trash.
     */
    suspend fun emptyAllTrash(context: Context, database: AppDatabase) = withContext(Dispatchers.IO) {
        try {
            val trashedItems = database.downloadDao().getTrashedDownloadsSync()
            for (item in trashedItems) {
                deleteCompressedTrashFile(context, item)
            }
            database.downloadDao().emptyTrash()
            // Also clean up any orphan .zcmp files in trash directory
            val trashDir = getTrashDir(context)
            trashDir.listFiles()?.forEach { file ->
                try { file.delete() } catch (_: Throwable) {}
            }
        } catch (e: Throwable) {
            Log.e(TAG, "Failed to empty all trash: ${e.message}")
        }
    }

    /**
     * Calculates days remaining until the 30-day retention window expires.
     */
    fun calculateDaysRemaining(trashedAt: Long): Int {
        if (trashedAt <= 0L) return RETENTION_PERIOD_DAYS.toInt()
        val elapsed = System.currentTimeMillis() - trashedAt
        val remainingMs = RETENTION_PERIOD_MS - elapsed
        if (remainingMs <= 0L) return 0
        val days = (remainingMs / (24L * 60L * 60L * 1000L)).toInt()
        return days.coerceIn(0, RETENTION_PERIOD_DAYS.toInt())
    }

    /**
     * Calculates percentage of storage saved through extreme compression.
     */
    fun calculateSavingsPercentage(originalSize: Long, compressedSize: Long): Int {
        if (originalSize <= 0L || compressedSize <= 0L || compressedSize >= originalSize) return 0
        val saved = originalSize - compressedSize
        return ((saved.toDouble() / originalSize.toDouble()) * 100.0).toInt().coerceIn(0, 99)
    }

    /**
     * Formats bytes into human-readable representation (e.g. "14.2 MB").
     */
    fun formatFileSize(bytes: Long): String {
        if (bytes <= 0L) return "0 B"
        val units = arrayOf("B", "KB", "MB", "GB", "TB")
        val digitGroups = (Math.log10(bytes.toDouble()) / Math.log10(1024.0)).toInt().coerceIn(0, units.size - 1)
        return String.format(java.util.Locale.US, "%.1f %s", bytes / Math.pow(1024.0, digitGroups.toDouble()), units[digitGroups])
    }
}
