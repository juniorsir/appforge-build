package com.example.media.player

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector

class UltraPlayerSystem(val context: Context) {
    var player by mutableStateOf<ExoPlayer?>(null)
        private set
    var trackSelector by mutableStateOf<DefaultTrackSelector?>(null)
        private set

    var isABLoopEnabled by mutableStateOf(false)
    var loopPointA by mutableStateOf<Long?>(null)
    var loopPointB by mutableStateOf<Long?>(null)
    var playbackSpeed by mutableFloatStateOf(1.0f)
    var audioPitch by mutableFloatStateOf(1.0f)
    var zoomScale by mutableFloatStateOf(1.0f)
    var fitMode by mutableStateOf("Fit Screen")

    fun attachPlayer(exoPlayer: ExoPlayer, selector: DefaultTrackSelector? = null) {
        this.player = exoPlayer
        this.trackSelector = selector
    }

    fun detachPlayer() {
        this.player = null
        this.trackSelector = null
    }

    fun onPlaybackTick(currentMs: Long) {
        val p = player ?: return
        if (isABLoopEnabled) {
            val a = loopPointA
            val b = loopPointB
            if (a != null && b != null && b > a) {
                if (currentMs >= b) {
                    p.seekTo(a)
                }
            }
        }
    }

    fun setPointA(pos: Long) {
        loopPointA = pos
        if (loopPointB != null && loopPointB!! <= pos) {
            loopPointB = null
        }
    }

    fun setPointB(pos: Long) {
        if (loopPointA != null && pos > loopPointA!!) {
            loopPointB = pos
            isABLoopEnabled = true
        }
    }

    fun clearABLoop() {
        isABLoopEnabled = false
        loopPointA = null
        loopPointB = null
    }

    fun updateSpeed(speed: Float) {
        playbackSpeed = speed
        val p = player ?: return
        p.setPlaybackSpeed(speed)
    }

    fun formatMs(ms: Long): String {
        val totalSec = ms / 1000
        val min = totalSec / 60
        val sec = totalSec % 60
        return String.format("%02d:%02d", min, sec)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MxUltraPlayerControlsSheet(
    system: UltraPlayerSystem,
    currentPosMs: Long,
    onSeekTo: (Long) -> Unit,
    onDismiss: () -> Unit
) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF181824),
        contentColor = Color.White
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "Ultra Player Pro Controls",
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                )
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.LightGray)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // A-B Repeat Loop Controls
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF232336)),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Repeat, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            "A-B Repeat Looper",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.SemiBold,
                                color = Color.White
                            )
                        )
                        Spacer(modifier = Modifier.weight(1f))
                        if (system.isABLoopEnabled) {
                            Text(
                                "ACTIVE",
                                color = Color(0xFF4CAF50),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { system.setPointA(currentPosMs) },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (system.loopPointA != null) MaterialTheme.colorScheme.primary else Color(0xFF3B3B52)
                            )
                        ) {
                            Text("Set A: ${system.loopPointA?.let { system.formatMs(it) } ?: "--:--"}")
                        }

                        Button(
                            onClick = { system.setPointB(currentPosMs) },
                            modifier = Modifier.weight(1f),
                            enabled = system.loopPointA != null && currentPosMs > system.loopPointA!!,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (system.loopPointB != null) MaterialTheme.colorScheme.secondary else Color(0xFF3B3B52)
                            )
                        ) {
                            Text("Set B: ${system.loopPointB?.let { system.formatMs(it) } ?: "--:--"}")
                        }

                        IconButton(
                            onClick = { system.clearABLoop() },
                            modifier = Modifier.background(Color(0xFF3B3B52), RoundedCornerShape(8.dp))
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = "Clear A-B Loop", tint = Color.White)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Quick Speed Selector
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF232336)),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Speed, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            "Playback Speed (${String.format("%.2fx", system.playbackSpeed)})",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.SemiBold,
                                color = Color.White
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf(0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 2.0f).forEach { speed ->
                            val isSelected = Math.abs(system.playbackSpeed - speed) < 0.01f
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (isSelected) MaterialTheme.colorScheme.primary else Color(0xFF32324A),
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable { system.updateSpeed(speed) }
                            ) {
                                Box(modifier = Modifier.padding(vertical = 8.dp), contentAlignment = Alignment.Center) {
                                    Text(
                                        "${speed}x",
                                        fontSize = 12.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                        color = if (isSelected) Color.White else Color.LightGray
                                    )
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
