package com.example.media.progressive

import java.util.UUID

/**
 * Phase 17.37: Authoritative Smart Buffer State Machine.
 */
enum class SmartBufferState {
    UNKNOWN,
    STARTING,
    HEALTHY,
    LOW_BUFFER,
    STALL_RISK,
    WAITING_FOR_TRANSCODE,
    COMPLETED,
    FAILED
}

/**
 * Phase 17.37: Seek request lifecycle status.
 */
enum class SeekStatus {
    REQUESTED,
    AVAILABLE,
    WAITING,
    COMPLETED,
    CANCELLED,
    STALE,
    FAILED
}

/**
 * Phase 17.37: Immutable representation of a Seek Request.
 */
data class SeekRequest(
    val seekId: String = UUID.randomUUID().toString().take(8),
    val playbackRequestId: String,
    val targetPositionMs: Long,
    val createdAtMs: Long = System.currentTimeMillis(),
    val status: SeekStatus = SeekStatus.REQUESTED,
    val executedAtMs: Long? = null,
    val supersededBySeekId: String? = null,
    val errorMessage: String? = null
)

/**
 * Phase 17.37: Comprehensive measurements snapshot for progressive playback intelligence.
 */
data class SmartBufferMetrics(
    val playbackRequestId: String? = null,
    val playerInstanceId: String? = null,
    val transcodeJobId: String? = null,
    val state: SmartBufferState = SmartBufferState.UNKNOWN,
    val playbackPositionMs: Long = 0L,
    val playableDurationMs: Long = 0L,
    val internalBufferedPositionMs: Long = 0L,
    val progressiveLeadMs: Long = 0L,
    val productionRate: Float = 0.0f,
    val consumptionRate: Float = 1.0f,
    val timeToDepletionSeconds: Double? = null,
    val startupTargetMs: Long = 8_000L,
    val isWaitingForTranscode: Boolean = false,
    val activeSeekRequest: SeekRequest? = null,
    val isTranscodeCompleted: Boolean = false,
    val isPausedByUser: Boolean = false,
    val fps: Double = 0.0,
    val generatedUnitsCount: Int = 0,
    val sourceDurationMs: Long = 0L,
    val latestLog: String? = null
)
