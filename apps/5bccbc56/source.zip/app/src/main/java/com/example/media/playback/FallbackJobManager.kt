package com.example.media.playback

import android.content.Context
import android.net.Uri
import android.os.StatFs
import android.util.Log
import com.example.media.ffmpeg.FFmpegProgress
import com.example.media.ffmpeg.FFmpegState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.*
import java.io.File
import java.util.concurrent.ConcurrentHashMap

object FallbackJobManager {
    private const val TAG = "FallbackJobManager"
    private const val MIN_FREE_SPACE_BYTES = 50L * 1024L * 1024L // 50MB absolute min
    
    private val activeJobs = ConcurrentHashMap<String, SharedFlow<FFmpegProgress>>()
    private val jobScopes = ConcurrentHashMap<String, CoroutineScope>()
    private val activeJobIds = ConcurrentHashMap<String, String>()

    @Synchronized
    fun getOrStartJob(
        context: Context,
        inputUri: Uri,
        outputFile: File,
        plan: PlaybackCompatibilityResult,
        requestId: String = "unknown"
    ): Flow<FFmpegProgress> {
        val cacheKey = outputFile.name
        
        activeJobs[cacheKey]?.let {
            val existingJobId = activeJobIds[cacheKey] ?: "F_dedup_${cacheKey.take(8)}"
            PlaybackRequestCoordinator.logAsyncOperation(
                requestId = requestId,
                operationId = existingJobId,
                operationType = "FFMPEG_FALLBACK",
                sourceType = "DEDUPLICATED_JOIN"
            )
            Log.i("FALLBACK_TRACE", "[TRANSCODING_DUPLICATE_GUARD] key=$cacheKey req=$requestId existingJob=$existingJobId")
            Log.i(TAG, "[FALLBACK_CACHE_TRACE] key=$cacheKey result=RACE_IGNORED (joined existing job)")
            return it
        }

        val jobId = PlaybackRequestCoordinator.generateNextFfmpegJobId(requestId)
        activeJobIds[cacheKey] = jobId
        PlaybackRequestCoordinator.logAsyncOperation(
            requestId = requestId,
            operationId = jobId,
            operationType = "FFMPEG_FALLBACK",
            sourceType = "NEW_JOB"
        )

        // Space check
        var inputSize = 0L
        if (inputUri.scheme == "file") {
            inputSize = File(inputUri.path ?: "").length()
        } else if (inputUri.scheme == "content") {
            try {
                context.contentResolver.openFileDescriptor(inputUri, "r")?.use {
                    inputSize = it.statSize
                }
            } catch (e: Exception) {}
        }
        
        val requiredSpace = (inputSize * 2.5).toLong().coerceAtLeast(MIN_FREE_SPACE_BYTES)
        val parentDir = outputFile.parentFile ?: context.cacheDir
        if (!parentDir.exists()) {
            parentDir.mkdirs()
        }
        
        val stat = try {
            StatFs(parentDir.absolutePath)
        } catch (e: Exception) {
            null
        }
        
        val availableSpace = stat?.let {
            if (it.blockCountLong == 0L) Long.MAX_VALUE
            else it.availableBlocksLong * it.blockSizeLong
        } ?: Long.MAX_VALUE
        
        Log.i(TAG, "[FFMPEG_RESOURCE_TRACE] cacheKey=$cacheKey inputSize=$inputSize availableSpace=$availableSpace requiredSpace=$requiredSpace state=CHECKING_SPACE")

        if (availableSpace < requiredSpace) {
            Log.e(TAG, "[FFMPEG_RESOURCE_TRACE] Insufficient storage space (INSUFFICIENT_STORAGE). Available: $availableSpace, Required: $requiredSpace")
            activeJobIds.remove(cacheKey)
            return flowOf(FFmpegProgress(state = FFmpegState.FAILED, error = IllegalStateException("INSUFFICIENT_STORAGE: Available $availableSpace, Required $requiredSpace")))
        }

        val scope = CoroutineScope(Dispatchers.IO)
        Log.i(TAG, "[FFMPEG_RESOURCE_TRACE] cacheKey=$cacheKey state=STARTING")
        
        val sharedFlow = PlaybackFallbackEngine.executeFix(context, inputUri, outputFile, plan)
            .onCompletion {
                activeJobs.remove(cacheKey)
                jobScopes.remove(cacheKey)
                activeJobIds.remove(cacheKey)
                scope.cancel()
                Log.i(TAG, "[FFMPEG_RESOURCE_TRACE] cacheKey=$cacheKey state=COMPLETED_OR_CANCELLED")
            }
            .shareIn(
                scope = scope,
                started = SharingStarted.Lazily,
                replay = 1
            )
            
        activeJobs[cacheKey] = sharedFlow
        jobScopes[cacheKey] = scope
        return sharedFlow
    }

    @Synchronized
    fun cancelJob(cacheKey: String) {
        jobScopes[cacheKey]?.cancel()
        jobScopes.remove(cacheKey)
        activeJobs.remove(cacheKey)
        activeJobIds.remove(cacheKey)
        Log.i(TAG, "[FFMPEG_RESOURCE_TRACE] cacheKey=$cacheKey state=CANCELLED (explicit cancel)")
    }
}
