package com.example.media.ffmpeg

import android.util.Log
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.FFmpegKitConfig
import com.arthenica.ffmpegkit.FFprobeKit
import com.arthenica.ffmpegkit.Packages
import com.arthenica.ffmpegkit.ReturnCode
import com.arthenica.ffmpegkit.SessionState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class FFmpegResult(
    val sessionId: Long,
    val isSuccess: Boolean,
    val returnCode: Int,
    val output: String,
    val failStackTrace: String? = null,
    val executionDurationMs: Long = 0L
)

object FFmpegEngine {
    private const val TAG = "FFmpegEngine"
    private var cachedDiagnostics: FFmpegDiagnostics? = null

    @Volatile
    var mockExecutionResult: FFmpegResult? = null

    @Volatile
    var mockAsyncSessionId: Long? = null

    fun resetForTesting() {
        mockExecutionResult = null
        mockAsyncSessionId = null
        cachedDiagnostics = null
    }

    @Volatile
    private var isInitialized = false

    private val sessionLogBuffers = java.util.concurrent.ConcurrentHashMap<Long, StringBuilder>()

    fun initialize() {
        if (isInitialized) return
        synchronized(this) {
            if (isInitialized) return
            try {
                // Ensure native libraries load cleanly and configure log levels
                FFmpegKitConfig.enableLogCallback { log ->
                    val sid = log.sessionId
                    val rawMsg = log.message ?: ""
                    if (rawMsg.isEmpty()) return@enableLogCallback

                    val buffer = sessionLogBuffers.computeIfAbsent(sid) { StringBuilder() }
                    val linesToProcess = mutableListOf<String>()

                    synchronized(buffer) {
                        buffer.append(rawMsg)
                        var str = buffer.toString()
                        while (str.contains("\n") || str.contains("\r")) {
                            val newlineIdx = str.indexOf('\n')
                            val carriageIdx = str.indexOf('\r')
                            val splitIdx = when {
                                newlineIdx != -1 && carriageIdx != -1 -> minOf(newlineIdx, carriageIdx)
                                newlineIdx != -1 -> newlineIdx
                                else -> carriageIdx
                            }
                            val line = str.substring(0, splitIdx).trimEnd('\r', '\n')
                            if (line.isNotBlank()) {
                                linesToProcess.add(line)
                            }
                            str = str.substring(splitIdx + 1)
                        }
                        buffer.setLength(0)
                        buffer.append(str)
                    }

                    val context = FFmpegSessionManager.getSessionContext(sid) ?: FFmpegSessionManager.getCurrentScopedContext()
                    val isTranscoding = context?.isTranscoding == true

                    for (line in linesToProcess) {
                        if (isTranscoding) {
                            com.example.media.playback.TranscodingLogManager.recordLogReceived(sid, line, context?.requestId)
                            
                            val frameMatch = Regex("""frame=\s*(\d+)""").find(line)
                            if (frameMatch != null) {
                                val frameNum = frameMatch.groupValues[1]
                                Log.d("FALLBACK_TRACE", "[FFMPEG_LAST_FRAME] sessionId=$sid frame=$frameNum")
                                Log.d("FALLBACK_TRACE", "[TRANSCODING_OUTPUT_ACTIVITY] sessionId=$sid line=$line")
                            }

                            if (log.level.value >= com.arthenica.ffmpegkit.Level.AV_LOG_WARNING.value) {
                                Log.d(TAG, "[FFmpeg #$sid] $line")
                            }
                        } else {
                            Log.d("FALLBACK_TRACE", "[FFMPEG_PROBE_LOG] [#$sid] $line")
                        }
                    }
                }
                isInitialized = true
                Log.i(TAG, "FFmpegEngine initialized successfully. Version: ${FFmpegKitConfig.getFFmpegVersion()}")
            } catch (t: Throwable) {
                Log.e(TAG, "Failed to initialize FFmpegKit: ${t.message}", t)
            }
        }
    }

    suspend fun getDiagnostics(forceRefresh: Boolean = false): FFmpegDiagnostics = withContext(Dispatchers.IO) {
        if (cachedDiagnostics != null && !forceRefresh) {
            return@withContext cachedDiagnostics!!
        }

        val startTime = System.currentTimeMillis()
        var classLoadingStatus = "UNKNOWN"
        var isAvailable = false
        var ffmpegVer = "N/A"
        var buildConfig = "N/A"
        var nativeLoaded = false
        var selfTestPassed = false
        var probeSelfTestPassed = false
        var packagesList = emptyList<String>()
        var errorMsg: String? = null

        try {
            // Explicit Runtime Class Detection
            try {
                Class.forName("com.arthenica.ffmpegkit.FFmpegKitConfig")
                Class.forName("com.arthenica.smartexception.java.Exceptions")
                classLoadingStatus = "CLASS FOUND"
            } catch (cnfe: ClassNotFoundException) {
                classLoadingStatus = "CLASS NOT FOUND: ${cnfe.message}"
                throw cnfe
            } catch (nde: NoClassDefFoundError) {
                classLoadingStatus = "CLASS NOT FOUND: ${nde.message}"
                throw nde
            }

            initialize()
            ffmpegVer = FFmpegKitConfig.getFFmpegVersion() ?: "Unknown"
            buildConfig = FFmpegKitConfig.getBuildDate() ?: "N/A"
            nativeLoaded = true
            isAvailable = true

            FFmpegSessionManager.withOperationScope(FFmpegOperationType.CAPABILITY_PROBE) {
                // Test harmless execution: -version
                val testSession = FFmpegKit.execute("-version")
                selfTestPassed = ReturnCode.isSuccess(testSession.returnCode)

                // Test harmless probe execution: -version
                val probeSession = FFprobeKit.execute("-version")
                probeSelfTestPassed = ReturnCode.isSuccess(probeSession.returnCode)
            }

            // Determine registered packages
            val pkgs = mutableListOf<String>()
            try {
                if (Packages.getPackageName() != null) {
                    pkgs.add(Packages.getPackageName())
                }
            } catch (_: Throwable) {}
            packagesList = pkgs

        } catch (t: Throwable) {
            errorMsg = "${t.javaClass.simpleName}: ${t.message}"
            Log.e(TAG, "FFmpeg self-diagnostic failed", t)
        }

        val diag = FFmpegDiagnostics(
            isAvailable = isAvailable && selfTestPassed,
            ffmpegVersion = ffmpegVer,
            ffmpegKitVersion = "8.1.7",
            abi = "arm64-v8a",
            buildConfiguration = buildConfig,
            classLoadingStatus = classLoadingStatus,
            nativeLibraryLoaded = nativeLoaded,
            selfTestPassed = selfTestPassed,
            probeSelfTestPassed = probeSelfTestPassed,
            registeredPackages = packagesList,
            errorMessage = errorMsg,
            executionTimeMs = System.currentTimeMillis() - startTime
        )

        cachedDiagnostics = diag
        diag
    }

    suspend fun execute(
        command: String,
        operationType: FFmpegOperationType = FFmpegOperationType.FFMPEG_COMMAND_PROBE,
        requestId: String? = null,
        jobId: String? = null
    ): FFmpegResult = withContext(Dispatchers.IO) {
        val start = System.currentTimeMillis()
        try {
            initialize()
            val session = FFmpegSessionManager.withOperationScope(operationType, requestId, jobId, command) {
                FFmpegKit.execute(command)
            }
            val duration = System.currentTimeMillis() - start
            val success = ReturnCode.isSuccess(session.returnCode)

            FFmpegResult(
                sessionId = session.sessionId,
                isSuccess = success,
                returnCode = session.returnCode?.value ?: -1,
                output = session.allLogsAsString ?: "",
                failStackTrace = session.failStackTrace,
                executionDurationMs = duration
            )
        } catch (t: Throwable) {
            Log.e(TAG, "FFmpeg execute failed", t)
            val duration = System.currentTimeMillis() - start
            FFmpegResult(
                sessionId = -1L,
                isSuccess = false,
                returnCode = -1,
                output = "FFmpeg Execution Error: ${t.javaClass.simpleName}: ${t.message}",
                failStackTrace = t.stackTraceToString(),
                executionDurationMs = duration
            )
        }
    }

    suspend fun executeWithArguments(
        arguments: Array<String>,
        operationType: FFmpegOperationType = FFmpegOperationType.FFMPEG_COMMAND_PROBE,
        requestId: String? = null,
        jobId: String? = null
    ): FFmpegResult = withContext(Dispatchers.IO) {
        mockExecutionResult?.let { return@withContext it }
        val start = System.currentTimeMillis()
        try {
            initialize()
            val cmdStr = arguments.joinToString(" ")
            val session = FFmpegSessionManager.withOperationScope(operationType, requestId, jobId, cmdStr) {
                FFmpegKit.executeWithArguments(arguments)
            }
            val duration = System.currentTimeMillis() - start
            val success = ReturnCode.isSuccess(session.returnCode)

            FFmpegResult(
                sessionId = session.sessionId,
                isSuccess = success,
                returnCode = session.returnCode?.value ?: -1,
                output = session.allLogsAsString ?: "",
                failStackTrace = session.failStackTrace,
                executionDurationMs = duration
            )
        } catch (t: Throwable) {
            Log.e(TAG, "FFmpeg executeWithArguments failed", t)
            val duration = System.currentTimeMillis() - start
            FFmpegResult(
                sessionId = -1L,
                isSuccess = false,
                returnCode = -1,
                output = "FFmpeg Execution Error: ${t.javaClass.simpleName}: ${t.message}",
                failStackTrace = t.stackTraceToString(),
                executionDurationMs = duration
            )
        }
    }

    fun executeAsyncWithArguments(
        arguments: Array<String>,
        totalDurationMs: Long = 0L,
        operationType: FFmpegOperationType = FFmpegOperationType.ACTUAL_TRANSCODING,
        requestId: String? = null,
        jobId: String? = null,
        onProgress: (FFmpegProgress) -> Unit,
        onComplete: (FFmpegResult) -> Unit
    ): Long {
        val mockResult = mockExecutionResult
        if (mockResult != null) {
            val sid = mockAsyncSessionId ?: if (mockResult.sessionId > 0) mockResult.sessionId else 201L
            onProgress(
                FFmpegProgress(
                    sessionId = sid,
                    state = FFmpegState.STARTING,
                    totalDurationMs = totalDurationMs
                )
            )
            onProgress(
                FFmpegProgress(
                    sessionId = sid,
                    state = FFmpegState.RUNNING,
                    progressPercentage = 50f,
                    currentTimestampMs = if (totalDurationMs > 0) totalDurationMs / 2 else 1000L,
                    totalDurationMs = totalDurationMs,
                    speed = 1.0,
                    fps = 24.0
                )
            )
            if (mockResult.isSuccess) {
                onProgress(
                    FFmpegProgress(
                        sessionId = sid,
                        state = FFmpegState.COMPLETED,
                        progressPercentage = 100f,
                        currentTimestampMs = totalDurationMs,
                        totalDurationMs = totalDurationMs,
                        speed = 1.0,
                        fps = 24.0
                    )
                )
            } else {
                onProgress(
                    FFmpegProgress(
                        sessionId = sid,
                        state = FFmpegState.FAILED,
                        totalDurationMs = totalDurationMs,
                        logOutput = mockResult.output
                    )
                )
            }
            onComplete(mockResult)
            return sid
        }
        if (mockAsyncSessionId != null) {
            val sid = mockAsyncSessionId!!
            onProgress(
                FFmpegProgress(
                    sessionId = sid,
                    state = FFmpegState.STARTING,
                    totalDurationMs = totalDurationMs
                )
            )
            return sid
        }
        initialize()
        val sessionStartTime = System.currentTimeMillis()
        val lastPublishedPct = java.util.concurrent.atomic.AtomicReference(0f)
        val cmdStr = arguments.joinToString(" ")

        val session = FFmpegKit.executeWithArgumentsAsync(
            arguments,
            { completedSession ->
                val sid = completedSession.sessionId
                // Flush any remaining buffer for this session
                sessionLogBuffers.remove(sid)?.let { buffer ->
                    val remaining = buffer.toString().trim()
                    if (remaining.isNotBlank()) {
                        val context = FFmpegSessionManager.getSessionContext(sid)
                        if (context?.isTranscoding == true) {
                            com.example.media.playback.TranscodingLogManager.recordLogReceived(sid, remaining, context.requestId)
                        } else {
                            Log.d("FALLBACK_TRACE", "[FFMPEG_PROBE_LOG] [#$sid] $remaining")
                        }
                    }
                }

                FFmpegSessionManager.unregisterSession(completedSession.sessionId)
                val duration = System.currentTimeMillis() - sessionStartTime
                val success = ReturnCode.isSuccess(completedSession.returnCode)
                val isCancelled = ReturnCode.isCancel(completedSession.returnCode)

                if (isCancelled) {
                    onProgress(
                        FFmpegProgress(
                            sessionId = completedSession.sessionId,
                            state = FFmpegState.CANCELLED,
                            totalDurationMs = totalDurationMs
                        )
                    )
                } else if (success) {
                    onProgress(
                        FFmpegProgress(
                            sessionId = completedSession.sessionId,
                            state = FFmpegState.COMPLETED,
                            progressPercentage = 100f,
                            currentTimestampMs = totalDurationMs,
                            totalDurationMs = totalDurationMs
                        )
                    )
                } else {
                    onProgress(
                        FFmpegProgress(
                            sessionId = completedSession.sessionId,
                            state = FFmpegState.FAILED,
                            totalDurationMs = totalDurationMs,
                            logOutput = completedSession.allLogsAsString
                        )
                    )
                }

                onComplete(
                    FFmpegResult(
                        sessionId = completedSession.sessionId,
                        isSuccess = success,
                        returnCode = completedSession.returnCode?.value ?: -1,
                        output = completedSession.allLogsAsString ?: "",
                        failStackTrace = completedSession.failStackTrace,
                        executionDurationMs = duration
                    )
                )
            },
            null, // Handled globally via FFmpegKitConfig.enableLogCallback with line accumulator
            { statistics ->
                val sid = statistics.sessionId
                val timeMs = statistics.time.toLong().coerceAtLeast(0L)
                val totalMs = totalDurationMs.coerceAtLeast(0L)
                val rawPercentage = if (totalMs > 0L) {
                    ((timeMs.toDouble() / totalMs.toDouble()) * 100.0).toFloat().coerceIn(0f, 99.9f)
                } else 0f

                val monotonicPct = maxOf(lastPublishedPct.get(), rawPercentage)
                lastPublishedPct.set(monotonicPct)

                val speed = statistics.speed
                val bitrate = statistics.bitrate
                val remainingMs = if (speed > 0 && totalMs > timeMs) {
                    ((totalMs - timeMs) / speed).toLong()
                } else 0L
                val latestLine = com.example.media.playback.TranscodingLogManager.sessionMetadata.value.latestLogLine

                Log.d("FALLBACK_TRACE", "[FFMPEG_PROCESS_STATE] sessionId=$sid state=RUNNING")
                Log.d("FALLBACK_TRACE", "[FFMPEG_LAST_PROGRESS] sessionId=$sid outTimeMs=$timeMs speed=$speed")
                Log.d("FALLBACK_TRACE", "[TRANSCODING_PROGRESS_RECEIVED] requestId=${requestId ?: "none"} jobId=${jobId ?: "none"} sessionId=$sid outTimeMs=$timeMs durationMs=$totalMs")
                Log.d("FALLBACK_TRACE", "[TRANSCODING_PROGRESS_NORMALIZED] progress=${monotonicPct}%")
                Log.d("FALLBACK_TRACE", "[TRANSCODING_PROGRESS_PUBLISHED] progress=${monotonicPct}%")

                onProgress(
                    FFmpegProgress(
                        sessionId = sid,
                        state = FFmpegState.RUNNING,
                        progressPercentage = monotonicPct,
                        currentTimestampMs = timeMs,
                        totalDurationMs = totalMs,
                        speed = speed,
                        bitrateKbps = bitrate,
                        estimatedRemainingTimeMs = remainingMs,
                        latestLogLine = latestLine
                    )
                )
            }
        )

        FFmpegSessionManager.registerSession(
            session = session,
            operationType = operationType,
            requestId = requestId,
            jobId = jobId,
            command = cmdStr,
            totalDurationMs = totalDurationMs
        )
        onProgress(
            FFmpegProgress(
                sessionId = session.sessionId,
                state = FFmpegState.STARTING,
                totalDurationMs = totalDurationMs
            )
        )
        return session.sessionId
    }

    fun cancel(sessionId: Long): Boolean {
        return FFmpegSessionManager.cancel(sessionId)
    }

    fun cancelAll() {
        FFmpegSessionManager.cancelAll()
    }
}
