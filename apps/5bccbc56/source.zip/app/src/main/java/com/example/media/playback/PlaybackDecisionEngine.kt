package com.example.media.playback

import androidx.media3.common.PlaybackException
import com.example.media.probe.MediaProbeInfo
import android.util.Log

enum class PlaybackAction {
    DIRECT,
    DIRECT_ATTEMPT,
    FALLBACK,
    REMUX,
    FAIL,
    CANCELLED,
    STALE
}

enum class StaticCompatibility {
    SUPPORTED,
    UNKNOWN,
    UNSUPPORTED
}

enum class RuntimeEvidence {
    NONE,
    DECODER_FAILURE,
    FORMAT_FAILURE,
    SOURCE_FAILURE,
    CANCELLATION,
    STALE
}

data class PlaybackDecision(
    val requestId: String,
    val sourceType: PlaybackSourceType,
    val compatibility: StaticCompatibility,
    val runtimeEvidence: RuntimeEvidence,
    val action: PlaybackAction,
    val reason: String
)

object PlaybackDecisionEngine {
    private const val TAG = "PlaybackDecisionEngine"

    fun makeDecision(
        requestId: String,
        sourceType: PlaybackSourceType,
        probeInfo: MediaProbeInfo?,
        compatibilityResult: PlaybackCompatibilityResult,
        runtimeException: PlaybackException?,
        isCancelled: Boolean,
        isStale: Boolean
    ): PlaybackDecision {
        
        var runtimeEvidence = RuntimeEvidence.NONE
        
        if (isCancelled) {
            runtimeEvidence = RuntimeEvidence.CANCELLATION
        } else if (isStale) {
            runtimeEvidence = RuntimeEvidence.STALE
        } else if (runtimeException != null) {
            val classifiedError = PlaybackErrorClassifier.classifyMedia3Error(
                requestId = requestId,
                error = runtimeException,
                sourceType = sourceType,
                fallbackAttemptCount = 0 // we just want the category
            )
            runtimeEvidence = when (classifiedError.category) {
                PlaybackErrorCategory.MEDIA3_DECODER_FAILED -> RuntimeEvidence.DECODER_FAILURE
                PlaybackErrorCategory.MEDIA3_SOURCE_ERROR -> RuntimeEvidence.FORMAT_FAILURE
                PlaybackErrorCategory.INPUT_NOT_FOUND, PlaybackErrorCategory.INPUT_PERMISSION_DENIED, PlaybackErrorCategory.INPUT_INVALID_URI, PlaybackErrorCategory.INPUT_UNREADABLE -> RuntimeEvidence.SOURCE_FAILURE
                else -> RuntimeEvidence.SOURCE_FAILURE
            }
        }

        val staticCompat = when (compatibilityResult.strategy) {
            PlaybackStrategy.DIRECT_HARDWARE, PlaybackStrategy.DIRECT_SAFE -> StaticCompatibility.SUPPORTED
            PlaybackStrategy.DIRECT_ATTEMPT -> StaticCompatibility.UNKNOWN
            else -> StaticCompatibility.UNSUPPORTED
        }
        
        val fallbackAttempted = (runtimeException != null && sourceType == PlaybackSourceType.ORIGINAL) || (sourceType == PlaybackSourceType.FALLBACK) || (sourceType == PlaybackSourceType.PROGRESSIVE_FALLBACK)

        val (action, reason) = when {
            isCancelled -> Pair(PlaybackAction.CANCELLED, "CANCELLED")
            isStale -> Pair(PlaybackAction.STALE, "STALE_REQUEST")
            sourceType == PlaybackSourceType.FALLBACK || sourceType == PlaybackSourceType.PROGRESSIVE_FALLBACK -> {
                if (runtimeEvidence != RuntimeEvidence.NONE) Pair(PlaybackAction.FAIL, "FALLBACK_RUNTIME_FAILURE")
                else Pair(PlaybackAction.DIRECT, "FALLBACK_SUCCESS")
            }
            runtimeEvidence == RuntimeEvidence.DECODER_FAILURE || runtimeEvidence == RuntimeEvidence.FORMAT_FAILURE -> Pair(PlaybackAction.FALLBACK, "FALLBACK_RUNTIME_DECODER_FAILURE")
            runtimeEvidence == RuntimeEvidence.SOURCE_FAILURE -> Pair(PlaybackAction.FAIL, "DIRECT_SOURCE_FAILURE")
            staticCompat == StaticCompatibility.SUPPORTED -> Pair(PlaybackAction.DIRECT, "DIRECT_SUPPORTED")
            staticCompat == StaticCompatibility.UNKNOWN -> Pair(PlaybackAction.DIRECT_ATTEMPT, "DIRECT_UNKNOWN_COMPATIBILITY")
            compatibilityResult.strategy == PlaybackStrategy.REMUX_REQUIRED -> Pair(PlaybackAction.REMUX, "REMUX_CONTAINER_INCOMPATIBILITY")
            else -> Pair(PlaybackAction.FALLBACK, "FALLBACK_STATIC_CODEC_UNSUPPORTED")
        }

        val decision = PlaybackDecision(requestId, sourceType, staticCompat, runtimeEvidence, action, reason)

        Log.i("PLAYBACK_DECISION_INPUT", "[PLAYBACK_DECISION_INPUT] requestId=$requestId sourceType=$sourceType compatibility=$staticCompat runtimeEvidence=$runtimeEvidence fallbackAttempted=$fallbackAttempted cancellation=$isCancelled stale=$isStale")
        Log.i("PLAYBACK_DECISION_RESULT", "[PLAYBACK_DECISION_RESULT] action=${decision.action} reason=${decision.reason}")
        Log.i("PLAYBACK_DECISION_GUARD", "[PLAYBACK_DECISION_GUARD] Decision successfully bound to $requestId (source: $sourceType)")
        
        return decision
    }
}
