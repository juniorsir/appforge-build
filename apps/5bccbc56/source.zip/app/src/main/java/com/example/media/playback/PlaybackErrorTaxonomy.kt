package com.example.media.playback

import android.content.Context
import android.net.Uri
import android.util.Log
import androidx.media3.common.ParserException
import androidx.media3.common.PlaybackException
import androidx.media3.exoplayer.ExoPlaybackException
import androidx.media3.exoplayer.mediacodec.MediaCodecRenderer
import androidx.media3.exoplayer.source.UnrecognizedInputFormatException
import com.example.media.DecoderCapabilityManager
import com.example.media.ffmpeg.FFmpegProgress
import com.example.media.ffmpeg.FFmpegState
import com.example.media.probe.MediaProbeInfo
import java.io.File
import java.io.FileNotFoundException
import java.io.IOException

/**
 * Phase 17.18-C: Authoritative error stages in the playback pipeline.
 */
enum class PlaybackErrorStage {
    INPUT,
    ANALYSIS,
    COMPATIBILITY,
    DECISION,
    FALLBACK_PROCESSING,
    FALLBACK_VALIDATION,
    CACHE,
    MEDIA3_PREPARATION,
    MEDIA3_PLAYBACK,
    LIFECYCLE,
    CANCELLATION
}

/**
 * Phase 17.18-D: Controlled error categories across the entire media pipeline.
 */
enum class PlaybackErrorCategory {
    // Input / URI errors (Phase 17.18-G)
    INPUT_NOT_FOUND,
    INPUT_PERMISSION_DENIED,
    INPUT_INVALID_URI,
    INPUT_UNREADABLE,

    // FFprobe / Analysis errors (Phase 17.18-H)
    FFPROBE_EXECUTION_FAILED,
    FFPROBE_NO_STREAMS,
    FFPROBE_INVALID_OUTPUT,
    FFPROBE_TIMEOUT,

    // Metadata errors (Phase 17.18-I)
    METADATA_MISSING,
    METADATA_INVALID,
    METADATA_UNSUPPORTED,

    // Decoder capability errors (Phase 17.18-J)
    DECODER_NOT_FOUND,
    DECODER_CAPABILITY_UNKNOWN,

    // Compatibility errors (Phase 17.18-K)
    COMPATIBILITY_UNSUPPORTED,
    COMPATIBILITY_UNKNOWN,

    // Decision errors
    DECISION_INVALID,

    // FFmpeg errors (Phase 17.18-O & 17.23 & 17.32)
    FFMPEG_EXECUTION_FAILED,
    FFMPEG_ENCODING_FAILED,
    FFMPEG_CANCELLED,
    FFMPEG_TIMEOUT,
    FFMPEG_ENCODER_UNAVAILABLE,
    FFMPEG_OUTPUT_FORMAT_UNDETERMINED,

    // Validation errors (Phase 17.18-P & 17.23)
    OUTPUT_MISSING,
    OUTPUT_EMPTY,
    OUTPUT_INVALID,
    FALLBACK_VALIDATION_FAILED,
    INVALID_VIDEO_CODEC,
    INVALID_PIXEL_FORMAT,
    INVALID_PROFILE,
    INVALID_RESOLUTION,
    INVALID_DURATION,
    AUDIO_STREAM_MISSING,

    // Cache errors (Phase 17.18-Q)
    CACHE_MISS,
    CACHE_INVALID,
    CACHE_CORRUPTED,

    // Media3 errors (Phase 17.18-M)
    MEDIA3_SOURCE_ERROR,
    MEDIA3_PREPARATION_FAILED,
    MEDIA3_DECODER_FAILED,
    MEDIA3_PLAYBACK_FAILED,

    // Cancellation & Stale (Phase 17.18-E & 17.18-F)
    PLAYBACK_INTERRUPTED,
    PLAYBACK_CANCELLED,
    REQUEST_STALE,
    REQUEST_SUPERSEDED,

    // Lifecycle
    LIFECYCLE_INTERRUPTED,

    // Progressive Generation errors (Phase 17.34)
    PROGRESSIVE_FFMPEG_FAILED,
    PROGRESSIVE_OUTPUT_FAILED,
    PROGRESSIVE_UNIT_INVALID,
    PROGRESSIVE_STORAGE_FAILED,
    PROGRESSIVE_CANCELLED,
    PROGRESSIVE_STALE,

    // Storage (Phase 17.18-R)
    INSUFFICIENT_STORAGE,

    // Unknown
    UNKNOWN_ERROR
}

/**
 * Phase 17.18-S: Error recoverability classification.
 */
enum class ErrorRecoverability {
    RECOVERABLE,
    NON_RECOVERABLE,
    USER_CANCELLED,
    STALE,
    RETRYABLE
}

/**
 * Phase 17.18-T: Deterministic recovery action mapping.
 */
enum class PlaybackRecoveryAction {
    NONE,
    REQUEST_ACCESS,
    DIRECT_ATTEMPT,
    TRANSCODE_FALLBACK,
    REMUX_FALLBACK,
    REGENERATE_CACHE_ONCE,
    FALLBACK_FAILED,
    PLAYBACK_FAILED,
    IGNORE,
    STOP
}

/**
 * Phase 17.18-B: Authoritative request-bound error model.
 */
data class PlaybackError(
    val requestId: String,
    val operationId: String? = null,
    val stage: PlaybackErrorStage,
    val category: PlaybackErrorCategory,
    val code: Int = 0,
    val technicalMessage: String,
    val userMessage: String,
    val cause: Throwable? = null,
    val sourceType: PlaybackSourceType? = null,
    val recoverable: ErrorRecoverability,
    val recoveryAction: PlaybackRecoveryAction
)

/**
 * Authoritative classifier and telemetry logger for playback errors.
 */
object PlaybackErrorClassifier {
    private const val TAG_CLASS = "ERROR_CLASSIFICATION"
    private const val TAG_RECOVERY = "ERROR_RECOVERY"

    fun logErrorClassification(error: PlaybackError, accepted: Boolean) {
        Log.i(
            TAG_CLASS,
            "[$TAG_CLASS] requestId=${error.requestId} operationId=${error.operationId ?: "none"} stage=${error.stage.name} category=${error.category.name} code=${error.code} sourceType=${error.sourceType?.name ?: "none"} recoverable=${error.recoverable.name} recoveryAction=${error.recoveryAction.name} accepted=$accepted"
        )
    }

    fun logErrorRecovery(
        requestId: String,
        category: PlaybackErrorCategory,
        action: PlaybackRecoveryAction,
        accepted: Boolean
    ) {
        Log.i(
            TAG_RECOVERY,
            "[$TAG_RECOVERY] requestId=$requestId category=${category.name} action=${action.name} accepted=$accepted"
        )
    }

    /**
     * Phase 17.18-G: Classify input URI or file access issues before or during playback.
     */
    fun classifyInputException(
        requestId: String,
        throwable: Throwable,
        uri: Uri?,
        operationId: String? = null
    ): PlaybackError {
        var current: Throwable? = throwable
        var isNotFound = false
        var isPermission = false
        var isInvalidUri = false

        while (current != null) {
            if (current is FileNotFoundException) isNotFound = true
            if (current is SecurityException) isPermission = true
            if (current is IllegalArgumentException) isInvalidUri = true
            current = current.cause
        }

        val category = when {
            isNotFound -> PlaybackErrorCategory.INPUT_NOT_FOUND
            isPermission -> PlaybackErrorCategory.INPUT_PERMISSION_DENIED
            isInvalidUri -> PlaybackErrorCategory.INPUT_INVALID_URI
            else -> PlaybackErrorCategory.INPUT_UNREADABLE
        }

        val (userMsg, action) = when (category) {
            PlaybackErrorCategory.INPUT_NOT_FOUND -> Pair(
                "The selected video file could not be found.",
                PlaybackRecoveryAction.STOP
            )
            PlaybackErrorCategory.INPUT_PERMISSION_DENIED -> Pair(
                "Permission to access the media file was denied.",
                PlaybackRecoveryAction.REQUEST_ACCESS
            )
            PlaybackErrorCategory.INPUT_INVALID_URI -> Pair(
                "Invalid media URI format.",
                PlaybackRecoveryAction.STOP
            )
            else -> Pair(
                "Unable to read the media source file.",
                PlaybackRecoveryAction.STOP
            )
        }

        return PlaybackError(
            requestId = requestId,
            operationId = operationId,
            stage = PlaybackErrorStage.INPUT,
            category = category,
            code = -1,
            technicalMessage = "Input access failed for URI '$uri': ${throwable.message}",
            userMessage = userMsg,
            cause = throwable,
            sourceType = PlaybackSourceType.ORIGINAL,
            recoverable = ErrorRecoverability.NON_RECOVERABLE,
            recoveryAction = action
        )
    }

    /**
     * Phase 17.18-H: Classify FFprobe inspection failure.
     */
    fun classifyProbeFailure(
        requestId: String,
        throwable: Throwable?,
        uri: Uri?,
        operationId: String? = null
    ): PlaybackError {
        val msg = throwable?.message?.lowercase() ?: ""
        val isTimeout = msg.contains("timeout")
        val isNoStreams = msg.contains("no streams") || msg.contains("0 streams")

        val category = when {
            isNoStreams -> PlaybackErrorCategory.FFPROBE_NO_STREAMS
            isTimeout -> PlaybackErrorCategory.FFPROBE_TIMEOUT
            else -> PlaybackErrorCategory.FFPROBE_EXECUTION_FAILED
        }

        // UNKNOWN metadata != UNSUPPORTED. Allow direct playback attempt if file exists.
        val recoveryAction = if (category == PlaybackErrorCategory.FFPROBE_NO_STREAMS) {
            PlaybackRecoveryAction.STOP
        } else {
            PlaybackRecoveryAction.DIRECT_ATTEMPT
        }

        return PlaybackError(
            requestId = requestId,
            operationId = operationId,
            stage = PlaybackErrorStage.ANALYSIS,
            category = category,
            code = -2,
            technicalMessage = "FFprobe inspection failed for URI '$uri': ${throwable?.message}",
            userMessage = if (category == PlaybackErrorCategory.FFPROBE_NO_STREAMS) {
                "The media file does not contain any readable audio or video streams."
            } else {
                "Media analysis incomplete. Attempting direct hardware playback."
            },
            cause = throwable,
            sourceType = PlaybackSourceType.ORIGINAL,
            recoverable = if (category == PlaybackErrorCategory.FFPROBE_NO_STREAMS) ErrorRecoverability.NON_RECOVERABLE else ErrorRecoverability.RETRYABLE,
            recoveryAction = recoveryAction
        )
    }

    /**
     * Phase 17.18-K: Classify compatibility decision.
     * Note: Incompatible codecs trigger fallback (recovery action), NOT a playback failure.
     */
    fun classifyCompatibility(
        requestId: String,
        strategy: PlaybackStrategy,
        probeInfo: MediaProbeInfo?,
        operationId: String? = null
    ): PlaybackError? {
        if (strategy.isDirect) {
            return null // No error
        }

        val category = if (strategy == PlaybackStrategy.REMUX_REQUIRED) {
            PlaybackErrorCategory.COMPATIBILITY_UNSUPPORTED
        } else {
            PlaybackErrorCategory.COMPATIBILITY_UNSUPPORTED
        }

        val action = if (strategy == PlaybackStrategy.REMUX_REQUIRED) {
            PlaybackRecoveryAction.REMUX_FALLBACK
        } else {
            PlaybackRecoveryAction.TRANSCODE_FALLBACK
        }

        val v = probeInfo?.primaryVideo
        val codecDesc = "${v?.codec ?: "unknown"} (${v?.profile ?: "unknown"}, ${v?.bitDepth ?: 8}-bit)"

        return PlaybackError(
            requestId = requestId,
            operationId = operationId,
            stage = PlaybackErrorStage.COMPATIBILITY,
            category = category,
            code = 0,
            technicalMessage = "Direct hardware decoding incompatible for $codecDesc; routing to ${action.name}",
            userMessage = "Optimizing media for direct device playback...",
            cause = null,
            sourceType = PlaybackSourceType.ORIGINAL,
            recoverable = ErrorRecoverability.RECOVERABLE,
            recoveryAction = action
        )
    }

    /**
     * Phase 17.18-O & 17.18-R: Classify FFmpeg execution progress / failure.
     */
    fun classifyFfmpegProgress(
        requestId: String,
        ffmpegJobId: String?,
        progress: FFmpegProgress
    ): PlaybackError? {
        if (progress.state != FFmpegState.FAILED) {
            return null
        }

        val error = progress.error
        val msg = error?.message ?: "FFmpeg execution failed"

        if (msg.contains("INSUFFICIENT_STORAGE", ignoreCase = true)) {
            return PlaybackError(
                requestId = requestId,
                operationId = ffmpegJobId,
                stage = PlaybackErrorStage.INPUT,
                category = PlaybackErrorCategory.INSUFFICIENT_STORAGE,
                code = -5,
                technicalMessage = msg,
                userMessage = "Insufficient storage space to prepare playback fallback. Please free up space on your device.",
                cause = error,
                sourceType = PlaybackSourceType.FALLBACK,
                recoverable = ErrorRecoverability.NON_RECOVERABLE,
                recoveryAction = PlaybackRecoveryAction.STOP
            )
        }

        if (msg.contains("cancel", ignoreCase = true) || error is kotlinx.coroutines.CancellationException) {
            return PlaybackError(
                requestId = requestId,
                operationId = ffmpegJobId,
                stage = PlaybackErrorStage.CANCELLATION,
                category = PlaybackErrorCategory.FFMPEG_CANCELLED,
                code = -6,
                technicalMessage = "FFmpeg conversion cancelled by user or superseded request.",
                userMessage = "Media processing cancelled.",
                cause = error,
                sourceType = PlaybackSourceType.FALLBACK,
                recoverable = ErrorRecoverability.USER_CANCELLED,
                recoveryAction = PlaybackRecoveryAction.STOP
            )
        }

        val category = when {
            msg.contains("Unable to choose an output format", ignoreCase = true) ||
            msg.contains("OUTPUT_FORMAT_UNDETERMINED", ignoreCase = true) ->
                PlaybackErrorCategory.FFMPEG_OUTPUT_FORMAT_UNDETERMINED
            msg.contains("ENCODER_UNAVAILABLE", ignoreCase = true) ->
                PlaybackErrorCategory.FFMPEG_ENCODER_UNAVAILABLE
            msg.contains("encode", ignoreCase = true) || msg.contains("codec", ignoreCase = true) ->
                PlaybackErrorCategory.FFMPEG_ENCODING_FAILED
            else ->
                PlaybackErrorCategory.FFMPEG_EXECUTION_FAILED
        }

        val userMsg = when (category) {
            PlaybackErrorCategory.FFMPEG_OUTPUT_FORMAT_UNDETERMINED ->
                "Playback Fallback Failed: Output format could not be determined."
            PlaybackErrorCategory.FFMPEG_ENCODER_UNAVAILABLE ->
                "Playback Fallback Failed: Required video encoder is unavailable."
            else ->
                "Playback Fallback Failed: FFmpeg processing encountered an error."
        }

        return PlaybackError(
            requestId = requestId,
            operationId = ffmpegJobId,
            stage = PlaybackErrorStage.FALLBACK_PROCESSING,
            category = category,
            code = -7,
            technicalMessage = "FFmpeg fallback processing failed: $msg",
            userMessage = userMsg,
            cause = error,
            sourceType = PlaybackSourceType.FALLBACK,
            recoverable = ErrorRecoverability.NON_RECOVERABLE,
            recoveryAction = PlaybackRecoveryAction.FALLBACK_FAILED
        )
    }

    /**
     * Phase 17.18-P: Classify fallback validation failure.
     */
    fun classifyValidationFailure(
        requestId: String,
        outputFile: File?,
        probeInfo: MediaProbeInfo?,
        operationId: String? = null
    ): PlaybackError {
        val category = when {
            outputFile == null || !outputFile.exists() -> PlaybackErrorCategory.OUTPUT_MISSING
            outputFile.length() == 0L -> PlaybackErrorCategory.OUTPUT_EMPTY
            else -> PlaybackErrorCategory.FALLBACK_VALIDATION_FAILED
        }

        val techMsg = when (category) {
            PlaybackErrorCategory.OUTPUT_MISSING -> "Fallback output file does not exist at ${outputFile?.absolutePath}"
            PlaybackErrorCategory.OUTPUT_EMPTY -> "Fallback output file is 0 bytes at ${outputFile?.absolutePath}"
            else -> "Fallback output file at ${outputFile?.absolutePath} is unparseable or contains 0 streams"
        }

        return PlaybackError(
            requestId = requestId,
            operationId = operationId,
            stage = PlaybackErrorStage.FALLBACK_VALIDATION,
            category = category,
            code = -8,
            technicalMessage = techMsg,
            userMessage = "Playback Fallback Failed: FFmpeg completed but output media is invalid.",
            cause = null,
            sourceType = PlaybackSourceType.FALLBACK,
            recoverable = ErrorRecoverability.NON_RECOVERABLE,
            recoveryAction = PlaybackRecoveryAction.FALLBACK_FAILED
        )
    }

    /**
     * Phase 17.18-Q: Classify cache result.
     */
    fun classifyCacheResult(
        requestId: String,
        cacheKey: String,
        cachedFile: File,
        isValid: Boolean
    ): PlaybackError? {
        if (!cachedFile.exists() || cachedFile.length() == 0L) {
            // CACHE_MISS is completely normal, not an error
            return null
        }
        if (!isValid) {
            return PlaybackError(
                requestId = requestId,
                operationId = cacheKey,
                stage = PlaybackErrorStage.CACHE,
                category = PlaybackErrorCategory.CACHE_CORRUPTED,
                code = 0,
                technicalMessage = "Cached fallback file $cacheKey is invalid or corrupted. Cleaning and regenerating.",
                userMessage = "Re-validating playback cache...",
                cause = null,
                sourceType = PlaybackSourceType.FALLBACK,
                recoverable = ErrorRecoverability.RETRYABLE,
                recoveryAction = PlaybackRecoveryAction.REGENERATE_CACHE_ONCE
            )
        }
        return null
    }

    /**
     * Phase 17.18-M, 17.18-U: Classify Media3 / ExoPlayer runtime errors.
     * Distinguishes ORIGINAL source errors from FALLBACK source errors.
     * Prevents recursive fallbacks (Invariant 9) and prevents input errors from becoming codec errors (Invariant 10).
     */
    fun classifyMedia3Error(
        requestId: String,
        error: PlaybackException,
        sourceType: PlaybackSourceType,
        fallbackAttemptCount: Int,
        operationId: String? = null
    ): PlaybackError {
        var current: Throwable? = error
        var rootCause: Throwable = error
        var decoderInitEx: MediaCodecRenderer.DecoderInitializationException? = null
        var codecEx: android.media.MediaCodec.CodecException? = null
        var parserEx: ParserException? = null
        var unrecogInputEx: UnrecognizedInputFormatException? = null
        var ioEx: IOException? = null
        var isFileNotFound = false
        var isPermissionDenied = false

        while (current != null) {
            rootCause = current
            if (current is MediaCodecRenderer.DecoderInitializationException && decoderInitEx == null) {
                decoderInitEx = current
            }
            if (current is android.media.MediaCodec.CodecException && codecEx == null) {
                codecEx = current
            }
            if (current is ParserException && parserEx == null) {
                parserEx = current
            }
            if (current is UnrecognizedInputFormatException && unrecogInputEx == null) {
                unrecogInputEx = current
            }
            if (current is IOException && ioEx == null) {
                ioEx = current
            }
            if (current is FileNotFoundException) isFileNotFound = true
            if (current is SecurityException) isPermissionDenied = true
            current = current.cause
        }

        if (error.errorCode == PlaybackException.ERROR_CODE_IO_FILE_NOT_FOUND) isFileNotFound = true
        if (error.errorCode == PlaybackException.ERROR_CODE_IO_NO_PERMISSION) isPermissionDenied = true

        // 1. Input / IO Errors: Must never trigger codec fallback! (Phase 17.18-G & Invariant 10)
        if (isFileNotFound) {
            return PlaybackError(
                requestId = requestId,
                operationId = operationId,
                stage = PlaybackErrorStage.INPUT,
                category = PlaybackErrorCategory.INPUT_NOT_FOUND,
                code = error.errorCode,
                technicalMessage = "Media3 source file not found: ${rootCause.message}",
                userMessage = "The media file could not be found.",
                cause = rootCause,
                sourceType = sourceType,
                recoverable = ErrorRecoverability.NON_RECOVERABLE,
                recoveryAction = PlaybackRecoveryAction.STOP
            )
        }

        if (isPermissionDenied) {
            return PlaybackError(
                requestId = requestId,
                operationId = operationId,
                stage = PlaybackErrorStage.INPUT,
                category = PlaybackErrorCategory.INPUT_PERMISSION_DENIED,
                code = error.errorCode,
                technicalMessage = "Media3 source permission denied: ${rootCause.message}",
                userMessage = "Permission to access the media file was denied.",
                cause = rootCause,
                sourceType = sourceType,
                recoverable = ErrorRecoverability.NON_RECOVERABLE,
                recoveryAction = PlaybackRecoveryAction.REQUEST_ACCESS
            )
        }

        if (ioEx != null || error.errorCode in setOf(
                PlaybackException.ERROR_CODE_IO_UNSPECIFIED,
                PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED,
                PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_TIMEOUT
            )
        ) {
            return PlaybackError(
                requestId = requestId,
                operationId = operationId,
                stage = PlaybackErrorStage.INPUT,
                category = PlaybackErrorCategory.INPUT_UNREADABLE,
                code = error.errorCode,
                technicalMessage = "Media3 IO read error: ${rootCause.message}",
                userMessage = "Unable to read media source.",
                cause = rootCause,
                sourceType = sourceType,
                recoverable = ErrorRecoverability.NON_RECOVERABLE,
                recoveryAction = PlaybackRecoveryAction.STOP
            )
        }

        // 2. Decoder / Codec errors
        val isDecoderFailure = decoderInitEx != null ||
                codecEx != null ||
                error.errorCode == PlaybackException.ERROR_CODE_DECODER_INIT_FAILED ||
                error.errorCode == PlaybackException.ERROR_CODE_DECODING_FAILED ||
                error.errorCode == PlaybackException.ERROR_CODE_DECODING_FORMAT_UNSUPPORTED ||
                error.errorCode == PlaybackException.ERROR_CODE_DECODING_FORMAT_EXCEEDS_CAPABILITIES

        if (isDecoderFailure) {
            // Check if error occurred on FALLBACK vs ORIGINAL (Phase 17.18-U & Invariant 9)
            if (sourceType == PlaybackSourceType.FALLBACK) {
                return PlaybackError(
                    requestId = requestId,
                    operationId = operationId,
                    stage = PlaybackErrorStage.MEDIA3_PLAYBACK,
                    category = PlaybackErrorCategory.MEDIA3_DECODER_FAILED,
                    code = error.errorCode,
                    technicalMessage = "Media3 decoder failed on fallback output: ${error.errorCodeName} (${rootCause.message})",
                    userMessage = "Playback Fallback Error: ${error.errorCodeName} (${error.errorCode})",
                    cause = rootCause,
                    sourceType = PlaybackSourceType.FALLBACK,
                    recoverable = ErrorRecoverability.NON_RECOVERABLE,
                    recoveryAction = PlaybackRecoveryAction.PLAYBACK_FAILED
                )
            } else {
                // On ORIGINAL source: if fallback has not yet been attempted, fallback is allowed
                val exoError = error as? androidx.media3.exoplayer.ExoPlaybackException
                val isAudioRenderer = exoError?.type == androidx.media3.exoplayer.ExoPlaybackException.TYPE_RENDERER && (exoError.rendererName?.contains("audio", ignoreCase = true) == true || exoError.rendererFormat?.sampleMimeType?.startsWith("audio") == true)
                val canFallback = (fallbackAttemptCount == 0) && !isAudioRenderer
                return PlaybackError(
                    requestId = requestId,
                    operationId = operationId,
                    stage = PlaybackErrorStage.MEDIA3_PLAYBACK,
                    category = PlaybackErrorCategory.MEDIA3_DECODER_FAILED,
                    code = error.errorCode,
                    technicalMessage = "Media3 decoder failed on original source: ${error.errorCodeName} (${rootCause.message})",
                    userMessage = if (isAudioRenderer) "Device hardware audio decoder failed." else "Device hardware decoder failed. Retrying with compatible video transcoding...",
                    cause = rootCause,
                    sourceType = PlaybackSourceType.ORIGINAL,
                    recoverable = if (canFallback) ErrorRecoverability.RECOVERABLE else ErrorRecoverability.NON_RECOVERABLE,
                    recoveryAction = if (canFallback) PlaybackRecoveryAction.TRANSCODE_FALLBACK else PlaybackRecoveryAction.PLAYBACK_FAILED
                )
            }
        }

        // 3. Parser / Demuxer errors
        val isParserFailure = parserEx != null ||
                unrecogInputEx != null ||
                error.errorCode == PlaybackException.ERROR_CODE_PARSING_CONTAINER_MALFORMED ||
                error.errorCode == PlaybackException.ERROR_CODE_PARSING_CONTAINER_UNSUPPORTED

        if (isParserFailure) {
            if (sourceType == PlaybackSourceType.FALLBACK) {
                return PlaybackError(
                    requestId = requestId,
                    operationId = operationId,
                    stage = PlaybackErrorStage.MEDIA3_PLAYBACK,
                    category = PlaybackErrorCategory.MEDIA3_PLAYBACK_FAILED,
                    code = error.errorCode,
                    technicalMessage = "Media3 parser failed on fallback output: ${error.errorCodeName}",
                    userMessage = "Playback Fallback Error: ${error.errorCodeName} (${error.errorCode})",
                    cause = rootCause,
                    sourceType = PlaybackSourceType.FALLBACK,
                    recoverable = ErrorRecoverability.NON_RECOVERABLE,
                    recoveryAction = PlaybackRecoveryAction.PLAYBACK_FAILED
                )
            } else {
                val exoError = error as? androidx.media3.exoplayer.ExoPlaybackException
                val isAudioRenderer = exoError?.type == androidx.media3.exoplayer.ExoPlaybackException.TYPE_RENDERER && (exoError.rendererName?.contains("audio", ignoreCase = true) == true || exoError.rendererFormat?.sampleMimeType?.startsWith("audio") == true)
                val canFallback = (fallbackAttemptCount == 0) && !isAudioRenderer
                return PlaybackError(
                    requestId = requestId,
                    operationId = operationId,
                    stage = PlaybackErrorStage.MEDIA3_PREPARATION,
                    category = PlaybackErrorCategory.MEDIA3_SOURCE_ERROR,
                    code = error.errorCode,
                    technicalMessage = "Media3 parser failed on original container: ${error.errorCodeName}",
                    userMessage = "Container format unreadable by hardware parser. Retrying with compatible MP4 container...",
                    cause = rootCause,
                    sourceType = PlaybackSourceType.ORIGINAL,
                    recoverable = if (canFallback) ErrorRecoverability.RECOVERABLE else ErrorRecoverability.NON_RECOVERABLE,
                    recoveryAction = if (canFallback) PlaybackRecoveryAction.REMUX_FALLBACK else PlaybackRecoveryAction.PLAYBACK_FAILED
                )
            }
        }

        // 4. Other general Media3 playback failures
        if (sourceType == PlaybackSourceType.FALLBACK) {
            return PlaybackError(
                requestId = requestId,
                operationId = operationId,
                stage = PlaybackErrorStage.MEDIA3_PLAYBACK,
                category = PlaybackErrorCategory.MEDIA3_PLAYBACK_FAILED,
                code = error.errorCode,
                technicalMessage = "Media3 general error on fallback output: ${error.errorCodeName} (${rootCause.message})",
                userMessage = "Playback Fallback Error: ${error.errorCodeName} (${error.errorCode})",
                cause = rootCause,
                sourceType = PlaybackSourceType.FALLBACK,
                recoverable = ErrorRecoverability.NON_RECOVERABLE,
                recoveryAction = PlaybackRecoveryAction.PLAYBACK_FAILED
            )
        } else {
            val exoError = error as? androidx.media3.exoplayer.ExoPlaybackException
                val isAudioRenderer = exoError?.type == androidx.media3.exoplayer.ExoPlaybackException.TYPE_RENDERER && (exoError.rendererName?.contains("audio", ignoreCase = true) == true || exoError.rendererFormat?.sampleMimeType?.startsWith("audio") == true)
                val canFallback = (fallbackAttemptCount == 0) && !isAudioRenderer
            return PlaybackError(
                requestId = requestId,
                operationId = operationId,
                stage = PlaybackErrorStage.MEDIA3_PLAYBACK,
                category = PlaybackErrorCategory.MEDIA3_PLAYBACK_FAILED,
                code = error.errorCode,
                technicalMessage = "Media3 general error on original source: ${error.errorCodeName} (${rootCause.message})",
                userMessage = if (canFallback) "Direct playback encountered an issue. Retrying with compatibility fallback..." else "Playback Error: ${error.errorCodeName} (${error.errorCode})",
                cause = rootCause,
                sourceType = PlaybackSourceType.ORIGINAL,
                recoverable = if (canFallback) ErrorRecoverability.RECOVERABLE else ErrorRecoverability.NON_RECOVERABLE,
                recoveryAction = if (canFallback) PlaybackRecoveryAction.TRANSCODE_FALLBACK else PlaybackRecoveryAction.PLAYBACK_FAILED
            )
        }
    }

    /**
     * Phase 17.18-E: Classify cancellation (normal cancellation is NOT a playback failure).
     */
    fun classifyCancellation(
        requestId: String,
        operationId: String? = null,
        reason: String = "user_cancelled"
    ): PlaybackError {
        return PlaybackError(
            requestId = requestId,
            operationId = operationId,
            stage = PlaybackErrorStage.CANCELLATION,
            category = PlaybackErrorCategory.PLAYBACK_CANCELLED,
            code = 0,
            technicalMessage = "Operation cancelled: $reason",
            userMessage = "Playback cancelled.",
            cause = null,
            sourceType = null,
            recoverable = ErrorRecoverability.USER_CANCELLED,
            recoveryAction = PlaybackRecoveryAction.STOP
        )
    }

    /**
     * Phase 17.18-F: Classify stale/superseded request (stale requests are ignored, NOT failures).
     */
    fun classifyStaleRequest(
        requestId: String,
        activeRequestId: String,
        operation: String
    ): PlaybackError {
        return PlaybackError(
            requestId = requestId,
            operationId = operation,
            stage = PlaybackErrorStage.LIFECYCLE,
            category = PlaybackErrorCategory.REQUEST_STALE,
            code = 0,
            technicalMessage = "Request $requestId superseded by active request $activeRequestId during $operation",
            userMessage = "",
            cause = null,
            sourceType = null,
            recoverable = ErrorRecoverability.STALE,
            recoveryAction = PlaybackRecoveryAction.IGNORE
        )
    }
}
