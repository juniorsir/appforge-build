package com.example.media.progressive

import android.content.Context
import android.os.StatFs
import android.util.Log
import com.example.media.ffmpeg.FFmpegEngine
import com.example.media.ffmpeg.FFmpegProgress
import com.example.media.ffmpeg.FFmpegState
import com.example.media.ffmpeg.H264EncoderSelector
import com.example.media.ffmpeg.SelectedH264Encoder
import com.example.media.playback.PlaybackErrorCategory
import com.example.media.probe.MediaProbeInfo
import com.example.media.storage.MediaUriResolver
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

/**
 * Phase 17.34: Media-generation layer for progressive playback.
 * Continuously produces independently validated/playable media units (HLS MPEG-TS segments)
 * and atomically publishes them to the playback layer.
 */
object ProgressiveMediaGenerator {
    private const val TAG = "ProgressiveMediaGen"
    private const val MIN_FREE_SPACE_BYTES = 50L * 1024L * 1024L // 50MB absolute min

    private val activeSessionIds = ConcurrentHashMap<String, Long>()
    private val activeJobsCancelled = ConcurrentHashMap<String, AtomicBoolean>()
    private val activeJobRequests = ConcurrentHashMap<String, ProgressiveGenerationRequest>()

    // Testing hook to mock unit validator probe during unit tests
    @Volatile
    var mockProbeFuncForTesting: (suspend (Context, android.net.Uri) -> Result<MediaProbeInfo>)? = null

    fun resetForTesting() {
        activeSessionIds.clear()
        activeJobsCancelled.clear()
        activeJobRequests.clear()
        mockProbeFuncForTesting = null
    }

    /**
     * Starts progressive background transcoding for the specified request.
     */
    fun startProgressiveGeneration(
        context: Context,
        request: ProgressiveGenerationRequest,
        scope: CoroutineScope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    ): Pair<StateFlow<ProgressiveGenerationProgress>, SharedFlow<ProgressiveGenerationEvent>> {
        val jobId = request.transcodeJobId
        val isCancelled = AtomicBoolean(false)
        activeJobsCancelled[jobId] = isCancelled
        activeJobRequests[jobId] = request

        val progressStateFlow = MutableStateFlow(
            ProgressiveGenerationProgress(
                playbackRequestId = request.playbackRequestId,
                transcodeJobId = request.transcodeJobId,
                sourceDurationMs = request.totalEstimatedDurationMs
            )
        )
        val eventSharedFlow = MutableSharedFlow<ProgressiveGenerationEvent>(replay = 10, extraBufferCapacity = 64)

        scope.launch {
            executeGenerationJob(
                context = context,
                request = request,
                progressFlow = progressStateFlow,
                eventFlow = eventSharedFlow,
                scope = scope
            )
        }

        return Pair(progressStateFlow.asStateFlow(), eventSharedFlow.asSharedFlow())
    }

    suspend fun cancelJob(jobId: String): Boolean {
        val isCancelledFlag = activeJobsCancelled[jobId]
        if (isCancelledFlag != null) {
            isCancelledFlag.set(true)
        }
        val sessionId = activeSessionIds[jobId]
        Log.i("FALLBACK_TRACE", "[PROGRESSIVE_CANCELLED] jobId=$jobId sessionId=$sessionId")
        val cancelled = if (sessionId != null && sessionId > 0) {
            FFmpegEngine.cancel(sessionId)
        } else {
            true
        }
        activeSessionIds.remove(jobId)
        val req = activeJobRequests.remove(jobId)
        if (req != null) {
            cleanTemporaryFiles(req.outputDir)
        }
        return cancelled
    }

    private suspend fun executeGenerationJob(
        context: Context,
        request: ProgressiveGenerationRequest,
        progressFlow: MutableStateFlow<ProgressiveGenerationProgress>,
        eventFlow: MutableSharedFlow<ProgressiveGenerationEvent>,
        scope: CoroutineScope,
        isFallbackRetry: Boolean = false
    ): Unit = withContext(Dispatchers.IO) {
        val reqId = request.playbackRequestId
        val jobId = request.transcodeJobId
        val outputDir = request.outputDir
        val isCancelled = activeJobsCancelled[jobId] ?: AtomicBoolean(false)

        if (!isFallbackRetry) {
            Log.i("FALLBACK_TRACE", "[PROGRESSIVE_GENERATION_REQUESTED] req=$reqId job=$jobId outputDir=${outputDir.absolutePath}")
            eventFlow.emit(ProgressiveGenerationEvent.GenerationRequested(reqId, jobId, outputDir.absolutePath))
        }

        // 1. Validate request
        val reqValidation = request.validate()
        if (reqValidation.isFailure) {
            val err = reqValidation.exceptionOrNull() ?: IllegalArgumentException("Invalid progressive request")
            Log.e("FALLBACK_TRACE", "[PROGRESSIVE_FAILED] Validation error: ${err.message}")
            progressFlow.value = progressFlow.value.copy(
                state = ProgressiveState.FAILED,
                error = err,
                errorCategory = PlaybackErrorCategory.PROGRESSIVE_UNIT_INVALID
            )
            eventFlow.emit(ProgressiveGenerationEvent.GenerationFailed(reqId, jobId, err, PlaybackErrorCategory.PROGRESSIVE_UNIT_INVALID))
            return@withContext
        }

        // 2. Storage Check
        if (!outputDir.exists()) {
            outputDir.mkdirs()
        }
        val freeBytes = getAvailableSpace(outputDir)
        if (freeBytes < MIN_FREE_SPACE_BYTES) {
            val err = IllegalStateException("Insufficient storage for progressive generation. Available: ${freeBytes / (1024 * 1024)}MB")
            Log.e("FALLBACK_TRACE", "[PROGRESSIVE_FAILED] Storage check failed: ${err.message}")
            progressFlow.value = progressFlow.value.copy(
                state = ProgressiveState.FAILED,
                error = err,
                errorCategory = PlaybackErrorCategory.PROGRESSIVE_STORAGE_FAILED
            )
            eventFlow.emit(ProgressiveGenerationEvent.GenerationFailed(reqId, jobId, err, PlaybackErrorCategory.PROGRESSIVE_STORAGE_FAILED))
            return@withContext
        }

        // 3. Resolve Input URI
        Log.i("FALLBACK_TRACE", "[MEDIA_PERFORMANCE_START] req=$reqId inputUri=${request.inputUri} durationMs=${request.totalEstimatedDurationMs}")
        val resolvedSource = MediaUriResolver.resolveUriForFFmpeg(context, request.inputUri, preferDirectSaf = true)
        if (resolvedSource == null) {
            val err = IllegalArgumentException("Could not resolve input URI for progressive transcoding: ${request.inputUri}")
            Log.e("FALLBACK_TRACE", "[PROGRESSIVE_FAILED] Input URI resolution error")
            progressFlow.value = progressFlow.value.copy(
                state = ProgressiveState.FAILED,
                error = err,
                errorCategory = PlaybackErrorCategory.INPUT_INVALID_URI
            )
            eventFlow.emit(ProgressiveGenerationEvent.GenerationFailed(reqId, jobId, err, PlaybackErrorCategory.INPUT_INVALID_URI))
            return@withContext
        }
        val inputPath = resolvedSource.pathOrSaf

        // 4. Select H.264 Encoder (Contract: 8-bit yuv420p)
        val workload = com.example.media.ThermalStateManager.evaluateWorkload(bufferLeadMs = null, requestId = reqId)
        val w = request.targetWidth ?: 1920
        val h = request.targetHeight ?: 1080
        val fps = request.frameRate ?: 23.98f
        val bitrateKbps = request.videoBitrateKbps ?: H264EncoderSelector.calculateDefaultBitrateKbps(w, h, fps)

        val selectedEncoder = H264EncoderSelector.selectBestH264Encoder(
            context = context,
            targetWidth = w,
            targetHeight = h,
            targetFps = fps,
            targetBitrateKbps = bitrateKbps,
            targetProfile = request.targetProfile,
            targetLevel = request.targetLevel
        )
        if (selectedEncoder == null) {
            val err = IllegalStateException("No compatible H.264 encoder found in build")
            Log.e("FALLBACK_TRACE", "[PROGRESSIVE_FAILED] No compatible H.264 encoder found")
            progressFlow.value = progressFlow.value.copy(
                state = ProgressiveState.FAILED,
                error = err,
                errorCategory = PlaybackErrorCategory.FFMPEG_ENCODER_UNAVAILABLE
            )
            eventFlow.emit(ProgressiveGenerationEvent.GenerationFailed(reqId, jobId, err, PlaybackErrorCategory.FFMPEG_ENCODER_UNAVAILABLE))
            return@withContext
        }
        val encoderName = selectedEncoder.name
        val targetProfile = H264EncoderSelector.mapProfileForEncoder(
            encoderName,
            request.targetProfile ?: selectedEncoder.defaultProfile
        ) ?: selectedEncoder.defaultProfile
        val targetLevel = H264EncoderSelector.sanitizeH264Level(request.targetLevel ?: selectedEncoder.defaultLevel)
        val gop = selectedEncoder.recommendedGop
        val threads = H264EncoderSelector.calculateOptimalThreads(encoderName)

        Log.i("FALLBACK_TRACE", "[OUTPUT_PROFILE] width=$w height=$h fps=$fps bitrate=${bitrateKbps}k profile=$targetProfile level=$targetLevel workload=$workload req=$reqId")
        if (selectedEncoder.isHardware) {
            Log.i("FALLBACK_TRACE", "[PIXEL_PATH] input=hevc_10bit decoderOutput=Surface(GraphicBuffer) intermediate=direct encoderInput=Surface conversion=none(hardware_surface) hardwareFrame=true systemMemoryCopy=false req=$reqId")
        } else {
            Log.i("FALLBACK_TRACE", "[PIXEL_PATH] input=hevc_10bit(yuv420p10le/fmt62) decoderOutput=yuv420p10le intermediate=yuv420p encoderInput=yuv420p conversion=swscale_10to8 hardwareFrame=false systemMemoryCopy=true req=$reqId")
        }
        Log.i("FALLBACK_TRACE", "[ENCODER_THREAD_DECISION] encoder=$encoderName threads=$threads cores=${Runtime.getRuntime().availableProcessors()} policy=BALANCED_THERMAL_SAFE req=$reqId")

        // 4b. Probe audio codec if request audioCodec is default/unspecified to check if source is AAC (copy without re-encoding)
        val shouldCopyAudio = if (request.audioCodec == "copy") {
            true
        } else if (request.audioCodec == "aac") {
            try {
                val inputProbe = if (mockProbeFuncForTesting != null) {
                    mockProbeFuncForTesting!!(context, request.inputUri).getOrNull()
                } else {
                    com.example.media.probe.MediaProbeEngine.probeMedia(context, request.inputUri).getOrNull()
                }
                val primaryAudioCodec = inputProbe?.primaryAudio?.codec?.lowercase()
                val isAac = primaryAudioCodec == "aac" || primaryAudioCodec == "mp4a-40-2"
                Log.i("FALLBACK_TRACE", "[AUDIO_PASSTHROUGH_EVAL] sourceAudioCodec=$primaryAudioCodec isAac=$isAac")
                isAac
            } catch (t: Throwable) {
                Log.w("FALLBACK_TRACE", "[AUDIO_PASSTHROUGH_EVAL] Probe failed: ${t.message}")
                false
            }
        } else {
            false
        }

        // 5. Build FFmpeg Arguments for Segment Generation
        val inputThreads = minOf(Runtime.getRuntime().availableProcessors(), 4).coerceAtLeast(2)
        val argsList = mutableListOf("-y", "-threads", inputThreads.toString(), "-i", inputPath)
        argsList.addAll(listOf("-map", "0:v:0?", "-map", "0:a?", "-sn", "-map_metadata", "-1"))

        // Video options
        argsList.addAll(listOf("-c:v", encoderName))
        if (threads > 0) {
            argsList.addAll(listOf("-threads", threads.toString()))
        }
        
        // Fast scaling filter for software transcoding to ensure >2.5x speed without thermal throttling
        if (!selectedEncoder.isHardware && (w > 1280 || h > 720 || request.targetWidth != null || request.targetHeight != null)) {
            val maxW = request.targetWidth ?: 1280
            val maxH = request.targetHeight ?: 720
            argsList.addAll(listOf("-vf", "scale=w='min($maxW,iw)':h='min($maxH,ih)':force_original_aspect_ratio=decrease,scale=trunc(iw/2)*2:trunc(ih/2)*2:flags=fast_bilinear"))
        }

        if (selectedEncoder.supportsPreset) {
            val chosenPreset = request.preset ?: "ultrafast"
            argsList.addAll(listOf("-preset", chosenPreset))
            if (encoderName == "libx264") {
                argsList.addAll(listOf("-tune", "zerolatency"))
            }
        }
        if (selectedEncoder.supportsCrf && request.crf != null) {
            argsList.addAll(listOf("-crf", request.crf.toString()))
        }
        val safeBitrate = if (!selectedEncoder.isHardware && bitrateKbps > 2500) 2500 else bitrateKbps
        argsList.addAll(listOf("-b:v", "${safeBitrate}k", "-maxrate", "${(safeBitrate * 1.5).toInt()}k", "-bufsize", "${safeBitrate * 2}k"))
        // Explicit GOP to fix "[h264_mediacodec] please set gop_size properly (>= fps)"
        argsList.addAll(listOf("-g", gop.toString(), "-keyint_min", gop.toString()))
        if (encoderName == "libopenh264") {
            argsList.addAll(listOf("-profile:v", targetProfile))
        } else {
            argsList.addAll(listOf("-profile:v", targetProfile, "-level:v", targetLevel))
        }
        argsList.addAll(listOf("-pix_fmt", "yuv420p"))

        // Audio options
        if (shouldCopyAudio) {
            Log.i("FALLBACK_TRACE", "[AUDIO_PASSTHROUGH] Using -c:a copy for progressive HLS output")
            com.example.media.playback.TranscodingLogManager.recordEvent("AUDIO_PASSTHROUGH", "Using -c:a copy for progressive HLS stream")
            argsList.addAll(listOf("-c:a", "copy"))
        } else {
            Log.i("FALLBACK_TRACE", "[AUDIO_TRANSCODE] Using -c:a aac -b:a ${request.audioBitrateKbps ?: 192}k for progressive HLS output")
            argsList.addAll(listOf("-c:a", "aac", "-b:a", "${request.audioBitrateKbps ?: 192}k"))
        }

        // HLS Segment options
        val segmentPattern = File(outputDir, "seg_%05d.ts.tmp").absolutePath
        val playlistFile = File(outputDir, "master_playlist.m3u8")

        argsList.addAll(
            listOf(
                "-f", "hls",
                "-hls_time", request.segmentDurationSec.toString(),
                "-hls_list_size", "0",
                "-hls_segment_type", "mpegts",
                "-hls_flags", "independent_segments",
                "-hls_segment_filename", segmentPattern,
                playlistFile.absolutePath
            )
        )

        val cmdString = argsList.joinToString(" ")
        Log.i("FALLBACK_TRACE", "[PROGRESSIVE_FFMPEG_INVOKE] args=$cmdString")
        com.example.media.playback.TranscodingLogManager.recordCommand(cmdString, reqId)
        com.example.media.playback.TranscodingLogManager.updateTranscodingState(com.example.media.playback.TranscodingLifecycleState.RUNNING, reqId)

        val publishedUnits = mutableListOf<ProgressiveMediaUnit>()
        val validatedIndices = mutableSetOf<Int>()
        var currentPlayableDurationMs = 0L
        val lastTranscodedDurationMs = AtomicLong(0L)

        progressFlow.value = progressFlow.value.copy(
            state = ProgressiveState.GENERATING,
            sourceDurationMs = request.totalEstimatedDurationMs
        )
        if (!isFallbackRetry) {
            eventFlow.emit(ProgressiveGenerationEvent.GenerationStarted(reqId, jobId, -1L))
        }

        // Helper to scan for new completed segments, validate, and atomically publish
        suspend fun scanAndPublishCompletedUnits(isFinalPass: Boolean = false) {
            val tmpFiles = outputDir.listFiles { _, name -> name.startsWith("seg_") && name.endsWith(".ts.tmp") }
                ?.sortedBy { it.name } ?: emptyList()

            for (i in tmpFiles.indices) {
                val tmpFile = tmpFiles[i]
                val indexStr = tmpFile.name.removePrefix("seg_").removeSuffix(".ts.tmp")
                val index = indexStr.toIntOrNull() ?: continue

                if (validatedIndices.contains(index)) continue

                val isReadyToValidate = isFinalPass || (i < tmpFiles.size - 1)
                if (!isReadyToValidate) continue

                Log.i("FALLBACK_TRACE", "[PROGRESSIVE_UNIT_GENERATED] unitIndex=$index tempFile=${tmpFile.name}")
                Log.i("FALLBACK_TRACE", "[HLS_SEGMENT_CREATED] segment=$index tempFile=${tmpFile.name} size=${tmpFile.length()}B")
                com.example.media.playback.TranscodingLogManager.recordEvent("HLS_SEGMENT_CREATED", "segment=$index tempFile=${tmpFile.name} size=${tmpFile.length()}B")
                eventFlow.emit(ProgressiveGenerationEvent.UnitGenerated(reqId, jobId, tmpFile.absolutePath, index))

                // Validate unit against 8-bit H.264 contract
                val validationRes = if (mockProbeFuncForTesting != null) {
                    ProgressiveUnitValidator.validateUnit(context, tmpFile, mockProbeFuncForTesting!!)
                } else {
                    ProgressiveUnitValidator.validateUnit(context, tmpFile)
                }

                if (validationRes.isFailure) {
                    val valErr = validationRes.exceptionOrNull() ?: IllegalStateException("Unit $index failed validation")
                    Log.w("FALLBACK_TRACE", "[PROGRESSIVE_UNIT_INVALID] unitIndex=$index reason=${valErr.message}")
                    continue
                }

                val meta = validationRes.getOrNull()
                val unitDurationMs = meta?.durationMs ?: (request.segmentDurationSec * 1000L)

                // Atomic publish: rename seg_XXXXX.ts.tmp -> seg_XXXXX.ts
                val publishedFile = File(outputDir, "seg_${String.format("%05d", index)}.ts")
                val renamed = tmpFile.renameTo(publishedFile)
                if (!renamed) {
                    Log.w("FALLBACK_TRACE", "[PROGRESSIVE_OUTPUT_FAILED] Failed to atomically rename ${tmpFile.name} to ${publishedFile.name}")
                    continue
                }

                val startMs = currentPlayableDurationMs
                val endMs = startMs + unitDurationMs
                val unit = ProgressiveMediaUnit(
                    index = index,
                    file = publishedFile,
                    durationMs = unitDurationMs,
                    startTimestampMs = startMs,
                    endTimestampMs = endMs,
                    sizeBytes = publishedFile.length(),
                    isValidated = true
                )

                validatedIndices.add(index)
                publishedUnits.add(unit)
                currentPlayableDurationMs += unitDurationMs

                val livePlaylistFile = File(outputDir, "live_playlist.m3u8")
                val livePlaylistUri = android.net.Uri.fromFile(livePlaylistFile)
                updatePublishedPlaylist(outputDir, publishedUnits, isFinal = isFinalPass, targetDurationSec = request.segmentDurationSec)

                Log.i("FALLBACK_TRACE", "[PROGRESSIVE_UNIT_PUBLISHED] unit=$index duration=${unitDurationMs}ms totalPlayable=${currentPlayableDurationMs}ms file=${publishedFile.name}")
                Log.i("FALLBACK_TRACE", "[HLS_SEGMENT_PUBLISHED] segment=$index duration=${unitDurationMs}ms totalPlayable=${currentPlayableDurationMs}ms file=${publishedFile.name}")
                Log.i("FALLBACK_TRACE", "[HLS_SEGMENT_FINALIZED] segment=$index duration=${unitDurationMs}ms size=${publishedFile.length()}B file=${publishedFile.name}")
                Log.i("FALLBACK_TRACE", "[HLS_OUTPUT_STATE] totalSegments=${publishedUnits.size} totalPlayable=${currentPlayableDurationMs}ms")
                Log.i("FALLBACK_TRACE", "[PROGRESSIVE_PLAYABLE_DURATION] totalPlayable=${currentPlayableDurationMs}ms")
                com.example.media.playback.TranscodingLogManager.recordEvent(
                    "HLS_SEGMENT_PUBLISHED",
                    "segment=$index duration=${unitDurationMs}ms totalPlayable=${currentPlayableDurationMs}ms file=${publishedFile.name}"
                )

                eventFlow.emit(ProgressiveGenerationEvent.UnitPublished(reqId, jobId, unit, currentPlayableDurationMs))
                eventFlow.emit(ProgressiveGenerationEvent.PlayableDurationUpdated(reqId, jobId, currentPlayableDurationMs))

                progressFlow.value = progressFlow.value.copy(
                    playableDurationMs = currentPlayableDurationMs,
                    publishedUnitsCount = publishedUnits.size,
                    publishedUnits = publishedUnits.toList(),
                    playlistFile = livePlaylistFile,
                    playlistUri = livePlaylistUri
                )
            }
        }

        val backend: VideoEncoderBackend = if (selectedEncoder.isHardware && NativeMediaCodecProbe.probeNativeH264Encoder(w, h, fps, bitrateKbps) != null) {
            AndroidMediaCodecH264Backend(selectedEncoder.name)
        } else {
            FfmpegOpenH264Backend()
        }

        var lastAdvancementWallTime = System.currentTimeMillis()
        var lastReportedTimeMs = 0L

        val sessionId = backend.executeTranscode(
            context = context,
            request = request,
            outputDir = outputDir,
            argsList = argsList,
            onProgress = { progress ->
                if (!isCancelled.get() && activeJobsCancelled[jobId]?.get() != true) {
                    val now = System.currentTimeMillis()
                    val currentTimeMs = progress.currentTimestampMs
                    Log.d("FALLBACK_TRACE", "[TRANSCODING_STALL_CHECK] currentTimeMs=$currentTimeMs lastAdvancementDeltaMs=${now - lastAdvancementWallTime}")
                    if (currentTimeMs > lastReportedTimeMs) {
                        lastAdvancementWallTime = now
                        lastReportedTimeMs = currentTimeMs
                    } else if (now - lastAdvancementWallTime > 6000L && progress.progressPercentage != null && progress.progressPercentage < 99f) {
                        Log.w(
                            "FALLBACK_TRACE",
                            "[TRANSCODING_STALL_DETECTED] mediaTimeMs=$currentTimeMs wallTimeDeltaMs=${now - lastAdvancementWallTime} speed=${progress.speed}x fps=${progress.fps} encoder=$encoderName"
                        )
                        Log.w(
                            "FALLBACK_TRACE",
                            "[TRANSCODING_STALL_TRACE] Transcoding stall detected at mediaTimeMs=$currentTimeMs wallTimeDeltaMs=${now - lastAdvancementWallTime} speed=${progress.speed}x fps=${progress.fps} encoder=$encoderName publishedUnits=${publishedUnits.size}"
                        )
                        com.example.media.playback.TranscodingLogManager.recordEvent(
                            "TRANSCODING_STALL_TRACE",
                            "mediaTimeMs=$currentTimeMs wallTimeDeltaMs=${now - lastAdvancementWallTime} speed=${progress.speed}x fps=${progress.fps} encoder=$encoderName",
                            reqId
                        )
                    }

                    lastTranscodedDurationMs.set(progress.currentTimestampMs)
                    Log.i("FALLBACK_TRACE", "[TRANSCODING_HEARTBEAT] sessionId=${progress.sessionId} mediaTimeMs=${progress.currentTimestampMs} speed=${progress.speed}x fps=${progress.fps} bitrate=${progress.bitrateKbps}k state=${progress.state}")
                    Log.i("FALLBACK_TRACE", "[TRANSCODING_MEDIA_TIME] current=${progress.currentTimestampMs}ms total=${progress.totalDurationMs}ms progressPct=${progress.progressPercentage}%")
                    Log.i("FALLBACK_TRACE", "[TRANSCODING_PERFORMANCE] req=$reqId fps=${progress.fps} speed=${progress.speed}x transcodedMs=${progress.currentTimestampMs} playableMs=$currentPlayableDurationMs")
                    Log.d("FALLBACK_TRACE", "[PROGRESSIVE_PROGRESS] time=${progress.currentTimestampMs}ms pct=${progress.progressPercentage}% speed=${progress.speed}x")
                    
                    progressFlow.value = progressFlow.value.copy(
                        sessionId = progress.sessionId,
                        transcodedDurationMs = progress.currentTimestampMs,
                        progressPercentage = progress.progressPercentage ?: 0.0f,
                        transcodingSpeed = progress.speed.toFloat(),
                        fps = progress.fps,
                        outputSizeBytes = progress.outputSizeBytes,
                        bitrateKbps = progress.bitrateKbps,
                        latestLogLine = progress.latestLogLine
                    )
                    scope.launch {
                        eventFlow.emit(ProgressiveGenerationEvent.ProgressUpdated(reqId, jobId, progressFlow.value))
                        progress.latestLogLine?.let {
                            eventFlow.emit(ProgressiveGenerationEvent.LogReceived(reqId, jobId, it))
                        }
                        scanAndPublishCompletedUnits(isFinalPass = false)
                    }
                } else if (activeJobsCancelled[jobId]?.get() == true) {
                    Log.w("FALLBACK_TRACE", "[PROGRESSIVE_STALE_CALLBACK] req=$reqId job=$jobId dropped")
                }
            },
            onComplete = { result ->
                activeSessionIds.remove(jobId)
                activeJobRequests.remove(jobId)

                scope.launch {
                    if (isCancelled.get()) {
                        cleanTemporaryFiles(outputDir)
                        progressFlow.value = progressFlow.value.copy(state = ProgressiveState.CANCELLED)
                        eventFlow.emit(ProgressiveGenerationEvent.GenerationCancelled(reqId, jobId))
                        Log.i("FALLBACK_TRACE", "[PROGRESSIVE_CANCELLED] Job $jobId clean exit")
                        return@launch
                    }

                    if (result.isSuccess) {
                        scanAndPublishCompletedUnits(isFinalPass = true)

                        val finalUnits = publishedUnits.toList()
                        progressFlow.value = progressFlow.value.copy(
                            state = ProgressiveState.COMPLETED,
                            progressPercentage = 100.0f,
                            playableDurationMs = currentPlayableDurationMs,
                            publishedUnits = finalUnits,
                            publishedUnitsCount = finalUnits.size
                        )
                        Log.i("FALLBACK_TRACE", "[PROGRESSIVE_COMPLETED] req=$reqId job=$jobId totalUnits=${finalUnits.size} totalPlayable=${currentPlayableDurationMs}ms")
                        Log.i("FALLBACK_TRACE", "[MEDIA_PERFORMANCE_RESULT] req=$reqId encoder=$encoderName isHardware=${selectedEncoder.isHardware} totalUnits=${finalUnits.size} totalPlayableMs=$currentPlayableDurationMs status=SUCCESS")
                        eventFlow.emit(ProgressiveGenerationEvent.GenerationCompleted(reqId, jobId, finalUnits.size, currentPlayableDurationMs))
                    } else {
                        // Check if this was a hardware encoder runtime failure before producing any units
                        if (selectedEncoder.isHardware && publishedUnits.isEmpty() && !isFallbackRetry) {
                            val errorSnippet = result.output.take(250)
                            Log.w(
                                "FALLBACK_TRACE",
                                "[HARDWARE_ENCODER_RUNTIME_FAILURE] encoder=${selectedEncoder.name} error=$errorSnippet"
                            )
                            H264EncoderSelector.quarantineEncoder(
                                encoderName = selectedEncoder.name,
                                reason = "HARDWARE_ENCODER_RUNTIME_FAILURE: $errorSnippet"
                            )
                            Log.i(
                                "FALLBACK_TRACE",
                                "[ENCODER_FALLBACK] from=${selectedEncoder.name} to=libopenh264 reason=HARDWARE_ENCODER_RUNTIME_FAILURE"
                            )
                            com.example.media.playback.TranscodingLogManager.recordEvent(
                                "ENCODER_FALLBACK",
                                "from=${selectedEncoder.name} to=libopenh264 reason=HARDWARE_ENCODER_RUNTIME_FAILURE"
                            )

                            cleanTemporaryFiles(outputDir)

                            // Seamlessly retry with software fallback (libopenh264)
                            executeGenerationJob(
                                context = context,
                                request = request,
                                progressFlow = progressFlow,
                                eventFlow = eventFlow,
                                scope = scope,
                                isFallbackRetry = true
                            )
                            return@launch
                        }

                        cleanTemporaryFiles(outputDir)
                        val err = Exception(result.output)
                        Log.e("FALLBACK_TRACE", "[PROGRESSIVE_FAILED] req=$reqId job=$jobId FFmpeg error: ${result.output}")
                        progressFlow.value = progressFlow.value.copy(
                            state = ProgressiveState.FAILED,
                            error = err,
                            errorCategory = PlaybackErrorCategory.PROGRESSIVE_FFMPEG_FAILED
                        )
                        eventFlow.emit(ProgressiveGenerationEvent.GenerationFailed(reqId, jobId, err, PlaybackErrorCategory.PROGRESSIVE_FFMPEG_FAILED))
                    }
                }
            },
            isCancelled = { isCancelled.get() }
        )

        activeSessionIds[jobId] = sessionId
        Log.i("FALLBACK_TRACE", "[PROGRESSIVE_PROCESS_STARTED] req=$reqId job=$jobId sessionId=$sessionId")
    }

    private fun updatePublishedPlaylist(
        outputDir: File,
        publishedUnits: List<ProgressiveMediaUnit>,
        isFinal: Boolean,
        targetDurationSec: Int
    ) {
        if (publishedUnits.isEmpty()) return
        val playlistFile = File(outputDir, "live_playlist.m3u8")
        val tempPlaylistFile = File(outputDir, "live_playlist.m3u8.tmp")

        val sb = StringBuilder()
        sb.append("#EXTM3U\n")
        sb.append("#EXT-X-VERSION:3\n")
        val maxUnitDurationSec = publishedUnits.maxOfOrNull { (it.durationMs / 1000.0).toInt() + 1 } ?: targetDurationSec
        sb.append("#EXT-X-TARGETDURATION:$maxUnitDurationSec\n")
        sb.append("#EXT-X-MEDIA-SEQUENCE:0\n")

        for (unit in publishedUnits) {
            val durationSecStr = String.format(java.util.Locale.US, "%.3f", unit.durationMs / 1000.0)
            sb.append("#EXTINF:$durationSecStr,\n")
            sb.append("${unit.file.name}\n")
        }

        if (isFinal) {
            sb.append("#EXT-X-ENDLIST\n")
        }

        try {
            tempPlaylistFile.writeText(sb.toString())
            tempPlaylistFile.renameTo(playlistFile)
            Log.i("FALLBACK_TRACE", "[HLS_PLAYLIST_UPDATED] segments=${publishedUnits.size} targetDuration=${maxUnitDurationSec}s isFinal=$isFinal playlist=${playlistFile.name}")
            com.example.media.playback.TranscodingLogManager.recordEvent(
                "HLS_PLAYLIST_UPDATED",
                "segments=${publishedUnits.size} targetDuration=${maxUnitDurationSec}s isFinal=$isFinal playlist=${playlistFile.name}"
            )
            Log.d(TAG, "[PROGRESSIVE_PLAYLIST_UPDATED] units=${publishedUnits.size} isFinal=$isFinal path=${playlistFile.absolutePath}")
        } catch (e: Exception) {
            Log.w(TAG, "Failed to update published playlist: ${e.message}")
        }
    }

    private fun cleanTemporaryFiles(outputDir: File) {
        try {
            outputDir.listFiles { _, name -> name.endsWith(".tmp") }?.forEach { it.delete() }
        } catch (_: Exception) {}
    }

    private fun getAvailableSpace(dir: File): Long {
        return try {
            val stat = StatFs(dir.absolutePath)
            val available = stat.availableBlocksLong * stat.blockSizeLong
            if (available <= 0L) {
                val free = dir.freeSpace
                if (free > 0L) free else (500L * 1024 * 1024)
            } else {
                available
            }
        } catch (_: Exception) {
            val free = dir.freeSpace
            if (free > 0L) free else (500L * 1024 * 1024)
        }
    }
}
