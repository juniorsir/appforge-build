package com.example.media.progressive

import android.content.Context
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import java.io.File
import java.util.concurrent.ConcurrentHashMap

/**
 * Phase 17.34: High-level manager coordinating progressive media generation jobs,
 * deduplication, cancellation, and lifecycle tracking.
 */
object ProgressiveJobManager {
    private const val TAG = "ProgressiveJobManager"

    private val activeJobFlows = ConcurrentHashMap<String, Pair<StateFlow<ProgressiveGenerationProgress>, SharedFlow<ProgressiveGenerationEvent>>>()
    private val activeJobIds = ConcurrentHashMap<String, String>()

    @Synchronized
    fun getOrStartProgressiveJob(
        context: Context,
        request: ProgressiveGenerationRequest,
        scope: CoroutineScope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    ): Pair<StateFlow<ProgressiveGenerationProgress>, SharedFlow<ProgressiveGenerationEvent>> {
        val cacheKey = request.transcodeJobId

        activeJobFlows[cacheKey]?.let {
            Log.i("FALLBACK_TRACE", "[PROGRESSIVE_DUPLICATE_GUARD] Joined existing progressive job for $cacheKey")
            return it
        }

        val pair = ProgressiveMediaGenerator.startProgressiveGeneration(
            context = context,
            request = request,
            scope = scope
        )

        activeJobFlows[cacheKey] = pair
        activeJobIds[cacheKey] = request.transcodeJobId
        return pair
    }

    suspend fun cancelJob(transcodeJobId: String): Boolean {
        activeJobFlows.remove(transcodeJobId)
        activeJobIds.remove(transcodeJobId)
        return ProgressiveMediaGenerator.cancelJob(transcodeJobId)
    }

    suspend fun cancelAll() {
        for (jobId in activeJobIds.values) {
            ProgressiveMediaGenerator.cancelJob(jobId)
        }
        activeJobFlows.clear()
        activeJobIds.clear()
    }

    fun resetForTesting() {
        activeJobFlows.clear()
        activeJobIds.clear()
    }
}
