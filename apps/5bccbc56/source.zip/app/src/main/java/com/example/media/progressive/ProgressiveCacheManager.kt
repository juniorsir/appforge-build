package com.example.media.progressive

import android.content.Context
import android.net.Uri
import android.util.Log
import java.io.File
import java.security.MessageDigest
import java.util.concurrent.ConcurrentHashMap

/**
 * Phase 17.38: Progressive Cache Manager.
 * Governs caching, validation, persistence, and safe reuse of fully completed progressive media streams.
 * Strict Contract: Only 100% completed, validated streams containing #EXT-X-ENDLIST and valid segment files
 * are permitted to become persistent cache entries. Partial or unvalidated transcodes are rejected.
 */
object ProgressiveCacheManager {
    private const val TAG = "ProgressiveCacheManager"

    private val registeredCaches = ConcurrentHashMap<String, File>()

    fun generateCacheKey(inputUri: Uri, totalDurationMs: Long = 0L, targetProfile: String? = null): String {
        val sb = StringBuilder()
        sb.append(inputUri.toString()).append("|")
        sb.append(totalDurationMs).append("|")
        if (targetProfile != null) {
            sb.append(targetProfile).append("|")
        }
        sb.append("hls_v1")

        val hash = MessageDigest.getInstance("SHA-256")
            .digest(sb.toString().toByteArray())
            .joinToString("") { "%02x".format(it) }

        return hash.take(16)
    }

    /**
     * Checks if a given directory contains a complete, validated progressive HLS stream.
     */
    fun isCacheValid(dir: File, expectedMinDurationMs: Long = 0L): Boolean {
        val cacheKey = dir.name
        if (!dir.exists() || !dir.isDirectory) {
            Log.i(TAG, "[PROGRESSIVE_CACHE_TRACE] key=$cacheKey result=MISS (dir not found)")
            return false
        }

        // Rule 1: No temporary files are allowed in a valid cache
        val tmpFiles = dir.listFiles { _, name -> name.endsWith(".tmp") }
        if (!tmpFiles.isNullOrEmpty()) {
            Log.w(TAG, "[PROGRESSIVE_CACHE_TRACE] key=$cacheKey result=HIT_INVALID (found ${tmpFiles.size} temp files)")
            return false
        }

        // Rule 2: live_playlist.m3u8 or master_playlist.m3u8 must exist
        val playlistFile = File(dir, "live_playlist.m3u8").takeIf { it.exists() }
            ?: File(dir, "master_playlist.m3u8").takeIf { it.exists() }

        if (playlistFile == null || playlistFile.length() == 0L) {
            Log.w(TAG, "[PROGRESSIVE_CACHE_TRACE] key=$cacheKey result=HIT_INVALID (missing or empty playlist)")
            return false
        }

        // Rule 3: Playlist must be complete with #EXT-X-ENDLIST
        val content = try {
            playlistFile.readText()
        } catch (e: Exception) {
            Log.e(TAG, "[PROGRESSIVE_CACHE_TRACE] key=$cacheKey result=HIT_INVALID (read error: ${e.message})")
            return false
        }

        if (!content.contains("#EXTM3U") || !content.contains("#EXT-X-ENDLIST")) {
            Log.w(TAG, "[PROGRESSIVE_CACHE_TRACE] key=$cacheKey result=HIT_INVALID (incomplete playlist: missing #EXT-X-ENDLIST)")
            return false
        }

        // Rule 4: All referenced segment files must exist and have size > 0
        val segmentLines = content.lines().filter { it.trim().endsWith(".ts") }
        if (segmentLines.isEmpty()) {
            Log.w(TAG, "[PROGRESSIVE_CACHE_TRACE] key=$cacheKey result=HIT_INVALID (no segment files referenced)")
            return false
        }

        for (segLine in segmentLines) {
            val segFile = File(dir, segLine.trim())
            if (!segFile.exists() || segFile.length() == 0L) {
                Log.w(TAG, "[PROGRESSIVE_CACHE_TRACE] key=$cacheKey result=HIT_INVALID (segment ${segFile.name} missing or empty)")
                return false
            }
        }

        // Rule 5: Check duration if expected
        if (expectedMinDurationMs > 0L) {
            var parsedDurationSec = 0.0
            for (line in content.lines()) {
                if (line.startsWith("#EXTINF:")) {
                    val durStr = line.removePrefix("#EXTINF:").substringBefore(",")
                    durStr.toDoubleOrNull()?.let { parsedDurationSec += it }
                }
            }
            val parsedDurationMs = (parsedDurationSec * 1000.0).toLong()
            if (parsedDurationMs < (expectedMinDurationMs * 0.9)) { // Allow 10% tolerance for rounding/timestamps
                Log.w(TAG, "[PROGRESSIVE_CACHE_TRACE] key=$cacheKey result=HIT_INVALID (duration $parsedDurationMs < expected $expectedMinDurationMs)")
                return false
            }
        }

        Log.i(TAG, "[PROGRESSIVE_CACHE_TRACE] key=$cacheKey result=HIT_VALID (segments=${segmentLines.size})")
        return true
    }

    /**
     * Registers a validated completed progressive output directory as a cache entry.
     */
    fun registerCompletedCache(
        context: Context,
        requestId: String,
        mediaKey: String,
        outputDir: File,
        expectedDurationMs: Long = 0L
    ): Boolean {
        if (!isCacheValid(outputDir, expectedDurationMs)) {
            Log.w(TAG, "[PROGRESSIVE_CACHE_TRACE] key=$mediaKey result=REGISTRATION_REJECTED (output validation failed)")
            return false
        }

        registeredCaches[mediaKey] = outputDir
        Log.i(TAG, "[PROGRESSIVE_CACHE_TRACE] key=$mediaKey result=REGISTERED path=${outputDir.absolutePath}")
        return true
    }

    /**
     * Retrieves completed cache directory for a given mediaKey if valid.
     */
    fun getCompletedCache(context: Context, mediaKey: String, expectedDurationMs: Long = 0L): File? {
        val memoryEntry = registeredCaches[mediaKey]
        if (memoryEntry != null && isCacheValid(memoryEntry, expectedDurationMs)) {
            Log.i(TAG, "[PROGRESSIVE_CACHE_TRACE] key=$mediaKey result=HIT_MEMORY path=${memoryEntry.absolutePath}")
            return memoryEntry
        }

        // Check storage for directory named progressive_cache_<mediaKey>
        val diskCacheDir = File(context.cacheDir, "progressive_cache_$mediaKey")
        if (isCacheValid(diskCacheDir, expectedDurationMs)) {
            registeredCaches[mediaKey] = diskCacheDir
            Log.i(TAG, "[PROGRESSIVE_CACHE_TRACE] key=$mediaKey result=HIT_DISK path=${diskCacheDir.absolutePath}")
            return diskCacheDir
        }

        return null
    }

    /**
     * Clears in-memory cache registry.
     */
    fun resetForTesting() {
        registeredCaches.clear()
    }
}
