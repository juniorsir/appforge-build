package com.example.media

import android.media.MediaCodecInfo
import android.os.Build

/**
 * Android H.264 / AVC Hardware & Software Encoder Capability Model.
 * Completely independent from decoder capabilities.
 */
data class AndroidEncoderInfo(
    val name: String,
    val mimeType: String = "video/avc",
    val isEncoder: Boolean = true,
    val isHardware: Boolean = false,
    val isSoftware: Boolean = false,
    val isVendor: Boolean = false,
    val minWidth: Int = 16,
    val maxWidth: Int = 1920,
    val minHeight: Int = 16,
    val maxHeight: Int = 1080,
    val widthAlignment: Int = 2,
    val heightAlignment: Int = 2,
    val supportedColorFormats: List<Int> = emptyList(),
    val colorFormatNames: List<String> = emptyList(),
    val minBitrate: Int = 0,
    val maxBitrate: Int = 0,
    val minFps: Double = 0.0,
    val maxFps: Double = 0.0,
    val supportedProfiles: List<String> = emptyList(),
    val supportedLevels: List<String> = emptyList(),
    val maxSupportedInstances: Int = 1
)

enum class EncoderProbeStage {
    DISCOVERY,
    BASIC_INIT,
    PIXEL_FORMAT,
    RESOLUTION,
    FRAME_RATE,
    BITRATE,
    PROFILE_LEVEL,
    GOP_CONFIG,
    RUNTIME_TRANSCODE
}

data class EncoderProbeResult(
    val encoderName: String,
    val stage: EncoderProbeStage,
    val isSuccess: Boolean,
    val returnCode: Int? = null,
    val errorMessage: String? = null,
    val testedResolution: String? = null,
    val testedProfile: String? = null,
    val testedLevel: String? = null,
    val testedFps: Float? = null,
    val testedBitrateKbps: Int? = null,
    val testedGop: Int? = null,
    val logSnippet: String? = null
)

data class EncoderQuarantineRecord(
    val encoderName: String,
    val reason: String,
    val timestampMs: Long = System.currentTimeMillis(),
    val resolutionKey: String? = null,
    val profileKey: String? = null
)

data class AndroidEncoderCapabilityReport(
    val encoders: List<AndroidEncoderInfo> = emptyList(),
    val hasHardwareAvcEncoder: Boolean = false,
    val preferredHwEncoderName: String? = null,
    val preferredSwEncoderName: String? = null
) {
    fun toFormattedReport(): String {
        val sb = StringBuilder()
        sb.appendLine("==========================================")
        sb.appendLine("   ANDROID H.264 ENCODER CAPABILITIES    ")
        sb.appendLine("==========================================")
        sb.appendLine("Hardware AVC Encoder Available: ${if (hasHardwareAvcEncoder) "YES ($preferredHwEncoderName)" else "NO"}")
        sb.appendLine("Software AVC Encoder Available: ${if (preferredSwEncoderName != null) "YES ($preferredSwEncoderName)" else "NO"}")
        sb.appendLine("Total AVC Encoders Found: ${encoders.size}")
        
        for (e in encoders) {
            sb.appendLine("\n[ENCODER: ${e.name}]")
            sb.appendLine("  Classification: ${if (e.isHardware) "HARDWARE" else if (e.isSoftware) "SOFTWARE" else "UNKNOWN"} (isVendor=${e.isVendor})")
            sb.appendLine("  Max Resolution: ${e.maxWidth}x${e.maxHeight} (Alignment: ${e.widthAlignment}x${e.heightAlignment})")
            sb.appendLine("  FPS Range: ${e.minFps.toInt()} - ${e.maxFps.toInt()} fps")
            sb.appendLine("  Bitrate Range: ${e.minBitrate / 1000}k - ${e.maxBitrate / 1000}k bps")
            sb.appendLine("  Supported Profiles: ${if (e.supportedProfiles.isEmpty()) "UNKNOWN" else e.supportedProfiles.joinToString(", ")}")
            sb.appendLine("  Supported Levels: ${if (e.supportedLevels.isEmpty()) "UNKNOWN" else e.supportedLevels.joinToString(", ")}")
            sb.appendLine("  Supported Color Formats: ${if (e.colorFormatNames.isEmpty()) "UNKNOWN" else e.colorFormatNames.joinToString(", ")}")
        }
        return sb.toString().trimEnd()
    }
}
