package com.example.media.ffmpeg

enum class FFmpegState {
    IDLE,
    STARTING,
    RUNNING,
    COMPLETED,
    FAILED,
    CANCELLED,
    VALIDATING
}

data class FFmpegProgress(
    val sessionId: Long = 0L,
    val state: FFmpegState = FFmpegState.IDLE,
    val progressPercentage: Float? = 0f,
    val currentTimestampMs: Long = 0L,
    val totalDurationMs: Long = 0L,
    val speed: Double = 0.0,
    val fps: Double = 0.0,
    val outputSizeBytes: Long = 0L,
    val latestLogLine: String? = null,
    val bitrateKbps: Double = 0.0,
    val estimatedRemainingTimeMs: Long = 0L,
    val error: Throwable? = null,
    val logOutput: String? = null
)
