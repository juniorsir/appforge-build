package com.example.media.progressive

import android.net.Uri
import java.io.File

data class ProgressiveGenerationRequest(
    val playbackRequestId: String,
    val transcodeJobId: String,
    val inputUri: Uri,
    val outputDir: File,
    val targetWidth: Int? = null,
    val targetHeight: Int? = null,
    val frameRate: Float? = null,
    val videoBitrateKbps: Int? = null,
    val targetProfile: String? = null,
    val targetLevel: String? = null,
    val audioCodec: String = "copy",
    val audioBitrateKbps: Int? = null,
    val preset: String? = null,
    val crf: Int? = null,
    val segmentDurationSec: Int = 4,
    val minInitialSegments: Int = 2,
    val totalEstimatedDurationMs: Long = 0L,
    val bitDepth: Int = 8,
    val pixelFormat: String = "yuv420p"
) {
    fun validate(): Result<Unit> {
        if (transcodeJobId.isBlank()) return Result.failure(IllegalArgumentException("Job ID cannot be blank"))
        if (playbackRequestId.isBlank()) return Result.failure(IllegalArgumentException("Request ID cannot be blank"))
        if (!outputDir.exists() && !outputDir.mkdirs()) return Result.failure(IllegalArgumentException("Cannot create output dir"))
        
        if (bitDepth != 8) return Result.failure(IllegalArgumentException("Only 8-bit output is supported for progressive HLS"))
        if (pixelFormat != "yuv420p") return Result.failure(IllegalArgumentException("Only yuv420p pixel format is supported for progressive HLS"))
        if (segmentDurationSec <= 0) return Result.failure(IllegalArgumentException("Segment duration must be greater than 0"))
        if (minInitialSegments <= 0) return Result.failure(IllegalArgumentException("Min initial segments must be greater than 0"))
        
        return Result.success(Unit)
    }
}
