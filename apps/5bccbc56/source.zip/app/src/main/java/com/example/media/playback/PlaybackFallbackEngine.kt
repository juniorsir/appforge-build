package com.example.media.playback

import android.content.Context
import android.net.Uri
import android.util.Log
import androidx.media3.common.ParserException
import androidx.media3.common.PlaybackException
import androidx.media3.exoplayer.mediacodec.MediaCodecRenderer
import androidx.media3.exoplayer.source.UnrecognizedInputFormatException
import com.example.media.DecoderCapabilityManager
import com.example.media.ffmpeg.FFmpegProgress
import com.example.media.operations.MediaConversionRequest
import com.example.media.operations.MediaConverter
import com.example.media.operations.RemuxEngine
import com.example.media.probe.MediaProbeEngine
import com.example.media.probe.MediaProbeInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.io.File

object PlaybackFallbackEngine {
    private const val TAG = "PlaybackFallbackEngine"

    suspend fun evaluatePlaybackStrategy(
        context: Context,
        uri: Uri,
        playbackError: PlaybackException? = null,
        probeInfoOverride: MediaProbeInfo? = null
    ): PlaybackCompatibilityResult = withContext(Dispatchers.IO) {
        com.example.media.preview.FrpPreviewEngine.setActivePlaybackSource(uri, uri.path)
        
        val probeInfo = probeInfoOverride ?: run {
            val probeResult = MediaProbeEngine.probeMedia(context, uri)
            probeResult.getOrNull()
        }

        if (probeInfo == null) {
            val isContainerErr = playbackError is UnrecognizedInputFormatException || playbackError?.cause is ParserException
            return@withContext if (isContainerErr) {
                PlaybackCompatibilityResult(
                    strategy = PlaybackStrategy.REMUX_REQUIRED,
                    reason = "Unrecognized container format error encountered; remuxing to standard MP4",
                    containerFormat = "unknown",
                    videoCodec = "unknown",
                    audioCodec = "unknown",
                    requiresRemux = true,
                    isContainerSupported = false,
                    videoAction = "copy",
                    audioAction = "copy",
                    qualityImpact = "None (Lossless Stream Copy)",
                    estimatedSpeed = "Extremely fast"
                )
            } else {
                PlaybackCompatibilityResult(
                    strategy = PlaybackStrategy.DIRECT_HARDWARE,
                    reason = "Probe unavailable; attempting direct Media3/ExoPlayer hardware playback",
                    containerFormat = "unknown",
                    videoCodec = "unknown",
                    audioCodec = "unknown"
                )
            }
        }

        val format = probeInfo.format.lowercase()
        val video = probeInfo.primaryVideo
        val audio = probeInfo.primaryAudio

        val videoCodec = video?.codec?.lowercase() ?: "none"
        val audioCodec = audio?.codec?.lowercase() ?: "none"
        val videoProfile = video?.profile?.lowercase() ?: ""
        val bitDepth = video?.bitDepth ?: 8

        Log.d(TAG, "Evaluating evidence-based playback: format=$format, video=$videoCodec ($videoProfile, ${bitDepth}-bit), audio=$audioCodec, error=${playbackError?.errorCodeName}")

        // 1. Check Container Compatibility
        val isMatroskaOrWebm = format.contains("matroska") || format.contains("webm")
        val isMp4OrMov = format.contains("mp4") || format.contains("mov") || format.contains("m4a") || format.contains("3gp")
        val isTsOrMpeg = format.contains("mpegts") || format.contains("ts")
        val isAudioOnlyContainer = format.contains("mp3") || format.contains("aac") || format.contains("flac") || format.contains("ogg") || format.contains("wav")
        
        var isContainerSupported = (isMatroskaOrWebm || isMp4OrMov || isTsOrMpeg || isAudioOnlyContainer)
        
        // If an explicit container demuxing error was thrown during playback
        if (playbackError is UnrecognizedInputFormatException || 
            playbackError?.cause is ParserException ||
            playbackError?.cause is UnrecognizedInputFormatException ||
            playbackError?.errorCode == PlaybackException.ERROR_CODE_PARSING_CONTAINER_UNSUPPORTED ||
            playbackError?.errorCode == PlaybackException.ERROR_CODE_PARSING_CONTAINER_MALFORMED ||
            playbackError?.cause is java.io.EOFException) {
            isContainerSupported = false
        }

        // 2. Check Video Codec Hardware / Software Support
        val hasVideo = video != null && videoCodec != "none"
        var isVideoSupported = true
        if (hasVideo) {
            val vAssessment = try {
                DecoderCapabilityManager.assessVideoDecoder(
                    codec = videoCodec,
                    requestedProfile = video?.profile,
                    requestedLevel = video?.level,
                    bitDepth = video?.bitDepth ?: 8,
                    pixelFormat = video?.pixelFormat,
                    width = video?.width ?: 0,
                    height = video?.height ?: 0,
                    frameRate = video?.frameRate ?: 0f
                )
            } catch (_: Throwable) { null }

            val isStandardHwVideo = videoCodec in setOf("h264", "avc", "avc1", "hevc", "h265", "hev1", "hvc1", "vp8", "vp9", "av01", "av1")
            
            // Check for 10-bit video on hardware that only supports 8-bit or unsupported profile
            val is10BitUnsupported = bitDepth > 8 && (vAssessment?.bitDepthSupported == false || vAssessment?.profileSupported == false || videoProfile.contains("high 10") || videoProfile.contains("high10"))
            
            isVideoSupported = when {
                vAssessment != null && vAssessment.deviceDecoderName != null -> vAssessment.isSupported && !is10BitUnsupported
                isStandardHwVideo && !is10BitUnsupported -> true
                else -> false
            }

            // If video decoder init or decoding failed during playback
            if (playbackError != null) {
                val errorMsg = playbackError.message?.lowercase() ?: ""
                val causeMsg = playbackError.cause?.message?.lowercase() ?: ""
                val isExplicitAudioError = errorMsg.contains("audio") || causeMsg.contains("audio") ||
                        errorMsg.contains("eac3") || causeMsg.contains("eac3") ||
                        errorMsg.contains("ac3") || causeMsg.contains("ac3") ||
                        errorMsg.contains("dts") || causeMsg.contains("dts") ||
                        playbackError.errorCode == PlaybackException.ERROR_CODE_AUDIO_TRACK_INIT_FAILED ||
                        playbackError.errorCode == PlaybackException.ERROR_CODE_AUDIO_TRACK_WRITE_FAILED
                
                val isExplicitVideoError = errorMsg.contains("video") || causeMsg.contains("video") ||
                        errorMsg.contains("avc") || causeMsg.contains("avc") ||
                        errorMsg.contains("hevc") || causeMsg.contains("hevc") ||
                        errorMsg.contains("vp9") || causeMsg.contains("vp9") ||
                        errorMsg.contains("c2.android.avc") || errorMsg.contains("c2.android.hevc")

                if (isExplicitVideoError || 
                    ((playbackError.errorCode == PlaybackException.ERROR_CODE_DECODER_INIT_FAILED || 
                      playbackError.errorCode == PlaybackException.ERROR_CODE_DECODING_FAILED ||
                      playbackError.errorCode == PlaybackException.ERROR_CODE_DECODER_QUERY_FAILED) && !isExplicitAudioError)) {
                    isVideoSupported = false
                }
            }
        }

        // 3. Check Audio Codec Hardware / Extension Support
        val hasAudio = audio != null && audioCodec != "none"
        var isAudioSupported = true
        if (hasAudio) {
            val aAssessment = try {
                DecoderCapabilityManager.assessAudioDecoder(
                    codec = audioCodec,
                    channels = audio?.channels ?: 2,
                    sampleRate = audio?.sampleRate ?: 48000
                )
            } catch (_: Throwable) { null }

            val isNativeSupportedAudio = audioCodec in setOf("aac", "mp3", "opus", "vorbis", "flac", "pcm_s16le", "pcm_s24le", "pcm_s32le", "alac", "amr-nb", "amr-wb", "amrnb", "amrwb")
            
            val isSpecializedDolbyOrDts = audioCodec in setOf("ac3", "eac3", "e-ac-3", "eac-3", "dts", "dts-hd", "dtshd", "truehd", "true-hd", "wma", "wmav2", "ac4")
            
            val hasExtensionOrMediaCodec = aAssessment != null && aAssessment.deviceDecoderName != null && aAssessment.isSupported
            
            isAudioSupported = when {
                isNativeSupportedAudio -> true
                isSpecializedDolbyOrDts -> hasExtensionOrMediaCodec
                aAssessment != null && aAssessment.deviceDecoderName != null -> aAssessment.isSupported
                else -> false
            }

            // If audio decoder init or rendering failed during playback
            if (playbackError != null) {
                val errorMsg = playbackError.message?.lowercase() ?: ""
                val causeMsg = playbackError.cause?.message?.lowercase() ?: ""
                val isExplicitVideoError = errorMsg.contains("video") || causeMsg.contains("video") ||
                        errorMsg.contains("avc") || causeMsg.contains("avc") ||
                        errorMsg.contains("hevc") || causeMsg.contains("hevc") ||
                        errorMsg.contains("vp9") || causeMsg.contains("vp9") ||
                        errorMsg.contains("c2.android.avc") || errorMsg.contains("c2.android.hevc")
                
                val isExplicitAudioError = errorMsg.contains("audio") || causeMsg.contains("audio") ||
                        errorMsg.contains("eac3") || causeMsg.contains("eac3") ||
                        errorMsg.contains("ac3") || causeMsg.contains("ac3") ||
                        errorMsg.contains("dts") || causeMsg.contains("dts") ||
                        causeMsg.contains("audiosink") ||
                        playbackError.errorCode == PlaybackException.ERROR_CODE_AUDIO_TRACK_INIT_FAILED ||
                        playbackError.errorCode == PlaybackException.ERROR_CODE_AUDIO_TRACK_WRITE_FAILED

                if (isExplicitAudioError || (playbackError.errorCode == PlaybackException.ERROR_CODE_DECODER_INIT_FAILED && !isExplicitVideoError)) {
                    isAudioSupported = false
                }
            }
        }

        // 4. Evidence-Based Decision Matrix (Hierarchy: Direct -> Remux -> Targeted Transcode -> Full Transcode)
        
        // Scenario 1: Direct Playback (No processing needed)
        if (isContainerSupported && (!hasVideo || isVideoSupported) && (!hasAudio || isAudioSupported)) {
            return@withContext PlaybackCompatibilityResult(
                strategy = PlaybackStrategy.DIRECT_HARDWARE,
                reason = "Hardware acceleration available for container ($format) and codecs (Video: $videoCodec, Audio: $audioCodec)",
                containerFormat = format,
                videoCodec = videoCodec,
                audioCodec = audioCodec,
                isVideoSupported = true,
                isAudioSupported = true,
                isContainerSupported = true,
                videoAction = "direct",
                audioAction = "direct",
                qualityImpact = "None (Direct Hardware Playback)",
                estimatedSpeed = "Instant (0 ms overhead)"
            )
        }

        // Scenario 2: Container Problem Only -> Stream-Copy Remux (Video: copy, Audio: copy)
        // Both video and audio codecs are hardware decodable, but container causes demux/seek issues
        if ((!hasVideo || isVideoSupported) && (!hasAudio || isAudioSupported)) {
            return@withContext PlaybackCompatibilityResult(
                strategy = PlaybackStrategy.REMUX_REQUIRED,
                reason = "Both video ($videoCodec) and audio ($audioCodec) codecs are fully hardware-supported, but the container ($format) requires stream-copy remuxing to standard MP4",
                containerFormat = format,
                videoCodec = videoCodec,
                audioCodec = audioCodec,
                requiresRemux = true,
                isVideoSupported = true,
                isAudioSupported = true,
                isContainerSupported = false,
                videoAction = "copy",
                audioAction = "copy",
                qualityImpact = "None (100% Lossless Bitstream Copy)",
                estimatedSpeed = "Extremely fast (~100x realtime, I/O bound)"
            )
        }

        // Scenario 3: Targeted Audio Transcode (Video: copy, Audio: transcode)
        // Video is supported, but Audio is unsupported (e.g. MKV with H.264/HEVC + E-AC-3/DTS/TrueHD)
        if ((!hasVideo || isVideoSupported) && hasAudio && !isAudioSupported) {
            return@withContext PlaybackCompatibilityResult(
                strategy = PlaybackStrategy.TARGETED_AUDIO_TRANSCODE,
                reason = "Video ($videoCodec) is hardware-compatible; audio codec ($audioCodec) lacks hardware/extension decoder. Stream-copying original video bitstream without re-encoding and transcoding audio to AAC.",
                containerFormat = format,
                videoCodec = videoCodec,
                audioCodec = audioCodec,
                requiresTranscode = true,
                isVideoSupported = true,
                isAudioSupported = false,
                isContainerSupported = isContainerSupported,
                videoAction = "copy",
                audioAction = "transcode",
                qualityImpact = "Video: 100% Lossless (Stream Copy); Audio: High-Quality AAC (192 kbps)",
                estimatedSpeed = "Very fast (~30-50x realtime, zero video re-encoding)"
            )
        }

        // Scenario 4: Targeted Video Transcode (Video: transcode, Audio: copy)
        // Audio is supported, but Video is unsupported (e.g. MKV with 10-bit HEVC / unsupported profile + AAC/Opus)
        if (hasVideo && !isVideoSupported && (!hasAudio || isAudioSupported)) {
            return@withContext PlaybackCompatibilityResult(
                strategy = PlaybackStrategy.TARGETED_VIDEO_TRANSCODE,
                reason = "Audio ($audioCodec) is hardware-compatible; video stream ($videoCodec $videoProfile) exceeds device decoder capabilities. Transcoding video to standard H.264 while preserving original audio bitstream.",
                containerFormat = format,
                videoCodec = videoCodec,
                audioCodec = audioCodec,
                requiresTranscode = true,
                isVideoSupported = false,
                isAudioSupported = true,
                isContainerSupported = isContainerSupported,
                videoAction = "transcode",
                audioAction = "copy",
                qualityImpact = "Audio: 100% Lossless (Stream Copy); Video: Transcoded to H.264 High@L4.1",
                estimatedSpeed = "Standard transcode speed (H.264 encode)"
            )
        }

        // Scenario 5: Full Transcode (Video: transcode, Audio: transcode)
        // Both video and audio are unsupported
        return@withContext PlaybackCompatibilityResult(
            strategy = PlaybackStrategy.FULL_TRANSCODE_REQUIRED,
            reason = "Both video ($videoCodec) and audio ($audioCodec) exceed device hardware decoder capabilities; transcoding both streams to standard H.264 + AAC MP4.",
            containerFormat = format,
            videoCodec = videoCodec,
            audioCodec = audioCodec,
            requiresTranscode = true,
            isVideoSupported = false,
            isAudioSupported = false,
            isContainerSupported = isContainerSupported,
            videoAction = "transcode",
            audioAction = "transcode",
            qualityImpact = "Both streams transcoded to standard H.264 High + AAC Stereo MP4",
            estimatedSpeed = "Standard transcode speed"
        )
    }

    fun executeFix(
        context: Context,
        inputUri: Uri,
        outputFile: File,
        plan: PlaybackCompatibilityResult
    ): Flow<FFmpegProgress> {
        Log.i(TAG, "Executing evidence-based fix: strategy=${plan.strategy}, videoAction=${plan.videoAction}, audioAction=${plan.audioAction} -> ${outputFile.absolutePath}")
        
        return when (plan.strategy) {
            PlaybackStrategy.REMUX_REQUIRED -> {
                RemuxEngine.remuxToMp4(
                    context = context,
                    inputUri = inputUri,
                    outputFile = outputFile
                )
            }
            PlaybackStrategy.TARGETED_AUDIO_TRANSCODE -> {
                MediaConverter.convertMedia(
                    context = context,
                    request = MediaConversionRequest(
                        inputUri = inputUri,
                        outputFile = outputFile,
                        videoCodec = "copy",
                        audioCodec = "aac",
                        audioBitrateKbps = 192,
                        fastStart = true
                    )
                )
            }
            PlaybackStrategy.TARGETED_VIDEO_TRANSCODE -> {
                val encoder = com.example.media.ffmpeg.H264EncoderSelector.getSelectedEncoder()
                val encName = encoder?.name ?: "libopenh264"
                MediaConverter.convertMedia(
                    context = context,
                    request = MediaConversionRequest(
                        inputUri = inputUri,
                        outputFile = outputFile,
                        videoCodec = encName,
                        audioCodec = "copy",
                        videoBitrateKbps = 2500,
                        preset = if (encoder?.supportsPreset == true) "ultrafast" else null,
                        crf = if (encoder?.supportsCrf == true) 23 else null,
                        fastStart = true
                    )
                )
            }
            PlaybackStrategy.FULL_TRANSCODE_REQUIRED, PlaybackStrategy.TRANSCODE_REQUIRED -> {
                val encoder = com.example.media.ffmpeg.H264EncoderSelector.getSelectedEncoder()
                val encName = encoder?.name ?: "libopenh264"
                MediaConverter.convertMedia(
                    context = context,
                    request = MediaConversionRequest(
                        inputUri = inputUri,
                        outputFile = outputFile,
                        videoCodec = encName,
                        audioCodec = "aac",
                        videoBitrateKbps = 2500,
                        audioBitrateKbps = 192,
                        preset = if (encoder?.supportsPreset == true) "ultrafast" else null,
                        crf = if (encoder?.supportsCrf == true) 23 else null,
                        fastStart = true
                    )
                )
            }
            PlaybackStrategy.DIRECT_HARDWARE, PlaybackStrategy.UNSUPPORTED -> {
                RemuxEngine.remuxToMp4(
                    context = context,
                    inputUri = inputUri,
                    outputFile = outputFile
                )
            }
            else -> {
                throw IllegalStateException("Unhandled strategy: ${plan.strategy}")
            }
        }
    }
}
