package com.example.media

import android.content.Context
import android.os.Build
import android.os.PowerManager
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.concurrent.atomic.AtomicReference

enum class DeviceThermalState {
    NORMAL,
    LIGHT,
    MODERATE,
    SEVERE,
    CRITICAL,
    UNKNOWN
}

enum class TranscodingWorkloadState {
    FAST,
    NORMAL,
    SAFE
}

/**
 * Phase 17.40: Device Thermal State & Adaptive Workload Manager.
 * Monitors Android PowerManager thermal status and governs adaptive transcoding workloads
 * with hysteresis to prevent oscillation.
 */
object ThermalStateManager {
    private const val TAG = "ThermalStateManager"

    private val _thermalState = MutableStateFlow(DeviceThermalState.NORMAL)
    val thermalState: StateFlow<DeviceThermalState> = _thermalState.asStateFlow()

    private val _workloadState = MutableStateFlow(TranscodingWorkloadState.NORMAL)
    val workloadState: StateFlow<TranscodingWorkloadState> = _workloadState.asStateFlow()

    private var powerManager: PowerManager? = null
    private var isListenerRegistered = false

    @Volatile
    var mockThermalStateForTesting: DeviceThermalState? = null

    private var lastLoggedThermalState: DeviceThermalState? = null
    private var lastLoggedWorkloadState: TranscodingWorkloadState? = null
    private var lastStateChangeTimeMs: Long = 0L
    private const val HYSTERESIS_MIN_INTERVAL_MS = 3000L

    fun initialize(context: Context) {
        if (isListenerRegistered) return
        try {
            powerManager = context.applicationContext.getSystemService(Context.POWER_SERVICE) as? PowerManager
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && powerManager != null) {
                powerManager?.addThermalStatusListener { status ->
                    val state = mapThermalStatus(status)
                    onThermalStatusChanged(state)
                }
                isListenerRegistered = true
                val initialStatus = powerManager?.currentThermalStatus ?: 0
                _thermalState.value = mapThermalStatus(initialStatus)
            }
        } catch (t: Throwable) {
            Log.w("FALLBACK_TRACE", "[THERMAL_STATE_INIT_ERROR] ${t.message}")
        }
    }

    fun getCurrentThermalState(): DeviceThermalState {
        mockThermalStateForTesting?.let { return it }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && powerManager != null) {
            try {
                val status = powerManager?.currentThermalStatus ?: 0
                return mapThermalStatus(status)
            } catch (_: Throwable) {}
        }
        return _thermalState.value
    }

    fun onThermalStatusChanged(newState: DeviceThermalState, requestId: String? = null) {
        _thermalState.value = newState
        evaluateWorkload(bufferLeadMs = null, requestId = requestId)
    }

    fun evaluateWorkload(
        bufferLeadMs: Long?,
        requestId: String? = null
    ): TranscodingWorkloadState {
        val thermal = getCurrentThermalState()
        val now = System.currentTimeMillis()

        // Determine target workload
        val targetWorkload = when {
            // SAFE workload under severe/critical thermal pressure
            thermal == DeviceThermalState.SEVERE || thermal == DeviceThermalState.CRITICAL -> {
                TranscodingWorkloadState.SAFE
            }
            // FAST workload when buffer is low and thermal is safe
            (bufferLeadMs != null && bufferLeadMs < 6000L) && (thermal == DeviceThermalState.NORMAL || thermal == DeviceThermalState.LIGHT) -> {
                TranscodingWorkloadState.FAST
            }
            // NORMAL workload when playback is healthy or thermal is moderate
            else -> {
                TranscodingWorkloadState.NORMAL
            }
        }

        // Apply hysteresis: prevent rapid flipping between workloads
        val currentWorkload = _workloadState.value
        if (targetWorkload != currentWorkload) {
            if (targetWorkload == TranscodingWorkloadState.SAFE || now - lastStateChangeTimeMs >= HYSTERESIS_MIN_INTERVAL_MS) {
                _workloadState.value = targetWorkload
                lastStateChangeTimeMs = now
            }
        }

        val activeWorkload = _workloadState.value

        if (thermal != lastLoggedThermalState || activeWorkload != lastLoggedWorkloadState) {
            lastLoggedThermalState = thermal
            lastLoggedWorkloadState = activeWorkload
            val reqStr = if (requestId != null) " req=$requestId" else ""
            Log.i("FALLBACK_TRACE", "[THERMAL_STATE] status=$thermal workload=$activeWorkload$reqStr")
        }

        return activeWorkload
    }

    private fun mapThermalStatus(status: Int): DeviceThermalState {
        return when (status) {
            0 -> DeviceThermalState.NORMAL      // THERMAL_STATUS_NONE
            1 -> DeviceThermalState.LIGHT       // THERMAL_STATUS_LIGHT
            2 -> DeviceThermalState.MODERATE    // THERMAL_STATUS_MODERATE
            3 -> DeviceThermalState.SEVERE      // THERMAL_STATUS_SEVERE
            4 -> DeviceThermalState.CRITICAL    // THERMAL_STATUS_CRITICAL
            5 -> DeviceThermalState.CRITICAL    // THERMAL_STATUS_EMERGENCY
            6 -> DeviceThermalState.CRITICAL    // THERMAL_STATUS_SHUTDOWN
            else -> DeviceThermalState.UNKNOWN
        }
    }

    fun resetForTesting() {
        mockThermalStateForTesting = null
        _thermalState.value = DeviceThermalState.NORMAL
        _workloadState.value = TranscodingWorkloadState.NORMAL
        lastLoggedThermalState = null
        lastLoggedWorkloadState = null
        lastStateChangeTimeMs = 0L
    }
}
