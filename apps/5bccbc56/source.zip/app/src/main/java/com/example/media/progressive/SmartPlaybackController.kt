package com.example.media.progressive

import android.util.Log
import com.example.media.MediaEngine
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.UUID
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Phase 17.37: Smart Playback Controller.
 * Central coordinator for progressive playback intelligence, stall prevention,
 * adaptive startup buffering, consumption rate awareness, and intelligent seeking.
 */
object SmartPlaybackController {
    private const val TAG = "SmartPlaybackController"

    const val DEFAULT_BASE_STARTUP_MS = 8_000L
    const val MIN_STARTUP_MS = 4_000L
    const val MAX_STARTUP_MS = 16_000L

    // Hysteresis thresholds
    const val LEAD_CRITICAL_MS = 1_000L
    const val LEAD_LOW_MS = 3_500L
    const val LEAD_HEALTHY_RECOVERY_MS = 6_000L
    const val LEAD_STALL_RECOVERY_MS = 4_000L

    private val _metrics = MutableStateFlow(SmartBufferMetrics())
    val metrics: StateFlow<SmartBufferMetrics> = _metrics.asStateFlow()

    @Volatile
    private var activeRequestId: String? = null

    @Volatile
    private var activePlayerInstanceId: String? = null

    @Volatile
    private var activeJobId: String? = null

    @Volatile
    private var activeSeekRequest: SeekRequest? = null

    @Volatile
    private var isWaitingForTranscodeBuffer = AtomicBoolean(false)

    private var lastStateLogged: SmartBufferState? = null
    private var lastLeadLoggedMs: Long = -1L
    private var lastRiskLogged: String? = null
    private var lastLogTimeMs: Long = 0L

    /**
     * Initializes or updates tracking for an active playback request.
     */
    fun startTracking(
        playbackRequestId: String,
        playerInstanceId: String,
        transcodeJobId: String? = null,
        sourceDurationMs: Long = 0L
    ) {
        val prevReq = activeRequestId
        if (prevReq != null && prevReq != playbackRequestId) {
            Log.w(
                "FALLBACK_TRACE",
                "[SMART_SEEK_SUPERSEDED] req=$prevReq supersededBy=$playbackRequestId (request switch)"
            )
        }

        activeRequestId = playbackRequestId
        activePlayerInstanceId = playerInstanceId
        activeJobId = transcodeJobId
        activeSeekRequest = null
        isWaitingForTranscodeBuffer.set(false)
        lastStateLogged = null
        lastLeadLoggedMs = -1L
        lastRiskLogged = null
        lastLogTimeMs = 0L

        val initialTarget = calculateAdaptiveStartupTarget(
            sourceDurationMs = sourceDurationMs,
            productionRate = 0.0f,
            consumptionRate = 1.0f
        )

        _metrics.value = SmartBufferMetrics(
            playbackRequestId = playbackRequestId,
            playerInstanceId = playerInstanceId,
            transcodeJobId = transcodeJobId,
            state = SmartBufferState.STARTING,
            sourceDurationMs = sourceDurationMs,
            startupTargetMs = initialTarget,
            consumptionRate = 1.0f,
            productionRate = 0.0f
        )

        Log.i(
            "FALLBACK_TRACE",
            "[SMART_BUFFER_TARGET] req=$playbackRequestId startupTarget=${initialTarget}ms productionRate=0.0x consumptionRate=1.0x"
        )
    }

    /**
     * Deterministic adaptive startup target calculation.
     */
    fun calculateAdaptiveStartupTarget(
        sourceDurationMs: Long,
        productionRate: Float,
        consumptionRate: Float
    ): Long {
        if (sourceDurationMs in 1L..MIN_STARTUP_MS) {
            return sourceDurationMs
        }

        val effConsumption = if (consumptionRate > 0f) consumptionRate else 1.0f
        val rateRatio = if (productionRate > 0f) productionRate / effConsumption else 0.0f

        val baseTarget = when {
            rateRatio >= 1.5f -> 6_000L   // Fast transcoding -> smaller startup buffer
            rateRatio >= 0.9f -> 10_000L  // Near real-time -> moderate startup buffer
            productionRate > 0.0f -> MAX_STARTUP_MS // Slow transcoding -> larger safety margin
            else -> DEFAULT_BASE_STARTUP_MS // Initial unknown rate -> default 8s
        }

        return if (sourceDurationMs > 0L) {
            minOf(sourceDurationMs, maxOf(MIN_STARTUP_MS, baseTarget))
        } else {
            baseTarget
        }
    }

    /**
     * Evaluates buffer state with hysteresis stabilization to prevent oscillation.
     */
    fun evaluateBufferState(
        playableDurationMs: Long,
        playbackPositionMs: Long?,
        internalBufferedMs: Long,
        productionRate: Float,
        consumptionRate: Float,
        isTranscodeCompleted: Boolean,
        isWaiting: Boolean,
        previousState: SmartBufferState
    ): Pair<SmartBufferState, Double?> {
        if (isTranscodeCompleted) {
            return Pair(SmartBufferState.COMPLETED, null)
        }
        if (playbackPositionMs == null) {
            return Pair(if (previousState == SmartBufferState.UNKNOWN) SmartBufferState.UNKNOWN else SmartBufferState.STARTING, null)
        }

        val progressiveLead = maxOf(0L, playableDurationMs - playbackPositionMs)
        val effConsumption = maxOf(0.1f, consumptionRate)
        val rateDiff = effConsumption - productionRate
        val timeToDepletion = if (rateDiff > 0.05f && productionRate > 0.0f && progressiveLead > 0L) {
            (progressiveLead / 1000.0) / rateDiff
        } else if (productionRate == 0f && progressiveLead > 0L) {
            (progressiveLead / 1000.0) / effConsumption
        } else {
            null
        }

        val newState = when {
            isWaiting || progressiveLead <= LEAD_CRITICAL_MS -> {
                SmartBufferState.WAITING_FOR_TRANSCODE
            }
            previousState == SmartBufferState.WAITING_FOR_TRANSCODE -> {
                // Hysteresis: require recovery lead before exiting wait
                if (progressiveLead >= LEAD_STALL_RECOVERY_MS) {
                    if (progressiveLead >= LEAD_HEALTHY_RECOVERY_MS && (productionRate >= effConsumption * 0.9f || timeToDepletion == null)) {
                        SmartBufferState.HEALTHY
                    } else {
                        SmartBufferState.LOW_BUFFER
                    }
                } else {
                    SmartBufferState.WAITING_FOR_TRANSCODE
                }
            }
            previousState == SmartBufferState.STALL_RISK -> {
                if (progressiveLead >= LEAD_HEALTHY_RECOVERY_MS && (productionRate >= effConsumption * 0.9f || timeToDepletion == null || timeToDepletion > 12.0)) {
                    SmartBufferState.HEALTHY
                } else if (progressiveLead >= 3_000L) {
                    SmartBufferState.LOW_BUFFER
                } else {
                    SmartBufferState.STALL_RISK
                }
            }
            previousState == SmartBufferState.LOW_BUFFER -> {
                if (progressiveLead < 2_000L || (timeToDepletion != null && timeToDepletion < 4.0)) {
                    SmartBufferState.STALL_RISK
                } else if (progressiveLead >= LEAD_HEALTHY_RECOVERY_MS && (productionRate >= effConsumption * 0.9f || timeToDepletion == null || timeToDepletion > 15.0)) {
                    SmartBufferState.HEALTHY
                } else {
                    SmartBufferState.LOW_BUFFER
                }
            }
            else -> { // HEALTHY or STARTING
                if (progressiveLead <= 2_000L || (timeToDepletion != null && timeToDepletion < 5.0)) {
                    SmartBufferState.STALL_RISK
                } else if (progressiveLead < LEAD_LOW_MS || (timeToDepletion != null && timeToDepletion < 8.0)) {
                    SmartBufferState.LOW_BUFFER
                } else {
                    SmartBufferState.HEALTHY
                }
            }
        }

        return Pair(newState, timeToDepletion)
    }

    /**
     * Updates transcoding progress information from the background generator.
     */
    fun updateTranscodeProgress(
        playableDurationMs: Long,
        productionRate: Float,
        fps: Double,
        generatedUnitsCount: Int,
        isCompleted: Boolean,
        error: Throwable? = null,
        mediaEngine: MediaEngine? = null
    ) {
        val current = _metrics.value
        val reqId = current.playbackRequestId ?: activeRequestId ?: "none"

        val targetStartup = calculateAdaptiveStartupTarget(
            sourceDurationMs = current.sourceDurationMs,
            productionRate = productionRate,
            consumptionRate = current.consumptionRate
        )

        val pos = current.playbackPositionMs
        val (state, depletion) = evaluateBufferState(
            playableDurationMs = playableDurationMs,
            playbackPositionMs = pos,
            internalBufferedMs = current.internalBufferedPositionMs,
            productionRate = productionRate,
            consumptionRate = current.consumptionRate,
            isTranscodeCompleted = isCompleted,
            isWaiting = isWaitingForTranscodeBuffer.get(),
            previousState = current.state
        )

        val lead = maxOf(0L, playableDurationMs - pos)

        if (productionRate > 0f && productionRate != current.productionRate) {
            Log.i("FALLBACK_TRACE", "[SMART_PRODUCTION_RATE] req=$reqId speed=${productionRate}x fps=$fps")
        }

        // Check if there is an active seek waiting for media to be produced
        val pendingSeek = activeSeekRequest
        if (pendingSeek != null && pendingSeek.status == SeekStatus.WAITING) {
            if (playableDurationMs >= pendingSeek.targetPositionMs || isCompleted) {
                Log.i(
                    "FALLBACK_TRACE",
                    "[SMART_SEEK_AVAILABLE] req=$reqId seekId=${pendingSeek.seekId} target=${pendingSeek.targetPositionMs}ms"
                )
                val targetPos = pendingSeek.targetPositionMs
                activeSeekRequest = pendingSeek.copy(
                    status = SeekStatus.COMPLETED,
                    executedAtMs = System.currentTimeMillis()
                )
                mediaEngine?.player?.seekTo(targetPos)
                Log.i(
                    "FALLBACK_TRACE",
                    "[SMART_SEEK_COMPLETED] req=$reqId seekId=${pendingSeek.seekId} target=${targetPos}ms finalPos=${targetPos}ms"
                )
                if (isWaitingForTranscodeBuffer.compareAndSet(true, false)) {
                    mediaEngine?.player?.play()
                    Log.i("FALLBACK_TRACE", "[SMART_WAIT_END] req=$reqId lead=${maxOf(0L, playableDurationMs - targetPos)}ms recovered=true")
                }
            }
        }

        // Check if waiting for buffer lead recovery
        if (isWaitingForTranscodeBuffer.get() && (lead >= LEAD_STALL_RECOVERY_MS || isCompleted)) {
            if (isWaitingForTranscodeBuffer.compareAndSet(true, false)) {
                mediaEngine?.player?.play()
                Log.i("FALLBACK_TRACE", "[SMART_WAIT_END] req=$reqId lead=${lead}ms recovered=true")
            }
        }

        logDiagnosticsThrottled(reqId, state, lead, pos, playableDurationMs, depletion)

        _metrics.value = current.copy(
            playableDurationMs = playableDurationMs,
            productionRate = productionRate,
            fps = fps,
            generatedUnitsCount = generatedUnitsCount,
            isTranscodeCompleted = isCompleted,
            progressiveLeadMs = lead,
            startupTargetMs = targetStartup,
            state = if (error != null) SmartBufferState.FAILED else state,
            timeToDepletionSeconds = depletion,
            isWaitingForTranscode = isWaitingForTranscodeBuffer.get(),
            activeSeekRequest = activeSeekRequest
        )
    }

    /**
     * Updates player position, internal buffered position, and playback speed from Media3.
     */
    fun updatePlaybackMetrics(
        playbackPositionMs: Long,
        internalBufferedPositionMs: Long,
        consumptionRate: Float,
        isPlaying: Boolean,
        isBuffering: Boolean,
        mediaEngine: MediaEngine? = null
    ) {
        val current = _metrics.value
        val reqId = current.playbackRequestId ?: activeRequestId ?: "none"
        val playable = current.playableDurationMs
        val lead = maxOf(0L, playable - playbackPositionMs)

        if (consumptionRate != current.consumptionRate && consumptionRate > 0f) {
            Log.i("FALLBACK_TRACE", "[SMART_CONSUMPTION_RATE] req=$reqId playbackSpeed=${consumptionRate}x")
            Log.i("FALLBACK_TRACE", "[SMART_PLAYBACK_RATE] req=$reqId rate=${consumptionRate}x")
        }

        // If lead becomes critically low and playback is in buffer state, initiate controlled wait
        if (lead <= LEAD_CRITICAL_MS && !current.isTranscodeCompleted && !isWaitingForTranscodeBuffer.get() && isBuffering) {
            if (isWaitingForTranscodeBuffer.compareAndSet(false, true)) {
                Log.w(
                    "FALLBACK_TRACE",
                    "[SMART_WAIT_START] req=$reqId reason=STALL_PREVENTION lead=${lead}ms"
                )
            }
        }

        val (state, depletion) = evaluateBufferState(
            playableDurationMs = playable,
            playbackPositionMs = playbackPositionMs,
            internalBufferedMs = internalBufferedPositionMs,
            productionRate = current.productionRate,
            consumptionRate = consumptionRate,
            isTranscodeCompleted = current.isTranscodeCompleted,
            isWaiting = isWaitingForTranscodeBuffer.get(),
            previousState = current.state
        )

        logDiagnosticsThrottled(reqId, state, lead, playbackPositionMs, playable, depletion)

        _metrics.value = current.copy(
            playbackPositionMs = playbackPositionMs,
            internalBufferedPositionMs = internalBufferedPositionMs,
            consumptionRate = consumptionRate,
            progressiveLeadMs = lead,
            state = state,
            timeToDepletionSeconds = depletion,
            isWaitingForTranscode = isWaitingForTranscodeBuffer.get()
        )
    }

    /**
     * Intelligent seek request handler.
     * Evaluates whether seek target is available or waiting on transcode.
     * Prevents seeking into nonexistent media and supersedes stale seek requests.
     */
    fun requestSeek(
        targetPositionMs: Long,
        playbackRequestId: String,
        mediaEngine: MediaEngine? = null
    ): SeekRequest {
        val currentReq = activeRequestId ?: playbackRequestId
        val current = _metrics.value
        val playable = current.playableDurationMs

        val newSeekId = UUID.randomUUID().toString().take(8)
        Log.i(
            "FALLBACK_TRACE",
            "[SMART_SEEK_REQUEST] req=$playbackRequestId seekId=$newSeekId target=${targetPositionMs}ms playable=${playable}ms"
        )

        // Supersede any existing pending seek
        val prevSeek = activeSeekRequest
        if (prevSeek != null && (prevSeek.status == SeekStatus.WAITING || prevSeek.status == SeekStatus.REQUESTED)) {
            Log.i(
                "FALLBACK_TRACE",
                "[SMART_SEEK_SUPERSEDED] req=$playbackRequestId seekId=${prevSeek.seekId} target=${prevSeek.targetPositionMs}ms supersededBy=$newSeekId"
            )
        }

        val seekRequest: SeekRequest
        if (targetPositionMs <= playable || current.isTranscodeCompleted) {
            // Target is available: seek immediately
            seekRequest = SeekRequest(
                seekId = newSeekId,
                playbackRequestId = playbackRequestId,
                targetPositionMs = targetPositionMs,
                status = SeekStatus.COMPLETED,
                executedAtMs = System.currentTimeMillis()
            )
            activeSeekRequest = seekRequest
            Log.i("FALLBACK_TRACE", "[SMART_SEEK_AVAILABLE] req=$playbackRequestId seekId=$newSeekId target=${targetPositionMs}ms")
            mediaEngine?.player?.seekTo(targetPositionMs)
            Log.i(
                "FALLBACK_TRACE",
                "[SMART_SEEK_COMPLETED] req=$playbackRequestId seekId=$newSeekId target=${targetPositionMs}ms finalPos=${targetPositionMs}ms"
            )
            updatePlaybackMetrics(
                playbackPositionMs = targetPositionMs,
                internalBufferedPositionMs = current.internalBufferedPositionMs,
                consumptionRate = current.consumptionRate,
                isPlaying = mediaEngine?.player?.isPlaying == true,
                isBuffering = false,
                mediaEngine = mediaEngine
            )
        } else {
            // Target is beyond playable duration: wait for transcoding to reach target
            val needed = targetPositionMs - playable
            seekRequest = SeekRequest(
                seekId = newSeekId,
                playbackRequestId = playbackRequestId,
                targetPositionMs = targetPositionMs,
                status = SeekStatus.WAITING
            )
            activeSeekRequest = seekRequest
            isWaitingForTranscodeBuffer.set(true)
            Log.i(
                "FALLBACK_TRACE",
                "[SMART_SEEK_WAITING] req=$playbackRequestId seekId=$newSeekId target=${targetPositionMs}ms playable=${playable}ms needed=${needed}ms"
            )
            Log.w("FALLBACK_TRACE", "[SMART_WAIT_START] req=$playbackRequestId reason=SEEK_WAITING lead=0ms")
        }

        _metrics.value = _metrics.value.copy(
            activeSeekRequest = activeSeekRequest,
            isWaitingForTranscode = isWaitingForTranscodeBuffer.get()
        )
        return seekRequest
    }

    /**
     * Updates playback speed and adjusts consumption rate metrics.
     */
    fun setPlaybackSpeed(
        speed: Float,
        playbackRequestId: String,
        mediaEngine: MediaEngine? = null
    ) {
        val current = _metrics.value
        val effSpeed = if (speed > 0f) speed else 1.0f
        Log.i("FALLBACK_TRACE", "[SMART_PLAYBACK_RATE] req=$playbackRequestId rate=${effSpeed}x")
        Log.i("FALLBACK_TRACE", "[SMART_CONSUMPTION_RATE] req=$playbackRequestId playbackSpeed=${effSpeed}x")

        mediaEngine?.setPlaybackSpeed(effSpeed)

        updatePlaybackMetrics(
            playbackPositionMs = current.playbackPositionMs,
            internalBufferedPositionMs = current.internalBufferedPositionMs,
            consumptionRate = effSpeed,
            isPlaying = mediaEngine?.player?.isPlaying == true,
            isBuffering = false,
            mediaEngine = mediaEngine
        )
    }

    /**
     * Manual pause by user: pause playback without stopping background transcoding.
     */
    fun onUserPause(playbackRequestId: String, mediaEngine: MediaEngine? = null) {
        Log.i("FALLBACK_TRACE", "[SMART_USER_PAUSE] req=$playbackRequestId Pausing player while preserving background transcode")
        mediaEngine?.player?.pause()
        _metrics.value = _metrics.value.copy(isPausedByUser = true)
    }

    /**
     * Manual play/resume by user.
     */
    fun onUserPlay(playbackRequestId: String, mediaEngine: MediaEngine? = null) {
        Log.i("FALLBACK_TRACE", "[SMART_USER_PLAY] req=$playbackRequestId Resuming player")
        mediaEngine?.player?.play()
        _metrics.value = _metrics.value.copy(isPausedByUser = false)
    }

    /**
     * Phase 17.38: Reconnects a newly recreated player instance to the active tracking session
     * without restarting smart metrics or transcode state.
     */
    fun reconnectPlayer(newPlayerInstanceId: String, playbackRequestId: String) {
        if (activeRequestId == playbackRequestId) {
            val oldId = activePlayerInstanceId
            activePlayerInstanceId = newPlayerInstanceId
            Log.i(
                "FALLBACK_TRACE",
                "[SMART_PLAYER_RECONNECT] req=$playbackRequestId oldPlayer=$oldId newPlayer=$newPlayerInstanceId"
            )
            _metrics.value = _metrics.value.copy(
                playerInstanceId = newPlayerInstanceId
            )
        }
    }

    /**
     * Phase 17.38: App background transition handler.
     * Pauses the active player while allowing the background transcode job to continue safely.
     */
    fun onAppBackground(playbackRequestId: String, mediaEngine: MediaEngine? = null) {
        if (activeRequestId == playbackRequestId) {
            Log.i("FALLBACK_TRACE", "[SMART_LIFECYCLE_BACKGROUND] req=$playbackRequestId (pausing player, transcode continues)")
            try {
                mediaEngine?.player?.pause()
            } catch (_: Exception) {}
        }
    }

    /**
     * Phase 17.38: App foreground transition handler.
     */
    fun onAppForeground(playbackRequestId: String, mediaEngine: MediaEngine? = null) {
        if (activeRequestId == playbackRequestId) {
            Log.i(
                "FALLBACK_TRACE",
                "[SMART_LIFECYCLE_FOREGROUND] req=$playbackRequestId playable=${_metrics.value.playableDurationMs}ms lead=${_metrics.value.progressiveLeadMs}ms"
            )
        }
    }

    private fun logDiagnosticsThrottled(
        reqId: String,
        state: SmartBufferState,
        lead: Long,
        pos: Long,
        playable: Long,
        depletion: Double?
    ) {
        val now = System.currentTimeMillis()
        if (state != lastStateLogged) {
            lastStateLogged = state
            Log.i("FALLBACK_TRACE", "[SMART_BUFFER_STATE] req=$reqId state=$state lead=${lead}ms")
            Log.i("FALLBACK_TRACE", "[PLAYBACK_BUFFER] req=$reqId position=${pos}ms playable=${playable}ms lead=${lead}ms state=$state")
            val priority = if (state == SmartBufferState.LOW_BUFFER || state == SmartBufferState.WAITING_FOR_TRANSCODE || state == SmartBufferState.STALL_RISK) "BUFFER_CATCHUP" else "STABLE_PLAYBACK"
            Log.i("FALLBACK_TRACE", "[PLAYBACK_PRIORITY] req=$reqId priority=$priority bufferLead=${lead}ms")
            com.example.media.ThermalStateManager.evaluateWorkload(bufferLeadMs = lead, requestId = reqId)
        }

        if (depletion != null && (now - lastLogTimeMs > 2000L || state == SmartBufferState.STALL_RISK)) {
            val riskTag = if (state == SmartBufferState.STALL_RISK) "HIGH" else "MODERATE"
            if (riskTag != lastRiskLogged) {
                lastRiskLogged = riskTag
                Log.i("FALLBACK_TRACE", "[SMART_STALL_RISK] req=$reqId risk=$riskTag timeToDepletion=${depletion.toInt()}s")
            }
        }

        if (now - lastLogTimeMs > 1500L || Math.abs(lead - lastLeadLoggedMs) >= 2000L) {
            lastLogTimeMs = now
            lastLeadLoggedMs = lead
            Log.i("FALLBACK_TRACE", "[SMART_BUFFER_LEAD] req=$reqId position=${pos}ms playable=${playable}ms lead=${lead}ms")
            Log.i("FALLBACK_TRACE", "[PLAYBACK_BUFFER] req=$reqId position=${pos}ms playable=${playable}ms lead=${lead}ms state=$state")
        }
    }

    /**
     * Resets controller state.
     */
    fun reset() {
        activeRequestId = null
        activePlayerInstanceId = null
        activeJobId = null
        activeSeekRequest = null
        isWaitingForTranscodeBuffer.set(false)
        lastStateLogged = null
        lastLeadLoggedMs = -1L
        lastRiskLogged = null
        lastLogTimeMs = 0L
        _metrics.value = SmartBufferMetrics()
    }
}
