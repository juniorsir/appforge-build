package com.example.media.progressive

import android.content.Context
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.util.Log
import com.arthenica.ffmpegkit.FFmpegKit
import com.example.media.storage.MediaUriResolver
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.File
import java.nio.ByteBuffer

class AndroidMediaCodecH264Backend(private val codecName: String) : VideoEncoderBackend {
    override val name: String = codecName
    override val isHardware: Boolean = true

    override suspend fun executeTranscode(
        context: Context,
        request: ProgressiveGenerationRequest,
        outputDir: File,
        argsList: List<String>,
        onProgress: (com.example.media.ffmpeg.FFmpegProgress) -> Unit,
        onComplete: (com.example.media.ffmpeg.FFmpegResult) -> Unit,
        isCancelled: () -> Boolean
    ): Long = withContext(Dispatchers.IO) {
        val resolvedSource = MediaUriResolver.resolveUriForFFmpeg(context, request.inputUri, preferDirectSaf = true)
            ?: throw IllegalArgumentException("Could not resolve URI")
        
        val extractor = MediaExtractor()
        try {
            if (resolvedSource.pathOrSaf.startsWith("content://")) {
                val fd = context.contentResolver.openFileDescriptor(android.net.Uri.parse(resolvedSource.pathOrSaf), "r")
                extractor.setDataSource(fd!!.fileDescriptor)
                fd.close()
            } else {
                extractor.setDataSource(resolvedSource.pathOrSaf)
            }
        } catch (e: Exception) {
            Log.e("FALLBACK_TRACE", "Failed to set data source: ${e.message}")
            return@withContext 0L
        }

        var videoTrackIndex = -1
        var audioTrackIndex = -1
        for (i in 0 until extractor.trackCount) {
            val format = extractor.getTrackFormat(i)
            val mime = format.getString(MediaFormat.KEY_MIME) ?: ""
            if (mime.startsWith("video/") && videoTrackIndex == -1) videoTrackIndex = i
            else if (mime.startsWith("audio/") && audioTrackIndex == -1) audioTrackIndex = i
        }

        if (videoTrackIndex == -1) return@withContext 0L
        
        val videoFormat = extractor.getTrackFormat(videoTrackIndex)
        val audioFormat = if (audioTrackIndex != -1) extractor.getTrackFormat(audioTrackIndex) else null

        val w = request.targetWidth ?: videoFormat.getInteger(MediaFormat.KEY_WIDTH)
        val h = request.targetHeight ?: videoFormat.getInteger(MediaFormat.KEY_HEIGHT)
        val fps = request.frameRate ?: 23.98f
        val bitrate = (request.videoBitrateKbps ?: 4000) * 1000

        var decoder: MediaCodec? = null
        var encoder: MediaCodec? = null
        var muxer: MediaMuxer? = null
        
        try {
            encoder = MediaCodec.createByCodecName(codecName)
            val encFormat = MediaFormat.createVideoFormat("video/avc", w, h)
            encFormat.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            encFormat.setInteger(MediaFormat.KEY_BIT_RATE, bitrate)
            encFormat.setInteger(MediaFormat.KEY_FRAME_RATE, fps.toInt())
            encFormat.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, request.segmentDurationSec)
            
            encoder.configure(encFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            val surface = encoder.createInputSurface()
            encoder.start()

            val mime = videoFormat.getString(MediaFormat.KEY_MIME)!!
            decoder = MediaCodec.createDecoderByType(mime)
            decoder.configure(videoFormat, surface, null, 0)
            decoder.start()

            extractor.selectTrack(videoTrackIndex)
            if (audioTrackIndex != -1) {
                extractor.selectTrack(audioTrackIndex)
            }

            var segmentIndex = 0
            var segmentStartPtsUs = 0L
            var currentMp4File = File(outputDir, "seg_%05d.mp4.tmp".format(segmentIndex))
            muxer = MediaMuxer(currentMp4File.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            
            // Wait for encoder to output format
            var muxerVideoTrack = -1
            var muxerAudioTrack = -1
            var muxerStarted = false

            // If we have audio, we need its format too. But MediaMuxer requires adding all tracks before start().
            // We can add audio track immediately since we are copying it.
            if (audioFormat != null) {
                muxerAudioTrack = muxer.addTrack(audioFormat)
            }

            val bufferInfo = MediaCodec.BufferInfo()
            var isVideoEos = false
            var isAudioEos = false
            var isDecoderEos = false
            var isEncoderEos = false
            
            val ptsValidator = PtsValidator()
            val segmentDurationUs = request.segmentDurationSec * 1000000L
            val publishedUnits = mutableListOf<ProgressiveMediaUnit>()
            
            // A helper to flush the segment
            val finishSegment = { lastSegment: Boolean ->
                muxer?.stop()
                muxer?.release()
                muxer = null
                
                // Invoke FFmpeg to remux mp4 to ts
                val tsTmp = File(outputDir, "seg_%05d.ts.tmp".format(segmentIndex))
                val tsFinal = File(outputDir, "seg_%05d.ts".format(segmentIndex))
                val cmd = "-y -i ${currentMp4File.absolutePath} -c copy -f mpegts -muxdelay 0 -map 0 ${tsTmp.absolutePath}"
                FFmpegKit.execute(cmd)
                
                if (tsTmp.exists()) {
                    tsTmp.renameTo(tsFinal)
                }
                currentMp4File.delete()
                
                val unit = ProgressiveMediaUnit(
                    index = segmentIndex,
                    file = tsFinal,
                    durationMs = request.segmentDurationSec * 1000L,
                    startTimestampMs = segmentStartPtsUs / 1000,
                    endTimestampMs = (segmentStartPtsUs / 1000) + (request.segmentDurationSec * 1000L),
                    sizeBytes = tsFinal.length(),
                    isValidated = true
                )
                publishedUnits.add(unit)
                
                segmentIndex++
                
                if (!lastSegment) {
                    currentMp4File = File(outputDir, "seg_%05d.mp4.tmp".format(segmentIndex))
                    muxer = MediaMuxer(currentMp4File.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
                    if (audioFormat != null) muxerAudioTrack = muxer!!.addTrack(audioFormat)
                    muxerStarted = false
                }
            }

            val timeoutUs = 10000L
            while (!isEncoderEos && !isCancelled()) {
                // 1. Read from extractor and feed decoder or muxer (audio)
                if (!isVideoEos || !isAudioEos) {
                    val trackIndex = extractor.sampleTrackIndex
                    if (trackIndex == videoTrackIndex && !isVideoEos) {
                        val inIndex = decoder.dequeueInputBuffer(timeoutUs)
                        if (inIndex >= 0) {
                            val buf = decoder.getInputBuffer(inIndex)!!
                            val size = extractor.readSampleData(buf, 0)
                            if (size < 0) {
                                decoder.queueInputBuffer(inIndex, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                                isVideoEos = true
                            } else {
                                decoder.queueInputBuffer(inIndex, 0, size, extractor.sampleTime, extractor.sampleFlags)
                                extractor.advance()
                            }
                        }
                    } else if (trackIndex == audioTrackIndex && !isAudioEos) {
                        // Extract Audio directly to Muxer
                        val buf = ByteBuffer.allocate(1024 * 1024)
                        val size = extractor.readSampleData(buf, 0)
                        if (size < 0) {
                            isAudioEos = true
                        } else {
                            if (muxerStarted) {
                                val info = MediaCodec.BufferInfo().apply {
                                    this.size = size
                                    this.presentationTimeUs = extractor.sampleTime
                                    this.flags = extractor.sampleFlags
                                    this.offset = 0
                                }
                                muxer?.writeSampleData(muxerAudioTrack, buf, info)
                            }
                            extractor.advance()
                        }
                    } else if (trackIndex == -1) {
                        if (!isVideoEos) {
                            val inIndex = decoder.dequeueInputBuffer(timeoutUs)
                            if (inIndex >= 0) {
                                decoder.queueInputBuffer(inIndex, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                                isVideoEos = true
                            }
                        }
                        isAudioEos = true
                    }
                }

                // 2. Decoder output -> Encoder input (via surface)
                if (!isDecoderEos) {
                    val decInfo = MediaCodec.BufferInfo()
                    val outIndex = decoder.dequeueOutputBuffer(decInfo, timeoutUs)
                    if (outIndex >= 0) {
                        val render = decInfo.size > 0
                        decoder.releaseOutputBuffer(outIndex, render)
                        if ((decInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                            encoder.signalEndOfInputStream()
                            isDecoderEos = true
                        }
                    }
                }

                // 3. Encoder output -> Muxer
                if (!isEncoderEos) {
                    val outIndex = encoder.dequeueOutputBuffer(bufferInfo, timeoutUs)
                    if (outIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                        val newFormat = encoder.outputFormat
                        muxerVideoTrack = muxer!!.addTrack(newFormat)
                        muxer!!.start()
                        muxerStarted = true
                    } else if (outIndex >= 0) {
                        val buf = encoder.getOutputBuffer(outIndex)!!
                        ptsValidator.validate(bufferInfo.presentationTimeUs)
                        
                        // Check segment boundary
                        val isKeyFrame = (bufferInfo.flags and MediaCodec.BUFFER_FLAG_KEY_FRAME) != 0
                        if (isKeyFrame && segmentIndex > 0 && (bufferInfo.presentationTimeUs - segmentStartPtsUs >= segmentDurationUs)) {
                            // Close current segment, start next
                            segmentStartPtsUs = bufferInfo.presentationTimeUs
                            finishSegment(false)
                            
                            // Re-add video track to new muxer
                            muxerVideoTrack = muxer!!.addTrack(encoder.outputFormat)
                            muxer!!.start()
                            muxerStarted = true
                        } else if (segmentIndex == 0) {
                            segmentStartPtsUs = 0L // First segment starts here
                        }

                        if (muxerStarted && bufferInfo.size > 0) {
                            muxer?.writeSampleData(muxerVideoTrack, buf, bufferInfo)
                        }

                        encoder.releaseOutputBuffer(outIndex, false)

                        if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                            isEncoderEos = true
                            finishSegment(true)
                        }
                    }
                }
            }
            val res = com.example.media.ffmpeg.FFmpegResult(
                isSuccess = isEncoderEos,
                returnCode = if (isEncoderEos) 0 else 1,
                output = "AndroidMediaCodecH264Backend execution finished.",
                sessionId = 9999L
            )
            onComplete(res)
            9999L
        } catch (e: Exception) {
            Log.e("FALLBACK_TRACE", "Error in AndroidMediaCodecH264Backend: ${e.message}", e)
            val res = com.example.media.ffmpeg.FFmpegResult(
                isSuccess = false,
                returnCode = 1,
                output = e.message ?: "Unknown error",
                sessionId = 9999L
            )
            onComplete(res)
            9999L
        } finally {
            try { muxer?.stop(); muxer?.release() } catch (e: Exception) {}
            try { decoder?.stop(); decoder?.release() } catch (e: Exception) {}
            try { encoder?.stop(); encoder?.release() } catch (e: Exception) {}
            try { extractor.release() } catch (e: Exception) {}
        }
    }
}
