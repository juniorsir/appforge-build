package com.example.media.progressive

enum class ProgressiveState {
    IDLE,
    INITIALIZING,
    GENERATING,
    COMPLETED,
    CANCELLED,
    FAILED
}

/**
 * Phase 17.34: Progress snapshot representing progressive output generation state.
 */
data class ProgressiveGenerationProgress(
    val playbackRequestId: String,
    val transcodeJobId: String,
    val state: ProgressiveState = ProgressiveState.IDLE,
    val playableDurationMs: Long = 0L,
    val transcodedDurationMs: Long = 0L,
    val sourceDurationMs: Long = 0L,
    val progressPercentage: Float = 0.0f,
    val transcodingSpeed: Float = 0.0f,
    val fps: Double = 0.0,
    val outputSizeBytes: Long = 0L,
    val bitrateKbps: Double = 0.0,
    val publishedUnitsCount: Int = 0,
    val publishedUnits: List<ProgressiveMediaUnit> = emptyList(),
    val playlistFile: java.io.File? = null,
    val playlistUri: android.net.Uri? = null,
    val latestLogLine: String? = null,
    val error: Throwable? = null,
    val errorCategory: com.example.media.playback.PlaybackErrorCategory? = null,
    val sessionId: Long = -1L
)
