package com.example.media.progressive

import android.util.Log

class PtsValidator {
    private var lastPts = -1L
    private var isFirst = true

    fun validate(ptsUs: Long) {
        if (isFirst) {
            isFirst = false
            lastPts = ptsUs
            return
        }
        if (ptsUs < lastPts) {
            Log.w("FALLBACK_TRACE", "[ENCODER_TIMESTAMP_ANOMALY] currentPtsUs=$ptsUs lastPtsUs=$lastPts diff=${ptsUs - lastPts} - PTS went backward!")
        }
        lastPts = ptsUs
    }
}
