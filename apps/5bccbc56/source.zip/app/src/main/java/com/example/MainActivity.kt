package com.example

import android.app.PictureInPictureParams
import android.app.StatusBarManager
import android.content.ComponentName
import android.content.Intent
import android.content.res.Configuration
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.util.Rational
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.ui.Modifier
import androidx.core.view.WindowCompat
import com.example.ui.VideoDownloaderScreen
import com.example.ui.VideoDownloaderViewModel
import com.example.ui.theme.MyApplicationTheme
import java.util.concurrent.Executors

class MainActivity : ComponentActivity() {
  
  private val viewModel: VideoDownloaderViewModel by viewModels()
  private var sentToOverlaySettings = false
  private var pendingExternalUrl: String? = null
  private var lastProcessedExternalUrl: String? = null
  private var isUiReady: Boolean = false

  fun setSentToOverlaySettings(sent: Boolean) {
      sentToOverlaySettings = sent
  }

  fun enterSystemPipMode() {
      if (com.example.util.DeviceCompatHelper.isPipSupported(this)) {
          try {
              val params = PictureInPictureParams.Builder()
                  .setAspectRatio(Rational(16, 9))
                  .build()
              enterPictureInPictureMode(params)
          } catch (e: Exception) {
              android.widget.Toast.makeText(this, "Unable to enter Picture-in-Picture: ${e.message}", android.widget.Toast.LENGTH_SHORT).show()
          }
      } else {
          android.widget.Toast.makeText(this, "Picture-in-Picture is not supported on this device.", android.widget.Toast.LENGTH_SHORT).show()
      }
  }

  override fun onUserLeaveHint() {
      super.onUserLeaveHint()
      if (com.example.util.DeviceCompatHelper.isPipSupported(this)) {
          val playing = viewModel.playingMedia.value
          if (playing != null && viewModel.shouldAutoEnterSystemPip()) {
              enterSystemPipMode()
          }
      }
  }

  override fun onPictureInPictureModeChanged(
      isInPictureInPictureMode: Boolean,
      newConfig: Configuration
  ) {
      super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
      viewModel.updateInSystemPipMode(isInPictureInPictureMode)
  }

  override fun onResume() {
      super.onResume()
      if (sentToOverlaySettings) {
          sentToOverlaySettings = false
          if (FloatingBubbleService.canDrawOverlaysSafe(this)) {
              val serviceIntent = Intent(this, FloatingBubbleService::class.java)
              startService(serviceIntent)
          }
      }
  }

  companion object {
    private const val TAG = "MainActivity"

    /**
     * Extracts and validates an HTTP or HTTPS URL from raw text.
     * Trims whitespace, removes surrounding quotes/brackets, rejects malformed/non-web schemes,
     * and validates the URL host structure without performing network operations.
     */
    fun extractValidUrl(text: String?): String? {
        if (text.isNullOrBlank()) return null
        try {
            val trimmed = text.trim()
                .removeSurrounding("\"")
                .removeSurrounding("'")
                .removeSurrounding("<", ">")
                .trim()

            if (trimmed.length < 8 || trimmed.length > 4096) return null

            // Reject non-web schemes explicitly
            if (trimmed.startsWith("content://", ignoreCase = true) ||
                trimmed.startsWith("file://", ignoreCase = true) ||
                trimmed.startsWith("javascript:", ignoreCase = true) ||
                trimmed.startsWith("data:", ignoreCase = true)) {
                return null
            }

            // Find start of http:// or https://
            val httpIdx = trimmed.indexOf("http://", ignoreCase = true).takeIf { it >= 0 }
            val httpsIdx = trimmed.indexOf("https://", ignoreCase = true).takeIf { it >= 0 }

            val startIdx = when {
                httpIdx != null && httpsIdx != null -> minOf(httpIdx, httpsIdx)
                httpsIdx != null -> httpsIdx
                httpIdx != null -> httpIdx
                else -> return null
            }

            val candidatePart = trimmed.substring(startIdx)
            val candidate = candidatePart.split("\\s+".toRegex()).firstOrNull()?.trim() ?: return null
            val cleaned = candidate.trimEnd('.', ',', ')', ']', '}', '!', '?', ';', '\'', '"', '>')

            if (cleaned.length < 8) return null
            if (!cleaned.startsWith("http://", ignoreCase = true) && !cleaned.startsWith("https://", ignoreCase = true)) {
                return null
            }

            val javaUri = try {
                java.net.URI(cleaned)
            } catch (_: Throwable) {
                null
            }

            val scheme = javaUri?.scheme?.lowercase() ?: if (cleaned.startsWith("https://", ignoreCase = true)) "https" else "http"
            val host = javaUri?.host ?: cleaned.substringAfter("://").substringBefore("/").substringBefore("?").substringBefore("#")

            if ((scheme == "http" || scheme == "https") && !host.isNullOrBlank() && host.contains(".")) {
                return cleaned
            }
        } catch (t: Throwable) {
            Log.w(TAG, "extractValidUrl parsing notice: ${t.message}")
        }
        return null
    }
  }

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    Log.d(TAG, "onCreate() started. savedInstanceState is ${if (savedInstanceState != null) "PRESENT" else "NULL"}")
    
    val isMobile = resources.configuration.smallestScreenWidthDp < 600
    if (isMobile) {
        try {
            requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        } catch (_: Throwable) {
            // Orientation request may fail safely on multi-window or emulator displays
        }
    }
    
    try {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = android.graphics.Color.TRANSPARENT
        window.navigationBarColor = android.graphics.Color.TRANSPARENT

        WindowCompat.getInsetsController(window, window.decorView)?.apply {
            isAppearanceLightStatusBars = false
            isAppearanceLightNavigationBars = false
        }
    } catch (_: Throwable) {}

    try {
        enableEdgeToEdge(
            statusBarStyle = androidx.activity.SystemBarStyle.dark(
                android.graphics.Color.TRANSPARENT
            ),
            navigationBarStyle = androidx.activity.SystemBarStyle.dark(
                android.graphics.Color.TRANSPARENT
            )
        )
    } catch (_: Throwable) {}

    // On cold start, store pending URL without touching ViewModel or UI before Compose is ready
    if (savedInstanceState == null) {
        pendingExternalUrl = extractExternalUrl(intent)
        handleInternalIntentExtras(intent)
    }

    setContent {
      val themeSettings by viewModel.appThemeSettings.collectAsStateWithLifecycle()
      MyApplicationTheme(themeSettings = themeSettings) {
        androidx.compose.runtime.LaunchedEffect(Unit) {
            isUiReady = true
            consumePendingExternalUrl()
        }
        VideoDownloaderScreen(
            viewModel = viewModel,
            modifier = Modifier.fillMaxSize()
        )
      }
    }
  }

  override fun onNewIntent(intent: Intent) {
      super.onNewIntent(intent)
      Log.d(TAG, "onNewIntent() received")
      setIntent(intent)
      processExternalIntent(intent)
  }

  /**
   * Pure extraction function: converts an incoming Intent to a validated URL or null.
   * Does NOT touch UI, ViewModel, navigation, Toast, or network.
   */
  private fun extractExternalUrl(intent: Intent?): String? {
      if (intent == null) return null
      return try {
          when (intent.action) {
              Intent.ACTION_VIEW -> {
                  val uri = intent.data ?: return null
                  val scheme = uri.scheme?.lowercase() ?: return null
                  if (scheme != "http" && scheme != "https") return null
                  uri.toString()
              }

              Intent.ACTION_SEND -> {
                  val extraText = try {
                      intent.getCharSequenceExtra(Intent.EXTRA_TEXT)?.toString()
                          ?: intent.getStringExtra(Intent.EXTRA_TEXT)
                  } catch (_: Throwable) {
                      null
                  }
                  if (!extraText.isNullOrBlank()) {
                      extractValidUrl(extraText)
                  } else {
                      null
                  }
              }

              else -> null
          }
      } catch (t: Throwable) {
          Log.w(TAG, "extractExternalUrl notice: ${t.message}")
          null
      }
  }

  /**
   * Processes the external intent and dispatches to the ViewModel if UI is ready,
   * or records to pendingExternalUrl for later consumption.
   */
  private fun processExternalIntent(intent: Intent?) {
      if (intent == null) return
      try {
          val extractedUrl = extractExternalUrl(intent)
          if (!extractedUrl.isNullOrBlank()) {
              if (extractedUrl == lastProcessedExternalUrl) {
                  Log.d(TAG, "ExternalIntent: Duplicate URL skipped ($extractedUrl)")
                  return
              }
              lastProcessedExternalUrl = extractedUrl

              if (isUiReady) {
                  Log.i(TAG, "ExternalIntent: UI ready -> delivering URL $extractedUrl to ViewModel")
                  viewModel.setPendingExternalUrl(extractedUrl)
                  android.widget.Toast.makeText(this, "Link added", android.widget.Toast.LENGTH_SHORT).show()
                  promptAddQuickTile()
              } else {
                  Log.i(TAG, "ExternalIntent: UI not yet ready -> saving to pendingExternalUrl")
                  pendingExternalUrl = extractedUrl
              }
          } else {
              handleInternalIntentExtras(intent)
          }
      } catch (exception: Throwable) {
          Log.e(TAG, "ExternalIntent: Exception in processExternalIntent: ${exception.message}", exception)
      }
  }

  private fun consumePendingExternalUrl() {
      val url = pendingExternalUrl ?: return
      pendingExternalUrl = null
      lastProcessedExternalUrl = url
      Log.i(TAG, "ExternalIntent: Consuming pendingExternalUrl -> $url")
      viewModel.setPendingExternalUrl(url)
      android.widget.Toast.makeText(this, "Link added", android.widget.Toast.LENGTH_SHORT).show()
      promptAddQuickTile()
  }

  private fun handleInternalIntentExtras(intent: Intent?) {
      if (intent == null) return
      try {
          if (safeGetBooleanExtra(intent, "launch_floating_widget", false)) {
              if (!FloatingBubbleService.canDrawOverlaysSafe(this)) {
                  sentToOverlaySettings = true
                  android.widget.Toast.makeText(this, "Please enable 'Draw over other apps' to use the floating search bubble", android.widget.Toast.LENGTH_LONG).show()
                  try {
                      val overlayIntent = Intent(
                          android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                          android.net.Uri.parse("package:$packageName")
                      )
                      startActivity(overlayIntent)
                  } catch (e: Throwable) {
                      Log.e(TAG, "Failed to open overlay settings: ${e.message}", e)
                  }
              } else {
                  try {
                      val serviceIntent = Intent(this, FloatingBubbleService::class.java)
                      startService(serviceIntent)
                  } catch (e: Throwable) {
                      Log.e(TAG, "Failed to start FloatingBubbleService: ${e.message}", e)
                  }
              }
          }

          if (safeGetBooleanExtra(intent, "OPEN_BACKGROUND_PLAYER", false)) {
              try {
                  val bgMedia = com.example.media.BackgroundPlaybackManager.currentMedia.value
                  if (bgMedia != null) {
                      viewModel.startPlayingMedia(bgMedia)
                  }
              } catch (e: Throwable) {
                  Log.e(TAG, "Error opening background player: ${e.message}", e)
              }
          }
      } catch (t: Throwable) {
          Log.w(TAG, "handleInternalIntentExtras notice: ${t.message}")
      }
  }

  private fun safeGetBooleanExtra(intent: Intent, name: String, defaultValue: Boolean = false): Boolean {
      return try {
          intent.getBooleanExtra(name, defaultValue)
      } catch (t: Throwable) {
          Log.w(TAG, "SafeExtra: failed to read boolean extra '$name': ${t.message}")
          defaultValue
      }
  }

  private fun promptAddQuickTile() {
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
          try {
              val statusBarManager = getSystemService(StatusBarManager::class.java)
              statusBarManager?.requestAddTileService(
                  ComponentName(this, QuickTileService::class.java),
                  "Downly",
                  Icon.createWithResource(this, R.drawable.ic_download_modern),
                  Executors.newSingleThreadExecutor()
              ) { _ ->
                  // handle result
              }
          } catch (e: Throwable) {
              Log.w(TAG, "QuickTile request notice: ${e.message}")
          }
      }
  }
}

