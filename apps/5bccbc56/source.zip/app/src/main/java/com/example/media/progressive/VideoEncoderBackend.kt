package com.example.media.progressive

import android.content.Context
import java.io.File
import com.example.media.ffmpeg.FFmpegProgress

interface VideoEncoderBackend {
    val name: String
    val isHardware: Boolean
    
    suspend fun executeTranscode(
        context: Context,
        request: ProgressiveGenerationRequest,
        outputDir: File,
        argsList: List<String>,
        onProgress: (FFmpegProgress) -> Unit,
        onComplete: (com.example.media.ffmpeg.FFmpegResult) -> Unit,
        isCancelled: () -> Boolean
    ): Long
}
