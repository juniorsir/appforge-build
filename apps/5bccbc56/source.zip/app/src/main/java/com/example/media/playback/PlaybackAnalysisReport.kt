package com.example.media.playback

enum class PlaybackAnalysisResult {
    SUCCESS,
    FAILED
}

data class PlaybackFailureDetails(
    val exceptionClass: String,
    val errorCode: Int = 0,
    val errorCodeName: String = "ERROR_CODE_UNSPECIFIED",
    val rootCauseClass: String = "Unknown",
    val rootCauseMessage: String = "",
    val rendererName: String? = null,
    val diagnosticInfo: String? = null,
    val isDecoderInit: Boolean = false,
    val isMediaCodecException: Boolean = false,
    val isParserException: Boolean = false,
    val isSourceException: Boolean = false,
    val failedFormat: String? = null
)

data class VideoAnalysisInfo(
    val codec: String,
    val profile: String? = null,
    val level: String? = null,
    val pixelFormat: String? = null,
    val bitDepth: Int = 8,
    val width: Int = 0,
    val height: Int = 0,
    val frameRate: Float = 0f
)

data class AudioAnalysisInfo(
    val codec: String,
    val profile: String? = null,
    val channels: Int = 0,
    val sampleRate: Int = 0,
    val bitrate: Long = 0L
)

data class DeviceDecoderAnalysis(
    val decoderName: String?,
    val decoderType: String?, // "Hardware" or "Software"
    val supportedProfiles: List<String> = emptyList(),
    val maxResolution: String? = null,
    val maxFrameRate: Int? = null,
    val isSupported: Boolean = true,
    val profileSupported: Boolean? = null,
    val bitDepthSupported: Boolean? = null,
    val resolutionSupported: Boolean? = null,
    val levelSupported: Boolean? = null,
    val detailedDiagnosis: String? = null
)

enum class AuthoritativePlaybackResult {
    DIRECT_SUCCESS,
    DIRECT_FAILED,
    FALLBACK_SUCCESS,
    FALLBACK_FAILED,
    CANCELLED
}

data class PlaybackAnalysisReport(
    val result: PlaybackAnalysisResult,
    val player: String = "Media3 / ExoPlayer",
    val failure: PlaybackFailureDetails? = null,
    val containerFormat: String? = null,
    val video: VideoAnalysisInfo? = null,
    val audio: AudioAnalysisInfo? = null,
    val deviceDecoder: DeviceDecoderAnalysis? = null,
    val analysis: String,
    val recommendedAction: String,
    val fallbackUsed: Boolean = false,
    val fallbackTranscodeSuccess: Boolean = false,
    val actualPlaybackConfirmed: Boolean = false,
    val authoritativeError: PlaybackError? = null,
    val terminalResult: AuthoritativePlaybackResult? = null,
    val playbackPath: String? = null,
    val directPlaybackCompatibility: Boolean? = null
) {
    fun toFormattedReport(): String {
        val sb = StringBuilder()
        sb.appendLine("# PLAYBACK ANALYSIS\n")

        sb.appendLine("Result:")
        sb.appendLine(result.name)

        sb.appendLine("\nPlayer:")
        sb.appendLine(player)

        if (failure != null) {
            sb.appendLine("\nFailure:")
            sb.appendLine(failure.exceptionClass)
        }

        if (!containerFormat.isNullOrBlank() && containerFormat != "unknown") {
            sb.appendLine("\nContainer:")
            val displayContainer = when {
                containerFormat.contains("matroska", ignoreCase = true) || containerFormat.contains("webm", ignoreCase = true) -> "Matroska / WebM"
                containerFormat.contains("mp4", ignoreCase = true) || containerFormat.contains("mov", ignoreCase = true) -> "MP4"
                containerFormat.contains("avi", ignoreCase = true) -> "AVI"
                containerFormat.contains("flv", ignoreCase = true) -> "FLV"
                else -> containerFormat
            }
            sb.appendLine(displayContainer)
        }

        if (video != null && video.codec != "none" && video.codec != "unknown") {
            sb.appendLine("\nVideo:")
            val displayCodec = when (video.codec.lowercase()) {
                "hevc", "h265" -> "HEVC"
                "h264", "avc", "avc1" -> "H.264"
                "vp9" -> "VP9"
                "vp8" -> "VP8"
                "av1", "av01" -> "AV1"
                else -> video.codec.uppercase()
            }
            sb.appendLine(displayCodec)

            if (!video.profile.isNullOrBlank() && video.profile != "N/A") {
                sb.appendLine("Profile:")
                sb.appendLine(video.profile)
            }

            val pixelFmtStr = when {
                video.bitDepth == 10 || video.pixelFormat?.contains("10") == true -> "10-bit"
                video.bitDepth == 8 || video.pixelFormat?.contains("8") == true -> "8-bit"
                !video.pixelFormat.isNullOrBlank() -> video.pixelFormat
                else -> null
            }
            if (pixelFmtStr != null) {
                sb.appendLine("Pixel Format:")
                sb.appendLine(pixelFmtStr)
            }

            if (video.width > 0 && video.height > 0) {
                sb.appendLine("Resolution:")
                sb.appendLine("${video.width}x${video.height}")
            }
        }

        if (audio != null && audio.codec != "none" && audio.codec != "unknown") {
            sb.appendLine("\nAudio:")
            val displayAudio = when (audio.codec.lowercase()) {
                "eac3", "e-ac-3", "eac-3" -> "E-AC-3"
                "ac3" -> "AC-3"
                "aac" -> "AAC"
                "mp3" -> "MP3"
                "dts" -> "DTS"
                "opus" -> "Opus"
                "flac" -> "FLAC"
                else -> audio.codec.uppercase()
            }
            sb.appendLine(displayAudio)

            if (audio.channels > 0) {
                sb.appendLine("Channels:")
                sb.appendLine("${audio.channels}")
            }
            if (audio.sampleRate > 0) {
                sb.appendLine("Sample Rate:")
                sb.appendLine("${audio.sampleRate} Hz")
            }
        }

        if (deviceDecoder != null && !deviceDecoder.decoderName.isNullOrBlank()) {
            sb.appendLine("\nDevice Decoder:")
            val typeStr = if (deviceDecoder.decoderType != null) " (${deviceDecoder.decoderType})" else ""
            sb.appendLine("${deviceDecoder.decoderName}$typeStr")
            if (deviceDecoder.profileSupported != null) {
                sb.appendLine("Profile Support: ${if (deviceDecoder.profileSupported) "PASS" else "FAIL"}")
            }
            if (deviceDecoder.bitDepthSupported != null) {
                sb.appendLine("Bit Depth Support: ${if (deviceDecoder.bitDepthSupported) "PASS" else "FAIL"}")
            }
            if (deviceDecoder.supportedProfiles.isNotEmpty()) {
                sb.appendLine("Supported Profiles:")
                sb.appendLine(deviceDecoder.supportedProfiles.joinToString())
            }
            if (!deviceDecoder.maxResolution.isNullOrBlank()) {
                sb.appendLine("Max Resolution:")
                sb.appendLine(deviceDecoder.maxResolution)
            }
            if (!deviceDecoder.detailedDiagnosis.isNullOrBlank()) {
                sb.appendLine("Diagnostic Note:")
                sb.appendLine(deviceDecoder.detailedDiagnosis)
            }
        }

        sb.appendLine("\nAnalysis:")
        sb.appendLine(analysis)

        sb.appendLine("\nRecommended action:")
        sb.append(recommendedAction)

        return sb.toString().trimEnd()
    }
}
