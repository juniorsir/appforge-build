package com.example.ui

import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.graphics.RenderEffect
import android.graphics.RuntimeShader
import android.os.Build
import android.view.View
import androidx.annotation.RequiresApi

/**
 * GPU Post-Processing Engine for Real-Time Video Playback:
 *
 * 1. True Spatial Convolution Sharpening (Unsharp Masking):
 *    Uses an adaptive 8-neighbor 2D convolution kernel with Rec. 709 Luminance
 *    isolation via AGSL RuntimeShader. Enhances spatial edge resolution, text,
 *    and texture details without altering color hues, saturation, or contrast.
 *
 * 2. Color Balance & Tone Mapping:
 *    Calculates a clean diagonal ColorMatrix for brightness, contrast, saturation,
 *    gamma, temperature, highlights, shadows, and tint without cross-channel
 *    color pollution.
 */
object VideoPostProcessingHelper {

    // AGSL Shader for True Spatial Convolution Edge Peaking (Unsharp Mask) with Rec. 709 Luminance Isolation
    const val SPATIAL_SHARPEN_AGSL = """
        uniform shader contents;
        uniform float2 resolution;
        uniform float sharpness;
        uniform float splitRatio;

        half4 main(float2 fragCoord) {
            half4 center = contents.eval(fragCoord);
            
            // When Before/After split comparison is active, pixels to the left of the split line remain original
            if (splitRatio < 0.999 && (fragCoord.x / max(resolution.x, 1.0)) < splitRatio) {
                return center;
            }

            if (sharpness <= 0.005) {
                return center;
            }

            // Screen-space 1-pixel sampling offset for edge detection
            float stepX = 1.0;
            float stepY = 1.0;

            // 4 cardinal neighbors (up, down, left, right)
            half4 up    = contents.eval(fragCoord + float2(0.0, -stepY));
            half4 down  = contents.eval(fragCoord + float2(0.0, stepY));
            half4 left  = contents.eval(fragCoord + float2(-stepX, 0.0));
            half4 right = contents.eval(fragCoord + float2(stepX, 0.0));

            // 4 diagonal neighbors (corners) for smooth isotropic anti-aliased edge detection
            half4 upLeft    = contents.eval(fragCoord + float2(-stepX, -stepY));
            half4 upRight   = contents.eval(fragCoord + float2(stepX, -stepY));
            half4 bottomLeft  = contents.eval(fragCoord + float2(-stepX, stepY));
            half4 bottomRight = contents.eval(fragCoord + float2(stepX, stepY));

            // Rec.709 Luminance weights: isolates spatial detail without shifting hues or color saturation
            const half3 lumaWeights = half3(0.2126, 0.7152, 0.0722);
            half cLuma = dot(center.rgb, lumaWeights);

            // Weighted average of surrounding 8-neighbor pixels (cardinal weight 2.0, diagonal weight 1.0)
            half nLuma = (
                (dot(up.rgb, lumaWeights) + dot(down.rgb, lumaWeights) + 
                 dot(left.rgb, lumaWeights) + dot(right.rgb, lumaWeights)) * 2.0 +
                (dot(topLeft.rgb, lumaWeights) + dot(topRight.rgb, lumaWeights) + 
                 dot(bottomLeft.rgb, lumaWeights) + dot(bottomRight.rgb, lumaWeights))
            ) * (1.0 / 12.0);

            // Laplacian edge delta: difference between center pixel luminance and local surrounding neighborhood
            half edgeDelta = cLuma - nLuma;

            // Coring: ignore microscopic sensor/compression noise below 0.003
            if (abs(edgeDelta) < 0.003) {
                edgeDelta = 0.0;
            }

            // High-pass edge sharpening: boost edge transitions in luminance while 100% preserving chrominance
            // Scales smoothly with sharpness factor (0.0 to 2.0)
            half boost = edgeDelta * (sharpness * 1.75);
            half3 sharpened = center.rgb + half3(boost, boost, boost);

            return half4(clamp(sharpened, half3(0.0, 0.0, 0.0), half3(1.0, 1.0, 1.0)), center.a);
        }
    """

    private var cachedShader: Any? = null

    @RequiresApi(Build.VERSION_CODES.TIRAMISU)
    fun getOrCreateSharpenShader(): RuntimeShader {
        var shader = cachedShader as? RuntimeShader
        if (shader == null) {
            shader = RuntimeShader(SPATIAL_SHARPEN_AGSL)
            cachedShader = shader
        }
        return shader
    }

    /**
     * Calculates a pure, distortion-free ColorMatrix for real-time video color adjustments.
     * Unlike naive implementations, this DOES NOT pollute colors with cross-channel sharpness offsets.
     */
    fun calculateCleanColorMatrix(
        brightness: Float, // -1.0 to +1.0 (neutral: 0.0)
        contrast: Float,   // 0.5 to 2.0 (neutral: 1.0)
        saturation: Float, // 0.0 to 2.0 (neutral: 1.0)
        gamma: Float,      // 0.5 to 2.0 (neutral: 1.0)
        temperature: Float = 0.0f, // -1.0 (Cool) to +1.0 (Warm)
        highlights: Float = 0.0f,  // -1.0 to +1.0 (neutral: 0.0)
        shadows: Float = 0.0f,     // -1.0 to +1.0 (neutral: 0.0)
        vibrance: Float = 1.0f,    // 0.0 to 2.0 (neutral: 1.0)
        tint: Float = 0.0f         // -1.0 (Magenta) to +1.0 (Green)
    ): ColorMatrix {
        val gInv = if (gamma > 0.05f) 1.0f / gamma else 1.0f
        val cScale = contrast * gInv

        val highlightOffset = highlights * 20f
        val shadowOffset = shadows * 25f
        val bcOffset = (255f * brightness * contrast + 128f * (1f - contrast)) * gInv + 128f * (1f - gInv) + highlightOffset + shadowOffset

        // Temperature (Red/Blue warmth balance) & Tint (Green/Magenta balance)
        val tempRed = if (temperature > 0) 1.0f + temperature * 0.25f else 1.0f + temperature * 0.10f
        val tempBlue = if (temperature < 0) 1.0f - temperature * 0.25f else 1.0f - temperature * 0.12f
        val tintGreen = if (tint > 0) 1.0f + tint * 0.20f else 1.0f + tint * 0.10f
        val tintRedGreen = if (tint < 0) 1.0f - tint * 0.15f else 1.0f

        // Pure diagonal scaling with offsets: preserves pure chrominance and natural skin tones
        val bcArray = floatArrayOf(
            cScale * tempRed * tintRedGreen, 0f, 0f, 0f, bcOffset,
            0f, cScale * tintGreen, 0f, 0f, bcOffset,
            0f, 0f, cScale * tempBlue, 0f, bcOffset,
            0f, 0f, 0f, 1f, 0f
        )
        val bcMatrix = ColorMatrix(bcArray)

        val effectiveSat = saturation * vibrance
        val satMatrix = ColorMatrix()
        satMatrix.setSaturation(effectiveSat)

        val finalMatrix = ColorMatrix()
        finalMatrix.setConcat(satMatrix, bcMatrix)

        return finalMatrix
    }

    /**
     * Applies full GPU post-processing (Color Matrix + Real Spatial Unsharp Mask Sharpening)
     * to the video surface view.
     */
    fun applyPostProcessing(
        view: View,
        targetView: View,
        adjustments: VideoColorAdjustments,
        isHoldOriginalActive: Boolean,
        compareSplitRatio: Float
    ) {
        val activeAdjustments = if (isHoldOriginalActive) {
            VideoColorAdjustments()
        } else if (compareSplitRatio < 1.0f) {
            val def = VideoColorAdjustments()
            VideoColorAdjustments(
                brightness = def.brightness + (adjustments.brightness - def.brightness) * compareSplitRatio,
                contrast = def.contrast + (adjustments.contrast - def.contrast) * compareSplitRatio,
                saturation = def.saturation + (adjustments.saturation - def.saturation) * compareSplitRatio,
                gamma = def.gamma + (adjustments.gamma - def.gamma) * compareSplitRatio,
                sharpness = def.sharpness + (adjustments.sharpness - def.sharpness) * compareSplitRatio,
                temperature = def.temperature + (adjustments.temperature - def.temperature) * compareSplitRatio,
                highlights = def.highlights + (adjustments.highlights - def.highlights) * compareSplitRatio,
                shadows = def.shadows + (adjustments.shadows - def.shadows) * compareSplitRatio,
                vibrance = def.vibrance + (adjustments.vibrance - def.vibrance) * compareSplitRatio,
                tint = def.tint + (adjustments.tint - def.tint) * compareSplitRatio
            )
        } else {
            adjustments
        }

        if (activeAdjustments.isDefault) {
            targetView.setLayerType(View.LAYER_TYPE_NONE, null)
            view.setLayerType(View.LAYER_TYPE_NONE, null)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                targetView.setRenderEffect(null)
                view.setRenderEffect(null)
            }
            return
        }

        val cm = calculateCleanColorMatrix(
            brightness = activeAdjustments.brightness,
            contrast = activeAdjustments.contrast,
            saturation = activeAdjustments.saturation,
            gamma = activeAdjustments.gamma,
            temperature = activeAdjustments.temperature,
            highlights = activeAdjustments.highlights,
            shadows = activeAdjustments.shadows,
            vibrance = activeAdjustments.vibrance,
            tint = activeAdjustments.tint
        )

        val isColorModified = activeAdjustments.brightness != 0.0f ||
                activeAdjustments.contrast != 1.0f ||
                activeAdjustments.saturation != 1.0f ||
                activeAdjustments.gamma != 1.0f ||
                activeAdjustments.temperature != 0.0f ||
                activeAdjustments.highlights != 0.0f ||
                activeAdjustments.shadows != 0.0f ||
                activeAdjustments.vibrance != 1.0f ||
                activeAdjustments.tint != 0.0f

        val hasRealSharpness = activeAdjustments.sharpness > 0.005f

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val colorFilterEffect = if (isColorModified) {
                RenderEffect.createColorFilterEffect(ColorMatrixColorFilter(cm))
            } else {
                null
            }

            if (hasRealSharpness) {
                val shader = getOrCreateSharpenShader()
                val width = if (targetView.width > 0) targetView.width.toFloat() else (if (view.width > 0) view.width.toFloat() else 1920f)
                val height = if (targetView.height > 0) targetView.height.toFloat() else (if (view.height > 0) view.height.toFloat() else 1080f)
                shader.setFloatUniform("resolution", width, height)
                shader.setFloatUniform("sharpness", activeAdjustments.sharpness)
                shader.setFloatUniform("splitRatio", compareSplitRatio)

                val sharpenShaderEffect = RenderEffect.createRuntimeShaderEffect(shader, "contents")

                val finalEffect = if (colorFilterEffect != null) {
                    RenderEffect.createChainEffect(sharpenShaderEffect, colorFilterEffect)
                } else {
                    sharpenShaderEffect
                }
                targetView.setRenderEffect(finalEffect)
            } else if (colorFilterEffect != null) {
                targetView.setRenderEffect(colorFilterEffect)
            } else {
                targetView.setRenderEffect(null)
            }
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            if (isColorModified) {
                val colorFilterEffect = RenderEffect.createColorFilterEffect(ColorMatrixColorFilter(cm))
                targetView.setRenderEffect(colorFilterEffect)
            } else {
                targetView.setRenderEffect(null)
            }
        } else {
            if (isColorModified) {
                val paint = Paint().apply {
                    colorFilter = ColorMatrixColorFilter(cm)
                }
                targetView.setLayerType(View.LAYER_TYPE_HARDWARE, paint)
            } else {
                targetView.setLayerType(View.LAYER_TYPE_NONE, null)
            }
        }
    }
}
