package com.example.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.storage.cleanup.AutoCleanPeriod
import com.example.storage.cleanup.WatchedMediaCleanupItem
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun WatchedMediaReviewDialog(
    viewModel: VideoDownloaderViewModel,
    onDismiss: () -> Unit
) {
    val watchedItems by viewModel.watchedCleanupItems.collectAsStateWithLifecycle()
    val autoCleanSettings by viewModel.autoCleanSettings.collectAsStateWithLifecycle()
    val eligibleItems = remember(watchedItems) { watchedItems.filter { it.isEligibleNow } }
    var selectedFilter by remember { mutableStateOf("All") } // "All", "Eligible", "Protected"
    var selectedMediaIds by remember { mutableStateOf<Set<String>>(emptySet()) }
    var showConfirmDeleteDialog by remember { mutableStateOf(false) }

    val displayedItems = remember(watchedItems, selectedFilter) {
        when (selectedFilter) {
            "Eligible" -> watchedItems.filter { it.isEligibleNow }
            "Protected" -> watchedItems.filter { it.protectionReason != null || it.isKept || it.isProtected || it.isFavorite }
            else -> watchedItems
        }
    }

    // Auto select eligible items on open
    LaunchedEffect(eligibleItems) {
        if (selectedMediaIds.isEmpty() && eligibleItems.isNotEmpty()) {
            selectedMediaIds = eligibleItems.map { it.mediaId }.toSet()
        }
    }

    val selectedItems = remember(displayedItems, selectedMediaIds) {
        displayedItems.filter { selectedMediaIds.contains(it.mediaId) }
    }

    val totalSelectedBytes = remember(selectedItems) { selectedItems.sumOf { it.fileSize } }
    val totalSelectedMb = totalSelectedBytes / (1024.0 * 1024.0)
    val totalSelectedFormatted = if (totalSelectedMb > 1024) {
        String.format(Locale.US, "%.2f GB", totalSelectedMb / 1024.0)
    } else {
        String.format(Locale.US, "%.1f MB", totalSelectedMb)
    }

    val isAllSelected = remember(displayedItems, selectedMediaIds) {
        displayedItems.isNotEmpty() && displayedItems.all { selectedMediaIds.contains(it.mediaId) }
    }

    val totalBytes = remember(displayedItems) { displayedItems.sumOf { it.fileSize } }
    val totalMb = totalBytes / (1024.0 * 1024.0)
    val totalSizeFormatted = if (totalMb > 1024) {
        String.format(Locale.US, "%.2f GB", totalMb / 1024.0)
    } else {
        String.format(Locale.US, "%.1f MB", totalMb)
    }

    var isCleaning by remember { mutableStateOf(false) }
    var cleanupResultMessage by remember { mutableStateOf<String?>(null) }

    val dateFormat = remember { SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault()) }

    // Confirmation Alert
    if (showConfirmDeleteDialog) {
        AlertDialog(
            onDismissRequest = { showConfirmDeleteDialog = false },
            icon = {
                Icon(Icons.Default.DeleteForever, contentDescription = null, tint = CrimsonFailure, modifier = Modifier.size(32.dp))
            },
            title = {
                Text("Delete ${selectedItems.size} Watched Videos?", fontWeight = FontWeight.Bold, color = SleekTextPrimary)
            },
            text = {
                Text(
                    "This will permanently delete the ${selectedItems.size} selected watched video files from your device memory, freeing up $totalSelectedFormatted.",
                    color = SleekTextSecondary,
                    fontSize = 13.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showConfirmDeleteDialog = false
                        isCleaning = true
                        val idsToDelete = selectedItems.map { it.mediaId }.toSet()
                        viewModel.runManualStorageCleanup(idsToDelete) { result ->
                            isCleaning = false
                            selectedMediaIds = selectedMediaIds - idsToDelete
                            cleanupResultMessage = "Deleted ${result.deletedCount} files (${result.freedBytes / (1024 * 1024)} MB freed)"
                            viewModel.refreshWatchedCleanupList()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CrimsonFailure)
                ) {
                    Text("Delete Selected", color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showConfirmDeleteDialog = false }) {
                    Text("Cancel", color = SleekTextSecondary)
                }
            },
            containerColor = SleekCardDark,
            shape = RoundedCornerShape(20.dp)
        )
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .fillMaxHeight(0.90f)
                .clip(RoundedCornerShape(24.dp))
                .border(1.dp, SleekBorderColor, RoundedCornerShape(24.dp)),
            color = SleekBg
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(SleekPurpleLight.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.AutoDelete,
                                contentDescription = "Auto-Clean Review",
                                tint = SleekPurpleLight,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Column {
                            Text(
                                text = "Watched Media Review",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = SleekTextPrimary
                            )
                            Text(
                                text = "Auto-clean: ${autoCleanSettings.period.displayName} · $totalSizeFormatted",
                                style = MaterialTheme.typography.bodySmall,
                                color = SleekTextSecondary
                            )
                        }
                    }

                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = SleekTextSecondary)
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Filter Chips
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = selectedFilter == "All",
                        onClick = { selectedFilter = "All" },
                        label = { Text("All (${watchedItems.size})", fontSize = 12.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = SleekPurpleDark,
                            selectedLabelColor = Color.White,
                            containerColor = SleekCardDark,
                            labelColor = SleekTextSecondary
                        ),
                        border = FilterChipDefaults.filterChipBorder(
                            enabled = true,
                            selected = selectedFilter == "All",
                            borderColor = SleekBorderColor,
                            selectedBorderColor = SleekPurpleLight
                        )
                    )

                    FilterChip(
                        selected = selectedFilter == "Eligible",
                        onClick = { selectedFilter = "Eligible" },
                        label = { Text("Eligible (${eligibleItems.size})", fontSize = 12.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = EmeraldSuccess.copy(alpha = 0.8f),
                            selectedLabelColor = Color.White,
                            containerColor = SleekCardDark,
                            labelColor = SleekTextSecondary
                        ),
                        border = FilterChipDefaults.filterChipBorder(
                            enabled = true,
                            selected = selectedFilter == "Eligible",
                            borderColor = SleekBorderColor,
                            selectedBorderColor = EmeraldSuccess
                        )
                    )

                    FilterChip(
                        selected = selectedFilter == "Protected",
                        onClick = { selectedFilter = "Protected" },
                        label = {
                            val protCount = watchedItems.count { it.protectionReason != null || it.isKept || it.isProtected || it.isFavorite }
                            Text("Protected ($protCount)", fontSize = 12.sp)
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Color(0xFFF59E0B).copy(alpha = 0.8f),
                            selectedLabelColor = Color.White,
                            containerColor = SleekCardDark,
                            labelColor = SleekTextSecondary
                        ),
                        border = FilterChipDefaults.filterChipBorder(
                            enabled = true,
                            selected = selectedFilter == "Protected",
                            borderColor = SleekBorderColor,
                            selectedBorderColor = Color(0xFFF59E0B)
                        )
                    )
                }

                // Batch Selection Bar with Checkbox
                Spacer(modifier = Modifier.height(10.dp))
                Surface(
                    color = SleekCardDark,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.clickable {
                                if (isAllSelected) {
                                    val currentDisplayedIds = displayedItems.map { it.mediaId }.toSet()
                                    selectedMediaIds = selectedMediaIds - currentDisplayedIds
                                } else {
                                    val currentDisplayedIds = displayedItems.map { it.mediaId }.toSet()
                                    selectedMediaIds = selectedMediaIds + currentDisplayedIds
                                }
                            }
                        ) {
                            Checkbox(
                                checked = isAllSelected,
                                onCheckedChange = { checked ->
                                    val currentDisplayedIds = displayedItems.map { it.mediaId }.toSet()
                                    selectedMediaIds = if (checked) selectedMediaIds + currentDisplayedIds else selectedMediaIds - currentDisplayedIds
                                },
                                colors = CheckboxDefaults.colors(
                                    checkedColor = SleekPurpleLight,
                                    uncheckedColor = SleekTextSecondary,
                                    checkmarkColor = Color.White
                                )
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (isAllSelected) "Deselect All" else "Select All",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = SleekTextPrimary
                            )
                        }

                        Text(
                            text = "Selected: ${selectedItems.size} ($totalSelectedFormatted)",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (selectedItems.isNotEmpty()) SleekPurpleLight else SleekTextSecondary
                        )
                    }
                }

                if (cleanupResultMessage != null) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Surface(
                        color = EmeraldSuccess.copy(alpha = 0.15f),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = EmeraldSuccess, modifier = Modifier.size(18.dp))
                            Text(
                                text = cleanupResultMessage ?: "",
                                color = EmeraldSuccess,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Items list
                if (displayedItems.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth(),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Visibility,
                                contentDescription = null,
                                tint = SleekTextSecondary.copy(alpha = 0.4f),
                                modifier = Modifier.size(48.dp)
                            )
                            Text(
                                text = if (selectedFilter == "Eligible") {
                                    "No watched files are currently eligible for cleanup."
                                } else if (selectedFilter == "Protected") {
                                    "No protected files in watched media."
                                } else {
                                    "No watched downloads recorded yet."
                                },
                                color = SleekTextSecondary,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Medium
                            )
                            Text(
                                text = "Media becomes eligible once playback reaches the final 2–5% of duration.",
                                color = SleekTextSecondary.copy(alpha = 0.7f),
                                fontSize = 11.sp
                            )
                        }
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(displayedItems, key = { it.mediaId }) { item ->
                            val isChecked = selectedMediaIds.contains(item.mediaId)
                            WatchedMediaCard(
                                item = item,
                                isChecked = isChecked,
                                dateFormat = dateFormat,
                                onToggleCheck = {
                                    selectedMediaIds = if (isChecked) {
                                        selectedMediaIds - item.mediaId
                                    } else {
                                        selectedMediaIds + item.mediaId
                                    }
                                },
                                onToggleKeep = { viewModel.toggleItemKeepState(item.mediaId, item.isKept) },
                                onDeleteNow = {
                                    viewModel.runManualStorageCleanup(setOf(item.mediaId)) { result ->
                                        cleanupResultMessage = "Cleaned ${item.title}"
                                        viewModel.refreshWatchedCleanupList()
                                    }
                                }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Bottom Action Bar
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = SleekTextSecondary),
                        border = BorderStroke(1.dp, SleekBorderColor)
                    ) {
                        Text("Close", fontWeight = FontWeight.SemiBold)
                    }

                    Button(
                        onClick = { showConfirmDeleteDialog = true },
                        enabled = selectedItems.isNotEmpty() && !isCleaning,
                        modifier = Modifier.weight(1.5f),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = CrimsonFailure,
                            disabledContainerColor = SleekCardDark,
                            contentColor = Color.White
                        )
                    ) {
                        if (isCleaning) {
                            CircularProgressIndicator(color = Color.White, modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Cleaning...", fontSize = 13.sp)
                        } else {
                            Icon(Icons.Default.DeleteSweep, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (selectedItems.isNotEmpty()) "Remove (${selectedItems.size})" else "Remove Selected",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun WatchedMediaCard(
    item: WatchedMediaCleanupItem,
    isChecked: Boolean,
    dateFormat: SimpleDateFormat,
    onToggleCheck: () -> Unit,
    onToggleKeep: () -> Unit,
    onDeleteNow: () -> Unit
) {
    val mb = item.fileSize / (1024.0 * 1024.0)
    val sizeFormatted = if (mb > 1024) String.format(Locale.US, "%.2f GB", mb / 1024.0) else String.format(Locale.US, "%.1f MB", mb)
    val completedDateStr = remember(item.completedTimestamp) {
        if (item.completedTimestamp > 0) dateFormat.format(Date(item.completedTimestamp)) else "Unknown"
    }
    val scheduledDateStr = remember(item.scheduledDeletionTimestamp) {
        if (item.scheduledDeletionTimestamp > 0) dateFormat.format(Date(item.scheduledDeletionTimestamp)) else "N/A"
    }

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .border(
                1.dp,
                if (isChecked) SleekPurpleLight.copy(alpha = 0.7f) else if (item.isEligibleNow) EmeraldSuccess.copy(alpha = 0.5f) else SleekBorderColor,
                RoundedCornerShape(16.dp)
            )
            .clickable { onToggleCheck() },
        color = if (isChecked) SleekCardDark.copy(alpha = 0.95f) else SleekCard
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.Top,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Checkbox(
                        checked = isChecked,
                        onCheckedChange = { onToggleCheck() },
                        colors = CheckboxDefaults.colors(
                            checkedColor = SleekPurpleLight,
                            uncheckedColor = SleekTextSecondary.copy(alpha = 0.7f),
                            checkmarkColor = Color.White
                        )
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = item.title,
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                            color = SleekTextPrimary,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Size: $sizeFormatted · Completed: $completedDateStr",
                            style = MaterialTheme.typography.bodySmall,
                            color = SleekTextSecondary,
                            fontSize = 11.sp
                        )
                    }
                }
            }

            // Status and Schedule info
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Status Badge
                if (item.protectionReason != null) {
                    Surface(
                        color = Color(0xFFF59E0B).copy(alpha = 0.15f),
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(1.dp, Color(0xFFF59E0B).copy(alpha = 0.4f))
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(Icons.Default.Lock, contentDescription = null, tint = Color(0xFFF59E0B), modifier = Modifier.size(12.dp))
                            Text(
                                text = item.protectionReason,
                                color = Color(0xFFF59E0B),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                } else if (item.isEligibleNow) {
                    Surface(
                        color = EmeraldSuccess.copy(alpha = 0.15f),
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(1.dp, EmeraldSuccess.copy(alpha = 0.4f))
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = EmeraldSuccess, modifier = Modifier.size(12.dp))
                            Text(
                                text = "Eligible for Auto-Clean",
                                color = EmeraldSuccess,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                } else {
                    Surface(
                        color = SleekPurpleLight.copy(alpha = 0.12f),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(Icons.Default.Schedule, contentDescription = null, tint = SleekPurpleLight, modifier = Modifier.size(12.dp))
                            Text(
                                text = "Scheduled: $scheduledDateStr",
                                color = SleekPurpleLight,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }

                // Action buttons
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Keep button
                    Surface(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .clickable { onToggleKeep() },
                        color = if (item.isKept) Color(0xFFFFD700).copy(alpha = 0.2f) else SleekCardDark,
                        border = BorderStroke(1.dp, if (item.isKept) Color(0xFFFFD700) else SleekBorderColor)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = if (item.isKept) Icons.Default.BookmarkAdded else Icons.Default.BookmarkBorder,
                                contentDescription = "Keep",
                                tint = if (item.isKept) Color(0xFFFFD700) else SleekTextSecondary,
                                modifier = Modifier.size(14.dp)
                            )
                            Text(
                                text = if (item.isKept) "Kept" else "Keep",
                                color = if (item.isKept) Color(0xFFFFD700) else SleekTextSecondary,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    // Delete single button
                    IconButton(
                        onClick = onDeleteNow,
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.DeleteOutline,
                            contentDescription = "Delete item",
                            tint = CrimsonFailure.copy(alpha = 0.8f),
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }
    }
}
