package com.example.media.operations

import android.content.Context
import android.net.Uri
import android.util.Log
import com.example.media.DecoderCapabilityManager
import com.example.media.probe.MediaProbeEngine
import com.example.media.probe.MediaProbeInfo
import java.io.File

object FallbackValidator {
    private const val TAG = "FallbackValidator"

    suspend fun validateFallbackOutput(
        context: Context,
        tempFile: File,
        request: MediaConversionRequest? = null,
        isRemux: Boolean = false,
        probeFunc: suspend (Context, Uri) -> Result<MediaProbeInfo> = { ctx, uri -> MediaProbeEngine.probeMedia(ctx, uri) }
    ): Result<Unit> {
        Log.i("FALLBACK_TRACE", "[FALLBACK_VALIDATION_START] Validating $tempFile")
        
        if (!tempFile.exists()) {
            return Result.failure(IllegalStateException("OUTPUT_MISSING: Temporary file is missing"))
        }
        if (tempFile.length() == 0L) {
            return Result.failure(IllegalStateException("OUTPUT_EMPTY: Temporary file is empty"))
        }

        val probeResult = probeFunc(context, Uri.fromFile(tempFile))
        val info = probeResult.getOrNull()
        if (info == null) {
            return Result.failure(IllegalStateException("FFPROBE_FAILED: FFprobe failed to inspect fallback output"))
        }

        Log.i("FALLBACK_TRACE", "[FALLBACK_FFPROBE_RESULT] Success")

        // 1. Container validation
        val format = info.format.lowercase()
        if (!format.contains("mp4") && !format.contains("mov") && !format.contains("m4a") && !format.contains("3gp")) {
            return Result.failure(IllegalStateException("CONTAINER_INVALID: Invalid container format $format (expected mp4)"))
        }

        // 2. Duration validation
        if (info.durationMs <= 0L) {
            return Result.failure(IllegalStateException("VIDEO_DURATION_INVALID: Duration is ${info.durationMs} ms"))
        }

        // 3. Video Stream Validation
        val primaryVideo = info.primaryVideo
        if (primaryVideo == null) {
            return Result.failure(IllegalStateException("OUTPUT_MISSING: No video stream found in output"))
        }

        // Reject if there are multiple video streams because the fallback should map only 1
        if (info.videoStreams.size > 1) {
            return Result.failure(IllegalStateException("STREAM_MAPPING_INVALID: Found ${info.videoStreams.size} video streams, expected 1"))
        }

        val codec = primaryVideo.codec.lowercase()
        if (codec != "h264" && codec != "avc1" && codec != "avc") {
            return Result.failure(IllegalStateException("VIDEO_CODEC_INVALID: Video codec is $codec (expected h264)"))
        }

        // 4. Resolution & Framerate Validation
        if (primaryVideo.width <= 0 || primaryVideo.height <= 0) {
            return Result.failure(IllegalStateException("VIDEO_RESOLUTION_INVALID: Dimensions are ${primaryVideo.width}x${primaryVideo.height}"))
        }
        if (primaryVideo.frameRate <= 0f) {
            return Result.failure(IllegalStateException("VIDEO_FRAMERATE_INVALID: Frame rate is ${primaryVideo.frameRate}"))
        }

        // 5. Normalization Trace
        val pixFmt = primaryVideo.pixelFormat?.lowercase() ?: ""
        val bitDepth = primaryVideo.bitDepth
        val profileStr = primaryVideo.profile
        val normalizedProfile = if (profileStr != null) DecoderCapabilityManager.normalizeProfile(primaryVideo.codec, profileStr) else ""
        
        Log.i("FALLBACK_TRACE", "[FALLBACK_METADATA_NORMALIZED] codec=$codec profile=$normalizedProfile pixFmt=$pixFmt bitDepth=$bitDepth")
        Log.i("FALLBACK_TRACE", "[FALLBACK_CONTRACT_CHECK] isRemux=$isRemux reqVideo=${request?.videoCodec}")

        // 6. Metadata Inconsistency & Contract Checks
        val profileImplies10Bit = normalizedProfile.contains("High 10") || normalizedProfile.contains("10-bit") || (normalizedProfile.contains("10") && !normalizedProfile.contains("High 4"))
        val pixFmtImplies10Bit = pixFmt.contains("10")

        if ((bitDepth == 10 && pixFmt == "yuv420p") ||
            (bitDepth == 8 && pixFmtImplies10Bit) ||
            (bitDepth == 8 && profileImplies10Bit) ||
            (bitDepth == 10 && (normalizedProfile == "High" || normalizedProfile == "Main" || normalizedProfile == "Baseline"))
        ) {
            Log.i("FALLBACK_TRACE", "[FALLBACK_VALIDATION_FAIL] METADATA_INCONSISTENT")
            return Result.failure(IllegalStateException("METADATA_INCONSISTENT: bitDepth=$bitDepth, pixFmt=$pixFmt, profile=$normalizedProfile"))
        }

        if (!isRemux && request?.videoCodec != "copy" && request?.videoCodec != null) {
            if (pixFmt != "yuv420p") {
                Log.i("FALLBACK_TRACE", "[FALLBACK_VALIDATION_FAIL] VIDEO_PIXEL_FORMAT_INVALID")
                return Result.failure(IllegalStateException("VIDEO_PIXEL_FORMAT_INVALID: Pixel format is $pixFmt (expected yuv420p)"))
            }
            if (bitDepth != 8) {
                Log.i("FALLBACK_TRACE", "[FALLBACK_VALIDATION_FAIL] VIDEO_BIT_DEPTH_INVALID")
                return Result.failure(IllegalStateException("VIDEO_BIT_DEPTH_INVALID: Bit depth is $bitDepth (expected 8)"))
            }
            if (profileImplies10Bit || normalizedProfile.contains("4:2:2") || normalizedProfile.contains("4:4:4")) {
                Log.i("FALLBACK_TRACE", "[FALLBACK_VALIDATION_FAIL] VIDEO_PROFILE_INVALID")
                return Result.failure(IllegalStateException("VIDEO_PROFILE_INVALID: Profile is $normalizedProfile (expected standard 8-bit profile)"))
            }
        }

        // 7. Audio Validation
        if (request?.audioCodec != "none") {
            if (info.audioStreams.size > 1) {
                return Result.failure(IllegalStateException("STREAM_MAPPING_INVALID: Found ${info.audioStreams.size} audio streams, expected at most 1"))
            }
            
            val primaryAudio = info.primaryAudio
            if (primaryAudio == null) {
                if (request?.audioCodec == "aac" || request?.audioCodec == "copy") {
                     return Result.failure(IllegalStateException("AUDIO_MISSING: Audio stream requested but not found in output"))
                }
            } else {
                val aCodec = primaryAudio.codec.lowercase()
                if (request?.audioCodec == "aac" && aCodec != "aac") {
                    return Result.failure(IllegalStateException("AUDIO_CODEC_INVALID: Expected aac, got $aCodec"))
                }
            }
        }
        
        Log.i("FALLBACK_TRACE", "[FALLBACK_VALIDATION_PASS] Output meets fallback contract")
        return Result.success(Unit)
    }
}
