package com.example.ui

import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.AppDatabase
import com.example.storage.cleanup.UnwantedFileCategory
import com.example.storage.cleanup.UnwantedFileItem
import com.example.storage.cleanup.UnwantedFilesCleanerManager
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun UnwantedFilesCleanerDialog(
    onDismiss: () -> Unit,
    onFilesRemoved: (freedBytes: Long, count: Int) -> Unit = { _, _ -> }
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val database = remember { AppDatabase.getDatabase(context) }

    var isScanning by remember { mutableStateOf(true) }
    var isDeleting by remember { mutableStateOf(false) }
    var unwantedItems by remember { mutableStateOf<List<UnwantedFileItem>>(emptyList()) }
    var selectedItemIds by remember { mutableStateOf<Set<String>>(emptySet()) }
    var selectedCategoryFilter by remember { mutableStateOf<UnwantedFileCategory?>(null) }
    var showConfirmDeleteDialog by remember { mutableStateOf(false) }
    var statusMessage by remember { mutableStateOf<String?>(null) }

    fun refreshScan() {
        coroutineScope.launch {
            isScanning = true
            val items = UnwantedFilesCleanerManager.scanUnwantedFiles(context, database)
            unwantedItems = items
            // By default, pre-select temp, cache, broken, and log files
            val defaultSelected = items.filter { it.category != UnwantedFileCategory.WATCHED_MEDIA }.map { it.id }.toSet()
            selectedItemIds = defaultSelected
            isScanning = false
        }
    }

    LaunchedEffect(Unit) {
        refreshScan()
    }

    val filteredItems = remember(unwantedItems, selectedCategoryFilter) {
        if (selectedCategoryFilter == null) {
            unwantedItems
        } else {
            unwantedItems.filter { it.category == selectedCategoryFilter }
        }
    }

    val selectedItems = remember(unwantedItems, selectedItemIds) {
        unwantedItems.filter { selectedItemIds.contains(it.id) }
    }

    val totalSelectedBytes = remember(selectedItems) {
        selectedItems.fold(0L) { acc, item -> acc + item.sizeBytes }
    }

    val totalSelectedFormatted = remember(totalSelectedBytes) {
        formatCleanerBytes(totalSelectedBytes)
    }

    val totalAllBytes = remember(unwantedItems) {
        unwantedItems.fold(0L) { acc, item -> acc + item.sizeBytes }
    }

    val totalAllFormatted = remember(totalAllBytes) {
        formatCleanerBytes(totalAllBytes)
    }

    val isAllSelected = remember(filteredItems, selectedItemIds) {
        filteredItems.isNotEmpty() && filteredItems.all { selectedItemIds.contains(it.id) }
    }

    val dateFormat = remember { SimpleDateFormat("dd MMM, HH:mm", Locale.getDefault()) }

    // Confirmation Alert Dialog
    if (showConfirmDeleteDialog) {
        AlertDialog(
            onDismissRequest = { showConfirmDeleteDialog = false },
            icon = {
                Icon(
                    Icons.Default.DeleteForever,
                    contentDescription = null,
                    tint = CrimsonFailure,
                    modifier = Modifier.size(32.dp)
                )
            },
            title = {
                Text(
                    "Delete ${selectedItems.size} Unwanted Files?",
                    fontWeight = FontWeight.Bold,
                    color = SleekTextPrimary
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        "This will permanently remove selected temporary files, caches, and unwanted items from device storage, freeing up $totalSelectedFormatted.",
                        color = SleekTextSecondary,
                        fontSize = 13.sp
                    )
                    Text(
                        "This operation cannot be undone.",
                        color = CrimsonFailure.copy(alpha = 0.9f),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showConfirmDeleteDialog = false
                        coroutineScope.launch {
                            isDeleting = true
                            val itemsToDelete = selectedItems
                            val result = UnwantedFilesCleanerManager.removeSelectedFiles(context, database, itemsToDelete)
                            isDeleting = false
                            val freedFormatted = formatCleanerBytes(result.freedBytes)
                            statusMessage = "Successfully removed ${result.deletedCount} files ($freedFormatted freed)"
                            onFilesRemoved(result.freedBytes, result.deletedCount)
                            refreshScan()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CrimsonFailure)
                ) {
                    Text("Delete Permanently", color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showConfirmDeleteDialog = false }) {
                    Text("Cancel", color = SleekTextSecondary)
                }
            },
            containerColor = SleekCardDark,
            shape = RoundedCornerShape(20.dp)
        )
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .fillMaxHeight(0.90f)
                .clip(RoundedCornerShape(24.dp))
                .border(1.dp, SleekBorderColor, RoundedCornerShape(24.dp)),
            color = SleekBg
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(42.dp)
                                .clip(CircleShape)
                                .background(SleekPurpleLight.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.CleaningServices,
                                contentDescription = "Cleaner",
                                tint = SleekPurpleLight,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        Column {
                            Text(
                                text = "Unwanted Files Cleaner",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = SleekTextPrimary
                            )
                            Text(
                                text = if (isScanning) "Scanning storage..." else "${unwantedItems.size} items detected · $totalAllFormatted total",
                                style = MaterialTheme.typography.bodySmall,
                                color = SleekTextSecondary
                            )
                        }
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        IconButton(
                            onClick = { refreshScan() },
                            enabled = !isScanning && !isDeleting,
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(
                                Icons.Default.Refresh,
                                contentDescription = "Refresh Scan",
                                tint = SleekTextSecondary
                            )
                        }
                        IconButton(
                            onClick = onDismiss,
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(Icons.Default.Close, contentDescription = "Close", tint = SleekTextSecondary)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Category Filter Chips
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = selectedCategoryFilter == null,
                        onClick = { selectedCategoryFilter = null },
                        label = { Text("All (${unwantedItems.size})", fontSize = 11.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = SleekPurpleDark,
                            selectedLabelColor = Color.White,
                            containerColor = SleekCardDark,
                            labelColor = SleekTextSecondary
                        ),
                        border = FilterChipDefaults.filterChipBorder(
                            enabled = true,
                            selected = selectedCategoryFilter == null,
                            borderColor = SleekBorderColor,
                            selectedBorderColor = SleekPurpleLight
                        )
                    )

                    UnwantedFileCategory.entries.forEach { category ->
                        val count = unwantedItems.count { it.category == category }
                        if (count > 0) {
                            FilterChip(
                                selected = selectedCategoryFilter == category,
                                onClick = {
                                    selectedCategoryFilter = if (selectedCategoryFilter == category) null else category
                                },
                                label = { Text("${category.displayName} ($count)", fontSize = 11.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = SleekPurpleLight.copy(alpha = 0.3f),
                                    selectedLabelColor = SleekPurpleLight,
                                    containerColor = SleekCardDark,
                                    labelColor = SleekTextSecondary
                                ),
                                border = FilterChipDefaults.filterChipBorder(
                                    enabled = true,
                                    selected = selectedCategoryFilter == category,
                                    borderColor = SleekBorderColor,
                                    selectedBorderColor = SleekPurpleLight
                                )
                            )
                        }
                    }
                }

                // Batch Selection Bar
                Spacer(modifier = Modifier.height(10.dp))
                Surface(
                    color = SleekCardDark,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.clickable {
                                if (isAllSelected) {
                                    val filteredIds = filteredItems.map { it.id }.toSet()
                                    selectedItemIds = selectedItemIds - filteredIds
                                } else {
                                    val filteredIds = filteredItems.map { it.id }.toSet()
                                    selectedItemIds = selectedItemIds + filteredIds
                                }
                            }
                        ) {
                            Checkbox(
                                checked = isAllSelected,
                                onCheckedChange = { checked ->
                                    val filteredIds = filteredItems.map { it.id }.toSet()
                                    selectedItemIds = if (checked) selectedItemIds + filteredIds else selectedItemIds - filteredIds
                                },
                                colors = CheckboxDefaults.colors(
                                    checkedColor = SleekPurpleLight,
                                    uncheckedColor = SleekTextSecondary,
                                    checkmarkColor = Color.White
                                )
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (isAllSelected) "Deselect All" else "Select All",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = SleekTextPrimary
                            )
                        }

                        Text(
                            text = "Selected: ${selectedItems.size} ($totalSelectedFormatted)",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (selectedItems.isNotEmpty()) SleekPurpleLight else SleekTextSecondary
                        )
                    }
                }

                // Status banner if present
                if (statusMessage != null) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Surface(
                        color = EmeraldSuccess.copy(alpha = 0.15f),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = EmeraldSuccess, modifier = Modifier.size(16.dp))
                            Text(
                                text = statusMessage ?: "",
                                color = EmeraldSuccess,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // List of Unwanted Files
                if (isScanning) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth(),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            CircularProgressIndicator(color = SleekPurpleLight, modifier = Modifier.size(36.dp), strokeWidth = 3.dp)
                            Text("Scanning device for unwanted files...", color = SleekTextSecondary, fontSize = 13.sp)
                        }
                    }
                } else if (filteredItems.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth(),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.CheckCircleOutline,
                                contentDescription = null,
                                tint = EmeraldSuccess,
                                modifier = Modifier.size(48.dp)
                            )
                            Text(
                                text = "Storage is Clean!",
                                color = SleekTextPrimary,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "No unwanted temporary files or junk fragments found.",
                                color = SleekTextSecondary,
                                fontSize = 12.sp
                            )
                        }
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(filteredItems, key = { it.id }) { item ->
                            val isChecked = selectedItemIds.contains(item.id)
                            UnwantedFileRow(
                                item = item,
                                isChecked = isChecked,
                                dateFormat = dateFormat,
                                onToggle = {
                                    selectedItemIds = if (isChecked) {
                                        selectedItemIds - item.id
                                    } else {
                                        selectedItemIds + item.id
                                    }
                                }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Bottom Action Bar
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = SleekTextSecondary),
                        border = BorderStroke(1.dp, SleekBorderColor)
                    ) {
                        Text("Close", fontWeight = FontWeight.SemiBold)
                    }

                    Button(
                        onClick = { showConfirmDeleteDialog = true },
                        enabled = selectedItems.isNotEmpty() && !isDeleting && !isScanning,
                        modifier = Modifier.weight(1.5f),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = CrimsonFailure,
                            disabledContainerColor = SleekCardDark,
                            contentColor = Color.White
                        )
                    ) {
                        if (isDeleting) {
                            CircularProgressIndicator(color = Color.White, modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Removing...", fontSize = 13.sp)
                        } else {
                            Icon(Icons.Default.DeleteSweep, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (selectedItems.isNotEmpty()) "Remove (${selectedItems.size})" else "Remove Selected",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun UnwantedFileRow(
    item: UnwantedFileItem,
    isChecked: Boolean,
    dateFormat: SimpleDateFormat,
    onToggle: () -> Unit
) {
    val sizeFormatted = remember(item.sizeBytes) { formatCleanerBytes(item.sizeBytes) }
    val dateStr = remember(item.lastModifiedMs) {
        if (item.lastModifiedMs > 0) dateFormat.format(Date(item.lastModifiedMs)) else ""
    }

    val (badgeColor, categoryIcon) = when (item.category) {
        UnwantedFileCategory.TEMP_AND_PARTIAL -> Color(0xFFF59E0B) to Icons.Default.Pending
        UnwantedFileCategory.TRANSCODE_CACHE -> SleekPurpleLight to Icons.Default.FolderZip
        UnwantedFileCategory.BROKEN_FILES -> CrimsonFailure to Icons.Default.BrokenImage
        UnwantedFileCategory.WATCHED_MEDIA -> EmeraldSuccess to Icons.Default.CheckCircle
        UnwantedFileCategory.LOGS_AND_TRACES -> SleekTextSecondary to Icons.Default.Description
    }

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .border(
                1.dp,
                if (isChecked) SleekPurpleLight.copy(alpha = 0.6f) else SleekBorderColor,
                RoundedCornerShape(14.dp)
            )
            .clickable { onToggle() },
        color = if (isChecked) SleekCardDark.copy(alpha = 0.95f) else SleekCardDark.copy(alpha = 0.6f)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Check Box
            Checkbox(
                checked = isChecked,
                onCheckedChange = { onToggle() },
                colors = CheckboxDefaults.colors(
                    checkedColor = SleekPurpleLight,
                    uncheckedColor = SleekTextSecondary.copy(alpha = 0.7f),
                    checkmarkColor = Color.White
                )
            )

            Spacer(modifier = Modifier.width(6.dp))

            // Category Icon Badge
            Box(
                modifier = Modifier
                    .size(34.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(badgeColor.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = categoryIcon,
                    contentDescription = null,
                    tint = badgeColor,
                    modifier = Modifier.size(18.dp)
                )
            }

            Spacer(modifier = Modifier.width(10.dp))

            // File Information
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = item.name,
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                    color = SleekTextPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                Spacer(modifier = Modifier.height(2.dp))

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = item.reason,
                        fontSize = 11.sp,
                        color = badgeColor,
                        fontWeight = FontWeight.Medium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    if (dateStr.isNotBlank()) {
                        Text(
                            text = "· $dateStr",
                            fontSize = 10.sp,
                            color = SleekTextSecondary
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.width(8.dp))

            // Size Badge
            Surface(
                color = SleekBg,
                shape = RoundedCornerShape(8.dp),
                border = BorderStroke(1.dp, SleekBorderColor)
            ) {
                Text(
                    text = sizeFormatted,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (item.sizeBytes > 0) SleekTextPrimary else SleekTextSecondary
                )
            }
        }
    }
}

private fun formatCleanerBytes(bytes: Long): String {
    val mb = bytes / (1024.0 * 1024.0)
    return when {
        bytes <= 0L -> "0 B"
        mb >= 1024.0 -> String.format(Locale.US, "%.2f GB", mb / 1024.0)
        mb >= 1.0 -> String.format(Locale.US, "%.1f MB", mb)
        else -> String.format(Locale.US, "%.1f KB", bytes / 1024.0)
    }
}
