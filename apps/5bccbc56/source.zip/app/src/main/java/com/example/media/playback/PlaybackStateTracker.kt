package com.example.media.playback

import android.util.Log

enum class PlaybackTraceState {
    IDLE,
    ANALYZING,
    DIRECT_PREPARING,
    DIRECT_PLAYING,
    FALLBACK_REQUIRED,
    FALLBACK_PROCESSING,
    FALLBACK_VALIDATING,
    FALLBACK_PREPARING,
    FALLBACK_PLAYING,
    DIRECT_SUCCESS,
    DIRECT_FAILED,
    FALLBACK_SUCCESS,
    FALLBACK_FAILED,
    CANCELLED
}

object PlaybackStateTracker {
    private const val TAG_TRACE = "PLAYBACK_STATE_TRACE"
    private const val TAG_FINAL = "PLAYBACK_FINAL_RESULT"
    private const val TAG_INVARIANT = "PLAYBACK_INVARIANT"

    /**
     * Logs a state transition strictly adhering to:
     * [PLAYBACK_STATE_TRACE][id=$requestId] $oldState -> $newState (cause=$cause)
     */
    fun logTransition(
        requestId: String,
        oldState: String,
        newState: String,
        cause: String
    ) {
        Log.i(TAG_TRACE, "[$TAG_TRACE][id=$requestId] $oldState -> $newState (cause=$cause)")
        try {
            PlaybackDiagnosticRegistry.recordEvent(
                eventType = when (newState) {
                    "DIRECT_PLAYING", "FALLBACK_PLAYING" -> DiagnosticEventType.MEDIA3_PLAYBACK_STARTED
                    "DIRECT_PREPARING", "FALLBACK_PREPARING" -> DiagnosticEventType.MEDIA3_PREPARE_STARTED
                    "FALLBACK_PROCESSING" -> DiagnosticEventType.FFMPEG_JOB_STARTED
                    "FALLBACK_VALIDATING" -> DiagnosticEventType.FALLBACK_VALIDATION_STARTED
                    "CANCELLED" -> DiagnosticEventType.REQUEST_CANCELLED
                    else -> DiagnosticEventType.INPUT_RECEIVED
                },
                stage = PlaybackErrorStage.MEDIA3_PLAYBACK,
                severity = if (newState.contains("FAIL")) DiagnosticSeverity.ERROR else DiagnosticSeverity.INFO,
                playbackRequestId = requestId,
                previousState = oldState,
                newState = newState,
                message = "State transition: $oldState -> $newState (cause=$cause)"
            )
        } catch (_: Throwable) { /* ignore */ }
    }

    /**
     * Logs a terminal outcome strictly adhering to:
     * [PLAYBACK_FINAL_RESULT][id=$requestId] result=$result (path=$playbackPath, fallbackUsed=$fallbackUsed, decoder=$decoder)
     */
    fun logFinalResult(
        requestId: String,
        result: AuthoritativePlaybackResult,
        playbackPath: String,
        fallbackUsed: Boolean,
        decoder: String
    ) {
        val existing = PlaybackDiagnosticRegistry.getTerminalResult(requestId)
        if (existing != null) {
            Log.w(
                "TERMINAL_STATE_GUARD",
                "[TERMINAL_STATE_GUARD][id=$requestId] Rejected duplicate terminal result $result (already committed $existing)"
            )
            return
        }

        Log.i(
            TAG_FINAL,
            "[$TAG_FINAL][id=$requestId] result=${result.name} (path=$playbackPath, fallbackUsed=$fallbackUsed, decoder=$decoder)"
        )

        try {
            PlaybackDiagnosticRegistry.recordEvent(
                eventType = DiagnosticEventType.PLAYBACK_FINAL_RESULT,
                stage = PlaybackErrorStage.MEDIA3_PLAYBACK,
                severity = if (result == AuthoritativePlaybackResult.DIRECT_FAILED || result == AuthoritativePlaybackResult.FALLBACK_FAILED) DiagnosticSeverity.ERROR else DiagnosticSeverity.INFO,
                playbackRequestId = requestId,
                sourceType = if (fallbackUsed) PlaybackSourceType.FALLBACK else PlaybackSourceType.ORIGINAL,
                rawUriOrPath = playbackPath,
                newState = result.name,
                message = "Authoritative playback final result: ${result.name} (decoder=$decoder)"
            )
        } catch (_: Throwable) { /* ignore */ }
    }

    /**
     * Validates and enforces all hard runtime playback state invariants.
     * Returns true if all invariants are satisfied; logs and throws or warns otherwise.
     */
    fun validateInvariants(
        requestId: String,
        result: AuthoritativePlaybackResult?,
        fallbackUsed: Boolean,
        playbackPath: String,
        originalPath: String,
        isProcessingActive: Boolean,
        ffmpegSuccess: Boolean,
        media3Confirmed: Boolean
    ): Boolean {
        var passed = true

        // Invariant 1: If fallbackUsed == true, playbackPath MUST contain cache/fallback path.
        if (fallbackUsed) {
            val isFallbackPath = playbackPath.contains("cache") ||
                    playbackPath.contains("fallback") ||
                    playbackPath.contains("tmp") ||
                    !playbackPath.equals(originalPath, ignoreCase = true)
            if (!isFallbackPath) {
                Log.e(TAG_INVARIANT, "[INVARIANT_1_VIOLATION][id=$requestId] fallbackUsed=true but playbackPath is not a fallback/cache path ($playbackPath)")
                passed = false
            }
        }

        // Invariant 2: If fallbackUsed == false, playbackPath MUST equal original source path.
        if (!fallbackUsed) {
            val cleanOriginal = originalPath.substringBefore("|STREAM_AUDIO_URL|").trim()
            val cleanPlayback = playbackPath.substringBefore("|STREAM_AUDIO_URL|").trim()
            if (cleanPlayback.isNotBlank() && cleanOriginal.isNotBlank() && cleanPlayback != cleanOriginal) {
                Log.e(TAG_INVARIANT, "[INVARIANT_2_VIOLATION][id=$requestId] fallbackUsed=false but playbackPath ($cleanPlayback) does not equal originalPath ($cleanOriginal)")
                passed = false
            }
        }

        // Invariant 3: PLAYBACK_SUCCESS cannot occur while isFallbackProcessingActive == true.
        if ((result == AuthoritativePlaybackResult.DIRECT_SUCCESS || result == AuthoritativePlaybackResult.FALLBACK_SUCCESS) && isProcessingActive) {
            Log.e(TAG_INVARIANT, "[INVARIANT_3_VIOLATION][id=$requestId] SUCCESS result reported while isProcessingActive is true")
            passed = false
        }

        // Invariant 4: FALLBACK_SUCCESS requires both ffmpegSuccess == true AND media3PlaybackConfirmed == true.
        if (result == AuthoritativePlaybackResult.FALLBACK_SUCCESS) {
            if (!ffmpegSuccess || !media3Confirmed) {
                Log.e(TAG_INVARIANT, "[INVARIANT_4_VIOLATION][id=$requestId] FALLBACK_SUCCESS requires ffmpegSuccess=true and media3Confirmed=true (got ffmpegSuccess=$ffmpegSuccess, media3Confirmed=$media3Confirmed)")
                passed = false
            }
        }

        return passed
    }
}
