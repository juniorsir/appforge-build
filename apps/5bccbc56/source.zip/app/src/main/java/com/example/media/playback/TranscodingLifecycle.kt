package com.example.media.playback

/**
 * Phase 17.33: Authoritative Playback Lifecycle States.
 * Decoupled from background transcoding execution.
 */
enum class PlaybackLifecycleState {
    IDLE,
    PLAYBACK_REQUESTED,
    DIRECT_ATTEMPT,
    FALLBACK_REQUIRED,
    FALLBACK_PLAYABLE_AVAILABLE,
    PLAYING,
    PLAYBACK_SUCCESS,
    PLAYBACK_FAILED,
    CANCELLED
}

/**
 * Phase 17.33: Authoritative Background Transcoding Lifecycle States.
 * Transcoding RUNNING must NOT imply playback is blocked.
 */
enum class TranscodingLifecycleState {
    NOT_STARTED,
    QUEUED,
    STARTING,
    RUNNING,
    PARTIAL_OUTPUT_AVAILABLE,
    COMPLETED,
    VALIDATING,
    VALIDATED,
    FAILED,
    CANCELLED;

    /**
     * Section 5: The existing Logs button must become visible whenever:
     * transcodingState in {QUEUED, STARTING, RUNNING, PARTIAL_OUTPUT_AVAILABLE, COMPLETED, VALIDATING, VALIDATED, FAILED, CANCELLED}
     */
    val isLogControlVisible: Boolean
        get() = this != NOT_STARTED

    val isTranscodingActive: Boolean
        get() = this == QUEUED || this == STARTING || this == RUNNING || this == PARTIAL_OUTPUT_AVAILABLE || this == VALIDATING
}
