package com.example.media.playback

import android.util.Log
import com.example.media.ffmpeg.FFmpegProgress
import com.example.media.ffmpeg.FFmpegState
import com.example.media.progressive.ProgressiveGenerationProgress
import com.example.media.progressive.ProgressiveState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ConcurrentLinkedQueue

/**
 * Metadata snapshot for the active or most recent transcoding session.
 */
data class TranscodingSessionMetadata(
    val sessionId: Long = -1L,
    val requestId: String? = null,
    val command: String? = null,
    val strategy: String? = null,
    val status: String = "IDLE",
    val progressPercentage: Float? = null,
    val speed: Double = 0.0,
    val fps: Double = 0.0,
    val outputSizeBytes: Long = 0L,
    val currentTimestampMs: Long = 0L,
    val totalDurationMs: Long = 0L,
    val latestLogLine: String? = null,
    val isActive: Boolean = false
)

/**
 * Authoritative central repository for transcoding logs and diagnostics.
 * Preserves log streams across UI recompositions, player lifecycles, and background execution.
 */
object TranscodingLogManager {
    private const val TAG = "TranscodingLogManager"
    private const val MAX_LOG_CAPACITY = 2000

    private val logQueue = ConcurrentLinkedQueue<String>()

    private val _logs = MutableStateFlow<List<String>>(emptyList())
    val logs: StateFlow<List<String>> = _logs.asStateFlow()

    private val _hasLogs = MutableStateFlow(false)
    val hasLogs: StateFlow<Boolean> = _hasLogs.asStateFlow()

    private val _sessionMetadata = MutableStateFlow(TranscodingSessionMetadata())
    val sessionMetadata: StateFlow<TranscodingSessionMetadata> = _sessionMetadata.asStateFlow()

    private val timeFormatter = SimpleDateFormat("HH:mm:ss.SSS", Locale.US)

    @Synchronized
    private fun getCurrentTimestamp(): String = timeFormatter.format(Date())

    @Synchronized
    fun addLogLine(line: String) {
        logQueue.add(line)
        while (logQueue.size > MAX_LOG_CAPACITY) {
            logQueue.poll()
        }
        val currentList = logQueue.toList()
        _logs.value = currentList
        _hasLogs.value = currentList.isNotEmpty()
    }

    fun recordEvent(tag: String, message: String, requestId: String? = null) {
        val ts = getCurrentTimestamp()
        val formatted = if (requestId != null) {
            "[$ts] [$tag] [id=$requestId] $message"
        } else {
            "[$ts] [$tag] $message"
        }
        Log.i("FALLBACK_TRACE", formatted)
        addLogLine(formatted)
    }

    fun recordLogReceived(sessionId: Long, message: String, requestId: String? = null) {
        val ts = getCurrentTimestamp()
        val formatted = if (sessionId > 0) {
            "[$ts] [TRANSCODING_LOG_RECEIVED] [#$sessionId] $message"
        } else {
            "[$ts] [TRANSCODING_LOG_RECEIVED] $message"
        }
        Log.d("TRANSCODING_LOG_TRACE", formatted)
        addLogLine(formatted)
        _sessionMetadata.value = _sessionMetadata.value.copy(latestLogLine = message)
    }

    fun recordCommand(command: String, requestId: String? = null, sessionId: Long = -1L) {
        val ts = getCurrentTimestamp()
        val formatted = "[$ts] [FFMPEG_COMMAND] $command"
        Log.i("FALLBACK_TRACE", formatted)
        addLogLine(formatted)
        _sessionMetadata.value = _sessionMetadata.value.copy(
            command = command,
            requestId = requestId ?: _sessionMetadata.value.requestId,
            sessionId = if (sessionId > 0) sessionId else _sessionMetadata.value.sessionId,
            isActive = true
        )
    }

    fun recordProgress(progress: FFmpegProgress, requestId: String? = null) {
        val ts = getCurrentTimestamp()
        val pctStr = if (progress.progressPercentage != null) String.format(Locale.US, "%.1f%%", progress.progressPercentage) else "indeterminate"
        val speedStr = if (progress.speed > 0.0) String.format(Locale.US, "%.2fx", progress.speed) else "--"
        val fpsStr = if (progress.fps > 0.0) String.format(Locale.US, "%.0f", progress.fps) else "--"
        val timeMs = progress.currentTimestampMs
        val totalMs = progress.totalDurationMs

        val formatted = "[$ts] [TRANSCODING_PROGRESS_RECEIVED] state=${progress.state} progress=$pctStr speed=$speedStr fps=$fpsStr time=${timeMs}ms/${totalMs}ms"
        Log.d("TRANSCODING_LOG_TRACE", formatted)

        _sessionMetadata.value = _sessionMetadata.value.copy(
            sessionId = if (progress.sessionId > 0) progress.sessionId else _sessionMetadata.value.sessionId,
            requestId = requestId ?: _sessionMetadata.value.requestId,
            status = progress.state.name,
            progressPercentage = progress.progressPercentage,
            speed = progress.speed,
            fps = progress.fps,
            outputSizeBytes = progress.outputSizeBytes,
            currentTimestampMs = progress.currentTimestampMs,
            totalDurationMs = progress.totalDurationMs,
            latestLogLine = progress.latestLogLine ?: _sessionMetadata.value.latestLogLine,
            isActive = (progress.state == FFmpegState.STARTING || progress.state == FFmpegState.RUNNING || progress.state == FFmpegState.VALIDATING)
        )

        progress.latestLogLine?.let { line ->
            if (line.isNotBlank() && !line.startsWith("[$ts]")) {
                addLogLine("[$ts] $line")
            }
        }
    }

    fun recordProgressiveProgress(progress: ProgressiveGenerationProgress, requestId: String? = null) {
        val ts = getCurrentTimestamp()
        val pctStr = String.format(Locale.US, "%.1f%%", progress.progressPercentage)
        val speedStr = String.format(Locale.US, "%.2fx", progress.transcodingSpeed)
        val formatted = "[$ts] [TRANSCODING_PROGRESS_RECEIVED] [progressive] state=${progress.state} progress=$pctStr speed=$speedStr playable=${progress.playableDurationMs}ms units=${progress.publishedUnitsCount}"
        Log.d("TRANSCODING_LOG_TRACE", formatted)

        _sessionMetadata.value = _sessionMetadata.value.copy(
            sessionId = if (progress.sessionId > 0) progress.sessionId else _sessionMetadata.value.sessionId,
            requestId = requestId ?: _sessionMetadata.value.requestId,
            status = progress.state.name,
            progressPercentage = progress.progressPercentage,
            speed = progress.transcodingSpeed.toDouble(),
            fps = progress.fps,
            outputSizeBytes = progress.outputSizeBytes,
            currentTimestampMs = progress.transcodedDurationMs,
            totalDurationMs = progress.sourceDurationMs,
            latestLogLine = progress.latestLogLine ?: _sessionMetadata.value.latestLogLine,
            isActive = (progress.state == ProgressiveState.INITIALIZING || progress.state == ProgressiveState.GENERATING)
        )

        progress.latestLogLine?.let { line ->
            if (line.isNotBlank() && !line.startsWith("[$ts]")) {
                addLogLine("[$ts] $line")
            }
        }
    }

    fun recordUiTrace(action: String, details: String? = null) {
        val ts = getCurrentTimestamp()
        val detailsStr = if (details != null) " - $details" else ""
        val formatted = "[$ts] [TRANSCODING_LOG_UI_TRACE] $action$detailsStr"
        Log.i("TRANSCODING_LOG_UI_TRACE", formatted)
        addLogLine(formatted)
    }

    fun recordCallbackRegistered(component: String, details: String? = null) {
        val ts = getCurrentTimestamp()
        val detailsStr = if (details != null) " ($details)" else ""
        val formatted = "[$ts] [TRANSCODING_LOG_CALLBACK_REGISTERED] $component$detailsStr"
        Log.i("FALLBACK_TRACE", formatted)
        addLogLine(formatted)
    }

    fun clear() {
        logQueue.clear()
        _logs.value = emptyList()
        _hasLogs.value = false
    }

    fun getAllLogsText(): String {
        return logQueue.joinToString("\n")
    }
}
