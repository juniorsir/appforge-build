package com.example.media.playback

import android.os.Handler
import android.os.Looper
import android.util.Log
import com.example.media.ffmpeg.FFmpegProgress
import com.example.media.ffmpeg.FFmpegState
import com.example.media.progressive.ProgressiveGenerationProgress
import com.example.media.progressive.ProgressiveState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong

/**
 * Metadata snapshot for the active or most recent transcoding session.
 */
data class TranscodingSessionMetadata(
    val sessionId: Long = -1L,
    val requestId: String? = null,
    val command: String? = null,
    val encoderName: String? = null,
    val strategy: String? = null,
    val status: String = "IDLE",
    val progressPercentage: Float? = null,
    val speed: Double = 0.0,
    val fps: Double = 0.0,
    val outputSizeBytes: Long = 0L,
    val currentTimestampMs: Long = 0L,
    val totalDurationMs: Long = 0L,
    val latestLogLine: String? = null,
    val isActive: Boolean = false
)

/**
 * Phase 17.40: High-Performance Central Repository for Transcoding Logs and Diagnostics.
 * Separates raw high-frequency logs from UI updates.
 * Implements deduplication, throttling, and bounded circular buffering to eliminate GC and UI overhead.
 */
object TranscodingLogManager {
    private const val TAG = "TranscodingLogManager"
    private const val MAX_LOG_CAPACITY = 1000
    private const val UI_UPDATE_THROTTLE_MS = 250L

    private val logQueue = ConcurrentLinkedQueue<String>()

    private val _logs = MutableStateFlow<List<String>>(emptyList())
    val logs: StateFlow<List<String>> = _logs.asStateFlow()

    private val _hasLogs = MutableStateFlow(false)
    val hasLogs: StateFlow<Boolean> = _hasLogs.asStateFlow()

    private val _sessionMetadata = MutableStateFlow(TranscodingSessionMetadata())
    val sessionMetadata: StateFlow<TranscodingSessionMetadata> = _sessionMetadata.asStateFlow()

    private val _transcodingState = MutableStateFlow(TranscodingLifecycleState.NOT_STARTED)
    val transcodingState: StateFlow<TranscodingLifecycleState> = _transcodingState.asStateFlow()

    private val _playbackState = MutableStateFlow(PlaybackLifecycleState.IDLE)
    val playbackState: StateFlow<PlaybackLifecycleState> = _playbackState.asStateFlow()

    // Performance Metrics (Part 15)
    val countReceived = AtomicLong(0)
    val countDeduplicated = AtomicLong(0)
    val countPublished = AtomicLong(0)
    val countDropped = AtomicLong(0)
    val countUiUpdates = AtomicLong(0)

    @Volatile
    private var lastRawLine: String? = null

    @Volatile
    private var lastUiPublishTimeMs = 0L

    @Volatile
    private var lastPerfLogTimeMs = 0L

    private val mainHandler = Handler(Looper.getMainLooper())
    private val pendingUiPublish = Runnable {
        publishLogsToUi()
    }

    fun updateTranscodingState(newState: TranscodingLifecycleState, requestId: String? = null) {
        val oldState = _transcodingState.value
        if (oldState != newState) {
            _transcodingState.value = newState
            val ts = getCurrentTimestamp()
            val isVisible = newState.isLogControlVisible
            Log.i("TRANSCODING_LOG_UI_STATE", "[$ts] [TRANSCODING_LOG_UI_STATE] oldState=$oldState newState=$newState req=$requestId")
            Log.i("TRANSCODING_LOG_UI_VISIBILITY", "[$ts] [TRANSCODING_LOG_UI_VISIBILITY] isVisible=$isVisible state=$newState req=$requestId")
            recordEvent("TRANSCODING_LOG_UI_STATE", "oldState=$oldState newState=$newState isVisible=$isVisible", requestId)
            scheduleUiPublish(immediate = true)
        }
    }

    fun updatePlaybackState(newState: PlaybackLifecycleState, requestId: String? = null) {
        val oldState = _playbackState.value
        if (oldState != newState) {
            _playbackState.value = newState
            val ts = getCurrentTimestamp()
            Log.i("PLAYBACK_STATE_TRACE", "[$ts] [PLAYBACK_STATE_TRACE] [id=${requestId ?: "unknown"}] $oldState -> $newState")
        }
    }

    private val timeFormatter = SimpleDateFormat("HH:mm:ss.SSS", Locale.US)

    @Synchronized
    private fun getCurrentTimestamp(): String = timeFormatter.format(Date())

    fun addLogLine(line: String, requestId: String? = null) {
        countReceived.incrementAndGet()

        // Deduplicate identical consecutive raw lines
        val trimmed = line.trim()
        if (trimmed.isEmpty() || trimmed == lastRawLine) {
            countDeduplicated.incrementAndGet()
            return
        }
        lastRawLine = trimmed

        logQueue.add(line)
        countPublished.incrementAndGet()

        while (logQueue.size > MAX_LOG_CAPACITY) {
            logQueue.poll()
            countDropped.incrementAndGet()
        }

        scheduleUiPublish(immediate = false, requestId = requestId)
    }

    private fun scheduleUiPublish(immediate: Boolean = false, requestId: String? = null) {
        val now = System.currentTimeMillis()
        if (immediate || now - lastUiPublishTimeMs >= UI_UPDATE_THROTTLE_MS) {
            mainHandler.removeCallbacks(pendingUiPublish)
            publishLogsToUi(requestId)
        } else {
            mainHandler.removeCallbacks(pendingUiPublish)
            mainHandler.postDelayed(pendingUiPublish, UI_UPDATE_THROTTLE_MS)
        }
    }

    private fun publishLogsToUi(requestId: String? = null) {
        lastUiPublishTimeMs = System.currentTimeMillis()
        countUiUpdates.incrementAndGet()
        val currentList = logQueue.toList()
        _logs.value = currentList
        _hasLogs.value = currentList.isNotEmpty()

        // Periodically log [LOG_PERFORMANCE]
        if (lastUiPublishTimeMs - lastPerfLogTimeMs > 4000L) {
            lastPerfLogTimeMs = lastUiPublishTimeMs
            val reqStr = if (requestId != null) " req=$requestId" else ""
            Log.i(
                "FALLBACK_TRACE",
                "[LOG_PERFORMANCE] received=${countReceived.get()} deduplicated=${countDeduplicated.get()} published=${countPublished.get()} dropped=${countDropped.get()} uiUpdates=${countUiUpdates.get()}$reqStr"
            )
        }
    }

    fun recordEvent(tag: String, message: String, requestId: String? = null) {
        val ts = getCurrentTimestamp()
        val formatted = if (requestId != null) {
            "[$ts] [$tag] [id=$requestId] $message"
        } else {
            "[$ts] [$tag] $message"
        }
        Log.i("FALLBACK_TRACE", formatted)
        addLogLine(formatted, requestId)
    }

    fun recordLogReceived(sessionId: Long, message: String, requestId: String? = null) {
        val ts = getCurrentTimestamp()
        val formatted = if (sessionId > 0) {
            "[$ts] [TRANSCODING_LOG_RECEIVED] [#$sessionId] $message"
        } else {
            "[$ts] [TRANSCODING_LOG_RECEIVED] $message"
        }
        Log.d("TRANSCODING_LOG_TRACE", formatted)
        addLogLine(formatted, requestId)
        _sessionMetadata.value = _sessionMetadata.value.copy(latestLogLine = message)
    }

    fun recordCommand(command: String, requestId: String? = null, sessionId: Long = -1L) {
        val ts = getCurrentTimestamp()
        val formatted = "[$ts] [FFMPEG_COMMAND] $command"
        Log.i("FALLBACK_TRACE", formatted)
        addLogLine(formatted, requestId)
        val extractedEncoder = when {
            command.contains("-c:v libopenh264") -> "libopenh264"
            command.contains("-c:v h264_mediacodec") -> "h264_mediacodec"
            command.contains("-c:v h264_v4l2m2m") -> "h264_v4l2m2m"
            command.contains("-c:v libx264") -> "libx264"
            command.contains("-c:v copy") -> "copy"
            else -> null
        }
        _sessionMetadata.value = _sessionMetadata.value.copy(
            command = command,
            encoderName = extractedEncoder ?: _sessionMetadata.value.encoderName,
            requestId = requestId ?: _sessionMetadata.value.requestId,
            sessionId = if (sessionId > 0) sessionId else _sessionMetadata.value.sessionId,
            isActive = true
        )
    }

    fun recordProgress(progress: FFmpegProgress, requestId: String? = null) {
        val ts = getCurrentTimestamp()
        val pctStr = if (progress.progressPercentage != null) String.format(Locale.US, "%.1f%%", progress.progressPercentage) else "indeterminate"
        val speedStr = if (progress.speed > 0.0) String.format(Locale.US, "%.2fx", progress.speed) else "--"
        val fpsStr = if (progress.fps > 0.0) String.format(Locale.US, "%.0f", progress.fps) else "--"
        val timeMs = progress.currentTimestampMs
        val totalMs = progress.totalDurationMs

        val formatted = "[$ts] [TRANSCODING_PROGRESS_RECEIVED] state=${progress.state} progress=$pctStr speed=$speedStr fps=$fpsStr time=${timeMs}ms/${totalMs}ms"
        Log.d("TRANSCODING_LOG_TRACE", formatted)

        _sessionMetadata.value = _sessionMetadata.value.copy(
            sessionId = if (progress.sessionId > 0) progress.sessionId else _sessionMetadata.value.sessionId,
            requestId = requestId ?: _sessionMetadata.value.requestId,
            status = progress.state.name,
            progressPercentage = progress.progressPercentage,
            speed = progress.speed,
            fps = progress.fps,
            outputSizeBytes = progress.outputSizeBytes,
            currentTimestampMs = progress.currentTimestampMs,
            totalDurationMs = progress.totalDurationMs,
            latestLogLine = progress.latestLogLine ?: _sessionMetadata.value.latestLogLine,
            isActive = (progress.state == FFmpegState.STARTING || progress.state == FFmpegState.RUNNING || progress.state == FFmpegState.VALIDATING)
        )

        progress.latestLogLine?.let { line ->
            if (line.isNotBlank() && !line.startsWith("[$ts]")) {
                addLogLine("[$ts] $line", requestId)
            }
        }
    }

    fun recordProgressiveProgress(progress: ProgressiveGenerationProgress, requestId: String? = null) {
        val ts = getCurrentTimestamp()
        val pctStr = String.format(Locale.US, "%.1f%%", progress.progressPercentage)
        val speedStr = String.format(Locale.US, "%.2fx", progress.transcodingSpeed)
        val formatted = "[$ts] [TRANSCODING_PROGRESS_RECEIVED] [progressive] state=${progress.state} progress=$pctStr speed=$speedStr playable=${progress.playableDurationMs}ms units=${progress.publishedUnitsCount}"
        Log.d("TRANSCODING_LOG_TRACE", formatted)

        _sessionMetadata.value = _sessionMetadata.value.copy(
            sessionId = if (progress.sessionId > 0) progress.sessionId else _sessionMetadata.value.sessionId,
            requestId = requestId ?: _sessionMetadata.value.requestId,
            status = progress.state.name,
            progressPercentage = progress.progressPercentage,
            speed = progress.transcodingSpeed.toDouble(),
            fps = progress.fps,
            outputSizeBytes = progress.outputSizeBytes,
            currentTimestampMs = progress.transcodedDurationMs,
            totalDurationMs = progress.sourceDurationMs,
            latestLogLine = progress.latestLogLine ?: _sessionMetadata.value.latestLogLine,
            isActive = (progress.state == ProgressiveState.INITIALIZING || progress.state == ProgressiveState.GENERATING)
        )

        progress.latestLogLine?.let { line ->
            if (line.isNotBlank() && !line.startsWith("[$ts]")) {
                addLogLine("[$ts] $line", requestId)
            }
        }
    }

    fun recordUiTrace(action: String, details: String? = null) {
        val ts = getCurrentTimestamp()
        val detailsStr = if (details != null) " - $details" else ""
        val formatted = "[$ts] [TRANSCODING_LOG_UI_TRACE] $action$detailsStr"
        Log.i("TRANSCODING_LOG_UI_TRACE", formatted)
        addLogLine(formatted)
    }

    fun recordCallbackRegistered(component: String, details: String? = null) {
        val ts = getCurrentTimestamp()
        val detailsStr = if (details != null) " ($details)" else ""
        val formatted = "[$ts] [TRANSCODING_LOG_CALLBACK_REGISTERED] $component$detailsStr"
        Log.i("FALLBACK_TRACE", formatted)
        addLogLine(formatted)
    }

    fun clear() {
        mainHandler.removeCallbacks(pendingUiPublish)
        logQueue.clear()
        _logs.value = emptyList()
        _hasLogs.value = false
        lastRawLine = null
        countReceived.set(0)
        countDeduplicated.set(0)
        countPublished.set(0)
        countDropped.set(0)
        countUiUpdates.set(0)
    }

    fun getAllLogsText(): String {
        return logQueue.joinToString("\n")
    }
}
