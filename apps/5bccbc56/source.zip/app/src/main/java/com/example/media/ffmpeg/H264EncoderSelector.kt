package com.example.media.ffmpeg

import android.content.Context
import android.util.Log
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.FFmpegKitConfig
import com.arthenica.ffmpegkit.ReturnCode
import com.example.media.EncoderCapabilityManager
import com.example.media.EncoderProbeResult
import com.example.media.EncoderProbeStage
import com.example.media.EncoderQuarantineRecord
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.concurrent.ConcurrentHashMap

data class EncoderCandidate(
    val name: String,
    val isHardware: Boolean,
    val canonicalCodec: String,
    val description: String
)

data class SelectedH264Encoder(
    val name: String,
    val isHardware: Boolean = false,
    val supportsCrf: Boolean = (name == "libx264"),
    val supportsPreset: Boolean = (name == "libx264"),
    val defaultProfile: String = "high",
    val defaultLevel: String = "4.1",
    val recommendedGop: Int = 48
)

object H264EncoderSelector {
    private const val TAG = "H264EncoderSelector"

    @Volatile
    private var cachedSelectedEncoder: SelectedH264Encoder? = null

    // In-memory quarantine cache: key is encoderName or encoderName + resolution/profile
    private val quarantinedEncoders = ConcurrentHashMap<String, EncoderQuarantineRecord>()

    // Probe results history for diagnostics
    private val probeResults = mutableListOf<EncoderProbeResult>()

    // Testing hooks
    @Volatile
    var mockEncodersForTesting: List<EncoderCandidate>? = null
    @Volatile
    var forceFailEncodersForTesting: Set<String> = emptySet()
    @Volatile
    var mockUsabilityForTesting: Boolean? = null
    @Volatile
    var mockProbeResultForTesting: EncoderProbeResult? = null

    fun resetCacheForTesting() {
        cachedSelectedEncoder = null
        quarantinedEncoders.clear()
        probeResults.clear()
        mockEncodersForTesting = null
        forceFailEncodersForTesting = emptySet()
        mockUsabilityForTesting = null
        mockProbeResultForTesting = null
    }

    fun getSelectedEncoder(): SelectedH264Encoder? = cachedSelectedEncoder

    fun quarantineEncoder(
        encoderName: String,
        reason: String,
        resolutionKey: String? = null,
        profileKey: String? = null
    ) {
        val record = EncoderQuarantineRecord(
            encoderName = encoderName,
            reason = reason,
            timestampMs = System.currentTimeMillis(),
            resolutionKey = resolutionKey,
            profileKey = profileKey
        )
        quarantinedEncoders[encoderName] = record
        if (resolutionKey != null) {
            quarantinedEncoders["${encoderName}_$resolutionKey"] = record
        }

        Log.w("FALLBACK_TRACE", "[ENCODER_QUARANTINED] encoder=$encoderName reason=$reason resolution=$resolutionKey profile=$profileKey")
        com.example.media.playback.TranscodingLogManager.recordEvent(
            "ENCODER_QUARANTINED",
            "encoder=$encoderName reason=$reason"
        )

        // Invalidate cached selection if it matches the quarantined encoder
        if (cachedSelectedEncoder?.name == encoderName) {
            cachedSelectedEncoder = null
        }
    }

    fun isQuarantined(encoderName: String, resolutionKey: String? = null): Boolean {
        if (quarantinedEncoders.containsKey(encoderName)) return true
        if (resolutionKey != null && quarantinedEncoders.containsKey("${encoderName}_$resolutionKey")) return true
        return false
    }

    fun getQuarantineReason(encoderName: String): String? {
        return quarantinedEncoders[encoderName]?.reason
    }

    suspend fun discoverH264Encoders(): List<EncoderCandidate> = withContext(Dispatchers.IO) {
        mockEncodersForTesting?.let { return@withContext it }

        Log.i("FALLBACK_TRACE", "[ENCODER_DISCOVERY_START] Querying available encoders in FFmpeg build...")
        val candidates = mutableListOf<EncoderCandidate>()
        try {
            FFmpegEngine.initialize()
            val ffmpegVer = try { FFmpegKitConfig.getFFmpegVersion() ?: "unknown" } catch (_: Throwable) { "unknown" }
            val session = FFmpegSessionManager.withOperationScope(FFmpegOperationType.ENCODER_PROBE) {
                FFmpegKit.execute("-hide_banner -encoders")
            }
            if (ReturnCode.isSuccess(session.returnCode)) {
                val output = session.allLogsAsString ?: ""
                val lineRegex = Regex("""^\s*([VAS][FSXBD.]{5})\s+([a-zA-Z0-9_\-]+)\s+(.*)$""")
                val codecRegex = Regex("""\(codec\s+([a-zA-Z0-9_\-]+)\)""")

                output.split("\n").forEach { line ->
                    val match = lineRegex.find(line)
                    if (match != null) {
                        val flags = match.groupValues[1]
                        val name = match.groupValues[2]
                        val desc = match.groupValues[3]
                        val isVideo = flags[0] == 'V'

                        if (isVideo && name != "=") {
                            val codecMatch = codecRegex.find(desc)
                            val canonical = codecMatch?.groupValues?.get(1)?.lowercase() ?: name.lowercase()
                            val isH264 = canonical == "h264" || name.contains("264") || name.contains("avc")

                            if (isH264) {
                                val isHw = name.contains("mediacodec") || name.contains("v4l2") || name.contains("vaapi") || name.contains("nvenc") || name.contains("qsv")
                                candidates.add(
                                    EncoderCandidate(
                                        name = name,
                                        isHardware = isHw,
                                        canonicalCodec = canonical,
                                        description = desc
                                    )
                                )
                            }
                        }
                    }
                }
                Log.i("FALLBACK_TRACE", "[ENCODER_DISCOVERY_RESULT] Discovered ${candidates.size} H.264 candidate encoders. Build: $ffmpegVer")
            } else {
                Log.w("FALLBACK_TRACE", "[ENCODER_DISCOVERY_RESULT] FFmpeg -encoders returned code ${session.returnCode?.value}")
            }
        } catch (t: Throwable) {
            Log.e("FALLBACK_TRACE", "[ENCODER_DISCOVERY_RESULT] Failed to query encoders: ${t.message}")
        }

        // If command parsing returned empty but we are on device, add known available encoders
        if (candidates.isEmpty()) {
            candidates.add(
                EncoderCandidate(
                    name = "libopenh264",
                    isHardware = false,
                    canonicalCodec = "h264",
                    description = "OpenH264 (codec h264)"
                )
            )
        }

        Log.i("FALLBACK_TRACE", "[H264_ENCODER_DISCOVERY] Candidates: ${candidates.map { it.name }}")
        candidates
    }

    /**
     * Evaluates and selects the best H.264 encoder with multi-stage verification:
     * 1. Check Android hardware encoder capability via MediaCodecList.
     * 2. Run real FFmpeg multi-level probe ladder.
     * 3. If hardware probe fails, quarantine it and seamlessly fallback to libopenh264.
     */
    suspend fun selectBestH264Encoder(
        context: Context? = null,
        targetWidth: Int = 1920,
        targetHeight: Int = 1080,
        targetFps: Float = 23.98f,
        targetBitrateKbps: Int = 4000,
        targetProfile: String? = null,
        targetLevel: String? = null
    ): SelectedH264Encoder? = withContext(Dispatchers.IO) {
        cachedSelectedEncoder?.let { return@withContext it }

        val candidates = discoverH264Encoders()
        if (candidates.isEmpty()) {
            Log.e("FALLBACK_TRACE", "[ENCODER_SELECTION] FAILED: No H.264 encoder candidates found in build.")
            return@withContext null
        }

        // Priority 1: Hardware H.264 encoders (h264_mediacodec, h264_v4l2m2m)
        // Priority 2: libx264 (If present in custom GPL builds)
        // Priority 3: libopenh264 (Standard software encoder in ffmpeg-kit-full)
        val rankedCandidates = candidates.sortedWith(
            compareBy(
                { candidate ->
                    when {
                        candidate.isHardware || candidate.name.contains("mediacodec") -> 0
                        candidate.name == "libx264" -> 1
                        candidate.name == "libopenh264" -> 2
                        else -> 3
                    }
                },
                { it.name }
            )
        )

        Log.i("FALLBACK_TRACE", "[ENCODER_AVAILABILITY] Candidates found: ${candidates.map { "${it.name}(hw=${it.isHardware})" }.joinToString(", ")}")

        for (candidate in rankedCandidates) {
            val encName = candidate.name
            Log.i("FALLBACK_TRACE", "[ENCODER_CANDIDATE] Evaluating candidate: $encName (isHardware=${candidate.isHardware}, desc=${candidate.description})")

            // 1. Check Quarantine
            if (isQuarantined(encName)) {
                val reason = getQuarantineReason(encName) ?: "Previously failed verification"
                Log.w("FALLBACK_TRACE", "[ENCODER_REJECTED] Rejected quarantined candidate: $encName, reason=$reason")
                continue
            }

            // 2. Check Simulated Testing Failure
            if (forceFailEncodersForTesting.contains(encName)) {
                Log.w("FALLBACK_TRACE", "[ENCODER_INIT_FAILURE] Candidate $encName failed initialization (simulated test failure)")
                quarantineEncoder(encName, "Simulated initialization failure")
                continue
            }

            // 3. For hardware encoder, verify Android MediaCodec encoder capability first
            var resolvedProfile = mapProfileForEncoder(encName, targetProfile)
                ?: if (encName == "libopenh264") "constrained_baseline" else "high"
            var resolvedLevel = targetLevel ?: if (encName == "libopenh264") "3.1" else "4.1"

            if (candidate.isHardware || encName.contains("mediacodec")) {
                val hwReport = EncoderCapabilityManager.getEncoderCapabilityReport()
                val isResolutionSupported = EncoderCapabilityManager.isResolutionSupportedByHwEncoder(targetWidth, targetHeight)
                val isProfileSupported = EncoderCapabilityManager.isProfileSupportedByHwEncoder(resolvedProfile)

                Log.i("FALLBACK_TRACE", "[ENCODER_CAPABILITY_EVAL] encoder=$encName hwAvailable=${hwReport.hasHardwareAvcEncoder} resSupported=$isResolutionSupported profileSupported=$isProfileSupported")

                if (!isProfileSupported) {
                    resolvedProfile = EncoderCapabilityManager.getPreferredHardwareProfile()
                    Log.i("FALLBACK_TRACE", "[ENCODER_PROFILE_ADJUST] Adjusted profile for $encName to $resolvedProfile")
                }
                resolvedLevel = EncoderCapabilityManager.getPreferredHardwareLevel(resolvedLevel)
            }

            // 4. Run real FFmpeg diagnostic probe ladder
            val probeResult = runEncoderProbeLadder(
                encoderName = encName,
                width = targetWidth,
                height = targetHeight,
                fps = targetFps,
                bitrateKbps = targetBitrateKbps,
                profile = resolvedProfile,
                level = resolvedLevel
            )

            if (probeResult.isSuccess) {
                Log.i("FALLBACK_TRACE", "[ENCODER_INIT_SUCCESS] Candidate $encName passed probe ladder successfully")
                val gop = calculateRecommendedGop(targetFps)
                val threads = calculateOptimalThreads(encName)
                val selected = SelectedH264Encoder(
                    name = encName,
                    isHardware = candidate.isHardware || encName.contains("mediacodec"),
                    supportsCrf = (encName == "libx264"),
                    supportsPreset = (encName == "libx264"),
                    defaultProfile = resolvedProfile,
                    defaultLevel = resolvedLevel,
                    recommendedGop = gop
                )
                Log.i(
                    "FALLBACK_TRACE",
                    "[ENCODER_SELECTION] candidate=$encName androidCapability=SUPPORTED ffmpegProbe=SUCCESS decision=SELECTED fallback=libopenh264 isHardware=${selected.isHardware}"
                )
                Log.i(
                    "FALLBACK_TRACE",
                    "[ENCODER_THREAD_DECISION] encoder=$encName threads=$threads cores=${Runtime.getRuntime().availableProcessors()} policy=BALANCED_THERMAL_SAFE"
                )
                Log.i("FALLBACK_TRACE", "[ACTIVE_ENCODER] activeEncoder=${selected.name} isHardware=${selected.isHardware} gop=$gop")
                com.example.media.playback.TranscodingLogManager.recordEvent(
                    "ACTIVE_ENCODER",
                    "activeEncoder=${selected.name} isHardware=${selected.isHardware} gop=$gop"
                )
                cachedSelectedEncoder = selected
                return@withContext selected
            } else {
                val errorMsg = probeResult.errorMessage ?: "Unknown probe failure"
                Log.w("FALLBACK_TRACE", "[ENCODER_INIT_FAILURE] Candidate $encName probe failed at stage=${probeResult.stage}: $errorMsg")
                quarantineEncoder(encName, "Probe failed at stage ${probeResult.stage}: $errorMsg")
                Log.w(
                    "FALLBACK_TRACE",
                    "[ENCODER_SELECTION] candidate=$encName androidCapability=${if (candidate.isHardware) "EVALUATED" else "N/A"} ffmpegProbe=FAILED decision=QUARANTINE fallback=libopenh264"
                )
                Log.i(
                    "FALLBACK_TRACE",
                    "[ENCODER_FALLBACK] from=$encName to=libopenh264 reason=HARDWARE_ENCODER_UNUSABLE stage=${probeResult.stage}"
                )
            }
        }

        Log.e("FALLBACK_TRACE", "[ENCODER_SELECTION] FAILED: All candidate encoders failed initialization.")
        null
    }

    /**
     * Executes the multi-level diagnostic probe ladder in levels:
     * Level A - Basic encoder initialization (64x64, 24fps, safe bitrate 500k, explicit GOP 48)
     * Level B - Production pixel format (-pix_fmt yuv420p)
     * Level C - Production resolution / parameters
     */
    fun runEncoderProbeLadder(
        encoderName: String,
        width: Int = 1920,
        height: Int = 1080,
        fps: Float = 23.98f,
        bitrateKbps: Int = 4000,
        profile: String = "high",
        level: String = "4.1"
    ): EncoderProbeResult {
        mockProbeResultForTesting?.let { return it }
        mockUsabilityForTesting?.let {
            return if (it) {
                EncoderProbeResult(encoderName, EncoderProbeStage.BASIC_INIT, true)
            } else {
                EncoderProbeResult(encoderName, EncoderProbeStage.BASIC_INIT, false, returnCode = 1, errorMessage = "Mock probe failure")
            }
        }

        val gop = calculateRecommendedGop(fps)

        // Log Probe Start
        Log.i(
            "FALLBACK_TRACE",
            "[ENCODER_PROBE_START] encoder=$encoderName resolution=${width}x$height fps=$fps pixelFormat=yuv420p profile=$profile level=$level bitrate=${bitrateKbps}k gop=$gop"
        )

        try {
            FFmpegEngine.initialize()

            // Stage 1: Basic Init + Explicit GOP
            val stage1Cmd = if (encoderName == "libx264") {
                "-f lavfi -i color=c=black:s=64x64:d=0.04 -c:v libx264 -preset ultrafast -pix_fmt yuv420p -g $gop -keyint_min $gop -frames:v 1 -f null -"
            } else if (encoderName == "libopenh264") {
                val mappedProbeProfile = mapProfileForEncoder(encoderName, profile) ?: "constrained_baseline"
                "-f lavfi -i color=c=black:s=64x64:d=0.04 -c:v libopenh264 -b:v 500k -pix_fmt yuv420p -g $gop -keyint_min $gop -profile:v $mappedProbeProfile -frames:v 1 -f null -"
            } else {
                // For h264_mediacodec, test with explicit GOP and pixel format
                "-f lavfi -i color=c=black:s=64x64:d=0.04 -c:v $encoderName -b:v 500k -pix_fmt yuv420p -g $gop -keyint_min $gop -frames:v 1 -f null -"
            }

            val session1 = FFmpegSessionManager.withOperationScope(FFmpegOperationType.ENCODER_PROBE) {
                FFmpegKit.execute(stage1Cmd)
            }
            if (!ReturnCode.isSuccess(session1.returnCode)) {
                val error = extractMeaningfulError(session1.allLogsAsString, session1.failStackTrace)
                val res = EncoderProbeResult(
                    encoderName = encoderName,
                    stage = EncoderProbeStage.BASIC_INIT,
                    isSuccess = false,
                    returnCode = session1.returnCode?.value,
                    errorMessage = error,
                    testedResolution = "64x64",
                    testedFps = fps,
                    testedGop = gop,
                    logSnippet = error.take(300)
                )
                Log.w("FALLBACK_TRACE", "[ENCODER_PROBE_RESULT] encoder=$encoderName result=FAILED stage=BASIC_INIT returnCode=${session1.returnCode?.value} error=$error")
                probeResults.add(res)
                return res
            }

            // Stage 2: Production Configuration Probe (Resolution, Profile, Level, GOP)
            if (encoderName.contains("mediacodec")) {
                // Test realistic production configuration for mediacodec
                val stage2Cmd = "-f lavfi -i color=c=black:s=${width}x${height}:d=0.04 -c:v $encoderName -b:v ${bitrateKbps}k -maxrate ${(bitrateKbps * 1.5).toInt()}k -bufsize ${bitrateKbps * 2}k -profile:v $profile -level:v $level -pix_fmt yuv420p -g $gop -keyint_min $gop -frames:v 1 -f null -"
                val session2 = FFmpegSessionManager.withOperationScope(FFmpegOperationType.ENCODER_PROBE) {
                    FFmpegKit.execute(stage2Cmd)
                }
                if (!ReturnCode.isSuccess(session2.returnCode)) {
                    val error = extractMeaningfulError(session2.allLogsAsString, session2.failStackTrace)
                    val res = EncoderProbeResult(
                        encoderName = encoderName,
                        stage = EncoderProbeStage.PROFILE_LEVEL,
                        isSuccess = false,
                        returnCode = session2.returnCode?.value,
                        errorMessage = error,
                        testedResolution = "${width}x$height",
                        testedProfile = profile,
                        testedLevel = level,
                        testedFps = fps,
                        testedBitrateKbps = bitrateKbps,
                        testedGop = gop,
                        logSnippet = error.take(300)
                    )
                    Log.w("FALLBACK_TRACE", "[ENCODER_PROBE_RESULT] encoder=$encoderName result=FAILED stage=PROFILE_LEVEL returnCode=${session2.returnCode?.value} error=$error")
                    probeResults.add(res)
                    return res
                }
            }

            val successResult = EncoderProbeResult(
                encoderName = encoderName,
                stage = EncoderProbeStage.GOP_CONFIG,
                isSuccess = true,
                returnCode = 0,
                testedResolution = "${width}x$height",
                testedProfile = profile,
                testedLevel = level,
                testedFps = fps,
                testedBitrateKbps = bitrateKbps,
                testedGop = gop
            )
            Log.i("FALLBACK_TRACE", "[ENCODER_PROBE_RESULT] encoder=$encoderName result=SUCCESS")
            probeResults.add(successResult)
            return successResult

        } catch (t: Throwable) {
            val res = EncoderProbeResult(
                encoderName = encoderName,
                stage = EncoderProbeStage.BASIC_INIT,
                isSuccess = false,
                errorMessage = t.message ?: "Exception during probe"
            )
            Log.w("FALLBACK_TRACE", "[ENCODER_PROBE_RESULT] encoder=$encoderName result=FAILED stage=BASIC_INIT error=${t.message}")
            probeResults.add(res)
            return res
        }
    }

    private fun extractMeaningfulError(allLogs: String?, stackTrace: String?): String {
        if (!allLogs.isNullOrBlank()) {
            val lines = allLogs.split("\n")
            val errorLines = lines.filter { line ->
                val l = line.lowercase()
                l.contains("error") || l.contains("failed") || l.contains("invalid") || l.contains("out of range") || l.contains("could not find")
            }
            if (errorLines.isNotEmpty()) {
                return errorLines.takeLast(3).joinToString(" | ")
            }
            return lines.takeLast(3).joinToString(" | ")
        }
        return stackTrace?.take(200) ?: "Unknown error"
    }

    fun calculateRecommendedGop(fps: Float): Int {
        val safeFps = if (fps > 0f) fps else 24f
        // For ~23.98/24 fps, GOP of 48 gives exactly 2-second keyframe intervals aligned with HLS segment size
        val gop = (safeFps * 2).toInt()
        return maxOf(24, gop)
    }

    fun sanitizeH264Level(rawLevel: String?): String {
        if (rawLevel.isNullOrBlank()) return "4.1"
        val trimmed = rawLevel.trim()
        if (trimmed.matches(Regex("""^[1-5]\.[0-2]$"""))) {
            return trimmed
        }
        if (trimmed.matches(Regex("""^[1-5][0-2]$"""))) {
            return "${trimmed[0]}.${trimmed[1]}"
        }
        if (trimmed.matches(Regex("""^[1-5]$"""))) {
            return "${trimmed[0]}.0"
        }
        return "4.1"
    }

    fun calculateDefaultBitrateKbps(width: Int, height: Int, fps: Float = 24f): Int {
        val maxDim = maxOf(width, height)
        val minDim = minOf(width, height)
        return when {
            maxDim >= 3840 || minDim >= 2160 -> if (fps > 30f) 14000 else 10000
            maxDim >= 1920 || minDim >= 1080 -> if (fps > 30f) 5500 else 4000
            maxDim >= 1280 || minDim >= 720 -> if (fps > 30f) 3500 else 2500
            maxDim >= 854 || minDim >= 480 -> 1500
            else -> 1000
        }
    }

    fun calculateOptimalThreads(encoderName: String): Int {
        val cores = Runtime.getRuntime().availableProcessors()
        return when (encoderName) {
            "libopenh264" -> cores.coerceIn(2, 4)
            "libx264" -> cores.coerceIn(2, 4)
            else -> 0 // default for mediacodec or others
        }
    }

    /**
     * Maps an H.264 profile string to the exact option value accepted by the target encoder.
     * For libopenh264 in FFmpeg, valid AVOption values are "constrained_baseline", "main", and "high".
     * "baseline" is not recognized by libopenh264's AVOption parser and causes FFmpeg initialization to fail.
     */
    fun mapProfileForEncoder(encoderName: String, profile: String?): String? {
        if (profile == null) return null
        val clean = profile.trim().lowercase().replace(" ", "").replace("-", "").replace("_", "")
        return if (encoderName == "libopenh264") {
            when (clean) {
                "baseline", "constrainedbaseline" -> "constrained_baseline"
                "main" -> "main"
                "high" -> "high"
                else -> "constrained_baseline"
            }
        } else {
            profile
        }
    }
}
