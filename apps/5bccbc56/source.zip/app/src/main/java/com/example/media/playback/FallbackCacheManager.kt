package com.example.media.playback

import android.content.Context
import android.net.Uri
import android.util.Log
import com.example.media.probe.MediaProbeEngine
import java.io.File
import java.security.MessageDigest

object FallbackCacheManager {
    private const val TAG = "FallbackCacheManager"

    fun generateCacheKey(inputUri: Uri, inputFile: File?, strategy: PlaybackCompatibilityResult): String {
        val sb = StringBuilder()
        sb.append(inputUri.toString()).append("|")
        
        if (inputFile != null && inputFile.exists()) {
            sb.append(inputFile.length()).append("|")
            sb.append(inputFile.lastModified()).append("|")
        }
        
        // Include strategy and codec info
        sb.append(strategy.strategy.name).append("|")
        sb.append(strategy.videoCodec).append("|")
        sb.append(strategy.audioCodec).append("|")
        sb.append(strategy.videoAction).append("|")
        sb.append(strategy.audioAction).append("|")
        sb.append("v1") // profile version
        
        val hash = MessageDigest.getInstance("SHA-256")
            .digest(sb.toString().toByteArray())
            .joinToString("") { "%02x".format(it) }
            
        return "fallback_${hash.take(16)}.mp4"
    }

    suspend fun validateCachedFile(
        context: Context, 
        file: File, 
        expectedStrategy: PlaybackCompatibilityResult? = null
    ): Boolean {
        val cacheKey = file.name
        if (!file.exists() || file.length() == 0L || file.name.endsWith(".tmp")) {
            Log.i(TAG, "[FALLBACK_CACHE_TRACE] key=$cacheKey result=MISS (not found or empty)")
            return false
        }
        
        return try {
            val probeResult = MediaProbeEngine.probeMedia(context, Uri.fromFile(file))
            if (probeResult.isSuccess) {
                val info = probeResult.getOrNull()
                if (info == null || info.videoStreams.isEmpty() || info.durationMs <= 0) {
                    Log.i(TAG, "[FALLBACK_CACHE_TRACE] key=$cacheKey result=HIT_INVALID (probe failed or no video/duration)")
                    return false
                }
                
                if (expectedStrategy != null) {
                    val vs = info.videoStreams[0]
                    
                    val expectedVideoCodec = if (expectedStrategy.videoAction == "transcode") "h264" else expectedStrategy.videoCodec
                    if (!expectedVideoCodec.equals("none", ignoreCase = true) && !vs.codec.equals(expectedVideoCodec, ignoreCase = true) && !vs.codec.contains(expectedVideoCodec, ignoreCase = true)) {
                        Log.i(TAG, "[FALLBACK_CACHE_TRACE] key=$cacheKey result=HIT_INVALID (expected codec $expectedVideoCodec but got ${vs.codec})")
                        return false
                    }
                    
                    if (expectedStrategy.videoAction == "transcode") {
                        if (vs.bitDepth > 8) {
                            Log.i(TAG, "[FALLBACK_CACHE_TRACE] key=$cacheKey result=HIT_INVALID (expected 8-bit but got ${vs.bitDepth})")
                            return false
                        }
                    }
                    
                    if (!expectedStrategy.audioAction.equals("none", ignoreCase = true)) {
                        if (info.audioStreams.isEmpty()) {
                            Log.i(TAG, "[FALLBACK_CACHE_TRACE] key=$cacheKey result=HIT_INVALID (expected audio stream missing)")
                            return false
                        }
                    }
                }
                
                Log.i(TAG, "[FALLBACK_CACHE_TRACE] key=$cacheKey result=HIT_VALID")
                true
            } else {
                Log.i(TAG, "[FALLBACK_CACHE_TRACE] key=$cacheKey result=HIT_INVALID (probe returned failure)")
                false
            }
        } catch (e: Exception) {
            Log.e(TAG, "[FALLBACK_CACHE_TRACE] key=$cacheKey result=HIT_INVALID (exception: ${e.message})")
            false
        }
    }
    
    fun cleanOrphanedTempFiles(context: Context) {
        try {
            val cacheDir = context.cacheDir
            if (cacheDir != null && cacheDir.exists()) {
                cacheDir.listFiles()?.forEach { file ->
                    if (file.name.startsWith("fallback_") && file.name.endsWith(".tmp")) {
                        Log.i(TAG, "[FALLBACK_CACHE_TRACE] key=${file.name} result=DELETE_ORPHAN")
                        file.delete()
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error cleaning orphaned temp files", e)
        }
    }
}
