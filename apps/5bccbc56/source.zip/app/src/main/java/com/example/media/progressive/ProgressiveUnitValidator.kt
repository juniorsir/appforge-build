package com.example.media.progressive

import android.content.Context
import android.net.Uri
import android.util.Log
import com.example.media.DecoderCapabilityManager
import com.example.media.probe.MediaProbeEngine
import com.example.media.probe.MediaProbeInfo
import java.io.File

/**
 * Phase 17.34: Validates individual progressive media units against the 8-bit H.264 contract
 * before they are published as playable.
 */
object ProgressiveUnitValidator {
    private const val TAG = "ProgressiveUnitValidator"

    suspend fun validateUnit(
        context: Context,
        file: File
    ): Result<ProgressiveMediaUnitMetadata> {
        return validateUnit(context, file) { ctx, uri -> MediaProbeEngine.probeMedia(ctx, uri) }
    }

    suspend fun validateUnit(
        context: Context,
        file: File,
        probeFunc: suspend (Context, Uri) -> Result<MediaProbeInfo>
    ): Result<ProgressiveMediaUnitMetadata> {
        if (!file.exists()) {
            return Result.failure(IllegalStateException("PROGRESSIVE_UNIT_MISSING: Unit file does not exist at ${file.absolutePath}"))
        }
        val sizeBytes = file.length()
        if (sizeBytes == 0L) {
            return Result.failure(IllegalStateException("PROGRESSIVE_UNIT_EMPTY: Unit file is 0 bytes at ${file.absolutePath}"))
        }

        val probeResult = probeFunc(context, Uri.fromFile(file))
        val info = probeResult.getOrNull()
        if (info == null) {
            val err = probeResult.exceptionOrNull()?.message ?: "FFprobe probe failed"
            return Result.failure(IllegalStateException("PROGRESSIVE_UNIT_FFPROBE_FAILED: $err"))
        }

        // 1. Duration check
        val durationMs = info.durationMs
        if (durationMs <= 0L) {
            return Result.failure(IllegalStateException("PROGRESSIVE_UNIT_INVALID_DURATION: Duration is ${durationMs}ms"))
        }

        // 2. Video stream validation
        val video = info.primaryVideo
        if (video == null) {
            return Result.failure(IllegalStateException("PROGRESSIVE_UNIT_NO_VIDEO: No video stream found in unit"))
        }

        val codec = video.codec.lowercase()
        if (codec != "h264" && codec != "avc" && codec != "avc1") {
            return Result.failure(IllegalStateException("PROGRESSIVE_UNIT_CODEC_INVALID: Expected H.264/AVC, got $codec"))
        }

        if (video.width <= 0 || video.height <= 0) {
            return Result.failure(IllegalStateException("PROGRESSIVE_UNIT_RESOLUTION_INVALID: ${video.width}x${video.height}"))
        }

        val pixFmt = video.pixelFormat?.lowercase() ?: ""
        val bitDepth = video.bitDepth
        val profileStr = video.profile
        val normalizedProfile = if (profileStr != null) DecoderCapabilityManager.normalizeProfile(video.codec, profileStr) else ""

        val profileImplies10Bit = normalizedProfile.contains("High 10") || normalizedProfile.contains("10-bit") || (normalizedProfile.contains("10") && !normalizedProfile.contains("High 4"))
        val pixFmtImplies10Bit = pixFmt.contains("10")

        if (bitDepth != 8 && bitDepth != 0) {
            return Result.failure(IllegalStateException("PROGRESSIVE_UNIT_BIT_DEPTH_INVALID: Bit depth is $bitDepth (expected 8)"))
        }
        if (pixFmtImplies10Bit || profileImplies10Bit) {
            return Result.failure(IllegalStateException("PROGRESSIVE_UNIT_PROFILE_INVALID: 10-bit output detected ($normalizedProfile / $pixFmt)"))
        }

        // 3. Audio stream validation
        val audio = info.primaryAudio
        if (audio != null) {
            val aCodec = audio.codec.lowercase()
            if (aCodec != "aac" && aCodec != "mp4a-40-2" && aCodec != "copy") {
                return Result.failure(IllegalStateException("PROGRESSIVE_UNIT_AUDIO_INVALID: Expected AAC audio, got $aCodec"))
            }
        }

        return Result.success(
            ProgressiveMediaUnitMetadata(
                durationMs = durationMs,
                sizeBytes = sizeBytes,
                width = video.width,
                height = video.height,
                codec = codec,
                profile = normalizedProfile,
                pixelFormat = pixFmt,
                bitDepth = 8
            )
        )
    }
}

data class ProgressiveMediaUnitMetadata(
    val durationMs: Long,
    val sizeBytes: Long,
    val width: Int,
    val height: Int,
    val codec: String,
    val profile: String,
    val pixelFormat: String,
    val bitDepth: Int
)
