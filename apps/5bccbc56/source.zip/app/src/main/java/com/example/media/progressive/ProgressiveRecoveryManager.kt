package com.example.media.progressive

import android.content.Context
import android.util.Log
import java.io.File

/**
 * Phase 17.38: Progressive Recovery & Resource Sanitation Manager.
 * Ensures deterministic state and storage hygiene across process restarts, crashes,
 * media switches, and abrupt cancellations.
 */
object ProgressiveRecoveryManager {
    private const val TAG = "ProgressiveRecoveryMgr"

    /**
     * Executes comprehensive startup sanitation to purge incomplete artifacts left from previous process crashes.
     */
    fun performStartupSanitation(context: Context) {
        try {
            var cleanedDirs = 0
            var cleanedFiles = 0

            val cacheDir = context.cacheDir ?: return
            if (!cacheDir.exists() || !cacheDir.isDirectory) return

            // 1. Scan for progressive working directories left unfinalized
            cacheDir.listFiles()?.forEach { file ->
                if (file.isDirectory && file.name.startsWith("progressive_")) {
                    // Check if it's a persistent cache vs a temporary working folder
                    val isCache = file.name.startsWith("progressive_cache_")
                    if (!isCache) {
                        // Working directories from prior process runs are stale
                        val isValidComplete = ProgressiveCacheManager.isCacheValid(file)
                        if (!isValidComplete) {
                            Log.i(TAG, "[PROGRESSIVE_RECOVERY_TRACE] Purging incomplete working dir ${file.name}")
                            file.deleteRecursively()
                            cleanedDirs++
                        } else {
                            // Completed stream: remove any stray tmp files
                            cleanTemporaryFiles(file)
                        }
                    } else {
                        // For cache directories, purge if incomplete
                        if (!ProgressiveCacheManager.isCacheValid(file)) {
                            Log.i(TAG, "[PROGRESSIVE_RECOVERY_TRACE] Purging invalid cache dir ${file.name}")
                            file.deleteRecursively()
                            cleanedDirs++
                        }
                    }
                } else if (file.isFile) {
                    val name = file.name
                    if (name.endsWith(".tmp") || name.startsWith("fallback_") && name.endsWith(".tmp") || name.startsWith("media_") && name.endsWith(".tmp")) {
                        Log.i(TAG, "[PROGRESSIVE_RECOVERY_TRACE] Deleting orphaned file ${file.name}")
                        file.delete()
                        cleanedFiles++
                    }
                }
            }

            Log.i(
                "FALLBACK_TRACE",
                "[PROGRESSIVE_RECOVERY_TRACE] event=STARTUP_SANITATION cleanedDirs=$cleanedDirs cleanedFiles=$cleanedFiles"
            )
        } catch (e: Exception) {
            Log.e(TAG, "Error performing startup sanitation: ${e.message}", e)
        }
    }

    /**
     * Recursively or flatly deletes all `.tmp` files in a given directory.
     */
    fun cleanTemporaryFiles(dir: File?) {
        if (dir == null || !dir.exists() || !dir.isDirectory) return
        try {
            dir.listFiles()?.forEach { file ->
                if (file.isDirectory) {
                    cleanTemporaryFiles(file)
                } else if (file.name.endsWith(".tmp")) {
                    file.delete()
                }
            }
        } catch (_: Exception) {}
    }

    /**
     * Cleans working directories not in activeRequestIds.
     */
    fun cleanStaleWorkingDirectories(context: Context, activeRequestIds: Set<String>) {
        try {
            val cacheDir = context.cacheDir ?: return
            cacheDir.listFiles()?.forEach { file ->
                if (file.isDirectory && file.name.startsWith("progressive_") && !file.name.startsWith("progressive_cache_")) {
                    val reqId = file.name.removePrefix("progressive_")
                    if (!activeRequestIds.contains(reqId)) {
                        if (!ProgressiveCacheManager.isCacheValid(file)) {
                            Log.i(TAG, "[PROGRESSIVE_RECOVERY_TRACE] Cleaning abandoned working dir ${file.name}")
                            file.deleteRecursively()
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Failed cleaning stale working directories: ${e.message}")
        }
    }
}
