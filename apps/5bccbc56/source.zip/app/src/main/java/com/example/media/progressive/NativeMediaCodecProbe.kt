package com.example.media.progressive

import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaCodecList
import android.media.MediaFormat
import android.util.Log
import android.view.Surface
import android.graphics.Canvas
import android.graphics.Color
import java.nio.ByteBuffer

object NativeMediaCodecProbe {
    fun probeNativeH264Encoder(width: Int = 1920, height: Int = 1080, fps: Float = 23.98f, bitrateKbps: Int = 4000): String? {
        val list = MediaCodecList(MediaCodecList.ALL_CODECS)
        var selectedCodec: MediaCodecInfo? = null
        for (info in list.codecInfos) {
            if (!info.isEncoder) continue
            try {
                val types = info.supportedTypes
                if (types.contains("video/avc")) {
                    val isHw = if (android.os.Build.VERSION.SDK_INT >= 29) info.isHardwareAccelerated else {
                        val name = info.name.lowercase()
                        !name.startsWith("omx.google.") && !name.startsWith("c2.android.") && !name.contains(".sw.")
                    }
                    val caps = info.getCapabilitiesForType("video/avc")
                    val vCaps = caps.videoCapabilities
                    Log.i("FALLBACK_TRACE", "[NATIVE_H264_ENCODER_DISCOVERY] name=${info.name} isEncoder=true mime=video/avc hardwareClassification=${if(isHw) "HARDWARE" else "SOFTWARE"} colorFormats=${caps.colorFormats.joinToString()} profiles=${caps.profileLevels.map{it.profile}.joinToString()} widthRange=${vCaps?.supportedWidths?.lower}-${vCaps?.supportedWidths?.upper} heightRange=${vCaps?.supportedHeights?.lower}-${vCaps?.supportedHeights?.upper}")
                    if (isHw && selectedCodec == null) {
                        // Check if COLOR_FormatSurface is supported
                        if (caps.colorFormats.contains(MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)) {
                            selectedCodec = info
                        }
                    }
                }
            } catch (e: Exception) { }
        }
        
        if (selectedCodec == null) {
            Log.w("FALLBACK_TRACE", "[NATIVE_ENCODER_PROBE_RESULT] encoder=null result=FAIL reason=DISCOVERY")
            return null
        }
        
        val encoderName = selectedCodec.name
        Log.i("FALLBACK_TRACE", "[NATIVE_ENCODER_PROBE_START] encoder=$encoderName")
        Log.i("FALLBACK_TRACE", "[NATIVE_ENCODER_PROBE_CONFIG] width=$width height=$height fps=$fps bitrate=${bitrateKbps}k colorFormat=COLOR_FormatSurface profile=High level=4.1")
        
        var encoder: MediaCodec? = null
        var surface: Surface? = null
        try {
            encoder = MediaCodec.createByCodecName(encoderName)
            val format = MediaFormat.createVideoFormat("video/avc", width, height)
            format.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            format.setInteger(MediaFormat.KEY_BIT_RATE, bitrateKbps * 1000)
            format.setInteger(MediaFormat.KEY_FRAME_RATE, fps.toInt())
            format.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1) // 1 second I-frame interval
            
            try {
                encoder.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            } catch (e: Exception) {
                Log.w("FALLBACK_TRACE", "[NATIVE_ENCODER_PROBE_RESULT] encoder=$encoderName result=FAIL reason=CONFIGURE msg=${e.message}")
                return null
            }
            
            try {
                surface = encoder.createInputSurface()
                encoder.start()
            } catch (e: Exception) {
                Log.w("FALLBACK_TRACE", "[NATIVE_ENCODER_PROBE_RESULT] encoder=$encoderName result=FAIL reason=START msg=${e.message}")
                return null
            }
            
            var spsFound = false
            var ppsFound = false
            var idrFound = false
            var totalBytes = 0
            var accessUnits = 0
            
            val bufferInfo = MediaCodec.BufferInfo()
            var framesFed = 0
            val maxFrames = 30
            var isEos = false
            
            while (!isEos && framesFed < maxFrames * 2) {
                if (framesFed < maxFrames) {
                    try {
                        val canvas = surface.lockCanvas(null)
                        canvas.drawColor(Color.BLUE)
                        surface.unlockCanvasAndPost(canvas)
                        framesFed++
                    } catch (e: Exception) {
                        // ignore
                    }
                } else if (framesFed == maxFrames) {
                    try {
                        encoder.signalEndOfInputStream()
                    } catch (e: Exception) {}
                    framesFed++
                }
                
                val outIndex = encoder.dequeueOutputBuffer(bufferInfo, 100000)
                if (outIndex >= 0) {
                    val buf = encoder.getOutputBuffer(outIndex)
                    if (buf != null && bufferInfo.size > 0) {
                        totalBytes += bufferInfo.size
                        accessUnits++
                        
                        val bytes = ByteArray(bufferInfo.size)
                        buf.position(bufferInfo.offset)
                        buf.limit(bufferInfo.offset + bufferInfo.size)
                        buf.get(bytes)
                        
                        // Parse NAL units
                        var i = 0
                        while (i < bytes.size - 4) {
                            if (bytes[i].toInt() == 0 && bytes[i+1].toInt() == 0 && bytes[i+2].toInt() == 0 && bytes[i+3].toInt() == 1) {
                                val nalType = bytes[i+4].toInt() and 0x1F
                                if (nalType == 7) spsFound = true
                                if (nalType == 8) ppsFound = true
                                if (nalType == 5) idrFound = true
                            }
                            i++
                        }
                    }
                    encoder.releaseOutputBuffer(outIndex, false)
                    if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                        isEos = true
                    }
                } else if (outIndex == MediaCodec.INFO_TRY_AGAIN_LATER) {
                    if (framesFed >= maxFrames) {
                        framesFed++ // Avoid infinite loop
                    }
                }
                
                if (spsFound && ppsFound && idrFound) {
                    break // We got everything we need
                }
            }
            
            Log.i("FALLBACK_TRACE", "[NATIVE_ENCODER_PROBE_OUTPUT] bytes=$totalBytes accessUnits=$accessUnits idrFound=$idrFound spsFound=$spsFound ppsFound=$ppsFound")
            
            if (spsFound && ppsFound && idrFound) {
                Log.i("FALLBACK_TRACE", "[NATIVE_ENCODER_PROBE_RESULT] encoder=$encoderName result=PASS")
                return encoderName
            } else {
                Log.w("FALLBACK_TRACE", "[NATIVE_ENCODER_PROBE_RESULT] encoder=$encoderName result=FAIL reason=ACCESS_UNIT_VALIDATION")
                return null
            }
            
        } catch (e: Exception) {
            Log.w("FALLBACK_TRACE", "[NATIVE_ENCODER_PROBE_RESULT] encoder=$encoderName result=FAIL reason=RUNTIME msg=${e.message}")
            return null
        } finally {
            try {
                surface?.release()
                encoder?.stop()
                encoder?.release()
            } catch (e: Exception) {}
        }
    }
}
