package com.example.media.progressive

import android.graphics.Canvas
import android.graphics.Color
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaCodecList
import android.media.MediaFormat
import android.os.Build
import android.util.Log
import android.view.Surface
import com.example.media.EncoderCapabilityManager
import java.nio.ByteBuffer

/**
 * Phase 17.40: Native Android MediaCodec Hardware Encoder Qualification Probe.
 * Tests candidate hardware encoders against a fast, synthetic H.264 probe input (320x240 @ 24fps)
 * to verify complete hardware pipeline (init, surface input, frame submission, SPS/PPS/IDR output, access units)
 * without using or stressing the original high-resolution HEVC media.
 */
object NativeMediaCodecProbe {
    private const val TAG = "NativeMediaCodecProbe"

    @Volatile
    private var cachedQualifiedEncoder: String? = null

    @Volatile
    private var hasProbed = false

    fun resetCacheForTesting() {
        cachedQualifiedEncoder = null
        hasProbed = false
    }

    /**
     * Probes candidate hardware H.264 encoders on the device.
     * Returns the name of the verified hardware encoder, or null if no hardware encoder passed.
     */
    fun probeNativeH264Encoder(
        width: Int = 320,
        height: Int = 240,
        fps: Float = 24.0f,
        bitrateKbps: Int = 1000,
        requestId: String? = null
    ): String? {
        val reqStr = if (requestId != null) " req=$requestId" else ""
        if (hasProbed) {
            val cached = cachedQualifiedEncoder
            if (cached != null) {
                Log.i("FALLBACK_TRACE", "[ENCODER_SELECTION] candidate=$cached isHardware=true qualified=true decision=CACHED_SELECTION$reqStr")
            }
            return cached
        }

        val startTime = System.currentTimeMillis()
        val list = MediaCodecList(MediaCodecList.ALL_CODECS)
        var candidateEncoderInfo: MediaCodecInfo? = null

        for (info in list.codecInfos) {
            if (info == null || !info.isEncoder) continue
            try {
                val types = info.supportedTypes ?: continue
                if (types.any { it.equals("video/avc", ignoreCase = true) }) {
                    val isHw = EncoderCapabilityManager.isHardwareEncoder(info)
                    val caps = info.getCapabilitiesForType("video/avc")
                    val vCaps = caps.videoCapabilities
                    val hasSurface = caps.colorFormats.contains(MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
                    
                    Log.i(
                        "FALLBACK_TRACE",
                        "[ENCODER_DISCOVERY] candidate=${info.name} mime=video/avc isEncoder=true hardware=$isHw software=${!isHw} vendor=${EncoderCapabilityManager.isVendorEncoder(info)} maxWidth=${vCaps?.supportedWidths?.upper ?: 1920} maxHeight=${vCaps?.supportedHeights?.upper ?: 1080} colorFormats=${caps.colorFormats.joinToString()}$reqStr"
                    )

                    if (isHw && hasSurface && candidateEncoderInfo == null) {
                        candidateEncoderInfo = info
                    }
                }
            } catch (_: Throwable) {}
        }

        if (candidateEncoderInfo == null) {
            Log.i("FALLBACK_TRACE", "[ENCODER_PROBE_FAILURE] encoder=none stage=DISCOVERY reason=NO_HARDWARE_AVC_SURFACE_ENCODER$reqStr")
            hasProbed = true
            cachedQualifiedEncoder = null
            return null
        }

        val encoderName = candidateEncoderInfo.name
        Log.i("FALLBACK_TRACE", "[ENCODER_PROBE_START] encoder=$encoderName isHardware=true resolution=${width}x$height fps=$fps bitrate=${bitrateKbps}k$reqStr")
        Log.i("FALLBACK_TRACE", "[ENCODER_PROBE_CONFIG] encoder=$encoderName width=$width height=$height fps=$fps bitrate=${bitrateKbps}k colorFormat=COLOR_FormatSurface profile=High level=4.1 gop=24$reqStr")

        var encoder: MediaCodec? = null
        var surface: Surface? = null

        try {
            encoder = MediaCodec.createByCodecName(encoderName)
            val format = MediaFormat.createVideoFormat("video/avc", width, height)
            format.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            format.setInteger(MediaFormat.KEY_BIT_RATE, bitrateKbps * 1000)
            format.setInteger(MediaFormat.KEY_FRAME_RATE, fps.toInt())
            format.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)

            try {
                encoder.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            } catch (e: Exception) {
                Log.w("FALLBACK_TRACE", "[ENCODER_PROBE_FAILURE] encoder=$encoderName stage=CONFIGURE reason=MEDIACODEC_INIT_FAILED msg=${e.message}$reqStr")
                hasProbed = true
                cachedQualifiedEncoder = null
                return null
            }

            try {
                surface = encoder.createInputSurface()
                encoder.start()
            } catch (e: Exception) {
                Log.w("FALLBACK_TRACE", "[ENCODER_PROBE_FAILURE] encoder=$encoderName stage=START reason=MEDIACODEC_START_FAILED msg=${e.message}$reqStr")
                hasProbed = true
                cachedQualifiedEncoder = null
                return null
            }

            var spsFound = false
            var ppsFound = false
            var idrFound = false
            var totalBytes = 0
            var accessUnits = 0

            val bufferInfo = MediaCodec.BufferInfo()
            var framesFed = 0
            val maxFrames = 15
            var isEos = false

            while (!isEos && framesFed < maxFrames * 2) {
                if (framesFed < maxFrames) {
                    try {
                        val canvas = surface.lockCanvas(null)
                        canvas.drawColor(Color.rgb(10, 20, 30))
                        surface.unlockCanvasAndPost(canvas)
                        framesFed++
                    } catch (_: Exception) {}
                } else if (framesFed == maxFrames) {
                    try {
                        encoder.signalEndOfInputStream()
                    } catch (_: Exception) {}
                    framesFed++
                }

                val outIndex = encoder.dequeueOutputBuffer(bufferInfo, 80_000)
                if (outIndex >= 0) {
                    val buf = encoder.getOutputBuffer(outIndex)
                    if (buf != null && bufferInfo.size > 0) {
                        totalBytes += bufferInfo.size
                        accessUnits++

                        val bytes = ByteArray(bufferInfo.size)
                        buf.position(bufferInfo.offset)
                        buf.limit(bufferInfo.offset + bufferInfo.size)
                        buf.get(bytes)

                        // Parse NAL units for SPS (7), PPS (8), IDR (5)
                        var i = 0
                        while (i < bytes.size - 4) {
                            if (bytes[i].toInt() == 0 && bytes[i + 1].toInt() == 0 && bytes[i + 2].toInt() == 0 && bytes[i + 3].toInt() == 1) {
                                val nalType = bytes[i + 4].toInt() and 0x1F
                                if (nalType == 7) spsFound = true
                                if (nalType == 8) ppsFound = true
                                if (nalType == 5) idrFound = true
                            }
                            i++
                        }
                    }
                    encoder.releaseOutputBuffer(outIndex, false)
                    if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                        isEos = true
                    }
                } else if (outIndex == MediaCodec.INFO_TRY_AGAIN_LATER) {
                    if (framesFed >= maxFrames) {
                        framesFed++
                    }
                }

                if (spsFound && ppsFound && idrFound) {
                    break
                }
            }

            val elapsed = System.currentTimeMillis() - startTime
            val probeSpeed = if (elapsed > 0) (framesFed.toDouble() / (fps * (elapsed / 1000.0))) else 1.0

            if (spsFound && ppsFound && idrFound) {
                Log.i(
                    "FALLBACK_TRACE",
                    "[ENCODER_PROBE_SUCCESS] encoder=$encoderName isHardware=true durationMs=$elapsed outputBytes=$totalBytes accessUnits=$accessUnits speed=${String.format(java.util.Locale.US, "%.2f", probeSpeed)}x$reqStr"
                )
                hasProbed = true
                cachedQualifiedEncoder = encoderName
                return encoderName
            } else {
                Log.w(
                    "FALLBACK_TRACE",
                    "[ENCODER_PROBE_FAILURE] encoder=$encoderName stage=VALIDATION reason=ACCESS_UNIT_VALIDATION_FAILED sps=$spsFound pps=$ppsFound idr=$idrFound$reqStr"
                )
                hasProbed = true
                cachedQualifiedEncoder = null
                return null
            }

        } catch (e: Exception) {
            Log.w("FALLBACK_TRACE", "[ENCODER_PROBE_FAILURE] encoder=$encoderName stage=RUNTIME reason=ENCODER_RUNTIME_FAILED msg=${e.message}$reqStr")
            hasProbed = true
            cachedQualifiedEncoder = null
            return null
        } finally {
            try {
                surface?.release()
                encoder?.stop()
                encoder?.release()
            } catch (_: Exception) {}
        }
    }
}
