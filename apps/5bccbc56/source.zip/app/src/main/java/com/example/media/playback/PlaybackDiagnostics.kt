package com.example.media.playback

import android.net.Uri
import android.util.Log
import java.security.MessageDigest
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLong

/**
 * PHASE 17.19: Structured Observability & Diagnostic Event System.
 * 
 * Strictly decoupled from playback control: diagnostics are pure observers
 * and MUST NEVER alter playback decision trees, fallback selection, or error handling.
 */

enum class DiagnosticEventType {
    INPUT_RECEIVED,
    INPUT_NORMALIZED,
    ANALYSIS_STARTED,
    ANALYSIS_COMPLETED,
    ANALYSIS_FAILED,
    METADATA_NORMALIZED,
    DECODER_CAPABILITY_ANALYZED,
    COMPATIBILITY_EVALUATED,
    PLAYBACK_DECISION,
    FFMPEG_JOB_STARTED,
    FFMPEG_JOB_PROGRESS,
    FFMPEG_JOB_COMPLETED,
    FFMPEG_JOB_FAILED,
    FFMPEG_JOB_CANCELLED,
    FALLBACK_VALIDATION_STARTED,
    FALLBACK_VALIDATION_COMPLETED,
    FALLBACK_VALIDATION_FAILED,
    MEDIA3_SOURCE_CREATED,
    MEDIA3_SOURCE_ATTACHED,
    MEDIA3_PREPARE_STARTED,
    MEDIA3_READY,
    MEDIA3_PLAYBACK_STARTED,
    MEDIA3_POSITION_ADVANCED,
    MEDIA3_ERROR,
    MEDIA3_FORMAT_DETECTED,
    MEDIA3_DECODER_INITIALIZED,
    MEDIA3_DECODER_SELECTED,
    MEDIA3_DECODER_DIFFERENCE,
    MEDIA3_AUDIO_FORMAT_DETECTED,
    MEDIA3_TRACKS_CHANGED,
    MEDIA3_SUPPORT_EVALUATED,
    MEDIA3_DECODER_ERROR,
    PLAYBACK_FINAL_RESULT,
    REQUEST_CANCELLED,
    REQUEST_STALE,
    PLAYER_CREATED,
    PLAYER_RELEASED,
    PLAYER_RECREATED,
    STALE_EVENT,
    STALE_PLAYER_CALLBACK,
    STALE_FFMPEG_RESULT
}

enum class DiagnosticSeverity {
    DEBUG,
    INFO,
    WARN,
    ERROR
}

/**
 * Immutable structured diagnostic event.
 */
data class DiagnosticEvent(
    val timestamp: Long = System.currentTimeMillis(),
    val sequenceNumber: Long,
    val eventType: DiagnosticEventType,
    val stage: PlaybackErrorStage,
    val severity: DiagnosticSeverity,
    val playbackRequestId: String,
    val operationId: String? = null,
    val playerInstanceId: String? = null,
    val analysisJobId: String? = null,
    val ffmpegJobId: String? = null,
    val sourceType: PlaybackSourceType? = null,
    val sourceUriIdentity: String? = null,
    val state: String? = null,
    val previousState: String? = null,
    val newState: String? = null,
    val errorCategory: PlaybackErrorCategory? = null,
    val errorCode: Int? = null,
    val message: String,
    val technicalMessage: String? = null,
    val metadata: Map<String, String> = emptyMap()
) {
    fun toStructuredTrace(): String {
        val tag = when (eventType) {
            DiagnosticEventType.INPUT_RECEIVED, DiagnosticEventType.INPUT_NORMALIZED -> "MEDIA_INPUT_TRACE"
            DiagnosticEventType.METADATA_NORMALIZED -> "METADATA_NORMALIZATION_TRACE"
            DiagnosticEventType.DECODER_CAPABILITY_ANALYZED -> "CAPABILITY_MAP_TRACE"
            DiagnosticEventType.COMPATIBILITY_EVALUATED -> "COMPATIBILITY_INPUT_TRACE"
            DiagnosticEventType.PLAYBACK_DECISION -> "DECISION_TRACE"
            DiagnosticEventType.FFMPEG_JOB_STARTED, DiagnosticEventType.FFMPEG_JOB_PROGRESS, DiagnosticEventType.FFMPEG_JOB_COMPLETED -> "FALLBACK_EXEC_TRACE"
            DiagnosticEventType.FFMPEG_JOB_FAILED -> "FALLBACK_FAILURE_TRACE"
            DiagnosticEventType.FALLBACK_VALIDATION_STARTED, DiagnosticEventType.FALLBACK_VALIDATION_COMPLETED, DiagnosticEventType.FALLBACK_VALIDATION_FAILED -> "FALLBACK_CACHE_TRACE"
            DiagnosticEventType.MEDIA3_SOURCE_CREATED -> "MEDIA3_SOURCE_CONSTRUCTION"
            DiagnosticEventType.MEDIA3_SOURCE_ATTACHED, DiagnosticEventType.MEDIA3_PREPARE_STARTED -> "MEDIA3_ACTIVE_SOURCE"
            DiagnosticEventType.MEDIA3_ERROR -> "ERROR_CLASSIFICATION"
            DiagnosticEventType.MEDIA3_FORMAT_DETECTED -> "MEDIA3_FORMAT_TRACE"
            DiagnosticEventType.MEDIA3_DECODER_INITIALIZED -> "MEDIA3_DECODER_INIT"
            DiagnosticEventType.MEDIA3_DECODER_SELECTED -> "MEDIA3_DECODER_SELECTED"
            DiagnosticEventType.MEDIA3_DECODER_DIFFERENCE -> "MEDIA3_DECODER_DIFFERENCE"
            DiagnosticEventType.MEDIA3_AUDIO_FORMAT_DETECTED -> "MEDIA3_AUDIO_FORMAT"
            DiagnosticEventType.MEDIA3_TRACKS_CHANGED -> "MEDIA3_TRACK_SELECTION"
            DiagnosticEventType.MEDIA3_SUPPORT_EVALUATED -> "MEDIA3_SUPPORT_TRACE"
            DiagnosticEventType.MEDIA3_DECODER_ERROR -> "MEDIA3_DECODER_ERROR"
            DiagnosticEventType.PLAYBACK_FINAL_RESULT -> "PLAYBACK_FINAL_RESULT"
            DiagnosticEventType.PLAYER_CREATED, DiagnosticEventType.PLAYER_RELEASED, DiagnosticEventType.PLAYER_RECREATED -> "PLAYER_INSTANCE"
            DiagnosticEventType.STALE_EVENT, DiagnosticEventType.STALE_PLAYER_CALLBACK, DiagnosticEventType.STALE_FFMPEG_RESULT -> "PLAYER_CALLBACK_GUARD"
            DiagnosticEventType.REQUEST_CANCELLED -> "CANCELLATION_TRACE"
            else -> "PLAYBACK_STATE_TRACE"
        }

        val details = StringBuilder("[$tag][id=$playbackRequestId]")
        if (!operationId.isNullOrBlank()) details.append(" op=$operationId")
        if (!playerInstanceId.isNullOrBlank()) details.append(" player=$playerInstanceId")
        if (!analysisJobId.isNullOrBlank()) details.append(" analysis=$analysisJobId")
        if (!ffmpegJobId.isNullOrBlank()) details.append(" ffmpeg=$ffmpegJobId")
        if (sourceType != null) details.append(" src=${sourceType.name}")
        if (!sourceUriIdentity.isNullOrBlank()) details.append(" uriId=$sourceUriIdentity")
        if (!previousState.isNullOrBlank() && !newState.isNullOrBlank()) details.append(" $previousState -> $newState")
        if (errorCategory != null) details.append(" errCategory=${errorCategory.name}")
        if (errorCode != null && errorCode != 0) details.append(" errCode=$errorCode")
        details.append(" msg=\"$message\"")
        if (!technicalMessage.isNullOrBlank()) details.append(" tech=\"$technicalMessage\"")
        return details.toString()
    }
}

/**
 * Diagnostic Snapshot representing authoritative end-to-end inspection of a playback request.
 */
data class PlaybackDiagnosticSnapshot(
    val playbackRequestId: String,
    val playerInstanceId: String?,
    val analysisJobId: String?,
    val ffmpegJobId: String?,
    val sourceType: PlaybackSourceType?,
    val safeUriIdentity: String,
    val containerFormat: String?,
    val videoCodec: String?,
    val videoProfile: String?,
    val bitDepth: Int?,
    val resolution: String?,
    val audioCodec: String?,
    val decoderName: String?,
    val decoderSupported: Boolean?,
    val directPlaybackCompatibility: Boolean?,
    val decisionStrategy: String?,
    val fallbackExecuted: Boolean,
    val fallbackValidated: Boolean,
    val activeMedia3SourceUri: String?,
    val playbackStarted: Boolean,
    val positionAdvanced: Boolean,
    val terminalResult: AuthoritativePlaybackResult?,
    val authoritativeError: PlaybackError?,
    val eventCount: Int,
    val events: List<DiagnosticEvent>
) {
    fun toFormattedSummary(): String {
        val sb = StringBuilder()
        sb.appendLine("=== PLAYBACK DIAGNOSTIC SNAPSHOT ===")
        sb.appendLine("Request ID: $playbackRequestId")
        sb.appendLine("Player Instance ID: ${playerInstanceId ?: "None"}")
        sb.appendLine("Analysis ID: ${analysisJobId ?: "None"}")
        sb.appendLine("FFmpeg Job ID: ${ffmpegJobId ?: "None"}")
        sb.appendLine("Source Type: ${sourceType?.name ?: "UNKNOWN"}")
        sb.appendLine("Safe URI: $safeUriIdentity")
        sb.appendLine("Container: ${containerFormat ?: "Unknown"}")
        sb.appendLine("Video Codec: ${videoCodec ?: "None"} (${videoProfile ?: "N/A"}, ${bitDepth ?: 8}-bit, ${resolution ?: "N/A"})")
        sb.appendLine("Audio Codec: ${audioCodec ?: "None"}")
        sb.appendLine("Decoder: ${decoderName ?: "Unknown"} (Supported: ${decoderSupported ?: "N/A"})")
        sb.appendLine("Direct Compatible: ${directPlaybackCompatibility ?: "N/A"}")
        sb.appendLine("Decision Strategy: ${decisionStrategy ?: "None"}")
        sb.appendLine("Fallback Executed: $fallbackExecuted (Validated: $fallbackValidated)")
        sb.appendLine("Active Source: ${activeMedia3SourceUri ?: "None"}")
        sb.appendLine("Playback Started: $playbackStarted | Position Advanced: $positionAdvanced")
        sb.appendLine("Terminal Result: ${terminalResult?.name ?: "IN_PROGRESS"}")
        if (authoritativeError != null) {
            sb.appendLine("Authoritative Error: [${authoritativeError.stage.name}] ${authoritativeError.category.name} (${authoritativeError.recoverable.name} -> ${authoritativeError.recoveryAction.name})")
        }
        sb.appendLine("Event Count: $eventCount")
        return sb.toString().trimEnd()
    }
}

/**
 * Thread-safe, centralized diagnostic registry capturing structured events per playback request.
 * Purely observational: cannot modify playback or control outcomes.
 */
object PlaybackDiagnosticRegistry {
    private const val MAX_EVENTS_PER_REQUEST = 150
    private const val MAX_TRACKED_REQUESTS = 20

    private val sequenceCounter = AtomicLong(0)
    private val requestEvents = ConcurrentHashMap<String, ArrayDeque<DiagnosticEvent>>()
    private val terminalResults = ConcurrentHashMap<String, AuthoritativePlaybackResult>()
    private val positionLogThrottle = ConcurrentHashMap<String, Long>()

    /**
     * Converts a raw path or URI to a deterministic, safe, anonymized identifier without leaking secrets.
     */
    fun toSafeUriIdentity(raw: String?): String {
        if (raw.isNullOrBlank()) return "source://none"
        val clean = raw.substringBefore("|STREAM_AUDIO_URL|").trim()

        if (clean.startsWith("http://", ignoreCase = true) || clean.startsWith("https://", ignoreCase = true)) {
            return try {
                val noScheme = clean.substringAfter("://")
                val host = noScheme.substringBefore("/").substringBefore("?").substringBefore(":")
                val effectiveHost = if (host.isNotBlank()) host else "remote-host"
                val hash = sha256Short(clean)
                "source://https/$effectiveHost/$hash"
            } catch (_: Throwable) {
                "source://https/redacted"
            }
        }

        if (clean.startsWith("content://", ignoreCase = true)) {
            return try {
                val afterScheme = clean.substringAfter("content://")
                val authority = afterScheme.substringBefore("/")
                val path = afterScheme.substringAfter("/", "")
                val lastSeg = if (path.contains("/")) path.substringAfterLast("/") else if (path.isNotBlank()) path else "item"
                "source://content/$authority/$lastSeg"
            } catch (_: Throwable) {
                "source://content/item"
            }
        }

        val file = java.io.File(clean)
        val name = file.name
        return if (clean.contains("cache") || clean.contains("fallback") || clean.contains("tmp")) {
            "source://cache/$name"
        } else if (name.isNotBlank()) {
            "source://local/$name"
        } else {
            "source://local/file"
        }
    }

    private fun sha256Short(input: String): String {
        return try {
            val md = MessageDigest.getInstance("SHA-256")
            val digest = md.digest(input.toByteArray(Charsets.UTF_8))
            digest.take(6).joinToString("") { "%02x".format(it) }
        } catch (_: Throwable) {
            "anon"
        }
    }

    /**
     * Records a structured diagnostic event.
     * Guarantees thread safety and circular memory containment.
     */
    fun recordEvent(
        eventType: DiagnosticEventType,
        stage: PlaybackErrorStage,
        severity: DiagnosticSeverity,
        playbackRequestId: String,
        operationId: String? = null,
        playerInstanceId: String? = null,
        analysisJobId: String? = null,
        ffmpegJobId: String? = null,
        sourceType: PlaybackSourceType? = null,
        rawUriOrPath: String? = null,
        state: String? = null,
        previousState: String? = null,
        newState: String? = null,
        errorCategory: PlaybackErrorCategory? = null,
        errorCode: Int? = null,
        message: String,
        technicalMessage: String? = null,
        metadata: Map<String, String> = emptyMap()
    ): DiagnosticEvent {
        val seq = sequenceCounter.incrementAndGet()
        val safeUri = if (!rawUriOrPath.isNullOrBlank()) toSafeUriIdentity(rawUriOrPath) else null

        val event = DiagnosticEvent(
            timestamp = System.currentTimeMillis(),
            sequenceNumber = seq,
            eventType = eventType,
            stage = stage,
            severity = severity,
            playbackRequestId = playbackRequestId,
            operationId = operationId,
            playerInstanceId = playerInstanceId,
            analysisJobId = analysisJobId,
            ffmpegJobId = ffmpegJobId,
            sourceType = sourceType,
            sourceUriIdentity = safeUri,
            state = state,
            previousState = previousState,
            newState = newState,
            errorCategory = errorCategory,
            errorCode = errorCode,
            message = message,
            technicalMessage = technicalMessage,
            metadata = metadata
        )

        // Store in bounded queue for request
        synchronized(requestEvents) {
            if (requestEvents.size >= MAX_TRACKED_REQUESTS && !requestEvents.containsKey(playbackRequestId)) {
                val oldest = requestEvents.keys.firstOrNull()
                if (oldest != null) {
                    requestEvents.remove(oldest)
                    terminalResults.remove(oldest)
                }
            }
            val queue = requestEvents.getOrPut(playbackRequestId) { ArrayDeque() }
            if (queue.size >= MAX_EVENTS_PER_REQUEST) {
                queue.removeFirst()
            }
            queue.addLast(event)
        }

        // Track terminal results uniqueness
        if (eventType == DiagnosticEventType.PLAYBACK_FINAL_RESULT && newState != null) {
            try {
                val terminal = AuthoritativePlaybackResult.valueOf(newState)
                terminalResults.putIfAbsent(playbackRequestId, terminal)
            } catch (_: Throwable) { /* ignore */ }
        }

        // Emit to Android Logcat with structured tag
        val trace = event.toStructuredTrace()
        when (severity) {
            DiagnosticSeverity.DEBUG -> Log.d("DIAGNOSTIC", trace)
            DiagnosticSeverity.INFO -> Log.i("DIAGNOSTIC", trace)
            DiagnosticSeverity.WARN -> Log.w("DIAGNOSTIC", trace)
            DiagnosticSeverity.ERROR -> Log.e("DIAGNOSTIC", trace)
        }

        return event
    }

    /**
     * Throttled position advancement logger to prevent log flooding while capturing progress milestones.
     */
    fun recordPositionMilestone(
        playbackRequestId: String,
        playerInstanceId: String?,
        currentPositionMs: Long,
        durationMs: Long,
        sourceType: PlaybackSourceType?
    ) {
        val lastLogged = positionLogThrottle[playbackRequestId] ?: 0L
        val now = System.currentTimeMillis()

        // Log at 0ms, or every 5 seconds, or at duration >= 0
        if (currentPositionMs == 0L || (now - lastLogged) >= 5000L) {
            positionLogThrottle[playbackRequestId] = now
            val pct = if (durationMs > 0) ((currentPositionMs.toFloat() / durationMs.toFloat()) * 100).toInt() else 0
            recordEvent(
                eventType = DiagnosticEventType.MEDIA3_POSITION_ADVANCED,
                stage = PlaybackErrorStage.MEDIA3_PLAYBACK,
                severity = DiagnosticSeverity.DEBUG,
                playbackRequestId = playbackRequestId,
                playerInstanceId = playerInstanceId,
                sourceType = sourceType,
                message = "Position advanced to ${currentPositionMs}ms ($pct%)",
                metadata = mapOf("posMs" to currentPositionMs.toString(), "pct" to pct.toString())
            )
        }
    }

    /**
     * Retrieves all ordered diagnostic events recorded for a given PlaybackRequestId.
     */
    fun getEventsForRequest(requestId: String): List<DiagnosticEvent> {
        return synchronized(requestEvents) {
            requestEvents[requestId]?.toList() ?: emptyList()
        }
    }

    /**
     * Returns the single authoritative terminal result recorded for the request, if any.
     */
    fun getTerminalResult(requestId: String): AuthoritativePlaybackResult? {
        return terminalResults[requestId]
    }

    /**
     * Builds an authoritative diagnostic snapshot for a request.
     */
    fun getSnapshot(
        requestId: String,
        request: PlaybackRequest?,
        report: PlaybackAnalysisReport?
    ): PlaybackDiagnosticSnapshot {
        val events = getEventsForRequest(requestId)
        val safeUri = toSafeUriIdentity(request?.originalUri?.toString() ?: report?.playbackPath)
        
        return PlaybackDiagnosticSnapshot(
            playbackRequestId = requestId,
            playerInstanceId = request?.requestId?.let { PlaybackRequestCoordinator.getActivePlayerInstanceId() },
            analysisJobId = request?.analysisId,
            ffmpegJobId = request?.ffmpegJobId,
            sourceType = request?.activeSource?.sourceType ?: if (report?.fallbackUsed == true) PlaybackSourceType.FALLBACK else PlaybackSourceType.ORIGINAL,
            safeUriIdentity = safeUri,
            containerFormat = report?.containerFormat,
            videoCodec = report?.video?.codec,
            videoProfile = report?.video?.profile,
            bitDepth = report?.video?.bitDepth,
            resolution = if (report?.video != null && report.video.width > 0) "${report.video.width}x${report.video.height}" else null,
            audioCodec = report?.audio?.codec,
            decoderName = report?.deviceDecoder?.decoderName,
            decoderSupported = report?.deviceDecoder?.isSupported,
            directPlaybackCompatibility = report?.directPlaybackCompatibility,
            decisionStrategy = if (report?.fallbackUsed == true) "FALLBACK_REQUIRED" else "DIRECT_PLAYBACK",
            fallbackExecuted = report?.fallbackUsed == true || report?.fallbackTranscodeSuccess == true,
            fallbackValidated = report?.fallbackTranscodeSuccess == true,
            activeMedia3SourceUri = request?.activeSource?.uri?.let { toSafeUriIdentity(it.toString()) },
            playbackStarted = report?.actualPlaybackConfirmed == true || events.any { it.eventType == DiagnosticEventType.MEDIA3_PLAYBACK_STARTED },
            positionAdvanced = events.any { it.eventType == DiagnosticEventType.MEDIA3_POSITION_ADVANCED },
            terminalResult = request?.terminalResult ?: report?.terminalResult ?: terminalResults[requestId],
            authoritativeError = request?.authoritativeError ?: report?.authoritativeError,
            eventCount = events.size,
            events = events
        )
    }

    /**
     * Resets diagnostic registry state for test suites.
     */
    fun resetForTesting() {
        requestEvents.clear()
        terminalResults.clear()
        positionLogThrottle.clear()
        sequenceCounter.set(0)
    }
}
