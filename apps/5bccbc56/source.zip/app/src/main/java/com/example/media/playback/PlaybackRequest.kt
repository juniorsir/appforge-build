package com.example.media.playback

import android.net.Uri
import android.util.Log
import kotlinx.coroutines.Job
import java.util.UUID
import java.util.concurrent.atomic.AtomicInteger

/**
 * Authoritative playback request model separating playback request lifecycle
 * from transient player instance lifecycle (Phase 17.16-B).
 */
data class PlaybackRequest(
    val requestId: String,
    val mediaKey: String,
    val originalUri: Uri,
    val originalPath: String,
    val audioUriString: String? = null,
    var subtitleUriString: String? = null,
    var activeSource: PlaybackSource? = null,
    var fallbackUri: Uri? = null,
    var fallbackPath: String? = null,
    var fallbackUsed: Boolean = false,
    var fallbackProcessingActive: Boolean = false,
    var fallbackJob: Job? = null,
    var ffmpegSuccessConfirmed: Boolean = false,
    var savedPositionMs: Long = 0L,
    var playWhenReady: Boolean = true,
    var currentPlaybackState: String = "IDLE",
    var isTerminal: Boolean = false,
    var terminalResult: AuthoritativePlaybackResult? = null,
    var analysisId: String = "A_$requestId",
    var ffmpegJobId: String? = null,
    var authoritativeError: PlaybackError? = null
)

/**
 * Coordinator holding authoritative playback request state across player
 * recreations, configuration changes, background transitions, and concurrent operations (Phase 17.16 & 17.17).
 */
object PlaybackRequestCoordinator {
    private const val TAG = "PlaybackRequestCoord"

    private val playerInstanceCounter = AtomicInteger(0)
    private val analysisCounter = AtomicInteger(0)
    private val ffmpegJobCounter = AtomicInteger(0)

    private var activeRequest: PlaybackRequest? = null
    private var activePlayerInstanceId: String? = null

    fun generateNextPlayerInstanceId(): String {
        return "P${playerInstanceCounter.incrementAndGet()}"
    }

    fun generateNextAnalysisId(requestId: String): String {
        return "A${analysisCounter.incrementAndGet()}_$requestId"
    }

    fun generateNextFfmpegJobId(requestId: String): String {
        return "F${ffmpegJobCounter.incrementAndGet()}_$requestId"
    }

    // --- PHASE 17.17-Z TRACE SYSTEM ---

    fun logConcurrencyRequest(requestId: String, activeRequestId: String, operation: String, accepted: Boolean) {
        Log.i(
            "CONCURRENCY_REQUEST",
            "[CONCURRENCY_REQUEST] requestId=$requestId activeRequestId=$activeRequestId operation=$operation accepted=$accepted"
        )
        if (!accepted) {
            try {
                PlaybackDiagnosticRegistry.recordEvent(
                    eventType = DiagnosticEventType.STALE_EVENT,
                    stage = PlaybackErrorStage.MEDIA3_PLAYBACK,
                    severity = DiagnosticSeverity.WARN,
                    playbackRequestId = requestId,
                    message = "Stale concurrency request rejected: op=$operation activeReq=$activeRequestId"
                )
            } catch (_: Throwable) { /* ignore */ }
        }
    }

    fun logAsyncOperation(requestId: String, operationId: String, operationType: String, sourceType: String) {
        Log.i(
            "ASYNC_OPERATION",
            "[ASYNC_OPERATION] requestId=$requestId operationId=$operationId operationType=$operationType sourceType=$sourceType"
        )
        try {
            val src = if (sourceType.contains("FALLBACK", ignoreCase = true)) PlaybackSourceType.FALLBACK else PlaybackSourceType.ORIGINAL
            val evtType = when {
                operationType.contains("PROBE", ignoreCase = true) -> DiagnosticEventType.ANALYSIS_STARTED
                operationType.contains("COMPAT", ignoreCase = true) -> DiagnosticEventType.COMPATIBILITY_EVALUATED
                operationType.contains("FFMPEG", ignoreCase = true) -> DiagnosticEventType.FFMPEG_JOB_STARTED
                operationType.contains("VAL", ignoreCase = true) -> DiagnosticEventType.FALLBACK_VALIDATION_STARTED
                operationType.contains("MEDIA3", ignoreCase = true) -> DiagnosticEventType.MEDIA3_PREPARE_STARTED
                else -> DiagnosticEventType.INPUT_NORMALIZED
            }
            PlaybackDiagnosticRegistry.recordEvent(
                eventType = evtType,
                stage = PlaybackErrorStage.MEDIA3_PLAYBACK,
                severity = DiagnosticSeverity.INFO,
                playbackRequestId = requestId,
                operationId = operationId,
                sourceType = src,
                message = "Async operation started: opId=$operationId opType=$operationType sourceType=$sourceType"
            )
        } catch (_: Throwable) { /* ignore */ }
    }

    fun logCompatibilityAsync(
        requestId: String,
        codec: String,
        profile: String,
        bitDepth: Int,
        decoder: String,
        result: String,
        accepted: Boolean
    ) {
        Log.i(
            "COMPATIBILITY_ASYNC_TRACE",
            "[COMPATIBILITY_ASYNC_TRACE] requestId=$requestId codec=$codec profile=$profile bitDepth=$bitDepth decoder=$decoder result=$result accepted=$accepted"
        )
        try {
            PlaybackDiagnosticRegistry.recordEvent(
                eventType = DiagnosticEventType.COMPATIBILITY_EVALUATED,
                stage = PlaybackErrorStage.COMPATIBILITY,
                severity = if (accepted) DiagnosticSeverity.INFO else DiagnosticSeverity.WARN,
                playbackRequestId = requestId,
                message = "Compatibility evaluation: codec=$codec profile=$profile bitDepth=$bitDepth decoder=$decoder result=$result (accepted=$accepted)",
                metadata = mapOf("codec" to codec, "profile" to profile, "bitDepth" to bitDepth.toString(), "decoder" to decoder, "result" to result)
            )
        } catch (_: Throwable) { /* ignore */ }
    }

    fun logCancellationTrace(
        requestId: String,
        operationId: String,
        reason: String,
        cancelRequested: Boolean,
        callbackAccepted: Boolean
    ) {
        Log.i(
            "CANCELLATION_TRACE",
            "[CANCELLATION_TRACE] requestId=$requestId operationId=$operationId reason=$reason cancelRequested=$cancelRequested callbackAccepted=$callbackAccepted"
        )
        try {
            PlaybackDiagnosticRegistry.recordEvent(
                eventType = if (callbackAccepted) DiagnosticEventType.REQUEST_CANCELLED else DiagnosticEventType.STALE_EVENT,
                stage = PlaybackErrorStage.MEDIA3_PLAYBACK,
                severity = if (callbackAccepted) DiagnosticSeverity.INFO else DiagnosticSeverity.WARN,
                playbackRequestId = requestId,
                operationId = operationId,
                message = "Cancellation trace: reason=$reason cancelRequested=$cancelRequested accepted=$callbackAccepted"
            )
        } catch (_: Throwable) { /* ignore */ }
    }

    fun logMedia3ConcurrencyGuard(
        requestId: String,
        callbackPlayerId: String,
        activeRequestId: String,
        activePlayerId: String,
        operation: String,
        accepted: Boolean
    ) {
        Log.i(
            "MEDIA3_CONCURRENCY_GUARD",
            "[MEDIA3_CONCURRENCY_GUARD] requestId=$requestId callbackPlayerId=$callbackPlayerId activeRequestId=$activeRequestId activePlayerId=$activePlayerId operation=$operation accepted=$accepted"
        )
        if (!accepted) {
            try {
                PlaybackDiagnosticRegistry.recordEvent(
                    eventType = DiagnosticEventType.STALE_PLAYER_CALLBACK,
                    stage = PlaybackErrorStage.MEDIA3_PLAYBACK,
                    severity = DiagnosticSeverity.WARN,
                    playbackRequestId = requestId,
                    playerInstanceId = callbackPlayerId,
                    message = "Stale player callback rejected: player=$callbackPlayerId activePlayer=$activePlayerId op=$operation"
                )
            } catch (_: Throwable) { /* ignore */ }
        }
    }

    fun logPlaybackVerifyConcurrency(
        requestId: String,
        playerInstanceId: String,
        expectedUri: String,
        actualUri: String,
        position: Long,
        accepted: Boolean
    ) {
        Log.i(
            "PLAYBACK_VERIFY_CONCURRENCY",
            "[PLAYBACK_VERIFY_CONCURRENCY] requestId=$requestId playerInstanceId=$playerInstanceId expectedUri=$expectedUri actualUri=$actualUri position=$position accepted=$accepted"
        )
    }

    fun logTerminalStateGuard(
        requestId: String,
        state: String,
        event: String,
        accepted: Boolean
    ) {
        Log.i(
            "TERMINAL_STATE_GUARD",
            "[TERMINAL_STATE_GUARD] requestId=$requestId state=$state event=$event accepted=$accepted"
        )
        if (!accepted) {
            try {
                PlaybackDiagnosticRegistry.recordEvent(
                    eventType = DiagnosticEventType.STALE_EVENT,
                    stage = PlaybackErrorStage.MEDIA3_PLAYBACK,
                    severity = DiagnosticSeverity.WARN,
                    playbackRequestId = requestId,
                    state = state,
                    message = "Event rejected by terminal state guard: event=$event state=$state"
                )
            } catch (_: Throwable) { /* ignore */ }
        }
    }

    fun logErrorClassification(error: PlaybackError, accepted: Boolean) {
        PlaybackErrorClassifier.logErrorClassification(error, accepted)
        try {
            PlaybackDiagnosticRegistry.recordEvent(
                eventType = DiagnosticEventType.MEDIA3_ERROR,
                stage = error.stage,
                severity = if (accepted) DiagnosticSeverity.ERROR else DiagnosticSeverity.WARN,
                playbackRequestId = error.requestId,
                errorCategory = error.category,
                errorCode = error.code,
                message = "Error classified: category=${error.category.name} stage=${error.stage.name} recoverable=${error.recoverable.name} accepted=$accepted",
                technicalMessage = error.technicalMessage
            )
        } catch (_: Throwable) { /* ignore */ }
    }

    fun logErrorRecovery(
        requestId: String,
        category: PlaybackErrorCategory,
        action: PlaybackRecoveryAction,
        accepted: Boolean
    ) {
        PlaybackErrorClassifier.logErrorRecovery(requestId, category, action, accepted)
    }

    @Synchronized
    fun setAuthoritativeError(requestId: String, error: PlaybackError) {
        val current = activeRequest
        if (current != null && current.requestId == requestId) {
            current.authoritativeError = error
        }
    }

    @Synchronized
    fun getAuthoritativeError(requestId: String): PlaybackError? {
        val current = activeRequest
        return if (current != null && current.requestId == requestId) current.authoritativeError else null
    }

    @Synchronized
    fun getOrCreateRequest(
        mediaKey: String,
        originalUri: Uri,
        originalPath: String,
        audioUriString: String? = null,
        subtitleUriString: String? = null,
        forceNew: Boolean = false
    ): Pair<PlaybackRequest, Boolean> {
        val current = activeRequest
        if (!forceNew && current != null && current.mediaKey == mediaKey) {
            Log.i(
                TAG,
                "[PLAYER_RESTORE_TRACE] Reusing existing authoritative request requestId=${current.requestId} for mediaKey=$mediaKey"
            )
            return Pair(current, false) // existing request restored
        }

        // New user playback action receives a new request ID (Invariant 12)
        val newRequestId = UUID.randomUUID().toString().take(8)
        val newRequest = PlaybackRequest(
            requestId = newRequestId,
            mediaKey = mediaKey,
            originalUri = originalUri,
            originalPath = originalPath,
            audioUriString = audioUriString,
            subtitleUriString = subtitleUriString
        )
        activeRequest = newRequest
        Log.i(TAG, "[PLAYBACK_REQUEST_NEW] Created new authoritative request requestId=$newRequestId for mediaKey=$mediaKey")
        return Pair(newRequest, true) // newly created request
    }

    @Synchronized
    fun getActiveRequest(): PlaybackRequest? = activeRequest

    @Synchronized
    fun getActiveRequestId(): String? = activeRequest?.requestId

    @Synchronized
    fun setActivePlayerInstanceId(instanceId: String?) {
        val oldId = activePlayerInstanceId
        activePlayerInstanceId = instanceId
        val reqId = activeRequest?.requestId ?: "none"
        if (instanceId != null) {
            Log.i(
                "PLAYER_INSTANCE",
                "[PLAYER_INSTANCE] requestId=$reqId playerInstanceId=$instanceId event=ATTACH"
            )
        } else if (oldId != null) {
            Log.i(
                "PLAYER_INSTANCE",
                "[PLAYER_INSTANCE] requestId=$reqId playerInstanceId=$oldId event=RELEASE"
            )
        }
    }

    @Synchronized
    fun getActivePlayerInstanceId(): String? = activePlayerInstanceId

    @Synchronized
    fun updateActiveSource(requestId: String, source: PlaybackSource) {
        val current = activeRequest
        if (current != null && current.requestId == requestId) {
            current.activeSource = source
            if (source.sourceType == PlaybackSourceType.FALLBACK) {
                current.fallbackUsed = true
                current.fallbackUri = source.uri
                current.fallbackPath = source.path
            }
        }
    }

    @Synchronized
    fun savePosition(requestId: String, positionMs: Long) {
        val current = activeRequest
        if (current != null && current.requestId == requestId) {
            if (positionMs >= 0L) {
                current.savedPositionMs = positionMs
            }
        }
    }

    @Synchronized
    fun getSavedPosition(requestId: String): Long {
        val current = activeRequest
        return if (current != null && current.requestId == requestId) current.savedPositionMs else 0L
    }

    @Synchronized
    fun savePlayWhenReady(requestId: String, playWhenReady: Boolean) {
        val current = activeRequest
        if (current != null && current.requestId == requestId) {
            current.playWhenReady = playWhenReady
        }
    }

    @Synchronized
    fun getPlayWhenReady(requestId: String): Boolean {
        val current = activeRequest
        return current?.playWhenReady ?: true
    }

    @Synchronized
    fun markFallbackStarted(requestId: String, job: Job?) {
        val current = activeRequest
        if (current != null && current.requestId == requestId) {
            current.fallbackProcessingActive = true
            current.fallbackJob = job
        }
    }

    @Synchronized
    fun markFallbackCompleted(
        requestId: String,
        fallbackUri: Uri,
        fallbackPath: String,
        ffmpegSuccess: Boolean
    ) {
        val current = activeRequest
        if (current != null && current.requestId == requestId) {
            current.fallbackProcessingActive = false
            current.fallbackUsed = true
            current.fallbackUri = fallbackUri
            current.fallbackPath = fallbackPath
            current.ffmpegSuccessConfirmed = ffmpegSuccess
            current.fallbackJob = null
        }
    }

    @Synchronized
    fun cancelFallbackJob(requestId: String) {
        val current = activeRequest
        if (current != null && current.requestId == requestId) {
            current.fallbackJob?.cancel()
            current.fallbackJob = null
            current.fallbackProcessingActive = false
        }
    }

    @Synchronized
    fun cancelActiveRequest(requestId: String) {
        val current = activeRequest
        if (current != null && current.requestId == requestId) {
            current.fallbackJob?.cancel()
            current.fallbackJob = null
            current.fallbackProcessingActive = false
        }
    }

    @Synchronized
    fun markTerminal(
        requestId: String,
        state: String,
        terminalResult: AuthoritativePlaybackResult?
    ) {
        val current = activeRequest
        if (current != null && current.requestId == requestId) {
            current.currentPlaybackState = state
            current.isTerminal = true
            current.terminalResult = terminalResult
        }
    }

    /**
     * Stale Player Callback & Concurrency Guard (Phase 17.16-M & Phase 17.17-O/S/Z).
     * Prevents callbacks from old/released player instances or stale/terminal requests from mutating state.
     */
    @Synchronized
    fun isCallbackAccepted(requestId: String, callbackPlayerInstanceId: String, event: String): Boolean {
        val current = activeRequest
        val activeReqId = current?.requestId ?: "none"
        val activePlayer = activePlayerInstanceId ?: "none"

        if (callbackPlayerInstanceId != activePlayer || requestId != activeReqId) {
            logMedia3ConcurrencyGuard(
                requestId = requestId,
                callbackPlayerId = callbackPlayerInstanceId,
                activeRequestId = activeReqId,
                activePlayerId = activePlayer,
                operation = event,
                accepted = false
            )
            Log.i(
                "PLAYER_CALLBACK_GUARD",
                "[PLAYER_CALLBACK_GUARD] requestId=$requestId callbackPlayer=$callbackPlayerInstanceId activePlayer=$activePlayer accepted=false event=$event"
            )
            return false
        }

        // Terminal state guard (Phase 17.17-S: Terminal state race)
        if (current?.isTerminal == true && (event == "onPlayerError" || event == "onPlaybackStateChanged")) {
            logTerminalStateGuard(
                requestId = requestId,
                state = current.currentPlaybackState,
                event = event,
                accepted = false
            )
            return false
        }

        logMedia3ConcurrencyGuard(
            requestId = requestId,
            callbackPlayerId = callbackPlayerInstanceId,
            activeRequestId = activeReqId,
            activePlayerId = activePlayer,
            operation = event,
            accepted = true
        )
        Log.i(
            "PLAYER_CALLBACK_GUARD",
            "[PLAYER_CALLBACK_GUARD] requestId=$requestId callbackPlayer=$callbackPlayerInstanceId activePlayer=$activePlayer accepted=true event=$event"
        )
        return true
    }

    @Synchronized
    fun verifyPlaybackSource(
        requestId: String,
        playerInstanceId: String,
        actualUri: String?,
        positionMs: Long
    ): Boolean {
        val current = activeRequest
        val activeReqId = current?.requestId ?: "none"
        val activePlayer = activePlayerInstanceId ?: "none"
        val expectedUri = current?.activeSource?.uri?.toString() ?: "none"
        val actual = actualUri ?: "none"

        val reqMatches = (requestId == activeReqId)
        val playerMatches = (playerInstanceId == activePlayer)
        
        // Exact strict equality for URIs. No heuristic substring matches.
        val uriMatches = (actual == expectedUri)
        val accepted = reqMatches && playerMatches && uriMatches

        if (reqMatches && playerMatches && !uriMatches) {
            Log.e(TAG, "[MEDIA3_HANDOFF_URI_MISMATCH] requestId=$requestId expectedUri=$expectedUri actualPlayerUri=$actual")
        }

        logPlaybackVerifyConcurrency(
            requestId = requestId,
            playerInstanceId = playerInstanceId,
            expectedUri = expectedUri,
            actualUri = actual,
            position = positionMs,
            accepted = accepted
        )
        return accepted
    }

    @Synchronized
    fun isRequestActive(requestId: String): Boolean {
        return activeRequest?.requestId == requestId
    }

    @Synchronized
    fun isRequestTerminal(requestId: String): Boolean {
        return activeRequest?.let { it.requestId == requestId && it.isTerminal } ?: false
    }

    @Synchronized
    fun isActiveSourceFallback(requestId: String): Boolean {
        return activeRequest?.let { it.requestId == requestId && it.activeSource?.sourceType == PlaybackSourceType.FALLBACK } ?: false
    }

    // --- PHASE 17.21 MEDIA3 RUNTIME DECODER & FORMAT TRACE METHODS ---

    fun logMedia3FormatTrace(
        requestId: String,
        playerInstanceId: String?,
        sampleMimeType: String?,
        codecs: String?,
        width: Int,
        height: Int,
        frameRate: Float,
        rotationDegrees: Int,
        pixelWidthHeightRatio: Float,
        profile: String?,
        level: String?,
        colorInfo: String?,
        cryptoType: Int,
        sourceType: PlaybackSourceType?
    ) {
        val src = sourceType?.name ?: "ORIGINAL"
        Log.i(
            "MEDIA3_FORMAT_TRACE",
            "[MEDIA3_FORMAT_TRACE][id=$requestId] player=${playerInstanceId ?: "none"} mime=${sampleMimeType ?: "unknown"} codecs=${codecs ?: "none"} width=$width height=$height fps=$frameRate rotation=$rotationDegrees par=$pixelWidthHeightRatio profile=${profile ?: "none"} level=${level ?: "none"} color=${colorInfo ?: "none"} crypto=$cryptoType src=$src"
        )
        try {
            PlaybackDiagnosticRegistry.recordEvent(
                eventType = DiagnosticEventType.MEDIA3_FORMAT_DETECTED,
                stage = PlaybackErrorStage.MEDIA3_PLAYBACK,
                severity = DiagnosticSeverity.INFO,
                playbackRequestId = requestId,
                playerInstanceId = playerInstanceId,
                sourceType = sourceType,
                message = "Media3 video format detected: mime=$sampleMimeType codecs=$codecs res=${width}x${height} fps=$frameRate",
                metadata = mapOf(
                    "mime" to (sampleMimeType ?: "unknown"),
                    "codecs" to (codecs ?: "none"),
                    "resolution" to "${width}x${height}",
                    "fps" to frameRate.toString(),
                    "sourceType" to src
                )
            )
        } catch (_: Throwable) { /* ignore */ }
    }

    fun logMedia3AudioFormat(
        requestId: String,
        playerInstanceId: String?,
        sampleMimeType: String?,
        codecs: String?,
        sampleRate: Int,
        channelCount: Int,
        language: String?,
        sourceType: PlaybackSourceType?
    ) {
        val src = sourceType?.name ?: "ORIGINAL"
        Log.i(
            "MEDIA3_AUDIO_FORMAT",
            "[MEDIA3_AUDIO_FORMAT][id=$requestId] player=${playerInstanceId ?: "none"} mime=${sampleMimeType ?: "unknown"} codecs=${codecs ?: "none"} sampleRate=$sampleRate channels=$channelCount lang=${language ?: "und"} src=$src"
        )
        try {
            PlaybackDiagnosticRegistry.recordEvent(
                eventType = DiagnosticEventType.MEDIA3_AUDIO_FORMAT_DETECTED,
                stage = PlaybackErrorStage.MEDIA3_PLAYBACK,
                severity = DiagnosticSeverity.INFO,
                playbackRequestId = requestId,
                playerInstanceId = playerInstanceId,
                sourceType = sourceType,
                message = "Media3 audio format detected: mime=$sampleMimeType codecs=$codecs rate=$sampleRate ch=$channelCount lang=$language",
                metadata = mapOf(
                    "mime" to (sampleMimeType ?: "unknown"),
                    "codecs" to (codecs ?: "none"),
                    "sampleRate" to sampleRate.toString(),
                    "channelCount" to channelCount.toString(),
                    "sourceType" to src
                )
            )
        } catch (_: Throwable) { /* ignore */ }
    }

    fun logMedia3DecoderInit(
        requestId: String,
        playerInstanceId: String?,
        decoderName: String,
        mimeType: String?,
        formatStr: String?,
        durationMs: Long
    ) {
        Log.i(
            "MEDIA3_DECODER_INIT",
            "[MEDIA3_DECODER_INIT][id=$requestId] player=${playerInstanceId ?: "none"} decoder=$decoderName mime=${mimeType ?: "unknown"} format=${formatStr ?: "none"} durationMs=$durationMs"
        )
        try {
            PlaybackDiagnosticRegistry.recordEvent(
                eventType = DiagnosticEventType.MEDIA3_DECODER_INITIALIZED,
                stage = PlaybackErrorStage.MEDIA3_PLAYBACK,
                severity = DiagnosticSeverity.INFO,
                playbackRequestId = requestId,
                playerInstanceId = playerInstanceId,
                message = "Media3 decoder initialized: $decoderName (mime=$mimeType duration=${durationMs}ms)",
                metadata = mapOf(
                    "decoder" to decoderName,
                    "mime" to (mimeType ?: "unknown"),
                    "durationMs" to durationMs.toString()
                )
            )
        } catch (_: Throwable) { /* ignore */ }
    }

    fun logMedia3DecoderSelected(
        requestId: String,
        playerInstanceId: String?,
        trackType: String,
        decoderName: String,
        isHardware: Boolean,
        mimeType: String?
    ) {
        Log.i(
            "MEDIA3_DECODER_SELECTED",
            "[MEDIA3_DECODER_SELECTED][id=$requestId] player=${playerInstanceId ?: "none"} trackType=$trackType decoder=$decoderName isHardware=$isHardware mimeType=${mimeType ?: "unknown"}"
        )
        try {
            PlaybackDiagnosticRegistry.recordEvent(
                eventType = DiagnosticEventType.MEDIA3_DECODER_SELECTED,
                stage = PlaybackErrorStage.MEDIA3_PLAYBACK,
                severity = DiagnosticSeverity.INFO,
                playbackRequestId = requestId,
                playerInstanceId = playerInstanceId,
                message = "Media3 decoder selected: track=$trackType decoder=$decoderName isHardware=$isHardware mime=$mimeType",
                metadata = mapOf(
                    "trackType" to trackType,
                    "decoder" to decoderName,
                    "isHardware" to isHardware.toString(),
                    "mimeType" to (mimeType ?: "unknown")
                )
            )
        } catch (_: Throwable) { /* ignore */ }
    }

    fun logMedia3DecoderDifference(
        requestId: String,
        predictedDecoder: String?,
        actualDecoder: String,
        reason: String = "Media3 runtime ranking rules"
    ) {
        Log.i(
            "MEDIA3_DECODER_DIFFERENCE",
            "[MEDIA3_DECODER_DIFFERENCE][id=$requestId] predicted=${predictedDecoder ?: "none"} actual=$actualDecoder reason=\"$reason\""
        )
        try {
            PlaybackDiagnosticRegistry.recordEvent(
                eventType = DiagnosticEventType.MEDIA3_DECODER_DIFFERENCE,
                stage = PlaybackErrorStage.MEDIA3_PLAYBACK,
                severity = DiagnosticSeverity.INFO,
                playbackRequestId = requestId,
                message = "Decoder selection difference: predicted=$predictedDecoder actual=$actualDecoder reason=$reason",
                metadata = mapOf(
                    "predicted" to (predictedDecoder ?: "none"),
                    "actual" to actualDecoder,
                    "reason" to reason
                )
            )
        } catch (_: Throwable) { /* ignore */ }
    }

    fun logMedia3TrackSelection(
        requestId: String,
        playerInstanceId: String?,
        selectedVideoTrack: String?,
        selectedAudioTrack: String?,
        groupCount: Int
    ) {
        Log.i(
            "MEDIA3_TRACK_SELECTION",
            "[MEDIA3_TRACK_SELECTION][id=$requestId] player=${playerInstanceId ?: "none"} videoTrack=${selectedVideoTrack ?: "none"} audioTrack=${selectedAudioTrack ?: "none"} groupCount=$groupCount"
        )
        try {
            PlaybackDiagnosticRegistry.recordEvent(
                eventType = DiagnosticEventType.MEDIA3_TRACKS_CHANGED,
                stage = PlaybackErrorStage.MEDIA3_PLAYBACK,
                severity = DiagnosticSeverity.INFO,
                playbackRequestId = requestId,
                playerInstanceId = playerInstanceId,
                message = "Media3 tracks changed: video=$selectedVideoTrack audio=$selectedAudioTrack groupCount=$groupCount",
                metadata = mapOf(
                    "videoTrack" to (selectedVideoTrack ?: "none"),
                    "audioTrack" to (selectedAudioTrack ?: "none"),
                    "groupCount" to groupCount.toString()
                )
            )
        } catch (_: Throwable) { /* ignore */ }
    }

    fun logMedia3SupportTrace(
        requestId: String,
        playerInstanceId: String?,
        trackType: String,
        formatSupport: String,
        formatStr: String?,
        isSupported: Boolean
    ) {
        Log.i(
            "MEDIA3_SUPPORT_TRACE",
            "[MEDIA3_SUPPORT_TRACE][id=$requestId] player=${playerInstanceId ?: "none"} trackType=$trackType formatSupport=$formatSupport format=${formatStr ?: "none"} isSupported=$isSupported"
        )
        try {
            PlaybackDiagnosticRegistry.recordEvent(
                eventType = DiagnosticEventType.MEDIA3_SUPPORT_EVALUATED,
                stage = PlaybackErrorStage.MEDIA3_PLAYBACK,
                severity = if (isSupported) DiagnosticSeverity.INFO else DiagnosticSeverity.WARN,
                playbackRequestId = requestId,
                playerInstanceId = playerInstanceId,
                message = "Media3 format support evaluated: track=$trackType support=$formatSupport supported=$isSupported",
                metadata = mapOf(
                    "trackType" to trackType,
                    "formatSupport" to formatSupport,
                    "isSupported" to isSupported.toString()
                )
            )
        } catch (_: Throwable) { /* ignore */ }
    }

    fun logMedia3DecoderError(
        requestId: String,
        playerInstanceId: String?,
        sourceType: PlaybackSourceType?,
        errorCode: Int,
        errorName: String,
        exceptionType: String,
        cause: String?,
        rendererName: String?,
        decoderName: String?,
        format: String?,
        formatSupport: String?
    ) {
        Log.e(
            "MEDIA3_DECODER_ERROR",
            "[MEDIA3_DECODER_ERROR][id=$requestId] player=${playerInstanceId ?: "none"} src=${sourceType?.name ?: "ORIGINAL"} errCode=$errorCode errName=$errorName excType=$exceptionType cause=\"${cause ?: "none"}\" renderer=${rendererName ?: "none"} decoder=${decoderName ?: "none"} format=${format ?: "none"} formatSupport=${formatSupport ?: "none"}"
        )
        try {
            PlaybackDiagnosticRegistry.recordEvent(
                eventType = DiagnosticEventType.MEDIA3_DECODER_ERROR,
                stage = PlaybackErrorStage.MEDIA3_PLAYBACK,
                severity = DiagnosticSeverity.ERROR,
                playbackRequestId = requestId,
                playerInstanceId = playerInstanceId,
                sourceType = sourceType,
                errorCode = errorCode,
                message = "Media3 decoder error: $errorName ($errorCode) in renderer=$rendererName decoder=$decoderName",
                technicalMessage = cause,
                metadata = mapOf(
                    "errorName" to errorName,
                    "errorCode" to errorCode.toString(),
                    "exceptionType" to exceptionType,
                    "renderer" to (rendererName ?: "none"),
                    "decoder" to (decoderName ?: "none"),
                    "formatSupport" to (formatSupport ?: "none")
                )
            )
        } catch (_: Throwable) { /* ignore */ }
    }

    @Synchronized
    fun resetForTesting() {
        activeRequest = null
        activePlayerInstanceId = null
        playerInstanceCounter.set(0)
        analysisCounter.set(0)
        ffmpegJobCounter.set(0)
    }
}
