package com.example.storage.cleanup

import android.content.Context
import android.os.Environment
import android.util.Log
import com.example.data.AppDatabase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

enum class UnwantedFileCategory(val displayName: String) {
    TEMP_AND_PARTIAL("Temp & Incomplete"),
    TRANSCODE_CACHE("Transcode & Cache"),
    BROKEN_FILES("Broken & 0B Files"),
    WATCHED_MEDIA("Watched Media"),
    LOGS_AND_TRACES("Logs & Diagnostics")
}

data class UnwantedFileItem(
    val id: String,
    val name: String,
    val path: String,
    val sizeBytes: Long,
    val category: UnwantedFileCategory,
    val reason: String,
    val lastModifiedMs: Long,
    val associatedDownloadId: String? = null
)

data class UnwantedCleanResult(
    val deletedCount: Int,
    val freedBytes: Long,
    val failedCount: Int
)

object UnwantedFilesCleanerManager {
    private const val TAG = "UnwantedFilesCleaner"

    private val TEMP_EXTENSIONS = setOf("tmp", "part", "ytdl", "download", "temp", "part-Frag", "frag")

    suspend fun scanUnwantedFiles(
        context: Context,
        database: AppDatabase
    ): List<UnwantedFileItem> = withContext(Dispatchers.IO) {
        val items = mutableListOf<UnwantedFileItem>()
        val seenPaths = mutableSetOf<String>()

        try {
            // 1. Scan Internal and External Cache Directories for Temp & Transcode Fragments
            val cacheDirs = listOfNotNull(
                context.cacheDir,
                context.externalCacheDir,
                context.codeCacheDir,
                File(context.cacheDir, "ffmpeg_temp"),
                File(context.cacheDir, "transcode_cache"),
                File(context.cacheDir, "audio_cache"),
                File(context.cacheDir, "thumbnail_cache")
            )

            for (dir in cacheDirs) {
                if (dir.exists() && dir.isDirectory) {
                    scanDirectoryForJunk(dir, items, seenPaths, isCacheDir = true)
                }
            }

            // 2. Scan App Files and Download Directories for Leftover Temp Files (.tmp, .part, etc.)
            val downloadDirs = listOfNotNull(
                context.filesDir,
                context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS),
                context.getExternalFilesDir(Environment.DIRECTORY_MOVIES),
                context.getExternalFilesDir(Environment.DIRECTORY_MUSIC),
                context.getExternalFilesDir(null)
            )

            for (dir in downloadDirs) {
                if (dir.exists() && dir.isDirectory) {
                    scanDirectoryForJunk(dir, items, seenPaths, isCacheDir = false)
                }
            }

            // 3. Scan Database for Failed / Cancelled / 0-Byte Unfinalized Downloads
            val allDownloads = try { database.downloadDao().getAllDownloadsSync() } catch (e: Exception) { emptyList() }
            val activeDownloadIds = allDownloads.filter { 
                it.downloadStatus.equals("DOWNLOADING", ignoreCase = true) ||
                it.downloadStatus.equals("PAUSED", ignoreCase = true) ||
                it.downloadStatus.equals("QUEUED", ignoreCase = true)
            }.map { it.id }.toSet()

            for (download in allDownloads) {
                if (activeDownloadIds.contains(download.id)) continue

                val file = File(download.localPath)
                if (file.exists() && !seenPaths.contains(file.absolutePath)) {
                    val statusUpper = download.downloadStatus.uppercase()
                    if (statusUpper == "FAILED" || statusUpper == "CANCELLED" || statusUpper == "CORRUPTED" || statusUpper == "INCOMPLETE") {
                        seenPaths.add(file.absolutePath)
                        items.add(
                            UnwantedFileItem(
                                id = "db_failed_${download.id}",
                                name = file.name.ifBlank { download.title },
                                path = file.absolutePath,
                                sizeBytes = file.length(),
                                category = UnwantedFileCategory.BROKEN_FILES,
                                reason = "Failed/Cancelled download artifact (${download.downloadStatus})",
                                lastModifiedMs = file.lastModified(),
                                associatedDownloadId = download.id
                            )
                        )
                    } else if (file.length() == 0L) {
                        seenPaths.add(file.absolutePath)
                        items.add(
                            UnwantedFileItem(
                                id = "db_zero_${download.id}",
                                name = file.name.ifBlank { download.title },
                                path = file.absolutePath,
                                sizeBytes = 0L,
                                category = UnwantedFileCategory.BROKEN_FILES,
                                reason = "0-byte broken media record",
                                lastModifiedMs = file.lastModified(),
                                associatedDownloadId = download.id
                            )
                        )
                    }
                }
            }

            // 4. Scan for Watched & Completed Media Items (if eligible / watched)
            val allProgress = try { database.playbackDao().getAllProgressSync().associateBy { it.mediaId } } catch (e: Exception) { emptyMap() }
            for (download in allDownloads) {
                if (download.isFavorite || download.isProtected || download.isKept) continue
                if (activeDownloadIds.contains(download.id)) continue

                val progress = allProgress[download.id]
                if (progress != null && progress.isCompleted) {
                    val file = File(download.localPath)
                    if (file.exists() && !seenPaths.contains(file.absolutePath)) {
                        seenPaths.add(file.absolutePath)
                        items.add(
                            UnwantedFileItem(
                                id = "db_watched_${download.id}",
                                name = file.name.ifBlank { download.title },
                                path = file.absolutePath,
                                sizeBytes = file.length(),
                                category = UnwantedFileCategory.WATCHED_MEDIA,
                                reason = "Fully watched media (100% completed)",
                                lastModifiedMs = progress.lastPlayedTimestamp.takeIf { it > 0 } ?: file.lastModified(),
                                associatedDownloadId = download.id
                            )
                        )
                    }
                }
            }

            // 5. Scan for Diagnostic Log and Trace Files
            val logDirs = listOfNotNull(
                context.getExternalFilesDir("logs"),
                File(context.cacheDir, "logs"),
                File(context.filesDir, "logs")
            )
            for (dir in logDirs) {
                if (dir.exists() && dir.isDirectory) {
                    dir.listFiles()?.forEach { logFile ->
                        if (logFile.isFile && !seenPaths.contains(logFile.absolutePath)) {
                            seenPaths.add(logFile.absolutePath)
                            items.add(
                                UnwantedFileItem(
                                    id = "log_${logFile.name}_${logFile.lastModified()}",
                                    name = logFile.name,
                                    path = logFile.absolutePath,
                                    sizeBytes = logFile.length(),
                                    category = UnwantedFileCategory.LOGS_AND_TRACES,
                                    reason = "App diagnostic / trace log dump",
                                    lastModifiedMs = logFile.lastModified()
                                )
                            )
                        }
                    }
                }
            }

        } catch (e: Exception) {
            Log.e(TAG, "Error scanning for unwanted files: ${e.message}", e)
        }

        items.sortedWith(compareByDescending<UnwantedFileItem> { it.sizeBytes }.thenByDescending { it.lastModifiedMs })
    }

    private fun scanDirectoryForJunk(
        dir: File,
        results: MutableList<UnwantedFileItem>,
        seenPaths: MutableSet<String>,
        isCacheDir: Boolean,
        depth: Int = 0
    ) {
        if (depth > 4) return
        val files = dir.listFiles() ?: return

        for (file in files) {
            if (file.isDirectory) {
                scanDirectoryForJunk(file, results, seenPaths, isCacheDir, depth + 1)
            } else if (file.isFile) {
                val path = file.absolutePath
                if (seenPaths.contains(path)) continue

                val ext = file.extension.lowercase()
                val name = file.name.lowercase()

                when {
                    TEMP_EXTENSIONS.contains(ext) || name.contains(".part-") || name.endsWith(".part") || name.endsWith(".ytdl") -> {
                        seenPaths.add(path)
                        results.add(
                            UnwantedFileItem(
                                id = "temp_${file.name}_${file.lastModified()}",
                                name = file.name,
                                path = path,
                                sizeBytes = file.length(),
                                category = UnwantedFileCategory.TEMP_AND_PARTIAL,
                                reason = "Incomplete/temporary fragment (.$ext)",
                                lastModifiedMs = file.lastModified()
                            )
                        )
                    }
                    isCacheDir && (ext in setOf("ts", "aac", "wav", "raw", "pcm", "m4s") || name.contains("transcode_") || name.contains("mux_") || name.contains("probe_")) -> {
                        seenPaths.add(path)
                        results.add(
                            UnwantedFileItem(
                                id = "cache_${file.name}_${file.lastModified()}",
                                name = file.name,
                                path = path,
                                sizeBytes = file.length(),
                                category = UnwantedFileCategory.TRANSCODE_CACHE,
                                reason = "Transcoding pipeline intermediate cache",
                                lastModifiedMs = file.lastModified()
                            )
                        )
                    }
                    file.length() == 0L && (isCacheDir || TEMP_EXTENSIONS.contains(ext)) -> {
                        seenPaths.add(path)
                        results.add(
                            UnwantedFileItem(
                                id = "zero_${file.name}_${file.lastModified()}",
                                name = file.name,
                                path = path,
                                sizeBytes = 0L,
                                category = UnwantedFileCategory.BROKEN_FILES,
                                reason = "0-byte orphaned file",
                                lastModifiedMs = file.lastModified()
                            )
                        )
                    }
                    isCacheDir && (name.endsWith(".log") || name.endsWith(".txt") || name.contains("trace")) -> {
                        seenPaths.add(path)
                        results.add(
                            UnwantedFileItem(
                                id = "log_${file.name}_${file.lastModified()}",
                                name = file.name,
                                path = path,
                                sizeBytes = file.length(),
                                category = UnwantedFileCategory.LOGS_AND_TRACES,
                                reason = "Temporary log dump",
                                lastModifiedMs = file.lastModified()
                            )
                        )
                    }
                }
            }
        }
    }

    suspend fun removeSelectedFiles(
        context: Context,
        database: AppDatabase,
        itemsToDelete: List<UnwantedFileItem>
    ): UnwantedCleanResult = withContext(Dispatchers.IO) {
        var deleted = 0
        var freedBytes = 0L
        var failed = 0

        for (item in itemsToDelete) {
            try {
                val file = File(item.path)
                val len = if (file.exists()) file.length() else item.sizeBytes
                var fileDeleted = false

                if (file.exists()) {
                    fileDeleted = file.delete()
                    if (!fileDeleted) {
                        try {
                            file.deleteOnExit()
                        } catch (_: Exception) {}
                    }
                } else {
                    fileDeleted = true // Already gone from disk
                }

                // If associated with a download entity in database, clean it up
                item.associatedDownloadId?.let { downloadId ->
                    try {
                        database.downloadDao().deleteDownloadById(downloadId)
                    } catch (e: Exception) {
                        Log.w(TAG, "Error removing download entity $downloadId: ${e.message}")
                    }
                }

                if (fileDeleted) {
                    deleted++
                    freedBytes += len
                } else {
                    failed++
                }
            } catch (e: Exception) {
                Log.e(TAG, "Failed to delete unwanted file ${item.path}: ${e.message}", e)
                failed++
            }
        }

        Log.i(TAG, "Cleaned unwanted files: deleted=$deleted, freedBytes=$freedBytes, failed=$failed")
        UnwantedCleanResult(deleted, freedBytes, failed)
    }
}
