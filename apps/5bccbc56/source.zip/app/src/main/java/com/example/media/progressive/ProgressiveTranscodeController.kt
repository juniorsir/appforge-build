package com.example.media.progressive

import android.content.Context
import android.util.Log
import com.example.media.playback.PlaybackErrorCategory
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Phase 17.35: Smart Background Transcoding Controller.
 * Authoritative orchestrator for progressive background transcoding.
 */
object ProgressiveTranscodeController {
    private const val TAG = "ProgressiveTranscodeController"

    private const val DEFAULT_BASE_STARTUP_DURATION_MS = 8_000L
    private const val MIN_STARTUP_DURATION_MS = 4_000L
    private const val MAX_STARTUP_DURATION_MS = 16_000L

    private val _state = MutableStateFlow(ProgressiveTranscodeState())
    val state: StateFlow<ProgressiveTranscodeState> = _state.asStateFlow()

    @Volatile
    private var activeRequestId: String? = null

    @Volatile
    private var activeJobId: String? = null

    @Volatile
    private var activeCollectorJob: Job? = null

    @Volatile
    private var startTimestampMs: Long = 0L

    private val isCancelling = AtomicBoolean(false)

    init {
        Log.i("FALLBACK_TRACE", "[TRANSCODE_CONTROLLER_CREATED] Controller initialized")
    }

    /**
     * Starts progressive background transcoding for the specified request.
     * Cancels any previously running job to ensure strict request isolation.
     */
    fun startTranscoding(
        context: Context,
        request: ProgressiveGenerationRequest,
        coroutineScope: CoroutineScope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    ): StateFlow<ProgressiveTranscodeState> {
        val reqId = request.playbackRequestId
        val jobId = request.transcodeJobId

        // Handle rapid switching: supersede any previous active job
        val previousJobId = activeJobId
        if (previousJobId != null && previousJobId != jobId) {
            Log.w("FALLBACK_TRACE", "[TRANSCODE_CONTROLLER_STALE] Superseding previous job $previousJobId with new job $jobId")
            coroutineScope.launch(Dispatchers.IO) {
                ProgressiveJobManager.cancelJob(previousJobId)
            }
        }

        activeCollectorJob?.cancel()
        isCancelling.set(false)
        activeRequestId = reqId
        activeJobId = jobId
        startTimestampMs = System.currentTimeMillis()

        val baseTargetStartupMs = calculateTargetStartupDurationMs(
            sourceDurationMs = request.totalEstimatedDurationMs,
            transcodingSpeed = 0.0f
        )

        _state.value = ProgressiveTranscodeState(
            playbackRequestId = reqId,
            transcodeJobId = jobId,
            status = ProgressiveTranscodeStatus.QUEUED,
            sourceDurationMs = request.totalEstimatedDurationMs,
            targetStartupPlayableDurationMs = baseTargetStartupMs,
            isReadyForPlayback = false,
            stallRisk = StallRisk.UNKNOWN
        )
        Log.i("FALLBACK_TRACE", "[TRANSCODE_CONTROLLER_QUEUED] req=$reqId job=$jobId targetStartup=${baseTargetStartupMs}ms")

        activeCollectorJob = coroutineScope.launch(Dispatchers.IO) {
            executeControllerPipeline(context, request, coroutineScope)
        }

        return state
    }

    private suspend fun executeControllerPipeline(
        context: Context,
        request: ProgressiveGenerationRequest,
        scope: CoroutineScope
    ) = withContext(Dispatchers.IO) {
        val reqId = request.playbackRequestId
        val jobId = request.transcodeJobId

        if (activeRequestId != reqId || activeJobId != jobId) {
            Log.w("FALLBACK_TRACE", "[TRANSCODE_CONTROLLER_STALE] Request $reqId superseded before starting")
            return@withContext
        }

        _state.value = _state.value.copy(status = ProgressiveTranscodeStatus.STARTING)
        Log.i("FALLBACK_TRACE", "[TRANSCODE_CONTROLLER_STARTED] req=$reqId job=$jobId")

        val (progressFlow, eventFlow) = ProgressiveJobManager.getOrStartProgressiveJob(
            context = context,
            request = request,
            scope = scope
        )

        // Launch event listener for structured logging
        scope.launch(Dispatchers.IO) {
            eventFlow.collect { event ->
                if (event.playbackRequestId != activeRequestId || event.transcodeJobId != activeJobId) {
                    Log.d("FALLBACK_TRACE", "[TRANSCODE_CONTROLLER_STALE] Event ${event::class.simpleName} dropped for obsolete req=${event.playbackRequestId}")
                    return@collect
                }
                when (event) {
                    is ProgressiveGenerationEvent.UnitPublished -> {
                        Log.i("FALLBACK_TRACE", "[TRANSCODE_CONTROLLER_PLAYABLE_DURATION] req=$reqId job=$jobId unit=${event.unit.index} totalPlayable=${event.totalPlayableDurationMs}ms")
                        com.example.media.playback.TranscodingLogManager.recordEvent("TRANSCODING_UNIT_PUBLISHED", "unit=${event.unit.index} totalPlayable=${event.totalPlayableDurationMs}ms", reqId)
                    }
                    is ProgressiveGenerationEvent.LogReceived -> {
                        com.example.media.playback.TranscodingLogManager.recordLogReceived(-1L, event.message, reqId)
                    }
                    is ProgressiveGenerationEvent.GenerationCompleted -> {
                        com.example.media.playback.TranscodingLogManager.recordEvent("TRANSCODING_COMPLETED", "req=$reqId units=${event.totalUnits} playable=${event.finalPlayableDurationMs}ms", reqId)
                    }
                    is ProgressiveGenerationEvent.GenerationCancelled -> {
                        com.example.media.playback.TranscodingLogManager.recordEvent("TRANSCODING_CANCELLED", "req=$reqId job=$jobId", reqId)
                    }
                    is ProgressiveGenerationEvent.GenerationFailed -> {
                        Log.e("FALLBACK_TRACE", "[TRANSCODE_CONTROLLER_FAILED] req=$reqId job=$jobId category=${event.category} err=${event.error.message}")
                        com.example.media.playback.TranscodingLogManager.recordEvent("TRANSCODING_FAILED", "req=$reqId category=${event.category} err=${event.error.message}", reqId)
                    }
                    else -> {}
                }
            }
        }

        // Collect progress updates and update authoritative state
        progressFlow.collect { progress ->
            if (progress.playbackRequestId != activeRequestId || progress.transcodeJobId != activeJobId) {
                Log.d("FALLBACK_TRACE", "[TRANSCODE_CONTROLLER_STALE] Progress update dropped for obsolete req=${progress.playbackRequestId}")
                return@collect
            }

            com.example.media.playback.TranscodingLogManager.recordProgressiveProgress(progress, reqId)

            if (isCancelling.get() || _state.value.status == ProgressiveTranscodeStatus.CANCELLED) {
                Log.d("FALLBACK_TRACE", "[TRANSCODE_CONTROLLER_STALE] Ignoring progress update for cancelled job $jobId")
                return@collect
            }

            val elapsedMs = if (startTimestampMs > 0) System.currentTimeMillis() - startTimestampMs else 0L
            val speed = progress.transcodingSpeed
            val sourceDuration = if (progress.sourceDurationMs > 0) progress.sourceDurationMs else request.totalEstimatedDurationMs
            val playableDuration = progress.playableDurationMs
            val unitsCount = progress.publishedUnitsCount

            val targetStartupMs = calculateTargetStartupDurationMs(sourceDuration, speed)
            val isReady = evaluateReadiness(
                status = mapInternalProgressState(progress.state),
                playableDurationMs = playableDuration,
                targetStartupMs = targetStartupMs,
                generatedUnitsCount = unitsCount
            )

            val currentPlaybackPos = _state.value.playbackPositionMs
            val bufferLead = if (currentPlaybackPos != null) maxOf(0L, playableDuration - currentPlaybackPos) else null
            val stallRisk = calculateStallRisk(
                status = mapInternalProgressState(progress.state),
                playableDurationMs = playableDuration,
                playbackPositionMs = currentPlaybackPos,
                transcodingSpeed = speed
            )

            val newStatus = when (progress.state) {
                ProgressiveState.IDLE -> if (_state.value.status == ProgressiveTranscodeStatus.QUEUED || _state.value.status == ProgressiveTranscodeStatus.STARTING) {
                    _state.value.status
                } else {
                    ProgressiveTranscodeStatus.IDLE
                }
                ProgressiveState.INITIALIZING -> ProgressiveTranscodeStatus.STARTING
                ProgressiveState.GENERATING -> {
                    if (isReady) ProgressiveTranscodeStatus.READY_FOR_PLAYBACK else ProgressiveTranscodeStatus.RUNNING
                }
                ProgressiveState.COMPLETED -> ProgressiveTranscodeStatus.COMPLETED
                ProgressiveState.CANCELLED -> ProgressiveTranscodeStatus.CANCELLED
                ProgressiveState.FAILED -> ProgressiveTranscodeStatus.FAILED
            }

            val wasReadyBefore = _state.value.isReadyForPlayback
            if (isReady && !wasReadyBefore) {
                Log.i("FALLBACK_TRACE", "[TRANSCODE_CONTROLLER_READINESS] req=$reqId job=$jobId READY_FOR_PLAYBACK (playable=${playableDuration}ms target=${targetStartupMs}ms units=$unitsCount)")
            }

            if (speed > 0f && speed != _state.value.transcodingSpeed) {
                Log.i("FALLBACK_TRACE", "[TRANSCODE_CONTROLLER_SPEED] req=$reqId job=$jobId speed=${speed}x fps=${progress.fps}")
            }

            if (stallRisk != _state.value.stallRisk) {
                Log.i("FALLBACK_TRACE", "[TRANSCODE_CONTROLLER_STALL_RISK] req=$reqId job=$jobId risk=$stallRisk bufferLead=${bufferLead ?: -1}ms")
            }

            Log.d("FALLBACK_TRACE", "[TRANSCODE_CONTROLLER_PROGRESS] req=$reqId job=$jobId pct=${progress.progressPercentage}% playable=${playableDuration}ms status=$newStatus")

            if (progress.state == ProgressiveState.COMPLETED) {
                Log.i("FALLBACK_TRACE", "[TRANSCODE_CONTROLLER_COMPLETED] req=$reqId job=$jobId finalized totalUnits=$unitsCount totalPlayable=${playableDuration}ms")
            }

            val errorCat = progress.errorCategory ?: if (progress.error != null) {
                mapThrowableToErrorCategory(progress.error)
            } else null

            _state.value = _state.value.copy(
                status = newStatus,
                sourceDurationMs = sourceDuration,
                transcodingProgress = progress.progressPercentage,
                playableDurationMs = playableDuration,
                bufferLeadMs = bufferLead,
                transcodingSpeed = speed,
                fps = progress.fps,
                generatedUnitsCount = unitsCount,
                generatedUnits = progress.publishedUnits,
                targetStartupPlayableDurationMs = targetStartupMs,
                isReadyForPlayback = isReady,
                stallRisk = stallRisk,
                elapsedTimeMs = elapsedMs,
                latestLogLine = progress.latestLogLine,
                playlistFile = progress.playlistFile,
                playlistUri = progress.playlistUri,
                error = progress.error,
                errorCategory = errorCat,
                sessionId = progress.sessionId
            )
        }
    }

    /**
     * Updates current playback position from the playback layer to calculate buffer-lead and stall risk.
     */
    fun updatePlaybackPosition(playbackPositionMs: Long) {
        val currentState = _state.value
        val playable = currentState.playableDurationMs
        val bufferLead = maxOf(0L, playable - playbackPositionMs)
        val risk = calculateStallRisk(
            status = currentState.status,
            playableDurationMs = playable,
            playbackPositionMs = playbackPositionMs,
            transcodingSpeed = currentState.transcodingSpeed
        )

        _state.value = currentState.copy(
            playbackPositionMs = playbackPositionMs,
            bufferLeadMs = bufferLead,
            stallRisk = risk
        )
    }

    /**
     * Authoritative cancellation operation for the active job.
     */
    suspend fun cancelCurrentJob(): Boolean = withContext(Dispatchers.IO) {
        val reqId = activeRequestId
        val jobId = activeJobId ?: return@withContext false

        isCancelling.set(true)
        Log.i("FALLBACK_TRACE", "[TRANSCODE_CONTROLLER_CANCEL] Cancelling active job $jobId (req=$reqId)")

        activeCollectorJob?.cancel()
        activeCollectorJob = null

        val cancelled = ProgressiveJobManager.cancelJob(jobId)

        _state.value = _state.value.copy(
            status = ProgressiveTranscodeStatus.CANCELLED,
            isReadyForPlayback = false,
            stallRisk = StallRisk.UNKNOWN
        )

        activeRequestId = null
        activeJobId = null
        return@withContext cancelled
    }

    /**
     * Cancels a specific job by requestId and transcodeJobId.
     */
    suspend fun cancelJob(playbackRequestId: String, transcodeJobId: String): Boolean = withContext(Dispatchers.IO) {
        if (activeRequestId == playbackRequestId || activeJobId == transcodeJobId) {
            return@withContext cancelCurrentJob()
        } else {
            Log.d("FALLBACK_TRACE", "[TRANSCODE_CONTROLLER_CANCEL] Cancelling inactive/background job $transcodeJobId")
            return@withContext ProgressiveJobManager.cancelJob(transcodeJobId)
        }
    }

    /**
     * Resets controller state to IDLE.
     */
    fun reset() {
        activeCollectorJob?.cancel()
        activeCollectorJob = null
        activeRequestId = null
        activeJobId = null
        isCancelling.set(false)
        startTimestampMs = 0L
        _state.value = ProgressiveTranscodeState()
        Log.i("FALLBACK_TRACE", "[TRANSCODE_CONTROLLER_CREATED] Controller reset to IDLE")
    }

    /**
     * Deterministic adaptive startup duration heuristic:
     * - Fast encoding (speed >= 1.5x): 8s base startup is safe
     * - Moderate encoding (0.9x <= speed < 1.5x): 12s startup
     * - Slow encoding (speed < 0.9x): 16s startup (or up to half source duration)
     * - Short media: capped at source duration
     */
    fun calculateTargetStartupDurationMs(sourceDurationMs: Long, transcodingSpeed: Float): Long {
        if (sourceDurationMs in 1L..DEFAULT_BASE_STARTUP_DURATION_MS) {
            return sourceDurationMs
        }

        val baseTarget = when {
            transcodingSpeed >= 1.5f -> DEFAULT_BASE_STARTUP_DURATION_MS // 8,000ms (fast production)
            transcodingSpeed >= 0.9f -> 12_000L                         // 12,000ms (near realtime)
            transcodingSpeed > 0.0f -> MAX_STARTUP_DURATION_MS           // 16,000ms (slower than realtime)
            else -> DEFAULT_BASE_STARTUP_DURATION_MS                    // Default initial before speed is known
        }

        return if (sourceDurationMs > 0L) {
            minOf(sourceDurationMs, maxOf(MIN_STARTUP_DURATION_MS, baseTarget))
        } else {
            baseTarget
        }
    }

    /**
     * Evaluates whether progressive output is ready for playback.
     */
    fun evaluateReadiness(
        status: ProgressiveTranscodeStatus,
        playableDurationMs: Long,
        targetStartupMs: Long,
        generatedUnitsCount: Int
    ): Boolean {
        if (generatedUnitsCount < 1) return false
        if (status == ProgressiveTranscodeStatus.COMPLETED) return true
        return playableDurationMs >= targetStartupMs
    }

    /**
     * Deterministic predictive stall-risk model based on buffer-lead and transcoding speed.
     */
    fun calculateStallRisk(
        status: ProgressiveTranscodeStatus,
        playableDurationMs: Long,
        playbackPositionMs: Long?,
        transcodingSpeed: Float
    ): StallRisk {
        if (status == ProgressiveTranscodeStatus.COMPLETED) {
            return StallRisk.SAFE
        }
        if (playbackPositionMs == null) {
            return StallRisk.UNKNOWN
        }

        val bufferLeadMs = maxOf(0L, playableDurationMs - playbackPositionMs)

        return when {
            transcodingSpeed in 0.01f..0.99f && bufferLeadMs < 12_000L -> StallRisk.STALL_RISK
            bufferLeadMs < 4_000L -> StallRisk.LOW_BUFFER
            bufferLeadMs >= 12_000L || transcodingSpeed >= 1.2f -> StallRisk.SAFE
            else -> StallRisk.LOW_BUFFER
        }
    }

    private fun mapInternalProgressState(state: ProgressiveState): ProgressiveTranscodeStatus {
        return when (state) {
            ProgressiveState.IDLE -> ProgressiveTranscodeStatus.IDLE
            ProgressiveState.INITIALIZING -> ProgressiveTranscodeStatus.STARTING
            ProgressiveState.GENERATING -> ProgressiveTranscodeStatus.RUNNING
            ProgressiveState.COMPLETED -> ProgressiveTranscodeStatus.COMPLETED
            ProgressiveState.CANCELLED -> ProgressiveTranscodeStatus.CANCELLED
            ProgressiveState.FAILED -> ProgressiveTranscodeStatus.FAILED
        }
    }

    private fun mapThrowableToErrorCategory(error: Throwable): PlaybackErrorCategory {
        val msg = error.message?.lowercase() ?: ""
        return when {
            msg.contains("storage") || msg.contains("space") -> PlaybackErrorCategory.PROGRESSIVE_STORAGE_FAILED
            msg.contains("validate") || msg.contains("invalid") -> PlaybackErrorCategory.PROGRESSIVE_UNIT_INVALID
            msg.contains("cancel") -> PlaybackErrorCategory.FFMPEG_CANCELLED
            msg.contains("encoder") -> PlaybackErrorCategory.FFMPEG_ENCODER_UNAVAILABLE
            msg.contains("uri") || msg.contains("input") -> PlaybackErrorCategory.INPUT_INVALID_URI
            else -> PlaybackErrorCategory.PROGRESSIVE_FFMPEG_FAILED
        }
    }
}
