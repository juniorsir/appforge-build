package com.example.media.progressive

import java.io.File

/**
 * Phase 17.34: Represents an independently valid and published playable media unit.
 *
 * @param index Monotonically increasing 0-based sequence index.
 * @param file The finalized, validated file on disk (never a .tmp file).
 * @param durationMs Validated duration of this specific unit in milliseconds.
 * @param startTimestampMs Media presentation start timestamp in milliseconds.
 * @param endTimestampMs Media presentation end timestamp in milliseconds.
 * @param sizeBytes Size of the unit file in bytes.
 * @param isValidated True if FFprobe inspection confirmed this unit adheres to the 8-bit H.264 contract.
 */
data class ProgressiveMediaUnit(
    val index: Int,
    val file: File,
    val durationMs: Long,
    val startTimestampMs: Long,
    val endTimestampMs: Long,
    val sizeBytes: Long,
    val isValidated: Boolean = true
)
