package com.example.media.progressive

import android.content.Context
import android.net.Uri
import android.util.Log
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import com.example.media.MediaEngine
import com.example.media.playback.PlaybackRequestCoordinator
import com.example.media.playback.PlaybackSource
import com.example.media.playback.PlaybackSourceType
import kotlinx.coroutines.*
import java.io.File
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Phase 17.36: Progressive Media3 Playback Integration Coordinator.
 * Bridges progressive transcoding generation and smart controller to Media3/ExoPlayer.
 */
object ProgressivePlaybackCoordinator {
    private const val TAG = "ProgressivePlaybackCoord"

    private val activePlaybackJobs = ConcurrentHashMap<String, Job>()
    private val activePlayerListeners = ConcurrentHashMap<String, Player.Listener>()
    private val activeOutputDirs = ConcurrentHashMap<String, File>()

    /**
     * Starts progressive transcoding and orchestrates handoff to Media3 when ready.
     */
    fun startProgressivePlayback(
        context: Context,
        mediaEngine: MediaEngine,
        inputUri: Uri,
        requestId: String,
        sourceDurationMs: Long,
        audioUriString: String? = null,
        subtitleUriString: String? = null,
        startPositionMs: Long = 0L,
        scope: CoroutineScope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    ): Job {
        val playerInstanceId = mediaEngine.playerInstanceId
        val activeReqId = PlaybackRequestCoordinator.getActiveRequestId() ?: requestId

        Log.i(
            "FALLBACK_TRACE",
            "[PROGRESSIVE_PLAYBACK_REQUESTED] requestId=$requestId uri=$inputUri duration=${sourceDurationMs}ms playerInstanceId=$playerInstanceId"
        )

        // Phase 17.38: Media Switch Discipline.
        // Immediately cancel and isolate any jobs, listeners, and temporary files from older requests.
        activePlaybackJobs.forEach { (oldReqId, oldJob) ->
            if (oldReqId != requestId) {
                Log.i("FALLBACK_TRACE", "[PROGRESSIVE_MEDIA_SWITCH] Cancelling stale request $oldReqId (active=$requestId)")
                oldJob.cancel()
                val oldListener = activePlayerListeners.remove(oldReqId)
                if (oldListener != null) {
                    try { mediaEngine.player.removeListener(oldListener) } catch (_: Exception) {}
                }
                val oldDir = activeOutputDirs.remove(oldReqId)
                if (oldDir != null && oldDir.exists()) {
                    ProgressiveRecoveryManager.cleanTemporaryFiles(oldDir)
                }
                scope.launch(Dispatchers.IO) {
                    ProgressiveTranscodeController.cancelJob(oldReqId, "P_$oldReqId")
                }
            }
        }
        activePlaybackJobs.keys.retainAll(setOf(requestId))

        // Phase 17.38: Cache Check.
        // If a 100% completed, validated progressive cache already exists for this media, reuse it immediately without FFmpeg.
        val mediaKey = PlaybackRequestCoordinator.getActiveRequest()?.mediaKey ?: inputUri.toString()
        val cachedDir = ProgressiveCacheManager.getCompletedCache(context, mediaKey, sourceDurationMs)
        if (cachedDir != null) {
            Log.i("FALLBACK_TRACE", "[PROGRESSIVE_CACHE_HIT] Reusing validated completed progressive cache for req=$requestId dir=${cachedDir.name}")
            val playlistFile = File(cachedDir, "live_playlist.m3u8").takeIf { it.exists() } ?: File(cachedDir, "master_playlist.m3u8")
            val playlistUri = Uri.fromFile(playlistFile)
            val progressiveSource = PlaybackSource(
                sourceType = PlaybackSourceType.PROGRESSIVE_FALLBACK,
                uri = playlistUri,
                originalUri = inputUri,
                path = playlistFile.absolutePath,
                requestId = requestId,
                container = "hls",
                codec = "h264"
            )
            mediaEngine.preparePlaybackSource(
                source = progressiveSource,
                audioUriString = audioUriString,
                subtitleUriString = subtitleUriString,
                startPositionMs = startPositionMs,
                activeRequestIdProvider = { requestId }
            )
            attachPlayerMonitoring(mediaEngine, requestId, playerInstanceId, scope)
            val completedJob = scope.launch { /* Completed cache playback placeholder */ }
            activePlaybackJobs[requestId] = completedJob
            return completedJob
        }

        // Phase 17.38: Player Recreation & Reconnection Check.
        val currentTranscodeState = ProgressiveTranscodeController.state.value
        val isReconnection = (currentTranscodeState.playbackRequestId == requestId &&
                (currentTranscodeState.status == ProgressiveTranscodeStatus.STARTING ||
                 currentTranscodeState.status == ProgressiveTranscodeStatus.RUNNING ||
                 currentTranscodeState.status == ProgressiveTranscodeStatus.COMPLETED))

        if (isReconnection && activePlaybackJobs.containsKey(requestId)) {
            Log.i(
                "FALLBACK_TRACE",
                "[PROGRESSIVE_LIFECYCLE_RECONNECT] Reconnecting player $playerInstanceId to active request $requestId (pos=${startPositionMs}ms, playable=${currentTranscodeState.playableDurationMs}ms)"
            )
            SmartPlaybackController.reconnectPlayer(playerInstanceId, requestId)
            PlaybackRequestCoordinator.setActivePlayerInstanceId(playerInstanceId)

            if (currentTranscodeState.isReadyForPlayback) {
                val outputDir = activeOutputDirs[requestId] ?: File(context.cacheDir, "progressive_$requestId")
                val playlistFile = currentTranscodeState.playlistFile ?: File(outputDir, "live_playlist.m3u8")
                val playlistUri = currentTranscodeState.playlistUri ?: Uri.fromFile(playlistFile)
                val progressiveSource = PlaybackSource(
                    sourceType = PlaybackSourceType.PROGRESSIVE_FALLBACK,
                    uri = playlistUri,
                    originalUri = inputUri,
                    path = playlistFile.absolutePath,
                    requestId = requestId,
                    container = "hls",
                    codec = "h264"
                )
                mediaEngine.preparePlaybackSource(
                    source = progressiveSource,
                    audioUriString = audioUriString,
                    subtitleUriString = subtitleUriString,
                    startPositionMs = startPositionMs,
                    activeRequestIdProvider = { requestId }
                )
                attachPlayerMonitoring(mediaEngine, requestId, playerInstanceId, scope)
            }
            return activePlaybackJobs[requestId]!!
        }

        // Cancel previous progressive job for this request if any
        activePlaybackJobs[requestId]?.cancel()

        val outputDir = File(context.cacheDir, "progressive_$requestId").apply {
            if (!exists()) mkdirs()
        }
        activeOutputDirs[requestId] = outputDir

        val request = ProgressiveGenerationRequest(
            inputUri = inputUri,
            outputDir = outputDir,
            playbackRequestId = requestId,
            transcodeJobId = "P_$requestId",
            totalEstimatedDurationMs = sourceDurationMs
        )

        val requestStartTimeMs = System.currentTimeMillis()

        val job = scope.launch(Dispatchers.Main) {
            val isSourceAttached = AtomicBoolean(false)
            SmartPlaybackController.startTracking(requestId, playerInstanceId, "P_$requestId", sourceDurationMs)
            val stateFlow = ProgressiveTranscodeController.startTranscoding(context, request, scope)

            stateFlow.collect { state ->
                val currentActiveRequestId = PlaybackRequestCoordinator.getActiveRequestId() ?: requestId
                val accepted = (state.playbackRequestId == currentActiveRequestId)

                PlaybackRequestCoordinator.logMedia3ConcurrencyGuard(
                    requestId = requestId,
                    callbackPlayerId = playerInstanceId,
                    activeRequestId = currentActiveRequestId,
                    activePlayerId = PlaybackRequestCoordinator.getActivePlayerInstanceId() ?: playerInstanceId,
                    operation = "PROGRESSIVE_STATE_UPDATE",
                    accepted = accepted
                )

                if (!accepted) {
                    Log.w(
                        "FALLBACK_TRACE",
                        "[PROGRESSIVE_STALE_CALLBACK] Dropping state update for obsolete req=$requestId (active=$currentActiveRequestId)"
                    )
                    return@collect
                }

                // Update smart playback controller
                SmartPlaybackController.updateTranscodeProgress(
                    playableDurationMs = state.playableDurationMs,
                    productionRate = state.transcodingSpeed,
                    fps = state.fps,
                    generatedUnitsCount = state.generatedUnitsCount,
                    isCompleted = (state.status == ProgressiveTranscodeStatus.COMPLETED),
                    error = state.error,
                    mediaEngine = mediaEngine
                )

                if (!state.isReadyForPlayback) {
                    Log.i(
                        "FALLBACK_TRACE",
                        "[PROGRESSIVE_WAITING_FOR_READY] requestId=$requestId status=${state.status} playable=${state.playableDurationMs}ms targetStartup=${state.targetStartupPlayableDurationMs}ms"
                    )
                } else if (!isSourceAttached.getAndSet(true)) {
                    val latencyMs = System.currentTimeMillis() - requestStartTimeMs
                    Log.i(
                        "FALLBACK_TRACE",
                        "[FIRST_PLAYABLE_LATENCY] requestId=$requestId latency=${latencyMs}ms playableDuration=${state.playableDurationMs}ms totalUnits=${state.generatedUnitsCount}"
                    )
                    com.example.media.playback.TranscodingLogManager.recordEvent(
                        "FIRST_PLAYABLE_LATENCY",
                        "requestId=$requestId latency=${latencyMs}ms playableDuration=${state.playableDurationMs}ms units=${state.generatedUnitsCount}"
                    )
                    Log.i(
                        "FALLBACK_TRACE",
                        "[PROGRESSIVE_READY_FOR_PLAYBACK] requestId=$requestId playableDuration=${state.playableDurationMs}ms totalUnits=${state.generatedUnitsCount}"
                    )

                    val playlistFile = state.playlistFile ?: File(outputDir, "live_playlist.m3u8")
                    val playlistUri = state.playlistUri ?: Uri.fromFile(playlistFile)

                    val progressiveSource = PlaybackSource(
                        sourceType = PlaybackSourceType.PROGRESSIVE_FALLBACK,
                        uri = playlistUri,
                        originalUri = inputUri,
                        path = playlistFile.absolutePath,
                        requestId = requestId,
                        container = "hls",
                        codec = "h264"
                    )

                    Log.i(
                        "FALLBACK_TRACE",
                        "[PROGRESSIVE_SOURCE_ATTACHED] requestId=$requestId uri=$playlistUri playerInstanceId=$playerInstanceId"
                    )

                    val prepared = mediaEngine.preparePlaybackSource(
                        source = progressiveSource,
                        audioUriString = audioUriString,
                        subtitleUriString = subtitleUriString,
                        startPositionMs = startPositionMs,
                        activeRequestIdProvider = { currentActiveRequestId }
                    )

                    if (prepared) {
                        attachPlayerMonitoring(mediaEngine, requestId, playerInstanceId, scope)
                    } else {
                        Log.e(
                            "FALLBACK_TRACE",
                            "[PROGRESSIVE_PLAYBACK_ERROR] requestId=$requestId Failed to prepare player with progressive source"
                        )
                    }
                }

                if (state.status == ProgressiveTranscodeStatus.COMPLETED) {
                    val totalElapsedMs = System.currentTimeMillis() - requestStartTimeMs
                    Log.i(
                        "FALLBACK_TRACE",
                        "[TRANSCODING_PERFORMANCE] requestId=$requestId totalElapsed=${totalElapsedMs}ms units=${state.generatedUnitsCount} playable=${state.playableDurationMs}ms avgSpeed=${String.format(java.util.Locale.US, "%.2f", state.transcodingSpeed)}x fps=${String.format(java.util.Locale.US, "%.1f", state.fps)}"
                    )
                    com.example.media.playback.TranscodingLogManager.recordEvent(
                        "TRANSCODING_PERFORMANCE",
                        "requestId=$requestId totalElapsed=${totalElapsedMs}ms units=${state.generatedUnitsCount} playable=${state.playableDurationMs}ms avgSpeed=${String.format(java.util.Locale.US, "%.2f", state.transcodingSpeed)}x fps=${String.format(java.util.Locale.US, "%.1f", state.fps)}"
                    )
                    Log.i(
                        "FALLBACK_TRACE",
                        "[PROGRESSIVE_COMPLETION] requestId=$requestId totalUnits=${state.generatedUnitsCount} totalPlayable=${state.playableDurationMs}ms"
                    )
                    // Phase 17.38: Register completed progressive stream into cache for instant reuse
                    ProgressiveCacheManager.registerCompletedCache(
                        context = context,
                        requestId = requestId,
                        mediaKey = mediaKey,
                        outputDir = outputDir,
                        expectedDurationMs = sourceDurationMs
                    )
                }

                if (state.status == ProgressiveTranscodeStatus.FAILED) {
                    Log.e(
                        "FALLBACK_TRACE",
                        "[PROGRESSIVE_PLAYBACK_ERROR] requestId=$requestId error=${state.error?.message} category=${state.errorCategory}"
                    )
                }
            }
        }

        activePlaybackJobs[requestId] = job
        return job
    }

    private fun attachPlayerMonitoring(
        mediaEngine: MediaEngine,
        requestId: String,
        playerInstanceId: String,
        scope: CoroutineScope
    ) {
        val player = mediaEngine.player
        var lastPublishedUnits = 0

        val listener = object : Player.Listener {
            override fun onPlaybackParametersChanged(playbackParameters: androidx.media3.common.PlaybackParameters) {
                val activeReq = PlaybackRequestCoordinator.getActiveRequestId() ?: requestId
                val accepted = (requestId == activeReq)
                if (!accepted) return

                SmartPlaybackController.setPlaybackSpeed(playbackParameters.speed, requestId, mediaEngine)
            }

            override fun onIsPlayingChanged(isPlaying: Boolean) {
                val activeReq = PlaybackRequestCoordinator.getActiveRequestId() ?: requestId
                val accepted = (requestId == activeReq)
                if (!accepted) return

                val pos = player.currentPosition
                val bufferedPos = player.bufferedPosition
                val speed = player.playbackParameters.speed

                SmartPlaybackController.updatePlaybackMetrics(
                    playbackPositionMs = pos,
                    internalBufferedPositionMs = bufferedPos,
                    consumptionRate = speed,
                    isPlaying = isPlaying,
                    isBuffering = (player.playbackState == Player.STATE_BUFFERING),
                    mediaEngine = mediaEngine
                )

                if (isPlaying) {
                    Log.i(
                        "FALLBACK_TRACE",
                        "[PROGRESSIVE_PLAYBACK_STARTED] requestId=$requestId playerInstanceId=$playerInstanceId position=${pos}ms"
                    )
                }
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                val activeReq = PlaybackRequestCoordinator.getActiveRequestId() ?: requestId
                val accepted = (requestId == activeReq)
                if (!accepted) return

                val state = ProgressiveTranscodeController.state.value
                val pos = player.currentPosition
                val bufferedPos = player.bufferedPosition
                val speed = player.playbackParameters.speed

                SmartPlaybackController.updatePlaybackMetrics(
                    playbackPositionMs = pos,
                    internalBufferedPositionMs = bufferedPos,
                    consumptionRate = speed,
                    isPlaying = player.isPlaying,
                    isBuffering = (playbackState == Player.STATE_BUFFERING),
                    mediaEngine = mediaEngine
                )

                if (playbackState == Player.STATE_BUFFERING && state.status != ProgressiveTranscodeStatus.COMPLETED) {
                    Log.i(
                        "FALLBACK_TRACE",
                        "[PROGRESSIVE_BUFFERING_WAIT_FOR_TRANSCODE] requestId=$requestId position=${pos}ms playable=${state.playableDurationMs}ms speed=${state.transcodingSpeed}x"
                    )
                }
            }

            override fun onEvents(player: Player, events: Player.Events) {
                val activeReq = PlaybackRequestCoordinator.getActiveRequestId() ?: requestId
                val accepted = (requestId == activeReq)
                if (!accepted) return

                val pos = player.currentPosition
                val bufferedPos = player.bufferedPosition
                val speed = player.playbackParameters.speed

                ProgressiveTranscodeController.updatePlaybackPosition(pos)
                SmartPlaybackController.updatePlaybackMetrics(
                    playbackPositionMs = pos,
                    internalBufferedPositionMs = bufferedPos,
                    consumptionRate = speed,
                    isPlaying = player.isPlaying,
                    isBuffering = (player.playbackState == Player.STATE_BUFFERING),
                    mediaEngine = mediaEngine
                )

                val state = ProgressiveTranscodeController.state.value

                if (state.generatedUnitsCount > lastPublishedUnits) {
                    val newUnits = state.generatedUnitsCount - lastPublishedUnits
                    lastPublishedUnits = state.generatedUnitsCount
                    Log.i(
                        "FALLBACK_TRACE",
                        "[PROGRESSIVE_CONTINUATION] requestId=$requestId newUnitsCount=$newUnits totalUnits=$lastPublishedUnits totalPlayable=${state.playableDurationMs}ms"
                    )
                }

                if (events.contains(Player.EVENT_IS_PLAYING_CHANGED) || events.contains(Player.EVENT_POSITION_DISCONTINUITY)) {
                    Log.i(
                        "FALLBACK_TRACE",
                        "[PROGRESSIVE_BUFFER_LEAD] requestId=$requestId position=${pos}ms playable=${state.playableDurationMs}ms bufferLead=${state.bufferLeadMs}ms stallRisk=${state.stallRisk}"
                    )
                }
            }

            override fun onPlayerError(error: PlaybackException) {
                val activeReq = PlaybackRequestCoordinator.getActiveRequestId() ?: requestId
                val accepted = (requestId == activeReq)
                if (!accepted) return

                Log.e(
                    "FALLBACK_TRACE",
                    "[PROGRESSIVE_PLAYBACK_ERROR] requestId=$requestId code=${error.errorCode} message=${error.message}"
                )
            }
        }

        player.addListener(listener)
        activePlayerListeners[requestId] = listener

        // Periodic buffer lead logger loop
        scope.launch(Dispatchers.Main) {
            while (isActive && activePlaybackJobs.containsKey(requestId)) {
                delay(1000L)
                val activeReq = PlaybackRequestCoordinator.getActiveRequestId() ?: requestId
                if (activeReq != requestId) break

                if (player.isPlaying) {
                    val pos = player.currentPosition
                    ProgressiveTranscodeController.updatePlaybackPosition(pos)
                    val state = ProgressiveTranscodeController.state.value
                    Log.i(
                        "FALLBACK_TRACE",
                        "[PROGRESSIVE_BUFFER_LEAD] requestId=$requestId position=${pos}ms playable=${state.playableDurationMs}ms bufferLead=${state.bufferLeadMs}ms stallRisk=${state.stallRisk}"
                    )
                }
            }
        }
    }

    /**
     * Performs an intelligent seek: seeks immediately if target is playable,
     * or queues the seek until transcoding reaches target without playing into EOF.
     */
    fun seekTo(
        positionMs: Long,
        mediaEngine: MediaEngine,
        requestId: String = PlaybackRequestCoordinator.getActiveRequestId() ?: "active"
    ): SeekRequest {
        return SmartPlaybackController.requestSeek(
            targetPositionMs = positionMs,
            playbackRequestId = requestId,
            mediaEngine = mediaEngine
        )
    }

    /**
     * Sets playback speed and updates smart consumption rate metrics.
     */
    fun setPlaybackSpeed(
        speed: Float,
        mediaEngine: MediaEngine,
        requestId: String = PlaybackRequestCoordinator.getActiveRequestId() ?: "active"
    ) {
        SmartPlaybackController.setPlaybackSpeed(
            speed = speed,
            playbackRequestId = requestId,
            mediaEngine = mediaEngine
        )
    }

    /**
     * User pauses playback: pauses player while preserving background transcode progress.
     */
    fun onUserPause(
        mediaEngine: MediaEngine,
        requestId: String = PlaybackRequestCoordinator.getActiveRequestId() ?: "active"
    ) {
        SmartPlaybackController.onUserPause(requestId, mediaEngine)
    }

    /**
     * User resumes playback.
     */
    fun onUserPlay(
        mediaEngine: MediaEngine,
        requestId: String = PlaybackRequestCoordinator.getActiveRequestId() ?: "active"
    ) {
        SmartPlaybackController.onUserPlay(requestId, mediaEngine)
    }

    /**
     * Returns state flow of smart buffer metrics.
     */
    fun getSmartBufferMetrics() = SmartPlaybackController.metrics

    /**
     * Phase 17.38: Handles application moving to background.
     * Pauses the player while preserving the background transcoding job.
     */
    fun onAppBackgrounded(
        requestId: String = PlaybackRequestCoordinator.getActiveRequestId() ?: "active",
        mediaEngine: MediaEngine? = null
    ) {
        val isTranscoding = (ProgressiveTranscodeController.state.value.status == ProgressiveTranscodeStatus.RUNNING)
        Log.i(
            "FALLBACK_TRACE",
            "[PROGRESSIVE_LIFECYCLE_BACKGROUND] req=$requestId isTranscodingActive=$isTranscoding"
        )
        SmartPlaybackController.onAppBackground(requestId, mediaEngine)
    }

    /**
     * Phase 17.38: Handles application returning to foreground.
     */
    fun onAppForegrounded(
        requestId: String = PlaybackRequestCoordinator.getActiveRequestId() ?: "active",
        mediaEngine: MediaEngine? = null
    ) {
        val state = ProgressiveTranscodeController.state.value
        Log.i(
            "FALLBACK_TRACE",
            "[PROGRESSIVE_LIFECYCLE_FOREGROUND] req=$requestId playableDuration=${state.playableDurationMs}ms lead=${state.bufferLeadMs}ms"
        )
        SmartPlaybackController.onAppForeground(requestId, mediaEngine)
    }

    /**
     * Cancels progressive playback, releases listeners, cancels transcode, and cleans temporary files.
     */
    suspend fun cancelPlayback(
        requestId: String,
        mediaEngine: MediaEngine? = null,
        context: Context? = null
    ) {
        Log.i("FALLBACK_TRACE", "[PROGRESSIVE_CANCEL_REQUEST] requestId=$requestId")
        activePlaybackJobs.remove(requestId)?.cancel()
        val listener = activePlayerListeners.remove(requestId)
        if (listener != null && mediaEngine != null) {
            try {
                mediaEngine.player.removeListener(listener)
            } catch (_: Exception) {}
        }
        val outputDir = activeOutputDirs.remove(requestId)
            ?: (context?.cacheDir?.let { File(it, "progressive_$requestId") })
        if (outputDir != null && outputDir.exists()) {
            ProgressiveRecoveryManager.cleanTemporaryFiles(outputDir)
        }
        ProgressiveTranscodeController.cancelCurrentJob()
        SmartPlaybackController.reset()
    }

    /**
     * Testing helper to bind an output directory for a request ID.
     */
    fun registerOutputDirForTesting(requestId: String, outputDir: File) {
        activeOutputDirs[requestId] = outputDir
    }

    /**
     * Resets coordinator state.
     */
    fun reset() {
        activePlaybackJobs.values.forEach { it.cancel() }
        activePlaybackJobs.clear()
        activePlayerListeners.clear()
        activeOutputDirs.clear()
        ProgressiveTranscodeController.reset()
        SmartPlaybackController.reset()
    }
}
