package com.example.media.progressive

import com.example.media.playback.PlaybackErrorCategory

/**
 * Phase 17.34: Structured events emitted during progressive media generation.
 */
sealed class ProgressiveGenerationEvent {
    abstract val playbackRequestId: String
    abstract val transcodeJobId: String

    data class GenerationRequested(
        override val playbackRequestId: String,
        override val transcodeJobId: String,
        val outputDir: String
    ) : ProgressiveGenerationEvent()

    data class GenerationStarted(
        override val playbackRequestId: String,
        override val transcodeJobId: String,
        val sessionId: Long
    ) : ProgressiveGenerationEvent()

    data class UnitGenerated(
        override val playbackRequestId: String,
        override val transcodeJobId: String,
        val tempFile: String,
        val unitIndex: Int
    ) : ProgressiveGenerationEvent()

    data class UnitPublished(
        override val playbackRequestId: String,
        override val transcodeJobId: String,
        val unit: ProgressiveMediaUnit,
        val totalPlayableDurationMs: Long
    ) : ProgressiveGenerationEvent()

    data class PlayableDurationUpdated(
        override val playbackRequestId: String,
        override val transcodeJobId: String,
        val playableDurationMs: Long
    ) : ProgressiveGenerationEvent()

    data class ProgressUpdated(
        override val playbackRequestId: String,
        override val transcodeJobId: String,
        val progress: ProgressiveGenerationProgress
    ) : ProgressiveGenerationEvent()

    data class LogReceived(
        override val playbackRequestId: String,
        override val transcodeJobId: String,
        val message: String
    ) : ProgressiveGenerationEvent()

    data class GenerationCompleted(
        override val playbackRequestId: String,
        override val transcodeJobId: String,
        val totalUnits: Int,
        val finalPlayableDurationMs: Long
    ) : ProgressiveGenerationEvent()

    data class GenerationCancelled(
        override val playbackRequestId: String,
        override val transcodeJobId: String
    ) : ProgressiveGenerationEvent()

    data class GenerationFailed(
        override val playbackRequestId: String,
        override val transcodeJobId: String,
        val error: Throwable,
        val category: PlaybackErrorCategory
    ) : ProgressiveGenerationEvent()

    data class StaleCallback(
        override val playbackRequestId: String,
        override val transcodeJobId: String,
        val activeRequestId: String,
        val activeJobId: String
    ) : ProgressiveGenerationEvent()
}
