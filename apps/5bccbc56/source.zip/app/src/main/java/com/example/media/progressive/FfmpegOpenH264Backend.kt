package com.example.media.progressive

import android.content.Context
import android.util.Log
import com.example.media.ffmpeg.FFmpegEngine
import com.example.media.ffmpeg.H264EncoderSelector
import com.example.media.storage.MediaUriResolver
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.ConcurrentHashMap
import kotlinx.coroutines.delay

class FfmpegOpenH264Backend : VideoEncoderBackend {
    override val name: String = "libopenh264"
    override val isHardware: Boolean = false

    override suspend fun executeTranscode(
        context: Context,
        request: ProgressiveGenerationRequest,
        outputDir: File,
        argsList: List<String>,
        onProgress: (com.example.media.ffmpeg.FFmpegProgress) -> Unit,
        onComplete: (com.example.media.ffmpeg.FFmpegResult) -> Unit,
        isCancelled: () -> Boolean
    ): Long {
        return FFmpegEngine.executeAsyncWithArguments(
            arguments = argsList.toTypedArray(),
            totalDurationMs = request.totalEstimatedDurationMs,
            onProgress = onProgress,
            onComplete = onComplete
        )
    }
}
