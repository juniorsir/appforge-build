package com.example.media.operations

import android.net.Uri
import java.io.File

data class MediaConversionRequest(
    val inputUri: Uri,
    val outputFile: File,
    val videoCodec: String? = "libopenh264",
    val audioCodec: String? = "aac",
    val container: String? = null,
    val targetWidth: Int? = null,
    val targetHeight: Int? = null,
    val videoBitrateKbps: Int? = 3500,
    val audioBitrateKbps: Int? = 192,
    val frameRate: Float? = null,
    val crf: Int? = null,
    val preset: String? = null,
    val fastStart: Boolean = true
) {
    fun validate(): Result<Unit> {
        val allowedVideoCodecs = setOf("libx264", "h264", "libopenh264", "h264_mediacodec", "libx265", "hevc", "libvpx-vp9", "vp9", "libaom-av1", "av1", "copy", null)
        val allowedAudioCodecs = setOf("aac", "libmp3lame", "mp3", "libopus", "opus", "flac", "pcm_s16le", "copy", "none", null)
        val allowedPresets = setOf("ultrafast", "superfast", "veryfast", "faster", "fast", "medium", "slow", null)
        val allowedContainers = setOf("mp4", "mkv", "matroska", "webm", "mpegts", "ts", null)

        if (videoCodec !in allowedVideoCodecs) {
            return Result.failure(IllegalArgumentException("Unsupported or invalid video codec: $videoCodec"))
        }
        if (audioCodec !in allowedAudioCodecs) {
            return Result.failure(IllegalArgumentException("Unsupported or invalid audio codec: $audioCodec"))
        }
        if (preset !in allowedPresets) {
            return Result.failure(IllegalArgumentException("Invalid preset: $preset"))
        }
        if (container != null && container.lowercase() !in allowedContainers) {
            return Result.failure(IllegalArgumentException("Unsupported or invalid container: $container"))
        }
        if (targetWidth != null && targetWidth <= 0) {
            return Result.failure(IllegalArgumentException("targetWidth must be positive"))
        }
        if (targetHeight != null && targetHeight <= 0) {
            return Result.failure(IllegalArgumentException("targetHeight must be positive"))
        }
        if (crf != null && (crf < 0 || crf > 51)) {
            return Result.failure(IllegalArgumentException("CRF must be between 0 and 51"))
        }
        return Result.success(Unit)
    }
}
