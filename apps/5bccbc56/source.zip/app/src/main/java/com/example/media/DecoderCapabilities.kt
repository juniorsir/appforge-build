package com.example.media

enum class DecoderClassification {
    HARDWARE,
    SOFTWARE,
    EXTENSION,
    UNKNOWN
}

enum class CapabilityStatus {
    COMPATIBLE,
    INCOMPATIBLE,
    UNKNOWN
}

enum class IncompatibilityReason {
    NONE,
    CODEC_UNSUPPORTED,
    AUDIO_UNSUPPORTED,
    BIT_DEPTH_UNSUPPORTED,
    PROFILE_UNSUPPORTED,
    LEVEL_UNSUPPORTED,
    RESOLUTION_UNSUPPORTED,
    FRAME_RATE_UNSUPPORTED,
    DECODER_UNAVAILABLE
}

data class CodecCapabilitiesInfo(
    val name: String,
    val mimeType: String,
    val isEncoder: Boolean,
    val classification: DecoderClassification,
    val maxSupportedWidth: Int = 0,
    val maxSupportedHeight: Int = 0,
    val maxSupportedFrameRate: Int = 0,
    val maxSupportedBitrate: Int = 0,
    val maxSupportedChannels: Int = 0,
    val maxSupportedSampleRate: Int = 0,
    val profiles: List<String> = emptyList()
)

data class CodecSupportStatus(
    val displayName: String,
    val mimeType: String,
    val hardwareAvailable: Boolean,
    val softwareAvailable: Boolean,
    val extensionAvailable: Boolean = false,
    val hardwareDecoders: List<String> = emptyList(),
    val softwareDecoders: List<String> = emptyList(),
    val extensionDecoders: List<String> = emptyList()
)

data class VideoDecoderCapabilityAssessment(
    val trackIndex: Int = 0,
    val codec: String,
    val mimeType: String,
    val requestedProfile: String? = null,
    val requestedLevel: String? = null,
    val requestedBitDepth: Int = 8,
    val requestedPixelFormat: String? = null,
    val requestedWidth: Int = 0,
    val requestedHeight: Int = 0,
    val requestedFrameRate: Float = 0f,
    val deviceDecoderName: String? = null,
    val decoderType: String? = null,
    val profileSupported: Boolean? = null,
    val bitDepthSupported: Boolean? = null,
    val levelSupported: Boolean? = null,
    val resolutionSupported: Boolean? = null,
    val frameRateSupported: Boolean? = null,
    val supportedProfilesList: List<String> = emptyList(),
    val supportedLevelsList: List<String> = emptyList(),
    val maxWidth: Int? = null,
    val maxHeight: Int? = null,
    val maxFrameRate: Int? = null,
    val detailedDiagnosis: String? = null,
    val isSupported: Boolean = false,
    val hasProfileMismatch: Boolean = false,
    val candidateDecoders: List<CodecCapabilitiesInfo> = emptyList(),
    val capabilityStatus: CapabilityStatus = if (isSupported) CapabilityStatus.COMPATIBLE else CapabilityStatus.INCOMPATIBLE,
    val primaryReason: IncompatibilityReason? = null
)

data class AudioDecoderCapabilityAssessment(
    val trackIndex: Int = 0,
    val codec: String,
    val mimeType: String,
    val requestedChannels: Int = 0,
    val requestedSampleRate: Int = 0,
    val deviceDecoderName: String? = null,
    val decoderType: String? = null,
    val isSupported: Boolean = false,
    val channelsSupported: Boolean? = null,
    val sampleRateSupported: Boolean? = null,
    val maxChannels: Int? = null,
    val detailedDiagnosis: String? = null,
    val capabilityStatus: CapabilityStatus = if (isSupported) CapabilityStatus.COMPATIBLE else CapabilityStatus.INCOMPATIBLE,
    val primaryReason: IncompatibilityReason? = null
)

data class AndroidDecoderCapabilityReport(
    val videoAssessments: List<VideoDecoderCapabilityAssessment> = emptyList(),
    val audioAssessments: List<AudioDecoderCapabilityAssessment> = emptyList()
) {
    fun toFormattedReport(): String {
        val sb = StringBuilder()
        sb.appendLine("# ANDROID DECODER CAPABILITY")

        for (v in videoAssessments) {
            sb.appendLine("\nVIDEO")
            val codecName = when (v.codec.lowercase().trim()) {
                "h264", "avc" -> "H.264"
                "hevc", "h265" -> "HEVC"
                "vp9" -> "VP9"
                "vp8" -> "VP8"
                "av1" -> "AV1"
                else -> v.codec.uppercase()
            }
            sb.appendLine("Codec: $codecName")
            sb.appendLine("Decoder: ${v.deviceDecoderName ?: "None"}")
            if (v.decoderType != null) {
                sb.appendLine("Type: ${v.decoderType}")
            }
            if (!v.requestedProfile.isNullOrBlank()) {
                sb.appendLine("Requested Profile: ${v.requestedProfile}")
            }
            if (v.requestedBitDepth > 0) {
                sb.appendLine("Requested Bit Depth: ${v.requestedBitDepth}-bit")
            }
            if (!v.requestedLevel.isNullOrBlank()) {
                sb.appendLine("Requested Level: ${v.requestedLevel}")
            }
            if (v.requestedWidth > 0 && v.requestedHeight > 0) {
                sb.appendLine("Requested Resolution: ${v.requestedWidth}x${v.requestedHeight}")
            }

            if (v.deviceDecoderName != null) {
                if (v.profileSupported != null) {
                    sb.appendLine("Profile Supported: ${if (v.profileSupported) "YES" else "NO"}")
                }
                if (v.bitDepthSupported != null) {
                    sb.appendLine("Bit Depth Supported: ${if (v.bitDepthSupported) "YES" else "NO"}")
                }
                if (v.levelSupported != null) {
                    sb.appendLine("Level Supported: ${if (v.levelSupported) "YES" else "NO"}")
                }
                if (v.resolutionSupported != null && v.requestedWidth > 0 && v.requestedHeight > 0) {
                    sb.appendLine("Resolution Supported: ${if (v.resolutionSupported) "YES" else "NO"}")
                }
                if (v.frameRateSupported != null && v.requestedFrameRate > 0f) {
                    sb.appendLine("Frame Rate Supported: ${if (v.frameRateSupported) "YES" else "NO"}")
                }
                if (v.supportedProfilesList.isNotEmpty()) {
                    sb.appendLine("Decoder Supported Profiles: ${v.supportedProfilesList.joinToString(", ")}")
                }
                if (v.maxWidth != null && v.maxHeight != null && v.maxWidth > 0 && v.maxHeight > 0) {
                    sb.appendLine("Decoder Max Resolution: ${v.maxWidth}x${v.maxHeight}")
                }
                if (!v.detailedDiagnosis.isNullOrBlank()) {
                    sb.appendLine("Diagnostic Note: ${v.detailedDiagnosis}")
                }
            }
            sb.appendLine("Overall Capability: ${if (v.isSupported) "SUPPORTED" else "UNSUPPORTED / EXCEEDS CAPABILITIES"}")
        }

        for (a in audioAssessments) {
            sb.appendLine("\nAUDIO")
            val codecName = when (a.codec.lowercase().trim()) {
                "eac3", "e-ac-3", "eac-3" -> "E-AC-3"
                "ac3", "ac-3" -> "AC-3"
                "truehd", "true-hd" -> "TrueHD"
                else -> a.codec.uppercase()
            }
            sb.appendLine("Codec: $codecName")
            sb.appendLine("Decoder: ${a.deviceDecoderName ?: "None"}")
            if (a.decoderType != null) {
                sb.appendLine("Type: ${a.decoderType}")
            }
            if (a.requestedChannels > 0) {
                sb.appendLine("Requested Channels: ${a.requestedChannels}")
            }
            if (a.channelsSupported != null) {
                sb.appendLine("Channels Supported: ${if (a.channelsSupported) "YES" else "NO"}")
            }
            if (a.sampleRateSupported != null && a.requestedSampleRate > 0) {
                sb.appendLine("Sample Rate Supported: ${if (a.sampleRateSupported) "YES" else "NO"}")
            }
            if (!a.detailedDiagnosis.isNullOrBlank()) {
                sb.appendLine("Diagnostic Note: ${a.detailedDiagnosis}")
            }
            sb.appendLine("Overall Capability: ${if (a.isSupported) "SUPPORTED" else "UNSUPPORTED"}")
        }

        return sb.toString().trimEnd()
    }
}

