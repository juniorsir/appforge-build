package com.example.media.ffmpeg

import android.util.Log
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.FFmpegSession
import com.arthenica.ffmpegkit.Session
import java.util.concurrent.ConcurrentHashMap

object FFmpegSessionManager {
    private const val TAG = "FFmpegSessionManager"
    private val activeSessions = ConcurrentHashMap<Long, Session>()
    private val sessionContexts = ConcurrentHashMap<Long, FFmpegSessionContext>()
    private val activeScopeContext = ThreadLocal<FFmpegSessionContext?>()

    fun <T> withOperationScope(
        operationType: FFmpegOperationType,
        requestId: String? = null,
        jobId: String? = null,
        command: String? = null,
        totalDurationMs: Long = 0L,
        block: () -> T
    ): T {
        val previous = activeScopeContext.get()
        val tempContext = FFmpegSessionContext(
            sessionId = -1L,
            operationType = operationType,
            requestId = requestId,
            jobId = jobId,
            command = command,
            totalDurationMs = totalDurationMs
        )
        activeScopeContext.set(tempContext)
        try {
            return block()
        } finally {
            activeScopeContext.set(previous)
        }
    }

    fun getCurrentScopedContext(): FFmpegSessionContext? {
        return activeScopeContext.get()
    }

    fun registerSession(
        session: Session,
        operationType: FFmpegOperationType = activeScopeContext.get()?.operationType ?: FFmpegOperationType.OTHER,
        requestId: String? = activeScopeContext.get()?.requestId,
        jobId: String? = activeScopeContext.get()?.jobId,
        command: String? = activeScopeContext.get()?.command,
        totalDurationMs: Long = activeScopeContext.get()?.totalDurationMs ?: 0L
    ) {
        val sid = session.sessionId
        activeSessions[sid] = session
        val context = FFmpegSessionContext(
            sessionId = sid,
            operationType = operationType,
            requestId = requestId,
            jobId = jobId,
            command = command,
            totalDurationMs = totalDurationMs
        )
        sessionContexts[sid] = context
        Log.i("FALLBACK_TRACE", "[FFMPEG_SESSION_CLASSIFIED] sessionId=$sid operationType=$operationType requestId=${requestId ?: "none"} jobId=${jobId ?: "none"}")
        Log.d(TAG, "Registered active FFmpeg session #$sid ($operationType)")
    }

    fun registerContext(
        sessionId: Long,
        operationType: FFmpegOperationType,
        requestId: String? = null,
        jobId: String? = null,
        command: String? = null,
        totalDurationMs: Long = 0L
    ) {
        val context = FFmpegSessionContext(
            sessionId = sessionId,
            operationType = operationType,
            requestId = requestId,
            jobId = jobId,
            command = command,
            totalDurationMs = totalDurationMs
        )
        sessionContexts[sessionId] = context
        Log.i("FALLBACK_TRACE", "[FFMPEG_SESSION_CLASSIFIED] sessionId=$sessionId operationType=$operationType requestId=${requestId ?: "none"} jobId=${jobId ?: "none"}")
    }

    fun getSessionContext(sessionId: Long): FFmpegSessionContext? {
        return sessionContexts[sessionId]
    }

    fun unregisterSession(sessionId: Long) {
        activeSessions.remove(sessionId)
        sessionContexts.remove(sessionId)
        Log.d(TAG, "Unregistered FFmpeg session #$sessionId")
    }

    fun getSession(sessionId: Long): Session? {
        return activeSessions[sessionId]
    }

    fun cancel(sessionId: Long): Boolean {
        val session = activeSessions[sessionId]
        return if (session != null) {
            Log.i(TAG, "Cancelling FFmpeg session #$sessionId...")
            FFmpegKit.cancel(sessionId)
            activeSessions.remove(sessionId)
            sessionContexts.remove(sessionId)
            true
        } else {
            Log.w(TAG, "Attempted to cancel unknown/inactive session #$sessionId")
            FFmpegKit.cancel(sessionId)
            false
        }
    }

    fun cancelAll() {
        Log.i(TAG, "Cancelling all active FFmpeg sessions (${activeSessions.size} active)...")
        for ((id, _) in activeSessions) {
            FFmpegKit.cancel(id)
        }
        activeSessions.clear()
        sessionContexts.clear()
    }

    fun getActiveSessionCount(): Int = activeSessions.size
}

