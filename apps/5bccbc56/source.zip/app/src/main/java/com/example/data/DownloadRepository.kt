package com.example.data

import kotlinx.coroutines.flow.Flow

class DownloadRepository(private val downloadDao: DownloadDao) {
    val allDownloads: Flow<List<DownloadEntity>> = downloadDao.getAllDownloads()
    val trashedDownloads: Flow<List<DownloadEntity>> = downloadDao.getTrashedDownloads()

    suspend fun insertDownload(download: DownloadEntity) {
        downloadDao.insertDownload(download)
    }

    suspend fun deleteDownload(download: DownloadEntity) {
        downloadDao.deleteDownload(download)
    }

    suspend fun deleteDownloadById(id: String) {
        downloadDao.deleteDownloadById(id)
    }

    suspend fun getDownloadById(id: String): DownloadEntity? {
        return downloadDao.getDownloadById(id)
    }

    suspend fun getAllDownloadsSync(): List<DownloadEntity> {
        return downloadDao.getAllDownloadsSync()
    }

    suspend fun getTrashedDownloadsSync(): List<DownloadEntity> {
        return downloadDao.getTrashedDownloadsSync()
    }

    suspend fun moveToTrash(id: String, trashedAt: Long, compressedPath: String, originalSize: Long, compressedSize: Long, originalPath: String) {
        downloadDao.moveToTrash(id, trashedAt, compressedPath, originalSize, compressedSize, originalPath)
    }

    suspend fun restoreFromTrash(id: String, restoredPath: String) {
        downloadDao.restoreFromTrash(id, restoredPath)
    }

    suspend fun emptyTrash() {
        downloadDao.emptyTrash()
    }

    suspend fun updateDownloadStatus(id: String, status: String, message: String) {
        downloadDao.updateDownloadStatus(id, status, message)
    }

    suspend fun deleteAllDownloads() {
        downloadDao.deleteAllDownloads()
    }
}
