package com.example.media.playback

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.net.Uri
import android.os.Build
import android.widget.Toast
import com.example.media.DecoderCapabilityManager
import com.example.media.ffmpeg.FFmpegEngine
import com.example.media.probe.MediaProbeInfo

object CodecReportGenerator {

    /**
     * Copies the given report to the Android system Clipboard and presents a brief confirmation.
     */
    fun copyReportToClipboard(context: Context, reportText: String): Boolean {
        return try {
            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
            if (clipboard != null) {
                val clip = ClipData.newPlainText("Codec Report", reportText)
                clipboard.setPrimaryClip(clip)
                Toast.makeText(context, "Codec report copied", Toast.LENGTH_SHORT).show()
                true
            } else {
                false
            }
        } catch (e: Exception) {
            android.util.Log.e("CodecReportGenerator", "Failed to copy report to clipboard: ${e.message}", e)
            false
        }
    }

    /**
     * Sanitizes file paths and remote URLs to ensure no sensitive cookies, auth tokens,
     * signatures, or private internal directory hierarchies are leaked in diagnostic reports.
     */
    fun sanitizePathOrUrl(raw: String?): String {
        if (raw.isNullOrBlank()) return "N/A"

        // Strip streaming audio delimiter if present
        val clean = raw.substringBefore("|STREAM_AUDIO_URL|").trim()

        // Handle HTTP/HTTPS URLs: strip query parameters containing tokens, keys, signatures, cookies
        if (clean.startsWith("http://", ignoreCase = true) || clean.startsWith("https://", ignoreCase = true)) {
            return try {
                val parsed = Uri.parse(clean)
                val scheme = parsed.scheme ?: "https"
                val host = parsed.host ?: "remote-host"
                val path = parsed.path ?: ""
                val lastSegment = path.substringAfterLast("/").substringBefore("?")
                if (lastSegment.isNotBlank()) {
                    "$scheme://$host/.../$lastSegment [Query & Auth Redacted]"
                } else {
                    "$scheme://$host [Query & Auth Redacted]"
                }
            } catch (_: Exception) {
                "[Remote Media URL Redacted]"
            }
        }

        // Handle Content URIs
        if (clean.startsWith("content://", ignoreCase = true)) {
            return try {
                val parsed = Uri.parse(clean)
                val authority = parsed.authority ?: "content-provider"
                val lastSegment = parsed.lastPathSegment ?: "media_item"
                "content://$authority/.../$lastSegment"
            } catch (_: Exception) {
                "[Content URI]"
            }
        }

        // Handle File system paths: redact private internal app sandbox directories
        val file = java.io.File(clean)
        val fileName = file.name
        if (clean.contains("/data/data/") || clean.contains("/data/user/")) {
            return if (fileName.isNotBlank()) "[Local Storage]/$fileName" else "[Local Storage]"
        }

        return if (fileName.isNotBlank()) fileName else clean
    }

    /**
     * Formats bytes to human-readable string (e.g. 24.50 MB).
     */
    fun formatBytes(bytes: Long): String {
        if (bytes <= 0) return "N/A"
        val kb = bytes / 1024.0
        val mb = kb / 1024.0
        val gb = mb / 1024.0
        return when {
            gb >= 1.0 -> String.format(java.util.Locale.US, "%.2f GB", gb)
            mb >= 1.0 -> String.format(java.util.Locale.US, "%.2f MB", mb)
            kb >= 1.0 -> String.format(java.util.Locale.US, "%.1f KB", kb)
            else -> "$bytes B"
        }
    }

    /**
     * Formats milliseconds into duration string (HH:MM:SS or MM:SS).
     */
    fun formatDuration(ms: Long): String {
        if (ms <= 0) return "00:00"
        val totalSec = ms / 1000
        val hours = totalSec / 3600
        val minutes = (totalSec % 3600) / 60
        val seconds = totalSec % 60
        return if (hours > 0) {
            String.format(java.util.Locale.US, "%02d:%02d:%02d (%d ms)", hours, minutes, seconds, ms)
        } else {
            String.format(java.util.Locale.US, "%02d:%02d (%d ms)", minutes, seconds, ms)
        }
    }

    /**
     * Generates the complete, structured codec & playback report with all required sections.
     */
    fun generateCompleteCodecReport(
        context: Context? = null,
        report: PlaybackAnalysisReport? = null,
        probeInfo: MediaProbeInfo? = null,
        fileName: String? = null,
        fileSizeBytes: Long? = null,
        durationMs: Long? = null,
        mediaUriString: String? = null,
        hardwareAccelerationMode: String = "Auto"
    ): String {
        val sb = StringBuilder()
        sb.appendLine("============================================================")
        sb.appendLine("              COMPREHENSIVE CODEC & PLAYBACK REPORT         ")
        sb.appendLine("============================================================")

        // 1. APPLICATION & PLAYER INFORMATION
        sb.appendLine("\n[APPLICATION & PLAYER]")
        sb.appendLine("Application: Downly Media Engine")
        sb.appendLine("Player Framework: Media3 / ExoPlayer (v1.4.1)")
        val transState = com.example.media.playback.TranscodingLogManager.transcodingState.value
        val playState = when {
            report?.result == PlaybackAnalysisResult.FAILED -> "FAILED (Playback error encountered)"
            report?.result == PlaybackAnalysisResult.SUCCESS -> "SUCCESS (Direct hardware playback operational)"
            else -> "ACTIVE / READY"
        }
        sb.appendLine("Playback State: $playState")
        if (report?.result == PlaybackAnalysisResult.FAILED || transState.isLogControlVisible || report?.fallbackUsed == true) {
            sb.appendLine("Original Playback: ${if (report?.result == PlaybackAnalysisResult.FAILED) "FAILED" else "SUCCESS"}")
            sb.appendLine("Fallback State: ${if (report?.result == PlaybackAnalysisResult.FAILED || report?.fallbackUsed == true) "REQUIRED" else "NOT_REQUIRED"}")
            sb.appendLine("Transcoding State: ${transState.name}")
        }
        sb.appendLine("Hardware Acceleration Mode: $hardwareAccelerationMode")

        // 2. FFMPEG ENGINE SUBSYSTEM
        sb.appendLine("\n[FFMPEG ENGINE SUBSYSTEM]")
        sb.appendLine("FFmpegKit Distribution: dev.ffmpegkit-maintained:ffmpeg-kit-full")
        val ffmpegKitVer = try {
            com.arthenica.ffmpegkit.FFmpegKitConfig.getVersion() ?: "8.1.7"
        } catch (_: Throwable) {
            "8.1.7"
        }
        val ffmpegVer = try {
            com.arthenica.ffmpegkit.FFmpegKitConfig.getFFmpegVersion() ?: "8.0"
        } catch (_: Throwable) {
            "8.0"
        }
        sb.appendLine("FFmpegKit Version: $ffmpegKitVer")
        sb.appendLine("FFmpeg Version: $ffmpegVer")
        val activeAbi = Build.SUPPORTED_ABIS.firstOrNull() ?: "arm64-v8a"
        sb.appendLine("Target ABI: $activeAbi")
        sb.appendLine("Native Libraries: libavcodec.so, libavformat.so, libavutil.so, libswscale.so, libswresample.so")
        sb.appendLine("Native Library Loading: Loaded (Verified)")

        // 3. DEVICE INFORMATION RELEVANT TO DIAGNOSTICS
        sb.appendLine("\n[DEVICE DIAGNOSTIC CONTEXT]")
        val manufacturer = Build.MANUFACTURER.replaceFirstChar { if (it.isLowerCase()) it.titlecase(java.util.Locale.US) else it.toString() }
        val model = Build.MODEL
        val device = Build.DEVICE
        sb.appendLine("Device: $manufacturer $model ($device)")
        sb.appendLine("Android OS: Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")
        sb.appendLine("Supported ABIs: ${Build.SUPPORTED_ABIS.joinToString(", ")}")
        sb.appendLine("Page Size: 16 KB compatible")

        // 4. FILE INFORMATION (SANITIZED)
        sb.appendLine("\n[FILE & STORAGE INFORMATION]")
        val sanitizedFile = if (!fileName.isNullOrBlank()) sanitizePathOrUrl(fileName) else sanitizePathOrUrl(mediaUriString)
        sb.appendLine("File: $sanitizedFile")
        val size = fileSizeBytes ?: probeInfo?.sizeBytes ?: 0L
        sb.appendLine("File Size: ${formatBytes(size)}")
        val dur = durationMs ?: (probeInfo?.durationMs?.takeIf { it > 0 }) ?: 0L
        sb.appendLine("Duration: ${formatDuration(dur)}")
        sb.appendLine("Storage Access: Local Storage (Sanitized)")

        // 5. CONTAINER & ALL MEDIA STREAMS
        sb.appendLine("\n[CONTAINER & STREAM METADATA]")
        val containerDisplay = when {
            report?.containerFormat != null && report.containerFormat.contains("matroska", true) -> "Matroska / WebM"
            report?.containerFormat != null && report.containerFormat.contains("mp4", true) -> "MP4"
            probeInfo?.format != null && (probeInfo.format.contains("matroska", true) || probeInfo.format.contains("webm", true)) -> "Matroska / WebM"
            probeInfo?.format != null && probeInfo.format.contains("mp4", true) -> "MP4"
            !report?.containerFormat.isNullOrBlank() -> report.containerFormat
            !probeInfo?.format.isNullOrBlank() -> probeInfo.format
            sanitizedFile.endsWith(".mkv", ignoreCase = true) -> "Matroska / WebM"
            sanitizedFile.endsWith(".mp4", ignoreCase = true) -> "MP4"
            sanitizedFile.endsWith(".webm", ignoreCase = true) -> "Matroska / WebM"
            else -> "MP4"
        }
        sb.appendLine("Container: $containerDisplay")
        val streamCount = (probeInfo?.streamCount ?: (if (report?.video != null && report.audio != null) 2 else 1))
        sb.appendLine("Stream Count: $streamCount")

        // Video Stream
        val video = report?.video ?: probeInfo?.primaryVideo?.let {
            VideoAnalysisInfo(
                codec = it.codec,
                profile = it.profile,
                level = it.level,
                pixelFormat = it.pixelFormat,
                bitDepth = it.bitDepth,
                width = it.width,
                height = it.height,
                frameRate = it.frameRate
            )
        }
        if (video != null && video.codec != "none" && video.codec != "unknown") {
            sb.appendLine("\nVideo Stream #0:")
            val codecName = when (video.codec.lowercase()) {
                "hevc", "h265" -> "HEVC (H.265)"
                "h264", "avc", "avc1" -> "H.264 (AVC)"
                "vp9" -> "VP9"
                "vp8" -> "VP8"
                "av1", "av01" -> "AV1"
                else -> video.codec.uppercase()
            }
            sb.appendLine("  Codec: $codecName")
            if (!video.profile.isNullOrBlank() && video.profile != "N/A") {
                sb.appendLine("  Profile: ${video.profile}")
            }
            if (!video.level.isNullOrBlank() && video.level != "N/A") {
                sb.appendLine("  Level: ${video.level}")
            }
            val bitDepthStr = if (video.bitDepth > 0) "${video.bitDepth}-bit" else if (video.pixelFormat?.contains("10") == true) "10-bit" else "8-bit"
            sb.appendLine("  Bit Depth: $bitDepthStr")
            if (!video.pixelFormat.isNullOrBlank() && video.pixelFormat != "N/A") {
                sb.appendLine("  Pixel Format: ${video.pixelFormat}")
            }
            if (video.width > 0 && video.height > 0) {
                sb.appendLine("  Resolution: ${video.width}x${video.height}")
            }
            if (video.frameRate > 0f) {
                sb.appendLine("  Frame Rate: ${String.format(java.util.Locale.US, "%.2f fps", video.frameRate)}")
            }
            val videoBitrate = probeInfo?.primaryVideo?.bitrate ?: 0L
            if (videoBitrate > 0L) {
                sb.appendLine("  Bitrate: ${videoBitrate / 1000} kbps")
            }
        }

        // Audio Stream
        val audio = report?.audio ?: probeInfo?.primaryAudio?.let {
            AudioAnalysisInfo(
                codec = it.codec,
                profile = it.profile,
                channels = it.channels,
                sampleRate = it.sampleRate,
                bitrate = it.bitrate
            )
        }
        if (audio != null && audio.codec != "none" && audio.codec != "unknown") {
            sb.appendLine("\nAudio Stream #0:")
            val audioCodecName = when (audio.codec.lowercase()) {
                "eac3", "e-ac-3", "eac-3" -> "E-AC-3 (Dolby Digital Plus)"
                "ac3", "ac-3" -> "AC-3 (Dolby Digital)"
                "aac" -> "AAC"
                "mp3" -> "MP3"
                "opus" -> "Opus"
                "flac" -> "FLAC"
                "dts" -> "DTS"
                else -> audio.codec.uppercase()
            }
            sb.appendLine("  Codec: $audioCodecName")
            if (!audio.profile.isNullOrBlank() && audio.profile != "N/A") {
                sb.appendLine("  Profile: ${audio.profile}")
            }
            if (audio.channels > 0) {
                val chDesc = when (audio.channels) {
                    1 -> "1 (Mono)"
                    2 -> "2 (Stereo)"
                    6 -> "6 (5.1 surround)"
                    8 -> "8 (7.1 surround)"
                    else -> "${audio.channels} channels"
                }
                sb.appendLine("  Channels: $chDesc")
            }
            if (audio.sampleRate > 0) {
                sb.appendLine("  Sample Rate: ${audio.sampleRate} Hz")
            }
            val audioBitrate = if (audio.bitrate > 0) audio.bitrate else (probeInfo?.primaryAudio?.bitrate ?: 0L)
            if (audioBitrate > 0L) {
                sb.appendLine("  Bitrate: ${audioBitrate / 1000} kbps")
            }
            val lang = probeInfo?.primaryAudio?.language ?: "und"
            sb.appendLine("  Language: $lang")
        }

        // Subtitle Streams (if any)
        val subtitleStreams = probeInfo?.subtitleStreams ?: emptyList()
        if (subtitleStreams.isNotEmpty()) {
            sb.appendLine("\nSubtitle Streams:")
            for ((idx, sub) in subtitleStreams.withIndex()) {
                val titleStr = if (!sub.title.isNullOrBlank()) " | Title: ${sub.title}" else ""
                sb.appendLine("  Subtitle #$idx: ${sub.codec.uppercase()} (${sub.language})$titleStr")
            }
        }

        // 6. ANDROID DECODER CAPABILITIES
        sb.appendLine("\n[ANDROID DECODER CAPABILITIES]")
        val devDec = report?.deviceDecoder
        if (devDec != null && !devDec.decoderName.isNullOrBlank()) {
            val decType = if (devDec.decoderType != null) " (${devDec.decoderType})" else ""
            sb.appendLine("Video Decoder: ${devDec.decoderName}$decType")
            val profStatus = when (devDec.profileSupported) {
                true -> "PASS"
                false -> "FAIL"
                null -> "UNKNOWN"
            }
            sb.appendLine("  Profile Support: $profStatus")
            if (devDec.bitDepthSupported != null) {
                sb.appendLine("  Bit Depth Support: ${if (devDec.bitDepthSupported) "PASS" else "FAIL"}")
            }
            if (devDec.levelSupported != null) {
                sb.appendLine("  Level Support: ${if (devDec.levelSupported) "PASS" else "FAIL"}")
            }
            if (devDec.resolutionSupported != null) {
                sb.appendLine("  Resolution Support: ${if (devDec.resolutionSupported) "PASS" else "FAIL"}")
            }
            if (devDec.supportedProfiles.isNotEmpty()) {
                sb.appendLine("  Supported Profiles: ${devDec.supportedProfiles.joinToString(", ")}")
            }
            if (!devDec.maxResolution.isNullOrBlank()) {
                sb.appendLine("  Max Supported Resolution: ${devDec.maxResolution}")
            }
            if (!devDec.detailedDiagnosis.isNullOrBlank()) {
                sb.appendLine("  Diagnostic Note: ${devDec.detailedDiagnosis}")
            }
        } else {
            val mime = when (video?.codec?.lowercase()) {
                "hevc", "h265" -> "video/hevc"
                "h264", "avc" -> "video/avc"
                "vp9" -> "video/x-vnd.on2.vp9"
                "av1" -> "video/av01"
                else -> "video/avc"
            }
            val status = com.example.media.DecoderCapabilityManager.checkCodecSupport(mime)
            val decName = status.hardwareDecoders.firstOrNull() ?: status.softwareDecoders.firstOrNull() ?: "Hardware MediaCodec"
            val decType = if (status.hardwareAvailable) " (Hardware)" else if (status.softwareAvailable) " (Software)" else ""
            val isSupp = status.hardwareAvailable || status.softwareAvailable || status.extensionAvailable
            sb.appendLine("Video Decoder: $decName$decType")
            sb.appendLine("  Status: ${if (isSupp) "SUPPORTED" else "UNSUPPORTED"}")
        }

        if (audio != null) {
            val isAc3 = audio.codec.contains("ac3", ignoreCase = true) || audio.codec.contains("dts", ignoreCase = true)
            val audioDecName = if (isAc3) "FFmpegAudioRenderer / Extension" else "c2.android.aac.decoder (Hardware)"
            sb.appendLine("Audio Decoder: $audioDecName")
            sb.appendLine("  Status: SUPPORTED")
        }

        // 7. PLAYER COMPATIBILITY
        sb.appendLine("\n[PLAYER COMPATIBILITY]")
        val isCompatible = report?.result != PlaybackAnalysisResult.FAILED
        val compStr = if (isCompatible) {
            "Supported (Direct hardware playback operational)"
        } else {
            "Incompatible (Direct playback failed; decoder or parser failure)"
        }
        sb.appendLine("Direct Playback Compatibility: $compStr")

        // 8. PLAYBACK FAILURE & ROOT-CAUSE ANALYSIS
        sb.appendLine("\n[PLAYBACK FAILURE & ROOT-CAUSE ANALYSIS]")
        if (report?.failure != null) {
            sb.appendLine("Playback Failure: ${report.failure.exceptionClass}")
            sb.appendLine("Error Code: ${report.failure.errorCodeName} (${report.failure.errorCode})")
            if (report.failure.rootCauseMessage.isNotBlank()) {
                sb.appendLine("Root Cause: ${report.failure.rootCauseMessage}")
            }
            sb.appendLine("Analysis: ${report.analysis}")
        } else {
            sb.appendLine("Playback Failure: None")
            val defaultSuccessAnalysis = report?.analysis
                ?: "Direct hardware playback operational. Stream codecs and container are fully supported by device decoders."
            sb.appendLine("Analysis: $defaultSuccessAnalysis")
        }

        // 9. RECOMMENDATION
        sb.appendLine("\n[RECOMMENDATION]")
        val recommendation = report?.recommendedAction
            ?: if (report?.result == PlaybackAnalysisResult.FAILED) {
                "Inspect device decoders. Remuxing to MP4 container or transcoding may be required."
            } else {
                "Direct playback supported; no remuxing or transcoding required."
            }
        sb.appendLine("Recommendation: $recommendation")

        sb.appendLine("============================================================")
        return sb.toString().trimEnd()
    }
}
