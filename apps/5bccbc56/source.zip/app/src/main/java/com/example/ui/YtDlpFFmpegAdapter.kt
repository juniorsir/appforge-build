package com.example.ui

import android.util.Log
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import com.yausername.youtubedl_android.YoutubeDLResponse
import com.example.media.ffmpeg.FFmpegEngine
import java.io.File
import kotlinx.coroutines.runBlocking

/**
 * Adapter to bridge yt-dlp with the application's FFmpegKit 8.1.7 engine.
 *
 * LIMITATION DOCUMENTATION:
 * The existing yt-dlp Android implementation executes as a standalone Python process
 * which strictly requires an external standalone executable binary for FFmpeg operations (e.g. merging, extraction).
 * FFmpegKit 8.1.7 is a JNI shared library (`libffmpegkit.so`), NOT a standalone executable.
 * Therefore, yt-dlp cannot directly consume FFmpegKit from within its Python process.
 *
 * BRIDGE IMPLEMENTATION:
 * Instead of pretending the AAR is an executable or breaking yt-dlp, this adapter
 * instructs yt-dlp to preserve the raw video and audio streams (using --keep-video).
 * If yt-dlp's own FFmpeg binary fails to merge the streams (e.g. due to Android 15 16KB page size
 * incompatibilities or missing codecs), this adapter catches the failure, locates the downloaded
 * raw stream files, and securely executes the merge/post-processing using our native FFmpegKit engine.
 */
object YtDlpFFmpegAdapter {
    private const val TAG = "YtDlpFFmpegAdapter"

    fun executeWithFallback(
        request: YoutubeDLRequest,
        processId: String? = null,
        onProgress: (progress: Float, etaInSeconds: Long, line: String) -> Unit
    ): YoutubeDLResponse {
        // Enforce keeping raw files so we can salvage them if yt-dlp's internal ffmpeg fails
        request.addOption("--keep-video")

        return try {
            val response = YoutubeDL.getInstance().execute(request, processId) { progress, eta, line ->
                onProgress(progress, eta, line)
            }
            // After successful execution/merging, clean up separate raw audio/video files
            cleanupIntermediateStreams(request)
            response
        } catch (e: Exception) {
            val errorMsg = e.localizedMessage ?: ""
            Log.w(TAG, "yt-dlp execution failed: $errorMsg")

            if (errorMsg.contains("ffmpeg", ignoreCase = true) || errorMsg.contains("Postprocessing", ignoreCase = true) || errorMsg.contains("returned non-zero exit status", ignoreCase = true)) {
                Log.w(TAG, "yt-dlp failed during FFmpeg post-processing. Salvaging raw files using FFmpegKit 8.1.7...")
                
                val commandList = getCommandList(request)
                
                // Extract expected output file path from the request options if available
                val outputOption = getOptionValue(commandList, "-o") ?: getOptionValue(commandList, "--output")
                if (outputOption != null) {
                    val outputFile = File(outputOption)
                    val dir = outputFile.parentFile
                    val baseName = outputFile.nameWithoutExtension
                    
                    if (dir != null && dir.exists()) {
                        // Find the raw video and audio files left behind
                        val candidates = dir.listFiles { _, name -> name.startsWith(baseName) && name != outputFile.name }?.toList() ?: emptyList()
                        
                        val videoFile = candidates.firstOrNull { it.name.endsWith(".mp4") || it.name.endsWith(".webm") || it.name.endsWith(".mkv") && !it.name.contains("audio", ignoreCase = true) }
                        val audioFile = candidates.firstOrNull { it.name.endsWith(".m4a") || it.name.endsWith(".webm") || it.name.endsWith(".mp3") || it.name.endsWith(".ogg") }
                        
                        if (videoFile != null && audioFile != null) {
                            Log.i(TAG, "Found salvageable raw streams: Video=${videoFile.name}, Audio=${audioFile.name}")
                            
                            val ext = outputFile.extension.ifBlank { "mkv" }
                            val finalFile = File(dir, "$baseName.$ext")
                            
                            val mergeArgs = arrayOf(
                                "-y",
                                "-i", videoFile.absolutePath,
                                "-i", audioFile.absolutePath,
                                "-c", "copy",
                                finalFile.absolutePath
                            )
                            
                            runBlocking {
                                val result = FFmpegEngine.executeWithArguments(mergeArgs)
                                if (result.isSuccess) {
                                    Log.i(TAG, "FFmpegKit salvaged the merge successfully!")
                                    // Clean up the raw files
                                    try { videoFile.delete() } catch (_: Throwable) {}
                                    try { audioFile.delete() } catch (_: Throwable) {}
                                    cleanupIntermediateFiles(finalFile)
                                } else {
                                    Log.e(TAG, "FFmpegKit salvage merge failed: ${result.output}")
                                    throw Exception("Native merge salvage failed: ${result.output}", e)
                                }
                            }
                            return YoutubeDLResponse(commandList, 0, 0, "Native salvage successful", "")
                        } else if (videoFile != null) {
                             Log.i(TAG, "Only video file found: ${videoFile.name}. Renaming to target.")
                             videoFile.renameTo(outputFile)
                             cleanupIntermediateFiles(outputFile)
                             return YoutubeDLResponse(commandList, 0, 0, "Native salvage successful (single stream)", "")
                        } else if (audioFile != null) {
                             Log.i(TAG, "Only audio file found: ${audioFile.name}. Renaming to target.")
                             audioFile.renameTo(outputFile)
                             cleanupIntermediateFiles(outputFile)
                             return YoutubeDLResponse(commandList, 0, 0, "Native salvage successful (single stream)", "")
                        } else {
                             Log.e(TAG, "Could not find raw files to salvage in ${dir.absolutePath}")
                        }
                    }
                }
            }
            throw e
        }
    }

    fun cleanupIntermediateStreams(request: YoutubeDLRequest) {
        try {
            val commandList = getCommandList(request)
            val outputOption = getOptionValue(commandList, "-o") ?: getOptionValue(commandList, "--output") ?: return
            val outputFile = File(outputOption)
            cleanupIntermediateFiles(outputFile)
        } catch (e: Exception) {
            Log.w(TAG, "cleanupIntermediateStreams error: ${e.message}")
        }
    }

    fun cleanupIntermediateFiles(outputFile: File) {
        try {
            val dir = outputFile.parentFile ?: return
            if (!dir.exists()) return
            val baseName = outputFile.nameWithoutExtension
            val finalExt = outputFile.extension

            // Delete separate raw audio/video files that were downloaded before merging:
            // e.g. <baseName>.f137.mp4, <baseName>.f140.m4a, <baseName>.f251.webm,
            // <baseName>.temp.mp4, <baseName>.part, <baseName>.ytdl,
            // or if output is .mkv and there's a separate <baseName>.mp4 or <baseName>.webm or <baseName>.m4a
            val candidates = dir.listFiles { file ->
                if (file.isDirectory) return@listFiles false
                val name = file.name
                if (file.absolutePath == outputFile.absolutePath) return@listFiles false
                if (!name.startsWith(baseName)) return@listFiles false

                val isFormatSpecific = name.matches(Regex("""^""" + Regex.escape(baseName) + """\.(f\d+|[a-zA-Z0-9_\-]+)\.(mp4|m4a|webm|mkv|mp3|ogg|opus|aac|flac|wav|part|ytdl)$""", RegexOption.IGNORE_CASE))
                val isPartOrTemp = name.endsWith(".part", ignoreCase = true) ||
                                   name.endsWith(".ytdl", ignoreCase = true) ||
                                   name.contains(".temp.", ignoreCase = true)
                val isIntermediateTrack = (name == "$baseName.mp4" && finalExt.equals("mkv", ignoreCase = true)) ||
                                          (name == "$baseName.webm" && finalExt.equals("mkv", ignoreCase = true)) ||
                                          (name == "$baseName.m4a" && (finalExt.equals("mkv", ignoreCase = true) || finalExt.equals("mp4", ignoreCase = true))) ||
                                          (name == "$baseName.opus" && (finalExt.equals("mkv", ignoreCase = true) || finalExt.equals("mp4", ignoreCase = true)))

                isFormatSpecific || isPartOrTemp || isIntermediateTrack
            }

            candidates?.forEach { file ->
                try {
                    Log.i(TAG, "Cleaning up separate intermediate stream file: ${file.name}")
                    file.delete()
                } catch (delEx: Exception) {
                    Log.w(TAG, "Failed to delete intermediate file: ${file.name}", delEx)
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Error cleaning up intermediate files: ${e.message}")
        }
    }

    private fun getCommandList(request: YoutubeDLRequest): List<String> {
        return try {
            val buildCommandMethod = YoutubeDLRequest::class.java.getDeclaredMethod("buildCommand")
            buildCommandMethod.isAccessible = true
            buildCommandMethod.invoke(request) as? List<String> ?: emptyList()
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun getOptionValue(commandList: List<String>, optionName: String): String? {
        val index = commandList.indexOf(optionName)
        if (index != -1 && index + 1 < commandList.size) {
            return commandList[index + 1]
        }
        return null
    }
}
