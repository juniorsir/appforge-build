package com.example.media.ffmpeg

/**
 * Phase 17.36: Formal classification of FFmpeg operations to distinguish probe/enumeration
 * sessions from active media transcoding sessions.
 */
enum class FFmpegOperationType {
    ENCODER_PROBE,
    CAPABILITY_PROBE,
    FFMPEG_COMMAND_PROBE,
    ACTUAL_TRANSCODING,
    VALIDATION,
    OTHER
}

/**
 * Metadata snapshot for an FFmpeg session.
 */
data class FFmpegSessionContext(
    val sessionId: Long,
    val operationType: FFmpegOperationType,
    val requestId: String? = null,
    val jobId: String? = null,
    val command: String? = null,
    val totalDurationMs: Long = 0L,
    val isTranscoding: Boolean = (operationType == FFmpegOperationType.ACTUAL_TRANSCODING)
)
