package com.example.media.progressive

import com.example.media.playback.PlaybackErrorCategory

/**
 * Phase 17.35: Authoritative status enum for smart background progressive transcoding.
 */
enum class ProgressiveTranscodeStatus {
    IDLE,
    QUEUED,
    STARTING,
    RUNNING,
    READY_FOR_PLAYBACK,
    COMPLETING,
    COMPLETED,
    FAILED,
    CANCELLED,
    STALE
}

/**
 * Phase 17.35: Predictive stall risk status.
 */
enum class StallRisk {
    SAFE,
    LOW_BUFFER,
    STALL_RISK,
    UNKNOWN
}

/**
 * Phase 17.35: Immutable authoritative snapshot representing background progressive transcoding state.
 */
data class ProgressiveTranscodeState(
    val playbackRequestId: String? = null,
    val transcodeJobId: String? = null,
    val status: ProgressiveTranscodeStatus = ProgressiveTranscodeStatus.IDLE,
    val sourceDurationMs: Long = 0L,
    val transcodedDurationMs: Long = 0L,
    val transcodingProgress: Float = 0.0f,
    val playableDurationMs: Long = 0L,
    val playbackPositionMs: Long? = null,
    val bufferLeadMs: Long? = null,
    val transcodingSpeed: Float = 0.0f,
    val fps: Double = 0.0,
    val generatedUnitsCount: Int = 0,
    val generatedUnits: List<ProgressiveMediaUnit> = emptyList(),
    val playlistFile: java.io.File? = null,
    val playlistUri: android.net.Uri? = null,
    val targetStartupPlayableDurationMs: Long = 8_000L,
    val isReadyForPlayback: Boolean = false,
    val stallRisk: StallRisk = StallRisk.UNKNOWN,
    val elapsedTimeMs: Long = 0L,
    val estimatedRemainingTimeMs: Long? = null,
    val latestLogLine: String? = null,
    val error: Throwable? = null,
    val errorCategory: PlaybackErrorCategory? = null,
    val sessionId: Long = -1L
)
