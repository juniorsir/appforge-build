import sys
file_path = "/app/applet/app/src/main/java/com/example/media/MediaEngine.kt"
with open(file_path, "r") as f:
    content = f.read()

target1 = "fun preparePlaybackSource(source: com.example.media.playback.PlaybackSource, audioUriString: String? = null, subtitleUriString: String? = null, startPositionMs: Long = 0L, activeRequestIdProvider: () -> String)"
replace1 = "fun preparePlaybackSource(source: com.example.media.playback.PlaybackSource, audioUriString: String? = null, subtitleUriString: String? = null, startPositionMs: Long = 0L, activeRequestIdProvider: () -> String): Boolean"
content = content.replace(target1, replace1)

target2 = "override fun preparePlaybackSource(source: com.example.media.playback.PlaybackSource, audioUriString: String?, subtitleUriString: String?, startPositionMs: Long, activeRequestIdProvider: () -> String) {"
replace2 = "override fun preparePlaybackSource(source: com.example.media.playback.PlaybackSource, audioUriString: String?, subtitleUriString: String?, startPositionMs: Long, activeRequestIdProvider: () -> String): Boolean {"
content = content.replace(target2, replace2)

target3 = "exoPlayer.playWhenReady = true\n    }"
replace3 = "exoPlayer.playWhenReady = true\n        return true\n    }"
content = content.replace(target3, replace3)

with open(file_path, "w") as f:
    f.write(content)
