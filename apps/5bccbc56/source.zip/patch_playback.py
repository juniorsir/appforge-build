import sys

file_path = "/app/applet/app/src/main/java/com/example/media/playback/PlaybackAnalysisReport.kt"

with open(file_path, "r") as f:
    content = f.read()

target = """data class PlaybackAnalysisReport(
    val result: PlaybackAnalysisResult,
    val player: String = "Media3 / ExoPlayer",
    val failure: PlaybackFailureDetails? = null,
    val containerFormat: String? = null,
    val video: VideoAnalysisInfo? = null,
    val audio: AudioAnalysisInfo? = null,
    val deviceDecoder: DeviceDecoderAnalysis? = null,
    val analysis: String,
    val recommendedAction: String
) {"""

replacement = """enum class AuthoritativePlaybackResult {
    DIRECT_SUCCESS,
    DIRECT_FAILED,
    FALLBACK_SUCCESS,
    FALLBACK_FAILED,
    CANCELLED
}

data class PlaybackAnalysisReport(
    val result: PlaybackAnalysisResult,
    val player: String = "Media3 / ExoPlayer",
    val failure: PlaybackFailureDetails? = null,
    val containerFormat: String? = null,
    val video: VideoAnalysisInfo? = null,
    val audio: AudioAnalysisInfo? = null,
    val deviceDecoder: DeviceDecoderAnalysis? = null,
    val analysis: String,
    val recommendedAction: String,
    val fallbackUsed: Boolean = false,
    val fallbackTranscodeSuccess: Boolean = false,
    val actualPlaybackConfirmed: Boolean = false,
    val authoritativeError: String? = null,
    val terminalResult: AuthoritativePlaybackResult? = null,
    val playbackPath: String? = null,
    val directPlaybackCompatibility: String? = null
) {"""

content = content.replace(target, replacement)

with open(file_path, "w") as f:
    f.write(content)
