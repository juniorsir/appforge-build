import sys

file_path = "/app/applet/app/src/main/java/com/example/media/MediaEngine.kt"
with open(file_path, "r") as f:
    content = f.read()

target = "interface MediaEngine {"
replace = """interface MediaEngine {
    val playerInstanceId: String"""
content = content.replace(target, replace)

target2 = "override val decoderManager: DecoderManager = com.example.media.orchestration.DecoderOrchestrator()\n) : MediaEngine {"
replace2 = """override val decoderManager: DecoderManager = com.example.media.orchestration.DecoderOrchestrator()
) : MediaEngine {
    override val playerInstanceId: String = java.util.UUID.randomUUID().toString()"""
content = content.replace(target2, replace2)

with open(file_path, "w") as f:
    f.write(content)
