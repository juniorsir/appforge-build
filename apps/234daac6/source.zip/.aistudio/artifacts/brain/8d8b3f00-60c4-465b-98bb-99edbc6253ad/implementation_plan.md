# Fully Dynamic Agy-Controlled HUD & Reliable Two-Stage Stop

Upgrade the floating Agy HUD so Agy can dynamically customize every visual, structural, and interactive element per task via full state pushes or lightweight partial patches, while fixing the broken Stop button with an immediate two-stage Stopping -> Force-Stop flow.

## User Review & Critical Decisions

> [!IMPORTANT]
> All core behavior choices below reflect your confirmed preferences from our clarification step. Please review and approve to begin implementation.

- **Confirmed Decision 1 — Full Dynamic HUD Control**: Agy can dynamically change everything on the HUD per task: custom status labels, light/dark/custom themes and aurora palettes, determinate or indeterminate progress bars, live metric pills, alert banners, custom content blocks, interactive action buttons with custom payloads, and layout/composer controls (expand/collapse, screen position, width, opacity, and showing/hiding the input bar, mic, macros, or stop button).
- **Confirmed Decision 2 — Two-Stage Stop & Force-Stop**: Tapping Stop while a task is active immediately switches the HUD into a clear **Stopping…** state and sends `STOP` to Agy. If Agy confirms completion/cancellation, the HUD transitions cleanly; tapping Stop a second time while in **Stopping…** immediately **Force-Stops** the HUD locally, stops the timer, broadcasts `FORCE_STOP` to Agy, and restores the prompt composer so you are never stuck even if Termux is disconnected.
- **Confirmed Decision 3 — Full Updates + Lightweight Partial Patches**: Support both full state snapshots and fast incremental patches (such as updating a single task by ID, bumping progress percentage, appending one log line, updating a metric pill, or toggling a layout flag) over both HTTP and WebSocket.

---

## 1. Overview & Core Concept

- **What It Does**: Turns the floating Agy HUD from a fixed task card into a programmable, real-time agent surface that adapts to whatever Agy is doing—whether running a Termux build, watching a browser workflow, asking a quick confirmation, or streaming live metrics—while ensuring user controls like Stop respond reliably on the first tap.
- **Target Audience / Persona**: Power users running autonomous Agy tasks on Android who want glanceable, task-tailored feedback floating over any app plus guaranteed manual control to halt any run.
- **Key Value**: Agy can present the exact minimal or rich UI needed for each step without resending huge payloads, and you always have responsive, reliable stop and force-stop control even when the local bridge is offline or busy.

---

## 2. User Experience & Visual Design

### Key User Flows

1. **Two-Stage Stop -> Force-Stop Flow**:
   - While a task is `WORKING`, `PAUSED`, or `NEEDS_INPUT`, the trailing composer orb displays the coral Stop square (`■`) with a generous 48dp touch hit area (and the collapsed live pill shows its inline Stop orb).
   - **Tap 1 (`STOP`)**: Instant haptic feedback + HUD transitions immediately to **`STOPPING`**: status dot pulses coral, status label shows `Stopping…` (with subtle subtitle hint `"Tap stop again to force-stop"`), the Stop orb shifts to a solid coral pulsing ring, keyboard focus releases cleanly, and `action: "STOP"` is pushed to Agy via WebSocket and the poll queue.
   - **Agy Confirms**: When Agy replies with `STOPPED`, `DONE`, or `IDLE`, the timer freezes, the aurora rim calms to neutral/emerald, and the trailing orb springs back to Send (`↑`).
   - **Tap 2 (`FORCE_STOP`)**: If Agy is unresponsive or Termux is disconnected, tapping Stop again immediately moves the HUD to **`STOPPED`**, stops the elapsed timer, marks active `doing` steps as `stopped`, logs the run as `STOPPED` in history, broadcasts `action: "FORCE_STOP"`, and restores the Send (`↑`) orb so you can immediately type a new task.
2. **Task-Adaptive Dynamic HUD Flow**:
   - **Default Clean Card**: When Agy sends a minimal payload, the HUD retains its crisp solid-white compact Gemini card aesthetic (zero clutter, zero bleed-through).
   - **Dynamic Rich Mode**: When Agy enables task-specific widgets, each section animates smoothly into place without visual jitter:
     - *Header*: Custom icon/emoji, custom status text (e.g., `Deploying`, `Analyzing`, `Rate Limited`), optional custom timer or hidden timer, steps toggle badge (`2/4 ▾`).
     - *Progress Strip*: Sleek animated pill progress bar with optional percentage/caption (e.g., `68% · Uploading build`).
     - *Live Metrics Strip*: Horizontal row of compact rounded metric pills (e.g., `Files 3/12`, `Latency 48ms`, `RAM 1.2GB`).
     - *Alert / Status Banner*: Tinted callout strip (`info`, `success`, `warning`, `error`) for warnings, confirmations, or error notices.
     - *Custom Content Blocks*: Optional modular blocks inside the card or expandable details drawer (key-value summary cards, monospace terminal/code snippet preview, or custom interactive button rows).
     - *Bottom Composer*: Adapts placeholder text, visible buttons (Mic, Macros `⚡`, Stop/Send), or hides completely when Agy requests a pure notification/telemetry mode.

### Visual Identity & Theme

- **Aesthetic Direction**: Precision Gemini elevated floating card with adaptive task theming—defaults to crisp opaque white (`#FFFFFF`) with `#E5E9F0` hairline border, and smoothly supports Agy-requested **Dark Surface** (`#0F172A` surface, `#1E293B` elevated inner capsules, `#F8FAFC` text) or **Custom Branded Surface** per task while automatically preserving high contrast.
- **Color Palette & Mood**:
  - *Default Light*: Solid `#FFFFFF` surface, `#F3F6FA` composer capsule, `#0F172A` primary ink, `#64748B` secondary ink.
  - *Dynamic Dark*: Solid `#0F172A` surface, `#1E293B` composer capsule, `#F8FAFC` primary ink, `#94A3B8` secondary ink.
  - *State & Accent Tokens*: Cyan `#0095F6` (`WORKING`), Amber `#D97706` (`PAUSED` / `NEEDS_INPUT`), Emerald `#16A34A` (`DONE`), Coral `#E11D48` (`STOPPING` / `ERROR`), Slate `#64748B` (`STOPPED` / `IDLE`), all overridable by Agy's custom `accentColor` and `auroraColors` array.
- **Typography & Hierarchy**: Bold crisp sans-serif header (`14.5sp` title, `11.5sp` status badge), monospace tabular timer and metric values (`11sp`), and clean single-line/two-line body hierarchy (`12.5sp`) so dynamic blocks stay compact and scannable over any app.
- **Interactive Feedback & Motion**:
  - Spring press feedback (`0.90x` -> `1.0x`) + haptic tick on Stop, Force-Stop, and custom action buttons.
  - Smooth animated progress fills, true-perimeter `SweepGradient` aurora border (dynamically recolored from Agy's palette), and pulsing coral border while in `STOPPING`.
  - Respects safe screen margins, IME keyboard docking, and minimum 48dp touch targets on interactive controls.

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1 — Why the Stop Button Failed & How Two-Stage Stop Solves It**:
  - *Root Cause*: The `STOP` command previously queued a message for Agy without updating local HUD state, stopping the timer, or giving any visual feedback—so whenever Termux was busy or disconnected, tapping Stop appeared completely broken. Additionally, the composer Stop orb had a tight `32dp` touch area and ignored `NEEDS_INPUT` states.
  - *Chosen Approach*: Introduce explicit `STOPPING` and `STOPPED` HUD states, expand the Stop button's effective touch area to 48dp with haptic feedback, handle `WORKING`, `PAUSED`, and `NEEDS_INPUT` uniformly, and allow a second tap in `STOPPING` to force-stop locally.
  - *Alternatives Considered*: Immediate silent collapse (rejected because users need clear feedback that a graceful stop was requested before force-stopping).

- **Decision 2 — Declarative Dynamic Schema + Partial Patch Engine**:
  - *Chosen Approach*: Extend the HUD state model with structured optional sections (`theme`, `layout`, `progress`, `metrics`, `banner`, `blocks`, `customButtons`) that default to empty/standard values so all existing Agy payloads remain 100% backward-compatible. Add a dedicated patch operation handler (`POST /api/hud/patch` and WebSocket `HUD_PATCH`) that merges incremental changes cleanly without wiping untouched fields.
  - *Why*: Keeps simple tasks super lightweight and backward-compatible while unlocking full dynamic HUD control for complex workflows, without forcing Agy to re-transmit the entire HUD JSON on every tick.
  - *Alternatives Considered*: Arbitrary raw HTML/WebView rendering inside the overlay (rejected due to high memory overhead, slow startup, keyboard focus bugs, and inconsistent native look).

- **Decision 3 — Unified Live Overlay & Simulator Parity**:
  - *Chosen Approach*: Mirror every new dynamic HUD capability (theme, progress bar, metrics strip, alert banner, custom blocks, layout toggles, and 2-stage `STOPPING` -> `FORCE_STOP`) in both the native Android floating overlay and the in-app HUD Simulator, including a quick Simulator demo mode so you can visually test dynamic Agy mutations and two-stage Stop even while Termux is offline.
  - *Why*: Lets you preview and verify every dynamic HUD element immediately inside the app without needing to craft manual curl commands first.

---

## 4. Technical Architecture & Data Strategy *(Technical Reference)*

### Architecture & Component Diagram

```text
┌─────────────────────────────────────────────────────────────────────────┐
│                         Agy Agent (Termux / Remote)                     │
│  HTTP: POST /api/hud/state  |  POST /api/hud/patch  |  /api/hud/command │
│  WS:   HUD_STATE | HUD_PATCH | HUD_COMMAND | HUD_HIDE | HUD_RESET       │
│  Discovery: Live Bridge Manifest (auto-documents full dynamic schema)   │
└───────────────────────────────────┬─────────────────────────────────────┘
                                    │ JSON State / Partial Patch
                                    ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                     Agy HUD State & Patch Engine                        │
│  ┌─────────────────────┐   ┌──────────────────┐   ┌──────────────────┐  │
│  │ Full State Merger   │   │ Partial Patcher  │   │ Stop State FSM   │  │
│  │ • Theme & Aurora    │   │ • updateTask(id) │   │ WORKING/PAUSED   │  │
│  │ • Progress & Stats  │   │ • setProgress    │   │   ──Tap 1──▶     │  │
│  │ • Banner & Blocks   │   │ • appendLog      │   │ STOPPING (STOP)  │  │
│  │ • Layout & Composer │   │ • upsertMetric   │   │   ──Tap 2──▶     │  │
│  │ • Custom Buttons    │   │ • setBanner/Block│   │ STOPPED (FORCE)  │  │
│  └──────────┬──────────┘   └────────┬─────────┘   └────────┬─────────┘  │
│             └───────────────────────┼──────────────────────┘            │
│                                     ▼                                   │
│                        StateFlow<AgyHudState>                           │
└───────────────────┬───────────────────────────────────┬─────────────────┘
                    │                                   │
                    ▼                                   ▼
┌───────────────────────────────────┐ ┌───────────────────────────────────┐
│   Live Android Floating Overlay   │ │     In-App HUD Simulator UI       │
│ • Dynamic Aurora Card (Light/Dark)│ │ • True-perimeter dynamic preview  │
│ • Header + Progress + Metrics     │ │ • Interactive 2-stage Stop test   │
│ • Alert Banner + Custom Blocks    │ │ • Dynamic Theme & Patch presets   │
│ • 48dp Touch-Expanded Composer    │ │ • Live JSON Event / Patch Log     │
└───────────────────┬───────────────┘ └─────────────────┬─────────────────┘
                    │                                   │
                    └───────────────┬───────────────────┘
                                    ▼
             Outgoing Events: HUD_COMMAND (PROMPT | STOP | FORCE_STOP |
                              PAUSE | RESUME | CUSTOM_ACTION + payload)
```

### Data Model & State

- **Extended HUD State**:
  - *Core Lifecycle*: `state` (`IDLE`, `WORKING`, `PAUSED`, `NEEDS_INPUT`, `STOPPING`, `STOPPED`, `DONE`), `statusLabel` (optional custom badge text), `title`, `currentAction`, `nextAction`, `question`, `timerVisible`, `customTimerText`.
  - *Visual Theme (`HudThemeConfig`)*: `mode` (`light`, `dark`, `custom`), `surfaceColor`, `secondarySurfaceColor`, `borderColor`, `textPrimaryColor`, `textSecondaryColor`, `accentColor`, `auroraColors` (list of hex stops), `auroraEnabled`, `cornerRadiusDp`, `opacity`.
  - *Layout & Controls (`HudLayoutConfig`)*: `collapsed`, `detailsExpanded`, `macrosDrawerOpen`, `showComposer`, `showMic`, `showMacros`, `showStopButton`, `showStepsBadge`, `showOverflowMenu`, `showCollapseButton`, `inputPlaceholder`, `position` (`top`, `center`, `bottom`), `xFraction`, `yFraction`, `widthFraction`.
  - *Dynamic Widgets*:
    - `HudProgress` (`value` 0..100 or `-1` indeterminate, `label`, `color`, `visible`).
    - `HudMetric` (`id`, `label`, `value`, `accentColor`, `icon`).
    - `HudBanner` (`level`: `info`/`success`/`warning`/`error`, `title`, `message`, `accentColor`).
    - `HudContentBlock` (`id`, `type`: `kv` | `code` | `text` | `progress`, `title`, `body`, `items`, `accentColor`, `inDetails`: whether shown inline or inside the expandable details drawer).
    - Enhanced `QuickActionChip` (`id`, `label`, `commandText`, `actionType`, `style`: `primary`/`secondary`/`danger`/`success`, `payload` JSON map).

### Interactive Component & State Mapping

- **Composer Stop/Send Orb & Collapsed Pill Stop Orb**:
  - When text is typed -> sends `PROMPT` with typed text and clears draft.
  - When draft is empty and state is `WORKING`, `PAUSED`, or `NEEDS_INPUT` -> transitions to `STOPPING`, triggers haptic tick, updates orb to pulsing coral Force-Stop visual, broadcasts `HUD_COMMAND` (`action: "STOP"`).
  - When state is already `STOPPING` -> immediately transitions to `STOPPED`, halts timer, marks running tasks `stopped`, logs run history, broadcasts `HUD_COMMAND` (`action: "FORCE_STOP"`), and restores Send (`↑`) orb.
- **Custom Action Buttons**: Tapping any Agy-defined button emits a structured `HUD_COMMAND` containing `action`, `text`, `buttonId`, and custom `payload` JSON back over WebSocket and `/api/hud/poll`, with optional immediate local feedback.
- **Partial Patch Operations**: Incoming `POST /api/hud/patch` or WebSocket `HUD_PATCH` applies atomic mutations (`patch` fields, `upsertTask`, `removeTask`, `appendLogs`, `upsertMetric`, `removeMetric`, `upsertBlock`, `removeBlock`, `setTheme`, `setLayout`, `clearWidgets`, `reset`) directly onto the active state without resetting untouched properties.
- **Bridge Discovery**: Exposes `/api/hud/patch`, all dynamic state fields, WebSocket `HUD_STATE`/`HUD_PATCH` frames, and `STOP` / `FORCE_STOP` / custom button event formats in the local bridge manifest so Agy discovers them automatically.
