package com.kavach.ui.overlay

import android.graphics.Color
import org.json.JSONArray
import org.json.JSONObject

/**
 * Dynamic, Agy-programmable theme, layout, progress, metric, banner, and modular content-block
 * schemas for the floating Agy HUD. All fields have safe defaults so legacy payloads remain
 * 100% backward-compatible.
 */
object AgyHudDynamicModels {

    fun parseColorOrNull(raw: String?): Int? {
        val trimmed = raw?.trim().orEmpty()
        if (trimmed.isEmpty()) return null
        return try {
            Color.parseColor(if (trimmed.startsWith("#")) trimmed else "#$trimmed")
        } catch (_: Exception) {
            null
        }
    }

    data class HudThemeConfig(
        val mode: String = "light", // light | dark | custom
        val surfaceColor: String = "",
        val secondarySurfaceColor: String = "",
        val borderColor: String = "",
        val textPrimaryColor: String = "",
        val textSecondaryColor: String = "",
        val accentColor: String = "",
        val auroraColors: List<String> = emptyList(),
        val auroraEnabled: Boolean = true,
        val cornerRadiusDp: Float? = null,
        val opacity: Float? = null
    ) {
        fun toJson(): JSONObject = JSONObject().apply {
            put("mode", mode)
            if (surfaceColor.isNotBlank()) put("surfaceColor", surfaceColor)
            if (secondarySurfaceColor.isNotBlank()) put("secondarySurfaceColor", secondarySurfaceColor)
            if (borderColor.isNotBlank()) put("borderColor", borderColor)
            if (textPrimaryColor.isNotBlank()) put("textPrimaryColor", textPrimaryColor)
            if (textSecondaryColor.isNotBlank()) put("textSecondaryColor", textSecondaryColor)
            if (accentColor.isNotBlank()) put("accentColor", accentColor)
            if (auroraColors.isNotEmpty()) {
                put("auroraColors", JSONArray().apply { auroraColors.forEach { put(it) } })
            }
            put("auroraEnabled", auroraEnabled)
            if (cornerRadiusDp != null) put("cornerRadiusDp", cornerRadiusDp.toDouble())
            if (opacity != null) put("opacity", opacity.toDouble())
        }

        fun merge(patch: JSONObject): HudThemeConfig {
            val parsedAurora = if (patch.has("auroraColors")) {
                val arr = patch.optJSONArray("auroraColors") ?: JSONArray()
                buildList {
                    for (i in 0 until arr.length()) {
                        val c = arr.optString(i, "").trim()
                        if (c.isNotEmpty()) add(c)
                    }
                }
            } else auroraColors
            return copy(
                mode = if (patch.has("mode")) patch.optString("mode", mode).lowercase().trim().ifBlank { "light" } else mode,
                surfaceColor = if (patch.has("surfaceColor")) patch.optString("surfaceColor", "").trim() else surfaceColor,
                secondarySurfaceColor = if (patch.has("secondarySurfaceColor")) patch.optString("secondarySurfaceColor", "").trim() else secondarySurfaceColor,
                borderColor = if (patch.has("borderColor")) patch.optString("borderColor", "").trim() else borderColor,
                textPrimaryColor = if (patch.has("textPrimaryColor")) patch.optString("textPrimaryColor", "").trim() else textPrimaryColor,
                textSecondaryColor = if (patch.has("textSecondaryColor")) patch.optString("textSecondaryColor", "").trim() else textSecondaryColor,
                accentColor = if (patch.has("accentColor")) patch.optString("accentColor", "").trim() else accentColor,
                auroraColors = parsedAurora,
                auroraEnabled = if (patch.has("auroraEnabled")) patch.optBoolean("auroraEnabled", auroraEnabled) else auroraEnabled,
                cornerRadiusDp = if (patch.has("cornerRadiusDp")) {
                    if (patch.isNull("cornerRadiusDp")) null else patch.optDouble("cornerRadiusDp", 24.0).toFloat().coerceIn(8f, 36f)
                } else cornerRadiusDp,
                opacity = if (patch.has("opacity")) {
                    if (patch.isNull("opacity")) null else patch.optDouble("opacity", 1.0).toFloat().coerceIn(0.35f, 1.0f)
                } else opacity
            )
        }

        companion object {
            fun fromJson(json: JSONObject?, base: HudThemeConfig = HudThemeConfig()): HudThemeConfig {
                if (json == null) return base
                return base.merge(json)
            }
        }
    }

    data class ResolvedHudTheme(
        val isDark: Boolean,
        val surface: Int,
        val secondarySurface: Int,
        val border: Int,
        val textPrimary: Int,
        val textSecondary: Int,
        val accent: Int,
        val auroraIntColors: IntArray?,
        val auroraEnabled: Boolean,
        val cornerRadiusDp: Float
    )

    fun resolveTheme(config: HudThemeConfig, defaultStateAccent: Int): ResolvedHudTheme {
        val explicitSurface = parseColorOrNull(config.surfaceColor)
        val isDark = when (config.mode.lowercase()) {
            "dark" -> true
            "custom" -> explicitSurface?.let { isColorDark(it) } ?: false
            else -> false
        }
        val surface = explicitSurface ?: if (isDark) Color.parseColor("#FF0F172A") else Color.WHITE
        val secondarySurface = parseColorOrNull(config.secondarySurfaceColor)
            ?: if (isDark) Color.parseColor("#FF1E293B") else Color.parseColor("#FFF3F6FA")
        val border = parseColorOrNull(config.borderColor)
            ?: if (isDark) Color.parseColor("#FF334155") else Color.parseColor("#FFE5E9F0")
        val textPrimary = parseColorOrNull(config.textPrimaryColor)
            ?: if (isDark) Color.parseColor("#FFF8FAFC") else Color.parseColor("#FF0F172A")
        val textSecondary = parseColorOrNull(config.textSecondaryColor)
            ?: if (isDark) Color.parseColor("#FF94A3B8") else Color.parseColor("#FF64748B")
        val accent = parseColorOrNull(config.accentColor) ?: defaultStateAccent
        val auroraParsed = config.auroraColors.mapNotNull { parseColorOrNull(it) }
        val auroraInts = when {
            auroraParsed.size >= 2 -> {
                if (auroraParsed.first() == auroraParsed.last()) auroraParsed.toIntArray()
                else (auroraParsed + auroraParsed.first()).toIntArray()
            }
            auroraParsed.size == 1 -> {
                val c = auroraParsed.first()
                intArrayOf(c, Color.argb(180, Color.red(c), Color.green(c), Color.blue(c)), c)
            }
            else -> null
        }
        return ResolvedHudTheme(
            isDark = isDark,
            surface = surface,
            secondarySurface = secondarySurface,
            border = border,
            textPrimary = textPrimary,
            textSecondary = textSecondary,
            accent = accent,
            auroraIntColors = auroraInts,
            auroraEnabled = config.auroraEnabled,
            cornerRadiusDp = config.cornerRadiusDp ?: 24f
        )
    }

    private fun isColorDark(color: Int): Boolean {
        val luminance = (0.299 * Color.red(color) + 0.587 * Color.green(color) + 0.114 * Color.blue(color)) / 255.0
        return luminance < 0.5
    }

    data class HudLayoutConfig(
        val collapsed: Boolean? = null,
        val detailsExpanded: Boolean? = null,
        val macrosDrawerOpen: Boolean? = null,
        val showComposer: Boolean = true,
        val showMic: Boolean = true,
        val showMacros: Boolean = true,
        val showStopButton: Boolean = true,
        val showStepsBadge: Boolean = true,
        val showOverflowMenu: Boolean = true,
        val showCollapseButton: Boolean = true,
        val inputPlaceholder: String = "",
        val position: String = "", // "" | "top" | "center" | "bottom"
        val xFraction: Float? = null,
        val yFraction: Float? = null,
        val widthFraction: Float? = null
    ) {
        fun toJson(): JSONObject = JSONObject().apply {
            if (collapsed != null) put("collapsed", collapsed)
            if (detailsExpanded != null) put("detailsExpanded", detailsExpanded)
            if (macrosDrawerOpen != null) put("macrosDrawerOpen", macrosDrawerOpen)
            put("showComposer", showComposer)
            put("showMic", showMic)
            put("showMacros", showMacros)
            put("showStopButton", showStopButton)
            put("showStepsBadge", showStepsBadge)
            put("showOverflowMenu", showOverflowMenu)
            put("showCollapseButton", showCollapseButton)
            if (inputPlaceholder.isNotBlank()) put("inputPlaceholder", inputPlaceholder)
            if (position.isNotBlank()) put("position", position)
            if (xFraction != null) put("xFraction", xFraction.toDouble())
            if (yFraction != null) put("yFraction", yFraction.toDouble())
            if (widthFraction != null) put("widthFraction", widthFraction.toDouble())
        }

        fun merge(patch: JSONObject): HudLayoutConfig = copy(
            collapsed = if (patch.has("collapsed")) {
                if (patch.isNull("collapsed")) null else patch.optBoolean("collapsed")
            } else collapsed,
            detailsExpanded = if (patch.has("detailsExpanded")) {
                if (patch.isNull("detailsExpanded")) null else patch.optBoolean("detailsExpanded")
            } else detailsExpanded,
            macrosDrawerOpen = if (patch.has("macrosDrawerOpen")) {
                if (patch.isNull("macrosDrawerOpen")) null else patch.optBoolean("macrosDrawerOpen")
            } else macrosDrawerOpen,
            showComposer = if (patch.has("showComposer")) patch.optBoolean("showComposer", showComposer) else showComposer,
            showMic = if (patch.has("showMic")) patch.optBoolean("showMic", showMic) else showMic,
            showMacros = if (patch.has("showMacros")) patch.optBoolean("showMacros", showMacros) else showMacros,
            showStopButton = if (patch.has("showStopButton")) patch.optBoolean("showStopButton", showStopButton) else showStopButton,
            showStepsBadge = if (patch.has("showStepsBadge")) patch.optBoolean("showStepsBadge", showStepsBadge) else showStepsBadge,
            showOverflowMenu = if (patch.has("showOverflowMenu")) patch.optBoolean("showOverflowMenu", showOverflowMenu) else showOverflowMenu,
            showCollapseButton = if (patch.has("showCollapseButton")) patch.optBoolean("showCollapseButton", showCollapseButton) else showCollapseButton,
            inputPlaceholder = if (patch.has("inputPlaceholder")) patch.optString("inputPlaceholder", "").trim() else inputPlaceholder,
            position = if (patch.has("position")) patch.optString("position", "").lowercase().trim() else position,
            xFraction = if (patch.has("xFraction")) {
                if (patch.isNull("xFraction")) null else patch.optDouble("xFraction", 0.5).toFloat().coerceIn(0f, 1f)
            } else xFraction,
            yFraction = if (patch.has("yFraction")) {
                if (patch.isNull("yFraction")) null else patch.optDouble("yFraction", 0.9).toFloat().coerceIn(0f, 1f)
            } else yFraction,
            widthFraction = if (patch.has("widthFraction")) {
                if (patch.isNull("widthFraction")) null else patch.optDouble("widthFraction", 0.88).toFloat().coerceIn(0.60f, 0.96f)
            } else widthFraction
        )

        companion object {
            fun fromJson(json: JSONObject?, base: HudLayoutConfig = HudLayoutConfig()): HudLayoutConfig {
                if (json == null) return base
                return base.merge(json)
            }
        }
    }

    data class HudProgressConfig(
        val visible: Boolean = false,
        val value: Float = -1f, // -1f = indeterminate, 0f..100f = determinate percent
        val label: String = "",
        val color: String = ""
    ) {
        val isDeterminate: Boolean get() = value >= 0f
        val fraction: Float get() = (value / 100f).coerceIn(0f, 1f)

        fun toJson(): JSONObject = JSONObject().apply {
            put("visible", visible)
            put("value", value.toDouble())
            if (label.isNotBlank()) put("label", label)
            if (color.isNotBlank()) put("color", color)
        }

        companion object {
            fun fromJson(raw: Any?, base: HudProgressConfig = HudProgressConfig()): HudProgressConfig {
                return when (raw) {
                    null -> HudProgressConfig(visible = false)
                    is Number -> {
                        val v = raw.toFloat()
                        HudProgressConfig(visible = true, value = if (v < 0f) -1f else v.coerceIn(0f, 100f))
                    }
                    is JSONObject -> {
                        val vis = if (raw.has("visible")) raw.optBoolean("visible", true) else true
                        val v = if (raw.has("value")) {
                            if (raw.isNull("value")) -1f else raw.optDouble("value", -1.0).toFloat()
                        } else if (raw.has("percent")) {
                            raw.optDouble("percent", -1.0).toFloat()
                        } else {
                            base.value
                        }
                        HudProgressConfig(
                            visible = vis,
                            value = if (v < 0f) -1f else v.coerceIn(0f, 100f),
                            label = if (raw.has("label")) raw.optString("label", "").trim() else base.label,
                            color = if (raw.has("color")) raw.optString("color", "").trim() else base.color
                        )
                    }
                    else -> base
                }
            }
        }
    }

    data class HudMetricItem(
        val id: String,
        val label: String,
        val value: String,
        val accentColor: String = "",
        val icon: String = ""
    ) {
        fun toJson(): JSONObject = JSONObject().apply {
            put("id", id)
            put("label", label)
            put("value", value)
            if (accentColor.isNotBlank()) put("accentColor", accentColor)
            if (icon.isNotBlank()) put("icon", icon)
        }

        companion object {
            fun fromJson(obj: JSONObject, fallbackIndex: Int = 0): HudMetricItem? {
                val lbl = obj.optString("label", "").trim()
                val valStr = obj.optString("value", "").trim()
                if (lbl.isEmpty() && valStr.isEmpty()) return null
                val id = obj.optString("id", lbl.lowercase().replace(" ", "_").ifBlank { "m_$fallbackIndex" }).trim()
                return HudMetricItem(
                    id = id,
                    label = lbl,
                    value = valStr,
                    accentColor = obj.optString("accentColor", obj.optString("color", "")).trim(),
                    icon = obj.optString("icon", "").trim()
                )
            }
        }
    }

    data class HudBannerConfig(
        val visible: Boolean = false,
        val level: String = "info", // info | success | warning | error
        val title: String = "",
        val message: String = "",
        val accentColor: String = ""
    ) {
        fun toJson(): JSONObject = JSONObject().apply {
            put("visible", visible)
            put("level", level)
            if (title.isNotBlank()) put("title", title)
            if (message.isNotBlank()) put("message", message)
            if (accentColor.isNotBlank()) put("accentColor", accentColor)
        }

        companion object {
            fun fromJson(raw: Any?): HudBannerConfig {
                return when (raw) {
                    null -> HudBannerConfig(visible = false)
                    is String -> {
                        val msg = raw.trim()
                        HudBannerConfig(visible = msg.isNotEmpty(), level = "info", message = msg)
                    }
                    is JSONObject -> {
                        val title = raw.optString("title", "").trim()
                        val msg = raw.optString("message", raw.optString("text", "")).trim()
                        val vis = if (raw.has("visible")) raw.optBoolean("visible", true) else (title.isNotEmpty() || msg.isNotEmpty())
                        HudBannerConfig(
                            visible = vis && (title.isNotEmpty() || msg.isNotEmpty()),
                            level = raw.optString("level", "info").lowercase().trim().ifBlank { "info" },
                            title = title,
                            message = msg,
                            accentColor = raw.optString("accentColor", raw.optString("color", "")).trim()
                        )
                    }
                    else -> HudBannerConfig(visible = false)
                }
            }
        }
    }

    data class HudContentBlock(
        val id: String,
        val type: String = "text", // kv | code | text | progress
        val title: String = "",
        val body: String = "",
        val items: List<Pair<String, String>> = emptyList(),
        val progressValue: Float? = null,
        val accentColor: String = "",
        val inDetails: Boolean = false
    ) {
        fun toJson(): JSONObject = JSONObject().apply {
            put("id", id)
            put("type", type)
            if (title.isNotBlank()) put("title", title)
            if (body.isNotBlank()) put("body", body)
            if (items.isNotEmpty()) {
                put("items", JSONArray().apply {
                    items.forEach { (k, v) ->
                        put(JSONObject().put("key", k).put("value", v))
                    }
                })
            }
            if (progressValue != null) put("progressValue", progressValue.toDouble())
            if (accentColor.isNotBlank()) put("accentColor", accentColor)
            put("inDetails", inDetails)
        }

        companion object {
            fun fromJson(obj: JSONObject, fallbackIndex: Int = 0): HudContentBlock? {
                val type = obj.optString("type", "text").lowercase().trim().ifBlank { "text" }
                val title = obj.optString("title", "").trim()
                val body = obj.optString("body", obj.optString("text", "")).trim()
                val items = mutableListOf<Pair<String, String>>()
                val itemsArr = obj.optJSONArray("items")
                if (itemsArr != null) {
                    for (i in 0 until itemsArr.length()) {
                        val row = itemsArr.optJSONObject(i) ?: continue
                        val k = row.optString("key", row.optString("label", "")).trim()
                        val v = row.optString("value", "").trim()
                        if (k.isNotEmpty() || v.isNotEmpty()) items.add(k to v)
                    }
                }
                val progressVal = if (obj.has("progressValue") || obj.has("value")) {
                    val rawKey = if (obj.has("progressValue")) "progressValue" else "value"
                    if (!obj.isNull(rawKey) && obj.opt(rawKey) is Number) {
                        obj.optDouble(rawKey, 0.0).toFloat().coerceIn(0f, 100f)
                    } else null
                } else null
                if (title.isEmpty() && body.isEmpty() && items.isEmpty() && progressVal == null) return null
                val id = obj.optString("id", "blk_$fallbackIndex").trim().ifBlank { "blk_$fallbackIndex" }
                return HudContentBlock(
                    id = id,
                    type = type,
                    title = title,
                    body = body,
                    items = items,
                    progressValue = progressVal,
                    accentColor = obj.optString("accentColor", obj.optString("color", "")).trim(),
                    inDetails = obj.optBoolean("inDetails", false)
                )
            }
        }
    }
}
