package com.kavach.ui.overlay

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.util.Log
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.animation.LayoutTransition
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.util.Locale
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Termux-First Dual-Window Agy HUD Overlay Manager.
 *
 * Manages two coordinated Dark Obsidian Liquid Glass overlays integrated with FloatingOverlayManager:
 * 1. Window 1 (`agy_input`): Floating interactive command/prompt input bar with dynamic Termux-safe
 *    `FLAG_NOT_FOCUSABLE` keyboard handoff (Termux keeps IME focus until user taps EditText, and
 *    regains focus immediately on Send, Stop, outside touch, or collapse).
 * 2. Window 2 (`agy_hud`): Draggable live Task & Screen HUD with Expanded mode (status dot, opacity
 *    cycle 90%/65%/35%, wireframe toggle, ghost touch-through toggle, live CheckBox task list,
 *    MiniScreenWireframeView) and Collapsed mode (`✓ Agy • Done | 💬 Ask / Task` pill).
 *
 * All views are tagged with `agy_hud_` for self-exclusion in AccessibilityRepositoryImpl, and
 * bounding boxes are exposed for temporary `FLAG_NOT_TOUCHABLE` collision pass-through.
 */
class AgyHudOverlayManager(
    private val context: Context,
    private val floatingOverlayManager: FloatingOverlayManager,
    private val onCommandBroadcast: ((JSONObject) -> Unit)? = null,
    private val onRunRecorded: ((RunRecord) -> Unit)? = null,
    private val onMacroUsed: ((String) -> Unit)? = null
) {
    companion object {
        private const val TAG = "AgyHudOverlayManager"
        const val HUD_NODE_TAG_PREFIX = "agy_hud_"
        private const val MAX_QUEUED_COMMANDS = 64

        val OPACITY_LEVELS = floatArrayOf(1.0f, 0.88f, 0.65f)

        // Crisp Opaque Elevated White Gemini Palette (zero bleed-through from apps underneath)
        private val COLOR_OBSIDIAN_GLASS = Color.parseColor("#FFFFFFFF")
        private val COLOR_PILL_INPUT_BG = Color.parseColor("#FFF3F6FA")
        private val COLOR_INNER_CAPSULE = Color.parseColor("#FFF3F6FA")
        private val COLOR_HAIRLINE = Color.parseColor("#FFE5E9F0")
        private val COLOR_CYAN = Color.parseColor("#0095F6")
        private val COLOR_VIOLET = Color.parseColor("#4F46E5")
        private val COLOR_EMERALD = Color.parseColor("#16A34A")
        private val COLOR_AMBER = Color.parseColor("#D97706")
        private val COLOR_CORAL = Color.parseColor("#E11D48")
        private val COLOR_TEXT_PRIMARY = Color.parseColor("#0F172A")
        private val COLOR_TEXT_SECONDARY = Color.parseColor("#64748B")
    }

    data class AgyHudTask(
        val id: String,
        val label: String,
        val status: String = "pending", // done | doing | pending | needs_input
        val icon: String = "",          // optional explicit icon key ("youtube", "termux", "chrome", ...)
        val appPackage: String = "",    // optional Android package name for real app icon lookup
        val detail: String = ""         // optional compact step note
    ) {
        fun toJson(): JSONObject = JSONObject().apply {
            put("id", id)
            put("label", label)
            put("status", status)
            if (icon.isNotBlank()) put("icon", icon)
            if (appPackage.isNotBlank()) put("appPackage", appPackage)
            if (detail.isNotBlank()) put("detail", detail)
        }
    }

    data class QuickActionChip(
        val label: String,
        val commandText: String,
        val actionType: String = "PROMPT", // PROMPT | STOP | FORCE_STOP | PAUSE | RESUME | COPY_OUTPUT | TOGGLE_OUTPUT | CUSTOM
        val id: String = "",
        val style: String = "", // "" | primary | secondary | danger | success
        val payload: JSONObject? = null
    ) {
        fun toJson(): JSONObject = JSONObject().apply {
            if (id.isNotBlank()) put("id", id)
            put("label", label)
            put("commandText", commandText)
            put("actionType", actionType)
            if (style.isNotBlank()) put("style", style)
            if (payload != null) put("payload", payload)
        }
    }

    data class WireframeZone(
        val x1: Float,
        val y1: Float,
        val x2: Float,
        val y2: Float,
        val role: String = "panel",
        val tag: String = ""
    ) {
        fun toJson(): JSONObject = JSONObject().apply {
            put("x1", x1.toDouble())
            put("y1", y1.toDouble())
            put("x2", x2.toDouble())
            put("y2", y2.toDouble())
            put("role", role)
            put("tag", tag)
        }
    }

    data class WireframeActionVector(
        val type: String = "TAP", // TAP | CLICK | SWIPE | DRAG
        val x1: Float,
        val y1: Float,
        val x2: Float = x1,
        val y2: Float = y1
    ) {
        fun toJson(): JSONObject = JSONObject().apply {
            put("type", type)
            put("x1", x1.toDouble())
            put("y1", y1.toDouble())
            put("x2", x2.toDouble())
            put("y2", y2.toDouble())
        }
    }

    data class ScreenWatchState(
        val active: Boolean = false,
        val label: String = "",
        val screenWidth: Int = 1080,
        val screenHeight: Int = 2400,
        val zones: List<WireframeZone> = emptyList(),
        val actionVector: WireframeActionVector? = null
    ) {
        fun toJson(): JSONObject = JSONObject().apply {
            put("active", active)
            put("label", label)
            put("screenWidth", screenWidth)
            put("screenHeight", screenHeight)
            put("zones", JSONArray().apply { zones.forEach { put(it.toJson()) } })
            if (actionVector != null) put("actionVector", actionVector.toJson())
        }
    }

    data class AgyHudState(
        val state: String = "IDLE", // IDLE | WORKING | PAUSED | NEEDS_INPUT | STOPPING | STOPPED | DONE
        val title: String = "Agy Ready",
        val currentAction: String = "",
        val nextAction: String = "",
        val question: String = "",
        val autoCollapseSeconds: Int = 4,
        val tasks: List<AgyHudTask> = emptyList(),
        val screenWatch: ScreenWatchState = ScreenWatchState(),
        val appPackage: String = "",
        val icon: String = "",
        val detailedOutput: String = "",
        val outputLogs: List<String> = emptyList(),
        val quickActions: List<QuickActionChip> = emptyList(),
        val statusLabel: String = "",
        val customEmoji: String = "",
        val timerVisible: Boolean = true,
        val customTimerText: String = "",
        val theme: AgyHudDynamicModels.HudThemeConfig = AgyHudDynamicModels.HudThemeConfig(),
        val layout: AgyHudDynamicModels.HudLayoutConfig = AgyHudDynamicModels.HudLayoutConfig(),
        val progress: AgyHudDynamicModels.HudProgressConfig = AgyHudDynamicModels.HudProgressConfig(),
        val metrics: List<AgyHudDynamicModels.HudMetricItem> = emptyList(),
        val banner: AgyHudDynamicModels.HudBannerConfig = AgyHudDynamicModels.HudBannerConfig(),
        val blocks: List<AgyHudDynamicModels.HudContentBlock> = emptyList()
    ) {
        fun toJson(): JSONObject = JSONObject().apply {
            put("state", state)
            put("title", title)
            put("currentAction", currentAction)
            put("nextAction", nextAction)
            put("question", question)
            put("autoCollapseSeconds", autoCollapseSeconds)
            put("tasks", JSONArray().apply { tasks.forEach { put(it.toJson()) } })
            put("screenWatch", screenWatch.toJson())
            if (appPackage.isNotBlank()) put("appPackage", appPackage)
            if (icon.isNotBlank()) put("icon", icon)
            if (detailedOutput.isNotBlank()) put("detailedOutput", detailedOutput)
            put("outputLogs", JSONArray().apply { outputLogs.forEach { put(it) } })
            put("quickActions", JSONArray().apply { quickActions.forEach { put(it.toJson()) } })
            if (statusLabel.isNotBlank()) put("statusLabel", statusLabel)
            if (customEmoji.isNotBlank()) put("customEmoji", customEmoji)
            put("timerVisible", timerVisible)
            if (customTimerText.isNotBlank()) put("customTimerText", customTimerText)
            put("theme", theme.toJson())
            put("layout", layout.toJson())
            put("progress", progress.toJson())
            put("metrics", JSONArray().apply { metrics.forEach { put(it.toJson()) } })
            put("banner", banner.toJson())
            put("blocks", JSONArray().apply { blocks.forEach { put(it.toJson()) } })
        }
    }

    data class HudCommand(
        val id: String = "cmd_${UUID.randomUUID().toString().take(8)}",
        val type: String = "HUD_COMMAND",
        val text: String,
        val action: String = "PROMPT", // PROMPT | STOP | FORCE_STOP | PAUSE | RESUME | CUSTOM
        val timestamp: Long = System.currentTimeMillis(),
        val buttonId: String = "",
        val payload: JSONObject? = null
    ) {
        fun toJson(): JSONObject = JSONObject().apply {
            put("id", id)
            put("type", type)
            put("text", text)
            put("action", action)
            put("timestamp", timestamp)
            if (buttonId.isNotBlank()) put("buttonId", buttonId)
            if (payload != null) put("payload", payload)
        }
    }

    data class CollapsedRunningStep(
        val label: String,
        val icon: AgyAppIconResolver.ResolvedIcon
    )

    data class MacroShortcut(
        val id: String,
        val title: String,
        val prompt: String,
        val iconHint: String = "spark_ai"
    )

    data class RunRecord(
        val title: String,
        val promptText: String,
        val finalState: String,
        val iconHint: String,
        val appPackage: String,
        val durationMs: Long,
        val stepCount: Int,
        val detailedOutput: String,
        val outputLogs: List<String>
    )

    private val mainHandler = Handler(Looper.getMainLooper())
    private val windowManager: WindowManager? by lazy {
        context.getSystemService(Context.WINDOW_SERVICE) as? WindowManager
    }
    private val inputMethodManager: InputMethodManager? by lazy {
        context.getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
    }

    private val commandQueue = ConcurrentLinkedQueue<HudCommand>()

    private val _isHudVisible = MutableStateFlow(false)
    val isHudVisible: StateFlow<Boolean> = _isHudVisible.asStateFlow()

    private val _isInputVisible = MutableStateFlow(false)
    val isInputVisible: StateFlow<Boolean> = _isInputVisible.asStateFlow()

    private val _hudState = MutableStateFlow(AgyHudState())
    val hudState: StateFlow<AgyHudState> = _hudState.asStateFlow()

    private val _isCollapsedFlow = MutableStateFlow(true)
    val isCollapsedFlow: StateFlow<Boolean> = _isCollapsedFlow.asStateFlow()

    private val _opacityFlow = MutableStateFlow(OPACITY_LEVELS[0])
    val opacityFlow: StateFlow<Float> = _opacityFlow.asStateFlow()

    private val _ghostPassThroughFlow = MutableStateFlow(false)
    val ghostPassThroughFlow: StateFlow<Boolean> = _ghostPassThroughFlow.asStateFlow()

    private val _wireframeEnabledFlow = MutableStateFlow(true)
    val wireframeEnabledFlow: StateFlow<Boolean> = _wireframeEnabledFlow.asStateFlow()

    private val _edgeSnapEnabledFlow = MutableStateFlow(true)
    val edgeSnapEnabledFlow: StateFlow<Boolean> = _edgeSnapEnabledFlow.asStateFlow()

    private val _isVoiceListeningFlow = MutableStateFlow(false)
    val isVoiceListeningFlow: StateFlow<Boolean> = _isVoiceListeningFlow.asStateFlow()

    private val _pinnedMacrosFlow = MutableStateFlow<List<MacroShortcut>>(emptyList())
    val pinnedMacrosFlow: StateFlow<List<MacroShortcut>> = _pinnedMacrosFlow.asStateFlow()

    private val _isOutputExpandedFlow = MutableStateFlow(false)
    val isOutputExpandedFlow: StateFlow<Boolean> = _isOutputExpandedFlow.asStateFlow()

    private val _elapsedMsFlow = MutableStateFlow(0L)
    val elapsedMsFlow: StateFlow<Long> = _elapsedMsFlow.asStateFlow()

    @Volatile
    private var isCollapsed: Boolean = true
        set(value) {
            field = value
            _isCollapsedFlow.value = value
        }
    @Volatile
    @set:JvmName("setOutputExpandedInternal")
    private var isOutputExpanded: Boolean = false
        set(value) {
            field = value
            _isOutputExpandedFlow.value = value
        }
    @Volatile
    private var opacityIndex: Int = 0
        set(value) {
            field = value
            _opacityFlow.value = OPACITY_LEVELS[value.coerceIn(0, OPACITY_LEVELS.lastIndex)]
        }
    @Volatile
    private var wireframeEnabled: Boolean = true
        set(value) {
            field = value
            _wireframeEnabledFlow.value = value
        }
    @Volatile
    private var edgeSnapEnabled: Boolean = true
        set(value) {
            field = value
            _edgeSnapEnabledFlow.value = value
        }
    @Volatile
    private var ghostPassThrough: Boolean = false
        set(value) {
            field = value
            _ghostPassThroughFlow.value = value
        }
    @Volatile
    private var isToolsTrayOpen: Boolean = false
    @Volatile
    private var isInputFocused: Boolean = false
    @Volatile
    private var temporaryPassThroughActive: Boolean = false
    @Volatile
    private var lastSubmittedPrompt: String = ""

    // Single Unified Floating Gemini HUD (`agy_hud`) references
    private var hudRootView: HoldDraggableDockLayout? = null
    private var hudParams: WindowManager.LayoutParams? = null
    private var hudExpandedContainer: AgyAuroraCardLayout? = null
    private var hudBottomDockRow: LinearLayout? = null
    private var workingLoadingBar: AgyLoadingBarView? = null
    private var headerAppIconView: AgyIconBadgeView? = null
    private var headerSpinnerView: AgySpinnerRingView? = null
    private var statusDotView: View? = null
    private var statusBadgeText: TextView? = null
    private var elapsedTimerText: TextView? = null
    private var toolsMenuBtn: TextView? = null
    private var toolsTrayContainer: LinearLayout? = null
    private var titleText: TextView? = null
    private var questionBannerText: TextView? = null
    private var doingRowContainer: LinearLayout? = null
    private var currentActionText: TextView? = null
    private var doingDotsView: AgyBouncingDotsView? = null
    private var nextActionText: TextView? = null
    private var taskListContainer: LinearLayout? = null
    private var taskScrollView: ScrollView? = null
    private var outputSectionContainer: LinearLayout? = null
    private var outputToggleHeaderText: TextView? = null
    private var outputDrawerContainer: LinearLayout? = null
    private var outputCopyBtn: TextView? = null
    private var outputBodyText: TextView? = null
    private var quickActionsScrollView: HorizontalScrollView? = null
    private var quickActionsContainer: LinearLayout? = null
    private var wireframeContainer: LinearLayout? = null
    private var wireframeLabelText: TextView? = null
    private var wireframeView: MiniScreenWireframeView? = null
    private var opacityBtn: TextView? = null
    private var wireframeBtn: TextView? = null
    private var ghostBtn: TextView? = null
    private var edgeSnapBtn: TextView? = null
    private var dockStandardStatusGroup: LinearLayout? = null
    private var dockStandardDivider: View? = null
    private var dockSpinnerView: AgySpinnerRingView? = null
    private var collapsedStatusText: TextView? = null
    private var bottomChatPillBtn: TextView? = null
    private var dockLiveStepGroup: LinearLayout? = null
    private var dockLiveSpinnerView: AgySpinnerRingView? = null
    private var dockLiveIconView: AgyIconBadgeView? = null
    private var dockLiveStepText: TextView? = null
    private var dockLiveTimerText: TextView? = null
    private var dockLiveStopBtn: TextView? = null
    private var lastCollapsedStepLabel: String = ""
    private var lastRenderedCollapsedState: Boolean? = null
    private var lastRenderedTitle: String = ""
    private var lastRenderedTaskStatuses: Map<String, String> = emptyMap()
    private var lastDockTapAtMs: Long = 0L

    // Built-in Bottom Composer Dock & On-Demand Progressive Disclosure inside the Unified Gemini Card
    private var telemetryDetailsContainer: LinearLayout? = null
    private var stepsTogglePill: TextView? = null
    private var headerCollapseBtn: TextView? = null
    private var customEmojiView: TextView? = null
    private var progressRowContainer: LinearLayout? = null
    private var progressBarView: AgyLoadingBarView? = null
    private var progressCaptionText: TextView? = null
    private var metricsScrollView: HorizontalScrollView? = null
    private var metricsContainer: LinearLayout? = null
    private var dynamicBannerContainer: LinearLayout? = null
    private var dynamicBannerTitleText: TextView? = null
    private var dynamicBannerMsgText: TextView? = null
    private var inlineBlocksContainer: LinearLayout? = null
    private var detailBlocksContainer: LinearLayout? = null
    private var composerDividerView: View? = null
    private var isDetailsExpanded: Boolean = false
    private var isMacrosDrawerOpen: Boolean = false
    private var savedYBeforeIme: Int? = null
    private var isTemporarilySuppressed: Boolean = false
    private var inlineComposerContainer: LinearLayout? = null
    private var composerInputCapsule: LinearLayout? = null
    private var composerVoiceStatusHint: TextView? = null
    private var inputEditText: EditText? = null
    private var inputMicBtn: AgyGlyphButtonView? = null
    private var clearDraftBtn: AgyGlyphButtonView? = null
    private var macrosToggleBtn: AgyGlyphButtonView? = null
    private var composerActionBtn: AgyGlyphButtonView? = null
    private var inputMacrosScrollView: HorizontalScrollView? = null
    private var inputMacrosContainer: LinearLayout? = null
    private var voiceController: AgyVoiceInputController? = null

    // Tiny ghost restore pill (only visible while ghost mode is ON so user can exit ghost mode)
    private var ghostRestoreView: View? = null
    private var ghostRestoreParams: WindowManager.LayoutParams? = null

    // Scheduled tasks & live accumulated elapsed timer
    private var autoCollapseRunnable: Runnable? = null
    private var passThroughRestoreRunnable: Runnable? = null
    private var pulseRunnable: Runnable? = null
    private var pulseToggle: Boolean = false
    private var elapsedTimerRunnable: Runnable? = null
    private var accumulatedElapsedMs: Long = 0L
    private var activeSegmentStartMs: Long = 0L
    private var edgeSnapAnimator: android.animation.ValueAnimator? = null
    private var copyFeedbackResetRunnable: Runnable? = null

    fun setPinnedMacros(macros: List<MacroShortcut>) {
        _pinnedMacrosFlow.value = macros
        runOnMain { renderInputMacrosStrip() }
    }

    fun hasOverlayPermission(): Boolean = floatingOverlayManager.hasPermission()

    fun getOverlayPermissionIntent(): Intent? = floatingOverlayManager.getPermissionIntent()

    fun parseHudStateFromJson(json: JSONObject): AgyHudState {
        val current = _hudState.value
        val validStates = listOf("IDLE", "WORKING", "PAUSED", "NEEDS_INPUT", "STOPPING", "STOPPED", "DONE")
        val state = json.optString("state", current.state).uppercase().trim()
            .let { if (it in validStates) it else "WORKING" }
        val title = if (json.has("title")) json.optString("title", "") else current.title
        val currentAction = if (json.has("currentAction")) json.optString("currentAction", "") else current.currentAction
        val nextAction = if (json.has("nextAction")) json.optString("nextAction", "") else current.nextAction
        val question = if (json.has("question")) json.optString("question", "") else if (state != "NEEDS_INPUT") "" else current.question
        val autoCollapse = json.optInt("autoCollapseSeconds", current.autoCollapseSeconds).coerceIn(0, 120)

        val tasks = if (json.has("tasks")) {
            val arr = json.optJSONArray("tasks") ?: JSONArray()
            val list = mutableListOf<AgyHudTask>()
            for (i in 0 until arr.length()) {
                val obj = arr.optJSONObject(i) ?: continue
                list.add(
                    AgyHudTask(
                        id = obj.optString("id", "t_$i"),
                        label = obj.optString("label", "").trim(),
                        status = obj.optString("status", "pending").lowercase().trim(),
                        icon = obj.optString("icon", "").trim(),
                        appPackage = obj.optString("appPackage", "").trim(),
                        detail = obj.optString("detail", "").trim()
                    )
                )
            }
            list
        } else {
            current.tasks
        }

        val appPackage = if (json.has("appPackage")) json.optString("appPackage", "").trim() else current.appPackage
        val icon = if (json.has("icon")) json.optString("icon", "").trim() else current.icon
        val detailedOutput = if (json.has("detailedOutput")) {
            json.optString("detailedOutput", "")
        } else {
            current.detailedOutput
        }
        val outputLogs = if (json.has("outputLogs")) {
            val arr = json.optJSONArray("outputLogs") ?: JSONArray()
            val logs = mutableListOf<String>()
            for (i in 0 until arr.length()) {
                val line = arr.optString(i, "").trim()
                if (line.isNotEmpty()) logs.add(line)
            }
            logs
        } else {
            current.outputLogs
        }
        val quickActions = if (json.has("quickActions") || json.has("buttons") || json.has("customButtons")) {
            val arr = json.optJSONArray("quickActions")
                ?: json.optJSONArray("buttons")
                ?: json.optJSONArray("customButtons")
                ?: JSONArray()
            val chips = mutableListOf<QuickActionChip>()
            for (i in 0 until arr.length()) {
                val item = arr.opt(i)
                when (item) {
                    is JSONObject -> {
                        val lbl = item.optString("label", "").trim()
                        if (lbl.isNotEmpty()) {
                            chips.add(
                                QuickActionChip(
                                    label = lbl,
                                    commandText = item.optString("commandText", item.optString("text", lbl)).trim(),
                                    actionType = item.optString("actionType", item.optString("action", "PROMPT")).uppercase().trim(),
                                    id = item.optString("id", "").trim(),
                                    style = item.optString("style", "").lowercase().trim(),
                                    payload = item.optJSONObject("payload")
                                )
                            )
                        }
                    }
                    is String -> {
                        val lbl = item.trim()
                        if (lbl.isNotEmpty()) {
                            chips.add(QuickActionChip(label = lbl, commandText = lbl, actionType = "PROMPT"))
                        }
                    }
                }
            }
            chips
        } else if (state != current.state) {
            emptyList()
        } else {
            current.quickActions
        }

        val screenWatch = if (json.has("screenWatch")) {
            val swObj = json.optJSONObject("screenWatch")
            if (swObj != null) {
                val zonesArr = swObj.optJSONArray("zones") ?: JSONArray()
                val zones = mutableListOf<WireframeZone>()
                for (i in 0 until zonesArr.length()) {
                    val z = zonesArr.optJSONObject(i) ?: continue
                    zones.add(
                        WireframeZone(
                            x1 = z.optDouble("x1", 0.0).toFloat(),
                            y1 = z.optDouble("y1", 0.0).toFloat(),
                            x2 = z.optDouble("x2", 0.0).toFloat(),
                            y2 = z.optDouble("y2", 0.0).toFloat(),
                            role = z.optString("role", "panel"),
                            tag = z.optString("tag", "")
                        )
                    )
                }
                val avObj = swObj.optJSONObject("actionVector")
                val actionVec = if (avObj != null) {
                    WireframeActionVector(
                        type = avObj.optString("type", "TAP").uppercase(),
                        x1 = avObj.optDouble("x1", 0.0).toFloat(),
                        y1 = avObj.optDouble("y1", 0.0).toFloat(),
                        x2 = avObj.optDouble("x2", avObj.optDouble("x1", 0.0)).toFloat(),
                        y2 = avObj.optDouble("y2", avObj.optDouble("y1", 0.0)).toFloat()
                    )
                } else null

                ScreenWatchState(
                    active = swObj.optBoolean("active", false),
                    label = swObj.optString("label", ""),
                    screenWidth = swObj.optInt("screenWidth", context.resources.displayMetrics.widthPixels.coerceAtLeast(360)),
                    screenHeight = swObj.optInt("screenHeight", context.resources.displayMetrics.heightPixels.coerceAtLeast(640)),
                    zones = zones,
                    actionVector = actionVec
                )
            } else {
                ScreenWatchState(active = false)
            }
        } else {
            current.screenWatch
        }

        val statusLabel = if (json.has("statusLabel")) json.optString("statusLabel", "").trim() else current.statusLabel
        val customEmoji = if (json.has("customEmoji") || json.has("emoji")) {
            json.optString("customEmoji", json.optString("emoji", "")).trim()
        } else current.customEmoji
        val timerVisible = if (json.has("timerVisible")) json.optBoolean("timerVisible", true) else current.timerVisible
        val customTimerText = if (json.has("customTimerText")) json.optString("customTimerText", "").trim() else current.customTimerText

        val theme = if (json.has("theme")) {
            if (json.isNull("theme")) AgyHudDynamicModels.HudThemeConfig()
            else AgyHudDynamicModels.HudThemeConfig.fromJson(json.optJSONObject("theme"), current.theme)
        } else {
            // Also support convenient top-level accentColor / themeMode shortcuts
            var t = current.theme
            if (json.has("accentColor")) t = t.copy(accentColor = json.optString("accentColor", "").trim())
            if (json.has("themeMode")) t = t.copy(mode = json.optString("themeMode", t.mode).lowercase().trim().ifBlank { "light" })
            t
        }

        val layout = if (json.has("layout")) {
            if (json.isNull("layout")) AgyHudDynamicModels.HudLayoutConfig()
            else AgyHudDynamicModels.HudLayoutConfig.fromJson(json.optJSONObject("layout"), current.layout)
        } else {
            var l = current.layout
            if (json.has("inputPlaceholder")) l = l.copy(inputPlaceholder = json.optString("inputPlaceholder", "").trim())
            if (json.has("showComposer")) l = l.copy(showComposer = json.optBoolean("showComposer", l.showComposer))
            l
        }

        val progress = if (json.has("progress")) {
            if (json.isNull("progress")) AgyHudDynamicModels.HudProgressConfig(visible = false)
            else AgyHudDynamicModels.HudProgressConfig.fromJson(json.opt("progress"), current.progress)
        } else current.progress

        val metrics = if (json.has("metrics")) {
            val arr = json.optJSONArray("metrics") ?: JSONArray()
            buildList {
                for (i in 0 until arr.length()) {
                    val obj = arr.optJSONObject(i) ?: continue
                    AgyHudDynamicModels.HudMetricItem.fromJson(obj, i)?.let { add(it) }
                }
            }
        } else current.metrics

        val banner = if (json.has("banner")) {
            if (json.isNull("banner")) AgyHudDynamicModels.HudBannerConfig(visible = false)
            else AgyHudDynamicModels.HudBannerConfig.fromJson(json.opt("banner"))
        } else current.banner

        val blocks = if (json.has("blocks")) {
            val arr = json.optJSONArray("blocks") ?: JSONArray()
            buildList {
                for (i in 0 until arr.length()) {
                    val obj = arr.optJSONObject(i) ?: continue
                    AgyHudDynamicModels.HudContentBlock.fromJson(obj, i)?.let { add(it) }
                }
            }
        } else current.blocks

        return AgyHudState(
            state = state,
            title = title.ifBlank { "Agy HUD" },
            currentAction = currentAction,
            nextAction = nextAction,
            question = question,
            autoCollapseSeconds = autoCollapse,
            tasks = tasks,
            screenWatch = screenWatch,
            appPackage = appPackage,
            icon = icon,
            detailedOutput = detailedOutput,
            outputLogs = outputLogs,
            quickActions = quickActions,
            statusLabel = statusLabel,
            customEmoji = customEmoji,
            timerVisible = timerVisible,
            customTimerText = customTimerText,
            theme = theme,
            layout = layout,
            progress = progress,
            metrics = metrics,
            banner = banner,
            blocks = blocks
        )
    }

    @Volatile
    private var stopRecordedForCurrentRun: Boolean = false

    /**
     * Handles POST /api/hud/state. Updates in-memory state immediately and renders Window 2 / Window 1.
     */
    fun updateState(json: JSONObject): JSONObject {
        val nextState = parseHudStateFromJson(json)
        val layoutJson = json.optJSONObject("layout")
        val explicitCollapsed = layoutJson?.takeIf { it.has("collapsed") && !it.isNull("collapsed") }?.optBoolean("collapsed")
            ?: json.takeIf { it.has("collapsed") && !it.isNull("collapsed") }?.optBoolean("collapsed")
        val explicitDetails = layoutJson?.takeIf { it.has("detailsExpanded") && !it.isNull("detailsExpanded") }?.optBoolean("detailsExpanded")
            ?: json.takeIf { it.has("detailsExpanded") && !it.isNull("detailsExpanded") }?.optBoolean("detailsExpanded")
        val explicitMacros = layoutJson?.takeIf { it.has("macrosDrawerOpen") && !it.isNull("macrosDrawerOpen") }?.optBoolean("macrosDrawerOpen")
            ?: json.takeIf { it.has("macrosDrawerOpen") && !it.isNull("macrosDrawerOpen") }?.optBoolean("macrosDrawerOpen")
        return applyHudStateInternal(
            nextState = nextState,
            explicitCollapsed = explicitCollapsed,
            explicitDetailsExpanded = explicitDetails,
            explicitMacrosDrawerOpen = explicitMacros
        )
    }

    /**
     * Handles POST /api/hud/patch (and WS HUD_PATCH): applies lightweight surgical updates
     * (single task upsert/remove, progress %, appendLog/appendLogs, metric upsert/remove,
     * banner update, block upsert/remove, theme/layout patch, clearWidgets, reset, plus
     * any top-level partial field updates) without wiping untouched HUD properties.
     */
    fun patchState(json: JSONObject): JSONObject {
        if (json.optBoolean("reset", false) || json.optString("op", "").equals("RESET", ignoreCase = true)) {
            return resetState()
        }

        // First merge any top-level partial fields using parseHudStateFromJson
        var merged = parseHudStateFromJson(json)

        // Single task upsert / update by ID: upsertTask / updateTask
        val upsertTaskObj = json.optJSONObject("upsertTask") ?: json.optJSONObject("updateTask")
        if (upsertTaskObj != null) {
            val tid = upsertTaskObj.optString("id", "").trim().ifBlank { "t_${merged.tasks.size}" }
            val mutable = merged.tasks.toMutableList()
            val idx = mutable.indexOfFirst { it.id == tid }
            val existing = if (idx >= 0) mutable[idx] else null
            val updated = AgyHudTask(
                id = tid,
                label = if (upsertTaskObj.has("label")) upsertTaskObj.optString("label", "").trim() else existing?.label.orEmpty(),
                status = if (upsertTaskObj.has("status")) upsertTaskObj.optString("status", "pending").lowercase().trim() else existing?.status ?: "pending",
                icon = if (upsertTaskObj.has("icon")) upsertTaskObj.optString("icon", "").trim() else existing?.icon.orEmpty(),
                appPackage = if (upsertTaskObj.has("appPackage")) upsertTaskObj.optString("appPackage", "").trim() else existing?.appPackage.orEmpty(),
                detail = if (upsertTaskObj.has("detail")) upsertTaskObj.optString("detail", "").trim() else existing?.detail.orEmpty()
            )
            if (idx >= 0) mutable[idx] = updated else mutable.add(updated)
            merged = merged.copy(tasks = mutable)
        }

        // Remove task by ID
        val removeTaskId = json.optString("removeTask", json.optString("removeTaskId", "")).trim()
        if (removeTaskId.isNotEmpty()) {
            merged = merged.copy(tasks = merged.tasks.filterNot { it.id == removeTaskId })
        }

        // Append one or many log lines
        val appendedLogs = mutableListOf<String>()
        if (json.has("appendLog")) {
            val single = json.optString("appendLog", "").trim()
            if (single.isNotEmpty()) appendedLogs.add(single)
        }
        val appendArr = json.optJSONArray("appendLogs")
        if (appendArr != null) {
            for (i in 0 until appendArr.length()) {
                val line = appendArr.optString(i, "").trim()
                if (line.isNotEmpty()) appendedLogs.add(line)
            }
        }
        if (appendedLogs.isNotEmpty()) {
            merged = merged.copy(outputLogs = (merged.outputLogs + appendedLogs).takeLast(120))
        }

        // Upsert / remove single metric pill
        val upsertMetricObj = json.optJSONObject("upsertMetric") ?: json.optJSONObject("setMetric")
        if (upsertMetricObj != null) {
            AgyHudDynamicModels.HudMetricItem.fromJson(upsertMetricObj, merged.metrics.size)?.let { m ->
                val mutable = merged.metrics.toMutableList()
                val idx = mutable.indexOfFirst { it.id == m.id }
                if (idx >= 0) mutable[idx] = m else mutable.add(m)
                merged = merged.copy(metrics = mutable)
            }
        }
        val removeMetricId = json.optString("removeMetric", "").trim()
        if (removeMetricId.isNotEmpty()) {
            merged = merged.copy(metrics = merged.metrics.filterNot { it.id == removeMetricId })
        }

        // Upsert / remove single content block
        val upsertBlockObj = json.optJSONObject("upsertBlock") ?: json.optJSONObject("setBlock")
        if (upsertBlockObj != null) {
            AgyHudDynamicModels.HudContentBlock.fromJson(upsertBlockObj, merged.blocks.size)?.let { b ->
                val mutable = merged.blocks.toMutableList()
                val idx = mutable.indexOfFirst { it.id == b.id }
                if (idx >= 0) mutable[idx] = b else mutable.add(b)
                merged = merged.copy(blocks = mutable)
            }
        }
        val removeBlockId = json.optString("removeBlock", "").trim()
        if (removeBlockId.isNotEmpty()) {
            merged = merged.copy(blocks = merged.blocks.filterNot { it.id == removeBlockId })
        }

        // Convenience setProgress / setBanner / setTheme / setLayout aliases
        if (json.has("setProgress")) {
            merged = merged.copy(
                progress = if (json.isNull("setProgress")) AgyHudDynamicModels.HudProgressConfig(visible = false)
                else AgyHudDynamicModels.HudProgressConfig.fromJson(json.opt("setProgress"), merged.progress)
            )
        }
        if (json.has("setBanner")) {
            merged = merged.copy(
                banner = if (json.isNull("setBanner")) AgyHudDynamicModels.HudBannerConfig(visible = false)
                else AgyHudDynamicModels.HudBannerConfig.fromJson(json.opt("setBanner"))
            )
        }
        if (json.has("setTheme")) {
            merged = merged.copy(
                theme = if (json.isNull("setTheme")) AgyHudDynamicModels.HudThemeConfig()
                else AgyHudDynamicModels.HudThemeConfig.fromJson(json.optJSONObject("setTheme"), merged.theme)
            )
        }
        val setLayoutObj = json.optJSONObject("setLayout") ?: json.optJSONObject("layout")
        if (json.has("setLayout")) {
            merged = merged.copy(
                layout = if (json.isNull("setLayout")) AgyHudDynamicModels.HudLayoutConfig()
                else AgyHudDynamicModels.HudLayoutConfig.fromJson(json.optJSONObject("setLayout"), merged.layout)
            )
        }

        // Clear all dynamic widgets (progress, metrics, banner, blocks)
        if (json.optBoolean("clearWidgets", false)) {
            merged = merged.copy(
                progress = AgyHudDynamicModels.HudProgressConfig(visible = false),
                metrics = emptyList(),
                banner = AgyHudDynamicModels.HudBannerConfig(visible = false),
                blocks = emptyList()
            )
        }

        val explicitCollapsed = setLayoutObj?.takeIf { it.has("collapsed") && !it.isNull("collapsed") }?.optBoolean("collapsed")
            ?: json.takeIf { it.has("collapsed") && !it.isNull("collapsed") }?.optBoolean("collapsed")
        val explicitDetails = setLayoutObj?.takeIf { it.has("detailsExpanded") && !it.isNull("detailsExpanded") }?.optBoolean("detailsExpanded")
            ?: json.takeIf { it.has("detailsExpanded") && !it.isNull("detailsExpanded") }?.optBoolean("detailsExpanded")
        val explicitMacros = setLayoutObj?.takeIf { it.has("macrosDrawerOpen") && !it.isNull("macrosDrawerOpen") }?.optBoolean("macrosDrawerOpen")
            ?: json.takeIf { it.has("macrosDrawerOpen") && !it.isNull("macrosDrawerOpen") }?.optBoolean("macrosDrawerOpen")

        return applyHudStateInternal(
            nextState = merged,
            explicitCollapsed = explicitCollapsed,
            explicitDetailsExpanded = explicitDetails,
            explicitMacrosDrawerOpen = explicitMacros
        ).put("patched", true)
    }

    /**
     * Resets the HUD back to its clean default IDLE state, clearing all dynamic themes,
     * widgets, progress, metrics, banners, blocks, and tasks.
     */
    fun resetState(): JSONObject {
        isDetailsExpanded = false
        isMacrosDrawerOpen = false
        isOutputExpanded = false
        stopRecordedForCurrentRun = false
        return applyHudStateInternal(
            nextState = AgyHudState(),
            explicitCollapsed = false,
            explicitDetailsExpanded = false,
            explicitMacrosDrawerOpen = false
        ).put("reset", true)
    }

    private fun applyHudStateInternal(
        nextState: AgyHudState,
        explicitCollapsed: Boolean? = null,
        explicitDetailsExpanded: Boolean? = null,
        explicitMacrosDrawerOpen: Boolean? = null
    ): JSONObject {
        val prevSnapshot = _hudState.value
        val prevState = prevSnapshot.state
        _hudState.value = nextState

        if (explicitDetailsExpanded != null) {
            isDetailsExpanded = explicitDetailsExpanded
        }
        if (explicitMacrosDrawerOpen != null) {
            isMacrosDrawerOpen = explicitMacrosDrawerOpen
        }

        val now = System.currentTimeMillis()
        // Manage accumulated live elapsed timer across WORKING / PAUSED / NEEDS_INPUT / STOPPING / STOPPED / DONE
        when (nextState.state) {
            "WORKING" -> {
                if (prevState == "IDLE" || prevState == "DONE" || prevState == "STOPPED") {
                    accumulatedElapsedMs = 0L
                    _elapsedMsFlow.value = 0L
                    stopRecordedForCurrentRun = false
                }
                if (prevState != "WORKING" || activeSegmentStartMs == 0L) {
                    activeSegmentStartMs = now
                }
                startElapsedTimer()
            }
            "PAUSED", "NEEDS_INPUT", "STOPPING" -> {
                if (activeSegmentStartMs > 0L) {
                    accumulatedElapsedMs += (now - activeSegmentStartMs).coerceAtLeast(0L)
                    activeSegmentStartMs = 0L
                }
                _elapsedMsFlow.value = accumulatedElapsedMs
                stopElapsedTimer()
            }
            "STOPPED" -> {
                if (activeSegmentStartMs > 0L) {
                    accumulatedElapsedMs += (now - activeSegmentStartMs).coerceAtLeast(0L)
                    activeSegmentStartMs = 0L
                }
                _elapsedMsFlow.value = accumulatedElapsedMs
                stopElapsedTimer()
                if (prevState != "STOPPED" && !stopRecordedForCurrentRun) {
                    stopRecordedForCurrentRun = true
                    emitRunRecord(nextState, finalState = "STOPPED", durationMs = accumulatedElapsedMs)
                }
            }
            "DONE" -> {
                if (activeSegmentStartMs > 0L) {
                    accumulatedElapsedMs += (now - activeSegmentStartMs).coerceAtLeast(0L)
                    activeSegmentStartMs = 0L
                }
                _elapsedMsFlow.value = accumulatedElapsedMs
                stopElapsedTimer()
                if (prevState != "DONE") {
                    emitRunRecord(nextState, finalState = "DONE", durationMs = accumulatedElapsedMs)
                }
            }
            else -> {
                accumulatedElapsedMs = 0L
                activeSegmentStartMs = 0L
                _elapsedMsFlow.value = 0L
                stopRecordedForCurrentRun = false
                stopElapsedTimer()
            }
        }

        val hasPerm = hasOverlayPermission()
        val justCompleted = nextState.state == "DONE" && prevState != "DONE"

        if (explicitCollapsed != null) {
            isCollapsed = explicitCollapsed
            _isInputVisible.value = !explicitCollapsed && nextState.layout.showComposer
        } else {
            when (nextState.state) {
                "WORKING" -> {
                    if (prevState != "WORKING" && prevState != "PAUSED") {
                        isCollapsed = false
                        _isInputVisible.value = nextState.layout.showComposer
                    }
                }
                "PAUSED", "STOPPING" -> {
                    // Preserve current collapsed/expanded posture when pausing or stopping
                }
                "NEEDS_INPUT" -> {
                    isCollapsed = false
                    _isInputVisible.value = nextState.layout.showComposer
                }
                "DONE", "IDLE", "STOPPED" -> {
                    if (nextState.autoCollapseSeconds <= 0 && !isOutputExpanded && !isInputFocused) {
                        isCollapsed = true
                        _isInputVisible.value = false
                    }
                }
            }
        }

        if (hasPerm) {
            runOnMain {
                ensureHudWindowAttached()
                when (nextState.state) {
                    "WORKING" -> {
                        cancelAutoCollapse()
                        if (explicitCollapsed == null && prevState != "WORKING" && prevState != "PAUSED") {
                            isCollapsed = false
                            _isInputVisible.value = nextState.layout.showComposer
                        }
                    }
                    "PAUSED", "STOPPING" -> {
                        cancelAutoCollapse()
                    }
                    "NEEDS_INPUT" -> {
                        cancelAutoCollapse()
                        if (explicitCollapsed == null) {
                            isCollapsed = false
                            _isInputVisible.value = nextState.layout.showComposer
                            if (nextState.layout.showComposer) {
                                focusInlineComposerInternal(requestKeyboardFocus = true)
                            }
                        }
                    }
                    "STOPPED" -> {
                        cancelAutoCollapse()
                        blurInlineComposerInternal()
                        if (explicitCollapsed == null && nextState.autoCollapseSeconds > 0 && !isOutputExpanded) {
                            scheduleAutoCollapse(nextState.autoCollapseSeconds)
                        }
                    }
                    "DONE", "IDLE" -> {
                        if (justCompleted) {
                            hudExpandedContainer?.playCompletionPulse()
                        }
                        if (explicitCollapsed != null) {
                            cancelAutoCollapse()
                            if (explicitCollapsed) blurInlineComposerInternal()
                        } else if (isOutputExpanded || isInputFocused) {
                            cancelAutoCollapse()
                        } else if (nextState.autoCollapseSeconds > 0) {
                            scheduleAutoCollapse(nextState.autoCollapseSeconds)
                        } else {
                            isCollapsed = true
                            blurInlineComposerInternal()
                        }
                    }
                }
                applyDynamicWindowGeometryInternal(nextState)
                renderHudWindow()
                syncPulseAnimation()
            }
        } else if ((nextState.state == "DONE" || nextState.state == "IDLE") && nextState.autoCollapseSeconds > 0 && !isOutputExpanded) {
            runOnMain { scheduleAutoCollapse(nextState.autoCollapseSeconds) }
        }

        return JSONObject().apply {
            put("success", true)
            put("overlayRendered", hasPerm)
            if (!hasPerm) {
                put("permissionRequired", true)
                put("warning", "SYSTEM_ALERT_WINDOW not granted; HUD state stored in memory only.")
            }
            put("state", nextState.state)
            put("hudVisible", _isHudVisible.value)
            put("inputVisible", _isInputVisible.value)
            put("collapsed", isCollapsed)
            put("detailsExpanded", isDetailsExpanded)
            put("outputExpanded", isOutputExpanded)
            put("taskCount", nextState.tasks.size)
            put("metricCount", nextState.metrics.size)
            put("blockCount", nextState.blocks.size)
            put("screenWatchActive", nextState.screenWatch.active)
        }
    }

    /**
     * Shows the compact HUD pill (or expands it) directly from the in-app Settings toggle.
     */
    fun showCompactPill(): Boolean {
        if (!hasOverlayPermission()) return false
        runOnMain {
            isCollapsed = true
            ensureHudWindowAttached()
            renderHudWindow()
        }
        return true
    }

    /**
     * Handles POST /api/hud/command:
     * - action = PROMPT / STOP / FORCE_STOP / PAUSE / RESUME / CUSTOM: enqueues command + broadcasts HUD_COMMAND via WebSocket
     * - action = OPEN_INPUT / CLOSE_INPUT / EXPAND / COLLAPSE / TOGGLE_GHOST / CYCLE_OPACITY / PATCH / RESET
     */
    fun handleRemoteCommand(json: JSONObject): JSONObject {
        val action = json.optString("action", "PROMPT").uppercase().trim()
        val text = json.optString("text", json.optString("prompt", "")).trim()
        val buttonId = json.optString("buttonId", json.optString("id", "")).trim()
        val payload = json.optJSONObject("payload")
        val result = JSONObject()

        when (action) {
            "OPEN_INPUT" -> {
                val autoFocus = json.optBoolean("focus", true)
                cancelAutoCollapse()
                isCollapsed = false
                _isInputVisible.value = true
                if (!hasOverlayPermission()) {
                    return result.put("success", true).put("action", action)
                        .put("collapsed", false)
                        .put("inputVisible", true).put("sandboxOnly", true)
                }
                runOnMain {
                    ensureHudWindowAttached()
                    renderHudWindow()
                    focusInlineComposerInternal(requestKeyboardFocus = autoFocus)
                }
                result.put("success", true).put("action", action)
                    .put("collapsed", false).put("inputVisible", true)
            }
            "CLOSE_INPUT" -> {
                runOnMain { blurInlineComposerInternal() }
                _isInputVisible.value = false
                result.put("success", true).put("action", action).put("inputVisible", false)
            }
            "EXPAND" -> {
                cancelAutoCollapse()
                isCollapsed = false
                _isInputVisible.value = true
                if (hasOverlayPermission()) {
                    runOnMain {
                        ensureHudWindowAttached()
                        renderHudWindow()
                    }
                }
                result.put("success", true).put("action", action)
                    .put("collapsed", false).put("inputVisible", true)
            }
            "COLLAPSE" -> {
                isCollapsed = true
                _isInputVisible.value = false
                runOnMain {
                    blurInlineComposerInternal()
                    if (hudRootView != null) renderHudWindow()
                }
                result.put("success", true).put("action", action)
                    .put("collapsed", true).put("inputVisible", false)
            }
            "PATCH" -> {
                return patchState(json)
            }
            "RESET" -> {
                return resetState()
            }
            "TOGGLE_GHOST" -> {
                val enabled = if (json.has("enabled")) json.optBoolean("enabled") else !ghostPassThrough
                runOnMain { setGhostModeInternal(enabled) }
                result.put("success", true).put("action", action).put("ghostPassThrough", enabled)
            }
            "TOGGLE_WIREFRAME" -> {
                val enabled = if (json.has("enabled")) json.optBoolean("enabled") else !wireframeEnabled
                wireframeEnabled = enabled
                runOnMain { if (hudRootView != null) renderHudWindow() }
                result.put("success", true).put("action", action).put("wireframeEnabled", enabled)
            }
            "TOGGLE_EDGE_SNAP" -> {
                val enabled = if (json.has("enabled")) json.optBoolean("enabled") else !edgeSnapEnabled
                edgeSnapEnabled = enabled
                runOnMain {
                    if (hudRootView != null) {
                        if (enabled) snapHudToNearestEdge()
                        renderHudWindow()
                    }
                }
                result.put("success", true).put("action", action).put("edgeSnapEnabled", enabled)
            }
            "TOGGLE_OUTPUT" -> {
                val expanded = if (json.has("expanded")) json.optBoolean("expanded") else !isOutputExpanded
                setOutputExpanded(expanded)
                result.put("success", true).put("action", action).put("outputExpanded", expanded)
            }
            "TOGGLE_DETAILS" -> {
                val expanded = if (json.has("expanded")) json.optBoolean("expanded") else !isDetailsExpanded
                isDetailsExpanded = expanded
                runOnMain { if (hudRootView != null) renderHudWindow() }
                result.put("success", true).put("action", action).put("detailsExpanded", expanded)
            }
            "COPY_OUTPUT" -> {
                val copied = copyDetailedOutputToClipboard()
                result.put("success", copied).put("action", action)
            }
            "CYCLE_OPACITY" -> {
                runOnMain { cycleOpacityInternal() }
                result.put("success", true).put("action", action)
                    .put("opacity", OPACITY_LEVELS[opacityIndex].toDouble())
            }
            "PAUSE" -> {
                val cmd = enqueueAndBroadcastCommand(text = text.ifBlank { "PAUSE" }, action = "PAUSE")
                if (_hudState.value.state == "WORKING") {
                    updateState(JSONObject().put("state", "PAUSED"))
                }
                result.put("success", true).put("command", cmd.toJson()).put("state", _hudState.value.state)
            }
            "RESUME" -> {
                val cmd = enqueueAndBroadcastCommand(text = text.ifBlank { "RESUME" }, action = "RESUME")
                if (_hudState.value.state == "PAUSED") {
                    updateState(JSONObject().put("state", "WORKING"))
                }
                result.put("success", true).put("command", cmd.toJson()).put("state", _hudState.value.state)
            }
            "STOP" -> {
                val current = _hudState.value
                when (current.state) {
                    "STOPPING" -> {
                        // Stage 2: Second tap while already STOPPING -> immediate local Force-Stop
                        val cmd = enqueueAndBroadcastCommand(
                            text = text.ifBlank { "FORCE_STOP" },
                            action = "FORCE_STOP"
                        )
                        val stoppedTasks = current.tasks.map { task ->
                            if (task.status == "doing" || task.status == "needs_input") {
                                task.copy(status = "stopped")
                            } else task
                        }
                        applyHudStateInternal(
                            current.copy(
                                state = "STOPPED",
                                statusLabel = "",
                                currentAction = "Stopped by user",
                                tasks = stoppedTasks
                            )
                        )
                        result.put("success", true)
                            .put("command", cmd.toJson())
                            .put("state", _hudState.value.state)
                            .put("stage", "FORCE_STOPPED")
                    }
                    "WORKING", "PAUSED", "NEEDS_INPUT" -> {
                        // Stage 1: Graceful stop request -> show Stopping… immediately, tap again to force-stop
                        val cmd = enqueueAndBroadcastCommand(
                            text = text.ifBlank { "STOP" },
                            action = "STOP"
                        )
                        applyHudStateInternal(
                            current.copy(
                                state = "STOPPING",
                                currentAction = "Stopping… tap Stop again to force-stop"
                            )
                        )
                        result.put("success", true)
                            .put("command", cmd.toJson())
                            .put("state", _hudState.value.state)
                            .put("stage", "STOPPING")
                    }
                    else -> {
                        val cmd = enqueueAndBroadcastCommand(text = text.ifBlank { "STOP" }, action = "STOP")
                        result.put("success", true)
                            .put("command", cmd.toJson())
                            .put("state", _hudState.value.state)
                            .put("stage", "IDLE")
                    }
                }
            }
            "FORCE_STOP" -> {
                val current = _hudState.value
                val cmd = enqueueAndBroadcastCommand(
                    text = text.ifBlank { "FORCE_STOP" },
                    action = "FORCE_STOP"
                )
                val stoppedTasks = current.tasks.map { task ->
                    if (task.status == "doing" || task.status == "needs_input") {
                        task.copy(status = "stopped")
                    } else task
                }
                applyHudStateInternal(
                    current.copy(
                        state = "STOPPED",
                        statusLabel = "",
                        currentAction = "Stopped by user",
                        tasks = stoppedTasks
                    )
                )
                result.put("success", true)
                    .put("command", cmd.toJson())
                    .put("state", _hudState.value.state)
                    .put("stage", "FORCE_STOPPED")
            }
            "CUSTOM", "CUSTOM_ACTION" -> {
                val cmd = enqueueAndBroadcastCommand(
                    text = text.ifBlank { buttonId.ifBlank { "CUSTOM" } },
                    action = "CUSTOM",
                    buttonId = buttonId,
                    payload = payload
                )
                result.put("success", true).put("command", cmd.toJson())
            }
            else -> {
                if (text.isEmpty()) {
                    return result.put("success", false).put("error", "Missing 'text' for PROMPT command")
                }
                val cmd = enqueueAndBroadcastCommand(
                    text = text,
                    action = "PROMPT",
                    buttonId = buttonId,
                    payload = payload
                )
                result.put("success", true).put("command", cmd.toJson())
            }
        }
        return result
    }

    /**
     * Enqueues a HUD_COMMAND into the thread-safe queue for GET /api/hud/poll and immediately
     * pushes it to connected WebSocket clients.
     */
    fun enqueueAndBroadcastCommand(
        text: String,
        action: String = "PROMPT",
        buttonId: String = "",
        payload: JSONObject? = null
    ): HudCommand {
        val normalizedAction = when (action.uppercase().trim()) {
            "STOP" -> "STOP"
            "FORCE_STOP" -> "FORCE_STOP"
            "PAUSE" -> "PAUSE"
            "RESUME" -> "RESUME"
            "CUSTOM", "CUSTOM_ACTION" -> "CUSTOM"
            else -> "PROMPT"
        }
        if (normalizedAction == "PROMPT" && text.isNotBlank()) {
            lastSubmittedPrompt = text.trim()
        } else if (normalizedAction == "STOP" || normalizedAction == "FORCE_STOP") {
            val activeSnapshot = _hudState.value
            val wasActive = activeSnapshot.state == "WORKING" ||
                activeSnapshot.state == "PAUSED" ||
                activeSnapshot.state == "NEEDS_INPUT" ||
                activeSnapshot.state == "STOPPING"
            if (wasActive && !stopRecordedForCurrentRun) {
                stopRecordedForCurrentRun = true
                val elapsedNow = computeCurrentElapsedMs()
                emitRunRecord(activeSnapshot, finalState = "STOPPED", durationMs = elapsedNow)
            }
        }
        val cmd = HudCommand(
            text = text,
            action = normalizedAction,
            buttonId = buttonId,
            payload = payload
        )
        while (commandQueue.size >= MAX_QUEUED_COMMANDS) {
            commandQueue.poll()
        }
        commandQueue.offer(cmd)
        try {
            onCommandBroadcast?.invoke(cmd.toJson())
        } catch (e: Exception) {
            Log.w(TAG, "Failed broadcasting HUD_COMMAND: ${e.message}")
        }
        return cmd
    }

    /**
     * Handles GET /api/hud/poll: atomically drains all pending commands typed in Window 1.
     */
    fun pollCommands(): JSONObject {
        val drained = JSONArray()
        while (true) {
            val next = commandQueue.poll() ?: break
            drained.put(next.toJson())
        }
        return JSONObject().apply {
            put("success", true)
            put("count", drained.length())
            put("commands", drained)
            put("hudVisible", _isHudVisible.value)
            put("inputVisible", _isInputVisible.value)
            put("collapsed", isCollapsed)
            put("state", _hudState.value.state)
            put("ghostPassThrough", ghostPassThrough)
            put("opacity", (_hudState.value.theme.opacity ?: OPACITY_LEVELS[opacityIndex]).toDouble())
        }
    }

    fun setOutputExpanded(expanded: Boolean) {
        isOutputExpanded = expanded
        if (expanded) {
            cancelAutoCollapse()
            if (isCollapsed) isCollapsed = false
            isDetailsExpanded = true
        }
        runOnMain {
            if (hudRootView != null) renderHudWindow()
        }
    }

    fun getFullOutputCopyText(state: AgyHudState = _hudState.value): String {
        val sb = StringBuilder()
        if (state.detailedOutput.isNotBlank()) {
            sb.append(state.detailedOutput.trim())
        }
        if (state.outputLogs.isNotEmpty()) {
            if (sb.isNotEmpty()) sb.append("\n\n--- Execution Log ---\n")
            sb.append(state.outputLogs.joinToString("\n"))
        }
        if (sb.isEmpty() && state.currentAction.isNotBlank()) {
            sb.append("${state.title}: ${state.currentAction}")
        }
        return sb.toString().trim()
    }

    fun copyDetailedOutputToClipboard(): Boolean {
        val content = getFullOutputCopyText()
        if (content.isBlank()) return false
        return try {
            val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
            cm?.setPrimaryClip(ClipData.newPlainText("Agy Output", content))
            runOnMain {
                outputCopyBtn?.text = "Copied ✓"
                outputCopyBtn?.setTextColor(COLOR_EMERALD)
                copyFeedbackResetRunnable?.let { mainHandler.removeCallbacks(it) }
                val reset = Runnable {
                    outputCopyBtn?.text = "Copy"
                    outputCopyBtn?.setTextColor(COLOR_CYAN)
                }
                copyFeedbackResetRunnable = reset
                mainHandler.postDelayed(reset, 1600L)
            }
            true
        } catch (_: Exception) {
            false
        }
    }

    fun resolveQuickActions(state: AgyHudState): List<QuickActionChip> {
        if (state.quickActions.isNotEmpty()) return state.quickActions
        val hasOutput = state.detailedOutput.isNotBlank() || state.outputLogs.isNotEmpty()
        return when (state.state) {
            "NEEDS_INPUT" -> listOf(
                QuickActionChip("Yes, proceed", "Yes, proceed", "PROMPT", style = "primary"),
                QuickActionChip("Skip step", "Skip this step", "PROMPT"),
                QuickActionChip("Cancel", "STOP", "STOP", style = "danger")
            )
            "DONE" -> buildList {
                if (hasOutput) {
                    add(QuickActionChip("Copy Output", "", "COPY_OUTPUT", style = "primary"))
                    add(QuickActionChip(if (isOutputExpanded) "Hide Output" else "View Output", "", "TOGGLE_OUTPUT"))
                }
                add(QuickActionChip("Run Again", "Run again: ${state.title}", "PROMPT"))
            }
            "STOPPING" -> listOf(
                QuickActionChip("Force Stop", "FORCE_STOP", "FORCE_STOP", style = "danger")
            )
            "STOPPED" -> buildList {
                if (hasOutput) {
                    add(QuickActionChip("Copy Output", "", "COPY_OUTPUT"))
                }
                add(QuickActionChip("Run Again", "Run again: ${state.title}", "PROMPT", style = "primary"))
            }
            "WORKING" -> buildList {
                add(QuickActionChip("Pause", "PAUSE", "PAUSE"))
                if (hasOutput) {
                    add(QuickActionChip(if (isOutputExpanded) "Hide Output" else "Live Output", "", "TOGGLE_OUTPUT"))
                }
                add(QuickActionChip("Stop", "STOP", "STOP", style = "danger"))
            }
            "PAUSED" -> buildList {
                add(QuickActionChip("Resume", "RESUME", "RESUME", style = "primary"))
                if (hasOutput) {
                    add(QuickActionChip(if (isOutputExpanded) "Hide Output" else "Output", "", "TOGGLE_OUTPUT"))
                }
                add(QuickActionChip("Stop", "STOP", "STOP", style = "danger"))
            }
            else -> emptyList()
        }
    }

    fun resolveCollapsedRunningStep(state: AgyHudState = _hudState.value): CollapsedRunningStep {
        val activeDoingTask = state.tasks.firstOrNull { it.status == "doing" }
        val stepLabel = when {
            state.state == "STOPPING" -> "Stopping… tap ■ to force-stop"
            activeDoingTask != null && activeDoingTask.label.isNotBlank() -> activeDoingTask.label.trim()
            state.currentAction.isNotBlank() -> state.currentAction.trim()
            state.title.isNotBlank() -> state.title.trim()
            else -> if (state.state == "PAUSED") "Paused" else "Working"
        }
        val resolvedIcon = AgyAppIconResolver.resolve(
            context = context,
            explicitIcon = activeDoingTask?.icon?.ifBlank { state.icon } ?: state.icon,
            explicitPackage = activeDoingTask?.appPackage?.ifBlank { state.appPackage } ?: state.appPackage,
            fallbackText = "${activeDoingTask?.label.orEmpty()} ${activeDoingTask?.detail.orEmpty()} ${state.currentAction} ${state.title}"
        )
        return CollapsedRunningStep(label = stepLabel, icon = resolvedIcon)
    }

    fun isCollapsedLiveRunningMode(
        state: AgyHudState = _hudState.value,
        collapsed: Boolean = isCollapsed
    ): Boolean = collapsed && (state.state == "WORKING" || state.state == "PAUSED" || state.state == "STOPPING")

    private fun computeCurrentElapsedMs(): Long {
        val extra = if (activeSegmentStartMs > 0L) {
            (System.currentTimeMillis() - activeSegmentStartMs).coerceAtLeast(0L)
        } else 0L
        return (accumulatedElapsedMs + extra).coerceAtLeast(0L)
    }

    private fun emitRunRecord(state: AgyHudState, finalState: String, durationMs: Long) {
        val cb = onRunRecorded ?: return
        val activeStep = resolveCollapsedRunningStep(state)
        try {
            cb.invoke(
                RunRecord(
                    title = state.title.ifBlank { activeStep.label },
                    promptText = lastSubmittedPrompt.ifBlank { state.title },
                    finalState = finalState,
                    iconHint = state.icon.ifBlank { activeStep.icon.kind.name.lowercase(Locale.US) },
                    appPackage = state.appPackage.ifBlank { activeStep.icon.packageName.orEmpty() },
                    durationMs = durationMs.coerceAtLeast(0L),
                    stepCount = state.tasks.size,
                    detailedOutput = state.detailedOutput.ifBlank { state.currentAction },
                    outputLogs = state.outputLogs
                )
            )
        } catch (e: Exception) {
            Log.w(TAG, "Failed recording run history: ${e.message}")
        }
    }

    fun formatElapsed(ms: Long, isDone: Boolean = false): String {
        val safe = ms.coerceAtLeast(0L)
        val totalSec = safe / 1000.0
        return if (isDone) {
            String.format(Locale.US, "Done %.1fs", totalSec)
        } else if (safe < 60_000L) {
            String.format(Locale.US, "00:%04.1f", totalSec)
        } else {
            val mins = safe / 60_000L
            val secs = (safe % 60_000L) / 1000L
            String.format(Locale.US, "%02d:%02d", mins, secs)
        }
    }

    /**
     * Handles POST /api/hud/hide: dismisses both HUD windows cleanly and cancels timers.
     */
    fun hideAll(): JSONObject {
        runOnMain {
            cancelAutoCollapse()
            stopPulseAnimation()
            stopElapsedTimer()
            stopAllLoadingAnimations()
            edgeSnapAnimator?.cancel()
            edgeSnapAnimator = null
            voiceController?.release()
            voiceController = null
            _isVoiceListeningFlow.value = false
            copyFeedbackResetRunnable?.let { mainHandler.removeCallbacks(it) }
            passThroughRestoreRunnable?.let { mainHandler.removeCallbacks(it) }
            temporaryPassThroughActive = false
            ghostPassThrough = false
            isOutputExpanded = false
            isToolsTrayOpen = false
            lastCollapsedStepLabel = ""
            lastRenderedCollapsedState = null
            lastRenderedTitle = ""
            lastRenderedTaskStatuses = emptyMap()
            hideGhostRestorePillInternal()
            blurInlineComposerInternal()
            hudRootView?.let { view ->
                try {
                    windowManager?.removeView(view)
                } catch (e: Exception) {
                    Log.w(TAG, "Error removing agy_hud: ${e.message}")
                }
            }
            hudRootView = null
            hudParams = null
            hudExpandedContainer = null
            hudBottomDockRow = null
            workingLoadingBar = null
            headerAppIconView = null
            headerSpinnerView = null
            elapsedTimerText = null
            toolsMenuBtn = null
            toolsTrayContainer = null
            edgeSnapBtn = null
            doingDotsView = null
            outputSectionContainer = null
            outputToggleHeaderText = null
            outputDrawerContainer = null
            outputCopyBtn = null
            outputBodyText = null
            quickActionsScrollView = null
            quickActionsContainer = null
            dockStandardStatusGroup = null
            dockStandardDivider = null
            dockSpinnerView = null
            collapsedStatusText = null
            bottomChatPillBtn = null
            dockLiveStepGroup = null
            dockLiveSpinnerView = null
            dockLiveIconView = null
            dockLiveStepText = null
            dockLiveTimerText = null
            dockLiveStopBtn = null
            telemetryDetailsContainer = null
            stepsTogglePill = null
            headerCollapseBtn = null
            customEmojiView = null
            progressRowContainer = null
            progressBarView = null
            progressCaptionText = null
            metricsScrollView = null
            metricsContainer = null
            dynamicBannerContainer = null
            dynamicBannerTitleText = null
            dynamicBannerMsgText = null
            inlineBlocksContainer = null
            detailBlocksContainer = null
            composerDividerView = null
            isDetailsExpanded = false
            isMacrosDrawerOpen = false
            savedYBeforeIme = null
            isTemporarilySuppressed = false
            inlineComposerContainer = null
            composerInputCapsule = null
            composerVoiceStatusHint = null
            inputEditText = null
            inputMicBtn = null
            clearDraftBtn = null
            macrosToggleBtn = null
            composerActionBtn = null
            inputMacrosScrollView = null
            inputMacrosContainer = null
            isInputFocused = false
            _isInputVisible.value = false
            _isHudVisible.value = false
        }
        return JSONObject().apply {
            put("success", true)
            put("hudVisible", false)
            put("inputVisible", false)
        }
    }

    private fun stopAllLoadingAnimations() {
        hudExpandedContainer?.stopAurora()
        workingLoadingBar?.setAnimating(false)
        headerSpinnerView?.setAnimating(false)
        doingDotsView?.setAnimating(false)
        dockSpinnerView?.setAnimating(false)
        dockLiveSpinnerView?.setAnimating(false)
    }

    // -------------------------------------------------------------------------
    // Touch Collision Pass-Through Helpers (called by DeviceBridgeManager)
    // -------------------------------------------------------------------------

    fun getOverlayBounds(): List<Rect> {
        val rects = mutableListOf<Rect>()
        val screenW = context.resources.displayMetrics.widthPixels.coerceAtLeast(1080)
        val screenH = context.resources.displayMetrics.heightPixels.coerceAtLeast(1920)

        fun collectRect(view: View?, params: WindowManager.LayoutParams?) {
            if (view == null || params == null) return
            val loc = IntArray(2)
            view.getLocationOnScreen(loc)
            val w = view.width.takeIf { it > 0 } ?: (260 * density()).toInt()
            val h = view.height.takeIf { it > 0 } ?: (96 * density()).toInt()
            val left = if (loc[0] != 0 || loc[1] != 0) {
                loc[0]
            } else if ((params.gravity and Gravity.END) == Gravity.END || (params.gravity and Gravity.RIGHT) == Gravity.RIGHT) {
                (screenW - params.x - w).coerceAtLeast(0)
            } else {
                params.x.coerceAtLeast(0)
            }
            val top = if (loc[0] != 0 || loc[1] != 0) {
                loc[1]
            } else if ((params.gravity and Gravity.BOTTOM) == Gravity.BOTTOM) {
                (screenH - params.y - h).coerceAtLeast(0)
            } else {
                params.y.coerceAtLeast(0)
            }
            rects.add(Rect(left, top, left + w, top + h))
        }

        collectRect(hudRootView, hudParams)
        collectRect(ghostRestoreView, ghostRestoreParams)
        return rects
    }

    fun coordinatesOverlapRects(
        x1: Float,
        y1: Float,
        x2: Float = x1,
        y2: Float = y1,
        rects: List<Rect>
    ): Boolean {
        if (rects.isEmpty()) return false
        val segRect = Rect(
            min(x1, x2).toInt(),
            min(y1, y2).toInt(),
            max(x1, x2).toInt() + 1,
            max(y1, y2).toInt() + 1
        )
        return rects.any { r ->
            r.contains(x1.toInt(), y1.toInt()) ||
                r.contains(x2.toInt(), y2.toInt()) ||
                Rect.intersects(r, segRect)
        }
    }

    /**
     * Checks if a gesture (TAP/SWIPE/DRAG) overlaps agy_hud or agy_input; if so, temporarily
     * applies FLAG_NOT_TOUCHABLE for ~durationMs (default 300ms) so touch passes directly underneath.
     */
    fun temporarilyPassThroughIfColliding(
        x1: Float,
        y1: Float,
        x2: Float = x1,
        y2: Float = y1,
        durationMs: Long = 300L
    ): Boolean {
        if (!_isHudVisible.value && !_isInputVisible.value) return false
        val bounds = getOverlayBounds()
        if (!coordinatesOverlapRects(x1, y1, x2, y2, bounds)) return false

        val safeDuration = durationMs.coerceIn(250L, 2500L)
        val latch = CountDownLatch(1)
        val applyTask = Runnable {
            try {
                temporaryPassThroughActive = true
                applyTouchableFlagsInternal(touchable = false)
                passThroughRestoreRunnable?.let { mainHandler.removeCallbacks(it) }
                val restore = Runnable {
                    temporaryPassThroughActive = false
                    if (!ghostPassThrough) {
                        applyTouchableFlagsInternal(touchable = true)
                    }
                }
                passThroughRestoreRunnable = restore
                mainHandler.postDelayed(restore, safeDuration)
            } finally {
                latch.countDown()
            }
        }
        if (Looper.myLooper() == Looper.getMainLooper()) {
            applyTask.run()
        } else {
            mainHandler.post(applyTask)
            try {
                latch.await(150L, TimeUnit.MILLISECONDS)
            } catch (_: InterruptedException) {}
        }
        return true
    }

    // -------------------------------------------------------------------------
    // Window 2: Live Task & Screen HUD (`agy_hud`)
    // -------------------------------------------------------------------------

    private fun ensureHudWindowAttached() {
        if (hudRootView != null) {
            _isHudVisible.value = true
            return
        }
        val wm = windowManager ?: return
        val d = density()

        val root = HoldDraggableDockLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.END
            clipChildren = false
            clipToPadding = false
        }
        val expanded = buildExpandedHudCard(d)
        val bottomDock = buildBottomChatDockRow(d)
        root.addView(expanded)
        root.addView(bottomDock)
        tagTreeForSelfExclusion(root, "window2")

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayWindowType(),
            // Start with FLAG_NOT_FOCUSABLE so Termux keeps keyboard focus until user taps the built-in bottom field.
            // Omit FLAG_LAYOUT_IN_SCREEN so Android automatically insets the bottom-anchored card cleanly above the soft keyboard!
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.END
            x = (14 * d).toInt()
            y = (16 * d).toInt()
            @Suppress("DEPRECATION")
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        }

        hudRootView = root
        hudParams = params
        hudExpandedContainer = expanded
        hudBottomDockRow = bottomDock

        // Tapping outside the unified card releases keyboard focus straight back to Termux
        root.onOutsideTouch = {
            if (isInputFocused) {
                releaseInputFocusToTermux()
            }
        }

        // Hold anywhere (~180ms) on the unified card or collapsed pill to drag cleanly
        root.onDragDelta = { dx, dy ->
            edgeSnapAnimator?.cancel()
            shiftBottomRightWindow(root, params, dx, dy)
        }
        root.onDragEnd = {
            if (edgeSnapEnabled) {
                snapHudToNearestEdge()
            }
        }
        // Horizontal flick across expanded card smoothly springs into the compact pill
        root.onHorizontalSwipe = {
            if (!isCollapsed) {
                cancelAutoCollapse()
                isCollapsed = true
                isToolsTrayOpen = false
                blurInlineComposerInternal()
                renderHudWindow()
            }
        }

        try {
            wm.addView(root, params)
            _isHudVisible.value = true
        } catch (e: Exception) {
            Log.e(TAG, "Failed adding agy_hud window: ${e.message}")
            hudRootView = null
            hudParams = null
            hudExpandedContainer = null
            hudBottomDockRow = null
            _isHudVisible.value = false
        }
    }

    private fun buildExpandedHudCard(d: Float): AgyAuroraCardLayout {
        val cardWidthPx = min((304 * d).toInt(), (context.resources.displayMetrics.widthPixels * 0.90f).toInt())
        val container = AgyAuroraCardLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(cardWidthPx, ViewGroup.LayoutParams.WRAP_CONTENT)
            setPadding((14 * d).toInt(), (11 * d).toInt(), (14 * d).toInt(), (11 * d).toInt())
            elevation = 12f * d
            layoutTransition = LayoutTransition().apply {
                setDuration(220L)
                enableTransitionType(LayoutTransition.CHANGING)
            }
        }

        // Top Indeterminate Sliding Progress Bar (animates while state == WORKING)
        val loadBar = AgyLoadingBarView(context).apply {
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                (3.5f * d).toInt().coerceAtLeast(4)
            ).apply {
                bottomMargin = (8 * d).toInt()
            }
            visibility = View.GONE
        }
        workingLoadingBar = loadBar
        container.addView(loadBar)

        // Ultra-Clean Minimal Header: App/Task Icon + Single-Line Status & Timer + Only 2 Quiet Controls (··· & —)
        val header = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }

        val appIcon = AgyIconBadgeView(context).apply {
            val sz = (24 * d).toInt()
            layoutParams = LinearLayout.LayoutParams(sz, sz).apply { marginEnd = (8 * d).toInt() }
        }
        headerAppIconView = appIcon

        val emojiTv = TextView(context).apply {
            val sz = (24 * d).toInt()
            layoutParams = LinearLayout.LayoutParams(sz, sz).apply { marginEnd = (8 * d).toInt() }
            gravity = Gravity.CENTER
            textSize = 15f
            visibility = View.GONE
        }
        customEmojiView = emojiTv

        val statusTopRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }

        val headerSpinner = AgySpinnerRingView(context).apply {
            val sz = (12 * d).toInt()
            layoutParams = LinearLayout.LayoutParams(sz, sz).apply { marginEnd = (6 * d).toInt() }
            setAccentColor(COLOR_CYAN)
            visibility = View.GONE
        }
        headerSpinnerView = headerSpinner

        val dot = View(context).apply {
            val sz = (6 * d).toInt()
            layoutParams = LinearLayout.LayoutParams(sz, sz).apply { marginEnd = (6 * d).toInt() }
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(COLOR_CYAN)
            }
        }
        statusDotView = dot

        val badge = TextView(context).apply {
            text = "Ready"
            textSize = 11.5f
            setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
            setTextColor(COLOR_TEXT_PRIMARY)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        statusBadgeText = badge

        val timerTv = TextView(context).apply {
            text = ""
            textSize = 10.5f
            typeface = Typeface.MONOSPACE
            setTextColor(COLOR_TEXT_SECONDARY)
            maxLines = 1
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { marginStart = (6 * d).toInt() }
            visibility = View.GONE
        }
        elapsedTimerText = timerTv

        statusTopRow.addView(headerSpinner)
        statusTopRow.addView(dot)
        statusTopRow.addView(badge)
        statusTopRow.addView(timerTv)

        fun headerControlChip(symbol: String, desc: String, onClick: () -> Unit): TextView {
            return TextView(context).apply {
                text = symbol
                textSize = 12f
                gravity = Gravity.CENTER
                setTextColor(COLOR_TEXT_SECONDARY)
                val sz = (26 * d).toInt()
                layoutParams = LinearLayout.LayoutParams(sz, sz).apply { marginStart = (4 * d).toInt() }
                background = createLiquidGlassDrawable(
                    fillColor = Color.parseColor("#F3F4F6"),
                    strokeColor = Color.TRANSPARENT,
                    radiusDp = 999f,
                    strokeDp = 0f
                )
                contentDescription = "${HUD_NODE_TAG_PREFIX}$desc"
                setOnClickListener { onClick() }
            }
        }

        val stepsPill = TextView(context).apply {
            text = "Steps ▾"
            textSize = 10f
            setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
            setTextColor(COLOR_TEXT_SECONDARY)
            gravity = Gravity.CENTER
            setPadding((8 * d).toInt(), (4 * d).toInt(), (8 * d).toInt(), (4 * d).toInt())
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                (26 * d).toInt()
            ).apply { marginStart = (4 * d).toInt() }
            background = createLiquidGlassDrawable(
                fillColor = Color.parseColor("#F3F6FA"),
                strokeColor = COLOR_HAIRLINE,
                radiusDp = 999f,
                strokeDp = 0.7f
            )
            contentDescription = "${HUD_NODE_TAG_PREFIX}steps_toggle_btn"
            visibility = View.GONE
            attachSpringPressFeedback(0.93f)
            setOnClickListener {
                cancelAutoCollapse()
                isDetailsExpanded = !isDetailsExpanded
                if (isDetailsExpanded && isInputFocused) {
                    releaseInputFocusToTermux()
                }
                renderHudWindow()
            }
        }
        stepsTogglePill = stepsPill

        val moreBtn = headerControlChip("···", "tools_menu_btn") {
            isToolsTrayOpen = !isToolsTrayOpen
            renderHudWindow()
        }
        toolsMenuBtn = moreBtn

        val collapseBtn = headerControlChip("─", "collapse_btn") {
            isCollapsed = true
            isDetailsExpanded = false
            isMacrosDrawerOpen = false
            isOutputExpanded = false
            isToolsTrayOpen = false
            blurInlineComposerInternal()
            renderHudWindow()
        }
        headerCollapseBtn = collapseBtn

        header.addView(appIcon)
        header.addView(emojiTv)
        header.addView(statusTopRow)
        header.addView(stepsPill)
        header.addView(moreBtn)
        header.addView(collapseBtn)
        container.addView(header)

        // Hidden-by-default Secondary Controls Tray (revealed on tapping ···)
        val tray = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding((6 * d).toInt(), (5 * d).toInt(), (6 * d).toInt(), (5 * d).toInt())
            background = createLiquidGlassDrawable(
                fillColor = Color.parseColor("#F5F6F8"),
                strokeColor = COLOR_HAIRLINE,
                radiusDp = 12f,
                strokeDp = 0.7f
            )
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = (8 * d).toInt() }
            visibility = View.GONE
        }

        fun trayToolChip(label: String, desc: String, onClick: () -> Unit): TextView {
            return TextView(context).apply {
                text = label
                textSize = 10f
                gravity = Gravity.CENTER
                setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
                setTextColor(COLOR_TEXT_PRIMARY)
                setPadding((8 * d).toInt(), (4 * d).toInt(), (8 * d).toInt(), (4 * d).toInt())
                background = createLiquidGlassDrawable(
                    fillColor = Color.WHITE,
                    strokeColor = COLOR_HAIRLINE,
                    radiusDp = 999f,
                    strokeDp = 0.7f
                )
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                    marginStart = (2 * d).toInt()
                    marginEnd = (2 * d).toInt()
                }
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
                contentDescription = "${HUD_NODE_TAG_PREFIX}$desc"
                setOnClickListener { onClick() }
            }
        }

        val opBtn = trayToolChip("100%", "opacity_btn") { cycleOpacityInternal() }
        opacityBtn = opBtn
        val wfBtn = trayToolChip("Wireframe", "wireframe_toggle_btn") {
            wireframeEnabled = !wireframeEnabled
            renderHudWindow()
        }
        wireframeBtn = wfBtn
        val ghBtn = trayToolChip("Ghost", "ghost_toggle_btn") {
            setGhostModeInternal(!ghostPassThrough)
        }
        ghostBtn = ghBtn
        val snapBtn = trayToolChip("● Snap", "edge_snap_toggle_btn") {
            edgeSnapEnabled = !edgeSnapEnabled
            if (edgeSnapEnabled) snapHudToNearestEdge()
            renderHudWindow()
        }
        edgeSnapBtn = snapBtn

        tray.addView(opBtn)
        tray.addView(wfBtn)
        tray.addView(ghBtn)
        tray.addView(snapBtn)
        toolsTrayContainer = tray
        container.addView(tray)

        // Task Title
        val titleTv = TextView(context).apply {
            text = "Agy Ready"
            textSize = 14f
            setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
            setTextColor(COLOR_TEXT_PRIMARY)
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = (9 * d).toInt() }
        }
        titleText = titleTv
        container.addView(titleTv)

        // Quiet Question Prompt Banner (visible on NEEDS_INPUT)
        val questionTv = TextView(context).apply {
            textSize = 11.5f
            setTextColor(Color.parseColor("#B45309"))
            setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
            setPadding((10 * d).toInt(), (7 * d).toInt(), (10 * d).toInt(), (7 * d).toInt())
            background = createLiquidGlassDrawable(
                fillColor = Color.parseColor("#FEF3C7"),
                strokeColor = Color.parseColor("#FDE68A"),
                radiusDp = 12f,
                strokeDp = 0.8f
            )
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = (7 * d).toInt() }
            visibility = View.GONE
            setOnClickListener { focusInlineComposerInternal(requestKeyboardFocus = true) }
        }
        questionBannerText = questionTv
        container.addView(questionTv)

        // Doing Now row + animated 3 bouncing dots
        val doingRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = (4 * d).toInt() }
            visibility = View.GONE
        }
        val doingTv = TextView(context).apply {
            textSize = 11.5f
            setTypeface(Typeface.SANS_SERIF, Typeface.NORMAL)
            setTextColor(COLOR_TEXT_SECONDARY)
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        val bounceDots = AgyBouncingDotsView(context).apply {
            setAccentColor(COLOR_CYAN)
            layoutParams = LinearLayout.LayoutParams(
                (22 * d).toInt(),
                (12 * d).toInt()
            ).apply { marginStart = (4 * d).toInt() }
            visibility = View.GONE
        }
        doingRow.addView(doingTv)
        doingRow.addView(bounceDots)
        doingRowContainer = doingRow
        currentActionText = doingTv
        doingDotsView = bounceDots
        container.addView(doingRow)

        val nextTv = TextView(context).apply {
            textSize = 10.5f
            setTypeface(Typeface.SANS_SERIF, Typeface.NORMAL)
            setTextColor(COLOR_TEXT_SECONDARY)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = (2 * d).toInt() }
            visibility = View.GONE
        }
        nextActionText = nextTv
        container.addView(nextTv)

        // Dynamic Progress Strip (determinate 0..100% or labeled indeterminate)
        val progRow = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = (7 * d).toInt() }
            visibility = View.GONE
        }
        val progCaption = TextView(context).apply {
            textSize = 10.5f
            typeface = Typeface.MONOSPACE
            setTextColor(COLOR_TEXT_SECONDARY)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = (4 * d).toInt() }
        }
        val progBar = AgyLoadingBarView(context).apply {
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                (5 * d).toInt().coerceAtLeast(5)
            )
        }
        progRow.addView(progCaption)
        progRow.addView(progBar)
        progressRowContainer = progRow
        progressCaptionText = progCaption
        progressBarView = progBar
        container.addView(progRow)

        // Dynamic Live Metrics Strip (horizontal compact stat chips)
        val metricsRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        metricsContainer = metricsRow
        val metricsScroll = HorizontalScrollView(context).apply {
            isHorizontalScrollBarEnabled = false
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = (7 * d).toInt() }
            addView(metricsRow)
            visibility = View.GONE
        }
        metricsScrollView = metricsScroll
        container.addView(metricsScroll)

        // Dynamic Alert / Status Banner (info | success | warning | error)
        val bannerBox = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((10 * d).toInt(), (7 * d).toInt(), (10 * d).toInt(), (7 * d).toInt())
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = (7 * d).toInt() }
            visibility = View.GONE
        }
        val bannerTitleTv = TextView(context).apply {
            textSize = 11f
            setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        val bannerMsgTv = TextView(context).apply {
            textSize = 11f
            maxLines = 3
            ellipsize = TextUtils.TruncateAt.END
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = (1 * d).toInt() }
        }
        bannerBox.addView(bannerTitleTv)
        bannerBox.addView(bannerMsgTv)
        dynamicBannerContainer = bannerBox
        dynamicBannerTitleText = bannerTitleTv
        dynamicBannerMsgText = bannerMsgTv
        container.addView(bannerBox)

        // Dynamic Inline Custom Blocks (kv | code | text | progress with inDetails == false)
        val inlineBlocks = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            visibility = View.GONE
        }
        inlineBlocksContainer = inlineBlocks
        container.addView(inlineBlocks)

        // Collapsible Telemetry Details Wrapper (auto-compacts smoothly when the soft keyboard is open!)
        val telemetryWrap = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }
        telemetryDetailsContainer = telemetryWrap
        container.addView(telemetryWrap)

        // Dynamic Detail Custom Blocks (inDetails == true)
        val detailBlocks = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            visibility = View.GONE
        }
        detailBlocksContainer = detailBlocks
        telemetryWrap.addView(detailBlocks)

        // Clean Airy Task List Container inside compact ScrollView (with per-task real/vector icons)
        val tasksLayout = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }
        taskListContainer = tasksLayout

        val scroll = ScrollView(context).apply {
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = (8 * d).toInt() }
            isVerticalScrollBarEnabled = false
            addView(tasksLayout)
            visibility = View.GONE
        }
        taskScrollView = scroll
        telemetryWrap.addView(scroll)

        // Quiet Neutral Expandable Detailed Output Drawer inside Working Card
        val outSection = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = (8 * d).toInt() }
            visibility = View.GONE
        }

        val outToggleTv = TextView(context).apply {
            text = "Output ▾"
            textSize = 11f
            setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
            setTextColor(COLOR_TEXT_PRIMARY)
            setPadding((10 * d).toInt(), (6 * d).toInt(), (10 * d).toInt(), (6 * d).toInt())
            background = createLiquidGlassDrawable(
                fillColor = Color.parseColor("#F3F4F6"),
                strokeColor = COLOR_HAIRLINE,
                radiusDp = 12f,
                strokeDp = 0.7f
            )
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            contentDescription = "${HUD_NODE_TAG_PREFIX}toggle_output_btn"
            setOnClickListener { setOutputExpanded(!isOutputExpanded) }
        }
        outputToggleHeaderText = outToggleTv

        val outDrawer = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((10 * d).toInt(), (8 * d).toInt(), (10 * d).toInt(), (8 * d).toInt())
            background = createLiquidGlassDrawable(
                fillColor = Color.parseColor("#F8FAFC"),
                strokeColor = COLOR_HAIRLINE,
                radiusDp = 12f,
                strokeDp = 0.7f
            )
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = (5 * d).toInt() }
            visibility = View.GONE
        }

        val outToolbar = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = (5 * d).toInt() }
        }

        val outMetaLbl = TextView(context).apply {
            text = "OUTPUT & LOGS"
            textSize = 9f
            typeface = Typeface.MONOSPACE
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(COLOR_TEXT_SECONDARY)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }

        val copyBtn = TextView(context).apply {
            text = "Copy"
            textSize = 9.5f
            setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
            setTextColor(COLOR_CYAN)
            setPadding((9 * d).toInt(), (3 * d).toInt(), (9 * d).toInt(), (3 * d).toInt())
            background = createLiquidGlassDrawable(
                fillColor = Color.WHITE,
                strokeColor = COLOR_HAIRLINE,
                radiusDp = 999f,
                strokeDp = 0.8f
            )
            contentDescription = "${HUD_NODE_TAG_PREFIX}copy_output_btn"
            setOnClickListener { copyDetailedOutputToClipboard() }
        }
        outputCopyBtn = copyBtn
        outToolbar.addView(outMetaLbl)
        outToolbar.addView(copyBtn)

        val outBody = TextView(context).apply {
            textSize = 10f
            typeface = Typeface.MONOSPACE
            setTextColor(COLOR_TEXT_PRIMARY)
            setLineSpacing(2f * d, 1.0f)
        }
        outputBodyText = outBody

        val outScroll = ScrollView(context).apply {
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                (128 * d).toInt()
            )
            isVerticalScrollBarEnabled = true
            addView(outBody)
        }

        outDrawer.addView(outToolbar)
        outDrawer.addView(outScroll)
        outputDrawerContainer = outDrawer

        outSection.addView(outToggleTv)
        outSection.addView(outDrawer)
        outputSectionContainer = outSection
        telemetryWrap.addView(outSection)

        // Contextual Quick Action Chips Strip
        val qaRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        quickActionsContainer = qaRow

        val qaScroll = HorizontalScrollView(context).apply {
            isHorizontalScrollBarEnabled = false
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = (7 * d).toInt() }
            addView(qaRow)
            visibility = View.GONE
        }
        quickActionsScrollView = qaScroll
        telemetryWrap.addView(qaScroll)

        // Mini Low-Poly Screen Wireframe Section (collapses to 0dp / GONE when screenWatch.active == false)
        val wfBox = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding((8 * d).toInt(), (6 * d).toInt(), (8 * d).toInt(), (6 * d).toInt())
            background = createLiquidGlassDrawable(
                fillColor = COLOR_INNER_CAPSULE,
                strokeColor = COLOR_HAIRLINE,
                radiusDp = 16f,
                strokeDp = 0.9f
            )
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = (7 * d).toInt() }
            visibility = View.GONE
        }

        val wfView = MiniScreenWireframeView(context)
        wireframeView = wfView

        val wfCaption = TextView(context).apply {
            textSize = 10f
            typeface = Typeface.MONOSPACE
            setTextColor(COLOR_TEXT_SECONDARY)
            maxLines = 3
            ellipsize = TextUtils.TruncateAt.END
            layoutParams = LinearLayout.LayoutParams(
                0,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                1f
            ).apply { marginStart = (10 * d).toInt() }
        }
        wireframeLabelText = wfCaption

        wfBox.addView(wfView)
        wfBox.addView(wfCaption)
        wireframeContainer = wfBox
        telemetryWrap.addView(wfBox)

        // ---------------------------------------------------------------------
        // Built-In Gemini Bottom Composer Dock (Unified Inside Single HUD Card)
        // ---------------------------------------------------------------------
        val composerDivider = View(context).apply {
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                (0.85f * d).toInt().coerceAtLeast(1)
            ).apply {
                topMargin = (10 * d).toInt()
                bottomMargin = (8 * d).toInt()
            }
            setBackgroundColor(COLOR_HAIRLINE)
        }
        container.addView(composerDivider)

        val composerBox = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }
        inlineComposerContainer = composerBox

        // Horizontal Pinned Macros / Saved Workflow Shortcuts right above the text field
        val macroRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        inputMacrosContainer = macroRow
        val macroScroll = HorizontalScrollView(context).apply {
            isHorizontalScrollBarEnabled = false
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = (7 * d).toInt() }
            addView(macroRow)
            visibility = View.GONE
        }
        inputMacrosScrollView = macroScroll
        composerBox.addView(macroScroll)
        renderInputMacrosStrip()

        // Optional Voice Listening / Error Micro-Banner
        val voiceHintTv = TextView(context).apply {
            text = "● Listening…"
            textSize = 10f
            typeface = Typeface.MONOSPACE
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(COLOR_CORAL)
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = (5 * d).toInt()
                marginStart = (4 * d).toInt()
            }
            visibility = View.GONE
        }
        composerVoiceStatusHint = voiceHintTv
        composerBox.addView(voiceHintTv)

        // Gemini-style Integrated Bottom Text Field Capsule: [Mic] [Ask Agy…] [Paste/Clear] [↑ / ■]
        val capsule = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding((5 * d).toInt(), (4 * d).toInt(), (5 * d).toInt(), (4 * d).toInt())
            background = createLiquidGlassDrawable(
                fillColor = Color.parseColor("#F5F7FA"),
                strokeColor = COLOR_HAIRLINE,
                radiusDp = 999f,
                strokeDp = 1.0f
            )
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }
        composerInputCapsule = capsule

        val micBtn = AgyGlyphButtonView(context, AgyGlyphButtonView.Glyph.MIC).apply {
            val sz = (32 * d).toInt()
            layoutParams = LinearLayout.LayoutParams(sz, sz).apply { marginEnd = (4 * d).toInt() }
            setStyle(
                glyph = AgyGlyphButtonView.Glyph.MIC,
                bgFill = Color.WHITE,
                bgStroke = COLOR_HAIRLINE,
                iconTint = COLOR_TEXT_SECONDARY,
                strokeDp = 0.85f
            )
            contentDescription = "${HUD_NODE_TAG_PREFIX}voice_mic_btn"
            attachSpringPressFeedback(0.92f)
            setOnClickListener {
                cancelAutoCollapse()
                toggleVoiceDictationInternal()
            }
        }
        inputMicBtn = micBtn

        val editText = EditText(context).apply {
            hint = "Ask Agy…"
            setHintTextColor(Color.parseColor("#94A3B8"))
            setTextColor(COLOR_TEXT_PRIMARY)
            textSize = 12.5f
            isSingleLine = true
            imeOptions = EditorInfo.IME_ACTION_SEND
            setPadding((6 * d).toInt(), (7 * d).toInt(), (4 * d).toInt(), (7 * d).toInt())
            background = null
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            contentDescription = "${HUD_NODE_TAG_PREFIX}prompt_input"

            setOnTouchListener { _, ev ->
                if (ev.action == MotionEvent.ACTION_UP || ev.action == MotionEvent.ACTION_DOWN) {
                    cancelAutoCollapse()
                    acquireInputFocusFromTermux()
                }
                false
            }

            setOnEditorActionListener { _, actionId, event ->
                if (actionId == EditorInfo.IME_ACTION_SEND ||
                    (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER && event.action == KeyEvent.ACTION_DOWN)
                ) {
                    submitPromptFromInput()
                    true
                } else {
                    false
                }
            }

            addTextChangedListener(object : android.text.TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                    updateInlineComposerControls()
                }
                override fun afterTextChanged(s: android.text.Editable?) {}
            })
        }
        inputEditText = editText

        val clearBtn = AgyGlyphButtonView(context, AgyGlyphButtonView.Glyph.CLEAR_X).apply {
            val sz = (22 * d).toInt()
            layoutParams = LinearLayout.LayoutParams(sz, sz).apply { marginEnd = (4 * d).toInt() }
            setStyle(
                glyph = AgyGlyphButtonView.Glyph.CLEAR_X,
                bgFill = Color.parseColor("#E5E9F0"),
                bgStroke = Color.TRANSPARENT,
                iconTint = COLOR_TEXT_SECONDARY,
                strokeDp = 0f
            )
            contentDescription = "${HUD_NODE_TAG_PREFIX}clear_draft_btn"
            visibility = View.GONE
            attachSpringPressFeedback(0.90f)
            setOnClickListener {
                inputEditText?.setText("")
                updateInlineComposerControls()
            }
        }
        clearDraftBtn = clearBtn

        val boltBtn = AgyGlyphButtonView(context, AgyGlyphButtonView.Glyph.BOLT).apply {
            val sz = (30 * d).toInt()
            layoutParams = LinearLayout.LayoutParams(sz, sz).apply { marginEnd = (4 * d).toInt() }
            setStyle(
                glyph = AgyGlyphButtonView.Glyph.BOLT,
                bgFill = Color.WHITE,
                bgStroke = COLOR_HAIRLINE,
                iconTint = COLOR_TEXT_SECONDARY,
                strokeDp = 0.8f
            )
            contentDescription = "${HUD_NODE_TAG_PREFIX}macros_toggle_btn"
            attachSpringPressFeedback(0.92f)
            setOnClickListener {
                cancelAutoCollapse()
                isMacrosDrawerOpen = !isMacrosDrawerOpen
                renderInputMacrosStrip()
                updateInlineComposerControls()
            }
        }
        macrosToggleBtn = boltBtn

        // Morphing Trailing Action Orb: ↑ Send when typing/idle, ■ Stop (Stage 1) / Force-Stop (Stage 2) when running
        val actionOrb = AgyGlyphButtonView(context, AgyGlyphButtonView.Glyph.SEND_UP).apply {
            val sz = (36 * d).toInt()
            layoutParams = LinearLayout.LayoutParams(sz, sz)
            setStyle(
                glyph = AgyGlyphButtonView.Glyph.SEND_UP,
                bgFill = COLOR_CYAN,
                bgStroke = COLOR_CYAN,
                iconTint = Color.WHITE,
                strokeDp = 0.8f
            )
            contentDescription = "${HUD_NODE_TAG_PREFIX}send_btn"
            attachSpringPressFeedback(0.88f)
            setOnClickListener {
                try {
                    performHapticFeedback(android.view.HapticFeedbackConstants.VIRTUAL_KEY)
                } catch (_: Exception) {}
                val draft = inputEditText?.text?.toString()?.trim().orEmpty()
                val st = _hudState.value.state
                if (draft.isNotEmpty()) {
                    submitPromptFromInput()
                } else if (st == "WORKING" || st == "PAUSED" || st == "NEEDS_INPUT" || st == "STOPPING") {
                    cancelAutoCollapse()
                    handleRemoteCommand(JSONObject().put("action", "STOP"))
                    releaseInputFocusToTermux()
                } else {
                    acquireInputFocusFromTermux()
                }
            }
        }
        composerActionBtn = actionOrb

        capsule.addView(micBtn)
        capsule.addView(editText)
        capsule.addView(clearBtn)
        capsule.addView(boltBtn)
        capsule.addView(actionOrb)
        // Expand Stop/Send orb hit target to at least 48dp inside the capsule for effortless thumb taps
        capsule.post {
            val hitRect = Rect()
            actionOrb.getHitRect(hitRect)
            val pad = (10 * d).toInt()
            hitRect.inset(-pad, -pad)
            capsule.touchDelegate = android.view.TouchDelegate(hitRect, actionOrb)
        }
        composerBox.addView(capsule)
        container.addView(composerBox)

        return container
    }

    /**
     * Compact Collapsed Pill shown ONLY when the unified card is collapsed (`isCollapsed == true`):
     * - When WORKING or PAUSED: live step pill [App Icon + Ring] [Marquee Step] [Timer] [■ Stop / ▶ Resume].
     * - When IDLE / DONE / NEEDS_INPUT: clean [Status | ✦ Ask Agy] pill that spring-expands into the
     *   unified Gemini card with its built-in bottom text field.
     */
    private fun buildBottomChatDockRow(d: Float): LinearLayout {
        val screenW = context.resources.displayMetrics.widthPixels.coerceAtLeast(360)
        val dock = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding((10 * d).toInt(), (6 * d).toInt(), (6 * d).toInt(), (6 * d).toInt())
            background = createLiquidGlassDrawable(
                fillColor = COLOR_OBSIDIAN_GLASS,
                strokeColor = COLOR_HAIRLINE,
                radiusDp = 999f,
                strokeDp = 1.0f
            )
            elevation = 10f * d
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            layoutTransition = LayoutTransition().apply {
                setDuration(200L)
                enableTransitionType(LayoutTransition.CHANGING)
            }
        }

        // --- Mode B: Standard Status + Ask Agy Collapsed Pill (Idle / Needs Input / Done) ---
        val statusGroup = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding((2 * d).toInt(), (3 * d).toInt(), (8 * d).toInt(), (3 * d).toInt())
            contentDescription = "${HUD_NODE_TAG_PREFIX}collapsed_expand_btn"
            attachSpringPressFeedback(0.96f)
            setOnClickListener {
                cancelAutoCollapse()
                val now = System.currentTimeMillis()
                val isDoubleTap = isCollapsed && (now - lastDockTapAtMs) in 1L..320L
                lastDockTapAtMs = now
                isCollapsed = false
                _isInputVisible.value = true
                renderHudWindow()
                if (isDoubleTap || _hudState.value.state == "IDLE" || _hudState.value.state == "NEEDS_INPUT") {
                    focusInlineComposerInternal(requestKeyboardFocus = true)
                }
            }
        }
        dockStandardStatusGroup = statusGroup

        val dSpinner = AgySpinnerRingView(context).apply {
            val sz = (13 * d).toInt()
            layoutParams = LinearLayout.LayoutParams(sz, sz).apply { marginEnd = (6 * d).toInt() }
            setAccentColor(COLOR_CYAN)
            visibility = View.GONE
        }
        dockSpinnerView = dSpinner

        val statusTv = TextView(context).apply {
            text = "○ Ready ▲"
            textSize = 11.5f
            setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
            setTextColor(COLOR_TEXT_PRIMARY)
            maxLines = 1
        }
        collapsedStatusText = statusTv

        statusGroup.addView(dSpinner)
        statusGroup.addView(statusTv)

        val divider = View(context).apply {
            layoutParams = LinearLayout.LayoutParams((1 * d).toInt(), (18 * d).toInt()).apply {
                marginEnd = (6 * d).toInt()
            }
            setBackgroundColor(COLOR_HAIRLINE)
        }
        dockStandardDivider = divider

        val askBtn = TextView(context).apply {
            text = "✦ Ask Agy"
            textSize = 11.5f
            setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
            setTextColor(Color.WHITE)
            setPadding((12 * d).toInt(), (6 * d).toInt(), (12 * d).toInt(), (6 * d).toInt())
            background = createLiquidGlassDrawable(
                fillColor = COLOR_CYAN,
                strokeColor = COLOR_CYAN,
                radiusDp = 999f,
                strokeDp = 0.8f
            )
            contentDescription = "${HUD_NODE_TAG_PREFIX}bottom_chat_pill_btn"
            attachSpringPressFeedback(0.94f)
            setOnClickListener {
                cancelAutoCollapse()
                isCollapsed = false
                _isInputVisible.value = true
                renderHudWindow()
                focusInlineComposerInternal(requestKeyboardFocus = true)
            }
        }
        bottomChatPillBtn = askBtn

        // --- Mode A: Live Collapsed Running/Paused Step Pill ---
        val liveGroup = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding((2 * d).toInt(), (1 * d).toInt(), (4 * d).toInt(), (1 * d).toInt())
            contentDescription = "${HUD_NODE_TAG_PREFIX}collapsed_live_step_btn"
            visibility = View.GONE
            attachSpringPressFeedback(0.96f)
            setOnClickListener {
                cancelAutoCollapse()
                isCollapsed = false
                _isInputVisible.value = true
                renderHudWindow()
            }
        }
        dockLiveStepGroup = liveGroup

        val badgeFrame = FrameLayout(context).apply {
            val outerSz = (26 * d).toInt()
            layoutParams = LinearLayout.LayoutParams(outerSz, outerSz).apply {
                marginEnd = (8 * d).toInt()
            }
        }
        val liveRing = AgySpinnerRingView(context).apply {
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            setAccentColor(COLOR_CYAN)
        }
        dockLiveSpinnerView = liveRing

        val liveIcon = AgyIconBadgeView(context).apply {
            val innerSz = (18 * d).toInt()
            layoutParams = FrameLayout.LayoutParams(innerSz, innerSz, Gravity.CENTER)
        }
        dockLiveIconView = liveIcon
        badgeFrame.addView(liveRing)
        badgeFrame.addView(liveIcon)

        val liveStepTv = TextView(context).apply {
            text = "Working"
            textSize = 12f
            setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
            setTextColor(COLOR_TEXT_PRIMARY)
            isSingleLine = true
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.MARQUEE
            marqueeRepeatLimit = -1
            isHorizontalFadingEdgeEnabled = true
            setFadingEdgeLength((14 * d).toInt())
            isSelected = true
            minWidth = (56 * d).toInt()
            maxWidth = min((168 * d).toInt(), (screenW * 0.45f).toInt())
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                marginEnd = (8 * d).toInt()
            }
        }
        dockLiveStepText = liveStepTv

        val liveTimerTv = TextView(context).apply {
            text = "00:00.0"
            textSize = 10.5f
            typeface = Typeface.MONOSPACE
            setTextColor(COLOR_TEXT_SECONDARY)
            maxLines = 1
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                marginEnd = (4 * d).toInt()
            }
        }
        dockLiveTimerText = liveTimerTv

        liveGroup.addView(badgeFrame)
        liveGroup.addView(liveStepTv)
        liveGroup.addView(liveTimerTv)

        val liveStopBtn = TextView(context).apply {
            text = "■"
            textSize = 11f
            setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
            setTextColor(COLOR_CORAL)
            gravity = Gravity.CENTER
            val sz = (32 * d).toInt()
            layoutParams = LinearLayout.LayoutParams(sz, sz).apply {
                marginStart = (2 * d).toInt()
            }
            background = createLiquidGlassDrawable(
                fillColor = Color.parseColor("#1AE11D48"),
                strokeColor = Color.parseColor("#44E11D48"),
                radiusDp = 999f,
                strokeDp = 0.85f
            )
            contentDescription = "${HUD_NODE_TAG_PREFIX}collapsed_stop_btn"
            visibility = View.GONE
            attachSpringPressFeedback(0.88f)
            setOnClickListener {
                try {
                    performHapticFeedback(android.view.HapticFeedbackConstants.VIRTUAL_KEY)
                } catch (_: Exception) {}
                cancelAutoCollapse()
                if (_hudState.value.state == "PAUSED") {
                    handleRemoteCommand(JSONObject().put("action", "RESUME"))
                } else {
                    handleRemoteCommand(JSONObject().put("action", "STOP"))
                }
            }
        }
        dockLiveStopBtn = liveStopBtn

        dock.addView(statusGroup)
        dock.addView(divider)
        dock.addView(askBtn)
        dock.addView(liveGroup)
        dock.addView(liveStopBtn)
        return dock
    }

    private fun applyDynamicWindowGeometryInternal(state: AgyHudState) {
        val d = density()
        val metrics = context.resources.displayMetrics
        val screenW = metrics.widthPixels.coerceAtLeast(360)
        val screenH = metrics.heightPixels.coerceAtLeast(640)
        val layout = state.layout

        // Dynamic card width fraction (default ~304dp capped at 90% width)
        hudExpandedContainer?.let { card ->
            val targetW = if (layout.widthFraction != null) {
                (screenW * layout.widthFraction.coerceIn(0.60f, 0.96f)).toInt()
            } else {
                min((304 * d).toInt(), (screenW * 0.90f).toInt())
            }
            val lp = card.layoutParams
            if (lp != null && lp.width != targetW) {
                lp.width = targetW
                card.layoutParams = lp
            }
        }

        // Dynamic screen anchor / x & y offsets when Agy explicitly sets position or fractions
        val params = hudParams ?: return
        val root = hudRootView ?: return
        if (isInputFocused) return
        var changed = false
        if (layout.position.isNotBlank() || layout.xFraction != null || layout.yFraction != null) {
            val vGravity = when (layout.position.lowercase()) {
                "top" -> Gravity.TOP
                "center" -> Gravity.CENTER_VERTICAL
                "bottom" -> Gravity.BOTTOM
                else -> Gravity.BOTTOM
            }
            val hGravity = when {
                layout.xFraction != null && layout.xFraction < 0.35f -> Gravity.START
                layout.xFraction != null && layout.xFraction > 0.65f -> Gravity.END
                layout.xFraction != null -> Gravity.CENTER_HORIZONTAL
                else -> Gravity.END
            }
            val nextGravity = vGravity or hGravity
            if (params.gravity != nextGravity) {
                params.gravity = nextGravity
                changed = true
            }
            if (layout.yFraction != null) {
                val targetY = ((1f - layout.yFraction).coerceIn(0.02f, 0.85f) * screenH).toInt()
                if (params.y != targetY) {
                    params.y = targetY
                    changed = true
                }
            } else if (layout.position == "top" && params.y < (32 * d).toInt()) {
                params.y = (42 * d).toInt()
                changed = true
            } else if (layout.position == "center") {
                params.y = 0
                changed = true
            }
            if (changed) {
                try {
                    windowManager?.updateViewLayout(root, params)
                } catch (_: Exception) {}
            }
        }
    }

    private fun renderHudWindow() {
        val state = _hudState.value
        val d = density()
        val alphaVal = state.theme.opacity ?: OPACITY_LEVELS[opacityIndex]
        val isWorking = state.state == "WORKING"
        val isPaused = state.state == "PAUSED"
        val isNeedsInput = state.state == "NEEDS_INPUT"
        val isStopping = state.state == "STOPPING"
        val isStopped = state.state == "STOPPED"
        val isDone = state.state == "DONE"
        val liveCollapsedMode = isCollapsedLiveRunningMode(state, isCollapsed)
        val baseStateAccent = when (state.state) {
            "WORKING" -> COLOR_CYAN
            "PAUSED", "NEEDS_INPUT" -> COLOR_AMBER
            "STOPPING", "STOPPED" -> COLOR_CORAL
            "DONE" -> COLOR_EMERALD
            else -> COLOR_VIOLET
        }
        val resolvedTheme = AgyHudDynamicModels.resolveTheme(state.theme, baseStateAccent)
        val accentColor = if (isStopping || isStopped) COLOR_CORAL else resolvedTheme.accent
        val layoutCfg = state.layout

        hudRootView?.alpha = if (ghostPassThrough) (alphaVal * 0.45f).coerceAtLeast(0.22f) else alphaVal
        hudRootView?.visibility = if (isTemporarilySuppressed) View.GONE else View.VISIBLE

        // Apply dynamic surface / border / aurora palette / corner radius directly to the card container
        hudExpandedContainer?.applyDynamicTheme(
            surfaceColor = resolvedTheme.surface,
            idleBorderColor = resolvedTheme.border,
            accentColor = accentColor,
            customAuroraColors = resolvedTheme.auroraIntColors,
            auroraEnabled = resolvedTheme.auroraEnabled,
            cornerRadiusDp = resolvedTheme.cornerRadiusDp
        )

        // Single Unified Gemini Morph: show EITHER the Expanded Card (with built-in bottom text field)
        // OR the compact Collapsed Pill, animated smoothly with Gemini spring physics!
        val collapseTransitioned = lastRenderedCollapsedState != null && lastRenderedCollapsedState != isCollapsed
        lastRenderedCollapsedState = isCollapsed

        hudExpandedContainer?.visibility = if (isCollapsed) View.GONE else View.VISIBLE
        hudBottomDockRow?.visibility = if (isCollapsed) View.VISIBLE else View.GONE
        val showDetailsDrawer = isDetailsExpanded && !isInputFocused
        telemetryDetailsContainer?.visibility = if (showDetailsDrawer) View.VISIBLE else View.GONE

        if (collapseTransitioned) {
            if (!isCollapsed) {
                hudExpandedContainer?.let { card ->
                    card.animate().cancel()
                    card.pivotX = card.width.takeIf { it > 0 }?.toFloat() ?: (280f * d)
                    card.pivotY = card.height.takeIf { it > 0 }?.toFloat() ?: (220f * d)
                    card.alpha = 0f
                    card.scaleX = 0.90f
                    card.scaleY = 0.86f
                    card.translationY = 14f * d
                    card.animate()
                        .alpha(1f)
                        .scaleX(1f)
                        .scaleY(1f)
                        .translationY(0f)
                        .setDuration(260L)
                        .setInterpolator(android.view.animation.OvershootInterpolator(0.85f))
                        .start()
                }
            } else {
                hudBottomDockRow?.let { pill ->
                    pill.animate().cancel()
                    pill.alpha = 0f
                    pill.scaleX = 0.90f
                    pill.scaleY = 0.90f
                    pill.animate()
                        .alpha(1f)
                        .scaleX(1f)
                        .scaleY(1f)
                        .setDuration(210L)
                        .setInterpolator(android.view.animation.OvershootInterpolator(0.95f))
                        .start()
                }
            }
        }

        // Flowing Gemini Aurora Shimmer Border + Focus/Voice/Stopping Halo on Unified Card
        hudExpandedContainer?.setRimMode(
            when {
                isCollapsed -> AgyAuroraCardLayout.RimMode.IDLE
                isStopping -> AgyAuroraCardLayout.RimMode.STOPPING
                isStopped -> AgyAuroraCardLayout.RimMode.STOPPED
                _isVoiceListeningFlow.value -> AgyAuroraCardLayout.RimMode.VOICE_LISTENING
                isWorking -> AgyAuroraCardLayout.RimMode.WORKING
                isNeedsInput -> AgyAuroraCardLayout.RimMode.NEEDS_INPUT
                isInputFocused -> AgyAuroraCardLayout.RimMode.INPUT_ACTIVE
                isPaused -> AgyAuroraCardLayout.RimMode.PAUSED
                isDone -> AgyAuroraCardLayout.RimMode.DONE
                else -> AgyAuroraCardLayout.RimMode.IDLE
            }
        )

        // Show/hide integrated composer based on Agy layout config
        inlineComposerContainer?.visibility = if (layoutCfg.showComposer) View.VISIBLE else View.GONE

        // Update built-in bottom composer visuals (capsule focus ring, Send/Stop orb, voice state, dynamic theme)
        updateInlineComposerControls()

        val rimColor = when {
            isStopping -> COLOR_CORAL
            isStopped -> Color.parseColor("#88E11D48")
            isNeedsInput -> COLOR_AMBER
            isPaused -> Color.parseColor("#88D97706")
            isWorking -> Color.argb(120, Color.red(accentColor), Color.green(accentColor), Color.blue(accentColor))
            isDone -> Color.parseColor("#6616A34A")
            else -> resolvedTheme.border
        }
        hudBottomDockRow?.setPadding(
            if (liveCollapsedMode) (8 * d).toInt() else (10 * d).toInt(),
            if (liveCollapsedMode) (5 * d).toInt() else (6 * d).toInt(),
            (6 * d).toInt(),
            if (liveCollapsedMode) (5 * d).toInt() else (6 * d).toInt()
        )
        hudBottomDockRow?.background = createLiquidGlassDrawable(
            fillColor = resolvedTheme.surface,
            strokeColor = rimColor,
            radiusDp = 999f,
            strokeDp = if (isNeedsInput || isWorking || isPaused || isStopping) 1.3f else 1.0f
        )

        // Resolve active App / Task Icon OR Agy custom emoji badge
        val activeCollapsedStep = resolveCollapsedRunningStep(state)
        if (state.customEmoji.isNotBlank()) {
            headerAppIconView?.visibility = View.GONE
            customEmojiView?.visibility = View.VISIBLE
            customEmojiView?.text = state.customEmoji
        } else {
            customEmojiView?.visibility = View.GONE
            headerAppIconView?.visibility = View.VISIBLE
            headerAppIconView?.setIcon(activeCollapsedStep.icon)
        }

        // Sync top shimmer loading bar (only when no explicit dynamic progress strip is taking over)
        workingLoadingBar?.setColors(
            accentColor = accentColor,
            trackColor = if (resolvedTheme.isDark) Color.parseColor("#334155") else Color.parseColor("#E2E8F0")
        )
        workingLoadingBar?.setDeterminateProgress(null)
        workingLoadingBar?.setAnimating(isWorking && !isCollapsed && !state.progress.visible)

        if (isWorking || isStopping) {
            headerSpinnerView?.visibility = View.VISIBLE
            headerSpinnerView?.setAccentColor(accentColor)
            headerSpinnerView?.setAnimating(!isCollapsed)
            statusDotView?.visibility = View.GONE
        } else {
            headerSpinnerView?.setAnimating(false)
            headerSpinnerView?.visibility = View.GONE
            statusDotView?.visibility = View.VISIBLE
            statusDotView?.background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(accentColor)
            }
        }

        // Toggle between Live Collapsed Running/Paused/Stopping Step Pill and Standard Ask Agy Bottom Dock
        dockStandardStatusGroup?.visibility = if (liveCollapsedMode) View.GONE else View.VISIBLE
        dockStandardDivider?.visibility = if (liveCollapsedMode) View.GONE else View.VISIBLE
        bottomChatPillBtn?.visibility = if (liveCollapsedMode) View.GONE else View.VISIBLE
        dockLiveStepGroup?.visibility = if (liveCollapsedMode) View.VISIBLE else View.GONE
        dockLiveStopBtn?.visibility = if (liveCollapsedMode && layoutCfg.showStopButton) View.VISIBLE else View.GONE

        if (liveCollapsedMode) {
            dockSpinnerView?.setAnimating(false)
            dockSpinnerView?.visibility = View.GONE
            dockLiveIconView?.setIcon(activeCollapsedStep.icon)
            dockLiveSpinnerView?.setAccentColor(
                when {
                    isStopping -> COLOR_CORAL
                    isPaused -> COLOR_AMBER
                    else -> accentColor
                }
            )
            dockLiveSpinnerView?.setAnimating(isWorking || isStopping)
            dockLiveStepText?.setTextColor(resolvedTheme.textPrimary)

            dockLiveStopBtn?.apply {
                if (isPaused) {
                    text = "▶"
                    setTextColor(accentColor)
                    background = createLiquidGlassDrawable(
                        fillColor = Color.argb(26, Color.red(accentColor), Color.green(accentColor), Color.blue(accentColor)),
                        strokeColor = Color.argb(80, Color.red(accentColor), Color.green(accentColor), Color.blue(accentColor)),
                        radiusDp = 999f,
                        strokeDp = 0.85f
                    )
                } else if (isStopping) {
                    text = "✕"
                    setTextColor(Color.WHITE)
                    background = createLiquidGlassDrawable(
                        fillColor = COLOR_CORAL,
                        strokeColor = COLOR_CORAL,
                        radiusDp = 999f,
                        strokeDp = 1.0f
                    )
                } else {
                    text = "■"
                    setTextColor(COLOR_CORAL)
                    background = createLiquidGlassDrawable(
                        fillColor = Color.parseColor("#1AE11D48"),
                        strokeColor = Color.parseColor("#55E11D48"),
                        radiusDp = 999f,
                        strokeDp = 0.9f
                    )
                }
            }

            val stepTv = dockLiveStepText
            if (stepTv != null) {
                val nextLabel = when {
                    isStopping -> "Stopping… tap ✕"
                    isPaused -> "Paused · ${activeCollapsedStep.label}"
                    else -> activeCollapsedStep.label
                }
                if (nextLabel != lastCollapsedStepLabel) {
                    if (lastCollapsedStepLabel.isNotEmpty()) {
                        stepTv.animate().cancel()
                        stepTv.alpha = 0f
                        stepTv.translationY = 4f * d
                        stepTv.text = nextLabel
                        stepTv.isSelected = true
                        stepTv.animate()
                            .alpha(1f)
                            .translationY(0f)
                            .setDuration(190L)
                            .start()
                    } else {
                        stepTv.alpha = 1f
                        stepTv.translationY = 0f
                        stepTv.text = nextLabel
                        stepTv.isSelected = true
                    }
                    lastCollapsedStepLabel = nextLabel
                } else if (!stepTv.isSelected) {
                    stepTv.isSelected = true
                }
            }
        } else {
            dockLiveSpinnerView?.setAnimating(false)
            lastCollapsedStepLabel = ""

            if (isWorking) {
                dockSpinnerView?.visibility = View.VISIBLE
                dockSpinnerView?.setAccentColor(COLOR_CYAN)
                dockSpinnerView?.setAnimating(true)
            } else {
                dockSpinnerView?.setAnimating(false)
                dockSpinnerView?.visibility = View.GONE
            }

            // Always-visible Bottom Dock status label & Ask Agy Chat pill styling
            val chevron = if (isCollapsed) "▲" else "▼"
            val elapsed = _elapsedMsFlow.value
            val dockLabel = when (state.state) {
                "WORKING" -> "Working $chevron"
                "PAUSED" -> "❚❚ Paused $chevron"
                "NEEDS_INPUT" -> "? Reply $chevron"
                "DONE" -> if (elapsed > 0L) {
                    "✓ Done · ${formatElapsed(elapsed, isDone = true).removePrefix("Done ")} $chevron"
                } else {
                    "✓ Done $chevron"
                }
                else -> "○ Ready $chevron"
            }
            collapsedStatusText?.text = dockLabel
            collapsedStatusText?.setTextColor(if (isNeedsInput || isPaused) COLOR_AMBER else COLOR_TEXT_PRIMARY)

            val chatPillBgColor = if (isNeedsInput) COLOR_AMBER else COLOR_CYAN
            bottomChatPillBtn?.text = if (isNeedsInput) "✦ Reply" else "✦ Ask Agy"
            bottomChatPillBtn?.background = createLiquidGlassDrawable(
                fillColor = chatPillBgColor,
                strokeColor = chatPillBgColor,
                radiusDp = 999f,
                strokeDp = 0.8f
            )
        }

        // Update Live Elapsed Timer label (both expanded header & collapsed live pill)
        updateElapsedTimerDisplay()

        // Ultra-Clean Single-Line Status & Expandable Tools Tray (with Agy custom statusLabel support)
        val cleanStatusLabel = state.statusLabel.ifBlank {
            when (state.state) {
                "WORKING" -> "Working"
                "PAUSED" -> "Paused"
                "NEEDS_INPUT" -> "Needs input"
                "STOPPING" -> "Stopping…"
                "STOPPED" -> "Stopped"
                "DONE" -> "Done"
                else -> "Ready"
            }
        }
        statusBadgeText?.text = cleanStatusLabel
        statusBadgeText?.setTextColor(accentColor)

        val hasDetailBlocks = state.blocks.any { it.inDetails }
        val hasExpandableDetails = state.tasks.isNotEmpty() ||
            state.detailedOutput.isNotBlank() ||
            state.outputLogs.isNotEmpty() ||
            hasDetailBlocks ||
            (state.screenWatch.active && wireframeEnabled)
        stepsTogglePill?.apply {
            visibility = if (hasExpandableDetails && layoutCfg.showStepsBadge) View.VISIBLE else View.GONE
            if (hasExpandableDetails && layoutCfg.showStepsBadge) {
                val doneCount = state.tasks.count { it.status == "done" }
                val totalCount = state.tasks.size
                val chevron = if (isDetailsExpanded && !isInputFocused) "▴" else "▾"
                text = if (totalCount > 0) "$doneCount/$totalCount $chevron" else "Details $chevron"
                val active = isDetailsExpanded && !isInputFocused
                setTextColor(if (active) accentColor else resolvedTheme.textSecondary)
                background = createLiquidGlassDrawable(
                    fillColor = if (active) Color.argb(30, Color.red(accentColor), Color.green(accentColor), Color.blue(accentColor)) else resolvedTheme.secondarySurface,
                    strokeColor = if (active) Color.argb(105, Color.red(accentColor), Color.green(accentColor), Color.blue(accentColor)) else resolvedTheme.border,
                    radiusDp = 999f,
                    strokeDp = 0.7f
                )
            }
        }

        toolsMenuBtn?.visibility = if (layoutCfg.showOverflowMenu) View.VISIBLE else View.GONE
        toolsMenuBtn?.background = createLiquidGlassDrawable(
            fillColor = if (isToolsTrayOpen) Color.argb(30, Color.red(accentColor), Color.green(accentColor), Color.blue(accentColor)) else resolvedTheme.secondarySurface,
            strokeColor = Color.TRANSPARENT,
            radiusDp = 999f,
            strokeDp = 0f
        )
        toolsMenuBtn?.setTextColor(if (isToolsTrayOpen) accentColor else resolvedTheme.textSecondary)

        headerCollapseBtn?.visibility = if (layoutCfg.showCollapseButton) View.VISIBLE else View.GONE
        headerCollapseBtn?.background = createLiquidGlassDrawable(
            fillColor = resolvedTheme.secondarySurface,
            strokeColor = Color.TRANSPARENT,
            radiusDp = 999f,
            strokeDp = 0f
        )
        headerCollapseBtn?.setTextColor(resolvedTheme.textSecondary)

        toolsTrayContainer?.visibility = if (isToolsTrayOpen && !isCollapsed && layoutCfg.showOverflowMenu) View.VISIBLE else View.GONE
        toolsTrayContainer?.background = createLiquidGlassDrawable(
            fillColor = resolvedTheme.secondarySurface,
            strokeColor = resolvedTheme.border,
            radiusDp = 12f,
            strokeDp = 0.7f
        )

        val opacityPct = (alphaVal * 100).toInt()
        opacityBtn?.text = "$opacityPct%"
        wireframeBtn?.text = if (wireframeEnabled) "● Wire" else "Wire"
        wireframeBtn?.setTextColor(if (wireframeEnabled) accentColor else resolvedTheme.textSecondary)
        ghostBtn?.text = if (ghostPassThrough) "● Ghost" else "Ghost"
        ghostBtn?.setTextColor(if (ghostPassThrough) COLOR_AMBER else resolvedTheme.textSecondary)
        edgeSnapBtn?.text = if (edgeSnapEnabled) "● Snap" else "Snap"
        edgeSnapBtn?.setTextColor(if (edgeSnapEnabled) accentColor else resolvedTheme.textSecondary)

        // Title with smooth crossfade when changing
        titleText?.let { tv ->
            tv.setTextColor(resolvedTheme.textPrimary)
            if (state.title != lastRenderedTitle && lastRenderedTitle.isNotEmpty() && !isCollapsed) {
                tv.animate().cancel()
                tv.alpha = 0f
                tv.translationY = 4f * d
                tv.text = state.title
                tv.animate().alpha(1f).translationY(0f).setDuration(190L).start()
            } else {
                tv.text = state.title
            }
            lastRenderedTitle = state.title
        }

        // Question Banner
        if (state.question.isNotBlank()) {
            questionBannerText?.visibility = View.VISIBLE
            questionBannerText?.text = state.question
        } else {
            questionBannerText?.visibility = View.GONE
        }

        // Doing Now row + animated 3 bouncing dots
        if (state.currentAction.isNotBlank()) {
            doingRowContainer?.visibility = View.VISIBLE
            currentActionText?.text = state.currentAction
            currentActionText?.setTextColor(if (isStopping) COLOR_CORAL else resolvedTheme.textSecondary)
            doingDotsView?.setAccentColor(accentColor)
            doingDotsView?.setAnimating((isWorking || isStopping) && !isCollapsed)
        } else {
            doingRowContainer?.visibility = View.GONE
            doingDotsView?.setAnimating(false)
        }

        // Only show nextAction when task checklist isn't already displaying upcoming steps
        if (state.nextAction.isNotBlank() && state.tasks.isEmpty()) {
            nextActionText?.visibility = View.VISIBLE
            nextActionText?.setTextColor(resolvedTheme.textSecondary)
            nextActionText?.text = "Next: ${state.nextAction}"
        } else {
            nextActionText?.visibility = View.GONE
        }

        // Render Dynamic Agy-Controlled Widgets (Progress, Metrics, Alert Banner, Modular Content Blocks)
        renderDynamicWidgetsInternal(state, resolvedTheme, d)

        // Airy Borderless Task List with Staggered Step Choreography & Micro-Pop Completion
        val listHost = taskListContainer
        if (listHost != null) {
            val prevStatuses = lastRenderedTaskStatuses
            listHost.removeAllViews()
            if (state.tasks.isEmpty()) {
                taskScrollView?.visibility = View.GONE
                lastRenderedTaskStatuses = emptyMap()
            } else {
                taskScrollView?.visibility = View.VISIBLE
                val maxListHeightPx = (132 * d).toInt()
                taskScrollView?.layoutParams = (taskScrollView?.layoutParams as? LinearLayout.LayoutParams)?.apply {
                    height = if (state.tasks.size > 4) maxListHeightPx else ViewGroup.LayoutParams.WRAP_CONTENT
                }
                val animateStagger = collapseTransitioned || prevStatuses.keys != state.tasks.map { it.id }.toSet()
                val nextStatusMap = mutableMapOf<String, String>()
                state.tasks.forEachIndexed { idx, task ->
                    nextStatusMap[task.id] = task.status
                    val prevTaskStatus = prevStatuses[task.id]
                    val justDone = task.status == "done" && prevTaskStatus != null && prevTaskStatus != "done"
                    val (marker, color) = when (task.status) {
                        "done" -> "✓" to COLOR_EMERALD
                        "doing" -> "•" to accentColor
                        "needs_input" -> "?" to COLOR_AMBER
                        "stopped", "error", "failed" -> "■" to COLOR_CORAL
                        else -> "○" to resolvedTheme.textSecondary
                    }
                    val row = LinearLayout(context).apply {
                        orientation = LinearLayout.HORIZONTAL
                        gravity = Gravity.CENTER_VERTICAL
                        setPadding((6 * d).toInt(), (5 * d).toInt(), (6 * d).toInt(), (5 * d).toInt())
                        if (task.status == "doing" || task.status == "needs_input") {
                            background = createLiquidGlassDrawable(
                                fillColor = Color.argb(16, Color.red(color), Color.green(color), Color.blue(color)),
                                strokeColor = Color.TRANSPARENT,
                                radiusDp = 10f,
                                strokeDp = 0f
                            )
                        }
                        layoutParams = LinearLayout.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.WRAP_CONTENT
                        ).apply { bottomMargin = (2 * d).toInt() }
                    }

                    // Per-task real app icon or custom vector badge (YouTube, Chrome, Termux, etc.)
                    val taskIcon = AgyAppIconResolver.resolve(
                        context = context,
                        explicitIcon = task.icon,
                        explicitPackage = task.appPackage,
                        fallbackText = "${task.label} ${task.detail}"
                    )
                    val iconBadge = AgyIconBadgeView(context).apply {
                        val sz = (19 * d).toInt()
                        layoutParams = LinearLayout.LayoutParams(sz, sz).apply { marginEnd = (8 * d).toInt() }
                        setIcon(taskIcon)
                    }
                    row.addView(iconBadge)

                    val textCol = LinearLayout(context).apply {
                        orientation = LinearLayout.VERTICAL
                        layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                    }
                    val labelTv = TextView(context).apply {
                        text = task.label
                        textSize = 11.5f
                        setTypeface(
                            Typeface.SANS_SERIF,
                            if (task.status == "doing") Typeface.BOLD else Typeface.NORMAL
                        )
                        setTextColor(if (task.status == "done") COLOR_TEXT_SECONDARY else COLOR_TEXT_PRIMARY)
                        maxLines = 2
                        ellipsize = TextUtils.TruncateAt.END
                    }
                    textCol.addView(labelTv)
                    if (task.detail.isNotBlank()) {
                        val detailTv = TextView(context).apply {
                            text = task.detail
                            textSize = 9.5f
                            typeface = Typeface.MONOSPACE
                            setTextColor(COLOR_TEXT_SECONDARY)
                            maxLines = 1
                            ellipsize = TextUtils.TruncateAt.END
                        }
                        textCol.addView(detailTv)
                    }
                    row.addView(textCol)

                    // Trailing live status indicator (spinning ring when doing, crisp mark with pop when done)
                    if (task.status == "doing" && isWorking && !isCollapsed) {
                        val taskSpinner = AgySpinnerRingView(context).apply {
                            val sz = (13 * d).toInt()
                            layoutParams = LinearLayout.LayoutParams(sz, sz).apply { marginStart = (6 * d).toInt() }
                            setAccentColor(COLOR_CYAN)
                            setAnimating(true)
                        }
                        row.addView(taskSpinner)
                    } else {
                        val statusTv = TextView(context).apply {
                            text = marker
                            textSize = 11f
                            setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
                            setTextColor(color)
                            layoutParams = LinearLayout.LayoutParams(
                                ViewGroup.LayoutParams.WRAP_CONTENT,
                                ViewGroup.LayoutParams.WRAP_CONTENT
                            ).apply { marginStart = (6 * d).toInt() }
                        }
                        if (justDone && !isCollapsed) {
                            statusTv.scaleX = 0.55f
                            statusTv.scaleY = 0.55f
                            statusTv.animate()
                                .scaleX(1f)
                                .scaleY(1f)
                                .setDuration(240L)
                                .setInterpolator(android.view.animation.OvershootInterpolator(1.8f))
                                .start()
                        }
                        row.addView(statusTv)
                    }

                    tagTreeForSelfExclusion(row, "task_${task.id}")
                    listHost.addView(row)

                    if (animateStagger && !isCollapsed) {
                        row.alpha = 0f
                        row.translationY = 10f * d
                        row.animate()
                            .alpha(1f)
                            .translationY(0f)
                            .setStartDelay((idx * 35L).coerceAtMost(180L))
                            .setDuration(210L)
                            .setInterpolator(android.view.animation.DecelerateInterpolator())
                            .start()
                    }
                }
                lastRenderedTaskStatuses = nextStatusMap
            }
        }

        // Quiet Expandable Detailed Output Drawer
        val hasDetailedOutput = state.detailedOutput.isNotBlank() || state.outputLogs.isNotEmpty()
        if (hasDetailedOutput) {
            outputSectionContainer?.visibility = View.VISIBLE
            val logCount = state.outputLogs.size
            val suffix = if (logCount > 0) " · $logCount logs" else ""
            outputToggleHeaderText?.text = if (isOutputExpanded) {
                "Hide Output$suffix ▴"
            } else {
                "Output$suffix ▾"
            }
            outputDrawerContainer?.visibility = if (isOutputExpanded) View.VISIBLE else View.GONE
            if (isOutputExpanded) {
                outputBodyText?.text = getFullOutputCopyText(state)
            }
        } else {
            outputSectionContainer?.visibility = View.GONE
            outputDrawerContainer?.visibility = View.GONE
        }

        // Contextual & Custom Agy Quick Action Chips Strip
        val quickHost = quickActionsContainer
        val chips = resolveQuickActions(state)
        if (quickHost != null) {
            quickHost.removeAllViews()
            if (chips.isEmpty()) {
                quickActionsScrollView?.visibility = View.GONE
            } else {
                quickActionsScrollView?.visibility = View.VISIBLE
                for ((idx, chip) in chips.withIndex()) {
                    val chipStyle = chip.style.lowercase().ifBlank {
                        when {
                            chip.actionType == "STOP" || chip.actionType == "FORCE_STOP" -> "danger"
                            idx == 0 -> "primary"
                            else -> "secondary"
                        }
                    }
                    val chipTextColor = when (chipStyle) {
                        "danger" -> COLOR_CORAL
                        "success" -> COLOR_EMERALD
                        "primary" -> accentColor
                        else -> resolvedTheme.textPrimary
                    }
                    val chipBg = when (chipStyle) {
                        "danger" -> Color.parseColor("#1AE11D48")
                        "success" -> Color.parseColor("#1A16A34A")
                        "primary" -> Color.argb(28, Color.red(accentColor), Color.green(accentColor), Color.blue(accentColor))
                        else -> resolvedTheme.secondarySurface
                    }
                    val chipBorder = when (chipStyle) {
                        "danger" -> Color.parseColor("#55E11D48")
                        "success" -> Color.parseColor("#5516A34A")
                        "primary" -> Color.argb(95, Color.red(accentColor), Color.green(accentColor), Color.blue(accentColor))
                        else -> resolvedTheme.border
                    }
                    val chipTv = TextView(context).apply {
                        text = chip.label
                        textSize = 10.5f
                        setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
                        setTextColor(chipTextColor)
                        setPadding((10 * d).toInt(), (5 * d).toInt(), (10 * d).toInt(), (5 * d).toInt())
                        background = createLiquidGlassDrawable(
                            fillColor = chipBg,
                            strokeColor = chipBorder,
                            radiusDp = 999f,
                            strokeDp = 0.8f
                        )
                        layoutParams = LinearLayout.LayoutParams(
                            ViewGroup.LayoutParams.WRAP_CONTENT,
                            ViewGroup.LayoutParams.WRAP_CONTENT
                        ).apply { marginEnd = (6 * d).toInt() }
                        contentDescription = "${HUD_NODE_TAG_PREFIX}quick_chip_${chip.id.ifBlank { idx.toString() }}"
                        attachSpringPressFeedback(0.93f)
                        setOnClickListener { executeQuickAction(chip) }
                    }
                    quickHost.addView(chipTv)
                }
            }
        }

        // Low-Poly Mini Screen Wireframe (ONLY visible when screenWatch.active == true && wireframeEnabled)
        val showWireframe = state.screenWatch.active && wireframeEnabled
        wireframeView?.updateScreenWatch(state.screenWatch, wireframeEnabled)
        wireframeContainer?.visibility = if (showWireframe) View.VISIBLE else View.GONE
        if (showWireframe) {
            val zoneCount = state.screenWatch.zones.size
            val vecDesc = state.screenWatch.actionVector?.let { " • ${it.type}" } ?: ""
            val lbl = state.screenWatch.label.ifBlank { "Screen Watch" }
            wireframeLabelText?.text = "$lbl\n$zoneCount zones$vecDesc"
        }

        hudRootView?.let { root ->
            hudParams?.let { params ->
                try {
                    windowManager?.updateViewLayout(root, params)
                } catch (_: Exception) {}
            }
        }
    }

    private fun renderDynamicWidgetsInternal(
        state: AgyHudState,
        theme: AgyHudDynamicModels.ResolvedHudTheme,
        d: Float
    ) {
        // 1. Dynamic Progress Strip
        val prog = state.progress
        if (prog.visible && !isInputFocused) {
            progressRowContainer?.visibility = View.VISIBLE
            val progColor = AgyHudDynamicModels.parseColorOrNull(prog.color) ?: theme.accent
            val trackColor = if (theme.isDark) Color.parseColor("#334155") else Color.parseColor("#E2E8F0")
            progressBarView?.setColors(progColor, trackColor)
            if (prog.isDeterminate) {
                progressBarView?.setDeterminateProgress(prog.fraction)
                val pctStr = "${prog.value.toInt()}%"
                progressCaptionText?.text = if (prog.label.isNotBlank()) "$pctStr · ${prog.label}" else pctStr
                progressCaptionText?.visibility = View.VISIBLE
            } else {
                progressBarView?.setDeterminateProgress(null)
                progressBarView?.setAnimating(!isCollapsed)
                progressCaptionText?.text = prog.label
                progressCaptionText?.visibility = if (prog.label.isNotBlank()) View.VISIBLE else View.GONE
            }
            progressCaptionText?.setTextColor(theme.textSecondary)
        } else {
            progressRowContainer?.visibility = View.GONE
            progressBarView?.setAnimating(false)
        }

        // 2. Dynamic Live Metrics Strip
        val metricsHost = metricsContainer
        if (metricsHost != null) {
            metricsHost.removeAllViews()
            if (state.metrics.isEmpty() || isInputFocused) {
                metricsScrollView?.visibility = View.GONE
            } else {
                metricsScrollView?.visibility = View.VISIBLE
                state.metrics.forEach { metric ->
                    val mAccent = AgyHudDynamicModels.parseColorOrNull(metric.accentColor) ?: theme.accent
                    val pill = LinearLayout(context).apply {
                        orientation = LinearLayout.HORIZONTAL
                        gravity = Gravity.CENTER_VERTICAL
                        setPadding((8 * d).toInt(), (4 * d).toInt(), (8 * d).toInt(), (4 * d).toInt())
                        background = createLiquidGlassDrawable(
                            fillColor = theme.secondarySurface,
                            strokeColor = theme.border,
                            radiusDp = 10f,
                            strokeDp = 0.75f
                        )
                        layoutParams = LinearLayout.LayoutParams(
                            ViewGroup.LayoutParams.WRAP_CONTENT,
                            ViewGroup.LayoutParams.WRAP_CONTENT
                        ).apply { marginEnd = (6 * d).toInt() }
                    }
                    if (metric.label.isNotBlank()) {
                        val lblTv = TextView(context).apply {
                            text = if (metric.icon.isNotBlank()) "${metric.icon} ${metric.label}" else metric.label
                            textSize = 9.5f
                            setTextColor(theme.textSecondary)
                            maxLines = 1
                            layoutParams = LinearLayout.LayoutParams(
                                ViewGroup.LayoutParams.WRAP_CONTENT,
                                ViewGroup.LayoutParams.WRAP_CONTENT
                            ).apply { marginEnd = (4 * d).toInt() }
                        }
                        pill.addView(lblTv)
                    }
                    if (metric.value.isNotBlank()) {
                        val valTv = TextView(context).apply {
                            text = metric.value
                            textSize = 10.5f
                            typeface = Typeface.MONOSPACE
                            setTypeface(typeface, Typeface.BOLD)
                            setTextColor(mAccent)
                            maxLines = 1
                        }
                        pill.addView(valTv)
                    }
                    metricsHost.addView(pill)
                }
            }
        }

        // 3. Dynamic Alert / Status Banner
        val banner = state.banner
        if (banner.visible && !isInputFocused) {
            dynamicBannerContainer?.visibility = View.VISIBLE
            val bannerColor = AgyHudDynamicModels.parseColorOrNull(banner.accentColor) ?: when (banner.level) {
                "success" -> COLOR_EMERALD
                "warning" -> COLOR_AMBER
                "error" -> COLOR_CORAL
                else -> theme.accent
            }
            dynamicBannerContainer?.background = createLiquidGlassDrawable(
                fillColor = Color.argb(if (theme.isDark) 36 else 22, Color.red(bannerColor), Color.green(bannerColor), Color.blue(bannerColor)),
                strokeColor = Color.argb(95, Color.red(bannerColor), Color.green(bannerColor), Color.blue(bannerColor)),
                radiusDp = 12f,
                strokeDp = 0.85f
            )
            dynamicBannerTitleText?.apply {
                visibility = if (banner.title.isNotBlank()) View.VISIBLE else View.GONE
                text = banner.title
                setTextColor(bannerColor)
            }
            dynamicBannerMsgText?.apply {
                visibility = if (banner.message.isNotBlank()) View.VISIBLE else View.GONE
                text = banner.message
                setTextColor(theme.textPrimary)
            }
        } else {
            dynamicBannerContainer?.visibility = View.GONE
        }

        // 4. Modular Custom Content Blocks (inline vs expandable details drawer)
        fun populateBlocks(host: LinearLayout?, items: List<AgyHudDynamicModels.HudContentBlock>, visible: Boolean) {
            if (host == null) return
            host.removeAllViews()
            if (!visible || items.isEmpty()) {
                host.visibility = View.GONE
                return
            }
            host.visibility = View.VISIBLE
            items.forEach { block ->
                val blockAccent = AgyHudDynamicModels.parseColorOrNull(block.accentColor) ?: theme.accent
                val card = LinearLayout(context).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding((9 * d).toInt(), (7 * d).toInt(), (9 * d).toInt(), (7 * d).toInt())
                    background = createLiquidGlassDrawable(
                        fillColor = if (block.type == "code") {
                            if (theme.isDark) Color.parseColor("#FF020617") else Color.parseColor("#FF0F172A")
                        } else theme.secondarySurface,
                        strokeColor = theme.border,
                        radiusDp = 12f,
                        strokeDp = 0.75f
                    )
                    layoutParams = LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                    ).apply { topMargin = (7 * d).toInt() }
                }
                if (block.title.isNotBlank()) {
                    val tTv = TextView(context).apply {
                        text = block.title
                        textSize = 10.5f
                        setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
                        setTextColor(if (block.type == "code") Color.parseColor("#38BDF8") else blockAccent)
                        maxLines = 1
                        ellipsize = TextUtils.TruncateAt.END
                    }
                    card.addView(tTv)
                }
                if (block.body.isNotBlank()) {
                    val bTv = TextView(context).apply {
                        text = block.body
                        textSize = if (block.type == "code") 10f else 11f
                        if (block.type == "code") typeface = Typeface.MONOSPACE
                        setTextColor(if (block.type == "code") Color.parseColor("#E2E8F0") else theme.textPrimary)
                        maxLines = if (block.type == "code") 4 else 3
                        ellipsize = TextUtils.TruncateAt.END
                        layoutParams = LinearLayout.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.WRAP_CONTENT
                        ).apply { if (block.title.isNotBlank()) topMargin = (3 * d).toInt() }
                    }
                    card.addView(bTv)
                }
                if (block.items.isNotEmpty()) {
                    block.items.take(4).forEach { (k, v) ->
                        val kvRow = LinearLayout(context).apply {
                            orientation = LinearLayout.HORIZONTAL
                            gravity = Gravity.CENTER_VERTICAL
                            layoutParams = LinearLayout.LayoutParams(
                                ViewGroup.LayoutParams.MATCH_PARENT,
                                ViewGroup.LayoutParams.WRAP_CONTENT
                            ).apply { topMargin = (3 * d).toInt() }
                        }
                        val kTv = TextView(context).apply {
                            text = k
                            textSize = 10.5f
                            setTextColor(theme.textSecondary)
                            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                            maxLines = 1
                            ellipsize = TextUtils.TruncateAt.END
                        }
                        val vTv = TextView(context).apply {
                            text = v
                            textSize = 10.5f
                            typeface = Typeface.MONOSPACE
                            setTypeface(typeface, Typeface.BOLD)
                            setTextColor(theme.textPrimary)
                            maxLines = 1
                        }
                        kvRow.addView(kTv)
                        kvRow.addView(vTv)
                        card.addView(kvRow)
                    }
                }
                if (block.type == "progress" && block.progressValue != null) {
                    val subBar = AgyLoadingBarView(context).apply {
                        layoutParams = LinearLayout.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            (4.5f * d).toInt().coerceAtLeast(4)
                        ).apply { topMargin = (5 * d).toInt() }
                        setColors(blockAccent, if (theme.isDark) Color.parseColor("#334155") else Color.parseColor("#E2E8F0"))
                        setDeterminateProgress(block.progressValue / 100f)
                    }
                    card.addView(subBar)
                }
                host.addView(card)
            }
        }
        populateBlocks(inlineBlocksContainer, state.blocks.filter { !it.inDetails }, !isInputFocused)
        populateBlocks(detailBlocksContainer, state.blocks.filter { it.inDetails }, true)
    }

    fun executeQuickAction(chip: QuickActionChip) {
        try {
            hudRootView?.performHapticFeedback(android.view.HapticFeedbackConstants.VIRTUAL_KEY)
        } catch (_: Exception) {}
        when (chip.actionType.uppercase()) {
            "COPY_OUTPUT" -> copyDetailedOutputToClipboard()
            "TOGGLE_OUTPUT" -> setOutputExpanded(!isOutputExpanded)
            "PAUSE" -> {
                cancelAutoCollapse()
                handleRemoteCommand(JSONObject().put("action", "PAUSE").put("text", chip.commandText.ifBlank { "PAUSE" }))
            }
            "RESUME" -> {
                cancelAutoCollapse()
                handleRemoteCommand(JSONObject().put("action", "RESUME").put("text", chip.commandText.ifBlank { "RESUME" }))
            }
            "STOP" -> {
                cancelAutoCollapse()
                handleRemoteCommand(JSONObject().put("action", "STOP").put("text", chip.commandText.ifBlank { "STOP" }))
            }
            "FORCE_STOP" -> {
                cancelAutoCollapse()
                handleRemoteCommand(JSONObject().put("action", "FORCE_STOP").put("text", chip.commandText.ifBlank { "FORCE_STOP" }))
            }
            "CUSTOM", "CUSTOM_ACTION" -> {
                cancelAutoCollapse()
                enqueueAndBroadcastCommand(
                    text = chip.commandText.ifBlank { chip.label },
                    action = "CUSTOM",
                    buttonId = chip.id,
                    payload = chip.payload
                )
            }
            else -> {
                cancelAutoCollapse()
                val cmdText = chip.commandText.ifBlank { chip.label }
                if (cmdText.isNotBlank()) {
                    enqueueAndBroadcastCommand(
                        text = cmdText,
                        action = "PROMPT",
                        buttonId = chip.id,
                        payload = chip.payload
                    )
                }
            }
        }
    }

    // -------------------------------------------------------------------------
    // Built-In Bottom Composer Focus Handoff & Voice Dictation (Single Window)
    // -------------------------------------------------------------------------

    private fun focusInlineComposerInternal(requestKeyboardFocus: Boolean) {
        _isInputVisible.value = true
        if (requestKeyboardFocus) {
            mainHandler.postDelayed({ acquireInputFocusFromTermux() }, 80L)
        }
    }

    private fun blurInlineComposerInternal() {
        voiceController?.stopListening()
        _isVoiceListeningFlow.value = false
        releaseInputFocusToTermux()
        if (isCollapsed) {
            _isInputVisible.value = false
        }
    }

    fun setTemporarilySuppressed(suppressed: Boolean) {
        runOnMain {
            if (isTemporarilySuppressed != suppressed) {
                isTemporarilySuppressed = suppressed
                hudRootView?.visibility = if (suppressed) View.GONE else View.VISIBLE
            }
        }
    }

    private fun acquireInputFocusFromTermux() {
        val root = hudRootView ?: return
        val params = hudParams ?: return
        val et = inputEditText ?: return
        val d = density()
        if (isCollapsed) {
            isCollapsed = false
            _isInputVisible.value = true
            renderHudWindow()
        }
        if (!isInputFocused) {
            // Remember user's dragged vertical offset and dock snugly right above the keyboard
            if (savedYBeforeIme == null) {
                savedYBeforeIme = params.y
            }
            params.y = (10 * d).toInt()
            params.flags = (params.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE.inv()
                and WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN.inv()) or
                WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
            isInputFocused = true
            // Smoothly compact verbose checklist/wireframe while typing so the Gemini card sits sleek above the IME
            telemetryDetailsContainer?.visibility = View.GONE
            try {
                windowManager?.updateViewLayout(root, params)
            } catch (e: Exception) {
                Log.w(TAG, "Failed updating focusable layout for unified agy_hud: ${e.message}")
            }
            updateInlineComposerControls()
            hudExpandedContainer?.setRimMode(
                when {
                    _isVoiceListeningFlow.value -> AgyAuroraCardLayout.RimMode.VOICE_LISTENING
                    _hudState.value.state == "WORKING" -> AgyAuroraCardLayout.RimMode.WORKING
                    _hudState.value.state == "NEEDS_INPUT" -> AgyAuroraCardLayout.RimMode.NEEDS_INPUT
                    else -> AgyAuroraCardLayout.RimMode.INPUT_ACTIVE
                }
            )
        }
        et.isFocusable = true
        et.isFocusableInTouchMode = true
        et.requestFocus()
        et.post {
            try {
                inputMethodManager?.showSoftInput(et, InputMethodManager.SHOW_IMPLICIT)
            } catch (_: Exception) {}
        }
        et.postDelayed({
            if (isInputFocused && hudRootView != null) {
                try {
                    et.requestFocus()
                    inputMethodManager?.showSoftInput(et, InputMethodManager.SHOW_IMPLICIT)
                } catch (_: Exception) {}
            }
        }, 60L)
    }

    private fun releaseInputFocusToTermux() {
        val root = hudRootView ?: return
        val params = hudParams ?: return
        val et = inputEditText
        try {
            if (et != null) {
                inputMethodManager?.hideSoftInputFromWindow(et.windowToken, 0)
                et.clearFocus()
            }
        } catch (_: Exception) {}

        val changed = isInputFocused || (params.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE) == 0
        if (changed) {
            savedYBeforeIme?.let { prevY ->
                params.y = prevY
                savedYBeforeIme = null
            }
            params.flags = (params.flags and WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN.inv()) or
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH
            isInputFocused = false
            telemetryDetailsContainer?.visibility = if (isDetailsExpanded) View.VISIBLE else View.GONE
            try {
                windowManager?.updateViewLayout(root, params)
            } catch (_: Exception) {}
            if (hudRootView != null) {
                updateInlineComposerControls()
                hudExpandedContainer?.setRimMode(
                    when {
                        isCollapsed -> AgyAuroraCardLayout.RimMode.IDLE
                        _isVoiceListeningFlow.value -> AgyAuroraCardLayout.RimMode.VOICE_LISTENING
                        _hudState.value.state == "WORKING" -> AgyAuroraCardLayout.RimMode.WORKING
                        _hudState.value.state == "NEEDS_INPUT" -> AgyAuroraCardLayout.RimMode.NEEDS_INPUT
                        _hudState.value.state == "PAUSED" -> AgyAuroraCardLayout.RimMode.PAUSED
                        _hudState.value.state == "DONE" -> AgyAuroraCardLayout.RimMode.DONE
                        else -> AgyAuroraCardLayout.RimMode.IDLE
                    }
                )
            }
        }
    }

    private fun submitPromptFromInput() {
        val et = inputEditText ?: return
        val text = et.text?.toString()?.trim().orEmpty()
        if (text.isNotEmpty()) {
            enqueueAndBroadcastCommand(text = text, action = "PROMPT")
            et.setText("")
            updateInlineComposerControls()
            isCollapsed = false
            renderHudWindow()
        }
        releaseInputFocusToTermux()
    }

    private fun toggleVoiceDictationInternal() {
        val controller = voiceController ?: AgyVoiceInputController(
            context = context,
            onListeningChanged = { listening ->
                _isVoiceListeningFlow.value = listening
                runOnMain {
                    updateVoiceMicUi(listening)
                    renderHudWindow()
                }
            },
            onPartialText = { partial ->
                runOnMain {
                    inputEditText?.setText(partial)
                    inputEditText?.setSelection(partial.length)
                    updateInlineComposerControls()
                }
            },
            onFinalText = { finalText ->
                runOnMain {
                    inputEditText?.setText(finalText)
                    inputEditText?.setSelection(finalText.length)
                    updateInlineComposerControls()
                }
            },
            onErrorMessage = { err ->
                runOnMain {
                    composerVoiceStatusHint?.apply {
                        visibility = View.VISIBLE
                        text = err
                        setTextColor(COLOR_AMBER)
                    }
                    mainHandler.postDelayed({
                        if (!_isVoiceListeningFlow.value) {
                            composerVoiceStatusHint?.visibility = View.GONE
                        }
                    }, 2200L)
                }
            }
        ).also { voiceController = it }
        controller.toggleListening()
    }

    private fun updateVoiceMicUi(listening: Boolean) {
        composerVoiceStatusHint?.apply {
            visibility = if (listening) View.VISIBLE else View.GONE
            if (listening) {
                text = "● Listening…"
                setTextColor(COLOR_CORAL)
            }
        }
        inputMicBtn?.setStyle(
            glyph = AgyGlyphButtonView.Glyph.MIC,
            bgFill = if (listening) COLOR_CORAL else Color.WHITE,
            bgStroke = if (listening) COLOR_CORAL else COLOR_HAIRLINE,
            iconTint = if (listening) Color.WHITE else COLOR_TEXT_SECONDARY,
            strokeDp = 0.85f
        )
    }

    private fun renderInputMacrosStrip() {
        val host = inputMacrosContainer ?: return
        val scroll = inputMacrosScrollView ?: return
        val macros = _pinnedMacrosFlow.value
        val d = density()
        host.removeAllViews()
        if (macros.isEmpty() || !isMacrosDrawerOpen) {
            scroll.visibility = View.GONE
            return
        }
        scroll.visibility = View.VISIBLE
        macros.take(8).forEachIndexed { idx, macro ->
            val chipRow = LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding((8 * d).toInt(), (4 * d).toInt(), (10 * d).toInt(), (4 * d).toInt())
                background = createLiquidGlassDrawable(
                    fillColor = Color.parseColor("#F5F6F8"),
                    strokeColor = COLOR_HAIRLINE,
                    radiusDp = 999f,
                    strokeDp = 0.75f
                )
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { marginEnd = (6 * d).toInt() }
                contentDescription = "${HUD_NODE_TAG_PREFIX}macro_chip_$idx"
                attachSpringPressFeedback(0.94f)
                setOnClickListener {
                    cancelAutoCollapse()
                    isMacrosDrawerOpen = false
                    enqueueAndBroadcastCommand(text = macro.prompt, action = "PROMPT")
                    onMacroUsed?.invoke(macro.id)
                    releaseInputFocusToTermux()
                    isCollapsed = false
                    renderHudWindow()
                }
            }
            val badge = AgyIconBadgeView(context).apply {
                val sz = (15 * d).toInt()
                layoutParams = LinearLayout.LayoutParams(sz, sz).apply { marginEnd = (5 * d).toInt() }
                setIcon(
                    AgyAppIconResolver.resolve(
                        context = context,
                        explicitIcon = macro.iconHint,
                        explicitPackage = "",
                        fallbackText = "${macro.title} ${macro.prompt}"
                    )
                )
            }
            val lbl = TextView(context).apply {
                text = macro.title
                textSize = 10.5f
                setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
                setTextColor(COLOR_TEXT_PRIMARY)
                maxLines = 1
            }
            chipRow.addView(badge)
            chipRow.addView(lbl)
            host.addView(chipRow)
        }
        tagTreeForSelfExclusion(scroll, "macro_strip")
    }

    private fun updateInlineComposerControls() {
        val state = _hudState.value
        val draft = inputEditText?.text?.toString()?.trim().orEmpty()
        val hasDraft = draft.isNotEmpty()
        val st = state.state
        val isStopping = st == "STOPPING"
        val isActiveRun = st == "WORKING" || st == "PAUSED" || st == "NEEDS_INPUT" || isStopping
        val isListening = _isVoiceListeningFlow.value
        val hasMacros = _pinnedMacrosFlow.value.isNotEmpty()
        val baseAccent = when (st) {
            "WORKING" -> COLOR_CYAN
            "PAUSED", "NEEDS_INPUT" -> COLOR_AMBER
            "STOPPING", "STOPPED" -> COLOR_CORAL
            "DONE" -> COLOR_EMERALD
            else -> COLOR_VIOLET
        }
        val resolvedTheme = AgyHudDynamicModels.resolveTheme(state.theme, baseAccent)
        val layoutCfg = state.layout

        // Focus/voice glow border on the integrated bottom text field capsule (dark/light/custom adaptive)
        composerInputCapsule?.background = createLiquidGlassDrawable(
            fillColor = if (isInputFocused || isListening) resolvedTheme.surface else resolvedTheme.secondarySurface,
            strokeColor = when {
                isListening || isStopping -> COLOR_CORAL
                isInputFocused -> resolvedTheme.accent
                st == "NEEDS_INPUT" -> COLOR_AMBER
                else -> resolvedTheme.border
            },
            radiusDp = 999f,
            strokeDp = if (isInputFocused || isListening || isStopping) 1.35f else 0.9f
        )

        inputEditText?.setTextColor(resolvedTheme.textPrimary)
        inputEditText?.setHintTextColor(resolvedTheme.textSecondary)
        inputEditText?.hint = when {
            isListening -> "Listening…"
            isStopping -> "Tap ■ to force-stop…"
            layoutCfg.inputPlaceholder.isNotBlank() -> layoutCfg.inputPlaceholder
            st == "NEEDS_INPUT" -> "Reply to Agy…"
            st == "WORKING" || st == "PAUSED" -> "Message Agy…"
            else -> "Ask Agy…"
        }

        // Dynamic Mic visibility & theme tint
        inputMicBtn?.apply {
            visibility = if (layoutCfg.showMic) View.VISIBLE else View.GONE
            if (!isListening) {
                setStyle(
                    glyph = AgyGlyphButtonView.Glyph.MIC,
                    bgFill = resolvedTheme.surface,
                    bgStroke = resolvedTheme.border,
                    iconTint = resolvedTheme.textSecondary,
                    strokeDp = 0.85f
                )
            }
        }

        // Show subtle vector clear X only when text is entered
        clearDraftBtn?.visibility = if (hasDraft) View.VISIBLE else View.GONE

        // Show ⚡ Macros toggle button cleanly when pinned macros exist and enabled by layout
        macrosToggleBtn?.apply {
            visibility = if (hasMacros && layoutCfg.showMacros) View.VISIBLE else View.GONE
            setStyle(
                glyph = AgyGlyphButtonView.Glyph.BOLT,
                bgFill = if (isMacrosDrawerOpen) Color.argb(30, Color.red(resolvedTheme.accent), Color.green(resolvedTheme.accent), Color.blue(resolvedTheme.accent)) else resolvedTheme.surface,
                bgStroke = if (isMacrosDrawerOpen) Color.argb(105, Color.red(resolvedTheme.accent), Color.green(resolvedTheme.accent), Color.blue(resolvedTheme.accent)) else resolvedTheme.border,
                iconTint = if (isMacrosDrawerOpen) resolvedTheme.accent else resolvedTheme.textSecondary,
                strokeDp = 0.8f
            )
        }

        // Morph trailing orb between vector Send (↑), Stop (■), and solid coral Force-Stop (■)
        composerActionBtn?.let { btn ->
            val showStopOrb = !hasDraft && isActiveRun && layoutCfg.showStopButton
            val nextGlyph = if (showStopOrb) AgyGlyphButtonView.Glyph.STOP_SQUARE else AgyGlyphButtonView.Glyph.SEND_UP
            val glyphChanged = btn.glyph != nextGlyph
            if (showStopOrb) {
                if (isStopping) {
                    // Stage 2 ready: solid coral button indicates "Tap again to Force-Stop"
                    btn.setStyle(
                        glyph = AgyGlyphButtonView.Glyph.STOP_SQUARE,
                        bgFill = COLOR_CORAL,
                        bgStroke = COLOR_CORAL,
                        iconTint = Color.WHITE,
                        strokeDp = 1.1f
                    )
                    btn.contentDescription = "${HUD_NODE_TAG_PREFIX}force_stop_btn"
                } else {
                    btn.setStyle(
                        glyph = AgyGlyphButtonView.Glyph.STOP_SQUARE,
                        bgFill = Color.parseColor("#1AE11D48"),
                        bgStroke = Color.parseColor("#66E11D48"),
                        iconTint = COLOR_CORAL,
                        strokeDp = 1.0f
                    )
                    btn.contentDescription = "${HUD_NODE_TAG_PREFIX}stop_btn"
                }
            } else {
                val activeFill = when {
                    hasDraft -> resolvedTheme.accent
                    st == "NEEDS_INPUT" -> COLOR_AMBER
                    else -> Color.argb(30, Color.red(resolvedTheme.accent), Color.green(resolvedTheme.accent), Color.blue(resolvedTheme.accent))
                }
                btn.setStyle(
                    glyph = AgyGlyphButtonView.Glyph.SEND_UP,
                    bgFill = activeFill,
                    bgStroke = if (hasDraft || st == "NEEDS_INPUT") activeFill else Color.argb(80, Color.red(resolvedTheme.accent), Color.green(resolvedTheme.accent), Color.blue(resolvedTheme.accent)),
                    iconTint = if (hasDraft || st == "NEEDS_INPUT") Color.WHITE else resolvedTheme.accent,
                    strokeDp = 0.85f
                )
                btn.contentDescription = "${HUD_NODE_TAG_PREFIX}send_btn"
            }
            if (glyphChanged) {
                btn.animate().cancel()
                btn.scaleX = 0.78f
                btn.scaleY = 0.78f
                btn.animate()
                    .scaleX(1f)
                    .scaleY(1f)
                    .setDuration(190L)
                    .setInterpolator(android.view.animation.OvershootInterpolator(1.6f))
                    .start()
            }
        }
    }

    // -------------------------------------------------------------------------
    // Ghost Pass-Through, Opacity, Timers & Pulse Helpers
    // -------------------------------------------------------------------------

    private fun cycleOpacityInternal() {
        opacityIndex = (opacityIndex + 1) % OPACITY_LEVELS.size
        renderHudWindow()
    }

    private fun setGhostModeInternal(enabled: Boolean) {
        ghostPassThrough = enabled
        applyTouchableFlagsInternal(touchable = !enabled && !temporaryPassThroughActive)
        if (enabled) {
            showGhostRestorePillInternal()
        } else {
            hideGhostRestorePillInternal()
        }
        renderHudWindow()
    }

    private fun showGhostRestorePillInternal() {
        if (ghostRestoreView != null) return
        val wm = windowManager ?: return
        val d = density()
        val restoreBtn = TextView(context).apply {
            text = "👻 Un-Ghost"
            textSize = 10f
            setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
            setTextColor(COLOR_AMBER)
            setPadding((10 * d).toInt(), (5 * d).toInt(), (10 * d).toInt(), (5 * d).toInt())
            background = createLiquidGlassDrawable(
                fillColor = COLOR_OBSIDIAN_GLASS,
                strokeColor = COLOR_AMBER,
                radiusDp = 999f,
                strokeDp = 1f
            )
            setOnClickListener { setGhostModeInternal(false) }
        }
        tagTreeForSelfExclusion(restoreBtn, "ghost_restore")
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayWindowType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.END
            x = (14 * d).toInt()
            y = ((hudParams?.y ?: (28 * d).toInt()) + (235 * d).toInt())
        }
        ghostRestoreView = restoreBtn
        ghostRestoreParams = params
        try {
            wm.addView(restoreBtn, params)
        } catch (_: Exception) {
            ghostRestoreView = null
            ghostRestoreParams = null
        }
    }

    private fun hideGhostRestorePillInternal() {
        ghostRestoreView?.let { v ->
            try {
                windowManager?.removeView(v)
            } catch (_: Exception) {}
        }
        ghostRestoreView = null
        ghostRestoreParams = null
    }

    private fun applyTouchableFlagsInternal(touchable: Boolean) {
        fun updateWindow(view: View?, params: WindowManager.LayoutParams?) {
            if (view == null || params == null) return
            params.flags = if (touchable) {
                params.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
            } else {
                params.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
            }
            try {
                windowManager?.updateViewLayout(view, params)
            } catch (_: Exception) {}
        }
        updateWindow(hudRootView, hudParams)
    }

    private fun scheduleAutoCollapse(seconds: Int) {
        cancelAutoCollapse()
        val task = Runnable {
            if (isInputFocused || _isVoiceListeningFlow.value) return@Runnable
            isCollapsed = true
            blurInlineComposerInternal()
            if (hudRootView != null) {
                renderHudWindow()
            }
        }
        autoCollapseRunnable = task
        mainHandler.postDelayed(task, seconds * 1000L)
    }

    private fun cancelAutoCollapse() {
        autoCollapseRunnable?.let { mainHandler.removeCallbacks(it) }
        autoCollapseRunnable = null
    }

    private fun syncPulseAnimation() {
        val state = _hudState.value.state
        val shouldPulse = _isHudVisible.value && (state == "WORKING" || state == "NEEDS_INPUT" || state == "STOPPING")
        if (shouldPulse && pulseRunnable == null) {
            val runner = object : Runnable {
                override fun run() {
                    if (!_isHudVisible.value) {
                        stopPulseAnimation()
                        return
                    }
                    pulseToggle = !pulseToggle
                    statusDotView?.alpha = if (pulseToggle) 1.0f else 0.35f
                    if (_hudState.value.state == "NEEDS_INPUT") {
                        questionBannerText?.alpha = if (pulseToggle) 1.0f else 0.72f
                    } else {
                        questionBannerText?.alpha = 1.0f
                    }
                    if (_hudState.value.state == "STOPPING") {
                        composerActionBtn?.alpha = if (pulseToggle) 1.0f else 0.72f
                    } else {
                        composerActionBtn?.alpha = 1.0f
                    }
                    mainHandler.postDelayed(this, 650L)
                }
            }
            pulseRunnable = runner
            mainHandler.postDelayed(runner, 650L)
        } else if (!shouldPulse) {
            stopPulseAnimation()
        }
    }

    private fun stopPulseAnimation() {
        pulseRunnable?.let { mainHandler.removeCallbacks(it) }
        pulseRunnable = null
        statusDotView?.alpha = 1.0f
        questionBannerText?.alpha = 1.0f
        composerActionBtn?.alpha = 1.0f
    }

    private fun startElapsedTimer() {
        stopElapsedTimer()
        val ticker = object : Runnable {
            override fun run() {
                if (_hudState.value.state != "WORKING") {
                    stopElapsedTimer()
                    return
                }
                if (activeSegmentStartMs > 0L) {
                    _elapsedMsFlow.value = computeCurrentElapsedMs()
                    updateElapsedTimerDisplay()
                }
                mainHandler.postDelayed(this, 100L)
            }
        }
        elapsedTimerRunnable = ticker
        mainHandler.postDelayed(ticker, 100L)
    }

    private fun stopElapsedTimer() {
        elapsedTimerRunnable?.let { mainHandler.removeCallbacks(it) }
        elapsedTimerRunnable = null
    }

    private fun updateElapsedTimerDisplay() {
        val hud = _hudState.value
        val st = hud.state
        val elapsed = _elapsedMsFlow.value
        val resolvedTheme = AgyHudDynamicModels.resolveTheme(hud.theme, COLOR_CYAN)
        elapsedTimerText?.let { tv ->
            if (!hud.timerVisible) {
                tv.visibility = View.GONE
            } else if (hud.customTimerText.isNotBlank()) {
                tv.visibility = View.VISIBLE
                tv.text = "· ${hud.customTimerText}"
                tv.setTextColor(resolvedTheme.textSecondary)
            } else when {
                st == "WORKING" -> {
                    tv.visibility = View.VISIBLE
                    tv.text = "· ${formatElapsed(elapsed, isDone = false)}"
                    tv.setTextColor(resolvedTheme.textSecondary)
                }
                st == "PAUSED" -> {
                    tv.visibility = View.VISIBLE
                    tv.text = "· ${formatElapsed(elapsed, isDone = false)}"
                    tv.setTextColor(COLOR_AMBER)
                }
                st == "STOPPING" || (st == "STOPPED" && elapsed > 0L) -> {
                    tv.visibility = View.VISIBLE
                    tv.text = "· ${formatElapsed(elapsed, isDone = false)}"
                    tv.setTextColor(COLOR_CORAL)
                }
                st == "DONE" && elapsed > 0L -> {
                    tv.visibility = View.VISIBLE
                    tv.text = "· ${formatElapsed(elapsed, isDone = true).removePrefix("Done ")}"
                    tv.setTextColor(COLOR_EMERALD)
                }
                st == "NEEDS_INPUT" && elapsed > 0L -> {
                    tv.visibility = View.VISIBLE
                    tv.text = "· ${formatElapsed(elapsed, isDone = false)}"
                    tv.setTextColor(COLOR_AMBER)
                }
                else -> {
                    tv.visibility = View.GONE
                }
            }
        }
        dockLiveTimerText?.let { liveTv ->
            if (!hud.timerVisible) {
                liveTv.visibility = View.GONE
            } else if (hud.customTimerText.isNotBlank()) {
                liveTv.visibility = View.VISIBLE
                liveTv.text = hud.customTimerText
            } else if (st == "WORKING" || st == "PAUSED" || st == "STOPPING") {
                liveTv.visibility = View.VISIBLE
                liveTv.text = formatElapsed(elapsed, isDone = false)
                liveTv.setTextColor(if (st == "PAUSED") COLOR_AMBER else COLOR_TEXT_SECONDARY)
            }
        }
    }

    private fun snapHudToNearestEdge() {
        val root = hudRootView ?: return
        val params = hudParams ?: return
        val d = density()
        val screenW = context.resources.displayMetrics.widthPixels.coerceAtLeast(360)
        val viewW = root.width.takeIf { it > 0 } ?: (220 * d).toInt()
        val marginPx = (14 * d).toInt()
        val maxX = (screenW - viewW - marginPx).coerceAtLeast(marginPx)
        val targetX = if (params.x > maxX / 2) maxX else marginPx
        val startX = params.x
        if (startX == targetX) return

        edgeSnapAnimator?.cancel()
        edgeSnapAnimator = android.animation.ValueAnimator.ofInt(startX, targetX).apply {
            duration = 250L
            interpolator = android.view.animation.OvershootInterpolator(0.75f)
            addUpdateListener { anim ->
                val nextX = anim.animatedValue as Int
                params.x = nextX.coerceIn(0, maxX + marginPx)
                try {
                    windowManager?.updateViewLayout(root, params)
                } catch (_: Exception) {}
            }
            start()
        }
    }

    // -------------------------------------------------------------------------
    // Utility Helpers
    // -------------------------------------------------------------------------

    private fun shiftBottomRightWindow(
        root: View,
        params: WindowManager.LayoutParams,
        dx: Float,
        dy: Float
    ) {
        val screenW = context.resources.displayMetrics.widthPixels
        val screenH = context.resources.displayMetrics.heightPixels
        val viewW = root.width.takeIf { it > 0 } ?: (120 * density()).toInt()
        val viewH = root.height.takeIf { it > 0 } ?: (56 * density()).toInt()
        // Anchored BOTTOM | END: dragging left increases x, dragging up increases y
        params.x = (params.x - dx.toInt()).coerceIn(0, (screenW - viewW).coerceAtLeast(0))
        params.y = (params.y - dy.toInt()).coerceIn(0, (screenH - viewH).coerceAtLeast(0))
        try {
            windowManager?.updateViewLayout(root, params)
        } catch (_: Exception) {}
    }

    private fun createLiquidGlassDrawable(
        fillColor: Int,
        strokeColor: Int,
        radiusDp: Float,
        strokeDp: Float = 1.2f
    ): GradientDrawable {
        val d = density()
        return GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = radiusDp * d
            setColor(fillColor)
            setStroke((strokeDp * d).toInt().coerceAtLeast(1), strokeColor)
        }
    }

    private fun tagTreeForSelfExclusion(view: View, suffix: String) {
        val existing = view.contentDescription?.toString()
        if (existing.isNullOrBlank() || !existing.startsWith(HUD_NODE_TAG_PREFIX)) {
            view.contentDescription = "$HUD_NODE_TAG_PREFIX$suffix"
        }
        view.tag = "$HUD_NODE_TAG_PREFIX$suffix"
        if (view is ViewGroup) {
            for (i in 0 until view.childCount) {
                tagTreeForSelfExclusion(view.getChildAt(i), "${suffix}_$i")
            }
        }
    }

    private fun overlayWindowType(): Int {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }
    }

    private fun density(): Float = context.resources.displayMetrics.density.coerceAtLeast(1f)

    private fun runOnMain(block: () -> Unit) {
        if (Looper.myLooper() == Looper.getMainLooper()) {
            block()
        } else {
            mainHandler.post(block)
        }
    }
}
