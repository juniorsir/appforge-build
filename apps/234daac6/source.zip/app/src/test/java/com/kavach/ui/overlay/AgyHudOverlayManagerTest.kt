package com.kavach.ui.overlay

import android.content.Context
import android.graphics.Rect
import androidx.test.core.app.ApplicationProvider
import com.kavach.accessibility.AccessibilityRepositoryImpl
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class AgyHudOverlayManagerTest {

    private lateinit var context: Context
    private lateinit var floatingOverlayManager: FloatingOverlayManager
    private lateinit var hudManager: AgyHudOverlayManager
    private val broadcastedCommands = mutableListOf<JSONObject>()

    @Before
    fun setUp() {
        context = ApplicationProvider.getApplicationContext()
        floatingOverlayManager = FloatingOverlayManager(context)
        broadcastedCommands.clear()
        hudManager = AgyHudOverlayManager(
            context = context,
            floatingOverlayManager = floatingOverlayManager,
            onCommandBroadcast = { cmd -> broadcastedCommands.add(cmd) }
        )
    }

    @Test
    fun `updateState parses tasks, question, autoCollapseSeconds, and screenWatch wireframe`() {
        val payload = JSONObject().apply {
            put("state", "WORKING")
            put("title", "Configure Termux Bridge")
            put("currentAction", "Tapping Connect button")
            put("nextAction", "Verify WebSocket live")
            put("autoCollapseSeconds", 5)
            put("tasks", JSONArray().apply {
                put(JSONObject().put("id", "t1").put("label", "Inspect screen").put("status", "done"))
                put(JSONObject().put("id", "t2").put("label", "Tap Connect").put("status", "doing"))
                put(JSONObject().put("id", "t3").put("label", "Verify reply").put("status", "pending"))
            })
            put("screenWatch", JSONObject().apply {
                put("active", true)
                put("label", "Settings Screen")
                put("screenWidth", 1080)
                put("screenHeight", 2400)
                put("zones", JSONArray().apply {
                    put(
                        JSONObject()
                            .put("x1", 700).put("y1", 400)
                            .put("x2", 1000).put("y2", 520)
                            .put("role", "target").put("tag", "Connect")
                    )
                })
                put(
                    "actionVector",
                    JSONObject()
                        .put("type", "TAP")
                        .put("x1", 850).put("y1", 460)
                        .put("x2", 850).put("y2", 460)
                )
            })
        }

        val res = hudManager.updateState(payload)
        assertTrue(res.optBoolean("success"))
        assertEquals("WORKING", res.optString("state"))
        assertEquals(3, res.optInt("taskCount"))
        assertTrue(res.optBoolean("screenWatchActive"))

        val stored = hudManager.hudState.value
        assertEquals("Configure Termux Bridge", stored.title)
        assertEquals(5, stored.autoCollapseSeconds)
        assertEquals("done", stored.tasks[0].status)
        assertEquals("doing", stored.tasks[1].status)
        assertEquals("pending", stored.tasks[2].status)
        assertTrue(stored.screenWatch.active)
        assertEquals(1, stored.screenWatch.zones.size)
        assertNotNull(stored.screenWatch.actionVector)
        assertEquals("TAP", stored.screenWatch.actionVector?.type)
    }

    @Test
    fun `remote PROMPT and STOP commands broadcast over WS callback and drain via poll`() {
        val promptRes = hudManager.handleRemoteCommand(
            JSONObject().put("action", "PROMPT").put("text", "List files in Termux")
        )
        assertTrue(promptRes.optBoolean("success"))

        val stopRes = hudManager.handleRemoteCommand(
            JSONObject().put("action", "STOP")
        )
        assertTrue(stopRes.optBoolean("success"))

        assertEquals(2, broadcastedCommands.size)
        assertEquals("HUD_COMMAND", broadcastedCommands[0].optString("type"))
        assertEquals("PROMPT", broadcastedCommands[0].optString("action"))
        assertEquals("List files in Termux", broadcastedCommands[0].optString("text"))
        assertEquals("STOP", broadcastedCommands[1].optString("action"))

        val poll1 = hudManager.pollCommands()
        assertTrue(poll1.optBoolean("success"))
        assertEquals(2, poll1.optInt("count"))
        val cmds = poll1.getJSONArray("commands")
        assertEquals("PROMPT", cmds.getJSONObject(0).optString("action"))
        assertEquals("STOP", cmds.getJSONObject(1).optString("action"))

        // Second poll should be empty (atomic drain)
        val poll2 = hudManager.pollCommands()
        assertEquals(0, poll2.optInt("count"))
    }

    @Test
    fun `accessibility repository self-excludes agy_hud_ prefixed nodes`() {
        val repo = AccessibilityRepositoryImpl()
        assertTrue(repo.isAgyHudIdentifier("com.kavach:id/agy_hud_window2", null))
        assertTrue(repo.isAgyHudIdentifier(null, "agy_hud_prompt_input"))
        assertTrue(repo.isAgyHudIdentifier("AGY_HUD_WIREFRAME", null))
        assertFalse(repo.isAgyHudIdentifier("com.termux:id/terminal_view", "Terminal"))
    }

    @Test
    fun `touch collision overlap detects TAP and SWIPE intersecting overlay bounds`() {
        val hudRect = listOf(Rect(650, 1800, 1050, 2320))
        // TAP inside HUD
        assertTrue(hudManager.coordinatesOverlapRects(800f, 2000f, 800f, 2000f, hudRect))
        // TAP outside HUD
        assertFalse(hudManager.coordinatesOverlapRects(200f, 400f, 200f, 400f, hudRect))
        // SWIPE crossing through HUD
        assertTrue(hudManager.coordinatesOverlapRects(500f, 2100f, 950f, 2100f, hudRect))
        // SWIPE completely above HUD
        assertFalse(hudManager.coordinatesOverlapRects(100f, 500f, 900f, 500f, hudRect))
    }

    @Test
    fun `mini wireframe view collapses to 0dp when screenWatch is inactive`() {
        val wf = MiniScreenWireframeView(context)
        wf.updateScreenWatch(
            AgyHudOverlayManager.ScreenWatchState(active = false),
            wireframeVisible = true
        )
        assertEquals(android.view.View.GONE, wf.visibility)
        wf.measure(
            android.view.View.MeasureSpec.makeMeasureSpec(400, android.view.View.MeasureSpec.AT_MOST),
            android.view.View.MeasureSpec.makeMeasureSpec(400, android.view.View.MeasureSpec.AT_MOST)
        )
        assertEquals(0, wf.measuredHeight)
        assertEquals(0, wf.measuredWidth)

        wf.updateScreenWatch(
            AgyHudOverlayManager.ScreenWatchState(
                active = true,
                screenWidth = 1080,
                screenHeight = 2400
            ),
            wireframeVisible = true
        )
        assertEquals(android.view.View.VISIBLE, wf.visibility)
        wf.measure(
            android.view.View.MeasureSpec.makeMeasureSpec(400, android.view.View.MeasureSpec.AT_MOST),
            android.view.View.MeasureSpec.makeMeasureSpec(400, android.view.View.MeasureSpec.AT_MOST)
        )
        assertTrue(wf.measuredHeight > 0)
        assertTrue(wf.measuredWidth > 0)
    }

    @Test
    fun `app icon resolver maps yt, youtube, whatsapp, chrome, termux, and generic tasks cleanly`() {
        val ytShort = AgyAppIconResolver.resolve(context, explicitIcon = "yt", explicitPackage = "", fallbackText = "")
        assertEquals(AgyAppIconResolver.BadgeKind.YOUTUBE, ytShort.kind)
        assertEquals("com.google.android.youtube", ytShort.packageName)

        val ytText = AgyAppIconResolver.resolve(context, explicitIcon = "", explicitPackage = "", fallbackText = "Open YouTube playlist")
        assertEquals(AgyAppIconResolver.BadgeKind.YOUTUBE, ytText.kind)

        val wa = AgyAppIconResolver.resolve(context, explicitIcon = "", explicitPackage = "", fallbackText = "Send WhatsApp summary")
        assertEquals(AgyAppIconResolver.BadgeKind.WHATSAPP, wa.kind)

        val chrome = AgyAppIconResolver.resolve(context, explicitIcon = "chrome", explicitPackage = "", fallbackText = "")
        assertEquals(AgyAppIconResolver.BadgeKind.CHROME, chrome.kind)

        val termux = AgyAppIconResolver.resolve(context, explicitIcon = "", explicitPackage = "", fallbackText = "Run bash script in Termux")
        assertEquals(AgyAppIconResolver.BadgeKind.TERMUX, termux.kind)

        val fallback = AgyAppIconResolver.resolve(context, explicitIcon = "", explicitPackage = "", fallbackText = "General assistance")
        assertEquals(AgyAppIconResolver.BadgeKind.SPARK_AI, fallback.kind)
    }

    @Test
    fun `updateState parses detailedOutput, outputLogs, quickActions, and per-task icon metadata`() {
        val payload = JSONObject().apply {
            put("state", "DONE")
            put("title", "YouTube Automation")
            put("icon", "youtube")
            put("appPackage", "com.google.android.youtube")
            put("currentAction", "Queued 4 videos")
            put("detailedOutput", "Added 4 AI & Android talks to Watch Later.")
            put("outputLogs", JSONArray().apply {
                put("[12:01:02] Opened YouTube")
                put("[12:01:05] Saved 4 videos")
            })
            put("quickActions", JSONArray().apply {
                put(JSONObject().put("label", "Copy Output").put("actionType", "COPY_OUTPUT"))
                put(JSONObject().put("label", "Run Again").put("commandText", "Run YouTube task again").put("actionType", "PROMPT"))
            })
            put("tasks", JSONArray().apply {
                put(
                    JSONObject()
                        .put("id", "t1")
                        .put("label", "Open YouTube")
                        .put("status", "done")
                        .put("icon", "yt")
                        .put("appPackage", "com.google.android.youtube")
                        .put("detail", "com.google.android.youtube")
                )
            })
        }

        val res = hudManager.updateState(payload)
        assertTrue(res.optBoolean("success"))

        val stored = hudManager.hudState.value
        assertEquals("youtube", stored.icon)
        assertEquals("com.google.android.youtube", stored.appPackage)
        assertEquals("Added 4 AI & Android talks to Watch Later.", stored.detailedOutput)
        assertEquals(2, stored.outputLogs.size)
        assertEquals(2, stored.quickActions.size)
        assertEquals("COPY_OUTPUT", stored.quickActions[0].actionType)
        assertEquals("yt", stored.tasks[0].icon)
        assertEquals("com.google.android.youtube", stored.tasks[0].appPackage)
        assertEquals("com.google.android.youtube", stored.tasks[0].detail)

        val copyText = hudManager.getFullOutputCopyText(stored)
        assertTrue(copyText.contains("Added 4 AI & Android talks"))
        assertTrue(copyText.contains("[12:01:02] Opened YouTube"))
    }

    @Test
    fun `TOGGLE_OUTPUT command toggles expanded drawer and formatElapsed formats seconds and minutes`() {
        assertFalse(hudManager.isOutputExpandedFlow.value)

        val toggleOn = hudManager.handleRemoteCommand(JSONObject().put("action", "TOGGLE_OUTPUT"))
        assertTrue(toggleOn.optBoolean("success"))
        assertTrue(hudManager.isOutputExpandedFlow.value)

        val toggleOff = hudManager.handleRemoteCommand(JSONObject().put("action", "TOGGLE_OUTPUT"))
        assertTrue(toggleOff.optBoolean("success"))
        assertFalse(hudManager.isOutputExpandedFlow.value)

        assertEquals("00:00.0", hudManager.formatElapsed(0L))
        assertEquals("00:04.2", hudManager.formatElapsed(4200L))
        assertEquals("01:05", hudManager.formatElapsed(65_000L))
        assertEquals("Done 4.2s", hudManager.formatElapsed(4200L, isDone = true))
    }

    @Test
    fun `collapsed live running pill resolves dynamic step, icon, and preserves collapse across WORKING updates`() {
        // 1. Entering WORKING from IDLE auto-expands the HUD
        hudManager.updateState(
            JSONObject().apply {
                put("state", "WORKING")
                put("title", "Focus Automation")
                put("currentAction", "Opening YouTube")
                put("tasks", JSONArray().apply {
                    put(
                        JSONObject()
                            .put("id", "s1")
                            .put("label", "Open YouTube & search playlist")
                            .put("status", "doing")
                            .put("icon", "youtube")
                            .put("appPackage", "com.google.android.youtube")
                    )
                    put(
                        JSONObject()
                            .put("id", "s2")
                            .put("label", "Scroll Chrome & extract summary")
                            .put("status", "pending")
                            .put("icon", "chrome")
                    )
                })
            }
        )
        assertFalse(hudManager.isCollapsedFlow.value)
        assertFalse(hudManager.isCollapsedLiveRunningMode())

        // 2. User collapses HUD during active run -> enters live running step pill mode
        hudManager.handleRemoteCommand(JSONObject().put("action", "COLLAPSE"))
        assertTrue(hudManager.isCollapsedFlow.value)
        assertTrue(hudManager.isCollapsedLiveRunningMode())

        val step1 = hudManager.resolveCollapsedRunningStep()
        assertEquals("Open YouTube & search playlist", step1.label)
        assertEquals(AgyAppIconResolver.BadgeKind.YOUTUBE, step1.icon.kind)

        // 3. Subsequent WORKING telemetry update preserves collapsed state & dynamically updates step + icon
        hudManager.updateState(
            JSONObject().apply {
                put("state", "WORKING")
                put("title", "Focus Automation")
                put("currentAction", "Scrolling Chrome article")
                put("tasks", JSONArray().apply {
                    put(JSONObject().put("id", "s1").put("label", "Open YouTube & search playlist").put("status", "done").put("icon", "youtube"))
                    put(
                        JSONObject()
                            .put("id", "s2")
                            .put("label", "Scroll Chrome & extract summary")
                            .put("status", "doing")
                            .put("icon", "chrome")
                            .put("appPackage", "com.android.chrome")
                    )
                })
            }
        )
        assertTrue(hudManager.isCollapsedFlow.value)
        assertTrue(hudManager.isCollapsedLiveRunningMode())

        val step2 = hudManager.resolveCollapsedRunningStep()
        assertEquals("Scroll Chrome & extract summary", step2.label)
        assertEquals(AgyAppIconResolver.BadgeKind.CHROME, step2.icon.kind)

        // 4. Fallback to currentAction when no doing task exists
        val fallbackStep = hudManager.resolveCollapsedRunningStep(
            AgyHudOverlayManager.AgyHudState(
                state = "WORKING",
                title = "Background Sync",
                currentAction = "Sending WhatsApp report",
                tasks = emptyList()
            )
        )
        assertEquals("Sending WhatsApp report", fallbackStep.label)
        assertEquals(AgyAppIconResolver.BadgeKind.WHATSAPP, fallbackStep.icon.kind)

        // 5. NEEDS_INPUT expands card and exits collapsed live running mode
        hudManager.updateState(
            JSONObject().apply {
                put("state", "NEEDS_INPUT")
                put("title", "Confirm Share")
                put("question", "Send link now?")
            }
        )
        assertFalse(hudManager.isCollapsedFlow.value)
        assertFalse(hudManager.isCollapsedLiveRunningMode())
    }

    @Test
    fun `PAUSE and RESUME transition state cleanly, preserve collapsed live mode, and broadcast commands`() {
        hudManager.updateState(
            JSONObject().apply {
                put("state", "WORKING")
                put("title", "Deploy Pipeline")
                put("currentAction", "Uploading APK artifact")
                put("tasks", JSONArray().apply {
                    put(JSONObject().put("id", "p1").put("label", "Upload APK").put("status", "doing").put("icon", "termux"))
                })
            }
        )
        hudManager.handleRemoteCommand(JSONObject().put("action", "COLLAPSE"))
        assertTrue(hudManager.isCollapsedLiveRunningMode())

        // Pause via remote command
        val pauseRes = hudManager.handleRemoteCommand(JSONObject().put("action", "PAUSE"))
        assertTrue(pauseRes.optBoolean("success"))
        assertEquals("PAUSED", hudManager.hudState.value.state)
        assertTrue(hudManager.isCollapsedFlow.value)
        assertTrue(hudManager.isCollapsedLiveRunningMode())
        assertTrue(broadcastedCommands.any { it.optString("action") == "PAUSE" })

        // Quick actions while paused should expose Resume
        val pausedActions = hudManager.resolveQuickActions(hudManager.hudState.value)
        assertTrue(pausedActions.any { it.actionType == "RESUME" })

        // Resume via quick action chip
        val resumeChip = pausedActions.first { it.actionType == "RESUME" }
        hudManager.executeQuickAction(resumeChip)
        assertEquals("WORKING", hudManager.hudState.value.state)
        assertTrue(hudManager.isCollapsedLiveRunningMode())
        assertTrue(broadcastedCommands.any { it.optString("action") == "RESUME" })
    }

    @Test
    fun `TOGGLE_EDGE_SNAP toggles magnetic edge-snap state and setPinnedMacros updates flow`() {
        assertTrue(hudManager.edgeSnapEnabledFlow.value)

        val offRes = hudManager.handleRemoteCommand(JSONObject().put("action", "TOGGLE_EDGE_SNAP"))
        assertTrue(offRes.optBoolean("success"))
        assertFalse(hudManager.edgeSnapEnabledFlow.value)

        val onRes = hudManager.handleRemoteCommand(JSONObject().put("action", "TOGGLE_EDGE_SNAP"))
        assertTrue(onRes.optBoolean("success"))
        assertTrue(hudManager.edgeSnapEnabledFlow.value)

        val shortcuts = listOf(
            AgyHudOverlayManager.MacroShortcut("m1", "YouTube Focus", "Open YouTube lofi", "youtube"),
            AgyHudOverlayManager.MacroShortcut("m2", "Termux Status", "Check termux daemon", "termux")
        )
        hudManager.setPinnedMacros(shortcuts)
        assertEquals(2, hudManager.pinnedMacrosFlow.value.size)
        assertEquals("YouTube Focus", hudManager.pinnedMacrosFlow.value[0].title)
    }

    @Test
    fun `onRunRecorded fires automatically on DONE completion and on STOP during active run`() {
        val recorded = mutableListOf<AgyHudOverlayManager.RunRecord>()
        val recordingManager = AgyHudOverlayManager(
            context = context,
            floatingOverlayManager = floatingOverlayManager,
            onRunRecorded = { recorded.add(it) }
        )

        // Start a run via prompt + WORKING -> DONE
        recordingManager.enqueueAndBroadcastCommand("Summarize Chrome tabs", "PROMPT")
        recordingManager.updateState(
            JSONObject().apply {
                put("state", "WORKING")
                put("title", "Chrome Summary")
                put("icon", "chrome")
                put("tasks", JSONArray().apply {
                    put(JSONObject().put("id", "t1").put("label", "Read tabs").put("status", "doing"))
                })
            }
        )
        recordingManager.updateState(
            JSONObject().apply {
                put("state", "DONE")
                put("title", "Chrome Summary")
                put("icon", "chrome")
                put("detailedOutput", "Summarized 5 open tabs cleanly.")
                put("outputLogs", JSONArray().put("[00:01] Done"))
                put("tasks", JSONArray().apply {
                    put(JSONObject().put("id", "t1").put("label", "Read tabs").put("status", "done"))
                })
            }
        )
        assertEquals(1, recorded.size)
        assertEquals("DONE", recorded[0].finalState)
        assertEquals("Chrome Summary", recorded[0].title)
        assertEquals("Summarize Chrome tabs", recorded[0].promptText)
        assertTrue(recorded[0].detailedOutput.contains("Summarized 5 open tabs"))

        // Second run stopped mid-flight -> records STOPPED entry
        recordingManager.enqueueAndBroadcastCommand("Run backup script", "PROMPT")
        recordingManager.updateState(
            JSONObject().apply {
                put("state", "WORKING")
                put("title", "Backup Script")
                put("icon", "termux")
            }
        )
        recordingManager.enqueueAndBroadcastCommand("STOP", "STOP")
        assertEquals(2, recorded.size)
        assertEquals("STOPPED", recorded[1].finalState)
        assertEquals("Backup Script", recorded[1].title)
    }

    @Test
    fun `unified single-HUD OPEN_INPUT, CLOSE_INPUT, EXPAND, and COLLAPSE synchronize card and composer state`() {
        // Start collapsed
        hudManager.handleRemoteCommand(JSONObject().put("action", "COLLAPSE"))
        assertTrue(hudManager.isCollapsedFlow.value)
        assertFalse(hudManager.isInputVisible.value)

        // OPEN_INPUT expands the unified card and activates the built-in bottom composer
        val openRes = hudManager.handleRemoteCommand(JSONObject().put("action", "OPEN_INPUT"))
        assertTrue(openRes.optBoolean("success"))
        assertFalse(hudManager.isCollapsedFlow.value)
        assertTrue(hudManager.isInputVisible.value)

        // CLOSE_INPUT releases composer focus without forcing a second window
        val closeRes = hudManager.handleRemoteCommand(JSONObject().put("action", "CLOSE_INPUT"))
        assertTrue(closeRes.optBoolean("success"))
        assertFalse(hudManager.isInputVisible.value)

        // EXPAND shows the unified card (including built-in bottom composer)
        hudManager.handleRemoteCommand(JSONObject().put("action", "COLLAPSE"))
        assertTrue(hudManager.isCollapsedFlow.value)
        val expandRes = hudManager.handleRemoteCommand(JSONObject().put("action", "EXPAND"))
        assertTrue(expandRes.optBoolean("success"))
        assertFalse(hudManager.isCollapsedFlow.value)
        assertTrue(hudManager.isInputVisible.value)

        // COLLAPSE folds unified card back to compact pill and clears input focus flag
        val collapseRes = hudManager.handleRemoteCommand(JSONObject().put("action", "COLLAPSE"))
        assertTrue(collapseRes.optBoolean("success"))
        assertTrue(hudManager.isCollapsedFlow.value)
        assertFalse(hudManager.isInputVisible.value)
    }

    @Test
    fun `aurora card layout supports INPUT_ACTIVE, VOICE_LISTENING, and emerald completion pulse cleanly`() {
        val card = AgyAuroraCardLayout(context)
        card.setRimMode(AgyAuroraCardLayout.RimMode.INPUT_ACTIVE)
        card.setRimMode(AgyAuroraCardLayout.RimMode.VOICE_LISTENING)
        card.setRimMode(AgyAuroraCardLayout.RimMode.WORKING)
        card.setRimMode(AgyAuroraCardLayout.RimMode.DONE)
        card.playCompletionPulse()
        card.setRimMode(AgyAuroraCardLayout.RimMode.IDLE)

        // Measure and dispatch draw to a bitmap canvas to ensure custom glow halo & rim rendering never throws
        card.measure(
            android.view.View.MeasureSpec.makeMeasureSpec(320, android.view.View.MeasureSpec.EXACTLY),
            android.view.View.MeasureSpec.makeMeasureSpec(240, android.view.View.MeasureSpec.EXACTLY)
        )
        card.layout(0, 0, 320, 240)
        val bmp = android.graphics.Bitmap.createBitmap(320, 240, android.graphics.Bitmap.Config.ARGB_8888)
        val canvas = android.graphics.Canvas(bmp)
        card.setRimMode(AgyAuroraCardLayout.RimMode.INPUT_ACTIVE)
        card.draw(canvas)
        card.setRimMode(AgyAuroraCardLayout.RimMode.VOICE_LISTENING)
        card.draw(canvas)
        card.setRimMode(AgyAuroraCardLayout.RimMode.DONE)
        card.playCompletionPulse()
        card.draw(canvas)
        assertTrue(card.width == 320 && card.height == 240)
    }

    @Test
    fun `opaque default opacity, temporary suppression, and drawn glyph buttons work cleanly`() {
        // Default opacity should be 100% crisp opaque so underlying screen text never bleeds through
        assertEquals(1.0f, AgyHudOverlayManager.OPACITY_LEVELS[0], 0.001f)

        // Temporary suppression for Simulator modal should toggle cleanly without crashing
        hudManager.setTemporarilySuppressed(true)
        hudManager.setTemporarilySuppressed(false)

        // All 5 custom Canvas-drawn composer glyphs should measure, layout, and draw cleanly
        val bmp = android.graphics.Bitmap.createBitmap(64, 64, android.graphics.Bitmap.Config.ARGB_8888)
        val canvas = android.graphics.Canvas(bmp)
        AgyGlyphButtonView.Glyph.values().forEach { glyph ->
            val btn = AgyGlyphButtonView(context, glyph)
            btn.setStyle(
                glyph = glyph,
                bgFill = android.graphics.Color.parseColor("#FFF0F4F9"),
                bgStroke = android.graphics.Color.parseColor("#FFD2E3FC"),
                iconTint = android.graphics.Color.parseColor("#FF1A73E8")
            )
            btn.measure(
                android.view.View.MeasureSpec.makeMeasureSpec(64, android.view.View.MeasureSpec.EXACTLY),
                android.view.View.MeasureSpec.makeMeasureSpec(64, android.view.View.MeasureSpec.EXACTLY)
            )
            btn.layout(0, 0, 64, 64)
            btn.draw(canvas)
            assertEquals(64, btn.width)
            assertEquals(64, btn.height)
        }
    }

    @Test
    fun `two-stage Stop transitions WORKING to STOPPING on first tap and FORCE_STOP to STOPPED on second tap with single history record`() {
        val recorded = mutableListOf<AgyHudOverlayManager.RunRecord>()
        val cmds = mutableListOf<JSONObject>()
        val mgr = AgyHudOverlayManager(
            context = context,
            floatingOverlayManager = floatingOverlayManager,
            onCommandBroadcast = { cmds.add(it) },
            onRunRecorded = { recorded.add(it) }
        )

        mgr.updateState(
            JSONObject().apply {
                put("state", "WORKING")
                put("title", "Long Build")
                put("currentAction", "Compiling module")
                put("tasks", JSONArray().apply {
                    put(JSONObject().put("id", "t1").put("label", "Prepare").put("status", "done"))
                    put(JSONObject().put("id", "t2").put("label", "Compile").put("status", "doing"))
                })
            }
        )
        assertEquals("WORKING", mgr.hudState.value.state)

        // Tap 1: STOP -> immediate STOPPING state + broadcasts STOP
        val res1 = mgr.handleRemoteCommand(JSONObject().put("action", "STOP"))
        assertTrue(res1.optBoolean("success"))
        assertEquals("STOPPING", mgr.hudState.value.state)
        assertEquals(1, cmds.size)
        assertEquals("STOP", cmds[0].optString("action"))

        // Tap 2 while STOPPING -> FORCE_STOP -> immediate STOPPED locally, doing task marked stopped, single history record
        val res2 = mgr.handleRemoteCommand(JSONObject().put("action", "STOP"))
        assertTrue(res2.optBoolean("success"))
        assertEquals("STOPPED", mgr.hudState.value.state)
        assertEquals(2, cmds.size)
        assertEquals("FORCE_STOP", cmds[1].optString("action"))
        assertEquals("done", mgr.hudState.value.tasks[0].status)
        assertEquals("stopped", mgr.hudState.value.tasks[1].status)
        assertEquals(1, recorded.size)
        assertEquals("STOPPED", recorded[0].finalState)
    }

    @Test
    fun `graceful Agy confirmation from STOPPING transitions cleanly to DONE`() {
        hudManager.updateState(
            JSONObject()
                .put("state", "WORKING")
                .put("title", "Sync Task")
                .put("currentAction", "Uploading")
        )
        hudManager.handleRemoteCommand(JSONObject().put("action", "STOP"))
        assertEquals("STOPPING", hudManager.hudState.value.state)

        // Agy finishes gracefully and confirms DONE
        hudManager.updateState(
            JSONObject()
                .put("state", "DONE")
                .put("title", "Sync Task")
                .put("currentAction", "Gracefully cancelled and cleaned up")
        )
        assertEquals("DONE", hudManager.hudState.value.state)
        assertEquals("Gracefully cancelled and cleaned up", hudManager.hudState.value.currentAction)
    }

    @Test
    fun `full dynamic schema parses theme, layout, progress, metrics, banner, blocks, custom status, and styled quickActions`() {
        val payload = JSONObject().apply {
            put("state", "WORKING")
            put("statusLabel", "Deploying")
            put("customEmoji", "🚀")
            put("timerVisible", true)
            put("customTimerText", "ETA 12s")
            put("title", "Dynamic Dark Build")
            put("currentAction", "Pushing release bundle")
            put("theme", JSONObject().apply {
                put("mode", "dark")
                put("accentColor", "#38BDF8")
                put("auroraColors", JSONArray().put("#38BDF8").put("#8B5CF6"))
                put("auroraEnabled", true)
                put("cornerRadiusDp", 20)
                put("opacity", 0.92)
            })
            put("layout", JSONObject().apply {
                put("collapsed", false)
                put("detailsExpanded", true)
                put("showComposer", true)
                put("showMic", false)
                put("showMacros", false)
                put("showStopButton", true)
                put("inputPlaceholder", "Send override…")
                put("position", "top")
                put("widthFraction", 0.86)
            })
            put("progress", JSONObject().apply {
                put("visible", true)
                put("value", 62.5)
                put("label", "Chunks 5/8")
                put("color", "#38BDF8")
            })
            put("metrics", JSONArray().apply {
                put(JSONObject().put("id", "cpu").put("label", "CPU").put("value", "41%").put("accentColor", "#38BDF8"))
                put(JSONObject().put("id", "ram").put("label", "RAM").put("value", "1.2GB"))
            })
            put("banner", JSONObject().apply {
                put("visible", true)
                put("level", "warning")
                put("title", "Rate Limit")
                put("message", "Backing off 2s")
            })
            put("blocks", JSONArray().apply {
                put(JSONObject().apply {
                    put("id", "b_kv")
                    put("type", "kv")
                    put("title", "Target")
                    put("items", JSONArray().put(JSONObject().put("key", "Env").put("value", "Prod")))
                })
                put(JSONObject().apply {
                    put("id", "b_code")
                    put("type", "code")
                    put("body", "echo ok")
                    put("inDetails", true)
                })
            })
            put("buttons", JSONArray().apply {
                put(JSONObject()
                    .put("id", "btn_boost")
                    .put("label", "Boost")
                    .put("style", "primary")
                    .put("actionType", "CUSTOM")
                    .put("payload", JSONObject().put("workers", 8)))
            })
        }

        val res = hudManager.updateState(payload)
        assertTrue(res.optBoolean("success"))

        val s = hudManager.hudState.value
        assertEquals("Deploying", s.statusLabel)
        assertEquals("🚀", s.customEmoji)
        assertEquals("ETA 12s", s.customTimerText)
        assertEquals("dark", s.theme.mode)
        assertEquals("#38BDF8", s.theme.accentColor)
        assertEquals(20f, s.theme.cornerRadiusDp ?: 0f, 0.01f)
        assertEquals(0.92f, s.theme.opacity ?: 0f, 0.01f)
        assertFalse(s.layout.showMic)
        assertEquals("Send override…", s.layout.inputPlaceholder)
        assertEquals("top", s.layout.position)
        assertTrue(s.progress.visible)
        assertEquals(62.5f, s.progress.value, 0.01f)
        assertEquals(2, s.metrics.size)
        assertEquals("41%", s.metrics[0].value)
        assertTrue(s.banner.visible)
        assertEquals("warning", s.banner.level)
        assertEquals(2, s.blocks.size)
        assertEquals("kv", s.blocks[0].type)
        assertTrue(s.blocks[1].inDetails)
        assertEquals(1, s.quickActions.size)
        assertEquals("btn_boost", s.quickActions[0].id)
        assertEquals("primary", s.quickActions[0].style)

        // Roundtrip serialization check
        val roundtrip = hudManager.parseHudStateFromJson(s.toJson())
        assertEquals(s.statusLabel, roundtrip.statusLabel)
        assertEquals(s.customEmoji, roundtrip.customEmoji)
        assertEquals(s.theme.mode, roundtrip.theme.mode)
        assertEquals(s.progress.value, roundtrip.progress.value, 0.01f)
        assertEquals(s.metrics.size, roundtrip.metrics.size)
        assertEquals(s.blocks.size, roundtrip.blocks.size)
    }

    @Test
    fun `patchState applies surgical partial updates without wiping untouched fields and resetState restores defaults`() {
        hudManager.updateState(
            JSONObject().apply {
                put("state", "WORKING")
                put("title", "Data Pipeline")
                put("currentAction", "Stage 1")
                put("theme", JSONObject().put("mode", "dark").put("accentColor", "#8B5CF6"))
                put("tasks", JSONArray().apply {
                    put(JSONObject().put("id", "s1").put("label", "Extract").put("status", "doing"))
                    put(JSONObject().put("id", "s2").put("label", "Transform").put("status", "pending"))
                })
                put("metrics", JSONArray().apply {
                    put(JSONObject().put("id", "rows").put("label", "Rows").put("value", "100"))
                })
                put("outputLogs", JSONArray().put("[00:01] Started"))
            }
        )

        // Patch progress, upsertTask, appendLog, upsertMetric, setBanner, upsertBlock, setTheme, setLayout
        val patchRes = hudManager.patchState(
            JSONObject().apply {
                put("setProgress", JSONObject().put("visible", true).put("value", 75).put("label", "75% complete"))
                put("upsertTask", JSONObject().put("id", "s1").put("label", "Extract").put("status", "done"))
                put("appendLogs", JSONArray().put("[00:02] Extracted").put("[00:03] Transforming"))
                put("upsertMetric", JSONObject().put("id", "rows").put("label", "Rows").put("value", "420"))
                put("setBanner", JSONObject().put("visible", true).put("level", "success").put("message", "Halfway!"))
                put("upsertBlock", JSONObject().put("id", "blk1").put("type", "text").put("body", "Streaming OK"))
                put("setTheme", JSONObject().put("cornerRadiusDp", 18))
                put("setLayout", JSONObject().put("inputPlaceholder", "Filter rows…"))
            }
        )
        assertTrue(patchRes.optBoolean("success"))

        val patched = hudManager.hudState.value
        // Untouched fields preserved!
        assertEquals("Data Pipeline", patched.title)
        assertEquals("dark", patched.theme.mode)
        assertEquals("#8B5CF6", patched.theme.accentColor)
        // Patched fields applied!
        assertEquals(18f, patched.theme.cornerRadiusDp ?: 0f, 0.01f)
        assertEquals("Filter rows…", patched.layout.inputPlaceholder)
        assertEquals(75f, patched.progress.value, 0.01f)
        assertEquals("done", patched.tasks.first { it.id == "s1" }.status)
        assertEquals(2, patched.tasks.size)
        assertEquals(3, patched.outputLogs.size)
        assertEquals("420", patched.metrics.first { it.id == "rows" }.value)
        assertTrue(patched.banner.visible)
        assertEquals(1, patched.blocks.size)

        // Remove task + removeMetric + clearWidgets
        hudManager.patchState(
            JSONObject()
                .put("removeTask", "s2")
                .put("removeMetric", "rows")
                .put("clearWidgets", true)
        )
        assertEquals(1, hudManager.hudState.value.tasks.size)
        assertTrue(hudManager.hudState.value.metrics.isEmpty())
        assertFalse(hudManager.hudState.value.banner.visible)
        assertTrue(hudManager.hudState.value.blocks.isEmpty())

        // Reset restores clean default state
        val resetRes = hudManager.resetState()
        assertTrue(resetRes.optBoolean("success"))
        assertEquals("IDLE", hudManager.hudState.value.state)
        assertEquals("light", hudManager.hudState.value.theme.mode)
    }

    @Test
    fun `executeQuickAction on custom styled button broadcasts HUD_COMMAND with buttonId and payload`() {
        val chip = AgyHudOverlayManager.QuickActionChip(
            label = "Boost Workers",
            commandText = "boost_workers",
            actionType = "CUSTOM",
            id = "btn_boost_8",
            style = "primary",
            payload = JSONObject().put("workers", 8).put("priority", "high")
        )
        hudManager.executeQuickAction(chip)

        assertEquals(1, broadcastedCommands.size)
        val cmd = broadcastedCommands[0]
        assertEquals("HUD_COMMAND", cmd.optString("type"))
        assertEquals("CUSTOM", cmd.optString("action"))
        assertEquals("btn_boost_8", cmd.optString("buttonId"))
        val payloadObj = cmd.optJSONObject("payload")
        assertNotNull(payloadObj)
        assertEquals(8, payloadObj?.optInt("workers"))
        assertEquals("high", payloadObj?.optString("priority"))
    }
}




