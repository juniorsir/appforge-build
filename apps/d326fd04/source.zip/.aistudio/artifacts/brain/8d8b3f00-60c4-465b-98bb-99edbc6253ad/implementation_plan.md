# Dynamic Live-Step Collapsed Agy HUD Pill

Transform the collapsed Agy floating pill during active tasks into a sleek, live-updating status capsule that displays the current running step's app/task icon, dynamically scrolling step description, ticking elapsed timer, and a compact one-tap Stop control—while keeping `✦ Ask Agy` ready whenever idle, finished, or expanded.

## User Review & Critical Decisions

> [!IMPORTANT]
> All core UX choices from your answers are locked in below. Review the visual layout and interaction details, then approve to begin implementation.

- **Confirmed Decision 1 (Collapsed Running Controls)**: When collapsed and running, tapping anywhere on the live step pill expands the full HUD card, while a compact circular **Stop (`■`)** button sits on the right edge for immediate cancellation.
- **Confirmed Decision 2 (Expanded Bottom Bar Behavior)**: The bottom dock automatically morphs by mode—showing the **Live Step Pill** when collapsed & running, and restoring the familiar **`✦ Ask Agy`** (or **`✦ Reply`**) bar whenever the full card is expanded, idle, or finished.
- **Confirmed Decision 3 (Long Step Text & Step Transitions)**: Long step labels glide horizontally with a smooth single-line marquee and soft edge fade, crossfading smoothly whenever the active step changes.
- **Smart Collapse Preservation (Recommended Default)**: Once you minimize the HUD during a running task, subsequent step updates in the same run keep the HUD collapsed and stream live into the pill instead of forcing the big card back open. Only a brand-new run or a `NEEDS_INPUT` prompt will auto-expand.

---

## 1. Overview & Core Concept

- **What It Does**: Replaces the generic `"Working ▲ | ✦ Ask Agy"` collapsed bar during active automation runs with an Apple Dynamic Island / Google Live Updates–inspired floating capsule that streams the live running step in real time—complete with the active app or action icon, smoothly scrolling step text, ticking elapsed clock, and a quick Stop button.
- **Target Audience / Persona**: Power users running multi-step Agy tasks across Android apps (YouTube, Chrome, WhatsApp, Termux, etc.) who want to keep most of their screen unobstructed while still knowing the exact step Agy is executing right now.
- **Key Value**: Glanceable, real-time situational awareness without covering the active app—one glance shows *which app* Agy is touching, *what step* is running, and *how long* it has been running, with one-tap expand or stop.

---

## 2. User Experience & Visual Design

### Key User Flows

1. **Idle / Ready / Done (Collapsed)**:
   - Displays the calm status badge (`○ Ready ▲` or `✓ Done · 4.2s ▲`) paired with the primary **`✦ Ask Agy`** pill button.
2. **Task Starts (`WORKING`) → User Minimizes (`─`)**:
   - The expanded card folds smoothly away, and the bottom capsule morphs into the **Live Running Step Pill**:
     - **Left**: Active app or task icon badge (real installed app icon like YouTube/Chrome/Termux or crisp vector badge) with a subtle live cyan progress ring indicator.
     - **Center**: Current running step label (prioritizing the active `doing` task label, falling back to `currentAction`, then task title). If the text exceeds the pill width, it pauses briefly then smoothly marquees with gentle fading edges.
     - **Right-Center**: Live tabular monospace elapsed clock (`00:04.2` / `01:12`) ticking smoothly at 10Hz without causing layout jitter.
     - **Far Right**: Quiet circular coral-tinted **Stop (`■`)** icon button.
3. **Dynamic Step Change While Collapsed**:
   - As Termux pushes the next step (e.g., `"Launching YouTube"` → `"Searching lo-fi beats"` → `"Tapping play"`), the HUD stays collapsed, crossfades the step label with a subtle vertical/opacity transition, swaps the app/task icon automatically if the step targets a different app, and keeps the timer ticking uninterrupted.
4. **Expanding Mid-Run**:
   - Tapping the live pill opens the full Working Card and smoothly switches the bottom dock back to `[Spinner] Working ▼ | [✦ Ask Agy]` so you can inspect the checklist, output drawer, or send a follow-up prompt.
5. **Needs Input / Completion**:
   - If Agy requires confirmation (`NEEDS_INPUT`), the card expands with the amber question banner and **`✦ Reply`** button.
   - When the task finishes (`DONE`), the pill gracefully transitions to a calm emerald completion state (`✓ Done · 4.2s ▲ | ✦ Ask Agy`) with the final runtime preserved.

### Visual Identity & Theme

- **Aesthetic Direction**: Crisp Google & Apple minimalism—pure frosted white pill surface, whisper-thin subtle cyan active hairline rim, generous internal breathing room, zero noisy emojis.
- **Color Palette & Mood**:
  - Surface: Frosted crisp white pill (`#F2FFFFFF` overlay / pure `#FFFFFF` in simulator) with soft elevation shadow.
  - Active Rim: Gentle translucent cyan (`#660095F6`) while running, warm amber (`#D97706`) on input needed, soft emerald (`#6616A34A`) on completion.
  - Typography: Clean geometric sans-serif (`SemiBold`, `12sp`) for the live step label (`#0F172A`), tabular monospace (`10.5sp`, `#64748B`) for the live elapsed clock so digits never wobble as tenths of a second tick.
  - Stop Control: Soft coral tint (`#1AE11D48`) circular pill with crisp `#E11D48` stop square, sized generously for clean thumb accuracy while staying visually quiet.
- **Interactive Feedback & Motion**:
  - Smooth layout morph when collapsing/expanding between the Live Step Pill and the `✦ Ask Agy` dock.
  - Crossfade (`~180ms` alpha + slight ease) whenever the running step text changes.
  - Continuous marquee (`basicMarquee` in Compose simulator and native `TruncateAt.MARQUEE` with horizontal fading edges in the live Android overlay) for long step descriptions.
  - Hold-anywhere (`180ms`) unified drag continues to work seamlessly on the live pill.

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1: Step Resolution Priority**
  - *Chosen Approach*: Resolve the collapsed pill text from `activeDoingTask.label` → `currentAction` → `title` → `"Working"`, and resolve the icon from `activeDoingTask` first (falling back to top-level `icon` / `appPackage` / keyword inference).
  - *Why*: Multi-step plans often have a high-level title (e.g., `"YouTube Focus Mode"`) while individual steps switch apps or actions (e.g., `"Open Termux"`, `"Launch YouTube"`, `"Tap Play"`). Prioritizing the active `doing` step ensures both the label and icon change dynamically at every single step.
  - *Alternatives Considered*: Always showing top-level `title` was passed over because it stays static across steps and hides real progress.

- **Decision 2: Keeping the Pill Collapsed Across In-Flight `WORKING` Updates**
  - *Chosen Approach*: Auto-expand only when entering `WORKING` from another state (`IDLE`, `DONE`, `NEEDS_INPUT`), not on every incremental `WORKING` → `WORKING` telemetry update.
  - *Why*: Without this safeguard, minimizing the HUD while running would immediately pop back open 1–2 seconds later when the next step arrives, breaking the core collapsed live-ticker workflow.
  - *Alternatives Considered*: Requiring a separate "lock collapsed" toggle adds unnecessary chrome and violates our ultra-clean minimalism goal.

- **Decision 3: Fixed-Width Tabular Timer & Bounded Pill Width**
  - *Chosen Approach*: Cap the live pill width to ~`86%` of screen width (max `296dp`) with `weight(1f)` on the scrolling step text and a stable monospace slot for the elapsed timer.
  - *Why*: Prevents the pill from jumping left/right or overflowing narrow viewports as step descriptions vary in length and as the timer ticks every 100ms.

---

## 4. Technical Architecture & Data Strategy *(Technical Reference)*

### Architecture & Component Diagram

```text
┌──────────────────────────────────────────────────────────────────────┐
│                   Agy Telemetry (/api/hud/state)                     │
│  state · title · currentAction · tasks[doing] · icon · appPackage    │
└──────────────────────────────────┬───────────────────────────────────┘
                                   │
                                   ▼
┌──────────────────────────────────────────────────────────────────────┐
│                Shared Collapsed Live-Step Resolver                   │
│  • Active Step Label: doing.label -> currentAction -> title          │
│  • Active App/Task Icon: doing icon/pkg -> state icon/pkg -> infer   │
│  • Live Elapsed Clock: 100ms ticker -> formatted tabular time        │
│  • Collapse Guard: preserve isCollapsed on WORKING -> WORKING        │
└──────────────────┬───────────────────────────────────┬───────────────┘
                   │                                   │
                   ▼                                   ▼
┌─────────────────────────────────────┐ ┌──────────────────────────────┐
│   Live Floating Overlay (Window 2)  │ │  In-App HUD Simulator        │
│  ┌───────────────────────────────┐  │ │  ┌────────────────────────┐  │
│  │ Collapsed & WORKING:          │  │ │  │ Collapsed & WORKING:   │  │
│  │ [Icon+Ring] [Marquee Step]    │  │ │  │ [Icon+Ring] [Marquee]  │  │
│  │             [00:12.4] [ ■ ]   │  │ │  │        [00:12.4] [ ■ ] │  │
│  ├───────────────────────────────┤  │ │  ├────────────────────────┤  │
│  │ Expanded / Idle / Done:       │  │ │  │ Expanded / Idle / Done:│  │
│  │ [Status ▼/▲] | [ ✦ Ask Agy ]  │  │ │  │ [Status ▼/▲] [✦ Ask ]  │  │
│  └───────────────────────────────┘  │ │  └────────────────────────┘  │
└─────────────────────────────────────┘ └──────────────────────────────┘
```

### Data Model & State

- **Existing `AgyHudState` & `AgyHudTask`**: No breaking schema changes required; leverages existing `state`, `title`, `currentAction`, `tasks` (with per-task `status`, `label`, `icon`, `appPackage`), and `_elapsedMsFlow`.
- **Derived Live-Step Helper**: A pure helper function computes the active collapsed step (`label`, `resolvedIcon`, `isLiveRunningMode`) consistently for both the native Android floating overlay, the Compose Simulator preview, and unit tests.
- **Step Change Tracking**: Tracks the last rendered collapsed step string so the crossfade transition only fires when the step text actually changes—never flickering on 100ms timer ticks.

### Interactive Component & State Mapping

- **Collapsed Live Pill Body Tap**: Cancels any pending auto-collapse, sets `isCollapsed = false`, and morphs to the Expanded Working Card + bottom `✦ Ask Agy` bar.
- **Collapsed Live Pill Stop (`■`) Tap**: Enqueues and broadcasts a `STOP` command (`action = "STOP"`), immediately signaling Termux/Simulator to halt the active run.
- **100ms Elapsed Timer Tick**: Updates both the expanded header timer and the collapsed live pill timer in-place without recreating views or interrupting marquee scroll.
- **Hold-Anywhere Drag (`180ms`)**: Preserved on the entire bottom dock capsule so users can reposition the live pill anywhere on screen while it ticks.
- **Simulator Live Verification**: Updating the Simulator's auto-play and state buttons so users can collapse during a running multi-step flow and watch the live pill dynamically swap icons, crossfade marquee steps, tick the timer, and respond to Stop.
