package com.kavach.ui.overlay

import android.content.Context
import android.graphics.Rect
import androidx.test.core.app.ApplicationProvider
import com.kavach.accessibility.AccessibilityRepositoryImpl
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class AgyHudOverlayManagerTest {

    private lateinit var context: Context
    private lateinit var floatingOverlayManager: FloatingOverlayManager
    private lateinit var hudManager: AgyHudOverlayManager
    private val broadcastedCommands = mutableListOf<JSONObject>()

    @Before
    fun setUp() {
        context = ApplicationProvider.getApplicationContext()
        floatingOverlayManager = FloatingOverlayManager(context)
        broadcastedCommands.clear()
        hudManager = AgyHudOverlayManager(
            context = context,
            floatingOverlayManager = floatingOverlayManager,
            onCommandBroadcast = { cmd -> broadcastedCommands.add(cmd) }
        )
    }

    @Test
    fun `updateState parses tasks, question, autoCollapseSeconds, and screenWatch wireframe`() {
        val payload = JSONObject().apply {
            put("state", "WORKING")
            put("title", "Configure Termux Bridge")
            put("currentAction", "Tapping Connect button")
            put("nextAction", "Verify WebSocket live")
            put("autoCollapseSeconds", 5)
            put("tasks", JSONArray().apply {
                put(JSONObject().put("id", "t1").put("label", "Inspect screen").put("status", "done"))
                put(JSONObject().put("id", "t2").put("label", "Tap Connect").put("status", "doing"))
                put(JSONObject().put("id", "t3").put("label", "Verify reply").put("status", "pending"))
            })
            put("screenWatch", JSONObject().apply {
                put("active", true)
                put("label", "Settings Screen")
                put("screenWidth", 1080)
                put("screenHeight", 2400)
                put("zones", JSONArray().apply {
                    put(
                        JSONObject()
                            .put("x1", 700).put("y1", 400)
                            .put("x2", 1000).put("y2", 520)
                            .put("role", "target").put("tag", "Connect")
                    )
                })
                put(
                    "actionVector",
                    JSONObject()
                        .put("type", "TAP")
                        .put("x1", 850).put("y1", 460)
                        .put("x2", 850).put("y2", 460)
                )
            })
        }

        val res = hudManager.updateState(payload)
        assertTrue(res.optBoolean("success"))
        assertEquals("WORKING", res.optString("state"))
        assertEquals(3, res.optInt("taskCount"))
        assertTrue(res.optBoolean("screenWatchActive"))

        val stored = hudManager.hudState.value
        assertEquals("Configure Termux Bridge", stored.title)
        assertEquals(5, stored.autoCollapseSeconds)
        assertEquals("done", stored.tasks[0].status)
        assertEquals("doing", stored.tasks[1].status)
        assertEquals("pending", stored.tasks[2].status)
        assertTrue(stored.screenWatch.active)
        assertEquals(1, stored.screenWatch.zones.size)
        assertNotNull(stored.screenWatch.actionVector)
        assertEquals("TAP", stored.screenWatch.actionVector?.type)
    }

    @Test
    fun `remote PROMPT and STOP commands broadcast over WS callback and drain via poll`() {
        val promptRes = hudManager.handleRemoteCommand(
            JSONObject().put("action", "PROMPT").put("text", "List files in Termux")
        )
        assertTrue(promptRes.optBoolean("success"))

        val stopRes = hudManager.handleRemoteCommand(
            JSONObject().put("action", "STOP")
        )
        assertTrue(stopRes.optBoolean("success"))

        assertEquals(2, broadcastedCommands.size)
        assertEquals("HUD_COMMAND", broadcastedCommands[0].optString("type"))
        assertEquals("PROMPT", broadcastedCommands[0].optString("action"))
        assertEquals("List files in Termux", broadcastedCommands[0].optString("text"))
        assertEquals("STOP", broadcastedCommands[1].optString("action"))

        val poll1 = hudManager.pollCommands()
        assertTrue(poll1.optBoolean("success"))
        assertEquals(2, poll1.optInt("count"))
        val cmds = poll1.getJSONArray("commands")
        assertEquals("PROMPT", cmds.getJSONObject(0).optString("action"))
        assertEquals("STOP", cmds.getJSONObject(1).optString("action"))

        // Second poll should be empty (atomic drain)
        val poll2 = hudManager.pollCommands()
        assertEquals(0, poll2.optInt("count"))
    }

    @Test
    fun `accessibility repository self-excludes agy_hud_ prefixed nodes`() {
        val repo = AccessibilityRepositoryImpl()
        assertTrue(repo.isAgyHudIdentifier("com.kavach:id/agy_hud_window2", null))
        assertTrue(repo.isAgyHudIdentifier(null, "agy_hud_prompt_input"))
        assertTrue(repo.isAgyHudIdentifier("AGY_HUD_WIREFRAME", null))
        assertFalse(repo.isAgyHudIdentifier("com.termux:id/terminal_view", "Terminal"))
    }

    @Test
    fun `touch collision overlap detects TAP and SWIPE intersecting overlay bounds`() {
        val hudRect = listOf(Rect(650, 1800, 1050, 2320))
        // TAP inside HUD
        assertTrue(hudManager.coordinatesOverlapRects(800f, 2000f, 800f, 2000f, hudRect))
        // TAP outside HUD
        assertFalse(hudManager.coordinatesOverlapRects(200f, 400f, 200f, 400f, hudRect))
        // SWIPE crossing through HUD
        assertTrue(hudManager.coordinatesOverlapRects(500f, 2100f, 950f, 2100f, hudRect))
        // SWIPE completely above HUD
        assertFalse(hudManager.coordinatesOverlapRects(100f, 500f, 900f, 500f, hudRect))
    }

    @Test
    fun `mini wireframe view collapses to 0dp when screenWatch is inactive`() {
        val wf = MiniScreenWireframeView(context)
        wf.updateScreenWatch(
            AgyHudOverlayManager.ScreenWatchState(active = false),
            wireframeVisible = true
        )
        assertEquals(android.view.View.GONE, wf.visibility)
        wf.measure(
            android.view.View.MeasureSpec.makeMeasureSpec(400, android.view.View.MeasureSpec.AT_MOST),
            android.view.View.MeasureSpec.makeMeasureSpec(400, android.view.View.MeasureSpec.AT_MOST)
        )
        assertEquals(0, wf.measuredHeight)
        assertEquals(0, wf.measuredWidth)

        wf.updateScreenWatch(
            AgyHudOverlayManager.ScreenWatchState(
                active = true,
                screenWidth = 1080,
                screenHeight = 2400
            ),
            wireframeVisible = true
        )
        assertEquals(android.view.View.VISIBLE, wf.visibility)
        wf.measure(
            android.view.View.MeasureSpec.makeMeasureSpec(400, android.view.View.MeasureSpec.AT_MOST),
            android.view.View.MeasureSpec.makeMeasureSpec(400, android.view.View.MeasureSpec.AT_MOST)
        )
        assertTrue(wf.measuredHeight > 0)
        assertTrue(wf.measuredWidth > 0)
    }

    @Test
    fun `app icon resolver maps yt, youtube, whatsapp, chrome, termux, and generic tasks cleanly`() {
        val ytShort = AgyAppIconResolver.resolve(context, explicitIcon = "yt", explicitPackage = "", fallbackText = "")
        assertEquals(AgyAppIconResolver.BadgeKind.YOUTUBE, ytShort.kind)
        assertEquals("com.google.android.youtube", ytShort.packageName)

        val ytText = AgyAppIconResolver.resolve(context, explicitIcon = "", explicitPackage = "", fallbackText = "Open YouTube playlist")
        assertEquals(AgyAppIconResolver.BadgeKind.YOUTUBE, ytText.kind)

        val wa = AgyAppIconResolver.resolve(context, explicitIcon = "", explicitPackage = "", fallbackText = "Send WhatsApp summary")
        assertEquals(AgyAppIconResolver.BadgeKind.WHATSAPP, wa.kind)

        val chrome = AgyAppIconResolver.resolve(context, explicitIcon = "chrome", explicitPackage = "", fallbackText = "")
        assertEquals(AgyAppIconResolver.BadgeKind.CHROME, chrome.kind)

        val termux = AgyAppIconResolver.resolve(context, explicitIcon = "", explicitPackage = "", fallbackText = "Run bash script in Termux")
        assertEquals(AgyAppIconResolver.BadgeKind.TERMUX, termux.kind)

        val fallback = AgyAppIconResolver.resolve(context, explicitIcon = "", explicitPackage = "", fallbackText = "General assistance")
        assertEquals(AgyAppIconResolver.BadgeKind.SPARK_AI, fallback.kind)
    }

    @Test
    fun `updateState parses detailedOutput, outputLogs, quickActions, and per-task icon metadata`() {
        val payload = JSONObject().apply {
            put("state", "DONE")
            put("title", "YouTube Automation")
            put("icon", "youtube")
            put("appPackage", "com.google.android.youtube")
            put("currentAction", "Queued 4 videos")
            put("detailedOutput", "Added 4 AI & Android talks to Watch Later.")
            put("outputLogs", JSONArray().apply {
                put("[12:01:02] Opened YouTube")
                put("[12:01:05] Saved 4 videos")
            })
            put("quickActions", JSONArray().apply {
                put(JSONObject().put("label", "Copy Output").put("actionType", "COPY_OUTPUT"))
                put(JSONObject().put("label", "Run Again").put("commandText", "Run YouTube task again").put("actionType", "PROMPT"))
            })
            put("tasks", JSONArray().apply {
                put(
                    JSONObject()
                        .put("id", "t1")
                        .put("label", "Open YouTube")
                        .put("status", "done")
                        .put("icon", "yt")
                        .put("appPackage", "com.google.android.youtube")
                        .put("detail", "com.google.android.youtube")
                )
            })
        }

        val res = hudManager.updateState(payload)
        assertTrue(res.optBoolean("success"))

        val stored = hudManager.hudState.value
        assertEquals("youtube", stored.icon)
        assertEquals("com.google.android.youtube", stored.appPackage)
        assertEquals("Added 4 AI & Android talks to Watch Later.", stored.detailedOutput)
        assertEquals(2, stored.outputLogs.size)
        assertEquals(2, stored.quickActions.size)
        assertEquals("COPY_OUTPUT", stored.quickActions[0].actionType)
        assertEquals("yt", stored.tasks[0].icon)
        assertEquals("com.google.android.youtube", stored.tasks[0].appPackage)
        assertEquals("com.google.android.youtube", stored.tasks[0].detail)

        val copyText = hudManager.getFullOutputCopyText(stored)
        assertTrue(copyText.contains("Added 4 AI & Android talks"))
        assertTrue(copyText.contains("[12:01:02] Opened YouTube"))
    }

    @Test
    fun `TOGGLE_OUTPUT command toggles expanded drawer and formatElapsed formats seconds and minutes`() {
        assertFalse(hudManager.isOutputExpandedFlow.value)

        val toggleOn = hudManager.handleRemoteCommand(JSONObject().put("action", "TOGGLE_OUTPUT"))
        assertTrue(toggleOn.optBoolean("success"))
        assertTrue(hudManager.isOutputExpandedFlow.value)

        val toggleOff = hudManager.handleRemoteCommand(JSONObject().put("action", "TOGGLE_OUTPUT"))
        assertTrue(toggleOff.optBoolean("success"))
        assertFalse(hudManager.isOutputExpandedFlow.value)

        assertEquals("00:00.0", hudManager.formatElapsed(0L))
        assertEquals("00:04.2", hudManager.formatElapsed(4200L))
        assertEquals("01:05", hudManager.formatElapsed(65_000L))
        assertEquals("Done 4.2s", hudManager.formatElapsed(4200L, isDone = true))
    }

    @Test
    fun `collapsed live running pill resolves dynamic step, icon, and preserves collapse across WORKING updates`() {
        // 1. Entering WORKING from IDLE auto-expands the HUD
        hudManager.updateState(
            JSONObject().apply {
                put("state", "WORKING")
                put("title", "Focus Automation")
                put("currentAction", "Opening YouTube")
                put("tasks", JSONArray().apply {
                    put(
                        JSONObject()
                            .put("id", "s1")
                            .put("label", "Open YouTube & search playlist")
                            .put("status", "doing")
                            .put("icon", "youtube")
                            .put("appPackage", "com.google.android.youtube")
                    )
                    put(
                        JSONObject()
                            .put("id", "s2")
                            .put("label", "Scroll Chrome & extract summary")
                            .put("status", "pending")
                            .put("icon", "chrome")
                    )
                })
            }
        )
        assertFalse(hudManager.isCollapsedFlow.value)
        assertFalse(hudManager.isCollapsedLiveRunningMode())

        // 2. User collapses HUD during active run -> enters live running step pill mode
        hudManager.handleRemoteCommand(JSONObject().put("action", "COLLAPSE"))
        assertTrue(hudManager.isCollapsedFlow.value)
        assertTrue(hudManager.isCollapsedLiveRunningMode())

        val step1 = hudManager.resolveCollapsedRunningStep()
        assertEquals("Open YouTube & search playlist", step1.label)
        assertEquals(AgyAppIconResolver.BadgeKind.YOUTUBE, step1.icon.kind)

        // 3. Subsequent WORKING telemetry update preserves collapsed state & dynamically updates step + icon
        hudManager.updateState(
            JSONObject().apply {
                put("state", "WORKING")
                put("title", "Focus Automation")
                put("currentAction", "Scrolling Chrome article")
                put("tasks", JSONArray().apply {
                    put(JSONObject().put("id", "s1").put("label", "Open YouTube & search playlist").put("status", "done").put("icon", "youtube"))
                    put(
                        JSONObject()
                            .put("id", "s2")
                            .put("label", "Scroll Chrome & extract summary")
                            .put("status", "doing")
                            .put("icon", "chrome")
                            .put("appPackage", "com.android.chrome")
                    )
                })
            }
        )
        assertTrue(hudManager.isCollapsedFlow.value)
        assertTrue(hudManager.isCollapsedLiveRunningMode())

        val step2 = hudManager.resolveCollapsedRunningStep()
        assertEquals("Scroll Chrome & extract summary", step2.label)
        assertEquals(AgyAppIconResolver.BadgeKind.CHROME, step2.icon.kind)

        // 4. Fallback to currentAction when no doing task exists
        val fallbackStep = hudManager.resolveCollapsedRunningStep(
            AgyHudOverlayManager.AgyHudState(
                state = "WORKING",
                title = "Background Sync",
                currentAction = "Sending WhatsApp report",
                tasks = emptyList()
            )
        )
        assertEquals("Sending WhatsApp report", fallbackStep.label)
        assertEquals(AgyAppIconResolver.BadgeKind.WHATSAPP, fallbackStep.icon.kind)

        // 5. NEEDS_INPUT expands card and exits collapsed live running mode
        hudManager.updateState(
            JSONObject().apply {
                put("state", "NEEDS_INPUT")
                put("title", "Confirm Share")
                put("question", "Send link now?")
            }
        )
        assertFalse(hudManager.isCollapsedFlow.value)
        assertFalse(hudManager.isCollapsedLiveRunningMode())
    }
}


