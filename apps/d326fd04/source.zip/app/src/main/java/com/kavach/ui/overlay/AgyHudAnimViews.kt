package com.kavach.ui.overlay

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.os.Handler
import android.os.Looper
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.LinearInterpolator
import android.widget.LinearLayout
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.sin

/**
 * Smooth 60fps Canvas-drawn rotating spinner ring for active WORKING HUD states.
 */
class AgySpinnerRingView(context: Context) : View(context) {
    private val density = context.resources.displayMetrics.density.coerceAtLeast(1f)
    private var sweepAngleDeg = 0f
    private var isRunning = false
    private var animator: ValueAnimator? = null

    private val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2.0f * density
        color = Color.parseColor("#260095F6")
    }

    private val arcPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2.2f * density
        strokeCap = Paint.Cap.ROUND
        color = Color.parseColor("#0095F6")
    }

    private val bounds = RectF()

    fun setAccentColor(color: Int) {
        arcPaint.color = color
        trackPaint.color = Color.argb(38, Color.red(color), Color.green(color), Color.blue(color))
        invalidate()
    }

    fun setAnimating(active: Boolean) {
        if (active == isRunning) return
        isRunning = active
        if (active) {
            startAnimator()
        } else {
            stopAnimator()
        }
    }

    private fun startAnimator() {
        stopAnimator()
        animator = ValueAnimator.ofFloat(0f, 360f).apply {
            duration = 900L
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener { anim ->
                sweepAngleDeg = anim.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    private fun stopAnimator() {
        animator?.cancel()
        animator = null
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (isRunning && animator == null) {
            startAnimator()
        }
    }

    override fun onDetachedFromWindow() {
        stopAnimator()
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val pad = arcPaint.strokeWidth * 0.65f
        bounds.set(pad, pad, width - pad, height - pad)
        if (bounds.width() <= 0f || bounds.height() <= 0f) return
        canvas.drawOval(bounds, trackPaint)
        canvas.drawArc(bounds, sweepAngleDeg - 90f, 250f, false, arcPaint)
    }
}

/**
 * Slim indeterminate sliding progress bar spanning the top edge of the working HUD card.
 */
class AgyLoadingBarView(context: Context) : View(context) {
    private val density = context.resources.displayMetrics.density.coerceAtLeast(1f)
    private var progress = 0f
    private var isRunning = false
    private var animator: ValueAnimator? = null

    private val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.parseColor("#E2E8F0")
    }

    private val barPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.parseColor("#0095F6")
    }

    private val trackRect = RectF()
    private val barRect = RectF()

    fun setAnimating(active: Boolean) {
        visibility = if (active) VISIBLE else GONE
        if (active == isRunning) return
        isRunning = active
        if (active) {
            startAnimator()
        } else {
            stopAnimator()
        }
    }

    private fun startAnimator() {
        stopAnimator()
        animator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 1250L
            repeatCount = ValueAnimator.INFINITE
            interpolator = AccelerateDecelerateInterpolator()
            addUpdateListener { anim ->
                progress = anim.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    private fun stopAnimator() {
        animator?.cancel()
        animator = null
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (isRunning && animator == null) {
            startAnimator()
        }
    }

    override fun onDetachedFromWindow() {
        stopAnimator()
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        val radius = h * 0.5f
        trackRect.set(0f, 0f, w, h)
        canvas.drawRoundRect(trackRect, radius, radius, trackPaint)

        val segWidth = w * 0.38f
        val startX = -segWidth + (w + segWidth) * progress
        val left = startX.coerceIn(0f, w)
        val right = (startX + segWidth).coerceIn(0f, w)
        if (right > left) {
            barPaint.shader = LinearGradient(
                left, 0f, right, 0f,
                Color.parseColor("#0095F6"),
                Color.parseColor("#4F46E5"),
                Shader.TileMode.CLAMP
            )
            barRect.set(left, 0f, right, h)
            canvas.drawRoundRect(barRect, radius, radius, barPaint)
        }
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val desiredH = (3.5f * density).toInt().coerceAtLeast(4)
        val w = MeasureSpec.getSize(widthMeasureSpec)
        setMeasuredDimension(w, resolveSize(desiredH, heightMeasureSpec))
    }
}

/**
 * Three staggered bouncing loading dots displayed beside the active "Doing now" line.
 */
class AgyBouncingDotsView(context: Context) : View(context) {
    private val density = context.resources.displayMetrics.density.coerceAtLeast(1f)
    private var phase = 0f
    private var isRunning = false
    private var animator: ValueAnimator? = null

    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.parseColor("#0095F6")
    }

    fun setAccentColor(color: Int) {
        dotPaint.color = color
        invalidate()
    }

    fun setAnimating(active: Boolean) {
        visibility = if (active) VISIBLE else GONE
        if (active == isRunning) return
        isRunning = active
        if (active) {
            startAnimator()
        } else {
            stopAnimator()
        }
    }

    private fun startAnimator() {
        stopAnimator()
        animator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 960L
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener { anim ->
                phase = anim.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    private fun stopAnimator() {
        animator?.cancel()
        animator = null
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (isRunning && animator == null) {
            startAnimator()
        }
    }

    override fun onDetachedFromWindow() {
        stopAnimator()
        super.onDetachedFromWindow()
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = (24f * density).toInt()
        val h = (14f * density).toInt()
        setMeasuredDimension(resolveSize(w, widthMeasureSpec), resolveSize(h, heightMeasureSpec))
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val r = 2.0f * density
        val spacing = 6.5f * density
        val baseY = height * 0.62f
        val lift = 3.2f * density
        val startX = (width - spacing * 2f) * 0.5f

        for (i in 0 until 3) {
            val dotPhase = (phase + i * 0.22f) % 1f
            val wave = sin(dotPhase * 2.0 * PI).toFloat().coerceAtLeast(0f)
            val cy = baseY - wave * lift
            dotPaint.alpha = (115 + (140 * wave).toInt()).coerceIn(115, 255)
            canvas.drawCircle(startX + i * spacing, cy, r, dotPaint)
        }
    }
}

/**
 * Container-level press-and-hold unified drag layout.
 *
 * Pressing and holding (~180ms) ANYWHERE on the dock — even directly over buttons, text, or the
 * bottom Chat pill — activates drag mode with subtle haptic feedback & lift scale and moves the
 * entire unified dock smoothly. Quick taps (<180ms) pass cleanly through to child click listeners.
 */
class HoldDraggableDockLayout(
    context: Context,
    private val holdThresholdMs: Long = 180L
) : LinearLayout(context) {

    var onDragStart: (() -> Unit)? = null
    var onDragDelta: ((dx: Float, dy: Float) -> Unit)? = null
    var onDragEnd: (() -> Unit)? = null
    var onOutsideTouch: (() -> Unit)? = null

    private val density = context.resources.displayMetrics.density.coerceAtLeast(1f)
    private val holdSlopPx = 18f * density
    private val handler = Handler(Looper.getMainLooper())

    private var downRawX = 0f
    private var downRawY = 0f
    private var lastRawX = 0f
    private var lastRawY = 0f
    private var holdTriggered = false
    private var pointerDown = false

    private val holdRunnable = Runnable {
        if (pointerDown && !holdTriggered) {
            holdTriggered = true
            lastRawX = downRawX
            lastRawY = downRawY
            try {
                performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            } catch (_: Exception) {}
            animate().scaleX(1.03f).scaleY(1.03f).setDuration(110L).start()
            onDragStart?.invoke()
        }
    }

    override fun onInterceptTouchEvent(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                pointerDown = true
                holdTriggered = false
                downRawX = ev.rawX
                downRawY = ev.rawY
                lastRawX = ev.rawX
                lastRawY = ev.rawY
                handler.removeCallbacks(holdRunnable)
                handler.postDelayed(holdRunnable, holdThresholdMs)
                return false
            }
            MotionEvent.ACTION_MOVE -> {
                if (holdTriggered) {
                    return true
                }
                val dx = ev.rawX - downRawX
                val dy = ev.rawY - downRawY
                if (abs(dx) > holdSlopPx || abs(dy) > holdSlopPx) {
                    // User swiped quickly (e.g. scrolling task list) before hold threshold
                    handler.removeCallbacks(holdRunnable)
                }
                return false
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                handler.removeCallbacks(holdRunnable)
                pointerDown = false
                if (holdTriggered) {
                    finishDrag()
                    return true
                }
                return false
            }
        }
        return super.onInterceptTouchEvent(ev)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_OUTSIDE -> {
                onOutsideTouch?.invoke()
                return true
            }
            MotionEvent.ACTION_DOWN -> {
                // Non-clickable background inside dock still starts hold-to-drag
                pointerDown = true
                holdTriggered = false
                downRawX = event.rawX
                downRawY = event.rawY
                lastRawX = event.rawX
                lastRawY = event.rawY
                handler.removeCallbacks(holdRunnable)
                handler.postDelayed(holdRunnable, holdThresholdMs)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (holdTriggered) {
                    val dx = event.rawX - lastRawX
                    val dy = event.rawY - lastRawY
                    lastRawX = event.rawX
                    lastRawY = event.rawY
                    if (dx != 0f || dy != 0f) {
                        onDragDelta?.invoke(dx, dy)
                    }
                    return true
                }
                val distX = event.rawX - downRawX
                val distY = event.rawY - downRawY
                if (abs(distX) > holdSlopPx || abs(distY) > holdSlopPx) {
                    handler.removeCallbacks(holdRunnable)
                }
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                handler.removeCallbacks(holdRunnable)
                pointerDown = false
                if (holdTriggered) {
                    finishDrag()
                    return true
                }
                return true
            }
        }
        return super.onTouchEvent(event)
    }

    private fun finishDrag() {
        holdTriggered = false
        animate().scaleX(1.0f).scaleY(1.0f).setDuration(120L).start()
        onDragEnd?.invoke()
    }

    override fun onDetachedFromWindow() {
        handler.removeCallbacks(holdRunnable)
        pointerDown = false
        holdTriggered = false
        super.onDetachedFromWindow()
    }
}

/**
 * Gemini-inspired frosted card container with a smooth 60fps sweeping Aurora Shimmer Border
 * while WORKING, soft breathing Amber rim on NEEDS_INPUT, calm Emerald rim on DONE, and
 * clean Crisp Hairline when IDLE.
 */
class AgyAuroraCardLayout(context: Context) : LinearLayout(context) {

    enum class RimMode { IDLE, WORKING, NEEDS_INPUT, DONE }

    private val density = context.resources.displayMetrics.density.coerceAtLeast(1f)
    private val cornerRadiusPx = 24f * density
    private val auroraMatrix = android.graphics.Matrix()
    private val borderRect = RectF()
    private val fillRect = RectF()

    private var rimMode: RimMode = RimMode.IDLE
    private var sweepDeg = 0f
    private var pulsePhase = 0f
    private var animator: ValueAnimator? = null

    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.parseColor("#F5FFFFFF")
    }

    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1.6f * density
        color = Color.parseColor("#FFE2E8F0")
    }

    private val auroraColors = intArrayOf(
        Color.parseColor("#0095F6"),
        Color.parseColor("#4F46E5"),
        Color.parseColor("#8B5CF6"),
        Color.parseColor("#38BDF8"),
        Color.parseColor("#0095F6")
    )

    private var sweepShader: android.graphics.SweepGradient? = null

    init {
        setWillNotDraw(false)
    }

    fun setRimMode(mode: RimMode) {
        if (rimMode == mode) return
        rimMode = mode
        when (mode) {
            RimMode.WORKING -> startSweepAnimator(2800L)
            RimMode.NEEDS_INPUT -> startSweepAnimator(1600L)
            RimMode.DONE, RimMode.IDLE -> {
                stopAnimator()
                invalidate()
            }
        }
    }

    fun stopAurora() {
        stopAnimator()
    }

    private fun startSweepAnimator(durationMs: Long) {
        stopAnimator()
        animator = ValueAnimator.ofFloat(0f, 360f).apply {
            duration = durationMs
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener { anim ->
                sweepDeg = anim.animatedValue as Float
                pulsePhase = (sweepDeg / 360f)
                invalidate()
            }
            start()
        }
    }

    private fun stopAnimator() {
        animator?.cancel()
        animator = null
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        if (w > 0 && h > 0) {
            sweepShader = android.graphics.SweepGradient(
                w * 0.5f,
                h * 0.5f,
                auroraColors,
                null
            )
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if ((rimMode == RimMode.WORKING || rimMode == RimMode.NEEDS_INPUT) && animator == null) {
            startSweepAnimator(if (rimMode == RimMode.WORKING) 2800L else 1600L)
        }
    }

    override fun onDetachedFromWindow() {
        stopAnimator()
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) {
            super.onDraw(canvas)
            return
        }
        val stroke = when (rimMode) {
            RimMode.WORKING -> 2.0f * density
            RimMode.NEEDS_INPUT -> 1.8f * density
            RimMode.DONE -> 1.4f * density
            RimMode.IDLE -> 1.0f * density
        }
        val half = stroke * 0.5f
        fillRect.set(half, half, w - half, h - half)
        borderRect.set(half, half, w - half, h - half)

        canvas.drawRoundRect(fillRect, cornerRadiusPx, cornerRadiusPx, bgPaint)

        borderPaint.strokeWidth = stroke
        when (rimMode) {
            RimMode.WORKING -> {
                val shader = sweepShader
                if (shader != null) {
                    auroraMatrix.reset()
                    auroraMatrix.setRotate(sweepDeg, w * 0.5f, h * 0.5f)
                    shader.setLocalMatrix(auroraMatrix)
                    borderPaint.shader = shader
                } else {
                    borderPaint.shader = null
                    borderPaint.color = Color.parseColor("#0095F6")
                }
            }
            RimMode.NEEDS_INPUT -> {
                borderPaint.shader = null
                val wave = 0.55f + 0.45f * sin(pulsePhase * 2.0 * PI).toFloat()
                borderPaint.color = Color.argb((wave * 255).toInt().coerceIn(120, 255), 217, 119, 6)
            }
            RimMode.DONE -> {
                borderPaint.shader = null
                borderPaint.color = Color.parseColor("#8816A34A")
            }
            RimMode.IDLE -> {
                borderPaint.shader = null
                borderPaint.color = Color.parseColor("#FFE2E8F0")
            }
        }
        canvas.drawRoundRect(borderRect, cornerRadiusPx, cornerRadiusPx, borderPaint)
        super.onDraw(canvas)
    }
}

