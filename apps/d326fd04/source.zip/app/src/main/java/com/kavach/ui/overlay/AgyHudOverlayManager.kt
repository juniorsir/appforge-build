package com.kavach.ui.overlay

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.util.Log
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.animation.LayoutTransition
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.util.Locale
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Termux-First Dual-Window Agy HUD Overlay Manager.
 *
 * Manages two coordinated Dark Obsidian Liquid Glass overlays integrated with FloatingOverlayManager:
 * 1. Window 1 (`agy_input`): Floating interactive command/prompt input bar with dynamic Termux-safe
 *    `FLAG_NOT_FOCUSABLE` keyboard handoff (Termux keeps IME focus until user taps EditText, and
 *    regains focus immediately on Send, Stop, outside touch, or collapse).
 * 2. Window 2 (`agy_hud`): Draggable live Task & Screen HUD with Expanded mode (status dot, opacity
 *    cycle 90%/65%/35%, wireframe toggle, ghost touch-through toggle, live CheckBox task list,
 *    MiniScreenWireframeView) and Collapsed mode (`✓ Agy • Done | 💬 Ask / Task` pill).
 *
 * All views are tagged with `agy_hud_` for self-exclusion in AccessibilityRepositoryImpl, and
 * bounding boxes are exposed for temporary `FLAG_NOT_TOUCHABLE` collision pass-through.
 */
class AgyHudOverlayManager(
    private val context: Context,
    private val floatingOverlayManager: FloatingOverlayManager,
    private val onCommandBroadcast: ((JSONObject) -> Unit)? = null
) {
    companion object {
        private const val TAG = "AgyHudOverlayManager"
        const val HUD_NODE_TAG_PREFIX = "agy_hud_"
        private const val MAX_QUEUED_COMMANDS = 64

        val OPACITY_LEVELS = floatArrayOf(0.90f, 0.65f, 0.35f)

        // Frosted Crisp Light Glass Palette (unified with main app Crisp Light Mode)
        private val COLOR_OBSIDIAN_GLASS = Color.parseColor("#F2FFFFFF")
        private val COLOR_PILL_INPUT_BG = Color.parseColor("#FFF1F5F9")
        private val COLOR_INNER_CAPSULE = Color.parseColor("#FFF1F5F9")
        private val COLOR_HAIRLINE = Color.parseColor("#FFE2E8F0")
        private val COLOR_CYAN = Color.parseColor("#0095F6")
        private val COLOR_VIOLET = Color.parseColor("#4F46E5")
        private val COLOR_EMERALD = Color.parseColor("#16A34A")
        private val COLOR_AMBER = Color.parseColor("#D97706")
        private val COLOR_CORAL = Color.parseColor("#E11D48")
        private val COLOR_TEXT_PRIMARY = Color.parseColor("#0F172A")
        private val COLOR_TEXT_SECONDARY = Color.parseColor("#64748B")
    }

    data class AgyHudTask(
        val id: String,
        val label: String,
        val status: String = "pending", // done | doing | pending | needs_input
        val icon: String = "",          // optional explicit icon key ("youtube", "termux", "chrome", ...)
        val appPackage: String = "",    // optional Android package name for real app icon lookup
        val detail: String = ""         // optional compact step note
    ) {
        fun toJson(): JSONObject = JSONObject().apply {
            put("id", id)
            put("label", label)
            put("status", status)
            if (icon.isNotBlank()) put("icon", icon)
            if (appPackage.isNotBlank()) put("appPackage", appPackage)
            if (detail.isNotBlank()) put("detail", detail)
        }
    }

    data class QuickActionChip(
        val label: String,
        val commandText: String,
        val actionType: String = "PROMPT" // PROMPT | STOP | COPY_OUTPUT | TOGGLE_OUTPUT
    ) {
        fun toJson(): JSONObject = JSONObject().apply {
            put("label", label)
            put("commandText", commandText)
            put("actionType", actionType)
        }
    }

    data class WireframeZone(
        val x1: Float,
        val y1: Float,
        val x2: Float,
        val y2: Float,
        val role: String = "panel",
        val tag: String = ""
    ) {
        fun toJson(): JSONObject = JSONObject().apply {
            put("x1", x1.toDouble())
            put("y1", y1.toDouble())
            put("x2", x2.toDouble())
            put("y2", y2.toDouble())
            put("role", role)
            put("tag", tag)
        }
    }

    data class WireframeActionVector(
        val type: String = "TAP", // TAP | CLICK | SWIPE | DRAG
        val x1: Float,
        val y1: Float,
        val x2: Float = x1,
        val y2: Float = y1
    ) {
        fun toJson(): JSONObject = JSONObject().apply {
            put("type", type)
            put("x1", x1.toDouble())
            put("y1", y1.toDouble())
            put("x2", x2.toDouble())
            put("y2", y2.toDouble())
        }
    }

    data class ScreenWatchState(
        val active: Boolean = false,
        val label: String = "",
        val screenWidth: Int = 1080,
        val screenHeight: Int = 2400,
        val zones: List<WireframeZone> = emptyList(),
        val actionVector: WireframeActionVector? = null
    ) {
        fun toJson(): JSONObject = JSONObject().apply {
            put("active", active)
            put("label", label)
            put("screenWidth", screenWidth)
            put("screenHeight", screenHeight)
            put("zones", JSONArray().apply { zones.forEach { put(it.toJson()) } })
            if (actionVector != null) put("actionVector", actionVector.toJson())
        }
    }

    data class AgyHudState(
        val state: String = "IDLE", // IDLE | WORKING | NEEDS_INPUT | DONE
        val title: String = "Agy Ready",
        val currentAction: String = "",
        val nextAction: String = "",
        val question: String = "",
        val autoCollapseSeconds: Int = 4,
        val tasks: List<AgyHudTask> = emptyList(),
        val screenWatch: ScreenWatchState = ScreenWatchState(),
        val appPackage: String = "",
        val icon: String = "",
        val detailedOutput: String = "",
        val outputLogs: List<String> = emptyList(),
        val quickActions: List<QuickActionChip> = emptyList()
    ) {
        fun toJson(): JSONObject = JSONObject().apply {
            put("state", state)
            put("title", title)
            put("currentAction", currentAction)
            put("nextAction", nextAction)
            put("question", question)
            put("autoCollapseSeconds", autoCollapseSeconds)
            put("tasks", JSONArray().apply { tasks.forEach { put(it.toJson()) } })
            put("screenWatch", screenWatch.toJson())
            if (appPackage.isNotBlank()) put("appPackage", appPackage)
            if (icon.isNotBlank()) put("icon", icon)
            if (detailedOutput.isNotBlank()) put("detailedOutput", detailedOutput)
            put("outputLogs", JSONArray().apply { outputLogs.forEach { put(it) } })
            put("quickActions", JSONArray().apply { quickActions.forEach { put(it.toJson()) } })
        }
    }

    data class HudCommand(
        val id: String = "cmd_${UUID.randomUUID().toString().take(8)}",
        val type: String = "HUD_COMMAND",
        val text: String,
        val action: String = "PROMPT", // PROMPT | STOP
        val timestamp: Long = System.currentTimeMillis()
    ) {
        fun toJson(): JSONObject = JSONObject().apply {
            put("id", id)
            put("type", type)
            put("text", text)
            put("action", action)
            put("timestamp", timestamp)
        }
    }

    data class CollapsedRunningStep(
        val label: String,
        val icon: AgyAppIconResolver.ResolvedIcon
    )

    private val mainHandler = Handler(Looper.getMainLooper())
    private val windowManager: WindowManager? by lazy {
        context.getSystemService(Context.WINDOW_SERVICE) as? WindowManager
    }
    private val inputMethodManager: InputMethodManager? by lazy {
        context.getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
    }

    private val commandQueue = ConcurrentLinkedQueue<HudCommand>()

    private val _isHudVisible = MutableStateFlow(false)
    val isHudVisible: StateFlow<Boolean> = _isHudVisible.asStateFlow()

    private val _isInputVisible = MutableStateFlow(false)
    val isInputVisible: StateFlow<Boolean> = _isInputVisible.asStateFlow()

    private val _hudState = MutableStateFlow(AgyHudState())
    val hudState: StateFlow<AgyHudState> = _hudState.asStateFlow()

    private val _isCollapsedFlow = MutableStateFlow(true)
    val isCollapsedFlow: StateFlow<Boolean> = _isCollapsedFlow.asStateFlow()

    private val _opacityFlow = MutableStateFlow(OPACITY_LEVELS[0])
    val opacityFlow: StateFlow<Float> = _opacityFlow.asStateFlow()

    private val _ghostPassThroughFlow = MutableStateFlow(false)
    val ghostPassThroughFlow: StateFlow<Boolean> = _ghostPassThroughFlow.asStateFlow()

    private val _wireframeEnabledFlow = MutableStateFlow(true)
    val wireframeEnabledFlow: StateFlow<Boolean> = _wireframeEnabledFlow.asStateFlow()

    private val _isOutputExpandedFlow = MutableStateFlow(false)
    val isOutputExpandedFlow: StateFlow<Boolean> = _isOutputExpandedFlow.asStateFlow()

    private val _elapsedMsFlow = MutableStateFlow(0L)
    val elapsedMsFlow: StateFlow<Long> = _elapsedMsFlow.asStateFlow()

    @Volatile
    private var isCollapsed: Boolean = true
        set(value) {
            field = value
            _isCollapsedFlow.value = value
        }
    @Volatile
    @set:JvmName("setOutputExpandedInternal")
    private var isOutputExpanded: Boolean = false
        set(value) {
            field = value
            _isOutputExpandedFlow.value = value
        }
    @Volatile
    private var opacityIndex: Int = 0
        set(value) {
            field = value
            _opacityFlow.value = OPACITY_LEVELS[value.coerceIn(0, OPACITY_LEVELS.lastIndex)]
        }
    @Volatile
    private var wireframeEnabled: Boolean = true
        set(value) {
            field = value
            _wireframeEnabledFlow.value = value
        }
    @Volatile
    private var ghostPassThrough: Boolean = false
        set(value) {
            field = value
            _ghostPassThroughFlow.value = value
        }
    @Volatile
    private var isToolsTrayOpen: Boolean = false
    @Volatile
    private var isInputFocused: Boolean = false
    @Volatile
    private var temporaryPassThroughActive: Boolean = false

    // Window 2 (agy_hud) Unified Vertical Dock references
    private var hudRootView: HoldDraggableDockLayout? = null
    private var hudParams: WindowManager.LayoutParams? = null
    private var hudExpandedContainer: AgyAuroraCardLayout? = null
    private var hudBottomDockRow: LinearLayout? = null
    private var workingLoadingBar: AgyLoadingBarView? = null
    private var headerAppIconView: AgyIconBadgeView? = null
    private var headerSpinnerView: AgySpinnerRingView? = null
    private var statusDotView: View? = null
    private var statusBadgeText: TextView? = null
    private var elapsedTimerText: TextView? = null
    private var toolsMenuBtn: TextView? = null
    private var toolsTrayContainer: LinearLayout? = null
    private var titleText: TextView? = null
    private var questionBannerText: TextView? = null
    private var doingRowContainer: LinearLayout? = null
    private var currentActionText: TextView? = null
    private var doingDotsView: AgyBouncingDotsView? = null
    private var nextActionText: TextView? = null
    private var taskListContainer: LinearLayout? = null
    private var taskScrollView: ScrollView? = null
    private var outputSectionContainer: LinearLayout? = null
    private var outputToggleHeaderText: TextView? = null
    private var outputDrawerContainer: LinearLayout? = null
    private var outputCopyBtn: TextView? = null
    private var outputBodyText: TextView? = null
    private var quickActionsScrollView: HorizontalScrollView? = null
    private var quickActionsContainer: LinearLayout? = null
    private var wireframeContainer: LinearLayout? = null
    private var wireframeLabelText: TextView? = null
    private var wireframeView: MiniScreenWireframeView? = null
    private var opacityBtn: TextView? = null
    private var wireframeBtn: TextView? = null
    private var ghostBtn: TextView? = null
    private var dockStandardStatusGroup: LinearLayout? = null
    private var dockStandardDivider: View? = null
    private var dockSpinnerView: AgySpinnerRingView? = null
    private var collapsedStatusText: TextView? = null
    private var bottomChatPillBtn: TextView? = null
    private var dockLiveStepGroup: LinearLayout? = null
    private var dockLiveSpinnerView: AgySpinnerRingView? = null
    private var dockLiveIconView: AgyIconBadgeView? = null
    private var dockLiveStepText: TextView? = null
    private var dockLiveTimerText: TextView? = null
    private var dockLiveStopBtn: TextView? = null
    private var lastCollapsedStepLabel: String = ""

    // Tiny ghost restore pill (only visible while ghost mode is ON so user can exit ghost mode)
    private var ghostRestoreView: View? = null
    private var ghostRestoreParams: WindowManager.LayoutParams? = null

    // Window 1 (agy_input) references
    private var inputRootView: HoldDraggableDockLayout? = null
    private var inputParams: WindowManager.LayoutParams? = null
    private var inputEditText: EditText? = null
    private var pasteClearBtn: TextView? = null

    // Scheduled tasks & live elapsed timer
    private var autoCollapseRunnable: Runnable? = null
    private var passThroughRestoreRunnable: Runnable? = null
    private var pulseRunnable: Runnable? = null
    private var pulseToggle: Boolean = false
    private var elapsedTimerRunnable: Runnable? = null
    private var workStartedAtMs: Long = 0L
    private var copyFeedbackResetRunnable: Runnable? = null

    fun hasOverlayPermission(): Boolean = floatingOverlayManager.hasPermission()

    fun getOverlayPermissionIntent(): Intent? = floatingOverlayManager.getPermissionIntent()

    fun parseHudStateFromJson(json: JSONObject): AgyHudState {
        val current = _hudState.value
        val state = json.optString("state", current.state).uppercase().trim()
            .let { if (it in listOf("IDLE", "WORKING", "NEEDS_INPUT", "DONE")) it else "WORKING" }
        val title = if (json.has("title")) json.optString("title", "") else current.title
        val currentAction = if (json.has("currentAction")) json.optString("currentAction", "") else current.currentAction
        val nextAction = if (json.has("nextAction")) json.optString("nextAction", "") else current.nextAction
        val question = if (json.has("question")) json.optString("question", "") else if (state != "NEEDS_INPUT") "" else current.question
        val autoCollapse = json.optInt("autoCollapseSeconds", current.autoCollapseSeconds).coerceIn(0, 120)

        val tasks = if (json.has("tasks")) {
            val arr = json.optJSONArray("tasks") ?: JSONArray()
            val list = mutableListOf<AgyHudTask>()
            for (i in 0 until arr.length()) {
                val obj = arr.optJSONObject(i) ?: continue
                list.add(
                    AgyHudTask(
                        id = obj.optString("id", "t_$i"),
                        label = obj.optString("label", "").trim(),
                        status = obj.optString("status", "pending").lowercase().trim(),
                        icon = obj.optString("icon", "").trim(),
                        appPackage = obj.optString("appPackage", "").trim(),
                        detail = obj.optString("detail", "").trim()
                    )
                )
            }
            list
        } else {
            current.tasks
        }

        val appPackage = if (json.has("appPackage")) json.optString("appPackage", "").trim() else current.appPackage
        val icon = if (json.has("icon")) json.optString("icon", "").trim() else current.icon
        val detailedOutput = if (json.has("detailedOutput")) {
            json.optString("detailedOutput", "")
        } else {
            current.detailedOutput
        }
        val outputLogs = if (json.has("outputLogs")) {
            val arr = json.optJSONArray("outputLogs") ?: JSONArray()
            val logs = mutableListOf<String>()
            for (i in 0 until arr.length()) {
                val line = arr.optString(i, "").trim()
                if (line.isNotEmpty()) logs.add(line)
            }
            logs
        } else {
            current.outputLogs
        }
        val quickActions = if (json.has("quickActions")) {
            val arr = json.optJSONArray("quickActions") ?: JSONArray()
            val chips = mutableListOf<QuickActionChip>()
            for (i in 0 until arr.length()) {
                val item = arr.opt(i)
                when (item) {
                    is JSONObject -> {
                        val lbl = item.optString("label", "").trim()
                        if (lbl.isNotEmpty()) {
                            chips.add(
                                QuickActionChip(
                                    label = lbl,
                                    commandText = item.optString("commandText", item.optString("text", lbl)).trim(),
                                    actionType = item.optString("actionType", item.optString("action", "PROMPT")).uppercase().trim()
                                )
                            )
                        }
                    }
                    is String -> {
                        val lbl = item.trim()
                        if (lbl.isNotEmpty()) {
                            chips.add(QuickActionChip(label = lbl, commandText = lbl, actionType = "PROMPT"))
                        }
                    }
                }
            }
            chips
        } else if (state != current.state) {
            emptyList()
        } else {
            current.quickActions
        }

        val screenWatch = if (json.has("screenWatch")) {
            val swObj = json.optJSONObject("screenWatch")
            if (swObj != null) {
                val zonesArr = swObj.optJSONArray("zones") ?: JSONArray()
                val zones = mutableListOf<WireframeZone>()
                for (i in 0 until zonesArr.length()) {
                    val z = zonesArr.optJSONObject(i) ?: continue
                    zones.add(
                        WireframeZone(
                            x1 = z.optDouble("x1", 0.0).toFloat(),
                            y1 = z.optDouble("y1", 0.0).toFloat(),
                            x2 = z.optDouble("x2", 0.0).toFloat(),
                            y2 = z.optDouble("y2", 0.0).toFloat(),
                            role = z.optString("role", "panel"),
                            tag = z.optString("tag", "")
                        )
                    )
                }
                val avObj = swObj.optJSONObject("actionVector")
                val actionVec = if (avObj != null) {
                    WireframeActionVector(
                        type = avObj.optString("type", "TAP").uppercase(),
                        x1 = avObj.optDouble("x1", 0.0).toFloat(),
                        y1 = avObj.optDouble("y1", 0.0).toFloat(),
                        x2 = avObj.optDouble("x2", avObj.optDouble("x1", 0.0)).toFloat(),
                        y2 = avObj.optDouble("y2", avObj.optDouble("y1", 0.0)).toFloat()
                    )
                } else null

                ScreenWatchState(
                    active = swObj.optBoolean("active", false),
                    label = swObj.optString("label", ""),
                    screenWidth = swObj.optInt("screenWidth", context.resources.displayMetrics.widthPixels.coerceAtLeast(360)),
                    screenHeight = swObj.optInt("screenHeight", context.resources.displayMetrics.heightPixels.coerceAtLeast(640)),
                    zones = zones,
                    actionVector = actionVec
                )
            } else {
                ScreenWatchState(active = false)
            }
        } else {
            current.screenWatch
        }

        return AgyHudState(
            state = state,
            title = title.ifBlank { "Agy HUD" },
            currentAction = currentAction,
            nextAction = nextAction,
            question = question,
            autoCollapseSeconds = autoCollapse,
            tasks = tasks,
            screenWatch = screenWatch,
            appPackage = appPackage,
            icon = icon,
            detailedOutput = detailedOutput,
            outputLogs = outputLogs,
            quickActions = quickActions
        )
    }

    /**
     * Handles POST /api/hud/state. Updates in-memory state immediately and renders Window 2 / Window 1.
     */
    fun updateState(json: JSONObject): JSONObject {
        val prevState = _hudState.value.state
        val nextState = parseHudStateFromJson(json)
        _hudState.value = nextState

        // Manage live elapsed execution timer across state transitions
        when (nextState.state) {
            "WORKING" -> {
                if (prevState != "WORKING") {
                    workStartedAtMs = System.currentTimeMillis()
                    _elapsedMsFlow.value = 0L
                }
                startElapsedTimer()
            }
            "NEEDS_INPUT" -> {
                if (workStartedAtMs > 0L) {
                    _elapsedMsFlow.value = (System.currentTimeMillis() - workStartedAtMs).coerceAtLeast(0L)
                }
                stopElapsedTimer()
            }
            "DONE" -> {
                if (workStartedAtMs > 0L) {
                    _elapsedMsFlow.value = (System.currentTimeMillis() - workStartedAtMs).coerceAtLeast(0L)
                }
                stopElapsedTimer()
            }
            else -> {
                workStartedAtMs = 0L
                _elapsedMsFlow.value = 0L
                stopElapsedTimer()
            }
        }

        val hasPerm = hasOverlayPermission()
        when (nextState.state) {
            "WORKING" -> {
                if (prevState != "WORKING") {
                    isCollapsed = false
                }
            }
            "NEEDS_INPUT" -> {
                isCollapsed = false
                if (!hasPerm) _isInputVisible.value = true
            }
            "DONE", "IDLE" -> {
                if (nextState.autoCollapseSeconds <= 0 && !isOutputExpanded) {
                    isCollapsed = true
                    if (!hasPerm) _isInputVisible.value = false
                }
            }
        }

        if (hasPerm) {
            runOnMain {
                ensureHudWindowAttached()
                when (nextState.state) {
                    "WORKING" -> {
                        cancelAutoCollapse()
                        if (prevState != "WORKING") {
                            isCollapsed = false
                        }
                    }
                    "NEEDS_INPUT" -> {
                        cancelAutoCollapse()
                        isCollapsed = false
                        showInputWindowInternal(requestKeyboardFocus = true)
                    }
                    "DONE", "IDLE" -> {
                        if (isOutputExpanded) {
                            cancelAutoCollapse()
                        } else if (nextState.autoCollapseSeconds > 0) {
                            scheduleAutoCollapse(nextState.autoCollapseSeconds)
                        } else {
                            isCollapsed = true
                            hideInputWindowInternal()
                        }
                    }
                }
                renderHudWindow()
                syncPulseAnimation()
            }
        } else if ((nextState.state == "DONE" || nextState.state == "IDLE") && nextState.autoCollapseSeconds > 0 && !isOutputExpanded) {
            runOnMain { scheduleAutoCollapse(nextState.autoCollapseSeconds) }
        }

        return JSONObject().apply {
            put("success", true)
            put("overlayRendered", hasPerm)
            if (!hasPerm) {
                put("permissionRequired", true)
                put("warning", "SYSTEM_ALERT_WINDOW not granted; HUD state stored in memory only.")
            }
            put("state", nextState.state)
            put("hudVisible", _isHudVisible.value)
            put("inputVisible", _isInputVisible.value)
            put("collapsed", isCollapsed)
            put("outputExpanded", isOutputExpanded)
            put("taskCount", nextState.tasks.size)
            put("screenWatchActive", nextState.screenWatch.active)
        }
    }

    /**
     * Shows the compact HUD pill (or expands it) directly from the in-app Settings toggle.
     */
    fun showCompactPill(): Boolean {
        if (!hasOverlayPermission()) return false
        runOnMain {
            isCollapsed = true
            ensureHudWindowAttached()
            renderHudWindow()
        }
        return true
    }

    /**
     * Handles POST /api/hud/command:
     * - action = PROMPT / STOP: enqueues command + broadcasts HUD_COMMAND via WebSocket
     * - action = OPEN_INPUT / CLOSE_INPUT / EXPAND / COLLAPSE / TOGGLE_GHOST / CYCLE_OPACITY
     */
    fun handleRemoteCommand(json: JSONObject): JSONObject {
        val action = json.optString("action", "PROMPT").uppercase().trim()
        val text = json.optString("text", json.optString("prompt", "")).trim()
        val result = JSONObject()

        when (action) {
            "OPEN_INPUT" -> {
                val autoFocus = json.optBoolean("focus", true)
                if (!hasOverlayPermission()) {
                    _isInputVisible.value = true
                    return result.put("success", true).put("action", action)
                        .put("inputVisible", true).put("sandboxOnly", true)
                }
                runOnMain {
                    ensureHudWindowAttached()
                    showInputWindowInternal(requestKeyboardFocus = autoFocus)
                    renderHudWindow()
                }
                result.put("success", true).put("action", action).put("inputVisible", true)
            }
            "CLOSE_INPUT" -> {
                runOnMain { hideInputWindowInternal() }
                _isInputVisible.value = false
                result.put("success", true).put("action", action).put("inputVisible", false)
            }
            "EXPAND" -> {
                cancelAutoCollapse()
                isCollapsed = false
                if (hasOverlayPermission()) {
                    runOnMain {
                        ensureHudWindowAttached()
                        renderHudWindow()
                    }
                }
                result.put("success", true).put("action", action).put("collapsed", false)
            }
            "COLLAPSE" -> {
                isCollapsed = true
                runOnMain {
                    hideInputWindowInternal()
                    if (hudRootView != null) renderHudWindow()
                }
                result.put("success", true).put("action", action).put("collapsed", true)
            }
            "TOGGLE_GHOST" -> {
                val enabled = if (json.has("enabled")) json.optBoolean("enabled") else !ghostPassThrough
                runOnMain { setGhostModeInternal(enabled) }
                result.put("success", true).put("action", action).put("ghostPassThrough", enabled)
            }
            "TOGGLE_WIREFRAME" -> {
                val enabled = if (json.has("enabled")) json.optBoolean("enabled") else !wireframeEnabled
                wireframeEnabled = enabled
                runOnMain { if (hudRootView != null) renderHudWindow() }
                result.put("success", true).put("action", action).put("wireframeEnabled", enabled)
            }
            "TOGGLE_OUTPUT" -> {
                val expanded = if (json.has("expanded")) json.optBoolean("expanded") else !isOutputExpanded
                setOutputExpanded(expanded)
                result.put("success", true).put("action", action).put("outputExpanded", expanded)
            }
            "COPY_OUTPUT" -> {
                val copied = copyDetailedOutputToClipboard()
                result.put("success", copied).put("action", action)
            }
            "CYCLE_OPACITY" -> {
                runOnMain { cycleOpacityInternal() }
                result.put("success", true).put("action", action)
                    .put("opacity", OPACITY_LEVELS[opacityIndex].toDouble())
            }
            "STOP" -> {
                val cmd = enqueueAndBroadcastCommand(text = text.ifBlank { "STOP" }, action = "STOP")
                result.put("success", true).put("command", cmd.toJson())
            }
            else -> {
                if (text.isEmpty()) {
                    return result.put("success", false).put("error", "Missing 'text' for PROMPT command")
                }
                val cmd = enqueueAndBroadcastCommand(text = text, action = "PROMPT")
                result.put("success", true).put("command", cmd.toJson())
            }
        }
        return result
    }

    /**
     * Enqueues a HUD_COMMAND into the thread-safe queue for GET /api/hud/poll and immediately
     * pushes it to connected WebSocket clients.
     */
    fun enqueueAndBroadcastCommand(text: String, action: String = "PROMPT"): HudCommand {
        val normalizedAction = if (action.equals("STOP", ignoreCase = true)) "STOP" else "PROMPT"
        val cmd = HudCommand(text = text, action = normalizedAction)
        while (commandQueue.size >= MAX_QUEUED_COMMANDS) {
            commandQueue.poll()
        }
        commandQueue.offer(cmd)
        try {
            onCommandBroadcast?.invoke(cmd.toJson())
        } catch (e: Exception) {
            Log.w(TAG, "Failed broadcasting HUD_COMMAND: ${e.message}")
        }
        return cmd
    }

    /**
     * Handles GET /api/hud/poll: atomically drains all pending commands typed in Window 1.
     */
    fun pollCommands(): JSONObject {
        val drained = JSONArray()
        while (true) {
            val next = commandQueue.poll() ?: break
            drained.put(next.toJson())
        }
        return JSONObject().apply {
            put("success", true)
            put("count", drained.length())
            put("commands", drained)
            put("hudVisible", _isHudVisible.value)
            put("inputVisible", _isInputVisible.value)
            put("collapsed", isCollapsed)
            put("state", _hudState.value.state)
            put("ghostPassThrough", ghostPassThrough)
            put("opacity", OPACITY_LEVELS[opacityIndex].toDouble())
        }
    }

    fun setOutputExpanded(expanded: Boolean) {
        isOutputExpanded = expanded
        if (expanded) {
            cancelAutoCollapse()
            if (isCollapsed) isCollapsed = false
        }
        runOnMain {
            if (hudRootView != null) renderHudWindow()
        }
    }

    fun getFullOutputCopyText(state: AgyHudState = _hudState.value): String {
        val sb = StringBuilder()
        if (state.detailedOutput.isNotBlank()) {
            sb.append(state.detailedOutput.trim())
        }
        if (state.outputLogs.isNotEmpty()) {
            if (sb.isNotEmpty()) sb.append("\n\n--- Execution Log ---\n")
            sb.append(state.outputLogs.joinToString("\n"))
        }
        if (sb.isEmpty() && state.currentAction.isNotBlank()) {
            sb.append("${state.title}: ${state.currentAction}")
        }
        return sb.toString().trim()
    }

    fun copyDetailedOutputToClipboard(): Boolean {
        val content = getFullOutputCopyText()
        if (content.isBlank()) return false
        return try {
            val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
            cm?.setPrimaryClip(ClipData.newPlainText("Agy Output", content))
            runOnMain {
                outputCopyBtn?.text = "Copied ✓"
                outputCopyBtn?.setTextColor(COLOR_EMERALD)
                copyFeedbackResetRunnable?.let { mainHandler.removeCallbacks(it) }
                val reset = Runnable {
                    outputCopyBtn?.text = "Copy"
                    outputCopyBtn?.setTextColor(COLOR_CYAN)
                }
                copyFeedbackResetRunnable = reset
                mainHandler.postDelayed(reset, 1600L)
            }
            true
        } catch (_: Exception) {
            false
        }
    }

    fun resolveQuickActions(state: AgyHudState): List<QuickActionChip> {
        if (state.quickActions.isNotEmpty()) return state.quickActions
        val hasOutput = state.detailedOutput.isNotBlank() || state.outputLogs.isNotEmpty()
        return when (state.state) {
            "NEEDS_INPUT" -> listOf(
                QuickActionChip("Yes, proceed", "Yes, proceed", "PROMPT"),
                QuickActionChip("Skip step", "Skip this step", "PROMPT"),
                QuickActionChip("Cancel", "STOP", "STOP")
            )
            "DONE" -> buildList {
                if (hasOutput) {
                    add(QuickActionChip("Copy Output", "", "COPY_OUTPUT"))
                    add(QuickActionChip(if (isOutputExpanded) "Hide Output" else "View Output", "", "TOGGLE_OUTPUT"))
                }
                add(QuickActionChip("Run Again", "Run again: ${state.title}", "PROMPT"))
            }
            "WORKING" -> buildList {
                if (hasOutput) {
                    add(QuickActionChip(if (isOutputExpanded) "Hide Output" else "Live Output", "", "TOGGLE_OUTPUT"))
                }
                add(QuickActionChip("Stop", "STOP", "STOP"))
            }
            else -> emptyList()
        }
    }

    fun resolveCollapsedRunningStep(state: AgyHudState = _hudState.value): CollapsedRunningStep {
        val activeDoingTask = state.tasks.firstOrNull { it.status == "doing" }
        val stepLabel = when {
            activeDoingTask != null && activeDoingTask.label.isNotBlank() -> activeDoingTask.label.trim()
            state.currentAction.isNotBlank() -> state.currentAction.trim()
            state.title.isNotBlank() -> state.title.trim()
            else -> "Working"
        }
        val resolvedIcon = AgyAppIconResolver.resolve(
            context = context,
            explicitIcon = activeDoingTask?.icon?.ifBlank { state.icon } ?: state.icon,
            explicitPackage = activeDoingTask?.appPackage?.ifBlank { state.appPackage } ?: state.appPackage,
            fallbackText = "${activeDoingTask?.label.orEmpty()} ${activeDoingTask?.detail.orEmpty()} ${state.currentAction} ${state.title}"
        )
        return CollapsedRunningStep(label = stepLabel, icon = resolvedIcon)
    }

    fun isCollapsedLiveRunningMode(
        state: AgyHudState = _hudState.value,
        collapsed: Boolean = isCollapsed
    ): Boolean = collapsed && state.state == "WORKING"

    fun formatElapsed(ms: Long, isDone: Boolean = false): String {
        val safe = ms.coerceAtLeast(0L)
        val totalSec = safe / 1000.0
        return if (isDone) {
            String.format(Locale.US, "Done %.1fs", totalSec)
        } else if (safe < 60_000L) {
            String.format(Locale.US, "00:%04.1f", totalSec)
        } else {
            val mins = safe / 60_000L
            val secs = (safe % 60_000L) / 1000L
            String.format(Locale.US, "%02d:%02d", mins, secs)
        }
    }

    /**
     * Handles POST /api/hud/hide: dismisses both HUD windows cleanly and cancels timers.
     */
    fun hideAll(): JSONObject {
        runOnMain {
            cancelAutoCollapse()
            stopPulseAnimation()
            stopElapsedTimer()
            stopAllLoadingAnimations()
            copyFeedbackResetRunnable?.let { mainHandler.removeCallbacks(it) }
            passThroughRestoreRunnable?.let { mainHandler.removeCallbacks(it) }
            temporaryPassThroughActive = false
            ghostPassThrough = false
            isOutputExpanded = false
            isToolsTrayOpen = false
            lastCollapsedStepLabel = ""
            hideGhostRestorePillInternal()
            hideInputWindowInternal()
            hudRootView?.let { view ->
                try {
                    windowManager?.removeView(view)
                } catch (e: Exception) {
                    Log.w(TAG, "Error removing agy_hud: ${e.message}")
                }
            }
            hudRootView = null
            hudParams = null
            hudExpandedContainer = null
            hudBottomDockRow = null
            workingLoadingBar = null
            headerAppIconView = null
            headerSpinnerView = null
            elapsedTimerText = null
            toolsMenuBtn = null
            toolsTrayContainer = null
            doingDotsView = null
            outputSectionContainer = null
            outputToggleHeaderText = null
            outputDrawerContainer = null
            outputCopyBtn = null
            outputBodyText = null
            quickActionsScrollView = null
            quickActionsContainer = null
            dockStandardStatusGroup = null
            dockStandardDivider = null
            dockSpinnerView = null
            collapsedStatusText = null
            bottomChatPillBtn = null
            dockLiveStepGroup = null
            dockLiveSpinnerView = null
            dockLiveIconView = null
            dockLiveStepText = null
            dockLiveTimerText = null
            dockLiveStopBtn = null
            _isHudVisible.value = false
        }
        return JSONObject().apply {
            put("success", true)
            put("hudVisible", false)
            put("inputVisible", false)
        }
    }

    private fun stopAllLoadingAnimations() {
        hudExpandedContainer?.stopAurora()
        workingLoadingBar?.setAnimating(false)
        headerSpinnerView?.setAnimating(false)
        doingDotsView?.setAnimating(false)
        dockSpinnerView?.setAnimating(false)
        dockLiveSpinnerView?.setAnimating(false)
    }

    // -------------------------------------------------------------------------
    // Touch Collision Pass-Through Helpers (called by DeviceBridgeManager)
    // -------------------------------------------------------------------------

    fun getOverlayBounds(): List<Rect> {
        val rects = mutableListOf<Rect>()
        val screenW = context.resources.displayMetrics.widthPixels.coerceAtLeast(1080)
        val screenH = context.resources.displayMetrics.heightPixels.coerceAtLeast(1920)

        fun collectRect(view: View?, params: WindowManager.LayoutParams?) {
            if (view == null || params == null) return
            val loc = IntArray(2)
            view.getLocationOnScreen(loc)
            val w = view.width.takeIf { it > 0 } ?: (260 * density()).toInt()
            val h = view.height.takeIf { it > 0 } ?: (96 * density()).toInt()
            val left = if (loc[0] != 0 || loc[1] != 0) {
                loc[0]
            } else if ((params.gravity and Gravity.END) == Gravity.END || (params.gravity and Gravity.RIGHT) == Gravity.RIGHT) {
                (screenW - params.x - w).coerceAtLeast(0)
            } else {
                params.x.coerceAtLeast(0)
            }
            val top = if (loc[0] != 0 || loc[1] != 0) {
                loc[1]
            } else if ((params.gravity and Gravity.BOTTOM) == Gravity.BOTTOM) {
                (screenH - params.y - h).coerceAtLeast(0)
            } else {
                params.y.coerceAtLeast(0)
            }
            rects.add(Rect(left, top, left + w, top + h))
        }

        collectRect(hudRootView, hudParams)
        collectRect(inputRootView, inputParams)
        collectRect(ghostRestoreView, ghostRestoreParams)
        return rects
    }

    fun coordinatesOverlapRects(
        x1: Float,
        y1: Float,
        x2: Float = x1,
        y2: Float = y1,
        rects: List<Rect>
    ): Boolean {
        if (rects.isEmpty()) return false
        val segRect = Rect(
            min(x1, x2).toInt(),
            min(y1, y2).toInt(),
            max(x1, x2).toInt() + 1,
            max(y1, y2).toInt() + 1
        )
        return rects.any { r ->
            r.contains(x1.toInt(), y1.toInt()) ||
                r.contains(x2.toInt(), y2.toInt()) ||
                Rect.intersects(r, segRect)
        }
    }

    /**
     * Checks if a gesture (TAP/SWIPE/DRAG) overlaps agy_hud or agy_input; if so, temporarily
     * applies FLAG_NOT_TOUCHABLE for ~durationMs (default 300ms) so touch passes directly underneath.
     */
    fun temporarilyPassThroughIfColliding(
        x1: Float,
        y1: Float,
        x2: Float = x1,
        y2: Float = y1,
        durationMs: Long = 300L
    ): Boolean {
        if (!_isHudVisible.value && !_isInputVisible.value) return false
        val bounds = getOverlayBounds()
        if (!coordinatesOverlapRects(x1, y1, x2, y2, bounds)) return false

        val safeDuration = durationMs.coerceIn(250L, 2500L)
        val latch = CountDownLatch(1)
        val applyTask = Runnable {
            try {
                temporaryPassThroughActive = true
                applyTouchableFlagsInternal(touchable = false)
                passThroughRestoreRunnable?.let { mainHandler.removeCallbacks(it) }
                val restore = Runnable {
                    temporaryPassThroughActive = false
                    if (!ghostPassThrough) {
                        applyTouchableFlagsInternal(touchable = true)
                    }
                }
                passThroughRestoreRunnable = restore
                mainHandler.postDelayed(restore, safeDuration)
            } finally {
                latch.countDown()
            }
        }
        if (Looper.myLooper() == Looper.getMainLooper()) {
            applyTask.run()
        } else {
            mainHandler.post(applyTask)
            try {
                latch.await(150L, TimeUnit.MILLISECONDS)
            } catch (_: InterruptedException) {}
        }
        return true
    }

    // -------------------------------------------------------------------------
    // Window 2: Live Task & Screen HUD (`agy_hud`)
    // -------------------------------------------------------------------------

    private fun ensureHudWindowAttached() {
        if (hudRootView != null) {
            _isHudVisible.value = true
            return
        }
        val wm = windowManager ?: return
        val d = density()

        val root = HoldDraggableDockLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.END
            clipChildren = false
            clipToPadding = false
        }
        val expanded = buildExpandedHudCard(d)
        val bottomDock = buildBottomChatDockRow(d)
        root.addView(expanded)
        root.addView(bottomDock)
        tagTreeForSelfExclusion(root, "window2")

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayWindowType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.END
            x = (14 * d).toInt()
            y = (28 * d).toInt()
        }

        hudRootView = root
        hudParams = params
        hudExpandedContainer = expanded
        hudBottomDockRow = bottomDock

        // Hold anywhere (~180ms) on either the Working Window or Bottom Chat Pill to drag both together
        root.onDragDelta = { dx, dy ->
            shiftBottomRightWindow(root, params, dx, dy)
            inputRootView?.let { inRoot ->
                inputParams?.let { inParams ->
                    shiftBottomRightWindow(inRoot, inParams, dx, dy)
                }
            }
        }

        try {
            wm.addView(root, params)
            _isHudVisible.value = true
        } catch (e: Exception) {
            Log.e(TAG, "Failed adding agy_hud window: ${e.message}")
            hudRootView = null
            hudParams = null
            hudExpandedContainer = null
            hudBottomDockRow = null
            _isHudVisible.value = false
        }
    }

    private fun buildExpandedHudCard(d: Float): AgyAuroraCardLayout {
        val cardWidthPx = min((286 * d).toInt(), (context.resources.displayMetrics.widthPixels * 0.86f).toInt())
        val container = AgyAuroraCardLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(cardWidthPx, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = (8 * d).toInt()
            }
            setPadding((14 * d).toInt(), (11 * d).toInt(), (14 * d).toInt(), (12 * d).toInt())
            elevation = 10f * d
            layoutTransition = LayoutTransition().apply {
                setDuration(190L)
                enableTransitionType(LayoutTransition.CHANGING)
            }
        }

        // Top Indeterminate Sliding Progress Bar (animates while state == WORKING)
        val loadBar = AgyLoadingBarView(context).apply {
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                (3.5f * d).toInt().coerceAtLeast(4)
            ).apply {
                bottomMargin = (8 * d).toInt()
            }
            visibility = View.GONE
        }
        workingLoadingBar = loadBar
        container.addView(loadBar)

        // Ultra-Clean Minimal Header: App/Task Icon + Single-Line Status & Timer + Only 2 Quiet Controls (··· & —)
        val header = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }

        val appIcon = AgyIconBadgeView(context).apply {
            val sz = (24 * d).toInt()
            layoutParams = LinearLayout.LayoutParams(sz, sz).apply { marginEnd = (8 * d).toInt() }
        }
        headerAppIconView = appIcon

        val statusTopRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }

        val headerSpinner = AgySpinnerRingView(context).apply {
            val sz = (12 * d).toInt()
            layoutParams = LinearLayout.LayoutParams(sz, sz).apply { marginEnd = (6 * d).toInt() }
            setAccentColor(COLOR_CYAN)
            visibility = View.GONE
        }
        headerSpinnerView = headerSpinner

        val dot = View(context).apply {
            val sz = (6 * d).toInt()
            layoutParams = LinearLayout.LayoutParams(sz, sz).apply { marginEnd = (6 * d).toInt() }
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(COLOR_CYAN)
            }
        }
        statusDotView = dot

        val badge = TextView(context).apply {
            text = "Ready"
            textSize = 11.5f
            setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
            setTextColor(COLOR_TEXT_PRIMARY)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        statusBadgeText = badge

        val timerTv = TextView(context).apply {
            text = ""
            textSize = 10.5f
            typeface = Typeface.MONOSPACE
            setTextColor(COLOR_TEXT_SECONDARY)
            maxLines = 1
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { marginStart = (6 * d).toInt() }
            visibility = View.GONE
        }
        elapsedTimerText = timerTv

        statusTopRow.addView(headerSpinner)
        statusTopRow.addView(dot)
        statusTopRow.addView(badge)
        statusTopRow.addView(timerTv)

        fun headerControlChip(symbol: String, desc: String, onClick: () -> Unit): TextView {
            return TextView(context).apply {
                text = symbol
                textSize = 12f
                gravity = Gravity.CENTER
                setTextColor(COLOR_TEXT_SECONDARY)
                val sz = (26 * d).toInt()
                layoutParams = LinearLayout.LayoutParams(sz, sz).apply { marginStart = (4 * d).toInt() }
                background = createLiquidGlassDrawable(
                    fillColor = Color.parseColor("#F3F4F6"),
                    strokeColor = Color.TRANSPARENT,
                    radiusDp = 999f,
                    strokeDp = 0f
                )
                contentDescription = "${HUD_NODE_TAG_PREFIX}$desc"
                setOnClickListener { onClick() }
            }
        }

        val moreBtn = headerControlChip("···", "tools_menu_btn") {
            isToolsTrayOpen = !isToolsTrayOpen
            renderHudWindow()
        }
        toolsMenuBtn = moreBtn

        val collapseBtn = headerControlChip("─", "collapse_btn") {
            isCollapsed = true
            isOutputExpanded = false
            isToolsTrayOpen = false
            hideInputWindowInternal()
            renderHudWindow()
        }

        header.addView(appIcon)
        header.addView(statusTopRow)
        header.addView(moreBtn)
        header.addView(collapseBtn)
        container.addView(header)

        // Hidden-by-default Secondary Controls Tray (revealed on tapping ···)
        val tray = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding((6 * d).toInt(), (5 * d).toInt(), (6 * d).toInt(), (5 * d).toInt())
            background = createLiquidGlassDrawable(
                fillColor = Color.parseColor("#F5F6F8"),
                strokeColor = COLOR_HAIRLINE,
                radiusDp = 12f,
                strokeDp = 0.7f
            )
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = (8 * d).toInt() }
            visibility = View.GONE
        }

        fun trayToolChip(label: String, desc: String, onClick: () -> Unit): TextView {
            return TextView(context).apply {
                text = label
                textSize = 10f
                gravity = Gravity.CENTER
                setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
                setTextColor(COLOR_TEXT_PRIMARY)
                setPadding((8 * d).toInt(), (4 * d).toInt(), (8 * d).toInt(), (4 * d).toInt())
                background = createLiquidGlassDrawable(
                    fillColor = Color.WHITE,
                    strokeColor = COLOR_HAIRLINE,
                    radiusDp = 999f,
                    strokeDp = 0.7f
                )
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                    marginStart = (2 * d).toInt()
                    marginEnd = (2 * d).toInt()
                }
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
                contentDescription = "${HUD_NODE_TAG_PREFIX}$desc"
                setOnClickListener { onClick() }
            }
        }

        val opBtn = trayToolChip("100%", "opacity_btn") { cycleOpacityInternal() }
        opacityBtn = opBtn
        val wfBtn = trayToolChip("Wireframe", "wireframe_toggle_btn") {
            wireframeEnabled = !wireframeEnabled
            renderHudWindow()
        }
        wireframeBtn = wfBtn
        val ghBtn = trayToolChip("Ghost", "ghost_toggle_btn") {
            setGhostModeInternal(!ghostPassThrough)
        }
        ghostBtn = ghBtn

        tray.addView(opBtn)
        tray.addView(wfBtn)
        tray.addView(ghBtn)
        toolsTrayContainer = tray
        container.addView(tray)

        // Task Title
        val titleTv = TextView(context).apply {
            text = "Agy Ready"
            textSize = 14f
            setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
            setTextColor(COLOR_TEXT_PRIMARY)
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = (9 * d).toInt() }
        }
        titleText = titleTv
        container.addView(titleTv)

        // Quiet Question Prompt Banner (visible on NEEDS_INPUT)
        val questionTv = TextView(context).apply {
            textSize = 11.5f
            setTextColor(Color.parseColor("#B45309"))
            setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
            setPadding((10 * d).toInt(), (7 * d).toInt(), (10 * d).toInt(), (7 * d).toInt())
            background = createLiquidGlassDrawable(
                fillColor = Color.parseColor("#FEF3C7"),
                strokeColor = Color.parseColor("#FDE68A"),
                radiusDp = 12f,
                strokeDp = 0.8f
            )
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = (7 * d).toInt() }
            visibility = View.GONE
            setOnClickListener { showInputWindowInternal(requestKeyboardFocus = true) }
        }
        questionBannerText = questionTv
        container.addView(questionTv)

        // Doing Now row + animated 3 bouncing dots
        val doingRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = (4 * d).toInt() }
            visibility = View.GONE
        }
        val doingTv = TextView(context).apply {
            textSize = 11.5f
            setTypeface(Typeface.SANS_SERIF, Typeface.NORMAL)
            setTextColor(COLOR_TEXT_SECONDARY)
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        val bounceDots = AgyBouncingDotsView(context).apply {
            setAccentColor(COLOR_CYAN)
            layoutParams = LinearLayout.LayoutParams(
                (22 * d).toInt(),
                (12 * d).toInt()
            ).apply { marginStart = (4 * d).toInt() }
            visibility = View.GONE
        }
        doingRow.addView(doingTv)
        doingRow.addView(bounceDots)
        doingRowContainer = doingRow
        currentActionText = doingTv
        doingDotsView = bounceDots
        container.addView(doingRow)

        val nextTv = TextView(context).apply {
            textSize = 10.5f
            setTypeface(Typeface.SANS_SERIF, Typeface.NORMAL)
            setTextColor(COLOR_TEXT_SECONDARY)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = (2 * d).toInt() }
            visibility = View.GONE
        }
        nextActionText = nextTv
        container.addView(nextTv)

        // Clean Airy Task List Container inside compact ScrollView (with per-task real/vector icons)
        val tasksLayout = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }
        taskListContainer = tasksLayout

        val scroll = ScrollView(context).apply {
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = (8 * d).toInt() }
            isVerticalScrollBarEnabled = false
            addView(tasksLayout)
            visibility = View.GONE
        }
        taskScrollView = scroll
        container.addView(scroll)

        // Quiet Neutral Expandable Detailed Output Drawer inside Working Card
        val outSection = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = (8 * d).toInt() }
            visibility = View.GONE
        }

        val outToggleTv = TextView(context).apply {
            text = "Output ▾"
            textSize = 11f
            setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
            setTextColor(COLOR_TEXT_PRIMARY)
            setPadding((10 * d).toInt(), (6 * d).toInt(), (10 * d).toInt(), (6 * d).toInt())
            background = createLiquidGlassDrawable(
                fillColor = Color.parseColor("#F3F4F6"),
                strokeColor = COLOR_HAIRLINE,
                radiusDp = 12f,
                strokeDp = 0.7f
            )
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            contentDescription = "${HUD_NODE_TAG_PREFIX}toggle_output_btn"
            setOnClickListener { setOutputExpanded(!isOutputExpanded) }
        }
        outputToggleHeaderText = outToggleTv

        val outDrawer = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((10 * d).toInt(), (8 * d).toInt(), (10 * d).toInt(), (8 * d).toInt())
            background = createLiquidGlassDrawable(
                fillColor = Color.parseColor("#F8FAFC"),
                strokeColor = COLOR_HAIRLINE,
                radiusDp = 12f,
                strokeDp = 0.7f
            )
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = (5 * d).toInt() }
            visibility = View.GONE
        }

        val outToolbar = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = (5 * d).toInt() }
        }

        val outMetaLbl = TextView(context).apply {
            text = "OUTPUT & LOGS"
            textSize = 9f
            typeface = Typeface.MONOSPACE
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(COLOR_TEXT_SECONDARY)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }

        val copyBtn = TextView(context).apply {
            text = "Copy"
            textSize = 9.5f
            setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
            setTextColor(COLOR_CYAN)
            setPadding((9 * d).toInt(), (3 * d).toInt(), (9 * d).toInt(), (3 * d).toInt())
            background = createLiquidGlassDrawable(
                fillColor = Color.WHITE,
                strokeColor = COLOR_HAIRLINE,
                radiusDp = 999f,
                strokeDp = 0.8f
            )
            contentDescription = "${HUD_NODE_TAG_PREFIX}copy_output_btn"
            setOnClickListener { copyDetailedOutputToClipboard() }
        }
        outputCopyBtn = copyBtn
        outToolbar.addView(outMetaLbl)
        outToolbar.addView(copyBtn)

        val outBody = TextView(context).apply {
            textSize = 10f
            typeface = Typeface.MONOSPACE
            setTextColor(COLOR_TEXT_PRIMARY)
            setLineSpacing(2f * d, 1.0f)
        }
        outputBodyText = outBody

        val outScroll = ScrollView(context).apply {
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                (128 * d).toInt()
            )
            isVerticalScrollBarEnabled = true
            addView(outBody)
        }

        outDrawer.addView(outToolbar)
        outDrawer.addView(outScroll)
        outputDrawerContainer = outDrawer

        outSection.addView(outToggleTv)
        outSection.addView(outDrawer)
        outputSectionContainer = outSection
        container.addView(outSection)

        // Contextual Quick Action Chips Strip
        val qaRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        quickActionsContainer = qaRow

        val qaScroll = HorizontalScrollView(context).apply {
            isHorizontalScrollBarEnabled = false
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = (7 * d).toInt() }
            addView(qaRow)
            visibility = View.GONE
        }
        quickActionsScrollView = qaScroll
        container.addView(qaScroll)

        // Mini Low-Poly Screen Wireframe Section (collapses to 0dp / GONE when screenWatch.active == false)
        val wfBox = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding((8 * d).toInt(), (6 * d).toInt(), (8 * d).toInt(), (6 * d).toInt())
            background = createLiquidGlassDrawable(
                fillColor = COLOR_INNER_CAPSULE,
                strokeColor = COLOR_HAIRLINE,
                radiusDp = 16f,
                strokeDp = 0.9f
            )
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = (7 * d).toInt() }
            visibility = View.GONE
        }

        val wfView = MiniScreenWireframeView(context)
        wireframeView = wfView

        val wfCaption = TextView(context).apply {
            textSize = 10f
            typeface = Typeface.MONOSPACE
            setTextColor(COLOR_TEXT_SECONDARY)
            maxLines = 3
            ellipsize = TextUtils.TruncateAt.END
            layoutParams = LinearLayout.LayoutParams(
                0,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                1f
            ).apply { marginStart = (10 * d).toInt() }
        }
        wireframeLabelText = wfCaption

        wfBox.addView(wfView)
        wfBox.addView(wfCaption)
        wireframeContainer = wfBox
        container.addView(wfBox)

        return container
    }

    /**
     * Always-visible bottom pill dock anchored underneath the Working Window.
     * - When collapsed & WORKING: morphs into a live running step capsule showing
     *   [Active App/Task Icon + Spinner Ring] [Scrolling Live Step] [Elapsed Timer] [Stop ■].
     * - When expanded, IDLE, NEEDS_INPUT, or DONE: shows the calm status toggle + [✦ Ask Agy / Reply].
     */
    private fun buildBottomChatDockRow(d: Float): LinearLayout {
        val screenW = context.resources.displayMetrics.widthPixels.coerceAtLeast(360)
        val dock = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding((10 * d).toInt(), (6 * d).toInt(), (6 * d).toInt(), (6 * d).toInt())
            background = createLiquidGlassDrawable(
                fillColor = COLOR_OBSIDIAN_GLASS,
                strokeColor = COLOR_HAIRLINE,
                radiusDp = 999f,
                strokeDp = 1.0f
            )
            elevation = 10f * d
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            layoutTransition = LayoutTransition().apply {
                setDuration(180L)
                enableTransitionType(LayoutTransition.CHANGING)
            }
        }

        // --- Mode B: Standard Status + Ask Agy Controls (Expanded / Idle / Needs Input / Done) ---
        val statusGroup = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding((2 * d).toInt(), (3 * d).toInt(), (8 * d).toInt(), (3 * d).toInt())
            contentDescription = "${HUD_NODE_TAG_PREFIX}collapsed_expand_btn"
            setOnClickListener {
                cancelAutoCollapse()
                isCollapsed = !isCollapsed
                renderHudWindow()
            }
        }
        dockStandardStatusGroup = statusGroup

        val dSpinner = AgySpinnerRingView(context).apply {
            val sz = (13 * d).toInt()
            layoutParams = LinearLayout.LayoutParams(sz, sz).apply { marginEnd = (6 * d).toInt() }
            setAccentColor(COLOR_CYAN)
            visibility = View.GONE
        }
        dockSpinnerView = dSpinner

        val statusTv = TextView(context).apply {
            text = "○ Ready ▲"
            textSize = 11.5f
            setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
            setTextColor(COLOR_TEXT_PRIMARY)
            maxLines = 1
        }
        collapsedStatusText = statusTv

        statusGroup.addView(dSpinner)
        statusGroup.addView(statusTv)

        val divider = View(context).apply {
            layoutParams = LinearLayout.LayoutParams((1 * d).toInt(), (18 * d).toInt()).apply {
                marginEnd = (6 * d).toInt()
            }
            setBackgroundColor(COLOR_HAIRLINE)
        }
        dockStandardDivider = divider

        val askBtn = TextView(context).apply {
            text = "✦ Ask Agy"
            textSize = 11.5f
            setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
            setTextColor(Color.WHITE)
            setPadding((12 * d).toInt(), (6 * d).toInt(), (12 * d).toInt(), (6 * d).toInt())
            background = createLiquidGlassDrawable(
                fillColor = COLOR_CYAN,
                strokeColor = COLOR_CYAN,
                radiusDp = 999f,
                strokeDp = 0.8f
            )
            contentDescription = "${HUD_NODE_TAG_PREFIX}bottom_chat_pill_btn"
            setOnClickListener {
                cancelAutoCollapse()
                if (_isInputVisible.value) {
                    hideInputWindowInternal()
                } else {
                    showInputWindowInternal(requestKeyboardFocus = true)
                }
            }
        }
        bottomChatPillBtn = askBtn

        // --- Mode A: Live Collapsed Running Step Pill (Collapsed && WORKING) ---
        val liveGroup = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding((2 * d).toInt(), (1 * d).toInt(), (4 * d).toInt(), (1 * d).toInt())
            contentDescription = "${HUD_NODE_TAG_PREFIX}collapsed_live_step_btn"
            visibility = View.GONE
            setOnClickListener {
                cancelAutoCollapse()
                isCollapsed = false
                renderHudWindow()
            }
        }
        dockLiveStepGroup = liveGroup

        val badgeFrame = FrameLayout(context).apply {
            val outerSz = (26 * d).toInt()
            layoutParams = LinearLayout.LayoutParams(outerSz, outerSz).apply {
                marginEnd = (8 * d).toInt()
            }
        }
        val liveRing = AgySpinnerRingView(context).apply {
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            setAccentColor(COLOR_CYAN)
        }
        dockLiveSpinnerView = liveRing

        val liveIcon = AgyIconBadgeView(context).apply {
            val innerSz = (18 * d).toInt()
            layoutParams = FrameLayout.LayoutParams(innerSz, innerSz, Gravity.CENTER)
        }
        dockLiveIconView = liveIcon
        badgeFrame.addView(liveRing)
        badgeFrame.addView(liveIcon)

        val liveStepTv = TextView(context).apply {
            text = "Working"
            textSize = 12f
            setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
            setTextColor(COLOR_TEXT_PRIMARY)
            isSingleLine = true
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.MARQUEE
            marqueeRepeatLimit = -1
            isHorizontalFadingEdgeEnabled = true
            setFadingEdgeLength((14 * d).toInt())
            isSelected = true
            minWidth = (56 * d).toInt()
            maxWidth = min((168 * d).toInt(), (screenW * 0.45f).toInt())
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                marginEnd = (8 * d).toInt()
            }
        }
        dockLiveStepText = liveStepTv

        val liveTimerTv = TextView(context).apply {
            text = "00:00.0"
            textSize = 10.5f
            typeface = Typeface.MONOSPACE
            setTextColor(COLOR_TEXT_SECONDARY)
            maxLines = 1
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                marginEnd = (4 * d).toInt()
            }
        }
        dockLiveTimerText = liveTimerTv

        liveGroup.addView(badgeFrame)
        liveGroup.addView(liveStepTv)
        liveGroup.addView(liveTimerTv)

        val liveStopBtn = TextView(context).apply {
            text = "■"
            textSize = 10.5f
            setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
            setTextColor(COLOR_CORAL)
            gravity = Gravity.CENTER
            val sz = (28 * d).toInt()
            layoutParams = LinearLayout.LayoutParams(sz, sz).apply {
                marginStart = (2 * d).toInt()
            }
            background = createLiquidGlassDrawable(
                fillColor = Color.parseColor("#1AE11D48"),
                strokeColor = Color.parseColor("#44E11D48"),
                radiusDp = 999f,
                strokeDp = 0.85f
            )
            contentDescription = "${HUD_NODE_TAG_PREFIX}collapsed_stop_btn"
            visibility = View.GONE
            setOnClickListener {
                cancelAutoCollapse()
                enqueueAndBroadcastCommand(text = "STOP", action = "STOP")
            }
        }
        dockLiveStopBtn = liveStopBtn

        dock.addView(statusGroup)
        dock.addView(divider)
        dock.addView(askBtn)
        dock.addView(liveGroup)
        dock.addView(liveStopBtn)
        return dock
    }

    private fun renderHudWindow() {
        val state = _hudState.value
        val d = density()
        val alphaVal = OPACITY_LEVELS[opacityIndex]
        val isWorking = state.state == "WORKING"
        val isNeedsInput = state.state == "NEEDS_INPUT"
        val isDone = state.state == "DONE"
        val liveCollapsedMode = isCollapsedLiveRunningMode(state, isCollapsed)
        val accentColor = when (state.state) {
            "WORKING" -> COLOR_CYAN
            "NEEDS_INPUT" -> COLOR_AMBER
            "DONE" -> COLOR_EMERALD
            else -> COLOR_VIOLET
        }

        hudRootView?.alpha = if (ghostPassThrough) (alphaVal * 0.45f).coerceAtLeast(0.22f) else alphaVal
        inputRootView?.alpha = if (ghostPassThrough) (alphaVal * 0.45f).coerceAtLeast(0.22f) else alphaVal

        // Upper Working Window collapses/expands independently; Lower Pill Dock stays ALWAYS visible!
        hudExpandedContainer?.visibility = if (isCollapsed) View.GONE else View.VISIBLE
        hudBottomDockRow?.visibility = View.VISIBLE

        // Flowing Aurora Shimmer Border on Working Card
        hudExpandedContainer?.setRimMode(
            when {
                isCollapsed -> AgyAuroraCardLayout.RimMode.IDLE
                isWorking -> AgyAuroraCardLayout.RimMode.WORKING
                isNeedsInput -> AgyAuroraCardLayout.RimMode.NEEDS_INPUT
                isDone -> AgyAuroraCardLayout.RimMode.DONE
                else -> AgyAuroraCardLayout.RimMode.IDLE
            }
        )

        val rimColor = when {
            isNeedsInput -> COLOR_AMBER
            isWorking -> Color.parseColor("#660095F6")
            isDone -> Color.parseColor("#6616A34A")
            else -> COLOR_HAIRLINE
        }
        hudBottomDockRow?.setPadding(
            if (liveCollapsedMode) (8 * d).toInt() else (10 * d).toInt(),
            if (liveCollapsedMode) (5 * d).toInt() else (6 * d).toInt(),
            (6 * d).toInt(),
            if (liveCollapsedMode) (5 * d).toInt() else (6 * d).toInt()
        )
        hudBottomDockRow?.background = createLiquidGlassDrawable(
            fillColor = COLOR_OBSIDIAN_GLASS,
            strokeColor = rimColor,
            radiusDp = 999f,
            strokeDp = if (isNeedsInput || isWorking) 1.3f else 1.0f
        )

        // Resolve active App / Task Icon (preferring current doing task so icon updates dynamically per step)
        val activeCollapsedStep = resolveCollapsedRunningStep(state)
        headerAppIconView?.setIcon(activeCollapsedStep.icon)

        // Sync loading animations for WORKING state
        workingLoadingBar?.setAnimating(isWorking && !isCollapsed)

        if (isWorking) {
            headerSpinnerView?.visibility = View.VISIBLE
            headerSpinnerView?.setAccentColor(COLOR_CYAN)
            headerSpinnerView?.setAnimating(!isCollapsed)
            statusDotView?.visibility = View.GONE
        } else {
            headerSpinnerView?.setAnimating(false)
            headerSpinnerView?.visibility = View.GONE
            statusDotView?.visibility = View.VISIBLE
            statusDotView?.background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(accentColor)
            }
        }

        // Toggle between Live Collapsed Running Step Pill and Standard Ask Agy Bottom Dock
        dockStandardStatusGroup?.visibility = if (liveCollapsedMode) View.GONE else View.VISIBLE
        dockStandardDivider?.visibility = if (liveCollapsedMode) View.GONE else View.VISIBLE
        bottomChatPillBtn?.visibility = if (liveCollapsedMode) View.GONE else View.VISIBLE
        dockLiveStepGroup?.visibility = if (liveCollapsedMode) View.VISIBLE else View.GONE
        dockLiveStopBtn?.visibility = if (liveCollapsedMode) View.VISIBLE else View.GONE

        if (liveCollapsedMode) {
            dockSpinnerView?.setAnimating(false)
            dockSpinnerView?.visibility = View.GONE
            dockLiveIconView?.setIcon(activeCollapsedStep.icon)
            dockLiveSpinnerView?.setAccentColor(COLOR_CYAN)
            dockLiveSpinnerView?.setAnimating(true)

            val stepTv = dockLiveStepText
            if (stepTv != null) {
                val nextLabel = activeCollapsedStep.label
                if (nextLabel != lastCollapsedStepLabel) {
                    if (lastCollapsedStepLabel.isNotEmpty()) {
                        stepTv.animate().cancel()
                        stepTv.alpha = 0f
                        stepTv.translationY = 4f * d
                        stepTv.text = nextLabel
                        stepTv.isSelected = true
                        stepTv.animate()
                            .alpha(1f)
                            .translationY(0f)
                            .setDuration(190L)
                            .start()
                    } else {
                        stepTv.alpha = 1f
                        stepTv.translationY = 0f
                        stepTv.text = nextLabel
                        stepTv.isSelected = true
                    }
                    lastCollapsedStepLabel = nextLabel
                } else if (!stepTv.isSelected) {
                    stepTv.isSelected = true
                }
            }
        } else {
            dockLiveSpinnerView?.setAnimating(false)
            lastCollapsedStepLabel = ""

            if (isWorking) {
                dockSpinnerView?.visibility = View.VISIBLE
                dockSpinnerView?.setAccentColor(COLOR_CYAN)
                dockSpinnerView?.setAnimating(true)
            } else {
                dockSpinnerView?.setAnimating(false)
                dockSpinnerView?.visibility = View.GONE
            }

            // Always-visible Bottom Dock status label & Ask Agy Chat pill styling
            val chevron = if (isCollapsed) "▲" else "▼"
            val elapsed = _elapsedMsFlow.value
            val dockLabel = when (state.state) {
                "WORKING" -> "Working $chevron"
                "NEEDS_INPUT" -> "? Reply $chevron"
                "DONE" -> if (elapsed > 0L) {
                    "✓ Done · ${formatElapsed(elapsed, isDone = true).removePrefix("Done ")} $chevron"
                } else {
                    "✓ Done $chevron"
                }
                else -> "○ Ready $chevron"
            }
            collapsedStatusText?.text = dockLabel
            collapsedStatusText?.setTextColor(if (isNeedsInput) COLOR_AMBER else COLOR_TEXT_PRIMARY)

            val chatPillBgColor = if (isNeedsInput) COLOR_AMBER else COLOR_CYAN
            bottomChatPillBtn?.text = if (isNeedsInput) "✦ Reply" else "✦ Ask Agy"
            bottomChatPillBtn?.background = createLiquidGlassDrawable(
                fillColor = chatPillBgColor,
                strokeColor = chatPillBgColor,
                radiusDp = 999f,
                strokeDp = 0.8f
            )
        }

        // Update Live Elapsed Timer label (both expanded header & collapsed live pill)
        updateElapsedTimerDisplay()

        // Ultra-Clean Single-Line Status & Expandable Tools Tray
        val cleanStatusLabel = when (state.state) {
            "WORKING" -> "Working"
            "NEEDS_INPUT" -> "Needs input"
            "DONE" -> "Done"
            else -> "Ready"
        }
        statusBadgeText?.text = cleanStatusLabel
        statusBadgeText?.setTextColor(accentColor)

        toolsMenuBtn?.background = createLiquidGlassDrawable(
            fillColor = if (isToolsTrayOpen) Color.parseColor("#E0F2FE") else Color.parseColor("#F3F4F6"),
            strokeColor = Color.TRANSPARENT,
            radiusDp = 999f,
            strokeDp = 0f
        )
        toolsMenuBtn?.setTextColor(if (isToolsTrayOpen) COLOR_CYAN else COLOR_TEXT_SECONDARY)
        toolsTrayContainer?.visibility = if (isToolsTrayOpen && !isCollapsed) View.VISIBLE else View.GONE

        val opacityPct = (alphaVal * 100).toInt()
        opacityBtn?.text = "Opacity $opacityPct%"
        wireframeBtn?.text = if (wireframeEnabled) "● Wireframe" else "Wireframe"
        wireframeBtn?.setTextColor(if (wireframeEnabled) COLOR_CYAN else COLOR_TEXT_SECONDARY)
        ghostBtn?.text = if (ghostPassThrough) "● Ghost" else "Ghost"
        ghostBtn?.setTextColor(if (ghostPassThrough) COLOR_AMBER else COLOR_TEXT_SECONDARY)

        // Title
        titleText?.text = state.title

        // Question Banner
        if (state.question.isNotBlank()) {
            questionBannerText?.visibility = View.VISIBLE
            questionBannerText?.text = state.question
        } else {
            questionBannerText?.visibility = View.GONE
        }

        // Doing Now row + animated 3 bouncing dots
        if (state.currentAction.isNotBlank()) {
            doingRowContainer?.visibility = View.VISIBLE
            currentActionText?.text = state.currentAction
            doingDotsView?.setAnimating(isWorking && !isCollapsed)
        } else {
            doingRowContainer?.visibility = View.GONE
            doingDotsView?.setAnimating(false)
        }

        // Only show nextAction when task checklist isn't already displaying upcoming steps
        if (state.nextAction.isNotBlank() && state.tasks.isEmpty()) {
            nextActionText?.visibility = View.VISIBLE
            nextActionText?.text = "Next: ${state.nextAction}"
        } else {
            nextActionText?.visibility = View.GONE
        }

        // Airy Borderless Task List with Hybrid Per-Task App/Task Icons & Live Mini Spinner
        val listHost = taskListContainer
        if (listHost != null) {
            listHost.removeAllViews()
            if (state.tasks.isEmpty()) {
                taskScrollView?.visibility = View.GONE
            } else {
                taskScrollView?.visibility = View.VISIBLE
                val maxListHeightPx = (132 * d).toInt()
                taskScrollView?.layoutParams = (taskScrollView?.layoutParams as? LinearLayout.LayoutParams)?.apply {
                    height = if (state.tasks.size > 4) maxListHeightPx else ViewGroup.LayoutParams.WRAP_CONTENT
                }
                for (task in state.tasks) {
                    val (marker, color) = when (task.status) {
                        "done" -> "✓" to COLOR_EMERALD
                        "doing" -> "•" to COLOR_CYAN
                        "needs_input" -> "?" to COLOR_AMBER
                        else -> "○" to COLOR_TEXT_SECONDARY
                    }
                    val row = LinearLayout(context).apply {
                        orientation = LinearLayout.HORIZONTAL
                        gravity = Gravity.CENTER_VERTICAL
                        setPadding((6 * d).toInt(), (5 * d).toInt(), (6 * d).toInt(), (5 * d).toInt())
                        if (task.status == "doing" || task.status == "needs_input") {
                            background = createLiquidGlassDrawable(
                                fillColor = Color.argb(16, Color.red(color), Color.green(color), Color.blue(color)),
                                strokeColor = Color.TRANSPARENT,
                                radiusDp = 10f,
                                strokeDp = 0f
                            )
                        }
                        layoutParams = LinearLayout.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.WRAP_CONTENT
                        ).apply { bottomMargin = (2 * d).toInt() }
                    }

                    // Per-task real app icon or custom vector badge (YouTube, Chrome, Termux, etc.)
                    val taskIcon = AgyAppIconResolver.resolve(
                        context = context,
                        explicitIcon = task.icon,
                        explicitPackage = task.appPackage,
                        fallbackText = "${task.label} ${task.detail}"
                    )
                    val iconBadge = AgyIconBadgeView(context).apply {
                        val sz = (19 * d).toInt()
                        layoutParams = LinearLayout.LayoutParams(sz, sz).apply { marginEnd = (8 * d).toInt() }
                        setIcon(taskIcon)
                    }
                    row.addView(iconBadge)

                    val textCol = LinearLayout(context).apply {
                        orientation = LinearLayout.VERTICAL
                        layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                    }
                    val labelTv = TextView(context).apply {
                        text = task.label
                        textSize = 11.5f
                        setTypeface(
                            Typeface.SANS_SERIF,
                            if (task.status == "doing") Typeface.BOLD else Typeface.NORMAL
                        )
                        setTextColor(if (task.status == "done") COLOR_TEXT_SECONDARY else COLOR_TEXT_PRIMARY)
                        maxLines = 2
                        ellipsize = TextUtils.TruncateAt.END
                    }
                    textCol.addView(labelTv)
                    if (task.detail.isNotBlank()) {
                        val detailTv = TextView(context).apply {
                            text = task.detail
                            textSize = 9.5f
                            typeface = Typeface.MONOSPACE
                            setTextColor(COLOR_TEXT_SECONDARY)
                            maxLines = 1
                            ellipsize = TextUtils.TruncateAt.END
                        }
                        textCol.addView(detailTv)
                    }
                    row.addView(textCol)

                    // Trailing live status indicator (spinning ring when doing, crisp mark otherwise)
                    if (task.status == "doing" && isWorking && !isCollapsed) {
                        val taskSpinner = AgySpinnerRingView(context).apply {
                            val sz = (13 * d).toInt()
                            layoutParams = LinearLayout.LayoutParams(sz, sz).apply { marginStart = (6 * d).toInt() }
                            setAccentColor(COLOR_CYAN)
                            setAnimating(true)
                        }
                        row.addView(taskSpinner)
                    } else {
                        val statusTv = TextView(context).apply {
                            text = marker
                            textSize = 11f
                            setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
                            setTextColor(color)
                            layoutParams = LinearLayout.LayoutParams(
                                ViewGroup.LayoutParams.WRAP_CONTENT,
                                ViewGroup.LayoutParams.WRAP_CONTENT
                            ).apply { marginStart = (6 * d).toInt() }
                        }
                        row.addView(statusTv)
                    }

                    tagTreeForSelfExclusion(row, "task_${task.id}")
                    listHost.addView(row)
                }
            }
        }

        // Quiet Expandable Detailed Output Drawer
        val hasDetailedOutput = state.detailedOutput.isNotBlank() || state.outputLogs.isNotEmpty()
        if (hasDetailedOutput) {
            outputSectionContainer?.visibility = View.VISIBLE
            val logCount = state.outputLogs.size
            val suffix = if (logCount > 0) " · $logCount logs" else ""
            outputToggleHeaderText?.text = if (isOutputExpanded) {
                "Hide Output$suffix ▴"
            } else {
                "Output$suffix ▾"
            }
            outputDrawerContainer?.visibility = if (isOutputExpanded) View.VISIBLE else View.GONE
            if (isOutputExpanded) {
                outputBodyText?.text = getFullOutputCopyText(state)
            }
        } else {
            outputSectionContainer?.visibility = View.GONE
            outputDrawerContainer?.visibility = View.GONE
        }

        // Contextual Quick Action Chips Strip
        val quickHost = quickActionsContainer
        val chips = resolveQuickActions(state)
        if (quickHost != null) {
            quickHost.removeAllViews()
            if (chips.isEmpty()) {
                quickActionsScrollView?.visibility = View.GONE
            } else {
                quickActionsScrollView?.visibility = View.VISIBLE
                for ((idx, chip) in chips.withIndex()) {
                    val isStop = chip.actionType == "STOP"
                    val isPrimary = idx == 0 && !isStop
                    val chipTextColor = when {
                        isStop -> COLOR_CORAL
                        isPrimary -> COLOR_CYAN
                        else -> COLOR_TEXT_PRIMARY
                    }
                    val chipBg = when {
                        isStop -> Color.parseColor("#18E11D48")
                        isPrimary -> Color.parseColor("#180095F6")
                        else -> COLOR_INNER_CAPSULE
                    }
                    val chipBorder = when {
                        isStop -> Color.parseColor("#55E11D48")
                        isPrimary -> Color.parseColor("#550095F6")
                        else -> COLOR_HAIRLINE
                    }
                    val chipTv = TextView(context).apply {
                        text = chip.label
                        textSize = 10.5f
                        setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
                        setTextColor(chipTextColor)
                        setPadding((10 * d).toInt(), (5 * d).toInt(), (10 * d).toInt(), (5 * d).toInt())
                        background = createLiquidGlassDrawable(
                            fillColor = chipBg,
                            strokeColor = chipBorder,
                            radiusDp = 999f,
                            strokeDp = 0.8f
                        )
                        layoutParams = LinearLayout.LayoutParams(
                            ViewGroup.LayoutParams.WRAP_CONTENT,
                            ViewGroup.LayoutParams.WRAP_CONTENT
                        ).apply { marginEnd = (6 * d).toInt() }
                        contentDescription = "${HUD_NODE_TAG_PREFIX}quick_chip_$idx"
                        setOnClickListener { executeQuickAction(chip) }
                    }
                    quickHost.addView(chipTv)
                }
            }
        }

        // Low-Poly Mini Screen Wireframe (ONLY visible when screenWatch.active == true && wireframeEnabled)
        val showWireframe = state.screenWatch.active && wireframeEnabled
        wireframeView?.updateScreenWatch(state.screenWatch, wireframeEnabled)
        wireframeContainer?.visibility = if (showWireframe) View.VISIBLE else View.GONE
        if (showWireframe) {
            val zoneCount = state.screenWatch.zones.size
            val vecDesc = state.screenWatch.actionVector?.let { " • ${it.type}" } ?: ""
            val lbl = state.screenWatch.label.ifBlank { "Screen Watch" }
            wireframeLabelText?.text = "$lbl\n$zoneCount zones$vecDesc"
        }

        hudRootView?.let { root ->
            hudParams?.let { params ->
                try {
                    windowManager?.updateViewLayout(root, params)
                } catch (_: Exception) {}
            }
        }
    }

    fun executeQuickAction(chip: QuickActionChip) {
        when (chip.actionType.uppercase()) {
            "COPY_OUTPUT" -> copyDetailedOutputToClipboard()
            "TOGGLE_OUTPUT" -> setOutputExpanded(!isOutputExpanded)
            "STOP" -> {
                cancelAutoCollapse()
                enqueueAndBroadcastCommand(text = chip.commandText.ifBlank { "STOP" }, action = "STOP")
            }
            else -> {
                cancelAutoCollapse()
                val cmdText = chip.commandText.ifBlank { chip.label }
                if (cmdText.isNotBlank()) {
                    enqueueAndBroadcastCommand(text = cmdText, action = "PROMPT")
                }
            }
        }
    }

    // -------------------------------------------------------------------------
    // Window 1: Message & Command Input (`agy_input`) with Dynamic Focus Handoff
    // -------------------------------------------------------------------------

    private fun showInputWindowInternal(requestKeyboardFocus: Boolean) {
        val wm = windowManager ?: return
        if (inputRootView == null) {
            val d = density()
            val cardWidthPx = min((304 * d).toInt(), (context.resources.displayMetrics.widthPixels * 0.90f).toInt())

            val root = HoldDraggableDockLayout(context).apply {
                orientation = LinearLayout.VERTICAL
                setPadding((10 * d).toInt(), (8 * d).toInt(), (10 * d).toInt(), (9 * d).toInt())
                background = createLiquidGlassDrawable(
                    fillColor = COLOR_OBSIDIAN_GLASS,
                    strokeColor = COLOR_HAIRLINE,
                    radiusDp = 24f,
                    strokeDp = 1.0f
                )
                elevation = 12f * d
                onOutsideTouch = { releaseInputFocusToTermux() }
            }

            // Compact top drag handle & close row
            val topBar = LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { bottomMargin = (6 * d).toInt() }
            }

            val barLabel = TextView(context).apply {
                text = "✦ Message Agy"
                textSize = 10.5f
                typeface = Typeface.MONOSPACE
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(COLOR_CYAN)
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            }

            val pasteClear = TextView(context).apply {
                text = "Paste"
                textSize = 10f
                setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
                setTextColor(COLOR_TEXT_SECONDARY)
                setPadding((8 * d).toInt(), (3 * d).toInt(), (8 * d).toInt(), (3 * d).toInt())
                background = createLiquidGlassDrawable(
                    fillColor = COLOR_INNER_CAPSULE,
                    strokeColor = Color.parseColor("#33FFFFFF"),
                    radiusDp = 999f,
                    strokeDp = 0.7f
                )
                contentDescription = "${HUD_NODE_TAG_PREFIX}paste_clear_btn"
                setOnClickListener {
                    val et = inputEditText ?: return@setOnClickListener
                    if (et.text.isNullOrEmpty()) {
                        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
                        val clip = cm?.primaryClip?.getItemAt(0)?.coerceToText(context)?.toString()?.trim().orEmpty()
                        if (clip.isNotEmpty()) {
                            et.setText(clip)
                            et.setSelection(clip.length)
                        }
                    } else {
                        et.setText("")
                    }
                    updatePasteClearLabel()
                }
            }
            pasteClearBtn = pasteClear

            val closeBtn = TextView(context).apply {
                text = "✕"
                textSize = 11f
                gravity = Gravity.CENTER
                setTextColor(COLOR_TEXT_SECONDARY)
                val sz = (24 * d).toInt()
                layoutParams = LinearLayout.LayoutParams(sz, sz).apply { marginStart = (6 * d).toInt() }
                background = createLiquidGlassDrawable(
                    fillColor = COLOR_INNER_CAPSULE,
                    strokeColor = Color.parseColor("#33FFFFFF"),
                    radiusDp = 999f,
                    strokeDp = 0.7f
                )
                contentDescription = "${HUD_NODE_TAG_PREFIX}close_input_btn"
                setOnClickListener { hideInputWindowInternal() }
            }

            topBar.addView(barLabel)
            topBar.addView(pasteClear)
            topBar.addView(closeBtn)
            root.addView(topBar)

            // Full-Pill Input Row: EditText + Send + Stop
            val inputRow = LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                )
            }

            val editText = EditText(context).apply {
                hint = "Ask Agy or assign task..."
                setHintTextColor(Color.parseColor("#8094A3B8"))
                setTextColor(COLOR_TEXT_PRIMARY)
                textSize = 12.5f
                isSingleLine = true
                imeOptions = EditorInfo.IME_ACTION_SEND
                setPadding((14 * d).toInt(), (8 * d).toInt(), (14 * d).toInt(), (8 * d).toInt())
                background = createLiquidGlassDrawable(
                    fillColor = COLOR_PILL_INPUT_BG,
                    strokeColor = Color.parseColor("#6638BDF8"),
                    radiusDp = 999f,
                    strokeDp = 1f
                )
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                contentDescription = "${HUD_NODE_TAG_PREFIX}prompt_input"

                setOnTouchListener { _, ev ->
                    if (ev.action == MotionEvent.ACTION_UP || ev.action == MotionEvent.ACTION_DOWN) {
                        acquireInputFocusFromTermux()
                    }
                    false
                }

                setOnEditorActionListener { _, actionId, event ->
                    if (actionId == EditorInfo.IME_ACTION_SEND ||
                        (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER && event.action == KeyEvent.ACTION_DOWN)
                    ) {
                        submitPromptFromInput()
                        true
                    } else {
                        false
                    }
                }

                addTextChangedListener(object : android.text.TextWatcher {
                    override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                    override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                        updatePasteClearLabel()
                    }
                    override fun afterTextChanged(s: android.text.Editable?) {}
                })
            }
            inputEditText = editText

            val sendBtn = TextView(context).apply {
                text = "Send"
                textSize = 11.5f
                setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
                setTextColor(Color.WHITE)
                gravity = Gravity.CENTER
                setPadding((12 * d).toInt(), (8 * d).toInt(), (12 * d).toInt(), (8 * d).toInt())
                background = createLiquidGlassDrawable(
                    fillColor = COLOR_CYAN,
                    strokeColor = COLOR_CYAN,
                    radiusDp = 999f,
                    strokeDp = 0.8f
                )
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { marginStart = (6 * d).toInt() }
                contentDescription = "${HUD_NODE_TAG_PREFIX}send_btn"
                setOnClickListener { submitPromptFromInput() }
            }

            val stopBtn = TextView(context).apply {
                text = "■"
                textSize = 12f
                setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
                setTextColor(COLOR_CORAL)
                gravity = Gravity.CENTER
                val sz = (34 * d).toInt()
                layoutParams = LinearLayout.LayoutParams(sz, sz).apply { marginStart = (5 * d).toInt() }
                background = createLiquidGlassDrawable(
                    fillColor = Color.parseColor("#2EE11D48"),
                    strokeColor = COLOR_CORAL,
                    radiusDp = 999f,
                    strokeDp = 1f
                )
                contentDescription = "${HUD_NODE_TAG_PREFIX}stop_btn"
                setOnClickListener {
                    enqueueAndBroadcastCommand(text = "STOP", action = "STOP")
                    releaseInputFocusToTermux()
                }
            }

            inputRow.addView(editText)
            inputRow.addView(sendBtn)
            inputRow.addView(stopBtn)
            root.addView(inputRow)
            tagTreeForSelfExclusion(root, "window1")

            // Position anchored BOTTOM_RIGHT cleanly above the unified dock (never covering Working Window or Bottom Chat Pill)
            val baseHudX = hudParams?.x ?: (14 * d).toInt()
            val baseHudY = hudParams?.y ?: (28 * d).toInt()
            val screenH = context.resources.displayMetrics.heightPixels.coerceAtLeast(1200)
            val measuredDockH = hudRootView?.height?.takeIf { it > 0 }
                ?: if (isCollapsed) (52 * d).toInt() else (230 * d).toInt()
            val targetY = (baseHudY + measuredDockH + (10 * d).toInt())
                .coerceIn((64 * d).toInt(), (screenH - (140 * d).toInt()).coerceAtLeast((64 * d).toInt()))
            val params = WindowManager.LayoutParams(
                cardWidthPx,
                WindowManager.LayoutParams.WRAP_CONTENT,
                overlayWindowType(),
                // Start with FLAG_NOT_FOCUSABLE so Termux keeps keyboard focus until user taps EditText!
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.BOTTOM or Gravity.END
                x = baseHudX
                y = targetY
                softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
            }

            inputRootView = root
            inputParams = params
            isInputFocused = false

            root.onDragDelta = { dx, dy ->
                shiftBottomRightWindow(root, params, dx, dy)
            }

            try {
                wm.addView(root, params)
                _isInputVisible.value = true
                root.alpha = OPACITY_LEVELS[opacityIndex]
            } catch (e: Exception) {
                Log.e(TAG, "Failed adding agy_input window: ${e.message}")
                inputRootView = null
                inputParams = null
                _isInputVisible.value = false
                return
            }
        }

        if (requestKeyboardFocus) {
            mainHandler.postDelayed({ acquireInputFocusFromTermux() }, 60L)
        }
    }

    private fun acquireInputFocusFromTermux() {
        val root = inputRootView ?: return
        val params = inputParams ?: return
        val et = inputEditText ?: return
        if (!isInputFocused) {
            params.flags = (params.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE.inv()) or
                WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
            isInputFocused = true
            try {
                windowManager?.updateViewLayout(root, params)
            } catch (e: Exception) {
                Log.w(TAG, "Failed updating focusable layout for agy_input: ${e.message}")
            }
        }
        et.isFocusable = true
        et.isFocusableInTouchMode = true
        et.requestFocus()
        et.post {
            try {
                inputMethodManager?.showSoftInput(et, InputMethodManager.SHOW_IMPLICIT)
            } catch (_: Exception) {}
        }
    }

    private fun releaseInputFocusToTermux() {
        val root = inputRootView ?: return
        val params = inputParams ?: return
        val et = inputEditText
        try {
            if (et != null) {
                inputMethodManager?.hideSoftInputFromWindow(et.windowToken, 0)
                et.clearFocus()
            }
        } catch (_: Exception) {}

        if (isInputFocused || (params.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE) == 0) {
            params.flags = params.flags or
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH
            isInputFocused = false
            try {
                windowManager?.updateViewLayout(root, params)
            } catch (_: Exception) {}
        }
    }

    private fun submitPromptFromInput() {
        val et = inputEditText ?: return
        val text = et.text?.toString()?.trim().orEmpty()
        if (text.isNotEmpty()) {
            enqueueAndBroadcastCommand(text = text, action = "PROMPT")
            et.setText("")
            updatePasteClearLabel()
            isCollapsed = false
            renderHudWindow()
        }
        releaseInputFocusToTermux()
    }

    private fun hideInputWindowInternal() {
        releaseInputFocusToTermux()
        inputRootView?.let { view ->
            try {
                windowManager?.removeView(view)
            } catch (e: Exception) {
                Log.w(TAG, "Error removing agy_input: ${e.message}")
            }
        }
        inputRootView = null
        inputParams = null
        inputEditText = null
        pasteClearBtn = null
        isInputFocused = false
        _isInputVisible.value = false
    }

    private fun updatePasteClearLabel() {
        val isEmpty = inputEditText?.text.isNullOrEmpty()
        pasteClearBtn?.text = if (isEmpty) "Paste" else "Clear"
    }

    // -------------------------------------------------------------------------
    // Ghost Pass-Through, Opacity, Timers & Pulse Helpers
    // -------------------------------------------------------------------------

    private fun cycleOpacityInternal() {
        opacityIndex = (opacityIndex + 1) % OPACITY_LEVELS.size
        renderHudWindow()
    }

    private fun setGhostModeInternal(enabled: Boolean) {
        ghostPassThrough = enabled
        applyTouchableFlagsInternal(touchable = !enabled && !temporaryPassThroughActive)
        if (enabled) {
            showGhostRestorePillInternal()
        } else {
            hideGhostRestorePillInternal()
        }
        renderHudWindow()
    }

    private fun showGhostRestorePillInternal() {
        if (ghostRestoreView != null) return
        val wm = windowManager ?: return
        val d = density()
        val restoreBtn = TextView(context).apply {
            text = "👻 Un-Ghost"
            textSize = 10f
            setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
            setTextColor(COLOR_AMBER)
            setPadding((10 * d).toInt(), (5 * d).toInt(), (10 * d).toInt(), (5 * d).toInt())
            background = createLiquidGlassDrawable(
                fillColor = COLOR_OBSIDIAN_GLASS,
                strokeColor = COLOR_AMBER,
                radiusDp = 999f,
                strokeDp = 1f
            )
            setOnClickListener { setGhostModeInternal(false) }
        }
        tagTreeForSelfExclusion(restoreBtn, "ghost_restore")
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayWindowType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.END
            x = (14 * d).toInt()
            y = ((hudParams?.y ?: (28 * d).toInt()) + (235 * d).toInt())
        }
        ghostRestoreView = restoreBtn
        ghostRestoreParams = params
        try {
            wm.addView(restoreBtn, params)
        } catch (_: Exception) {
            ghostRestoreView = null
            ghostRestoreParams = null
        }
    }

    private fun hideGhostRestorePillInternal() {
        ghostRestoreView?.let { v ->
            try {
                windowManager?.removeView(v)
            } catch (_: Exception) {}
        }
        ghostRestoreView = null
        ghostRestoreParams = null
    }

    private fun applyTouchableFlagsInternal(touchable: Boolean) {
        fun updateWindow(view: View?, params: WindowManager.LayoutParams?) {
            if (view == null || params == null) return
            params.flags = if (touchable) {
                params.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
            } else {
                params.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
            }
            try {
                windowManager?.updateViewLayout(view, params)
            } catch (_: Exception) {}
        }
        updateWindow(hudRootView, hudParams)
        updateWindow(inputRootView, inputParams)
    }

    private fun scheduleAutoCollapse(seconds: Int) {
        cancelAutoCollapse()
        val task = Runnable {
            isCollapsed = true
            hideInputWindowInternal()
            if (hudRootView != null) {
                renderHudWindow()
            }
        }
        autoCollapseRunnable = task
        mainHandler.postDelayed(task, seconds * 1000L)
    }

    private fun cancelAutoCollapse() {
        autoCollapseRunnable?.let { mainHandler.removeCallbacks(it) }
        autoCollapseRunnable = null
    }

    private fun syncPulseAnimation() {
        val state = _hudState.value.state
        val shouldPulse = _isHudVisible.value && (state == "WORKING" || state == "NEEDS_INPUT")
        if (shouldPulse && pulseRunnable == null) {
            val runner = object : Runnable {
                override fun run() {
                    if (!_isHudVisible.value) {
                        stopPulseAnimation()
                        return
                    }
                    pulseToggle = !pulseToggle
                    statusDotView?.alpha = if (pulseToggle) 1.0f else 0.35f
                    if (_hudState.value.state == "NEEDS_INPUT") {
                        questionBannerText?.alpha = if (pulseToggle) 1.0f else 0.72f
                    } else {
                        questionBannerText?.alpha = 1.0f
                    }
                    mainHandler.postDelayed(this, 650L)
                }
            }
            pulseRunnable = runner
            mainHandler.postDelayed(runner, 650L)
        } else if (!shouldPulse) {
            stopPulseAnimation()
        }
    }

    private fun stopPulseAnimation() {
        pulseRunnable?.let { mainHandler.removeCallbacks(it) }
        pulseRunnable = null
        statusDotView?.alpha = 1.0f
        questionBannerText?.alpha = 1.0f
    }

    private fun startElapsedTimer() {
        stopElapsedTimer()
        val ticker = object : Runnable {
            override fun run() {
                if (_hudState.value.state != "WORKING") {
                    stopElapsedTimer()
                    return
                }
                if (workStartedAtMs > 0L) {
                    _elapsedMsFlow.value = (System.currentTimeMillis() - workStartedAtMs).coerceAtLeast(0L)
                    updateElapsedTimerDisplay()
                }
                mainHandler.postDelayed(this, 100L)
            }
        }
        elapsedTimerRunnable = ticker
        mainHandler.postDelayed(ticker, 100L)
    }

    private fun stopElapsedTimer() {
        elapsedTimerRunnable?.let { mainHandler.removeCallbacks(it) }
        elapsedTimerRunnable = null
    }

    private fun updateElapsedTimerDisplay() {
        val st = _hudState.value.state
        val elapsed = _elapsedMsFlow.value
        elapsedTimerText?.let { tv ->
            when {
                st == "WORKING" -> {
                    tv.visibility = View.VISIBLE
                    tv.text = "· ${formatElapsed(elapsed, isDone = false)}"
                    tv.setTextColor(COLOR_TEXT_SECONDARY)
                }
                st == "DONE" && elapsed > 0L -> {
                    tv.visibility = View.VISIBLE
                    tv.text = "· ${formatElapsed(elapsed, isDone = true).removePrefix("Done ")}"
                    tv.setTextColor(COLOR_EMERALD)
                }
                st == "NEEDS_INPUT" && elapsed > 0L -> {
                    tv.visibility = View.VISIBLE
                    tv.text = "· ${formatElapsed(elapsed, isDone = false)}"
                    tv.setTextColor(COLOR_AMBER)
                }
                else -> {
                    tv.visibility = View.GONE
                }
            }
        }
        dockLiveTimerText?.let { liveTv ->
            if (st == "WORKING") {
                liveTv.text = formatElapsed(elapsed, isDone = false)
            }
        }
    }

    // -------------------------------------------------------------------------
    // Utility Helpers
    // -------------------------------------------------------------------------

    private fun shiftBottomRightWindow(
        root: View,
        params: WindowManager.LayoutParams,
        dx: Float,
        dy: Float
    ) {
        val screenW = context.resources.displayMetrics.widthPixels
        val screenH = context.resources.displayMetrics.heightPixels
        val viewW = root.width.takeIf { it > 0 } ?: (120 * density()).toInt()
        val viewH = root.height.takeIf { it > 0 } ?: (56 * density()).toInt()
        // Anchored BOTTOM | END: dragging left increases x, dragging up increases y
        params.x = (params.x - dx.toInt()).coerceIn(0, (screenW - viewW).coerceAtLeast(0))
        params.y = (params.y - dy.toInt()).coerceIn(0, (screenH - viewH).coerceAtLeast(0))
        try {
            windowManager?.updateViewLayout(root, params)
        } catch (_: Exception) {}
    }

    private fun createLiquidGlassDrawable(
        fillColor: Int,
        strokeColor: Int,
        radiusDp: Float,
        strokeDp: Float = 1.2f
    ): GradientDrawable {
        val d = density()
        return GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = radiusDp * d
            setColor(fillColor)
            setStroke((strokeDp * d).toInt().coerceAtLeast(1), strokeColor)
        }
    }

    private fun tagTreeForSelfExclusion(view: View, suffix: String) {
        val existing = view.contentDescription?.toString()
        if (existing.isNullOrBlank() || !existing.startsWith(HUD_NODE_TAG_PREFIX)) {
            view.contentDescription = "$HUD_NODE_TAG_PREFIX$suffix"
        }
        view.tag = "$HUD_NODE_TAG_PREFIX$suffix"
        if (view is ViewGroup) {
            for (i in 0 until view.childCount) {
                tagTreeForSelfExclusion(view.getChildAt(i), "${suffix}_$i")
            }
        }
    }

    private fun overlayWindowType(): Int {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }
    }

    private fun density(): Float = context.resources.displayMetrics.density.coerceAtLeast(1f)

    private fun runOnMain(block: () -> Unit) {
        if (Looper.myLooper() == Looper.getMainLooper()) {
            block()
        } else {
            mainHandler.post(block)
        }
    }
}
