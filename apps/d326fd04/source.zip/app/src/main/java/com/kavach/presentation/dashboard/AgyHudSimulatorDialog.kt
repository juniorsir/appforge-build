package com.kavach.presentation.dashboard

import android.graphics.Rect
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.KeyboardArrowUp
import androidx.compose.material.icons.rounded.Layers
import androidx.compose.material.icons.rounded.OpenWith
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material.icons.rounded.TouchApp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.LayoutCoordinates
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.kavach.accessibility.AccessibilityRepositoryImpl
import com.kavach.ui.overlay.AgyAppIconResolver
import com.kavach.ui.overlay.AgyHudOverlayManager
import com.kavach.ui.theme.CrispAmber
import com.kavach.ui.theme.CrispBg
import com.kavach.ui.theme.CrispBlue
import com.kavach.ui.theme.CrispBorder
import com.kavach.ui.theme.CrispEmerald
import com.kavach.ui.theme.CrispHairline
import com.kavach.ui.theme.CrispIndigo
import com.kavach.ui.theme.CrispInkMuted
import com.kavach.ui.theme.CrispInkPrimary
import com.kavach.ui.theme.CrispInkSecondary
import com.kavach.ui.theme.CrispRose
import com.kavach.ui.theme.CrispSurface
import com.kavach.ui.theme.CrispSurfaceSubtle
import com.kavach.ui.theme.JetBrainsMonoFamily
import com.kavach.ui.theme.LiquidIconOrb
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

/**
 * Full Interactive Agy HUD Test Mode Simulator.
 * Drives the real AgyHudOverlayManager (floating overlay + /api/hud endpoints & command queue)
 * while mirroring live Window 2 (Task + Low-Poly Wireframe / Collapsed Pill) & Window 1 (Prompt)
 * inside a clean Crisp Light Mode sandbox so every feature can be tested without Termux running.
 */
@Composable
fun AgyHudSimulatorDialog(
    hudManager: AgyHudOverlayManager,
    onDismissRequest: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val hudState by hudManager.hudState.collectAsState()
    val isHudVisible by hudManager.isHudVisible.collectAsState()
    val isInputVisible by hudManager.isInputVisible.collectAsState()
    val isCollapsed by hudManager.isCollapsedFlow.collectAsState()
    val isOutputExpanded by hudManager.isOutputExpandedFlow.collectAsState()
    val elapsedMs by hudManager.elapsedMsFlow.collectAsState()
    val opacity by hudManager.opacityFlow.collectAsState()
    val ghostPassThrough by hudManager.ghostPassThroughFlow.collectAsState()
    val wireframeEnabled by hudManager.wireframeEnabledFlow.collectAsState()

    var isAutoPlaying by remember { mutableStateOf(false) }
    var activeFlowStep by remember { mutableStateOf("Ready to simulate Agy lifecycle") }
    var autoPlayJob by remember { mutableStateOf<Job?>(null) }
    var simulatedTurnJob by remember { mutableStateOf<Job?>(null) }
    var sandboxPrompt by remember { mutableStateOf("") }
    var hasOverlayPerm by remember { mutableStateOf(hudManager.hasOverlayPermission()) }
    var dockOffsetX by remember { mutableFloatStateOf(0f) }
    var dockOffsetY by remember { mutableFloatStateOf(0f) }
    var isDraggingDock by remember { mutableStateOf(false) }
    var showDiagnostics by remember { mutableStateOf(false) }
    val haptic = LocalHapticFeedback.current

    val echoLogs = remember { mutableStateListOf<String>() }
    val timeFmt = remember { SimpleDateFormat("HH:mm:ss", Locale.US) }

    fun addLog(msg: String) {
        val ts = timeFmt.format(Date())
        echoLogs.add(0, "[$ts] $msg")
        if (echoLogs.size > 30) echoLogs.removeAt(echoLogs.lastIndex)
    }

    fun pushStatePayload(label: String, json: JSONObject) {
        hasOverlayPerm = hudManager.hasOverlayPermission()
        val res = hudManager.updateState(json)
        activeFlowStep = label
        val overlayTag = if (res.optBoolean("overlayRendered")) "real HUD + sandbox" else "sandbox preview"
        addLog("STATE -> ${json.optString("state")} ($overlayTag)")
    }

    fun runSimulatedPromptTurn(promptText: String) {
        simulatedTurnJob?.cancel()
        simulatedTurnJob = scope.launch {
            pushStatePayload(
                "Simulating prompt: $promptText",
                buildWorkingPayload(promptText)
            )
            delay(1600L)
            pushStatePayload(
                "Screen Watch: Inspecting UI & targeting button",
                buildTapWatchPayload(promptText)
            )
            delay(1900L)
            pushStatePayload(
                "Task Complete — auto-collapsing in 4s",
                buildDonePayload("Finished: ${promptText.take(36)}")
            )
        }
    }

    // Live command echo loop: drains real HUD_COMMAND items submitted via Window 1 or Simulator bar
    LaunchedEffect(hudManager) {
        addLog("Simulator ready. Tap 'Play Full Flow' or type a prompt below.")
        while (isActive) {
            val pollRes = hudManager.pollCommands()
            val count = pollRes.optInt("count", 0)
            if (count > 0) {
                val arr = pollRes.optJSONArray("commands") ?: JSONArray()
                for (i in 0 until arr.length()) {
                    val cmd = arr.optJSONObject(i) ?: continue
                    val action = cmd.optString("action", "PROMPT")
                    val text = cmd.optString("text", "")
                    addLog("HUD_COMMAND [$action]: \"$text\"")
                    if (action == "STOP") {
                        autoPlayJob?.cancel()
                        simulatedTurnJob?.cancel()
                        isAutoPlaying = false
                        pushStatePayload("Stopped by user", buildIdlePayload("Stopped by user"))
                    } else if (text.isNotBlank()) {
                        autoPlayJob?.cancel()
                        isAutoPlaying = false
                        runSimulatedPromptTurn(text)
                    }
                }
            }
            delay(300L)
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            autoPlayJob?.cancel()
            simulatedTurnJob?.cancel()
        }
    }

    Dialog(
        onDismissRequest = onDismissRequest,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            color = CrispSurface,
            shape = RoundedCornerShape(28.dp),
            border = BorderStroke(1.dp, CrispHairline),
            shadowElevation = 6.dp,
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .heightIn(max = 780.dp)
                .testTag("agy_hud_simulator_dialog")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
                    .verticalScroll(rememberScrollState(), enabled = !isDraggingDock),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        LiquidIconOrb(
                            icon = Icons.Rounded.AutoAwesome,
                            tint = CrispBlue,
                            size = 38.dp,
                            iconSize = 20.dp
                        )
                        Column {
                            Text(
                                text = "Agy HUD Simulator",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = CrispInkPrimary
                            )
                            Text(
                                text = activeFlowStep,
                                style = MaterialTheme.typography.labelSmall,
                                color = CrispInkSecondary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                    IconButton(
                        onClick = onDismissRequest,
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(CrispSurfaceSubtle)
                            .testTag("close_hud_simulator_button")
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Close,
                            contentDescription = "Close Simulator",
                            tint = CrispInkSecondary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                // Real Overlay Permission Banner
                if (!hasOverlayPerm) {
                    Surface(
                        color = CrispAmber.copy(alpha = 0.08f),
                        shape = RoundedCornerShape(16.dp),
                        border = BorderStroke(1.dp, CrispAmber.copy(alpha = 0.25f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Sandbox live. Grant overlay permission to float over Termux.",
                                style = MaterialTheme.typography.labelSmall,
                                color = CrispAmber,
                                modifier = Modifier.weight(1f)
                            )
                            Spacer(Modifier.width(8.dp))
                            Surface(
                                color = CrispAmber,
                                shape = RoundedCornerShape(50),
                                modifier = Modifier
                                    .clip(RoundedCornerShape(50))
                                    .clickable {
                                        hudManager.getOverlayPermissionIntent()?.let { intent ->
                                            try {
                                                context.startActivity(intent)
                                            } catch (_: Exception) {}
                                        }
                                    }
                            ) {
                                Text(
                                    text = "Grant",
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                    color = Color.White,
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp)
                                )
                            }
                        }
                    }
                }

                // 1. Calm Minimalist Interactive Hold-to-Drag Stage
                Surface(
                    color = Color(0xFFF6F7F9),
                    shape = RoundedCornerShape(22.dp),
                    border = BorderStroke(0.85.dp, Color(0xFFE8ECF1)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("simulator_live_preview_box")
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.OpenWith,
                                    contentDescription = null,
                                    tint = if (isDraggingDock) CrispBlue else CrispInkMuted,
                                    modifier = Modifier.size(13.dp)
                                )
                                Text(
                                    text = if (isDraggingDock) "Moving dock…" else "Hold HUD to drag",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontWeight = FontWeight.Medium,
                                        fontSize = 11.sp
                                    ),
                                    color = if (isDraggingDock) CrispBlue else CrispInkSecondary
                                )
                            }
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                if (dockOffsetX != 0f || dockOffsetY != 0f) {
                                    Text(
                                        text = "Reset",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontWeight = FontWeight.SemiBold,
                                            fontSize = 10.5.sp
                                        ),
                                        color = CrispBlue,
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(50))
                                            .background(CrispBlue.copy(alpha = 0.09f))
                                            .clickable {
                                                dockOffsetX = 0f
                                                dockOffsetY = 0f
                                            }
                                            .padding(horizontal = 9.dp, vertical = 3.dp)
                                            .testTag("simulator_reset_pos_button")
                                    )
                                }
                                Text(
                                    text = if (ghostPassThrough) "Ghost" else if (isHudVisible) "Live overlay" else "Preview",
                                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.5.sp),
                                    color = CrispInkMuted
                                )
                            }
                        }

                        // Spacious clean alabaster stage simulating Android viewport
                        BoxWithConstraints(
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(min = 272.dp)
                                .clip(RoundedCornerShape(18.dp))
                                .background(Color(0xFFEDF0F4))
                        ) {
                            val density = LocalDensity.current
                            val holdSlopPx = with(density) { 16.dp.toPx() }
                            var stageSize by remember { mutableStateOf(IntSize.Zero) }
                            var dockSize by remember { mutableStateOf(IntSize.Zero) }
                            var dockCoords by remember { mutableStateOf<LayoutCoordinates?>(null) }
                            val dragScale by animateFloatAsState(
                                targetValue = if (isDraggingDock) 1.03f else 1f,
                                animationSpec = tween(durationMillis = 120),
                                label = "dock_drag_scale"
                            )

                            // Whisper-subtle micro-dot canvas so drag motion feels crisp
                            Canvas(
                                modifier = Modifier
                                    .matchParentSize()
                                    .onSizeChanged { stageSize = it }
                            ) {
                                val step = 22.dp.toPx()
                                val dotColor = Color(0xFFCBD5E1).copy(alpha = 0.45f)
                                var y = step * 0.6f
                                while (y < size.height) {
                                    var x = step * 0.6f
                                    while (x < size.width) {
                                        drawCircle(color = dotColor, radius = 1.dp.toPx(), center = Offset(x, y))
                                        x += step
                                    }
                                    y += step
                                }
                            }

                            Box(
                                modifier = Modifier
                                    .align(Alignment.BottomEnd)
                                    .padding(10.dp)
                                    .offset { IntOffset(dockOffsetX.roundToInt(), dockOffsetY.roundToInt()) }
                                    .graphicsLayer {
                                        scaleX = dragScale
                                        scaleY = dragScale
                                    }
                                    .onGloballyPositioned { coords ->
                                        dockCoords = coords
                                        dockSize = coords.size
                                    }
                                    .pointerInput(holdSlopPx) {
                                        awaitEachGesture {
                                            // Wait for initial DOWN without consuming so quick taps hit child buttons
                                            var downChange = awaitPointerEvent(PointerEventPass.Initial)
                                                .changes
                                                .firstOrNull { it.pressed && !it.previousPressed }
                                                ?: return@awaitEachGesture
                                            val pointerId = downChange.id
                                            val downWinPos = dockCoords?.localToWindow(downChange.position) ?: downChange.position
                                            var holdActivated = false
                                            var cancelledEarly = false

                                            // 180ms press-and-hold window (matches HoldDraggableDockLayout)
                                            withTimeoutOrNull(180L) {
                                                while (true) {
                                                    val ev = awaitPointerEvent(PointerEventPass.Initial)
                                                    val ch = ev.changes.firstOrNull { it.id == pointerId } ?: break
                                                    if (!ch.pressed) {
                                                        cancelledEarly = true
                                                        break
                                                    }
                                                    val curWin = dockCoords?.localToWindow(ch.position) ?: ch.position
                                                    if ((curWin - downWinPos).getDistance() > holdSlopPx) {
                                                        cancelledEarly = true
                                                        break
                                                    }
                                                    downChange = ch
                                                }
                                            }

                                            if (!cancelledEarly && downChange.pressed) {
                                                holdActivated = true
                                                isDraggingDock = true
                                                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                                var lastWinPos = dockCoords?.localToWindow(downChange.position) ?: downWinPos
                                                try {
                                                    while (true) {
                                                        val ev = awaitPointerEvent(PointerEventPass.Initial)
                                                        val ch = ev.changes.firstOrNull { it.id == pointerId } ?: break
                                                        ch.consume()
                                                        if (!ch.pressed) break
                                                        val curWin = dockCoords?.localToWindow(ch.position) ?: lastWinPos
                                                        val delta = curWin - lastWinPos
                                                        lastWinPos = curWin
                                                        if (delta.x != 0f || delta.y != 0f) {
                                                            val padPx = (20f * density.density)
                                                            val maxLeft = (stageSize.width - dockSize.width - padPx).coerceAtLeast(0f)
                                                            val maxUp = (stageSize.height - dockSize.height - padPx).coerceAtLeast(0f)
                                                            dockOffsetX = (dockOffsetX + delta.x).coerceIn(-maxLeft, 0f)
                                                            dockOffsetY = (dockOffsetY + delta.y).coerceIn(-maxUp, 0f)
                                                        }
                                                    }
                                                } finally {
                                                    if (holdActivated) {
                                                        isDraggingDock = false
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    .testTag("simulator_draggable_hud_dock")
                            ) {
                                // Unified Dock: Collapsible Working Window ABOVE Dynamic Bottom Pill Dock
                                SandboxWindow2Preview(
                                    state = hudState,
                                    isCollapsed = isCollapsed,
                                    isOutputExpanded = isOutputExpanded,
                                    elapsedMs = elapsedMs,
                                    opacity = opacity,
                                    ghostPassThrough = ghostPassThrough,
                                    wireframeEnabled = wireframeEnabled,
                                    collapsedRunningStep = hudManager.resolveCollapsedRunningStep(hudState),
                                    quickActions = hudManager.resolveQuickActions(hudState),
                                    formatElapsed = { ms, done -> hudManager.formatElapsed(ms, done) },
                                    fullOutputText = hudManager.getFullOutputCopyText(hudState),
                                    onCycleOpacity = {
                                        hudManager.handleRemoteCommand(JSONObject().put("action", "CYCLE_OPACITY"))
                                        addLog("OPACITY -> ${(hudManager.opacityFlow.value * 100).toInt()}%")
                                    },
                                    onToggleWireframe = {
                                        hudManager.handleRemoteCommand(JSONObject().put("action", "TOGGLE_WIREFRAME"))
                                    },
                                    onToggleGhost = {
                                        hudManager.handleRemoteCommand(JSONObject().put("action", "TOGGLE_GHOST"))
                                        addLog("GHOST PASS-THROUGH -> ${!ghostPassThrough}")
                                    },
                                    onToggleInput = {
                                        val nextAction = if (isInputVisible) "CLOSE_INPUT" else "OPEN_INPUT"
                                        hudManager.handleRemoteCommand(JSONObject().put("action", nextAction))
                                    },
                                    onToggleCollapse = {
                                        val nextAction = if (isCollapsed) "EXPAND" else "COLLAPSE"
                                        hudManager.handleRemoteCommand(JSONObject().put("action", nextAction))
                                    },
                                    onToggleOutput = {
                                        hudManager.setOutputExpanded(!isOutputExpanded)
                                        addLog("OUTPUT DRAWER -> ${if (!isOutputExpanded) "EXPANDED" else "COLLAPSED"}")
                                    },
                                    onCopyOutput = {
                                        val ok = hudManager.copyDetailedOutputToClipboard()
                                        addLog(if (ok) "CLIPBOARD -> Copied detailed output ✓" else "CLIPBOARD -> Nothing to copy")
                                        ok
                                    },
                                    onQuickAction = { chip ->
                                        hudManager.executeQuickAction(chip)
                                        addLog("QUICK ACTION -> ${chip.label} (${chip.actionType})")
                                    },
                                    onStop = {
                                        hudManager.enqueueAndBroadcastCommand("STOP", "STOP")
                                    }
                                )
                            }
                        }

                        // Synchronized Window 1 Preview (Prompt + Send + Stop — opened by bottom Ask Agy Chat pill)
                        AnimatedVisibility(
                            visible = isInputVisible,
                            enter = fadeIn() + expandVertically(),
                            exit = fadeOut() + shrinkVertically()
                        ) {
                            Surface(
                                color = CrispSurface,
                                shape = RoundedCornerShape(20.dp),
                                border = BorderStroke(1.dp, CrispBorder),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 8.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    OutlinedTextField(
                                        value = sandboxPrompt,
                                        onValueChange = { sandboxPrompt = it },
                                        singleLine = true,
                                        placeholder = {
                                            Text(
                                                text = "Type test prompt for Agy...",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = CrispInkMuted
                                            )
                                        },
                                        textStyle = MaterialTheme.typography.bodySmall.copy(color = CrispInkPrimary),
                                        shape = RoundedCornerShape(50),
                                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                                        keyboardActions = KeyboardActions(
                                            onSend = {
                                                val txt = sandboxPrompt.trim()
                                                if (txt.isNotEmpty()) {
                                                    hudManager.enqueueAndBroadcastCommand(txt, "PROMPT")
                                                    sandboxPrompt = ""
                                                }
                                            }
                                        ),
                                        colors = OutlinedTextFieldDefaults.colors(
                                            focusedBorderColor = CrispBlue,
                                            unfocusedBorderColor = CrispHairline,
                                            focusedContainerColor = CrispSurfaceSubtle,
                                            unfocusedContainerColor = CrispSurfaceSubtle
                                        ),
                                        modifier = Modifier
                                            .weight(1f)
                                            .testTag("simulator_prompt_input")
                                    )

                                    Surface(
                                        color = CrispBlue,
                                        shape = CircleShape,
                                        modifier = Modifier
                                            .size(40.dp)
                                            .clip(CircleShape)
                                            .clickable {
                                                val txt = sandboxPrompt.trim().ifEmpty { "Check Wi-Fi & open Termux" }
                                                hudManager.enqueueAndBroadcastCommand(txt, "PROMPT")
                                                sandboxPrompt = ""
                                            }
                                            .testTag("simulator_send_button")
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Icon(
                                                imageVector = Icons.AutoMirrored.Rounded.Send,
                                                contentDescription = "Send Test Prompt",
                                                tint = Color.White,
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }
                                    }

                                    Surface(
                                        color = CrispRose.copy(alpha = 0.12f),
                                        shape = CircleShape,
                                        border = BorderStroke(1.dp, CrispRose.copy(alpha = 0.3f)),
                                        modifier = Modifier
                                            .size(40.dp)
                                            .clip(CircleShape)
                                            .clickable {
                                                hudManager.enqueueAndBroadcastCommand("STOP", "STOP")
                                            }
                                            .testTag("simulator_stop_button")
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Icon(
                                                imageVector = Icons.Rounded.Stop,
                                                contentDescription = "Stop Agy",
                                                tint = CrispRose,
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // 2. One-Tap Auto-Play Full Flow CTA
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = {
                            if (isAutoPlaying) {
                                autoPlayJob?.cancel()
                                isAutoPlaying = false
                                activeFlowStep = "Auto-play stopped"
                                addLog("DEMO stopped")
                            } else {
                                simulatedTurnJob?.cancel()
                                isAutoPlaying = true
                                autoPlayJob = scope.launch {
                                    try {
                                        pushStatePayload("Step 1/5: WORKING (Task Checklist)", buildWorkingPayload("Deploy Termux Script"))
                                        delay(2200L)
                                        pushStatePayload("Step 2/5: SCREEN WATCH (TAP Reticle)", buildTapWatchPayload("Deploy Termux Script"))
                                        delay(2600L)
                                        pushStatePayload("Step 3/5: SCREEN WATCH (SWIPE Vector)", buildSwipeWatchPayload("Deploy Termux Script"))
                                        delay(2600L)
                                        pushStatePayload("Step 4/5: NEEDS_INPUT (Auto-Opens Window 1)", buildNeedsInputPayload())
                                        delay(2600L)
                                        pushStatePayload("Step 5/5: DONE (Auto-Collapses in 4s)", buildDonePayload("All tasks verified & deployed"))
                                        delay(4300L)
                                        activeFlowStep = "Completed — Collapsed to bottom-right pill"
                                        addLog("Auto-collapsed to compact bottom-right pill")
                                    } finally {
                                        isAutoPlaying = false
                                    }
                                }
                            }
                        },
                        shape = RoundedCornerShape(50),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isAutoPlaying) CrispRose else CrispBlue,
                            contentColor = Color.White
                        ),
                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 10.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(44.dp)
                            .testTag("simulator_autoplay_button")
                    ) {
                        Icon(
                            imageVector = if (isAutoPlaying) Icons.Rounded.Stop else Icons.Rounded.PlayArrow,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(Modifier.width(6.dp))
                        Text(
                            text = if (isAutoPlaying) "Stop Demo" else "Play Full Flow",
                            style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold)
                        )
                    }

                    Surface(
                        color = CrispSurfaceSubtle,
                        shape = RoundedCornerShape(50),
                        border = BorderStroke(1.dp, CrispHairline),
                        modifier = Modifier
                            .height(44.dp)
                            .clip(RoundedCornerShape(50))
                            .clickable {
                                autoPlayJob?.cancel()
                                simulatedTurnJob?.cancel()
                                isAutoPlaying = false
                                hudManager.hideAll()
                                activeFlowStep = "HUD hidden cleanly"
                                addLog("POST /api/hud/hide -> dismissed both windows")
                            }
                            .testTag("simulator_hide_button")
                    ) {
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier.padding(horizontal = 16.dp)
                        ) {
                            Text(
                                text = "Hide",
                                style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.SemiBold),
                                color = CrispInkSecondary
                            )
                        }
                    }
                }

                // 3. Clean Single-Row State Switcher
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Preview states",
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold),
                        color = CrispInkSecondary
                    )
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        SimChip("Working", CrispBlue, "sim_trigger_working") {
                            pushStatePayload("Working · YouTube + Termux", buildWorkingPayload("Play Lo-Fi on YouTube"))
                        }
                        SimChip("Tap Watch", CrispBlue, "sim_trigger_tap") {
                            pushStatePayload("Screen Watch · YouTube tap", buildTapWatchPayload("Search & Play on YouTube"))
                        }
                        SimChip("Swipe Watch", CrispIndigo, "sim_trigger_swipe") {
                            pushStatePayload("Screen Watch · Chrome + WhatsApp", buildSwipeWatchPayload("Share Link to WhatsApp"))
                        }
                        SimChip("Needs Input", CrispAmber, "sim_trigger_input") {
                            pushStatePayload("Needs input · Quick reply", buildNeedsInputPayload())
                        }
                        SimChip("Done", CrispEmerald, "sim_trigger_done") {
                            pushStatePayload("Done · Output ready", buildDonePayload("YouTube stream live & summary copied"))
                        }
                        SimChip("Output", CrispInkPrimary, "sim_cmd_output") {
                            hudManager.setOutputExpanded(!isOutputExpanded)
                            addLog("CMD -> TOGGLE_OUTPUT (${!isOutputExpanded})")
                        }
                    }
                }

                // 4. Collapsible Diagnostics, Controls & Command Echo
                Surface(
                    color = Color(0xFFF6F7F9),
                    shape = RoundedCornerShape(18.dp),
                    border = BorderStroke(0.85.dp, Color(0xFFE8ECF1)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { showDiagnostics = !showDiagnostics }
                                .padding(horizontal = 14.dp, vertical = 11.dp)
                                .testTag("simulator_diagnostics_toggle"),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Text(
                                    text = "Diagnostics & Echo",
                                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold),
                                    color = CrispInkPrimary
                                )
                                if (echoLogs.isNotEmpty()) {
                                    Surface(
                                        color = Color.White,
                                        shape = RoundedCornerShape(50),
                                        border = BorderStroke(0.75.dp, CrispHairline)
                                    ) {
                                        Text(
                                            text = "${echoLogs.size}",
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                fontFamily = JetBrainsMonoFamily,
                                                fontSize = 10.sp
                                            ),
                                            color = CrispInkSecondary,
                                            modifier = Modifier.padding(horizontal = 7.dp, vertical = 1.dp)
                                        )
                                    }
                                }
                            }
                            Icon(
                                imageVector = if (showDiagnostics) Icons.Rounded.KeyboardArrowUp else Icons.Rounded.KeyboardArrowDown,
                                contentDescription = "Toggle Diagnostics",
                                tint = CrispInkSecondary,
                                modifier = Modifier.size(18.dp)
                            )
                        }

                        AnimatedVisibility(
                            visible = showDiagnostics,
                            enter = fadeIn() + expandVertically(),
                            exit = fadeOut() + shrinkVertically()
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(start = 12.dp, end = 12.dp, bottom = 12.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                HorizontalDivider(color = Color(0xFFE8ECF1), thickness = 0.75.dp)

                                // Remote Commands Row
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .horizontalScroll(rememberScrollState()),
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    SimChip("Expand", CrispInkPrimary, "sim_cmd_expand") {
                                        hudManager.handleRemoteCommand(JSONObject().put("action", "EXPAND"))
                                        addLog("CMD -> EXPAND")
                                    }
                                    SimChip("Collapse", CrispInkPrimary, "sim_cmd_collapse") {
                                        hudManager.handleRemoteCommand(JSONObject().put("action", "COLLAPSE"))
                                        addLog("CMD -> COLLAPSE")
                                    }
                                    SimChip("Open Input", CrispBlue, "sim_cmd_open_input") {
                                        hudManager.handleRemoteCommand(JSONObject().put("action", "OPEN_INPUT"))
                                        addLog("CMD -> OPEN_INPUT")
                                    }
                                    SimChip("Opacity ${(opacity * 100).toInt()}%", CrispInkPrimary, "sim_cmd_opacity") {
                                        hudManager.handleRemoteCommand(JSONObject().put("action", "CYCLE_OPACITY"))
                                        addLog("CMD -> CYCLE_OPACITY (${(hudManager.opacityFlow.value * 100).toInt()}%)")
                                    }
                                    SimChip(if (ghostPassThrough) "Un-Ghost" else "Ghost", CrispAmber, "sim_cmd_ghost") {
                                        hudManager.handleRemoteCommand(JSONObject().put("action", "TOGGLE_GHOST"))
                                        addLog("CMD -> TOGGLE_GHOST")
                                    }
                                }

                                // Safety Hooks Verification
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Surface(
                                        color = Color.White,
                                        shape = RoundedCornerShape(50),
                                        border = BorderStroke(0.85.dp, CrispHairline),
                                        modifier = Modifier
                                            .weight(1f)
                                            .clip(RoundedCornerShape(50))
                                            .clickable {
                                                val repo = AccessibilityRepositoryImpl()
                                                val hudExcluded = repo.isAgyHudIdentifier("com.kavach:id/agy_hud_window2", "agy_hud_root")
                                                val termuxKept = !repo.isAgyHudIdentifier("com.termux:id/terminal_view", "Terminal")
                                                val status = if (hudExcluded && termuxKept) "PASS" else "FAIL"
                                                addLog("SAFETY [$status] Self-Exclusion: agy_hud_ filtered, Termux visible")
                                            }
                                            .testTag("sim_test_self_exclusion")
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.Center
                                        ) {
                                            Icon(
                                                imageVector = Icons.Rounded.Shield,
                                                contentDescription = null,
                                                tint = CrispEmerald,
                                                modifier = Modifier.size(14.dp)
                                            )
                                            Spacer(Modifier.width(5.dp))
                                            Text(
                                                text = "Self-Exclusion",
                                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Medium),
                                                color = CrispInkPrimary,
                                                maxLines = 1
                                            )
                                        }
                                    }

                                    Surface(
                                        color = Color.White,
                                        shape = RoundedCornerShape(50),
                                        border = BorderStroke(0.85.dp, CrispHairline),
                                        modifier = Modifier
                                            .weight(1f)
                                            .clip(RoundedCornerShape(50))
                                            .clickable {
                                                val sampleRects = hudManager.getOverlayBounds().ifEmpty {
                                                    listOf(Rect(640, 1800, 1060, 2320))
                                                }
                                                val hit = hudManager.coordinatesOverlapRects(820f, 2000f, 820f, 2000f, sampleRects)
                                                val miss = !hudManager.coordinatesOverlapRects(120f, 240f, 120f, 240f, sampleRects)
                                                val applied = hudManager.temporarilyPassThroughIfColliding(820f, 2000f)
                                                val status = if (hit && miss) "PASS" else "FAIL"
                                                addLog("SAFETY [$status] Touch Pass-Through: overlap=$hit, liveApplied=$applied (300ms)")
                                            }
                                            .testTag("sim_test_touch_passthrough")
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.Center
                                        ) {
                                            Icon(
                                                imageVector = Icons.Rounded.TouchApp,
                                                contentDescription = null,
                                                tint = CrispBlue,
                                                modifier = Modifier.size(14.dp)
                                            )
                                            Spacer(Modifier.width(5.dp))
                                            Text(
                                                text = "Pass-Through",
                                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Medium),
                                                color = CrispInkPrimary,
                                                maxLines = 1
                                            )
                                        }
                                    }
                                }

                                // Live Command Echo Console
                                Surface(
                                    color = Color.White,
                                    shape = RoundedCornerShape(14.dp),
                                    border = BorderStroke(0.85.dp, CrispHairline),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(10.dp),
                                        verticalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = "Command Echo",
                                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
                                                color = CrispInkSecondary
                                            )
                                            Text(
                                                text = "Clear",
                                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
                                                color = CrispBlue,
                                                modifier = Modifier
                                                    .clip(RoundedCornerShape(50))
                                                    .clickable { echoLogs.clear() }
                                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                                            )
                                        }
                                        if (echoLogs.isEmpty()) {
                                            Text(
                                                text = "No events yet.",
                                                style = MaterialTheme.typography.labelSmall.copy(fontFamily = JetBrainsMonoFamily),
                                                color = CrispInkMuted
                                            )
                                        } else {
                                            echoLogs.take(6).forEach { line ->
                                                Text(
                                                    text = line,
                                                    style = MaterialTheme.typography.labelSmall.copy(
                                                        fontFamily = JetBrainsMonoFamily,
                                                        fontSize = 10.sp,
                                                        lineHeight = 14.sp
                                                    ),
                                                    color = when {
                                                        line.contains("HUD_COMMAND") -> CrispBlue
                                                        line.contains("PASS") -> CrispEmerald
                                                        line.contains("NEEDS_INPUT") -> CrispAmber
                                                        else -> CrispInkSecondary
                                                    },
                                                    maxLines = 2,
                                                    overflow = TextOverflow.Ellipsis
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun SandboxWindow2Preview(
    state: AgyHudOverlayManager.AgyHudState,
    isCollapsed: Boolean,
    isOutputExpanded: Boolean,
    elapsedMs: Long,
    opacity: Float,
    ghostPassThrough: Boolean,
    wireframeEnabled: Boolean,
    collapsedRunningStep: AgyHudOverlayManager.CollapsedRunningStep,
    quickActions: List<AgyHudOverlayManager.QuickActionChip>,
    formatElapsed: (Long, Boolean) -> String,
    fullOutputText: String,
    onCycleOpacity: () -> Unit,
    onToggleWireframe: () -> Unit,
    onToggleGhost: () -> Unit,
    onToggleInput: () -> Unit,
    onToggleCollapse: () -> Unit,
    onToggleOutput: () -> Unit,
    onCopyOutput: () -> Boolean,
    onQuickAction: (AgyHudOverlayManager.QuickActionChip) -> Unit,
    onStop: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var copiedFlash by remember { mutableStateOf(false) }
    var isToolsTrayOpen by remember { mutableStateOf(false) }
    LaunchedEffect(isCollapsed) {
        if (isCollapsed) isToolsTrayOpen = false
    }

    val isWorking = state.state == "WORKING"
    val isNeedsInput = state.state == "NEEDS_INPUT"
    val isDone = state.state == "DONE"
    val liveCollapsedMode = isCollapsed && isWorking
    val accent = when (state.state) {
        "WORKING" -> CrispBlue
        "NEEDS_INPUT" -> CrispAmber
        "DONE" -> CrispEmerald
        else -> CrispIndigo
    }
    val visualAlpha = if (ghostPassThrough) (opacity * 0.5f).coerceAtLeast(0.35f) else opacity

    // Flowing Gemini-style Aurora sweep rotation while WORKING
    val auroraTransition = rememberInfiniteTransition(label = "aurora_border")
    val auroraAngle by auroraTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 2800, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "aurora_angle"
    )
    val amberPulse by auroraTransition.animateFloat(
        initialValue = 0.55f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 900, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "amber_pulse"
    )

    val headerIcon = collapsedRunningStep.icon

    // Unified vertical dock: Collapsible Working Card ABOVE Always-Visible Bottom Ask Agy Chat Pill
    Column(
        horizontalAlignment = Alignment.End,
        verticalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.alpha(visualAlpha)
    ) {
        // Upper Slot: Collapsible Working Window with Aurora Shimmer Rim
        AnimatedVisibility(
            visible = !isCollapsed,
            enter = fadeIn() + expandVertically(expandFrom = Alignment.Bottom),
            exit = fadeOut() + shrinkVertically(shrinkTowards = Alignment.Bottom)
        ) {
            Surface(
                color = CrispSurface,
                shape = RoundedCornerShape(22.dp),
                shadowElevation = 4.dp,
                modifier = Modifier
                    .widthIn(min = 248.dp, max = 294.dp)
                    .drawWithContent {
                        drawContent()
                        val corner = CornerRadius(22.dp.toPx(), 22.dp.toPx())
                        when {
                            isWorking -> {
                                val strokePx = 2.dp.toPx()
                                rotate(degrees = auroraAngle) {
                                    drawRoundRect(
                                        brush = Brush.sweepGradient(
                                            colors = listOf(
                                                Color(0xFF0095F6),
                                                Color(0xFF4F46E5),
                                                Color(0xFF8B5CF6),
                                                Color(0xFF38BDF8),
                                                Color(0xFF0095F6)
                                            )
                                        ),
                                        cornerRadius = corner,
                                        style = Stroke(width = strokePx)
                                    )
                                }
                            }
                            isNeedsInput -> {
                                drawRoundRect(
                                    color = CrispAmber.copy(alpha = amberPulse),
                                    cornerRadius = corner,
                                    style = Stroke(width = 1.8.dp.toPx())
                                )
                            }
                            isDone -> {
                                drawRoundRect(
                                    color = CrispEmerald.copy(alpha = 0.55f),
                                    cornerRadius = corner,
                                    style = Stroke(width = 1.4.dp.toPx())
                                )
                            }
                            else -> {
                                drawRoundRect(
                                    color = CrispBorder,
                                    cornerRadius = corner,
                                    style = Stroke(width = 1.dp.toPx())
                                )
                            }
                        }
                    }
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // 1. Sliding Top Indeterminate Loading Bar while WORKING
                    if (isWorking) {
                        ComposeSlidingLoadingBar(modifier = Modifier.fillMaxWidth())
                    }

                    // Ultra-Clean Header: Real/Vector App Icon + Single-Line Status & Timer + Only 2 Quiet Controls (··· & —)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            AgyComposeIconBadge(icon = headerIcon, size = 24.dp)
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(5.dp)
                            ) {
                                if (isWorking) {
                                    ComposeSpinnerRing(color = CrispBlue, size = 11.dp)
                                } else {
                                    Box(
                                        modifier = Modifier
                                            .size(6.dp)
                                            .clip(CircleShape)
                                            .background(accent)
                                    )
                                }
                                val cleanStatus = when (state.state) {
                                    "WORKING" -> "Working"
                                    "NEEDS_INPUT" -> "Needs input"
                                    "DONE" -> "Done"
                                    else -> "Ready"
                                }
                                Text(
                                    text = cleanStatus,
                                    style = MaterialTheme.typography.labelMedium.copy(
                                        fontWeight = FontWeight.SemiBold,
                                        fontSize = 11.5.sp
                                    ),
                                    color = accent,
                                    maxLines = 1
                                )
                                val timerLabel = when {
                                    isWorking -> "· ${formatElapsed(elapsedMs, false)}"
                                    isDone && elapsedMs > 0L -> "· ${formatElapsed(elapsedMs, true).removePrefix("Done ")}"
                                    isNeedsInput && elapsedMs > 0L -> "· ${formatElapsed(elapsedMs, false)}"
                                    else -> ""
                                }
                                if (timerLabel.isNotEmpty()) {
                                    Text(
                                        text = timerLabel,
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontFamily = JetBrainsMonoFamily,
                                            fontSize = 10.sp
                                        ),
                                        color = CrispInkSecondary,
                                        maxLines = 1,
                                        modifier = Modifier.testTag("simulator_elapsed_timer")
                                    )
                                }
                            }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            MiniHudChip(
                                symbol = "···",
                                active = isToolsTrayOpen,
                                onClick = { isToolsTrayOpen = !isToolsTrayOpen }
                            )
                            MiniHudChip(
                                symbol = "─",
                                active = false,
                                onClick = {
                                    isToolsTrayOpen = false
                                    onToggleCollapse()
                                }
                            )
                        }
                    }

                    // Hidden-by-default Secondary Tools Tray (Opacity, Wireframe, Ghost — zero emojis)
                    AnimatedVisibility(
                        visible = isToolsTrayOpen,
                        enter = fadeIn() + expandVertically(),
                        exit = fadeOut() + shrinkVertically()
                    ) {
                        Surface(
                            color = Color(0xFFF5F6F8),
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(0.75.dp, Color(0xFFE8ECF1)),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("simulator_hud_tools_tray")
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(4.dp),
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                HudTrayPill(
                                    label = "Opacity ${(opacity * 100).toInt()}%",
                                    active = false,
                                    accent = CrispBlue,
                                    onClick = onCycleOpacity,
                                    modifier = Modifier.weight(1f)
                                )
                                HudTrayPill(
                                    label = if (wireframeEnabled) "● Wireframe" else "Wireframe",
                                    active = wireframeEnabled,
                                    accent = CrispBlue,
                                    onClick = onToggleWireframe,
                                    modifier = Modifier.weight(1f)
                                )
                                HudTrayPill(
                                    label = if (ghostPassThrough) "● Ghost" else "Ghost",
                                    active = ghostPassThrough,
                                    accent = CrispAmber,
                                    onClick = onToggleGhost,
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }

                    Text(
                        text = state.title,
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 14.sp
                        ),
                        color = CrispInkPrimary,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )

                    if (state.question.isNotBlank()) {
                        Surface(
                            color = Color(0xFFFEF3C7),
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(0.8.dp, Color(0xFFFDE68A)),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .clickable(onClick = onToggleInput)
                        ) {
                            Text(
                                text = state.question,
                                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold),
                                color = Color(0xFFB45309),
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp)
                            )
                        }
                    }

                    // Calm Active Step Line + 3 Animated Bouncing Dots while WORKING
                    if (state.currentAction.isNotBlank()) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                text = state.currentAction,
                                style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.5.sp),
                                color = CrispInkSecondary,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f, fill = false)
                            )
                            if (isWorking) {
                                ComposeBouncingDots(color = CrispBlue)
                            }
                        }
                    }
                    if (state.nextAction.isNotBlank() && state.tasks.isEmpty()) {
                        Text(
                            text = "Next: ${state.nextAction}",
                            style = MaterialTheme.typography.labelSmall,
                            color = CrispInkMuted,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    // Airy Borderless Task List with Hybrid Per-Task App/Task Icons
                    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        state.tasks.forEach { task ->
                            val (marker, color) = when (task.status) {
                                "done" -> "✓" to CrispEmerald
                                "doing" -> "•" to CrispBlue
                                "needs_input" -> "?" to CrispAmber
                                else -> "○" to CrispInkMuted
                            }
                            val taskIcon = remember(context, task.icon, task.appPackage, task.label, task.detail) {
                                AgyAppIconResolver.resolve(
                                    context = context,
                                    explicitIcon = task.icon,
                                    explicitPackage = task.appPackage,
                                    fallbackText = "${task.label} ${task.detail}"
                                )
                            }
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .then(
                                        if (task.status == "doing" || task.status == "needs_input") {
                                            Modifier
                                                .clip(RoundedCornerShape(10.dp))
                                                .background(color.copy(alpha = 0.07f))
                                                .padding(horizontal = 6.dp, vertical = 5.dp)
                                        } else {
                                            Modifier.padding(horizontal = 4.dp, vertical = 3.dp)
                                        }
                                    )
                            ) {
                                AgyComposeIconBadge(icon = taskIcon, size = 19.dp)
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = task.label,
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontSize = 11.5.sp,
                                            fontWeight = if (task.status == "doing") FontWeight.SemiBold else FontWeight.Normal
                                        ),
                                        color = if (task.status == "done") CrispInkSecondary else CrispInkPrimary,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    if (task.detail.isNotBlank()) {
                                        Text(
                                            text = task.detail,
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                fontFamily = JetBrainsMonoFamily,
                                                fontSize = 9.5.sp
                                            ),
                                            color = CrispInkMuted,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                }
                                if (task.status == "doing" && isWorking) {
                                    ComposeSpinnerRing(color = CrispBlue, size = 12.dp)
                                } else {
                                    Text(
                                        text = marker,
                                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                        color = color
                                    )
                                }
                            }
                        }
                    }

                    // Quiet Neutral Expandable Detailed Output Drawer inside Working Card
                    val hasDetailedOutput = state.detailedOutput.isNotBlank() || state.outputLogs.isNotEmpty()
                    if (hasDetailedOutput) {
                        Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                            Surface(
                                color = Color(0xFFF3F4F6),
                                shape = RoundedCornerShape(12.dp),
                                border = BorderStroke(0.75.dp, Color(0xFFE5E7EB)),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .clickable(onClick = onToggleOutput)
                                    .testTag("simulator_toggle_output_drawer")
                            ) {
                                val logSuffix = if (state.outputLogs.isNotEmpty()) " · ${state.outputLogs.size} logs" else ""
                                Text(
                                    text = if (isOutputExpanded) {
                                        "Hide Output$logSuffix ▴"
                                    } else {
                                        "Output$logSuffix ▾"
                                    },
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontWeight = FontWeight.SemiBold,
                                        fontSize = 11.sp
                                    ),
                                    color = CrispInkPrimary,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                )
                            }

                            AnimatedVisibility(
                                visible = isOutputExpanded,
                                enter = fadeIn() + expandVertically(),
                                exit = fadeOut() + shrinkVertically()
                            ) {
                                Surface(
                                    color = Color(0xFFF8FAFC),
                                    shape = RoundedCornerShape(12.dp),
                                    border = BorderStroke(0.75.dp, CrispHairline),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("simulator_output_drawer_content")
                                ) {
                                    Column(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(10.dp),
                                        verticalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = "OUTPUT & LOGS",
                                                style = MaterialTheme.typography.labelSmall.copy(
                                                    fontFamily = JetBrainsMonoFamily,
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 9.sp
                                                ),
                                                color = CrispInkMuted
                                            )
                                            Surface(
                                                color = Color.White,
                                                shape = RoundedCornerShape(50),
                                                border = BorderStroke(0.8.dp, CrispHairline),
                                                modifier = Modifier
                                                    .clip(RoundedCornerShape(50))
                                                    .clickable {
                                                        if (onCopyOutput()) {
                                                            copiedFlash = true
                                                            scope.launch {
                                                                delay(1600L)
                                                                copiedFlash = false
                                                            }
                                                        }
                                                    }
                                                    .testTag("simulator_copy_output_button")
                                            ) {
                                                Text(
                                                    text = if (copiedFlash) "Copied ✓" else "Copy",
                                                    style = MaterialTheme.typography.labelSmall.copy(
                                                        fontWeight = FontWeight.Bold,
                                                        fontSize = 9.5.sp
                                                    ),
                                                    color = if (copiedFlash) CrispEmerald else CrispBlue,
                                                    modifier = Modifier.padding(horizontal = 9.dp, vertical = 2.dp)
                                                )
                                            }
                                        }
                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .heightIn(max = 120.dp)
                                                .verticalScroll(rememberScrollState())
                                        ) {
                                            Text(
                                                text = fullOutputText,
                                                style = MaterialTheme.typography.labelSmall.copy(
                                                    fontFamily = JetBrainsMonoFamily,
                                                    fontSize = 10.sp,
                                                    lineHeight = 14.sp
                                                ),
                                                color = CrispInkPrimary
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Contextual Quick Action Chips Strip
                    if (quickActions.isNotEmpty()) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState())
                                .testTag("simulator_quick_actions_row"),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            quickActions.forEachIndexed { idx, chip ->
                                val isStop = chip.actionType == "STOP"
                                val isPrimary = idx == 0 && !isStop
                                val chipTint = when {
                                    isStop -> CrispRose
                                    isPrimary -> CrispBlue
                                    else -> CrispInkPrimary
                                }
                                Surface(
                                    color = when {
                                        isStop -> CrispRose.copy(alpha = 0.10f)
                                        isPrimary -> CrispBlue.copy(alpha = 0.10f)
                                        else -> CrispSurfaceSubtle
                                    },
                                    shape = RoundedCornerShape(50),
                                    border = BorderStroke(
                                        0.8.dp,
                                        when {
                                            isStop -> CrispRose.copy(alpha = 0.35f)
                                            isPrimary -> CrispBlue.copy(alpha = 0.35f)
                                            else -> CrispHairline
                                        }
                                    ),
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(50))
                                        .clickable { onQuickAction(chip) }
                                        .testTag("simulator_quick_chip_$idx")
                                ) {
                                    Text(
                                        text = chip.label,
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 10.5.sp
                                        ),
                                        color = chipTint,
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                                    )
                                }
                            }
                        }
                    }

                    // Miniature Low-Poly Wireframe Canvas (collapses to 0dp when screenWatch.active == false)
                    AnimatedVisibility(
                        visible = state.screenWatch.active && wireframeEnabled,
                        enter = fadeIn() + expandVertically(),
                        exit = fadeOut() + shrinkVertically()
                    ) {
                        Surface(
                            color = CrispSurfaceSubtle,
                            shape = RoundedCornerShape(14.dp),
                            border = BorderStroke(1.dp, CrispHairline),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 4.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                SandboxWireframeCanvas(watch = state.screenWatch)
                                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                    Text(
                                        text = state.screenWatch.label.ifBlank { "Screen Watch" },
                                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                        color = CrispInkPrimary
                                    )
                                    Text(
                                        text = "${state.screenWatch.zones.size} key zones${state.screenWatch.actionVector?.let { " • ${it.type}" } ?: ""}",
                                        style = MaterialTheme.typography.labelSmall.copy(fontFamily = JetBrainsMonoFamily),
                                        color = CrispInkSecondary
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Lower Slot: Morphing Bottom Pill Dock
        // - Collapsed & WORKING: Live Running Step Pill ([Icon+Ring] [Marquee Step] [Timer] [Stop ■])
        // - Expanded / Idle / Needs Input / Done: Status Toggle + [✦ Ask Agy / Reply]
        Surface(
            color = CrispSurface,
            shape = RoundedCornerShape(50),
            shadowElevation = 3.dp,
            border = BorderStroke(
                if (isWorking || isNeedsInput) 1.15.dp else 1.dp,
                when {
                    isNeedsInput -> CrispAmber
                    isWorking -> CrispBlue.copy(alpha = 0.45f)
                    isDone -> CrispEmerald.copy(alpha = 0.45f)
                    else -> CrispBorder
                }
            ),
            modifier = Modifier
                .animateContentSize(animationSpec = tween(durationMillis = 200))
                .testTag("simulator_bottom_chat_dock")
        ) {
            if (liveCollapsedMode) {
                Row(
                    modifier = Modifier
                        .widthIn(max = 292.dp)
                        .padding(start = 7.dp, end = 6.dp, top = 5.dp, bottom = 5.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier
                            .weight(1f, fill = false)
                            .clip(RoundedCornerShape(50))
                            .clickable(onClick = onToggleCollapse)
                            .padding(end = 2.dp)
                            .testTag("simulator_collapsed_live_step_pill")
                    ) {
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier.size(26.dp)
                        ) {
                            ComposeSpinnerRing(color = CrispBlue, size = 26.dp)
                            AgyComposeIconBadge(icon = collapsedRunningStep.icon, size = 18.dp)
                        }
                        AnimatedContent(
                            targetState = collapsedRunningStep.label,
                            transitionSpec = {
                                (fadeIn(tween(190)) + slideInVertically(tween(190)) { it / 3 }) togetherWith
                                    (fadeOut(tween(140)) + slideOutVertically(tween(140)) { -it / 3 })
                            },
                            label = "collapsed_live_step_crossfade",
                            modifier = Modifier
                                .weight(1f, fill = false)
                                .widthIn(min = 56.dp, max = 160.dp)
                        ) { stepLabel ->
                            Text(
                                text = stepLabel,
                                style = MaterialTheme.typography.labelMedium.copy(
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 12.sp
                                ),
                                color = CrispInkPrimary,
                                maxLines = 1,
                                softWrap = false,
                                modifier = Modifier
                                    .graphicsLayer(compositingStrategy = CompositingStrategy.Offscreen)
                                    .drawWithContent {
                                        drawContent()
                                        val fadeW = 12.dp.toPx()
                                        if (size.width > fadeW * 2.5f) {
                                            drawRect(
                                                brush = Brush.horizontalGradient(
                                                    0f to Color.Transparent,
                                                    1f to Color.Black,
                                                    startX = size.width - fadeW,
                                                    endX = size.width
                                                ),
                                                blendMode = BlendMode.DstOut
                                            )
                                        }
                                    }
                                    .basicMarquee(
                                        iterations = Int.MAX_VALUE,
                                        repeatDelayMillis = 1200,
                                        initialDelayMillis = 600,
                                        velocity = 34.dp
                                    )
                                    .testTag("simulator_collapsed_live_step_text")
                            )
                        }
                        Text(
                            text = formatElapsed(elapsedMs, false),
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontFamily = JetBrainsMonoFamily,
                                fontSize = 10.5.sp
                            ),
                            color = CrispInkSecondary,
                            maxLines = 1,
                            modifier = Modifier.testTag("simulator_collapsed_live_timer")
                        )
                    }

                    Surface(
                        color = CrispRose.copy(alpha = 0.12f),
                        shape = CircleShape,
                        border = BorderStroke(0.85.dp, CrispRose.copy(alpha = 0.30f)),
                        modifier = Modifier
                            .size(28.dp)
                            .clip(CircleShape)
                            .clickable(onClick = onStop)
                            .testTag("simulator_collapsed_stop_btn")
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Rounded.Stop,
                                contentDescription = "Stop Agy",
                                tint = CrispRose,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                    }
                }
            } else {
                Row(
                    modifier = Modifier.padding(start = 10.dp, end = 6.dp, top = 5.dp, bottom = 5.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val chevron = if (isCollapsed) "▲" else "▼"
                    val statusLabel = when (state.state) {
                        "WORKING" -> "Working $chevron"
                        "NEEDS_INPUT" -> "? Reply $chevron"
                        "DONE" -> if (elapsedMs > 0L) {
                            "✓ Done · ${formatElapsed(elapsedMs, true).removePrefix("Done ")} $chevron"
                        } else {
                            "✓ Done $chevron"
                        }
                        else -> "○ Ready $chevron"
                    }
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier
                            .clip(RoundedCornerShape(50))
                            .clickable(onClick = onToggleCollapse)
                            .padding(horizontal = 4.dp, vertical = 3.dp)
                            .testTag("simulator_dock_status_toggle")
                    ) {
                        if (isWorking) {
                            ComposeSpinnerRing(color = CrispBlue, size = 12.dp)
                        }
                        Text(
                            text = statusLabel,
                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                            color = if (isNeedsInput) CrispAmber else CrispInkPrimary
                        )
                    }
                    Box(
                        modifier = Modifier
                            .width(1.dp)
                            .height(16.dp)
                            .background(CrispHairline)
                    )
                    Surface(
                        color = if (isNeedsInput) CrispAmber else CrispBlue,
                        shape = RoundedCornerShape(50),
                        modifier = Modifier
                            .clip(RoundedCornerShape(50))
                            .clickable(onClick = onToggleInput)
                            .testTag("simulator_bottom_chat_pill")
                    ) {
                        Text(
                            text = if (isNeedsInput) "✦ Reply" else "✦ Ask Agy",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = Color.White,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun AgyComposeIconBadge(
    icon: AgyAppIconResolver.ResolvedIcon,
    size: Dp
) {
    Canvas(modifier = Modifier.size(size)) {
        drawIntoCanvas { canvas ->
            AgyAppIconResolver.drawBadgeOnCanvas(
                canvas = canvas.nativeCanvas,
                width = this.size.width,
                height = this.size.height,
                icon = icon
            )
        }
    }
}

@Composable
private fun ComposeSpinnerRing(color: Color, size: Dp) {
    val infinite = rememberInfiniteTransition(label = "spinner_ring")
    val angle by infinite.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 900, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "spinner_angle"
    )
    Canvas(modifier = Modifier.size(size)) {
        val strokePx = 2.dp.toPx()
        val pad = strokePx * 0.6f
        val arcSize = Size(this.size.width - pad * 2f, this.size.height - pad * 2f)
        drawArc(
            color = color.copy(alpha = 0.16f),
            startAngle = 0f,
            sweepAngle = 360f,
            useCenter = false,
            topLeft = Offset(pad, pad),
            size = arcSize,
            style = Stroke(width = strokePx)
        )
        drawArc(
            color = color,
            startAngle = angle - 90f,
            sweepAngle = 250f,
            useCenter = false,
            topLeft = Offset(pad, pad),
            size = arcSize,
            style = Stroke(width = strokePx, cap = StrokeCap.Round)
        )
    }
}

@Composable
private fun ComposeSlidingLoadingBar(modifier: Modifier = Modifier) {
    val infinite = rememberInfiniteTransition(label = "loading_bar")
    val progress by infinite.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1250, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "bar_progress"
    )
    Canvas(
        modifier = modifier
            .height(3.5.dp)
            .clip(RoundedCornerShape(50))
    ) {
        val w = size.width
        val h = size.height
        val r = CornerRadius(h * 0.5f, h * 0.5f)
        drawRoundRect(color = Color(0xFFE2E8F0), cornerRadius = r)
        val segW = w * 0.38f
        val startX = -segW + (w + segW) * progress
        val left = startX.coerceIn(0f, w)
        val right = (startX + segW).coerceIn(0f, w)
        if (right > left) {
            drawRoundRect(
                brush = Brush.horizontalGradient(
                    colors = listOf(CrispBlue, CrispIndigo),
                    startX = left,
                    endX = right
                ),
                topLeft = Offset(left, 0f),
                size = Size(right - left, h),
                cornerRadius = r
            )
        }
    }
}

@Composable
private fun ComposeBouncingDots(color: Color) {
    val infinite = rememberInfiniteTransition(label = "bouncing_dots")
    val phase by infinite.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 960, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "dots_phase"
    )
    Canvas(modifier = Modifier.size(width = 24.dp, height = 14.dp)) {
        val r = 2.dp.toPx()
        val spacing = 6.5.dp.toPx()
        val baseY = size.height * 0.62f
        val lift = 3.2.dp.toPx()
        val startX = (size.width - spacing * 2f) * 0.5f
        for (i in 0 until 3) {
            val dotPhase = (phase + i * 0.22f) % 1f
            val wave = sin(dotPhase * 2.0 * PI).toFloat().coerceAtLeast(0f)
            val cy = baseY - wave * lift
            drawCircle(
                color = color.copy(alpha = (0.45f + 0.55f * wave).coerceIn(0.45f, 1f)),
                radius = r,
                center = Offset(startX + i * spacing, cy)
            )
        }
    }
}

@Composable
private fun SandboxWireframeCanvas(watch: AgyHudOverlayManager.ScreenWatchState) {
    val infinite = rememberInfiniteTransition(label = "wf_anim")
    val phase by infinite.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "wf_phase"
    )
    Canvas(
        modifier = Modifier
            .size(width = 48.dp, height = 88.dp)
    ) {
        val pad = 2.dp.toPx()
        val w = (size.width - pad * 2).coerceAtLeast(1f)
        val h = (size.height - pad * 2).coerceAtLeast(1f)
        drawRoundRect(
            color = Color(0xFFFFFFFF),
            topLeft = Offset(pad, pad),
            size = Size(w, h),
            cornerRadius = CornerRadius(8.dp.toPx(), 8.dp.toPx())
        )
        drawRoundRect(
            color = Color(0xFFCBD5E1),
            topLeft = Offset(pad, pad),
            size = Size(w, h),
            cornerRadius = CornerRadius(8.dp.toPx(), 8.dp.toPx()),
            style = Stroke(width = 1.2.dp.toPx())
        )

        val sw = watch.screenWidth.coerceAtLeast(1).toFloat()
        val sh = watch.screenHeight.coerceAtLeast(1).toFloat()
        val inset = 4.dp.toPx()
        val iw = (w - inset * 2).coerceAtLeast(1f)
        val ih = (h - inset * 2).coerceAtLeast(1f)
        fun mx(x: Float) = pad + inset + (x / sw).coerceIn(0f, 1f) * iw
        fun my(y: Float) = pad + inset + (y / sh).coerceIn(0f, 1f) * ih

        watch.zones.take(6).forEach { z ->
            val l = mx(min(z.x1, z.x2))
            val t = my(min(z.y1, z.y2))
            val r = max(l + 4.dp.toPx(), mx(max(z.x1, z.x2)))
            val b = max(t + 4.dp.toPx(), my(max(z.y1, z.y2)))
            val isTarget = z.role.contains("target", true) || z.role.contains("focus", true)
            val isAction = z.role.contains("button", true) || z.role.contains("input", true)
            val stroke = when {
                isTarget -> CrispAmber
                isAction -> CrispBlue
                else -> Color(0xFF94A3B8)
            }
            drawRoundRect(
                color = stroke.copy(alpha = 0.16f),
                topLeft = Offset(l, t),
                size = Size(r - l, b - t),
                cornerRadius = CornerRadius(3.dp.toPx(), 3.dp.toPx())
            )
            drawRoundRect(
                color = stroke,
                topLeft = Offset(l, t),
                size = Size(r - l, b - t),
                cornerRadius = CornerRadius(3.dp.toPx(), 3.dp.toPx()),
                style = Stroke(width = 1.dp.toPx())
            )
        }

        watch.actionVector?.let { vec ->
            val sx = mx(vec.x1)
            val sy = my(vec.y1)
            if (vec.type.equals("SWIPE", true) || vec.type.equals("DRAG", true)) {
                val ex = mx(vec.x2)
                val ey = my(vec.y2)
                drawLine(
                    color = CrispBlue,
                    start = Offset(sx, sy),
                    end = Offset(ex, ey),
                    strokeWidth = 1.6.dp.toPx(),
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 4f), 0f)
                )
                val angle = atan2((ey - sy).toDouble(), (ex - sx).toDouble())
                val head = 5.dp.toPx()
                val arrow = Path().apply {
                    moveTo(ex, ey)
                    lineTo((ex - head * cos(angle - 0.5)).toFloat(), (ey - head * sin(angle - 0.5)).toFloat())
                    lineTo((ex - head * cos(angle + 0.5)).toFloat(), (ey - head * sin(angle + 0.5)).toFloat())
                    close()
                }
                drawPath(arrow, color = CrispAmber)
                val bx = sx + (ex - sx) * phase
                val by = sy + (ey - sy) * phase
                drawCircle(color = CrispBlue, radius = 3.dp.toPx(), center = Offset(bx, by))
            } else {
                drawCircle(
                    color = CrispBlue.copy(alpha = (1f - phase).coerceIn(0.15f, 0.9f)),
                    radius = (3f + phase * 8f).dp.toPx(),
                    center = Offset(sx, sy),
                    style = Stroke(width = 1.4.dp.toPx())
                )
                drawCircle(color = CrispAmber, radius = 2.6.dp.toPx(), center = Offset(sx, sy))
            }
        }
    }
}

@Composable
private fun MiniHudChip(
    symbol: String,
    active: Boolean = false,
    onClick: () -> Unit
) {
    Surface(
        color = if (active) Color(0xFFE0F2FE) else Color(0xFFF3F4F6),
        shape = CircleShape,
        modifier = Modifier
            .size(26.dp)
            .clip(CircleShape)
            .clickable(onClick = onClick)
    ) {
        Box(contentAlignment = Alignment.Center) {
            Text(
                text = symbol,
                fontSize = 11.5.sp,
                fontWeight = FontWeight.SemiBold,
                color = if (active) CrispBlue else CrispInkSecondary
            )
        }
    }
}

@Composable
private fun HudTrayPill(
    label: String,
    active: Boolean,
    accent: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        color = Color.White,
        shape = RoundedCornerShape(50),
        border = BorderStroke(0.75.dp, if (active) accent.copy(alpha = 0.35f) else Color(0xFFE5E7EB)),
        modifier = modifier
            .clip(RoundedCornerShape(50))
            .clickable(onClick = onClick)
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 5.dp)
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall.copy(
                    fontSize = 10.sp,
                    fontWeight = FontWeight.SemiBold
                ),
                color = if (active) accent else CrispInkSecondary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun SimChip(label: String, tint: Color, tag: String, onClick: () -> Unit) {
    Surface(
        color = Color(0xFFF5F6F8),
        shape = RoundedCornerShape(50),
        border = BorderStroke(0.85.dp, Color(0xFFE8ECF1)),
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .clickable(onClick = onClick)
            .testTag(tag)
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
            color = tint,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp)
        )
    }
}

private fun buildIdlePayload(note: String): JSONObject = JSONObject().apply {
    put("state", "IDLE")
    put("title", "Agy Ready")
    put("icon", "spark_ai")
    put("currentAction", note)
    put("nextAction", "")
    put("question", "")
    put("autoCollapseSeconds", 3)
    put("detailedOutput", "")
    put("outputLogs", JSONArray())
    put("tasks", JSONArray())
    put("screenWatch", JSONObject().put("active", false))
}

private fun buildWorkingPayload(title: String): JSONObject = JSONObject().apply {
    put("state", "WORKING")
    put("title", title)
    put("icon", "youtube")
    put("appPackage", "com.google.android.youtube")
    put("currentAction", "Opening YouTube & preparing Termux bridge")
    put("nextAction", "Search target video & inspect playback UI")
    put("question", "")
    put("autoCollapseSeconds", 4)
    put("detailedOutput", "Launching multi-app automation pipeline across Termux, YouTube, and Chrome.")
    put("outputLogs", JSONArray().apply {
        put("[00:00.4] Termux: Loaded ~/.aura_token (200 OK)")
        put("[00:01.1] YouTube: Launching com.google.android.youtube")
    })
    put("tasks", JSONArray().apply {
        put(JSONObject().put("id", "s1").put("label", "Verify Termux bridge token").put("status", "done").put("icon", "termux").put("detail", "127.0.0.1:8080"))
        put(JSONObject().put("id", "s2").put("label", "Open YouTube & search playlist").put("status", "doing").put("icon", "youtube").put("appPackage", "com.google.android.youtube").put("detail", "Query: Lo-Fi Coding Beats"))
        put(JSONObject().put("id", "s3").put("label", "Verify stream metadata in Chrome").put("status", "pending").put("icon", "chrome"))
        put(JSONObject().put("id", "s4").put("label", "Send summary link via WhatsApp").put("status", "pending").put("icon", "whatsapp"))
    })
    put("screenWatch", JSONObject().put("active", false))
}

private fun buildTapWatchPayload(title: String): JSONObject = JSONObject().apply {
    put("state", "WORKING")
    put("title", title)
    put("icon", "youtube")
    put("appPackage", "com.google.android.youtube")
    put("currentAction", "Tapping YouTube Play CTA (pass-through safe)")
    put("nextAction", "Capture stream URL & verify in Chrome")
    put("question", "")
    put("autoCollapseSeconds", 4)
    put("detailedOutput", "Located top YouTube search result 'Lofi Hip Hop Radio — Beats to Code To'. Targeting Play button at [830, 1005] with 300ms HUD collision pass-through.")
    put("outputLogs", JSONArray().apply {
        put("[00:00.4] Termux: Loaded ~/.aura_token (200 OK)")
        put("[00:01.1] YouTube: Opened search bar & typed query")
        put("[00:02.3] UI Tree: Found 4 key zones (agy_hud_ excluded)")
        put("[00:02.6] Tap: Dispatched [830, 1005] -> Play")
    })
    put("tasks", JSONArray().apply {
        put(JSONObject().put("id", "s1").put("label", "Verify Termux bridge token").put("status", "done").put("icon", "termux"))
        put(JSONObject().put("id", "s2").put("label", "Tap Play in YouTube").put("status", "doing").put("icon", "youtube").put("appPackage", "com.google.android.youtube").put("detail", "Reticle [830, 1005]"))
        put(JSONObject().put("id", "s3").put("label", "Verify stream metadata in Chrome").put("status", "pending").put("icon", "chrome"))
        put(JSONObject().put("id", "s4").put("label", "Send summary link via WhatsApp").put("status", "pending").put("icon", "whatsapp"))
    })
    put("screenWatch", JSONObject().apply {
        put("active", true)
        put("label", "YouTube • Tap Play")
        put("screenWidth", 1080)
        put("screenHeight", 2400)
        put("zones", JSONArray().apply {
            put(JSONObject().put("x1", 60).put("y1", 160).put("x2", 1020).put("y2", 320).put("role", "header").put("tag", "YouTube"))
            put(JSONObject().put("x1", 80).put("y1", 460).put("x2", 1000).put("y2", 620).put("role", "input").put("tag", "Search"))
            put(JSONObject().put("x1", 660).put("y1", 920).put("x2", 1000).put("y2", 1090).put("role", "target").put("tag", "Play"))
            put(JSONObject().put("x1", 80).put("y1", 1220).put("x2", 1000).put("y2", 1740).put("role", "panel").put("tag", "Up Next"))
        })
        put("actionVector", JSONObject().put("type", "TAP").put("x1", 830).put("y1", 1005).put("x2", 830).put("y2", 1005))
    })
}

private fun buildSwipeWatchPayload(title: String): JSONObject = JSONObject().apply {
    put("state", "WORKING")
    put("title", title)
    put("icon", "chrome")
    put("appPackage", "com.android.chrome")
    put("currentAction", "Scrolling Chrome article & preparing WhatsApp share")
    put("nextAction", "Ask confirmation before sending message")
    put("question", "")
    put("autoCollapseSeconds", 4)
    put("detailedOutput", "Extracted video title, duration (LIVE), and clean share link in Chrome. Ready to draft WhatsApp share card.")
    put("outputLogs", JSONArray().apply {
        put("[00:00.4] Termux: Loaded ~/.aura_token (200 OK)")
        put("[00:02.6] YouTube: Playback started cleanly")
        put("[00:03.9] Chrome: Swiped feed [540,1820 -> 540,620]")
        put("[00:04.5] Parser: Captured clean URL & metadata")
    })
    put("tasks", JSONArray().apply {
        put(JSONObject().put("id", "s1").put("label", "Verify Termux bridge token").put("status", "done").put("icon", "termux"))
        put(JSONObject().put("id", "s2").put("label", "Open YouTube & start playback").put("status", "done").put("icon", "youtube"))
        put(JSONObject().put("id", "s3").put("label", "Scroll Chrome & extract summary").put("status", "doing").put("icon", "chrome").put("detail", "Swipe up gesture"))
        put(JSONObject().put("id", "s4").put("label", "Send summary link via WhatsApp").put("status", "pending").put("icon", "whatsapp"))
    })
    put("screenWatch", JSONObject().apply {
        put("active", true)
        put("label", "Chrome • Swipe Up")
        put("screenWidth", 1080)
        put("screenHeight", 2400)
        put("zones", JSONArray().apply {
            put(JSONObject().put("x1", 60).put("y1", 180).put("x2", 1020).put("y2", 340).put("role", "header").put("tag", "Chrome"))
            put(JSONObject().put("x1", 80).put("y1", 460).put("x2", 1000).put("y2", 1180).put("role", "panel").put("tag", "Article"))
            put(JSONObject().put("x1", 80).put("y1", 1260).put("x2", 1000).put("y2", 1980).put("role", "button").put("tag", "Share"))
        })
        put("actionVector", JSONObject().put("type", "SWIPE").put("x1", 540).put("y1", 1820).put("x2", 540).put("y2", 620))
    })
}

private fun buildNeedsInputPayload(): JSONObject = JSONObject().apply {
    put("state", "NEEDS_INPUT")
    put("title", "Confirm WhatsApp Share")
    put("icon", "whatsapp")
    put("appPackage", "com.whatsapp")
    put("currentAction", "Waiting for your confirmation...")
    put("nextAction", "Send message & complete workflow")
    put("question", "Share the YouTube link to your Dev Group on WhatsApp?")
    put("autoCollapseSeconds", 4)
    put("detailedOutput", "Draft message ready:\n\"Now playing: Lofi Hip Hop Radio — Beats to Code To (YouTube Live)\"")
    put("outputLogs", JSONArray().apply {
        put("[00:02.6] YouTube: Playback verified")
        put("[00:04.5] Chrome: Extracted title & canonical URL")
        put("[00:05.1] WhatsApp: Paused for user confirmation")
    })
    put("quickActions", JSONArray().apply {
        put(JSONObject().put("label", "Yes, send it").put("commandText", "Yes, send on WhatsApp").put("actionType", "PROMPT"))
        put(JSONObject().put("label", "Skip share").put("commandText", "Skip WhatsApp share").put("actionType", "PROMPT"))
        put(JSONObject().put("label", "Cancel").put("commandText", "STOP").put("actionType", "STOP"))
    })
    put("tasks", JSONArray().apply {
        put(JSONObject().put("id", "s1").put("label", "Verify Termux bridge token").put("status", "done").put("icon", "termux"))
        put(JSONObject().put("id", "s2").put("label", "Play stream on YouTube").put("status", "done").put("icon", "youtube"))
        put(JSONObject().put("id", "s3").put("label", "Confirm WhatsApp share").put("status", "needs_input").put("icon", "whatsapp"))
    })
    put("screenWatch", JSONObject().put("active", false))
}

private fun buildDonePayload(summary: String): JSONObject = JSONObject().apply {
    put("state", "DONE")
    put("title", "Workflow Completed")
    put("icon", "youtube")
    put("appPackage", "com.google.android.youtube")
    put("currentAction", summary)
    put("nextAction", "")
    put("question", "")
    put("autoCollapseSeconds", 5)
    put(
        "detailedOutput",
        "Result Summary:\n" +
            "• YouTube: 'Lofi Hip Hop Radio — Beats to Code To' playing smoothly.\n" +
            "• Chrome: Metadata verified (1080p60, live stream active).\n" +
            "• WhatsApp: Share link delivered cleanly.\n" +
            "• Safety: 0 overlay collisions; agy_hud_ nodes 100% self-excluded."
    )
    put("outputLogs", JSONArray().apply {
        put("[00:00.4] Termux: Auth verified via ~/.aura_token")
        put("[00:01.2] YouTube: Launched & searched target stream")
        put("[00:02.6] Tap: Clicked Play at [830, 1005] (pass-through OK)")
        put("[00:04.1] Chrome: Verified canonical share metadata")
        put("[00:05.8] WhatsApp: Delivered summary • exit code 0")
    })
    put("tasks", JSONArray().apply {
        put(JSONObject().put("id", "s1").put("label", "Verify Termux bridge token").put("status", "done").put("icon", "termux"))
        put(JSONObject().put("id", "s2").put("label", "Play stream on YouTube").put("status", "done").put("icon", "youtube"))
        put(JSONObject().put("id", "s3").put("label", "Verify stream metadata in Chrome").put("status", "done").put("icon", "chrome"))
        put(JSONObject().put("id", "s4").put("label", "Send summary link via WhatsApp").put("status", "done").put("icon", "whatsapp"))
    })
    put("screenWatch", JSONObject().put("active", false))
}
