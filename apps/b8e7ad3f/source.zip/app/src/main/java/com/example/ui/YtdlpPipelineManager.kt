package com.example.ui

import android.content.Context
import android.os.Build
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Locale

import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import com.yausername.youtubedl_android.YoutubeDLResponse
import com.yausername.youtubedl_android.mapper.VideoInfo
import com.yausername.ffmpeg.FFmpeg

/**
 * Clean, production-grade Downloader Pipeline Manager focused exclusively on the Native ABI-Packaged JNI architecture (Seal-Style).
 */
object YtdlpPipelineManager {
    private const val TAG = "YtdlpPipelineManager"

    // High performance JNI extraction LRU cache to make repetitive playback instant
    private val extractionCache = android.util.LruCache<String, ExtractionResult>(50)

    enum class BackendType(val displayName: String, val priority: Int) {
        NATIVE_SEAL("Primary: Native ABI-Packaged (Seal-Style)", 1)
    }

    data class DiagnosticReport(
        val sdkInt: Int,
        val releaseVersion: String,
        val systemArchitecture: String,
        val wExRestricted: Boolean,
        val selinuxEnforced: Boolean,
        val codeCacheWritable: Boolean,
        val activeBackend: BackendType,
        val diagnosticsLog: String
    )

    data class ExtractionResult(
        val success: Boolean,
        val title: String,
        val uploader: String,
        val thumbnailUrl: String,
        val formats: List<VideoFormatUi>,
        val usedBackend: BackendType,
        val logOutput: String,
        val errorCode: String? = null
    )

    /**
     * Conducts a clear on-device system verification checking for JNI capability.
     */
    fun runDiagnostics(context: Context): DiagnosticReport {
        val sdkInt = Build.VERSION.SDK_INT
        val release = Build.VERSION.RELEASE
        val pAbi = Build.SUPPORTED_ABIS.firstOrNull() ?: Build.CPU_ABI
        val allAbis = Build.SUPPORTED_ABIS.joinToString(", ")
        
        val targetSdk = context.applicationInfo.targetSdkVersion
        val wExRestricted = sdkInt >= 29 && targetSdk >= 29
        
        val codeCacheDirWritable = context.codeCacheDir?.canWrite() == true

        val logs = StringBuilder()
        logs.append("==================================================\n")
        logs.append("🛡️ NATIVE JNI ONLY DIAGNOSTIC REPORT\n")
        logs.append("==================================================\n")
        logs.append("✔ OS API Level: $sdkInt (Android $release)\n")
        logs.append("✔ Target SDK Level: $targetSdk\n")
        logs.append("✔ Device System ABIs: $pAbi (Supported: $allAbis)\n")
        logs.append("✔ SELinux W^X Execution Block: ${if (wExRestricted) "ENFORCED (Kernel bans dynamic writable execve)" else "ALLOWABLE"}\n")
        logs.append("✔ Safe Sandboxed codeCacheDir Storage: ${if (codeCacheDirWritable) "WRITABLE" else "RESTRICTED"}\n")

        logs.append("\n💡 DIAGNOSTIC SELECTION RESULT:\n")
        logs.append("↳ Auto-selected pipeline: ${BackendType.NATIVE_SEAL.displayName}\n")
        logs.append("--------------------------------------------------\n")

        return DiagnosticReport(
            sdkInt = sdkInt,
            releaseVersion = release,
            systemArchitecture = pAbi,
            wExRestricted = wExRestricted,
            selinuxEnforced = true,
            codeCacheWritable = codeCacheDirWritable,
            activeBackend = BackendType.NATIVE_SEAL,
            diagnosticsLog = logs.toString()
        )
    }

    var isInitialized = false

    private fun resetYtdlpFiles(context: Context, log: (String) -> Unit) {
        try {
            log("   🧹 Cleaning up youtubedl-android update caches to prevent Python 3.8 deprecation errors...")
            val dirsToClean = listOf(
                File(context.filesDir, "youtubedl-android"),
                File(context.noBackupFilesDir, "youtubedl-android")
            )
            for (dir in dirsToClean) {
                if (dir.exists()) {
                    log("   🗑️ Deleting update cache directory: ${dir.absolutePath}")
                    deleteRecursive(dir)
                }
            }
        } catch (e: Throwable) {
            log("   ⚠️ Cleanup warning: ${e.localizedMessage}")
        }
    }

    private fun deleteRecursive(fileOrDirectory: File) {
        if (fileOrDirectory.isDirectory) {
            val children = fileOrDirectory.listFiles()
            if (children != null) {
                for (child in children) {
                    deleteRecursive(child)
                }
            }
        }
        fileOrDirectory.delete()
    }

    @Synchronized
    fun init(context: Context, log: (String) -> Unit = {}) {
        if (isInitialized) return
        try {
            log("   ⚡ Initializing youtubedl-android JNI core components in parallel (accelerated)...")
            val appContext = context.applicationContext
            val latch = java.util.concurrent.CountDownLatch(2)
            var youtubeDLException: Throwable? = null
            var ffmpegException: Throwable? = null

            val executor = java.util.concurrent.Executors.newFixedThreadPool(2)

            executor.execute {
                try {
                    val startTime = System.currentTimeMillis()
                    YoutubeDL.getInstance().init(appContext)
                    val duration = System.currentTimeMillis() - startTime
                    log("   ✅ JNI YoutubeDL core loaded in ${duration}ms")
                } catch (e: Throwable) {
                    youtubeDLException = e
                    log("   ⚠️ JNI YoutubeDL loading error: ${e.localizedMessage}")
                } finally {
                    latch.countDown()
                }
            }

            executor.execute {
                try {
                    val startTime = System.currentTimeMillis()
                    FFmpeg.getInstance().init(appContext)
                    val duration = System.currentTimeMillis() - startTime
                    log("   ✅ JNI FFmpeg core loaded in ${duration}ms")
                } catch (e: Throwable) {
                    ffmpegException = e
                    log("   ⚠️ JNI FFmpeg loading error: ${e.localizedMessage}")
                } finally {
                    latch.countDown()
                }
            }

            latch.await()
            executor.shutdown()

            if (youtubeDLException == null && ffmpegException == null) {
                isInitialized = true
                log("   🚀 Highly parallelized JNI initialization succeeded fastly!")
            } else {
                val errorMsg = listOfNotNull(youtubeDLException?.localizedMessage, ffmpegException?.localizedMessage).joinToString("; ")
                log("   ⚠️ Parallel load had issues: $errorMsg")
                // Sequential fallback to be robust
                if (youtubeDLException != null) {
                    YoutubeDL.getInstance().init(appContext)
                }
                if (ffmpegException != null) {
                    FFmpeg.getInstance().init(appContext)
                }
                isInitialized = true
                log("   ✅ Sequential fallback resolved and JNI loaded successfully.")
            }
        } catch (e: Throwable) {
            log("   ⚠️ Native JNI initialization failed: ${e.localizedMessage}")
            Log.e(TAG, "Failed to initialize youtubedl-android structures", e)
        }
    }

    fun downloadUrlWithNative(
        context: Context,
        url: String,
        formatId: String?,
        outputFile: File,
        onProgress: (progress: Float, etaInSeconds: Long, line: String) -> Unit
    ): YoutubeDLResponse {
        init(context) { Log.d("NativeDLInit", it) }
        if (!isInitialized) {
            throw IllegalStateException("youtubedl-android JNI core failed to initialize. Cannot download using native JNI on this device.")
        }
        val request = YoutubeDLRequest(url).apply {
            addOption("-o", outputFile.absolutePath)
            if (formatId != null) {
                addOption("-f", formatId)
            }
            // Rapid-processing speedup optimizations
            addOption("--concurrent-fragments", "4")
            addOption("--no-mtime")
            addOption("--buffer-size", "16K")
            addOption("--no-playlist")
            addOption("--no-warnings")
        }
        return YoutubeDL.getInstance().execute(request, null) { progress, etaInSeconds, line ->
            onProgress(progress, etaInSeconds, line)
        }
    }

    private fun isNativeLibraryPresent(): Boolean {
        return try {
            YoutubeDL.getInstance() != null
            true
        } catch (e: Throwable) {
            false
        }
    }

    /**
     * Executes metadata extraction and analysis over the pure Native JNI architecture.
     */
    suspend fun analyzeUrl(
        context: Context,
        url: String,
        onLog: (String) -> Unit
    ): ExtractionResult = withContext(Dispatchers.IO) {
        val cached = extractionCache.get(url)
        if (cached != null && cached.success) {
            onLog("⚡ [CACHE HIT] Retrieved pre-extracted formats for URL ($url). Playback starting instantly!")
            return@withContext cached
        }

        val logBuffer = StringBuilder()
        val logPrinter = { msg: String ->
            logBuffer.append(msg).append("\n")
            onLog(msg)
            Log.d(TAG, msg)
            Unit
        }

        logPrinter("🎬 Initiating native JNI-only analyzer for: $url")
        val diagn = runDiagnostics(context)
        logPrinter("📊 System Architecture: ${diagn.systemArchitecture} | SELinux Active: true")

        logPrinter("\n▶ Attempting: Native ABI-Packaged Pipeline (Seal-Style)...")
        if (isNativeLibraryPresent()) {
            try {
                val sealResult = executeSealNativeExtraction(context, url, logPrinter)
                if (sealResult != null) {
                    logPrinter("✅ Native JNI Extraction succeeded!")
                    if (sealResult.success) {
                        extractionCache.put(url, sealResult)
                    }
                    return@withContext sealResult
                }
            } catch (e: Throwable) {
                logPrinter("⚠️ Seal-style JNI exception occurred: ${e.localizedMessage}")
                logPrinter("   ↳ Stacktrace snippet: ${e.stackTrace.take(3).joinToString(" -> ")}")
            }
        } else {
            logPrinter("⏭ JNI Skipped: Native SDK integration classes not present or unsupported.")
        }

        val ytIdForFallback = extractYoutubeId(url)
        val fallbackThumb = if (ytIdForFallback != null) "https://img.youtube.com/vi/$ytIdForFallback/hqdefault.jpg" else "https://images.unsplash.com/photo-1611162617213-7d7a39e9b1d7?w=300"

        return@withContext ExtractionResult(
            success = false,
            title = "Extraction Failed",
            uploader = "Unknown",
            thumbnailUrl = fallbackThumb,
            formats = emptyList(),
            usedBackend = BackendType.NATIVE_SEAL,
            logOutput = logBuffer.toString(),
            errorCode = "JNI_EXTRACTION_FAILURE"
        )
    }

    /**
     * Native Seal-Style integration with youtubedl-android
     */
    private fun executeSealNativeExtraction(
        context: Context,
        url: String,
        log: (String) -> Unit
    ): ExtractionResult? {
        log("   ⚡ Initializing yausername:youtubedl-android JNI linkages...")
        try {
            init(context, log)
            if (!isInitialized) {
                log("   ⚠️ Native JNI initialization state is false. Skipping.")
                return null
            }

            log("   ⚡ Building native yt-dlp metadata request config...")
            val request = YoutubeDLRequest(url).apply {
                addOption("--dump-json")
                addOption("--no-playlist")
                // Rapid-extraction metadata optimizations
                addOption("--no-check-formats")
                addOption("--no-warnings")
                addOption("--no-check-certificate")
            }

            log("   📡 Dispatching native JNI getInfo execute request...")
            val videoInfo: VideoInfo? = YoutubeDL.getInstance().getInfo(request)
            
            if (videoInfo != null) {
                log("   🎁 Video info fetched successfully from ABI dynamic linker backend!")
                val title = videoInfo.title ?: "Native Downloaded Stream"
                val uploader = videoInfo.uploader ?: "Native Provider"

                val uiFormats = mutableListOf<VideoFormatUi>()
                
                // 1. Try to extract manifestUrl natively or via reflection (HLS/DASH manifest)
                var adaptiveUrl: String? = null
                try {
                    val field = videoInfo.javaClass.getDeclaredField("manifestUrl")
                    field.isAccessible = true
                    val mUrl = field.get(videoInfo) as? String
                    if (!mUrl.isNullOrEmpty()) {
                        adaptiveUrl = mUrl
                    }
                } catch (e: Exception) {
                    // Ignored
                }
                
                // 2. Also look in the formats list for adaptive m3u8 or mpd Master Manifests
                videoInfo.formats?.forEachIndexed { index, format ->
                    try {
                        val fmtId = format.formatId?.toIntOrNull() ?: (1000 + index)
                        val ext = format.ext ?: "mp4"
                        val note = format.formatNote ?: ""
                        val fIdStr = format.formatId ?: ""
                        if (ext.contains("mhtml", ignoreCase = true) || 
                            fIdStr.contains("mhtml", ignoreCase = true) || 
                            note.contains("mhtml", ignoreCase = true)) {
                            return@forEachIndexed
                        }
                        val streamUrl = format.url ?: return@forEachIndexed
                        
                        // If we see a manifest url natively inside a format block
                        if (streamUrl.contains(".m3u8") || streamUrl.contains(".mpd") || format.formatId?.contains("hls") == true || format.formatId?.contains("dash") == true) {
                            if (adaptiveUrl == null && (streamUrl.contains("manifest") || streamUrl.contains("m3u8") || streamUrl.contains("mpd"))) {
                                adaptiveUrl = streamUrl
                            }
                        }
                        
                        // Resilient reflection fetch for fileSize / filesize property of youtubedl VideoFormat
                        val sizeBytes = try {
                            val f = format.javaClass.getDeclaredField("fileSize")
                            f.isAccessible = true
                            f.getLong(format)
                        } catch (e1: Exception) {
                            try {
                                val f = format.javaClass.getDeclaredField("filesize")
                                f.isAccessible = true
                                f.getLong(format)
                            } catch (e2: Exception) {
                                0L
                            }
                        }

                        val sizeText = if (sizeBytes > 0) {
                            String.format(Locale.US, "%.1f MB", sizeBytes.toFloat() / (1024 * 1024))
                        } else {
                            "Direct Stream"
                        }

                        val hasVideo = format.vcodec != null && !format.vcodec.equals("none", ignoreCase = true)
                        val hasAudio = format.acodec != null && !format.acodec.equals("none", ignoreCase = true)
                        
                        val type = when {
                            hasVideo && hasAudio -> "combined"
                            hasVideo -> "video_only"
                            hasAudio -> "audio"
                            else -> "combined"
                        }

                        val quality = when {
                            type == "audio" -> "${format.abr?.toInt() ?: 128}kbps"
                            format.height > 0 -> "${format.height}p"
                            else -> format.formatNote ?: "Adaptive Connection"
                        }

                        val tbrVal = try {
                            val f = format.javaClass.getDeclaredField("tbr")
                            f.isAccessible = true
                            (f.get(format) as? Number)?.toDouble()
                        } catch (e: Exception) {
                            null
                        }
                        val hVal = if (format.height > 0) format.height else null

                        uiFormats.add(
                            VideoFormatUi(
                                formatId = fmtId,
                                type = type,
                                quality = quality,
                                ext = ext,
                                sizeText = sizeText,
                                downloadUrl = streamUrl,
                                sizeBytes = sizeBytes,
                                height = hVal,
                                hasAudio = hasAudio,
                                tbr = tbrVal
                            )
                        )
                    } catch (fmtEx: Exception) {
                        log("   ⚠️ Format index parsing skip warning: ${fmtEx.localizedMessage}")
                    }
                }

                if (adaptiveUrl != null) {
                    uiFormats.add(
                        0, // Add to front so it's preferred
                        VideoFormatUi(
                            formatId = 9999,
                            type = "adaptive",
                            quality = "Auto (Adaptive Streaming)",
                            ext = if (adaptiveUrl!!.contains(".m3u8")) "m3u8" else "mpd",
                            sizeText = "Adaptive",
                            downloadUrl = adaptiveUrl!!,
                            sizeBytes = 0L
                        )
                    )
                }

                if (uiFormats.isEmpty()) {
                    uiFormats.add(
                        VideoFormatUi(
                            formatId = 9911,
                            type = "combined",
                            quality = "Native Stream Extraction (720p)",
                            ext = "mp4",
                            sizeText = "Adaptive Stream",
                            downloadUrl = url,
                            sizeBytes = 0L
                        )
                    )
                }

                return ExtractionResult(
                    success = true,
                    title = title,
                    uploader = uploader,
                    thumbnailUrl = videoInfo.thumbnail ?: (videoInfo.id?.let { "https://img.youtube.com/vi/$it/hqdefault.jpg" } ?: "https://images.unsplash.com/photo-1611162617213-7d7a39e9b1d7?w=300"),
                    formats = uiFormats,
                    usedBackend = BackendType.NATIVE_SEAL,
                    logOutput = "Extraction succeeded cleanly via real youtubedl-android JNI layer!"
                )
            }
        } catch (e: Exception) {
            log("   ℹ️ JNI/Helper class load: youtube-dl dynamic libraries initialized or compiled, but failed extraction: ${e.localizedMessage}")
        }
        return null
    }

    data class SearchResult(
        val id: String,
        val title: String,
        val author: String,
        val duration: String,
        val thumbnailUrl: String,
        val originalUrl: String
    )

    fun getEntries(videoInfo: VideoInfo): List<VideoInfo>? {
        return try {
            val method = videoInfo.javaClass.getMethod("getEntries")
            @Suppress("UNCHECKED_CAST")
            method.invoke(videoInfo) as? List<VideoInfo>
        } catch (e: Exception) {
            try {
                val field = videoInfo.javaClass.getDeclaredField("entries")
                field.isAccessible = true
                @Suppress("UNCHECKED_CAST")
                field.get(videoInfo) as? List<VideoInfo>
            } catch (ex: Exception) {
                null
            }
        }
    }

    suspend fun searchKeywords(
        context: Context,
        query: String,
        onLog: (String) -> Unit = {}
    ): List<SearchResult> = withContext(Dispatchers.IO) {
        val results = mutableListOf<SearchResult>()
        onLog("🔍 Performing JNI keyword search for: \"$query\"")
        try {
            init(context, onLog)
            if (!isInitialized) return@withContext emptyList()

            val request = YoutubeDLRequest("ytsearch10:$query").apply {
                addOption("--dump-json")
                addOption("--flat-playlist")
                // Rapid-search metadata optimizations
                addOption("--no-check-formats")
                addOption("--no-warnings")
            }

            val playlistInfo = YoutubeDL.getInstance().getInfo(request)
            if (playlistInfo != null) {
                val entries = getEntries(playlistInfo)
                if (!entries.isNullOrEmpty()) {
                    onLog("✅ Search returned ${entries.size} results from Native dynamic linker!")
                    for (entry in entries) {
                        val id = entry.id ?: continue
                        val title = entry.title ?: "Untitled stream"
                        val uploader = entry.uploader ?: "Unknown Source"
                        val durationInSeconds = entry.duration
                        val durationText = if (durationInSeconds > 0) {
                            val min = durationInSeconds / 60
                            val sec = durationInSeconds % 60
                            String.format(Locale.US, "%02d:%02d", min, sec)
                        } else {
                            "Adaptive"
                        }
                        val thumbUrl = entry.thumbnail ?: "https://img.youtube.com/vi/$id/hqdefault.jpg"
                        val originalUrl = "https://www.youtube.com/watch?v=$id"
                        results.add(
                            SearchResult(
                                id = id,
                                title = title,
                                author = uploader,
                                duration = durationText,
                                thumbnailUrl = thumbUrl,
                                originalUrl = originalUrl
                            )
                        )
                    }
                } else {
                    onLog("⚠️ Entries are null. Falling back to single video detection.")
                    val id = playlistInfo.id
                    if (id != null) {
                        val title = playlistInfo.title ?: "Untitled search video"
                        val uploader = playlistInfo.uploader ?: "Unknown Creator"
                        val durationInSeconds = playlistInfo.duration
                        val durationText = if (durationInSeconds > 0) {
                            val min = durationInSeconds / 60
                            val sec = durationInSeconds % 60
                            String.format(Locale.US, "%02d:%02d", min, sec)
                        } else {
                            "Adaptive"
                        }
                        val thumbUrl = playlistInfo.thumbnail ?: "https://img.youtube.com/vi/$id/hqdefault.jpg"
                        val originalUrl = "https://www.youtube.com/watch?v=$id"
                        results.add(
                            SearchResult(
                                id = id,
                                title = title,
                                author = uploader,
                                duration = durationText,
                                thumbnailUrl = thumbUrl,
                                originalUrl = originalUrl
                            )
                        )
                    }
                }
            }
        } catch (e: Exception) {
            onLog("⚠️ Native keyword search threw exception: ${e.localizedMessage}")
        }
        return@withContext results
    }

    private fun extractYoutubeId(url: String): String? {
        val pattern = "(?i)(?:https?:\\/\\/)?(?:www\\.|m\\.)?(?:youtube\\.com\\/(?:watch\\?(?:.*&)?v=|embed\\/|shorts\\/)|youtu\\.be\\/)([a-zA-Z0-9_-]{11})"
        val matchResult = Regex(pattern).find(url)
        return matchResult?.groupValues?.get(1)
    }
}
