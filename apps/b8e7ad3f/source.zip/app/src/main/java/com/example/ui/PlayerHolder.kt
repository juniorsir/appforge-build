package com.example.ui

import android.content.Context
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import android.media.audiofx.LoudnessEnhancer

object PlayerHolder {
    var player: ExoPlayer? = null
    var loudnessEnhancer: LoudnessEnhancer? = null
    var trackSelector: DefaultTrackSelector? = null

    fun initialize(context: Context): ExoPlayer {
        if (player == null) {
            val dataSourceFactory = androidx.media3.datasource.DefaultHttpDataSource.Factory()
                .setUserAgent("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.127 Safari/537.36")
                .setDefaultRequestProperties(mapOf("Accept" to "*/*"))
                .setConnectTimeoutMs(8000)
                .setReadTimeoutMs(8000)
                .setAllowCrossProtocolRedirects(true)

            // Setup Adaptive Track Selector
            val trackSelectorFactory = DefaultTrackSelector.Parameters.Builder(context)
                .setForceHighestSupportedBitrate(false)
                .build()
            trackSelector = DefaultTrackSelector(context, trackSelectorFactory)

            // Setup LoadControl for Fast Startup & Ultra-Smooth Buffer Management
            val loadControl = DefaultLoadControl.Builder()
                .setBufferDurationsMs(
                    30000, // minBufferMs
                    60000, // maxBufferMs
                    1500,  // bufferForPlaybackMs
                    5000   // bufferForPlaybackAfterRebufferMs (longer buffer to guarantee smooth streaming recovery)
                )
                .setPrioritizeTimeOverSizeThresholds(true)
                .build()

            val mediaSourceFactory = androidx.media3.exoplayer.source.DefaultMediaSourceFactory(dataSourceFactory)

            player = ExoPlayer.Builder(context.applicationContext)
                .setTrackSelector(trackSelector!!)
                .setLoadControl(loadControl)
                .setMediaSourceFactory(mediaSourceFactory)
                .build()

            loudnessEnhancer = LoudnessEnhancer(player!!.audioSessionId).apply {
                setTargetGain(2000) // +20dB boost
            }
        }
        return player!!
    }
}
