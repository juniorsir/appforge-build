package com.example.capabilities.clipboard

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import com.example.capabilities.CapabilityResult
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject

interface ClipboardRepository {
    fun readClipboard(): CapabilityResult<String>
    fun writeClipboard(text: String): CapabilityResult<Unit>
}

class ClipboardRepositoryImpl @Inject constructor(
    @ApplicationContext private val context: Context
) : ClipboardRepository {
    private val clipboardManager = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager

    override fun readClipboard(): CapabilityResult<String> {
        return try {
            if (clipboardManager.hasPrimaryClip()) {
                val item = clipboardManager.primaryClip?.getItemAt(0)
                CapabilityResult.Success(item?.text?.toString() ?: "")
            } else {
                CapabilityResult.Success("")
            }
        } catch (e: Exception) {
            CapabilityResult.Error("Failed to read clipboard", e)
        }
    }

    override fun writeClipboard(text: String): CapabilityResult<Unit> {
        return try {
            val clip = ClipData.newPlainText("Copied Text", text)
            clipboardManager.setPrimaryClip(clip)
            CapabilityResult.Success(Unit)
        } catch (e: Exception) {
            CapabilityResult.Error("Failed to write clipboard", e)
        }
    }
}
