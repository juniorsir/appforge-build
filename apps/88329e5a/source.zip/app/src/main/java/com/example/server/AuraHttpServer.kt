package com.example.server

import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStream
import java.net.ServerSocket
import java.net.Socket

class AuraHttpServer(
    private val scope: CoroutineScope,
    private val port: Int = 8080,
    private val onApiRequest: ((endpoint: String, jsonPayload: JSONObject) -> JSONObject)? = null
) {
    private val TAG = "AuraHttpServer"
    private var serverSocket: ServerSocket? = null
    private var serverJob: Job? = null

    fun start() {
        if (serverJob?.isActive == true) return
        serverJob = scope.launch(Dispatchers.IO) {
            try {
                serverSocket = ServerSocket(port)
                Log.i(TAG, "Aura Documentation & REST API HTTP Server listening on http://127.0.0.1:$port")

                while (isActive && serverSocket?.isClosed == false) {
                    try {
                        val clientSocket = serverSocket?.accept() ?: break
                        launch(Dispatchers.IO) {
                            handleClient(clientSocket)
                        }
                    } catch (e: Exception) {
                        if (isActive) {
                            Log.w(TAG, "Exception accepting connection: ${e.message}")
                        }
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Failed to bind AuraHttpServer to port $port: ${e.message}")
            }
        }
    }

    private val cachedHelpBytes by lazy {
        AuraManifestProvider.generateManifestJson().toByteArray(Charsets.UTF_8)
    }

    private val cachedCapabilitiesBytes by lazy {
        val manifest = JSONObject(AuraManifestProvider.generateManifestJson())
        val caps = manifest.optJSONArray("capabilities") ?: org.json.JSONArray()
        val responseObj = JSONObject().apply {
            put("totalCapabilities", manifest.optInt("totalCapabilitiesCount", 42))
            put("categories", manifest.optJSONArray("categories"))
            put("capabilities", caps)
        }
        responseObj.toString(2).toByteArray(Charsets.UTF_8)
    }

    private val cachedCommandsBytes by lazy {
        val manifest = JSONObject(AuraManifestProvider.generateManifestJson())
        val cmds = manifest.optJSONArray("commands") ?: org.json.JSONArray()
        val responseObj = JSONObject().apply {
            put("totalCommands", manifest.optInt("totalCommandsCount", 24))
            put("commands", cmds)
        }
        responseObj.toString(2).toByteArray(Charsets.UTF_8)
    }

    private val cachedHealthBytes by lazy {
        val statusObj = JSONObject().apply {
            put("status", "UP")
            put("server", "Aura Local Media & Device Engine")
            put("totalCapabilities", 42)
            put("totalCommands", 24)
            put("websocketPort", 8000)
            put("httpDocsPort", port)
        }
        statusObj.toString(2).toByteArray(Charsets.UTF_8)
    }

    private fun handleClient(socket: Socket) {
        socket.use { client ->
            try {
                client.soTimeout = 4000
                val reader = BufferedReader(InputStreamReader(client.getInputStream()))
                val requestLine = reader.readLine() ?: return
                val parts = requestLine.split(" ")
                if (parts.size < 2) return

                val method = parts[0].uppercase()
                val fullUri = parts[1]
                val path = fullUri.substringBefore("?")
                val queryString = if (fullUri.contains("?")) fullUri.substringAfter("?") else ""

                // Read headers
                var contentLength = 0
                var line = reader.readLine()
                while (!line.isNullOrEmpty()) {
                    val headerLower = line.lowercase()
                    if (headerLower.startsWith("content-length:")) {
                        contentLength = headerLower.substringAfter(":").trim().toIntOrNull() ?: 0
                    }
                    line = reader.readLine()
                }

                // Handle CORS preflight
                if (method == "OPTIONS") {
                    val out: OutputStream = client.getOutputStream()
                    val header = "HTTP/1.1 204 No Content\r\n" +
                            "Access-Control-Allow-Origin: *\r\n" +
                            "Access-Control-Allow-Methods: GET, POST, OPTIONS\r\n" +
                            "Access-Control-Allow-Headers: Content-Type\r\n" +
                            "Connection: close\r\n\r\n"
                    out.write(header.toByteArray(Charsets.UTF_8))
                    out.flush()
                    return
                }

                // Read body if POST/PUT
                var bodyJson = JSONObject()
                if (contentLength > 0) {
                    val bodyChars = CharArray(contentLength)
                    var readCount = 0
                    while (readCount < contentLength) {
                        val read = reader.read(bodyChars, readCount, contentLength - readCount)
                        if (read <= 0) break
                        readCount += read
                    }
                    val bodyString = String(bodyChars, 0, readCount)
                    if (bodyString.isNotBlank()) {
                        try {
                            bodyJson = JSONObject(bodyString)
                        } catch (e: Exception) {
                            bodyJson.put("raw", bodyString)
                        }
                    }
                }

                // Populate query string parameters if not already in JSON body
                if (queryString.isNotBlank()) {
                    queryString.split("&").forEach { param ->
                        val kv = param.split("=", limit = 2)
                        if (kv.isNotEmpty()) {
                            val k = java.net.URLDecoder.decode(kv[0], "UTF-8")
                            val v = if (kv.size > 1) java.net.URLDecoder.decode(kv[1], "UTF-8") else "true"
                            if (!bodyJson.has(k)) {
                                if (v.equals("true", ignoreCase = true)) bodyJson.put(k, true)
                                else if (v.equals("false", ignoreCase = true)) bodyJson.put(k, false)
                                else bodyJson.put(k, v)
                            }
                        }
                    }
                }

                val (statusCode, bodyBytes) = when {
                    path == "/" || path == "/help" || path == "/docs" || path == "/manifest" -> {
                        Pair("200 OK", cachedHelpBytes)
                    }
                    path == "/capabilities" -> {
                        Pair("200 OK", cachedCapabilitiesBytes)
                    }
                    path == "/commands" -> {
                        Pair("200 OK", cachedCommandsBytes)
                    }
                    path == "/health" || path == "/status" -> {
                        Pair("200 OK", cachedHealthBytes)
                    }
                    path.startsWith("/api/") && onApiRequest != null -> {
                        try {
                            val apiResult = onApiRequest.invoke(path, bodyJson)
                            Pair("200 OK", apiResult.toString(2).toByteArray(Charsets.UTF_8))
                        } catch (e: Exception) {
                            val errObj = JSONObject().apply {
                                put("success", false)
                                put("error", e.message ?: "API Error")
                            }
                            Pair("500 Internal Server Error", errObj.toString(2).toByteArray(Charsets.UTF_8))
                        }
                    }
                    else -> {
                        val notFoundObj = JSONObject().apply {
                            put("error", "Not Found")
                            put("availableEndpoints", listOf("/help", "/capabilities", "/commands", "/health", "/api/*"))
                        }
                        Pair("404 Not Found", notFoundObj.toString(2).toByteArray(Charsets.UTF_8))
                    }
                }

                val out: OutputStream = client.getOutputStream()
                val header = buildString {
                    append("HTTP/1.1 $statusCode\r\n")
                    append("Content-Type: application/json; charset=utf-8\r\n")
                    append("Content-Length: ${bodyBytes.size}\r\n")
                    append("Access-Control-Allow-Origin: *\r\n")
                    append("Access-Control-Allow-Methods: GET, POST, OPTIONS\r\n")
                    append("Access-Control-Allow-Headers: Content-Type\r\n")
                    append("Connection: close\r\n")
                    append("\r\n")
                }
                out.write(header.toByteArray(Charsets.UTF_8))
                out.write(bodyBytes)
                out.flush()
            } catch (e: Exception) {
                Log.e(TAG, "Error handling HTTP client request: ${e.message}")
            }
        }
    }

    fun stop() {
        try {
            serverSocket?.close()
        } catch (e: Exception) {
            // Ignore
        }
        serverJob?.cancel()
    }
}
