#!/usr/bin/env python3
"""
CLI Controller for Termux AIOS & Android Automation Bridge
Sends commands over localhost WebSocket or HTTP REST to the Android device.

Features:
- List installed applications (with search filter & system app toggle)
- Open / Launch applications by name, package name, or URL
- Inspect on-screen UI hierarchy (Accessibility tree)
- Tap elements by label or coordinates
- Dispatch gestures (swipe, click, scroll next)
- Trigger system actions (Back, Home, Recents, Notifications)
- Display live toast messages
- Seamless auto-fallback to HTTP REST (Port 8080) if WebSocket server (Port 8000) is offline

Usage:
    python send_cmd.py apps [filter] [--system] [--json]
    python send_cmd.py open <appName | packageName | url>
    python send_cmd.py inspect [delay_sec]
    python send_cmd.py click <x> <y>
    python send_cmd.py tap <label>
    python send_cmd.py swipe <x1> <y1> <x2> <y2> [duration_ms]
    python send_cmd.py next
    python send_cmd.py back | home | recents | notifications
    python send_cmd.py toast <text>
"""

import asyncio
import json
import os
import re
import sys
import time
import urllib.error
import urllib.parse
import urllib.request

WS_SERVER_URL = os.environ.get("AURA_WS_URL", "ws://127.0.0.1:8000/ws")
HTTP_SERVER_URL = os.environ.get("AURA_HTTP_URL", "http://127.0.0.1:8080")

try:
    import websockets
    HAS_WEBSOCKETS = True
except ImportError:
    HAS_WEBSOCKETS = False


def parse_center(bounds_str):
    try:
        nums = [int(n) for n in re.findall(r'\d+', bounds_str)]
        if len(nums) == 4:
            return (nums[0] + nums[2]) // 2, (nums[1] + nums[3]) // 2
    except Exception:
        pass
    return None


def print_tree(nodes, depth=0, find_text=None, matched_targets=None):
    if not isinstance(nodes, list):
        nodes = [nodes]

    for node in nodes:
        indent = "  " * depth
        class_name = node.get("className", "").split(".")[-1]
        text = node.get("text", "") or ""
        desc = node.get("contentDescription", "") or ""
        clickable = node.get("isClickable", False)
        bounds = node.get("boundsInScreen", "")

        center = parse_center(bounds)
        cx, cy = center if center else (0, 0)
        coord_str = f" -> click {cx} {cy}" if (clickable and center) else ""

        if find_text and matched_targets is not None:
            clean_search = find_text.strip().lower()
            if (clean_search in text.lower() or clean_search in desc.lower()) and center:
                matched_targets.append((text or desc or class_name, cx, cy))

        info = []
        if text:
            info.append(f'"{text}"')
        if desc and desc != text:
            info.append(f'desc="{desc}"')
        if not info and clickable:
            info.append("(clickable area)")

        label = " ".join(info) if info else ""
        marker = "•" if (clickable or text or desc) else "·"
        print(f"{indent}{marker} [{class_name}] {label}{coord_str}")

        children = node.get("children", [])
        if children:
            print_tree(children, depth + 1, find_text, matched_targets)


# ---------------------------------------------------------------------------
# HTTP REST Fallback Helpers (Zero external dependencies needed)
# ---------------------------------------------------------------------------

def http_get(path_and_query):
    url = f"{HTTP_SERVER_URL}{path_and_query}"
    req = urllib.request.Request(url, headers={"User-Agent": "AuraTermuxCLI/1.0"})
    try:
        with urllib.request.urlopen(req, timeout=4.0) as resp:
            data = resp.read().decode("utf-8")
            return json.loads(data)
    except Exception as e:
        return {"success": False, "error": str(e)}


def http_post(endpoint, payload):
    url = f"{HTTP_SERVER_URL}{endpoint}"
    data_bytes = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(
        url,
        data=data_bytes,
        headers={"Content-Type": "application/json", "User-Agent": "AuraTermuxCLI/1.0"}
    )
    try:
        with urllib.request.urlopen(req, timeout=4.0) as resp:
            data = resp.read().decode("utf-8")
            return json.loads(data)
    except Exception as e:
        return {"success": False, "error": str(e)}


# ---------------------------------------------------------------------------
# App Listing & Formatting
# ---------------------------------------------------------------------------

def display_apps(apps_list, filter_query="", as_json=False):
    if as_json:
        print(json.dumps(apps_list, indent=2))
        return

    if not apps_list:
        if filter_query:
            print(f"\n[!] No installed applications found matching '{filter_query}'.")
            print("    Try running without a filter: python send_cmd.py apps")
        else:
            print("\n[!] No installed applications found.")
        return

    print("\n" + "=" * 80)
    title = f" INSTALLED APPLICATIONS ({len(apps_list)} found)"
    if filter_query:
        title += f" [Filter: '{filter_query}']"
    print(title)
    print("=" * 80)
    print(f" {'#':<4} {'APP NAME':<28} {'PACKAGE NAME':<34} {'TYPE':<8}")
    print("-" * 80)

    for idx, app in enumerate(apps_list, start=1):
        name = app.get("appName", "Unknown")[:26]
        pkg = app.get("packageName", "")[:33]
        is_sys = app.get("isSystemApp", False)
        app_type = "[System]" if is_sys else "[User]"
        print(f" {idx:<4} {name:<28} {pkg:<34} {app_type:<8}")

    print("=" * 80)
    print("💡 Tip: To launch an app, run:")
    print("   python send_cmd.py open <appName | packageName | url>")
    print("   Example: python send_cmd.py open Termux\n")


# ---------------------------------------------------------------------------
# App List & Launch Execution (with automatic WebSocket -> HTTP fallback)
# ---------------------------------------------------------------------------

async def execute_list_apps(include_system=False, filter_query="", as_json=False, force_http=False):
    # If force HTTP or no websockets library, use HTTP directly
    if force_http or not HAS_WEBSOCKETS:
        return run_http_list_apps(include_system, filter_query, as_json)

    # Try WebSocket first
    now_ms = int(time.time() * 1000)
    req_id = "apps-" + str(now_ms)
    packet = {
        "type": "APP_LIST",
        "timestamp": now_ms,
        "sessionId": "cli-" + str(now_ms),
        "requestId": req_id,
        "includeSystem": include_system
    }

    try:
        async with websockets.connect(WS_SERVER_URL, open_timeout=2.0) as ws:
            # Drain server hello
            try:
                await asyncio.wait_for(ws.recv(), timeout=0.8)
            except Exception:
                pass

            await ws.send(json.dumps(packet))

            # Wait for APP_LIST_RESULT
            while True:
                msg = await asyncio.wait_for(ws.recv(), timeout=6.0)
                data = json.loads(msg)
                if data.get("type") == "APP_LIST_RESULT" or data.get("requestId") == req_id:
                    apps = data.get("apps", [])
                    if filter_query:
                        q = filter_query.lower()
                        apps = [a for a in apps if q in a.get("appName", "").lower() or q in a.get("packageName", "").lower()]
                    display_apps(apps, filter_query, as_json)
                    return True

    except (ConnectionRefusedError, OSError, asyncio.TimeoutError):
        # Fall back gracefully to HTTP REST server on port 8080
        return run_http_list_apps(include_system, filter_query, as_json)
    except Exception as e:
        print(f"[!] WebSocket error: {e}. Falling back to HTTP REST...")
        return run_http_list_apps(include_system, filter_query, as_json)


def run_http_list_apps(include_system=False, filter_query="", as_json=False):
    params = []
    if include_system:
        params.append("includeSystem=true")
    if filter_query:
        params.append(f"filter={urllib.parse.quote(filter_query)}")
    q_str = "?" + "&".join(params) if params else ""

    res = http_get(f"/api/app/list{q_str}")
    if res.get("success", False):
        apps = res.get("apps", [])
        if filter_query and not q_str:
            q = filter_query.lower()
            apps = [a for a in apps if q in a.get("appName", "").lower() or q in a.get("packageName", "").lower()]
        display_apps(apps, filter_query, as_json)
        return True
    else:
        err = res.get("error", "Unknown error")
        print(f"[ERROR] Could not fetch apps via HTTP: {err}")
        print("Ensure Aura is running on the device (HTTP REST active on port 8080).")
        return False


async def execute_launch_app(target, force_http=False):
    clean_target = target.strip()
    is_url = clean_target.startswith(("http://", "https://", "www."))

    # If force HTTP or no websockets library, use HTTP directly
    if force_http or not HAS_WEBSOCKETS:
        return run_http_launch_app(clean_target, is_url)

    # Try WebSocket first
    now_ms = int(time.time() * 1000)
    req_id = "launch-" + str(now_ms)
    packet = {
        "type": "APP_LAUNCH",
        "timestamp": now_ms,
        "sessionId": "cli-" + str(now_ms),
        "requestId": req_id,
        "packageName": clean_target if not is_url else None,
        "url": clean_target if is_url else None
    }

    try:
        async with websockets.connect(WS_SERVER_URL, open_timeout=2.0) as ws:
            # Drain server hello
            try:
                await asyncio.wait_for(ws.recv(), timeout=0.8)
            except Exception:
                pass

            await ws.send(json.dumps(packet))

            # Wait for APP_LAUNCH_RESULT
            while True:
                msg = await asyncio.wait_for(ws.recv(), timeout=5.0)
                data = json.loads(msg)
                if data.get("type") == "APP_LAUNCH_RESULT" or data.get("requestId") == req_id:
                    success = data.get("success", False)
                    launched = data.get("launchedTarget") or clean_target
                    if success:
                        print(f"✓ Successfully launched: '{launched}'")
                    else:
                        err = data.get("errorMessage", "Target not found or launch failed")
                        print(f"✗ Failed to launch '{clean_target}': {err}")
                        print("  💡 Run 'python send_cmd.py apps' to view installed applications.")
                    return success

    except (ConnectionRefusedError, OSError, asyncio.TimeoutError):
        # Fall back gracefully to HTTP REST server on port 8080
        return run_http_launch_app(clean_target, is_url)
    except Exception as e:
        print(f"[!] WebSocket error: {e}. Falling back to HTTP REST...")
        return run_http_launch_app(clean_target, is_url)


def run_http_launch_app(clean_target, is_url):
    payload = {
        "packageName": clean_target if not is_url else None,
        "url": clean_target if is_url else None
    }
    res = http_post("/api/app/launch", payload)
    if res.get("success", False):
        target_name = res.get("target") or clean_target
        print(f"✓ Successfully launched: '{target_name}'")
        return True
    else:
        err = res.get("error", "Target not found or launch failed")
        print(f"✗ Failed to launch '{clean_target}': {err}")
        print("  💡 Run 'python send_cmd.py apps' to view installed applications.")
        return False


# ---------------------------------------------------------------------------
# AeroShare Peer-to-Peer File Transfer & Local Device Discovery
# ---------------------------------------------------------------------------

def execute_devices(as_json=False):
    res = http_get("/api/share/devices")
    if as_json:
        print(json.dumps(res, indent=2))
        return
    if not res.get("success", False):
        print(f"[ERROR] Could not fetch devices: {res.get('error', 'Unknown')}")
        return

    local_name = res.get("localDeviceName", "Android Device")
    local_ip = res.get("localIp", "Unknown")
    is_radar = res.get("isRadarActive", True)
    devices = res.get("devices", [])

    print("\n" + "=" * 80)
    print(f" AEROSHARE LOCAL RADAR & PEER DISCOVERY")
    print(f" Local Device: {local_name} ({local_ip}) | Radar: {'[ON - Scanning]' if is_radar else '[OFF]'}")
    print("=" * 80)
    if not devices:
        print(" [!] No nearby AeroShare peers discovered yet.")
        print("     • Ensure devices are connected to the same Wi-Fi or Hotspot.")
        print("     • You can manually beam to any device IP via: python send_cmd.py share <file> <IP>")
    else:
        print(f" {'#':<4} {'DEVICE NAME':<28} {'IP ADDRESS':<18} {'PORT':<8} {'TYPE':<10} {'SIGNAL':<8}")
        print("-" * 80)
        for idx, dev in enumerate(devices, start=1):
            name = dev.get("name", "Peer")[:26]
            ip = dev.get("ip", "")[:16]
            port = dev.get("port", 8080)
            dtype = dev.get("deviceType", "PHONE")[:8]
            rssi = f"{dev.get('rssi', -50)}dBm"
            print(f" {idx:<4} {name:<28} {ip:<18} {port:<8} {dtype:<10} {rssi:<8}")
    print("=" * 80 + "\n")


def execute_share(target_input, peer_ip="", as_json=False):
    if not target_input:
        print("[ERROR] Please specify a file path or text snippet to share.")
        print("Usage: python send_cmd.py share <filePath | text> [targetDeviceIp]")
        return

    is_file = os.path.exists(target_input) and os.path.isfile(target_input)
    payload = {}
    if is_file:
        payload["filePath"] = os.path.abspath(target_input)
    else:
        payload["text"] = target_input

    if peer_ip:
        payload["ip"] = peer_ip

    res = http_post("/api/share/send", payload)
    if as_json:
        print(json.dumps(res, indent=2))
        return

    if res.get("success", False):
        if is_file:
            print(f"✓ Started AeroShare transfer of '{res.get('fileName')}' ({res.get('sizeBytes', 0)} bytes)")
            print(f"  Transfer ID : {res.get('transferId')}")
            print(f"  Target Peer : {res.get('targetIp')}")
            print("  Run 'python send_cmd.py transfers' to inspect live progress.")
        else:
            print(f"✓ Sent text snippet to {res.get('targetIp')}: \"{res.get('text')}\"")
    else:
        print(f"✗ Failed to initiate transfer: {res.get('error', 'Unknown error')}")


def execute_transfers(as_json=False):
    res = http_get("/api/share/transfers")
    if as_json:
        print(json.dumps(res, indent=2))
        return
    transfers = res.get("transfers", [])
    print("\n" + "=" * 80)
    print(f" AEROSHARE ACTIVE TRANSFERS ({len(transfers)} active)")
    print("=" * 80)
    if not transfers:
        print(" No active transfers currently running.")
    else:
        for tx in transfers:
            fn = tx.get("fileName", "file")
            pct = tx.get("progressPct", 0)
            status = tx.get("status", "TRANSFERRING")
            speed = tx.get("speedBytesPerSec", 0) / (1024 * 1024)
            eta = tx.get("etaSeconds", 0)
            direction = tx.get("direction", "SEND")
            peer = tx.get("peerName", tx.get("peerIp", "Peer"))
            tx_id = tx.get("id", "")
            bar_len = 20
            filled = int(bar_len * pct / 100)
            bar = "█" * filled + "░" * (bar_len - filled)
            print(f" [{direction}] {fn} -> {peer}")
            print(f"   [{bar}] {pct}% | {speed:.2f} MB/s | ETA: {eta}s | Status: {status} | ID: {tx_id}")
    print("=" * 80 + "\n")


def execute_history(as_json=False):
    res = http_get("/api/share/history")
    if as_json:
        print(json.dumps(res, indent=2))
        return
    history = res.get("history", [])
    print("\n" + "=" * 80)
    print(f" AEROSHARE TRANSFER HISTORY ({len(history)} items)")
    print("=" * 80)
    if not history:
        print(" No completed transfers recorded.")
    else:
        print(f" {'FILE NAME':<30} {'STATUS':<12} {'DIR':<8} {'PEER':<20}")
        print("-" * 80)
        for item in history[:20]:
            fn = item.get("fileName", "file")[:28]
            status = item.get("status", "DONE")[:10]
            direction = item.get("direction", "SEND")[:6]
            peer = item.get("peerName", "Peer")[:18]
            print(f" {fn:<30} {status:<12} {direction:<8} {peer:<20}")
    print("=" * 80 + "\n")


def execute_cancel(transfer_id):
    if not transfer_id:
        print("[ERROR] Missing transfer ID to cancel.")
        return
    res = http_post("/api/share/cancel", {"id": transfer_id})
    if res.get("success", False):
        print(f"✓ Cancelled transfer: {transfer_id}")
    else:
        print(f"✗ Could not cancel transfer: {transfer_id}")


def execute_clip(text=None, as_json=False):
    if text:
        res = http_post("/api/share/clip", {"text": text})
        if as_json:
            print(json.dumps(res, indent=2))
        else:
            print(f"✓ Beamed clipboard snippet: \"{text}\"")
    else:
        res = http_get("/api/share/clip")
        if as_json:
            print(json.dumps(res, indent=2))
        else:
            clip_text = res.get("clipboardText", "")
            print(f"Clipboard Content: {clip_text}")


def execute_radar(enable=None, as_json=False):
    payload = {}
    if enable is not None:
        payload["enabled"] = enable
    res = http_post("/api/share/radar", payload)
    if as_json:
        print(json.dumps(res, indent=2))
    else:
        status_str = "ACTIVE (Scanning)" if res.get("isRadarActive", True) else "PAUSED"
        print(f"✓ AeroShare Radar is now: {status_str}")


# ---------------------------------------------------------------------------
# Main CLI Router
# ---------------------------------------------------------------------------

def print_help():
    print("""
================================================================================
  Aura Android & Termux Automation CLI (send_cmd.py)
================================================================================

AEROSHARE P2P FILE TRANSFER & RADAR:
  python send_cmd.py devices                   # Discover nearby AeroShare peers
  python send_cmd.py share <file|text> [ip]    # Send file or text to device
  python send_cmd.py transfers                 # View live transfer progress & speeds
  python send_cmd.py history                   # View completed transfer history
  python send_cmd.py cancel <transfer_id>      # Cancel an active file transfer
  python send_cmd.py clip [text]               # Read or beam shared clipboard
  python send_cmd.py radar [on|off]            # Toggle background discovery radar

APPLICATION CONTROLS:
  python send_cmd.py apps [filter] [--system] [--json]
      List installed applications.
      Examples:
        python send_cmd.py apps                     # List user apps
        python send_cmd.py apps --system            # Include system apps
        python send_cmd.py apps termux              # Search for 'termux'
        python send_cmd.py apps --json              # Output as JSON

  python send_cmd.py open <app_name | packageName | url>
      Launch an app by friendly name, package name, or open a web URL.
      Aliases: launch, run, start
      Examples:
        python send_cmd.py open Termux              # Launch by name
        python send_cmd.py open YouTube             # Case-insensitive
        python send_cmd.py open com.android.chrome  # Launch by package ID
        python send_cmd.py open https://github.com  # Open in browser

SCREEN INSPECTION & GESTURES:
  python send_cmd.py inspect [delay_sec]
      Scan foreground UI hierarchy and print interactive elements with click bounds.
      Example: python send_cmd.py inspect 3

  python send_cmd.py tap <text>
      Find a UI element matching visible text or content description and tap it.
      Example: python send_cmd.py tap Settings

  python send_cmd.py click <x> <y>
      Tap exact screen coordinates.
      Example: python send_cmd.py click 540 1200

  python send_cmd.py swipe <x1> <y1> <x2> <y2> [duration_ms]
      Perform drag or swipe gesture.
      Example: python send_cmd.py swipe 500 1500 500 300 200

  python send_cmd.py next
      Scroll upward to the next post, video, or reel.

SYSTEM HARDWARE NAVIGATION:
  python send_cmd.py back            # Trigger Android Back key
  python send_cmd.py home            # Trigger Android Home key
  python send_cmd.py recents         # Open Recent Apps switcher
  python send_cmd.py notifications   # Pull down notification drawer

MESSAGING & TOASTS:
  python send_cmd.py toast <text>    # Display custom toast message on device
  python send_cmd.py <prompt text>   # Stream text / AI prompt to phone

FLAGS:
  --http     Force direct HTTP REST execution (port 8080) instead of WebSocket.
  --system   Include system apps in listing.
  --json     Output raw JSON format.
================================================================================
""")


async def main():
    raw_args = sys.argv[1:]
    if not raw_args or raw_args[0] in ["-h", "--help", "help"]:
        print_help()
        return

    # Extract global flags
    force_http = "--http" in raw_args
    include_system = "--system" in raw_args or "-s" in raw_args
    as_json = "--json" in raw_args

    args = [a for a in raw_args if a not in ["--http", "--system", "-s", "--json"]]
    if not args:
        print_help()
        return

    cmd = args[0].lower()

    # AeroShare P2P & File Sharing Controls
    if cmd in ["devices", "peers", "nearby"]:
        execute_devices(as_json=as_json)
        return

    if cmd in ["share", "send"]:
        if len(args) < 2:
            print("[ERROR] Missing file path or text to share.")
            print("Usage: python send_cmd.py share <filePath | text> [targetDeviceIp]")
            return
        target_input = args[1]
        peer_ip = args[2] if len(args) > 2 else ""
        execute_share(target_input, peer_ip, as_json=as_json)
        return

    if cmd in ["transfers", "tx"]:
        execute_transfers(as_json=as_json)
        return

    if cmd in ["history", "transfers-history"]:
        execute_history(as_json=as_json)
        return

    if cmd in ["cancel", "abort"]:
        if len(args) < 2:
            print("[ERROR] Missing transfer ID to cancel.")
            print("Usage: python send_cmd.py cancel <transferId>")
            return
        execute_cancel(args[1])
        return

    if cmd in ["clip", "clipboard"]:
        text_arg = " ".join(args[1:]) if len(args) > 1 else None
        execute_clip(text_arg, as_json=as_json)
        return

    if cmd in ["radar"]:
        enable_arg = None
        if len(args) > 1:
            enable_arg = args[1].lower() in ["on", "true", "start", "enable"]
        execute_radar(enable_arg, as_json=as_json)
        return

    # 1. LIST APPS: apps, list-apps, list_apps, list, ls
    if cmd in ["apps", "list-apps", "list_apps", "list", "ls"]:
        filter_query = " ".join(args[1:]) if len(args) > 1 else ""
        await execute_list_apps(include_system=include_system, filter_query=filter_query, as_json=as_json, force_http=force_http)
        return

    # 2. OPEN / LAUNCH APPS: open, launch, run, start
    if cmd in ["open", "launch", "run", "start"]:
        if len(args) < 2:
            print("[ERROR] Missing app name, package name, or URL.")
            print("Usage: python send_cmd.py open <appName | packageName | url>")
            return
        target = " ".join(args[1:])
        await execute_launch_app(target, force_http=force_http)
        return

    # Check for websockets for gesture/inspect operations
    if not HAS_WEBSOCKETS:
        print("[ERROR] The 'websockets' library is required for real-time gestures & inspection.")
        print("Install via: pip install websockets")
        print("\nNote: 'apps' and 'open' commands work without websockets via HTTP REST!")
        return

    now_ms = int(time.time() * 1000)

    try:
        async with websockets.connect(WS_SERVER_URL) as ws:
            # Drain initial server HELLO
            try:
                await asyncio.wait_for(ws.recv(), timeout=1.0)
            except asyncio.TimeoutError:
                pass

            # 3. SYSTEM HARDWARE GESTURES (Back, Home, Recents, Notifications)
            if cmd in ["back", "home", "recents", "notifications"]:
                packet = {
                    "type": "ACCESSIBILITY_GESTURE",
                    "timestamp": now_ms,
                    "sessionId": "cli-" + str(now_ms),
                    "gestureId": f"{cmd}-{now_ms}",
                    "gestureType": cmd.upper(),
                    "startX": 0.0,
                    "startY": 0.0,
                    "durationMs": 50
                }
                await ws.send(json.dumps(packet))
                print(f"Dispatched system action: {cmd.upper()}")

            # 4. INSPECT SCREEN UI
            elif cmd == "inspect":
                delay = int(args[1]) if len(args) > 1 and args[1].isdigit() else 0
                if delay > 0:
                    print(f"Switch to target app! Inspecting in {delay}s...")
                    for i in range(delay, 0, -1):
                        print(f" {i}...", end="", flush=True)
                        await asyncio.sleep(1)
                    print(" Inspecting!")

                packet = {
                    "type": "ACCESSIBILITY_INSPECT",
                    "timestamp": now_ms,
                    "sessionId": "cli-" + str(now_ms),
                    "target": "active_window"
                }
                print("Sent ACCESSIBILITY_INSPECT -> Waiting for screen nodes...")
                await ws.send(json.dumps(packet))

                while True:
                    msg = await asyncio.wait_for(ws.recv(), timeout=8.0)
                    data = json.loads(msg)
                    if data.get("type") == "ACCESSIBILITY_INSPECT_RESULT":
                        nodes = data.get("nodes", [])
                        print("\n" + "=" * 60)
                        print(f" PHONE SCREEN UI MAP ({len(nodes)} root node(s)):")
                        print("=" * 60)
                        print_tree(nodes)
                        print("=" * 60 + "\n")
                        break

            # 5. TAP BY LABEL
            elif cmd == "tap" and len(args) >= 2:
                target_label = " ".join(args[1:])
                packet = {
                    "type": "ACCESSIBILITY_INSPECT",
                    "timestamp": now_ms,
                    "sessionId": "cli-" + str(now_ms),
                    "target": "active_window"
                }
                print(f"Searching screen for '{target_label}'...")
                await ws.send(json.dumps(packet))

                matched_targets = []
                while True:
                    msg = await asyncio.wait_for(ws.recv(), timeout=8.0)
                    data = json.loads(msg)
                    if data.get("type") == "ACCESSIBILITY_INSPECT_RESULT":
                        nodes = data.get("nodes", [])
                        print_tree(nodes, depth=0, find_text=target_label, matched_targets=matched_targets)
                        break

                if matched_targets:
                    found_name, tx, ty = matched_targets[0]
                    click_packet = {
                        "type": "ACCESSIBILITY_GESTURE",
                        "timestamp": now_ms,
                        "sessionId": "cli-" + str(now_ms),
                        "gestureId": f"click-{now_ms}",
                        "gestureType": "CLICK",
                        "action": "CLICK",
                        "startX": float(tx),
                        "startY": float(ty),
                        "x": int(tx),
                        "y": int(ty),
                        "durationMs": 100
                    }
                    await ws.send(json.dumps(click_packet))
                    print(f"✓ Tapped '{found_name}' at ({tx}, {ty})")
                else:
                    print(f"✗ Could not find element matching '{target_label}' on screen.")
                    print("  Try running 'python send_cmd.py inspect' to see full UI structure.")

            # 6. CLICK COORDINATES
            elif cmd == "click" and len(args) >= 3:
                x, y = int(args[1]), int(args[2])
                packet = {
                    "type": "ACCESSIBILITY_GESTURE",
                    "timestamp": now_ms,
                    "sessionId": "cli-" + str(now_ms),
                    "gestureId": f"click-{now_ms}",
                    "gestureType": "CLICK",
                    "action": "CLICK",
                    "startX": float(x),
                    "startY": float(y),
                    "x": x,
                    "y": y,
                    "durationMs": 100
                }
                await ws.send(json.dumps(packet))
                print(f"Dispatched CLICK at ({x}, {y})")

            # 7. SWIPE
            elif cmd == "swipe" and len(args) >= 5:
                x1, y1 = int(args[1]), int(args[2])
                x2, y2 = int(args[3]), int(args[4])
                dur = int(args[5]) if len(args) > 5 else 300
                packet = {
                    "type": "ACCESSIBILITY_GESTURE",
                    "timestamp": now_ms,
                    "sessionId": "cli-" + str(now_ms),
                    "gestureId": f"swipe-{now_ms}",
                    "gestureType": "SWIPE",
                    "action": "SWIPE",
                    "startX": float(x1),
                    "startY": float(y1),
                    "endX": float(x2),
                    "endY": float(y2),
                    "x": x1,
                    "y": y1,
                    "durationMs": dur
                }
                await ws.send(json.dumps(packet))
                print(f"Dispatched SWIPE from ({x1}, {y1}) to ({x2}, {y2}) [{dur}ms]")

            # 8. NEXT (REELS / SCROLL)
            elif cmd == "next":
                packet = {
                    "type": "ACCESSIBILITY_GESTURE",
                    "timestamp": now_ms,
                    "sessionId": "cli-" + str(now_ms),
                    "gestureId": f"next-{now_ms}",
                    "gestureType": "SWIPE",
                    "action": "SWIPE",
                    "startX": 500.0,
                    "startY": 1400.0,
                    "endX": 500.0,
                    "endY": 300.0,
                    "durationMs": 250
                }
                await ws.send(json.dumps(packet))
                print("Dispatched scroll to next item")

            # 9. TOAST
            elif cmd == "toast" and len(args) >= 2:
                msg = " ".join(args[1:])
                packet = {
                    "type": "AI_STREAM",
                    "timestamp": now_ms,
                    "sessionId": "cli-" + str(now_ms),
                    "textChunk": msg,
                    "isFinal": True
                }
                await ws.send(json.dumps(packet))
                print(f"Dispatched toast: '{msg}'")

            # 10. ARBITRARY TEXT / AI PROMPT
            else:
                prompt_text = " ".join(args)
                packet = {
                    "type": "AI_STREAM",
                    "timestamp": now_ms,
                    "sessionId": "cli-" + str(now_ms),
                    "textChunk": prompt_text,
                    "isFinal": True
                }
                await ws.send(json.dumps(packet))
                print(f"Dispatched message: '{prompt_text}'")

    except ConnectionRefusedError:
        print(f"[!] Could not connect to WebSocket at {WS_SERVER_URL}.")
        print("    If Termux relay is offline, start it with: python mock_server.py")
        print("    Or for app controls, they work automatically with: python send_cmd.py apps")
    except Exception as e:
        print(f"[ERROR] {type(e).__name__}: {e}")


if __name__ == "__main__":
    asyncio.run(main())
