#!/usr/bin/env python3
"""
Termux & proot/Ubuntu WebSocket Relay Server (ws_relay.py)
Binds to 127.0.0.1:8000 and transparently relays messages between ACAgent (proot) and the Aura Android app.

Supported Message Types:
  - HELLO, PING / PONG
  - AI_STREAM, AI_STREAM_RESULT
  - ACCESSIBILITY_GESTURE, ACCESSIBILITY_INSPECT, ACCESSIBILITY_INSPECT_RESULT
  - APP_LIST, APP_LAUNCH, APP_LIST_RESULT, APP_LAUNCH_RESULT
  - AUDIO_STREAM, AUDIO_END

Requirements:
  pip install websockets
"""

import sys
import os

# Import implementation from mock_server
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from mock_server import *

if __name__ == "__main__":
    import asyncio
    print("==================================================")
    print("  ACAgent & Termux WebSocket Relay Server Active")
    print(f"  Listening on ws://{HOST}:{PORT}")
    print("==================================================")
    
    # Run server using same entrypoint as mock_server
    try:
        if hasattr(websockets, "serve"):
            start_server = websockets.serve(
                ws_handler,
                HOST,
                PORT,
                process_request=handle_http_or_ws_request
            )
            asyncio.get_event_loop().run_until_complete(start_server)
            asyncio.get_event_loop().run_forever()
    except KeyboardInterrupt:
        print("\n[STOPPED] Relay server stopped.")
