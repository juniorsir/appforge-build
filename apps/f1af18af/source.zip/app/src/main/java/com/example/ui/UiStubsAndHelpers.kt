package com.example.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.DownloadEntity

val Int.responsiveSp: TextUnit
    @Composable get() = this.sp

val Float.responsiveSp: TextUnit
    @Composable get() = this.sp

val Double.responsiveSp: TextUnit
    @Composable get() = this.sp

@Composable
fun responsiveSp(compact: Float, expanded: Float): TextUnit = compact.sp

@Composable
fun responsiveSp(compact: Int, expanded: Int): TextUnit = compact.sp

data class CarouselMediaItem(
    val url: String = "",
    val title: String = "",
    val thumbnail: String = ""
)

fun isAudioFormat(fmt: Any?): Boolean {
    if (fmt == null) return false
    val str = fmt.toString().lowercase()
    return str.contains("audio") || str.contains("mp3") || str.contains("m4a") || str.contains("aac") || str.contains("opus")
}

fun openInstagramProfile(context: android.content.Context, profileUrl: String = "") {
    try {
        val url = if (profileUrl.isNotBlank()) profileUrl else "https://instagram.com"
        val intent = android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(url))
        intent.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
    } catch (_: Exception) {}
}

fun calculateVideoColorMatrix(
    brightness: Float = 0f,
    contrast: Float = 1f,
    saturation: Float = 1f,
    gamma: Float = 1f,
    sharpness: Float = 0f,
    temperature: Float = 0f,
    highlights: Float = 0f,
    shadows: Float = 0f,
    vibrance: Float = 0f,
    tint: Float = 0f
): android.graphics.ColorMatrix {
    return android.graphics.ColorMatrix()
}

class ExoPlayerAudioFxEngine(exoPlayer: Any? = null, viewModel: Any? = null) {
    fun release() {}
}

@Composable
fun FluidIncognitoButton(
    isIncognitoMode: Boolean = false,
    isIncognito: Boolean = false,
    onToggle: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    IconButton(onClick = onToggle, modifier = modifier) {
        Icon(
            imageVector = if (isIncognitoMode || isIncognito) Icons.Default.VisibilityOff else Icons.Default.Visibility,
            contentDescription = "Incognito Mode",
            tint = if (isIncognitoMode || isIncognito) MaterialTheme.colorScheme.primary else Color.Gray
        )
    }
}

@Composable
fun InstagramIcon(modifier: Modifier = Modifier, useGradient: Boolean = false) {
    Icon(imageVector = Icons.Default.Share, contentDescription = "Instagram", modifier = modifier)
}

@Composable
fun LiquidGlassIcon(
    imageVector: ImageVector = Icons.Default.Star,
    contentDescription: String? = null,
    modifier: Modifier = Modifier,
    tint: Color = Color.Unspecified,
    isSelected: Boolean = false,
    containerSize: Dp = 40.dp,
    size: Dp = 24.dp,
    onClick: () -> Unit = {}
) {
    Icon(imageVector = imageVector, contentDescription = contentDescription, modifier = modifier, tint = tint)
}

@Composable
fun CrazyAnimationOrb(modifier: Modifier = Modifier) {
    Box(modifier = modifier)
}

@Composable
fun CoverflowCarousel(
    items: List<CarouselMediaItem> = emptyList(),
    onSelect: (CarouselMediaItem) -> Unit = {},
    onDownload: (CarouselMediaItem) -> Unit = {},
    onPlayClick: (CarouselMediaItem) -> Unit = {},
    onDownloadClick: (CarouselMediaItem) -> Unit = {}
) {
    Column {
        items.forEach { item ->
            TextButton(onClick = { onPlayClick(item) }) {
                Text(item.title.ifBlank { item.url })
            }
        }
    }
}

@Composable
fun MediaTrimmerDialog(
    state: Any? = null,
    onUpdateRange: (Long, Long) -> Unit = { _, _ -> },
    onPreview: () -> Unit = {},
    onExport: () -> Unit = {},
    onCancelExport: () -> Unit = {},
    onOpenExported: (DownloadEntity) -> Unit = {},
    onShareExported: (String) -> Unit = {},
    onDismiss: () -> Unit = {}
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Media Trimmer") },
        text = { Text("Trim media segment") },
        confirmButton = { TextButton(onClick = onExport) { Text("Export") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
fun VideoCompressionDialog(
    state: Any? = null,
    onSelectPreset: ((String) -> Unit)? = null,
    onUpdateCustomOptions: ((Int, Int, Int, Int, Int) -> Unit)? = null,
    onCompress: (() -> Unit)? = null,
    onCancelCompress: (() -> Unit)? = null,
    onOpenCompressed: ((DownloadEntity) -> Unit)? = null,
    onShareCompressed: ((String) -> Unit)? = null,
    onCancel: (() -> Unit)? = null,
    onDismiss: () -> Unit = {}
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Video Compression") },
        text = { Text("Compress video resolution and bitrate") },
        confirmButton = { TextButton(onClick = { onCompress?.invoke() }) { Text("Compress") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
fun AudioFxStudioModal(viewModel: Any? = null, onDismiss: () -> Unit = {}) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Audio FX Studio") },
        text = { Text("Equalizer and audio processing effects") },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } }
    )
}

@Composable
fun BatchQueueManagerModal(viewModel: Any? = null, onDismiss: () -> Unit = {}) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Batch Download Queue") },
        text = { Text("Manage active download queue") },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } }
    )
}

@Composable
fun MetadataEditorModal(item: Any? = null, entity: Any? = null, viewModel: Any? = null, onDismiss: () -> Unit = {}) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Edit Metadata") },
        text = { Text("Modify title, artist, and tags") },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } }
    )
}

@Composable
fun DownloadSchedulerModal(
    entity: Any? = null,
    viewModel: Any? = null,
    videoTitle: String = "",
    videoUrl: String = "",
    formatQuality: String = "",
    formatExt: String = "",
    onDismiss: () -> Unit = {}
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Download Scheduler") },
        text = { Text("Schedule download execution time") },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } }
    )
}

@Composable
fun AddToPlaylistModal(
    item: Any? = null,
    entity: Any? = null,
    viewModel: Any? = null,
    onCreateNewRequest: () -> Unit = {},
    onDismiss: () -> Unit = {}
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add to Playlist") },
        text = { Text("Select target playlist") },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } }
    )
}

@Composable
fun CreatePlaylistModal(viewModel: Any? = null, onDismiss: () -> Unit = {}) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Create Playlist") },
        text = { Text("Enter playlist name") },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } }
    )
}

@Composable
fun TermsAndConditionsDialog(onDismiss: () -> Unit = {}) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Terms & Conditions") },
        text = { Text("Terms of Service details...") },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } }
    )
}

@Composable
fun PrivacyPolicyDialog(onDismiss: () -> Unit = {}) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Privacy Policy") },
        text = { Text("Privacy policy details...") },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } }
    )
}

@Composable
fun YouTubeBackgroundMiniPlayerBar(
    media: Any? = null,
    isPlaying: Boolean = false,
    currentPosMs: Long = 0,
    durationMs: Long = 0,
    onTogglePlay: () -> Unit = {},
    onSeekRelative: (Long) -> Unit = {},
    onOpenFullPlayer: () -> Unit = {},
    onClose: () -> Unit = {},
    modifier: Modifier = Modifier,
    onDismiss: () -> Unit = {}
) {
    Box(modifier = modifier.fillMaxWidth().height(48.dp)) {
        Text("Background Mini Player")
    }
}

@Composable
fun SleepTimerDialog(
    currentMinutes: Int = 0,
    currentSecondsRemaining: Int = 0,
    onSelectMinutes: (Int) -> Unit = {},
    onSetTimer: ((Int) -> Unit)? = null,
    onCancelTimer: (() -> Unit)? = null,
    onDismiss: () -> Unit = {}
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Sleep Timer") },
        text = { Text("Set playback sleep timer") },
        confirmButton = { TextButton(onClick = { onSelectMinutes(30) }) { Text("30 Min") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
