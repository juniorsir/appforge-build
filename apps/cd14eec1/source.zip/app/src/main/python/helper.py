import io
import sys
import traceback
import contextlib

# --- MONKEY PATCH FOR CHAQUOPY AssetPath LINTER COMPATIBILITY ---
try:
    import importlib
    for mod_name in ["chaquopy.import_override", "chaquopy.internal"]:
        try:
            mod = importlib.import_module(mod_name)
            AssetPath = getattr(mod, "AssetPath", None)
            if AssetPath:
                # Dynamically delegate str methods to string representation
                def make_delegate(name):
                    def delegate(self, *args, **kwargs):
                        s = str(self)
                        method = getattr(s, name, None)
                        if method:
                            mapped_args = [str(a) if isinstance(a, AssetPath) else a for a in args]
                            mapped_kwargs = {k: (str(v) if isinstance(v, AssetPath) else v) for k, v in kwargs.items()}
                            return method(*mapped_args, **mapped_kwargs)
                        if name == "__radd__":
                            return str(args[0]) + s
                        raise AttributeError(f"'AssetPath' object has no attribute '{name}'")
                    return delegate

                for name in dir(str):
                    if name.startswith("__") and name.endswith("__"):
                        if name in [
                            "__add__", "__radd__", "__contains__", "__eq__", "__ge__", "__gt__",
                            "__le__", "__lt__", "__ne__", "__len__", "__getitem__", "__hash__",
                            "__iter__"
                        ]:
                            if not hasattr(AssetPath, name):
                                setattr(AssetPath, name, make_delegate(name))
                    else:
                        if not hasattr(AssetPath, name):
                            setattr(AssetPath, name, make_delegate(name))

                # Implement path protocols for pathlib and os.path compatibility
                if not hasattr(AssetPath, "__fspath__"):
                    setattr(AssetPath, "__fspath__", lambda self: str(self))
                if not hasattr(AssetPath, "parent"):
                    setattr(AssetPath, "parent", property(lambda self: AssetPath(os.path.dirname(str(self)))))
                if not hasattr(AssetPath, "name"):
                    setattr(AssetPath, "name", property(lambda self: os.path.basename(str(self))))
        except Exception:
            pass
except Exception:
    pass
# -------------------------------------------------------------


if not hasattr(contextlib, 'redirect_stdin'):
    class RedirectStdin:
        def __init__(self, new_target):
            self._new_target = new_target
        def __enter__(self):
            self._old_target = sys.stdin
            sys.stdin = self._new_target
            return self._new_target
        def __exit__(self, exctype, excinst, exctb):
            sys.stdin = self._old_target
    contextlib.redirect_stdin = RedirectStdin

import urllib.request
import json
import zipfile
import tarfile
import os
import shutil
import subprocess

def _blocked(*args, **kwargs):
    import os
    import errno
    raise OSError(errno.EACCES, "Native subprocess call blocked in the High-Density Sandbox to enforce system stability. Use the integrated Python-based terminal for supported shell commands (ls, cat, cd, etc.).")

try:
    import _posixsubprocess
    # Aggressively patch everything that might lead to a crash
    for attr in ['fork_exec', 'posix_spawn', 'posix_spawnp', 'cloexec_pipe']:
        if hasattr(_posixsubprocess, attr): setattr(_posixsubprocess, attr, _blocked)
except ImportError:
    pass

# DummyPopen removed
if hasattr(os, 'fork'): os.fork = _blocked
if hasattr(os, 'spawnv'): os.spawnv = _blocked
if hasattr(os, 'posix_spawn'): os.posix_spawn = _blocked
if hasattr(os, 'posix_spawnp'): os.posix_spawnp = _blocked
if hasattr(os, 'system'): os.system = _blocked
if hasattr(os, '_exit'): os._exit = _blocked

persistent_scope = {}

def prune_conflicting_packages(site_packages_dir):
    if not site_packages_dir or not os.path.exists(site_packages_dir):
        return
    import shutil
    # List of import/folder names that are precompiled and pre-installed via Build/Gradle
    # and should NOT be shadowed by dynamic files in the user's running sandbox
    conflicting_folders = [
        'numpy', 'pandas', 'scipy', 'matplotlib', 'sklearn', 'scikit_learn',
        'requests', 'yt_dlp', 'bs4', 'beautifulsoup4', 'flask', 'urllib3', 'idna', 'certifi',
        'pydantic', 'pydantic_core', 'fastapi'
    ]
    try:
        for entry in os.listdir(site_packages_dir):
            entry_lower = entry.lower()
            is_conflict = False
            for conf in conflicting_folders:
                if entry_lower == conf:
                    is_conflict = True
                    break
                if (entry_lower.startswith(conf + "-") or entry_lower.startswith(conf.replace('_', '-') + "-")) and (entry_lower.endswith(".dist-info") or entry_lower.endswith(".egg-info")):
                    is_conflict = True
                    break
            
            if is_conflict:
                path = os.path.join(site_packages_dir, entry)
                try:
                    if os.path.isdir(path):
                        shutil.rmtree(path)
                    else:
                        os.remove(path)
                except Exception:
                    pass
    except Exception:
        pass

def run_code(code, site_packages_dir=None):
    if site_packages_dir:
        prune_conflicting_packages(site_packages_dir)
        if site_packages_dir not in sys.path:
            sys.path.append(site_packages_dir)
            
    # Dynamic patching of yt-dlp to support headless cloud sandbox fallback gracefully
    try:
        import yt_dlp
        if not hasattr(yt_dlp.YoutubeDL, '_patched_by_sandbox'):
            original_extract_info = yt_dlp.YoutubeDL.extract_info
            original_download = yt_dlp.YoutubeDL.download
            
            # Suppress specific JS Runtime deprecation warnings and missing runtime logs from yt-dlp output
            original_report_warning = yt_dlp.YoutubeDL.report_warning
            original_report_error = getattr(yt_dlp.YoutubeDL, 'report_error', None)
            original_to_stderr = yt_dlp.YoutubeDL.to_stderr
            original_to_screen = yt_dlp.YoutubeDL.to_screen
            
            def should_suppress(message):
                msg_str = str(message)
                return any(term in msg_str for term in [
                    "No supported JavaScript runtime",
                    "without a js runtime",
                    "js-runtimes",
                    "EJS",
                    "EJS-runtimes"
                ])
                
            def patched_report_warning(self, message, *args, **kwargs):
                if should_suppress(message):
                    return
                if original_report_warning:
                    try:
                        return original_report_warning(self, message, *args, **kwargs)
                    except Exception:
                        pass

            def patched_report_error(self, message, *args, **kwargs):
                if should_suppress(message):
                    return
                if original_report_error:
                    try:
                        return original_report_error(self, message, *args, **kwargs)
                    except Exception:
                        pass
                        
            def patched_to_stderr(self, message, *args, **kwargs):
                if should_suppress(message):
                    return
                if original_to_stderr:
                    try:
                        return original_to_stderr(self, message, *args, **kwargs)
                    except Exception:
                        pass
                        
            def patched_to_screen(self, message, *args, **kwargs):
                if should_suppress(message):
                    return
                if original_to_screen:
                    try:
                        return original_to_screen(self, message, *args, **kwargs)
                    except Exception:
                        pass

            yt_dlp.YoutubeDL.report_warning = patched_report_warning
            if original_report_error:
                yt_dlp.YoutubeDL.report_error = patched_report_error
            yt_dlp.YoutubeDL.to_stderr = patched_to_stderr
            yt_dlp.YoutubeDL.to_screen = patched_to_screen
            
            def patched_extract_info(self, url, *args, **kwargs):
                try:
                    return original_extract_info(self, url, *args, **kwargs)
                except Exception as e:
                    print(f"\n[YouTube Sandbox Note] Live query of {url} was blocked or video is unavailable.")
                    print(f"To ensure a seamless developer preview, the sandbox has supplied mock metadata.")
                    vid_id = "rwj2pPH1aMs"
                    if "v=" in url:
                        vid_id = url.split("v=")[1].split("&")[0]
                    elif "youtu.be/" in url:
                        vid_id = url.split("youtu.be/")[1].split("?")[0]
                        
                    return {
                        "id": vid_id,
                        "title": "Chaquopy Android Developer Guide - Deep Dive Study",
                        "duration": 482,
                        "view_count": 2154093,
                        "uploader": "Android Tech Channel",
                        "description": "Simulated description for the sandboxed YouTube URL.",
                        "url": url,
                        "formats": [{"url": "http://example.com/stream.mp4"}]
                    }
                    
            def patched_download(self, url_list, *args, **kwargs):
                try:
                    return original_download(self, url_list, *args, **kwargs)
                except Exception as e:
                    print(f"\n[YouTube Sandbox Note] Download of {url_list} fell back gracefully under emulator constraints.")
                    return 0
                    
            yt_dlp.YoutubeDL.extract_info = patched_extract_info
            yt_dlp.YoutubeDL.download = patched_download
            yt_dlp.YoutubeDL._patched_by_sandbox = True
    except Exception:
        pass
        
    global _persistent_cwd
    if _persistent_cwd:
        try:
            os.chdir(_persistent_cwd)
        except Exception:
            pass

    stdout_io = io.StringIO()
    stderr_io = io.StringIO()
    # Dummy stdin to prevent hanging
    class DummyStdin(io.StringIO):
        def read(self, *args, **kwargs): return ""
        def readline(self, *args, **kwargs): return "\n"
    dummy_stdin = DummyStdin()
    with contextlib.redirect_stdout(stdout_io), contextlib.redirect_stderr(stderr_io), contextlib.redirect_stdin(dummy_stdin):
        try:
            compiled_eval = None
            try:
                # Attempt to compile code as custom expression for clean eval
                compiled_eval = compile(code, '<string>', 'eval')
            except SyntaxError:
                pass
                
            if compiled_eval is not None:
                res = eval(compiled_eval, persistent_scope)
                if res is not None:
                    print(repr(res))
            else:
                exec(code, persistent_scope)
        except BaseException:
            stderr_io.write(traceback.format_exc())
            
    return [stdout_io.getvalue(), stderr_io.getvalue()]

def hoist_packages(src_dir, dest_dir):
    import os
    import shutil
    
    # Check if there's a unique top-level directory in src_dir (typical of source tar.gz/zip)
    try:
        entries = os.listdir(src_dir)
        entries = [e for e in entries if not e.startswith('.')]
        if len(entries) == 1 and os.path.isdir(os.path.join(src_dir, entries[0])):
            src_dir = os.path.join(src_dir, entries[0])
            entries = os.listdir(src_dir)
            
        # Check if there is a 'src' directory (src layout)
        if 'src' in entries and os.path.isdir(os.path.join(src_dir, 'src')):
            src_dir = os.path.join(src_dir, 'src')
            entries = os.listdir(src_dir)
            
        # Clear / copy entries to dest_dir
        for entry in entries:
            if entry in ['test', 'tests', 'testing', 'docs', 'example', 'examples', 'setup.py', 'setup.cfg']:
                continue
            src_path = os.path.join(src_dir, entry)
            dest_path = os.path.join(dest_dir, entry)
            try:
                if os.path.isdir(src_path):
                    if os.path.exists(dest_path):
                        shutil.rmtree(dest_path)
                    shutil.copytree(src_path, dest_path)
                else:
                    shutil.copy2(src_path, dest_path)
            except Exception:
                pass
    except Exception:
        pass

def deploy_simulated_package(pkg_name, install_dir):
    import os
    clean_name = pkg_name.strip().lower().replace('_', '-')
    print(f"[PIP] Intercepted binary-only package '{clean_name}'.")
    print(f"[PIP] Deploying High-Density Simulated Python compatibility layout for '{clean_name}'...")
    
    def write_file(path, content):
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            f.write(content)

    if clean_name == 'tensorflow':
        tf_dir = os.path.join(install_dir, "tensorflow")
        tf_init = """# Pure-Python Simulated TensorFlow Core
from . import keras
from . import random

__version__ = "2.16.1-android-sandbox"

class Tensor:
    def __init__(self, val, dtype="float32"):
        self.val = val
        self.shape = getattr(val, 'shape', ()) if hasattr(val, 'shape') else (len(val),) if isinstance(val, (list, tuple)) else ()
        self.dtype = dtype
    def __repr__(self):
        return f"<tf.Tensor: shape={self.shape}, dtype={self.dtype}, numpy={repr(self.val)}>"
    def numpy(self):
        import numpy as np
        return np.array(self.val)
    def __add__(self, other):
        o_val = other.val if isinstance(other, Tensor) else other
        return Tensor(self.val + o_val)
    def __mul__(self, other):
        o_val = other.val if isinstance(other, Tensor) else other
        return Tensor(self.val * o_val)

def constant(value, dtype="float32", name=None):
    return Tensor(value, dtype=dtype)

def Variable(initial_value, dtype="float32", trainable=True, name=None):
    return Tensor(initial_value, dtype=dtype)

def matmul(a, b):
    import numpy as np
    a_arr = a.numpy() if isinstance(a, Tensor) else np.array(a)
    b_arr = b.numpy() if isinstance(b, Tensor) else np.array(b)
    res = np.matmul(a_arr, b_arr)
    return Tensor(res.tolist())

class Random:
    def normal(self, shape, mean=0.0, stddev=1.0, dtype="float32", seed=None):
        import numpy as np
        return Tensor(np.random.normal(mean, stddev, shape), dtype=dtype)
    def uniform(self, shape, minval=0.0, maxval=1.0, dtype="float32", seed=None):
        import numpy as np
        return Tensor(np.random.uniform(minval, maxval, shape), dtype=dtype)

random = Random()
"""
        write_file(os.path.join(tf_dir, "__init__.py"), tf_init)

        # keras submodule
        write_file(os.path.join(tf_dir, "keras", "__init__.py"), """# tf.keras subsystem
from . import models
from . import layers
from . import datasets
from . import optimizers
""")

        # keras.models
        write_file(os.path.join(tf_dir, "keras", "models", "__init__.py"), """# tf.keras.models
class Sequential:
    def __init__(self, layers=None):
        self._layers = []
        if layers:
            for l in layers:
                self.add(l)
    def add(self, layer):
        self._layers.append(layer)
    def compile(self, optimizer="adam", loss="mse", metrics=None):
        print(f"[tf.keras] Model compiled successfully using '{optimizer}' optimizer and loss function '{loss}'.")
    def fit(self, x=None, y=None, epochs=1, batch_size=None, verbose=1):
        print(f"[tf.keras] Starting training simulation across {epochs} epochs on Android environment...")
        import time
        for epoch in range(1, epochs + 1):
            time.sleep(0.04)
            print(f"Epoch {epoch}/{epochs} - loss: {(0.92 / (epoch + 0.1)):.4f} - accuracy: {(0.50 + 0.45 * (epoch / epochs)):.4f}")
        print("[tf.keras] Training completed. Metrics saved in local compilation history.")
        return History()
    def summary(self):
        print("Model: 'sequential_sandbox_simulation'")
        print("_________________________________________________________________")
        print(" Layer (type)                Output Shape              Param #   ")
        print("=================================================================")
        print(" dense_1 (Dense)             (None, 64)                3200      ")
        print(" dense_2 (Dense)             (None, 10)                650       ")
        print("=================================================================")
        print("Total params: 3,850 (15.04 KB)")
        print("Trainable params: 3,850 (15.04 KB)")
        print("_________________________________________________________________")

class History:
    def __init__(self):
        self.history = {"loss": [0.45, 0.23, 0.11], "accuracy": [0.65, 0.88, 0.95]}
""")

        # keras.layers
        write_file(os.path.join(tf_dir, "keras", "layers", "__init__.py"), """# tf.keras.layers
class Dense:
    def __init__(self, units, activation=None, name=None):
        self.units = units
        self.activation = activation
    def __repr__(self):
        return f"<DenseLayer units={self.units} activation={self.activation}>"

class Conv2D:
    def __init__(self, filters, kernel_size, activation=None, name=None):
        self.filters = filters
        self.kernel_size = kernel_size
    def __repr__(self):
        return f"<Conv2DLayer filters={self.filters}>"

class Flatten:
    def __repr__(self):
        return "<FlattenLayer>"

class Dropout:
    def __init__(self, rate):
        self.rate = rate
""")

        # keras.datasets
        write_file(os.path.join(tf_dir, "keras", "datasets", "__init__.py"), """# tf.keras.datasets
class DatasetLoader:
    def load_data(self):
        import numpy as np
        print("[tf.keras.datasets] Loading simulated mock tensor data partition...")
        return (np.random.rand(100, 28, 28), np.random.randint(0, 10, 100)), \\
               (np.random.rand(20, 28, 28), np.random.randint(0, 10, 20))

mnist = DatasetLoader()
fashion_mnist = DatasetLoader()
cifar10 = DatasetLoader()
""")

        # keras.optimizers
        write_file(os.path.join(tf_dir, "keras", "optimizers", "__init__.py"), """# tf.keras.optimizers
def Adam(learning_rate=0.001):
    return "adam"
def SGD(learning_rate=0.01):
    return "sgd"
""")
        print("[PIP] Simulated tensorflow package deployed successfully.")

    elif clean_name in ['torch', 'pytorch']:
        torch_dir = os.path.join(install_dir, "torch")
        torch_init = """# Pure-Python Simulated PyTorch Core
import sys
from . import nn
from . import optim

__version__ = "2.2.1-android-sandbox"

class Tensor:
    def __init__(self, val, requires_grad=False):
        self.val = val
        self.requires_grad = requires_grad
        self.shape = getattr(val, 'shape', ()) if hasattr(val, 'shape') else (len(val),) if isinstance(val, (list, tuple)) else ()
    def __repr__(self):
        return f"tensor({repr(self.val)}, requires_grad={self.requires_grad}, device='cpu')"
    def numpy(self):
        import numpy as np
        return np.array(self.val)
    def backward(self):
        print("[PyTorch] Backward propagation call registered. Dynamic gradients assigned.")

def tensor(value, dtype=None, device=None, requires_grad=False):
    return Tensor(value, requires_grad=requires_grad)

def ones(shape, dtype=None, requires_grad=False):
    import numpy as np
    return Tensor(np.ones(shape), requires_grad=requires_grad)

def rand(shape, dtype=None, requires_grad=False):
    import numpy as np
    return Tensor(np.random.rand(*shape), requires_grad=requires_grad)
"""
        write_file(os.path.join(torch_dir, "__init__.py"), torch_init)

        # torch.nn
        write_file(os.path.join(torch_dir, "nn", "__init__.py"), """# torch.nn
class Module:
    def __init__(self):
        self._modules = {}
    def __call__(self, *args, **kwargs):
        from .. import Tensor
        return Tensor([0.05, 0.95])
    def parameters(self):
        from .. import Tensor
        return [Tensor([0.22, -0.45], requires_grad=True)]

class Linear(Module):
    def __init__(self, in_features, out_features, bias=True):
        super().__init__()
        self.in_features = in_features
        self.out_features = out_features

class Sequential(Module):
    def __init__(self, *args):
        super().__init__()
        self.layers = list(args)

def MSELoss():
    return lambda pred, target: 0.1245

def CrossEntropyLoss():
    return lambda pred, target: 1.054
""")

        # torch.optim
        write_file(os.path.join(torch_dir, "optim", "__init__.py"), """# torch.optim
class Optimizer:
    def __init__(self, params, lr=0.001):
        self.params = params
        self.lr = lr
    def zero_grad(self):
        pass
    def step(self):
        print("[PyTorch.optim] Optimizer SGD/Adam weight update step executed.")

class SGD(Optimizer):
    pass

class Adam(Optimizer):
    pass
""")
        if clean_name == 'pytorch':
            pytorch_init = "from torch import *"
            write_file(os.path.join(install_dir, "pytorch", "__init__.py"), pytorch_init)
        print("[PIP] Simulated torch package deployed successfully.")

    elif clean_name in ['cv2', 'opencv-python']:
        cv2_dir = os.path.join(install_dir, "cv2")
        cv2_init = """# Pure-Python Simulated OpenCV Core
__version__ = "4.9.0-android-sandbox"

def imread(filename, flags=1):
    import numpy as np
    print(f"[OpenCV Sandbox] Emulating loading image file: '{filename}'")
    return np.random.randint(0, 255, (224, 224, 3), dtype=np.uint8)

def imwrite(filename, img, params=None):
    print(f"[OpenCV Sandbox] Saved emulated composite matrix to: '{filename}' (shape structure: {getattr(img, 'shape', 'unknown')})")
    return True

def imshow(winname, mat):
    print(f"[OpenCV Sandbox Preview] Created graphic layout window '{winname}' displaying frame stream of shape {getattr(mat, 'shape', 'unknown')}")

def resize(src, dsize, fx=0, fy=0, interpolation=3):
    import numpy as np
    print(f"[OpenCV Sandbox] Scaled matrix resolution dynamically to width={dsize[0]} height={dsize[1]}")
    return np.random.randint(0, 255, (dsize[1], dsize[0], 3), dtype=np.uint8)

def cvtColor(src, code, dst=None, dstCn=0):
    print(f"[OpenCV Sandbox] Converted channels using color-space transformation ID {code}")
    return src

COLOR_BGR2GRAY = 6
COLOR_GRAY2BGR = 8
COLOR_BGR2RGB = 4
COLOR_RGB2BGR = 4
"""
        write_file(os.path.join(cv2_dir, "__init__.py"), cv2_init)
        print("[PIP] Simulated cv2 package deployed successfully.")

    elif clean_name == 'black':
        black_dir = os.path.join(install_dir, "black")
        black_init = """# Pure-Python Simulated Black Formatter
__version__ = "24.3.0"
"""
        write_file(os.path.join(black_dir, "__init__.py"), black_init)

        black_main = """# Pure-Python Simulated Black Entry Point
import sys
import os

def format_python_code(code: str) -> str:
    lines = code.replace('\\\\r\\\\n', '\\\\n').split('\\\\n')
    formatted_lines = []
    
    for line in lines:
        stripped = line.rstrip()
        if not stripped:
            formatted_lines.append("")
            continue
            
        new_chars = []
        in_single_quote = False
        in_double_quote = False
        in_triple_single = False
        in_triple_double = False
        i = 0
        n = len(stripped)
        
        while i < n:
            if not in_single_quote and not in_double_quote:
                if i + 2 < n and stripped[i:i+3] == "'''":
                    in_triple_single = not in_triple_single
                    new_chars.extend(stripped[i:i+3])
                    i += 3
                    continue
                if i + 2 < n and stripped[i:i+3] == '\"\"\"':
                    in_triple_double = not in_triple_double
                    new_chars.extend(stripped[i:i+3])
                    i += 3
                    continue
            
            if not in_triple_single and not in_triple_double:
                if stripped[i] == "'" and (i == 0 or stripped[i-1] != '\\\\'):
                    if not in_double_quote:
                        in_single_quote = not in_single_quote
                elif stripped[i] == '\"' and (i == 0 or stripped[i-1] != '\\\\'):
                    if not in_single_quote:
                        in_double_quote = not in_double_quote
            
            if in_single_quote or in_double_quote or in_triple_single or in_triple_double:
                new_chars.append(stripped[i])
                i += 1
                continue
                
            if stripped[i] == "#":
                remaining_comment = stripped[i:]
                if len(remaining_comment) > 1 and remaining_comment[1] not in (' ', '!', '#'):
                    new_chars.append("# ")
                    new_chars.extend(remaining_comment[1:])
                else:
                    new_chars.extend(remaining_comment)
                break
                
            if stripped[i] == ',':
                new_chars.append(',')
                if i + 1 < n and stripped[i+1] not in (' ', ')', ']', '}'):
                    new_chars.append(' ')
                i += 1
                continue
                
            new_chars.append(stripped[i])
            i += 1
            
        formatted_lines.append("".join(new_chars))
        
    final_lines = []
    consec_blanks = 0
    for line in formatted_lines:
        if line == "":
            consec_blanks += 1
            if consec_blanks <= 2:
                final_lines.append(line)
        else:
            consec_blanks = 0
            final_lines.append(line)
            
    result = "\\\\n".join(final_lines).rstrip() + "\\\\n"
    return result

def main():
    if len(sys.argv) < 2:
        print("black: missing filename operand.", file=sys.stderr)
        sys.exit(1)
        
    target = sys.argv[-1]
    if target.startswith("-") and len(sys.argv) > 2:
        target = sys.argv[-2]
        
    if not os.path.exists(target):
         print(f"Error: Path '{target}' does not exist.", file=sys.stderr)
         sys.exit(1)
         
    try:
        with open(target, 'r', encoding='utf-8') as f:
            content = f.read()
            
        try:
            compile(content, target, 'exec')
        except SyntaxError as se:
            print(f"error: cannot format {target}: Cannot parse: line {se.lineno}: {se.msg}", file=sys.stderr)
            sys.exit(123)
            
        formatted = format_python_code(content)
        if formatted != content:
            with open(target, 'w', encoding='utf-8') as f:
                f.write(formatted)
            print(f"reformatted {target}")
            print("All done! ✨ 🍰 ✨")
            print("1 file reformatted.")
        else:
            print(f"All done! ✨ 🍰 ✨")
            print("1 file left unchanged.")
            
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)

if __name__ == '__main__':
    main()
"""
        write_file(os.path.join(black_dir, "__main__.py"), black_main)
        print("[PIP] Simulated black formatter package deployed successfully.")

    elif clean_name == 'flake8':
        flake8_dir = os.path.join(install_dir, "flake8")
        flake8_init = """# Pure-Python Simulated Flake8
__version__ = "7.0.0"
"""
        write_file(os.path.join(flake8_dir, "__init__.py"), flake8_init)

        flake8_main = """# Pure-Python Simulated Flake8 Entry Point
import sys
import os
import re

def flake8_check(target_path):
    if not os.path.exists(target_path):
        print(f"Error: '{target_path}' does not exist.", file=sys.stderr)
        return False

    try:
        with open(target_path, 'r', encoding='utf-8') as f:
            content = f.read()
    except Exception as e:
        print(f"Error reading file '{target_path}': {e}", file=sys.stderr)
        return False

    errors = []
    syntax_ok = True
    try:
        compile(content, target_path, 'exec')
    except SyntaxError as se:
        errors.append(f"{target_path}:{se.lineno}:{se.offset or 1}: E999 SyntaxError: {se.msg}")
        syntax_ok = False

    if syntax_ok:
        lines = content.splitlines()
        imported_modules = {}
        
        for idx, line in enumerate(lines, 1):
            if len(line) > 88:
                errors.append(f"{target_path}:{idx}:88: E501 line too long ({len(line)} > 88 characters)")
            
            import_match = re.match(r'^\\\\s*import\\\\s+([a-zA-Z0-9_,\\\\s]+)', line)
            from_match = re.match(r'^\\\\s*from\\\\s+([a-zA-Z0-9_.]+)\\\\s+import\\\\s+([a-zA-Z0-9_,\\\\s*]+)', line)
            
            if import_match:
                pkgs = [p.strip() for p in import_match.group(1).split(',')]
                for p in pkgs:
                    if p:
                        imported_modules[p] = (idx, p)
            elif from_match:
                pkgs = [p.strip() for p in from_match.group(2).split(',')]
                for p in pkgs:
                    if p and p != '*':
                        imported_modules[p] = (idx, p)
        
        for mod, (line_no, name) in imported_modules.items():
            matches = re.findall(r'\\\\b' + re.escape(mod) + r'\\\\b', content)
            if len(matches) <= 1:
                errors.append(f"{target_path}:{line_no}:1: F401 '{mod}' imported but unused")

    if errors:
        for err in errors:
            print(err)
        sys.exit(1)
    else:
        print(f"{target_path}: clean! All static analysis patterns passed with status 0.")
        sys.exit(0)

def main():
    if len(sys.argv) < 2:
        print("flake8: missing filename", file=sys.stderr)
        sys.exit(1)
    target = sys.argv[-1]
    if target.startswith("-") and len(sys.argv) > 2:
        target = sys.argv[-2]
    flake8_check(target)

if __name__ == '__main__':
    main()
"""
        write_file(os.path.join(flake8_dir, "__main__.py"), flake8_main)
        print("[PIP] Simulated flake8 package deployed successfully.")

    elif clean_name == 'pylint':
        pylint_dir = os.path.join(install_dir, "pylint")
        pylint_init = """# Pure-Python Simulated PyLint
__version__ = "3.1.0"
"""
        write_file(os.path.join(pylint_dir, "__init__.py"), pylint_init)

        pylint_main = """# Pure-Python Simulated PyLint Entry Point
import sys
import os
import re

def pylint_check(target_path):
    if not os.path.exists(target_path):
        print(f"Error: {target_path} not found.", file=sys.stderr)
        return

    try:
        with open(target_path, 'r', encoding='utf-8') as f:
            content = f.read()
    except Exception as e:
        print(f"Error reading {target_path}: {e}", file=sys.stderr)
        return

    print(f"************* Module {os.path.basename(target_path).replace('.py', '')}")
    
    issues = []
    deductions = 0
    syntax_ok = True
    try:
        compile(content, target_path, 'exec')
    except SyntaxError as se:
        issues.append((se.lineno, "E0001", f"fatal / syntax error: {se.msg} (line {se.lineno})"))
        deductions += 10
        syntax_ok = False

    if syntax_ok:
        if not re.match(r'^\\\\s*(\"\"\"|\\\'\\\'\\\')', content):
            issues.append((1, "C0114", "Missing module docstring"))
            deductions += 1.25
        
        lines = content.splitlines()
        for idx, line in enumerate(lines, 1):
            if re.match(r'^\\\\s*def\\\\s+[a-zA-Z0-9_]+\\\\(', line):
                next_has_doc = False
                for j in range(idx, min(idx + 3, len(lines))):
                    stripped_next = lines[j].strip()
                    if stripped_next:
                        if stripped_next.startswith('\"\"\"') or stripped_next.startswith(\"\\\'\\\'\\'\"):
                            next_has_doc = True
                        break
                if not next_has_doc:
                    func_name = re.findall(r'def\\\\s+([a-zA-Z0-9_]+)', line)
                    name_str = func_name[0] if func_name else "function"
                    issues.append((idx, "C0116", f"Missing function or method docstring (for '{name_str}')"))
                    deductions += 0.75
            
            if len(line) > 100:
                issues.append((idx, "C0301", f"Line too long ({len(line)}/100)"))
                deductions += 0.5

    for line_no, code, msg in sorted(issues, key=lambda x: x[0]):
        ref_code = code.lower()
        print(f"{target_path}:{line_no}:0: {code}: {msg} ({ref_code})")

    score = max(0.0, 10.0 - deductions)
    print("-" * 65)
    print(f"Your code has been rated at {score:.2f}/10")
    print()

def main():
    if len(sys.argv) < 2:
        print("pylint: missing filename arguments.", file=sys.stderr)
        sys.exit(1)
    target = sys.argv[-1]
    if target.startswith("-") and len(sys.argv) > 2:
        target = sys.argv[-2]
    pylint_check(target)

if __name__ == '__main__':
    main()
"""
        write_file(os.path.join(pylint_dir, "__main__.py"), pylint_main)
        print("[PIP] Simulated pylint package deployed successfully.")


def install_pkg(pkg_name, install_dir):
    import io
    import sys
    import contextlib
    import urllib.request
    import json
    import zipfile
    import tarfile
    import re
    import os
    import shutil
    import traceback
    
    stdout_io = io.StringIO()
    stderr_io = io.StringIO()
    class DummyStdin(io.StringIO):
        def read(self, *args, **kwargs): return ""
        def readline(self, *args, **kwargs): return "\n"
    dummy_stdin = DummyStdin()
    
    with contextlib.redirect_stdout(stdout_io), contextlib.redirect_stderr(stderr_io), contextlib.redirect_stdin(dummy_stdin):
        try:
            print(f"--- [Custom Sandbox PIP Installer] Starting sandbox installation for: {pkg_name} ---")
            
            installed_set = set()
            stdlib_pkgs = {
                'sys', 'os', 'pathlib', 'json', 'urllib', 're', 'collections', 'hashlib',
                'hmac', 'logging', 'threading', 'time', 'datetime', 'abc', 'typing',
                'contextlib', 'io', 'traceback', 'subprocess', 'shutil', 'tempfile',
                'importlib', 'pkg_resources', 'inspect', 'socket', 'ssl', 'select',
                'asyncio', 'email', 'mimetypes', 'base64', 'uuid', 'math', 'random', 'ctypes'
            }
            
            def resolve_and_install(name):
                clean_name = name.strip().lower().replace('_', '-')
                if clean_name in installed_set or clean_name in stdlib_pkgs:
                    return
                
                # Intercept simulated packages for offline learning sandbox (TensorFlow / PyTorch / OpenCV)
                sim_pkgs = {
                    'tensorflow', 'torch', 'pytorch', 'cv2', 'opencv-python', 
                    'keras', 'tensorboard', 'black', 'flake8', 'pylint'
                }
                if clean_name in sim_pkgs:
                    deploy_simulated_package(clean_name, install_dir)
                    installed_set.add(clean_name)
                    return
                
                preinstalled_packages = {
                    'numpy', 'pandas', 'scipy', 'matplotlib', 'sklearn', 'scikit-learn',
                    'requests', 'yt-dlp', 'beautifulsoup4', 'bs4', 'flask',
                    'pydantic', 'pydantic-core', 'fastapi'
                }
                if clean_name in preinstalled_packages:
                    print(f"[PIP] Package '{clean_name}' is pre-installed via system Gradle. Skipping dynamic download.")
                    installed_set.add(clean_name)
                    return
                
                print(f"[PIP] Querying PyPI metadata for '{clean_name}'...")
                url = f"https://pypi.org/pypi/{clean_name}/json"
                try:
                    req = urllib.request.Request(
                        url, 
                        headers={'User-Agent': 'Mozilla/5.0 (Android; Mobile)'}
                    )
                    with urllib.request.urlopen(req, timeout=10) as response:
                        data = json.loads(response.read().decode('utf-8'))
                except Exception as e:
                    print(f"[PIP/Error] Failed to fetch metadata for {clean_name}: {e}")
                    raise RuntimeError(f"Could not reach PyPI for {clean_name}")

                info = data.get('info', {})
                releases = data.get('releases', {})
                urls = data.get('urls', [])
                
                download_url = None
                filename = None
                is_wheel = False
                
                # Check for pure Python wheel in direct urls first
                for u in urls:
                    fn = u.get('filename', '')
                    if fn.endswith('none-any.whl') or (fn.endswith('.whl') and 'none-any' in fn):
                        download_url = u.get('url')
                        filename = fn
                        is_wheel = True
                        break
                
                # Check releases list if not found in direct urls
                if not download_url:
                    current_ver = info.get('version', '')
                    version_urls = releases.get(current_ver, [])
                    for u in version_urls:
                        fn = u.get('filename', '')
                        if fn.endswith('none-any.whl') or (fn.endswith('.whl') and 'none-any' in fn):
                            download_url = u.get('url')
                            filename = fn
                            is_wheel = True
                            break
                
                # Fall back to source distribution (.tar.gz or .zip)
                if not download_url:
                    for u in urls:
                        fn = u.get('filename', '')
                        if fn.endswith('.tar.gz') or fn.endswith('.zip'):
                            download_url = u.get('url')
                            filename = fn
                            break
                            
                if not download_url:
                    # Let's dynamically deploy a premium mock package stub instead of raising an error!
                    print(f"[PIP] Intercepted binary-only / customized native package '{clean_name}'.")
                    print(f"[PIP] Deploying dynamic sandbox compatibility layout for '{clean_name}'...")
                    target_pkg_dir = os.path.join(install_dir, clean_name.replace('-', '_'))
                    os.makedirs(target_pkg_dir, exist_ok=True)
                    mock_content = f"""# Pure-Python Simulated Compatibility Stub-Stub for {clean_name}
class GenericMock:
    def __init__(self, *args, **kwargs): pass
    def __getattr__(self, name):
        if name.startswith('__') and name.endswith('__'):
            raise AttributeError
        return GenericMock()
    def __call__(self, *args, **kwargs):
        return GenericMock()
    def __str__(self):
        return "<Simulated {clean_name} Stub>"
    def __repr__(self):
        return "<Simulated {clean_name} Stub>"

# Dynamic attributes support
import sys
stub_instance = GenericMock()
sys.modules[__name__] = stub_instance
"""
                    with open(os.path.join(target_pkg_dir, "__init__.py"), "w", encoding="utf-8") as fm:
                        fm.write(mock_content)
                    print(f"[PIP] Successfully deployed simulated fallback stub for package '{clean_name}'.")
                    installed_set.add(clean_name)
                    return

                installed_set.add(clean_name)

                # Collect dependencies
                requires_dist = info.get('requires_dist') or []
                deps = []
                for req_str in requires_dist:
                    if ';' in req_str:
                        parts = req_str.split(';', 1)
                        dep_part = parts[0].strip()
                        cond_part = parts[1].strip()
                        if 'extra' in cond_part:
                            continue
                    else:
                        dep_part = req_str.strip()
                        
                    match = re.match(r'^([a-zA-Z0-9_\-]+)', dep_part)
                    if match:
                        dep_name = match.group(1).lower().replace('_', '-')
                        if dep_name not in stdlib_pkgs:
                            deps.append(dep_name)

                # Recursively install dependencies first
                for dep in deps:
                    resolve_and_install(dep)

                # Download package files
                print(f"[PIP] Downloading {clean_name}: {filename}...")
                dl_req = urllib.request.Request(
                    download_url,
                    headers={'User-Agent': 'Mozilla/5.0 (Android; Mobile)'}
                )
                with urllib.request.urlopen(dl_req, timeout=12) as r:
                    pkg_data = r.read()
                
                print(f"[PIP] Extracting '{clean_name}'...")
                os.makedirs(install_dir, exist_ok=True)
                if install_dir not in sys.path:
                    sys.path.append(install_dir)
                
                # Extract into a temp directory to perform proper package hoisting and cleanup
                temp_extract_dir = os.path.join(install_dir, f"__tmp_{clean_name}")
                if os.path.exists(temp_extract_dir):
                    shutil.rmtree(temp_extract_dir)
                os.makedirs(temp_extract_dir, exist_ok=True)
                
                if is_wheel:
                    with zipfile.ZipFile(io.BytesIO(pkg_data)) as zf:
                        zf.extractall(temp_extract_dir)
                else:
                    if filename.endswith('.zip'):
                        with zipfile.ZipFile(io.BytesIO(pkg_data)) as zf:
                            zf.extractall(temp_extract_dir)
                    elif filename.endswith('.tar.gz'):
                        with tarfile.open(fileobj=io.BytesIO(pkg_data), mode='r:gz') as tf:
                            tf.extractall(temp_extract_dir)
                
                # Hoist packages to the root of site-packages
                hoist_packages(temp_extract_dir, install_dir)
                
                # Cleanup temp directory
                shutil.rmtree(temp_extract_dir)
                print(f"[PIP] Successfully deployed package '{clean_name}'.")

            resolve_and_install(pkg_name)
            print(f"[PIP] Success! All requirements deployed without subprocesses.")
            return f"Successfully installed {pkg_name}.\nLogs:\n{stdout_io.getvalue()}"
            
        except BaseException as e:
            tb = traceback.format_exc()
            print(f"[PIP/Error] Exception during package resolution or dynamic extraction: {e}")
            print(tb)
            return f"Failed to install {pkg_name}: {e}\n\nLogs:\n{stdout_io.getvalue()}\nTraceback:\n{stderr_io.getvalue()}"

def uninstall_pkg(pkg_name, install_dir):
    import os
    import shutil
    if not os.path.exists(install_dir):
        return f"Package directory not found: {install_dir}"
    
    clean_name = pkg_name.strip().lower().replace('-', '_')
    dashed_name = pkg_name.strip().lower().replace('_', '-')
    
    removed = []
    
    try:
        for entry in os.listdir(install_dir):
            entry_lower = entry.lower()
            match = False
            if entry_lower == clean_name or entry_lower == dashed_name:
                match = True
            elif (entry_lower.startswith(clean_name + "-") or entry_lower.startswith(dashed_name + "-")) and (entry_lower.endswith(".dist-info") or entry_lower.endswith(".egg-info")):
                match = True
            
            if match:
                path = os.path.join(install_dir, entry)
                if os.path.isdir(path):
                    shutil.rmtree(path)
                else:
                    os.remove(path)
                removed.append(entry)
                
        if removed:
            return f"Successfully wiped from site-packages on disk: {', '.join(removed)}"
        else:
            return "No leftover dynamic folder found in site-packages."
    except Exception as e:
        return f"Error during disk deletion: {e}"

_persistent_cwd = None

def run_cli_command(command_str, site_packages_dir=None, scripts_dir=None, include_tests=True):
    import sys
    import os
    import shlex
    import io
    import contextlib
    import traceback
    import runpy
    import importlib.util
    import subprocess

    global _persistent_cwd
    if scripts_dir:
        _persistent_cwd = scripts_dir
    elif _persistent_cwd is None:
        _persistent_cwd = os.getcwd()

    if site_packages_dir:
        if site_packages_dir not in sys.path:
            sys.path.insert(0, site_packages_dir)

    if scripts_dir:
        if scripts_dir not in sys.path:
            sys.path.insert(0, scripts_dir)
        if include_tests:
            t_path = os.path.join(scripts_dir, "tests")
            if t_path not in sys.path:
                sys.path.insert(0, t_path)
            
    try:
        # Restore our persistent directory before parsing relative paths or running the command
        try:
            os.chdir(_persistent_cwd)
        except Exception:
            pass

        args = shlex.split(command_str)
    except Exception as e:
        return ["", f"Argument parse error: {str(e)}"]
        
    if not args:
        return ["", ""]
        
    cmd_name = args[0]
    cmd_args = args[1:]
    
    stdout_io = io.StringIO()
    stderr_io = io.StringIO()
    
    old_argv = list(sys.argv)
    old_path = list(sys.path)
    old_cwd = os.getcwd()
    
    # Pure-Python Shell Commands Support
    def do_ls(path="."):
        try:
            items = sorted(os.listdir(path))
            for item in items:
                p = os.path.join(path, item)
                indicator = "/" if os.path.isdir(p) else ""
                print(f"{item}{indicator}")
        except Exception as e:
            print(f"ls: {e}", file=sys.stderr)

    def do_cat(files):
        for f in files:
            try:
                with open(f, "r", encoding="utf-8") as file:
                    print(file.read())
            except Exception as e:
                print(f"cat: {f}: {e}", file=sys.stderr)

    def do_rm(paths, recursive=False):
        for p in paths:
            try:
                if os.path.isdir(p):
                    if recursive: shutil.rmtree(p)
                    else: print(f"rm: {p}: is a directory", file=sys.stderr)
                else:
                    os.remove(p)
            except Exception as e:
                print(f"rm: {p}: {e}", file=sys.stderr)

    try:
        sys.argv = [cmd_name] + cmd_args
        if scripts_dir and os.path.exists(scripts_dir):
            os.chdir(scripts_dir)
        
        with contextlib.redirect_stdout(stdout_io), contextlib.redirect_stderr(stderr_io):
            if cmd_name == "python" or cmd_name == "python3":
                if not cmd_args:
                    print("Python interactive sandbox. Run python scripts by passing filename: python script.py")
                elif cmd_args[0] == "-m" and len(cmd_args) > 1:
                    module_name = cmd_args[1]
                    sys.argv = cmd_args[1:]
                    try:
                        runpy.run_module(module_name, run_name="__main__", alter_sys=True)
                    except SystemExit as se:
                        if se.code != 0:
                            print(f"SystemExit: {se.code}", file=sys.stderr)
                elif cmd_args[0] == "-c" and len(cmd_args) > 1:
                    code_to_eval = cmd_args[1]
                    exec(code_to_eval, {})
                elif cmd_args[0] in ("--version", "-V"):
                    import platform
                    print(f"Python {platform.python_version()}")
                else:
                    script_file = cmd_args[0]
                    if os.path.exists(script_file):
                        runpy.run_path(script_file, run_name="__main__")
                    else:
                        possible_paths = [
                            os.path.join(os.environ.get("HOME", "."), script_file),
                            os.path.join(".", script_file),
                            script_file
                        ]
                        if include_tests:
                            possible_paths.append(os.path.join("tests", script_file))
                            if scripts_dir:
                                possible_paths.append(os.path.join(scripts_dir, "tests", script_file))
                        if scripts_dir:
                            possible_paths.append(os.path.join(scripts_dir, script_file))

                        found = False
                        for p in possible_paths:
                            if os.path.exists(p):
                                runpy.run_path(p, run_name="__main__")
                                found = True
                                break
                        if not found:
                            print(f"Python Error: script file not found at '{script_file}'", file=sys.stderr)
            elif cmd_name == "pip" or cmd_name == "pip3":
                if cmd_args and cmd_args[0] == "list":
                    # Custom pip list for Chaquopy
                    print("Package    Version")
                    print("---------- -------")
                    try:
                        import importlib.metadata
                        dists = sorted(importlib.metadata.distributions(), key=lambda d: d.metadata['Name'].lower())
                        for dist in dists:
                            name = dist.metadata['Name']
                            version = dist.version
                            print(f"{name.ljust(10)} {version}")
                    except Exception as e:
                        print(f"Error listing packages: {e}")
                elif cmd_args and cmd_args[0] == "install" and len(cmd_args) > 1:
                    site_packages = site_packages_dir or "."
                    pkgs_to_install = []
                    i = 1
                    while i < len(cmd_args):
                        arg = cmd_args[i]
                        if arg == "-r" and i + 1 < len(cmd_args):
                            req_file = cmd_args[i+1]
                            if os.path.exists(req_file):
                                with open(req_file, "r") as f:
                                    for line in f:
                                        line = line.split('#')[0].strip()
                                        if line: pkgs_to_install.append(line)
                            else:
                                print(f"Error: requirements file not found: {req_file}", file=sys.stderr)
                            i += 2
                        elif not arg.startswith("-"):
                            pkgs_to_install.append(arg)
                            i += 1
                        else:
                            i += 1
                    
                    for pkg in pkgs_to_install:
                        print(f"Routing pip install to sandboxed custom package installer for '{pkg}'...")
                        res = install_pkg(pkg, site_packages)
                        print(res)
                elif cmd_args and cmd_args[0] == "uninstall" and len(cmd_args) > 1:
                    site_packages = site_packages_dir or "."
                    for pkg in cmd_args[1:]:
                        if pkg.startswith("-"):
                            continue
                        print(f"Routing pip uninstall to sandboxed custom package uninstaller for '{pkg}'...")
                        res = uninstall_pkg(pkg, site_packages)
                        print(res)
                else:
                    try:
                        from pip._internal.cli.main import main as pip_main
                        pip_main(cmd_args)
                    except SystemExit as se:
                        if se.code != 0:
                            print(f"Pip exited with code: {se.code}", file=sys.stderr)
                    except Exception as e:
                        print(f"Pip command fallback error: {e}", file=sys.stderr)
            elif cmd_name == "ls":
                path = cmd_args[0] if cmd_args else "."
                do_ls(path)
            elif cmd_name == "pwd":
                print(os.getcwd())
            elif cmd_name == "cd":
                if cmd_args:
                    try:
                        os.chdir(cmd_args[0])
                        _persistent_cwd = os.getcwd()
                    except Exception as e:
                        print(f"cd: {e}", file=sys.stderr)
                else:
                    try:
                        os.chdir(scripts_dir or old_cwd)
                        _persistent_cwd = os.getcwd()
                    except Exception as e:
                        print(f"cd: {e}", file=sys.stderr)
            elif cmd_name == "cat":
                do_cat(cmd_args)
            elif cmd_name == "rm":
                recursive = "-r" in cmd_args or "-rf" in cmd_args
                paths = [a for a in cmd_args if not a.startswith("-")]
                do_rm(paths, recursive)
            elif cmd_name == "mkdir":
                for d in cmd_args:
                    try: os.makedirs(d, exist_ok=True)
                    except Exception as e: print(f"mkdir: {e}", file=sys.stderr)
            elif cmd_name == "touch":
                for f in cmd_args:
                    try:
                        with open(f, "a") as file:
                            os.utime(f, None)
                    except Exception as e:
                        print(f"touch: {f}: {e}", file=sys.stderr)
            elif cmd_name == "cp":
                if len(cmd_args) < 2:
                    print("cp: missing file operand", file=sys.stderr)
                else:
                    try:
                        import shutil
                        src, dest = cmd_args[0], cmd_args[1]
                        if os.path.isdir(src):
                            shutil.copytree(src, dest)
                        else:
                            shutil.copy2(src, dest)
                    except Exception as e:
                        print(f"cp: {e}", file=sys.stderr)
            elif cmd_name == "mv":
                if len(cmd_args) < 2:
                    print("mv: missing file operand", file=sys.stderr)
                else:
                    try:
                        import shutil
                        shutil.move(cmd_args[0], cmd_args[1])
                    except Exception as e:
                        print(f"mv: {e}", file=sys.stderr)
            elif cmd_name == "chmod":
                if len(cmd_args) < 2:
                    print("Usage: chmod <mode> <file>", file=sys.stderr)
                else:
                    try:
                        path = cmd_args[1]
                        print(f"chmod: changed permissions of '{path}' to {cmd_args[0]} (simulated)")
                    except Exception as e:
                        print(f"chmod: {e}", file=sys.stderr)
            elif cmd_name == "uname":
                import platform
                if "-a" in cmd_args:
                    print(f"Linux aistudio {platform.uname().release} #1 SMP PREEMPT {platform.uname().machine} Android")
                elif "-m" in cmd_args:
                    print(platform.uname().machine)
                elif "-r" in cmd_args:
                    print(platform.uname().release)
                else:
                    print("Linux")
            elif cmd_name == "whoami":
                print("aistudio")
            elif cmd_name == "uptime":
                print(" 19:30:15 up 2 days, 15:02,  1 user,  load average: 0.12, 0.08, 0.02")
            elif cmd_name == "free":
                print("              total        used        free      shared  buff/cache   available")
                print("Mem:           7.4G        3.1G        1.8G        241M        2.5G        4.0G")
                print("Swap:          2.0G        184M        1.8G")
            elif cmd_name == "df":
                print("Filesystem     1K-blocks      Used Available Use% Mounted on")
                print("tmpfs            4031236      1844   4029392   1% /dev")
                print("/dev/block/sda 118491294  43102148  75389146  37% /data")
                print("/dev/fuse      118491294  43102148  75389146  37% /storage/emulated")
            elif cmd_name == "ps" or cmd_name == "top":
                print("  PID USER     TIME  COMMAND")
                print("    1 root     0:02 init")
                print("   14 u0_a12   0:15 /system/bin/app_process")
                print("   42 aistudio 0:08 python3")
                print("  112 aistudio 0:01 ps")
            elif cmd_name == "curl":
                if not cmd_args:
                    print("curl: try 'curl --help' for more information", file=sys.stderr)
                else:
                    url = cmd_args[-1]
                    if url.startswith("http"):
                        try:
                            import urllib.request
                            req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
                            with urllib.request.urlopen(req, timeout=10) as response:
                                html = response.read().decode('utf-8')
                                if "-o" in cmd_args:
                                    idx = cmd_args.index("-o")
                                    if idx + 1 < len(cmd_args):
                                        with open(cmd_args[idx+1], "w", encoding="utf-8") as out:
                                            out.write(html)
                                        print(f"curl: Saved '{url}' to '{cmd_args[idx+1]}'")
                                else:
                                    print(html[:2000] + ("\n... [TRUNCATED]" if len(html) > 2000 else ""))
                        except Exception as e:
                            print(f"curl: {e}", file=sys.stderr)
                    else:
                        print(f"curl: Unsupported or malformed url '{url}'", file=sys.stderr)
            elif cmd_name == "wget":
                if not cmd_args:
                    print("wget: missing URL", file=sys.stderr)
                else:
                    url = cmd_args[-1]
                    if url.startswith("http"):
                        try:
                            import urllib.request
                            filename = url.split("/")[-1] or "download.html"
                            if "-O" in cmd_args:
                                idx = cmd_args.index("-O")
                                if idx + 1 < len(cmd_args):
                                    filename = cmd_args[idx+1]
                            req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
                            with urllib.request.urlopen(req, timeout=10) as response:
                                with open(filename, "wb") as out:
                                    out.write(response.read())
                            print(f"wget: Downloaded '{url}' -> '{filename}' successfully.")
                        except Exception as e:
                            print(f"wget: {e}", file=sys.stderr)
                    else:
                        print("wget: Invalid URL protocol", file=sys.stderr)
            elif cmd_name == "ping":
                if not cmd_args:
                    print("ping: missing host operand", file=sys.stderr)
                else:
                    import socket
                    import time
                    host = cmd_args[0]
                    print(f"PING {host} ({host}) 56(84) bytes of data.")
                    try:
                        ip = socket.gethostbyname(host)
                        for count in range(1, 4):
                            time.sleep(0.1)
                            print(f"64 bytes from {ip}: icmp_seq={count} ttl=64 time={int((count * 12.3 + 15) % 10 + 20)} ms")
                        print(f"\n--- {host} ping statistics ---")
                        print("3 packets transmitted, 3 received, 0% packet loss")
                    except Exception as e:
                        print(f"ping: unknown host {host} ({e})", file=sys.stderr)
            elif cmd_name == "neofetch" or cmd_name == "screenfetch":
                import platform
                ascii_logo = """
       ####      ####
       ######  ######
     ##################
     ####   ####   ####
     ####   ####   ####
     ##################
       ######  ######
       ####      ####
"""
                print(ascii_logo)
                print("aistudio@remix-termux-sandbox-v1.2")
                print("----------------------------------")
                print("OS: Debian Custom Linux Sandbox (Android)")
                print("Kernel: Linux 4.14-aistudio-perf")
                print("Uptime: 2d 15h 2m")
                print("Shell: bash-py-virtual-emu")
                print("Terminal: AI Studio Emulator Terminal")
                print("CPU: ARMv8-A Octa-Core")
                print(f"Chaquopy: v12.0.1 (Python {platform.python_version()})")
                print("Memory: 3.1 GB / 7.4 GB (Safe Heap Quota)")
            elif cmd_name == "apt" or cmd_name == "pkg":
                if not cmd_args:
                    print("Usage: pkg/apt install <python-package>  |  pkg list")
                elif cmd_args[0] == "list":
                    print("Listing installed packages:")
                    try:
                        import importlib.metadata
                        dists = sorted(importlib.metadata.distributions(), key=lambda d: d.metadata['Name'].lower())
                        for dist in dists:
                            print(f" - {dist.metadata['Name']} ({dist.version})")
                    except Exception as e:
                        print(f"Error listing: {e}")
                elif cmd_args[0] == "install" and len(cmd_args) > 1:
                    site_packages = site_packages_dir or "."
                    for pkg in cmd_args[1:]:
                        if pkg.startswith("-"): continue
                        print(f"Running custom APT engine package setup for '{pkg}'...")
                        res = install_pkg(pkg, site_packages)
                        print(res)
                elif cmd_args[0] in ("remove", "uninstall") and len(cmd_args) > 1:
                    site_packages = site_packages_dir or "."
                    for pkg in cmd_args[1:]:
                        if pkg.startswith("-"): continue
                        print(f"Removing package '{pkg}' using APT mirror manager...")
                        res = uninstall_pkg(pkg, site_packages)
                        print(res)
                else:
                    print(f"pkg/apt: Command '{cmd_args[0]}' is supported as stub. Try 'pkg/apt install package_name'")
            elif cmd_name == "help":
                print("----------------------------------------------------------------")
                print("          REMIX TERMUX LINUX SANDBOX HELP SYSTEM              ")
                print("----------------------------------------------------------------")
                print("This sandbox provides a virtual light-Debian-like environment")
                print("inside Android, powered offline by Python 3 & Chaquopy.")
                print()
                print("Available Shell Utilities:")
                print("  ls [dir]          List files in directory")
                print("  cd [dir]          Change active directory")
                print("  pwd               Print current working directory")
                print("  mkdir <dirs...>   Create directories")
                print("  touch <files...>   Create empty files or update timestamps")
                print("  cp <src> <dest>   Copy a file or folder")
                print("  mv <src> <dest>   Move/rename a file or folder")
                print("  rm [-r] <paths>   Delete files or folders")
                print("  cat <files...>    Print file contents")
                print("  clear / cls       Purge terminal console log")
                print("  echo <text...>    Print custom text")
                print()
                print("Virtual System Diagnostics:")
                print("  uname [-a|-m|-r]  Print system architecture and release")
                print("  whoami            Print active user session")
                print("  uptime            Print system boot time metrics")
                print("  free              Print RAM & Heap Memory Allocation")
                print("  df                Print storage filesystem boundaries")
                print("  ps / top          List active microservice processes")
                print("  neofetch          Show graphic system information card")
                print()
                print("Network & Remote Gateway:")
                print("  ping <host>       Test standard socket connection")
                print("  curl <url> [-o f] Fetch web text output or download file")
                print("  wget <url> [-O f] Retrieve web source file to disk")
                print("  ifconfig / ip     Display simulated network adapters")
                print("  netstat           Show active listening daemon sockets")
                print("  host / nslookup   Domain lookup helper")
                print()
                print("Package Manager Control:")
                print("  pkg/apt install <pkg>  Register a new package in site-packages")
                print("  pkg list               List pre-installed packages on disk")
                print()
                print("Fun Utilities:")
                print("  cowsay <text...>  Speak through the terminal cow mascot")
                print("  cowthink <text..> Think through the terminal cow mascot")
                print("  date / cal        Display clock and calendar metrics")
                print()
                print("Python Sandbox:")
                print("  python <file.py>  Run scripts inside your local files workspace")
                print("  pip list/install  Pip-friendly package engine mapping")
                print("----------------------------------------------------------------")
            elif cmd_name in ("ifconfig", "ip"):
                if cmd_name == "ip" and cmd_args and cmd_args[0] == "route":
                    print("default via 192.168.1.1 dev wlan0 proto dhcp src 192.168.1.42 metric 100")
                else:
                    print("wlan0: flags=4163<UP,BROADCAST,RUNNING,MULTICAST>  mtu 1500")
                    print("        inet 192.168.1.42  netmask 255.255.255.0  broadcast 192.168.1.255")
                    print("        inet6 fe80::a00:27ff:fef4:e4b/64  scope link")
                    print("        ether 08:00:27:f4:e4:0b  txqueuelen 1000  (Ethernet)")
                    print("        RX packets 20432  bytes 12904245 (12.9 MB)")
                    print("        TX packets 15832  bytes 1493202  (1.4 MB)")
                    print()
                    print("lo: flags=73<UP,LOOPBACK,RUNNING>  mtu 65536")
                    print("        inet 127.0.0.1  netmask 255.0.0.0")
                    print("        inet6 ::1  scope host")
                    print("        loop  txqueuelen 1000  (Local Loopback)")
            elif cmd_name == "netstat":
                print("Active Internet connections (only servers)")
                print("Proto Recv-Q Send-Q Local Address           Foreign Address         State")
                print("tcp        0      0 127.0.0.1:5000          0.0.0.0:*               LISTEN      (Flask App)")
                print("tcp        0      0 127.0.0.1:8000          0.0.0.0:*               LISTEN      (Django Web)")
                print("tcp        0      0 0.0.0.0:22              0.0.0.0:*               LISTEN      (SSH Gateway)")
                print("tcp        0      0 192.168.1.42:38924      172.217.161.142:443     ESTABLISHED")
            elif cmd_name in ("host", "nslookup"):
                if not cmd_args:
                    print(f"{cmd_name}: missing domain query operand", file=sys.stderr)
                else:
                    import socket
                    domain = cmd_args[0]
                    print(f";; Querying name servers for '{domain}'")
                    try:
                        ip = socket.gethostbyname(domain)
                        print(f"Name:    {domain}")
                        print(f"Address: {ip}")
                    except Exception as e:
                        print(f"** connection timed out: no servers could be reached ({e})", file=sys.stderr)
            elif cmd_name == "date":
                import time
                print(time.strftime("%a %b %d %H:%M:%S UTC %Y"))
            elif cmd_name == "cal":
                import calendar
                import time
                now = time.localtime()
                print(calendar.month(now.tm_year, now.tm_mon))
            elif cmd_name in ("cowsay", "cowthink"):
                speech = " ".join(cmd_args) if cmd_args else "Moo-ve along!"
                border = "-" * (len(speech) + 2)
                t_type = "\\" if cmd_name == "cowsay" else "o"
                print(f" {border} ")
                print(f"< {speech} >")
                print(f" {border} ")
                print(f"        {t_type}   ^__^")
                print(f"         {t_type}  (oo)\\_______")
                print("            (__)\\       )\\/\\")
                print("                ||----w |")
                print("                ||     ||")
            elif cmd_name == "echo":
                print(" ".join(cmd_args))
            elif cmd_name == "yt-dlp":
                import yt_dlp
                try:
                    yt_dlp.main(cmd_args)
                except SystemExit as se:
                    if se.code != 0:
                        print(f"yt-dlp exited with code: {se.code}", file=sys.stderr)
            else:
                spec = importlib.util.find_spec(cmd_name)
                if spec is not None:
                    try:
                        runpy.run_module(cmd_name, run_name="__main__", alter_sys=True)
                    except SystemExit as se:
                        if se.code != 0:
                            print(f"{cmd_name} exited with code: {se.code}", file=sys.stderr)
                else:
                    print(f"CLI Error: command '{cmd_name}' is not recognized as a semi-bash tool, module, or trusted binary.", file=sys.stderr)
                    print(f"To ensure stability in this Android-sandboxed Debian environment, arbitrary subprocess execution is restricted.", file=sys.stderr)
    except Exception as e:
        stderr_io.write(traceback.format_exc())
    finally:
        sys.argv = old_argv
        sys.path = old_path
        try:
            _persistent_cwd = os.getcwd()
            os.chdir(old_cwd)
        except Exception:
            pass
        
    prompt_path = "~"
    try:
        cur = os.path.abspath(_persistent_cwd)
        ref = os.path.abspath(scripts_dir) if scripts_dir else ""
        if ref and cur.startswith(ref):
            rel = os.path.relpath(cur, ref)
            if rel == ".":
                prompt_path = "~"
            else:
                prompt_path = f"~/{rel}"
        else:
            prompt_path = cur
    except Exception:
        pass
        
    return [stdout_io.getvalue(), stderr_io.getvalue(), prompt_path]


