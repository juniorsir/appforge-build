import json
import urllib.request
import urllib.error
import threading
import base64
import socket
from java import jclass

# Setup the hook to Java
ExtensionAPI = jclass("com.example.ExtensionAPI")

class LocalAIPlugin:
    def __init__(self):
        self.tab_id = "local_ai_tab"
        self.ai_url = "http://10.0.2.2:11434/api/generate" # Default for Android Emulator mapped to local machine
        self.model_name = "llama3"
        self.timeout = 5                                   # Default timeout in seconds
        self.chat_history = []
        
        # Register a sidebar tab
        ExtensionAPI.registerTab(
            self.tab_id, 
            "Local AI", 
            "auto_awesome", # Material icon
            "right", 
            self            # The callback target
        )
        self.render_initial_ui()
    
    def render_initial_ui(self):
        """Constructs the HTML UI shell. All updates run dynamically via JavaScript."""
        html = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="utf-8">
            <style>
                body {{ font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; background: #1e1e1e; color: #fff; padding: 12px; margin: 0; display: flex; flex-direction: column; height: 100vh; box-sizing: border-box; }}
                h3 {{ margin-top: 0; margin-bottom: 12px; font-weight: 500; letter-spacing: 0.5px; opacity: 0.9; }}
                .form-group {{ margin-bottom: 10px; flex-shrink: 0; }}
                label {{ display: block; margin-bottom: 4px; font-size: 11px; color: #aaa; text-transform: uppercase; letter-spacing: 0.5px; }}
                input[type="text"], input[type="number"] {{ width: 100%; padding: 8px 10px; box-sizing: border-box; background: #333; border: 1px solid #555; color: #fff; border-radius: 6px; font-size: 13px; outline: none; }}
                input[type="text"]:focus, input[type="number"]:focus {{ border-color: #007acc; }}
                
                button {{ background: #007acc; color: white; border: none; padding: 10px 14px; cursor: pointer; border-radius: 6px; font-weight: 600; box-sizing: border-box; transition: background 0.1s; }}
                button:hover {{ background: #005f9e; }}
                button:disabled {{ background: #444; color: #888; cursor: not-allowed; }}
                
                #chatbox {{ flex-grow: 1; overflow-y: auto; background: #252526; border: 1px solid #444; border-radius: 6px; padding: 12px; margin-bottom: 12px; font-size: 13px; word-wrap: break-word; }}
                .msg-container {{ margin-bottom: 12px; line-height: 1.4; border-bottom: 1px solid #444; padding-bottom: 8px; }}
                .insert-btn {{ float: right; font-size: 11px; color: #007acc; cursor: pointer; font-weight: 600; }}
                .insert-btn:hover {{ text-decoration: underline; }}
            </style>
        </head>
        <body>
            <h3>Ollama Local AI</h3>
            
            <div class="form-group">
                <label>Ollama Endpoint URL</label>
                <input type="text" id="ai_url" value="{self.ai_url}" onchange="updateConfig('url', this.value)">
            </div>
            
            <div class="form-group" style="display: flex; gap: 8px;">
                <div style="flex: 1;">
                    <label>Model Name</label>
                    <input type="text" id="ai_model" value="{self.model_name}" onchange="updateConfig('model', this.value)">
                </div>
                <div style="width: 80px;">
                    <label>Timeout (s)</label>
                    <input type="number" id="ai_timeout" value="{self.timeout}" min="1" max="120" onchange="updateConfig('timeout', this.value)">
                </div>
            </div>

            <div id="chatbox">
                <!-- Messages appended dynamically -->
            </div>

            <div class="form-group" style="display: flex; gap: 8px; align-items: center;">
                <input type="text" id="prompt_input" placeholder="Message AI..." style="flex-grow: 1;" onkeydown="handleKey(event)">
                <button id="send_btn" onclick="sendPrompt()">Send</button>
            </div>

            <script>
                var cb = document.getElementById('chatbox');
                
                function updateConfig(key, val) {{
                    window.VSCodeAPI.postMessage(JSON.stringify({{action: 'update_config', key: key, value: val}}));
                }}

                function handleKey(e) {{
                    if (e.key === 'Enter') {{
                        sendPrompt();
                    }}
                }}
                
                function insertText(text) {{
                    window.VSCodeAPI.postMessage(JSON.stringify({{action: 'insert', text: text}}));
                }}

                function sendPrompt() {{
                    var input = document.getElementById('prompt_input');
                    var prompt = input.value.trim();
                    if (!prompt) return;
                    
                    // Append user message instantly
                    appendMessage('user', prompt);
                    
                    // Post to Python
                    window.VSCodeAPI.postMessage(JSON.stringify({{action: 'send_prompt', prompt: prompt}}));
                    
                    // Clear input and show loading status
                    input.value = '';
                    setLoading(true);
                }}

                function appendMessage(role, content) {{
                    var roleColor = "#4fc1ff";
                    var roleName = "You";
                    var actionBtn = "";
                    
                    if (role === 'ai') {{
                        roleColor = "#ce9178";
                        roleName = "AI";
                        var escapedText = btoa(unescape(encodeURIComponent(content)));
                        actionBtn = `<span class="insert-btn" onclick="insertBase64Text('${escapedText}')">[Insert]</span>`;
                    }} else if (role === 'error') {{
                        roleColor = "#f48771";
                        roleName = "System";
                    }}
                    
                    var div = document.createElement('div');
                    div.className = 'msg-container';
                    div.innerHTML = `<b>\${roleName}:</b> \${actionBtn}<br/><div>\${content.replace(/\\n/g, '<br/>')}</div>`;
                    cb.appendChild(div);
                    cb.scrollTop = cb.scrollHeight;
                }}

                function insertBase64Text(base64Str) {{
                    var desc = decodeURIComponent(escape(atob(base64Str)));
                    insertText(desc);
                }}

                function setLoading(isLoading) {{
                    var input = document.getElementById('prompt_input');
                    var btn = document.getElementById('send_btn');
                    if (isLoading) {{
                        input.disabled = true;
                        input.placeholder = 'Interrogating Model...';
                        btn.disabled = true;
                        btn.innerText = 'Busy...';
                    }} else {{
                        input.disabled = false;
                        input.placeholder = 'Message AI...';
                        btn.disabled = false;
                        btn.innerText = 'Send';
                        input.focus();
                    }}
                }}
            </script>
        </body>
        </html>
        """
        ExtensionAPI.setTabHtml(self.tab_id, html)
        
    def _fetch_ai_response(self, prompt):
        """Runs on a background thread to prevent blocking the WebView message bridge"""
        try:
            # Set socket default timeout to make absolutely certain any network hangs fail fast!
            socket.setdefaulttimeout(float(self.timeout))
            
            payload = json.dumps({
                "model": self.model_name,
                "prompt": prompt,
                "stream": False
            }).encode('utf-8')
            
            req = urllib.request.Request(
                self.ai_url, 
                data=payload, 
                headers={'Content-Type': 'application/json'}
            )
            
            with urllib.request.urlopen(req, timeout=float(self.timeout)) as response:
                res_data = json.loads(response.read().decode('utf-8'))
                response_text = res_data.get('response', 'No response context provided.')
                
                # Append to chat_history
                self.chat_history.append({"role": "ai", "content": response_text.strip()})
                
                # Dynamic update WebView
                safe_content_b64 = base64.b64encode(response_text.strip().encode('utf-8')).decode('utf-8')
                js = f"appendMessage('ai', decodeURIComponent(escape(atob('{safe_content_b64}')))); setLoading(false);"
                ExtensionAPI.executeTabJavascript(self.tab_id, js)
                
        except Exception as e:
            if "timed out" in str(e).lower() or "timeout" in str(e).lower() or isinstance(e, socket.timeout):
                error_msg = f"Timed Out Error: The server at {self.ai_url} did not respond within {self.timeout} seconds.\n\nPlease check if your Model is correct and the server has started successfully."
            else:
                error_msg = f"Error: {e}\n\nPlease check:\n- The server at {self.ai_url} is running.\n- The URL is accessible."
                
            self.chat_history.append({"role": "error", "content": error_msg})
            ExtensionAPI.logError(f"Local AI error: {e}")
            
            # Dynamic update WebView with error
            safe_error_b64 = base64.b64encode(error_msg.encode('utf-8')).decode('utf-8')
            js = f"appendMessage('error', decodeURIComponent(escape(atob('{safe_error_b64}')))); setLoading(false);"
            ExtensionAPI.executeTabJavascript(self.tab_id, js)

    def call(self, message_str):
        """Hook mapped to `window.VSCodeAPI.postMessage()`"""
        try:
            data = json.loads(message_str)
            action = data.get('action')
            
            if action == 'update_config':
                key = data.get('key')
                if key == 'url':
                    self.ai_url = data.get('value')
                elif key == 'model':
                    self.model_name = data.get('value')
                elif key == 'timeout':
                    try:
                        self.timeout = int(data.get('value'))
                    except ValueError:
                        self.timeout = 5
                    
            elif action == 'insert':
                ExtensionAPI.insertTextAtCursor(data.get('text'))
                ExtensionAPI.showToast("Inserted AI Response")
                
            elif action == 'send_prompt':
                prompt = data.get('prompt')
                self.chat_history.append({"role": "user", "content": prompt})
                
                # Start network request asynchronously to keep WebView active
                threading.Thread(target=self._fetch_ai_response, args=(prompt,)).start()
                
        except Exception as e:
            ExtensionAPI.logError(f"Local AI Plugin Bus error: {str(e)}")

# Initialize the plugin
plugin = LocalAIPlugin()
ExtensionAPI.logSuccess("Ollama Local AI Extension active.")
