import java.io.File
import java.io.FileOutputStream
import java.net.URL

plugins {
  alias(libs.plugins.android.application)
  alias(libs.plugins.kotlin.compose)
//   alias(libs.plugins.google.devtools.ksp)
  alias(libs.plugins.roborazzi)
  alias(libs.plugins.chaquopy)
}

android {
  namespace = "com.example"
  compileSdk { version = release(36) { minorApiLevel = 1 } }

  defaultConfig {
    applicationId = "com.aistudio.pytoolkit.xytpqz"
    minSdk = 24
    targetSdk = 36
    versionCode = 1
    versionName = "1.0"

    testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"

    ndk {
      abiFilters += listOf("arm64-v8a", "x86_64")
    }
  }

  signingConfigs {
    create("release") {
      val keystorePath = System.getenv("KEYSTORE_PATH") ?: "${rootDir}/my-upload-key.jks"
      storeFile = file(keystorePath)
      storePassword = System.getenv("STORE_PASSWORD")
      keyAlias = "upload"
      keyPassword = System.getenv("KEY_PASSWORD")
    }
    create("debugConfig") {
      storeFile = file("${rootDir}/debug.keystore")
      storePassword = "android"
      keyAlias = "androiddebugkey"
      keyPassword = "android"
    }
  }

  buildTypes {
    release {
      isCrunchPngs = false
      isMinifyEnabled = false
      proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
      signingConfig = signingConfigs.getByName("release")
    }
    debug {
      signingConfig = signingConfigs.getByName("debugConfig")
    }
  }
  compileOptions {
    sourceCompatibility = JavaVersion.VERSION_11
    targetCompatibility = JavaVersion.VERSION_11
  }
  buildFeatures {
    compose = true
    buildConfig = true
  }
  testOptions { unitTests { isIncludeAndroidResources = true } }
}

fun getBuildPython312Path(rootDir: File): String {
  val targetDir = File(rootDir, ".gradle/python312_portable")
  val binFile = File(targetDir, "python/bin/python3")
  if (binFile.exists()) {
    return binFile.absolutePath
  }

  println("=== STATIC STABLE PYTHON 3.12 INJECTOR ===")
  println("Portable Python 3.12 not found. Downloading...")
  targetDir.mkdirs()
  val archiveFile = File(targetDir, "python.tar.gz")
  
  try {
    val website = URL("https://github.com/indygreg/python-build-standalone/releases/download/20240107/cpython-3.12.1+20240107-x86_64-unknown-linux-gnu-install_only.tar.gz")
    website.openStream().use { input ->
      FileOutputStream(archiveFile).use { output ->
        input.copyTo(output)
      }
    }
    println("Download complete. Extracting Python 3.12 compile toolchain...")
    
    val process = ProcessBuilder("tar", "-xzf", archiveFile.name)
      .directory(targetDir)
      .redirectErrorStream(true)
      .start()
    
    val stdout = process.inputStream.bufferedReader().readText()
    println(stdout)
    process.waitFor()
    
    archiveFile.delete()
    if (binFile.exists()) {
      println("Extraction complete. Python 3.12 executable path: ${binFile.absolutePath}")
      binFile.setExecutable(true)
      return binFile.absolutePath
    } else {
      println("Error: Python binary not found at expected path: ${binFile.absolutePath}")
      return "/usr/bin/python3"
    }
  } catch (e: Exception) {
    println("Failed to setup standalone python: ${e.message}")
    e.printStackTrace()
    return "/usr/bin/python3"
  }
}

chaquopy {
  defaultConfig {
    version = "3.12"
    buildPython(getBuildPython312Path(rootDir))
    pip {
      install("pip")
      install("requests")
      install("numpy")
      install("pandas")
      install("beautifulsoup4")
      install("flask")
      install("yt-dlp")
      install("pydantic")
      install("fastapi")
    }
  }
}

// Some unused dependencies are commented out below instead of being removed.
dependencies {
  implementation(platform(libs.androidx.compose.bom))
  implementation(platform(libs.firebase.bom))
  // implementation(libs.accompanist.permissions)
  implementation(libs.androidx.activity.compose)
  // implementation(libs.androidx.camera.camera2)
  // implementation(libs.androidx.camera.core)
  // implementation(libs.androidx.camera.lifecycle)
  // implementation(libs.androidx.camera.view)
  implementation(libs.androidx.compose.material.icons.core)
  implementation(libs.androidx.compose.material.icons.extended)
  implementation(libs.androidx.compose.material3)
  implementation(libs.androidx.compose.ui)
  implementation(libs.androidx.compose.ui.graphics)
  implementation(libs.androidx.compose.ui.tooling.preview)
  implementation(libs.androidx.core.ktx)
  implementation("androidx.documentfile:documentfile:1.0.1")
  // implementation(libs.androidx.datastore.preferences)
  implementation(libs.androidx.lifecycle.runtime.compose)
  implementation(libs.androidx.lifecycle.runtime.ktx)
  implementation(libs.androidx.lifecycle.viewmodel.compose)
  // implementation(libs.androidx.navigation.compose)
  // implementation(libs.androidx.room.ktx)
  // implementation(libs.androidx.room.runtime)
  // implementation(libs.coil.compose)
  // implementation(libs.converter.moshi)
  // implementation(libs.firebase.ai)
  implementation(libs.kotlinx.coroutines.android)
  implementation(libs.kotlinx.coroutines.core)
  implementation(libs.logging.interceptor)
  implementation("com.github.mwiede:jsch:0.2.20")
  // implementation(libs.moshi.kotlin)
  implementation(libs.okhttp)
  // implementation(libs.play.services.location)
  implementation(libs.retrofit)
  testImplementation(libs.androidx.compose.ui.test.junit4)
  testImplementation(libs.androidx.core)
  testImplementation(libs.androidx.junit)
  testImplementation(libs.junit)
  testImplementation(libs.kotlinx.coroutines.test)
  testImplementation(libs.robolectric)
  testImplementation(libs.roborazzi)
  testImplementation(libs.roborazzi.compose)
  testImplementation(libs.roborazzi.junit.rule)
  androidTestImplementation(platform(libs.androidx.compose.bom))
  androidTestImplementation(libs.androidx.compose.ui.test.junit4)
  androidTestImplementation(libs.androidx.espresso.core)
  androidTestImplementation(libs.androidx.junit)
  androidTestImplementation(libs.androidx.runner)
  debugImplementation(libs.androidx.compose.ui.test.manifest)
  debugImplementation(libs.androidx.compose.ui.tooling)
  // "ksp"(libs.androidx.room.compiler)
  // "ksp"(libs.moshi.kotlin.codegen)
}



