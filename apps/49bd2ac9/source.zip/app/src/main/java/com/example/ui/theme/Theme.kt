package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme =
  darkColorScheme(
    primary = DarkHighDensityPrimary,
    onPrimary = DarkHighDensityOnPrimaryContainer,
    primaryContainer = DarkHighDensityPrimaryContainer,
    onPrimaryContainer = DarkHighDensityOnPrimaryContainer,
    secondary = DarkHighDensitySecondaryText,
    onSecondary = Color.White,
    secondaryContainer = DarkHighDensitySecondaryContainer,
    background = DarkHighDensityBg,
    onBackground = DarkHighDensityText,
    surface = DarkHighDensitySurface,
    onSurface = DarkHighDensityText,
    surfaceVariant = DarkHighDensitySurfaceLow,
    onSurfaceVariant = DarkHighDensitySecondaryText,
    outlineVariant = DarkHighDensityBorder
  )

private val LightColorScheme =
  lightColorScheme(
    primary = LightHighDensityPrimary,
    onPrimary = Color.White,
    primaryContainer = LightHighDensityPrimaryContainer,
    onPrimaryContainer = LightHighDensityOnPrimaryContainer,
    secondary = LightHighDensitySecondaryText,
    onSecondary = LightHighDensityText,
    secondaryContainer = LightHighDensitySecondaryContainer,
    background = LightHighDensityBg,
    onBackground = LightHighDensityText,
    surface = LightHighDensitySurface,
    onSurface = LightHighDensityText,
    surfaceVariant = LightHighDensitySurfaceLow,
    onSurfaceVariant = LightHighDensitySecondaryText,
    outlineVariant = LightHighDensityBorder
  )

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  // Dynamic color is available on Android 12+
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  val colorScheme =
    if (darkTheme) DarkColorScheme else LightColorScheme

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
