package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)

// Light Theme Raw Constants
val LightHighDensityBg = Color(0xFFFDFCFF)
val LightHighDensityText = Color(0xFF1A1C1E)
val LightHighDensityPrimary = Color(0xFF0061A4)
val LightHighDensityPrimaryContainer = Color(0xFFD1E4FF)
val LightHighDensityOnPrimaryContainer = Color(0xFF001D36)
val LightHighDensitySecondaryContainer = Color(0xFFE1E2EC)
val LightHighDensityBorder = Color(0xFFC3C6CF)
val LightHighDensitySurfaceLow = Color(0xFFF3F4FA)
val LightHighDensitySurface = Color(0xFFFDFCFF)
val LightHighDensitySecondaryText = Color(0xFF43474E)

// Dark Theme Raw Constants
val DarkHighDensityBg = Color(0xFF181C20)
val DarkHighDensityText = Color(0xFFE2E2E6)
val DarkHighDensityPrimary = Color(0xFF72D2FF)
val DarkHighDensityPrimaryContainer = Color(0xFF004C75)
val DarkHighDensityOnPrimaryContainer = Color(0xFFCBE6FF)
val DarkHighDensitySecondaryContainer = Color(0xFF3B4146)
val DarkHighDensityBorder = Color(0xFF3B4146)
val DarkHighDensitySurfaceLow = Color(0xFF25292E)
val DarkHighDensitySurface = Color(0xFF1E2226)
val DarkHighDensitySecondaryText = Color(0xFF8E9199)

val LightGreen = Color(0xFFD5F3D1)
val DarkGreen = Color(0xFF0E5B09)
val LightOrange = Color(0xFFFFDDB3)
val DarkOrange = Color(0xFF8B5000)
val LightRed = Color(0xFFFFDAD6)
val DarkRed = Color(0xFFBA1A1A)
val ConsoleDark = Color(0xFF181C20)
val ConsoleText = Color(0xFFE2E2E6)

// Composable Getters to maintain source compatibility under High Density Theme
val HighDensityBg: Color @Composable get() = MaterialTheme.colorScheme.background
val HighDensityText: Color @Composable get() = MaterialTheme.colorScheme.onBackground
val HighDensityPrimary: Color @Composable get() = MaterialTheme.colorScheme.primary
val HighDensityPrimaryContainer: Color @Composable get() = MaterialTheme.colorScheme.primaryContainer
val HighDensityOnPrimaryContainer: Color @Composable get() = MaterialTheme.colorScheme.onPrimaryContainer
val HighDensitySecondaryContainer: Color @Composable get() = MaterialTheme.colorScheme.secondaryContainer
val HighDensityBorder: Color @Composable get() = MaterialTheme.colorScheme.outlineVariant
val HighDensitySurfaceLow: Color @Composable get() = MaterialTheme.colorScheme.surfaceVariant
val HighDensitySurface: Color @Composable get() = MaterialTheme.colorScheme.surface
val HighDensitySecondaryText: Color @Composable get() = MaterialTheme.colorScheme.onSurfaceVariant
