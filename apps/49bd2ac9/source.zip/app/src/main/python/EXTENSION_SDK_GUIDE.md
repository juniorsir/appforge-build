# Extension SDK Reference: Building Perfect Structures

This workspace includes an extremely versatile offline Python Sandbox and extension runtime integrated via **Chaquopy**. Custom user-defined scripts can easily tap into workspace UI hooks, remote server gateways, local analytics databases, and build dynamic tooling features on-the-fly.

This guide provides the complete documentation, method index, structural requirements, and code samples to build flawless extensions.

---

## The 4 Rules of Perfect Structure

Any custom extension script should follow these design rules to operate safely in the sandbox layout:

1. **Explicit Binding Resolution**  
   Your extension script executes inside a fully sandboxed python context but requires binding reference to the JVM environment. Always initialize your binding first:
   ```python
   from java import jclass
   ExtensionAPI = jclass("com.example.ExtensionAPI")
   ```

2. **Self-Contained Object Action Handlers**  
   Interactive elements such as Custom Floating Action Buttons (FABs) and top-bar actions must map their callbacks inside lightweight Python classes containing a `call(self)` method to ensure callback bindings persist cleanly in system memory:
   ```python
   class CleanLogsHandler:
       def call(self):
           ExtensionAPI.clearConsole()
           ExtensionAPI.logSuccess("Wiped log buffers!")
   ```

3. **Status Indicators & Active Priming**  
   A well-engineered extension always informs the workspace UI about its status. On active script boot, verify and trigger a visual update so users are aware that your event interceptors are primed:
   ```python
   ExtensionAPI.setStatusText("Backup Gateway Primed")
   ExtensionAPI.logSuccess("Dynamic synchronization gateway loaded!")
   ```

4. **Independent Namespace & ID Hygiene**  
   Ensure all registered action IDs are descriptive and un-conflicting (e.g. `ext_custom_sync_v1` or `format_static_pad_001`).

---

## SDK Methods Reference Catalog

The standard `ExtensionAPI` binding class exposes complete hook utilities:

### 1. Status Indicators & Interface Panel

* **`setStatusText(text: str) -> None`**  
  Injects a high-visibility text message in the bottom status panel (e.g. `"Sync Connection Online"`). Clear it by sending `None` or clicking the clear action on screen.

* **`toggleConsole() -> None`**  
  Programmatically expands or hides the interactive Python terminal outputs.

* **`clearConsole() -> None`**  
  Flushes all lines inside the console display AND developer debug log buffer.

---

### 2. Editor & Code Manipulation

* **`getText() -> str`**  
  Retrieves the complete, raw code content of the modern tab script editor workspace.

* **`setText(text: str) -> None`**  
  Replaces all lines of the workspace editor with input string. Useful for automated formatters (like Black simulation) or remote script pullers.

* **`insertTextAtCursor(text: str) -> None`**  
  Appends or inserts text right at the active insertion index or trailing end. Perfect for template inject block components.

---

### 3. Workspace Interactive Controls (Floating & Toolbar Actions)

* **`registerFloatingAction(id: str, name: str, callback: PyObject) -> None`**  
  Deploys an independent, high-contrast Floating Action Button (FAB) on the lower viewport of the workspace.
  * *`id`*: A unique string ID to prevent duplicate insertions.
  * *`name`*: Label displayed under/next to the visual button.
  * *`callback`*: Instance of an action class with a `def call(self)` hook.

* **`registerToolbarAction(id: str, name: str, iconName: str, callback: PyObject) -> None`**  
  Injects a primary shortcut button inside the workspace top status bar next to Run.
  * *`iconName`*: Simple icon mapping key. Supported labels: `"sparkles"`, `"code"`, `"settings"`.

---

### 4. Lifecycle Event Triggers

* **`registerOnBeforeRun(callback: function) -> None`**  
  Pre-execution triggers. Passes control to the callback function immediately *before* the user's main Python execution begins. Ideal for Linters (Flake8 / PyLint), formatter verification checks, or metrics recorders.

* **`registerOnAfterRun(callback: function) -> None`**  
  Post-execution hooks. Triggers automatically immediately *after* code execution successfully completes. Excellent for log exporters, metrics capture, and remote storage upload synchronicity.

* **`registerOnFileChanged(callback: function) -> None`**  
  File-switch alerts. Invokes automatically when user loads different playground scripts or switches between active test files.

---

### 5. Debug Logs & Toasts

* **`logInfo(message: str) -> None`**  
  Outputs a grey details telemetry string to the console log stream.
* **`logSuccess(message: str) -> None`**  
  Outputs a green success notification statement prefixed with `[SUCCESS]`.
* **`logError(message: str) -> None`**  
  Prunes a red diagnostic statement directly into error terminals.
* **`showToast(message: str) -> None`**  
  Displays a localized transient toast message in the environment status system.

---

### 6. Sandbox File System Operations

Verify files or persist workspace records directly on local storage:

* **`getFiles() -> Array[str]`**  
  Returns names of all files stored inside the active Workspace scripts storage folder.
* **`readFile(fileName: str) -> str`**  
  Opens a specific local sandbox file context and reads all text content.
* **`writeFile(fileName: str, content: str) -> None`**  
  Saves/writes input text data to a destination file in the workspace scripts sub-directory.

---

## Reference Implementation Specimen

This script acts as the golden standard for a production-grade, highly functional custom extension matching the perfect structural requirements of the SDK:

```python
# =====================================================================
# Developer Gateway Extension Specs v1.0
# Author: Dev Support Group
# =====================================================================
from java import jclass
import json
import urllib.request

# 1. Initialize API reference 
ExtensionAPI = jclass("com.example.ExtensionAPI")

# 2. Design class-based UI handlers
class CodeSyncAgent:
    def call(self):
        ExtensionAPI.setStatusText("Sync Initializing...")
        ExtensionAPI.logInfo("[CloudSync] Contacting target synchronize repository...")
        
        try:
            # We perform full HTTP JSON queries safely with standard socket timeouts
            target_url = "https://httpbin.org/post"
            headers = {
                "Content-Type": "application/json",
                "User-Agent": "SandboxDeveloperGatewayClient"
            }
            body = json.dumps({
                "source": "Sandbox IDE",
                "length": len(ExtensionAPI.getText())
            }).encode('utf-8')
            
            req = urllib.request.Request(target_url, data=body, headers=headers, method="POST")
            with urllib.request.urlopen(req, timeout=4) as response:
                if response.status == 200:
                    ExtensionAPI.setStatusText("Developer Gateway Synchronized")
                    ExtensionAPI.logSuccess("Successfully backed up script source state onto web repository!")
                else:
                    ExtensionAPI.logError(f"Rejected with status: {response.status}")
        except Exception as e:
            ExtensionAPI.logError(f"Web synchronizer unreachable. Catching error: {str(e)}")
            ExtensionAPI.setStatusText("Developer Gateway Offline (Offline Cache active)")

# 3. Dynamic Check hook before run
def run_linter_safety():
    code = ExtensionAPI.getText()
    ExtensionAPI.logInfo("[Safe-Lint] Parsing workspace characters...")
    
    if "eval(" in code:
        ExtensionAPI.logInfo("[Lint Warning] 'eval()' call detected. Consider structured functions instead!")
    else:
        ExtensionAPI.logSuccess("[Safe-Lint] Syntax guidelines verified successfully.")

# 4. Bind hooks, action buttons, and status labels
ExtensionAPI.setStatusText("Developer Gateway Ready")
ExtensionAPI.registerOnBeforeRun(run_linter_safety)
ExtensionAPI.registerToolbarAction("cloud_sync_db", "Backup to Cloud", "sparkles", CodeSyncAgent())

# 5. Output load success confirmation
ExtensionAPI.logSuccess("Successfully installed Developer Gateway Extension! Clicking the top 'Backup' sparkles icon to test cloud gateway syncing.")
```

---

## Packaged Extension Directory & Layout Structure

To package, distribute, and register loaded directories (with the 'Import Ext' button), structure your folders matching this production layout:

```text
my_packaged_extension/
│
├── extension.json           # Root JSON configuration containing package metadata (MANDATORY)
├── README.md                # General developer readme, installation instructions & usage
├── main.py                  # Primary activation Python entrypoint (MANDATORY, runs via jclass bind)
│
├── config/                  # Static assets/settings directory
│   └── rules.json           # Declarative rule parameters parsed by python modules
│
└── utils/                   # Executable subfolders/libraries supporting modules
    ├── __init__.py          # Marks subdirectory as a valid python package import
    └── code_formatter.py    # Custom linter and formatting implementation code
```

### 1. Root Configuration: `extension.json` (or `manifest.json`)
The `extension.json` file resides in the root directory and defines the identifying attributes, target initiation script, and required packages to automatically fetch:
```json
{
  "id": "ext.quality.standards",
  "name": "Quality Standards Suite",
  "version": "1.2.0",
  "description": "Production code standard workspace optimizer. Injects real-time formatting, custom rules analyzer, and clean boilerplate structures.",
  "author": "AI Developer Guild",
  "main_script": "main.py",
  "pip_dependencies": [
    "black",
    "pylint"
  ]
}
```

### 2. Main Entrypoint: `main.py`
The primary script binds to the standard environment JVM `ExtensionAPI` dynamically:
- Resolves binding hooks.
- Registers custom top status bar **Toolbar Actions**.
- Registers custom high-visibility viewport **Floating Action Buttons (FABs)**.
- Attaches pre-run analyzer callback listeners.

```python
from java import jclass
import json

ExtensionAPI = jclass("com.example.ExtensionAPI")

# Core actions map inside class call self callbacks for memory preservation:
class ResetHandler:
    def call(self):
        ExtensionAPI.clearConsole()
        ExtensionAPI.logSuccess("Console buffers flushed!")
```

### 3. Modular Accessories (`utils/` & `config/`)
By utilizing modern relative package pathways, scripts can safely import secondary python helper subfolders:
```python
from utils.code_formatter import format_source
```
Supporting dictionaries, JSON sheets, or binary icons lookups resolve dynamically relative to standard package filepaths:
```python
config_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), "config", "rules.json")
```

### 4. Installation & Deployment Options

#### Option 1: Guided UI Import (Recommended)
To load a packaged extension directly inside your Sandbox runtime:
1. Open the **Explorer Tab** or launch the **File Manager** from the top toolbar.
2. Navigate to your extension directory (the folder containing `extension.json`).
3. Click the green **"Import Ext"** button. The system auto-parses metadata, installs `pip_dependencies` automatically, and activates your hooks.

#### Option 2: Terminal & Requirements Management (Shell-based)
For advanced developers needing manual control or `bash`-style package management:
1. **Manual pip Installation**: You can install specific libraries or a full `requirements.txt` via the integrated terminal console. Use the standard pip-load command:
   ```bash
   pip install -r requirements.txt
   ```
2. **Bash-style Commands**: The terminal supports standard unix-like file operations (`ls`, `pwd`, `cat`) to verify your structure before activation.
3. **Requirement Verification**: If an extension fails to load due to missing modules, you can manually verify pathing and dependencies using:
   ```bash
   python -m pip list
   ```
   This ensures your Debian-like sandbox environment is perfectly syncronized with your extension needs.

