# main.py - Python Sandbox core script
import sys

def greet(name="User"):
    return f"Hello, {name}! Welcome to the Chaquopy Python Sandbox."

def system_info():
    return {
        "version": sys.version,
        "platform": sys.platform,
        "path": sys.path
    }

if __name__ == "__main__":
    print(greet())
