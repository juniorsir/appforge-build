import sys
import os
try:
    import pip
    print("pip is available")
except Exception as e:
    print("pip not available:", e)
    
try:
    import urllib.request
    print("urllib is available")
except Exception as e:
    print("urllib not available:", e)
