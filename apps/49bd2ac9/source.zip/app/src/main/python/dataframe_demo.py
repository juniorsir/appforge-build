# dataframe_demo.py - Mini DataFrame & Statistical Analysis Demo

class MiniDataFrame:
    def __init__(self, data_dict):
        self.data = data_dict
        
    def describe(self):
        description = {}
        for col, values in self.data.items():
            if all(isinstance(v, (int, float)) for v in values):
                description[col] = {
                    "count": len(values),
                    "mean": sum(values) / len(values),
                    "max": max(values),
                    "min": min(values)
                }
        return description

if __name__ == "__main__":
    dataset = {
        "temperatures": [20.5, 22.1, 19.8, 23.4, 21.0],
        "humidity": [65, 70, 58, 62, 60]
    }
    df = MiniDataFrame(dataset)
    print("Dataset Summary statistics:")
    print(df.describe())
