# fibonacci_calc.py - High Performance Fibonacci Calculator

def calculate_fibonacci(n):
    """Calculates the first n numbers in the Fibonacci sequence."""
    if n <= 0:
        return []
    elif n == 1:
        return [0]
    
    sequence = [0, 1]
    while len(sequence) < n:
        sequence.append(sequence[-1] + sequence[-2])
    return sequence

if __name__ == "__main__":
    n = 10
    print(f"First {n} Fibonacci numbers: {calculate_fibonacci(n)}")
