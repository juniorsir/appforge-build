# Structured Modular Python Sandbox Extension

This package represents a **Perfect Extension Structure** designed for offline execution inside our Android Python Sandbox workspace environment. It demonstrates how modular scripts can be packaged, distributed, and loaded dynamically.

## Directory Layout Structure

A valid, production-grade packaged extension is required to conform to the following directory tree:

```text
sample_extension/
│
├── extension.json           # Root JSON configuration containing package metadata 
├── README.md                # General developer readme, installation instructions & usage
├── main.py                  # Primary activation Python entrypoint (runs via jclass bind)
│
├── config/                  # Static assets/settings directory
│   └── rules.json           # Declarative rule parameters parsed by python modules
│
└── utils/                   # Executable subfolders/libraries supporting modules
    ├── __init__.py          # Marks subdirectory as a valid python package import
    └── code_formatter.py    # Custom analyzer and formatting implementation code
```

---

## 1. Root Configuration: `extension.json`
The `extension.json` file resides in the root directory and defines the identifying attributes, target initiation script, and required packages to automatically fetch:
```json
{
  "id": "ext.quality.standards",
  "name": "Quality Standards Suite",
  "version": "1.2.0",
  "description": "Production code standard workspace optimizer. Injects formating, custom rules analyzer, and clear boilerplate structures.",
  "author": "AI Developer Guild",
  "main_script": "main.py",
  "pip_dependencies": ["black", "pylint"]
}
```

---

## 2. Main Entrypoint: `main.py`
The primary script binds to the standard environment JVM `ExtensionAPI` dynamically:
- Resolves binding hooks.
- Registers custom top status bar **Toolbar Actions**.
- Registers custom high-visibility viewport **Floating Action Buttons (FABs)**.
- Attaches pre-run analyzer callback listeners.

```python
from java import jclass
ExtensionAPI = jclass("com.example.ExtensionAPI")

# Core actions map inside class call self callbacks for memory preservation:
class ResetHandler:
    def call(self):
        ExtensionAPI.clearConsole()
        ExtensionAPI.logSuccess("Console buffers flushed!")
```

---

## 3. Modular Accessories (`utils/` & `config/`)
By utilizing modern relative package pathways, scripts can safely import secondary python helper subfolders:
```python
from utils.code_formatter import format_source
```
Supporting dictionaries, JSON sheets, or binary icons lookups resolve dynamically relative to standard package filepaths:
```python
config_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), "config", "rules.json")
```

---

## Installation / Activation Guides

To load this packaged extension layout directly inside your Sandbox runtime workspace:
1. Navigate to the **Explorer Tab** (or launch the **External File Manager** window on the top toolbar).
2. Browse your local simulated storage device directory. 
3. Select the `sample_extension/` directory.
4. Click the green **"Import Ext"** button. The system will auto-parse `extension.json`, bind your callbacks, and add it directly to your running **Extensions Panel** tab!
