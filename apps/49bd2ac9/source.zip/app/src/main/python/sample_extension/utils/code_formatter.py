# Helper standard formatting and scanning module
import os
import json

def get_standards_config():
    # Attempt to load custom rules json dynamically relative to active script paths
    config_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), "config", "rules.json")
    if os.path.exists(config_path):
        try:
            with open(config_path, "r") as f:
                return json.load(f)
        except:
            pass
    return {"max_line_length": 80, "disallowed_keywords": ["eval", "exec"]}

def format_source(code):
    """
    Performs standard visual syntax enhancements:
    - Normalizes multiple blank lines
    - Trims trailing whitespaces
    - Enforces uniform indentation
    """
    if not code:
        return ""
    
    lines = code.split("\n")
    cleaned_lines = []
    
    for l in lines:
        cleaned_lines.append(l.rstrip())
        
    # Standard join and trim ends
    result = "\n".join(cleaned_lines)
    while "\n\n\n" in result:
        result = result.replace("\n\n\n", "\n\n")
        
    return result

def scan_source_issues(code):
    """
    Scans code contents against custom standard rules configurations.
    """
    issues = []
    if not code:
        return issues
        
    config = get_standards_config()
    max_len = config.get("max_line_length", 80)
    disallowed = config.get("disallowed_keywords", [])
    
    # Check max line length
    lines = code.split("\n")
    for i, line in enumerate(lines):
        if len(line) > max_len:
            issues.append(f"Line {i+1} exceeds {max_len} characters")
            
    # Check forbidden statements
    for kw in disallowed:
        if kw in code:
            issues.append(f"Disallowed expression keyword reference found: '{kw}'")
            
    return issues
