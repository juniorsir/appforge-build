package com.example

import org.junit.Assert.*
import org.junit.Test

/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * See [testing documentation](http://d.android.com/tools/testing).
 */
class ExampleUnitTest {
  @Test
  fun addition_isCorrect() {
    assertEquals(4, 2 + 2)
  }

  @Test
  fun testParseParameters_simple() {
    val sig = "print(*objects, sep=' ', end='\\n')"
    val params = parseParameters(sig)
    assertEquals(3, params.size)
    assertEquals("*objects", params[0])
    assertEquals("sep=' '", params[1])
    assertEquals("end='\\n'", params[2])
  }

  @Test
  fun testParseParameters_nested() {
    val sig = "func(a, b=[1, 2], c={})"
    val params = parseParameters(sig)
    assertEquals(3, params.size)
    assertEquals("a", params[0])
    assertEquals("b=[1, 2]", params[1])
    assertEquals("c={}", params[2])
  }

  @Test
  fun testExtractUserDefinedFunctions() {
    val code = """
      def my_add(x, y=10):
          return x + y
          
      class Car:
          def __init__(self, make, model):
              pass
    """.trimIndent()
    
    val userFuncs = extractUserDefinedFunctions(code)
    assertTrue(userFuncs.containsKey("my_add"))
    assertEquals("my_add(x, y=10)", userFuncs["my_add"])
    
    // Test self parameter filtering
    assertTrue(userFuncs.containsKey("__init__"))
    assertEquals("__init__(make, model)", userFuncs["__init__"])
  }

  @Test
  fun testFindActiveSignature_builtin() {
    val code = "print("
    val activeInfo = findActiveSignature(code, code.length, emptyMap())
    assertNotNull(activeInfo)
    assertEquals("print", activeInfo!!.functionName)
    assertEquals(0, activeInfo.activeParamIndex)
  }

  @Test
  fun testFindActiveSignature_builtinWithArgs() {
    val code = "print(1, 'hello', "
    val activeInfo = findActiveSignature(code, code.length, emptyMap())
    assertNotNull(activeInfo)
    assertEquals("print", activeInfo!!.functionName)
    assertEquals(2, activeInfo.activeParamIndex)
  }

  @Test
  fun testFindActiveSignature_nested() {
    val code = "print(len(x), "
    val activeInfo = findActiveSignature(code, code.length, emptyMap())
    assertNotNull(activeInfo)
    assertEquals("print", activeInfo!!.functionName)
    assertEquals(1, activeInfo.activeParamIndex)
  }

  @Test
  fun testTerminalLineModels() {
    val line = TerminalLine("print('hello')", TerminalLineType.COMMAND)
    assertEquals("print('hello')", line.text)
    assertEquals(TerminalLineType.COMMAND, line.type)
    assertNotNull(line.timestamp)
  }

  @Test
  fun testGetWordAtCharIndex() {
    val text = "import os\ndef login():\n    pass\n"
    // hovering inside 'import'
    assertEquals("import", getWordAtCharIndex(text, 2))
    // hovering inside 'os'
    assertEquals("os", getWordAtCharIndex(text, 8))
    // hovering inside 'login'
    assertEquals("login", getWordAtCharIndex(text, 14))
    // hovering inside whitespace should return empty
    assertEquals("", getWordAtCharIndex(text, 24))
  }

  @Test
  fun testGetHoverTooltipText() {
    val code = """
      import sys
      
      class User:
          pass
          
      def login():
          return "session"
    """.trimIndent()
    
    // Exact matches
    assertEquals("Module: os", getHoverTooltipText("os", code))
    assertEquals("Class: User", getHoverTooltipText("User", code))
    assertEquals("str", getHoverTooltipText("str", code))
    assertEquals("int", getHoverTooltipText("int", code))
    assertEquals("list", getHoverTooltipText("list", code))
    assertEquals("dict", getHoverTooltipText("dict", code))
    assertEquals("Function: login()\nReturns user session", getHoverTooltipText("login", code))
    
    // Dynamic matching from content
    assertEquals("Module: sys", getHoverTooltipText("sys", code))
  }

  @Test
  fun testCheckPythonSyntaxMissingColon() {
    val code = """
      if x == 5
          pass
    """.trimIndent()
    val errors = checkPythonSyntax(code)
    assertTrue(errors.any { it.type == "missing_colon" && it.line == 0 })
  }

  @Test
  fun testCheckPythonSyntaxMissingBrackets() {
    val code = """
      data = [1, 2, 3
      print(data
    """.trimIndent()
    val errors = checkPythonSyntax(code)
    assertTrue(errors.any { it.type == "missing_bracket" && it.line == 0 })
    assertTrue(errors.any { it.type == "missing_paren" && it.line == 1 })
  }

  @Test
  fun testCheckPythonSyntaxBadIndentation() {
    val code = """
      def calculate():
      pass
    """.trimIndent()
    val errors = checkPythonSyntax(code)
    assertTrue(errors.any { it.type == "bad_indent" && it.line == 1 })
  }

  @Test
  fun testCheckPythonSyntaxUnclosedStrings() {
    val code = "msg = \"hello"
    val errors = checkPythonSyntax(code)
    assertTrue(errors.any { it.type == "unclosed_string" })
  }

  @Test
  fun testCheckPythonSyntaxInvalidKeywords() {
    val code = """
      x++
      y = null
      flag = true
      is_equal = a === b
    """.trimIndent()
    val errors = checkPythonSyntax(code)
    assertTrue(errors.any { it.type == "invalid_syntax" && it.message.contains("increment") })
    assertTrue(errors.any { it.type == "invalid_syntax" && it.message.contains("null") })
    assertTrue(errors.any { it.type == "invalid_syntax" && it.message.contains("capitalized") })
    assertTrue(errors.any { it.type == "invalid_syntax" && it.message.contains("===") })
  }

  @Test
  fun testSnippetTriggerAtCursor() {
    val code = "for"
    val trigger = getSnippetTriggerAtCursor(code, 3)
    assertNotNull(trigger)
    assertEquals("for", trigger!!.first)
    assertEquals(0, trigger.second)

    // Not a trigger word
    assertNull(getSnippetTriggerAtCursor("fort", 4))

    // Part of a larger word
    assertNull(getSnippetTriggerAtCursor("my_for", 6))
  }

  @Test
  fun testSnippetExpansionWithIndent() {
    val indent = "    "
    val expanded = getSnippetExpansion("for", indent)
    val expected = "for item in iterable:\n        pass"
    assertEquals(expected, expanded)

    val expandedIf = getSnippetExpansion("if", "  ")
    val expectedIf = "if condition:\n      pass" // Wait, is it?
    // Let's trace getSnippetExpansion: "if condition:\n    pass".split("\n")
    // "if condition:" and "    pass" joined with "\n  " -> "if condition:\n      pass"
    assertEquals(expectedIf, expandedIf)
  }

  @Test
  fun testGetImportedModules() {
    val code = """
      import os, sys
      import json as j
      from math import sin, cos as c
      # import random
    """.trimIndent()
    val imported = getImportedModules(code)
    assertTrue(imported.contains("os"))
    assertTrue(imported.contains("sys"))
    assertTrue(imported.contains("json"))
    assertTrue(imported.contains("j"))
    assertTrue(imported.contains("math"))
    assertTrue(imported.contains("sin"))
    assertTrue(imported.contains("c"))
    assertFalse(imported.contains("random"))
  }

  @Test
  fun testFindUnimportedModules() {
    val code = """
      data = json.loads(text)
      print(math.pi)
      # sys.exit()
      val_str = "os.path"
    """.trimIndent()
    val unimported = findUnimportedModules(code)
    assertTrue(unimported.any { it.type == "missing_import_json" && it.line == 0 })
    assertTrue(unimported.any { it.type == "missing_import_math" && it.line == 1 })
    // Commented out reference should not trigger error:
    assertFalse(unimported.any { it.type == "missing_import_sys" })
    // Double quoted string literal should not trigger error:
    assertFalse(unimported.any { it.type == "missing_import_os" })
  }

  @Test
  fun testCheckPythonSyntaxWithUnimportedDetection() {
    val code = """
      import os
      print(os.getcwd())
      print(json.dumps(data))
    """.trimIndent()
    val errors = checkPythonSyntax(code)
    // "os" is imported, so no error for line 1
    assertFalse(errors.any { it.type == "missing_import_os" })
    // "json" is unimported, so there's an error for line 2
    assertTrue(errors.any { it.type == "missing_import_json" && it.line == 2 })
  }

  @Test
  fun testGetWordAtCursor() {
    val text = "def parse_data(input_str): return None"
    
    // Inside 'parse_data'
    var wordPair = getWordAtCursor(text, 5)
    assertNotNull(wordPair)
    assertEquals("parse_data", wordPair!!.first)
    assertEquals(4, wordPair.second)

    // At edge
    wordPair = getWordAtCursor(text, 4)
    assertNotNull(wordPair)
    assertEquals("parse_data", wordPair!!.first)

    // After spaces (just after 'def')
    wordPair = getWordAtCursor(text, 3)
    assertNotNull(wordPair)
    assertEquals("def", wordPair!!.first)
  }

  @Test
  fun testFindDefinitionInProject() {
    val currentScript = "print(my_var)\nmy_var = 10"
    val otherScript = PythonScript("other.py", "def my_func(): pass", "10", "now")
    val scripts = listOf(otherScript)

    var defResult = findDefinitionInProject("my_var", currentScript, scripts)
    assertNotNull(defResult)
    assertEquals("", defResult!!.first) 

    defResult = findDefinitionInProject("my_func", currentScript, scripts)
    assertNotNull(defResult)
    assertEquals("other.py", defResult!!.first)

    defResult = findDefinitionInProject("not_found", currentScript, scripts)
    assertNull(defResult)
  }

  @Test
  fun testFindReferencesInProject() {
    val scripts = listOf(
      PythonScript("a.py", "val = compute()\nprint(val)", "10", "now"),
      PythonScript("b.py", "def compute(): return 42\nval2 = compute()", "10", "now")
    )
    val refs = findReferencesInProject("compute", scripts)
    assertEquals(3, refs.size)
    assertEquals(1, refs.count { it.first == "a.py" })
    assertEquals(2, refs.count { it.first == "b.py" })
  }
}

