package org.gradle.util;

import java.io.Serializable;

public class VersionNumber implements Comparable<VersionNumber>, Serializable {
    public static final VersionNumber UNKNOWN = new VersionNumber(0, 0, 0, null);

    private final int major;
    private final int minor;
    private final int micro;
    private final String qualifier;

    public VersionNumber(int major, int minor, int micro, String qualifier) {
        this.major = major;
        this.minor = minor;
        this.micro = micro;
        this.qualifier = qualifier;
    }

    public int getMajor() {
        return major;
    }

    public int getMinor() {
        return minor;
    }

    public int getMicro() {
        return micro;
    }

    public String getQualifier() {
        return qualifier;
    }

    public static VersionNumber parse(String version) {
        if (version == null || version.isEmpty()) {
            return UNKNOWN;
        }
        int major = 0;
        int minor = 0;
        int micro = 0;
        String qualifier = null;

        try {
            String[] parts = version.split("-", 2);
            String mainPart = parts[0];
            if (parts.length > 1) {
                qualifier = parts[1];
            }

            String[] numbers = mainPart.split("\\.");
            if (numbers.length > 0) {
                major = Integer.parseInt(numbers[0]);
            }
            if (numbers.length > 1) {
                minor = Integer.parseInt(numbers[1]);
            }
            if (numbers.length > 2) {
                micro = Integer.parseInt(numbers[2]);
            }
        } catch (Exception e) {
            // fallback
        }

        return new VersionNumber(major, minor, micro, qualifier);
    }

    @Override
    public int compareTo(VersionNumber other) {
        if (this.major != other.major) {
            return Integer.compare(this.major, other.major);
        }
        if (this.minor != other.minor) {
            return Integer.compare(this.minor, other.minor);
        }
        if (this.micro != other.micro) {
            return Integer.compare(this.micro, other.micro);
        }
        if (this.qualifier == null && other.qualifier != null) {
            return 1;
        }
        if (this.qualifier != null && other.qualifier == null) {
            return -1;
        }
        if (this.qualifier != null && other.qualifier != null) {
            return this.qualifier.compareTo(other.qualifier);
        }
        return 0;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (!(obj instanceof VersionNumber)) return false;
        VersionNumber other = (VersionNumber) obj;
        return major == other.major && minor == other.minor && micro == other.micro && 
               ((qualifier == null && other.qualifier == null) || (qualifier != null && qualifier.equals(other.qualifier)));
    }

    @Override
    public int hashCode() {
        int result = major;
        result = 31 * result + minor;
        result = 31 * result + micro;
        result = 31 * result + (qualifier != null ? qualifier.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(major).append(".").append(minor).append(".").append(micro);
        if (qualifier != null) {
            sb.append("-").append(qualifier);
        }
        return sb.toString();
    }
}
