package com.example.security

import android.app.Activity
import android.app.KeyguardManager
import android.content.Context
import android.content.DialogInterface
import android.hardware.biometrics.BiometricManager
import android.hardware.biometrics.BiometricPrompt
import android.os.Build
import android.os.CancellationSignal
import android.util.Log

/**
 * Manager for Biometric (Face Unlock / Fingerprint) Authentication.
 *
 * STRICT SECURITY POLICY:
 * Does NOT permit device credential fallback (PIN, Pattern, Password).
 * Only strong biometric sensors (Face / Biometrics) are accepted.
 */
class AuraBiometricAuthManager(private val context: Context) {

    private val TAG = "AuraBiometricAuth"
    private var cancellationSignal: CancellationSignal? = null

    /**
     * Checks if the device has physical Face Unlock hardware.
     */
    fun hasFaceHardware(): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                context.packageManager.hasSystemFeature(android.content.pm.PackageManager.FEATURE_FACE)
            } else {
                false
            }
        } catch (e: Exception) {
            false
        }
    }

    /**
     * Checks if biometric hardware (Face / Fingerprint) is available and enrolled.
     * Evaluates both BIOMETRIC_STRONG and BIOMETRIC_WEAK to prioritize Face Unlock.
     */
    fun isBiometricAvailable(): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                val biometricManager = context.getSystemService(BiometricManager::class.java)
                val authenticators = BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.BIOMETRIC_WEAK
                biometricManager?.canAuthenticate(authenticators) == BiometricManager.BIOMETRIC_SUCCESS
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val biometricManager = context.getSystemService(BiometricManager::class.java)
                biometricManager?.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG) == BiometricManager.BIOMETRIC_SUCCESS
            } else {
                val keyguardManager = context.getSystemService(Context.KEYGUARD_SERVICE) as? KeyguardManager
                keyguardManager?.isDeviceSecure ?: false
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to check biometric availability", e)
            false
        }
    }

    /**
     * Checks if biometric hardware and security credentials are configured.
     */
    fun isBiometricOrDeviceCredentialAvailable(): Boolean {
        return try {
            val keyguardManager = context.getSystemService(Context.KEYGUARD_SERVICE) as? KeyguardManager
            keyguardManager?.isDeviceSecure ?: false
        } catch (e: Exception) {
            Log.e(TAG, "Failed to check device security status", e)
            false
        }
    }

    /**
     * Prompts user for Face / Biometric authentication.
     * CRITICAL: Screen lock fallback (PIN/Pattern) is STRICTLY DISABLED.
     * Prioritizes Face verification by configuring passive recognition and Class 2/3 sensors.
     */
    fun authenticateFaceOnly(
        activity: Activity,
        title: String = "Face Authentication Required",
        subtitle: String = "Authorize Bridge Connection",
        description: String = "Look at the screen to verify your Face and authorize Termux bridge requests. (Screen lock PIN/Pattern is disabled)",
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            try {
                cancellationSignal?.cancel()
                val signal = CancellationSignal()
                cancellationSignal = signal

                val builder = BiometricPrompt.Builder(activity)
                    .setTitle(title)
                    .setSubtitle(subtitle)
                    .setDescription(description)

                // Android 10+ (API 29+): Disable extra confirmation tap for instant passive Face Unlock
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    builder.setConfirmationRequired(false)
                }

                // Android 11+ (API 30+): Allow both Strong and Weak biometrics so OEM Face Unlock
                // is prioritized and activated, while strictly forbidding DEVICE_CREDENTIAL (PIN/Pattern).
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    builder.setAllowedAuthenticators(
                        BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.BIOMETRIC_WEAK
                    )
                }

                // Enforce biometric sensor validation: Only "Cancel" is available, no PIN/Pattern fallback
                builder.setNegativeButton("Cancel", activity.mainExecutor, DialogInterface.OnClickListener { _, _ ->
                    onError("Face authentication cancelled by user")
                })

                val prompt = builder.build()

                val callback = object : BiometricPrompt.AuthenticationCallback() {
                    override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult?) {
                        super.onAuthenticationSucceeded(result)
                        Log.i(TAG, "Biometric Face authentication succeeded!")
                        activity.runOnUiThread {
                            onSuccess()
                        }
                    }

                    override fun onAuthenticationError(errorCode: Int, errString: CharSequence?) {
                        super.onAuthenticationError(errorCode, errString)
                        val message = when (errorCode) {
                            BiometricPrompt.BIOMETRIC_ERROR_NO_BIOMETRICS -> "No Face enrolled in Android Settings. Please register Face Unlock in Settings > Security."
                            BiometricPrompt.BIOMETRIC_ERROR_HW_NOT_PRESENT -> "No physical biometric hardware detected on this device/emulator."
                            BiometricPrompt.BIOMETRIC_ERROR_HW_UNAVAILABLE -> "Biometric hardware is temporarily unavailable."
                            BiometricPrompt.BIOMETRIC_ERROR_LOCKOUT -> "Too many failed attempts. Biometric sensor locked for 30 seconds."
                            BiometricPrompt.BIOMETRIC_ERROR_USER_CANCELED, BiometricPrompt.BIOMETRIC_ERROR_CANCELED -> "Face authentication cancelled by user."
                            else -> errString?.toString() ?: "Android Biometric error: $errorCode"
                        }
                        Log.w(TAG, "Biometric authentication error ($errorCode): $message")
                        activity.runOnUiThread {
                            onError(message)
                        }
                    }

                    override fun onAuthenticationFailed() {
                        super.onAuthenticationFailed()
                        Log.w(TAG, "Biometric Face authentication failed (Face not recognized)")
                    }
                }

                prompt.authenticate(signal, activity.mainExecutor, callback)
            } catch (e: Exception) {
                Log.e(TAG, "Failed to launch native BiometricPrompt: ${e.message}", e)
                onError(e.message ?: "Failed to launch Face BiometricPrompt")
            }
        } else {
            onError("Biometric authentication requires Android 9.0+ (API 28)")
        }
    }

    fun cancelAuthentication() {
        try {
            cancellationSignal?.cancel()
            cancellationSignal = null
        } catch (ignored: Exception) {}
    }

    /**
     * Retrieves the biometric & authentication capability status of the device.
     */
    fun getBiometricStatus(): Map<String, Any> {
        val keyguardManager = context.getSystemService(Context.KEYGUARD_SERVICE) as? KeyguardManager
        val isSecure = keyguardManager?.isDeviceSecure ?: false
        val isLocked = keyguardManager?.isKeyguardLocked ?: false

        return mapOf(
            "isDeviceSecure" to isSecure,
            "isKeyguardLocked" to isLocked,
            "isBiometricAvailable" to isBiometricAvailable(),
            "hasFaceHardware" to hasFaceHardware(),
            "facePrioritized" to true,
            "supportedTypes" to listOf("FACE_AUTHENTICATION", "BIOMETRIC_STRONG", "BIOMETRIC_WEAK"),
            "pinPatternAllowed" to false,
            "sdkVersion" to Build.VERSION.SDK_INT
        )
    }
}

