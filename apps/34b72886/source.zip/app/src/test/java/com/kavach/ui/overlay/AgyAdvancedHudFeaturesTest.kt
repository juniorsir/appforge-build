package com.kavach.ui.overlay

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Looper
import androidx.test.core.app.ApplicationProvider
import com.kavach.accessibility.models.AccessibilityNodeModel
import org.json.JSONObject
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows
import org.robolectric.annotation.Config
import org.robolectric.shadows.ShadowSettings

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34], qualifiers = "w360dp-h800dp-xxhdpi")
class AgyAdvancedHudFeaturesTest {

    private lateinit var context: Context
    private lateinit var floatingOverlayManager: FloatingOverlayManager
    private lateinit var hudManager: AgyHudOverlayManager
    private var mockForegroundPackage: String = "com.android.settings"
    private var mockRootNodes: List<AccessibilityNodeModel> = emptyList()

    private val broadcastedCommands = mutableListOf<JSONObject>()
    private val savedMacros = mutableListOf<Triple<String, String, String>>()

    @Before
    fun setUp() {
        context = ApplicationProvider.getApplicationContext()
        ShadowSettings.setCanDrawOverlays(true)
        context.getSharedPreferences("agy_hud_power_prefs", Context.MODE_PRIVATE)
            .edit()
            .clear()
            .commit()

        floatingOverlayManager = FloatingOverlayManager(context)
        broadcastedCommands.clear()
        savedMacros.clear()

        hudManager = AgyHudOverlayManager(
            context = context,
            floatingOverlayManager = floatingOverlayManager,
            onCommandBroadcast = { cmd -> broadcastedCommands.add(cmd) },
            onSaveMacro = { title, prompt, icon -> savedMacros.add(Triple(title, prompt, icon)) }
        )
        hudManager.foregroundPackageProvider = { mockForegroundPackage }
        hudManager.nodeTreeProvider = { mockRootNodes }
    }

    @After
    fun tearDown() {
        hudManager.resetState()
        Shadows.shadowOf(Looper.getMainLooper()).idle()
    }

    private fun makeNode(
        text: String? = null,
        contentDescription: String? = null,
        viewId: String? = null,
        className: String? = "android.widget.View",
        isClickable: Boolean = false,
        bounds: String = "[0,0][1080,2400]",
        packageName: String? = "com.android.settings",
        children: List<AccessibilityNodeModel> = emptyList()
    ): AccessibilityNodeModel = AccessibilityNodeModel(
        text = text,
        contentDescription = contentDescription,
        viewId = viewId,
        className = className,
        isClickable = isClickable,
        isScrollable = false,
        isEditable = false,
        isFocused = false,
        bounds = bounds,
        packageName = packageName,
        children = children
    )

    @Test
    fun `demonstration recorder captures accessibility-enriched steps, saves macro, and emits DEMO_RECORDED`() {
        mockForegroundPackage = "com.android.settings"
        mockRootNodes = listOf(
            makeNode(
                className = "android.widget.FrameLayout",
                packageName = "com.android.settings",
                bounds = "[0,0][1080,2400]",
                children = listOf(
                    makeNode(
                        className = "android.widget.Switch",
                        text = "Wi-Fi",
                        viewId = "com.android.settings:id/wifi_switch",
                        packageName = "com.android.settings",
                        bounds = "[800,300][1000,400]",
                        isClickable = true
                    ),
                    makeNode(
                        className = "android.widget.Button",
                        text = "agy_hud_ignore_me",
                        viewId = "com.kavach:id/agy_hud_btn",
                        packageName = "com.kavach",
                        bounds = "[100,100][300,200]",
                        isClickable = true
                    )
                )
            )
        )

        // 1. Start demo recording via JSON command
        val startRes = hudManager.handleDemoAction(
            JSONObject().apply {
                put("action", "start")
                put("title", "Toggle Wi-Fi Flow")
            }
        )
        Shadows.shadowOf(Looper.getMainLooper()).idle()

        assertTrue(startRes.optBoolean("success"))
        assertTrue(startRes.optBoolean("active"))
        assertEquals("Toggle Wi-Fi Flow", hudManager.hudState.value.demoSession.title)
        assertTrue(hudManager.hudState.value.demoSession.active)

        // 2. Record a TAP step at (900, 350) which hits the Wi-Fi Switch node
        val tapRes = hudManager.handleDemoAction(
            JSONObject().apply {
                put("action", "add_step")
                put("step", JSONObject().apply {
                    put("action", "TAP")
                    put("x", 900)
                    put("y", 350)
                })
            }
        )
        Shadows.shadowOf(Looper.getMainLooper()).idle()

        assertEquals(1, tapRes.optInt("stepCount"))
        val firstStep = hudManager.hudState.value.demoSession.steps.first()
        assertEquals("TAP", firstStep.actionType)
        assertEquals("Wi-Fi", firstStep.nodeLabel)
        assertEquals("com.android.settings:id/wifi_switch", firstStep.viewId)
        assertEquals("com.android.settings", firstStep.packageName)

        // 3. Save recorded demo as a reusable HUD Macro
        val savedMacro = hudManager.saveDemoAsMacro("Wi-Fi Quick Macro")
        Shadows.shadowOf(Looper.getMainLooper()).idle()

        assertTrue(savedMacro)
        assertEquals(1, savedMacros.size)
        assertEquals("Wi-Fi Quick Macro", savedMacros.first().first)
        assertTrue(savedMacros.first().second.contains("Wi-Fi"))

        // 4. Finish and send DEMO_RECORDED command to Agy
        broadcastedCommands.clear()
        val finishRes = hudManager.finishAndSendDemoToAgy()
        Shadows.shadowOf(Looper.getMainLooper()).idle()

        assertTrue(finishRes.optBoolean("success"))
        assertFalse(hudManager.hudState.value.demoSession.active)
        val demoCmd = broadcastedCommands.firstOrNull { it.optString("action") == "DEMO_RECORDED" }
        assertNotNull("Expected DEMO_RECORDED command to be emitted", demoCmd)
        assertTrue(demoCmd!!.optString("text").contains("Toggle Wi-Fi Flow"))
        assertNotNull(demoCmd.optJSONObject("payload")?.optJSONObject("demoSession"))
    }

    @Test
    fun `smart clipboard and scratchpad infers item kinds, pins, copies, and sends ask prompt`() {
        // 1. Add URL item (kind auto-inferred as 'url')
        hudManager.handleScratchpadAction(
            JSONObject().apply {
                put("action", "add")
                put("content", "https://developer.android.com/jetpack/compose")
                put("label", "Compose Docs")
                put("pinned", true)
            }
        )
        // 2. Add JSON item (kind auto-inferred as 'json')
        hudManager.handleScratchpadAction(
            JSONObject().apply {
                put("action", "add")
                put("content", """{"status":"ok","count":3}""")
            }
        )
        // 3. Add Code item (kind auto-inferred as 'code')
        hudManager.handleScratchpadAction(
            JSONObject().apply {
                put("action", "add")
                put("content", "fun main() {\n    val x = 42\n}")
            }
        )
        Shadows.shadowOf(Looper.getMainLooper()).idle()

        val items = hudManager.scratchpadManager.currentItems()
        assertEquals(3, items.size)

        val urlItem = items.first { it.label == "Compose Docs" }
        assertEquals("url", urlItem.kind)
        assertTrue(urlItem.pinned)

        val jsonItem = items.first { it.content.startsWith("{") }
        assertEquals("json", jsonItem.kind)

        val codeItem = items.first { it.content.contains("fun main") }
        assertEquals("code", codeItem.kind)

        // 4. Copy item to system clipboard via scratchpad action
        hudManager.handleScratchpadAction(
            JSONObject().apply {
                put("action", "copy")
                put("id", urlItem.id)
            }
        )
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        assertEquals(
            "https://developer.android.com/jetpack/compose",
            clipboard.primaryClip?.getItemAt(0)?.coerceToText(context)?.toString()
        )

        // 5. Capture from system clipboard
        clipboard.setPrimaryClip(ClipData.newPlainText("test", "Clipboard captured note"))
        hudManager.handleScratchpadAction(
            JSONObject().apply {
                put("action", "capture_clipboard")
            }
        )
        assertTrue(hudManager.scratchpadManager.currentItems().any { it.content == "Clipboard captured note" })

        // 6. Ask Agy with a scratchpad item -> emits PROMPT command
        broadcastedCommands.clear()
        hudManager.handleScratchpadAction(
            JSONObject().apply {
                put("action", "ask")
                put("id", urlItem.id)
            }
        )
        Shadows.shadowOf(Looper.getMainLooper()).idle()

        assertTrue(
            broadcastedCommands.any {
                it.optString("action") == "PROMPT" &&
                    it.optString("text").contains("https://developer.android.com/jetpack/compose")
            }
        )
    }

    @Test
    fun `live screen diff and visual watchdog triggers WATCHDOG_TRIGGERED when target text appears`() {
        // Initial screen without target text
        mockRootNodes = listOf(
            makeNode(
                className = "android.widget.FrameLayout",
                packageName = "com.termux",
                bounds = "[0,0][1080,2400]",
                children = listOf(
                    makeNode(
                        className = "android.widget.TextView",
                        text = "Compiling project...",
                        packageName = "com.termux",
                        bounds = "[40,200][800,300]"
                    )
                )
            )
        )

        // Arm a text_contains watchdog waiting for "BUILD SUCCESSFUL"
        val armRes = hudManager.setWatchdog(
            JSONObject().apply {
                put("action", "arm")
                put("rule", "text_contains")
                put("targetText", "BUILD SUCCESSFUL")
                put("triggerPrompt", "Deploy the built APK and notify me")
                put("oneShot", true)
            }
        )
        Shadows.shadowOf(Looper.getMainLooper()).idle()

        assertTrue(armRes.optBoolean("success"))
        assertTrue(hudManager.hudState.value.watchdog.active)
        assertEquals("text_contains", hudManager.hudState.value.watchdog.rule)
        broadcastedCommands.clear()

        // Evaluate before target text appears -> should not trigger
        hudManager.evaluateWatchdogNow()
        assertEquals(0, hudManager.hudState.value.watchdog.triggeredCount)
        assertTrue(broadcastedCommands.isEmpty())

        // Mutate foreground UI tree so "BUILD SUCCESSFUL in 4s" appears
        mockRootNodes = listOf(
            makeNode(
                className = "android.widget.FrameLayout",
                packageName = "com.termux",
                bounds = "[0,0][1080,2400]",
                children = listOf(
                    makeNode(
                        className = "android.widget.TextView",
                        text = "BUILD SUCCESSFUL in 4s",
                        packageName = "com.termux",
                        bounds = "[40,200][800,300]"
                    )
                )
            )
        )

        hudManager.evaluateWatchdogNow()
        Shadows.shadowOf(Looper.getMainLooper()).idle()

        val afterMatch = hudManager.hudState.value.watchdog
        assertEquals(1, afterMatch.triggeredCount)
        assertFalse("oneShot watchdog should auto-disarm after firing", afterMatch.active)
        assertTrue(afterMatch.lastTriggeredSummary.contains("BUILD SUCCESSFUL"))

        val wdCmd = broadcastedCommands.firstOrNull { it.optString("action") == "WATCHDOG_TRIGGERED" }
        assertNotNull("Expected WATCHDOG_TRIGGERED command to be emitted", wdCmd)
        assertEquals("Deploy the built APK and notify me", wdCmd!!.optString("text"))
        assertTrue(wdCmd.optJSONObject("payload")?.optString("diffSummary", "")!!.contains("BUILD SUCCESSFUL"))
    }

    @Test
    fun `voice co-pilot speaks DONE summaries and auto-activates hands-free listening on NEEDS_INPUT question`() {
        // 1. Enable Voice Co-Pilot
        val cfgRes = hudManager.setVoiceCoPilot(
            JSONObject().apply {
                put("enabled", true)
                put("autoSpeakDone", true)
                put("autoSpeakQuestion", true)
                put("autoListenOnQuestion", true)
            }
        )
        Shadows.shadowOf(Looper.getMainLooper()).idle()
        assertTrue(cfgRes.optBoolean("success"))
        assertTrue(hudManager.hudState.value.voiceCoPilot.enabled)

        // 2. Transition HUD from WORKING to DONE -> should speak completion summary
        hudManager.updateState(
            JSONObject().apply {
                put("state", "WORKING")
                put("title", "Checking battery")
                put("currentAction", "Inspecting battery stats")
            }
        )
        Shadows.shadowOf(Looper.getMainLooper()).idle()

        hudManager.updateState(
            JSONObject().apply {
                put("state", "DONE")
                put("title", "Checking battery")
                put("currentAction", "Battery is at 88 percent and charging")
            }
        )
        Shadows.shadowOf(Looper.getMainLooper()).idle()

        assertEquals(
            "Battery is at 88 percent and charging",
            hudManager.voiceCoPilotManager.lastSpokenTextFlow.value
        )

        // 3. Transition HUD to NEEDS_INPUT with a question -> should speak question and auto-activate hands-free mic
        hudManager.updateState(
            JSONObject().apply {
                put("state", "NEEDS_INPUT")
                put("title", "Confirm recipient")
                put("question", "Which contact should I message?")
            }
        )
        Shadows.shadowOf(Looper.getMainLooper()).idle()

        assertEquals(
            "Which contact should I message?",
            hudManager.voiceCoPilotManager.lastSpokenTextFlow.value
        )
    }
}
