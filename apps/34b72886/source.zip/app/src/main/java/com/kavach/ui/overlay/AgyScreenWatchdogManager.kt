package com.kavach.ui.overlay

import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import com.kavach.accessibility.models.AccessibilityNodeModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONObject
import java.util.Locale

/**
 * Feature 3: Live Screen Diff & Visual Watchdog Triggers Manager.
 *
 * Monitors the live foreground Accessibility UI tree (optionally bounded to a snipped region)
 * for visual/structural changes or target text/node conditions, and fires an automatic
 * HUD prompt or `WATCHDOG_TRIGGERED` event when a rule matches.
 */
class AgyScreenWatchdogManager(
    var nodeTreeProvider: (() -> List<AccessibilityNodeModel>)? = null,
    var foregroundPackageProvider: (() -> String?)? = null,
    var onWatchdogTriggered: ((AgyHudDynamicModels.ScreenWatchdogConfig, String) -> Unit)? = null
) {
    private val mainHandler = Handler(Looper.getMainLooper())
    private val _watchdogFlow = MutableStateFlow(AgyHudDynamicModels.ScreenWatchdogConfig(active = false))
    val watchdogFlow: StateFlow<AgyHudDynamicModels.ScreenWatchdogConfig> = _watchdogFlow.asStateFlow()

    var onWatchdogStateChanged: ((AgyHudDynamicModels.ScreenWatchdogConfig) -> Unit)? = null

    private var baselineSignature: String? = null
    private var baselineLabels: Set<String> = emptySet()

    private val pollRunnable = object : Runnable {
        override fun run() {
            val current = _watchdogFlow.value
            if (!current.active) return
            evaluateNow()
            val afterEval = _watchdogFlow.value
            if (afterEval.active) {
                mainHandler.postDelayed(this, afterEval.intervalMs)
            }
        }
    }

    fun currentWatchdog(): AgyHudDynamicModels.ScreenWatchdogConfig = _watchdogFlow.value

    fun armWatchdog(config: AgyHudDynamicModels.ScreenWatchdogConfig): AgyHudDynamicModels.ScreenWatchdogConfig {
        mainHandler.removeCallbacks(pollRunnable)
        val nodes = collectFilteredNodes(config.region)
        baselineSignature = computeTreeSignature(nodes)
        baselineLabels = collectNodeLabels(nodes)

        val armed = config.copy(active = true)
        _watchdogFlow.value = armed
        onWatchdogStateChanged?.invoke(armed)
        mainHandler.postDelayed(pollRunnable, armed.intervalMs)
        return armed
    }

    fun disarmWatchdog(): AgyHudDynamicModels.ScreenWatchdogConfig {
        mainHandler.removeCallbacks(pollRunnable)
        val disarmed = _watchdogFlow.value.copy(active = false)
        _watchdogFlow.value = disarmed
        onWatchdogStateChanged?.invoke(disarmed)
        return disarmed
    }

    fun clearWatchdog(): AgyHudDynamicModels.ScreenWatchdogConfig {
        mainHandler.removeCallbacks(pollRunnable)
        baselineSignature = null
        baselineLabels = emptySet()
        val cleared = AgyHudDynamicModels.ScreenWatchdogConfig(active = false)
        _watchdogFlow.value = cleared
        onWatchdogStateChanged?.invoke(cleared)
        return cleared
    }

    /**
     * Evaluates the currently configured watchdog against the latest accessibility node tree.
     * Can be invoked periodically by the internal timer or synchronously in tests / manual checks.
     */
    fun evaluateNow(): JSONObject {
        val current = _watchdogFlow.value
        if (!current.active) {
            return JSONObject().apply {
                put("success", true)
                put("status", "idle")
                put("triggered", false)
                put("watchdog", current.toJson())
            }
        }

        val nodes = collectFilteredNodes(current.region)
        val currentSignature = computeTreeSignature(nodes)
        val currentLabels = collectNodeLabels(nodes)
        val rule = current.rule.lowercase(Locale.US)
        val target = current.targetText.trim()

        var matched = false
        var diffSummary = ""

        when (rule) {
            "any_change" -> {
                val baseSig = baselineSignature
                if (baseSig == null) {
                    baselineSignature = currentSignature
                    baselineLabels = currentLabels
                } else if (currentSignature != baseSig) {
                    matched = true
                    val added = (currentLabels - baselineLabels).take(3)
                    val removed = (baselineLabels - currentLabels).take(3)
                    diffSummary = buildString {
                        append("Screen changed")
                        if (added.isNotEmpty()) append(" (+${added.joinToString(", ")})")
                        if (removed.isNotEmpty()) append(" (-${removed.joinToString(", ")})")
                    }
                    baselineSignature = currentSignature
                    baselineLabels = currentLabels
                }
            }
            "text_contains" -> {
                if (target.isNotEmpty()) {
                    val matchingNode = nodes.firstOrNull { node ->
                        node.text?.contains(target, ignoreCase = true) == true ||
                            node.contentDescription?.contains(target, ignoreCase = true) == true
                    }
                    if (matchingNode != null) {
                        matched = true
                        val foundLabel = matchingNode.text ?: matchingNode.contentDescription ?: target
                        diffSummary = "Matched text '$target' in '${foundLabel.take(40)}'"
                    }
                }
            }
            "text_disappears" -> {
                if (target.isNotEmpty()) {
                    val stillPresent = nodes.any { node ->
                        node.text?.contains(target, ignoreCase = true) == true ||
                            node.contentDescription?.contains(target, ignoreCase = true) == true
                    }
                    if (!stillPresent) {
                        matched = true
                        diffSummary = "Text '$target' disappeared from screen"
                    }
                }
            }
            "node_appears" -> {
                if (target.isNotEmpty()) {
                    val matchingNode = nodes.firstOrNull { node ->
                        node.viewId?.contains(target, ignoreCase = true) == true ||
                            node.text?.contains(target, ignoreCase = true) == true ||
                            node.contentDescription?.contains(target, ignoreCase = true) == true ||
                            node.className?.contains(target, ignoreCase = true) == true
                    }
                    if (matchingNode != null) {
                        matched = true
                        val idOrText = matchingNode.viewId ?: matchingNode.text ?: matchingNode.contentDescription ?: target
                        diffSummary = "Node '$idOrText' appeared on screen"
                    }
                }
            }
        }

        return if (matched) {
            val nextActive = !current.oneShot
            if (!nextActive) {
                mainHandler.removeCallbacks(pollRunnable)
            }
            val updated = current.copy(
                active = nextActive,
                triggeredCount = current.triggeredCount + 1,
                lastTriggeredSummary = diffSummary
            )
            _watchdogFlow.value = updated
            onWatchdogStateChanged?.invoke(updated)
            onWatchdogTriggered?.invoke(updated, diffSummary)
            JSONObject().apply {
                put("success", true)
                put("status", "triggered")
                put("triggered", true)
                put("diffSummary", diffSummary)
                put("watchdog", updated.toJson())
            }
        } else {
            JSONObject().apply {
                put("success", true)
                put("status", if (current.active) "watching" else "disarmed")
                put("triggered", false)
                put("nodeCount", nodes.size)
                put("watchdog", current.toJson())
            }
        }
    }

    fun applyFromJson(
        json: JSONObject,
        fallbackRegion: AgyHudDynamicModels.SnippedRegionContext? = null
    ): JSONObject {
        val action = json.optString("action", json.optString("op", "arm")).trim().lowercase(Locale.US)
        if (json.optBoolean("clear", false) || action in setOf("clear", "remove")) {
            val cleared = clearWatchdog()
            return JSONObject().apply {
                put("success", true)
                put("status", "cleared")
                put("active", false)
                put("watchdog", cleared.toJson())
            }
        }
        return when (action) {
            "disarm", "pause", "stop" -> {
                val disarmed = disarmWatchdog()
                JSONObject().apply {
                    put("success", true)
                    put("status", "disarmed")
                    put("active", false)
                    put("watchdog", disarmed.toJson())
                }
            }
            "check", "evaluate", "test" -> {
                evaluateNow()
            }
            else -> {
                val configJson = json.optJSONObject("watchdog") ?: json
                val parsed = AgyHudDynamicModels.ScreenWatchdogConfig.fromJson(configJson, fallbackRegion)
                if (!parsed.active) {
                    val disarmed = disarmWatchdog()
                    JSONObject().apply {
                        put("success", true)
                        put("status", "disarmed")
                        put("active", false)
                        put("watchdog", disarmed.toJson())
                    }
                } else {
                    val armed = armWatchdog(parsed)
                    JSONObject().apply {
                        put("success", true)
                        put("status", "armed")
                        put("active", armed.active)
                        put("watchdog", armed.toJson())
                    }
                }
            }
        }
    }

    fun toJson(): JSONObject {
        val current = _watchdogFlow.value
        return JSONObject().apply {
            put("success", true)
            put("active", current.active)
            put("watchdog", current.toJson())
        }
    }

    private fun collectFilteredNodes(region: AgyHudDynamicModels.SnippedRegionContext?): List<AccessibilityNodeModel> {
        val roots = nodeTreeProvider?.invoke().orEmpty()
        val regionRect = region?.let { Rect(it.x1, it.y1, it.x2, it.y2) }
        val collected = mutableListOf<AccessibilityNodeModel>()

        fun walk(node: AccessibilityNodeModel) {
            val desc = node.contentDescription.orEmpty()
            val id = node.viewId.orEmpty()
            val text = node.text.orEmpty()
            val prefix = AgyHudOverlayManager.HUD_NODE_TAG_PREFIX
            if (desc.contains(prefix, ignoreCase = true) ||
                id.contains(prefix, ignoreCase = true) ||
                text.contains(prefix, ignoreCase = true)
            ) {
                return
            }
            val matchesRegion = if (regionRect != null && !regionRect.isEmpty) {
                val nodeRect = AgyRegionSnipOverlayManager.parseBoundsRect(node.bounds)
                nodeRect != null && Rect.intersects(regionRect, nodeRect)
            } else {
                true
            }
            if (matchesRegion) {
                collected.add(node)
            }
            node.children.forEach { walk(it) }
        }

        roots.forEach { walk(it) }
        return collected
    }

    private fun computeTreeSignature(nodes: List<AccessibilityNodeModel>): String {
        if (nodes.isEmpty()) return "empty"
        return nodes.joinToString("|") { node ->
            "${node.viewId.orEmpty()}:${node.text.orEmpty()}:${node.contentDescription.orEmpty()}:${node.isClickable}"
        }
    }

    private fun collectNodeLabels(nodes: List<AccessibilityNodeModel>): Set<String> {
        val labels = LinkedHashSet<String>()
        for (node in nodes) {
            val label = node.text?.takeIf { it.isNotBlank() }
                ?: node.contentDescription?.takeIf { it.isNotBlank() }
                ?: node.viewId?.substringAfterLast('/')?.takeIf { it.isNotBlank() }
            if (label != null) {
                labels.add(label.trim().take(36))
            }
        }
        return labels
    }
}
