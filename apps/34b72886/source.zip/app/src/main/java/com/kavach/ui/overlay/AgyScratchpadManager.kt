package com.kavach.ui.overlay

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject

/**
 * Feature 2: Smart Clipboard & Cross-App Scratchpad Dropzone Manager.
 *
 * Maintains a multi-slot floating scratchpad of text snippets, URLs, code blocks, and JSON payloads
 * captured from the system clipboard or pushed by Agy via `/api/hud/scratchpad`.
 */
class AgyScratchpadManager(
    private val context: Context,
    var foregroundPackageProvider: (() -> String?)? = null
) {
    companion object {
        const val MAX_SCRATCHPAD_ITEMS = 20
    }

    private val clipboardManager: ClipboardManager? by lazy {
        context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
    }

    private val _itemsFlow = MutableStateFlow<List<AgyHudDynamicModels.ScratchpadItem>>(emptyList())
    val itemsFlow: StateFlow<List<AgyHudDynamicModels.ScratchpadItem>> = _itemsFlow.asStateFlow()

    private var autoCaptureClipboard: Boolean = true
    private var lastInternalCopyContent: String = ""
    private var clipListenerRegistered: Boolean = false

    var onItemsChanged: ((List<AgyHudDynamicModels.ScratchpadItem>) -> Unit)? = null

    private val clipChangedListener = ClipboardManager.OnPrimaryClipChangedListener {
        if (!autoCaptureClipboard) return@OnPrimaryClipChangedListener
        try {
            val clip = clipboardManager?.primaryClip ?: return@OnPrimaryClipChangedListener
            val label = clip.description?.label?.toString().orEmpty()
            if (label == "Agy Output" || label == "Agy Scratchpad") return@OnPrimaryClipChangedListener
            if (clip.itemCount > 0) {
                val text = clip.getItemAt(0)?.coerceToText(context)?.toString()?.trim().orEmpty()
                if (text.isNotEmpty() && text != lastInternalCopyContent) {
                    addOrUpdateItem(
                        content = text,
                        sourcePackage = foregroundPackageProvider?.invoke().orEmpty()
                    )
                }
            }
        } catch (_: Exception) {}
    }

    fun startClipboardMonitoring() {
        if (clipListenerRegistered) return
        try {
            clipboardManager?.addPrimaryClipChangedListener(clipChangedListener)
            clipListenerRegistered = true
        } catch (_: Exception) {}
    }

    fun stopClipboardMonitoring() {
        if (!clipListenerRegistered) return
        try {
            clipboardManager?.removePrimaryClipChangedListener(clipChangedListener)
        } catch (_: Exception) {}
        clipListenerRegistered = false
    }

    fun currentItems(): List<AgyHudDynamicModels.ScratchpadItem> = _itemsFlow.value

    fun addOrUpdateItem(
        content: String,
        label: String = "",
        kind: String = "",
        sourcePackage: String = "",
        pinned: Boolean = false,
        explicitId: String = ""
    ): AgyHudDynamicModels.ScratchpadItem? {
        val clean = content.trim()
        if (clean.isEmpty()) return null
        val cur = _itemsFlow.value.toMutableList()
        val existingIdx = cur.indexOfFirst {
            (explicitId.isNotBlank() && it.id == explicitId) || it.content == clean
        }
        val inferredKind = AgyHudDynamicModels.ScratchpadItem.inferKind(clean, kind)
        val item = if (existingIdx >= 0) {
            val prev = cur.removeAt(existingIdx)
            prev.copy(
                kind = if (kind.isNotBlank()) inferredKind else prev.kind,
                content = clean,
                label = label.trim().ifBlank { prev.label },
                sourcePackage = sourcePackage.trim().ifBlank { prev.sourcePackage },
                pinned = pinned || prev.pinned,
                timestampMs = System.currentTimeMillis()
            )
        } else {
            AgyHudDynamicModels.ScratchpadItem(
                id = explicitId.trim().ifBlank { "clip_${System.currentTimeMillis() % 100000}_${cur.size}" },
                kind = inferredKind,
                content = clean,
                label = label.trim(),
                sourcePackage = sourcePackage.trim().ifBlank { foregroundPackageProvider?.invoke().orEmpty() },
                pinned = pinned,
                timestampMs = System.currentTimeMillis()
            )
        }
        // Place newly added/updated items at top (keeping pinned items prioritized)
        cur.add(0, item)
        val pinnedItems = cur.filter { it.pinned }
        val unpinnedItems = cur.filterNot { it.pinned }
        val bounded = (pinnedItems + unpinnedItems).take(MAX_SCRATCHPAD_ITEMS)
        _itemsFlow.value = bounded
        onItemsChanged?.invoke(bounded)
        return item
    }

    fun captureSystemClipboard(sourcePackage: String = ""): AgyHudDynamicModels.ScratchpadItem? {
        return try {
            val clip = clipboardManager?.primaryClip ?: return null
            if (clip.itemCount <= 0) return null
            val text = clip.getItemAt(0)?.coerceToText(context)?.toString()?.trim().orEmpty()
            if (text.isEmpty()) return null
            addOrUpdateItem(
                content = text,
                sourcePackage = sourcePackage.ifBlank { foregroundPackageProvider?.invoke().orEmpty() }
            )
        } catch (_: Exception) {
            null
        }
    }

    fun copyItemToClipboard(id: String): Boolean {
        val item = _itemsFlow.value.firstOrNull { it.id == id } ?: return false
        return try {
            lastInternalCopyContent = item.content
            clipboardManager?.setPrimaryClip(ClipData.newPlainText("Agy Scratchpad", item.content))
            true
        } catch (_: Exception) {
            false
        }
    }

    fun togglePin(id: String): Boolean {
        val cur = _itemsFlow.value.toMutableList()
        val idx = cur.indexOfFirst { it.id == id }
        if (idx < 0) return false
        val toggled = cur[idx].copy(pinned = !cur[idx].pinned)
        cur[idx] = toggled
        val sorted = cur.filter { it.pinned } + cur.filterNot { it.pinned }
        _itemsFlow.value = sorted
        onItemsChanged?.invoke(sorted)
        return toggled.pinned
    }

    fun removeItem(id: String): Boolean {
        val before = _itemsFlow.value
        val next = before.filterNot { it.id == id }
        if (next.size == before.size) return false
        _itemsFlow.value = next
        onItemsChanged?.invoke(next)
        return true
    }

    fun clearAll(keepPinned: Boolean = false) {
        val next = if (keepPinned) _itemsFlow.value.filter { it.pinned } else emptyList()
        _itemsFlow.value = next
        onItemsChanged?.invoke(next)
    }

    fun applyFromJson(json: JSONObject): JSONObject {
        val action = json.optString("action", json.optString("op", "")).lowercase().trim()
        if (json.optBoolean("clear", false) || action == "clear") {
            clearAll(keepPinned = json.optBoolean("keepPinned", false))
            return toJson()
        }
        when (action) {
            "remove", "delete" -> {
                removeItem(json.optString("id", "").trim())
            }
            "pin", "toggle_pin" -> {
                togglePin(json.optString("id", "").trim())
            }
            "copy" -> {
                copyItemToClipboard(json.optString("id", "").trim())
            }
            "capture_clipboard" -> {
                captureSystemClipboard()
            }
            else -> {
                val arr = json.optJSONArray("items")
                if (arr != null) {
                    if (json.optBoolean("replace", false)) {
                        _itemsFlow.value = emptyList()
                    }
                    for (i in 0 until arr.length()) {
                        AgyHudDynamicModels.ScratchpadItem.fromJson(arr.opt(i), i)?.let { item ->
                            addOrUpdateItem(
                                content = item.content,
                                label = item.label,
                                kind = item.kind,
                                sourcePackage = item.sourcePackage,
                                pinned = item.pinned,
                                explicitId = item.id
                            )
                        }
                    }
                } else {
                    val single = json.optJSONObject("item") ?: json
                    val content = single.optString("content", single.optString("text", single.optString("value", ""))).trim()
                    if (content.isNotEmpty()) {
                        addOrUpdateItem(
                            content = content,
                            label = single.optString("label", single.optString("title", "")),
                            kind = single.optString("kind", single.optString("type", "")),
                            sourcePackage = single.optString("sourcePackage", ""),
                            pinned = single.optBoolean("pinned", false),
                            explicitId = single.optString("id", "")
                        )
                    }
                }
            }
        }
        return toJson()
    }

    fun toJson(): JSONObject = JSONObject().apply {
        val list = _itemsFlow.value
        put("success", true)
        put("count", list.size)
        put("items", JSONArray().apply { list.forEach { put(it.toJson()) } })
    }
}
