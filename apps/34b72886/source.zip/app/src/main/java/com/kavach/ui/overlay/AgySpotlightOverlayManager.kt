package com.kavach.ui.overlay

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.util.Log
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.animation.LinearInterpolator
import android.widget.LinearLayout
import android.widget.TextView
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.math.sin

/**
 * Non-blocking Co-Pilot Spotlight overlay (`agy_hud_spotlight`) for step-by-step guided coaching.
 *
 * Architecture:
 * - Window 1 (`agy_hud_spotlight`): Full-screen `FLAG_NOT_TOUCHABLE or FLAG_NOT_FOCUSABLE` canvas
 *   so every tap passes directly through to the underlying app while Agy highlights target regions
 *   with dimmed scrim cutouts (`Path.FillType.EVEN_ODD`), pulsing accent rings, numbered step pins
 *   (`1`, `2`, `3`), directional arrows, and crisp callout tooltips.
 * - Window 2 (`agy_hud_spotlight_dismiss`): Compact touchable floating `✕ Clear Guide` pill at
 *   top-center (`≥48dp` height) so the user can dismiss the guide immediately at any moment.
 */
class AgySpotlightOverlayManager(
    private val context: Context
) {
    companion object {
        private const val TAG = "AgySpotlightOverlay"
        const val NODE_TAG = "${AgyHudOverlayManager.HUD_NODE_TAG_PREFIX}spotlight"
        const val DISMISS_NODE_TAG = "${AgyHudOverlayManager.HUD_NODE_TAG_PREFIX}spotlight_dismiss"
    }

    private val mainHandler = Handler(Looper.getMainLooper())
    private val windowManager: WindowManager? by lazy {
        context.getSystemService(Context.WINDOW_SERVICE) as? WindowManager
    }

    private val _spotlightFlow = MutableStateFlow(AgyHudDynamicModels.SpotlightConfig(active = false))
    val spotlightFlow: StateFlow<AgyHudDynamicModels.SpotlightConfig> = _spotlightFlow.asStateFlow()

    @Volatile
    var onDismissedByUser: (() -> Unit)? = null

    private var spotlightCanvasView: SpotlightCanvasView? = null
    private var dismissPillView: LinearLayout? = null
    private var dismissTitleView: TextView? = null
    private var autoHideRunnable: Runnable? = null

    private fun hasOverlayPermission(): Boolean {
        return Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(context)
    }

    private fun runOnMain(block: () -> Unit) {
        if (Looper.myLooper() == Looper.getMainLooper()) block() else mainHandler.post(block)
    }

    fun showSpotlight(config: AgyHudDynamicModels.SpotlightConfig): Boolean {
        cancelAutoHide()
        if (!config.active || config.targets.isEmpty()) {
            hideSpotlight()
            return true
        }
        _spotlightFlow.value = config

        if (config.autoHideSeconds > 0) {
            val r = Runnable { hideSpotlight() }
            autoHideRunnable = r
            mainHandler.postDelayed(r, config.autoHideSeconds * 1000L)
        }

        if (!hasOverlayPermission()) {
            return false
        }

        runOnMain {
            ensureCanvasAttached()
            ensureDismissPillAttached()
            spotlightCanvasView?.setSpotlightConfig(config)
            dismissTitleView?.text = config.title.ifBlank { "Co-Pilot Guide (${config.targets.size})" }
        }
        return true
    }

    fun hideSpotlight() {
        cancelAutoHide()
        _spotlightFlow.value = AgyHudDynamicModels.SpotlightConfig(active = false)
        runOnMain {
            spotlightCanvasView?.let { v ->
                v.stopPulse()
                try {
                    windowManager?.removeView(v)
                } catch (_: Exception) {}
            }
            spotlightCanvasView = null
            dismissPillView?.let { v ->
                try {
                    windowManager?.removeView(v)
                } catch (_: Exception) {}
            }
            dismissPillView = null
            dismissTitleView = null
        }
    }

    private fun cancelAutoHide() {
        autoHideRunnable?.let { mainHandler.removeCallbacks(it) }
        autoHideRunnable = null
    }

    private fun overlayWindowType(): Int {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }
    }

    private fun ensureCanvasAttached() {
        if (spotlightCanvasView != null) return
        val canvas = SpotlightCanvasView(context).apply {
            contentDescription = NODE_TAG
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            overlayWindowType(),
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            title = NODE_TAG
        }
        try {
            windowManager?.addView(canvas, lp)
            spotlightCanvasView = canvas
        } catch (e: Exception) {
            Log.w(TAG, "Failed adding spotlight canvas: ${e.message}")
        }
    }

    private fun ensureDismissPillAttached() {
        if (dismissPillView != null) return
        val d = context.resources.displayMetrics.density.coerceAtLeast(1f)
        val pill = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding((14 * d).toInt(), (6 * d).toInt(), (8 * d).toInt(), (6 * d).toInt())
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = 999f * d
                setColor(Color.parseColor("#EB0F172A"))
                setStroke((1.1f * d).toInt().coerceAtLeast(1), Color.parseColor("#8800D4FF"))
            }
            elevation = 12f * d
            contentDescription = DISMISS_NODE_TAG
        }

        val titleTv = TextView(context).apply {
            text = "Co-Pilot Guide"
            textSize = 12f
            setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
            setTextColor(Color.WHITE)
            setPadding(0, 0, (10 * d).toInt(), 0)
        }
        dismissTitleView = titleTv

        val clearBtn = TextView(context).apply {
            text = "✕ Clear Guide"
            textSize = 11.5f
            setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            minWidth = (48 * d).toInt()
            minHeight = (44 * d).toInt()
            setPadding((12 * d).toInt(), (6 * d).toInt(), (12 * d).toInt(), (6 * d).toInt())
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = 999f * d
                setColor(Color.parseColor("#0095F6"))
            }
            contentDescription = "${DISMISS_NODE_TAG}_btn"
            setOnClickListener {
                hideSpotlight()
                onDismissedByUser?.invoke()
            }
        }

        pill.addView(titleTv)
        pill.addView(clearBtn)

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayWindowType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = (42 * d).toInt()
            title = DISMISS_NODE_TAG
        }
        try {
            windowManager?.addView(pill, lp)
            dismissPillView = pill
        } catch (e: Exception) {
            Log.w(TAG, "Failed adding spotlight dismiss pill: ${e.message}")
        }
    }

    /**
     * Full-screen touch-pass-through canvas that draws dimmed scrim cutouts, pulsing target borders,
     * numbered step pins, directional arrows, and crisp floating tooltips.
     */
    internal class SpotlightCanvasView(context: Context) : View(context) {
        private val d = context.resources.displayMetrics.density.coerceAtLeast(1f)
        private var config = AgyHudDynamicModels.SpotlightConfig(active = false)
        private var pulsePhase = 0f
        private var pulseAnimator: ValueAnimator? = null

        private val scrimPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            color = Color.argb(140, 8, 13, 24)
        }
        private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
        }
        private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 2.4f * d
        }
        private val pinBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
        }
        private val pinRingPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            color = Color.WHITE
            strokeWidth = 2f * d
        }
        private val pinTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = 12f * d
            textAlign = Paint.Align.CENTER
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        }
        private val tooltipBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#F20F172A")
            style = Paint.Style.FILL
        }
        private val tooltipStrokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 1.2f * d
        }
        private val tooltipTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = 12f * d
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        }
        private val arrowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
        }
        private val scrimPath = Path()
        private val tempRect = RectF()
        private val arrowPath = Path()

        fun setSpotlightConfig(next: AgyHudDynamicModels.SpotlightConfig) {
            config = next
            val alphaInt = (next.dimAlpha.coerceIn(0.15f, 0.85f) * 255).toInt()
            scrimPaint.color = Color.argb(alphaInt, 8, 13, 24)
            if (next.active && next.targets.isNotEmpty()) {
                startPulse()
            } else {
                stopPulse()
            }
            invalidate()
        }

        private fun startPulse() {
            val animatorsEnabled = Build.VERSION.SDK_INT < Build.VERSION_CODES.O || ValueAnimator.areAnimatorsEnabled()
            if (!animatorsEnabled || pulseAnimator != null) return
            pulseAnimator = ValueAnimator.ofFloat(0f, (Math.PI * 2.0).toFloat()).apply {
                duration = 1700L
                repeatCount = ValueAnimator.INFINITE
                interpolator = LinearInterpolator()
                addUpdateListener { anim ->
                    pulsePhase = anim.animatedValue as Float
                    invalidate()
                }
                start()
            }
        }

        fun stopPulse() {
            pulseAnimator?.cancel()
            pulseAnimator = null
        }

        override fun onDetachedFromWindow() {
            stopPulse()
            super.onDetachedFromWindow()
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            if (!config.active || config.targets.isEmpty()) return

            val w = width.toFloat().coerceAtLeast(1f)
            val h = height.toFloat().coerceAtLeast(1f)
            val pad = 6f * d
            val corner = 16f * d

            // 1. Dimmed scrim with EVEN_ODD rounded cutouts around every spotlight target
            scrimPath.reset()
            scrimPath.fillType = Path.FillType.EVEN_ODD
            scrimPath.addRect(0f, 0f, w, h, Path.Direction.CW)
            for (t in config.targets) {
                tempRect.set(
                    (t.x1 - pad).coerceAtLeast(0f),
                    (t.y1 - pad).coerceAtLeast(0f),
                    (t.x2 + pad).coerceAtMost(w),
                    (t.y2 + pad).coerceAtMost(h)
                )
                scrimPath.addRoundRect(tempRect, corner, corner, Path.Direction.CW)
            }
            canvas.drawPath(scrimPath, scrimPaint)

            // 2. Pulsing highlight halos, numbered pins, directional arrows & tooltips
            val pulseWave = (sin(pulsePhase.toDouble()).toFloat() + 1f) * 0.5f // 0..1
            for (t in config.targets) {
                val accent = AgyHudDynamicModels.parseColorOrNull(t.accentColor) ?: Color.parseColor("#00D4FF")
                val box = RectF(
                    (t.x1 - pad).coerceAtLeast(0f),
                    (t.y1 - pad).coerceAtLeast(0f),
                    (t.x2 + pad).coerceAtMost(w),
                    (t.y2 + pad).coerceAtMost(h)
                )

                // Outer pulsing halo
                val expand = (3f + 5f * pulseWave) * d
                val haloRect = RectF(box.left - expand, box.top - expand, box.right + expand, box.bottom + expand)
                glowPaint.color = Color.argb((115 - (pulseWave * 55)).toInt().coerceIn(30, 140), Color.red(accent), Color.green(accent), Color.blue(accent))
                glowPaint.strokeWidth = (5f + 2f * pulseWave) * d
                canvas.drawRoundRect(haloRect, corner + expand * 0.5f, corner + expand * 0.5f, glowPaint)

                // Crisp solid inner ring
                borderPaint.color = accent
                canvas.drawRoundRect(box, corner, corner, borderPaint)

                // Numbered step pin badge at top-start corner of box
                val pinR = 13f * d
                val pinX = box.left.coerceIn(pinR + 6f * d, w - pinR - 6f * d)
                val pinY = box.top.coerceIn(pinR + 6f * d, h - pinR - 6f * d)
                pinBgPaint.color = accent
                canvas.drawCircle(pinX, pinY, pinR, pinBgPaint)
                canvas.drawCircle(pinX, pinY, pinR, pinRingPaint)
                val numText = t.stepNumber.toString()
                val textOffsetY = (pinTextPaint.descent() + pinTextPaint.ascent()) * 0.5f
                canvas.drawText(numText, pinX, pinY - textOffsetY, pinTextPaint)

                // Tooltip callout + directional triangle arrow
                if (t.label.isNotBlank()) {
                    drawTooltipCallout(canvas, box, t.label, t.calloutPosition, accent, w, h)
                }
            }
        }

        private fun drawTooltipCallout(
            canvas: Canvas,
            box: RectF,
            label: String,
            calloutPos: String,
            accent: Int,
            canvasW: Float,
            canvasH: Float
        ) {
            val clean = if (label.length > 52) label.take(51) + "…" else label
            val textW = tooltipTextPaint.measureText(clean)
            val padH = 12f * d
            val padV = 8f * d
            val maxTipW = (canvasW - 24f * d).coerceAtLeast(48f * d)
            val tipW = (textW + padH * 2f).coerceIn(48f * d, maxTipW)
            val tipH = tooltipTextPaint.textSize + padV * 2f
            val arrowSz = 7f * d
            val gap = 10f * d

            val placeAbove = when (calloutPos) {
                "top" -> true
                "bottom" -> false
                else -> box.bottom + gap + tipH > canvasH - 48f * d && box.top - gap - tipH > 96f * d
            }

            val cx = box.centerX()
            val tipLeft = (cx - tipW * 0.5f).coerceIn(12f * d, (canvasW - tipW - 12f * d).coerceAtLeast(12f * d))
            val tipTop = if (placeAbove) {
                (box.top - gap - tipH).coerceAtLeast(96f * d)
            } else {
                (box.bottom + gap).coerceAtMost((canvasH - tipH - 16f * d).coerceAtLeast(16f * d))
            }
            val tipRect = RectF(tipLeft, tipTop, tipLeft + tipW, tipTop + tipH)

            // Arrow connecting tooltip to target box
            val minArrowX = tipRect.left + 12f * d
            val maxArrowX = (tipRect.right - 12f * d).coerceAtLeast(minArrowX)
            val arrowX = cx.coerceIn(minArrowX, maxArrowX)
            arrowPath.reset()
            if (placeAbove) {
                arrowPath.moveTo(arrowX - arrowSz, tipRect.bottom)
                arrowPath.lineTo(arrowX + arrowSz, tipRect.bottom)
                arrowPath.lineTo(arrowX, tipRect.bottom + arrowSz)
            } else {
                arrowPath.moveTo(arrowX - arrowSz, tipRect.top)
                arrowPath.lineTo(arrowX + arrowSz, tipRect.top)
                arrowPath.lineTo(arrowX, tipRect.top - arrowSz)
            }
            arrowPath.close()
            arrowPaint.color = accent
            canvas.drawPath(arrowPath, arrowPaint)

            tooltipStrokePaint.color = accent
            canvas.drawRoundRect(tipRect, 12f * d, 12f * d, tooltipBgPaint)
            canvas.drawRoundRect(tipRect, 12f * d, 12f * d, tooltipStrokePaint)
            val baseline = tipRect.top + padV + tooltipTextPaint.textSize * 0.82f
            canvas.drawText(clean, tipRect.left + padH, baseline, tooltipTextPaint)
        }
    }
}
