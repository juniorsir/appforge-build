package com.kavach.ui.overlay

import android.graphics.Rect
import com.kavach.accessibility.models.AccessibilityNodeModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONObject

/**
 * Feature 1: Demonstration Recorder (Teach-by-Example) Manager.
 *
 * Records user-demonstrated steps (TAP, SWIPE, TYPE, LONG_PRESS) enriched with live
 * accessibility node metadata (`nodeLabel`, `viewId`, `packageName`, screen coordinates)
 * so the user can either send the demonstration to Agy (`DEMO_RECORDED`) or save it
 * directly as a reusable 1-tap HUD Macro.
 */
class AgyDemoRecorderManager(
    var nodeTreeProvider: (() -> List<AccessibilityNodeModel>)? = null,
    var foregroundPackageProvider: (() -> String?)? = null
) {
    private val _sessionFlow = MutableStateFlow(AgyHudDynamicModels.DemoRecordingSession())
    val sessionFlow: StateFlow<AgyHudDynamicModels.DemoRecordingSession> = _sessionFlow.asStateFlow()

    var onSessionChanged: ((AgyHudDynamicModels.DemoRecordingSession) -> Unit)? = null

    fun currentSession(): AgyHudDynamicModels.DemoRecordingSession = _sessionFlow.value

    fun isRecording(): Boolean = _sessionFlow.value.active

    fun startRecording(title: String = "Recorded Demonstration"): AgyHudDynamicModels.DemoRecordingSession {
        val next = AgyHudDynamicModels.DemoRecordingSession(
            id = "demo_${System.currentTimeMillis() % 100000}",
            title = title.trim().ifBlank { "Recorded Demonstration" },
            active = true,
            steps = emptyList()
        )
        _sessionFlow.value = next
        onSessionChanged?.invoke(next)
        return next
    }

    fun stopRecording(): AgyHudDynamicModels.DemoRecordingSession {
        val cur = _sessionFlow.value
        val next = cur.copy(active = false)
        _sessionFlow.value = next
        onSessionChanged?.invoke(next)
        return next
    }

    fun clearRecording(): AgyHudDynamicModels.DemoRecordingSession {
        val next = AgyHudDynamicModels.DemoRecordingSession(active = false, steps = emptyList())
        _sessionFlow.value = next
        onSessionChanged?.invoke(next)
        return next
    }

    fun recordStep(
        actionType: String = "TAP",
        x: Int = 0,
        y: Int = 0,
        endX: Int = x,
        endY: Int = y,
        text: String = "",
        explicitNodeLabel: String = "",
        explicitViewId: String = "",
        explicitPackage: String = ""
    ): AgyHudDynamicModels.DemoStepItem {
        val cur = _sessionFlow.value
        val normalizedAction = actionType.uppercase().trim().let {
            if (it in setOf("TAP", "SWIPE", "TYPE", "LONG_PRESS")) it else "TAP"
        }
        val matchedNode = if (x > 0 || y > 0) findBestNodeAt(x, y) else null
        val nodeLabel = explicitNodeLabel.trim().ifBlank {
            matchedNode?.let { n ->
                n.text?.trim().orEmpty().ifBlank { n.contentDescription?.trim().orEmpty() }
            }.orEmpty()
        }
        val viewId = explicitViewId.trim().ifBlank { matchedNode?.viewId?.trim().orEmpty() }
        val pkg = explicitPackage.trim()
            .ifBlank { foregroundPackageProvider?.invoke()?.trim().orEmpty() }

        val nextIndex = cur.steps.size + 1
        val step = AgyHudDynamicModels.DemoStepItem(
            index = nextIndex,
            actionType = normalizedAction,
            x = x,
            y = y,
            endX = if (normalizedAction == "SWIPE") endX else x,
            endY = if (normalizedAction == "SWIPE") endY else y,
            text = text.trim(),
            nodeLabel = nodeLabel,
            viewId = viewId,
            packageName = pkg
        )
        val updatedSteps = cur.steps + step
        val nextSession = cur.copy(steps = updatedSteps)
        _sessionFlow.value = nextSession
        onSessionChanged?.invoke(nextSession)
        return step
    }

    /**
     * Captures a step from the most prominent clickable/focused node currently visible on screen
     * when the user taps `[+ Step]` in the HUD Demo Recorder bar.
     */
    fun captureBestVisibleNodeStep(): AgyHudDynamicModels.DemoStepItem? {
        val nodes = nodeTreeProvider?.invoke().orEmpty()
        val candidate = findPrimaryInteractiveNode(nodes) ?: return null
        val rect = parseBounds(candidate.bounds)
        val cx = rect?.centerX() ?: 540
        val cy = rect?.centerY() ?: 1200
        val label = candidate.text?.trim().orEmpty().ifBlank {
            candidate.contentDescription?.trim().orEmpty()
        }
        return recordStep(
            actionType = "TAP",
            x = cx,
            y = cy,
            explicitNodeLabel = label,
            explicitViewId = candidate.viewId.orEmpty()
        )
    }

    fun removeStep(stepIndexOneBased: Int): AgyHudDynamicModels.DemoRecordingSession {
        val cur = _sessionFlow.value
        val filtered = cur.steps
            .filterNot { it.index == stepIndexOneBased }
            .mapIndexed { idx, item -> item.copy(index = idx + 1) }
        val next = cur.copy(steps = filtered)
        _sessionFlow.value = next
        onSessionChanged?.invoke(next)
        return next
    }

    fun applyFromJson(json: JSONObject): AgyHudDynamicModels.DemoRecordingSession {
        val action = json.optString("action", json.optString("op", "")).lowercase().trim()
        return when (action) {
            "start", "begin", "record" -> {
                val started = startRecording(json.optString("title", "Recorded Demonstration"))
                val stepArr = json.optJSONArray("steps")
                if (stepArr != null) {
                    for (i in 0 until stepArr.length()) {
                        val sObj = stepArr.optJSONObject(i) ?: continue
                        recordStepFromJson(sObj)
                    }
                }
                _sessionFlow.value
            }
            "add_step", "step", "record_step" -> {
                if (!_sessionFlow.value.active && _sessionFlow.value.steps.isEmpty()) {
                    startRecording(json.optString("title", "Recorded Demonstration"))
                }
                val stepObj = json.optJSONObject("step") ?: json
                recordStepFromJson(stepObj)
                _sessionFlow.value
            }
            "stop", "finish" -> stopRecording()
            "clear", "reset" -> clearRecording()
            else -> {
                if (json.has("steps")) {
                    val parsed = AgyHudDynamicModels.DemoRecordingSession.fromJson(json)
                    _sessionFlow.value = parsed
                    onSessionChanged?.invoke(parsed)
                    parsed
                } else if (json.has("actionType") || json.has("x") || json.has("nodeLabel")) {
                    recordStepFromJson(json)
                    _sessionFlow.value
                } else {
                    _sessionFlow.value
                }
            }
        }
    }

    private fun recordStepFromJson(obj: JSONObject): AgyHudDynamicModels.DemoStepItem {
        return recordStep(
            actionType = obj.optString("actionType", obj.optString("type", "TAP")),
            x = obj.optInt("x", obj.optInt("x1", 0)),
            y = obj.optInt("y", obj.optInt("y1", 0)),
            endX = obj.optInt("endX", obj.optInt("x2", obj.optInt("x", 0))),
            endY = obj.optInt("endY", obj.optInt("y2", obj.optInt("y", 0))),
            text = obj.optString("text", obj.optString("inputText", "")),
            explicitNodeLabel = obj.optString("nodeLabel", obj.optString("label", "")),
            explicitViewId = obj.optString("viewId", ""),
            explicitPackage = obj.optString("packageName", "")
        )
    }

    private fun findBestNodeAt(x: Int, y: Int): AccessibilityNodeModel? {
        val roots = nodeTreeProvider?.invoke().orEmpty()
        var best: AccessibilityNodeModel? = null
        var bestArea = Int.MAX_VALUE

        fun visit(node: AccessibilityNodeModel) {
            val tag = (node.text.orEmpty() + " " + node.contentDescription.orEmpty() + " " + node.viewId.orEmpty())
            if (tag.contains(AgyHudOverlayManager.HUD_NODE_TAG_PREFIX)) return
            val rect = parseBounds(node.bounds)
            if (rect != null && rect.contains(x, y)) {
                val area = (rect.width().coerceAtLeast(1)) * (rect.height().coerceAtLeast(1))
                val hasLabel = !node.text.isNullOrBlank() || !node.contentDescription.isNullOrBlank() || !node.viewId.isNullOrBlank()
                if (hasLabel && area <= bestArea) {
                    best = node
                    bestArea = area
                }
            }
            node.children.forEach { visit(it) }
        }

        roots.forEach { visit(it) }
        return best
    }

    private fun findPrimaryInteractiveNode(roots: List<AccessibilityNodeModel>): AccessibilityNodeModel? {
        var found: AccessibilityNodeModel? = null
        fun visit(node: AccessibilityNodeModel) {
            if (found != null) return
            val tag = (node.text.orEmpty() + " " + node.contentDescription.orEmpty() + " " + node.viewId.orEmpty())
            if (tag.contains(AgyHudOverlayManager.HUD_NODE_TAG_PREFIX)) return
            val hasLabel = !node.text.isNullOrBlank() || !node.contentDescription.isNullOrBlank()
            if (node.isClickable && hasLabel) {
                found = node
                return
            }
            node.children.forEach { visit(it) }
        }
        roots.forEach { visit(it) }
        return found
    }

    private fun parseBounds(raw: String): Rect? {
        val regex = Regex("""\[(\d+),(\d+)]\[(\d+),(\d+)]""")
        val m = regex.find(raw) ?: return null
        val x1 = m.groupValues[1].toIntOrNull() ?: return null
        val y1 = m.groupValues[2].toIntOrNull() ?: return null
        val x2 = m.groupValues[3].toIntOrNull() ?: return null
        val y2 = m.groupValues[4].toIntOrNull() ?: return null
        return if (x2 > x1 && y2 > y1) Rect(x1, y1, x2, y2) else null
    }
}
