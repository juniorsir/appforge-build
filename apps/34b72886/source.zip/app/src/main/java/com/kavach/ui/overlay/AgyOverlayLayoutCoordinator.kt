package com.kavach.ui.overlay

import android.content.Context
import android.graphics.Rect
import android.view.Gravity
import android.view.WindowManager
import java.util.concurrent.atomic.AtomicLong
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Shared Geometry & Anti-Overlap Coordinator for the dual floating overlays:
 * - Main Agy HUD (`agy_hud`, [ManagedWindowId.HUD])
 * - Left Task Map / Results Window (`agy_task_map`, [ManagedWindowId.TASK_MAP])
 *
 * Guarantees a minimum 12dp breathing gap inside screen safe bounds (respecting status bar,
 * navigation bar, and active IME keyboard height), performs live auto-dodge & push during
 * drag or keyboard focus, and automatically collapses the lower-priority window into a
 * compact edge pill when screen space cannot comfortably host both expanded cards.
 */
class AgyOverlayLayoutCoordinator(
    private val context: Context
) {
    companion object {
        const val MIN_SAFE_GAP_DP = 12f
        const val EDGE_MARGIN_DP = 8f
        const val RESTORE_HYSTERESIS_DP = 8f
        private const val POSITION_EPSILON_PX = 2

        /**
         * Returns true when [a] and [b] intersect or come closer than [gapPx].
         */
        fun rectsOverlapWithGap(a: Rect, b: Rect, gapPx: Int): Boolean {
            return a.left < b.right + gapPx &&
                a.right + gapPx > b.left &&
                a.top < b.bottom + gapPx &&
                a.bottom + gapPx > b.top
        }

        /**
         * Clamps a rectangle's top-left coordinate so a window of size [width] x [height]
         * remains fully inside [viewport] safe bounds.
         */
        fun clampTopLeftToSafeBounds(
            left: Int,
            top: Int,
            width: Int,
            height: Int,
            viewport: ViewportSafeBounds
        ): Pair<Int, Int> {
            val maxLeft = (viewport.safeRight - width).coerceAtLeast(viewport.safeLeft)
            val maxTop = (viewport.safeBottom - height).coerceAtLeast(viewport.safeTop)
            return left.coerceIn(viewport.safeLeft, maxLeft) to top.coerceIn(viewport.safeTop, maxTop)
        }

        /**
         * Converts a [WindowManager.LayoutParams] + window dimensions into absolute screen-space
         * [Rect] coordinates, correctly respecting Android Gravity bitmasks.
         */
        fun windowParamsToScreenRect(
            params: WindowManager.LayoutParams,
            width: Int,
            height: Int,
            screenWidth: Int,
            screenHeight: Int,
            measuredOnScreen: IntArray? = null
        ): Rect {
            val safeW = width.coerceAtLeast(1)
            val safeH = height.coerceAtLeast(1)
            if (measuredOnScreen != null && (measuredOnScreen[0] != 0 || measuredOnScreen[1] != 0)) {
                val l = measuredOnScreen[0]
                val t = measuredOnScreen[1]
                return Rect(l, t, l + safeW, t + safeH)
            }
            val hGrav = params.gravity and Gravity.HORIZONTAL_GRAVITY_MASK
            val vGrav = params.gravity and Gravity.VERTICAL_GRAVITY_MASK

            val left = when (hGrav) {
                Gravity.RIGHT -> screenWidth - params.x - safeW
                Gravity.CENTER_HORIZONTAL -> (screenWidth - safeW) / 2 + params.x
                else -> params.x
            }
            val top = when (vGrav) {
                Gravity.BOTTOM -> screenHeight - params.y - safeH
                Gravity.CENTER_VERTICAL -> (screenHeight - safeH) / 2 + params.y
                else -> params.y
            }
            return Rect(left, top, left + safeW, top + safeH)
        }

        /**
         * Converts absolute screen-space `(targetLeft, targetTop)` into `(params.x, params.y)`
         * for the given [gravity].
         */
        fun screenTopLeftToWindowOffset(
            gravity: Int,
            targetLeft: Int,
            targetTop: Int,
            width: Int,
            height: Int,
            screenWidth: Int,
            screenHeight: Int
        ): Pair<Int, Int> {
            val hGrav = gravity and Gravity.HORIZONTAL_GRAVITY_MASK
            val vGrav = gravity and Gravity.VERTICAL_GRAVITY_MASK

            val nextX = when (hGrav) {
                Gravity.RIGHT -> (screenWidth - targetLeft - width).coerceAtLeast(0)
                Gravity.CENTER_HORIZONTAL -> targetLeft - (screenWidth - width) / 2
                else -> targetLeft.coerceAtLeast(0)
            }
            val nextY = when (vGrav) {
                Gravity.BOTTOM -> (screenHeight - targetTop - height).coerceAtLeast(0)
                Gravity.CENTER_VERTICAL -> targetTop - (screenHeight - height) / 2
                else -> targetTop.coerceAtLeast(0)
            }
            return nextX to nextY
        }

        /**
         * Computes viewport safe bounds from display metrics and optional IME height.
         */
        fun buildViewportSafeBounds(
            screenWidth: Int,
            screenHeight: Int,
            density: Float,
            statusBarHeightPx: Int = 0,
            navBarHeightPx: Int = 0,
            imeVisible: Boolean = false,
            imeHeightPx: Int = 0
        ): ViewportSafeBounds {
            val d = density.coerceAtLeast(1f)
            val safeScreenW = screenWidth.coerceAtLeast((320 * d).toInt())
            val safeScreenH = screenHeight.coerceAtLeast((480 * d).toInt())
            val marginPx = (EDGE_MARGIN_DP * d).toInt()
            val gapPx = (MIN_SAFE_GAP_DP * d).toInt()
            val topInset = max(statusBarHeightPx, (26 * d).toInt()) + (6 * d).toInt()
            val defaultNav = max(navBarHeightPx, (18 * d).toInt())
            val effectiveBottomInset = if (imeVisible) {
                max(imeHeightPx, (safeScreenH * 0.38f).toInt()) + (8 * d).toInt()
            } else {
                defaultNav + (8 * d).toInt()
            }
            val safeLeft = marginPx
            val safeRight = (safeScreenW - marginPx).coerceAtLeast(safeLeft + (120 * d).toInt())
            val safeTop = topInset.coerceAtMost(safeScreenH / 4)
            val safeBottom = (safeScreenH - effectiveBottomInset)
                .coerceAtLeast(safeTop + (120 * d).toInt())
                .coerceAtMost(safeScreenH - marginPx)

            return ViewportSafeBounds(
                screenWidth = safeScreenW,
                screenHeight = safeScreenH,
                safeLeft = safeLeft,
                safeTop = safeTop,
                safeRight = safeRight,
                safeBottom = safeBottom,
                gapPx = gapPx,
                restoreHysteresisPx = (RESTORE_HYSTERESIS_DP * d).toInt(),
                imeVisible = imeVisible
            )
        }

        /**
         * Pure, deterministic geometry solver for the dual floating windows.
         *
         * Rules:
         * 1. Higher interaction priority (`IME_FOCUSED > DRAGGING > USER_INTERACTED > PASSIVE`)
         *    wins primary posture; ties break by latest interaction sequence, then HUD default.
         * 2. Primary stays in place (clamped to safe bounds unless IME-managed vertically).
         * 3. Secondary checks whether an auto-collapsed window can safely expand again
         *    (never overriding manual user collapse).
         * 4. If secondary overlaps primary (with [ViewportSafeBounds.gapPx] breathing margin),
         *    secondary dodges along the clearest valid escape vector inside safe bounds.
         * 5. If no non-overlapping placement fits for expanded secondary, secondary automatically
         *    collapses into its compact edge pill (`autoCollapsedByCoordinator = true`) and
         *    positions cleanly with ≥12dp clearance.
         */
        fun solve(
            hud: WindowBoxState?,
            taskMap: WindowBoxState?,
            viewport: ViewportSafeBounds,
            restoreHintForSecondary: Pair<Int, Int>? = null
        ): LayoutResolution {
            val hudVisible = hud != null && hud.visible
            val mapVisible = taskMap != null && taskMap.visible

            if (!hudVisible && !mapVisible) {
                return LayoutResolution(primaryId = null, secondaryId = null)
            }

            // Single visible window: clamp to safe bounds and restore if previously auto-collapsed
            if (hudVisible xor mapVisible) {
                val solo = if (hudVisible) hud!! else taskMap!!
                val shouldRestore = solo.isCollapsed &&
                    solo.autoCollapsedByCoordinator &&
                    !solo.userManuallyCollapsed
                val targetCollapsed = if (shouldRestore) false else solo.isCollapsed
                val targetW = if (targetCollapsed) solo.collapsedWidth else solo.expandedWidth
                val targetH = if (targetCollapsed) solo.collapsedHeight else solo.expandedHeight
                val anchorLeft = restoreHintForSecondary?.first ?: solo.rect.left
                val anchorTop = restoreHintForSecondary?.second ?: solo.rect.top
                val (clampedL, clampedT) = clampTopLeftToSafeBounds(anchorLeft, anchorTop, targetW, targetH, viewport)
                val posChanged = abs(clampedL - solo.rect.left) > POSITION_EPSILON_PX ||
                    abs(clampedT - solo.rect.top) > POSITION_EPSILON_PX
                val adj = if (posChanged || shouldRestore) {
                    WindowAdjustment(
                        targetLeft = clampedL,
                        targetTop = clampedT,
                        targetCollapsed = targetCollapsed,
                        autoCollapsedByCoordinator = false,
                        positionChanged = posChanged,
                        collapseChanged = targetCollapsed != solo.isCollapsed
                    )
                } else null
                return LayoutResolution(
                    primaryId = null,
                    secondaryId = solo.id,
                    secondaryAdjustment = adj,
                    hadCollision = false
                )
            }

            // Both windows visible
            val hudState = hud!!
            val mapState = taskMap!!
            val (primary, secondary) = selectPrimaryAndSecondary(hudState, mapState)

            // Clamp primary inside safe bounds (preserve vertical position when IME-managed)
            val primW = primary.currentWidth()
            val primH = primary.currentHeight()
            val (primClampedL, primClampedT) = if (primary.priority == InteractionPriority.IME_FOCUSED) {
                val maxL = (viewport.safeRight - primW).coerceAtLeast(viewport.safeLeft)
                val clampedL = primary.rect.left.coerceIn(viewport.safeLeft, maxL)
                // Keep IME-positioned top inside screen top
                val clampedT = primary.rect.top.coerceAtLeast(viewport.safeTop)
                clampedL to clampedT
            } else {
                clampTopLeftToSafeBounds(primary.rect.left, primary.rect.top, primW, primH, viewport)
            }
            val primaryNeedsClamp = primary.priority != InteractionPriority.DRAGGING &&
                primary.priority != InteractionPriority.IME_FOCUSED &&
                (abs(primClampedL - primary.rect.left) > POSITION_EPSILON_PX ||
                    abs(primClampedT - primary.rect.top) > POSITION_EPSILON_PX)

            val effectivePrimaryRect = Rect(
                primClampedL,
                primClampedT,
                primClampedL + primW,
                primClampedT + primH
            )

            // Step A: If secondary is TASK_MAP with autoFollowHud enabled, compute its docked position
            // directly to the left of primary HUD (`hud.left - gapPx - width`, `hud.top`) whenever fits!
            var workingCollapsed = secondary.isCollapsed
            var workingAutoCollapsed = secondary.autoCollapsedByCoordinator
            var desiredLeft = restoreHintForSecondary?.first ?: secondary.rect.left
            var desiredTop = restoreHintForSecondary?.second ?: secondary.rect.top

            if (secondary.id == ManagedWindowId.TASK_MAP &&
                primary.id == ManagedWindowId.HUD &&
                secondary.autoFollowHud &&
                restoreHintForSecondary == null
            ) {
                val followW = if (workingCollapsed) secondary.collapsedWidth else secondary.expandedWidth
                val followH = if (workingCollapsed) secondary.collapsedHeight else secondary.expandedHeight
                val dockedLeftOfHud = effectivePrimaryRect.left - viewport.gapPx - followW
                if (dockedLeftOfHud >= viewport.safeLeft) {
                    val maxTop = (viewport.safeBottom - followH).coerceAtLeast(viewport.safeTop)
                    desiredLeft = dockedLeftOfHud
                    desiredTop = effectivePrimaryRect.top.coerceIn(viewport.safeTop, maxTop)
                }
            }

            // Step A.2: If secondary was auto-collapsed earlier and NOT manually collapsed, check if it can safely expand
            if (secondary.isCollapsed && secondary.autoCollapsedByCoordinator && !secondary.userManuallyCollapsed) {
                val restoreGap = viewport.gapPx + viewport.restoreHysteresisPx
                val expW = secondary.expandedWidth
                val expH = secondary.expandedHeight
                val expPrefLeft = if (secondary.id == ManagedWindowId.TASK_MAP &&
                    primary.id == ManagedWindowId.HUD &&
                    secondary.autoFollowHud &&
                    (effectivePrimaryRect.left - viewport.gapPx - expW) >= viewport.safeLeft
                ) {
                    effectivePrimaryRect.left - viewport.gapPx - expW
                } else {
                    desiredLeft
                }
                val expPrefTop = if (secondary.id == ManagedWindowId.TASK_MAP &&
                    primary.id == ManagedWindowId.HUD &&
                    secondary.autoFollowHud &&
                    (effectivePrimaryRect.left - viewport.gapPx - expW) >= viewport.safeLeft
                ) {
                    effectivePrimaryRect.top
                } else {
                    desiredTop
                }
                val expandedPlacement = findBestNonOverlappingPlacement(
                    preferredLeft = expPrefLeft,
                    preferredTop = expPrefTop,
                    width = expW,
                    height = expH,
                    obstacle = effectivePrimaryRect,
                    viewport = viewport,
                    gapPx = restoreGap,
                    windowId = secondary.id,
                    dockedToObstacle = secondary.autoFollowHud
                )
                if (expandedPlacement != null) {
                    workingCollapsed = false
                    workingAutoCollapsed = false
                    desiredLeft = expandedPlacement.first
                    desiredTop = expandedPlacement.second
                }
            }

            // Step B: Evaluate collision at working size (expanded or collapsed)
            val workW = if (workingCollapsed) secondary.collapsedWidth else secondary.expandedWidth
            val workH = if (workingCollapsed) secondary.collapsedHeight else secondary.expandedHeight
            val (clampedSecL, clampedSecT) = clampTopLeftToSafeBounds(desiredLeft, desiredTop, workW, workH, viewport)
            val clampedSecRect = Rect(clampedSecL, clampedSecT, clampedSecL + workW, clampedSecT + workH)

            val initialCollision = rectsOverlapWithGap(clampedSecRect, effectivePrimaryRect, viewport.gapPx)

            var finalLeft = clampedSecL
            var finalTop = clampedSecT
            var finalCollapsed = workingCollapsed
            var finalAutoCollapsed = workingAutoCollapsed

            if (initialCollision) {
                // Step C: Attempt auto-dodge at current size
                val dodged = findBestNonOverlappingPlacement(
                    preferredLeft = clampedSecL,
                    preferredTop = clampedSecT,
                    width = workW,
                    height = workH,
                    obstacle = effectivePrimaryRect,
                    viewport = viewport,
                    gapPx = viewport.gapPx,
                    windowId = secondary.id,
                    dockedToObstacle = secondary.autoFollowHud
                )
                if (dodged != null) {
                    finalLeft = dodged.first
                    finalTop = dodged.second
                } else if (!workingCollapsed) {
                    // Step D: Tight space — auto-collapse secondary into compact edge pill and dodge cleanly!
                    finalCollapsed = true
                    finalAutoCollapsed = true
                    val pillW = secondary.collapsedWidth
                    val pillH = secondary.collapsedHeight
                    val dockedPillLeft = effectivePrimaryRect.left - viewport.gapPx - pillW
                    val pillPrefL = if (secondary.id == ManagedWindowId.TASK_MAP) {
                        if (secondary.autoFollowHud && dockedPillLeft >= viewport.safeLeft) {
                            dockedPillLeft
                        } else {
                            viewport.safeLeft
                        }
                    } else {
                        (viewport.safeRight - pillW).coerceAtLeast(viewport.safeLeft)
                    }
                    val pillPrefT = if (secondary.id == ManagedWindowId.TASK_MAP &&
                        secondary.autoFollowHud &&
                        dockedPillLeft >= viewport.safeLeft
                    ) {
                        effectivePrimaryRect.top.coerceIn(
                            viewport.safeTop,
                            (viewport.safeBottom - pillH).coerceAtLeast(viewport.safeTop)
                        )
                    } else {
                        clampedSecT
                    }
                    val pillPlacement = findBestNonOverlappingPlacement(
                        preferredLeft = pillPrefL,
                        preferredTop = pillPrefT,
                        width = pillW,
                        height = pillH,
                        obstacle = effectivePrimaryRect,
                        viewport = viewport,
                        gapPx = viewport.gapPx,
                        windowId = secondary.id,
                        dockedToObstacle = secondary.autoFollowHud
                    ) ?: findMaxSeparationCorner(
                        width = pillW,
                        height = pillH,
                        obstacle = effectivePrimaryRect,
                        viewport = viewport,
                        windowId = secondary.id
                    )
                    finalLeft = pillPlacement.first
                    finalTop = pillPlacement.second
                } else {
                    // Already collapsed pill still overlapped — push to clearest corner
                    val corner = findMaxSeparationCorner(
                        width = workW,
                        height = workH,
                        obstacle = effectivePrimaryRect,
                        viewport = viewport,
                        windowId = secondary.id
                    )
                    finalLeft = corner.first
                    finalTop = corner.second
                }
            }

            val posChanged = abs(finalLeft - secondary.rect.left) > POSITION_EPSILON_PX ||
                abs(finalTop - secondary.rect.top) > POSITION_EPSILON_PX
            val collapseChanged = finalCollapsed != secondary.isCollapsed ||
                finalAutoCollapsed != secondary.autoCollapsedByCoordinator

            val adjustment = if (posChanged || collapseChanged) {
                WindowAdjustment(
                    targetLeft = finalLeft,
                    targetTop = finalTop,
                    targetCollapsed = finalCollapsed,
                    autoCollapsedByCoordinator = finalAutoCollapsed,
                    positionChanged = posChanged,
                    collapseChanged = finalCollapsed != secondary.isCollapsed
                )
            } else {
                null
            }

            return LayoutResolution(
                primaryId = primary.id,
                secondaryId = secondary.id,
                secondaryAdjustment = adjustment,
                primaryClampedPosition = if (primaryNeedsClamp) (primClampedL to primClampedT) else null,
                hadCollision = initialCollision
            )
        }

        private fun selectPrimaryAndSecondary(
            hud: WindowBoxState,
            taskMap: WindowBoxState
        ): Pair<WindowBoxState, WindowBoxState> {
            return when {
                hud.priority.rank != taskMap.priority.rank ->
                    if (hud.priority.rank > taskMap.priority.rank) hud to taskMap else taskMap to hud
                hud.lastInteractionSeq != taskMap.lastInteractionSeq ->
                    if (hud.lastInteractionSeq > taskMap.lastInteractionSeq) hud to taskMap else taskMap to hud
                hud.isCollapsed != taskMap.isCollapsed ->
                    // Expanded window yields to nothing if the other is already collapsed passively
                    if (!hud.isCollapsed) hud to taskMap else taskMap to hud
                else -> hud to taskMap
            }
        }

        private fun findBestNonOverlappingPlacement(
            preferredLeft: Int,
            preferredTop: Int,
            width: Int,
            height: Int,
            obstacle: Rect,
            viewport: ViewportSafeBounds,
            gapPx: Int,
            windowId: ManagedWindowId,
            dockedToObstacle: Boolean = false
        ): Pair<Int, Int>? {
            val maxLeft = viewport.safeRight - width
            val maxTop = viewport.safeBottom - height
            if (maxLeft < viewport.safeLeft || maxTop < viewport.safeTop) return null

            val clampedPrefL = preferredLeft.coerceIn(viewport.safeLeft, maxLeft)
            val clampedPrefT = preferredTop.coerceIn(viewport.safeTop, maxTop)
            val dockedLeft = (obstacle.left - gapPx - width).coerceIn(viewport.safeLeft, maxLeft)
            val homeEdgeLeft = if (windowId == ManagedWindowId.TASK_MAP) {
                if (dockedToObstacle && (obstacle.left - gapPx - width) >= viewport.safeLeft) {
                    dockedLeft
                } else {
                    viewport.safeLeft
                }
            } else {
                maxLeft
            }

            val candidates = ArrayList<Pair<Int, Int>>(14)
            // 0. Preferred spot itself (fast path for auto-restore or docked position)
            candidates.add(clampedPrefL to clampedPrefT)
            // 0b. Directly docked to the left of obstacle aligned with obstacle.top
            if (windowId == ManagedWindowId.TASK_MAP) {
                candidates.add((obstacle.left - gapPx - width) to obstacle.top.coerceIn(viewport.safeTop, maxTop))
            }
            // 1. Push Above obstacle
            candidates.add(clampedPrefL to (obstacle.top - gapPx - height))
            candidates.add(homeEdgeLeft to (obstacle.top - gapPx - height))
            // 2. Push Below obstacle
            candidates.add(clampedPrefL to (obstacle.bottom + gapPx))
            candidates.add(homeEdgeLeft to (obstacle.bottom + gapPx))
            // 3. Push Left of obstacle
            candidates.add((obstacle.left - gapPx - width) to clampedPrefT)
            // 4. Push Right of obstacle
            candidates.add((obstacle.right + gapPx) to clampedPrefT)
            // 5. Four safe corners
            candidates.add(viewport.safeLeft to viewport.safeTop)
            candidates.add(maxLeft to viewport.safeTop)
            candidates.add(viewport.safeLeft to maxTop)
            candidates.add(maxLeft to maxTop)

            var best: Pair<Int, Int>? = null
            var bestScore = Double.POSITIVE_INFINITY

            for ((candL, candT) in candidates) {
                if (candL < viewport.safeLeft || candL > maxLeft) continue
                if (candT < viewport.safeTop || candT > maxTop) continue
                val candRect = Rect(candL, candT, candL + width, candT + height)
                if (rectsOverlapWithGap(candRect, obstacle, gapPx)) continue

                val moveDist = abs(candL - clampedPrefL) * 1.15 + abs(candT - clampedPrefT)
                // Gentle preference for keeping each window near its natural horizontal lane (or docked left of HUD)
                val homeBias = abs(candL - homeEdgeLeft) * 0.12
                // Slight preference for placing Task Map above HUD when vertically equidistant
                val laneBias = if (windowId == ManagedWindowId.TASK_MAP && candT < obstacle.top) -12.0 else 0.0
                val score = moveDist + homeBias + laneBias
                if (score < bestScore) {
                    bestScore = score
                    best = candL to candT
                }
            }
            return best
        }

        private fun findMaxSeparationCorner(
            width: Int,
            height: Int,
            obstacle: Rect,
            viewport: ViewportSafeBounds,
            windowId: ManagedWindowId
        ): Pair<Int, Int> {
            val maxLeft = (viewport.safeRight - width).coerceAtLeast(viewport.safeLeft)
            val maxTop = (viewport.safeBottom - height).coerceAtLeast(viewport.safeTop)
            val corners = listOf(
                viewport.safeLeft to viewport.safeTop,
                maxLeft to viewport.safeTop,
                viewport.safeLeft to maxTop,
                maxLeft to maxTop
            )
            val obsCx = (obstacle.left + obstacle.right) / 2.0
            val obsCy = (obstacle.top + obstacle.bottom) / 2.0
            val homeEdgeLeft = if (windowId == ManagedWindowId.TASK_MAP) viewport.safeLeft else maxLeft

            return corners.maxByOrNull { (l, t) ->
                val cx = l + width / 2.0
                val cy = t + height / 2.0
                val overlapArea = computeOverlapArea(Rect(l, t, l + width, t + height), obstacle)
                val dist = abs(cx - obsCx) + abs(cy - obsCy)
                val homeBonus = if (l == homeEdgeLeft) 24.0 else 0.0
                -overlapArea * 100.0 + dist + homeBonus
            } ?: (viewport.safeLeft to viewport.safeTop)
        }

        private fun computeOverlapArea(a: Rect, b: Rect): Long {
            val ow = (min(a.right, b.right) - max(a.left, b.left)).coerceAtLeast(0)
            val oh = (min(a.bottom, b.bottom) - max(a.top, b.top)).coerceAtLeast(0)
            return ow.toLong() * oh.toLong()
        }
    }

    enum class ManagedWindowId {
        HUD,
        TASK_MAP
    }

    enum class InteractionPriority(val rank: Int) {
        PASSIVE(0),
        USER_INTERACTED(1),
        DRAGGING(2),
        IME_FOCUSED(3)
    }

    data class ViewportSafeBounds(
        val screenWidth: Int,
        val screenHeight: Int,
        val safeLeft: Int,
        val safeTop: Int,
        val safeRight: Int,
        val safeBottom: Int,
        val gapPx: Int,
        val restoreHysteresisPx: Int = 0,
        val imeVisible: Boolean = false
    ) {
        val safeWidth: Int get() = (safeRight - safeLeft).coerceAtLeast(1)
        val safeHeight: Int get() = (safeBottom - safeTop).coerceAtLeast(1)
    }

    data class WindowBoxState(
        val id: ManagedWindowId,
        val visible: Boolean,
        val rect: Rect,
        val expandedWidth: Int,
        val expandedHeight: Int,
        val collapsedWidth: Int,
        val collapsedHeight: Int,
        val isCollapsed: Boolean,
        val autoCollapsedByCoordinator: Boolean,
        val userManuallyCollapsed: Boolean,
        val priority: InteractionPriority = InteractionPriority.PASSIVE,
        val lastInteractionSeq: Long = 0L,
        val autoFollowHud: Boolean = false
    ) {
        fun currentWidth(): Int = if (isCollapsed) collapsedWidth else expandedWidth
        fun currentHeight(): Int = if (isCollapsed) collapsedHeight else expandedHeight
    }

    data class WindowAdjustment(
        val targetLeft: Int,
        val targetTop: Int,
        val targetCollapsed: Boolean,
        val autoCollapsedByCoordinator: Boolean,
        val positionChanged: Boolean,
        val collapseChanged: Boolean
    )

    data class LayoutResolution(
        val primaryId: ManagedWindowId?,
        val secondaryId: ManagedWindowId?,
        val secondaryAdjustment: WindowAdjustment? = null,
        val primaryClampedPosition: Pair<Int, Int>? = null,
        val hadCollision: Boolean = false
    )

    interface ManagedOverlayEndpoint {
        val windowId: ManagedWindowId
        fun captureBoxState(viewport: ViewportSafeBounds): WindowBoxState
        fun applyAdjustment(adjustment: WindowAdjustment, viewport: ViewportSafeBounds, animate: Boolean)
        fun clampPosition(targetLeft: Int, targetTop: Int, viewport: ViewportSafeBounds, animate: Boolean)
    }

    private data class SavedPreImeSnapshot(
        val left: Int,
        val top: Int
    )

    private val endpoints = HashMap<ManagedWindowId, ManagedOverlayEndpoint>(2)
    private val priorities = HashMap<ManagedWindowId, InteractionPriority>(2)
    private val interactionSeqMap = HashMap<ManagedWindowId, Long>(2)
    private val seqCounter = AtomicLong(1L)

    @Volatile
    private var imeVisible: Boolean = false

    @Volatile
    private var measuredImeHeightPx: Int = 0

    private var savedTaskMapBeforeIme: SavedPreImeSnapshot? = null
    private var isReconciling: Boolean = false

    fun registerEndpoint(endpoint: ManagedOverlayEndpoint) {
        endpoints[endpoint.windowId] = endpoint
        priorities.putIfAbsent(endpoint.windowId, InteractionPriority.PASSIVE)
        interactionSeqMap.putIfAbsent(endpoint.windowId, 0L)
    }

    fun getPriority(id: ManagedWindowId): InteractionPriority =
        priorities[id] ?: InteractionPriority.PASSIVE

    fun getInteractionSeq(id: ManagedWindowId): Long =
        interactionSeqMap[id] ?: 0L

    fun isImeVisible(): Boolean = imeVisible

    /**
     * Computes the preferred `(left, top)` screen position for the left window (`TASK_MAP`)
     * docked directly to the left of the main `HUD` window (`hud.left - gapPx - width`, `hud.top`)
     * when horizontal space permits, falling back to the upper-left safe zone if `HUD` is not visible
     * or if the screen is too narrow for side-by-side placement.
     */
    fun computeDockedLeftOfHudPosition(width: Int, height: Int): Pair<Int, Int> {
        val viewport = currentViewportSafeBounds()
        val hudEndpoint = endpoints[ManagedWindowId.HUD]
        val hudBox = hudEndpoint?.captureBoxState(viewport)
        if (hudBox != null && hudBox.visible) {
            val dockedLeft = hudBox.rect.left - viewport.gapPx - width
            if (dockedLeft >= viewport.safeLeft) {
                val maxTop = (viewport.safeBottom - height).coerceAtLeast(viewport.safeTop)
                return dockedLeft to hudBox.rect.top.coerceIn(viewport.safeTop, maxTop)
            }
        }
        val d = context.resources.displayMetrics.density.coerceAtLeast(1f)
        val fallbackTop = viewport.safeTop + ((viewport.safeHeight * 0.08f).toInt()).coerceAtMost((48 * d).toInt())
        return AgyOverlayLayoutCoordinator.clampTopLeftToSafeBounds(
            left = viewport.safeLeft,
            top = fallbackTop,
            width = width,
            height = height,
            viewport = viewport
        )
    }

    fun currentViewportSafeBounds(): ViewportSafeBounds {
        val dm = context.resources.displayMetrics
        val d = dm.density.coerceAtLeast(1f)
        val statusBarH = resolveSystemDimenPx("status_bar_height", (26 * d).toInt())
        val navBarH = resolveSystemDimenPx("navigation_bar_height", (20 * d).toInt())
        return buildViewportSafeBounds(
            screenWidth = dm.widthPixels,
            screenHeight = dm.heightPixels,
            density = d,
            statusBarHeightPx = statusBarH,
            navBarHeightPx = navBarH,
            imeVisible = imeVisible,
            imeHeightPx = measuredImeHeightPx
        )
    }

    fun notifyInteraction(
        id: ManagedWindowId,
        priority: InteractionPriority = InteractionPriority.USER_INTERACTED,
        animate: Boolean = true
    ) {
        priorities[id] = priority
        interactionSeqMap[id] = seqCounter.incrementAndGet()
        if (id == ManagedWindowId.TASK_MAP && imeVisible) {
            // User explicitly moved/tapped Task Map while IME open -> don't snap back over their manual choice
            savedTaskMapBeforeIme = null
        }
        reconcile(animate = animate)
    }

    fun notifyDragStart(id: ManagedWindowId) {
        priorities[id] = InteractionPriority.DRAGGING
        interactionSeqMap[id] = seqCounter.incrementAndGet()
        if (id == ManagedWindowId.TASK_MAP && imeVisible) {
            savedTaskMapBeforeIme = null
        }
    }

    fun notifyDragMove(id: ManagedWindowId) {
        priorities[id] = InteractionPriority.DRAGGING
        interactionSeqMap[id] = seqCounter.incrementAndGet()
        reconcile(animate = false)
    }

    fun notifyDragEnd(id: ManagedWindowId, animate: Boolean = true) {
        if (priorities[id] == InteractionPriority.DRAGGING) {
            priorities[id] = InteractionPriority.USER_INTERACTED
        }
        interactionSeqMap[id] = seqCounter.incrementAndGet()
        reconcile(animate = animate)
    }

    fun notifyImeFocusChanged(focused: Boolean, estimatedImeHeightPx: Int = 0) {
        val wasFocused = imeVisible
        imeVisible = focused
        if (estimatedImeHeightPx > 0) {
            measuredImeHeightPx = estimatedImeHeightPx
        }
        if (focused) {
            if (!wasFocused) {
                val mapEndpoint = endpoints[ManagedWindowId.TASK_MAP]
                if (mapEndpoint != null) {
                    val vp = currentViewportSafeBounds()
                    val mapBox = mapEndpoint.captureBoxState(vp)
                    if (mapBox.visible) {
                        savedTaskMapBeforeIme = SavedPreImeSnapshot(mapBox.rect.left, mapBox.rect.top)
                    }
                }
            }
            priorities[ManagedWindowId.HUD] = InteractionPriority.IME_FOCUSED
            interactionSeqMap[ManagedWindowId.HUD] = seqCounter.incrementAndGet()
            reconcile(animate = true)
        } else {
            if (priorities[ManagedWindowId.HUD] == InteractionPriority.IME_FOCUSED) {
                priorities[ManagedWindowId.HUD] = InteractionPriority.USER_INTERACTED
            }
            val restoreHint = savedTaskMapBeforeIme?.let { it.left to it.top }
            savedTaskMapBeforeIme = null
            reconcile(animate = true, secondaryRestoreHint = restoreHint)
        }
    }

    fun reconcile(
        animate: Boolean = true,
        secondaryRestoreHint: Pair<Int, Int>? = null
    ): LayoutResolution {
        if (isReconciling) {
            return LayoutResolution(primaryId = null, secondaryId = null)
        }
        isReconciling = true
        try {
            val viewport = currentViewportSafeBounds()
            val hudEndpoint = endpoints[ManagedWindowId.HUD]
            val mapEndpoint = endpoints[ManagedWindowId.TASK_MAP]

            val hudBox = hudEndpoint?.captureBoxState(viewport)?.copy(
                priority = getPriority(ManagedWindowId.HUD),
                lastInteractionSeq = getInteractionSeq(ManagedWindowId.HUD)
            )
            val mapBox = mapEndpoint?.captureBoxState(viewport)?.copy(
                priority = getPriority(ManagedWindowId.TASK_MAP),
                lastInteractionSeq = getInteractionSeq(ManagedWindowId.TASK_MAP)
            )

            val resolution = solve(
                hud = hudBox,
                taskMap = mapBox,
                viewport = viewport,
                restoreHintForSecondary = secondaryRestoreHint
            )

            resolution.primaryClampedPosition?.let { (clampedL, clampedT) ->
                val primId = resolution.primaryId
                if (primId != null) {
                    endpoints[primId]?.clampPosition(clampedL, clampedT, viewport, animate)
                }
            }

            resolution.secondaryAdjustment?.let { adj ->
                val secId = resolution.secondaryId
                if (secId != null) {
                    endpoints[secId]?.applyAdjustment(adj, viewport, animate)
                }
            }

            return resolution
        } finally {
            isReconciling = false
        }
    }

    private fun resolveSystemDimenPx(name: String, fallbackPx: Int): Int {
        return try {
            val resId = context.resources.getIdentifier(name, "dimen", "android")
            if (resId > 0) context.resources.getDimensionPixelSize(resId) else fallbackPx
        } catch (_: Exception) {
            fallbackPx
        }
    }
}
