package com.kavach.ui.overlay

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.text.TextPaint
import android.text.TextUtils
import android.util.AttributeSet
import android.view.View
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Domain-specific Canvas renderer for Window 3 (`agy_task_map`).
 * Supports 4 dedicated modes without duplicating Termux or raw full-phone bezels:
 * 1. `chess`: 8x8 checkerboard oriented by playerColor + eval bar + move arrow + crisp piece glyphs
 * 2. `media`: Now-playing card with app artwork badge, title/subtitle, scrub bar, and [⏮ ⏯ ⏭] strip
 * 3. `telemetry`: Circular progress gauge + compact key-value telemetry rows
 * 4. `app_pane`: Auto-cropped target app schematic with semantic UI primitives (`search_bar`,
 *    `toggle`, `input`, `list_row`, `cta_button`, `target`) respecting `paneBounds` & rotation
 */
class AgyTaskMapView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    private var config: AgyHudDynamicModels.TaskMapConfig = AgyHudDynamicModels.TaskMapConfig()
    private var resolvedTheme: AgyHudDynamicModels.ResolvedHudTheme =
        AgyHudDynamicModels.resolveTheme(AgyHudDynamicModels.HudThemeConfig(), Color.parseColor("#0095F6"))

    private var animPhase: Float = 0f
    private var isAnimating: Boolean = false
    private val density = context.resources.displayMetrics.density

    private val frameRect = RectF()
    private val tempRect = RectF()
    private val arrowPath = Path()

    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val textPaint = TextPaint(Paint.ANTI_ALIAS_FLAG)

    private val dashPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeWidth = 1.9f * density
        pathEffect = DashPathEffect(floatArrayOf(4.5f * density, 3f * density), 0f)
    }

    private val frameTickRunnable = object : Runnable {
        override fun run() {
            if (!isAnimating || visibility != VISIBLE || !isAttachedToWindow) {
                isAnimating = false
                return
            }
            animPhase = (animPhase + 0.045f) % 1f
            invalidate()
            postDelayed(this, 33L)
        }
    }

    init {
        tag = "${AgyHudOverlayManager.HUD_NODE_TAG_PREFIX}task_map_canvas"
        contentDescription = "${AgyHudOverlayManager.HUD_NODE_TAG_PREFIX}task_map_canvas"
    }

    fun updateTaskMap(
        nextConfig: AgyHudDynamicModels.TaskMapConfig,
        theme: AgyHudDynamicModels.ResolvedHudTheme
    ) {
        config = nextConfig
        resolvedTheme = theme
        requestLayout()
        invalidate()
        syncAnimationState()
    }

    private fun needsAnimation(): Boolean {
        if (visibility != VISIBLE || !isAttachedToWindow || !config.active) return false
        return when (config.mode) {
            "chess" -> config.chess?.bestMove != null || config.chess?.lastMove != null
            "media" -> config.media?.playing == true
            "telemetry" -> (config.telemetry?.percent ?: -1f) < 0f
            else -> config.appPane?.actionVector != null || config.appPane?.zones?.any {
                it.role.equals("input", ignoreCase = true) || it.role.equals("target", ignoreCase = true)
            } == true
        }
    }

    private fun syncAnimationState() {
        val want = needsAnimation()
        if (want && !isAnimating) {
            isAnimating = true
            removeCallbacks(frameTickRunnable)
            post(frameTickRunnable)
        } else if (!want && isAnimating) {
            isAnimating = false
            removeCallbacks(frameTickRunnable)
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        syncAnimationState()
    }

    override fun onDetachedFromWindow() {
        isAnimating = false
        removeCallbacks(frameTickRunnable)
        super.onDetachedFromWindow()
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val availW = MeasureSpec.getSize(widthMeasureSpec).takeIf { it > 0 }
            ?: (config.widthDp * density).toInt()

        val desiredH: Int = when (config.mode) {
            "chess" -> {
                val extraFooter = (20f * density).toInt()
                availW + extraFooter
            }
            "media" -> (108f * density).toInt()
            "telemetry" -> {
                val rows = (config.telemetry?.metrics?.size ?: 0).coerceAtMost(5)
                (92f * density + rows * 20f * density).toInt()
            }
            else -> {
                val pane = config.appPane
                val bounds = if (config.paneMode == "pane") config.paneBounds else null
                val rawW = (bounds?.width ?: pane?.screenWidth ?: 1080).coerceAtLeast(100).toFloat()
                val rawH = (bounds?.height ?: pane?.screenHeight ?: 2000).coerceAtLeast(100).toFloat()
                val aspect = (rawW / rawH).coerceIn(0.45f, 1.85f)
                (availW / aspect).toInt().coerceIn((96f * density).toInt(), (238f * density).toInt())
            }
        }
        setMeasuredDimension(
            resolveSize(availW, widthMeasureSpec),
            resolveSize(desiredH, heightMeasureSpec)
        )
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (width <= 8 || height <= 8) return
        when (config.mode) {
            "chess" -> drawChessBoard(canvas)
            "media" -> drawMediaCard(canvas)
            "telemetry" -> drawTelemetryCard(canvas)
            else -> drawAppPane(canvas)
        }
    }

    // =========================================================================
    // 1. CHESS MODE — Clean 8x8 board, Eval bar, piece glyphs & animated arrow
    // =========================================================================
    private fun drawChessBoard(canvas: Canvas) {
        val chess = config.chess ?: AgyHudDynamicModels.ChessTaskMapData()
        val isWhiteBottom = !chess.playerColor.equals("black", ignoreCase = true)
        val boardGrid = parseFenBoard(chess.fen)

        val pad = 2f * density
        val evalBarWidth = 11f * density
        val evalGap = 5f * density
        val footerH = 18f * density

        val availBoardW = (width - pad * 2f - evalBarWidth - evalGap).coerceAtLeast(48f)
        val availBoardH = (height - pad * 2f - footerH).coerceAtLeast(48f)
        val boardSize = min(availBoardW, availBoardH)
        val boardLeft = pad + evalBarWidth + evalGap + (availBoardW - boardSize) * 0.5f
        val boardTop = pad
        val sqSize = boardSize / 8f

        // Left-edge Evaluation Bar
        val evalLeft = pad
        val evalRect = RectF(evalLeft, boardTop, evalLeft + evalBarWidth, boardTop + boardSize)
        val whiteFrac = computeEvalWhiteFraction(chess.evalCp)
        val splitY = evalRect.top + evalRect.height() * (1f - whiteFrac)

        fillPaint.color = Color.parseColor("#1E293B")
        canvas.drawRoundRect(evalRect, 4f * density, 4f * density, fillPaint)
        canvas.save()
        val clipPath = Path().apply { addRoundRect(evalRect, 4f * density, 4f * density, Path.Direction.CW) }
        canvas.clipPath(clipPath)
        fillPaint.color = Color.parseColor("#F8FAFC")
        canvas.drawRect(evalRect.left, splitY, evalRect.right, evalRect.bottom, fillPaint)
        canvas.restore()

        strokePaint.color = Color.parseColor("#64748B")
        strokePaint.strokeWidth = 0.8f * density
        canvas.drawRoundRect(evalRect, 4f * density, 4f * density, strokePaint)

        // Highlight squares helper: (file 0..7, rank 0..7 where rank 0 = rank '8')
        fun squareToScreenCenter(algebraic: String): Pair<Float, Float>? {
            if (algebraic.length < 2) return null
            val fChar = algebraic[0].lowercaseChar()
            val rChar = algebraic[1]
            if (fChar !in 'a'..'h' || rChar !in '1'..'8') return null
            val fileIdx = fChar - 'a'
            val rankFromTop = '8' - rChar // 0 for '8', 7 for '1'
            val col = if (isWhiteBottom) fileIdx else (7 - fileIdx)
            val row = if (isWhiteBottom) rankFromTop else (7 - rankFromTop)
            return (boardLeft + (col + 0.5f) * sqSize) to (boardTop + (row + 0.5f) * sqSize)
        }

        fun squareToBoardIndices(algebraic: String): Pair<Int, Int>? {
            if (algebraic.length < 2) return null
            val fChar = algebraic[0].lowercaseChar()
            val rChar = algebraic[1]
            if (fChar !in 'a'..'h' || rChar !in '1'..'8') return null
            val fileIdx = fChar - 'a'
            val rankFromTop = '8' - rChar
            val col = if (isWhiteBottom) fileIdx else (7 - fileIdx)
            val row = if (isWhiteBottom) rankFromTop else (7 - rankFromTop)
            return row to col
        }

        val lastFromIdx = chess.lastMove?.from?.let { squareToBoardIndices(it) }
        val lastToIdx = chess.lastMove?.to?.let { squareToBoardIndices(it) }
        val bestFromIdx = chess.bestMove?.from?.let { squareToBoardIndices(it) }
        val bestToIdx = chess.bestMove?.to?.let { squareToBoardIndices(it) }

        val lightSq = Color.parseColor("#EEEED2")
        val darkSq = Color.parseColor("#769656")

        // Rounded board container clip
        val boardRect = RectF(boardLeft, boardTop, boardLeft + boardSize, boardTop + boardSize)
        canvas.save()
        val boardClip = Path().apply { addRoundRect(boardRect, 6f * density, 6f * density, Path.Direction.CW) }
        canvas.clipPath(boardClip)

        val coordPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = (sqSize * 0.24f).coerceAtLeast(6f * density)
            typeface = Typeface.MONOSPACE
            isFakeBoldText = true
        }
        val pieceFillPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = sqSize * 0.72f
            textAlign = Paint.Align.CENTER
            typeface = Typeface.DEFAULT_BOLD
        }
        val pieceStrokePaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = sqSize * 0.72f
            textAlign = Paint.Align.CENTER
            typeface = Typeface.DEFAULT_BOLD
            style = Paint.Style.STROKE
            strokeWidth = (sqSize * 0.06f).coerceAtLeast(1f)
        }

        for (row in 0 until 8) {
            for (col in 0 until 8) {
                val fenRow = if (isWhiteBottom) row else (7 - row)
                val fenCol = if (isWhiteBottom) col else (7 - col)
                val isLight = ((fenRow + fenCol) % 2 == 0)
                val left = boardLeft + col * sqSize
                val top = boardTop + row * sqSize
                tempRect.set(left, top, left + sqSize, top + sqSize)

                fillPaint.color = if (isLight) lightSq else darkSq
                canvas.drawRect(tempRect, fillPaint)

                // Highlights: from = cyan, to = amber pulse
                val rc = row to col
                if (rc == lastFromIdx || rc == bestFromIdx) {
                    fillPaint.color = Color.argb(95, 0, 229, 255)
                    canvas.drawRect(tempRect, fillPaint)
                }
                if (rc == lastToIdx || rc == bestToIdx) {
                    val pulseAlpha = (85 + 55 * sin(animPhase * Math.PI * 2.0)).toInt().coerceIn(60, 150)
                    fillPaint.color = Color.argb(pulseAlpha, 245, 158, 11)
                    canvas.drawRect(tempRect, fillPaint)
                }

                // Rank & file micro labels
                if (col == 0) {
                    coordPaint.color = if (isLight) darkSq else lightSq
                    val rankNum = if (isWhiteBottom) (8 - row) else (row + 1)
                    canvas.drawText(rankNum.toString(), left + 1.5f * density, top + coordPaint.textSize, coordPaint)
                }
                if (row == 7) {
                    coordPaint.color = if (isLight) darkSq else lightSq
                    val fileChar = if (isWhiteBottom) ('a' + col) else ('h' - col)
                    canvas.drawText(fileChar.toString(), left + sqSize - coordPaint.textSize * 0.75f, top + sqSize - 1.5f * density, coordPaint)
                }

                // Piece glyph
                val pieceChar = boardGrid[fenRow][fenCol]
                if (pieceChar != ' ') {
                    val glyph = chessPieceGlyph(pieceChar)
                    val isWhitePiece = pieceChar.isUpperCase()
                    val fm = pieceFillPaint.fontMetrics
                    val py = tempRect.centerY() - (fm.ascent + fm.descent) * 0.5f
                    pieceStrokePaint.color = if (isWhitePiece) Color.parseColor("#0F172A") else Color.parseColor("#F8FAFC")
                    pieceFillPaint.color = if (isWhitePiece) Color.WHITE else Color.parseColor("#0F172A")
                    canvas.drawText(glyph, tempRect.centerX(), py, pieceStrokePaint)
                    canvas.drawText(glyph, tempRect.centerX(), py, pieceFillPaint)
                }
            }
        }

        // Animated move arrow (prefer bestMove, else lastMove)
        val activeMove = chess.bestMove?.takeIf { it.isValid } ?: chess.lastMove?.takeIf { it.isValid }
        if (activeMove != null) {
            val fromPt = squareToScreenCenter(activeMove.from)
            val toPt = squareToScreenCenter(activeMove.to)
            if (fromPt != null && toPt != null) {
                val (sx, sy) = fromPt
                val (ex, ey) = toPt
                val isBest = chess.bestMove?.isValid == true
                val arrowCol = if (isBest) Color.parseColor("#0EA5E9") else Color.parseColor("#F59E0B")
                strokePaint.color = Color.argb(215, Color.red(arrowCol), Color.green(arrowCol), Color.blue(arrowCol))
                strokePaint.strokeWidth = 3.0f * density
                strokePaint.strokeCap = Paint.Cap.ROUND
                canvas.drawLine(sx, sy, ex, ey, strokePaint)

                val angle = atan2((ey - sy).toDouble(), (ex - sx).toDouble())
                val headLen = 6.5f * density
                arrowPath.reset()
                arrowPath.moveTo(ex, ey)
                arrowPath.lineTo((ex - headLen * cos(angle - 0.5)).toFloat(), (ey - headLen * sin(angle - 0.5)).toFloat())
                arrowPath.lineTo((ex - headLen * cos(angle + 0.5)).toFloat(), (ey - headLen * sin(angle + 0.5)).toFloat())
                arrowPath.close()
                fillPaint.color = arrowCol
                canvas.drawPath(arrowPath, fillPaint)

                // Traveling pulse bead
                val bx = sx + (ex - sx) * animPhase
                val by = sy + (ey - sy) * animPhase
                fillPaint.color = Color.WHITE
                canvas.drawCircle(bx, by, 2.2f * density, fillPaint)
            }
        }
        canvas.restore()

        strokePaint.color = resolvedTheme.border
        strokePaint.strokeWidth = 1f * density
        canvas.drawRoundRect(boardRect, 6f * density, 6f * density, strokePaint)

        // Footer bar: Eval score pill + Turn label
        val footerY = boardRect.bottom + 13f * density
        textPaint.textSize = 9.5f * density
        textPaint.typeface = Typeface.MONOSPACE
        textPaint.isFakeBoldText = true
        textPaint.textAlign = Paint.Align.LEFT
        textPaint.color = resolvedTheme.accent
        canvas.drawText(chess.evalCp.ifBlank { "0.0" }, pad, footerY, textPaint)

        val moveBadge = activeMove?.let { "${it.from}→${it.to}" }.orEmpty()
        val turnStr = listOf(chess.turnLabel, moveBadge).filter { it.isNotBlank() }.joinToString(" · ")
        if (turnStr.isNotBlank()) {
            textPaint.textAlign = Paint.Align.RIGHT
            textPaint.color = resolvedTheme.textSecondary
            val maxW = (width - pad * 2f - 40f * density).coerceAtLeast(30f)
            val ellipsized = TextUtils.ellipsize(turnStr, textPaint, maxW, TextUtils.TruncateAt.END).toString()
            canvas.drawText(ellipsized, width - pad, footerY, textPaint)
        }
    }

    private fun parseFenBoard(fen: String): Array<CharArray> {
        val grid = Array(8) { CharArray(8) { ' ' } }
        val placement = fen.substringBefore(' ').trim()
        val ranks = placement.split('/')
        for (r in 0 until min(8, ranks.size)) {
            var c = 0
            for (ch in ranks[r]) {
                if (c >= 8) break
                if (ch.isDigit()) {
                    c += (ch - '0')
                } else {
                    grid[r][c] = ch
                    c++
                }
            }
        }
        return grid
    }

    private fun chessPieceGlyph(piece: Char): String = when (piece) {
        'K' -> "♔"
        'Q' -> "♕"
        'R' -> "♖"
        'B' -> "♗"
        'N' -> "♘"
        'P' -> "♙"
        'k' -> "♚"
        'q' -> "♛"
        'r' -> "♜"
        'b' -> "♝"
        'n' -> "♞"
        'p' -> "♟"
        else -> ""
    }

    private fun computeEvalWhiteFraction(evalStr: String): Float {
        val clean = evalStr.trim().uppercase()
        if (clean.startsWith("M") || clean.startsWith("+M")) return 0.94f
        if (clean.startsWith("-M")) return 0.06f
        val num = clean.toFloatOrNull() ?: return 0.5f
        val pawns = if (kotlin.math.abs(num) >= 20f) num / 100f else num
        return (0.5f + (pawns / 12f)).coerceIn(0.08f, 0.92f)
    }

    // =========================================================================
    // 2. MEDIA MODE — Now-Playing card with artwork badge, scrub bar & controls
    // =========================================================================
    private fun drawMediaCard(canvas: Canvas) {
        val media = config.media ?: AgyHudDynamicModels.MediaTaskMapData()
        val pad = 4f * density
        val cardRect = RectF(pad, pad, width - pad, height - pad)
        val radius = 12f * density

        fillPaint.color = resolvedTheme.secondarySurface
        canvas.drawRoundRect(cardRect, radius, radius, fillPaint)
        strokePaint.color = resolvedTheme.border
        strokePaint.strokeWidth = 0.8f * density
        canvas.drawRoundRect(cardRect, radius, radius, strokePaint)

        // Artwork / App badge
        val iconSz = 34f * density
        val iconLeft = cardRect.left + 8f * density
        val iconTop = cardRect.top + 8f * density
        val resolvedIcon = AgyAppIconResolver.resolve(
            context = context,
            explicitIcon = media.provider,
            explicitPackage = media.appPackage,
            fallbackText = "${media.provider} ${media.title}"
        )
        canvas.save()
        canvas.translate(iconLeft, iconTop)
        AgyAppIconResolver.drawBadgeOnCanvas(canvas, iconSz, iconSz, resolvedIcon)
        canvas.restore()

        val textLeft = iconLeft + iconSz + 8f * density
        val textAvailW = (cardRect.right - 8f * density - textLeft).coerceAtLeast(36f)

        textPaint.textAlign = Paint.Align.LEFT
        textPaint.textSize = 11f * density
        textPaint.typeface = Typeface.SANS_SERIF
        textPaint.isFakeBoldText = true
        textPaint.color = resolvedTheme.textPrimary
        val titleClipped = TextUtils.ellipsize(media.title, textPaint, textAvailW, TextUtils.TruncateAt.END).toString()
        canvas.drawText(titleClipped, textLeft, iconTop + 13f * density, textPaint)

        if (media.subtitle.isNotBlank()) {
            textPaint.textSize = 9.2f * density
            textPaint.isFakeBoldText = false
            textPaint.color = resolvedTheme.textSecondary
            val subClipped = TextUtils.ellipsize(media.subtitle, textPaint, textAvailW - 18f * density, TextUtils.TruncateAt.END).toString()
            canvas.drawText(subClipped, textLeft, iconTop + 27f * density, textPaint)
        }

        // Animated equalizer bars at top-right if playing
        if (media.playing) {
            val eqBaseX = cardRect.right - 20f * density
            val eqBaseY = iconTop + 28f * density
            fillPaint.color = resolvedIcon.accentColor
            for (b in 0..2) {
                val h = (4f + 8f * kotlin.math.abs(sin((animPhase * 6.28f + b * 1.3f).toDouble())).toFloat()) * density
                val bx = eqBaseX + b * 4f * density
                canvas.drawRoundRect(RectF(bx, eqBaseY - h, bx + 2.5f * density, eqBaseY), 1.5f * density, 1.5f * density, fillPaint)
            }
        }

        // Scrub bar
        val barTop = iconTop + iconSz + 10f * density
        val barLeft = cardRect.left + 8f * density
        val barRight = cardRect.right - 8f * density
        val barRect = RectF(barLeft, barTop, barRight, barTop + 4f * density)
        fillPaint.color = resolvedTheme.border
        canvas.drawRoundRect(barRect, 2f * density, 2f * density, fillPaint)

        val frac = (media.progressPercent / 100f).coerceIn(0f, 1f)
        val fillW = barRect.width() * frac
        if (fillW > 1f) {
            fillPaint.color = resolvedIcon.accentColor
            canvas.drawRoundRect(RectF(barRect.left, barRect.top, barRect.left + fillW, barRect.bottom), 2f * density, 2f * density, fillPaint)
        }

        // Time labels + [⏮ ⏯ ⏭] indicator strip
        val timeStr = if (media.elapsedText.isNotBlank() || media.durationText.isNotBlank()) {
            "${media.elapsedText.ifBlank { "0:00" }} / ${media.durationText.ifBlank { "--:--" }}"
        } else {
            "${media.progressPercent.toInt()}%"
        }
        textPaint.textSize = 8.5f * density
        textPaint.typeface = Typeface.MONOSPACE
        textPaint.isFakeBoldText = false
        textPaint.color = resolvedTheme.textSecondary
        canvas.drawText(timeStr, barLeft, barTop + 16f * density, textPaint)

        val ctrlCenterY = cardRect.bottom - 14f * density
        val cx = cardRect.centerX()
        textPaint.textAlign = Paint.Align.CENTER
        textPaint.textSize = 11f * density
        textPaint.typeface = Typeface.SANS_SERIF
        textPaint.isFakeBoldText = true
        textPaint.color = resolvedTheme.textSecondary
        canvas.drawText("⏮", cx - 28f * density, ctrlCenterY + 4f * density, textPaint)
        canvas.drawText("⏭", cx + 28f * density, ctrlCenterY + 4f * density, textPaint)

        fillPaint.color = resolvedIcon.accentColor
        canvas.drawCircle(cx, ctrlCenterY, 10f * density, fillPaint)
        textPaint.color = Color.WHITE
        textPaint.textSize = 10f * density
        canvas.drawText(if (media.playing) "❚❚" else "▶", cx, ctrlCenterY + 3.5f * density, textPaint)
    }

    // =========================================================================
    // 3. TELEMETRY MODE — Progress gauge + Key-Value telemetry metrics
    // =========================================================================
    private fun drawTelemetryCard(canvas: Canvas) {
        val tel = config.telemetry ?: AgyHudDynamicModels.TelemetryTaskMapData()
        val accent = AgyHudDynamicModels.parseColorOrNull(tel.accentColor) ?: resolvedTheme.accent
        val pad = 4f * density
        val cardRect = RectF(pad, pad, width - pad, height - pad)
        fillPaint.color = resolvedTheme.secondarySurface
        canvas.drawRoundRect(cardRect, 12f * density, 12f * density, fillPaint)
        strokePaint.color = resolvedTheme.border
        strokePaint.strokeWidth = 0.8f * density
        canvas.drawRoundRect(cardRect, 12f * density, 12f * density, strokePaint)

        val gaugeR = 24f * density
        val cx = cardRect.left + 12f * density + gaugeR
        val cy = cardRect.top + 12f * density + gaugeR
        val arcRect = RectF(cx - gaugeR, cy - gaugeR, cx + gaugeR, cy + gaugeR)

        strokePaint.strokeWidth = 5f * density
        strokePaint.strokeCap = Paint.Cap.ROUND
        strokePaint.color = resolvedTheme.border
        canvas.drawArc(arcRect, 0f, 360f, false, strokePaint)

        strokePaint.color = accent
        if (tel.percent >= 0f) {
            canvas.drawArc(arcRect, -90f, 360f * (tel.percent / 100f).coerceIn(0f, 1f), false, strokePaint)
        } else {
            canvas.drawArc(arcRect, animPhase * 360f - 90f, 110f, false, strokePaint)
        }

        textPaint.textAlign = Paint.Align.CENTER
        textPaint.typeface = Typeface.MONOSPACE
        textPaint.isFakeBoldText = true
        textPaint.textSize = 11f * density
        textPaint.color = resolvedTheme.textPrimary
        val pctTxt = if (tel.percent >= 0f) "${tel.percent.toInt()}%" else "•••"
        canvas.drawText(pctTxt, cx, cy + 4f * density, textPaint)

        // Title next to gauge
        val titleLeft = cx + gaugeR + 10f * density
        val titleAvail = (cardRect.right - 8f * density - titleLeft).coerceAtLeast(30f)
        textPaint.textAlign = Paint.Align.LEFT
        textPaint.typeface = Typeface.SANS_SERIF
        textPaint.textSize = 11f * density
        val titleClip = TextUtils.ellipsize(tel.title, textPaint, titleAvail, TextUtils.TruncateAt.END).toString()
        canvas.drawText(titleClip, titleLeft, cy + 4f * density, textPaint)

        // Metrics rows
        var rowY = cy + gaugeR + 18f * density
        for ((k, v) in tel.metrics.take(5)) {
            if (rowY > cardRect.bottom - 6f * density) break
            textPaint.textAlign = Paint.Align.LEFT
            textPaint.textSize = 9.2f * density
            textPaint.isFakeBoldText = false
            textPaint.color = resolvedTheme.textSecondary
            canvas.drawText(k, cardRect.left + 10f * density, rowY, textPaint)

            textPaint.textAlign = Paint.Align.RIGHT
            textPaint.typeface = Typeface.MONOSPACE
            textPaint.isFakeBoldText = true
            textPaint.color = resolvedTheme.textPrimary
            canvas.drawText(v, cardRect.right - 10f * density, rowY, textPaint)
            rowY += 18f * density
        }
    }

    // =========================================================================
    // 4. APP PANE MODE — Auto-cropped target window with rich semantic primitives
    // =========================================================================
    private fun drawAppPane(canvas: Canvas) {
        val pane = config.appPane
        val pad = 2f * density
        frameRect.set(pad, pad, width - pad, height - pad)
        val radius = 12f * density

        fillPaint.color = resolvedTheme.secondarySurface
        canvas.drawRoundRect(frameRect, radius, radius, fillPaint)
        strokePaint.color = resolvedTheme.border
        strokePaint.strokeWidth = 1f * density
        canvas.drawRoundRect(frameRect, radius, radius, strokePaint)

        val innerLeft = frameRect.left + 4f * density
        val innerTop = frameRect.top + 4f * density
        val innerW = (frameRect.width() - 8f * density).coerceAtLeast(1f)
        val innerH = (frameRect.height() - 8f * density).coerceAtLeast(1f)

        // Subtle alignment guide crosshair
        strokePaint.color = Color.argb(45, Color.red(resolvedTheme.textSecondary), Color.green(resolvedTheme.textSecondary), Color.blue(resolvedTheme.textSecondary))
        strokePaint.strokeWidth = 0.6f * density
        for (i in 1..2) {
            val gx = innerLeft + innerW * (i / 3f)
            val gy = innerTop + innerH * (i / 3f)
            canvas.drawLine(gx, innerTop, gx, innerTop + innerH, strokePaint)
            canvas.drawLine(innerLeft, gy, innerLeft + innerW, gy, strokePaint)
        }

        val crop = if (config.paneMode == "pane") config.paneBounds else null
        val originX = (crop?.x1 ?: 0).toFloat()
        val originY = (crop?.y1 ?: 0).toFloat()
        val mapW = (crop?.width ?: pane?.screenWidth ?: 1080).coerceAtLeast(1).toFloat()
        val mapH = (crop?.height ?: pane?.screenHeight ?: 2400).coerceAtLeast(1).toFloat()

        fun mapX(px: Float): Float = innerLeft + ((px - originX) / mapW).coerceIn(0f, 1f) * innerW
        fun mapY(py: Float): Float = innerTop + ((py - originY) / mapH).coerceIn(0f, 1f) * innerH

        val zones = pane?.zones.orEmpty().take(10)
        for (zone in zones) {
            val left = mapX(min(zone.x1, zone.x2))
            val top = mapY(min(zone.y1, zone.y2))
            val right = max(left + 6f * density, mapX(max(zone.x1, zone.x2)))
            val bottom = max(top + 5f * density, mapY(max(zone.y1, zone.y2)))
            tempRect.set(left, top, right, bottom)
            drawSemanticZone(canvas, tempRect, zone)
        }

        // Animated tap / drag vector
        pane?.actionVector?.let { vec ->
            val sx = mapX(vec.x1)
            val sy = mapY(vec.y1)
            val typeUpper = vec.type.uppercase()
            if (typeUpper == "SWIPE" || typeUpper == "DRAG") {
                val ex = mapX(vec.x2)
                val ey = mapY(vec.y2)
                dashPaint.color = resolvedTheme.accent
                canvas.drawLine(sx, sy, ex, ey, dashPaint)

                val angle = atan2((ey - sy).toDouble(), (ex - sx).toDouble())
                val headLen = 6f * density
                arrowPath.reset()
                arrowPath.moveTo(ex, ey)
                arrowPath.lineTo((ex - headLen * cos(angle - 0.5)).toFloat(), (ey - headLen * sin(angle - 0.5)).toFloat())
                arrowPath.lineTo((ex - headLen * cos(angle + 0.5)).toFloat(), (ey - headLen * sin(angle + 0.5)).toFloat())
                arrowPath.close()
                fillPaint.color = Color.parseColor("#F59E0B")
                canvas.drawPath(arrowPath, fillPaint)

                val bx = sx + (ex - sx) * animPhase
                val by = sy + (ey - sy) * animPhase
                fillPaint.color = Color.parseColor("#38BDF8")
                canvas.drawCircle(bx, by, 3f * density, fillPaint)
            } else {
                val ringRadius = (3f + animPhase * 8f) * density
                strokePaint.color = Color.argb(((1f - animPhase) * 230f).toInt().coerceIn(20, 230), 56, 189, 248)
                strokePaint.strokeWidth = 1.6f * density
                canvas.drawCircle(sx, sy, ringRadius, strokePaint)
                fillPaint.color = Color.parseColor("#F59E0B")
                canvas.drawCircle(sx, sy, 2.8f * density, fillPaint)
            }
        }
    }

    private fun drawSemanticZone(
        canvas: Canvas,
        rect: RectF,
        zone: AgyHudDynamicModels.TaskMapZone
    ) {
        val role = zone.role.lowercase().trim()
        val tag = zone.tag.trim()
        when (role) {
            "search_bar" -> {
                val pillR = rect.height() * 0.5f
                fillPaint.color = resolvedTheme.surface
                canvas.drawRoundRect(rect, pillR, pillR, fillPaint)
                strokePaint.color = resolvedTheme.accent
                strokePaint.strokeWidth = 1.1f * density
                canvas.drawRoundRect(rect, pillR, pillR, strokePaint)
                // Magnifier glyph
                val r = min(rect.height() * 0.24f, 4f * density)
                val gx = rect.left + r + 5f * density
                val gy = rect.centerY()
                canvas.drawCircle(gx, gy, r, strokePaint)
                canvas.drawLine(gx + r * 0.7f, gy + r * 0.7f, gx + r * 1.4f, gy + r * 1.4f, strokePaint)
                drawZoneLabel(canvas, rect, tag, startOffset = r * 2f + 9f * density)
            }
            "toggle" -> {
                val isOn = zone.checked ?: tag.contains("on", ignoreCase = true)
                val pillH = min(rect.height(), 14f * density)
                val swW = (pillH * 1.85f).coerceAtMost(rect.width())
                val swRect = RectF(rect.right - swW, rect.centerY() - pillH * 0.5f, rect.right, rect.centerY() + pillH * 0.5f)
                fillPaint.color = if (isOn) Color.parseColor("#16A34A") else resolvedTheme.border
                canvas.drawRoundRect(swRect, pillH * 0.5f, pillH * 0.5f, fillPaint)
                fillPaint.color = Color.WHITE
                val thumbR = pillH * 0.36f
                val thumbX = if (isOn) swRect.right - pillH * 0.5f else swRect.left + pillH * 0.5f
                canvas.drawCircle(thumbX, swRect.centerY(), thumbR, fillPaint)
                if (rect.width() > swW + 16f * density) {
                    drawZoneLabel(canvas, RectF(rect.left, rect.top, swRect.left - 3f * density, rect.bottom), tag, 2f * density)
                }
            }
            "input" -> {
                fillPaint.color = Color.argb(30, Color.red(resolvedTheme.accent), Color.green(resolvedTheme.accent), Color.blue(resolvedTheme.accent))
                canvas.drawRoundRect(rect, 5f * density, 5f * density, fillPaint)
                strokePaint.color = resolvedTheme.accent
                strokePaint.strokeWidth = 1.2f * density
                canvas.drawRoundRect(rect, 5f * density, 5f * density, strokePaint)
                // Blinking caret
                if (animPhase < 0.55f) {
                    val caretX = (rect.left + 6f * density).coerceAtMost(rect.right - 3f * density)
                    canvas.drawLine(caretX, rect.top + 3f * density, caretX, rect.bottom - 3f * density, strokePaint)
                }
                drawZoneLabel(canvas, rect, tag, startOffset = 9f * density)
            }
            "list_row" -> {
                fillPaint.color = Color.argb(18, Color.red(resolvedTheme.textSecondary), Color.green(resolvedTheme.textSecondary), Color.blue(resolvedTheme.textSecondary))
                canvas.drawRoundRect(rect, 3f * density, 3f * density, fillPaint)
                fillPaint.color = resolvedTheme.textSecondary
                canvas.drawCircle(rect.left + 5f * density, rect.centerY(), 1.8f * density, fillPaint)
                canvas.drawLine(rect.left + 3f * density, rect.bottom, rect.right - 3f * density, rect.bottom, strokePaint.apply {
                    color = resolvedTheme.border
                    strokeWidth = 0.6f * density
                })
                drawZoneLabel(canvas, rect, tag, startOffset = 10f * density)
            }
            "cta_button", "target" -> {
                val amber = Color.parseColor("#F59E0B")
                fillPaint.color = Color.argb(52, Color.red(amber), Color.green(amber), Color.blue(amber))
                canvas.drawRoundRect(rect, 6f * density, 6f * density, fillPaint)
                strokePaint.color = amber
                strokePaint.strokeWidth = 1.6f * density
                canvas.drawRoundRect(rect, 6f * density, 6f * density, strokePaint)
                drawZoneLabel(canvas, rect, tag, startOffset = 4f * density, textColor = resolvedTheme.textPrimary)
            }
            "button" -> {
                fillPaint.color = Color.argb(36, Color.red(resolvedTheme.accent), Color.green(resolvedTheme.accent), Color.blue(resolvedTheme.accent))
                canvas.drawRoundRect(rect, 6f * density, 6f * density, fillPaint)
                strokePaint.color = resolvedTheme.accent
                strokePaint.strokeWidth = 1.1f * density
                canvas.drawRoundRect(rect, 6f * density, 6f * density, strokePaint)
                drawZoneLabel(canvas, rect, tag, startOffset = 4f * density)
            }
            else -> {
                fillPaint.color = Color.argb(24, 100, 116, 139)
                canvas.drawRoundRect(rect, 4f * density, 4f * density, fillPaint)
                strokePaint.color = resolvedTheme.border
                strokePaint.strokeWidth = 0.8f * density
                canvas.drawRoundRect(rect, 4f * density, 4f * density, strokePaint)
                drawZoneLabel(canvas, rect, tag, startOffset = 4f * density)
            }
        }
    }

    private fun drawZoneLabel(
        canvas: Canvas,
        rect: RectF,
        tag: String,
        startOffset: Float,
        textColor: Int = resolvedTheme.textPrimary
    ) {
        if (tag.isBlank() || rect.height() < 10f * density || rect.width() < startOffset + 16f * density) return
        textPaint.textAlign = Paint.Align.LEFT
        textPaint.typeface = Typeface.SANS_SERIF
        textPaint.isFakeBoldText = true
        textPaint.textSize = 7.8f * density
        textPaint.color = textColor
        val avail = (rect.width() - startOffset - 3f * density).coerceAtLeast(8f)
        val clipped = TextUtils.ellipsize(tag, textPaint, avail, TextUtils.TruncateAt.END).toString()
        val fm = textPaint.fontMetrics
        val y = rect.centerY() - (fm.ascent + fm.descent) * 0.5f
        canvas.drawText(clipped, rect.left + startOffset, y, textPaint)
    }
}
