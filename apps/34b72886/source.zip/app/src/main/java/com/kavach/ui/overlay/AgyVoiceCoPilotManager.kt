package com.kavach.ui.overlay

import android.content.Context
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONObject
import java.util.Locale

/**
 * Feature 4: Voice Co-Pilot (Spoken TTS & Continuous Hands-Free Reply) Manager.
 *
 * - Spoken TTS readout of agent completion summaries, explicit `speakText`, and `NEEDS_INPUT` questions.
 * - Automatic hands-free microphone activation (`onRequestAutoListen`) right after speaking a question.
 */
class AgyVoiceCoPilotManager(
    private val context: Context,
    var onRequestAutoListen: (() -> Unit)? = null
) {
    private val mainHandler = Handler(Looper.getMainLooper())
    private val _configFlow = MutableStateFlow(AgyHudDynamicModels.VoiceCoPilotConfig())
    val configFlow: StateFlow<AgyHudDynamicModels.VoiceCoPilotConfig> = _configFlow.asStateFlow()

    private val _isSpeakingFlow = MutableStateFlow(false)
    val isSpeakingFlow: StateFlow<Boolean> = _isSpeakingFlow.asStateFlow()

    private val _lastSpokenTextFlow = MutableStateFlow("")
    val lastSpokenTextFlow: StateFlow<String> = _lastSpokenTextFlow.asStateFlow()

    var onConfigChanged: ((AgyHudDynamicModels.VoiceCoPilotConfig) -> Unit)? = null

    private var tts: TextToSpeech? = null
    private var ttsReady: Boolean = false
    private var lastAutoSpokenQuestionSignature: String = ""
    private var lastAutoSpokenDoneSignature: String = ""

    fun currentConfig(): AgyHudDynamicModels.VoiceCoPilotConfig = _configFlow.value

    fun configure(config: AgyHudDynamicModels.VoiceCoPilotConfig): AgyHudDynamicModels.VoiceCoPilotConfig {
        _configFlow.value = config
        onConfigChanged?.invoke(config)
        if (config.enabled) {
            ensureTtsInitialized()
            if (config.speakText.isNotBlank()) {
                speak(config.speakText, isQuestion = false)
            }
        } else {
            stopSpeaking()
        }
        return config
    }

    fun toggleEnabled(): AgyHudDynamicModels.VoiceCoPilotConfig {
        val current = _configFlow.value
        val next = current.copy(enabled = !current.enabled, speakText = "")
        return configure(next)
    }

    fun speak(
        text: String,
        isQuestion: Boolean = false,
        autoListenAfter: Boolean = isQuestion && _configFlow.value.autoListenOnQuestion
    ): Boolean {
        val clean = text.trim()
        if (clean.isEmpty()) return false

        val cfg = _configFlow.value
        _lastSpokenTextFlow.value = clean
        _isSpeakingFlow.value = true

        val utteranceId = if (autoListenAfter) {
            "agy_tts_q_${System.currentTimeMillis()}"
        } else {
            "agy_tts_msg_${System.currentTimeMillis()}"
        }

        ensureTtsInitialized()
        val engine = tts
        var queuedToEngine = false
        if (engine != null && ttsReady) {
            try {
                engine.setSpeechRate(cfg.speechRate)
                val result = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    engine.speak(clean, TextToSpeech.QUEUE_FLUSH, null, utteranceId)
                } else {
                    @Suppress("DEPRECATION")
                    engine.speak(clean, TextToSpeech.QUEUE_FLUSH, null)
                }
                queuedToEngine = (result == TextToSpeech.SUCCESS)
            } catch (_: Throwable) {
                queuedToEngine = false
            }
        }

        // In headless/Robolectric JVM or when native TTS engine is not bound,
        // complete speech state deterministically and trigger hands-free auto-listen callback.
        if (!queuedToEngine) {
            _isSpeakingFlow.value = false
            if (autoListenAfter) {
                onRequestAutoListen?.invoke()
            }
        }
        return true
    }

    fun stopSpeaking() {
        _isSpeakingFlow.value = false
        try {
            tts?.stop()
        } catch (_: Throwable) {
        }
    }

    /**
     * Called when the HUD state updates so Voice Co-Pilot can automatically read out
     * questions (`NEEDS_INPUT`) or completion summaries (`DONE`) when enabled.
     */
    fun onHudStateUpdated(
        state: String,
        title: String,
        currentAction: String,
        questionText: String,
        detailedOutput: String
    ) {
        val cfg = _configFlow.value
        if (!cfg.enabled) return

        when (state.uppercase(Locale.US)) {
            "NEEDS_INPUT" -> {
                if (!cfg.autoSpeakQuestion) return
                val qText = questionText.ifBlank { currentAction }.ifBlank { title }.trim()
                if (qText.isNotEmpty() && qText != lastAutoSpokenQuestionSignature) {
                    lastAutoSpokenQuestionSignature = qText
                    speak(
                        text = qText,
                        isQuestion = true,
                        autoListenAfter = cfg.autoListenOnQuestion
                    )
                }
            }
            "DONE" -> {
                if (!cfg.autoSpeakDone) return
                val summary = currentAction.ifBlank { detailedOutput }.ifBlank { title }.trim()
                if (summary.isNotEmpty() && summary != lastAutoSpokenDoneSignature) {
                    lastAutoSpokenDoneSignature = summary
                    speak(
                        text = summary,
                        isQuestion = false,
                        autoListenAfter = false
                    )
                }
            }
            "WORKING" -> {
                lastAutoSpokenQuestionSignature = ""
                lastAutoSpokenDoneSignature = ""
            }
        }
    }

    fun applyFromJson(json: JSONObject): JSONObject {
        val action = json.optString("action", json.optString("op", "configure")).trim().lowercase(Locale.US)
        return when (action) {
            "toggle" -> {
                val updated = toggleEnabled()
                toJson().apply { put("status", if (updated.enabled) "enabled" else "disabled") }
            }
            "speak" -> {
                val text = json.optString(
                    "text",
                    json.optString("speakText", json.optString("speak", json.optString("tts", "")))
                ).trim()
                val isQuestion = json.optBoolean("isQuestion", false)
                val autoListen = json.optBoolean(
                    "autoListenAfter",
                    isQuestion && _configFlow.value.autoListenOnQuestion
                )
                if (json.optBoolean("enable", true) && !_configFlow.value.enabled) {
                    _configFlow.value = _configFlow.value.copy(enabled = true)
                    onConfigChanged?.invoke(_configFlow.value)
                }
                val ok = speak(text, isQuestion = isQuestion, autoListenAfter = autoListen)
                toJson().apply {
                    put("status", if (ok) "speaking" else "empty_text")
                }
            }
            "stop" -> {
                stopSpeaking()
                toJson().apply { put("status", "stopped") }
            }
            else -> {
                val cfgObj = json.optJSONObject("voice") ?: json
                val next = AgyHudDynamicModels.VoiceCoPilotConfig.fromJson(cfgObj, _configFlow.value)
                configure(next)
                toJson().apply { put("status", if (next.enabled) "enabled" else "configured") }
            }
        }
    }

    fun toJson(): JSONObject {
        val cfg = _configFlow.value
        return cfg.toJson().apply {
            put("success", true)
            put("isSpeaking", _isSpeakingFlow.value)
            put("lastSpokenText", _lastSpokenTextFlow.value)
        }
    }

    fun shutdown() {
        stopSpeaking()
        try {
            tts?.shutdown()
        } catch (_: Throwable) {
        }
        tts = null
        ttsReady = false
    }

    private fun ensureTtsInitialized() {
        if (tts != null) return
        try {
            tts = TextToSpeech(context.applicationContext) { status ->
                ttsReady = (status == TextToSpeech.SUCCESS)
                if (ttsReady) {
                    try {
                        tts?.language = Locale.US
                    } catch (_: Throwable) {
                    }
                }
            }.apply {
                setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        _isSpeakingFlow.value = true
                    }

                    override fun onDone(utteranceId: String?) {
                        _isSpeakingFlow.value = false
                        if (utteranceId != null && utteranceId.startsWith("agy_tts_q_")) {
                            mainHandler.post {
                                onRequestAutoListen?.invoke()
                            }
                        }
                    }

                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        _isSpeakingFlow.value = false
                    }
                })
            }
        } catch (_: Throwable) {
            tts = null
            ttsReady = false
        }
    }
}
