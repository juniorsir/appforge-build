package com.kavach.ui.overlay

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.TextUtils
import android.util.Log
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.MediaController
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.VideoView
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Full-screen interactive Lightbox Preview Overlay (`agy_hud_lightbox`) launched when the user
 * taps any Image, Video, or File card in Window 3's Results Carousel.
 *
 * Supports double-tap zoom for images, inline VideoView playback with controls, monospace snippet
 * preview for files, Prev/Next sibling stepping, and a one-tap "Open in App" native handoff.
 */
class AgyResultLightboxOverlay(
    private val context: Context
) {
    companion object {
        private const val TAG = "AgyResultLightbox"
        const val LIGHTBOX_NODE_TAG = "${AgyHudOverlayManager.HUD_NODE_TAG_PREFIX}lightbox"
    }

    private val mainHandler = Handler(Looper.getMainLooper())
    private val windowManager: WindowManager? by lazy {
        context.getSystemService(Context.WINDOW_SERVICE) as? WindowManager
    }

    private val _isOpenFlow = MutableStateFlow(false)
    val isOpenFlow: StateFlow<Boolean> = _isOpenFlow.asStateFlow()

    private val _currentIndexFlow = MutableStateFlow(0)
    val currentIndexFlow: StateFlow<Int> = _currentIndexFlow.asStateFlow()

    private var items: List<AgyHudDynamicModels.ResultMediaItem> = emptyList()
    private var currentTheme: AgyHudDynamicModels.ResolvedHudTheme =
        AgyHudDynamicModels.resolveTheme(AgyHudDynamicModels.HudThemeConfig(mode = "dark"), Color.parseColor("#38BDF8"))
    private var isZoomed = false

    private var rootBackdrop: FrameLayout? = null
    private var dialogCard: LinearLayout? = null
    private var kindBadgeText: TextView? = null
    private var titleText: TextView? = null
    private var counterText: TextView? = null
    private var mediaImageView: ImageView? = null
    private var videoView: VideoView? = null
    private var fileScrollView: ScrollView? = null
    private var fileContentText: TextView? = null
    private var loadingBar: ProgressBar? = null
    private var subtitleText: TextView? = null
    private var prevBtn: TextView? = null
    private var openAppBtn: TextView? = null
    private var nextBtn: TextView? = null

    fun show(
        mediaItems: List<AgyHudDynamicModels.ResultMediaItem>,
        initialIndex: Int,
        theme: AgyHudDynamicModels.ResolvedHudTheme
    ) {
        if (mediaItems.isEmpty()) return
        items = mediaItems
        currentTheme = theme
        _currentIndexFlow.value = initialIndex.coerceIn(0, mediaItems.lastIndex)
        isZoomed = false
        _isOpenFlow.value = true

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(context)) {
            return
        }
        runOnMain {
            ensureAttached()
            bindCurrentItem()
        }
    }

    fun step(delta: Int) {
        if (items.isEmpty()) return
        val next = (_currentIndexFlow.value + delta).coerceIn(0, items.lastIndex)
        if (next == _currentIndexFlow.value) return
        _currentIndexFlow.value = next
        isZoomed = false
        runOnMain { bindCurrentItem() }
    }

    fun dismiss() {
        _isOpenFlow.value = false
        runOnMain {
            try {
                videoView?.stopPlayback()
            } catch (_: Exception) {}
            rootBackdrop?.let { view ->
                try {
                    windowManager?.removeView(view)
                } catch (e: Exception) {
                    Log.w(TAG, "Error removing lightbox: ${e.message}")
                }
            }
            rootBackdrop = null
            dialogCard = null
            kindBadgeText = null
            titleText = null
            counterText = null
            mediaImageView = null
            videoView = null
            fileScrollView = null
            fileContentText = null
            loadingBar = null
            subtitleText = null
            prevBtn = null
            openAppBtn = null
            nextBtn = null
        }
    }

    private fun ensureAttached() {
        if (rootBackdrop != null) return
        val wm = windowManager ?: return
        val d = context.resources.displayMetrics.density

        val backdrop = object : FrameLayout(context) {
            override fun dispatchKeyEvent(event: KeyEvent): Boolean {
                if (event.keyCode == KeyEvent.KEYCODE_BACK && event.action == KeyEvent.ACTION_UP) {
                    dismiss()
                    return true
                }
                return super.dispatchKeyEvent(event)
            }
        }.apply {
            tag = LIGHTBOX_NODE_TAG
            contentDescription = LIGHTBOX_NODE_TAG
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS
            setBackgroundColor(Color.parseColor("#CC020617"))
            setPadding((16 * d).toInt(), (32 * d).toInt(), (16 * d).toInt(), (32 * d).toInt())
            setOnClickListener { dismiss() }
        }

        val card = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((14 * d).toInt(), (12 * d).toInt(), (14 * d).toInt(), (12 * d).toInt())
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER
            )
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = 20f * d
                setColor(Color.parseColor("#FF0F172A"))
                setStroke((1.2f * d).toInt().coerceAtLeast(1), Color.parseColor("#FF334155"))
            }
            setOnClickListener { /* absorb inside clicks */ }
        }
        dialogCard = card

        // Top Header
        val header = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = (10 * d).toInt() }
        }

        val kindBadge = TextView(context).apply {
            textSize = 10f
            setTypeface(Typeface.MONOSPACE, Typeface.BOLD)
            setTextColor(Color.WHITE)
            setPadding((7 * d).toInt(), (3 * d).toInt(), (7 * d).toInt(), (3 * d).toInt())
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { marginEnd = (8 * d).toInt() }
        }
        kindBadgeText = kindBadge

        val titleTv = TextView(context).apply {
            textSize = 13.5f
            setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
            setTextColor(Color.parseColor("#FFF8FAFC"))
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        titleText = titleTv

        val counterTv = TextView(context).apply {
            textSize = 11f
            typeface = Typeface.MONOSPACE
            setTextColor(Color.parseColor("#FF94A3B8"))
            setPadding((6 * d).toInt(), 0, (8 * d).toInt(), 0)
        }
        counterText = counterTv

        val closeBtn = TextView(context).apply {
            text = "✕"
            textSize = 14f
            setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
            setTextColor(Color.parseColor("#FFF8FAFC"))
            gravity = Gravity.CENTER
            minWidth = (36 * d).toInt()
            minHeight = (36 * d).toInt()
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = 999f * d
                setColor(Color.parseColor("#FF1E293B"))
            }
            contentDescription = "${LIGHTBOX_NODE_TAG}_close"
            setOnClickListener { dismiss() }
        }

        header.addView(kindBadge)
        header.addView(titleTv)
        header.addView(counterTv)
        header.addView(closeBtn)
        card.addView(header)

        // Center Content Viewport
        val viewport = FrameLayout(context).apply {
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                (300 * d).toInt()
            ).apply { bottomMargin = (10 * d).toInt() }
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = 14f * d
                setColor(Color.parseColor("#FF020617"))
                setStroke((1f * d).toInt(), Color.parseColor("#FF1E293B"))
            }
            clipChildren = true
            clipToPadding = true
        }

        val imgView = ImageView(context).apply {
            scaleType = ImageView.ScaleType.FIT_CENTER
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            setOnClickListener {
                isZoomed = !isZoomed
                scaleType = if (isZoomed) ImageView.ScaleType.CENTER_CROP else ImageView.ScaleType.FIT_CENTER
            }
        }
        mediaImageView = imgView

        val vidView = VideoView(context).apply {
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT,
                Gravity.CENTER
            )
            visibility = View.GONE
        }
        videoView = vidView

        val scroll = ScrollView(context).apply {
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            setPadding((12 * d).toInt(), (10 * d).toInt(), (12 * d).toInt(), (10 * d).toInt())
            visibility = View.GONE
        }
        val fileTv = TextView(context).apply {
            textSize = 11.5f
            typeface = Typeface.MONOSPACE
            setTextColor(Color.parseColor("#FFE2E8F0"))
            setLineSpacing(2f * d, 1.15f)
        }
        scroll.addView(fileTv)
        fileScrollView = scroll
        fileContentText = fileTv

        val progress = ProgressBar(context).apply {
            layoutParams = FrameLayout.LayoutParams(
                (36 * d).toInt(),
                (36 * d).toInt(),
                Gravity.CENTER
            )
            visibility = View.GONE
        }
        loadingBar = progress

        viewport.addView(imgView)
        viewport.addView(vidView)
        viewport.addView(scroll)
        viewport.addView(progress)
        card.addView(viewport)

        // Caption / Subtitle
        val subTv = TextView(context).apply {
            textSize = 11.5f
            setTextColor(Color.parseColor("#FFCBD5E1"))
            maxLines = 3
            ellipsize = TextUtils.TruncateAt.END
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = (10 * d).toInt() }
        }
        subtitleText = subTv
        card.addView(subTv)

        // Footer Action Bar: [‹ Prev] [Open in App ↗] [Next ›]
        val footer = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }

        fun pillBtn(label: String, bgHex: String, fgHex: String, weight: Float = 0f, onClick: () -> Unit): TextView {
            return TextView(context).apply {
                text = label
                textSize = 12f
                setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
                setTextColor(Color.parseColor(fgHex))
                gravity = Gravity.CENTER
                minHeight = (40 * d).toInt()
                setPadding((14 * d).toInt(), (8 * d).toInt(), (14 * d).toInt(), (8 * d).toInt())
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = 999f * d
                    setColor(Color.parseColor(bgHex))
                }
                layoutParams = if (weight > 0f) {
                    LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, weight).apply {
                        marginStart = (8 * d).toInt()
                        marginEnd = (8 * d).toInt()
                    }
                } else {
                    LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.WRAP_CONTENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                    )
                }
                setOnClickListener { onClick() }
            }
        }

        val prev = pillBtn("‹ Prev", "#FF1E293B", "#FFF8FAFC") { step(-1) }
        val openApp = pillBtn("Open in App ↗", "#FF0095F6", "#FFFFFFFF", weight = 1f) {
            items.getOrNull(_currentIndexFlow.value)?.let { item ->
                AgyResultsMediaLoader.openInDefaultApp(context, item)
            }
        }
        val next = pillBtn("Next ›", "#FF1E293B", "#FFF8FAFC") { step(1) }

        prevBtn = prev
        openAppBtn = openApp
        nextBtn = next

        footer.addView(prev)
        footer.addView(openApp)
        footer.addView(next)
        card.addView(footer)

        backdrop.addView(card)

        val windowType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            windowType,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )

        try {
            wm.addView(backdrop, params)
            rootBackdrop = backdrop
        } catch (e: Exception) {
            Log.e(TAG, "Failed attaching lightbox overlay: ${e.message}")
        }
    }

    private fun bindCurrentItem() {
        val idx = _currentIndexFlow.value.coerceIn(0, items.lastIndex.coerceAtLeast(0))
        val item = items.getOrNull(idx) ?: return
        val d = context.resources.displayMetrics.density

        try {
            videoView?.stopPlayback()
        } catch (_: Exception) {}

        val badgeColor = when (item.kind) {
            "video" -> Color.parseColor("#FFE11D48")
            "file" -> Color.parseColor("#FFD97706")
            else -> currentTheme.accent
        }
        kindBadgeText?.apply {
            text = AgyResultsMediaLoader.fileExtensionBadge(item)
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = 6f * d
                setColor(badgeColor)
            }
        }
        titleText?.text = item.title
        counterText?.apply {
            visibility = if (items.size > 1) View.VISIBLE else View.GONE
            text = "${idx + 1} / ${items.size}"
        }
        subtitleText?.apply {
            val detail = buildString {
                if (item.subtitle.isNotBlank()) append(item.subtitle)
                if (item.fileSizeLabel.isNotBlank()) {
                    if (isNotEmpty()) append(" • ")
                    append(item.fileSizeLabel)
                }
                if (item.kind == "image") {
                    if (isNotEmpty()) append(" • ")
                    append("Tap image to zoom")
                }
            }
            text = detail
            visibility = if (detail.isNotBlank()) View.VISIBLE else View.GONE
        }

        val multi = items.size > 1
        prevBtn?.apply {
            visibility = if (multi) View.VISIBLE else View.GONE
            alpha = if (idx > 0) 1f else 0.4f
            isEnabled = idx > 0
        }
        nextBtn?.apply {
            visibility = if (multi) View.VISIBLE else View.GONE
            alpha = if (idx < items.lastIndex) 1f else 0.4f
            isEnabled = idx < items.lastIndex
        }
        openAppBtn?.apply {
            visibility = if (item.uri.isNotBlank()) View.VISIBLE else View.GONE
        }

        mediaImageView?.visibility = View.GONE
        videoView?.visibility = View.GONE
        fileScrollView?.visibility = View.GONE
        loadingBar?.visibility = View.GONE

        when (item.kind) {
            "image" -> {
                mediaImageView?.visibility = View.VISIBLE
                mediaImageView?.scaleType = ImageView.ScaleType.FIT_CENTER
                mediaImageView?.setImageDrawable(null)
                loadingBar?.visibility = View.VISIBLE
                AgyResultsMediaLoader.loadPreviewBitmap(context, item, maxDimensionPx = 1080) { bmp ->
                    if (_currentIndexFlow.value != idx || !_isOpenFlow.value) return@loadPreviewBitmap
                    loadingBar?.visibility = View.GONE
                    if (bmp != null) {
                        mediaImageView?.setImageBitmap(bmp)
                    } else {
                        mediaImageView?.visibility = View.GONE
                        fileScrollView?.visibility = View.VISIBLE
                        fileContentText?.text = "Preview unavailable.\n\nSource: ${item.uri}\n\nTap 'Open in App' below to view externally."
                    }
                }
            }
            "video" -> {
                val parsedUri = AgyResultsMediaLoader.resolveDisplayUri(item.uri)
                if (parsedUri != null) {
                    videoView?.visibility = View.VISIBLE
                    loadingBar?.visibility = View.VISIBLE
                    val vv = videoView
                    if (vv != null) {
                        val controller = MediaController(context)
                        controller.setAnchorView(vv)
                        vv.setMediaController(controller)
                        vv.setOnPreparedListener { mp ->
                            loadingBar?.visibility = View.GONE
                            mp.isLooping = true
                            vv.start()
                        }
                        vv.setOnErrorListener { _, _, _ ->
                            loadingBar?.visibility = View.GONE
                            vv.visibility = View.GONE
                            fileScrollView?.visibility = View.VISIBLE
                            fileContentText?.text = "Inline playback unavailable for this stream.\n\nSource: ${item.uri}\n\nTap 'Open in App' below to launch your video player."
                            true
                        }
                        vv.setVideoURI(parsedUri)
                    }
                } else {
                    fileScrollView?.visibility = View.VISIBLE
                    fileContentText?.text = "No playable video URI provided."
                }
            }
            else -> {
                fileScrollView?.visibility = View.VISIBLE
                fileContentText?.text = buildFileMetadataHeader(item) + "\nLoading preview..."
                AgyResultsMediaLoader.readFileSnippet(context, item) { snippet ->
                    if (_currentIndexFlow.value != idx || !_isOpenFlow.value) return@readFileSnippet
                    val header = buildFileMetadataHeader(item)
                    fileContentText?.text = if (snippet.isNotBlank()) {
                        "$header\n\n$snippet"
                    } else {
                        "$header\n\nTap 'Open in App' below to open with Android viewer."
                    }
                }
            }
        }
    }

    private fun buildFileMetadataHeader(item: AgyHudDynamicModels.ResultMediaItem): String = buildString {
        append("File: ").append(item.title)
        val mime = AgyResultsMediaLoader.resolveMimeType(item)
        append("\nType: ").append(mime)
        if (item.fileSizeLabel.isNotBlank()) append("\nSize: ").append(item.fileSizeLabel)
        if (item.uri.isNotBlank()) append("\nLocation: ").append(item.uri)
    }

    private fun runOnMain(block: () -> Unit) {
        if (Looper.myLooper() == Looper.getMainLooper()) {
            block()
        } else {
            mainHandler.post(block)
        }
    }
}
