package com.kavach.ui.overlay

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.util.Log
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.animation.LayoutTransition
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.util.Locale
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Termux-First Dual-Window Agy HUD Overlay Manager.
 *
 * Manages two coordinated Dark Obsidian Liquid Glass overlays integrated with FloatingOverlayManager:
 * 1. Window 1 (`agy_input`): Floating interactive command/prompt input bar with dynamic Termux-safe
 *    `FLAG_NOT_FOCUSABLE` keyboard handoff (Termux keeps IME focus until user taps EditText, and
 *    regains focus immediately on Send, Stop, outside touch, or collapse).
 * 2. Window 2 (`agy_hud`): Draggable live Task & Screen HUD with Expanded mode (status dot, opacity
 *    cycle 90%/65%/35%, wireframe toggle, ghost touch-through toggle, live CheckBox task list,
 *    MiniScreenWireframeView) and Collapsed mode (`✓ Agy • Done | 💬 Ask / Task` pill).
 *
 * All views are tagged with `agy_hud_` for self-exclusion in AccessibilityRepositoryImpl, and
 * bounding boxes are exposed for temporary `FLAG_NOT_TOUCHABLE` collision pass-through.
 */
class AgyHudOverlayManager(
    private val context: Context,
    private val floatingOverlayManager: FloatingOverlayManager,
    private val onCommandBroadcast: ((JSONObject) -> Unit)? = null,
    private val onRunRecorded: ((RunRecord) -> Unit)? = null,
    private val onMacroUsed: ((String) -> Unit)? = null,
    private val onSaveMacro: ((title: String, prompt: String, iconHint: String) -> Unit)? = null
) {
    companion object {
        private const val TAG = "AgyHudOverlayManager"
        const val HUD_NODE_TAG_PREFIX = "agy_hud_"
        private const val MAX_QUEUED_COMMANDS = 64

        val OPACITY_LEVELS = floatArrayOf(1.0f, 0.88f, 0.65f)

        // Crisp Opaque Elevated White Gemini Palette (zero bleed-through from apps underneath)
        private val COLOR_OBSIDIAN_GLASS = Color.parseColor("#FFFFFFFF")
        private val COLOR_PILL_INPUT_BG = Color.parseColor("#FFF3F6FA")
        private val COLOR_INNER_CAPSULE = Color.parseColor("#FFF3F6FA")
        private val COLOR_HAIRLINE = Color.parseColor("#FFE5E9F0")
        private val COLOR_CYAN = Color.parseColor("#0095F6")
        private val COLOR_VIOLET = Color.parseColor("#4F46E5")
        private val COLOR_EMERALD = Color.parseColor("#16A34A")
        private val COLOR_AMBER = Color.parseColor("#D97706")
        private val COLOR_CORAL = Color.parseColor("#E11D48")
        private val COLOR_TEXT_PRIMARY = Color.parseColor("#0F172A")
        private val COLOR_TEXT_SECONDARY = Color.parseColor("#64748B")
    }

    data class AgyHudTask(
        val id: String,
        val label: String,
        val status: String = "pending", // done | doing | pending | needs_input
        val icon: String = "",          // optional explicit icon key ("youtube", "termux", "chrome", ...)
        val appPackage: String = "",    // optional Android package name for real app icon lookup
        val detail: String = "",        // optional compact step note
        val actionKind: String = ""     // optional action sub-badge hint ("watching", "tapping", "typing", ...)
    ) {
        fun toJson(): JSONObject = JSONObject().apply {
            put("id", id)
            put("label", label)
            put("status", status)
            if (icon.isNotBlank()) put("icon", icon)
            if (appPackage.isNotBlank()) put("appPackage", appPackage)
            if (detail.isNotBlank()) put("detail", detail)
            if (actionKind.isNotBlank()) put("actionKind", actionKind)
        }
    }

    data class QuickActionChip(
        val label: String,
        val commandText: String,
        val actionType: String = "PROMPT", // PROMPT | STOP | FORCE_STOP | PAUSE | RESUME | COPY_OUTPUT | TOGGLE_OUTPUT | CUSTOM
        val id: String = "",
        val style: String = "", // "" | primary | secondary | danger | success
        val payload: JSONObject? = null
    ) {
        fun toJson(): JSONObject = JSONObject().apply {
            if (id.isNotBlank()) put("id", id)
            put("label", label)
            put("commandText", commandText)
            put("actionType", actionType)
            if (style.isNotBlank()) put("style", style)
            if (payload != null) put("payload", payload)
        }
    }

    data class WireframeZone(
        val x1: Float,
        val y1: Float,
        val x2: Float,
        val y2: Float,
        val role: String = "panel",
        val tag: String = ""
    ) {
        fun toJson(): JSONObject = JSONObject().apply {
            put("x1", x1.toDouble())
            put("y1", y1.toDouble())
            put("x2", x2.toDouble())
            put("y2", y2.toDouble())
            put("role", role)
            put("tag", tag)
        }
    }

    data class WireframeActionVector(
        val type: String = "TAP", // TAP | CLICK | SWIPE | DRAG
        val x1: Float,
        val y1: Float,
        val x2: Float = x1,
        val y2: Float = y1
    ) {
        fun toJson(): JSONObject = JSONObject().apply {
            put("type", type)
            put("x1", x1.toDouble())
            put("y1", y1.toDouble())
            put("x2", x2.toDouble())
            put("y2", y2.toDouble())
        }
    }

    data class ScreenWatchState(
        val active: Boolean = false,
        val label: String = "",
        val screenWidth: Int = 1080,
        val screenHeight: Int = 2400,
        val zones: List<WireframeZone> = emptyList(),
        val actionVector: WireframeActionVector? = null
    ) {
        fun toJson(): JSONObject = JSONObject().apply {
            put("active", active)
            put("label", label)
            put("screenWidth", screenWidth)
            put("screenHeight", screenHeight)
            put("zones", JSONArray().apply { zones.forEach { put(it.toJson()) } })
            if (actionVector != null) put("actionVector", actionVector.toJson())
        }
    }

    data class AgyHudState(
        val state: String = "IDLE", // IDLE | WORKING | PAUSED | NEEDS_INPUT | STOPPING | STOPPED | DONE
        val title: String = "Agy Ready",
        val currentAction: String = "",
        val nextAction: String = "",
        val question: String = "",
        val autoCollapseSeconds: Int = 4,
        val tasks: List<AgyHudTask> = emptyList(),
        val screenWatch: ScreenWatchState = ScreenWatchState(),
        val appPackage: String = "",
        val icon: String = "",
        val detailedOutput: String = "",
        val outputLogs: List<String> = emptyList(),
        val quickActions: List<QuickActionChip> = emptyList(),
        val statusLabel: String = "",
        val customEmoji: String = "",
        val timerVisible: Boolean = true,
        val customTimerText: String = "",
        val theme: AgyHudDynamicModels.HudThemeConfig = AgyHudDynamicModels.HudThemeConfig(),
        val layout: AgyHudDynamicModels.HudLayoutConfig = AgyHudDynamicModels.HudLayoutConfig(),
        val progress: AgyHudDynamicModels.HudProgressConfig = AgyHudDynamicModels.HudProgressConfig(),
        val metrics: List<AgyHudDynamicModels.HudMetricItem> = emptyList(),
        val banner: AgyHudDynamicModels.HudBannerConfig = AgyHudDynamicModels.HudBannerConfig(),
        val blocks: List<AgyHudDynamicModels.HudContentBlock> = emptyList(),
        val actionKind: String = "",
        val taskMap: AgyHudDynamicModels.TaskMapConfig = AgyHudDynamicModels.TaskMapConfig(),
        val approvalGate: AgyHudDynamicModels.ApprovalGateConfig = AgyHudDynamicModels.ApprovalGateConfig(),
        val spotlight: AgyHudDynamicModels.SpotlightConfig = AgyHudDynamicModels.SpotlightConfig(),
        val smartSuggestions: List<AgyHudDynamicModels.SmartSuggestionChip> = emptyList(),
        val demoSession: AgyHudDynamicModels.DemoRecordingSession = AgyHudDynamicModels.DemoRecordingSession(),
        val scratchpadItems: List<AgyHudDynamicModels.ScratchpadItem> = emptyList(),
        val watchdog: AgyHudDynamicModels.ScreenWatchdogConfig = AgyHudDynamicModels.ScreenWatchdogConfig(),
        val voiceCoPilot: AgyHudDynamicModels.VoiceCoPilotConfig = AgyHudDynamicModels.VoiceCoPilotConfig()
    ) {
        fun toJson(): JSONObject = JSONObject().apply {
            put("state", state)
            put("title", title)
            put("currentAction", currentAction)
            put("nextAction", nextAction)
            put("question", question)
            put("autoCollapseSeconds", autoCollapseSeconds)
            put("tasks", JSONArray().apply { tasks.forEach { put(it.toJson()) } })
            put("screenWatch", screenWatch.toJson())
            if (appPackage.isNotBlank()) put("appPackage", appPackage)
            if (icon.isNotBlank()) put("icon", icon)
            if (detailedOutput.isNotBlank()) put("detailedOutput", detailedOutput)
            put("outputLogs", JSONArray().apply { outputLogs.forEach { put(it) } })
            put("quickActions", JSONArray().apply { quickActions.forEach { put(it.toJson()) } })
            if (statusLabel.isNotBlank()) put("statusLabel", statusLabel)
            if (customEmoji.isNotBlank()) put("customEmoji", customEmoji)
            put("timerVisible", timerVisible)
            if (customTimerText.isNotBlank()) put("customTimerText", customTimerText)
            put("theme", theme.toJson())
            put("layout", layout.toJson())
            put("progress", progress.toJson())
            put("metrics", JSONArray().apply { metrics.forEach { put(it.toJson()) } })
            put("banner", banner.toJson())
            put("blocks", JSONArray().apply { blocks.forEach { put(it.toJson()) } })
            if (actionKind.isNotBlank()) put("actionKind", actionKind)
            put("taskMap", taskMap.toJson())
            put("approval", approvalGate.toJson())
            put("spotlight", spotlight.toJson())
            put("smartSuggestions", JSONArray().apply { smartSuggestions.forEach { put(it.toJson()) } })
            put("demoSession", demoSession.toJson())
            put("scratchpad", JSONArray().apply { scratchpadItems.forEach { put(it.toJson()) } })
            put("watchdog", watchdog.toJson())
            put("voiceCoPilot", voiceCoPilot.toJson())
        }
    }

    data class HudCommand(
        val id: String = "cmd_${UUID.randomUUID().toString().take(8)}",
        val type: String = "HUD_COMMAND",
        val text: String,
        val action: String = "PROMPT", // PROMPT | STOP | FORCE_STOP | PAUSE | RESUME | CUSTOM
        val timestamp: Long = System.currentTimeMillis(),
        val buttonId: String = "",
        val payload: JSONObject? = null
    ) {
        fun toJson(): JSONObject = JSONObject().apply {
            put("id", id)
            put("type", type)
            put("text", text)
            put("action", action)
            put("timestamp", timestamp)
            if (buttonId.isNotBlank()) put("buttonId", buttonId)
            if (payload != null) put("payload", payload)
        }
    }

    data class CollapsedRunningStep(
        val label: String,
        val icon: AgyAppIconResolver.ResolvedIcon
    )

    data class MacroShortcut(
        val id: String,
        val title: String,
        val prompt: String,
        val iconHint: String = "spark_ai"
    )

    data class RunRecord(
        val title: String,
        val promptText: String,
        val finalState: String,
        val iconHint: String,
        val appPackage: String,
        val durationMs: Long,
        val stepCount: Int,
        val detailedOutput: String,
        val outputLogs: List<String>
    )

    private val mainHandler = Handler(Looper.getMainLooper())
    private val windowManager: WindowManager? by lazy {
        context.getSystemService(Context.WINDOW_SERVICE) as? WindowManager
    }
    private val inputMethodManager: InputMethodManager? by lazy {
        context.getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
    }

    private val commandQueue = ConcurrentLinkedQueue<HudCommand>()

    private val _isHudVisible = MutableStateFlow(false)
    val isHudVisible: StateFlow<Boolean> = _isHudVisible.asStateFlow()

    private val _isInputVisible = MutableStateFlow(false)
    val isInputVisible: StateFlow<Boolean> = _isInputVisible.asStateFlow()

    private val _hudState = MutableStateFlow(AgyHudState())
    val hudState: StateFlow<AgyHudState> = _hudState.asStateFlow()

    private val _isCollapsedFlow = MutableStateFlow(true)
    val isCollapsedFlow: StateFlow<Boolean> = _isCollapsedFlow.asStateFlow()

    private val _opacityFlow = MutableStateFlow(OPACITY_LEVELS[0])
    val opacityFlow: StateFlow<Float> = _opacityFlow.asStateFlow()

    private val _ghostPassThroughFlow = MutableStateFlow(false)
    val ghostPassThroughFlow: StateFlow<Boolean> = _ghostPassThroughFlow.asStateFlow()

    private val _wireframeEnabledFlow = MutableStateFlow(true)
    val wireframeEnabledFlow: StateFlow<Boolean> = _wireframeEnabledFlow.asStateFlow()

    private val _edgeSnapEnabledFlow = MutableStateFlow(true)
    val edgeSnapEnabledFlow: StateFlow<Boolean> = _edgeSnapEnabledFlow.asStateFlow()

    private val _pointerEnabledFlow = MutableStateFlow(true)
    val pointerEnabledFlow: StateFlow<Boolean> = _pointerEnabledFlow.asStateFlow()

    private val _pointerShowLabelFlow = MutableStateFlow(true)
    val pointerShowLabelFlow: StateFlow<Boolean> = _pointerShowLabelFlow.asStateFlow()

    @Volatile
    var pointerOverlayManager: AgyPointerOverlayManager? = null
        set(value) {
            field = value
            value?.setPointerConfig(
                enabled = _pointerEnabledFlow.value,
                showLabel = _pointerShowLabelFlow.value
            )
        }

    @Volatile
    var taskMapOverlayManager: AgyTaskMapOverlayManager? = null
        set(value) {
            field = value
            value?.onDismissRequested = { dismissedSig ->
                lastDismissedTaskMapSig = dismissedSig
            }
            value?.attachLayoutCoordinator(layoutCoordinator)
        }

    @Volatile
    var regionSnipOverlayManager: AgyRegionSnipOverlayManager? = null

    @Volatile
    var edgeHandleOverlayManager: AgyEdgeHandleOverlayManager? = null
        set(value) {
            field = value
            value?.setCallbacks(
                AgyEdgeHandleOverlayManager.Callbacks(
                    onAsk = { summonFromEdge(focusComposer = true) },
                    onVoice = { summonFromEdge(startVoice = true) },
                    onSnip = { summonFromEdge(startSnip = true) },
                    onExpand = { summonFromEdge(focusComposer = false) },
                    onStop = { handleRemoteCommand(JSONObject().put("action", "STOP")) }
                )
            )
        }

    @Volatile
    var spotlightOverlayManager: AgySpotlightOverlayManager? = null
        set(value) {
            field = value
            value?.onDismissedByUser = {
                val cur = _hudState.value
                if (cur.spotlight.active) {
                    _hudState.value = cur.copy(spotlight = AgyHudDynamicModels.SpotlightConfig(active = false))
                }
            }
        }

    val demoRecorderManager: AgyDemoRecorderManager = AgyDemoRecorderManager().apply {
        onSessionChanged = { session ->
            val cur = _hudState.value
            if (cur.demoSession != session) {
                _hudState.value = cur.copy(demoSession = session)
            }
            runOnMain { if (hudRootView != null) renderHudWindow() }
        }
    }

    val scratchpadManager: AgyScratchpadManager = AgyScratchpadManager(context).apply {
        onItemsChanged = { items ->
            val cur = _hudState.value
            if (cur.scratchpadItems != items) {
                _hudState.value = cur.copy(scratchpadItems = items)
            }
            runOnMain { if (hudRootView != null) renderHudWindow() }
        }
    }

    val screenWatchdogManager: AgyScreenWatchdogManager = AgyScreenWatchdogManager().apply {
        onWatchdogStateChanged = { wd ->
            val cur = _hudState.value
            if (cur.watchdog != wd) {
                _hudState.value = cur.copy(watchdog = wd)
            }
            runOnMain { if (hudRootView != null) renderHudWindow() }
        }
        onWatchdogTriggered = { triggeredConfig, diffSummary ->
            val promptText = triggeredConfig.triggerPrompt.ifBlank {
                "Watchdog triggered (${triggeredConfig.rule}): $diffSummary"
            }
            val payload = JSONObject().apply {
                put("watchdog", triggeredConfig.toJson())
                put("diffSummary", diffSummary)
                triggeredConfig.region?.let { put("regionContext", it.toJson()) }
            }
            enqueueAndBroadcastCommand(
                text = promptText,
                action = "WATCHDOG_TRIGGERED",
                buttonId = triggeredConfig.id,
                payload = payload
            )
            runOnMain { if (hudRootView != null) renderHudWindow() }
        }
    }

    val voiceCoPilotManager: AgyVoiceCoPilotManager = AgyVoiceCoPilotManager(context).apply {
        onConfigChanged = { cfg ->
            val cur = _hudState.value
            if (cur.voiceCoPilot != cfg) {
                _hudState.value = cur.copy(voiceCoPilot = cfg)
            }
            runOnMain { if (hudRootView != null) renderHudWindow() }
        }
        onRequestAutoListen = {
            if (!_isVoiceListeningFlow.value) {
                _isVoiceListeningFlow.value = true
                runOnMain {
                    updateVoiceMicUi(true)
                    try {
                        toggleVoiceDictationInternal()
                    } catch (_: Throwable) {}
                    // Ensure flow remains true even in headless JVM/Robolectric where SpeechRecognizer is unbound
                    _isVoiceListeningFlow.value = true
                    updateVoiceMicUi(true)
                    if (hudRootView != null) renderHudWindow()
                }
            }
        }
    }

    @Volatile
    private var isScratchpadDrawerOpen: Boolean = false

    @Volatile
    var foregroundPackageProvider: (() -> String?)? = null
        set(value) {
            field = value
            demoRecorderManager.foregroundPackageProvider = value
            scratchpadManager.foregroundPackageProvider = value
            screenWatchdogManager.foregroundPackageProvider = value
        }

    @Volatile
    var nodeTreeProvider: (() -> List<com.kavach.accessibility.models.AccessibilityNodeModel>)? = null
        set(value) {
            field = value
            demoRecorderManager.nodeTreeProvider = value
            screenWatchdogManager.nodeTreeProvider = value
        }

    private val _queuedPromptsFlow = MutableStateFlow<List<AgyHudDynamicModels.QueuedPromptItem>>(emptyList())
    val queuedPromptsFlow: StateFlow<List<AgyHudDynamicModels.QueuedPromptItem>> = _queuedPromptsFlow.asStateFlow()

    private val _attachedRegionContextFlow = MutableStateFlow<AgyHudDynamicModels.SnippedRegionContext?>(null)
    val attachedRegionContextFlow: StateFlow<AgyHudDynamicModels.SnippedRegionContext?> = _attachedRegionContextFlow.asStateFlow()

    private val _isEdgeParkedFlow = MutableStateFlow(false)
    val isEdgeParkedFlow: StateFlow<Boolean> = _isEdgeParkedFlow.asStateFlow()

    @Volatile
    private var pendingEditApprovalId: String? = null

    @Volatile
    private var approvalRemainingSeconds: Int = 0

    @Volatile
    private var activeApprovalCountdownId: String = ""

    private var approvalCountdownRunnable: Runnable? = null
    private var autoDequeueRunnable: Runnable? = null

    @Volatile
    private var lastMacroSavedPrompt: String = ""

    val layoutCoordinator: AgyOverlayLayoutCoordinator = AgyOverlayLayoutCoordinator(context)

    private val _isAutoCollapsedFlow = MutableStateFlow(false)
    val isAutoCollapsedFlow: StateFlow<Boolean> = _isAutoCollapsedFlow.asStateFlow()

    @Volatile
    private var autoCollapsedByCoordinator: Boolean = false
        set(value) {
            field = value
            _isAutoCollapsedFlow.value = value
        }

    @Volatile
    private var userManuallyCollapsed: Boolean = false

    @Volatile
    private var isHudDragging: Boolean = false

    private var lastMeasuredExpandedWidthPx: Int = 0
    private var lastMeasuredExpandedHeightPx: Int = 0
    private var lastMeasuredCollapsedWidthPx: Int = 0
    private var lastMeasuredCollapsedHeightPx: Int = 0
    private var hudDodgeAnimator: android.animation.ValueAnimator? = null
    private var pendingHudTargetLeft: Int? = null
    private var pendingHudTargetTop: Int? = null
    private var hudLayoutReconcileScheduled: Boolean = false
    private val hudLayoutReconcileRunnable = Runnable {
        hudLayoutReconcileScheduled = false
        layoutCoordinator.reconcile(animate = true)
    }

    private val hudCoordinatorEndpoint = object : AgyOverlayLayoutCoordinator.ManagedOverlayEndpoint {
        override val windowId = AgyOverlayLayoutCoordinator.ManagedWindowId.HUD

        override fun captureBoxState(
            viewport: AgyOverlayLayoutCoordinator.ViewportSafeBounds
        ): AgyOverlayLayoutCoordinator.WindowBoxState {
            val visible = _isHudVisible.value && !isTemporarilySuppressed && hudRootView != null && hudParams != null
            val expW = estimateHudExpandedWidthPx()
            val expH = estimateHudExpandedHeightPx()
            val colW = estimateHudCollapsedWidthPx()
            val colH = estimateHudCollapsedHeightPx()
            val curW = if (isCollapsed) colW else expW
            val curH = if (isCollapsed) colH else expH
            val rect = computeHudScreenRect(viewport, curW, curH)
            return AgyOverlayLayoutCoordinator.WindowBoxState(
                id = windowId,
                visible = visible,
                rect = rect,
                expandedWidth = expW,
                expandedHeight = expH,
                collapsedWidth = colW,
                collapsedHeight = colH,
                isCollapsed = isCollapsed,
                autoCollapsedByCoordinator = autoCollapsedByCoordinator,
                userManuallyCollapsed = userManuallyCollapsed
            )
        }

        override fun applyAdjustment(
            adjustment: AgyOverlayLayoutCoordinator.WindowAdjustment,
            viewport: AgyOverlayLayoutCoordinator.ViewportSafeBounds,
            animate: Boolean
        ) {
            runOnMain {
                if (hudRootView == null || hudParams == null) return@runOnMain
                val collapseChanged = adjustment.targetCollapsed != isCollapsed
                autoCollapsedByCoordinator = adjustment.autoCollapsedByCoordinator
                if (collapseChanged) {
                    isCollapsed = adjustment.targetCollapsed
                    if (adjustment.targetCollapsed) {
                        isToolsTrayOpen = false
                        blurInlineComposerInternal()
                    } else {
                        userManuallyCollapsed = false
                        _isInputVisible.value = _hudState.value.layout.showComposer
                    }
                    renderHudWindow(scheduleReconcile = false)
                }
                if ((adjustment.positionChanged || collapseChanged) && !isInputFocused) {
                    moveHudToScreenTopLeft(adjustment.targetLeft, adjustment.targetTop, viewport, animate)
                }
            }
        }

        override fun clampPosition(
            targetLeft: Int,
            targetTop: Int,
            viewport: AgyOverlayLayoutCoordinator.ViewportSafeBounds,
            animate: Boolean
        ) {
            runOnMain {
                if (!isInputFocused) {
                    moveHudToScreenTopLeft(targetLeft, targetTop, viewport, animate)
                }
            }
        }
    }

    init {
        layoutCoordinator.registerEndpoint(hudCoordinatorEndpoint)
    }

    @Volatile
    private var lastDismissedTaskMapSig: String? = null

    private val _isVoiceListeningFlow = MutableStateFlow(false)
    val isVoiceListeningFlow: StateFlow<Boolean> = _isVoiceListeningFlow.asStateFlow()

    private val _pinnedMacrosFlow = MutableStateFlow<List<MacroShortcut>>(emptyList())
    val pinnedMacrosFlow: StateFlow<List<MacroShortcut>> = _pinnedMacrosFlow.asStateFlow()

    private val _isOutputExpandedFlow = MutableStateFlow(false)
    val isOutputExpandedFlow: StateFlow<Boolean> = _isOutputExpandedFlow.asStateFlow()

    private val _elapsedMsFlow = MutableStateFlow(0L)
    val elapsedMsFlow: StateFlow<Long> = _elapsedMsFlow.asStateFlow()

    @Volatile
    private var isCollapsed: Boolean = true
        set(value) {
            field = value
            _isCollapsedFlow.value = value
        }
    @Volatile
    @set:JvmName("setOutputExpandedInternal")
    private var isOutputExpanded: Boolean = false
        set(value) {
            field = value
            _isOutputExpandedFlow.value = value
        }
    @Volatile
    private var opacityIndex: Int = 0
        set(value) {
            field = value
            _opacityFlow.value = OPACITY_LEVELS[value.coerceIn(0, OPACITY_LEVELS.lastIndex)]
        }
    @Volatile
    private var wireframeEnabled: Boolean = true
        set(value) {
            field = value
            _wireframeEnabledFlow.value = value
        }
    @Volatile
    private var edgeSnapEnabled: Boolean = true
        set(value) {
            field = value
            _edgeSnapEnabledFlow.value = value
        }
    @Volatile
    private var ghostPassThrough: Boolean = false
        set(value) {
            field = value
            _ghostPassThroughFlow.value = value
        }
    @Volatile
    private var isToolsTrayOpen: Boolean = false
    @Volatile
    private var isInputFocused: Boolean = false
    @Volatile
    private var temporaryPassThroughActive: Boolean = false
    @Volatile
    private var lastSubmittedPrompt: String = ""

    // Single Unified Floating Gemini HUD (`agy_hud`) references
    private var hudRootView: HoldDraggableDockLayout? = null
    private var hudParams: WindowManager.LayoutParams? = null
    private var hudExpandedContainer: AgyAuroraCardLayout? = null
    private var hudBottomDockRow: LinearLayout? = null
    private var workingLoadingBar: AgyLoadingBarView? = null
    private var headerAppIconView: AgyIconBadgeView? = null
    private var headerSpinnerView: AgySpinnerRingView? = null
    private var statusDotView: View? = null
    private var statusBadgeText: TextView? = null
    private var elapsedTimerText: TextView? = null
    private var toolsMenuBtn: TextView? = null
    private var toolsTrayContainer: LinearLayout? = null
    private var titleText: TextView? = null
    private var questionBannerText: TextView? = null
    private var doingRowContainer: LinearLayout? = null
    private var currentActionText: TextView? = null
    private var doingDotsView: AgyBouncingDotsView? = null
    private var nextActionText: TextView? = null
    private var taskListContainer: LinearLayout? = null
    private var taskScrollView: ScrollView? = null
    private var outputSectionContainer: LinearLayout? = null
    private var outputToggleHeaderText: TextView? = null
    private var outputDrawerContainer: LinearLayout? = null
    private var outputCopyBtn: TextView? = null
    private var outputBodyText: TextView? = null
    private var quickActionsScrollView: HorizontalScrollView? = null
    private var quickActionsContainer: LinearLayout? = null
    private var opacityBtn: TextView? = null
    private var wireframeBtn: TextView? = null
    private var ghostBtn: TextView? = null
    private var edgeSnapBtn: TextView? = null
    private var pointerBtn: TextView? = null
    private var dockStandardStatusGroup: LinearLayout? = null
    private var dockStandardDivider: View? = null
    private var dockSpinnerView: AgySpinnerRingView? = null
    private var collapsedStatusText: TextView? = null
    private var bottomChatPillBtn: TextView? = null
    private var dockLiveStepGroup: LinearLayout? = null
    private var dockLiveSpinnerView: AgySpinnerRingView? = null
    private var dockLiveIconView: AgyIconBadgeView? = null
    private var dockLiveStepText: TextView? = null
    private var dockLiveTimerText: TextView? = null
    private var dockLiveStopBtn: TextView? = null
    private var lastCollapsedStepLabel: String = ""
    private var lastRenderedCollapsedState: Boolean? = null
    private var lastRenderedTitle: String = ""
    private var lastRenderedTaskStatuses: Map<String, String> = emptyMap()
    private var lastDockTapAtMs: Long = 0L

    // Built-in Bottom Composer Dock & On-Demand Progressive Disclosure inside the Unified Gemini Card
    private var telemetryDetailsContainer: LinearLayout? = null
    private var stepsTogglePill: TextView? = null
    private var headerCollapseBtn: TextView? = null
    private var customEmojiView: TextView? = null
    private var progressRowContainer: LinearLayout? = null
    private var progressBarView: AgyLoadingBarView? = null
    private var progressCaptionText: TextView? = null
    private var metricsScrollView: HorizontalScrollView? = null
    private var metricsContainer: LinearLayout? = null
    private var dynamicBannerContainer: LinearLayout? = null
    private var dynamicBannerTitleText: TextView? = null
    private var dynamicBannerMsgText: TextView? = null
    private var inlineBlocksContainer: LinearLayout? = null
    private var detailBlocksContainer: LinearLayout? = null
    private var composerDividerView: View? = null
    private var isDetailsExpanded: Boolean = false
    private var isMacrosDrawerOpen: Boolean = false
    private var savedYBeforeIme: Int? = null
    private var isTemporarilySuppressed: Boolean = false
    private var inlineComposerContainer: LinearLayout? = null
    private var composerInputCapsule: LinearLayout? = null
    private var composerVoiceStatusHint: TextView? = null
    private var inputEditText: EditText? = null
    private var inputMicBtn: AgyGlyphButtonView? = null
    private var clearDraftBtn: AgyGlyphButtonView? = null
    private var macrosToggleBtn: AgyGlyphButtonView? = null
    private var composerActionBtn: AgyGlyphButtonView? = null
    private var inputMacrosScrollView: HorizontalScrollView? = null
    private var inputMacrosContainer: LinearLayout? = null
    private var voiceController: AgyVoiceInputController? = null

    // Power-Feature HUD views (Approval Gate, Prompt Queue, Region Snip Chip, Smart Suggestions, Edge/Snip tools)
    private var approvalCardContainer: LinearLayout? = null
    private var approvalRiskBadgeText: TextView? = null
    private var approvalTimerBadgeText: TextView? = null
    private var approvalTitleText: TextView? = null
    private var approvalDescText: TextView? = null
    private var approvalPreviewText: TextView? = null
    private var approvalApproveBtn: TextView? = null
    private var approvalEditBtn: TextView? = null
    private var approvalDenyBtn: TextView? = null
    private var promptQueueContainer: LinearLayout? = null
    private var promptQueueHeaderText: TextView? = null
    private var promptQueueListContainer: LinearLayout? = null
    private var attachedRegionChipRow: LinearLayout? = null
    private var attachedRegionChipText: TextView? = null
    private var smartSuggestionsScrollView: HorizontalScrollView? = null
    private var smartSuggestionsContainer: LinearLayout? = null
    private var snipToolBtn: TextView? = null
    private var edgeParkToolBtn: TextView? = null
    private var composerSnipBtn: TextView? = null
    private var demoToolBtn: TextView? = null
    private var scratchpadToolBtn: TextView? = null
    private var watchdogToolBtn: TextView? = null
    private var voiceCoPilotToolBtn: TextView? = null
    private var demoRecorderCardContainer: LinearLayout? = null
    private var demoRecorderHeaderText: TextView? = null
    private var demoRecorderStepsContainer: LinearLayout? = null
    private var scratchpadCardContainer: LinearLayout? = null
    private var scratchpadHeaderText: TextView? = null
    private var scratchpadListContainer: LinearLayout? = null
    private var watchdogCardContainer: LinearLayout? = null
    private var watchdogStatusText: TextView? = null

    // Tiny ghost restore pill (only visible while ghost mode is ON so user can exit ghost mode)
    private var ghostRestoreView: View? = null
    private var ghostRestoreParams: WindowManager.LayoutParams? = null

    // Scheduled tasks & live accumulated elapsed timer
    private var autoCollapseRunnable: Runnable? = null
    private var passThroughRestoreRunnable: Runnable? = null
    private var pulseRunnable: Runnable? = null
    private var pulseToggle: Boolean = false
    private var elapsedTimerRunnable: Runnable? = null
    private var accumulatedElapsedMs: Long = 0L
    private var activeSegmentStartMs: Long = 0L
    private var edgeSnapAnimator: android.animation.ValueAnimator? = null
    private var copyFeedbackResetRunnable: Runnable? = null

    fun setPinnedMacros(macros: List<MacroShortcut>) {
        _pinnedMacrosFlow.value = macros
        runOnMain { renderInputMacrosStrip() }
    }

    fun hasOverlayPermission(): Boolean = floatingOverlayManager.hasPermission()

    fun getOverlayPermissionIntent(): Intent? = floatingOverlayManager.getPermissionIntent()

    fun parseHudStateFromJson(json: JSONObject): AgyHudState {
        val current = _hudState.value
        val validStates = listOf("IDLE", "WORKING", "PAUSED", "NEEDS_INPUT", "STOPPING", "STOPPED", "DONE")
        val state = json.optString("state", current.state).uppercase().trim()
            .let { if (it in validStates) it else "WORKING" }
        val title = if (json.has("title")) json.optString("title", "") else current.title
        val currentAction = if (json.has("currentAction")) json.optString("currentAction", "") else current.currentAction
        val nextAction = if (json.has("nextAction")) json.optString("nextAction", "") else current.nextAction
        val question = if (json.has("question")) json.optString("question", "") else if (state != "NEEDS_INPUT") "" else current.question
        val autoCollapse = json.optInt("autoCollapseSeconds", current.autoCollapseSeconds).coerceIn(0, 120)

        val tasks = if (json.has("tasks")) {
            val arr = json.optJSONArray("tasks") ?: JSONArray()
            val list = mutableListOf<AgyHudTask>()
            for (i in 0 until arr.length()) {
                val obj = arr.optJSONObject(i) ?: continue
                list.add(
                    AgyHudTask(
                        id = obj.optString("id", "t_$i"),
                        label = obj.optString("label", "").trim(),
                        status = obj.optString("status", "pending").lowercase().trim(),
                        icon = obj.optString("icon", "").trim(),
                        appPackage = obj.optString("appPackage", "").trim(),
                        detail = obj.optString("detail", "").trim(),
                        actionKind = obj.optString("actionKind", "").trim()
                    )
                )
            }
            list
        } else {
            current.tasks
        }

        val appPackage = if (json.has("appPackage")) json.optString("appPackage", "").trim() else current.appPackage
        val icon = if (json.has("icon")) json.optString("icon", "").trim() else current.icon
        val detailedOutput = if (json.has("detailedOutput")) {
            json.optString("detailedOutput", "")
        } else {
            current.detailedOutput
        }
        val outputLogs = if (json.has("outputLogs")) {
            val arr = json.optJSONArray("outputLogs") ?: JSONArray()
            val logs = mutableListOf<String>()
            for (i in 0 until arr.length()) {
                val line = arr.optString(i, "").trim()
                if (line.isNotEmpty()) logs.add(line)
            }
            logs
        } else {
            current.outputLogs
        }
        val quickActions = if (json.has("quickActions") || json.has("buttons") || json.has("customButtons")) {
            val arr = json.optJSONArray("quickActions")
                ?: json.optJSONArray("buttons")
                ?: json.optJSONArray("customButtons")
                ?: JSONArray()
            val chips = mutableListOf<QuickActionChip>()
            for (i in 0 until arr.length()) {
                val item = arr.opt(i)
                when (item) {
                    is JSONObject -> {
                        val lbl = item.optString("label", "").trim()
                        if (lbl.isNotEmpty()) {
                            chips.add(
                                QuickActionChip(
                                    label = lbl,
                                    commandText = item.optString("commandText", item.optString("text", lbl)).trim(),
                                    actionType = item.optString("actionType", item.optString("action", "PROMPT")).uppercase().trim(),
                                    id = item.optString("id", "").trim(),
                                    style = item.optString("style", "").lowercase().trim(),
                                    payload = item.optJSONObject("payload")
                                )
                            )
                        }
                    }
                    is String -> {
                        val lbl = item.trim()
                        if (lbl.isNotEmpty()) {
                            chips.add(QuickActionChip(label = lbl, commandText = lbl, actionType = "PROMPT"))
                        }
                    }
                }
            }
            chips
        } else if (state != current.state) {
            emptyList()
        } else {
            current.quickActions
        }

        val screenWatch = if (json.has("screenWatch")) {
            val swObj = json.optJSONObject("screenWatch")
            if (swObj != null) {
                val zonesArr = swObj.optJSONArray("zones") ?: JSONArray()
                val zones = mutableListOf<WireframeZone>()
                for (i in 0 until zonesArr.length()) {
                    val z = zonesArr.optJSONObject(i) ?: continue
                    zones.add(
                        WireframeZone(
                            x1 = z.optDouble("x1", 0.0).toFloat(),
                            y1 = z.optDouble("y1", 0.0).toFloat(),
                            x2 = z.optDouble("x2", 0.0).toFloat(),
                            y2 = z.optDouble("y2", 0.0).toFloat(),
                            role = z.optString("role", "panel"),
                            tag = z.optString("tag", "")
                        )
                    )
                }
                val avObj = swObj.optJSONObject("actionVector")
                val actionVec = if (avObj != null) {
                    WireframeActionVector(
                        type = avObj.optString("type", "TAP").uppercase(),
                        x1 = avObj.optDouble("x1", 0.0).toFloat(),
                        y1 = avObj.optDouble("y1", 0.0).toFloat(),
                        x2 = avObj.optDouble("x2", avObj.optDouble("x1", 0.0)).toFloat(),
                        y2 = avObj.optDouble("y2", avObj.optDouble("y1", 0.0)).toFloat()
                    )
                } else null

                ScreenWatchState(
                    active = swObj.optBoolean("active", false),
                    label = swObj.optString("label", ""),
                    screenWidth = swObj.optInt("screenWidth", context.resources.displayMetrics.widthPixels.coerceAtLeast(360)),
                    screenHeight = swObj.optInt("screenHeight", context.resources.displayMetrics.heightPixels.coerceAtLeast(640)),
                    zones = zones,
                    actionVector = actionVec
                )
            } else {
                ScreenWatchState(active = false)
            }
        } else {
            current.screenWatch
        }

        val statusLabel = if (json.has("statusLabel")) json.optString("statusLabel", "").trim() else current.statusLabel
        val customEmoji = if (json.has("customEmoji") || json.has("emoji")) {
            json.optString("customEmoji", json.optString("emoji", "")).trim()
        } else current.customEmoji
        val timerVisible = if (json.has("timerVisible")) json.optBoolean("timerVisible", true) else current.timerVisible
        val customTimerText = if (json.has("customTimerText")) json.optString("customTimerText", "").trim() else current.customTimerText

        val theme = if (json.has("theme")) {
            if (json.isNull("theme")) AgyHudDynamicModels.HudThemeConfig()
            else AgyHudDynamicModels.HudThemeConfig.fromJson(json.optJSONObject("theme"), current.theme)
        } else {
            // Also support convenient top-level accentColor / themeMode shortcuts
            var t = current.theme
            if (json.has("accentColor")) t = t.copy(accentColor = json.optString("accentColor", "").trim())
            if (json.has("themeMode")) t = t.copy(mode = json.optString("themeMode", t.mode).lowercase().trim().ifBlank { "light" })
            t
        }

        val layout = if (json.has("layout")) {
            if (json.isNull("layout")) AgyHudDynamicModels.HudLayoutConfig()
            else AgyHudDynamicModels.HudLayoutConfig.fromJson(json.optJSONObject("layout"), current.layout)
        } else {
            var l = current.layout
            if (json.has("inputPlaceholder")) l = l.copy(inputPlaceholder = json.optString("inputPlaceholder", "").trim())
            if (json.has("showComposer")) l = l.copy(showComposer = json.optBoolean("showComposer", l.showComposer))
            l
        }

        val progress = if (json.has("progress")) {
            if (json.isNull("progress")) AgyHudDynamicModels.HudProgressConfig(visible = false)
            else AgyHudDynamicModels.HudProgressConfig.fromJson(json.opt("progress"), current.progress)
        } else current.progress

        val metrics = if (json.has("metrics")) {
            val arr = json.optJSONArray("metrics") ?: JSONArray()
            buildList {
                for (i in 0 until arr.length()) {
                    val obj = arr.optJSONObject(i) ?: continue
                    AgyHudDynamicModels.HudMetricItem.fromJson(obj, i)?.let { add(it) }
                }
            }
        } else current.metrics

        val banner = if (json.has("banner")) {
            if (json.isNull("banner")) AgyHudDynamicModels.HudBannerConfig(visible = false)
            else AgyHudDynamicModels.HudBannerConfig.fromJson(json.opt("banner"))
        } else current.banner

        val blocks = if (json.has("blocks")) {
            val arr = json.optJSONArray("blocks") ?: JSONArray()
            buildList {
                for (i in 0 until arr.length()) {
                    val obj = arr.optJSONObject(i) ?: continue
                    AgyHudDynamicModels.HudContentBlock.fromJson(obj, i)?.let { add(it) }
                }
            }
        } else current.blocks

        val actionKind = if (json.has("actionKind")) json.optString("actionKind", "").trim() else current.actionKind
        val baselinePlayer = currentPlayerBaseline() ?: current.taskMap.player
        val clearPlayerRequested = json.optBoolean("clearPlayer", false)
        val hasActiveStickyPlayer = !clearPlayerRequested &&
            current.taskMap.active &&
            current.taskMap.mode == "player" &&
            baselinePlayer != null &&
            lastDismissedTaskMapSig != current.taskMap.contentSignature()

        val taskMap = if (json.has("taskMap")) {
            if (json.isNull("taskMap")) {
                lastDismissedTaskMapSig = null
                AgyHudDynamicModels.TaskMapConfig(active = false)
            } else {
                val parsedTm = AgyHudDynamicModels.TaskMapConfig.fromJson(json.opt("taskMap"), baselinePlayer)
                // If the daemon pushed its default inactive app_pane taskMap while the user's player is active,
                // keep the active player alive rather than closing it!
                if (!parsedTm.active && parsedTm.mode == "app_pane" && hasActiveStickyPlayer) {
                    current.taskMap.copy(active = true, player = baselinePlayer)
                } else {
                    if (parsedTm.contentSignature() != lastDismissedTaskMapSig) {
                        lastDismissedTaskMapSig = null
                    }
                    parsedTm
                }
            }
        } else if (json.has("player")) {
            if (json.isNull("player")) {
                lastDismissedTaskMapSig = null
                if (current.taskMap.mode == "player") current.taskMap.copy(active = false) else current.taskMap
            } else {
                val playerData = AgyHudDynamicModels.PlayerTaskMapData.fromJson(json.optJSONObject("player"), baselinePlayer)
                if (playerData != null) {
                    val built = AgyHudDynamicModels.TaskMapConfig(
                        active = true,
                        mode = "player",
                        title = playerData.currentTrack()?.title.orEmpty().ifBlank { "Agy Player" },
                        widthDp = 228f,
                        persistOnDone = true,
                        player = playerData
                    )
                    if (built.contentSignature() != lastDismissedTaskMapSig) {
                        lastDismissedTaskMapSig = null
                    }
                    built
                } else {
                    current.taskMap
                }
            }
        } else if (json.has("results")) {
            if (json.isNull("results")) {
                lastDismissedTaskMapSig = null
                if (current.taskMap.mode == "results") current.taskMap.copy(active = false) else current.taskMap
            } else {
                val resData = AgyHudDynamicModels.ResultsTaskMapData.fromJson(json.optJSONObject("results"))
                if (resData != null) {
                    val built = AgyHudDynamicModels.TaskMapConfig(
                        active = true,
                        mode = "results",
                        title = resData.query.ifBlank { resData.summaryTitle }.ifBlank { "Results" },
                        widthDp = 224f,
                        persistOnDone = true,
                        results = resData
                    )
                    if (built.contentSignature() != lastDismissedTaskMapSig) {
                        lastDismissedTaskMapSig = null
                    }
                    built
                } else {
                    current.taskMap
                }
            }
        } else {
            current.taskMap
        }

        val approvalGate = when {
            json.has("approval") -> if (json.isNull("approval")) AgyHudDynamicModels.ApprovalGateConfig(active = false)
            else AgyHudDynamicModels.ApprovalGateConfig.fromJson(json.opt("approval"))
            json.has("approvalGate") -> if (json.isNull("approvalGate")) AgyHudDynamicModels.ApprovalGateConfig(active = false)
            else AgyHudDynamicModels.ApprovalGateConfig.fromJson(json.opt("approvalGate"))
            else -> current.approvalGate
        }

        val spotlight = if (json.has("spotlight")) {
            if (json.isNull("spotlight")) AgyHudDynamicModels.SpotlightConfig(active = false)
            else AgyHudDynamicModels.SpotlightConfig.fromJson(json.opt("spotlight"))
        } else {
            current.spotlight
        }

        val smartSuggestions = if (json.has("smartSuggestions") || json.has("suggestions")) {
            val arr = json.optJSONArray("smartSuggestions") ?: json.optJSONArray("suggestions")
            if (arr == null) emptyList() else buildList {
                for (i in 0 until arr.length()) {
                    AgyHudDynamicModels.SmartSuggestionChip.fromJson(arr.opt(i), i)?.let { add(it) }
                }
            }
        } else {
            current.smartSuggestions
        }

        val demoSession = if (json.has("demo") || json.has("demoSession")) {
            val rawDemo = json.optJSONObject("demo") ?: json.optJSONObject("demoSession")
            if (rawDemo == null) demoRecorderManager.clearRecording()
            else demoRecorderManager.applyFromJson(rawDemo)
        } else {
            demoRecorderManager.currentSession()
        }

        val scratchpadItems = if (json.has("scratchpad")) {
            val rawPad = json.opt("scratchpad")
            when (rawPad) {
                is JSONObject -> {
                    scratchpadManager.applyFromJson(rawPad)
                    scratchpadManager.currentItems()
                }
                is JSONArray -> {
                    scratchpadManager.applyFromJson(JSONObject().put("items", rawPad))
                    scratchpadManager.currentItems()
                }
                else -> {
                    scratchpadManager.clearAll()
                    scratchpadManager.currentItems()
                }
            }
        } else {
            scratchpadManager.currentItems()
        }

        val watchdog = if (json.has("watchdog")) {
            val rawWd = json.optJSONObject("watchdog")
            if (rawWd == null) {
                screenWatchdogManager.clearWatchdog()
            } else {
                screenWatchdogManager.applyFromJson(rawWd, _attachedRegionContextFlow.value)
                screenWatchdogManager.currentWatchdog()
            }
        } else {
            screenWatchdogManager.currentWatchdog()
        }

        val voiceCoPilot = if (json.has("voice") || json.has("voiceCoPilot")) {
            val rawVoice = json.optJSONObject("voice") ?: json.optJSONObject("voiceCoPilot")
            if (rawVoice != null) {
                voiceCoPilotManager.applyFromJson(rawVoice)
            }
            voiceCoPilotManager.currentConfig()
        } else {
            voiceCoPilotManager.currentConfig()
        }

        return AgyHudState(
            state = state,
            title = title.ifBlank { "Agy HUD" },
            currentAction = currentAction,
            nextAction = nextAction,
            question = question,
            autoCollapseSeconds = autoCollapse,
            tasks = tasks,
            screenWatch = screenWatch,
            appPackage = appPackage,
            icon = icon,
            detailedOutput = detailedOutput,
            outputLogs = outputLogs,
            quickActions = quickActions,
            statusLabel = statusLabel,
            customEmoji = customEmoji,
            timerVisible = timerVisible,
            customTimerText = customTimerText,
            theme = theme,
            layout = layout,
            progress = progress,
            metrics = metrics,
            banner = banner,
            blocks = blocks,
            actionKind = actionKind,
            taskMap = taskMap,
            approvalGate = approvalGate,
            spotlight = spotlight,
            smartSuggestions = smartSuggestions,
            demoSession = demoSession,
            scratchpadItems = scratchpadItems,
            watchdog = watchdog,
            voiceCoPilot = voiceCoPilot
        )
    }

    @Volatile
    private var stopRecordedForCurrentRun: Boolean = false

    fun setPointerEnabled(enabled: Boolean): JSONObject =
        setPointerConfig(enabled = enabled, showLabel = null)

    fun setPointerConfig(enabled: Boolean? = null, showLabel: Boolean? = null): JSONObject {
        val nextEnabled = enabled ?: _pointerEnabledFlow.value
        val nextShowLabel = showLabel ?: _pointerShowLabelFlow.value
        _pointerEnabledFlow.value = nextEnabled
        _pointerShowLabelFlow.value = nextShowLabel
        pointerOverlayManager?.setPointerConfig(enabled = nextEnabled, showLabel = nextShowLabel)
        runOnMain { if (hudRootView != null) renderHudWindow() }
        return JSONObject().apply {
            put("success", true)
            put("pointerEnabled", nextEnabled)
            put("enabled", nextEnabled)
            put("showLabel", nextShowLabel)
        }
    }

    fun resolveEffectiveTaskMap(state: AgyHudState = _hudState.value): AgyHudDynamicModels.TaskMapConfig {
        if (state.taskMap.active) return state.taskMap
        val sw = state.screenWatch
        if (sw.active) {
            return AgyHudDynamicModels.TaskMapConfig(
                active = true,
                mode = "app_pane",
                title = sw.label.ifBlank { "App Pane" },
                appPane = AgyHudDynamicModels.AppPaneTaskMapData(
                    targetPackage = state.appPackage,
                    screenWidth = sw.screenWidth,
                    screenHeight = sw.screenHeight,
                    zones = sw.zones.map { z ->
                        AgyHudDynamicModels.TaskMapZone(
                            x1 = z.x1,
                            y1 = z.y1,
                            x2 = z.x2,
                            y2 = z.y2,
                            role = z.role,
                            tag = z.tag
                        )
                    },
                    actionVector = sw.actionVector?.let { v ->
                        AgyHudDynamicModels.TaskMapActionVector(
                            type = v.type,
                            x1 = v.x1,
                            y1 = v.y1,
                            x2 = v.x2,
                            y2 = v.y2
                        )
                    }
                )
            )
        }
        return state.taskMap.copy(active = false)
    }

    private fun syncTaskMapOverlay(state: AgyHudState) {
        val effective = resolveEffectiveTaskMap(state)
        val isTerminalState = state.state in setOf("IDLE", "DONE", "STOPPED")
        val shouldHideForTerminalState = isTerminalState && !effective.persistOnDone
        val isDismissed = lastDismissedTaskMapSig != null && lastDismissedTaskMapSig == effective.contentSignature()
        if (shouldHideForTerminalState || isDismissed || !effective.active || !wireframeEnabled) {
            taskMapOverlayManager?.hideMap(dismissLightbox = true)
        } else {
            taskMapOverlayManager?.updateTaskMap(
                config = effective,
                themeConfig = state.theme,
                enabled = wireframeEnabled
            )
        }
    }

    /**
     * Handles POST /api/hud/state. Updates in-memory state immediately and renders Window 2 / Window 1.
     */
    fun updateState(json: JSONObject): JSONObject {
        val ptrEn = if (json.has("pointerEnabled") && !json.isNull("pointerEnabled")) json.optBoolean("pointerEnabled", true) else null
        val ptrShowLbl = when {
            json.has("pointerShowLabel") && !json.isNull("pointerShowLabel") -> json.optBoolean("pointerShowLabel", true)
            json.has("showPointerLabel") && !json.isNull("showPointerLabel") -> json.optBoolean("showPointerLabel", true)
            else -> null
        }
        if (ptrEn != null || ptrShowLbl != null) {
            if (ptrEn != null) _pointerEnabledFlow.value = ptrEn
            if (ptrShowLbl != null) _pointerShowLabelFlow.value = ptrShowLbl
            pointerOverlayManager?.setPointerConfig(enabled = ptrEn, showLabel = ptrShowLbl)
        }
        val nextState = parseHudStateFromJson(json)
        val layoutJson = json.optJSONObject("layout")
        val explicitCollapsed = layoutJson?.takeIf { it.has("collapsed") && !it.isNull("collapsed") }?.optBoolean("collapsed")
            ?: json.takeIf { it.has("collapsed") && !it.isNull("collapsed") }?.optBoolean("collapsed")
        val explicitDetails = layoutJson?.takeIf { it.has("detailsExpanded") && !it.isNull("detailsExpanded") }?.optBoolean("detailsExpanded")
            ?: json.takeIf { it.has("detailsExpanded") && !it.isNull("detailsExpanded") }?.optBoolean("detailsExpanded")
        val explicitMacros = layoutJson?.takeIf { it.has("macrosDrawerOpen") && !it.isNull("macrosDrawerOpen") }?.optBoolean("macrosDrawerOpen")
            ?: json.takeIf { it.has("macrosDrawerOpen") && !it.isNull("macrosDrawerOpen") }?.optBoolean("macrosDrawerOpen")
        return applyHudStateInternal(
            nextState = nextState,
            explicitCollapsed = explicitCollapsed,
            explicitDetailsExpanded = explicitDetails,
            explicitMacrosDrawerOpen = explicitMacros
        ).put("pointerEnabled", _pointerEnabledFlow.value)
            .put("pointerShowLabel", _pointerShowLabelFlow.value)
    }

    /**
     * Handles POST /api/hud/patch (and WS HUD_PATCH): applies lightweight surgical updates
     * (single task upsert/remove, progress %, appendLog/appendLogs, metric upsert/remove,
     * banner update, block upsert/remove, theme/layout patch, clearWidgets, reset, plus
     * any top-level partial field updates) without wiping untouched HUD properties.
     */
    fun patchState(json: JSONObject): JSONObject {
        if (json.optBoolean("reset", false) || json.optString("op", "").equals("RESET", ignoreCase = true)) {
            return resetState()
        }
        val ptrEn = if (json.has("pointerEnabled") && !json.isNull("pointerEnabled")) json.optBoolean("pointerEnabled", true) else null
        val ptrShowLbl = when {
            json.has("pointerShowLabel") && !json.isNull("pointerShowLabel") -> json.optBoolean("pointerShowLabel", true)
            json.has("showPointerLabel") && !json.isNull("showPointerLabel") -> json.optBoolean("showPointerLabel", true)
            else -> null
        }
        if (ptrEn != null || ptrShowLbl != null) {
            if (ptrEn != null) _pointerEnabledFlow.value = ptrEn
            if (ptrShowLbl != null) _pointerShowLabelFlow.value = ptrShowLbl
            pointerOverlayManager?.setPointerConfig(enabled = ptrEn, showLabel = ptrShowLbl)
        }

        // First merge any top-level partial fields using parseHudStateFromJson
        var merged = parseHudStateFromJson(json)

        // Single task upsert / update by ID: upsertTask / updateTask
        val upsertTaskObj = json.optJSONObject("upsertTask") ?: json.optJSONObject("updateTask")
        if (upsertTaskObj != null) {
            val tid = upsertTaskObj.optString("id", "").trim().ifBlank { "t_${merged.tasks.size}" }
            val mutable = merged.tasks.toMutableList()
            val idx = mutable.indexOfFirst { it.id == tid }
            val existing = if (idx >= 0) mutable[idx] else null
            val updated = AgyHudTask(
                id = tid,
                label = if (upsertTaskObj.has("label")) upsertTaskObj.optString("label", "").trim() else existing?.label.orEmpty(),
                status = if (upsertTaskObj.has("status")) upsertTaskObj.optString("status", "pending").lowercase().trim() else existing?.status ?: "pending",
                icon = if (upsertTaskObj.has("icon")) upsertTaskObj.optString("icon", "").trim() else existing?.icon.orEmpty(),
                appPackage = if (upsertTaskObj.has("appPackage")) upsertTaskObj.optString("appPackage", "").trim() else existing?.appPackage.orEmpty(),
                detail = if (upsertTaskObj.has("detail")) upsertTaskObj.optString("detail", "").trim() else existing?.detail.orEmpty(),
                actionKind = if (upsertTaskObj.has("actionKind")) upsertTaskObj.optString("actionKind", "").trim() else existing?.actionKind.orEmpty()
            )
            if (idx >= 0) mutable[idx] = updated else mutable.add(updated)
            merged = merged.copy(tasks = mutable)
        }

        // Remove task by ID
        val removeTaskId = json.optString("removeTask", json.optString("removeTaskId", "")).trim()
        if (removeTaskId.isNotEmpty()) {
            merged = merged.copy(tasks = merged.tasks.filterNot { it.id == removeTaskId })
        }

        // Append one or many log lines
        val appendedLogs = mutableListOf<String>()
        if (json.has("appendLog")) {
            val single = json.optString("appendLog", "").trim()
            if (single.isNotEmpty()) appendedLogs.add(single)
        }
        val appendArr = json.optJSONArray("appendLogs")
        if (appendArr != null) {
            for (i in 0 until appendArr.length()) {
                val line = appendArr.optString(i, "").trim()
                if (line.isNotEmpty()) appendedLogs.add(line)
            }
        }
        if (appendedLogs.isNotEmpty()) {
            merged = merged.copy(outputLogs = (merged.outputLogs + appendedLogs).takeLast(120))
        }

        // Upsert / remove single metric pill
        val upsertMetricObj = json.optJSONObject("upsertMetric") ?: json.optJSONObject("setMetric")
        if (upsertMetricObj != null) {
            AgyHudDynamicModels.HudMetricItem.fromJson(upsertMetricObj, merged.metrics.size)?.let { m ->
                val mutable = merged.metrics.toMutableList()
                val idx = mutable.indexOfFirst { it.id == m.id }
                if (idx >= 0) mutable[idx] = m else mutable.add(m)
                merged = merged.copy(metrics = mutable)
            }
        }
        val removeMetricId = json.optString("removeMetric", "").trim()
        if (removeMetricId.isNotEmpty()) {
            merged = merged.copy(metrics = merged.metrics.filterNot { it.id == removeMetricId })
        }

        // Upsert / remove single content block
        val upsertBlockObj = json.optJSONObject("upsertBlock") ?: json.optJSONObject("setBlock")
        if (upsertBlockObj != null) {
            AgyHudDynamicModels.HudContentBlock.fromJson(upsertBlockObj, merged.blocks.size)?.let { b ->
                val mutable = merged.blocks.toMutableList()
                val idx = mutable.indexOfFirst { it.id == b.id }
                if (idx >= 0) mutable[idx] = b else mutable.add(b)
                merged = merged.copy(blocks = mutable)
            }
        }
        val removeBlockId = json.optString("removeBlock", "").trim()
        if (removeBlockId.isNotEmpty()) {
            merged = merged.copy(blocks = merged.blocks.filterNot { it.id == removeBlockId })
        }

        // Convenience setProgress / setBanner / setTheme / setLayout aliases
        if (json.has("setProgress")) {
            merged = merged.copy(
                progress = if (json.isNull("setProgress")) AgyHudDynamicModels.HudProgressConfig(visible = false)
                else AgyHudDynamicModels.HudProgressConfig.fromJson(json.opt("setProgress"), merged.progress)
            )
        }
        if (json.has("setBanner")) {
            merged = merged.copy(
                banner = if (json.isNull("setBanner")) AgyHudDynamicModels.HudBannerConfig(visible = false)
                else AgyHudDynamicModels.HudBannerConfig.fromJson(json.opt("setBanner"))
            )
        }
        if (json.has("setTheme")) {
            merged = merged.copy(
                theme = if (json.isNull("setTheme")) AgyHudDynamicModels.HudThemeConfig()
                else AgyHudDynamicModels.HudThemeConfig.fromJson(json.optJSONObject("setTheme"), merged.theme)
            )
        }
        val setLayoutObj = json.optJSONObject("setLayout") ?: json.optJSONObject("layout")
        if (json.has("setLayout")) {
            merged = merged.copy(
                layout = if (json.isNull("setLayout")) AgyHudDynamicModels.HudLayoutConfig()
                else AgyHudDynamicModels.HudLayoutConfig.fromJson(json.optJSONObject("setLayout"), merged.layout)
            )
        }

        // Convenience setResults / upsertResultItem / clearResults aliases
        if (json.has("setResults")) {
            if (json.isNull("setResults")) {
                lastDismissedTaskMapSig = null
                taskMapOverlayManager?.clearDismissedState()
                merged = merged.copy(taskMap = AgyHudDynamicModels.TaskMapConfig(active = false))
            } else {
                val resData = AgyHudDynamicModels.ResultsTaskMapData.fromJson(json.optJSONObject("setResults"))
                if (resData != null) {
                    val tm = AgyHudDynamicModels.TaskMapConfig(
                        active = true,
                        mode = "results",
                        title = resData.query.ifBlank { resData.summaryTitle }.ifBlank { "Results" },
                        widthDp = 224f,
                        persistOnDone = true,
                        results = resData
                    )
                    if (tm.contentSignature() != lastDismissedTaskMapSig) {
                        lastDismissedTaskMapSig = null
                        taskMapOverlayManager?.clearDismissedState()
                    }
                    merged = merged.copy(taskMap = tm)
                }
            }
        }
        val upsertResultObj = json.optJSONObject("upsertResultItem")
        if (upsertResultObj != null) {
            val baseResults = merged.taskMap.results ?: AgyHudDynamicModels.ResultsTaskMapData(
                query = merged.title,
                summaryTitle = merged.title
            )
            val newItem = AgyHudDynamicModels.ResultMediaItem.fromJson(upsertResultObj, baseResults.items.size)
            if (newItem != null) {
                val mutable = baseResults.items.toMutableList()
                val idx = mutable.indexOfFirst { it.id == newItem.id }
                if (idx >= 0) mutable[idx] = newItem else mutable.add(newItem)
                val updatedResults = baseResults.copy(loading = false, items = mutable)
                val tm = merged.taskMap.copy(
                    active = true,
                    mode = "results",
                    widthDp = merged.taskMap.widthDp.coerceAtLeast(224f),
                    persistOnDone = true,
                    results = updatedResults
                )
                lastDismissedTaskMapSig = null
                taskMapOverlayManager?.clearDismissedState()
                merged = merged.copy(taskMap = tm)
            }
        }
        if (json.optBoolean("clearResults", false)) {
            lastDismissedTaskMapSig = null
            taskMapOverlayManager?.clearDismissedState()
            if (merged.taskMap.mode == "results") {
                merged = merged.copy(taskMap = AgyHudDynamicModels.TaskMapConfig(active = false))
            }
        }

        // Convenience setPlayer / playerCommand / clearPlayer aliases
        if (json.has("setPlayer") || json.has("playerCommand")) {
            val rawKey = if (json.has("setPlayer")) "setPlayer" else "playerCommand"
            if (json.isNull(rawKey)) {
                lastDismissedTaskMapSig = null
                taskMapOverlayManager?.clearDismissedState()
                merged = merged.copy(taskMap = AgyHudDynamicModels.TaskMapConfig(active = false))
            } else {
                val basePlayer = currentPlayerBaseline() ?: merged.taskMap.player
                val playerData = AgyHudDynamicModels.PlayerTaskMapData.fromJson(json.optJSONObject(rawKey), basePlayer)
                if (playerData != null) {
                    val tm = AgyHudDynamicModels.TaskMapConfig(
                        active = true,
                        mode = "player",
                        title = playerData.currentTrack()?.title.orEmpty().ifBlank { "Agy Player" },
                        widthDp = merged.taskMap.widthDp.coerceAtLeast(228f),
                        persistOnDone = true,
                        player = playerData
                    )
                    lastDismissedTaskMapSig = null
                    taskMapOverlayManager?.clearDismissedState()
                    merged = merged.copy(taskMap = tm)
                }
            }
        }
        if (json.optBoolean("clearPlayer", false)) {
            lastDismissedTaskMapSig = null
            taskMapOverlayManager?.clearDismissedState()
            if (merged.taskMap.mode == "player") {
                merged = merged.copy(taskMap = AgyHudDynamicModels.TaskMapConfig(active = false))
            }
        }

        // Approval Gate / Spotlight / Suggestions convenience patch aliases
        if (json.has("setApproval")) {
            merged = merged.copy(
                approvalGate = if (json.isNull("setApproval")) AgyHudDynamicModels.ApprovalGateConfig(active = false)
                else AgyHudDynamicModels.ApprovalGateConfig.fromJson(json.opt("setApproval"))
            )
        }
        if (json.optBoolean("clearApproval", false)) {
            merged = merged.copy(approvalGate = AgyHudDynamicModels.ApprovalGateConfig(active = false))
        }
        if (json.has("setSpotlight")) {
            merged = merged.copy(
                spotlight = if (json.isNull("setSpotlight")) AgyHudDynamicModels.SpotlightConfig(active = false)
                else AgyHudDynamicModels.SpotlightConfig.fromJson(json.opt("setSpotlight"))
            )
        }
        if (json.optBoolean("clearSpotlight", false)) {
            merged = merged.copy(spotlight = AgyHudDynamicModels.SpotlightConfig(active = false))
        }
        if (json.has("setSuggestions")) {
            val arr = json.optJSONArray("setSuggestions")
            val parsedSug = if (arr == null) emptyList() else buildList {
                for (i in 0 until arr.length()) {
                    AgyHudDynamicModels.SmartSuggestionChip.fromJson(arr.opt(i), i)?.let { add(it) }
                }
            }
            merged = merged.copy(smartSuggestions = parsedSug)
        }
        if (json.has("setDemo")) {
            val rawDemo = json.optJSONObject("setDemo")
            val nextDemo = if (rawDemo == null) demoRecorderManager.clearRecording() else demoRecorderManager.applyFromJson(rawDemo)
            merged = merged.copy(demoSession = nextDemo)
        }
        if (json.optBoolean("clearDemo", false)) {
            merged = merged.copy(demoSession = demoRecorderManager.clearRecording())
        }
        if (json.has("setScratchpad")) {
            val rawPad = json.opt("setScratchpad")
            when (rawPad) {
                is JSONObject -> scratchpadManager.applyFromJson(rawPad)
                is JSONArray -> scratchpadManager.applyFromJson(JSONObject().put("items", rawPad))
                else -> scratchpadManager.clearAll()
            }
            merged = merged.copy(scratchpadItems = scratchpadManager.currentItems())
        }
        if (json.optBoolean("clearScratchpad", false)) {
            scratchpadManager.clearAll()
            merged = merged.copy(scratchpadItems = emptyList())
        }
        if (json.has("setWatchdog")) {
            val rawWd = json.optJSONObject("setWatchdog")
            if (rawWd == null) {
                screenWatchdogManager.clearWatchdog()
            } else {
                screenWatchdogManager.applyFromJson(rawWd, _attachedRegionContextFlow.value)
            }
            merged = merged.copy(watchdog = screenWatchdogManager.currentWatchdog())
        }
        if (json.optBoolean("clearWatchdog", false)) {
            merged = merged.copy(watchdog = screenWatchdogManager.clearWatchdog())
        }
        if (json.has("setVoice")) {
            val rawV = json.optJSONObject("setVoice")
            if (rawV != null) {
                voiceCoPilotManager.applyFromJson(rawV)
            } else {
                voiceCoPilotManager.configure(AgyHudDynamicModels.VoiceCoPilotConfig(enabled = false))
            }
            merged = merged.copy(voiceCoPilot = voiceCoPilotManager.currentConfig())
        }

        // Clear all dynamic widgets (progress, metrics, banner, blocks)
        if (json.optBoolean("clearWidgets", false)) {
            merged = merged.copy(
                progress = AgyHudDynamicModels.HudProgressConfig(visible = false),
                metrics = emptyList(),
                banner = AgyHudDynamicModels.HudBannerConfig(visible = false),
                blocks = emptyList()
            )
        }

        val explicitCollapsed = setLayoutObj?.takeIf { it.has("collapsed") && !it.isNull("collapsed") }?.optBoolean("collapsed")
            ?: json.takeIf { it.has("collapsed") && !it.isNull("collapsed") }?.optBoolean("collapsed")
        val explicitDetails = setLayoutObj?.takeIf { it.has("detailsExpanded") && !it.isNull("detailsExpanded") }?.optBoolean("detailsExpanded")
            ?: json.takeIf { it.has("detailsExpanded") && !it.isNull("detailsExpanded") }?.optBoolean("detailsExpanded")
        val explicitMacros = setLayoutObj?.takeIf { it.has("macrosDrawerOpen") && !it.isNull("macrosDrawerOpen") }?.optBoolean("macrosDrawerOpen")
            ?: json.takeIf { it.has("macrosDrawerOpen") && !it.isNull("macrosDrawerOpen") }?.optBoolean("macrosDrawerOpen")

        return applyHudStateInternal(
            nextState = merged,
            explicitCollapsed = explicitCollapsed,
            explicitDetailsExpanded = explicitDetails,
            explicitMacrosDrawerOpen = explicitMacros
        ).put("patched", true).put("pointerEnabled", _pointerEnabledFlow.value)
    }

    /**
     * Resets the HUD back to its clean default IDLE state, clearing all dynamic themes,
     * widgets, progress, metrics, banners, blocks, and tasks.
     */
    fun resetState(): JSONObject {
        isDetailsExpanded = false
        isMacrosDrawerOpen = false
        isOutputExpanded = false
        stopRecordedForCurrentRun = false
        lastDismissedTaskMapSig = null
        pendingEditApprovalId = null
        cancelApprovalCountdown()
        cancelAutoDequeue()
        _queuedPromptsFlow.value = emptyList()
        _attachedRegionContextFlow.value = null
        _isEdgeParkedFlow.value = false
        isScratchpadDrawerOpen = false
        lastMacroSavedPrompt = ""
        demoRecorderManager.clearRecording()
        scratchpadManager.clearAll()
        screenWatchdogManager.clearWatchdog()
        voiceCoPilotManager.configure(AgyHudDynamicModels.VoiceCoPilotConfig(enabled = false))
        taskMapOverlayManager?.clearDismissedState()
        taskMapOverlayManager?.hideMap(dismissLightbox = true)
        regionSnipOverlayManager?.hide()
        edgeHandleOverlayManager?.hide()
        spotlightOverlayManager?.hideSpotlight()
        return applyHudStateInternal(
            nextState = AgyHudState(),
            explicitCollapsed = false,
            explicitDetailsExpanded = false,
            explicitMacrosDrawerOpen = false
        ).put("reset", true)
    }

    private fun applyHudStateInternal(
        nextState: AgyHudState,
        explicitCollapsed: Boolean? = null,
        explicitDetailsExpanded: Boolean? = null,
        explicitMacrosDrawerOpen: Boolean? = null
    ): JSONObject {
        val prevSnapshot = _hudState.value
        val prevState = prevSnapshot.state
        val startingNewWorkingTask = nextState.state == "WORKING" &&
            prevState in setOf("IDLE", "DONE", "STOPPED")

        // Confirmed User Decision 3: When a new Agy task starts while the left-window player is active,
        // auto-collapse the player to the background mini-pill and keep playback running uninterrupted.
        val resolvedNextState = if (startingNewWorkingTask &&
            nextState.taskMap.active &&
            nextState.taskMap.mode == "player" &&
            nextState.taskMap.player != null
        ) {
            val bgPlayer = nextState.taskMap.player.copy(backgroundMode = true)
            nextState.copy(
                taskMap = nextState.taskMap.copy(
                    active = true,
                    persistOnDone = true,
                    player = bgPlayer
                )
            )
        } else {
            nextState
        }

        _hudState.value = resolvedNextState
        if (startingNewWorkingTask &&
            resolvedNextState.taskMap.active &&
            resolvedNextState.taskMap.mode == "player"
        ) {
            taskMapOverlayManager?.collapseToBackgroundMiniPill()
        }

        if (explicitDetailsExpanded != null) {
            isDetailsExpanded = explicitDetailsExpanded
        }
        if (explicitMacrosDrawerOpen != null) {
            isMacrosDrawerOpen = explicitMacrosDrawerOpen
        }

        val now = System.currentTimeMillis()
        // Manage accumulated live elapsed timer across WORKING / PAUSED / NEEDS_INPUT / STOPPING / STOPPED / DONE
        when (nextState.state) {
            "WORKING" -> {
                if (prevState == "IDLE" || prevState == "DONE" || prevState == "STOPPED") {
                    accumulatedElapsedMs = 0L
                    _elapsedMsFlow.value = 0L
                    stopRecordedForCurrentRun = false
                }
                if (prevState != "WORKING" || activeSegmentStartMs == 0L) {
                    activeSegmentStartMs = now
                }
                startElapsedTimer()
            }
            "PAUSED", "NEEDS_INPUT", "STOPPING" -> {
                if (activeSegmentStartMs > 0L) {
                    accumulatedElapsedMs += (now - activeSegmentStartMs).coerceAtLeast(0L)
                    activeSegmentStartMs = 0L
                }
                _elapsedMsFlow.value = accumulatedElapsedMs
                stopElapsedTimer()
            }
            "STOPPED" -> {
                if (activeSegmentStartMs > 0L) {
                    accumulatedElapsedMs += (now - activeSegmentStartMs).coerceAtLeast(0L)
                    activeSegmentStartMs = 0L
                }
                _elapsedMsFlow.value = accumulatedElapsedMs
                stopElapsedTimer()
                if (prevState != "STOPPED" && !stopRecordedForCurrentRun) {
                    stopRecordedForCurrentRun = true
                    emitRunRecord(nextState, finalState = "STOPPED", durationMs = accumulatedElapsedMs)
                }
            }
            "DONE" -> {
                if (activeSegmentStartMs > 0L) {
                    accumulatedElapsedMs += (now - activeSegmentStartMs).coerceAtLeast(0L)
                    activeSegmentStartMs = 0L
                }
                _elapsedMsFlow.value = accumulatedElapsedMs
                stopElapsedTimer()
                if (prevState != "DONE") {
                    emitRunRecord(nextState, finalState = "DONE", durationMs = accumulatedElapsedMs)
                }
            }
            else -> {
                accumulatedElapsedMs = 0L
                activeSegmentStartMs = 0L
                _elapsedMsFlow.value = 0L
                stopRecordedForCurrentRun = false
                stopElapsedTimer()
            }
        }

        val hasPerm = hasOverlayPermission()
        val justCompleted = nextState.state == "DONE" && prevState != "DONE"

        if (explicitCollapsed != null) {
            isCollapsed = explicitCollapsed
            autoCollapsedByCoordinator = false
            userManuallyCollapsed = explicitCollapsed
            _isInputVisible.value = !explicitCollapsed && nextState.layout.showComposer
        } else {
            when (nextState.state) {
                "WORKING" -> {
                    if (prevState != "WORKING" && prevState != "PAUSED") {
                        isCollapsed = false
                        autoCollapsedByCoordinator = false
                        userManuallyCollapsed = false
                        _isInputVisible.value = nextState.layout.showComposer
                    }
                }
                "PAUSED", "STOPPING" -> {
                    // Preserve current collapsed/expanded posture when pausing or stopping
                }
                "NEEDS_INPUT" -> {
                    isCollapsed = false
                    autoCollapsedByCoordinator = false
                    userManuallyCollapsed = false
                    _isInputVisible.value = nextState.layout.showComposer
                }
                "DONE", "IDLE", "STOPPED" -> {
                    if (nextState.autoCollapseSeconds <= 0 && !isOutputExpanded && !isInputFocused) {
                        isCollapsed = true
                        autoCollapsedByCoordinator = false
                        _isInputVisible.value = false
                    }
                }
            }
        }

        if (hasPerm) {
            runOnMain {
                ensureHudWindowAttached()
                when (nextState.state) {
                    "WORKING" -> {
                        cancelAutoCollapse()
                        if (explicitCollapsed == null && prevState != "WORKING" && prevState != "PAUSED") {
                            isCollapsed = false
                            _isInputVisible.value = nextState.layout.showComposer
                        }
                    }
                    "PAUSED", "STOPPING" -> {
                        cancelAutoCollapse()
                    }
                    "NEEDS_INPUT" -> {
                        cancelAutoCollapse()
                        if (explicitCollapsed == null) {
                            isCollapsed = false
                            _isInputVisible.value = nextState.layout.showComposer
                            if (nextState.layout.showComposer) {
                                focusInlineComposerInternal(requestKeyboardFocus = true)
                            }
                        }
                    }
                    "STOPPED" -> {
                        cancelAutoCollapse()
                        blurInlineComposerInternal()
                        if (explicitCollapsed == null && nextState.autoCollapseSeconds > 0 && !isOutputExpanded) {
                            scheduleAutoCollapse(nextState.autoCollapseSeconds)
                        }
                    }
                    "DONE", "IDLE" -> {
                        if (justCompleted) {
                            hudExpandedContainer?.playCompletionPulse()
                        }
                        if (explicitCollapsed != null) {
                            cancelAutoCollapse()
                            if (explicitCollapsed) blurInlineComposerInternal()
                        } else if (isOutputExpanded || isInputFocused) {
                            cancelAutoCollapse()
                        } else if (nextState.autoCollapseSeconds > 0) {
                            scheduleAutoCollapse(nextState.autoCollapseSeconds)
                        } else {
                            isCollapsed = true
                            blurInlineComposerInternal()
                        }
                    }
                }
                applyDynamicWindowGeometryInternal(nextState)
                renderHudWindow()
                syncPulseAnimation()
            }
        } else if ((nextState.state == "DONE" || nextState.state == "IDLE") && nextState.autoCollapseSeconds > 0 && !isOutputExpanded) {
            runOnMain { scheduleAutoCollapse(nextState.autoCollapseSeconds) }
        }

        syncTaskMapOverlay(resolvedNextState)
        syncApprovalCountdown(resolvedNextState.approvalGate)
        syncSpotlightOverlay(resolvedNextState.spotlight)
        edgeHandleOverlayManager?.updateAgentActive(
            nextState.state in setOf("WORKING", "PAUSED", "NEEDS_INPUT", "STOPPING")
        )
        if (nextState.approvalGate.active) {
            if (_isEdgeParkedFlow.value) {
                summonFromEdge(focusComposer = false)
            }
            cancelAutoCollapse()
            isCollapsed = false
            runOnMain { if (hudRootView != null) renderHudWindow() }
        }
        if (justCompleted && _queuedPromptsFlow.value.isNotEmpty() && !nextState.approvalGate.active) {
            scheduleAutoDequeueNextPrompt()
        } else if (nextState.state == "STOPPED" || nextState.state == "STOPPING") {
            cancelAutoDequeue()
        }

        // Notify Voice Co-Pilot so it can auto-speak DONE summaries or NEEDS_INPUT questions + hands-free listen
        voiceCoPilotManager.onHudStateUpdated(
            state = nextState.state,
            title = nextState.title,
            currentAction = nextState.currentAction,
            questionText = nextState.question,
            detailedOutput = nextState.detailedOutput
        )

        return JSONObject().apply {
            put("success", true)
            put("overlayRendered", hasPerm)
            if (!hasPerm) {
                put("permissionRequired", true)
                put("warning", "SYSTEM_ALERT_WINDOW not granted; HUD state stored in memory only.")
            }
            put("state", nextState.state)
            put("hudVisible", _isHudVisible.value)
            put("inputVisible", _isInputVisible.value)
            put("collapsed", isCollapsed)
            put("detailsExpanded", isDetailsExpanded)
            put("outputExpanded", isOutputExpanded)
            put("taskCount", nextState.tasks.size)
            put("metricCount", nextState.metrics.size)
            put("blockCount", nextState.blocks.size)
            put("screenWatchActive", nextState.screenWatch.active)
            put("taskMapActive", resolveEffectiveTaskMap(nextState).active)
            put("approvalActive", nextState.approvalGate.active)
            put("spotlightActive", nextState.spotlight.active)
            put("queuedPromptCount", _queuedPromptsFlow.value.size)
            put("edgeParked", _isEdgeParkedFlow.value)
            put("demoActive", nextState.demoSession.active)
            put("demoStepCount", nextState.demoSession.steps.size)
            put("scratchpadCount", nextState.scratchpadItems.size)
            put("watchdogActive", nextState.watchdog.active)
            put("voiceCoPilotEnabled", nextState.voiceCoPilot.enabled)
        }
    }

    /**
     * Shows the compact HUD pill (or expands it) directly from the in-app Settings toggle.
     */
    fun showCompactPill(): Boolean {
        if (!hasOverlayPermission()) return false
        runOnMain {
            isCollapsed = true
            ensureHudWindowAttached()
            renderHudWindow()
        }
        return true
    }

    /**
     * Handles POST /api/hud/command:
     * - action = PROMPT / STOP / FORCE_STOP / PAUSE / RESUME / CUSTOM: enqueues command + broadcasts HUD_COMMAND via WebSocket
     * - action = OPEN_INPUT / CLOSE_INPUT / EXPAND / COLLAPSE / TOGGLE_GHOST / CYCLE_OPACITY / PATCH / RESET
     */
    fun handleRemoteCommand(json: JSONObject): JSONObject {
        val action = json.optString("action", "PROMPT").uppercase().trim()
        val text = json.optString("text", json.optString("prompt", "")).trim()
        val buttonId = json.optString("buttonId", json.optString("id", "")).trim()
        val payload = json.optJSONObject("payload")
        val result = JSONObject()

        when (action) {
            "OPEN_INPUT" -> {
                val autoFocus = json.optBoolean("focus", true)
                cancelAutoCollapse()
                isCollapsed = false
                autoCollapsedByCoordinator = false
                userManuallyCollapsed = false
                _isInputVisible.value = true
                if (!hasOverlayPermission()) {
                    return result.put("success", true).put("action", action)
                        .put("collapsed", false)
                        .put("inputVisible", true).put("sandboxOnly", true)
                }
                runOnMain {
                    ensureHudWindowAttached()
                    renderHudWindow()
                    layoutCoordinator.notifyInteraction(
                        id = AgyOverlayLayoutCoordinator.ManagedWindowId.HUD,
                        priority = AgyOverlayLayoutCoordinator.InteractionPriority.USER_INTERACTED,
                        animate = true
                    )
                    focusInlineComposerInternal(requestKeyboardFocus = autoFocus)
                }
                result.put("success", true).put("action", action)
                    .put("collapsed", false).put("inputVisible", true)
            }
            "CLOSE_INPUT" -> {
                runOnMain { blurInlineComposerInternal() }
                _isInputVisible.value = false
                result.put("success", true).put("action", action).put("inputVisible", false)
            }
            "EXPAND" -> {
                cancelAutoCollapse()
                isCollapsed = false
                autoCollapsedByCoordinator = false
                userManuallyCollapsed = false
                _isInputVisible.value = true
                if (hasOverlayPermission()) {
                    runOnMain {
                        ensureHudWindowAttached()
                        renderHudWindow()
                        layoutCoordinator.notifyInteraction(
                            id = AgyOverlayLayoutCoordinator.ManagedWindowId.HUD,
                            priority = AgyOverlayLayoutCoordinator.InteractionPriority.USER_INTERACTED,
                            animate = true
                        )
                    }
                }
                result.put("success", true).put("action", action)
                    .put("collapsed", false).put("inputVisible", true)
            }
            "COLLAPSE" -> {
                isCollapsed = true
                autoCollapsedByCoordinator = false
                userManuallyCollapsed = true
                _isInputVisible.value = false
                runOnMain {
                    blurInlineComposerInternal()
                    if (hudRootView != null) {
                        renderHudWindow()
                        layoutCoordinator.reconcile(animate = true)
                    }
                }
                result.put("success", true).put("action", action)
                    .put("collapsed", true).put("inputVisible", false)
            }
            "PATCH" -> {
                return patchState(json)
            }
            "RESET" -> {
                return resetState()
            }
            "TOGGLE_GHOST" -> {
                val enabled = if (json.has("enabled")) json.optBoolean("enabled") else !ghostPassThrough
                runOnMain { setGhostModeInternal(enabled) }
                result.put("success", true).put("action", action).put("ghostPassThrough", enabled)
            }
            "TOGGLE_WIREFRAME", "TOGGLE_TASK_MAP" -> {
                val enabled = if (json.has("enabled")) json.optBoolean("enabled") else !wireframeEnabled
                wireframeEnabled = enabled
                syncTaskMapOverlay(_hudState.value)
                runOnMain { if (hudRootView != null) renderHudWindow() }
                result.put("success", true).put("action", action).put("wireframeEnabled", enabled)
            }
            "TOGGLE_EDGE_SNAP" -> {
                val enabled = if (json.has("enabled")) json.optBoolean("enabled") else !edgeSnapEnabled
                edgeSnapEnabled = enabled
                runOnMain {
                    if (hudRootView != null) {
                        if (enabled) snapHudToNearestEdge()
                        renderHudWindow()
                    }
                }
                result.put("success", true).put("action", action).put("edgeSnapEnabled", enabled)
            }
            "TOGGLE_POINTER", "SET_POINTER" -> {
                val enabled = if (json.has("enabled")) json.optBoolean("enabled") else !_pointerEnabledFlow.value
                val showLabel = if (json.has("showLabel") && !json.isNull("showLabel")) {
                    json.optBoolean("showLabel", true)
                } else null
                val ptrRes = setPointerConfig(enabled = enabled, showLabel = showLabel)
                result.put("success", true)
                    .put("action", action)
                    .put("pointerEnabled", ptrRes.optBoolean("pointerEnabled", enabled))
                    .put("showLabel", ptrRes.optBoolean("showLabel", _pointerShowLabelFlow.value))
            }
            "TOGGLE_OUTPUT" -> {
                val expanded = if (json.has("expanded")) json.optBoolean("expanded") else !isOutputExpanded
                setOutputExpanded(expanded)
                result.put("success", true).put("action", action).put("outputExpanded", expanded)
            }
            "TOGGLE_DETAILS" -> {
                val expanded = if (json.has("expanded")) json.optBoolean("expanded") else !isDetailsExpanded
                isDetailsExpanded = expanded
                runOnMain { if (hudRootView != null) renderHudWindow() }
                result.put("success", true).put("action", action).put("detailsExpanded", expanded)
            }
            "COPY_OUTPUT" -> {
                val copied = copyDetailedOutputToClipboard()
                result.put("success", copied).put("action", action)
            }
            "CYCLE_OPACITY" -> {
                runOnMain { cycleOpacityInternal() }
                result.put("success", true).put("action", action)
                    .put("opacity", OPACITY_LEVELS[opacityIndex].toDouble())
            }
            "PAUSE" -> {
                val cmd = enqueueAndBroadcastCommand(text = text.ifBlank { "PAUSE" }, action = "PAUSE")
                if (_hudState.value.state == "WORKING") {
                    updateState(JSONObject().put("state", "PAUSED"))
                }
                result.put("success", true).put("command", cmd.toJson()).put("state", _hudState.value.state)
            }
            "RESUME" -> {
                val cmd = enqueueAndBroadcastCommand(text = text.ifBlank { "RESUME" }, action = "RESUME")
                if (_hudState.value.state == "PAUSED") {
                    updateState(JSONObject().put("state", "WORKING"))
                }
                result.put("success", true).put("command", cmd.toJson()).put("state", _hudState.value.state)
            }
            "STOP" -> {
                val current = _hudState.value
                when (current.state) {
                    "STOPPING" -> {
                        // Stage 2: Second tap while already STOPPING -> immediate local Force-Stop
                        val cmd = enqueueAndBroadcastCommand(
                            text = text.ifBlank { "FORCE_STOP" },
                            action = "FORCE_STOP"
                        )
                        val stoppedTasks = current.tasks.map { task ->
                            if (task.status == "doing" || task.status == "needs_input") {
                                task.copy(status = "stopped")
                            } else task
                        }
                        applyHudStateInternal(
                            current.copy(
                                state = "STOPPED",
                                statusLabel = "",
                                currentAction = "Stopped by user",
                                tasks = stoppedTasks
                            )
                        )
                        result.put("success", true)
                            .put("command", cmd.toJson())
                            .put("state", _hudState.value.state)
                            .put("stage", "FORCE_STOPPED")
                    }
                    "WORKING", "PAUSED", "NEEDS_INPUT" -> {
                        // Stage 1: Graceful stop request -> show Stopping… immediately, tap again to force-stop
                        val cmd = enqueueAndBroadcastCommand(
                            text = text.ifBlank { "STOP" },
                            action = "STOP"
                        )
                        applyHudStateInternal(
                            current.copy(
                                state = "STOPPING",
                                currentAction = "Stopping… tap Stop again to force-stop"
                            )
                        )
                        result.put("success", true)
                            .put("command", cmd.toJson())
                            .put("state", _hudState.value.state)
                            .put("stage", "STOPPING")
                    }
                    else -> {
                        val cmd = enqueueAndBroadcastCommand(text = text.ifBlank { "STOP" }, action = "STOP")
                        result.put("success", true)
                            .put("command", cmd.toJson())
                            .put("state", _hudState.value.state)
                            .put("stage", "IDLE")
                    }
                }
            }
            "FORCE_STOP" -> {
                val current = _hudState.value
                val cmd = enqueueAndBroadcastCommand(
                    text = text.ifBlank { "FORCE_STOP" },
                    action = "FORCE_STOP"
                )
                val stoppedTasks = current.tasks.map { task ->
                    if (task.status == "doing" || task.status == "needs_input") {
                        task.copy(status = "stopped")
                    } else task
                }
                applyHudStateInternal(
                    current.copy(
                        state = "STOPPED",
                        statusLabel = "",
                        currentAction = "Stopped by user",
                        tasks = stoppedTasks
                    )
                )
                result.put("success", true)
                    .put("command", cmd.toJson())
                    .put("state", _hudState.value.state)
                    .put("stage", "FORCE_STOPPED")
            }
            "CUSTOM", "CUSTOM_ACTION" -> {
                val cmd = enqueueAndBroadcastCommand(
                    text = text.ifBlank { buttonId.ifBlank { "CUSTOM" } },
                    action = "CUSTOM",
                    buttonId = buttonId,
                    payload = payload
                )
                result.put("success", true).put("command", cmd.toJson())
            }
            "APPROVAL_RESPONSE" -> {
                val decision = json.optString(
                    "decision",
                    payload?.optString("decision", text.ifBlank { "deny" }) ?: text.ifBlank { "deny" }
                ).lowercase().trim()
                val edited = json.optString(
                    "editedText",
                    payload?.optString("editedText", "") ?: ""
                ).trim()
                val apprId = json.optString(
                    "approvalId",
                    payload?.optString("approvalId", _hudState.value.approvalGate.id) ?: _hudState.value.approvalGate.id
                ).trim()
                return respondToApproval(decision = decision, editedText = edited, approvalId = apprId)
            }
            "PARK_EDGE" -> {
                val sideRaw = json.optString("side", "right").lowercase().trim()
                val side = if (sideRaw == "left") AgyEdgeHandleOverlayManager.EdgeSide.LEFT else AgyEdgeHandleOverlayManager.EdgeSide.RIGHT
                return parkToEdge(side)
            }
            "SUMMON_EDGE" -> {
                val focus = json.optBoolean("focus", false)
                val voice = json.optBoolean("voice", false)
                val snip = json.optBoolean("snip", false)
                return summonFromEdge(focusComposer = focus, startVoice = voice, startSnip = snip)
            }
            "START_SNIP" -> {
                val started = startRegionSnip()
                result.put("success", true).put("action", action).put("started", started)
            }
            "RUN_NEXT_QUEUED" -> {
                val dispatched = dispatchNextQueuedPrompt()
                result.put("success", dispatched != null)
                    .put("action", action)
                    .put("remaining", _queuedPromptsFlow.value.size)
                if (dispatched != null) result.put("command", dispatched.toJson())
            }
            "CLEAR_QUEUE" -> {
                cancelAutoDequeue()
                _queuedPromptsFlow.value = emptyList()
                runOnMain { if (hudRootView != null) renderHudWindow() }
                result.put("success", true).put("action", action).put("remaining", 0)
            }
            "SAVE_MACRO" -> {
                val saved = saveLastPromptAsMacro(
                    customTitle = json.optString("title", "").trim(),
                    customPrompt = text
                )
                result.put("success", saved).put("action", action)
            }
            "CLEAR_SPOTLIGHT" -> {
                return clearSpotlight()
            }
            "PLAYER", "PLAY_MEDIA", "PLAYER_CONTROL" -> {
                return setPlayer(payload ?: json)
            }
            "CLEAR_PLAYER", "STOP_PLAYER" -> {
                return clearPlayer()
            }
            "DEMO", "DEMO_RECORD", "HUD_DEMO" -> {
                return handleDemoAction(payload ?: json)
            }
            "DEMO_SEND", "FINISH_DEMO" -> {
                return finishAndSendDemoToAgy(text)
            }
            "SCRATCHPAD", "HUD_SCRATCHPAD" -> {
                return handleScratchpadAction(payload ?: json)
            }
            "WATCHDOG", "HUD_WATCHDOG" -> {
                return setWatchdog(payload ?: json)
            }
            "CLEAR_WATCHDOG" -> {
                return clearWatchdog()
            }
            "VOICE", "VOICE_COPILOT", "HUD_VOICE" -> {
                return setVoiceCoPilot(payload ?: json)
            }
            else -> {
                if (text.isEmpty()) {
                    return result.put("success", false).put("error", "Missing 'text' for PROMPT command")
                }
                val regionFromPayload = AgyHudDynamicModels.SnippedRegionContext.fromJson(
                    payload?.optJSONObject("regionContext") ?: json.optJSONObject("regionContext")
                )
                val queueIfBusy = json.optBoolean("queueIfBusy", false)
                if (queueIfBusy) {
                    return submitOrQueuePrompt(text = text, regionOverride = regionFromPayload, forceSendNow = false)
                }
                val cmd = enqueueAndBroadcastCommand(
                    text = text,
                    action = "PROMPT",
                    buttonId = buttonId,
                    payload = payload
                )
                result.put("success", true).put("command", cmd.toJson())
            }
        }
        return result
    }

    /**
     * Enqueues a HUD_COMMAND into the thread-safe queue for GET /api/hud/poll and immediately
     * pushes it to connected WebSocket clients.
     */
    fun enqueueAndBroadcastCommand(
        text: String,
        action: String = "PROMPT",
        buttonId: String = "",
        payload: JSONObject? = null
    ): HudCommand {
        val normalizedAction = when (action.uppercase().trim()) {
            "STOP" -> "STOP"
            "FORCE_STOP" -> "FORCE_STOP"
            "PAUSE" -> "PAUSE"
            "RESUME" -> "RESUME"
            "CUSTOM", "CUSTOM_ACTION" -> "CUSTOM"
            "APPROVAL_RESPONSE" -> "APPROVAL_RESPONSE"
            "DEMO_RECORDED" -> "DEMO_RECORDED"
            "WATCHDOG_TRIGGERED" -> "WATCHDOG_TRIGGERED"
            else -> "PROMPT"
        }
        if (normalizedAction == "PROMPT" && text.isNotBlank()) {
            lastSubmittedPrompt = text.trim()
        } else if (normalizedAction == "STOP" || normalizedAction == "FORCE_STOP") {
            val activeSnapshot = _hudState.value
            val wasActive = activeSnapshot.state == "WORKING" ||
                activeSnapshot.state == "PAUSED" ||
                activeSnapshot.state == "NEEDS_INPUT" ||
                activeSnapshot.state == "STOPPING"
            if (wasActive && !stopRecordedForCurrentRun) {
                stopRecordedForCurrentRun = true
                val elapsedNow = computeCurrentElapsedMs()
                emitRunRecord(activeSnapshot, finalState = "STOPPED", durationMs = elapsedNow)
            }
        }
        val cmd = HudCommand(
            text = text,
            action = normalizedAction,
            buttonId = buttonId,
            payload = payload
        )
        while (commandQueue.size >= MAX_QUEUED_COMMANDS) {
            commandQueue.poll()
        }
        commandQueue.offer(cmd)
        try {
            onCommandBroadcast?.invoke(cmd.toJson())
        } catch (e: Exception) {
            Log.w(TAG, "Failed broadcasting HUD_COMMAND: ${e.message}")
        }
        return cmd
    }

    /**
     * Handles GET /api/hud/poll: atomically drains all pending commands typed in Window 1.
     */
    fun pollCommands(): JSONObject {
        val drained = JSONArray()
        while (true) {
            val next = commandQueue.poll() ?: break
            drained.put(next.toJson())
        }
        return JSONObject().apply {
            put("success", true)
            put("count", drained.length())
            put("commands", drained)
            put("hudVisible", _isHudVisible.value)
            put("inputVisible", _isInputVisible.value)
            put("collapsed", isCollapsed)
            put("state", _hudState.value.state)
            put("ghostPassThrough", ghostPassThrough)
            put("opacity", (_hudState.value.theme.opacity ?: OPACITY_LEVELS[opacityIndex]).toDouble())
        }
    }

    fun setOutputExpanded(expanded: Boolean) {
        isOutputExpanded = expanded
        if (expanded) {
            cancelAutoCollapse()
            if (isCollapsed) isCollapsed = false
            isDetailsExpanded = true
        }
        runOnMain {
            if (hudRootView != null) renderHudWindow()
        }
    }

    fun getFullOutputCopyText(state: AgyHudState = _hudState.value): String {
        val sb = StringBuilder()
        if (state.detailedOutput.isNotBlank()) {
            sb.append(state.detailedOutput.trim())
        }
        if (state.outputLogs.isNotEmpty()) {
            if (sb.isNotEmpty()) sb.append("\n\n--- Execution Log ---\n")
            sb.append(state.outputLogs.joinToString("\n"))
        }
        if (sb.isEmpty() && state.currentAction.isNotBlank()) {
            sb.append("${state.title}: ${state.currentAction}")
        }
        return sb.toString().trim()
    }

    fun copyDetailedOutputToClipboard(): Boolean {
        val content = getFullOutputCopyText()
        if (content.isBlank()) return false
        return try {
            val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
            cm?.setPrimaryClip(ClipData.newPlainText("Agy Output", content))
            runOnMain {
                outputCopyBtn?.text = "Copied ✓"
                outputCopyBtn?.setTextColor(COLOR_EMERALD)
                copyFeedbackResetRunnable?.let { mainHandler.removeCallbacks(it) }
                val reset = Runnable {
                    outputCopyBtn?.text = "Copy"
                    outputCopyBtn?.setTextColor(COLOR_CYAN)
                }
                copyFeedbackResetRunnable = reset
                mainHandler.postDelayed(reset, 1600L)
            }
            true
        } catch (_: Exception) {
            false
        }
    }

    fun resolveQuickActions(state: AgyHudState): List<QuickActionChip> {
        if (state.quickActions.isNotEmpty()) return state.quickActions
        val hasOutput = state.detailedOutput.isNotBlank() || state.outputLogs.isNotEmpty()
        return when (state.state) {
            "NEEDS_INPUT" -> listOf(
                QuickActionChip("Yes, proceed", "Yes, proceed", "PROMPT", style = "primary"),
                QuickActionChip("Skip step", "Skip this step", "PROMPT"),
                QuickActionChip("Cancel", "STOP", "STOP", style = "danger")
            )
            "DONE" -> buildList {
                if (hasOutput) {
                    add(QuickActionChip("Copy Output", "", "COPY_OUTPUT", style = "primary"))
                    add(QuickActionChip(if (isOutputExpanded) "Hide Output" else "View Output", "", "TOGGLE_OUTPUT"))
                }
                add(QuickActionChip("Run Again", "Run again: ${state.title}", "PROMPT"))
            }
            "STOPPING" -> listOf(
                QuickActionChip("Force Stop", "FORCE_STOP", "FORCE_STOP", style = "danger")
            )
            "STOPPED" -> buildList {
                if (hasOutput) {
                    add(QuickActionChip("Copy Output", "", "COPY_OUTPUT"))
                }
                add(QuickActionChip("Run Again", "Run again: ${state.title}", "PROMPT", style = "primary"))
            }
            "WORKING" -> buildList {
                add(QuickActionChip("Pause", "PAUSE", "PAUSE"))
                if (hasOutput) {
                    add(QuickActionChip(if (isOutputExpanded) "Hide Output" else "Live Output", "", "TOGGLE_OUTPUT"))
                }
                add(QuickActionChip("Stop", "STOP", "STOP", style = "danger"))
            }
            "PAUSED" -> buildList {
                add(QuickActionChip("Resume", "RESUME", "RESUME", style = "primary"))
                if (hasOutput) {
                    add(QuickActionChip(if (isOutputExpanded) "Hide Output" else "Output", "", "TOGGLE_OUTPUT"))
                }
                add(QuickActionChip("Stop", "STOP", "STOP", style = "danger"))
            }
            else -> emptyList()
        }
    }

    fun resolveCollapsedRunningStep(state: AgyHudState = _hudState.value): CollapsedRunningStep {
        val activeDoingTask = state.tasks.firstOrNull { it.status == "doing" }
        val stepLabel = when {
            state.state == "STOPPING" -> "Stopping… tap ■ to force-stop"
            activeDoingTask != null && activeDoingTask.label.isNotBlank() -> activeDoingTask.label.trim()
            state.currentAction.isNotBlank() -> state.currentAction.trim()
            state.title.isNotBlank() -> state.title.trim()
            else -> if (state.state == "PAUSED") "Paused" else "Working"
        }
        val resolvedIcon = AgyAppIconResolver.resolve(
            context = context,
            explicitIcon = activeDoingTask?.icon?.ifBlank { state.icon } ?: state.icon,
            explicitPackage = activeDoingTask?.appPackage?.ifBlank { state.appPackage } ?: state.appPackage,
            fallbackText = "${activeDoingTask?.label.orEmpty()} ${activeDoingTask?.detail.orEmpty()} ${state.currentAction} ${state.title}",
            actionKindHint = activeDoingTask?.actionKind?.ifBlank { state.actionKind } ?: state.actionKind
        )
        return CollapsedRunningStep(label = stepLabel, icon = resolvedIcon)
    }

    fun isCollapsedLiveRunningMode(
        state: AgyHudState = _hudState.value,
        collapsed: Boolean = isCollapsed
    ): Boolean = collapsed && (state.state == "WORKING" || state.state == "PAUSED" || state.state == "STOPPING")

    private fun computeCurrentElapsedMs(): Long {
        val extra = if (activeSegmentStartMs > 0L) {
            (System.currentTimeMillis() - activeSegmentStartMs).coerceAtLeast(0L)
        } else 0L
        return (accumulatedElapsedMs + extra).coerceAtLeast(0L)
    }

    private fun emitRunRecord(state: AgyHudState, finalState: String, durationMs: Long) {
        val cb = onRunRecorded ?: return
        val activeStep = resolveCollapsedRunningStep(state)
        try {
            cb.invoke(
                RunRecord(
                    title = state.title.ifBlank { activeStep.label },
                    promptText = lastSubmittedPrompt.ifBlank { state.title },
                    finalState = finalState,
                    iconHint = state.icon.ifBlank { activeStep.icon.kind.name.lowercase(Locale.US) },
                    appPackage = state.appPackage.ifBlank { activeStep.icon.packageName.orEmpty() },
                    durationMs = durationMs.coerceAtLeast(0L),
                    stepCount = state.tasks.size,
                    detailedOutput = state.detailedOutput.ifBlank { state.currentAction },
                    outputLogs = state.outputLogs
                )
            )
        } catch (e: Exception) {
            Log.w(TAG, "Failed recording run history: ${e.message}")
        }
    }

    fun formatElapsed(ms: Long, isDone: Boolean = false): String {
        val safe = ms.coerceAtLeast(0L)
        val totalSec = safe / 1000.0
        return if (isDone) {
            String.format(Locale.US, "Done %.1fs", totalSec)
        } else if (safe < 60_000L) {
            String.format(Locale.US, "00:%04.1f", totalSec)
        } else {
            val mins = safe / 60_000L
            val secs = (safe % 60_000L) / 1000L
            String.format(Locale.US, "%02d:%02d", mins, secs)
        }
    }

    /**
     * Handles POST /api/hud/hide: dismisses both HUD windows cleanly and cancels timers.
     */
    fun hideAll(): JSONObject {
        runOnMain {
            cancelAutoCollapse()
            cancelApprovalCountdown()
            cancelAutoDequeue()
            stopPulseAnimation()
            stopElapsedTimer()
            stopAllLoadingAnimations()
            edgeSnapAnimator?.cancel()
            edgeSnapAnimator = null
            hudDodgeAnimator?.cancel()
            hudDodgeAnimator = null
            pendingHudTargetLeft = null
            pendingHudTargetTop = null
            mainHandler.removeCallbacks(hudLayoutReconcileRunnable)
            hudLayoutReconcileScheduled = false
            isHudDragging = false
            autoCollapsedByCoordinator = false
            _isEdgeParkedFlow.value = false
            pendingEditApprovalId = null
            voiceController?.release()
            voiceController = null
            _isVoiceListeningFlow.value = false
            copyFeedbackResetRunnable?.let { mainHandler.removeCallbacks(it) }
            passThroughRestoreRunnable?.let { mainHandler.removeCallbacks(it) }
            temporaryPassThroughActive = false
            ghostPassThrough = false
            isOutputExpanded = false
            isToolsTrayOpen = false
            lastCollapsedStepLabel = ""
            lastRenderedCollapsedState = null
            lastRenderedTitle = ""
            lastRenderedTaskStatuses = emptyMap()
            hideGhostRestorePillInternal()
            lastDismissedTaskMapSig = null
            blurInlineComposerInternal()
            pointerOverlayManager?.hidePointer()
            taskMapOverlayManager?.clearDismissedState()
            taskMapOverlayManager?.hideMap(dismissLightbox = true)
            regionSnipOverlayManager?.hide()
            edgeHandleOverlayManager?.hide()
            spotlightOverlayManager?.hideSpotlight()
            hudRootView?.let { view ->
                try {
                    windowManager?.removeView(view)
                } catch (e: Exception) {
                    Log.w(TAG, "Error removing agy_hud: ${e.message}")
                }
            }
            hudRootView = null
            hudParams = null
            hudExpandedContainer = null
            hudBottomDockRow = null
            workingLoadingBar = null
            headerAppIconView = null
            headerSpinnerView = null
            elapsedTimerText = null
            toolsMenuBtn = null
            toolsTrayContainer = null
            edgeSnapBtn = null
            pointerBtn = null
            doingDotsView = null
            outputSectionContainer = null
            outputToggleHeaderText = null
            outputDrawerContainer = null
            outputCopyBtn = null
            outputBodyText = null
            quickActionsScrollView = null
            quickActionsContainer = null
            dockStandardStatusGroup = null
            dockStandardDivider = null
            dockSpinnerView = null
            collapsedStatusText = null
            bottomChatPillBtn = null
            dockLiveStepGroup = null
            dockLiveSpinnerView = null
            dockLiveIconView = null
            dockLiveStepText = null
            dockLiveTimerText = null
            dockLiveStopBtn = null
            telemetryDetailsContainer = null
            stepsTogglePill = null
            headerCollapseBtn = null
            customEmojiView = null
            progressRowContainer = null
            progressBarView = null
            progressCaptionText = null
            metricsScrollView = null
            metricsContainer = null
            dynamicBannerContainer = null
            dynamicBannerTitleText = null
            dynamicBannerMsgText = null
            inlineBlocksContainer = null
            detailBlocksContainer = null
            composerDividerView = null
            isDetailsExpanded = false
            isMacrosDrawerOpen = false
            savedYBeforeIme = null
            isTemporarilySuppressed = false
            inlineComposerContainer = null
            composerInputCapsule = null
            composerVoiceStatusHint = null
            inputEditText = null
            inputMicBtn = null
            clearDraftBtn = null
            macrosToggleBtn = null
            composerActionBtn = null
            inputMacrosScrollView = null
            inputMacrosContainer = null
            approvalCardContainer = null
            approvalRiskBadgeText = null
            approvalTimerBadgeText = null
            approvalTitleText = null
            approvalDescText = null
            approvalPreviewText = null
            approvalApproveBtn = null
            approvalEditBtn = null
            approvalDenyBtn = null
            promptQueueContainer = null
            promptQueueHeaderText = null
            promptQueueListContainer = null
            attachedRegionChipRow = null
            attachedRegionChipText = null
            smartSuggestionsScrollView = null
            smartSuggestionsContainer = null
            snipToolBtn = null
            edgeParkToolBtn = null
            composerSnipBtn = null
            demoToolBtn = null
            scratchpadToolBtn = null
            watchdogToolBtn = null
            voiceCoPilotToolBtn = null
            demoRecorderCardContainer = null
            demoRecorderHeaderText = null
            demoRecorderStepsContainer = null
            scratchpadCardContainer = null
            scratchpadHeaderText = null
            scratchpadListContainer = null
            watchdogCardContainer = null
            watchdogStatusText = null
            isScratchpadDrawerOpen = false
            voiceCoPilotManager.stopSpeaking()
            isInputFocused = false
            _isInputVisible.value = false
            _isHudVisible.value = false
        }
        return JSONObject().apply {
            put("success", true)
            put("hudVisible", false)
            put("inputVisible", false)
        }
    }

    // -------------------------------------------------------------------------
    // Power Features: Approval Gate, Region Snip, Prompt Queue, Run-to-Macro,
    // Smart Suggestions, Edge Swipe Handle, and Co-Pilot Spotlight
    // -------------------------------------------------------------------------

    fun setApprovalGate(json: JSONObject): JSONObject {
        val clearRequested = json.optBoolean("clear", false) ||
            (json.has("active") && !json.optBoolean("active", true))
        if (clearRequested) {
            return clearApprovalGate()
        }
        val approvalObj = json.optJSONObject("approval") ?: json
        val gate = AgyHudDynamicModels.ApprovalGateConfig.fromJson(approvalObj)
        val cur = _hudState.value
        val next = cur.copy(
            state = if (gate.active && cur.state != "STOPPING") "NEEDS_INPUT" else cur.state,
            approvalGate = gate
        )
        return applyHudStateInternal(next, explicitCollapsed = if (gate.active) false else null)
            .put("approvalId", gate.id)
    }

    fun clearApprovalGate(): JSONObject {
        cancelApprovalCountdown()
        pendingEditApprovalId = null
        val cur = _hudState.value
        val next = cur.copy(approvalGate = AgyHudDynamicModels.ApprovalGateConfig(active = false))
        return applyHudStateInternal(next).put("approvalCleared", true)
    }

    fun respondToApproval(
        decision: String,
        editedText: String = "",
        approvalId: String = ""
    ): JSONObject {
        val normDecision = when (decision.lowercase().trim()) {
            "approve", "approved", "yes", "allow", "ok" -> "approve"
            "edit", "edited", "modify" -> "edit"
            else -> "deny"
        }
        val activeGate = _hudState.value.approvalGate
        val resolvedId = approvalId.ifBlank { activeGate.id }.ifBlank { "apr_unknown" }
        val cleanEdit = editedText.trim()
        cancelApprovalCountdown()
        pendingEditApprovalId = null

        val payload = JSONObject().apply {
            put("approvalId", resolvedId)
            put("decision", normDecision)
            if (cleanEdit.isNotBlank()) put("editedText", cleanEdit)
        }
        val cmdText = when (normDecision) {
            "approve" -> "APPROVE:$resolvedId"
            "edit" -> cleanEdit.ifBlank { "EDIT:$resolvedId" }
            else -> "DENY:$resolvedId"
        }
        val cmd = enqueueAndBroadcastCommand(
            text = cmdText,
            action = "APPROVAL_RESPONSE",
            buttonId = resolvedId,
            payload = payload
        )
        val cur = _hudState.value
        val nextStateStr = when {
            normDecision == "deny" && cur.state == "NEEDS_INPUT" -> "WORKING"
            normDecision != "deny" && cur.state == "NEEDS_INPUT" -> "WORKING"
            else -> cur.state
        }
        applyHudStateInternal(
            cur.copy(
                state = nextStateStr,
                currentAction = when (normDecision) {
                    "approve" -> "Approved — continuing…"
                    "edit" -> "Updated instruction sent…"
                    else -> "Action denied"
                },
                approvalGate = AgyHudDynamicModels.ApprovalGateConfig(active = false)
            )
        )
        return JSONObject().apply {
            put("success", true)
            put("action", "APPROVAL_RESPONSE")
            put("approvalId", resolvedId)
            put("decision", normDecision)
            put("command", cmd.toJson())
        }
    }

    fun setSpotlight(json: JSONObject): JSONObject {
        val clearRequested = json.optBoolean("clear", false) ||
            (json.has("active") && !json.optBoolean("active", true))
        if (clearRequested) {
            return clearSpotlight()
        }
        val spotObj = json.optJSONObject("spotlight") ?: json
        val cfg = AgyHudDynamicModels.SpotlightConfig.fromJson(spotObj)
        val cur = _hudState.value
        val next = cur.copy(spotlight = cfg)
        _hudState.value = next
        syncSpotlightOverlay(cfg)
        return JSONObject().apply {
            put("success", true)
            put("spotlightActive", cfg.active)
            put("targetCount", cfg.targets.size)
            put("spotlight", cfg.toJson())
        }
    }

    fun clearSpotlight(): JSONObject {
        val cur = _hudState.value
        _hudState.value = cur.copy(spotlight = AgyHudDynamicModels.SpotlightConfig(active = false))
        spotlightOverlayManager?.hideSpotlight()
        return JSONObject().apply {
            put("success", true)
            put("spotlightActive", false)
            put("targetCount", 0)
        }
    }

    private fun syncSpotlightOverlay(config: AgyHudDynamicModels.SpotlightConfig) {
        if (config.active && config.targets.isNotEmpty()) {
            spotlightOverlayManager?.showSpotlight(config)
        } else {
            spotlightOverlayManager?.hideSpotlight()
        }
    }

    private fun currentPlayerBaseline(): AgyHudDynamicModels.PlayerTaskMapData? {
        val snap = taskMapOverlayManager?.getPlayerSnapshot()
        if (snap != null && snap.playlist.isNotEmpty()) {
            return AgyHudDynamicModels.PlayerTaskMapData(
                mediaMode = snap.mediaMode,
                backgroundMode = snap.backgroundMode,
                playing = snap.isPlaying,
                loop = snap.isLooping,
                muted = snap.isMuted,
                volume = snap.volume,
                speed = snap.speed,
                currentIndex = snap.currentIndex,
                positionMs = snap.positionMs,
                durationMs = snap.durationMs,
                playlist = snap.playlist
            )
        }
        return _hudState.value.taskMap.player
    }

    fun setPlayer(json: JSONObject): JSONObject {
        val actionRaw = json.optString("action", json.optString("command", "")).lowercase().trim()
        val clearRequested = json.optBoolean("clear", false) ||
            (json.has("active") && !json.optBoolean("active", true)) ||
            actionRaw in setOf("close", "dismiss", "clear")
        if (clearRequested) {
            return clearPlayer()
        }
        val playerObj = json.optJSONObject("player") ?: json
        val baseline = currentPlayerBaseline()
        val parsed = AgyHudDynamicModels.PlayerTaskMapData.fromJson(playerObj, baseline)
            ?: return JSONObject().apply {
                put("success", false)
                put("error", "No playable track, playlist, or player command supplied")
            }

        lastDismissedTaskMapSig = null
        taskMapOverlayManager?.clearDismissedState()

        val title = json.optString("title", "").trim().ifBlank {
            parsed.currentTrack()?.title.orEmpty().ifBlank { "Agy Player" }
        }
        val cur = _hudState.value
        val tm = AgyHudDynamicModels.TaskMapConfig(
            active = true,
            mode = "player",
            title = title,
            widthDp = json.optDouble("widthDp", 228.0).toFloat().coerceIn(180f, 268f),
            persistOnDone = json.optBoolean("persistOnDone", true),
            player = parsed
        )
        val next = cur.copy(taskMap = tm)
        _hudState.value = next
        syncTaskMapOverlay(next)

        val liveSnap = taskMapOverlayManager?.getPlayerSnapshot()
        val effectivePlaying = liveSnap?.isPlaying ?: parsed.playing
        val effectiveMode = liveSnap?.mediaMode ?: parsed.mediaMode
        val effectiveBg = liveSnap?.backgroundMode ?: parsed.backgroundMode
        val effectiveIndex = liveSnap?.currentIndex ?: parsed.currentIndex

        return JSONObject().apply {
            put("success", true)
            put("playerActive", true)
            put("mediaMode", effectiveMode)
            put("backgroundMode", effectiveBg)
            put("bg", effectiveBg)
            put("playing", effectivePlaying)
            put("loop", liveSnap?.isLooping ?: parsed.loop)
            put("muted", liveSnap?.isMuted ?: parsed.muted)
            put("volume", (liveSnap?.volume ?: parsed.volume).toDouble())
            put("speed", (liveSnap?.speed ?: parsed.speed).toDouble())
            put("currentIndex", effectiveIndex)
            put("trackCount", parsed.playlist.size)
            put("title", parsed.currentTrack()?.title ?: title)
            put("player", parsed.toJson())
        }
    }

    fun clearPlayer(): JSONObject {
        lastDismissedTaskMapSig = null
        taskMapOverlayManager?.clearDismissedState()
        val cur = _hudState.value
        val nextTm = if (cur.taskMap.mode == "player") {
            AgyHudDynamicModels.TaskMapConfig(active = false)
        } else cur.taskMap
        val next = cur.copy(taskMap = nextTm)
        _hudState.value = next
        syncTaskMapOverlay(next)
        return JSONObject().apply {
            put("success", true)
            put("playerActive", false)
            put("trackCount", 0)
        }
    }

    // -------------------------------------------------------------------------
    // Advanced Suite APIs:
    // 1. Demonstration Recorder (`/api/hud/demo`, `DEMO_RECORDED`)
    // 2. Smart Clipboard & Scratchpad (`/api/hud/scratchpad`)
    // 3. Live Screen Diff & Watchdog (`/api/hud/watchdog`, `WATCHDOG_TRIGGERED`)
    // 4. Voice Co-Pilot (`/api/hud/voice`)
    // -------------------------------------------------------------------------

    fun handleDemoAction(json: JSONObject): JSONObject {
        val action = json.optString("action", json.optString("op", "")).lowercase().trim()
        return when (action) {
            "send", "teach", "send_to_agy" -> {
                finishAndSendDemoToAgy(json.optString("goal", json.optString("title", "")))
            }
            "save_macro", "macro" -> {
                val saved = saveDemoAsMacro(json.optString("title", ""))
                JSONObject().apply {
                    put("success", saved)
                    put("savedAsMacro", saved)
                    put("demoSession", demoRecorderManager.currentSession().toJson())
                }
            }
            "capture_visible", "capture_node" -> {
                if (!demoRecorderManager.isRecording()) {
                    demoRecorderManager.startRecording(json.optString("title", "Recorded Demonstration"))
                }
                val step = demoRecorderManager.captureBestVisibleNodeStep()
                val session = demoRecorderManager.currentSession()
                _hudState.value = _hudState.value.copy(demoSession = session)
                runOnMain { if (hudRootView != null) renderHudWindow() }
                JSONObject().apply {
                    put("success", step != null)
                    put("active", session.active)
                    put("stepCount", session.steps.size)
                    if (step != null) put("step", step.toJson())
                    put("demoSession", session.toJson())
                }
            }
            else -> {
                val session = demoRecorderManager.applyFromJson(json)
                _hudState.value = _hudState.value.copy(demoSession = session)
                if (session.active) {
                    isCollapsed = false
                }
                runOnMain { if (hudRootView != null) renderHudWindow() }
                JSONObject().apply {
                    put("success", true)
                    put("active", session.active)
                    put("stepCount", session.steps.size)
                    put("macroPrompt", session.toMacroPrompt())
                    put("demoSession", session.toJson())
                }
            }
        }
    }

    fun finishAndSendDemoToAgy(customGoal: String = ""): JSONObject {
        val stopped = demoRecorderManager.stopRecording()
        _hudState.value = _hudState.value.copy(demoSession = stopped)
        if (stopped.steps.isEmpty()) {
            return JSONObject().apply {
                put("success", false)
                put("error", "No demonstration steps recorded")
            }
        }
        val prompt = stopped.toMacroPrompt(customGoal)
        val payload = JSONObject().apply {
            put("demoSession", stopped.toJson())
            put("stepCount", stopped.steps.size)
            put("macroPrompt", prompt)
        }
        val cmd = enqueueAndBroadcastCommand(
            text = prompt,
            action = "DEMO_RECORDED",
            buttonId = stopped.id,
            payload = payload
        )
        runOnMain { if (hudRootView != null) renderHudWindow() }
        return JSONObject().apply {
            put("success", true)
            put("action", "DEMO_RECORDED")
            put("stepCount", stopped.steps.size)
            put("macroPrompt", prompt)
            put("command", cmd.toJson())
            put("demoSession", stopped.toJson())
        }
    }

    fun saveDemoAsMacro(customTitle: String = ""): Boolean {
        val session = demoRecorderManager.stopRecording()
        _hudState.value = _hudState.value.copy(demoSession = session)
        if (session.steps.isEmpty()) return false
        val title = customTitle.trim().ifBlank { session.title.ifBlank { "Demo (${session.steps.size} steps)" } }
        val prompt = session.toMacroPrompt(title)
        return saveLastPromptAsMacro(customTitle = title, customPrompt = prompt)
    }

    fun handleScratchpadAction(json: JSONObject): JSONObject {
        val action = json.optString("action", json.optString("op", "")).lowercase().trim()
        if (action == "toggle_drawer" || action == "open_drawer") {
            isScratchpadDrawerOpen = if (action == "open_drawer") true else !isScratchpadDrawerOpen
            if (isScratchpadDrawerOpen) isCollapsed = false
            runOnMain { if (hudRootView != null) renderHudWindow() }
            return scratchpadManager.toJson().put("drawerOpen", isScratchpadDrawerOpen)
        }
        if (action == "ask" || action == "send_to_agy") {
            val id = json.optString("id", "").trim()
            val item = scratchpadManager.currentItems().firstOrNull { it.id == id }
                ?: scratchpadManager.currentItems().firstOrNull()
            if (item == null) {
                return JSONObject().put("success", false).put("error", "Scratchpad item not found")
            }
            val prefix = json.optString("promptPrefix", "Use this ${item.kind} snippet:").trim()
            val prompt = "$prefix ${item.content}"
            return submitOrQueuePrompt(text = prompt)
        }
        val res = scratchpadManager.applyFromJson(json)
        _hudState.value = _hudState.value.copy(scratchpadItems = scratchpadManager.currentItems())
        if (json.optBoolean("openDrawer", false)) {
            isScratchpadDrawerOpen = true
            isCollapsed = false
        }
        runOnMain { if (hudRootView != null) renderHudWindow() }
        return res.put("drawerOpen", isScratchpadDrawerOpen)
    }

    fun setWatchdog(json: JSONObject): JSONObject {
        val res = screenWatchdogManager.applyFromJson(json, _attachedRegionContextFlow.value)
        val currentWd = screenWatchdogManager.currentWatchdog()
        _hudState.value = _hudState.value.copy(watchdog = currentWd)
        runOnMain { if (hudRootView != null) renderHudWindow() }
        return res
    }

    fun clearWatchdog(): JSONObject {
        val cleared = screenWatchdogManager.clearWatchdog()
        _hudState.value = _hudState.value.copy(watchdog = cleared)
        runOnMain { if (hudRootView != null) renderHudWindow() }
        return JSONObject().apply {
            put("success", true)
            put("status", "cleared")
            put("active", false)
            put("watchdog", cleared.toJson())
        }
    }

    fun evaluateWatchdogNow(): JSONObject {
        val res = screenWatchdogManager.evaluateNow()
        _hudState.value = _hudState.value.copy(watchdog = screenWatchdogManager.currentWatchdog())
        runOnMain { if (hudRootView != null) renderHudWindow() }
        return res
    }

    fun setVoiceCoPilot(json: JSONObject): JSONObject {
        val res = voiceCoPilotManager.applyFromJson(json)
        _hudState.value = _hudState.value.copy(voiceCoPilot = voiceCoPilotManager.currentConfig())
        runOnMain { if (hudRootView != null) renderHudWindow() }
        return res
    }

    private fun syncApprovalCountdown(gate: AgyHudDynamicModels.ApprovalGateConfig) {
        if (!gate.active || gate.timeoutSeconds <= 0) {
            cancelApprovalCountdown()
            return
        }
        if (activeApprovalCountdownId == gate.id && approvalCountdownRunnable != null) {
            return
        }
        cancelApprovalCountdown()
        activeApprovalCountdownId = gate.id
        approvalRemainingSeconds = gate.timeoutSeconds
        val ticker = object : Runnable {
            override fun run() {
                val curGate = _hudState.value.approvalGate
                if (!curGate.active || curGate.id != activeApprovalCountdownId) {
                    cancelApprovalCountdown()
                    return
                }
                approvalRemainingSeconds = (approvalRemainingSeconds - 1).coerceAtLeast(0)
                approvalTimerBadgeText?.text = "${approvalRemainingSeconds}s"
                if (approvalRemainingSeconds <= 0) {
                    respondToApproval(decision = "deny", approvalId = curGate.id)
                } else {
                    mainHandler.postDelayed(this, 1000L)
                }
            }
        }
        approvalCountdownRunnable = ticker
        mainHandler.postDelayed(ticker, 1000L)
    }

    private fun cancelApprovalCountdown() {
        approvalCountdownRunnable?.let { mainHandler.removeCallbacks(it) }
        approvalCountdownRunnable = null
        activeApprovalCountdownId = ""
        approvalRemainingSeconds = 0
    }

    /**
     * Submits a prompt immediately when Agy is IDLE / DONE / STOPPED / NEEDS_INPUT, or appends it
     * to the ordered Prompt Queue when Agy is currently WORKING or PAUSED.
     * If an Approval Gate Edit is pending, emits `APPROVAL_RESPONSE` (`decision = "edit"`).
     */
    fun submitOrQueuePrompt(
        text: String,
        regionOverride: AgyHudDynamicModels.SnippedRegionContext? = null,
        forceSendNow: Boolean = false
    ): JSONObject {
        val clean = text.trim()
        if (clean.isEmpty()) {
            return JSONObject().put("success", false).put("error", "Empty prompt")
        }
        val editApprovalId = pendingEditApprovalId
        if (!editApprovalId.isNullOrBlank()) {
            return respondToApproval(decision = "edit", editedText = clean, approvalId = editApprovalId)
        }
        val region = regionOverride ?: _attachedRegionContextFlow.value
        val curState = _hudState.value.state
        val shouldQueue = !forceSendNow && (curState == "WORKING" || curState == "PAUSED")
        if (shouldQueue) {
            val item = AgyHudDynamicModels.QueuedPromptItem(
                id = "qp_${UUID.randomUUID().toString().take(8)}",
                text = clean,
                regionContext = region
            )
            _queuedPromptsFlow.value = (_queuedPromptsFlow.value + item).take(12)
            if (regionOverride == null) _attachedRegionContextFlow.value = null
            runOnMain { if (hudRootView != null) renderHudWindow() }
            return JSONObject().apply {
                put("success", true)
                put("queued", true)
                put("queueSize", _queuedPromptsFlow.value.size)
                put("item", item.toJson())
            }
        }

        val payload = region?.let { JSONObject().put("regionContext", it.toJson()) }
        val cmd = enqueueAndBroadcastCommand(
            text = clean,
            action = "PROMPT",
            payload = payload
        )
        if (regionOverride == null) _attachedRegionContextFlow.value = null
        lastMacroSavedPrompt = ""
        runOnMain { if (hudRootView != null) renderHudWindow() }
        return JSONObject().apply {
            put("success", true)
            put("queued", false)
            put("command", cmd.toJson())
        }
    }

    fun promoteQueuedPrompt(itemId: String): Boolean {
        val current = _queuedPromptsFlow.value
        val idx = current.indexOfFirst { it.id == itemId }
        if (idx <= 0) return false
        val target = current[idx]
        val reordered = buildList {
            add(target)
            current.forEachIndexed { i, item -> if (i != idx) add(item) }
        }
        _queuedPromptsFlow.value = reordered
        runOnMain { if (hudRootView != null) renderHudWindow() }
        return true
    }

    fun removeQueuedPrompt(itemId: String): Boolean {
        val current = _queuedPromptsFlow.value
        val next = current.filterNot { it.id == itemId }
        if (next.size == current.size) return false
        _queuedPromptsFlow.value = next
        if (next.isEmpty()) cancelAutoDequeue()
        runOnMain { if (hudRootView != null) renderHudWindow() }
        return true
    }

    fun dispatchNextQueuedPrompt(): HudCommand? {
        cancelAutoDequeue()
        val current = _queuedPromptsFlow.value
        if (current.isEmpty()) return null
        val head = current.first()
        _queuedPromptsFlow.value = current.drop(1)
        val payload = head.regionContext?.let { JSONObject().put("regionContext", it.toJson()) }
        val cmd = enqueueAndBroadcastCommand(
            text = head.text,
            action = "PROMPT",
            payload = payload
        )
        lastMacroSavedPrompt = ""
        runOnMain { if (hudRootView != null) renderHudWindow() }
        return cmd
    }

    private fun scheduleAutoDequeueNextPrompt() {
        cancelAutoDequeue()
        val r = Runnable {
            autoDequeueRunnable = null
            val st = _hudState.value
            if (st.state == "DONE" && !st.approvalGate.active && _queuedPromptsFlow.value.isNotEmpty()) {
                dispatchNextQueuedPrompt()
            }
        }
        autoDequeueRunnable = r
        mainHandler.postDelayed(r, 650L)
    }

    private fun cancelAutoDequeue() {
        autoDequeueRunnable?.let { mainHandler.removeCallbacks(it) }
        autoDequeueRunnable = null
    }

    fun saveLastPromptAsMacro(customTitle: String = "", customPrompt: String = ""): Boolean {
        val prompt = customPrompt.trim().ifBlank { lastSubmittedPrompt }.ifBlank { _hudState.value.title }
        if (prompt.isBlank() || prompt == "Agy Ready" || prompt == "Agy HUD") return false
        val title = customTitle.trim().ifBlank {
            prompt.split(Regex("\\s+")).take(4).joinToString(" ").take(26).trim()
        }
        val iconHint = _hudState.value.icon.ifBlank {
            AgySmartSuggestionsResolver.shortAppLabel(resolveActiveAppPackage(_hudState.value)).lowercase().ifBlank { "spark_ai" }
        }
        onSaveMacro?.invoke(title, prompt, iconHint)
        lastMacroSavedPrompt = prompt
        runOnMain { if (hudRootView != null) renderHudWindow() }
        return true
    }

    fun attachRegionContext(ctx: AgyHudDynamicModels.SnippedRegionContext?) {
        _attachedRegionContextFlow.value = ctx
        runOnMain { if (hudRootView != null) renderHudWindow() }
    }

    fun startRegionSnip(): Boolean {
        val manager = regionSnipOverlayManager ?: return false
        if (!hasOverlayPermission()) return false
        cancelAutoCollapse()
        isToolsTrayOpen = false
        val wasEdgeParked = _isEdgeParkedFlow.value
        if (wasEdgeParked) {
            edgeHandleOverlayManager?.hide()
        }
        isTemporarilySuppressed = true
        runOnMain {
            blurInlineComposerInternal()
            hudRootView?.visibility = View.GONE
        }
        return manager.startSnip(
            nodeTreeProvider = nodeTreeProvider,
            foregroundPackageProvider = foregroundPackageProvider,
            onComplete = { captured ->
                _attachedRegionContextFlow.value = captured
                _isEdgeParkedFlow.value = false
                isTemporarilySuppressed = false
                isCollapsed = false
                userManuallyCollapsed = false
                _isInputVisible.value = true
                runOnMain {
                    ensureHudWindowAttached()
                    hudRootView?.visibility = View.VISIBLE
                    renderHudWindow()
                    focusInlineComposerInternal(requestKeyboardFocus = true)
                }
            },
            onCancel = {
                isTemporarilySuppressed = false
                if (wasEdgeParked) {
                    edgeHandleOverlayManager?.show(
                        agentActive = _hudState.value.state in setOf("WORKING", "PAUSED", "NEEDS_INPUT", "STOPPING")
                    )
                } else {
                    runOnMain {
                        hudRootView?.visibility = View.VISIBLE
                        renderHudWindow()
                    }
                }
            }
        )
    }

    fun parkToEdge(side: AgyEdgeHandleOverlayManager.EdgeSide = AgyEdgeHandleOverlayManager.EdgeSide.RIGHT): JSONObject {
        cancelAutoCollapse()
        isToolsTrayOpen = false
        _isEdgeParkedFlow.value = true
        isTemporarilySuppressed = true
        runOnMain {
            blurInlineComposerInternal()
            hudRootView?.visibility = View.GONE
        }
        val active = _hudState.value.state in setOf("WORKING", "PAUSED", "NEEDS_INPUT", "STOPPING")
        val shown = edgeHandleOverlayManager?.show(side = side, agentActive = active) ?: false
        return JSONObject().apply {
            put("success", true)
            put("action", "PARK_EDGE")
            put("edgeParked", true)
            put("handleRendered", shown)
        }
    }

    fun summonFromEdge(
        focusComposer: Boolean = false,
        startVoice: Boolean = false,
        startSnip: Boolean = false
    ): JSONObject {
        _isEdgeParkedFlow.value = false
        edgeHandleOverlayManager?.hide()
        if (startSnip) {
            val started = startRegionSnip()
            return JSONObject().apply {
                put("success", true)
                put("action", "SUMMON_EDGE")
                put("edgeParked", false)
                put("snipStarted", started)
            }
        }
        isTemporarilySuppressed = false
        isCollapsed = false
        autoCollapsedByCoordinator = false
        userManuallyCollapsed = false
        _isInputVisible.value = _hudState.value.layout.showComposer
        if (hasOverlayPermission()) {
            runOnMain {
                ensureHudWindowAttached()
                hudRootView?.visibility = View.VISIBLE
                renderHudWindow()
                layoutCoordinator.notifyInteraction(
                    id = AgyOverlayLayoutCoordinator.ManagedWindowId.HUD,
                    priority = AgyOverlayLayoutCoordinator.InteractionPriority.USER_INTERACTED,
                    animate = true
                )
                if (focusComposer) {
                    focusInlineComposerInternal(requestKeyboardFocus = true)
                }
                if (startVoice) {
                    toggleVoiceDictationInternal()
                }
            }
        }
        return JSONObject().apply {
            put("success", true)
            put("action", "SUMMON_EDGE")
            put("edgeParked", false)
            put("collapsed", false)
        }
    }

    fun resolveActiveAppPackage(state: AgyHudState = _hudState.value): String {
        val fromProvider = try { foregroundPackageProvider?.invoke()?.trim().orEmpty() } catch (_: Throwable) { "" }
        if (fromProvider.isNotBlank() && fromProvider != context.packageName) return fromProvider
        return state.appPackage.trim()
    }

    fun resolveEffectiveSmartSuggestions(state: AgyHudState = _hudState.value): List<AgyHudDynamicModels.SmartSuggestionChip> {
        return AgySmartSuggestionsResolver.resolve(
            appPackage = resolveActiveAppPackage(state),
            explicitSuggestions = state.smartSuggestions,
            maxItems = 3
        )
    }

    private fun stopAllLoadingAnimations() {
        hudExpandedContainer?.stopAurora()
        workingLoadingBar?.setAnimating(false)
        headerSpinnerView?.setAnimating(false)
        doingDotsView?.setAnimating(false)
        dockSpinnerView?.setAnimating(false)
        dockLiveSpinnerView?.setAnimating(false)
    }

    // -------------------------------------------------------------------------
    // Touch Collision Pass-Through Helpers (called by DeviceBridgeManager)
    // -------------------------------------------------------------------------

    fun getOverlayBounds(): List<Rect> {
        val rects = mutableListOf<Rect>()
        val vp = layoutCoordinator.currentViewportSafeBounds()

        if (hudRootView != null && hudParams != null && !isTemporarilySuppressed) {
            val w = hudRootView?.width?.takeIf { it > 0 }
                ?: if (isCollapsed) estimateHudCollapsedWidthPx() else estimateHudExpandedWidthPx()
            val h = hudRootView?.height?.takeIf { it > 0 }
                ?: if (isCollapsed) estimateHudCollapsedHeightPx() else estimateHudExpandedHeightPx()
            rects.add(computeHudScreenRect(vp, w, h))
        }

        ghostRestoreView?.let { gv ->
            ghostRestoreParams?.let { gp ->
                val w = gv.width.takeIf { it > 0 } ?: (96 * density()).toInt()
                val h = gv.height.takeIf { it > 0 } ?: (34 * density()).toInt()
                rects.add(
                    AgyOverlayLayoutCoordinator.windowParamsToScreenRect(
                        params = gp,
                        width = w,
                        height = h,
                        screenWidth = vp.screenWidth,
                        screenHeight = vp.screenHeight
                    )
                )
            }
        }

        taskMapOverlayManager?.getOverlayRect()?.let { rects.add(it) }
        return rects
    }

    fun coordinatesOverlapRects(
        x1: Float,
        y1: Float,
        x2: Float = x1,
        y2: Float = y1,
        rects: List<Rect>
    ): Boolean {
        if (rects.isEmpty()) return false
        val segRect = Rect(
            min(x1, x2).toInt(),
            min(y1, y2).toInt(),
            max(x1, x2).toInt() + 1,
            max(y1, y2).toInt() + 1
        )
        return rects.any { r ->
            r.contains(x1.toInt(), y1.toInt()) ||
                r.contains(x2.toInt(), y2.toInt()) ||
                Rect.intersects(r, segRect)
        }
    }

    /**
     * Checks if a gesture (TAP/SWIPE/DRAG) overlaps agy_hud, agy_input, or agy_task_map; if so,
     * temporarily applies FLAG_NOT_TOUCHABLE for ~durationMs (default 300ms) so touch passes underneath.
     */
    fun temporarilyPassThroughIfColliding(
        x1: Float,
        y1: Float,
        x2: Float = x1,
        y2: Float = y1,
        durationMs: Long = 300L
    ): Boolean {
        val mapVisible = taskMapOverlayManager?.isMapVisibleFlow?.value == true
        if (!_isHudVisible.value && !_isInputVisible.value && !mapVisible) return false
        val bounds = getOverlayBounds()
        if (!coordinatesOverlapRects(x1, y1, x2, y2, bounds)) return false

        val safeDuration = durationMs.coerceIn(250L, 2500L)
        val latch = CountDownLatch(1)
        val applyTask = Runnable {
            try {
                temporaryPassThroughActive = true
                applyTouchableFlagsInternal(touchable = false)
                taskMapOverlayManager?.setTemporaryTouchPassThrough(true)
                passThroughRestoreRunnable?.let { mainHandler.removeCallbacks(it) }
                val restore = Runnable {
                    temporaryPassThroughActive = false
                    taskMapOverlayManager?.setTemporaryTouchPassThrough(false)
                    if (!ghostPassThrough) {
                        applyTouchableFlagsInternal(touchable = true)
                    }
                }
                passThroughRestoreRunnable = restore
                mainHandler.postDelayed(restore, safeDuration)
            } finally {
                latch.countDown()
            }
        }
        if (Looper.myLooper() == Looper.getMainLooper()) {
            applyTask.run()
        } else {
            mainHandler.post(applyTask)
            try {
                latch.await(150L, TimeUnit.MILLISECONDS)
            } catch (_: InterruptedException) {}
        }
        return true
    }

    // -------------------------------------------------------------------------
    // Window 2: Live Task & Screen HUD (`agy_hud`)
    // -------------------------------------------------------------------------

    private fun ensureHudWindowAttached() {
        if (hudRootView != null) {
            _isHudVisible.value = true
            return
        }
        val wm = windowManager ?: return
        val d = density()

        val root = HoldDraggableDockLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.END
            clipChildren = false
            clipToPadding = false
        }
        val expanded = buildExpandedHudCard(d)
        val bottomDock = buildBottomChatDockRow(d)
        root.addView(expanded)
        root.addView(bottomDock)
        tagTreeForSelfExclusion(root, "window2")

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayWindowType(),
            // Start with FLAG_NOT_FOCUSABLE so Termux keeps keyboard focus until user taps the built-in bottom field.
            // Omit FLAG_LAYOUT_IN_SCREEN so Android automatically insets the bottom-anchored card cleanly above the soft keyboard!
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.END
            x = (14 * d).toInt()
            y = (16 * d).toInt()
            @Suppress("DEPRECATION")
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        }

        hudRootView = root
        hudParams = params
        hudExpandedContainer = expanded
        hudBottomDockRow = bottomDock

        // Observe dynamic size changes (task checklist growth, output drawer, collapse morph)
        root.addOnLayoutChangeListener { _, left, top, right, bottom, oldLeft, oldTop, oldRight, oldBottom ->
            val newW = right - left
            val newH = bottom - top
            val oldW = oldRight - oldLeft
            val oldH = oldBottom - oldTop
            if (newW > 0 && newH > 0) {
                if (isCollapsed) {
                    lastMeasuredCollapsedWidthPx = newW
                    lastMeasuredCollapsedHeightPx = newH
                } else {
                    lastMeasuredExpandedWidthPx = newW
                    lastMeasuredExpandedHeightPx = newH
                }
                if (abs(newW - oldW) > 3 || abs(newH - oldH) > 3) {
                    scheduleHudLayoutReconcile()
                }
            }
        }

        // Tapping outside the unified card releases keyboard focus straight back to Termux
        root.onOutsideTouch = {
            if (isInputFocused) {
                releaseInputFocusToTermux()
            }
        }

        // Hold anywhere (~180ms) on the unified card or collapsed pill to drag cleanly + live auto-dodge partner
        root.onDragDelta = { dx, dy ->
            edgeSnapAnimator?.cancel()
            hudDodgeAnimator?.cancel()
            hudDodgeAnimator = null
            pendingHudTargetLeft = null
            pendingHudTargetTop = null
            if (!isHudDragging) {
                isHudDragging = true
                layoutCoordinator.notifyDragStart(AgyOverlayLayoutCoordinator.ManagedWindowId.HUD)
            }
            shiftBottomRightWindow(root, params, dx, dy)
            layoutCoordinator.notifyDragMove(AgyOverlayLayoutCoordinator.ManagedWindowId.HUD)
        }
        root.onDragEnd = {
            isHudDragging = false
            if (edgeSnapEnabled) {
                snapHudToNearestEdge()
            } else {
                layoutCoordinator.notifyDragEnd(AgyOverlayLayoutCoordinator.ManagedWindowId.HUD, animate = true)
            }
        }
        // Horizontal flick across expanded card smoothly springs into the compact pill
        root.onHorizontalSwipe = {
            if (!isCollapsed) {
                cancelAutoCollapse()
                isCollapsed = true
                autoCollapsedByCoordinator = false
                userManuallyCollapsed = true
                isToolsTrayOpen = false
                blurInlineComposerInternal()
                renderHudWindow()
                layoutCoordinator.reconcile(animate = true)
            }
        }

        try {
            wm.addView(root, params)
            _isHudVisible.value = true
        } catch (e: Exception) {
            Log.e(TAG, "Failed adding agy_hud window: ${e.message}")
            hudRootView = null
            hudParams = null
            hudExpandedContainer = null
            hudBottomDockRow = null
            _isHudVisible.value = false
        }
    }

    private fun buildExpandedHudCard(d: Float): AgyAuroraCardLayout {
        val cardWidthPx = min((304 * d).toInt(), (context.resources.displayMetrics.widthPixels * 0.90f).toInt())
        val container = AgyAuroraCardLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(cardWidthPx, ViewGroup.LayoutParams.WRAP_CONTENT)
            setPadding((14 * d).toInt(), (11 * d).toInt(), (14 * d).toInt(), (11 * d).toInt())
            elevation = 12f * d
            layoutTransition = LayoutTransition().apply {
                setDuration(220L)
                enableTransitionType(LayoutTransition.CHANGING)
            }
        }

        // Top Indeterminate Sliding Progress Bar (animates while state == WORKING)
        val loadBar = AgyLoadingBarView(context).apply {
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                (3.5f * d).toInt().coerceAtLeast(4)
            ).apply {
                bottomMargin = (8 * d).toInt()
            }
            visibility = View.GONE
        }
        workingLoadingBar = loadBar
        container.addView(loadBar)

        // Ultra-Clean Minimal Header: App/Task Icon + Single-Line Status & Timer + Only 2 Quiet Controls (··· & —)
        val header = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }

        val appIcon = AgyIconBadgeView(context).apply {
            val sz = (34 * d).toInt()
            layoutParams = LinearLayout.LayoutParams(sz, sz).apply { marginEnd = (8 * d).toInt() }
        }
        headerAppIconView = appIcon

        val emojiTv = TextView(context).apply {
            val sz = (34 * d).toInt()
            layoutParams = LinearLayout.LayoutParams(sz, sz).apply { marginEnd = (8 * d).toInt() }
            gravity = Gravity.CENTER
            textSize = 16f
            visibility = View.GONE
        }
        customEmojiView = emojiTv

        val statusTopRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }

        val headerSpinner = AgySpinnerRingView(context).apply {
            val sz = (12 * d).toInt()
            layoutParams = LinearLayout.LayoutParams(sz, sz).apply { marginEnd = (6 * d).toInt() }
            setAccentColor(COLOR_CYAN)
            visibility = View.GONE
        }
        headerSpinnerView = headerSpinner

        val dot = View(context).apply {
            val sz = (6 * d).toInt()
            layoutParams = LinearLayout.LayoutParams(sz, sz).apply { marginEnd = (6 * d).toInt() }
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(COLOR_CYAN)
            }
        }
        statusDotView = dot

        val badge = TextView(context).apply {
            text = "Ready"
            textSize = 11.5f
            setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
            setTextColor(COLOR_TEXT_PRIMARY)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        statusBadgeText = badge

        val timerTv = TextView(context).apply {
            text = ""
            textSize = 10.5f
            typeface = Typeface.MONOSPACE
            setTextColor(COLOR_TEXT_SECONDARY)
            maxLines = 1
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { marginStart = (6 * d).toInt() }
            visibility = View.GONE
        }
        elapsedTimerText = timerTv

        statusTopRow.addView(headerSpinner)
        statusTopRow.addView(dot)
        statusTopRow.addView(badge)
        statusTopRow.addView(timerTv)

        fun headerControlChip(symbol: String, desc: String, onClick: () -> Unit): TextView {
            return TextView(context).apply {
                text = symbol
                textSize = 12f
                gravity = Gravity.CENTER
                setTextColor(COLOR_TEXT_SECONDARY)
                val sz = (26 * d).toInt()
                layoutParams = LinearLayout.LayoutParams(sz, sz).apply { marginStart = (4 * d).toInt() }
                background = createLiquidGlassDrawable(
                    fillColor = Color.parseColor("#F3F4F6"),
                    strokeColor = Color.TRANSPARENT,
                    radiusDp = 999f,
                    strokeDp = 0f
                )
                contentDescription = "${HUD_NODE_TAG_PREFIX}$desc"
                setOnClickListener { onClick() }
            }
        }

        val stepsPill = TextView(context).apply {
            text = "Steps ▾"
            textSize = 10f
            setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
            setTextColor(COLOR_TEXT_SECONDARY)
            gravity = Gravity.CENTER
            setPadding((8 * d).toInt(), (4 * d).toInt(), (8 * d).toInt(), (4 * d).toInt())
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                (26 * d).toInt()
            ).apply { marginStart = (4 * d).toInt() }
            background = createLiquidGlassDrawable(
                fillColor = Color.parseColor("#F3F6FA"),
                strokeColor = COLOR_HAIRLINE,
                radiusDp = 999f,
                strokeDp = 0.7f
            )
            contentDescription = "${HUD_NODE_TAG_PREFIX}steps_toggle_btn"
            visibility = View.GONE
            attachSpringPressFeedback(0.93f)
            setOnClickListener {
                cancelAutoCollapse()
                isDetailsExpanded = !isDetailsExpanded
                if (isDetailsExpanded && isInputFocused) {
                    releaseInputFocusToTermux()
                }
                renderHudWindow()
                layoutCoordinator.notifyInteraction(
                    id = AgyOverlayLayoutCoordinator.ManagedWindowId.HUD,
                    priority = AgyOverlayLayoutCoordinator.InteractionPriority.USER_INTERACTED,
                    animate = true
                )
            }
        }
        stepsTogglePill = stepsPill

        val moreBtn = headerControlChip("···", "tools_menu_btn") {
            isToolsTrayOpen = !isToolsTrayOpen
            renderHudWindow()
        }
        toolsMenuBtn = moreBtn

        val collapseBtn = headerControlChip("─", "collapse_btn") {
            isCollapsed = true
            autoCollapsedByCoordinator = false
            userManuallyCollapsed = true
            isDetailsExpanded = false
            isMacrosDrawerOpen = false
            isOutputExpanded = false
            isToolsTrayOpen = false
            blurInlineComposerInternal()
            renderHudWindow()
            layoutCoordinator.reconcile(animate = true)
        }
        headerCollapseBtn = collapseBtn

        header.addView(appIcon)
        header.addView(emojiTv)
        header.addView(statusTopRow)
        header.addView(stepsPill)
        header.addView(moreBtn)
        header.addView(collapseBtn)
        container.addView(header)

        // Hidden-by-default Secondary Controls Tray (revealed on tapping ···)
        val tray = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((6 * d).toInt(), (5 * d).toInt(), (6 * d).toInt(), (5 * d).toInt())
            background = createLiquidGlassDrawable(
                fillColor = Color.parseColor("#F5F6F8"),
                strokeColor = COLOR_HAIRLINE,
                radiusDp = 12f,
                strokeDp = 0.7f
            )
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = (8 * d).toInt() }
            visibility = View.GONE
        }
        val trayRow1 = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }
        val trayRow2 = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = (4 * d).toInt() }
        }

        fun trayToolChip(label: String, desc: String, onClick: () -> Unit): TextView {
            return TextView(context).apply {
                text = label
                textSize = 9.5f
                gravity = Gravity.CENTER
                setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
                setTextColor(COLOR_TEXT_PRIMARY)
                setPadding((4 * d).toInt(), (5 * d).toInt(), (4 * d).toInt(), (5 * d).toInt())
                background = createLiquidGlassDrawable(
                    fillColor = Color.WHITE,
                    strokeColor = COLOR_HAIRLINE,
                    radiusDp = 999f,
                    strokeDp = 0.7f
                )
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                    marginStart = (2 * d).toInt()
                    marginEnd = (2 * d).toInt()
                }
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
                contentDescription = "${HUD_NODE_TAG_PREFIX}$desc"
                setOnClickListener { onClick() }
            }
        }

        val opBtn = trayToolChip("100%", "opacity_btn") { cycleOpacityInternal() }
        opacityBtn = opBtn
        val wfBtn = trayToolChip("● Map", "wireframe_toggle_btn") {
            wireframeEnabled = !wireframeEnabled
            syncTaskMapOverlay(_hudState.value)
            renderHudWindow()
        }
        wireframeBtn = wfBtn
        val ghBtn = trayToolChip("Ghost", "ghost_toggle_btn") {
            setGhostModeInternal(!ghostPassThrough)
        }
        ghostBtn = ghBtn
        val snapBtn = trayToolChip("● Snap", "edge_snap_toggle_btn") {
            edgeSnapEnabled = !edgeSnapEnabled
            if (edgeSnapEnabled) snapHudToNearestEdge()
            renderHudWindow()
        }
        edgeSnapBtn = snapBtn
        val ptrBtn = trayToolChip("● 🖱", "pointer_toggle_btn") {
            setPointerEnabled(!_pointerEnabledFlow.value)
        }
        pointerBtn = ptrBtn

        val snipBtn = trayToolChip("✂ Snip Region", "snip_region_btn") {
            startRegionSnip()
        }
        snipToolBtn = snipBtn

        val parkBtn = trayToolChip("⇥ Edge Handle", "park_edge_btn") {
            parkToEdge(AgyEdgeHandleOverlayManager.EdgeSide.RIGHT)
        }
        edgeParkToolBtn = parkBtn

        val trayRow3 = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = (4 * d).toInt() }
        }

        val recBtn = trayToolChip("⏺ Record", "demo_record_toggle_btn") {
            if (demoRecorderManager.isRecording()) {
                demoRecorderManager.stopRecording()
            } else {
                demoRecorderManager.startRecording("Teach Agy Demo")
            }
            _hudState.value = _hudState.value.copy(demoSession = demoRecorderManager.currentSession())
            renderHudWindow()
        }
        demoToolBtn = recBtn

        val padBtn = trayToolChip("📋 Pad", "scratchpad_toggle_btn") {
            isScratchpadDrawerOpen = !isScratchpadDrawerOpen
            if (isScratchpadDrawerOpen) {
                scratchpadManager.startClipboardMonitoring()
                if (scratchpadManager.currentItems().isEmpty()) {
                    scratchpadManager.captureSystemClipboard()
                }
            }
            renderHudWindow()
        }
        scratchpadToolBtn = padBtn

        val diffBtn = trayToolChip("👁 Diff", "watchdog_toggle_btn") {
            val curWd = screenWatchdogManager.currentWatchdog()
            if (curWd.active) {
                screenWatchdogManager.disarmWatchdog()
            } else {
                screenWatchdogManager.armWatchdog(
                    AgyHudDynamicModels.ScreenWatchdogConfig(
                        id = "wd_${System.currentTimeMillis() % 100000}",
                        active = true,
                        rule = "any_change",
                        region = _attachedRegionContextFlow.value
                    )
                )
            }
            _hudState.value = _hudState.value.copy(watchdog = screenWatchdogManager.currentWatchdog())
            renderHudWindow()
        }
        watchdogToolBtn = diffBtn

        val vcpBtn = trayToolChip("🔊 Voice", "voice_copilot_toggle_btn") {
            voiceCoPilotManager.toggleEnabled()
            _hudState.value = _hudState.value.copy(voiceCoPilot = voiceCoPilotManager.currentConfig())
            renderHudWindow()
        }
        voiceCoPilotToolBtn = vcpBtn

        trayRow1.addView(opBtn)
        trayRow1.addView(wfBtn)
        trayRow1.addView(ghBtn)
        trayRow1.addView(snapBtn)
        trayRow1.addView(ptrBtn)
        trayRow2.addView(snipBtn)
        trayRow2.addView(parkBtn)
        trayRow3.addView(recBtn)
        trayRow3.addView(padBtn)
        trayRow3.addView(diffBtn)
        trayRow3.addView(vcpBtn)
        tray.addView(trayRow1)
        tray.addView(trayRow2)
        tray.addView(trayRow3)
        toolsTrayContainer = tray
        container.addView(tray)

        // Task Title
        val titleTv = TextView(context).apply {
            text = "Agy Ready"
            textSize = 14f
            setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
            setTextColor(COLOR_TEXT_PRIMARY)
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = (9 * d).toInt() }
        }
        titleText = titleTv
        container.addView(titleTv)

        // Quiet Question Prompt Banner (visible on NEEDS_INPUT)
        val questionTv = TextView(context).apply {
            textSize = 11.5f
            setTextColor(Color.parseColor("#B45309"))
            setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
            setPadding((10 * d).toInt(), (7 * d).toInt(), (10 * d).toInt(), (7 * d).toInt())
            background = createLiquidGlassDrawable(
                fillColor = Color.parseColor("#FEF3C7"),
                strokeColor = Color.parseColor("#FDE68A"),
                radiusDp = 12f,
                strokeDp = 0.8f
            )
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = (7 * d).toInt() }
            visibility = View.GONE
            setOnClickListener { focusInlineComposerInternal(requestKeyboardFocus = true) }
        }
        questionBannerText = questionTv
        container.addView(questionTv)

        // Interactive Safety Approval Gate Card (Approve / Edit / Deny with risk badge & countdown)
        val approvalBox = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((10 * d).toInt(), (9 * d).toInt(), (10 * d).toInt(), (9 * d).toInt())
            background = createLiquidGlassDrawable(
                fillColor = Color.parseColor("#FFFBEB"),
                strokeColor = Color.parseColor("#F59E0B"),
                radiusDp = 14f,
                strokeDp = 1.1f
            )
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = (8 * d).toInt() }
            contentDescription = "${HUD_NODE_TAG_PREFIX}approval_gate_card"
            visibility = View.GONE
        }
        val approvalTopRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }
        val riskTv = TextView(context).apply {
            text = "MEDIUM RISK"
            textSize = 9.5f
            setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
            setTextColor(Color.WHITE)
            setPadding((7 * d).toInt(), (2 * d).toInt(), (7 * d).toInt(), (2 * d).toInt())
            background = createLiquidGlassDrawable(
                fillColor = COLOR_AMBER,
                strokeColor = Color.TRANSPARENT,
                radiusDp = 999f,
                strokeDp = 0f
            )
        }
        approvalRiskBadgeText = riskTv
        val riskSpacer = View(context).apply {
            layoutParams = LinearLayout.LayoutParams(0, 1, 1f)
        }
        val apprTimerTv = TextView(context).apply {
            textSize = 10f
            typeface = Typeface.MONOSPACE
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(COLOR_AMBER)
            visibility = View.GONE
        }
        approvalTimerBadgeText = apprTimerTv
        approvalTopRow.addView(riskTv)
        approvalTopRow.addView(riskSpacer)
        approvalTopRow.addView(apprTimerTv)
        approvalBox.addView(approvalTopRow)

        val apprTitleTv = TextView(context).apply {
            text = "Confirm Action"
            textSize = 12.5f
            setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
            setTextColor(COLOR_TEXT_PRIMARY)
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = (5 * d).toInt() }
        }
        approvalTitleText = apprTitleTv
        approvalBox.addView(apprTitleTv)

        val apprDescTv = TextView(context).apply {
            textSize = 11f
            setTextColor(COLOR_TEXT_SECONDARY)
            maxLines = 3
            ellipsize = TextUtils.TruncateAt.END
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = (2 * d).toInt() }
            visibility = View.GONE
        }
        approvalDescText = apprDescTv
        approvalBox.addView(apprDescTv)

        val apprPreviewTv = TextView(context).apply {
            textSize = 10.5f
            typeface = Typeface.MONOSPACE
            setTextColor(Color.parseColor("#E2E8F0"))
            setPadding((8 * d).toInt(), (6 * d).toInt(), (8 * d).toInt(), (6 * d).toInt())
            background = createLiquidGlassDrawable(
                fillColor = Color.parseColor("#0F172A"),
                strokeColor = Color.parseColor("#334155"),
                radiusDp = 9f,
                strokeDp = 0.8f
            )
            maxLines = 3
            ellipsize = TextUtils.TruncateAt.END
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = (6 * d).toInt() }
            visibility = View.GONE
        }
        approvalPreviewText = apprPreviewTv
        approvalBox.addView(apprPreviewTv)

        val apprActionsRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = (8 * d).toInt() }
        }

        fun approvalActionPill(
            label: String,
            desc: String,
            fill: Int,
            textColor: Int,
            stroke: Int = Color.TRANSPARENT,
            weight: Float = 1f,
            onClick: () -> Unit
        ): TextView {
            return TextView(context).apply {
                text = label
                textSize = 11f
                setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
                setTextColor(textColor)
                gravity = Gravity.CENTER
                minHeight = (38 * d).toInt()
                setPadding((8 * d).toInt(), (7 * d).toInt(), (8 * d).toInt(), (7 * d).toInt())
                background = createLiquidGlassDrawable(
                    fillColor = fill,
                    strokeColor = stroke,
                    radiusDp = 999f,
                    strokeDp = if (stroke == Color.TRANSPARENT) 0f else 0.9f
                )
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, weight).apply {
                    marginEnd = (5 * d).toInt()
                }
                contentDescription = "${HUD_NODE_TAG_PREFIX}$desc"
                attachSpringPressFeedback(0.94f)
                setOnClickListener { onClick() }
            }
        }

        val approveBtn = approvalActionPill("✓ Approve", "approval_approve_btn", COLOR_EMERALD, Color.WHITE) {
            respondToApproval(decision = "approve")
        }
        approvalApproveBtn = approveBtn

        val editBtn = approvalActionPill("✎ Edit", "approval_edit_btn", Color.WHITE, COLOR_TEXT_PRIMARY, COLOR_HAIRLINE, 0.85f) {
            val gate = _hudState.value.approvalGate
            pendingEditApprovalId = gate.id
            val prefill = gate.editableText.ifBlank { gate.commandPreview }
            inputEditText?.setText(prefill)
            inputEditText?.setSelection(prefill.length)
            focusInlineComposerInternal(requestKeyboardFocus = true)
            updateInlineComposerControls()
        }
        approvalEditBtn = editBtn

        val denyBtn = approvalActionPill("✕ Deny", "approval_deny_btn", COLOR_CORAL, Color.WHITE) {
            respondToApproval(decision = "deny")
        }.apply {
            (layoutParams as LinearLayout.LayoutParams).marginEnd = 0
        }
        approvalDenyBtn = denyBtn

        apprActionsRow.addView(approveBtn)
        apprActionsRow.addView(editBtn)
        apprActionsRow.addView(denyBtn)
        approvalBox.addView(apprActionsRow)
        approvalCardContainer = approvalBox
        container.addView(approvalBox)

        // ---------------------------------------------------------------------
        // Advanced Suite Inline Cards:
        // 1. Demonstration Recorder Strip (`agy_hud_demo_recorder_card`)
        // 2. Smart Clipboard & Scratchpad Drawer (`agy_hud_scratchpad_card`)
        // 3. Live Screen Diff Watchdog Status Card (`agy_hud_watchdog_card`)
        // ---------------------------------------------------------------------

        val demoBox = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((9 * d).toInt(), (7 * d).toInt(), (9 * d).toInt(), (7 * d).toInt())
            background = createLiquidGlassDrawable(
                fillColor = Color.parseColor("#FFF1F2"),
                strokeColor = COLOR_CORAL,
                radiusDp = 12f,
                strokeDp = 0.95f
            )
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = (7 * d).toInt() }
            contentDescription = "${HUD_NODE_TAG_PREFIX}demo_recorder_card"
            visibility = View.GONE
        }
        val demoHeader = TextView(context).apply {
            text = "⏺ Recording Demo (0 steps)"
            textSize = 10.5f
            setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
            setTextColor(COLOR_CORAL)
        }
        demoRecorderHeaderText = demoHeader
        val demoStepsList = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = (3 * d).toInt() }
        }
        demoRecorderStepsContainer = demoStepsList
        val demoBtnRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = (6 * d).toInt() }
        }
        fun demoActionChip(label: String, desc: String, fill: Int, fg: Int, onClick: () -> Unit): TextView {
            return TextView(context).apply {
                text = label
                textSize = 9.5f
                setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
                setTextColor(fg)
                gravity = Gravity.CENTER
                setPadding((7 * d).toInt(), (4 * d).toInt(), (7 * d).toInt(), (4 * d).toInt())
                background = createLiquidGlassDrawable(
                    fillColor = fill,
                    strokeColor = COLOR_HAIRLINE,
                    radiusDp = 999f,
                    strokeDp = 0.7f
                )
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { marginEnd = (5 * d).toInt() }
                contentDescription = "${HUD_NODE_TAG_PREFIX}$desc"
                setOnClickListener { onClick() }
            }
        }
        demoBtnRow.addView(
            demoActionChip("+ Step", "demo_capture_step_btn", Color.WHITE, COLOR_TEXT_PRIMARY) {
                if (!demoRecorderManager.isRecording()) {
                    demoRecorderManager.startRecording("Teach Agy Demo")
                }
                val captured = demoRecorderManager.captureBestVisibleNodeStep()
                if (captured == null) {
                    demoRecorderManager.recordStep(actionType = "TAP", x = 540, y = 1200, explicitNodeLabel = "Screen Action")
                }
                _hudState.value = _hudState.value.copy(demoSession = demoRecorderManager.currentSession())
                renderHudWindow()
            }
        )
        demoBtnRow.addView(
            demoActionChip("🤖 Teach Agy", "demo_send_btn", COLOR_CYAN, Color.WHITE) {
                finishAndSendDemoToAgy()
            }
        )
        demoBtnRow.addView(
            demoActionChip("★ Macro", "demo_macro_btn", COLOR_VIOLET, Color.WHITE) {
                saveDemoAsMacro()
            }
        )
        demoBtnRow.addView(
            demoActionChip("✕", "demo_clear_btn", Color.WHITE, COLOR_CORAL) {
                demoRecorderManager.clearRecording()
                _hudState.value = _hudState.value.copy(demoSession = demoRecorderManager.currentSession())
                renderHudWindow()
            }
        )
        demoBox.addView(demoHeader)
        demoBox.addView(demoStepsList)
        demoBox.addView(demoBtnRow)
        demoRecorderCardContainer = demoBox
        container.addView(demoBox)

        // Smart Scratchpad Drawer Card
        val padBox = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((9 * d).toInt(), (7 * d).toInt(), (9 * d).toInt(), (7 * d).toInt())
            background = createLiquidGlassDrawable(
                fillColor = Color.parseColor("#F8FAFC"),
                strokeColor = COLOR_HAIRLINE,
                radiusDp = 12f,
                strokeDp = 0.85f
            )
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = (7 * d).toInt() }
            contentDescription = "${HUD_NODE_TAG_PREFIX}scratchpad_card"
            visibility = View.GONE
        }
        val padTopRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }
        val padHeaderTv = TextView(context).apply {
            text = "📋 Smart Scratchpad (0)"
            textSize = 10.5f
            setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
            setTextColor(COLOR_VIOLET)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        scratchpadHeaderText = padHeaderTv
        val padCaptureClipBtn = demoActionChip("+ Clip", "scratchpad_capture_btn", Color.WHITE, COLOR_CYAN) {
            scratchpadManager.captureSystemClipboard()
            _hudState.value = _hudState.value.copy(scratchpadItems = scratchpadManager.currentItems())
            renderHudWindow()
        }
        val padCloseBtn = demoActionChip("✕", "scratchpad_close_btn", Color.WHITE, COLOR_TEXT_SECONDARY) {
            isScratchpadDrawerOpen = false
            renderHudWindow()
        }
        padTopRow.addView(padHeaderTv)
        padTopRow.addView(padCaptureClipBtn)
        padTopRow.addView(padCloseBtn)
        val padList = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = (4 * d).toInt() }
        }
        scratchpadListContainer = padList
        padBox.addView(padTopRow)
        padBox.addView(padList)
        scratchpadCardContainer = padBox
        container.addView(padBox)

        // Live Screen Diff Watchdog Status Card
        val wdBox = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding((9 * d).toInt(), (6 * d).toInt(), (8 * d).toInt(), (6 * d).toInt())
            background = createLiquidGlassDrawable(
                fillColor = Color.parseColor("#ECFDF5"),
                strokeColor = COLOR_EMERALD,
                radiusDp = 12f,
                strokeDp = 0.85f
            )
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = (7 * d).toInt() }
            contentDescription = "${HUD_NODE_TAG_PREFIX}watchdog_card"
            visibility = View.GONE
        }
        val wdStatusTv = TextView(context).apply {
            text = "👁 Watchdog: any UI change"
            textSize = 10f
            setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
            setTextColor(COLOR_EMERALD)
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        watchdogStatusText = wdStatusTv
        val wdCheckBtn = demoActionChip("Check", "watchdog_check_btn", Color.WHITE, COLOR_EMERALD) {
            evaluateWatchdogNow()
        }
        val wdClearBtn = demoActionChip("✕", "watchdog_clear_btn", Color.WHITE, COLOR_CORAL) {
            clearWatchdog()
        }
        wdBox.addView(wdStatusTv)
        wdBox.addView(wdCheckBtn)
        wdBox.addView(wdClearBtn)
        watchdogCardContainer = wdBox
        container.addView(wdBox)

        // Doing Now row + animated 3 bouncing dots
        val doingRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = (4 * d).toInt() }
            visibility = View.GONE
        }
        val doingTv = TextView(context).apply {
            textSize = 11.5f
            setTypeface(Typeface.SANS_SERIF, Typeface.NORMAL)
            setTextColor(COLOR_TEXT_SECONDARY)
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        val bounceDots = AgyBouncingDotsView(context).apply {
            setAccentColor(COLOR_CYAN)
            layoutParams = LinearLayout.LayoutParams(
                (22 * d).toInt(),
                (12 * d).toInt()
            ).apply { marginStart = (4 * d).toInt() }
            visibility = View.GONE
        }
        doingRow.addView(doingTv)
        doingRow.addView(bounceDots)
        doingRowContainer = doingRow
        currentActionText = doingTv
        doingDotsView = bounceDots
        container.addView(doingRow)

        val nextTv = TextView(context).apply {
            textSize = 10.5f
            setTypeface(Typeface.SANS_SERIF, Typeface.NORMAL)
            setTextColor(COLOR_TEXT_SECONDARY)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = (2 * d).toInt() }
            visibility = View.GONE
        }
        nextActionText = nextTv
        container.addView(nextTv)

        // Dynamic Progress Strip (determinate 0..100% or labeled indeterminate)
        val progRow = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = (7 * d).toInt() }
            visibility = View.GONE
        }
        val progCaption = TextView(context).apply {
            textSize = 10.5f
            typeface = Typeface.MONOSPACE
            setTextColor(COLOR_TEXT_SECONDARY)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = (4 * d).toInt() }
        }
        val progBar = AgyLoadingBarView(context).apply {
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                (5 * d).toInt().coerceAtLeast(5)
            )
        }
        progRow.addView(progCaption)
        progRow.addView(progBar)
        progressRowContainer = progRow
        progressCaptionText = progCaption
        progressBarView = progBar
        container.addView(progRow)

        // Dynamic Live Metrics Strip (horizontal compact stat chips)
        val metricsRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        metricsContainer = metricsRow
        val metricsScroll = HorizontalScrollView(context).apply {
            isHorizontalScrollBarEnabled = false
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = (7 * d).toInt() }
            addView(metricsRow)
            visibility = View.GONE
        }
        metricsScrollView = metricsScroll
        container.addView(metricsScroll)

        // Dynamic Alert / Status Banner (info | success | warning | error)
        val bannerBox = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((10 * d).toInt(), (7 * d).toInt(), (10 * d).toInt(), (7 * d).toInt())
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = (7 * d).toInt() }
            visibility = View.GONE
        }
        val bannerTitleTv = TextView(context).apply {
            textSize = 11f
            setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        val bannerMsgTv = TextView(context).apply {
            textSize = 11f
            maxLines = 3
            ellipsize = TextUtils.TruncateAt.END
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = (1 * d).toInt() }
        }
        bannerBox.addView(bannerTitleTv)
        bannerBox.addView(bannerMsgTv)
        dynamicBannerContainer = bannerBox
        dynamicBannerTitleText = bannerTitleTv
        dynamicBannerMsgText = bannerMsgTv
        container.addView(bannerBox)

        // Dynamic Inline Custom Blocks (kv | code | text | progress with inDetails == false)
        val inlineBlocks = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            visibility = View.GONE
        }
        inlineBlocksContainer = inlineBlocks
        container.addView(inlineBlocks)

        // Collapsible Telemetry Details Wrapper (auto-compacts smoothly when the soft keyboard is open!)
        val telemetryWrap = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }
        telemetryDetailsContainer = telemetryWrap
        container.addView(telemetryWrap)

        // Dynamic Detail Custom Blocks (inDetails == true)
        val detailBlocks = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            visibility = View.GONE
        }
        detailBlocksContainer = detailBlocks
        telemetryWrap.addView(detailBlocks)

        // Clean Airy Task List Container inside compact ScrollView (with per-task real/vector icons)
        val tasksLayout = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }
        taskListContainer = tasksLayout

        val scroll = ScrollView(context).apply {
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = (8 * d).toInt() }
            isVerticalScrollBarEnabled = false
            addView(tasksLayout)
            visibility = View.GONE
        }
        taskScrollView = scroll
        telemetryWrap.addView(scroll)

        // Quiet Neutral Expandable Detailed Output Drawer inside Working Card
        val outSection = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = (8 * d).toInt() }
            visibility = View.GONE
        }

        val outToggleTv = TextView(context).apply {
            text = "Output ▾"
            textSize = 11f
            setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
            setTextColor(COLOR_TEXT_PRIMARY)
            setPadding((10 * d).toInt(), (6 * d).toInt(), (10 * d).toInt(), (6 * d).toInt())
            background = createLiquidGlassDrawable(
                fillColor = Color.parseColor("#F3F4F6"),
                strokeColor = COLOR_HAIRLINE,
                radiusDp = 12f,
                strokeDp = 0.7f
            )
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            contentDescription = "${HUD_NODE_TAG_PREFIX}toggle_output_btn"
            setOnClickListener { setOutputExpanded(!isOutputExpanded) }
        }
        outputToggleHeaderText = outToggleTv

        val outDrawer = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((10 * d).toInt(), (8 * d).toInt(), (10 * d).toInt(), (8 * d).toInt())
            background = createLiquidGlassDrawable(
                fillColor = Color.parseColor("#F8FAFC"),
                strokeColor = COLOR_HAIRLINE,
                radiusDp = 12f,
                strokeDp = 0.7f
            )
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = (5 * d).toInt() }
            visibility = View.GONE
        }

        val outToolbar = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = (5 * d).toInt() }
        }

        val outMetaLbl = TextView(context).apply {
            text = "OUTPUT & LOGS"
            textSize = 9f
            typeface = Typeface.MONOSPACE
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(COLOR_TEXT_SECONDARY)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }

        val copyBtn = TextView(context).apply {
            text = "Copy"
            textSize = 9.5f
            setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
            setTextColor(COLOR_CYAN)
            setPadding((9 * d).toInt(), (3 * d).toInt(), (9 * d).toInt(), (3 * d).toInt())
            background = createLiquidGlassDrawable(
                fillColor = Color.WHITE,
                strokeColor = COLOR_HAIRLINE,
                radiusDp = 999f,
                strokeDp = 0.8f
            )
            contentDescription = "${HUD_NODE_TAG_PREFIX}copy_output_btn"
            setOnClickListener { copyDetailedOutputToClipboard() }
        }
        outputCopyBtn = copyBtn
        outToolbar.addView(outMetaLbl)
        outToolbar.addView(copyBtn)

        val outBody = TextView(context).apply {
            textSize = 10f
            typeface = Typeface.MONOSPACE
            setTextColor(COLOR_TEXT_PRIMARY)
            setLineSpacing(2f * d, 1.0f)
        }
        outputBodyText = outBody

        val outScroll = ScrollView(context).apply {
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                (128 * d).toInt()
            )
            isVerticalScrollBarEnabled = true
            addView(outBody)
        }

        outDrawer.addView(outToolbar)
        outDrawer.addView(outScroll)
        outputDrawerContainer = outDrawer

        outSection.addView(outToggleTv)
        outSection.addView(outDrawer)
        outputSectionContainer = outSection
        telemetryWrap.addView(outSection)

        // Contextual Quick Action Chips Strip
        val qaRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        quickActionsContainer = qaRow

        val qaScroll = HorizontalScrollView(context).apply {
            isHorizontalScrollBarEnabled = false
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = (7 * d).toInt() }
            addView(qaRow)
            visibility = View.GONE
        }
        quickActionsScrollView = qaScroll
        telemetryWrap.addView(qaScroll)

        // ---------------------------------------------------------------------
        // Built-In Gemini Bottom Composer Dock (Unified Inside Single HUD Card)
        // ---------------------------------------------------------------------
        val composerDivider = View(context).apply {
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                (0.85f * d).toInt().coerceAtLeast(1)
            ).apply {
                topMargin = (10 * d).toInt()
                bottomMargin = (8 * d).toInt()
            }
            setBackgroundColor(COLOR_HAIRLINE)
        }
        container.addView(composerDivider)

        val composerBox = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }
        inlineComposerContainer = composerBox

        // Ordered Prompt Queue Strip (shown when user queues follow-ups while WORKING/PAUSED)
        val queueBox = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((8 * d).toInt(), (6 * d).toInt(), (8 * d).toInt(), (6 * d).toInt())
            background = createLiquidGlassDrawable(
                fillColor = Color.parseColor("#F1F5F9"),
                strokeColor = COLOR_HAIRLINE,
                radiusDp = 12f,
                strokeDp = 0.8f
            )
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = (6 * d).toInt() }
            contentDescription = "${HUD_NODE_TAG_PREFIX}prompt_queue_strip"
            visibility = View.GONE
        }
        val queueHeader = TextView(context).apply {
            text = "Queued (0)"
            textSize = 10f
            setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
            setTextColor(COLOR_VIOLET)
        }
        promptQueueHeaderText = queueHeader
        val queueList = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = (4 * d).toInt() }
        }
        promptQueueListContainer = queueList
        queueBox.addView(queueHeader)
        queueBox.addView(queueList)
        promptQueueContainer = queueBox
        composerBox.addView(queueBox)

        // Removable Attached Region Snip Context Pill
        val regionPillRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding((10 * d).toInt(), (5 * d).toInt(), (8 * d).toInt(), (5 * d).toInt())
            background = createLiquidGlassDrawable(
                fillColor = Color.parseColor("#E0F2FE"),
                strokeColor = Color.parseColor("#38BDF8"),
                radiusDp = 999f,
                strokeDp = 0.9f
            )
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = (6 * d).toInt() }
            contentDescription = "${HUD_NODE_TAG_PREFIX}attached_region_pill"
            visibility = View.GONE
        }
        val regionLabelTv = TextView(context).apply {
            text = "✂ Region"
            textSize = 10.5f
            setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
            setTextColor(Color.parseColor("#0369A1"))
        }
        attachedRegionChipText = regionLabelTv
        val regionClearBtn = TextView(context).apply {
            text = "✕"
            textSize = 11f
            setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
            setTextColor(Color.parseColor("#0369A1"))
            setPadding((8 * d).toInt(), (2 * d).toInt(), (4 * d).toInt(), (2 * d).toInt())
            contentDescription = "${HUD_NODE_TAG_PREFIX}clear_region_btn"
            setOnClickListener { attachRegionContext(null) }
        }
        regionPillRow.addView(regionLabelTv)
        regionPillRow.addView(regionClearBtn)
        attachedRegionChipRow = regionPillRow
        composerBox.addView(regionPillRow)

        // App-Aware Smart Suggestion Chips + One-Tap Run-to-Macro Bar
        val sugRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        smartSuggestionsContainer = sugRow
        val sugScroll = HorizontalScrollView(context).apply {
            isHorizontalScrollBarEnabled = false
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = (6 * d).toInt() }
            addView(sugRow)
            contentDescription = "${HUD_NODE_TAG_PREFIX}smart_suggestions_bar"
            visibility = View.GONE
        }
        smartSuggestionsScrollView = sugScroll
        composerBox.addView(sugScroll)

        // Horizontal Pinned Macros / Saved Workflow Shortcuts right above the text field
        val macroRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        inputMacrosContainer = macroRow
        val macroScroll = HorizontalScrollView(context).apply {
            isHorizontalScrollBarEnabled = false
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = (7 * d).toInt() }
            addView(macroRow)
            visibility = View.GONE
        }
        inputMacrosScrollView = macroScroll
        composerBox.addView(macroScroll)
        renderInputMacrosStrip()

        // Optional Voice Listening / Error Micro-Banner
        val voiceHintTv = TextView(context).apply {
            text = "● Listening…"
            textSize = 10f
            typeface = Typeface.MONOSPACE
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(COLOR_CORAL)
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = (5 * d).toInt()
                marginStart = (4 * d).toInt()
            }
            visibility = View.GONE
        }
        composerVoiceStatusHint = voiceHintTv
        composerBox.addView(voiceHintTv)

        // Gemini-style Integrated Bottom Text Field Capsule: [Mic] [Ask Agy…] [Paste/Clear] [↑ / ■]
        val capsule = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding((5 * d).toInt(), (4 * d).toInt(), (5 * d).toInt(), (4 * d).toInt())
            background = createLiquidGlassDrawable(
                fillColor = Color.parseColor("#F5F7FA"),
                strokeColor = COLOR_HAIRLINE,
                radiusDp = 999f,
                strokeDp = 1.0f
            )
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }
        composerInputCapsule = capsule

        val micBtn = AgyGlyphButtonView(context, AgyGlyphButtonView.Glyph.MIC).apply {
            val sz = (32 * d).toInt()
            layoutParams = LinearLayout.LayoutParams(sz, sz).apply { marginEnd = (4 * d).toInt() }
            setStyle(
                glyph = AgyGlyphButtonView.Glyph.MIC,
                bgFill = Color.WHITE,
                bgStroke = COLOR_HAIRLINE,
                iconTint = COLOR_TEXT_SECONDARY,
                strokeDp = 0.85f
            )
            contentDescription = "${HUD_NODE_TAG_PREFIX}voice_mic_btn"
            attachSpringPressFeedback(0.92f)
            setOnClickListener {
                cancelAutoCollapse()
                toggleVoiceDictationInternal()
            }
        }
        inputMicBtn = micBtn

        val editText = EditText(context).apply {
            hint = "Ask Agy…"
            setHintTextColor(Color.parseColor("#94A3B8"))
            setTextColor(COLOR_TEXT_PRIMARY)
            textSize = 12.5f
            isSingleLine = true
            imeOptions = EditorInfo.IME_ACTION_SEND
            setPadding((6 * d).toInt(), (7 * d).toInt(), (4 * d).toInt(), (7 * d).toInt())
            background = null
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            contentDescription = "${HUD_NODE_TAG_PREFIX}prompt_input"

            setOnTouchListener { _, ev ->
                if (ev.action == MotionEvent.ACTION_UP || ev.action == MotionEvent.ACTION_DOWN) {
                    cancelAutoCollapse()
                    acquireInputFocusFromTermux()
                }
                false
            }

            setOnEditorActionListener { _, actionId, event ->
                if (actionId == EditorInfo.IME_ACTION_SEND ||
                    (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER && event.action == KeyEvent.ACTION_DOWN)
                ) {
                    submitPromptFromInput()
                    true
                } else {
                    false
                }
            }

            addTextChangedListener(object : android.text.TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                    updateInlineComposerControls()
                }
                override fun afterTextChanged(s: android.text.Editable?) {}
            })
        }
        inputEditText = editText

        val clearBtn = AgyGlyphButtonView(context, AgyGlyphButtonView.Glyph.CLEAR_X).apply {
            val sz = (22 * d).toInt()
            layoutParams = LinearLayout.LayoutParams(sz, sz).apply { marginEnd = (4 * d).toInt() }
            setStyle(
                glyph = AgyGlyphButtonView.Glyph.CLEAR_X,
                bgFill = Color.parseColor("#E5E9F0"),
                bgStroke = Color.TRANSPARENT,
                iconTint = COLOR_TEXT_SECONDARY,
                strokeDp = 0f
            )
            contentDescription = "${HUD_NODE_TAG_PREFIX}clear_draft_btn"
            visibility = View.GONE
            attachSpringPressFeedback(0.90f)
            setOnClickListener {
                inputEditText?.setText("")
                updateInlineComposerControls()
            }
        }
        clearDraftBtn = clearBtn

        val boltBtn = AgyGlyphButtonView(context, AgyGlyphButtonView.Glyph.BOLT).apply {
            val sz = (30 * d).toInt()
            layoutParams = LinearLayout.LayoutParams(sz, sz).apply { marginEnd = (4 * d).toInt() }
            setStyle(
                glyph = AgyGlyphButtonView.Glyph.BOLT,
                bgFill = Color.WHITE,
                bgStroke = COLOR_HAIRLINE,
                iconTint = COLOR_TEXT_SECONDARY,
                strokeDp = 0.8f
            )
            contentDescription = "${HUD_NODE_TAG_PREFIX}macros_toggle_btn"
            attachSpringPressFeedback(0.92f)
            setOnClickListener {
                cancelAutoCollapse()
                isMacrosDrawerOpen = !isMacrosDrawerOpen
                renderInputMacrosStrip()
                updateInlineComposerControls()
            }
        }
        macrosToggleBtn = boltBtn

        // Morphing Trailing Action Orb: ↑ Send when typing/idle, ■ Stop (Stage 1) / Force-Stop (Stage 2) when running
        val actionOrb = AgyGlyphButtonView(context, AgyGlyphButtonView.Glyph.SEND_UP).apply {
            val sz = (36 * d).toInt()
            layoutParams = LinearLayout.LayoutParams(sz, sz)
            setStyle(
                glyph = AgyGlyphButtonView.Glyph.SEND_UP,
                bgFill = COLOR_CYAN,
                bgStroke = COLOR_CYAN,
                iconTint = Color.WHITE,
                strokeDp = 0.8f
            )
            contentDescription = "${HUD_NODE_TAG_PREFIX}send_btn"
            attachSpringPressFeedback(0.88f)
            setOnClickListener {
                try {
                    performHapticFeedback(android.view.HapticFeedbackConstants.VIRTUAL_KEY)
                } catch (_: Exception) {}
                val draft = inputEditText?.text?.toString()?.trim().orEmpty()
                val st = _hudState.value.state
                if (draft.isNotEmpty()) {
                    submitPromptFromInput()
                } else if (st == "WORKING" || st == "PAUSED" || st == "NEEDS_INPUT" || st == "STOPPING") {
                    cancelAutoCollapse()
                    handleRemoteCommand(JSONObject().put("action", "STOP"))
                    releaseInputFocusToTermux()
                } else {
                    acquireInputFocusFromTermux()
                }
            }
        }
        composerActionBtn = actionOrb

        // Quick Region Snip trigger button inside composer capsule
        val snipCapsuleBtn = TextView(context).apply {
            text = "✂"
            textSize = 13f
            gravity = Gravity.CENTER
            setTextColor(COLOR_TEXT_SECONDARY)
            val sz = (30 * d).toInt()
            layoutParams = LinearLayout.LayoutParams(sz, sz).apply { marginEnd = (4 * d).toInt() }
            background = createLiquidGlassDrawable(
                fillColor = Color.WHITE,
                strokeColor = COLOR_HAIRLINE,
                radiusDp = 999f,
                strokeDp = 0.8f
            )
            contentDescription = "${HUD_NODE_TAG_PREFIX}composer_snip_btn"
            attachSpringPressFeedback(0.92f)
            setOnClickListener {
                cancelAutoCollapse()
                startRegionSnip()
            }
        }
        composerSnipBtn = snipCapsuleBtn

        capsule.addView(micBtn)
        capsule.addView(editText)
        capsule.addView(clearBtn)
        capsule.addView(snipCapsuleBtn)
        capsule.addView(boltBtn)
        capsule.addView(actionOrb)
        // Expand Stop/Send orb hit target to at least 48dp inside the capsule for effortless thumb taps
        capsule.post {
            val hitRect = Rect()
            actionOrb.getHitRect(hitRect)
            val pad = (10 * d).toInt()
            hitRect.inset(-pad, -pad)
            capsule.touchDelegate = android.view.TouchDelegate(hitRect, actionOrb)
        }
        composerBox.addView(capsule)
        container.addView(composerBox)

        return container
    }

    /**
     * Compact Collapsed Pill shown ONLY when the unified card is collapsed (`isCollapsed == true`):
     * - When WORKING or PAUSED: live step pill [App Icon + Ring] [Marquee Step] [Timer] [■ Stop / ▶ Resume].
     * - When IDLE / DONE / NEEDS_INPUT: clean [Status | ✦ Ask Agy] pill that spring-expands into the
     *   unified Gemini card with its built-in bottom text field.
     */
    private fun buildBottomChatDockRow(d: Float): LinearLayout {
        val screenW = context.resources.displayMetrics.widthPixels.coerceAtLeast(360)
        val dock = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding((10 * d).toInt(), (6 * d).toInt(), (6 * d).toInt(), (6 * d).toInt())
            background = createLiquidGlassDrawable(
                fillColor = COLOR_OBSIDIAN_GLASS,
                strokeColor = COLOR_HAIRLINE,
                radiusDp = 999f,
                strokeDp = 1.0f
            )
            elevation = 10f * d
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            layoutTransition = LayoutTransition().apply {
                setDuration(200L)
                enableTransitionType(LayoutTransition.CHANGING)
            }
        }

        // --- Mode B: Standard Status + Ask Agy Collapsed Pill (Idle / Needs Input / Done) ---
        val statusGroup = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding((2 * d).toInt(), (3 * d).toInt(), (8 * d).toInt(), (3 * d).toInt())
            contentDescription = "${HUD_NODE_TAG_PREFIX}collapsed_expand_btn"
            attachSpringPressFeedback(0.96f)
            setOnClickListener {
                cancelAutoCollapse()
                val now = System.currentTimeMillis()
                val isDoubleTap = isCollapsed && (now - lastDockTapAtMs) in 1L..320L
                lastDockTapAtMs = now
                isCollapsed = false
                autoCollapsedByCoordinator = false
                userManuallyCollapsed = false
                _isInputVisible.value = true
                renderHudWindow()
                layoutCoordinator.notifyInteraction(
                    id = AgyOverlayLayoutCoordinator.ManagedWindowId.HUD,
                    priority = AgyOverlayLayoutCoordinator.InteractionPriority.USER_INTERACTED,
                    animate = true
                )
                if (isDoubleTap || _hudState.value.state == "IDLE" || _hudState.value.state == "NEEDS_INPUT") {
                    focusInlineComposerInternal(requestKeyboardFocus = true)
                }
            }
        }
        dockStandardStatusGroup = statusGroup

        val dSpinner = AgySpinnerRingView(context).apply {
            val sz = (13 * d).toInt()
            layoutParams = LinearLayout.LayoutParams(sz, sz).apply { marginEnd = (6 * d).toInt() }
            setAccentColor(COLOR_CYAN)
            visibility = View.GONE
        }
        dockSpinnerView = dSpinner

        val statusTv = TextView(context).apply {
            text = "○ Ready ▲"
            textSize = 11.5f
            setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
            setTextColor(COLOR_TEXT_PRIMARY)
            maxLines = 1
        }
        collapsedStatusText = statusTv

        statusGroup.addView(dSpinner)
        statusGroup.addView(statusTv)

        val divider = View(context).apply {
            layoutParams = LinearLayout.LayoutParams((1 * d).toInt(), (18 * d).toInt()).apply {
                marginEnd = (6 * d).toInt()
            }
            setBackgroundColor(COLOR_HAIRLINE)
        }
        dockStandardDivider = divider

        val askBtn = TextView(context).apply {
            text = "✦ Ask Agy"
            textSize = 11.5f
            setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
            setTextColor(Color.WHITE)
            setPadding((12 * d).toInt(), (6 * d).toInt(), (12 * d).toInt(), (6 * d).toInt())
            background = createLiquidGlassDrawable(
                fillColor = COLOR_CYAN,
                strokeColor = COLOR_CYAN,
                radiusDp = 999f,
                strokeDp = 0.8f
            )
            contentDescription = "${HUD_NODE_TAG_PREFIX}bottom_chat_pill_btn"
            attachSpringPressFeedback(0.94f)
            setOnClickListener {
                cancelAutoCollapse()
                isCollapsed = false
                autoCollapsedByCoordinator = false
                userManuallyCollapsed = false
                _isInputVisible.value = true
                renderHudWindow()
                layoutCoordinator.notifyInteraction(
                    id = AgyOverlayLayoutCoordinator.ManagedWindowId.HUD,
                    priority = AgyOverlayLayoutCoordinator.InteractionPriority.USER_INTERACTED,
                    animate = true
                )
                focusInlineComposerInternal(requestKeyboardFocus = true)
            }
        }
        bottomChatPillBtn = askBtn

        // --- Mode A: Live Collapsed Running/Paused Step Pill ---
        val liveGroup = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding((2 * d).toInt(), (1 * d).toInt(), (4 * d).toInt(), (1 * d).toInt())
            contentDescription = "${HUD_NODE_TAG_PREFIX}collapsed_live_step_btn"
            visibility = View.GONE
            attachSpringPressFeedback(0.96f)
            setOnClickListener {
                cancelAutoCollapse()
                isCollapsed = false
                autoCollapsedByCoordinator = false
                userManuallyCollapsed = false
                _isInputVisible.value = true
                renderHudWindow()
                layoutCoordinator.notifyInteraction(
                    id = AgyOverlayLayoutCoordinator.ManagedWindowId.HUD,
                    priority = AgyOverlayLayoutCoordinator.InteractionPriority.USER_INTERACTED,
                    animate = true
                )
            }
        }
        dockLiveStepGroup = liveGroup

        val badgeFrame = FrameLayout(context).apply {
            val outerSz = (26 * d).toInt()
            layoutParams = LinearLayout.LayoutParams(outerSz, outerSz).apply {
                marginEnd = (8 * d).toInt()
            }
        }
        val liveRing = AgySpinnerRingView(context).apply {
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            setAccentColor(COLOR_CYAN)
        }
        dockLiveSpinnerView = liveRing

        val liveIcon = AgyIconBadgeView(context).apply {
            val innerSz = (18 * d).toInt()
            layoutParams = FrameLayout.LayoutParams(innerSz, innerSz, Gravity.CENTER)
        }
        dockLiveIconView = liveIcon
        badgeFrame.addView(liveRing)
        badgeFrame.addView(liveIcon)

        val liveStepTv = TextView(context).apply {
            text = "Working"
            textSize = 12f
            setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
            setTextColor(COLOR_TEXT_PRIMARY)
            isSingleLine = true
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.MARQUEE
            marqueeRepeatLimit = -1
            isHorizontalFadingEdgeEnabled = true
            setFadingEdgeLength((14 * d).toInt())
            isSelected = true
            minWidth = (56 * d).toInt()
            maxWidth = min((168 * d).toInt(), (screenW * 0.45f).toInt())
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                marginEnd = (8 * d).toInt()
            }
        }
        dockLiveStepText = liveStepTv

        val liveTimerTv = TextView(context).apply {
            text = "00:00.0"
            textSize = 10.5f
            typeface = Typeface.MONOSPACE
            setTextColor(COLOR_TEXT_SECONDARY)
            maxLines = 1
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                marginEnd = (4 * d).toInt()
            }
        }
        dockLiveTimerText = liveTimerTv

        liveGroup.addView(badgeFrame)
        liveGroup.addView(liveStepTv)
        liveGroup.addView(liveTimerTv)

        val liveStopBtn = TextView(context).apply {
            text = "■"
            textSize = 11f
            setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
            setTextColor(COLOR_CORAL)
            gravity = Gravity.CENTER
            val sz = (32 * d).toInt()
            layoutParams = LinearLayout.LayoutParams(sz, sz).apply {
                marginStart = (2 * d).toInt()
            }
            background = createLiquidGlassDrawable(
                fillColor = Color.parseColor("#1AE11D48"),
                strokeColor = Color.parseColor("#44E11D48"),
                radiusDp = 999f,
                strokeDp = 0.85f
            )
            contentDescription = "${HUD_NODE_TAG_PREFIX}collapsed_stop_btn"
            visibility = View.GONE
            attachSpringPressFeedback(0.88f)
            setOnClickListener {
                try {
                    performHapticFeedback(android.view.HapticFeedbackConstants.VIRTUAL_KEY)
                } catch (_: Exception) {}
                cancelAutoCollapse()
                if (_hudState.value.state == "PAUSED") {
                    handleRemoteCommand(JSONObject().put("action", "RESUME"))
                } else {
                    handleRemoteCommand(JSONObject().put("action", "STOP"))
                }
            }
        }
        dockLiveStopBtn = liveStopBtn

        dock.addView(statusGroup)
        dock.addView(divider)
        dock.addView(askBtn)
        dock.addView(liveGroup)
        dock.addView(liveStopBtn)
        return dock
    }

    private fun applyDynamicWindowGeometryInternal(state: AgyHudState) {
        val d = density()
        val metrics = context.resources.displayMetrics
        val screenW = metrics.widthPixels.coerceAtLeast(360)
        val screenH = metrics.heightPixels.coerceAtLeast(640)
        val layout = state.layout

        // Dynamic card width fraction (default ~304dp capped at 90% width)
        hudExpandedContainer?.let { card ->
            val targetW = if (layout.widthFraction != null) {
                (screenW * layout.widthFraction.coerceIn(0.60f, 0.96f)).toInt()
            } else {
                min((304 * d).toInt(), (screenW * 0.90f).toInt())
            }
            val lp = card.layoutParams
            if (lp != null && lp.width != targetW) {
                lp.width = targetW
                card.layoutParams = lp
            }
        }

        // Dynamic screen anchor / x & y offsets when Agy explicitly sets position or fractions
        val params = hudParams ?: return
        val root = hudRootView ?: return
        if (isInputFocused) return
        var changed = false
        if (layout.position.isNotBlank() || layout.xFraction != null || layout.yFraction != null) {
            val vGravity = when (layout.position.lowercase()) {
                "top" -> Gravity.TOP
                "center" -> Gravity.CENTER_VERTICAL
                "bottom" -> Gravity.BOTTOM
                else -> Gravity.BOTTOM
            }
            val hGravity = when {
                layout.xFraction != null && layout.xFraction < 0.35f -> Gravity.START
                layout.xFraction != null && layout.xFraction > 0.65f -> Gravity.END
                layout.xFraction != null -> Gravity.CENTER_HORIZONTAL
                else -> Gravity.END
            }
            val nextGravity = vGravity or hGravity
            if (params.gravity != nextGravity) {
                params.gravity = nextGravity
                changed = true
            }
            if (layout.yFraction != null) {
                val targetY = ((1f - layout.yFraction).coerceIn(0.02f, 0.85f) * screenH).toInt()
                if (params.y != targetY) {
                    params.y = targetY
                    changed = true
                }
            } else if (layout.position == "top" && params.y < (32 * d).toInt()) {
                params.y = (42 * d).toInt()
                changed = true
            } else if (layout.position == "center") {
                params.y = 0
                changed = true
            }
            if (changed) {
                try {
                    windowManager?.updateViewLayout(root, params)
                } catch (_: Exception) {}
            }
        }
    }

    private fun renderHudWindow(scheduleReconcile: Boolean = true) {
        val state = _hudState.value
        val d = density()
        val alphaVal = state.theme.opacity ?: OPACITY_LEVELS[opacityIndex]
        val isWorking = state.state == "WORKING"
        val isPaused = state.state == "PAUSED"
        val isNeedsInput = state.state == "NEEDS_INPUT"
        val isStopping = state.state == "STOPPING"
        val isStopped = state.state == "STOPPED"
        val isDone = state.state == "DONE"
        val liveCollapsedMode = isCollapsedLiveRunningMode(state, isCollapsed)
        val baseStateAccent = when (state.state) {
            "WORKING" -> COLOR_CYAN
            "PAUSED", "NEEDS_INPUT" -> COLOR_AMBER
            "STOPPING", "STOPPED" -> COLOR_CORAL
            "DONE" -> COLOR_EMERALD
            else -> COLOR_VIOLET
        }
        val resolvedTheme = AgyHudDynamicModels.resolveTheme(state.theme, baseStateAccent)
        val accentColor = if (isStopping || isStopped) COLOR_CORAL else resolvedTheme.accent
        val layoutCfg = state.layout

        hudRootView?.alpha = if (ghostPassThrough) (alphaVal * 0.45f).coerceAtLeast(0.22f) else alphaVal
        hudRootView?.visibility = if (isTemporarilySuppressed) View.GONE else View.VISIBLE

        // Apply dynamic surface / border / aurora palette / corner radius directly to the card container
        hudExpandedContainer?.applyDynamicTheme(
            surfaceColor = resolvedTheme.surface,
            idleBorderColor = resolvedTheme.border,
            accentColor = accentColor,
            customAuroraColors = resolvedTheme.auroraIntColors,
            auroraEnabled = resolvedTheme.auroraEnabled,
            cornerRadiusDp = resolvedTheme.cornerRadiusDp
        )

        // Single Unified Gemini Morph: show EITHER the Expanded Card (with built-in bottom text field)
        // OR the compact Collapsed Pill, animated smoothly with Gemini spring physics!
        val collapseTransitioned = lastRenderedCollapsedState != null && lastRenderedCollapsedState != isCollapsed
        lastRenderedCollapsedState = isCollapsed

        hudExpandedContainer?.visibility = if (isCollapsed) View.GONE else View.VISIBLE
        hudBottomDockRow?.visibility = if (isCollapsed) View.VISIBLE else View.GONE
        val showDetailsDrawer = isDetailsExpanded && !isInputFocused
        telemetryDetailsContainer?.visibility = if (showDetailsDrawer) View.VISIBLE else View.GONE

        if (collapseTransitioned) {
            if (!isCollapsed) {
                hudExpandedContainer?.let { card ->
                    card.animate().cancel()
                    card.pivotX = card.width.takeIf { it > 0 }?.toFloat() ?: (280f * d)
                    card.pivotY = card.height.takeIf { it > 0 }?.toFloat() ?: (220f * d)
                    card.alpha = 0f
                    card.scaleX = 0.90f
                    card.scaleY = 0.86f
                    card.translationY = 14f * d
                    card.animate()
                        .alpha(1f)
                        .scaleX(1f)
                        .scaleY(1f)
                        .translationY(0f)
                        .setDuration(260L)
                        .setInterpolator(android.view.animation.OvershootInterpolator(0.85f))
                        .start()
                }
            } else {
                hudBottomDockRow?.let { pill ->
                    pill.animate().cancel()
                    pill.alpha = 0f
                    pill.scaleX = 0.90f
                    pill.scaleY = 0.90f
                    pill.animate()
                        .alpha(1f)
                        .scaleX(1f)
                        .scaleY(1f)
                        .setDuration(210L)
                        .setInterpolator(android.view.animation.OvershootInterpolator(0.95f))
                        .start()
                }
            }
        }

        // Flowing Gemini Aurora Shimmer Border + Focus/Voice/Stopping Halo on Unified Card
        hudExpandedContainer?.setRimMode(
            when {
                isCollapsed -> AgyAuroraCardLayout.RimMode.IDLE
                isStopping -> AgyAuroraCardLayout.RimMode.STOPPING
                isStopped -> AgyAuroraCardLayout.RimMode.STOPPED
                _isVoiceListeningFlow.value -> AgyAuroraCardLayout.RimMode.VOICE_LISTENING
                isWorking -> AgyAuroraCardLayout.RimMode.WORKING
                isNeedsInput -> AgyAuroraCardLayout.RimMode.NEEDS_INPUT
                isInputFocused -> AgyAuroraCardLayout.RimMode.INPUT_ACTIVE
                isPaused -> AgyAuroraCardLayout.RimMode.PAUSED
                isDone -> AgyAuroraCardLayout.RimMode.DONE
                else -> AgyAuroraCardLayout.RimMode.IDLE
            }
        )

        // Show/hide integrated composer based on Agy layout config
        inlineComposerContainer?.visibility = if (layoutCfg.showComposer) View.VISIBLE else View.GONE

        // Update built-in bottom composer visuals (capsule focus ring, Send/Stop orb, voice state, dynamic theme)
        updateInlineComposerControls()

        val rimColor = when {
            isStopping -> COLOR_CORAL
            isStopped -> Color.parseColor("#88E11D48")
            isNeedsInput -> COLOR_AMBER
            isPaused -> Color.parseColor("#88D97706")
            isWorking -> Color.argb(120, Color.red(accentColor), Color.green(accentColor), Color.blue(accentColor))
            isDone -> Color.parseColor("#6616A34A")
            else -> resolvedTheme.border
        }
        hudBottomDockRow?.setPadding(
            if (liveCollapsedMode) (8 * d).toInt() else (10 * d).toInt(),
            if (liveCollapsedMode) (5 * d).toInt() else (6 * d).toInt(),
            (6 * d).toInt(),
            if (liveCollapsedMode) (5 * d).toInt() else (6 * d).toInt()
        )
        hudBottomDockRow?.background = createLiquidGlassDrawable(
            fillColor = resolvedTheme.surface,
            strokeColor = rimColor,
            radiusDp = 999f,
            strokeDp = if (isNeedsInput || isWorking || isPaused || isStopping) 1.3f else 1.0f
        )

        // Resolve active App / Task Icon OR Agy custom emoji badge
        val activeCollapsedStep = resolveCollapsedRunningStep(state)
        if (state.customEmoji.isNotBlank()) {
            headerAppIconView?.visibility = View.GONE
            customEmojiView?.visibility = View.VISIBLE
            customEmojiView?.text = state.customEmoji
        } else {
            customEmojiView?.visibility = View.GONE
            headerAppIconView?.visibility = View.VISIBLE
            headerAppIconView?.setIcon(activeCollapsedStep.icon, resolvedTheme.surface)
        }

        // Sync top shimmer loading bar (only when no explicit dynamic progress strip is taking over)
        workingLoadingBar?.setColors(
            accentColor = accentColor,
            trackColor = if (resolvedTheme.isDark) Color.parseColor("#334155") else Color.parseColor("#E2E8F0")
        )
        workingLoadingBar?.setDeterminateProgress(null)
        workingLoadingBar?.setAnimating(isWorking && !isCollapsed && !state.progress.visible)

        if (isWorking || isStopping) {
            headerSpinnerView?.visibility = View.VISIBLE
            headerSpinnerView?.setAccentColor(accentColor)
            headerSpinnerView?.setAnimating(!isCollapsed)
            statusDotView?.visibility = View.GONE
        } else {
            headerSpinnerView?.setAnimating(false)
            headerSpinnerView?.visibility = View.GONE
            statusDotView?.visibility = View.VISIBLE
            statusDotView?.background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(accentColor)
            }
        }

        // Toggle between Live Collapsed Running/Paused/Stopping Step Pill and Standard Ask Agy Bottom Dock
        dockStandardStatusGroup?.visibility = if (liveCollapsedMode) View.GONE else View.VISIBLE
        dockStandardDivider?.visibility = if (liveCollapsedMode) View.GONE else View.VISIBLE
        bottomChatPillBtn?.visibility = if (liveCollapsedMode) View.GONE else View.VISIBLE
        dockLiveStepGroup?.visibility = if (liveCollapsedMode) View.VISIBLE else View.GONE
        dockLiveStopBtn?.visibility = if (liveCollapsedMode && layoutCfg.showStopButton) View.VISIBLE else View.GONE

        if (liveCollapsedMode) {
            dockSpinnerView?.setAnimating(false)
            dockSpinnerView?.visibility = View.GONE
            dockLiveIconView?.setIcon(activeCollapsedStep.icon, resolvedTheme.surface)
            dockLiveSpinnerView?.setAccentColor(
                when {
                    isStopping -> COLOR_CORAL
                    isPaused -> COLOR_AMBER
                    else -> accentColor
                }
            )
            dockLiveSpinnerView?.setAnimating(isWorking || isStopping)
            dockLiveStepText?.setTextColor(resolvedTheme.textPrimary)

            dockLiveStopBtn?.apply {
                if (isPaused) {
                    text = "▶"
                    setTextColor(accentColor)
                    background = createLiquidGlassDrawable(
                        fillColor = Color.argb(26, Color.red(accentColor), Color.green(accentColor), Color.blue(accentColor)),
                        strokeColor = Color.argb(80, Color.red(accentColor), Color.green(accentColor), Color.blue(accentColor)),
                        radiusDp = 999f,
                        strokeDp = 0.85f
                    )
                } else if (isStopping) {
                    text = "✕"
                    setTextColor(Color.WHITE)
                    background = createLiquidGlassDrawable(
                        fillColor = COLOR_CORAL,
                        strokeColor = COLOR_CORAL,
                        radiusDp = 999f,
                        strokeDp = 1.0f
                    )
                } else {
                    text = "■"
                    setTextColor(COLOR_CORAL)
                    background = createLiquidGlassDrawable(
                        fillColor = Color.parseColor("#1AE11D48"),
                        strokeColor = Color.parseColor("#55E11D48"),
                        radiusDp = 999f,
                        strokeDp = 0.9f
                    )
                }
            }

            val stepTv = dockLiveStepText
            if (stepTv != null) {
                val nextLabel = when {
                    isStopping -> "Stopping… tap ✕"
                    isPaused -> "Paused · ${activeCollapsedStep.label}"
                    else -> activeCollapsedStep.label
                }
                if (nextLabel != lastCollapsedStepLabel) {
                    if (lastCollapsedStepLabel.isNotEmpty()) {
                        stepTv.animate().cancel()
                        stepTv.alpha = 0f
                        stepTv.translationY = 4f * d
                        stepTv.text = nextLabel
                        stepTv.isSelected = true
                        stepTv.animate()
                            .alpha(1f)
                            .translationY(0f)
                            .setDuration(190L)
                            .start()
                    } else {
                        stepTv.alpha = 1f
                        stepTv.translationY = 0f
                        stepTv.text = nextLabel
                        stepTv.isSelected = true
                    }
                    lastCollapsedStepLabel = nextLabel
                } else if (!stepTv.isSelected) {
                    stepTv.isSelected = true
                }
            }
        } else {
            dockLiveSpinnerView?.setAnimating(false)
            lastCollapsedStepLabel = ""

            if (isWorking) {
                dockSpinnerView?.visibility = View.VISIBLE
                dockSpinnerView?.setAccentColor(COLOR_CYAN)
                dockSpinnerView?.setAnimating(true)
            } else {
                dockSpinnerView?.setAnimating(false)
                dockSpinnerView?.visibility = View.GONE
            }

            // Always-visible Bottom Dock status label & Ask Agy Chat pill styling
            val chevron = if (isCollapsed) "▲" else "▼"
            val elapsed = _elapsedMsFlow.value
            val dockLabel = when (state.state) {
                "WORKING" -> "Working $chevron"
                "PAUSED" -> "❚❚ Paused $chevron"
                "NEEDS_INPUT" -> "? Reply $chevron"
                "DONE" -> if (elapsed > 0L) {
                    "✓ Done · ${formatElapsed(elapsed, isDone = true).removePrefix("Done ")} $chevron"
                } else {
                    "✓ Done $chevron"
                }
                else -> "○ Ready $chevron"
            }
            collapsedStatusText?.text = dockLabel
            collapsedStatusText?.setTextColor(if (isNeedsInput || isPaused) COLOR_AMBER else COLOR_TEXT_PRIMARY)

            val chatPillBgColor = if (isNeedsInput) COLOR_AMBER else COLOR_CYAN
            bottomChatPillBtn?.text = if (isNeedsInput) "✦ Reply" else "✦ Ask Agy"
            bottomChatPillBtn?.background = createLiquidGlassDrawable(
                fillColor = chatPillBgColor,
                strokeColor = chatPillBgColor,
                radiusDp = 999f,
                strokeDp = 0.8f
            )
        }

        // Update Live Elapsed Timer label (both expanded header & collapsed live pill)
        updateElapsedTimerDisplay()

        // Ultra-Clean Single-Line Status & Expandable Tools Tray (with Agy custom statusLabel support)
        val cleanStatusLabel = state.statusLabel.ifBlank {
            when (state.state) {
                "WORKING" -> "Working"
                "PAUSED" -> "Paused"
                "NEEDS_INPUT" -> "Needs input"
                "STOPPING" -> "Stopping…"
                "STOPPED" -> "Stopped"
                "DONE" -> "Done"
                else -> "Ready"
            }
        }
        statusBadgeText?.text = cleanStatusLabel
        statusBadgeText?.setTextColor(accentColor)

        val hasDetailBlocks = state.blocks.any { it.inDetails }
        val hasExpandableDetails = state.tasks.isNotEmpty() ||
            state.detailedOutput.isNotBlank() ||
            state.outputLogs.isNotEmpty() ||
            hasDetailBlocks
        stepsTogglePill?.apply {
            visibility = if (hasExpandableDetails && layoutCfg.showStepsBadge) View.VISIBLE else View.GONE
            if (hasExpandableDetails && layoutCfg.showStepsBadge) {
                val doneCount = state.tasks.count { it.status == "done" }
                val totalCount = state.tasks.size
                val chevron = if (isDetailsExpanded && !isInputFocused) "▴" else "▾"
                text = if (totalCount > 0) "$doneCount/$totalCount $chevron" else "Details $chevron"
                val active = isDetailsExpanded && !isInputFocused
                setTextColor(if (active) accentColor else resolvedTheme.textSecondary)
                background = createLiquidGlassDrawable(
                    fillColor = if (active) Color.argb(30, Color.red(accentColor), Color.green(accentColor), Color.blue(accentColor)) else resolvedTheme.secondarySurface,
                    strokeColor = if (active) Color.argb(105, Color.red(accentColor), Color.green(accentColor), Color.blue(accentColor)) else resolvedTheme.border,
                    radiusDp = 999f,
                    strokeDp = 0.7f
                )
            }
        }

        toolsMenuBtn?.visibility = if (layoutCfg.showOverflowMenu) View.VISIBLE else View.GONE
        toolsMenuBtn?.background = createLiquidGlassDrawable(
            fillColor = if (isToolsTrayOpen) Color.argb(30, Color.red(accentColor), Color.green(accentColor), Color.blue(accentColor)) else resolvedTheme.secondarySurface,
            strokeColor = Color.TRANSPARENT,
            radiusDp = 999f,
            strokeDp = 0f
        )
        toolsMenuBtn?.setTextColor(if (isToolsTrayOpen) accentColor else resolvedTheme.textSecondary)

        headerCollapseBtn?.visibility = if (layoutCfg.showCollapseButton) View.VISIBLE else View.GONE
        headerCollapseBtn?.background = createLiquidGlassDrawable(
            fillColor = resolvedTheme.secondarySurface,
            strokeColor = Color.TRANSPARENT,
            radiusDp = 999f,
            strokeDp = 0f
        )
        headerCollapseBtn?.setTextColor(resolvedTheme.textSecondary)

        toolsTrayContainer?.visibility = if (isToolsTrayOpen && !isCollapsed && layoutCfg.showOverflowMenu) View.VISIBLE else View.GONE
        toolsTrayContainer?.background = createLiquidGlassDrawable(
            fillColor = resolvedTheme.secondarySurface,
            strokeColor = resolvedTheme.border,
            radiusDp = 12f,
            strokeDp = 0.7f
        )

        val opacityPct = (alphaVal * 100).toInt()
        opacityBtn?.text = "$opacityPct%"
        wireframeBtn?.text = if (wireframeEnabled) "● Map" else "Map"
        wireframeBtn?.setTextColor(if (wireframeEnabled) accentColor else resolvedTheme.textSecondary)
        ghostBtn?.text = if (ghostPassThrough) "● Ghost" else "Ghost"
        ghostBtn?.setTextColor(if (ghostPassThrough) COLOR_AMBER else resolvedTheme.textSecondary)
        edgeSnapBtn?.text = if (edgeSnapEnabled) "● Snap" else "Snap"
        edgeSnapBtn?.setTextColor(if (edgeSnapEnabled) accentColor else resolvedTheme.textSecondary)
        val ptrActive = _pointerEnabledFlow.value
        pointerBtn?.text = if (ptrActive) "● 🖱" else "🖱"
        pointerBtn?.setTextColor(if (ptrActive) accentColor else resolvedTheme.textSecondary)

        val demoSession = demoRecorderManager.currentSession()
        demoToolBtn?.text = if (demoSession.active) "● ⏺ Rec" else "⏺ Record"
        demoToolBtn?.setTextColor(if (demoSession.active) COLOR_CORAL else resolvedTheme.textSecondary)

        val padCount = scratchpadManager.currentItems().size
        scratchpadToolBtn?.text = if (padCount > 0) "📋 Pad ($padCount)" else "📋 Pad"
        scratchpadToolBtn?.setTextColor(if (isScratchpadDrawerOpen || padCount > 0) COLOR_VIOLET else resolvedTheme.textSecondary)

        val wdConfig = screenWatchdogManager.currentWatchdog()
        watchdogToolBtn?.text = if (wdConfig.active) "● 👁 Diff" else "👁 Diff"
        watchdogToolBtn?.setTextColor(if (wdConfig.active) COLOR_EMERALD else resolvedTheme.textSecondary)

        val vcpConfig = voiceCoPilotManager.currentConfig()
        voiceCoPilotToolBtn?.text = if (vcpConfig.enabled) "● 🔊 Voice" else "🔊 Voice"
        voiceCoPilotToolBtn?.setTextColor(if (vcpConfig.enabled) COLOR_CYAN else resolvedTheme.textSecondary)

        // Title with smooth crossfade when changing
        titleText?.let { tv ->
            tv.setTextColor(resolvedTheme.textPrimary)
            if (state.title != lastRenderedTitle && lastRenderedTitle.isNotEmpty() && !isCollapsed) {
                tv.animate().cancel()
                tv.alpha = 0f
                tv.translationY = 4f * d
                tv.text = state.title
                tv.animate().alpha(1f).translationY(0f).setDuration(190L).start()
            } else {
                tv.text = state.title
            }
            lastRenderedTitle = state.title
        }

        // Question Banner
        if (state.question.isNotBlank()) {
            questionBannerText?.visibility = View.VISIBLE
            questionBannerText?.text = state.question
        } else {
            questionBannerText?.visibility = View.GONE
        }

        // Doing Now row + animated 3 bouncing dots
        if (state.currentAction.isNotBlank()) {
            doingRowContainer?.visibility = View.VISIBLE
            currentActionText?.text = state.currentAction
            currentActionText?.setTextColor(if (isStopping) COLOR_CORAL else resolvedTheme.textSecondary)
            doingDotsView?.setAccentColor(accentColor)
            doingDotsView?.setAnimating((isWorking || isStopping) && !isCollapsed)
        } else {
            doingRowContainer?.visibility = View.GONE
            doingDotsView?.setAnimating(false)
        }

        // Only show nextAction when task checklist isn't already displaying upcoming steps
        if (state.nextAction.isNotBlank() && state.tasks.isEmpty()) {
            nextActionText?.visibility = View.VISIBLE
            nextActionText?.setTextColor(resolvedTheme.textSecondary)
            nextActionText?.text = "Next: ${state.nextAction}"
        } else {
            nextActionText?.visibility = View.GONE
        }

        // Render Dynamic Agy-Controlled Widgets (Progress, Metrics, Alert Banner, Modular Content Blocks)
        renderDynamicWidgetsInternal(state, resolvedTheme, d)
        renderPowerFeaturesInternal(state, resolvedTheme, accentColor, d)

        // Airy Borderless Task List with Staggered Step Choreography & Micro-Pop Completion
        val listHost = taskListContainer
        if (listHost != null) {
            val prevStatuses = lastRenderedTaskStatuses
            listHost.removeAllViews()
            if (state.tasks.isEmpty()) {
                taskScrollView?.visibility = View.GONE
                lastRenderedTaskStatuses = emptyMap()
            } else {
                taskScrollView?.visibility = View.VISIBLE
                val maxListHeightPx = (132 * d).toInt()
                taskScrollView?.layoutParams = (taskScrollView?.layoutParams as? LinearLayout.LayoutParams)?.apply {
                    height = if (state.tasks.size > 4) maxListHeightPx else ViewGroup.LayoutParams.WRAP_CONTENT
                }
                val animateStagger = collapseTransitioned || prevStatuses.keys != state.tasks.map { it.id }.toSet()
                val nextStatusMap = mutableMapOf<String, String>()
                state.tasks.forEachIndexed { idx, task ->
                    nextStatusMap[task.id] = task.status
                    val prevTaskStatus = prevStatuses[task.id]
                    val justDone = task.status == "done" && prevTaskStatus != null && prevTaskStatus != "done"
                    val (marker, color) = when (task.status) {
                        "done" -> "✓" to COLOR_EMERALD
                        "doing" -> "•" to accentColor
                        "needs_input" -> "?" to COLOR_AMBER
                        "stopped", "error", "failed" -> "■" to COLOR_CORAL
                        else -> "○" to resolvedTheme.textSecondary
                    }
                    val row = LinearLayout(context).apply {
                        orientation = LinearLayout.HORIZONTAL
                        gravity = Gravity.CENTER_VERTICAL
                        setPadding((6 * d).toInt(), (5 * d).toInt(), (6 * d).toInt(), (5 * d).toInt())
                        if (task.status == "doing" || task.status == "needs_input") {
                            background = createLiquidGlassDrawable(
                                fillColor = Color.argb(16, Color.red(color), Color.green(color), Color.blue(color)),
                                strokeColor = Color.TRANSPARENT,
                                radiusDp = 10f,
                                strokeDp = 0f
                            )
                        }
                        layoutParams = LinearLayout.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.WRAP_CONTENT
                        ).apply { bottomMargin = (2 * d).toInt() }
                    }

                    // Per-task real app icon or custom vector badge (YouTube, Chrome, Termux, etc.) + sub-badge
                    val taskIcon = AgyAppIconResolver.resolve(
                        context = context,
                        explicitIcon = task.icon,
                        explicitPackage = task.appPackage,
                        fallbackText = "${task.label} ${task.detail}",
                        actionKindHint = task.actionKind
                    )
                    val iconBadge = AgyIconBadgeView(context).apply {
                        val sz = (22 * d).toInt()
                        layoutParams = LinearLayout.LayoutParams(sz, sz).apply { marginEnd = (8 * d).toInt() }
                        setIcon(taskIcon, resolvedTheme.surface)
                    }
                    row.addView(iconBadge)

                    val textCol = LinearLayout(context).apply {
                        orientation = LinearLayout.VERTICAL
                        layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                    }
                    val labelTv = TextView(context).apply {
                        text = task.label
                        textSize = 11.5f
                        setTypeface(
                            Typeface.SANS_SERIF,
                            if (task.status == "doing") Typeface.BOLD else Typeface.NORMAL
                        )
                        setTextColor(if (task.status == "done") COLOR_TEXT_SECONDARY else COLOR_TEXT_PRIMARY)
                        maxLines = 2
                        ellipsize = TextUtils.TruncateAt.END
                    }
                    textCol.addView(labelTv)
                    if (task.detail.isNotBlank()) {
                        val detailTv = TextView(context).apply {
                            text = task.detail
                            textSize = 9.5f
                            typeface = Typeface.MONOSPACE
                            setTextColor(COLOR_TEXT_SECONDARY)
                            maxLines = 1
                            ellipsize = TextUtils.TruncateAt.END
                        }
                        textCol.addView(detailTv)
                    }
                    row.addView(textCol)

                    // Trailing live status indicator (spinning ring when doing, crisp mark with pop when done)
                    if (task.status == "doing" && isWorking && !isCollapsed) {
                        val taskSpinner = AgySpinnerRingView(context).apply {
                            val sz = (13 * d).toInt()
                            layoutParams = LinearLayout.LayoutParams(sz, sz).apply { marginStart = (6 * d).toInt() }
                            setAccentColor(COLOR_CYAN)
                            setAnimating(true)
                        }
                        row.addView(taskSpinner)
                    } else {
                        val statusTv = TextView(context).apply {
                            text = marker
                            textSize = 11f
                            setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
                            setTextColor(color)
                            layoutParams = LinearLayout.LayoutParams(
                                ViewGroup.LayoutParams.WRAP_CONTENT,
                                ViewGroup.LayoutParams.WRAP_CONTENT
                            ).apply { marginStart = (6 * d).toInt() }
                        }
                        if (justDone && !isCollapsed) {
                            statusTv.scaleX = 0.55f
                            statusTv.scaleY = 0.55f
                            statusTv.animate()
                                .scaleX(1f)
                                .scaleY(1f)
                                .setDuration(240L)
                                .setInterpolator(android.view.animation.OvershootInterpolator(1.8f))
                                .start()
                        }
                        row.addView(statusTv)
                    }

                    tagTreeForSelfExclusion(row, "task_${task.id}")
                    listHost.addView(row)

                    if (animateStagger && !isCollapsed) {
                        row.alpha = 0f
                        row.translationY = 10f * d
                        row.animate()
                            .alpha(1f)
                            .translationY(0f)
                            .setStartDelay((idx * 35L).coerceAtMost(180L))
                            .setDuration(210L)
                            .setInterpolator(android.view.animation.DecelerateInterpolator())
                            .start()
                    }
                }
                lastRenderedTaskStatuses = nextStatusMap
            }
        }

        // Quiet Expandable Detailed Output Drawer
        val hasDetailedOutput = state.detailedOutput.isNotBlank() || state.outputLogs.isNotEmpty()
        if (hasDetailedOutput) {
            outputSectionContainer?.visibility = View.VISIBLE
            val logCount = state.outputLogs.size
            val suffix = if (logCount > 0) " · $logCount logs" else ""
            outputToggleHeaderText?.text = if (isOutputExpanded) {
                "Hide Output$suffix ▴"
            } else {
                "Output$suffix ▾"
            }
            outputDrawerContainer?.visibility = if (isOutputExpanded) View.VISIBLE else View.GONE
            if (isOutputExpanded) {
                outputBodyText?.text = getFullOutputCopyText(state)
            }
        } else {
            outputSectionContainer?.visibility = View.GONE
            outputDrawerContainer?.visibility = View.GONE
        }

        // Contextual & Custom Agy Quick Action Chips Strip
        val quickHost = quickActionsContainer
        val chips = resolveQuickActions(state)
        if (quickHost != null) {
            quickHost.removeAllViews()
            if (chips.isEmpty()) {
                quickActionsScrollView?.visibility = View.GONE
            } else {
                quickActionsScrollView?.visibility = View.VISIBLE
                for ((idx, chip) in chips.withIndex()) {
                    val chipStyle = chip.style.lowercase().ifBlank {
                        when {
                            chip.actionType == "STOP" || chip.actionType == "FORCE_STOP" -> "danger"
                            idx == 0 -> "primary"
                            else -> "secondary"
                        }
                    }
                    val chipTextColor = when (chipStyle) {
                        "danger" -> COLOR_CORAL
                        "success" -> COLOR_EMERALD
                        "primary" -> accentColor
                        else -> resolvedTheme.textPrimary
                    }
                    val chipBg = when (chipStyle) {
                        "danger" -> Color.parseColor("#1AE11D48")
                        "success" -> Color.parseColor("#1A16A34A")
                        "primary" -> Color.argb(28, Color.red(accentColor), Color.green(accentColor), Color.blue(accentColor))
                        else -> resolvedTheme.secondarySurface
                    }
                    val chipBorder = when (chipStyle) {
                        "danger" -> Color.parseColor("#55E11D48")
                        "success" -> Color.parseColor("#5516A34A")
                        "primary" -> Color.argb(95, Color.red(accentColor), Color.green(accentColor), Color.blue(accentColor))
                        else -> resolvedTheme.border
                    }
                    val chipTv = TextView(context).apply {
                        text = chip.label
                        textSize = 10.5f
                        setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
                        setTextColor(chipTextColor)
                        setPadding((10 * d).toInt(), (5 * d).toInt(), (10 * d).toInt(), (5 * d).toInt())
                        background = createLiquidGlassDrawable(
                            fillColor = chipBg,
                            strokeColor = chipBorder,
                            radiusDp = 999f,
                            strokeDp = 0.8f
                        )
                        layoutParams = LinearLayout.LayoutParams(
                            ViewGroup.LayoutParams.WRAP_CONTENT,
                            ViewGroup.LayoutParams.WRAP_CONTENT
                        ).apply { marginEnd = (6 * d).toInt() }
                        contentDescription = "${HUD_NODE_TAG_PREFIX}quick_chip_${chip.id.ifBlank { idx.toString() }}"
                        attachSpringPressFeedback(0.93f)
                        setOnClickListener { executeQuickAction(chip) }
                    }
                    quickHost.addView(chipTv)
                }
            }
        }

        // Visual Map is rendered solely in Window 3 (`agy_task_map`) with zero duplication here.

        hudRootView?.let { root ->
            hudParams?.let { params ->
                try {
                    windowManager?.updateViewLayout(root, params)
                } catch (_: Exception) {}
            }
        }
        if (scheduleReconcile) {
            scheduleHudLayoutReconcile()
        }
    }

    private fun renderDynamicWidgetsInternal(
        state: AgyHudState,
        theme: AgyHudDynamicModels.ResolvedHudTheme,
        d: Float
    ) {
        // 1. Dynamic Progress Strip
        val prog = state.progress
        if (prog.visible && !isInputFocused) {
            progressRowContainer?.visibility = View.VISIBLE
            val progColor = AgyHudDynamicModels.parseColorOrNull(prog.color) ?: theme.accent
            val trackColor = if (theme.isDark) Color.parseColor("#334155") else Color.parseColor("#E2E8F0")
            progressBarView?.setColors(progColor, trackColor)
            if (prog.isDeterminate) {
                progressBarView?.setDeterminateProgress(prog.fraction)
                val pctStr = "${prog.value.toInt()}%"
                progressCaptionText?.text = if (prog.label.isNotBlank()) "$pctStr · ${prog.label}" else pctStr
                progressCaptionText?.visibility = View.VISIBLE
            } else {
                progressBarView?.setDeterminateProgress(null)
                progressBarView?.setAnimating(!isCollapsed)
                progressCaptionText?.text = prog.label
                progressCaptionText?.visibility = if (prog.label.isNotBlank()) View.VISIBLE else View.GONE
            }
            progressCaptionText?.setTextColor(theme.textSecondary)
        } else {
            progressRowContainer?.visibility = View.GONE
            progressBarView?.setAnimating(false)
        }

        // 2. Dynamic Live Metrics Strip
        val metricsHost = metricsContainer
        if (metricsHost != null) {
            metricsHost.removeAllViews()
            if (state.metrics.isEmpty() || isInputFocused) {
                metricsScrollView?.visibility = View.GONE
            } else {
                metricsScrollView?.visibility = View.VISIBLE
                state.metrics.forEach { metric ->
                    val mAccent = AgyHudDynamicModels.parseColorOrNull(metric.accentColor) ?: theme.accent
                    val pill = LinearLayout(context).apply {
                        orientation = LinearLayout.HORIZONTAL
                        gravity = Gravity.CENTER_VERTICAL
                        setPadding((8 * d).toInt(), (4 * d).toInt(), (8 * d).toInt(), (4 * d).toInt())
                        background = createLiquidGlassDrawable(
                            fillColor = theme.secondarySurface,
                            strokeColor = theme.border,
                            radiusDp = 10f,
                            strokeDp = 0.75f
                        )
                        layoutParams = LinearLayout.LayoutParams(
                            ViewGroup.LayoutParams.WRAP_CONTENT,
                            ViewGroup.LayoutParams.WRAP_CONTENT
                        ).apply { marginEnd = (6 * d).toInt() }
                    }
                    if (metric.label.isNotBlank()) {
                        val lblTv = TextView(context).apply {
                            text = if (metric.icon.isNotBlank()) "${metric.icon} ${metric.label}" else metric.label
                            textSize = 9.5f
                            setTextColor(theme.textSecondary)
                            maxLines = 1
                            layoutParams = LinearLayout.LayoutParams(
                                ViewGroup.LayoutParams.WRAP_CONTENT,
                                ViewGroup.LayoutParams.WRAP_CONTENT
                            ).apply { marginEnd = (4 * d).toInt() }
                        }
                        pill.addView(lblTv)
                    }
                    if (metric.value.isNotBlank()) {
                        val valTv = TextView(context).apply {
                            text = metric.value
                            textSize = 10.5f
                            typeface = Typeface.MONOSPACE
                            setTypeface(typeface, Typeface.BOLD)
                            setTextColor(mAccent)
                            maxLines = 1
                        }
                        pill.addView(valTv)
                    }
                    metricsHost.addView(pill)
                }
            }
        }

        // 3. Dynamic Alert / Status Banner
        val banner = state.banner
        if (banner.visible && !isInputFocused) {
            dynamicBannerContainer?.visibility = View.VISIBLE
            val bannerColor = AgyHudDynamicModels.parseColorOrNull(banner.accentColor) ?: when (banner.level) {
                "success" -> COLOR_EMERALD
                "warning" -> COLOR_AMBER
                "error" -> COLOR_CORAL
                else -> theme.accent
            }
            dynamicBannerContainer?.background = createLiquidGlassDrawable(
                fillColor = Color.argb(if (theme.isDark) 36 else 22, Color.red(bannerColor), Color.green(bannerColor), Color.blue(bannerColor)),
                strokeColor = Color.argb(95, Color.red(bannerColor), Color.green(bannerColor), Color.blue(bannerColor)),
                radiusDp = 12f,
                strokeDp = 0.85f
            )
            dynamicBannerTitleText?.apply {
                visibility = if (banner.title.isNotBlank()) View.VISIBLE else View.GONE
                text = banner.title
                setTextColor(bannerColor)
            }
            dynamicBannerMsgText?.apply {
                visibility = if (banner.message.isNotBlank()) View.VISIBLE else View.GONE
                text = banner.message
                setTextColor(theme.textPrimary)
            }
        } else {
            dynamicBannerContainer?.visibility = View.GONE
        }

        // 4. Modular Custom Content Blocks (inline vs expandable details drawer)
        fun populateBlocks(host: LinearLayout?, items: List<AgyHudDynamicModels.HudContentBlock>, visible: Boolean) {
            if (host == null) return
            host.removeAllViews()
            if (!visible || items.isEmpty()) {
                host.visibility = View.GONE
                return
            }
            host.visibility = View.VISIBLE
            items.forEach { block ->
                val blockAccent = AgyHudDynamicModels.parseColorOrNull(block.accentColor) ?: theme.accent
                val card = LinearLayout(context).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding((9 * d).toInt(), (7 * d).toInt(), (9 * d).toInt(), (7 * d).toInt())
                    background = createLiquidGlassDrawable(
                        fillColor = if (block.type == "code") {
                            if (theme.isDark) Color.parseColor("#FF020617") else Color.parseColor("#FF0F172A")
                        } else theme.secondarySurface,
                        strokeColor = theme.border,
                        radiusDp = 12f,
                        strokeDp = 0.75f
                    )
                    layoutParams = LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                    ).apply { topMargin = (7 * d).toInt() }
                }
                if (block.title.isNotBlank()) {
                    val tTv = TextView(context).apply {
                        text = block.title
                        textSize = 10.5f
                        setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
                        setTextColor(if (block.type == "code") Color.parseColor("#38BDF8") else blockAccent)
                        maxLines = 1
                        ellipsize = TextUtils.TruncateAt.END
                    }
                    card.addView(tTv)
                }
                if (block.body.isNotBlank()) {
                    val bTv = TextView(context).apply {
                        text = block.body
                        textSize = if (block.type == "code") 10f else 11f
                        if (block.type == "code") typeface = Typeface.MONOSPACE
                        setTextColor(if (block.type == "code") Color.parseColor("#E2E8F0") else theme.textPrimary)
                        maxLines = if (block.type == "code") 4 else 3
                        ellipsize = TextUtils.TruncateAt.END
                        layoutParams = LinearLayout.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.WRAP_CONTENT
                        ).apply { if (block.title.isNotBlank()) topMargin = (3 * d).toInt() }
                    }
                    card.addView(bTv)
                }
                if (block.items.isNotEmpty()) {
                    block.items.take(4).forEach { (k, v) ->
                        val kvRow = LinearLayout(context).apply {
                            orientation = LinearLayout.HORIZONTAL
                            gravity = Gravity.CENTER_VERTICAL
                            layoutParams = LinearLayout.LayoutParams(
                                ViewGroup.LayoutParams.MATCH_PARENT,
                                ViewGroup.LayoutParams.WRAP_CONTENT
                            ).apply { topMargin = (3 * d).toInt() }
                        }
                        val kTv = TextView(context).apply {
                            text = k
                            textSize = 10.5f
                            setTextColor(theme.textSecondary)
                            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                            maxLines = 1
                            ellipsize = TextUtils.TruncateAt.END
                        }
                        val vTv = TextView(context).apply {
                            text = v
                            textSize = 10.5f
                            typeface = Typeface.MONOSPACE
                            setTypeface(typeface, Typeface.BOLD)
                            setTextColor(theme.textPrimary)
                            maxLines = 1
                        }
                        kvRow.addView(kTv)
                        kvRow.addView(vTv)
                        card.addView(kvRow)
                    }
                }
                if (block.type == "progress" && block.progressValue != null) {
                    val subBar = AgyLoadingBarView(context).apply {
                        layoutParams = LinearLayout.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            (4.5f * d).toInt().coerceAtLeast(4)
                        ).apply { topMargin = (5 * d).toInt() }
                        setColors(blockAccent, if (theme.isDark) Color.parseColor("#334155") else Color.parseColor("#E2E8F0"))
                        setDeterminateProgress(block.progressValue / 100f)
                    }
                    card.addView(subBar)
                }
                host.addView(card)
            }
        }
        populateBlocks(inlineBlocksContainer, state.blocks.filter { !it.inDetails }, !isInputFocused)
        populateBlocks(detailBlocksContainer, state.blocks.filter { it.inDetails }, true)
    }

    fun executeQuickAction(chip: QuickActionChip) {
        try {
            hudRootView?.performHapticFeedback(android.view.HapticFeedbackConstants.VIRTUAL_KEY)
        } catch (_: Exception) {}
        when (chip.actionType.uppercase()) {
            "COPY_OUTPUT" -> copyDetailedOutputToClipboard()
            "TOGGLE_OUTPUT" -> setOutputExpanded(!isOutputExpanded)
            "PAUSE" -> {
                cancelAutoCollapse()
                handleRemoteCommand(JSONObject().put("action", "PAUSE").put("text", chip.commandText.ifBlank { "PAUSE" }))
            }
            "RESUME" -> {
                cancelAutoCollapse()
                handleRemoteCommand(JSONObject().put("action", "RESUME").put("text", chip.commandText.ifBlank { "RESUME" }))
            }
            "STOP" -> {
                cancelAutoCollapse()
                handleRemoteCommand(JSONObject().put("action", "STOP").put("text", chip.commandText.ifBlank { "STOP" }))
            }
            "FORCE_STOP" -> {
                cancelAutoCollapse()
                handleRemoteCommand(JSONObject().put("action", "FORCE_STOP").put("text", chip.commandText.ifBlank { "FORCE_STOP" }))
            }
            "CUSTOM", "CUSTOM_ACTION" -> {
                cancelAutoCollapse()
                enqueueAndBroadcastCommand(
                    text = chip.commandText.ifBlank { chip.label },
                    action = "CUSTOM",
                    buttonId = chip.id,
                    payload = chip.payload
                )
            }
            else -> {
                cancelAutoCollapse()
                val cmdText = chip.commandText.ifBlank { chip.label }
                if (cmdText.isNotBlank()) {
                    enqueueAndBroadcastCommand(
                        text = cmdText,
                        action = "PROMPT",
                        buttonId = chip.id,
                        payload = chip.payload
                    )
                }
            }
        }
    }

    // -------------------------------------------------------------------------
    // Built-In Bottom Composer Focus Handoff & Voice Dictation (Single Window)
    // -------------------------------------------------------------------------

    private fun focusInlineComposerInternal(requestKeyboardFocus: Boolean) {
        _isInputVisible.value = true
        if (requestKeyboardFocus) {
            mainHandler.postDelayed({ acquireInputFocusFromTermux() }, 80L)
        }
    }

    private fun blurInlineComposerInternal() {
        voiceController?.stopListening()
        _isVoiceListeningFlow.value = false
        releaseInputFocusToTermux()
        if (isCollapsed) {
            _isInputVisible.value = false
        }
    }

    fun setTemporarilySuppressed(suppressed: Boolean) {
        runOnMain {
            if (isTemporarilySuppressed != suppressed) {
                isTemporarilySuppressed = suppressed
                hudRootView?.visibility = if (suppressed) View.GONE else View.VISIBLE
            }
        }
    }

    private fun acquireInputFocusFromTermux() {
        val root = hudRootView ?: return
        val params = hudParams ?: return
        val et = inputEditText ?: return
        val d = density()
        if (isCollapsed) {
            isCollapsed = false
            _isInputVisible.value = true
            renderHudWindow()
        }
        if (!isInputFocused) {
            // Remember user's dragged vertical offset and dock snugly right above the keyboard
            if (savedYBeforeIme == null) {
                savedYBeforeIme = params.y
            }
            params.y = (10 * d).toInt()
            params.flags = (params.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE.inv()
                and WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN.inv()) or
                WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
            isInputFocused = true
            // Smoothly compact verbose checklist/wireframe while typing so the Gemini card sits sleek above the IME
            telemetryDetailsContainer?.visibility = View.GONE
            try {
                windowManager?.updateViewLayout(root, params)
            } catch (e: Exception) {
                Log.w(TAG, "Failed updating focusable layout for unified agy_hud: ${e.message}")
            }
            updateInlineComposerControls()
            hudExpandedContainer?.setRimMode(
                when {
                    _isVoiceListeningFlow.value -> AgyAuroraCardLayout.RimMode.VOICE_LISTENING
                    _hudState.value.state == "WORKING" -> AgyAuroraCardLayout.RimMode.WORKING
                    _hudState.value.state == "NEEDS_INPUT" -> AgyAuroraCardLayout.RimMode.NEEDS_INPUT
                    else -> AgyAuroraCardLayout.RimMode.INPUT_ACTIVE
                }
            )
            // Immediately shift / auto-collapse Left Task Map clear of keyboard + docked HUD
            layoutCoordinator.notifyImeFocusChanged(focused = true)
        }
        et.isFocusable = true
        et.isFocusableInTouchMode = true
        et.requestFocus()
        et.post {
            try {
                inputMethodManager?.showSoftInput(et, InputMethodManager.SHOW_IMPLICIT)
            } catch (_: Exception) {}
        }
        et.postDelayed({
            if (isInputFocused && hudRootView != null) {
                try {
                    et.requestFocus()
                    inputMethodManager?.showSoftInput(et, InputMethodManager.SHOW_IMPLICIT)
                } catch (_: Exception) {}
            }
        }, 60L)
    }

    private fun releaseInputFocusToTermux() {
        val root = hudRootView ?: return
        val params = hudParams ?: return
        val et = inputEditText
        try {
            if (et != null) {
                inputMethodManager?.hideSoftInputFromWindow(et.windowToken, 0)
                et.clearFocus()
            }
        } catch (_: Exception) {}

        val changed = isInputFocused || (params.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE) == 0
        if (changed) {
            savedYBeforeIme?.let { prevY ->
                params.y = prevY
                savedYBeforeIme = null
            }
            params.flags = (params.flags and WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN.inv()) or
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH
            isInputFocused = false
            telemetryDetailsContainer?.visibility = if (isDetailsExpanded) View.VISIBLE else View.GONE
            try {
                windowManager?.updateViewLayout(root, params)
            } catch (_: Exception) {}
            if (hudRootView != null) {
                updateInlineComposerControls()
                hudExpandedContainer?.setRimMode(
                    when {
                        isCollapsed -> AgyAuroraCardLayout.RimMode.IDLE
                        _isVoiceListeningFlow.value -> AgyAuroraCardLayout.RimMode.VOICE_LISTENING
                        _hudState.value.state == "WORKING" -> AgyAuroraCardLayout.RimMode.WORKING
                        _hudState.value.state == "NEEDS_INPUT" -> AgyAuroraCardLayout.RimMode.NEEDS_INPUT
                        _hudState.value.state == "PAUSED" -> AgyAuroraCardLayout.RimMode.PAUSED
                        _hudState.value.state == "DONE" -> AgyAuroraCardLayout.RimMode.DONE
                        else -> AgyAuroraCardLayout.RimMode.IDLE
                    }
                )
            }
            // Restore Left Task Map from its pre-IME dodge / auto-collapse cleanly
            layoutCoordinator.notifyImeFocusChanged(focused = false)
        }
    }

    private fun renderPowerFeaturesInternal(
        state: AgyHudState,
        theme: AgyHudDynamicModels.ResolvedHudTheme,
        accentColor: Int,
        d: Float
    ) {
        // 1. Safety Approval Gate Card
        val gate = state.approvalGate
        if (gate.active && !isCollapsed) {
            approvalCardContainer?.visibility = View.VISIBLE
            val riskColor = when (gate.riskLevel) {
                "high" -> COLOR_CORAL
                "low" -> COLOR_CYAN
                else -> COLOR_AMBER
            }
            val riskFill = when (gate.riskLevel) {
                "high" -> if (theme.isDark) Color.parseColor("#3B1220") else Color.parseColor("#FFF1F2")
                "low" -> if (theme.isDark) Color.parseColor("#0F293B") else Color.parseColor("#F0F9FF")
                else -> if (theme.isDark) Color.parseColor("#35240A") else Color.parseColor("#FFFBEB")
            }
            approvalCardContainer?.background = createLiquidGlassDrawable(
                fillColor = riskFill,
                strokeColor = riskColor,
                radiusDp = 14f,
                strokeDp = 1.15f
            )
            approvalRiskBadgeText?.apply {
                text = when (gate.riskLevel) {
                    "high" -> "HIGH RISK"
                    "low" -> "CONFIRM"
                    else -> "MEDIUM RISK"
                }
                background = createLiquidGlassDrawable(
                    fillColor = riskColor,
                    strokeColor = Color.TRANSPARENT,
                    radiusDp = 999f,
                    strokeDp = 0f
                )
            }
            approvalTimerBadgeText?.apply {
                if (gate.timeoutSeconds > 0) {
                    visibility = View.VISIBLE
                    val secs = if (approvalRemainingSeconds > 0) approvalRemainingSeconds else gate.timeoutSeconds
                    text = "${secs}s"
                    setTextColor(riskColor)
                } else {
                    visibility = View.GONE
                }
            }
            approvalTitleText?.apply {
                text = gate.title
                setTextColor(theme.textPrimary)
            }
            approvalDescText?.apply {
                if (gate.description.isNotBlank()) {
                    visibility = View.VISIBLE
                    text = gate.description
                    setTextColor(theme.textSecondary)
                } else {
                    visibility = View.GONE
                }
            }
            approvalPreviewText?.apply {
                if (gate.commandPreview.isNotBlank()) {
                    visibility = View.VISIBLE
                    text = gate.commandPreview
                } else {
                    visibility = View.GONE
                }
            }
            approvalApproveBtn?.text = "✓ ${gate.approveLabel}"
            approvalDenyBtn?.text = "✕ ${gate.denyLabel}"
            approvalEditBtn?.visibility = if (gate.allowEdit) View.VISIBLE else View.GONE
        } else {
            approvalCardContainer?.visibility = View.GONE
        }

        // 2. Ordered Prompt Queue Strip
        val queued = _queuedPromptsFlow.value
        val queueHost = promptQueueListContainer
        if (queued.isNotEmpty() && !isCollapsed && queueHost != null) {
            promptQueueContainer?.visibility = View.VISIBLE
            promptQueueContainer?.background = createLiquidGlassDrawable(
                fillColor = theme.secondarySurface,
                strokeColor = theme.border,
                radiusDp = 12f,
                strokeDp = 0.8f
            )
            promptQueueHeaderText?.text = "Queued (${queued.size}) · runs next when done"
            queueHost.removeAllViews()
            queued.take(3).forEachIndexed { idx, item ->
                val row = LinearLayout(context).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    layoutParams = LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                    ).apply { topMargin = (3 * d).toInt() }
                }
                val txt = TextView(context).apply {
                    text = "${idx + 1}. ${item.text}"
                    textSize = 10.5f
                    setTextColor(theme.textPrimary)
                    maxLines = 1
                    ellipsize = TextUtils.TruncateAt.END
                    layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                }
                row.addView(txt)
                if (idx > 0) {
                    val promoteBtn = TextView(context).apply {
                        text = "↑"
                        textSize = 11f
                        setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
                        setTextColor(accentColor)
                        setPadding((7 * d).toInt(), (3 * d).toInt(), (7 * d).toInt(), (3 * d).toInt())
                        contentDescription = "${HUD_NODE_TAG_PREFIX}queue_promote_$idx"
                        setOnClickListener { promoteQueuedPrompt(item.id) }
                    }
                    row.addView(promoteBtn)
                }
                val removeBtn = TextView(context).apply {
                    text = "✕"
                    textSize = 10.5f
                    setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
                    setTextColor(COLOR_CORAL)
                    setPadding((7 * d).toInt(), (3 * d).toInt(), (5 * d).toInt(), (3 * d).toInt())
                    contentDescription = "${HUD_NODE_TAG_PREFIX}queue_remove_$idx"
                    setOnClickListener { removeQueuedPrompt(item.id) }
                }
                row.addView(removeBtn)
                queueHost.addView(row)
            }
        } else {
            promptQueueContainer?.visibility = View.GONE
        }

        // 3. Attached Region Snip Context Pill
        val region = _attachedRegionContextFlow.value
        if (region != null && !isCollapsed) {
            attachedRegionChipRow?.visibility = View.VISIBLE
            attachedRegionChipText?.text = region.summaryChipLabel()
        } else {
            attachedRegionChipRow?.visibility = View.GONE
        }

        // Highlight composer snip button when region context is attached
        composerSnipBtn?.background = createLiquidGlassDrawable(
            fillColor = if (region != null) Color.parseColor("#E0F2FE") else Color.WHITE,
            strokeColor = if (region != null) COLOR_CYAN else COLOR_HAIRLINE,
            radiusDp = 999f,
            strokeDp = 0.85f
        )
        composerSnipBtn?.setTextColor(if (region != null) COLOR_CYAN else COLOR_TEXT_SECONDARY)

        // 4. App-Aware Smart Suggestion Chips + One-Tap Run-to-Macro Chip
        val sugHost = smartSuggestionsContainer
        val sugScroll = smartSuggestionsScrollView
        if (sugHost != null && sugScroll != null) {
            sugHost.removeAllViews()
            val showSuggestions = !isCollapsed && state.layout.showComposer && !gate.active && !isMacrosDrawerOpen
            val canSaveMacro = state.state == "DONE" &&
                (lastSubmittedPrompt.isNotBlank() || (state.title.isNotBlank() && state.title != "Agy Ready" && state.title != "Agy HUD"))
            val suggestions = if (showSuggestions && state.state in setOf("IDLE", "DONE", "STOPPED", "NEEDS_INPUT")) {
                resolveEffectiveSmartSuggestions(state)
            } else emptyList()

            if (!showSuggestions || (!canSaveMacro && suggestions.isEmpty())) {
                sugScroll.visibility = View.GONE
            } else {
                sugScroll.visibility = View.VISIBLE
                if (canSaveMacro) {
                    val activePrompt = lastSubmittedPrompt.ifBlank { state.title }
                    val alreadySaved = lastMacroSavedPrompt.isNotBlank() && lastMacroSavedPrompt == activePrompt
                    val saveChip = TextView(context).apply {
                        text = if (alreadySaved) "✓ Saved ★" else "★ Save Macro"
                        textSize = 10.5f
                        setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
                        setTextColor(if (alreadySaved) COLOR_EMERALD else COLOR_VIOLET)
                        setPadding((10 * d).toInt(), (5 * d).toInt(), (10 * d).toInt(), (5 * d).toInt())
                        background = createLiquidGlassDrawable(
                            fillColor = if (alreadySaved) Color.parseColor("#DCFCE7") else Color.parseColor("#EEF2FF"),
                            strokeColor = if (alreadySaved) COLOR_EMERALD else COLOR_VIOLET,
                            radiusDp = 999f,
                            strokeDp = 0.85f
                        )
                        layoutParams = LinearLayout.LayoutParams(
                            ViewGroup.LayoutParams.WRAP_CONTENT,
                            ViewGroup.LayoutParams.WRAP_CONTENT
                        ).apply { marginEnd = (6 * d).toInt() }
                        contentDescription = "${HUD_NODE_TAG_PREFIX}save_macro_chip"
                        attachSpringPressFeedback(0.94f)
                        setOnClickListener {
                            if (!alreadySaved) {
                                saveLastPromptAsMacro()
                            }
                        }
                    }
                    sugHost.addView(saveChip)
                }

                suggestions.forEachIndexed { idx, chip ->
                    val chipView = TextView(context).apply {
                        text = "✦ ${chip.label}"
                        textSize = 10.5f
                        setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
                        setTextColor(theme.textPrimary)
                        setPadding((10 * d).toInt(), (5 * d).toInt(), (10 * d).toInt(), (5 * d).toInt())
                        background = createLiquidGlassDrawable(
                            fillColor = theme.secondarySurface,
                            strokeColor = theme.border,
                            radiusDp = 999f,
                            strokeDp = 0.8f
                        )
                        layoutParams = LinearLayout.LayoutParams(
                            ViewGroup.LayoutParams.WRAP_CONTENT,
                            ViewGroup.LayoutParams.WRAP_CONTENT
                        ).apply { marginEnd = (6 * d).toInt() }
                        contentDescription = "${HUD_NODE_TAG_PREFIX}smart_suggestion_$idx"
                        attachSpringPressFeedback(0.94f)
                        setOnClickListener {
                            cancelAutoCollapse()
                            submitOrQueuePrompt(chip.prompt)
                            releaseInputFocusToTermux()
                        }
                    }
                    sugHost.addView(chipView)
                }
            }
        }

        // 5. Demonstration Recorder Card (`agy_hud_demo_recorder_card`)
        val demoSession = demoRecorderManager.currentSession()
        val demoStepsHost = demoRecorderStepsContainer
        if ((demoSession.active || demoSession.steps.isNotEmpty()) && !isCollapsed && demoStepsHost != null) {
            demoRecorderCardContainer?.visibility = View.VISIBLE
            val statusPrefix = if (demoSession.active) "⏺ Recording" else "⏹ Recorded"
            demoRecorderHeaderText?.text = "$statusPrefix: ${demoSession.title} (${demoSession.steps.size} steps)"
            demoStepsHost.removeAllViews()
            demoSession.steps.takeLast(3).forEach { step ->
                val stepTv = TextView(context).apply {
                    text = step.summaryLine()
                    textSize = 10f
                    typeface = Typeface.MONOSPACE
                    setTextColor(theme.textPrimary)
                    maxLines = 1
                    ellipsize = TextUtils.TruncateAt.END
                }
                demoStepsHost.addView(stepTv)
            }
        } else {
            demoRecorderCardContainer?.visibility = View.GONE
        }

        // 6. Smart Clipboard & Cross-App Scratchpad Drawer (`agy_hud_scratchpad_card`)
        val padItems = scratchpadManager.currentItems()
        val padHost = scratchpadListContainer
        if ((isScratchpadDrawerOpen || padItems.isNotEmpty()) && !isCollapsed && padHost != null) {
            val showPad = isScratchpadDrawerOpen || padItems.any { it.pinned }
            if (showPad) {
                scratchpadCardContainer?.visibility = View.VISIBLE
                scratchpadHeaderText?.text = "📋 Smart Scratchpad (${padItems.size})"
                padHost.removeAllViews()
                padItems.take(4).forEachIndexed { idx, item ->
                    val row = LinearLayout(context).apply {
                        orientation = LinearLayout.HORIZONTAL
                        gravity = Gravity.CENTER_VERTICAL
                        layoutParams = LinearLayout.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.WRAP_CONTENT
                        ).apply { topMargin = (3 * d).toInt() }
                    }
                    val badgeTv = TextView(context).apply {
                        text = item.kind.uppercase(Locale.US)
                        textSize = 8.5f
                        typeface = Typeface.MONOSPACE
                        setTypeface(typeface, Typeface.BOLD)
                        setTextColor(Color.WHITE)
                        setPadding((5 * d).toInt(), (2 * d).toInt(), (5 * d).toInt(), (2 * d).toInt())
                        background = createLiquidGlassDrawable(
                            fillColor = when (item.kind) {
                                "url" -> COLOR_CYAN
                                "json" -> COLOR_AMBER
                                "code" -> COLOR_VIOLET
                                else -> COLOR_TEXT_SECONDARY
                            },
                            strokeColor = Color.TRANSPARENT,
                            radiusDp = 6f,
                            strokeDp = 0f
                        )
                        layoutParams = LinearLayout.LayoutParams(
                            ViewGroup.LayoutParams.WRAP_CONTENT,
                            ViewGroup.LayoutParams.WRAP_CONTENT
                        ).apply { marginEnd = (6 * d).toInt() }
                    }
                    val previewTv = TextView(context).apply {
                        text = (if (item.pinned) "📌 " else "") + item.displayPreview
                        textSize = 10f
                        setTextColor(theme.textPrimary)
                        maxLines = 1
                        ellipsize = TextUtils.TruncateAt.END
                        layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                    }
                    val askBtn = TextView(context).apply {
                        text = "↗ Ask"
                        textSize = 9.5f
                        setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
                        setTextColor(COLOR_CYAN)
                        setPadding((6 * d).toInt(), (2 * d).toInt(), (6 * d).toInt(), (2 * d).toInt())
                        contentDescription = "${HUD_NODE_TAG_PREFIX}scratchpad_ask_$idx"
                        setOnClickListener {
                            submitOrQueuePrompt("Use this ${item.kind} snippet: ${item.content}")
                        }
                    }
                    val copyBtn = TextView(context).apply {
                        text = "Copy"
                        textSize = 9.5f
                        setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
                        setTextColor(theme.textSecondary)
                        setPadding((6 * d).toInt(), (2 * d).toInt(), (6 * d).toInt(), (2 * d).toInt())
                        contentDescription = "${HUD_NODE_TAG_PREFIX}scratchpad_copy_$idx"
                        setOnClickListener {
                            scratchpadManager.copyItemToClipboard(item.id)
                        }
                    }
                    val pinBtn = TextView(context).apply {
                        text = if (item.pinned) "★" else "☆"
                        textSize = 10.5f
                        setTextColor(if (item.pinned) COLOR_AMBER else theme.textSecondary)
                        setPadding((4 * d).toInt(), (2 * d).toInt(), (4 * d).toInt(), (2 * d).toInt())
                        contentDescription = "${HUD_NODE_TAG_PREFIX}scratchpad_pin_$idx"
                        setOnClickListener {
                            scratchpadManager.togglePin(item.id)
                            _hudState.value = _hudState.value.copy(scratchpadItems = scratchpadManager.currentItems())
                            renderHudWindow()
                        }
                    }
                    row.addView(badgeTv)
                    row.addView(previewTv)
                    row.addView(askBtn)
                    row.addView(copyBtn)
                    row.addView(pinBtn)
                    padHost.addView(row)
                }
            } else {
                scratchpadCardContainer?.visibility = View.GONE
            }
        } else {
            scratchpadCardContainer?.visibility = View.GONE
        }

        // 7. Live Screen Diff & Visual Watchdog Card (`agy_hud_watchdog_card`)
        val wd = screenWatchdogManager.currentWatchdog()
        if ((wd.active || wd.lastTriggeredSummary.isNotBlank()) && !isCollapsed) {
            watchdogCardContainer?.visibility = View.VISIBLE
            val statusStr = if (wd.active) {
                wd.statusSummaryChip()
            } else {
                "✓ Watchdog Triggered: ${wd.lastTriggeredSummary}"
            }
            watchdogStatusText?.text = statusStr
        } else {
            watchdogCardContainer?.visibility = View.GONE
        }
    }

    private fun submitPromptFromInput() {
        val et = inputEditText ?: return
        val text = et.text?.toString()?.trim().orEmpty()
        if (text.isNotEmpty()) {
            submitOrQueuePrompt(text = text)
            et.setText("")
            updateInlineComposerControls()
            isCollapsed = false
            renderHudWindow()
        }
        releaseInputFocusToTermux()
    }

    private fun toggleVoiceDictationInternal() {
        val controller = voiceController ?: AgyVoiceInputController(
            context = context,
            onListeningChanged = { listening ->
                _isVoiceListeningFlow.value = listening
                runOnMain {
                    updateVoiceMicUi(listening)
                    renderHudWindow()
                }
            },
            onPartialText = { partial ->
                runOnMain {
                    inputEditText?.setText(partial)
                    inputEditText?.setSelection(partial.length)
                    updateInlineComposerControls()
                }
            },
            onFinalText = { finalText ->
                runOnMain {
                    inputEditText?.setText(finalText)
                    inputEditText?.setSelection(finalText.length)
                    updateInlineComposerControls()
                }
            },
            onErrorMessage = { err ->
                runOnMain {
                    composerVoiceStatusHint?.apply {
                        visibility = View.VISIBLE
                        text = err
                        setTextColor(COLOR_AMBER)
                    }
                    mainHandler.postDelayed({
                        if (!_isVoiceListeningFlow.value) {
                            composerVoiceStatusHint?.visibility = View.GONE
                        }
                    }, 2200L)
                }
            }
        ).also { voiceController = it }
        controller.toggleListening()
    }

    private fun updateVoiceMicUi(listening: Boolean) {
        composerVoiceStatusHint?.apply {
            visibility = if (listening) View.VISIBLE else View.GONE
            if (listening) {
                text = "● Listening…"
                setTextColor(COLOR_CORAL)
            }
        }
        inputMicBtn?.setStyle(
            glyph = AgyGlyphButtonView.Glyph.MIC,
            bgFill = if (listening) COLOR_CORAL else Color.WHITE,
            bgStroke = if (listening) COLOR_CORAL else COLOR_HAIRLINE,
            iconTint = if (listening) Color.WHITE else COLOR_TEXT_SECONDARY,
            strokeDp = 0.85f
        )
    }

    private fun renderInputMacrosStrip() {
        val host = inputMacrosContainer ?: return
        val scroll = inputMacrosScrollView ?: return
        val macros = _pinnedMacrosFlow.value
        val d = density()
        host.removeAllViews()
        if (macros.isEmpty() || !isMacrosDrawerOpen) {
            scroll.visibility = View.GONE
            return
        }
        scroll.visibility = View.VISIBLE
        macros.take(8).forEachIndexed { idx, macro ->
            val chipRow = LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding((8 * d).toInt(), (4 * d).toInt(), (10 * d).toInt(), (4 * d).toInt())
                background = createLiquidGlassDrawable(
                    fillColor = Color.parseColor("#F5F6F8"),
                    strokeColor = COLOR_HAIRLINE,
                    radiusDp = 999f,
                    strokeDp = 0.75f
                )
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { marginEnd = (6 * d).toInt() }
                contentDescription = "${HUD_NODE_TAG_PREFIX}macro_chip_$idx"
                attachSpringPressFeedback(0.94f)
                setOnClickListener {
                    cancelAutoCollapse()
                    isMacrosDrawerOpen = false
                    enqueueAndBroadcastCommand(text = macro.prompt, action = "PROMPT")
                    onMacroUsed?.invoke(macro.id)
                    releaseInputFocusToTermux()
                    isCollapsed = false
                    renderHudWindow()
                }
            }
            val badge = AgyIconBadgeView(context).apply {
                val sz = (15 * d).toInt()
                layoutParams = LinearLayout.LayoutParams(sz, sz).apply { marginEnd = (5 * d).toInt() }
                setIcon(
                    AgyAppIconResolver.resolve(
                        context = context,
                        explicitIcon = macro.iconHint,
                        explicitPackage = "",
                        fallbackText = "${macro.title} ${macro.prompt}"
                    )
                )
            }
            val lbl = TextView(context).apply {
                text = macro.title
                textSize = 10.5f
                setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
                setTextColor(COLOR_TEXT_PRIMARY)
                maxLines = 1
            }
            chipRow.addView(badge)
            chipRow.addView(lbl)
            host.addView(chipRow)
        }
        tagTreeForSelfExclusion(scroll, "macro_strip")
    }

    private fun updateInlineComposerControls() {
        val state = _hudState.value
        val draft = inputEditText?.text?.toString()?.trim().orEmpty()
        val hasDraft = draft.isNotEmpty()
        val st = state.state
        val isStopping = st == "STOPPING"
        val isActiveRun = st == "WORKING" || st == "PAUSED" || st == "NEEDS_INPUT" || isStopping
        val isListening = _isVoiceListeningFlow.value
        val hasMacros = _pinnedMacrosFlow.value.isNotEmpty()
        val baseAccent = when (st) {
            "WORKING" -> COLOR_CYAN
            "PAUSED", "NEEDS_INPUT" -> COLOR_AMBER
            "STOPPING", "STOPPED" -> COLOR_CORAL
            "DONE" -> COLOR_EMERALD
            else -> COLOR_VIOLET
        }
        val resolvedTheme = AgyHudDynamicModels.resolveTheme(state.theme, baseAccent)
        val layoutCfg = state.layout

        // Focus/voice glow border on the integrated bottom text field capsule (dark/light/custom adaptive)
        composerInputCapsule?.background = createLiquidGlassDrawable(
            fillColor = if (isInputFocused || isListening) resolvedTheme.surface else resolvedTheme.secondarySurface,
            strokeColor = when {
                isListening || isStopping -> COLOR_CORAL
                isInputFocused -> resolvedTheme.accent
                st == "NEEDS_INPUT" -> COLOR_AMBER
                else -> resolvedTheme.border
            },
            radiusDp = 999f,
            strokeDp = if (isInputFocused || isListening || isStopping) 1.35f else 0.9f
        )

        inputEditText?.setTextColor(resolvedTheme.textPrimary)
        inputEditText?.setHintTextColor(resolvedTheme.textSecondary)
        inputEditText?.hint = when {
            isListening -> "Listening…"
            isStopping -> "Tap ■ to force-stop…"
            layoutCfg.inputPlaceholder.isNotBlank() -> layoutCfg.inputPlaceholder
            st == "NEEDS_INPUT" -> "Reply to Agy…"
            st == "WORKING" || st == "PAUSED" -> "Message Agy…"
            else -> "Ask Agy…"
        }

        // Dynamic Mic visibility & theme tint
        inputMicBtn?.apply {
            visibility = if (layoutCfg.showMic) View.VISIBLE else View.GONE
            if (!isListening) {
                setStyle(
                    glyph = AgyGlyphButtonView.Glyph.MIC,
                    bgFill = resolvedTheme.surface,
                    bgStroke = resolvedTheme.border,
                    iconTint = resolvedTheme.textSecondary,
                    strokeDp = 0.85f
                )
            }
        }

        // Show subtle vector clear X only when text is entered
        clearDraftBtn?.visibility = if (hasDraft) View.VISIBLE else View.GONE

        // Show ⚡ Macros toggle button cleanly when pinned macros exist and enabled by layout
        macrosToggleBtn?.apply {
            visibility = if (hasMacros && layoutCfg.showMacros) View.VISIBLE else View.GONE
            setStyle(
                glyph = AgyGlyphButtonView.Glyph.BOLT,
                bgFill = if (isMacrosDrawerOpen) Color.argb(30, Color.red(resolvedTheme.accent), Color.green(resolvedTheme.accent), Color.blue(resolvedTheme.accent)) else resolvedTheme.surface,
                bgStroke = if (isMacrosDrawerOpen) Color.argb(105, Color.red(resolvedTheme.accent), Color.green(resolvedTheme.accent), Color.blue(resolvedTheme.accent)) else resolvedTheme.border,
                iconTint = if (isMacrosDrawerOpen) resolvedTheme.accent else resolvedTheme.textSecondary,
                strokeDp = 0.8f
            )
        }

        // Morph trailing orb between vector Send (↑), Stop (■), and solid coral Force-Stop (■)
        composerActionBtn?.let { btn ->
            val showStopOrb = !hasDraft && isActiveRun && layoutCfg.showStopButton
            val nextGlyph = if (showStopOrb) AgyGlyphButtonView.Glyph.STOP_SQUARE else AgyGlyphButtonView.Glyph.SEND_UP
            val glyphChanged = btn.glyph != nextGlyph
            if (showStopOrb) {
                if (isStopping) {
                    // Stage 2 ready: solid coral button indicates "Tap again to Force-Stop"
                    btn.setStyle(
                        glyph = AgyGlyphButtonView.Glyph.STOP_SQUARE,
                        bgFill = COLOR_CORAL,
                        bgStroke = COLOR_CORAL,
                        iconTint = Color.WHITE,
                        strokeDp = 1.1f
                    )
                    btn.contentDescription = "${HUD_NODE_TAG_PREFIX}force_stop_btn"
                } else {
                    btn.setStyle(
                        glyph = AgyGlyphButtonView.Glyph.STOP_SQUARE,
                        bgFill = Color.parseColor("#1AE11D48"),
                        bgStroke = Color.parseColor("#66E11D48"),
                        iconTint = COLOR_CORAL,
                        strokeDp = 1.0f
                    )
                    btn.contentDescription = "${HUD_NODE_TAG_PREFIX}stop_btn"
                }
            } else {
                val activeFill = when {
                    hasDraft -> resolvedTheme.accent
                    st == "NEEDS_INPUT" -> COLOR_AMBER
                    else -> Color.argb(30, Color.red(resolvedTheme.accent), Color.green(resolvedTheme.accent), Color.blue(resolvedTheme.accent))
                }
                btn.setStyle(
                    glyph = AgyGlyphButtonView.Glyph.SEND_UP,
                    bgFill = activeFill,
                    bgStroke = if (hasDraft || st == "NEEDS_INPUT") activeFill else Color.argb(80, Color.red(resolvedTheme.accent), Color.green(resolvedTheme.accent), Color.blue(resolvedTheme.accent)),
                    iconTint = if (hasDraft || st == "NEEDS_INPUT") Color.WHITE else resolvedTheme.accent,
                    strokeDp = 0.85f
                )
                btn.contentDescription = "${HUD_NODE_TAG_PREFIX}send_btn"
            }
            if (glyphChanged) {
                btn.animate().cancel()
                btn.scaleX = 0.78f
                btn.scaleY = 0.78f
                btn.animate()
                    .scaleX(1f)
                    .scaleY(1f)
                    .setDuration(190L)
                    .setInterpolator(android.view.animation.OvershootInterpolator(1.6f))
                    .start()
            }
        }
    }

    // -------------------------------------------------------------------------
    // Ghost Pass-Through, Opacity, Timers & Pulse Helpers
    // -------------------------------------------------------------------------

    private fun cycleOpacityInternal() {
        opacityIndex = (opacityIndex + 1) % OPACITY_LEVELS.size
        renderHudWindow()
    }

    private fun setGhostModeInternal(enabled: Boolean) {
        ghostPassThrough = enabled
        applyTouchableFlagsInternal(touchable = !enabled && !temporaryPassThroughActive)
        if (enabled) {
            showGhostRestorePillInternal()
        } else {
            hideGhostRestorePillInternal()
        }
        renderHudWindow()
    }

    private fun showGhostRestorePillInternal() {
        if (ghostRestoreView != null) return
        val wm = windowManager ?: return
        val d = density()
        val restoreBtn = TextView(context).apply {
            text = "👻 Un-Ghost"
            textSize = 10f
            setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
            setTextColor(COLOR_AMBER)
            setPadding((10 * d).toInt(), (5 * d).toInt(), (10 * d).toInt(), (5 * d).toInt())
            background = createLiquidGlassDrawable(
                fillColor = COLOR_OBSIDIAN_GLASS,
                strokeColor = COLOR_AMBER,
                radiusDp = 999f,
                strokeDp = 1f
            )
            setOnClickListener { setGhostModeInternal(false) }
        }
        tagTreeForSelfExclusion(restoreBtn, "ghost_restore")
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayWindowType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.END
            x = (14 * d).toInt()
            y = ((hudParams?.y ?: (28 * d).toInt()) + (235 * d).toInt())
        }
        ghostRestoreView = restoreBtn
        ghostRestoreParams = params
        try {
            wm.addView(restoreBtn, params)
        } catch (_: Exception) {
            ghostRestoreView = null
            ghostRestoreParams = null
        }
    }

    private fun hideGhostRestorePillInternal() {
        ghostRestoreView?.let { v ->
            try {
                windowManager?.removeView(v)
            } catch (_: Exception) {}
        }
        ghostRestoreView = null
        ghostRestoreParams = null
    }

    private fun applyTouchableFlagsInternal(touchable: Boolean) {
        fun updateWindow(view: View?, params: WindowManager.LayoutParams?) {
            if (view == null || params == null) return
            params.flags = if (touchable) {
                params.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
            } else {
                params.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
            }
            try {
                windowManager?.updateViewLayout(view, params)
            } catch (_: Exception) {}
        }
        updateWindow(hudRootView, hudParams)
    }

    private fun scheduleAutoCollapse(seconds: Int) {
        cancelAutoCollapse()
        val task = Runnable {
            if (isInputFocused || _isVoiceListeningFlow.value) return@Runnable
            isCollapsed = true
            blurInlineComposerInternal()
            if (hudRootView != null) {
                renderHudWindow()
            }
        }
        autoCollapseRunnable = task
        mainHandler.postDelayed(task, seconds * 1000L)
    }

    private fun cancelAutoCollapse() {
        autoCollapseRunnable?.let { mainHandler.removeCallbacks(it) }
        autoCollapseRunnable = null
    }

    private fun syncPulseAnimation() {
        val state = _hudState.value.state
        val shouldPulse = _isHudVisible.value && (state == "WORKING" || state == "NEEDS_INPUT" || state == "STOPPING")
        if (shouldPulse && pulseRunnable == null) {
            val runner = object : Runnable {
                override fun run() {
                    if (!_isHudVisible.value) {
                        stopPulseAnimation()
                        return
                    }
                    pulseToggle = !pulseToggle
                    statusDotView?.alpha = if (pulseToggle) 1.0f else 0.35f
                    if (_hudState.value.state == "NEEDS_INPUT") {
                        questionBannerText?.alpha = if (pulseToggle) 1.0f else 0.72f
                    } else {
                        questionBannerText?.alpha = 1.0f
                    }
                    if (_hudState.value.state == "STOPPING") {
                        composerActionBtn?.alpha = if (pulseToggle) 1.0f else 0.72f
                    } else {
                        composerActionBtn?.alpha = 1.0f
                    }
                    mainHandler.postDelayed(this, 650L)
                }
            }
            pulseRunnable = runner
            mainHandler.postDelayed(runner, 650L)
        } else if (!shouldPulse) {
            stopPulseAnimation()
        }
    }

    private fun stopPulseAnimation() {
        pulseRunnable?.let { mainHandler.removeCallbacks(it) }
        pulseRunnable = null
        statusDotView?.alpha = 1.0f
        questionBannerText?.alpha = 1.0f
        composerActionBtn?.alpha = 1.0f
    }

    private fun startElapsedTimer() {
        stopElapsedTimer()
        val ticker = object : Runnable {
            override fun run() {
                if (_hudState.value.state != "WORKING") {
                    stopElapsedTimer()
                    return
                }
                if (activeSegmentStartMs > 0L) {
                    _elapsedMsFlow.value = computeCurrentElapsedMs()
                    updateElapsedTimerDisplay()
                }
                mainHandler.postDelayed(this, 100L)
            }
        }
        elapsedTimerRunnable = ticker
        mainHandler.postDelayed(ticker, 100L)
    }

    private fun stopElapsedTimer() {
        elapsedTimerRunnable?.let { mainHandler.removeCallbacks(it) }
        elapsedTimerRunnable = null
    }

    private fun updateElapsedTimerDisplay() {
        val hud = _hudState.value
        val st = hud.state
        val elapsed = _elapsedMsFlow.value
        val resolvedTheme = AgyHudDynamicModels.resolveTheme(hud.theme, COLOR_CYAN)
        elapsedTimerText?.let { tv ->
            if (!hud.timerVisible) {
                tv.visibility = View.GONE
            } else if (hud.customTimerText.isNotBlank()) {
                tv.visibility = View.VISIBLE
                tv.text = "· ${hud.customTimerText}"
                tv.setTextColor(resolvedTheme.textSecondary)
            } else when {
                st == "WORKING" -> {
                    tv.visibility = View.VISIBLE
                    tv.text = "· ${formatElapsed(elapsed, isDone = false)}"
                    tv.setTextColor(resolvedTheme.textSecondary)
                }
                st == "PAUSED" -> {
                    tv.visibility = View.VISIBLE
                    tv.text = "· ${formatElapsed(elapsed, isDone = false)}"
                    tv.setTextColor(COLOR_AMBER)
                }
                st == "STOPPING" || (st == "STOPPED" && elapsed > 0L) -> {
                    tv.visibility = View.VISIBLE
                    tv.text = "· ${formatElapsed(elapsed, isDone = false)}"
                    tv.setTextColor(COLOR_CORAL)
                }
                st == "DONE" && elapsed > 0L -> {
                    tv.visibility = View.VISIBLE
                    tv.text = "· ${formatElapsed(elapsed, isDone = true).removePrefix("Done ")}"
                    tv.setTextColor(COLOR_EMERALD)
                }
                st == "NEEDS_INPUT" && elapsed > 0L -> {
                    tv.visibility = View.VISIBLE
                    tv.text = "· ${formatElapsed(elapsed, isDone = false)}"
                    tv.setTextColor(COLOR_AMBER)
                }
                else -> {
                    tv.visibility = View.GONE
                }
            }
        }
        dockLiveTimerText?.let { liveTv ->
            if (!hud.timerVisible) {
                liveTv.visibility = View.GONE
            } else if (hud.customTimerText.isNotBlank()) {
                liveTv.visibility = View.VISIBLE
                liveTv.text = hud.customTimerText
            } else if (st == "WORKING" || st == "PAUSED" || st == "STOPPING") {
                liveTv.visibility = View.VISIBLE
                liveTv.text = formatElapsed(elapsed, isDone = false)
                liveTv.setTextColor(if (st == "PAUSED") COLOR_AMBER else COLOR_TEXT_SECONDARY)
            }
        }
    }

    private fun snapHudToNearestEdge() {
        val root = hudRootView ?: return
        val params = hudParams ?: return
        val d = density()
        val vp = layoutCoordinator.currentViewportSafeBounds()
        val viewW = root.width.takeIf { it > 0 }
            ?: if (isCollapsed) estimateHudCollapsedWidthPx() else estimateHudExpandedWidthPx()
        val viewH = root.height.takeIf { it > 0 }
            ?: if (isCollapsed) estimateHudCollapsedHeightPx() else estimateHudExpandedHeightPx()
        val currentRect = computeHudScreenRect(vp, viewW, viewH)

        val leftSnap = vp.safeLeft
        val rightSnap = (vp.safeRight - viewW).coerceAtLeast(vp.safeLeft)
        val midLeft = (leftSnap + rightSnap) / 2
        val targetLeft = if (currentRect.left < midLeft) leftSnap else rightSnap
        val (clampedLeft, clampedTop) = AgyOverlayLayoutCoordinator.clampTopLeftToSafeBounds(
            left = targetLeft,
            top = currentRect.top,
            width = viewW,
            height = viewH,
            viewport = vp
        )
        val (targetX, targetY) = AgyOverlayLayoutCoordinator.screenTopLeftToWindowOffset(
            gravity = params.gravity,
            targetLeft = clampedLeft,
            targetTop = clampedTop,
            width = viewW,
            height = viewH,
            screenWidth = vp.screenWidth,
            screenHeight = vp.screenHeight
        )
        val startX = params.x
        val startY = params.y
        if (abs(startX - targetX) <= 2 && abs(startY - targetY) <= 2) {
            layoutCoordinator.notifyDragEnd(AgyOverlayLayoutCoordinator.ManagedWindowId.HUD, animate = true)
            return
        }

        edgeSnapAnimator?.cancel()
        pendingHudTargetLeft = clampedLeft
        pendingHudTargetTop = clampedTop
        // Immediately notify coordinator of our snap destination so Task Map dodges smoothly in sync
        layoutCoordinator.notifyDragEnd(AgyOverlayLayoutCoordinator.ManagedWindowId.HUD, animate = true)

        val animatorsEnabled = Build.VERSION.SDK_INT < Build.VERSION_CODES.O || android.animation.ValueAnimator.areAnimatorsEnabled()
        if (!animatorsEnabled) {
            pendingHudTargetLeft = null
            pendingHudTargetTop = null
            params.x = targetX
            params.y = targetY
            try {
                windowManager?.updateViewLayout(root, params)
            } catch (_: Exception) {}
            return
        }

        edgeSnapAnimator = android.animation.ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 250L
            interpolator = android.view.animation.OvershootInterpolator(0.75f)
            addUpdateListener { anim ->
                val f = anim.animatedValue as Float
                params.x = (startX + (targetX - startX) * f).toInt().coerceAtLeast(0)
                params.y = (startY + (targetY - startY) * f).toInt().coerceAtLeast(0)
                try {
                    windowManager?.updateViewLayout(root, params)
                } catch (_: Exception) {}
                if (f >= 1f) {
                    pendingHudTargetLeft = null
                    pendingHudTargetTop = null
                }
            }
            start()
        }
    }

    // -------------------------------------------------------------------------
    // Utility Helpers & Layout Coordinator Geometry Helpers
    // -------------------------------------------------------------------------

    private fun estimateHudExpandedWidthPx(): Int {
        val d = density()
        val screenW = context.resources.displayMetrics.widthPixels.coerceAtLeast(360)
        val layout = _hudState.value.layout
        val fallback = if (layout.widthFraction != null) {
            (screenW * layout.widthFraction.coerceIn(0.60f, 0.96f)).toInt()
        } else {
            min((304 * d).toInt(), (screenW * 0.90f).toInt())
        }
        return lastMeasuredExpandedWidthPx.takeIf { it > 0 }
            ?: hudExpandedContainer?.width?.takeIf { it > 0 && !isCollapsed }
            ?: fallback
    }

    private fun estimateHudExpandedHeightPx(): Int {
        val d = density()
        val fallbackDp = when {
            isDetailsExpanded && isOutputExpanded -> 390f
            isDetailsExpanded -> 300f
            else -> 185f
        }
        return lastMeasuredExpandedHeightPx.takeIf { it > 0 }
            ?: hudExpandedContainer?.height?.takeIf { it > 0 && !isCollapsed }
            ?: (fallbackDp * d).toInt()
    }

    private fun estimateHudCollapsedWidthPx(): Int {
        val d = density()
        return lastMeasuredCollapsedWidthPx.takeIf { it > 0 }
            ?: hudBottomDockRow?.width?.takeIf { it > 0 && isCollapsed }
            ?: (196 * d).toInt()
    }

    private fun estimateHudCollapsedHeightPx(): Int {
        val d = density()
        return lastMeasuredCollapsedHeightPx.takeIf { it > 0 }
            ?: hudBottomDockRow?.height?.takeIf { it > 0 && isCollapsed }
            ?: (46 * d).toInt()
    }

    private fun computeHudScreenRect(
        viewport: AgyOverlayLayoutCoordinator.ViewportSafeBounds,
        width: Int,
        height: Int
    ): Rect {
        val tL = pendingHudTargetLeft
        val tT = pendingHudTargetTop
        if (tL != null && tT != null) {
            return Rect(tL, tT, tL + width, tT + height)
        }
        val params = hudParams
            ?: return Rect(viewport.safeRight - width, viewport.safeBottom - height, viewport.safeRight, viewport.safeBottom)
        if (isInputFocused) {
            // While IME is active, Android docks the bottom-anchored HUD directly above the keyboard (viewport.safeBottom)
            val baseRect = AgyOverlayLayoutCoordinator.windowParamsToScreenRect(
                params = params,
                width = width,
                height = height,
                screenWidth = viewport.screenWidth,
                screenHeight = viewport.screenHeight
            )
            val dockedTop = (viewport.safeBottom - height).coerceAtLeast(viewport.safeTop)
            return Rect(baseRect.left, dockedTop, baseRect.left + width, dockedTop + height)
        }
        return AgyOverlayLayoutCoordinator.windowParamsToScreenRect(
            params = params,
            width = width,
            height = height,
            screenWidth = viewport.screenWidth,
            screenHeight = viewport.screenHeight
        )
    }

    private fun moveHudToScreenTopLeft(
        targetLeft: Int,
        targetTop: Int,
        viewport: AgyOverlayLayoutCoordinator.ViewportSafeBounds,
        animate: Boolean
    ) {
        val root = hudRootView ?: return
        val params = hudParams ?: return
        val w = if (isCollapsed) estimateHudCollapsedWidthPx() else estimateHudExpandedWidthPx()
        val h = if (isCollapsed) estimateHudCollapsedHeightPx() else estimateHudExpandedHeightPx()
        val (safeL, safeT) = AgyOverlayLayoutCoordinator.clampTopLeftToSafeBounds(
            left = targetLeft,
            top = targetTop,
            width = w,
            height = h,
            viewport = viewport
        )
        val (targetX, targetY) = AgyOverlayLayoutCoordinator.screenTopLeftToWindowOffset(
            gravity = params.gravity,
            targetLeft = safeL,
            targetTop = safeT,
            width = w,
            height = h,
            screenWidth = viewport.screenWidth,
            screenHeight = viewport.screenHeight
        )

        val startX = params.x
        val startY = params.y
        edgeSnapAnimator?.cancel()
        hudDodgeAnimator?.cancel()
        hudDodgeAnimator = null

        if (abs(startX - targetX) <= 2 && abs(startY - targetY) <= 2) {
            pendingHudTargetLeft = null
            pendingHudTargetTop = null
            return
        }

        val animatorsEnabled = Build.VERSION.SDK_INT < Build.VERSION_CODES.O || android.animation.ValueAnimator.areAnimatorsEnabled()
        val canAnimate = animate && animatorsEnabled
        if (!canAnimate) {
            pendingHudTargetLeft = null
            pendingHudTargetTop = null
            params.x = targetX
            params.y = targetY
            try {
                windowManager?.updateViewLayout(root, params)
            } catch (_: Exception) {}
            return
        }

        pendingHudTargetLeft = safeL
        pendingHudTargetTop = safeT
        hudDodgeAnimator = android.animation.ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 190L
            interpolator = android.view.animation.DecelerateInterpolator()
            addUpdateListener { anim ->
                val f = anim.animatedValue as Float
                params.x = (startX + (targetX - startX) * f).toInt().coerceAtLeast(0)
                params.y = (startY + (targetY - startY) * f).toInt().coerceAtLeast(0)
                try {
                    windowManager?.updateViewLayout(root, params)
                } catch (_: Exception) {}
                if (f >= 1f) {
                    pendingHudTargetLeft = null
                    pendingHudTargetTop = null
                }
            }
            start()
        }
    }

    private fun scheduleHudLayoutReconcile() {
        if (!hudLayoutReconcileScheduled) {
            hudLayoutReconcileScheduled = true
            mainHandler.post(hudLayoutReconcileRunnable)
        }
    }

    private fun shiftBottomRightWindow(
        root: View,
        params: WindowManager.LayoutParams,
        dx: Float,
        dy: Float
    ) {
        val vp = layoutCoordinator.currentViewportSafeBounds()
        val viewW = root.width.takeIf { it > 0 }
            ?: if (isCollapsed) estimateHudCollapsedWidthPx() else estimateHudExpandedWidthPx()
        val viewH = root.height.takeIf { it > 0 }
            ?: if (isCollapsed) estimateHudCollapsedHeightPx() else estimateHudExpandedHeightPx()
        val currentRect = AgyOverlayLayoutCoordinator.windowParamsToScreenRect(
            params = params,
            width = viewW,
            height = viewH,
            screenWidth = vp.screenWidth,
            screenHeight = vp.screenHeight
        )
        val (clampedLeft, clampedTop) = AgyOverlayLayoutCoordinator.clampTopLeftToSafeBounds(
            left = currentRect.left + dx.toInt(),
            top = currentRect.top + dy.toInt(),
            width = viewW,
            height = viewH,
            viewport = vp
        )
        val (nextX, nextY) = AgyOverlayLayoutCoordinator.screenTopLeftToWindowOffset(
            gravity = params.gravity,
            targetLeft = clampedLeft,
            targetTop = clampedTop,
            width = viewW,
            height = viewH,
            screenWidth = vp.screenWidth,
            screenHeight = vp.screenHeight
        )
        params.x = nextX
        params.y = nextY
        try {
            windowManager?.updateViewLayout(root, params)
        } catch (_: Exception) {}
    }

    private fun createLiquidGlassDrawable(
        fillColor: Int,
        strokeColor: Int,
        radiusDp: Float,
        strokeDp: Float = 1.2f
    ): GradientDrawable {
        val d = density()
        return GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = radiusDp * d
            setColor(fillColor)
            setStroke((strokeDp * d).toInt().coerceAtLeast(1), strokeColor)
        }
    }

    private fun tagTreeForSelfExclusion(view: View, suffix: String) {
        val existing = view.contentDescription?.toString()
        if (existing.isNullOrBlank() || !existing.startsWith(HUD_NODE_TAG_PREFIX)) {
            view.contentDescription = "$HUD_NODE_TAG_PREFIX$suffix"
        }
        view.tag = "$HUD_NODE_TAG_PREFIX$suffix"
        if (view is ViewGroup) {
            for (i in 0 until view.childCount) {
                tagTreeForSelfExclusion(view.getChildAt(i), "${suffix}_$i")
            }
        }
    }

    private fun overlayWindowType(): Int {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }
    }

    private fun density(): Float = context.resources.displayMetrics.density.coerceAtLeast(1f)

    private fun runOnMain(block: () -> Unit) {
        if (Looper.myLooper() == Looper.getMainLooper()) {
            block()
        } else {
            mainHandler.post(block)
        }
    }
}
