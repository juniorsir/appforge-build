package com.kavach.ui.overlay

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.os.Handler
import android.os.Looper
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.LinearInterpolator
import android.widget.LinearLayout
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.sin

/**
 * Smooth 60fps Canvas-drawn rotating spinner ring for active WORKING HUD states.
 */
class AgySpinnerRingView(context: Context) : View(context) {
    private val density = context.resources.displayMetrics.density.coerceAtLeast(1f)
    private var sweepAngleDeg = 0f
    private var isRunning = false
    private var animator: ValueAnimator? = null

    private val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2.0f * density
        color = Color.parseColor("#260095F6")
    }

    private val arcPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2.2f * density
        strokeCap = Paint.Cap.ROUND
        color = Color.parseColor("#0095F6")
    }

    private val bounds = RectF()

    fun setAccentColor(color: Int) {
        arcPaint.color = color
        trackPaint.color = Color.argb(38, Color.red(color), Color.green(color), Color.blue(color))
        invalidate()
    }

    fun setAnimating(active: Boolean) {
        if (active == isRunning) return
        isRunning = active
        if (active) {
            startAnimator()
        } else {
            stopAnimator()
        }
    }

    private fun startAnimator() {
        stopAnimator()
        animator = ValueAnimator.ofFloat(0f, 360f).apply {
            duration = 900L
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener { anim ->
                sweepAngleDeg = anim.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    private fun stopAnimator() {
        animator?.cancel()
        animator = null
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (isRunning && animator == null) {
            startAnimator()
        }
    }

    override fun onDetachedFromWindow() {
        stopAnimator()
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val pad = arcPaint.strokeWidth * 0.65f
        bounds.set(pad, pad, width - pad, height - pad)
        if (bounds.width() <= 0f || bounds.height() <= 0f) return
        canvas.drawOval(bounds, trackPaint)
        canvas.drawArc(bounds, sweepAngleDeg - 90f, 250f, false, arcPaint)
    }
}

/**
 * Slim indeterminate sliding progress bar spanning the top edge of the working HUD card.
 */
class AgyLoadingBarView(context: Context) : View(context) {
    private val density = context.resources.displayMetrics.density.coerceAtLeast(1f)
    private var progress = 0f
    private var determinateFraction: Float? = null
    private var isRunning = false
    private var animator: ValueAnimator? = null
    private var accentStartColor: Int = Color.parseColor("#0095F6")
    private var accentEndColor: Int = Color.parseColor("#4F46E5")

    private val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.parseColor("#E2E8F0")
    }

    private val barPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.parseColor("#0095F6")
    }

    private val trackRect = RectF()
    private val barRect = RectF()

    fun setColors(accentColor: Int, trackColor: Int = Color.parseColor("#E2E8F0")) {
        accentStartColor = accentColor
        accentEndColor = accentColor
        trackPaint.color = trackColor
        invalidate()
    }

    fun setDeterminateProgress(fraction: Float?) {
        determinateFraction = fraction?.coerceIn(0f, 1f)
        if (determinateFraction != null) {
            visibility = VISIBLE
            isRunning = false
            stopAnimator()
            invalidate()
        }
    }

    fun setAnimating(active: Boolean) {
        if (determinateFraction != null) {
            visibility = VISIBLE
            stopAnimator()
            return
        }
        visibility = if (active) VISIBLE else GONE
        if (active == isRunning) return
        isRunning = active
        if (active) {
            startAnimator()
        } else {
            stopAnimator()
        }
    }

    private fun startAnimator() {
        stopAnimator()
        animator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 1250L
            repeatCount = ValueAnimator.INFINITE
            interpolator = AccelerateDecelerateInterpolator()
            addUpdateListener { anim ->
                progress = anim.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    private fun stopAnimator() {
        animator?.cancel()
        animator = null
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (isRunning && determinateFraction == null && animator == null) {
            startAnimator()
        }
    }

    override fun onDetachedFromWindow() {
        stopAnimator()
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        val radius = h * 0.5f
        trackRect.set(0f, 0f, w, h)
        canvas.drawRoundRect(trackRect, radius, radius, trackPaint)

        val det = determinateFraction
        if (det != null) {
            val right = (w * det).coerceIn(if (det > 0f) h else 0f, w)
            if (right > 0f) {
                barPaint.shader = LinearGradient(
                    0f, 0f, right, 0f,
                    accentStartColor,
                    accentEndColor,
                    Shader.TileMode.CLAMP
                )
                barRect.set(0f, 0f, right, h)
                canvas.drawRoundRect(barRect, radius, radius, barPaint)
            }
            return
        }

        val segWidth = w * 0.38f
        val startX = -segWidth + (w + segWidth) * progress
        val left = startX.coerceIn(0f, w)
        val right = (startX + segWidth).coerceIn(0f, w)
        if (right > left) {
            barPaint.shader = LinearGradient(
                left, 0f, right, 0f,
                accentStartColor,
                accentEndColor,
                Shader.TileMode.CLAMP
            )
            barRect.set(left, 0f, right, h)
            canvas.drawRoundRect(barRect, radius, radius, barPaint)
        }
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val desiredH = (3.5f * density).toInt().coerceAtLeast(4)
        val w = MeasureSpec.getSize(widthMeasureSpec)
        setMeasuredDimension(w, resolveSize(desiredH, heightMeasureSpec))
    }
}

/**
 * Three staggered bouncing loading dots displayed beside the active "Doing now" line.
 */
class AgyBouncingDotsView(context: Context) : View(context) {
    private val density = context.resources.displayMetrics.density.coerceAtLeast(1f)
    private var phase = 0f
    private var isRunning = false
    private var animator: ValueAnimator? = null

    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.parseColor("#0095F6")
    }

    fun setAccentColor(color: Int) {
        dotPaint.color = color
        invalidate()
    }

    fun setAnimating(active: Boolean) {
        visibility = if (active) VISIBLE else GONE
        if (active == isRunning) return
        isRunning = active
        if (active) {
            startAnimator()
        } else {
            stopAnimator()
        }
    }

    private fun startAnimator() {
        stopAnimator()
        animator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 960L
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener { anim ->
                phase = anim.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    private fun stopAnimator() {
        animator?.cancel()
        animator = null
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (isRunning && animator == null) {
            startAnimator()
        }
    }

    override fun onDetachedFromWindow() {
        stopAnimator()
        super.onDetachedFromWindow()
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = (24f * density).toInt()
        val h = (14f * density).toInt()
        setMeasuredDimension(resolveSize(w, widthMeasureSpec), resolveSize(h, heightMeasureSpec))
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val r = 2.0f * density
        val spacing = 6.5f * density
        val baseY = height * 0.62f
        val lift = 3.2f * density
        val startX = (width - spacing * 2f) * 0.5f

        for (i in 0 until 3) {
            val dotPhase = (phase + i * 0.22f) % 1f
            val wave = sin(dotPhase * 2.0 * PI).toFloat().coerceAtLeast(0f)
            val cy = baseY - wave * lift
            dotPaint.alpha = (115 + (140 * wave).toInt()).coerceIn(115, 255)
            canvas.drawCircle(startX + i * spacing, cy, r, dotPaint)
        }
    }
}

/**
 * Container-level press-and-hold unified drag layout.
 *
 * Pressing and holding (~180ms) ANYWHERE on the dock — even directly over buttons, text, or the
 * bottom Chat pill — activates drag mode with subtle haptic feedback & lift scale and moves the
 * entire unified dock smoothly. Quick taps (<180ms) pass cleanly through to child click listeners.
 */
class HoldDraggableDockLayout(
    context: Context,
    private val holdThresholdMs: Long = 250L
) : LinearLayout(context) {

    var onDragStart: (() -> Unit)? = null
    var onDragDelta: ((dx: Float, dy: Float) -> Unit)? = null
    var onDragEnd: (() -> Unit)? = null
    var onOutsideTouch: (() -> Unit)? = null
    var onHorizontalSwipe: (() -> Unit)? = null

    private val density = context.resources.displayMetrics.density.coerceAtLeast(1f)
    private val holdSlopPx = 18f * density
    private val swipeThresholdPx = 68f * density
    private val handler = Handler(Looper.getMainLooper())

    private var downRawX = 0f
    private var downRawY = 0f
    private var lastRawX = 0f
    private var lastRawY = 0f
    private var holdTriggered = false
    private var pointerDown = false
    private var startedInHorizontalScroller = false

    private val holdRunnable = Runnable {
        if (pointerDown && !holdTriggered) {
            holdTriggered = true
            lastRawX = downRawX
            lastRawY = downRawY
            try {
                performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            } catch (_: Exception) {}
            animate().scaleX(1.03f).scaleY(1.03f).setDuration(110L).start()
            onDragStart?.invoke()
        }
    }

    private fun isPointInInteractiveTextOrScroller(view: View, rawX: Float, rawY: Float): Boolean {
        if (view.visibility != VISIBLE) return false
        val loc = IntArray(2)
        view.getLocationOnScreen(loc)
        val inside = rawX >= loc[0] && rawX <= loc[0] + view.width &&
            rawY >= loc[1] && rawY <= loc[1] + view.height
        if (!inside) return false
        if (view is android.widget.HorizontalScrollView ||
            view is android.widget.EditText ||
            view is AgyGlyphButtonView
        ) return true
        if (view is android.view.ViewGroup) {
            for (i in 0 until view.childCount) {
                if (isPointInInteractiveTextOrScroller(view.getChildAt(i), rawX, rawY)) return true
            }
        }
        return false
    }

    override fun onInterceptTouchEvent(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                pointerDown = true
                holdTriggered = false
                downRawX = ev.rawX
                downRawY = ev.rawY
                lastRawX = ev.rawX
                lastRawY = ev.rawY
                startedInHorizontalScroller = isPointInInteractiveTextOrScroller(this, ev.rawX, ev.rawY)
                handler.removeCallbacks(holdRunnable)
                if (!startedInHorizontalScroller) {
                    handler.postDelayed(holdRunnable, holdThresholdMs)
                }
                return false
            }
            MotionEvent.ACTION_MOVE -> {
                if (holdTriggered) {
                    return true
                }
                val dx = ev.rawX - downRawX
                val dy = ev.rawY - downRawY
                if (abs(dx) > holdSlopPx || abs(dy) > holdSlopPx) {
                    // User swiped quickly (e.g. scrolling task list or horizontal flick) before hold threshold
                    handler.removeCallbacks(holdRunnable)
                }
                if (onHorizontalSwipe != null && !startedInHorizontalScroller &&
                    abs(dx) > swipeThresholdPx && abs(dx) > abs(dy) * 1.8f
                ) {
                    pointerDown = false
                    handler.removeCallbacks(holdRunnable)
                    onHorizontalSwipe?.invoke()
                    return true
                }
                return false
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                handler.removeCallbacks(holdRunnable)
                pointerDown = false
                if (holdTriggered) {
                    finishDrag()
                    return true
                }
                return false
            }
        }
        return super.onInterceptTouchEvent(ev)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_OUTSIDE -> {
                onOutsideTouch?.invoke()
                return true
            }
            MotionEvent.ACTION_DOWN -> {
                // Non-clickable background inside dock still starts hold-to-drag
                pointerDown = true
                holdTriggered = false
                downRawX = event.rawX
                downRawY = event.rawY
                lastRawX = event.rawX
                lastRawY = event.rawY
                handler.removeCallbacks(holdRunnable)
                handler.postDelayed(holdRunnable, holdThresholdMs)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (holdTriggered) {
                    val dx = event.rawX - lastRawX
                    val dy = event.rawY - lastRawY
                    lastRawX = event.rawX
                    lastRawY = event.rawY
                    if (dx != 0f || dy != 0f) {
                        onDragDelta?.invoke(dx, dy)
                    }
                    return true
                }
                val distX = event.rawX - downRawX
                val distY = event.rawY - downRawY
                if (abs(distX) > holdSlopPx || abs(distY) > holdSlopPx) {
                    handler.removeCallbacks(holdRunnable)
                }
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                handler.removeCallbacks(holdRunnable)
                pointerDown = false
                if (holdTriggered) {
                    finishDrag()
                    return true
                }
                return true
            }
        }
        return super.onTouchEvent(event)
    }

    private fun finishDrag() {
        holdTriggered = false
        animate()
            .scaleX(1.0f)
            .scaleY(1.0f)
            .setDuration(165L)
            .setInterpolator(android.view.animation.OvershootInterpolator(1.1f))
            .start()
        onDragEnd?.invoke()
    }

    override fun onDetachedFromWindow() {
        handler.removeCallbacks(holdRunnable)
        pointerDown = false
        holdTriggered = false
        super.onDetachedFromWindow()
    }
}

/**
 * Gemini-inspired frosted card container with a smooth 60fps sweeping Aurora Shimmer Border
 * and layered ambient halo glow while WORKING, typing (INPUT_ACTIVE), or listening (VOICE_LISTENING),
 * soft breathing Amber rim on NEEDS_INPUT, warm static Amber on PAUSED, calm Emerald pulse on DONE,
 * and clean Crisp Hairline when IDLE.
 */
class AgyAuroraCardLayout(context: Context) : LinearLayout(context) {

    enum class RimMode { IDLE, WORKING, PAUSED, NEEDS_INPUT, STOPPING, STOPPED, DONE, INPUT_ACTIVE, VOICE_LISTENING }

    private val density = context.resources.displayMetrics.density.coerceAtLeast(1f)
    private var cornerRadiusPx = 24f * density
    private val auroraMatrix = android.graphics.Matrix()
    private val borderRect = RectF()
    private val haloRect = RectF()
    private val fillRect = RectF()

    private var rimMode: RimMode = RimMode.IDLE
    private var sweepDeg = 0f
    private var pulsePhase = 0f
    private var completionFlashAlpha = 0f
    private var animator: ValueAnimator? = null
    private var completionAnimator: ValueAnimator? = null
    private var dynamicIdleBorderColor: Int = Color.parseColor("#FFE5E9F0")
    private var dynamicAccentColor: Int? = null
    private var dynamicAuroraEnabled: Boolean = true

    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.WHITE
    }

    private val haloPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 5.5f * density
        color = Color.TRANSPARENT
    }

    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1.6f * density
        color = Color.parseColor("#FFE5E9F0")
    }

    private val defaultAuroraColors = intArrayOf(
        Color.parseColor("#0095F6"),
        Color.parseColor("#4F46E5"),
        Color.parseColor("#8B5CF6"),
        Color.parseColor("#38BDF8"),
        Color.parseColor("#0095F6")
    )
    private var activeAuroraColors: IntArray = defaultAuroraColors

    private val voiceColors = intArrayOf(
        Color.parseColor("#E11D48"),
        Color.parseColor("#8B5CF6"),
        Color.parseColor("#0095F6"),
        Color.parseColor("#FB7185"),
        Color.parseColor("#E11D48")
    )

    private var sweepShader: android.graphics.SweepGradient? = null
    private var voiceSweepShader: android.graphics.SweepGradient? = null

    init {
        setWillNotDraw(false)
    }

    fun applyDynamicTheme(
        surfaceColor: Int,
        idleBorderColor: Int,
        accentColor: Int?,
        customAuroraColors: IntArray?,
        auroraEnabled: Boolean,
        cornerRadiusDp: Float
    ) {
        bgPaint.color = surfaceColor
        dynamicIdleBorderColor = idleBorderColor
        dynamicAccentColor = accentColor
        dynamicAuroraEnabled = auroraEnabled
        cornerRadiusPx = cornerRadiusDp.coerceIn(8f, 36f) * density
        val nextAurora = customAuroraColors ?: defaultAuroraColors
        if (!activeAuroraColors.contentEquals(nextAurora)) {
            activeAuroraColors = nextAurora
            if (width > 0 && height > 0) {
                sweepShader = android.graphics.SweepGradient(
                    width * 0.5f,
                    height * 0.5f,
                    activeAuroraColors,
                    null
                )
            }
        }
        invalidate()
    }

    fun setRimMode(mode: RimMode) {
        if (rimMode == mode) return
        rimMode = mode
        when (mode) {
            RimMode.WORKING -> startSweepAnimator(2600L)
            RimMode.INPUT_ACTIVE -> startSweepAnimator(3400L)
            RimMode.VOICE_LISTENING -> startSweepAnimator(1500L)
            RimMode.STOPPING -> startSweepAnimator(1150L)
            RimMode.NEEDS_INPUT -> startSweepAnimator(1600L)
            RimMode.PAUSED, RimMode.STOPPED, RimMode.DONE, RimMode.IDLE -> {
                stopAnimator()
                invalidate()
            }
        }
    }

    fun playCompletionPulse() {
        completionAnimator?.cancel()
        completionAnimator = ValueAnimator.ofFloat(1f, 0f).apply {
            duration = 560L
            interpolator = AccelerateDecelerateInterpolator()
            addUpdateListener { anim ->
                completionFlashAlpha = anim.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    fun stopAurora() {
        stopAnimator()
        completionAnimator?.cancel()
        completionAnimator = null
        completionFlashAlpha = 0f
    }

    private fun startSweepAnimator(durationMs: Long) {
        stopAnimator()
        animator = ValueAnimator.ofFloat(0f, 360f).apply {
            duration = durationMs
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener { anim ->
                sweepDeg = anim.animatedValue as Float
                pulsePhase = (sweepDeg / 360f)
                invalidate()
            }
            start()
        }
    }

    private fun stopAnimator() {
        animator?.cancel()
        animator = null
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        if (w > 0 && h > 0) {
            sweepShader = android.graphics.SweepGradient(
                w * 0.5f,
                h * 0.5f,
                activeAuroraColors,
                null
            )
            voiceSweepShader = android.graphics.SweepGradient(
                w * 0.5f,
                h * 0.5f,
                voiceColors,
                null
            )
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        val animated = rimMode == RimMode.WORKING ||
            rimMode == RimMode.NEEDS_INPUT ||
            rimMode == RimMode.STOPPING ||
            rimMode == RimMode.INPUT_ACTIVE ||
            rimMode == RimMode.VOICE_LISTENING
        if (animated && animator == null) {
            val dur = when (rimMode) {
                RimMode.WORKING -> 2600L
                RimMode.INPUT_ACTIVE -> 3400L
                RimMode.VOICE_LISTENING -> 1500L
                RimMode.STOPPING -> 1150L
                else -> 1600L
            }
            startSweepAnimator(dur)
        }
    }

    override fun onDetachedFromWindow() {
        stopAurora()
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) {
            super.onDraw(canvas)
            return
        }
        val stroke = when (rimMode) {
            RimMode.WORKING -> 2.1f * density
            RimMode.VOICE_LISTENING -> 2.2f * density
            RimMode.STOPPING -> 2.2f * density
            RimMode.INPUT_ACTIVE -> 1.9f * density
            RimMode.PAUSED -> 1.6f * density
            RimMode.NEEDS_INPUT -> 1.8f * density
            RimMode.STOPPED -> 1.3f * density
            RimMode.DONE -> 1.4f * density
            RimMode.IDLE -> 1.0f * density
        }
        val half = stroke * 0.5f
        fillRect.set(half, half, w - half, h - half)
        borderRect.set(half, half, w - half, h - half)

        canvas.drawRoundRect(fillRect, cornerRadiusPx, cornerRadiusPx, bgPaint)

        // Subtle inner-edge ambient glow halo during active Gemini modes
        val drawGlow = (dynamicAuroraEnabled && (
            rimMode == RimMode.WORKING ||
                rimMode == RimMode.INPUT_ACTIVE ||
                rimMode == RimMode.VOICE_LISTENING
            )) || rimMode == RimMode.STOPPING || completionFlashAlpha > 0.02f
        if (drawGlow) {
            val haloInset = 2.6f * density
            haloRect.set(haloInset, haloInset, w - haloInset, h - haloInset)
            haloPaint.strokeWidth = 4.6f * density
            if (completionFlashAlpha > 0.02f) {
                haloPaint.shader = null
                haloPaint.color = Color.argb((completionFlashAlpha * 95f).toInt().coerceIn(0, 95), 22, 163, 74)
            } else if (rimMode == RimMode.STOPPING) {
                haloPaint.shader = null
                val wave = 0.45f + 0.55f * sin(pulsePhase * 2.0 * PI).toFloat()
                haloPaint.color = Color.argb((wave * 88f).toInt().coerceIn(28, 88), 225, 29, 72)
            } else {
                val activeShader = if (rimMode == RimMode.VOICE_LISTENING) voiceSweepShader else sweepShader
                if (activeShader != null) {
                    auroraMatrix.reset()
                    auroraMatrix.setRotate(sweepDeg, w * 0.5f, h * 0.5f)
                    activeShader.setLocalMatrix(auroraMatrix)
                    haloPaint.shader = activeShader
                    haloPaint.alpha = when (rimMode) {
                        RimMode.VOICE_LISTENING -> 72
                        RimMode.WORKING -> 54
                        else -> 42
                    }
                } else {
                    haloPaint.shader = null
                    val c = dynamicAccentColor ?: Color.parseColor("#0095F6")
                    haloPaint.color = Color.argb(42, Color.red(c), Color.green(c), Color.blue(c))
                }
            }
            canvas.drawRoundRect(haloRect, (cornerRadiusPx - density).coerceAtLeast(4f), (cornerRadiusPx - density).coerceAtLeast(4f), haloPaint)
            haloPaint.alpha = 255
        }

        borderPaint.strokeWidth = stroke
        when (rimMode) {
            RimMode.WORKING, RimMode.INPUT_ACTIVE -> {
                val shader = if (dynamicAuroraEnabled) sweepShader else null
                if (shader != null) {
                    auroraMatrix.reset()
                    auroraMatrix.setRotate(sweepDeg, w * 0.5f, h * 0.5f)
                    shader.setLocalMatrix(auroraMatrix)
                    borderPaint.shader = shader
                } else {
                    borderPaint.shader = null
                    borderPaint.color = dynamicAccentColor ?: Color.parseColor("#0095F6")
                }
            }
            RimMode.VOICE_LISTENING -> {
                val shader = voiceSweepShader
                if (shader != null) {
                    auroraMatrix.reset()
                    auroraMatrix.setRotate(sweepDeg, w * 0.5f, h * 0.5f)
                    shader.setLocalMatrix(auroraMatrix)
                    borderPaint.shader = shader
                } else {
                    borderPaint.shader = null
                    borderPaint.color = Color.parseColor("#E11D48")
                }
            }
            RimMode.STOPPING -> {
                borderPaint.shader = null
                val wave = 0.52f + 0.48f * sin(pulsePhase * 2.0 * PI).toFloat()
                borderPaint.color = Color.argb((wave * 255).toInt().coerceIn(135, 255), 225, 29, 72)
            }
            RimMode.STOPPED -> {
                borderPaint.shader = null
                borderPaint.color = Color.parseColor("#88E11D48")
            }
            RimMode.PAUSED -> {
                borderPaint.shader = null
                borderPaint.color = Color.parseColor("#99D97706")
            }
            RimMode.NEEDS_INPUT -> {
                borderPaint.shader = null
                val wave = 0.55f + 0.45f * sin(pulsePhase * 2.0 * PI).toFloat()
                borderPaint.color = Color.argb((wave * 255).toInt().coerceIn(120, 255), 217, 119, 6)
            }
            RimMode.DONE -> {
                borderPaint.shader = null
                borderPaint.color = dynamicAccentColor?.let {
                    Color.argb(175, Color.red(it), Color.green(it), Color.blue(it))
                } ?: Color.parseColor("#8816A34A")
            }
            RimMode.IDLE -> {
                borderPaint.shader = null
                borderPaint.color = dynamicIdleBorderColor
            }
        }
        canvas.drawRoundRect(borderRect, cornerRadiusPx, cornerRadiusPx, borderPaint)
        super.onDraw(canvas)
    }
}

/**
 * Adds crisp tactile spring press feedback (0.95f scale down -> bouncy release) to any interactive HUD view
 * without swallowing click listeners.
 */
fun View.attachSpringPressFeedback(pressedScale: Float = 0.95f) {
    setOnTouchListener { v, ev ->
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                v.animate().cancel()
                v.animate()
                    .scaleX(pressedScale)
                    .scaleY(pressedScale)
                    .setDuration(75L)
                    .start()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                v.animate().cancel()
                v.animate()
                    .scaleX(1f)
                    .scaleY(1f)
                    .setDuration(155L)
                    .setInterpolator(android.view.animation.OvershootInterpolator(1.25f))
                    .start()
            }
        }
        false
    }
}

/**
 * Crisp Canvas-drawn vector icon button for the native Android overlay composer
 * (replaces cramped text glyphs like "Mic" with Material-style rounded vector geometry).
 */
class AgyGlyphButtonView(
    context: Context,
    initialGlyph: Glyph = Glyph.MIC
) : View(context) {

    enum class Glyph { MIC, BOLT, SEND_UP, STOP_SQUARE, CLEAR_X }

    private val density = context.resources.displayMetrics.density.coerceAtLeast(1f)

    var glyph: Glyph = initialGlyph
        set(value) {
            if (field != value) {
                field = value
                invalidate()
            }
        }

    private var fillBgColor: Int = Color.WHITE
    private var strokeBgColor: Int = Color.parseColor("#FFE5E9F0")
    private var strokeWidthDp: Float = 0.85f
    private var iconTintColor: Int = Color.parseColor("#64748B")

    private val bgFillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val bgStrokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
    }
    private val iconFillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val iconStrokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val tmpRect = RectF()
    private val tmpPath = android.graphics.Path()

    init {
        isClickable = true
        isFocusable = false
    }

    fun setStyle(
        glyph: Glyph = this.glyph,
        bgFill: Int = fillBgColor,
        bgStroke: Int = strokeBgColor,
        iconTint: Int = iconTintColor,
        strokeDp: Float = strokeWidthDp
    ) {
        this.glyph = glyph
        this.fillBgColor = bgFill
        this.strokeBgColor = bgStroke
        this.iconTintColor = iconTint
        this.strokeWidthDp = strokeDp
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        val cx = w * 0.5f
        val cy = h * 0.5f
        val strokePx = strokeWidthDp * density
        val radius = (minOf(w, h) * 0.5f) - strokePx * 0.5f

        if (Color.alpha(fillBgColor) > 0) {
            bgFillPaint.color = fillBgColor
            canvas.drawCircle(cx, cy, radius, bgFillPaint)
        }
        if (Color.alpha(strokeBgColor) > 0 && strokePx > 0f) {
            bgStrokePaint.color = strokeBgColor
            bgStrokePaint.strokeWidth = strokePx
            canvas.drawCircle(cx, cy, radius, bgStrokePaint)
        }

        val unit = minOf(w, h) * 0.46f
        iconFillPaint.color = iconTintColor
        iconStrokePaint.color = iconTintColor
        iconStrokePaint.strokeWidth = (1.7f * density).coerceAtLeast(1.5f)

        when (glyph) {
            Glyph.MIC -> {
                // Capsule body
                val capW = unit * 0.44f
                val capH = unit * 0.86f
                tmpRect.set(cx - capW * 0.5f, cy - unit * 0.66f, cx + capW * 0.5f, cy - unit * 0.66f + capH)
                canvas.drawRoundRect(tmpRect, capW * 0.5f, capW * 0.5f, iconFillPaint)
                // U-cradle arc
                val arcR = unit * 0.48f
                tmpRect.set(cx - arcR, cy - unit * 0.44f, cx + arcR, cy + unit * 0.44f)
                canvas.drawArc(tmpRect, 12f, 156f, false, iconStrokePaint)
                // Stem & base
                val stemTop = cy + unit * 0.44f
                val stemBot = cy + unit * 0.72f
                canvas.drawLine(cx, stemTop, cx, stemBot, iconStrokePaint)
                canvas.drawLine(cx - unit * 0.28f, stemBot, cx + unit * 0.28f, stemBot, iconStrokePaint)
            }
            Glyph.BOLT -> {
                tmpPath.reset()
                tmpPath.moveTo(cx + unit * 0.10f, cy - unit * 0.68f)
                tmpPath.lineTo(cx - unit * 0.42f, cy + unit * 0.08f)
                tmpPath.lineTo(cx - unit * 0.02f, cy + unit * 0.08f)
                tmpPath.lineTo(cx - unit * 0.14f, cy + unit * 0.68f)
                tmpPath.lineTo(cx + unit * 0.42f, cy - unit * 0.08f)
                tmpPath.lineTo(cx + unit * 0.02f, cy - unit * 0.08f)
                tmpPath.close()
                canvas.drawPath(tmpPath, iconFillPaint)
            }
            Glyph.SEND_UP -> {
                iconStrokePaint.strokeWidth = (2.0f * density).coerceAtLeast(2f)
                val topY = cy - unit * 0.48f
                val botY = cy + unit * 0.50f
                canvas.drawLine(cx, botY, cx, topY, iconStrokePaint)
                val wing = unit * 0.42f
                tmpPath.reset()
                tmpPath.moveTo(cx - wing, topY + wing * 0.92f)
                tmpPath.lineTo(cx, topY)
                tmpPath.lineTo(cx + wing, topY + wing * 0.92f)
                canvas.drawPath(tmpPath, iconStrokePaint)
            }
            Glyph.STOP_SQUARE -> {
                val halfSq = unit * 0.42f
                val r = unit * 0.16f
                tmpRect.set(cx - halfSq, cy - halfSq, cx + halfSq, cy + halfSq)
                canvas.drawRoundRect(tmpRect, r, r, iconFillPaint)
            }
            Glyph.CLEAR_X -> {
                iconStrokePaint.strokeWidth = (1.7f * density).coerceAtLeast(1.5f)
                val arm = unit * 0.36f
                canvas.drawLine(cx - arm, cy - arm, cx + arm, cy + arm, iconStrokePaint)
                canvas.drawLine(cx + arm, cy - arm, cx - arm, cy + arm, iconStrokePaint)
            }
        }
    }
}


