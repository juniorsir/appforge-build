package com.kavach.ui.overlay

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.TextUtils
import android.util.Log
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.math.abs

/**
 * Window 3 (`agy_task_map`): Independent, draggable, semi-transparent Left Task-Specific Map
 * & Query Results Overlay anchored in the upper-left safe zone (`TOP | START`).
 *
 * - Tagged with `agy_hud_task_map` for 100% `/api/ui/tree` self-exclusion.
 * - Coordinates with `AgyHudOverlayManager` via [AgyOverlayLayoutCoordinator] to maintain a
 *   minimum 12dp gap, perform live auto-dodge on drag or IME keyboard focus, clamp strictly
 *   inside screen safe bounds, and auto-collapse into a compact edge pill when space is tight.
 * - Includes `[⤢ Pane/Full]` crop/size toggle, `90% / 65% / 35%` opacity cycler, and collapse
 *   button (`─`) morphing into a slim `[🗺 Map]` / `[🗺 Results]` edge pill.
 */
class AgyTaskMapOverlayManager(
    private val context: Context
) {
    companion object {
        private const val TAG = "AgyTaskMapOverlayMgr"
        const val TASK_MAP_NODE_TAG = "${AgyHudOverlayManager.HUD_NODE_TAG_PREFIX}task_map"
        val MAP_OPACITY_LEVELS = floatArrayOf(1.00f, 0.85f, 0.65f)
    }

    private val mainHandler = Handler(Looper.getMainLooper())
    private val windowManager: WindowManager? by lazy {
        context.getSystemService(Context.WINDOW_SERVICE) as? WindowManager
    }

    private val _isMapVisibleFlow = MutableStateFlow(false)
    val isMapVisibleFlow: StateFlow<Boolean> = _isMapVisibleFlow.asStateFlow()

    private val _isCollapsedFlow = MutableStateFlow(false)
    val isCollapsedFlow: StateFlow<Boolean> = _isCollapsedFlow.asStateFlow()

    private val _isAutoCollapsedFlow = MutableStateFlow(false)
    val isAutoCollapsedFlow: StateFlow<Boolean> = _isAutoCollapsedFlow.asStateFlow()

    private val _opacityFlow = MutableStateFlow(MAP_OPACITY_LEVELS[0])
    val opacityFlow: StateFlow<Float> = _opacityFlow.asStateFlow()

    private val _taskMapStateFlow = MutableStateFlow(AgyHudDynamicModels.TaskMapConfig())
    val taskMapStateFlow: StateFlow<AgyHudDynamicModels.TaskMapConfig> = _taskMapStateFlow.asStateFlow()

    val lightboxOverlay = AgyResultLightboxOverlay(context)

    var onDismissRequested: ((String) -> Unit)? = null

    private var layoutCoordinator: AgyOverlayLayoutCoordinator? = null
    private var rootFrame: FrameLayout? = null
    private var rootParams: WindowManager.LayoutParams? = null
    private var cardContainer: LinearLayout? = null
    private var collapsedPillContainer: LinearLayout? = null
    private var collapsedPillIcon: AgyAppleVectorIconView? = null
    private var collapsedPillView: TextView? = null
    private var collapsedMiniPlayPauseBtn: AgyAppleVectorIconView? = null
    private var collapsedMiniNextBtn: AgyAppleVectorIconView? = null
    private var headerModeIcon: AgyAppleVectorIconView? = null
    private var headerTitleText: TextView? = null
    private var splitChipText: TextView? = null
    private var paneToggleBtn: AgyAppleVectorIconView? = null
    private var opacityBtn: AgyAppleVectorIconView? = null
    private var collapseBtn: AgyAppleVectorIconView? = null
    private var dismissBtn: AgyAppleVectorIconView? = null
    private var mapCanvasView: AgyTaskMapView? = null
    private var resultsPanelView: AgyResultsPanelView? = null
    private var mediaPlayerPanelView: AgyMediaPlayerPanelView? = null

    @Volatile
    private var dismissedContentSignature: String? = null

    @Volatile
    private var opacityIndex: Int = 0
        set(value) {
            field = value
            _opacityFlow.value = MAP_OPACITY_LEVELS[value.coerceIn(0, MAP_OPACITY_LEVELS.lastIndex)]
        }

    @Volatile
    private var userPaneModeOverride: String? = null

    @Volatile
    private var isWideSize: Boolean = false

    @Volatile
    private var isCollapsed: Boolean = false
        set(value) {
            field = value
            _isCollapsedFlow.value = value
        }

    @Volatile
    private var autoCollapsedByCoordinator: Boolean = false
        set(value) {
            field = value
            _isAutoCollapsedFlow.value = value
        }

    @Volatile
    private var userManuallyCollapsed: Boolean = false

    @Volatile
    var autoFollowHud: Boolean = true

    @Volatile
    private var temporaryPassThroughActive: Boolean = false

    private var lastMeasuredExpandedWidthPx: Int = 0
    private var lastMeasuredExpandedHeightPx: Int = 0
    private var lastMeasuredCollapsedWidthPx: Int = 0
    private var lastMeasuredCollapsedHeightPx: Int = 0
    private var dodgeAnimator: ValueAnimator? = null
    private var pendingTargetLeft: Int? = null
    private var pendingTargetTop: Int? = null
    private var layoutReconcileScheduled: Boolean = false
    private val layoutReconcileRunnable = Runnable {
        layoutReconcileScheduled = false
        layoutCoordinator?.reconcile(animate = true)
    }

    private var currentTheme: AgyHudDynamicModels.ResolvedHudTheme =
        AgyHudDynamicModels.resolveTheme(AgyHudDynamicModels.HudThemeConfig(), Color.parseColor("#0095F6"))

    private val coordinatorEndpoint = object : AgyOverlayLayoutCoordinator.ManagedOverlayEndpoint {
        override val windowId = AgyOverlayLayoutCoordinator.ManagedWindowId.TASK_MAP

        override fun captureBoxState(
            viewport: AgyOverlayLayoutCoordinator.ViewportSafeBounds
        ): AgyOverlayLayoutCoordinator.WindowBoxState {
            val visible = _isMapVisibleFlow.value && rootFrame != null && rootParams != null
            val expW = estimateExpandedWidthPx()
            val expH = estimateExpandedHeightPx()
            val colW = estimateCollapsedWidthPx()
            val colH = estimateCollapsedHeightPx()
            val curW = if (isCollapsed) colW else expW
            val curH = if (isCollapsed) colH else expH
            val rect = computeCurrentScreenRect(viewport, curW, curH)
            return AgyOverlayLayoutCoordinator.WindowBoxState(
                id = windowId,
                visible = visible,
                rect = rect,
                expandedWidth = expW,
                expandedHeight = expH,
                collapsedWidth = colW,
                collapsedHeight = colH,
                isCollapsed = isCollapsed,
                autoCollapsedByCoordinator = autoCollapsedByCoordinator,
                userManuallyCollapsed = userManuallyCollapsed,
                autoFollowHud = autoFollowHud
            )
        }

        override fun applyAdjustment(
            adjustment: AgyOverlayLayoutCoordinator.WindowAdjustment,
            viewport: AgyOverlayLayoutCoordinator.ViewportSafeBounds,
            animate: Boolean
        ) {
            runOnMain {
                if (rootFrame == null || rootParams == null) return@runOnMain
                val collapseChanged = adjustment.targetCollapsed != isCollapsed
                autoCollapsedByCoordinator = adjustment.autoCollapsedByCoordinator
                if (collapseChanged) {
                    isCollapsed = adjustment.targetCollapsed
                    if (!adjustment.targetCollapsed) {
                        userManuallyCollapsed = false
                    }
                    renderMapWindow(scheduleReconcile = false)
                }
                if (adjustment.positionChanged || collapseChanged) {
                    moveToScreenTopLeft(adjustment.targetLeft, adjustment.targetTop, viewport, animate)
                }
            }
        }

        override fun clampPosition(
            targetLeft: Int,
            targetTop: Int,
            viewport: AgyOverlayLayoutCoordinator.ViewportSafeBounds,
            animate: Boolean
        ) {
            runOnMain {
                moveToScreenTopLeft(targetLeft, targetTop, viewport, animate)
            }
        }
    }

    fun attachLayoutCoordinator(coordinator: AgyOverlayLayoutCoordinator) {
        layoutCoordinator = coordinator
        coordinator.registerEndpoint(coordinatorEndpoint)
    }

    fun getPlayerController(): AgyMediaPlaybackController? = mediaPlayerPanelView?.controller

    fun getPlayerSnapshot(): AgyMediaPlaybackController.PlaybackSnapshot? =
        mediaPlayerPanelView?.controller?.currentSnapshot()

    fun getOverlayRect(): Rect? {
        if (!_isMapVisibleFlow.value || rootFrame == null || rootParams == null) return null
        val vp = layoutCoordinator?.currentViewportSafeBounds()
            ?: AgyOverlayLayoutCoordinator.buildViewportSafeBounds(
                screenWidth = context.resources.displayMetrics.widthPixels,
                screenHeight = context.resources.displayMetrics.heightPixels,
                density = context.resources.displayMetrics.density
            )
        val curW = if (isCollapsed) estimateCollapsedWidthPx() else estimateExpandedWidthPx()
        val curH = if (isCollapsed) estimateCollapsedHeightPx() else estimateExpandedHeightPx()
        return computeCurrentScreenRect(vp, curW, curH)
    }

    fun setTemporaryTouchPassThrough(passThrough: Boolean) {
        temporaryPassThroughActive = passThrough
        runOnMain {
            val view = rootFrame ?: return@runOnMain
            val params = rootParams ?: return@runOnMain
            params.flags = if (passThrough) {
                params.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
            } else {
                params.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
            }
            try {
                windowManager?.updateViewLayout(view, params)
            } catch (_: Exception) {}
        }
    }

    fun clearDismissedState() {
        dismissedContentSignature = null
    }

    fun dismissByUser() {
        val sig = _taskMapStateFlow.value.contentSignature()
        dismissedContentSignature = sig
        hideMap(dismissLightbox = true)
        onDismissRequested?.invoke(sig)
    }

    fun openLightbox(index: Int = 0) {
        val cfg = _taskMapStateFlow.value
        val items = if (cfg.mode == "player") {
            val playlist = mediaPlayerPanelView?.controller?.currentSnapshot()?.playlist
                ?: cfg.player?.playlist.orEmpty()
            playlist.map { it.toResultMediaItem() }
        } else {
            cfg.results?.items.orEmpty()
        }
        if (items.isNotEmpty()) {
            lightboxOverlay.show(items, index, currentTheme)
        }
    }

    fun updateTaskMap(
        config: AgyHudDynamicModels.TaskMapConfig,
        themeConfig: AgyHudDynamicModels.HudThemeConfig,
        enabled: Boolean = true
    ) {
        val effectiveConfig = if (userPaneModeOverride != null && config.mode == "app_pane") {
            config.copy(paneMode = userPaneModeOverride!!)
        } else {
            config
        }
        val sig = effectiveConfig.contentSignature()
        if (dismissedContentSignature != null) {
            if (sig == dismissedContentSignature) {
                hideMap(dismissLightbox = false)
                return
            } else {
                dismissedContentSignature = null
            }
        }
        val prevCfg = _taskMapStateFlow.value
        val prevMode = prevCfg.mode
        val prevBg = prevCfg.player?.backgroundMode
        _taskMapStateFlow.value = effectiveConfig
        if (prevMode != effectiveConfig.mode) {
            // Reset cached expanded height so the coordinator re-measures accurately for the new mode
            lastMeasuredExpandedHeightPx = 0
            lastMeasuredExpandedWidthPx = 0
        }
        if (effectiveConfig.mode == "player" && effectiveConfig.player != null) {
            val nextBg = effectiveConfig.player.backgroundMode
            if (nextBg && prevBg != true) {
                isCollapsed = true
                autoCollapsedByCoordinator = false
                userManuallyCollapsed = true
            } else if (!nextBg && prevBg == true) {
                isCollapsed = false
                autoCollapsedByCoordinator = false
                userManuallyCollapsed = false
            }
        }
        val defaultAccent = when (effectiveConfig.mode) {
            "chess" -> Color.parseColor("#16A34A")
            "media" -> Color.parseColor("#FF0033")
            "player" -> Color.parseColor("#EC4899")
            "telemetry" -> Color.parseColor("#7C3AED")
            "results" -> Color.parseColor("#0EA5E9")
            else -> Color.parseColor("#0095F6")
        }
        currentTheme = AgyHudDynamicModels.resolveTheme(themeConfig, defaultAccent)

        if (!effectiveConfig.active || !enabled) {
            hideMap(dismissLightbox = true)
            return
        }

        _isMapVisibleFlow.value = hasOverlayPermission()
        if (!hasOverlayPermission()) return

        runOnMain {
            ensureAttached()
            renderMapWindow(scheduleReconcile = true)
        }
    }

    fun hideMap(dismissLightbox: Boolean = true) {
        val wasVisible = _isMapVisibleFlow.value
        _isMapVisibleFlow.value = false
        autoCollapsedByCoordinator = false
        if (dismissLightbox) {
            lightboxOverlay.dismiss()
        }
        runOnMain {
            mainHandler.removeCallbacks(layoutReconcileRunnable)
            layoutReconcileScheduled = false
            dodgeAnimator?.cancel()
            dodgeAnimator = null
            pendingTargetLeft = null
            pendingTargetTop = null
            mediaPlayerPanelView?.stopPlayback()
            rootFrame?.let { view ->
                try {
                    windowManager?.removeView(view)
                } catch (e: Exception) {
                    Log.w(TAG, "Error removing agy_task_map: ${e.message}")
                }
            }
            rootFrame = null
            rootParams = null
            cardContainer = null
            collapsedPillContainer = null
            collapsedPillIcon = null
            collapsedPillView = null
            collapsedMiniPlayPauseBtn = null
            collapsedMiniNextBtn = null
            headerModeIcon = null
            headerTitleText = null
            splitChipText = null
            paneToggleBtn = null
            opacityBtn = null
            collapseBtn = null
            dismissBtn = null
            mapCanvasView = null
            resultsPanelView = null
            mediaPlayerPanelView = null
            if (wasVisible) {
                layoutCoordinator?.reconcile(animate = true)
            }
        }
    }

    fun cycleOpacity() {
        opacityIndex = (opacityIndex + 1) % MAP_OPACITY_LEVELS.size
        runOnMain { renderMapWindow(scheduleReconcile = false) }
    }

    fun toggleCollapse() {
        val nextCollapsed = !isCollapsed
        isCollapsed = nextCollapsed
        autoCollapsedByCoordinator = false
        userManuallyCollapsed = nextCollapsed
        if (_taskMapStateFlow.value.mode == "player") {
            mediaPlayerPanelView?.controller?.setBackgroundMode(nextCollapsed)
            _taskMapStateFlow.value.player?.let { p ->
                _taskMapStateFlow.value = _taskMapStateFlow.value.copy(
                    player = p.copy(backgroundMode = nextCollapsed)
                )
            }
        }
        runOnMain {
            renderMapWindow(scheduleReconcile = false)
            if (!nextCollapsed) {
                // User explicitly expanded Task Map -> raise its priority so HUD dodges/collapses if needed
                layoutCoordinator?.notifyInteraction(
                    id = AgyOverlayLayoutCoordinator.ManagedWindowId.TASK_MAP,
                    priority = AgyOverlayLayoutCoordinator.InteractionPriority.USER_INTERACTED,
                    animate = true
                )
            } else {
                layoutCoordinator?.reconcile(animate = true)
            }
        }
    }

    /**
     * Automatically collapses the active player window into its compact background (`BG`) mini-pill
     * without interrupting playback (e.g., when a new Agy task starts).
     */
    fun collapseToBackgroundMiniPill() {
        isCollapsed = true
        autoCollapsedByCoordinator = false
        userManuallyCollapsed = true
        if (_taskMapStateFlow.value.mode == "player") {
            mediaPlayerPanelView?.controller?.setBackgroundMode(true)
            _taskMapStateFlow.value.player?.let { p ->
                _taskMapStateFlow.value = _taskMapStateFlow.value.copy(
                    player = p.copy(backgroundMode = true)
                )
            }
        }
        runOnMain {
            renderMapWindow(scheduleReconcile = true)
        }
    }

    fun togglePaneOrSize() {
        val cfg = _taskMapStateFlow.value
        if (cfg.mode == "app_pane" && cfg.paneBounds != null) {
            val nextMode = if (cfg.paneMode == "pane") "full" else "pane"
            userPaneModeOverride = nextMode
            _taskMapStateFlow.value = cfg.copy(paneMode = nextMode)
        } else {
            isWideSize = !isWideSize
            lastMeasuredExpandedWidthPx = 0
        }
        runOnMain {
            renderMapWindow(scheduleReconcile = false)
            layoutCoordinator?.notifyInteraction(
                id = AgyOverlayLayoutCoordinator.ManagedWindowId.TASK_MAP,
                priority = AgyOverlayLayoutCoordinator.InteractionPriority.USER_INTERACTED,
                animate = true
            )
        }
    }

    private fun ensureAttached() {
        if (rootFrame != null) return
        val wm = windowManager ?: return
        val d = context.resources.displayMetrics.density.coerceAtLeast(1f)

        val frame = FrameLayout(context).apply {
            tag = TASK_MAP_NODE_TAG
            contentDescription = TASK_MAP_NODE_TAG
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                transitionName = TASK_MAP_NODE_TAG
            }
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS
        }

        frame.addOnLayoutChangeListener { _, left, top, right, bottom, oldLeft, oldTop, oldRight, oldBottom ->
            val newW = right - left
            val newH = bottom - top
            val oldW = oldRight - oldLeft
            val oldH = oldBottom - oldTop
            if (newW > 0 && newH > 0) {
                if (isCollapsed) {
                    lastMeasuredCollapsedWidthPx = newW
                    lastMeasuredCollapsedHeightPx = newH
                } else {
                    lastMeasuredExpandedWidthPx = newW
                    lastMeasuredExpandedHeightPx = newH
                }
                if (abs(newW - oldW) > 3 || abs(newH - oldH) > 3) {
                    scheduleLayoutReconcile()
                }
            }
        }

        val card = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((8 * d).toInt(), (7 * d).toInt(), (8 * d).toInt(), (8 * d).toInt())
            layoutParams = FrameLayout.LayoutParams(
                (176 * d).toInt(),
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            tag = "${TASK_MAP_NODE_TAG}_card"
            contentDescription = "${TASK_MAP_NODE_TAG}_card"
        }
        attachDragBehavior(card)

        // Header strip: Vector Mode Icon + Title + Inline Apple SVG Controls ([Resize], [Opacity], [Minimize], [Close])
        val headerRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = (5 * d).toInt() }
        }

        val modeIcon = AgyAppleVectorIconView(context, AgyAppleVectorIconView.IconType.MAP_GRID).apply {
            glassStyle = AgyAppleVectorIconView.GlassStyle.NONE
            iconSizeDp = 13f
            minTouchSizeDp = 18f
            isClickable = false
            layoutParams = LinearLayout.LayoutParams((18 * d).toInt(), (18 * d).toInt()).apply {
                marginEnd = (5 * d).toInt()
            }
        }
        headerModeIcon = modeIcon

        val titleTv = TextView(context).apply {
            textSize = 10.5f
            setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        headerTitleText = titleTv

        fun headerSvgBtn(
            icon: AgyAppleVectorIconView.IconType,
            label: String = "",
            desc: String,
            onClick: () -> Unit
        ): AgyAppleVectorIconView {
            return AgyAppleVectorIconView(context, icon).apply {
                iconSizeDp = 12f
                minTouchSizeDp = 23f
                labelText = label
                glassStyle = if (label.isNotBlank()) {
                    AgyAppleVectorIconView.GlassStyle.GLASS_PILL
                } else {
                    AgyAppleVectorIconView.GlassStyle.GLASS_CIRCLE
                }
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    (23 * d).toInt()
                ).apply { marginStart = (3 * d).toInt() }
                contentDescription = "${TASK_MAP_NODE_TAG}_$desc"
                tag = "${TASK_MAP_NODE_TAG}_$desc"
                setOnClickListener { onClick() }
            }
        }

        val paneBtn = headerSvgBtn(AgyAppleVectorIconView.IconType.RESIZE_PANE, "", "pane_toggle") {
            togglePaneOrSize()
        }
        paneToggleBtn = paneBtn

        val opBtn = headerSvgBtn(AgyAppleVectorIconView.IconType.OPACITY_DROP, "100%", "opacity_toggle") {
            cycleOpacity()
        }
        opacityBtn = opBtn

        val minBtn = headerSvgBtn(AgyAppleVectorIconView.IconType.MINUS, "", "collapse_toggle") {
            toggleCollapse()
        }
        collapseBtn = minBtn

        val closeBtn = headerSvgBtn(AgyAppleVectorIconView.IconType.XMARK, "", "dismiss_btn") {
            dismissByUser()
        }.apply {
            visibility = View.GONE
        }
        dismissBtn = closeBtn

        headerRow.addView(modeIcon)
        headerRow.addView(titleTv)
        headerRow.addView(paneBtn)
        headerRow.addView(opBtn)
        headerRow.addView(minBtn)
        headerRow.addView(closeBtn)
        card.addView(headerRow)

        val splitTv = TextView(context).apply {
            textSize = 8.5f
            typeface = Typeface.MONOSPACE
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            setPadding((5 * d).toInt(), (2 * d).toInt(), (5 * d).toInt(), (2 * d).toInt())
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = (5 * d).toInt() }
            visibility = View.GONE
        }
        splitChipText = splitTv
        card.addView(splitTv)

        val canvasView = AgyTaskMapView(context).apply {
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }
        mapCanvasView = canvasView
        card.addView(canvasView)

        val resultsView = AgyResultsPanelView(context).apply {
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            visibility = View.GONE
            onItemClicked = { mediaItems, idx ->
                lightboxOverlay.show(mediaItems, idx, currentTheme)
            }
        }
        resultsPanelView = resultsView
        card.addView(resultsView)

        val playerView = AgyMediaPlayerPanelView(context).apply {
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            visibility = View.GONE
            onRequestBackgroundPill = {
                if (!isCollapsed) {
                    toggleCollapse()
                }
            }
            onRequestFullscreenLightbox = { mediaItems, idx ->
                // Pause in-window video while viewing in fullscreen lightbox if video mode
                if (controller.currentSnapshot().mediaMode == "video" && controller.currentSnapshot().isPlaying) {
                    controller.setPlaying(false)
                }
                lightboxOverlay.show(mediaItems, idx, currentTheme)
            }
            onPlayerStateChanged = { snap ->
                updateCollapsedMiniPlayerPill(snap)
            }
            onRequestDismissPlayer = {
                dismissByUser()
            }
        }
        mediaPlayerPanelView = playerView
        card.addView(playerView)

        val pillBar = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            minimumHeight = (40 * d).toInt()
            setPadding((10 * d).toInt(), (6 * d).toInt(), (10 * d).toInt(), (6 * d).toInt())
            visibility = View.GONE
            tag = "${TASK_MAP_NODE_TAG}_pill_bar"
            contentDescription = "${TASK_MAP_NODE_TAG}_pill_bar"
        }
        attachDragBehavior(pillBar)
        collapsedPillContainer = pillBar

        val pillIcon = AgyAppleVectorIconView(context, AgyAppleVectorIconView.IconType.MAP_GRID).apply {
            glassStyle = AgyAppleVectorIconView.GlassStyle.NONE
            iconSizeDp = 13.5f
            minTouchSizeDp = 18f
            isClickable = false
            layoutParams = LinearLayout.LayoutParams((18 * d).toInt(), (18 * d).toInt()).apply {
                marginEnd = (5 * d).toInt()
            }
        }
        collapsedPillIcon = pillIcon

        val edgePill = TextView(context).apply {
            text = "Map"
            textSize = 10.5f
            gravity = Gravity.CENTER_VERTICAL
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            maxWidth = (140 * d).toInt()
            setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
            setPadding((2 * d).toInt(), (2 * d).toInt(), (4 * d).toInt(), (2 * d).toInt())
            contentDescription = "${TASK_MAP_NODE_TAG}_pill"
            setOnClickListener { toggleCollapse() }
        }
        attachDragBehavior(edgePill)
        collapsedPillView = edgePill

        val miniPlayBtn = AgyAppleVectorIconView(context, AgyAppleVectorIconView.IconType.PAUSE_FILL).apply {
            iconSizeDp = 13f
            minTouchSizeDp = 28f
            glassStyle = AgyAppleVectorIconView.GlassStyle.ACCENT_CIRCLE
            visibility = View.GONE
            contentDescription = "${TASK_MAP_NODE_TAG}_pill_play_pause"
            tag = "${TASK_MAP_NODE_TAG}_pill_play_pause"
            layoutParams = LinearLayout.LayoutParams((28 * d).toInt(), (28 * d).toInt()).apply {
                marginStart = (5 * d).toInt()
            }
            setOnClickListener {
                mediaPlayerPanelView?.controller?.togglePlayPause()
            }
        }
        collapsedMiniPlayPauseBtn = miniPlayBtn

        val miniNextBtn = AgyAppleVectorIconView(context, AgyAppleVectorIconView.IconType.FORWARD_FILL).apply {
            iconSizeDp = 12f
            minTouchSizeDp = 28f
            glassStyle = AgyAppleVectorIconView.GlassStyle.GLASS_CIRCLE
            visibility = View.GONE
            contentDescription = "${TASK_MAP_NODE_TAG}_pill_next"
            tag = "${TASK_MAP_NODE_TAG}_pill_next"
            layoutParams = LinearLayout.LayoutParams((28 * d).toInt(), (28 * d).toInt()).apply {
                marginStart = (4 * d).toInt()
            }
            setOnClickListener {
                mediaPlayerPanelView?.controller?.nextTrack()
            }
        }
        collapsedMiniNextBtn = miniNextBtn

        pillBar.addView(pillIcon)
        pillBar.addView(edgePill)
        pillBar.addView(miniPlayBtn)
        pillBar.addView(miniNextBtn)

        frame.addView(card)
        frame.addView(pillBar)

        val windowType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val estW = if (isCollapsed) estimateCollapsedWidthPx() else estimateExpandedWidthPx()
        val estH = if (isCollapsed) estimateCollapsedHeightPx() else estimateExpandedHeightPx()
        val (initialLeft, initialTop) = layoutCoordinator?.computeDockedLeftOfHudPosition(estW, estH)
            ?: run {
                val viewport = AgyOverlayLayoutCoordinator.buildViewportSafeBounds(
                    screenWidth = context.resources.displayMetrics.widthPixels,
                    screenHeight = context.resources.displayMetrics.heightPixels,
                    density = d
                )
                viewport.safeLeft to (viewport.safeTop + ((viewport.safeHeight * 0.08f).toInt()).coerceAtMost((48 * d).toInt()))
            }

        val initialFlags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            (if (temporaryPassThroughActive) WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE else 0)

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            windowType,
            initialFlags,
            PixelFormat.TRANSLUCENT
        ).apply {
            // Anchor TOP | START so (x, y) map 1:1 to absolute screen (left, top) without height-centering jumps
            gravity = Gravity.TOP or Gravity.START
            x = initialLeft
            y = initialTop
        }

        try {
            wm.addView(frame, params)
            rootFrame = frame
            rootParams = params
            cardContainer = card
        } catch (e: Exception) {
            Log.e(TAG, "Failed attaching agy_task_map overlay: ${e.message}")
        }
    }

    private fun updateCollapsedMiniPlayerPill(snap: AgyMediaPlaybackController.PlaybackSnapshot) {
        val cfg = _taskMapStateFlow.value
        if (cfg.mode != "player") return
        val theme = currentTheme
        val trackTitle = snap.currentTrack?.title ?: cfg.title.ifBlank { "Agy Player" }
        collapsedPillIcon?.apply {
            iconType = if (snap.mediaMode == "audio" || snap.backgroundMode) {
                if (snap.isPlaying) AgyAppleVectorIconView.IconType.WAVEFORM
                else AgyAppleVectorIconView.IconType.MUSIC_NOTE
            } else {
                AgyAppleVectorIconView.IconType.VIDEO_FILL
            }
            iconTint = theme.accent
        }
        collapsedPillView?.text = trackTitle
        collapsedMiniPlayPauseBtn?.apply {
            visibility = if (isCollapsed) View.VISIBLE else View.GONE
            iconType = if (snap.isPlaying) {
                AgyAppleVectorIconView.IconType.PAUSE_FILL
            } else {
                AgyAppleVectorIconView.IconType.PLAY_FILL
            }
            accentColor = theme.accent
            glassStyle = AgyAppleVectorIconView.GlassStyle.ACCENT_CIRCLE
            iconTint = Color.WHITE
        }
        collapsedMiniNextBtn?.apply {
            visibility = if (isCollapsed && snap.playlist.size > 1) View.VISIBLE else View.GONE
            accentColor = theme.accent
            glassStyle = AgyAppleVectorIconView.GlassStyle.GLASS_CIRCLE
            glassFillColor = theme.secondarySurface
            glassBorderColor = theme.border
            iconTint = theme.textPrimary
        }
    }

    private fun renderMapWindow(scheduleReconcile: Boolean = true) {
        val cfg = _taskMapStateFlow.value
        val theme = currentTheme
        val d = context.resources.displayMetrics.density.coerceAtLeast(1f)
        val alphaVal = cfg.opacity ?: MAP_OPACITY_LEVELS[opacityIndex]

        rootFrame?.alpha = alphaVal

        val targetWidthDp = resolveTargetWidthDp(cfg)
        cardContainer?.apply {
            visibility = if (isCollapsed) View.GONE else View.VISIBLE
            layoutParams = (layoutParams as? FrameLayout.LayoutParams)?.apply {
                width = (targetWidthDp * d).toInt()
            } ?: FrameLayout.LayoutParams((targetWidthDp * d).toInt(), ViewGroup.LayoutParams.WRAP_CONTENT)
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = 18f * d
                setColor(theme.surface)
                setStroke((1f * d).toInt().coerceAtLeast(1), theme.border)
            }
        }

        // Update inner mode panels first so player snapshot is fresh for collapsed pill rendering
        when (cfg.mode) {
            "results" -> {
                mapCanvasView?.visibility = View.GONE
                mediaPlayerPanelView?.visibility = View.GONE
                resultsPanelView?.visibility = View.VISIBLE
                resultsPanelView?.updateResults(cfg, theme)
            }
            "player" -> {
                mapCanvasView?.visibility = View.GONE
                resultsPanelView?.visibility = View.GONE
                mediaPlayerPanelView?.visibility = View.VISIBLE
                mediaPlayerPanelView?.updatePlayer(cfg, theme)
            }
            else -> {
                resultsPanelView?.visibility = View.GONE
                mediaPlayerPanelView?.visibility = View.GONE
                mapCanvasView?.visibility = View.VISIBLE
                mapCanvasView?.updateTaskMap(cfg, theme)
            }
        }

        collapsedPillContainer?.apply {
            visibility = if (isCollapsed) View.VISIBLE else View.GONE
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = 999f * d
                setColor(theme.surface)
                setStroke((1.1f * d).toInt().coerceAtLeast(1), theme.accent)
            }
        }

        collapsedPillView?.apply {
            visibility = if (isCollapsed) View.VISIBLE else View.GONE
            setTextColor(theme.textPrimary)
            if (cfg.mode == "player") {
                val snap = mediaPlayerPanelView?.controller?.currentSnapshot()
                if (snap != null) {
                    updateCollapsedMiniPlayerPill(snap)
                } else {
                    collapsedPillIcon?.iconType = AgyAppleVectorIconView.IconType.VIDEO_FILL
                    collapsedPillIcon?.iconTint = theme.accent
                    text = cfg.title.ifBlank { "Agy Player" }
                }
            } else {
                collapsedMiniPlayPauseBtn?.visibility = View.GONE
                collapsedMiniNextBtn?.visibility = View.GONE
                collapsedPillIcon?.iconType = AgyAppleVectorIconView.IconType.MAP_GRID
                collapsedPillIcon?.iconTint = theme.accent
                text = if (cfg.mode == "results") {
                    val n = cfg.results?.items?.size ?: 0
                    if (n > 0) "Results ($n)" else "Results"
                } else {
                    "Map"
                }
            }
        }

        headerModeIcon?.apply {
            iconType = when (cfg.mode) {
                "player" -> {
                    val snap = mediaPlayerPanelView?.controller?.currentSnapshot()
                    if (snap?.mediaMode == "audio") AgyAppleVectorIconView.IconType.MUSIC_NOTE
                    else AgyAppleVectorIconView.IconType.VIDEO_FILL
                }
                "media" -> AgyAppleVectorIconView.IconType.PLAY_FILL
                else -> AgyAppleVectorIconView.IconType.MAP_GRID
            }
            iconTint = theme.accent
        }

        headerTitleText?.apply {
            text = cfg.title.ifBlank {
                when (cfg.mode) {
                    "chess" -> "Chess Board"
                    "media" -> "Media"
                    "player" -> "Agy Player"
                    "telemetry" -> "Telemetry"
                    "results" -> cfg.results?.query?.takeIf { it.isNotBlank() } ?: "Results"
                    else -> "App Pane"
                }
            }
            setTextColor(theme.textPrimary)
        }

        splitChipText?.apply {
            if (cfg.splitLabel.isNotBlank()) {
                visibility = View.VISIBLE
                text = cfg.splitLabel
                setTextColor(theme.accent)
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = 999f * d
                    setColor(Color.argb(24, Color.red(theme.accent), Color.green(theme.accent), Color.blue(theme.accent)))
                }
            } else {
                visibility = View.GONE
            }
        }

        fun styleHeaderSvgBtn(
            btn: AgyAppleVectorIconView?,
            activeAccent: Boolean = false,
            pill: Boolean = false
        ) {
            btn ?: return
            btn.accentColor = theme.accent
            if (activeAccent) {
                btn.glassStyle = if (pill) AgyAppleVectorIconView.GlassStyle.ACCENT_PILL else AgyAppleVectorIconView.GlassStyle.ACCENT_CIRCLE
                btn.iconTint = Color.WHITE
            } else {
                btn.glassStyle = if (pill) AgyAppleVectorIconView.GlassStyle.GLASS_PILL else AgyAppleVectorIconView.GlassStyle.GLASS_CIRCLE
                btn.glassFillColor = theme.secondarySurface
                btn.glassBorderColor = theme.border
                btn.iconTint = theme.textSecondary
            }
        }

        paneToggleBtn?.apply {
            labelText = if (cfg.mode == "app_pane") {
                if (cfg.paneMode == "pane") "Pane" else "Full"
            } else {
                ""
            }
            styleHeaderSvgBtn(
                this,
                activeAccent = (cfg.mode == "app_pane" && cfg.paneMode == "pane") || (cfg.mode != "app_pane" && isWideSize),
                pill = labelText.isNotBlank()
            )
        }

        opacityBtn?.apply {
            labelText = "${(alphaVal * 100).toInt()}%"
            styleHeaderSvgBtn(this, activeAccent = false, pill = true)
        }
        styleHeaderSvgBtn(collapseBtn, activeAccent = false, pill = false)
        dismissBtn?.apply {
            visibility = if (cfg.mode == "results" || cfg.mode == "player" || cfg.persistOnDone) View.VISIBLE else View.GONE
            styleHeaderSvgBtn(this, activeAccent = false, pill = false)
        }

        rootFrame?.let { view ->
            rootParams?.let { params ->
                try {
                    windowManager?.updateViewLayout(view, params)
                } catch (_: Exception) {}
            }
        }

        if (scheduleReconcile) {
            layoutCoordinator?.reconcile(animate = true)
            scheduleLayoutReconcile()
        }
    }

    private fun resolveTargetWidthDp(cfg: AgyHudDynamicModels.TaskMapConfig): Float {
        return when (cfg.mode) {
            "results", "player" -> {
                if (isWideSize) (cfg.widthDp + 32f).coerceAtMost(268f) else cfg.widthDp.coerceIn(196f, 248f)
            }
            else -> {
                if (isWideSize) (cfg.widthDp + 34f).coerceAtMost(226f) else cfg.widthDp.coerceIn(156f, 200f)
            }
        }
    }

    private fun estimateExpandedWidthPx(): Int {
        val d = context.resources.displayMetrics.density.coerceAtLeast(1f)
        val fallback = (resolveTargetWidthDp(_taskMapStateFlow.value) * d).toInt()
        return lastMeasuredExpandedWidthPx.takeIf { it > 0 }
            ?: cardContainer?.width?.takeIf { it > 0 && !isCollapsed }
            ?: fallback
    }

    private fun estimateExpandedHeightPx(): Int {
        val d = context.resources.displayMetrics.density.coerceAtLeast(1f)
        val fallbackDp = when (_taskMapStateFlow.value.mode) {
            "results" -> if (_taskMapStateFlow.value.results?.items.orEmpty().isNotEmpty()) 330f else 175f
            "player" -> if (_taskMapStateFlow.value.player?.mediaMode == "audio") 225f else 285f
            "chess" -> 235f
            "media" -> 165f
            "telemetry" -> 185f
            else -> 255f
        }
        return lastMeasuredExpandedHeightPx.takeIf { it > 0 }
            ?: cardContainer?.height?.takeIf { it > 0 && !isCollapsed }
            ?: (fallbackDp * d).toInt()
    }

    private fun estimateCollapsedWidthPx(): Int {
        val d = context.resources.displayMetrics.density.coerceAtLeast(1f)
        val fallbackDp = when (_taskMapStateFlow.value.mode) {
            "player" -> 178f
            "results" -> 116f
            else -> 88f
        }
        return lastMeasuredCollapsedWidthPx.takeIf { it > 0 }
            ?: collapsedPillContainer?.width?.takeIf { it > 0 && isCollapsed }
            ?: (fallbackDp * d).toInt()
    }

    private fun estimateCollapsedHeightPx(): Int {
        val d = context.resources.displayMetrics.density.coerceAtLeast(1f)
        return lastMeasuredCollapsedHeightPx.takeIf { it > 0 }
            ?: collapsedPillContainer?.height?.takeIf { it > 0 && isCollapsed }
            ?: (40 * d).toInt()
    }

    private fun computeCurrentScreenRect(
        viewport: AgyOverlayLayoutCoordinator.ViewportSafeBounds,
        width: Int,
        height: Int
    ): Rect {
        val tL = pendingTargetLeft
        val tT = pendingTargetTop
        if (tL != null && tT != null) {
            return Rect(tL, tT, tL + width, tT + height)
        }
        val params = rootParams ?: return Rect(viewport.safeLeft, viewport.safeTop, viewport.safeLeft + width, viewport.safeTop + height)
        return AgyOverlayLayoutCoordinator.windowParamsToScreenRect(
            params = params,
            width = width,
            height = height,
            screenWidth = viewport.screenWidth,
            screenHeight = viewport.screenHeight
        )
    }

    private fun moveToScreenTopLeft(
        targetLeft: Int,
        targetTop: Int,
        viewport: AgyOverlayLayoutCoordinator.ViewportSafeBounds,
        animate: Boolean
    ) {
        val frame = rootFrame ?: return
        val params = rootParams ?: return
        val w = if (isCollapsed) estimateCollapsedWidthPx() else estimateExpandedWidthPx()
        val h = if (isCollapsed) estimateCollapsedHeightPx() else estimateExpandedHeightPx()
        val (safeL, safeT) = AgyOverlayLayoutCoordinator.clampTopLeftToSafeBounds(
            left = targetLeft,
            top = targetTop,
            width = w,
            height = h,
            viewport = viewport
        )
        val (targetX, targetY) = AgyOverlayLayoutCoordinator.screenTopLeftToWindowOffset(
            gravity = params.gravity,
            targetLeft = safeL,
            targetTop = safeT,
            width = w,
            height = h,
            screenWidth = viewport.screenWidth,
            screenHeight = viewport.screenHeight
        )

        val startX = params.x
        val startY = params.y
        dodgeAnimator?.cancel()
        dodgeAnimator = null

        if (abs(startX - targetX) <= 2 && abs(startY - targetY) <= 2) {
            pendingTargetLeft = null
            pendingTargetTop = null
            return
        }

        val animatorsEnabled = Build.VERSION.SDK_INT < Build.VERSION_CODES.O || ValueAnimator.areAnimatorsEnabled()
        val canAnimate = animate && animatorsEnabled
        if (!canAnimate) {
            pendingTargetLeft = null
            pendingTargetTop = null
            params.x = targetX
            params.y = targetY
            try {
                windowManager?.updateViewLayout(frame, params)
            } catch (_: Exception) {}
            return
        }

        pendingTargetLeft = safeL
        pendingTargetTop = safeT
        dodgeAnimator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 190L
            interpolator = DecelerateInterpolator()
            addUpdateListener { anim ->
                val f = anim.animatedValue as Float
                params.x = (startX + (targetX - startX) * f).toInt()
                params.y = (startY + (targetY - startY) * f).toInt()
                try {
                    windowManager?.updateViewLayout(frame, params)
                } catch (_: Exception) {}
                if (f >= 1f) {
                    pendingTargetLeft = null
                    pendingTargetTop = null
                }
            }
            start()
        }
    }

    private fun scheduleLayoutReconcile() {
        if (layoutCoordinator == null) return
        if (!layoutReconcileScheduled) {
            layoutReconcileScheduled = true
            mainHandler.post(layoutReconcileRunnable)
        }
    }

    private fun attachDragBehavior(targetView: View) {
        var downRawX = 0f
        var downRawY = 0f
        var startX = 0
        var startY = 0
        var moved = false
        val slopPx = 6f * context.resources.displayMetrics.density.coerceAtLeast(1f)

        targetView.setOnTouchListener { _, event ->
            val params = rootParams ?: return@setOnTouchListener false
            val frame = rootFrame ?: return@setOnTouchListener false
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downRawX = event.rawX
                    downRawY = event.rawY
                    startX = params.x
                    startY = params.y
                    moved = false
                    false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - downRawX
                    val dy = event.rawY - downRawY
                    if (!moved && (abs(dx) > slopPx || abs(dy) > slopPx)) {
                        moved = true
                        dodgeAnimator?.cancel()
                        dodgeAnimator = null
                        pendingTargetLeft = null
                        pendingTargetTop = null
                        layoutCoordinator?.notifyDragStart(AgyOverlayLayoutCoordinator.ManagedWindowId.TASK_MAP)
                    }
                    if (moved) {
                        val vp = layoutCoordinator?.currentViewportSafeBounds()
                            ?: AgyOverlayLayoutCoordinator.buildViewportSafeBounds(
                                screenWidth = context.resources.displayMetrics.widthPixels,
                                screenHeight = context.resources.displayMetrics.heightPixels,
                                density = context.resources.displayMetrics.density
                            )
                        val curW = frame.width.takeIf { it > 0 }
                            ?: if (isCollapsed) estimateCollapsedWidthPx() else estimateExpandedWidthPx()
                        val curH = frame.height.takeIf { it > 0 }
                            ?: if (isCollapsed) estimateCollapsedHeightPx() else estimateExpandedHeightPx()
                        val (clampedX, clampedY) = AgyOverlayLayoutCoordinator.clampTopLeftToSafeBounds(
                            left = startX + dx.toInt(),
                            top = startY + dy.toInt(),
                            width = curW,
                            height = curH,
                            viewport = vp
                        )
                        params.x = clampedX
                        params.y = clampedY
                        try {
                            windowManager?.updateViewLayout(frame, params)
                        } catch (_: Exception) {}
                        layoutCoordinator?.notifyDragMove(AgyOverlayLayoutCoordinator.ManagedWindowId.TASK_MAP)
                        true
                    } else {
                        false
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (moved) {
                        layoutCoordinator?.notifyDragEnd(
                            id = AgyOverlayLayoutCoordinator.ManagedWindowId.TASK_MAP,
                            animate = true
                        )
                    }
                    moved
                }
                else -> false
            }
        }
    }

    private fun hasOverlayPermission(): Boolean {
        return Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(context)
    }

    private fun runOnMain(block: () -> Unit) {
        if (Looper.myLooper() == Looper.getMainLooper()) {
            block()
        } else {
            mainHandler.post(block)
        }
    }
}

