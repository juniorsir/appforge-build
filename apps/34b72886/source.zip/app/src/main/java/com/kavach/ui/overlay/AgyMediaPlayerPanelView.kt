package com.kavach.ui.overlay

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.SurfaceTexture
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.TextUtils
import android.view.Gravity
import android.view.Surface
import android.view.TextureView
import android.view.View
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import java.util.Locale
import kotlin.math.abs
import kotlin.math.sin

/**
 * Apple Picture-in-Picture / QuickTime-inspired Custom Media Player Panel rendered inside
 * Window 3 (`agy_task_map`) when `mode == "player"`.
 *
 * Design & Architecture:
 * - Zero emojis: All icons are rendered as crisp Apple SF Symbols-style vector SVG paths via
 *   [AgyAppleVectorIconView].
 * - Translucent frosted-glass inline overlay controls (`topGlassBar`, `centerTransportCluster`,
 *   and `bottomGlassBar`) float directly on top of the 16:9 video / audio-artwork canvas.
 * - Lazy WebView instantiation: `WebView` is only created on demand if a YouTube/web-embed track
 *   is played, preventing service-context WebView crashes when playing standard local/HTTP videos.
 */
@SuppressLint("SetJavaScriptEnabled")
class AgyMediaPlayerPanelView(
    context: Context,
    val controller: AgyMediaPlaybackController = AgyMediaPlaybackController(context)
) : LinearLayout(context) {

    companion object {
        const val PLAYER_TAG_PREFIX = "${AgyTaskMapOverlayManager.TASK_MAP_NODE_TAG}_player"
    }

    var onRequestBackgroundPill: (() -> Unit)? = null
    var onRequestFullscreenLightbox: ((List<AgyHudDynamicModels.ResultMediaItem>, Int) -> Unit)? = null
    var onPlayerStateChanged: ((AgyMediaPlaybackController.PlaybackSnapshot) -> Unit)? = null
    var onRequestDismissPlayer: (() -> Unit)? = null

    private val d = context.resources.displayMetrics.density.coerceAtLeast(1f)

    // Unified 16:9 Media Surface Hosting Video, Audio Deck, and Translucent Glass Overlays
    private val mediaSurfaceContainer: FrameLayout
    private val videoTextureView: TextureView
    private var embedWebView: WebView? = null
    private val webEmbedHostFrame: FrameLayout

    // Audio-Only Canvas inside the same 16:9 surface
    private val audioDeckContainer: LinearLayout
    private val audioThumbImage: ImageView
    private val audioFallbackIcon: AgyAppleVectorIconView
    private val audioWaveformView: AudioWaveformView
    private val audioModeBadgeText: TextView

    // Top Translucent Glass Overlay Bar (Track Title + Inline SVG Mode / PiP / Expand / Close Buttons)
    private val topGlassBar: LinearLayout
    private val modeIndicatorIcon: AgyAppleVectorIconView
    private val trackTitleText: TextView
    private val trackSubtitleText: TextView
    val videoModeBtn: AgyAppleVectorIconView
    val audioModeBtn: AgyAppleVectorIconView
    val bgModeBtn: AgyAppleVectorIconView
    val popOutBtn: AgyAppleVectorIconView

    // Center Translucent Glass Transport Cluster (Backward, Play/Pause, Forward)
    private val centerTransportCluster: LinearLayout
    val prevBtn: AgyAppleVectorIconView
    val playPauseBtn: AgyAppleVectorIconView
    val nextBtn: AgyAppleVectorIconView

    // Bottom Translucent Glass Scrubber + Inline SVG Utility Bar
    private val bottomGlassBar: LinearLayout
    private val seekBar: SeekBar
    private val elapsedTimeText: TextView
    private val durationTimeText: TextView
    val volumeMuteBtn: AgyAppleVectorIconView
    val loopBtn: AgyAppleVectorIconView
    val speedBtn: AgyAppleVectorIconView
    val queueToggleBtn: AgyAppleVectorIconView

    // Expandable Playlist Queue Drawer below the surface
    private val queueScrollView: ScrollView
    private val queueListContainer: LinearLayout

    private var activeSurface: Surface? = null
    private var isUserSeeking: Boolean = false
    private var isQueueExpanded: Boolean = false
    private var glassOverlayVisible: Boolean = true
    private var lastLoadedThumbUri: String = ""
    private var lastRenderedPlaylistSig: String = ""

    private var currentTheme: AgyHudDynamicModels.ResolvedHudTheme =
        AgyHudDynamicModels.resolveTheme(AgyHudDynamicModels.HudThemeConfig(), Color.parseColor("#EC4899"))

    init {
        orientation = VERTICAL
        tag = PLAYER_TAG_PREFIX
        contentDescription = PLAYER_TAG_PREFIX
        importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS

        // Provide lazy WebView factory to controller so WebView is never created unless a web embed is loaded
        controller.webViewProvider = { getOrCreateEmbedWebView() }

        // 1. Primary 16:9 Media Surface Container with Overlaid Translucent Glass Controls
        mediaSurfaceContainer = FrameLayout(context).apply {
            layoutParams = LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (164 * d).toInt())
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = 15f * d
                setColor(Color.parseColor("#FF070B14"))
                setStroke((1f * d).toInt().coerceAtLeast(1), Color.parseColor("#33FFFFFF"))
            }
            clipChildren = true
            clipToPadding = true
            contentDescription = "${PLAYER_TAG_PREFIX}_video_viewport"
            tag = "${PLAYER_TAG_PREFIX}_video_viewport"
        }

        videoTextureView = TextureView(context).apply {
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT,
                Gravity.CENTER
            )
            surfaceTextureListener = object : TextureView.SurfaceTextureListener {
                override fun onSurfaceTextureAvailable(surface: SurfaceTexture, width: Int, height: Int) {
                    try {
                        activeSurface?.release()
                    } catch (_: Throwable) {}
                    val s = Surface(surface)
                    activeSurface = s
                    controller.bindVideoSurface(s)
                }

                override fun onSurfaceTextureSizeChanged(surface: SurfaceTexture, width: Int, height: Int) {}

                override fun onSurfaceTextureDestroyed(surface: SurfaceTexture): Boolean {
                    controller.bindVideoSurface(null)
                    try {
                        activeSurface?.release()
                    } catch (_: Throwable) {}
                    activeSurface = null
                    return true
                }

                override fun onSurfaceTextureUpdated(surface: SurfaceTexture) {}
            }
            setOnClickListener {
                toggleGlassControlsOrPlayPause()
            }
        }

        webEmbedHostFrame = FrameLayout(context).apply {
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            visibility = View.GONE
        }

        // Audio-Only Deck Layer inside the 16:9 surface
        audioDeckContainer = LinearLayout(context).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding((14 * d).toInt(), (38 * d).toInt(), (14 * d).toInt(), (44 * d).toInt())
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(
                    Color.parseColor("#FF0F172A"),
                    Color.parseColor("#FF1E1B4B"),
                    Color.parseColor("#FF090D16")
                )
            ).apply {
                cornerRadius = 15f * d
            }
            visibility = View.GONE
            contentDescription = "${PLAYER_TAG_PREFIX}_audio_deck"
            tag = "${PLAYER_TAG_PREFIX}_audio_deck"
            setOnClickListener { controller.togglePlayPause() }
        }

        val thumbFrame = FrameLayout(context).apply {
            layoutParams = LayoutParams((52 * d).toInt(), (52 * d).toInt()).apply {
                marginEnd = (10 * d).toInt()
            }
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = 12f * d
                setColor(Color.parseColor("#441E293B"))
                setStroke((1f * d).toInt().coerceAtLeast(1), Color.parseColor("#33FFFFFF"))
            }
            clipChildren = true
            clipToPadding = true
        }

        audioFallbackIcon = AgyAppleVectorIconView(context, AgyAppleVectorIconView.IconType.MUSIC_NOTE).apply {
            glassStyle = AgyAppleVectorIconView.GlassStyle.NONE
            iconSizeDp = 22f
            iconTint = Color.parseColor("#CCFFFFFF")
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT,
                Gravity.CENTER
            )
        }

        audioThumbImage = ImageView(context).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        }
        thumbFrame.addView(audioFallbackIcon)
        thumbFrame.addView(audioThumbImage)

        val audioRightCol = LinearLayout(context).apply {
            orientation = VERTICAL
            layoutParams = LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }

        audioModeBadgeText = TextView(context).apply {
            text = "AUDIO STREAM"
            textSize = 8f
            setTypeface(Typeface.MONOSPACE, Typeface.BOLD)
            setTextColor(Color.parseColor("#CCFFFFFF"))
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }

        audioWaveformView = AudioWaveformView(context).apply {
            layoutParams = LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (26 * d).toInt()).apply {
                topMargin = (4 * d).toInt()
            }
        }

        audioRightCol.addView(audioModeBadgeText)
        audioRightCol.addView(audioWaveformView)
        audioDeckContainer.addView(thumbFrame)
        audioDeckContainer.addView(audioRightCol)

        // 2. Top Translucent Frosted-Glass Overlay Bar
        topGlassBar = LinearLayout(context).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding((7 * d).toInt(), (4 * d).toInt(), (5 * d).toInt(), (4 * d).toInt())
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP
            ).apply {
                setMargins((6 * d).toInt(), (6 * d).toInt(), (6 * d).toInt(), 0)
            }
            background = buildFrostedGlassBackground(radiusDp = 12f, alpha = 168)
        }

        modeIndicatorIcon = AgyAppleVectorIconView(context, AgyAppleVectorIconView.IconType.VIDEO_FILL).apply {
            glassStyle = AgyAppleVectorIconView.GlassStyle.NONE
            iconSizeDp = 12.5f
            minTouchSizeDp = 18f
            iconTint = Color.WHITE
            isClickable = false
            layoutParams = LayoutParams((18 * d).toInt(), (18 * d).toInt()).apply {
                marginEnd = (5 * d).toInt()
            }
        }

        val titleCol = LinearLayout(context).apply {
            orientation = VERTICAL
            layoutParams = LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                marginEnd = (4 * d).toInt()
            }
        }

        trackTitleText = TextView(context).apply {
            text = "Ready to Play"
            textSize = 10f
            setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
            setTextColor(Color.WHITE)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            contentDescription = "${PLAYER_TAG_PREFIX}_track_title"
            tag = "${PLAYER_TAG_PREFIX}_track_title"
        }

        trackSubtitleText = TextView(context).apply {
            text = "Video"
            textSize = 8f
            setTextColor(Color.parseColor("#B8E2E8F0"))
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            contentDescription = "${PLAYER_TAG_PREFIX}_track_subtitle"
            tag = "${PLAYER_TAG_PREFIX}_track_subtitle"
        }

        titleCol.addView(trackTitleText)
        titleCol.addView(trackSubtitleText)

        fun inlineTopSvgBtn(
            icon: AgyAppleVectorIconView.IconType,
            suffix: String,
            onClick: () -> Unit
        ): AgyAppleVectorIconView {
            return AgyAppleVectorIconView(context, icon).apply {
                iconSizeDp = 12.5f
                minTouchSizeDp = 24f
                glassStyle = AgyAppleVectorIconView.GlassStyle.GLASS_CIRCLE
                contentDescription = "${PLAYER_TAG_PREFIX}_$suffix"
                tag = "${PLAYER_TAG_PREFIX}_$suffix"
                layoutParams = LayoutParams((24 * d).toInt(), (24 * d).toInt()).apply {
                    marginStart = (3 * d).toInt()
                }
                setOnClickListener { onClick() }
            }
        }

        videoModeBtn = inlineTopSvgBtn(AgyAppleVectorIconView.IconType.VIDEO_FILL, "mode_video") {
            controller.setMediaMode("video")
        }
        audioModeBtn = inlineTopSvgBtn(AgyAppleVectorIconView.IconType.MUSIC_NOTE, "mode_audio") {
            controller.setMediaMode("audio")
        }
        bgModeBtn = inlineTopSvgBtn(AgyAppleVectorIconView.IconType.PIP_ENTER, "mode_bg") {
            controller.setBackgroundMode(true)
            onRequestBackgroundPill?.invoke()
        }
        popOutBtn = inlineTopSvgBtn(AgyAppleVectorIconView.IconType.ARROW_EXPAND, "popout_btn") {
            val snap = controller.currentSnapshot()
            val items = snap.playlist.map { it.toResultMediaItem() }
            if (items.isNotEmpty()) {
                onRequestFullscreenLightbox?.invoke(items, snap.currentIndex)
            }
        }

        topGlassBar.addView(modeIndicatorIcon)
        topGlassBar.addView(titleCol)
        topGlassBar.addView(videoModeBtn)
        topGlassBar.addView(audioModeBtn)
        topGlassBar.addView(bgModeBtn)
        topGlassBar.addView(popOutBtn)

        // 3. Center Translucent Glass Transport Cluster (Overlaid directly on video/artwork)
        centerTransportCluster = LinearLayout(context).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER
            setPadding((8 * d).toInt(), (4 * d).toInt(), (8 * d).toInt(), (4 * d).toInt())
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER
            )
            background = buildFrostedGlassBackground(radiusDp = 999f, alpha = 135)
        }

        prevBtn = AgyAppleVectorIconView(context, AgyAppleVectorIconView.IconType.BACKWARD_FILL).apply {
            iconSizeDp = 14f
            minTouchSizeDp = 32f
            glassStyle = AgyAppleVectorIconView.GlassStyle.GLASS_CIRCLE
            contentDescription = "${PLAYER_TAG_PREFIX}_prev_btn"
            tag = "${PLAYER_TAG_PREFIX}_prev_btn"
            layoutParams = LayoutParams((32 * d).toInt(), (32 * d).toInt())
            setOnClickListener { controller.previousTrack() }
        }

        playPauseBtn = AgyAppleVectorIconView(context, AgyAppleVectorIconView.IconType.PAUSE_FILL).apply {
            iconSizeDp = 17f
            minTouchSizeDp = 40f
            glassStyle = AgyAppleVectorIconView.GlassStyle.ACCENT_CIRCLE
            contentDescription = "${PLAYER_TAG_PREFIX}_play_pause_btn"
            tag = "${PLAYER_TAG_PREFIX}_play_pause_btn"
            layoutParams = LayoutParams((40 * d).toInt(), (40 * d).toInt()).apply {
                marginStart = (10 * d).toInt()
                marginEnd = (10 * d).toInt()
            }
            setOnClickListener { controller.togglePlayPause() }
        }

        nextBtn = AgyAppleVectorIconView(context, AgyAppleVectorIconView.IconType.FORWARD_FILL).apply {
            iconSizeDp = 14f
            minTouchSizeDp = 32f
            glassStyle = AgyAppleVectorIconView.GlassStyle.GLASS_CIRCLE
            contentDescription = "${PLAYER_TAG_PREFIX}_next_btn"
            tag = "${PLAYER_TAG_PREFIX}_next_btn"
            layoutParams = LayoutParams((32 * d).toInt(), (32 * d).toInt())
            setOnClickListener { controller.nextTrack() }
        }

        centerTransportCluster.addView(prevBtn)
        centerTransportCluster.addView(playPauseBtn)
        centerTransportCluster.addView(nextBtn)

        // 4. Bottom Translucent Frosted-Glass Scrubber & Inline Utility Bar
        bottomGlassBar = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding((7 * d).toInt(), (3 * d).toInt(), (6 * d).toInt(), (3 * d).toInt())
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM
            ).apply {
                setMargins((6 * d).toInt(), 0, (6 * d).toInt(), (6 * d).toInt())
            }
            background = buildFrostedGlassBackground(radiusDp = 12f, alpha = 176)
        }

        elapsedTimeText = TextView(context).apply {
            text = "00:00"
            textSize = 8f
            typeface = Typeface.MONOSPACE
            setTextColor(Color.parseColor("#E2E8F0"))
            contentDescription = "${PLAYER_TAG_PREFIX}_elapsed_time"
            tag = "${PLAYER_TAG_PREFIX}_elapsed_time"
            layoutParams = LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        }

        seekBar = SeekBar(context).apply {
            max = 1000
            progress = 0
            setPadding((6 * d).toInt(), 0, (6 * d).toInt(), 0)
            contentDescription = "${PLAYER_TAG_PREFIX}_seek_bar"
            tag = "${PLAYER_TAG_PREFIX}_seek_bar"
            layoutParams = LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                    if (fromUser) {
                        val dur = controller.currentSnapshot().durationMs
                        if (dur > 0L) {
                            val previewMs = ((progress / 1000.0) * dur).toLong()
                            elapsedTimeText.text = AgyMediaPlaybackController.formatTimeMs(previewMs)
                        }
                    }
                }

                override fun onStartTrackingTouch(sb: SeekBar?) {
                    isUserSeeking = true
                }

                override fun onStopTrackingTouch(sb: SeekBar?) {
                    isUserSeeking = false
                    controller.seekByPermille(sb?.progress ?: 0)
                }
            })
        }

        durationTimeText = TextView(context).apply {
            text = "--:--"
            textSize = 8f
            typeface = Typeface.MONOSPACE
            setTextColor(Color.parseColor("#94A3B8"))
            contentDescription = "${PLAYER_TAG_PREFIX}_duration_time"
            tag = "${PLAYER_TAG_PREFIX}_duration_time"
            layoutParams = LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                marginEnd = (4 * d).toInt()
            }
        }

        fun inlineBottomSvgBtn(
            icon: AgyAppleVectorIconView.IconType,
            suffix: String,
            onClick: () -> Unit
        ): AgyAppleVectorIconView {
            return AgyAppleVectorIconView(context, icon).apply {
                iconSizeDp = 12f
                minTouchSizeDp = 23f
                glassStyle = AgyAppleVectorIconView.GlassStyle.GLASS_CIRCLE
                contentDescription = "${PLAYER_TAG_PREFIX}_$suffix"
                tag = "${PLAYER_TAG_PREFIX}_$suffix"
                layoutParams = LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, (23 * d).toInt()).apply {
                    marginStart = (2.5f * d).toInt()
                }
                setOnClickListener { onClick() }
            }
        }

        volumeMuteBtn = inlineBottomSvgBtn(AgyAppleVectorIconView.IconType.SPEAKER_WAVE, "mute_vol_btn") {
            controller.cycleVolumePreset()
        }.apply {
            setOnLongClickListener {
                controller.toggleMute()
                true
            }
        }

        loopBtn = inlineBottomSvgBtn(AgyAppleVectorIconView.IconType.REPEAT, "loop_btn") {
            controller.toggleLoop()
        }

        speedBtn = inlineBottomSvgBtn(AgyAppleVectorIconView.IconType.NONE, "speed_btn") {
            controller.cycleSpeed()
        }.apply {
            glassStyle = AgyAppleVectorIconView.GlassStyle.GLASS_PILL
            labelText = "1x"
        }

        queueToggleBtn = inlineBottomSvgBtn(AgyAppleVectorIconView.IconType.LIST_BULLET, "queue_toggle_btn") {
            isQueueExpanded = !isQueueExpanded
            renderSnapshot(controller.currentSnapshot())
        }

        bottomGlassBar.addView(elapsedTimeText)
        bottomGlassBar.addView(seekBar)
        bottomGlassBar.addView(durationTimeText)
        bottomGlassBar.addView(volumeMuteBtn)
        bottomGlassBar.addView(loopBtn)
        bottomGlassBar.addView(speedBtn)
        bottomGlassBar.addView(queueToggleBtn)

        mediaSurfaceContainer.addView(videoTextureView)
        mediaSurfaceContainer.addView(webEmbedHostFrame)
        mediaSurfaceContainer.addView(audioDeckContainer)
        mediaSurfaceContainer.addView(topGlassBar)
        mediaSurfaceContainer.addView(centerTransportCluster)
        mediaSurfaceContainer.addView(bottomGlassBar)
        addView(mediaSurfaceContainer)

        // 5. Expandable Playlist Queue Drawer
        queueListContainer = LinearLayout(context).apply {
            orientation = VERTICAL
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }

        queueScrollView = ScrollView(context).apply {
            layoutParams = LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (88 * d).toInt()).apply {
                topMargin = (5 * d).toInt()
            }
            visibility = View.GONE
            contentDescription = "${PLAYER_TAG_PREFIX}_queue_drawer"
            tag = "${PLAYER_TAG_PREFIX}_queue_drawer"
            addView(queueListContainer)
        }
        addView(queueScrollView)

        controller.onStateChanged = { snap ->
            renderSnapshot(snap)
            onPlayerStateChanged?.invoke(snap)
        }
    }

    private fun getOrCreateEmbedWebView(): WebView? {
        embedWebView?.let { return it }
        return try {
            val wv = WebView(context).apply {
                layoutParams = FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
                setBackgroundColor(Color.BLACK)
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                settings.mediaPlaybackRequiresUserGesture = false
                settings.loadWithOverviewMode = true
                settings.useWideViewPort = true
                settings.cacheMode = WebSettings.LOAD_DEFAULT
                webViewClient = WebViewClient()
                webChromeClient = WebChromeClient()
            }
            webEmbedHostFrame.removeAllViews()
            webEmbedHostFrame.addView(wv)
            embedWebView = wv
            wv
        } catch (_: Throwable) {
            null
        }
    }

    private fun toggleGlassControlsOrPlayPause() {
        val snap = controller.currentSnapshot()
        if (snap.mediaMode == "video" && snap.isPlaying) {
            glassOverlayVisible = !glassOverlayVisible
            renderSnapshot(snap)
        } else {
            glassOverlayVisible = true
            controller.togglePlayPause()
        }
    }

    fun updatePlayer(
        config: AgyHudDynamicModels.TaskMapConfig,
        theme: AgyHudDynamicModels.ResolvedHudTheme
    ) {
        currentTheme = theme
        val playerData = config.player ?: AgyHudDynamicModels.PlayerTaskMapData(
            mediaMode = "audio",
            playing = config.media?.playing ?: true,
            playlist = listOf(
                AgyHudDynamicModels.PlayerTrackItem(
                    id = "trk_0",
                    title = config.media?.title ?: config.title.ifBlank { "Now Playing" },
                    subtitle = config.media?.subtitle.orEmpty(),
                    uri = "",
                    isVideo = false
                )
            )
        )
        controller.applyPlayerData(playerData)
        renderSnapshot(controller.currentSnapshot())
    }

    fun stopPlayback() {
        controller.stopAndRelease()
    }

    private fun renderSnapshot(snap: AgyMediaPlaybackController.PlaybackSnapshot) {
        val theme = currentTheme
        val track = snap.currentTrack
        val isVideoMode = snap.mediaMode == "video"

        // Always keep glass overlays visible when paused or in audio mode
        val showOverlays = glassOverlayVisible || !snap.isPlaying || !isVideoMode
        topGlassBar.visibility = if (showOverlays) View.VISIBLE else View.GONE
        centerTransportCluster.visibility = if (showOverlays) View.VISIBLE else View.GONE
        bottomGlassBar.visibility = if (showOverlays) View.VISIBLE else View.GONE

        // Update Top Glass Mode & Window Buttons
        modeIndicatorIcon.iconType = if (isVideoMode) {
            AgyAppleVectorIconView.IconType.VIDEO_FILL
        } else {
            AgyAppleVectorIconView.IconType.WAVEFORM
        }
        modeIndicatorIcon.iconTint = theme.accent

        styleGlassIconButton(videoModeBtn, active = isVideoMode, accent = theme.accent, circle = true)
        styleGlassIconButton(audioModeBtn, active = !isVideoMode, accent = theme.accent, circle = true)
        styleGlassIconButton(bgModeBtn, active = snap.backgroundMode, accent = theme.accent, circle = true)
        styleGlassIconButton(popOutBtn, active = false, accent = theme.accent, circle = true)

        // Toggle Video Surface vs Audio-Only Artwork Deck inside the 16:9 viewport
        if (isVideoMode) {
            audioDeckContainer.visibility = View.GONE
            if (track?.isWebEmbed == true) {
                getOrCreateEmbedWebView()
                webEmbedHostFrame.visibility = View.VISIBLE
                videoTextureView.visibility = View.INVISIBLE
            } else {
                webEmbedHostFrame.visibility = View.GONE
                videoTextureView.visibility = View.VISIBLE
            }
        } else {
            webEmbedHostFrame.visibility = View.INVISIBLE
            videoTextureView.visibility = View.INVISIBLE
            audioDeckContainer.visibility = View.VISIBLE
            audioModeBadgeText.setTextColor(theme.accent)
            audioModeBadgeText.text = when {
                track?.isWebEmbed == true -> "WEB AUDIO STREAM"
                snap.isPlaying -> "AUDIO-ONLY • LIVE"
                else -> "AUDIO-ONLY • PAUSED"
            }
            audioWaveformView.updateState(isPlaying = snap.isPlaying, accentColor = theme.accent)

            val thumbUri = track?.thumbnailUri.orEmpty().ifBlank { track?.uri.orEmpty() }
            if (thumbUri != lastLoadedThumbUri) {
                lastLoadedThumbUri = thumbUri
                if (thumbUri.isNotBlank() && track?.isWebEmbed == false) {
                    AgyResultsMediaLoader.loadPreviewBitmap(
                        context = context,
                        item = track.toResultMediaItem(),
                        maxDimensionPx = 240
                    ) { bmp ->
                        audioThumbImage.setImageBitmap(bmp)
                        audioFallbackIcon.visibility = if (bmp != null) View.GONE else View.VISIBLE
                    }
                } else {
                    audioThumbImage.setImageDrawable(null)
                    audioFallbackIcon.visibility = View.VISIBLE
                }
            }
        }

        // Track Title & Subtitle inside top glass bar
        trackTitleText.text = track?.title ?: "No Track Loaded"
        val totalTracks = snap.playlist.size
        val subBuilder = StringBuilder()
        if (!track?.subtitle.isNullOrBlank()) {
            subBuilder.append(track?.subtitle).append(" • ")
        }
        if (totalTracks > 1) {
            subBuilder.append("${snap.currentIndex + 1}/$totalTracks")
        } else {
            subBuilder.append(if (isVideoMode) "Video" else "Audio")
        }
        trackSubtitleText.text = subBuilder.toString()

        // Center Glass Transport Cluster
        styleGlassIconButton(prevBtn, active = false, accent = theme.accent, circle = true)
        playPauseBtn.iconType = if (snap.isPlaying) {
            AgyAppleVectorIconView.IconType.PAUSE_FILL
        } else {
            AgyAppleVectorIconView.IconType.PLAY_FILL
        }
        playPauseBtn.accentColor = theme.accent
        playPauseBtn.glassStyle = AgyAppleVectorIconView.GlassStyle.ACCENT_CIRCLE
        playPauseBtn.iconTint = Color.WHITE
        styleGlassIconButton(nextBtn, active = false, accent = theme.accent, circle = true)

        // Bottom Glass Scrubber & Inline SVG Utility Buttons
        if (!isUserSeeking) {
            seekBar.progress = snap.progressPermille
            elapsedTimeText.text = snap.elapsedLabel
        }
        durationTimeText.text = snap.durationLabel

        val volPercent = if (snap.isMuted) 0 else (snap.volume * 100).toInt()
        volumeMuteBtn.iconType = if (snap.isMuted || volPercent == 0) {
            AgyAppleVectorIconView.IconType.SPEAKER_SLASH
        } else {
            AgyAppleVectorIconView.IconType.SPEAKER_WAVE
        }
        styleGlassIconButton(volumeMuteBtn, active = snap.isMuted, accent = theme.accent, circle = true)

        styleGlassIconButton(loopBtn, active = snap.isLooping, accent = theme.accent, circle = true)

        val speedStr = if (snap.speed % 1.0f == 0f) {
            String.format(Locale.US, "%.0fx", snap.speed)
        } else {
            String.format(Locale.US, "%.2fx", snap.speed).trimEnd('0').trimEnd('.') + "x"
        }
        speedBtn.labelText = speedStr.replace("xx", "x")
        styleGlassIconButton(speedBtn, active = abs(snap.speed - 1.0f) > 0.05f, accent = theme.accent, circle = false)

        queueToggleBtn.labelText = if (snap.playlist.size > 1) "${snap.playlist.size}" else ""
        styleGlassIconButton(
            queueToggleBtn,
            active = isQueueExpanded,
            accent = theme.accent,
            circle = snap.playlist.size <= 1
        )

        // Expandable Playlist Queue Drawer
        if (isQueueExpanded && snap.playlist.isNotEmpty()) {
            queueScrollView.visibility = View.VISIBLE
            queueScrollView.background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = 12f * d
                setColor(theme.secondarySurface)
                setStroke((0.9f * d).toInt().coerceAtLeast(1), theme.border)
            }
            val sig = "${snap.currentIndex}|${snap.isPlaying}|${snap.playlist.joinToString(",") { "${it.id}:${it.title}" }}"
            if (sig != lastRenderedPlaylistSig) {
                lastRenderedPlaylistSig = sig
                rebuildQueueRows(snap, theme)
            }
        } else {
            queueScrollView.visibility = View.GONE
        }
    }

    private fun styleGlassIconButton(
        btn: AgyAppleVectorIconView,
        active: Boolean,
        accent: Int,
        circle: Boolean
    ) {
        btn.accentColor = accent
        if (active) {
            btn.glassStyle = if (circle) {
                AgyAppleVectorIconView.GlassStyle.ACCENT_CIRCLE
            } else {
                AgyAppleVectorIconView.GlassStyle.ACCENT_PILL
            }
            btn.iconTint = Color.WHITE
        } else {
            btn.glassStyle = if (circle) {
                AgyAppleVectorIconView.GlassStyle.GLASS_CIRCLE
            } else {
                AgyAppleVectorIconView.GlassStyle.GLASS_PILL
            }
            btn.glassFillColor = Color.parseColor("#880F172A")
            btn.glassBorderColor = Color.parseColor("#3DFFFFFF")
            btn.iconTint = Color.parseColor("#F1F5F9")
        }
    }

    private fun buildFrostedGlassBackground(radiusDp: Float, alpha: Int): GradientDrawable {
        return GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = radiusDp * d
            setColor(Color.argb(alpha.coerceIn(80, 235), 11, 17, 32))
            setStroke((0.9f * d).toInt().coerceAtLeast(1), Color.argb(68, 255, 255, 255))
        }
    }

    private fun rebuildQueueRows(
        snap: AgyMediaPlaybackController.PlaybackSnapshot,
        theme: AgyHudDynamicModels.ResolvedHudTheme
    ) {
        queueListContainer.removeAllViews()
        snap.playlist.forEachIndexed { idx, item ->
            val isCurrent = idx == snap.currentIndex
            val row = LinearLayout(context).apply {
                orientation = HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding((8 * d).toInt(), (6 * d).toInt(), (8 * d).toInt(), (6 * d).toInt())
                contentDescription = "${PLAYER_TAG_PREFIX}_queue_item_$idx"
                tag = "${PLAYER_TAG_PREFIX}_queue_item_$idx"
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = 8f * d
                    setColor(
                        if (isCurrent) {
                            Color.argb(38, Color.red(theme.accent), Color.green(theme.accent), Color.blue(theme.accent))
                        } else {
                            Color.TRANSPARENT
                        }
                    )
                }
                setOnClickListener {
                    controller.selectTrack(idx, autoPlay = true)
                }
            }

            val rowIcon = AgyAppleVectorIconView(
                context,
                when {
                    isCurrent && snap.isPlaying -> AgyAppleVectorIconView.IconType.WAVEFORM
                    isCurrent -> AgyAppleVectorIconView.IconType.PLAY_FILL
                    item.isVideo -> AgyAppleVectorIconView.IconType.VIDEO_FILL
                    else -> AgyAppleVectorIconView.IconType.MUSIC_NOTE
                }
            ).apply {
                glassStyle = AgyAppleVectorIconView.GlassStyle.NONE
                iconSizeDp = 12f
                minTouchSizeDp = 18f
                isClickable = false
                iconTint = if (isCurrent) theme.accent else theme.textSecondary
                layoutParams = LayoutParams((18 * d).toInt(), (18 * d).toInt()).apply {
                    marginEnd = (6 * d).toInt()
                }
            }

            val titleTv = TextView(context).apply {
                text = "${idx + 1}. ${item.title}"
                textSize = 9.5f
                setTypeface(Typeface.SANS_SERIF, if (isCurrent) Typeface.BOLD else Typeface.NORMAL)
                setTextColor(if (isCurrent) theme.accent else theme.textPrimary)
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
                layoutParams = LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            }

            val durTv = TextView(context).apply {
                text = if (item.durationMs > 0L) AgyMediaPlaybackController.formatTimeMs(item.durationMs) else ""
                textSize = 8f
                typeface = Typeface.MONOSPACE
                setTextColor(theme.textSecondary)
                layoutParams = LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                    marginStart = (6 * d).toInt()
                }
            }

            row.addView(rowIcon)
            row.addView(titleTv)
            row.addView(durTv)
            queueListContainer.addView(row)
        }
    }

    /**
     * Lightweight animated audio equalizer waveform for the Audio-Only music deck.
     */
    class AudioWaveformView(context: Context) : View(context) {
        private val d = context.resources.displayMetrics.density.coerceAtLeast(1f)
        private val barPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
        }
        private val barRect = RectF()
        private var isPlaying: Boolean = false
        private var accentColor: Int = Color.parseColor("#EC4899")
        private var phase: Float = 0f

        private val ticker = object : Runnable {
            override fun run() {
                if (!isPlaying || !isAttachedToWindow) return
                phase += 0.35f
                invalidate()
                postDelayed(this, 80L)
            }
        }

        fun updateState(isPlaying: Boolean, accentColor: Int) {
            val changed = this.isPlaying != isPlaying || this.accentColor != accentColor
            this.isPlaying = isPlaying
            this.accentColor = accentColor
            if (changed) {
                removeCallbacks(ticker)
                if (isPlaying) {
                    post(ticker)
                }
                invalidate()
            }
        }

        override fun onDetachedFromWindow() {
            removeCallbacks(ticker)
            super.onDetachedFromWindow()
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val w = width.toFloat()
            val h = height.toFloat()
            if (w <= 0f || h <= 0f) return

            val barCount = 20
            val gap = 2.5f * d
            val totalGap = gap * (barCount - 1)
            val barW = ((w - totalGap) / barCount).coerceAtLeast(2f * d)
            val radius = barW / 2f

            for (i in 0 until barCount) {
                val ratio = if (isPlaying) {
                    val wave = sin(phase + i * 0.55f).toFloat()
                    (0.28f + 0.65f * ((wave + 1f) * 0.5f)).coerceIn(0.18f, 0.96f)
                } else {
                    0.22f + (i % 3) * 0.08f
                }
                val barH = (h * ratio).coerceAtLeast(3f * d)
                val left = i * (barW + gap)
                val top = (h - barH) / 2f
                barRect.set(left, top, left + barW, top + barH)
                barPaint.color = if (isPlaying) {
                    accentColor
                } else {
                    Color.argb(110, Color.red(accentColor), Color.green(accentColor), Color.blue(accentColor))
                }
                canvas.drawRoundRect(barRect, radius, radius, barPaint)
            }
        }
    }
}
