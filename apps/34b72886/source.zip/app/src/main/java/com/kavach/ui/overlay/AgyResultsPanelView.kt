package com.kavach.ui.overlay

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.util.AttributeSet
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * Interactive Summary Card + Horizontal Swipe Media/File Carousel rendered inside Window 3
 * (`agy_task_map`) when `taskMap.mode == "results"`.
 */
class AgyResultsPanelView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : LinearLayout(context, attrs, defStyleAttr) {

    var onItemClicked: ((List<AgyHudDynamicModels.ResultMediaItem>, Int) -> Unit)? = null

    private val density: Float get() = context.resources.displayMetrics.density
    private val mainHandler = Handler(Looper.getMainLooper())

    private var currentConfig: AgyHudDynamicModels.TaskMapConfig = AgyHudDynamicModels.TaskMapConfig()
    private var currentTheme: AgyHudDynamicModels.ResolvedHudTheme =
        AgyHudDynamicModels.resolveTheme(AgyHudDynamicModels.HudThemeConfig(), Color.parseColor("#0095F6"))
    private var lastSignature: String = ""
    private var currentItems: List<AgyHudDynamicModels.ResultMediaItem> = emptyList()
    private var currentIndex: Int = 0
    private var summaryExpanded: Boolean = false
    private var carouselPageWidthPx: Int = 0

    // Summary Card Views
    private val summaryCard: LinearLayout
    private val metaRow: LinearLayout
    private val queryChipText: TextView
    private val sourceLabelText: TextView
    private val summaryTitleText: TextView
    private val summaryBodyText: TextView
    private val summaryMoreBtn: TextView
    private val loadingRow: LinearLayout
    private val loadingLabel: TextView

    // Carousel Views
    private val carouselSection: LinearLayout
    private val carouselPager: HorizontalScrollView
    private val carouselTrack: LinearLayout
    private val cardWrappers = mutableListOf<View>()
    private val footerNavRow: LinearLayout
    private val prevArrowBtn: TextView
    private val dotsContainer: LinearLayout
    private val counterBadgeText: TextView
    private val nextArrowBtn: TextView

    init {
        val d = density
        orientation = VERTICAL
        tag = "${AgyHudOverlayManager.HUD_NODE_TAG_PREFIX}results_panel"
        contentDescription = "${AgyHudOverlayManager.HUD_NODE_TAG_PREFIX}results_panel"
        layoutParams = LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

        // 1. Summary Card above Carousel
        summaryCard = LinearLayout(context).apply {
            orientation = VERTICAL
            setPadding((9 * d).toInt(), (8 * d).toInt(), (9 * d).toInt(), (8 * d).toInt())
            layoutParams = LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                .apply { bottomMargin = (6 * d).toInt() }
        }

        metaRow = LinearLayout(context).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                .apply { bottomMargin = (4 * d).toInt() }
        }

        queryChipText = TextView(context).apply {
            textSize = 9.5f
            setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            setPadding((6 * d).toInt(), (2 * d).toInt(), (6 * d).toInt(), (2 * d).toInt())
            layoutParams = LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }

        sourceLabelText = TextView(context).apply {
            textSize = 8.5f
            typeface = Typeface.MONOSPACE
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            setPadding((5 * d).toInt(), (2 * d).toInt(), (5 * d).toInt(), (2 * d).toInt())
            layoutParams = LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                .apply { marginStart = (4 * d).toInt() }
        }
        metaRow.addView(queryChipText)
        metaRow.addView(sourceLabelText)
        summaryCard.addView(metaRow)

        summaryTitleText = TextView(context).apply {
            textSize = 12f
            setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
            layoutParams = LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                .apply { bottomMargin = (3 * d).toInt() }
        }
        summaryCard.addView(summaryTitleText)

        summaryBodyText = TextView(context).apply {
            textSize = 10.5f
            setLineSpacing(1.5f * d, 1.12f)
            maxLines = 4
            ellipsize = TextUtils.TruncateAt.END
            layoutParams = LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            setOnClickListener { toggleSummaryExpanded() }
        }
        summaryCard.addView(summaryBodyText)

        summaryMoreBtn = TextView(context).apply {
            text = "More ▾"
            textSize = 9.5f
            setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
            setPadding(0, (3 * d).toInt(), (4 * d).toInt(), 0)
            layoutParams = LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            visibility = View.GONE
            setOnClickListener { toggleSummaryExpanded() }
        }
        summaryCard.addView(summaryMoreBtn)

        loadingRow = LinearLayout(context).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                .apply { topMargin = (5 * d).toInt() }
            visibility = View.GONE
        }
        val spinner = ProgressBar(context).apply {
            layoutParams = LayoutParams((14 * d).toInt(), (14 * d).toInt()).apply { marginEnd = (6 * d).toInt() }
        }
        loadingLabel = TextView(context).apply {
            text = "Gathering results…"
            textSize = 9.5f
            typeface = Typeface.MONOSPACE
        }
        loadingRow.addView(spinner)
        loadingRow.addView(loadingLabel)
        summaryCard.addView(loadingRow)

        addView(summaryCard)

        // 2. Swipeable Horizontal Media / File Carousel
        carouselSection = LinearLayout(context).apply {
            orientation = VERTICAL
            layoutParams = LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            visibility = View.GONE
        }

        carouselTrack = LinearLayout(context).apply {
            orientation = HORIZONTAL
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }

        var downX = 0f
        var downScrollX = 0
        carouselPager = object : HorizontalScrollView(context) {
            override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
                super.onSizeChanged(w, h, oldw, oldh)
                if (w > 0 && w != carouselPageWidthPx) {
                    carouselPageWidthPx = w
                    updateCarouselCardWidths()
                    post { snapToIndex(currentIndex, smooth = false) }
                }
            }
        }.apply {
            isHorizontalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            layoutParams = LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            addView(carouselTrack)
            setOnTouchListener { _, ev ->
                when (ev.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        downX = ev.rawX
                        downScrollX = scrollX
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        val pageW = resolvePageWidthPx()
                        if (pageW > 0 && currentItems.size > 1) {
                            val dx = downX - ev.rawX
                            val targetIdx = when {
                                abs(dx) > pageW * 0.18f -> {
                                    if (dx > 0) (currentIndex + 1).coerceAtMost(currentItems.lastIndex)
                                    else (currentIndex - 1).coerceAtLeast(0)
                                }
                                else -> ((scrollX.toFloat() / pageW.toFloat()).roundToInt())
                                    .coerceIn(0, currentItems.lastIndex)
                            }
                            post { selectIndex(targetIdx, smooth = true) }
                        }
                    }
                }
                false
            }
        }
        carouselSection.addView(carouselPager)

        // Footer Controls: [‹] [ • • • ] [1/N] [›]
        footerNavRow = LinearLayout(context).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                .apply { topMargin = (6 * d).toInt() }
        }

        fun navArrow(symbol: String, desc: String, delta: Int): TextView {
            return TextView(context).apply {
                text = symbol
                textSize = 13f
                setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
                gravity = Gravity.CENTER
                minWidth = (28 * d).toInt()
                minHeight = (26 * d).toInt()
                setPadding((6 * d).toInt(), (2 * d).toInt(), (6 * d).toInt(), (2 * d).toInt())
                contentDescription = "${AgyHudOverlayManager.HUD_NODE_TAG_PREFIX}$desc"
                setOnClickListener {
                    selectIndex((currentIndex + delta).coerceIn(0, (currentItems.size - 1).coerceAtLeast(0)), smooth = true)
                }
            }
        }

        prevArrowBtn = navArrow("‹", "results_prev", -1)
        dotsContainer = LinearLayout(context).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER
            layoutParams = LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        counterBadgeText = TextView(context).apply {
            textSize = 9.5f
            typeface = Typeface.MONOSPACE
            setPadding((6 * d).toInt(), (2 * d).toInt(), (6 * d).toInt(), (2 * d).toInt())
            layoutParams = LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                .apply { marginEnd = (4 * d).toInt() }
        }
        nextArrowBtn = navArrow("›", "results_next", 1)

        footerNavRow.addView(prevArrowBtn)
        footerNavRow.addView(dotsContainer)
        footerNavRow.addView(counterBadgeText)
        footerNavRow.addView(nextArrowBtn)
        carouselSection.addView(footerNavRow)

        addView(carouselSection)
    }

    fun getCurrentIndex(): Int = currentIndex
    fun getItemCount(): Int = currentItems.size
    fun isSummaryExpanded(): Boolean = summaryExpanded

    fun toggleSummaryExpanded() {
        summaryExpanded = !summaryExpanded
        summaryBodyText.maxLines = if (summaryExpanded) 18 else 4
        summaryMoreBtn.text = if (summaryExpanded) "Less ▴" else "More ▾"
    }

    fun selectIndex(index: Int, smooth: Boolean = true) {
        if (currentItems.isEmpty()) return
        currentIndex = index.coerceIn(0, currentItems.lastIndex)
        snapToIndex(currentIndex, smooth)
        updateFooterIndicators()
    }

    fun updateResults(
        config: AgyHudDynamicModels.TaskMapConfig,
        theme: AgyHudDynamicModels.ResolvedHudTheme
    ) {
        currentConfig = config
        currentTheme = theme
        val data = config.results ?: AgyHudDynamicModels.ResultsTaskMapData(
            query = config.title,
            summaryTitle = config.title.ifBlank { "Results" },
            summaryText = "No results payload provided."
        )
        val sig = data.contentSignature()
        val dataChanged = sig != lastSignature
        lastSignature = sig

        val d = density
        if (carouselPageWidthPx <= 0) {
            carouselPageWidthPx = ((config.widthDp - 18f).coerceAtLeast(130f) * d).toInt()
        }

        // Style & populate Summary Card
        summaryCard.background = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = 12f * d
            setColor(theme.secondarySurface)
            setStroke((0.8f * d).toInt().coerceAtLeast(1), theme.border)
        }

        val queryLabel = data.query.ifBlank { config.title }.ifBlank { "Results" }
        queryChipText.apply {
            text = "🔍 $queryLabel"
            setTextColor(theme.accent)
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = 999f * d
                setColor(Color.argb(26, Color.red(theme.accent), Color.green(theme.accent), Color.blue(theme.accent)))
            }
        }

        val src = data.sourceLabel.ifBlank {
            if (data.items.isNotEmpty()) "${data.items.size} media" else ""
        }
        sourceLabelText.apply {
            if (src.isNotBlank()) {
                visibility = View.VISIBLE
                text = src
                setTextColor(theme.textSecondary)
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = 999f * d
                    setColor(theme.surface)
                    setStroke((0.6f * d).toInt().coerceAtLeast(1), theme.border)
                }
            } else {
                visibility = View.GONE
            }
        }

        val titleVal = data.summaryTitle.ifBlank { queryLabel }
        summaryTitleText.apply {
            text = titleVal
            setTextColor(theme.textPrimary)
            visibility = if (titleVal.isNotBlank()) View.VISIBLE else View.GONE
        }

        summaryBodyText.apply {
            text = data.summaryText
            setTextColor(theme.textSecondary)
            visibility = if (data.summaryText.isNotBlank()) View.VISIBLE else View.GONE
            maxLines = if (summaryExpanded) 18 else 4
        }

        val needsMoreToggle = data.summaryText.length > 130 || data.summaryText.count { it == '\n' } >= 3
        summaryMoreBtn.apply {
            visibility = if (needsMoreToggle) View.VISIBLE else View.GONE
            text = if (summaryExpanded) "Less ▴" else "More ▾"
            setTextColor(theme.accent)
        }

        loadingRow.visibility = if (data.loading && data.items.isEmpty()) View.VISIBLE else View.GONE
        loadingLabel.setTextColor(theme.textSecondary)

        // Rebuild carousel if items changed or theme/width updated
        currentItems = data.items
        if (currentItems.isEmpty()) {
            carouselSection.visibility = View.GONE
            carouselTrack.removeAllViews()
            cardWrappers.clear()
            currentIndex = 0
            return
        }

        carouselSection.visibility = View.VISIBLE
        if (dataChanged) {
            if (currentIndex > currentItems.lastIndex) {
                currentIndex = 0
            }
            rebuildCarouselCards(theme)
        } else {
            updateCarouselCardWidths()
        }
        updateFooterIndicators()
        mainHandler.post { snapToIndex(currentIndex, smooth = false) }
    }

    private fun resolvePageWidthPx(): Int {
        val measuredW = carouselPager.width
        if (measuredW > 0) return measuredW
        if (carouselPageWidthPx > 0) return carouselPageWidthPx
        val d = density
        return ((currentConfig.widthDp - 18f).coerceAtLeast(140f) * d).toInt()
    }

    private fun rebuildCarouselCards(theme: AgyHudDynamicModels.ResolvedHudTheme) {
        val d = density
        val pageW = resolvePageWidthPx()
        carouselTrack.removeAllViews()
        cardWrappers.clear()

        currentItems.forEachIndexed { idx, item ->
            val card = LinearLayout(context).apply {
                orientation = VERTICAL
                setPadding((7 * d).toInt(), (7 * d).toInt(), (7 * d).toInt(), (8 * d).toInt())
                layoutParams = LayoutParams(pageW, ViewGroup.LayoutParams.WRAP_CONTENT)
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = 12f * d
                    setColor(theme.secondarySurface)
                    setStroke((0.9f * d).toInt().coerceAtLeast(1), theme.border)
                }
                tag = "${AgyHudOverlayManager.HUD_NODE_TAG_PREFIX}result_card_$idx"
                contentDescription = "${AgyHudOverlayManager.HUD_NODE_TAG_PREFIX}result_card_$idx"
                setOnClickListener {
                    onItemClicked?.invoke(currentItems, idx)
                }
            }

            // Preview frame
            val previewFrame = FrameLayout(context).apply {
                layoutParams = LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (116 * d).toInt())
                    .apply { bottomMargin = (6 * d).toInt() }
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = 9f * d
                    setColor(if (theme.isDark) Color.parseColor("#FF020617") else Color.parseColor("#FFE2E8F0"))
                }
                clipChildren = true
                clipToPadding = true
            }

            val imgView = ImageView(context).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                layoutParams = FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
            }
            previewFrame.addView(imgView)

            val fileExcerptTv = TextView(context).apply {
                textSize = 9.5f
                typeface = Typeface.MONOSPACE
                setTextColor(theme.textPrimary)
                setPadding((8 * d).toInt(), (24 * d).toInt(), (8 * d).toInt(), (8 * d).toInt())
                maxLines = 4
                ellipsize = TextUtils.TruncateAt.END
                layoutParams = FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
                visibility = View.GONE
            }
            previewFrame.addView(fileExcerptTv)

            val fallbackCenterTv = TextView(context).apply {
                textSize = 18f
                gravity = Gravity.CENTER
                setTextColor(theme.textSecondary)
                layoutParams = FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
                visibility = View.GONE
            }
            previewFrame.addView(fallbackCenterTv)

            if (item.kind == "video") {
                val playPill = TextView(context).apply {
                    text = "▶"
                    textSize = 15f
                    setTextColor(Color.WHITE)
                    gravity = Gravity.CENTER
                    val sz = (36 * d).toInt()
                    layoutParams = FrameLayout.LayoutParams(sz, sz, Gravity.CENTER)
                    background = GradientDrawable().apply {
                        shape = GradientDrawable.OVAL
                        setColor(Color.parseColor("#AA0F172A"))
                        setStroke((1.5f * d).toInt().coerceAtLeast(1), Color.WHITE)
                    }
                }
                previewFrame.addView(playPill)
            }

            val badgeColor = when (item.kind) {
                "video" -> Color.parseColor("#FFE11D48")
                "file" -> Color.parseColor("#FFD97706")
                else -> theme.accent
            }
            val kindChip = TextView(context).apply {
                text = AgyResultsMediaLoader.fileExtensionBadge(item)
                textSize = 8.5f
                setTypeface(Typeface.MONOSPACE, Typeface.BOLD)
                setTextColor(Color.WHITE)
                setPadding((5 * d).toInt(), (2 * d).toInt(), (5 * d).toInt(), (2 * d).toInt())
                layoutParams = FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    Gravity.TOP or Gravity.START
                ).apply {
                    leftMargin = (6 * d).toInt()
                    topMargin = (6 * d).toInt()
                }
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = 5f * d
                    setColor(badgeColor)
                }
            }
            previewFrame.addView(kindChip)

            val expandHint = TextView(context).apply {
                text = "⤢"
                textSize = 10f
                setTextColor(Color.WHITE)
                gravity = Gravity.CENTER
                val sz = (20 * d).toInt()
                layoutParams = FrameLayout.LayoutParams(sz, sz, Gravity.TOP or Gravity.END).apply {
                    rightMargin = (6 * d).toInt()
                    topMargin = (6 * d).toInt()
                }
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = 6f * d
                    setColor(Color.parseColor("#880F172A"))
                }
            }
            previewFrame.addView(expandHint)

            // Populate preview asynchronously
            when (item.kind) {
                "image", "video" -> {
                    fallbackCenterTv.apply {
                        text = if (item.kind == "video") "" else "🖼"
                        visibility = if (item.kind == "video") View.GONE else View.VISIBLE
                    }
                    AgyResultsMediaLoader.loadPreviewBitmap(context, item, maxDimensionPx = 480) { bmp ->
                        if (bmp != null) {
                            imgView.setImageBitmap(bmp)
                            fallbackCenterTv.visibility = View.GONE
                        }
                    }
                }
                else -> {
                    imgView.visibility = View.GONE
                    fileExcerptTv.visibility = View.VISIBLE
                    fileExcerptTv.text = item.previewText.ifBlank {
                        item.uri.ifBlank { "Tap to preview file" }
                    }
                    if (item.previewText.isBlank() && item.uri.isNotBlank()) {
                        AgyResultsMediaLoader.readFileSnippet(context, item) { snippet ->
                            if (snippet.isNotBlank()) {
                                fileExcerptTv.text = snippet.take(180)
                            }
                        }
                    }
                }
            }

            card.addView(previewFrame)

            // Title & Subtitle below preview
            val cardTitle = TextView(context).apply {
                text = item.title
                textSize = 11f
                setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
                setTextColor(theme.textPrimary)
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
            }
            card.addView(cardTitle)

            val subLabel = buildString {
                if (item.subtitle.isNotBlank()) append(item.subtitle)
                if (item.fileSizeLabel.isNotBlank()) {
                    if (isNotEmpty()) append(" • ")
                    append(item.fileSizeLabel)
                }
            }
            if (subLabel.isNotBlank()) {
                val cardSub = TextView(context).apply {
                    text = subLabel
                    textSize = 9.5f
                    setTextColor(theme.textSecondary)
                    maxLines = 1
                    ellipsize = TextUtils.TruncateAt.END
                    layoutParams = LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                        .apply { topMargin = (1 * d).toInt() }
                }
                card.addView(cardSub)
            }

            carouselTrack.addView(card)
            cardWrappers.add(card)
        }
    }

    private fun updateCarouselCardWidths() {
        val pageW = resolvePageWidthPx()
        if (pageW <= 0) return
        cardWrappers.forEach { child ->
            val lp = child.layoutParams ?: LayoutParams(pageW, ViewGroup.LayoutParams.WRAP_CONTENT)
            if (lp.width != pageW) {
                lp.width = pageW
                child.layoutParams = lp
            }
        }
    }

    private fun snapToIndex(index: Int, smooth: Boolean) {
        val pageW = resolvePageWidthPx()
        if (pageW <= 0) return
        val targetX = index.coerceIn(0, (currentItems.size - 1).coerceAtLeast(0)) * pageW
        if (smooth) {
            carouselPager.smoothScrollTo(targetX, 0)
        } else {
            carouselPager.scrollTo(targetX, 0)
        }
    }

    private fun updateFooterIndicators() {
        val d = density
        val count = currentItems.size
        val multi = count > 1
        footerNavRow.visibility = if (multi) View.VISIBLE else View.GONE
        if (!multi) return

        fun styleArrow(tv: TextView, enabled: Boolean) {
            tv.isEnabled = enabled
            tv.alpha = if (enabled) 1f else 0.35f
            tv.setTextColor(currentTheme.textPrimary)
            tv.background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = 999f * d
                setColor(currentTheme.secondarySurface)
                setStroke((0.7f * d).toInt().coerceAtLeast(1), currentTheme.border)
            }
        }
        styleArrow(prevArrowBtn, currentIndex > 0)
        styleArrow(nextArrowBtn, currentIndex < count - 1)

        counterBadgeText.apply {
            text = "${currentIndex + 1}/$count"
            setTextColor(currentTheme.textSecondary)
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = 999f * d
                setColor(currentTheme.secondarySurface)
            }
        }

        dotsContainer.removeAllViews()
        val maxDots = count.coerceAtMost(8)
        val dotWindowStart = if (count <= maxDots) 0 else (currentIndex - maxDots / 2).coerceIn(0, count - maxDots)
        for (i in dotWindowStart until (dotWindowStart + maxDots)) {
            val selected = i == currentIndex
            val dot = View(context).apply {
                val w = ((if (selected) 14f else 5f) * d).toInt()
                val h = (5f * d).toInt()
                layoutParams = LayoutParams(w, h).apply {
                    marginStart = (2 * d).toInt()
                    marginEnd = (2 * d).toInt()
                }
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = 999f * d
                    setColor(if (selected) currentTheme.accent else currentTheme.border)
                }
                setOnClickListener { selectIndex(i, smooth = true) }
            }
            dotsContainer.addView(dot)
        }
    }
}
