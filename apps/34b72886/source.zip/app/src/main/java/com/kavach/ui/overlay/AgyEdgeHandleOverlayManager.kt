package com.kavach.ui.overlay

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.util.Log
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.math.abs

/**
 * Slim translucent vertical screen-edge summon handle (`agy_hud_edge`) shown when the main
 * Agy HUD is parked to the screen edge.
 *
 * - Visual tab: ~6dp × 68dp glowing pill hugging the screen edge.
 * - Hit target: full 48dp touch strip so grabbing or swiping inward is effortless.
 * - Supports vertical drag repositioning, inward swipe or tap to open quick summon fan
 *   (`✦ Ask`, `🎤 Voice`, `✂ Snip`, `⤢ Expand`, plus `■ Stop` when Agy is running).
 */
class AgyEdgeHandleOverlayManager(
    private val context: Context
) {
    companion object {
        private const val TAG = "AgyEdgeHandleOverlay"
        const val NODE_TAG = "${AgyHudOverlayManager.HUD_NODE_TAG_PREFIX}edge"
    }

    enum class EdgeSide { RIGHT, LEFT }

    data class Callbacks(
        val onAsk: () -> Unit = {},
        val onVoice: () -> Unit = {},
        val onSnip: () -> Unit = {},
        val onExpand: () -> Unit = {},
        val onStop: () -> Unit = {}
    )

    private val mainHandler = Handler(Looper.getMainLooper())
    private val windowManager: WindowManager? by lazy {
        context.getSystemService(Context.WINDOW_SERVICE) as? WindowManager
    }

    private val _isVisibleFlow = MutableStateFlow(false)
    val isVisibleFlow: StateFlow<Boolean> = _isVisibleFlow.asStateFlow()

    private val _isFanOpenFlow = MutableStateFlow(false)
    val isFanOpenFlow: StateFlow<Boolean> = _isFanOpenFlow.asStateFlow()

    @Volatile
    private var edgeSide: EdgeSide = EdgeSide.RIGHT

    @Volatile
    private var isAgentActive: Boolean = false

    @Volatile
    private var anchorYOffsetPx: Int = -1

    @Volatile
    private var callbacks: Callbacks = Callbacks()

    private var rootContainer: LinearLayout? = null
    private var fanContainer: LinearLayout? = null
    private var stopButtonView: TextView? = null
    private var tabIndicatorView: View? = null
    private var windowParams: WindowManager.LayoutParams? = null

    private fun hasOverlayPermission(): Boolean {
        return Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(context)
    }

    private fun runOnMain(block: () -> Unit) {
        if (Looper.myLooper() == Looper.getMainLooper()) block() else mainHandler.post(block)
    }

    fun setCallbacks(cb: Callbacks) {
        callbacks = cb
    }

    fun updateAgentActive(active: Boolean) {
        isAgentActive = active
        runOnMain { refreshVisuals() }
    }

    fun show(
        side: EdgeSide = edgeSide,
        agentActive: Boolean = isAgentActive,
        openFanImmediately: Boolean = false
    ): Boolean {
        edgeSide = side
        isAgentActive = agentActive
        _isVisibleFlow.value = true
        _isFanOpenFlow.value = openFanImmediately

        if (!hasOverlayPermission()) {
            return false
        }

        runOnMain {
            attachOrUpdateWindow()
            refreshVisuals()
        }
        return true
    }

    fun setFanOpen(open: Boolean) {
        _isFanOpenFlow.value = open
        runOnMain { refreshVisuals() }
    }

    fun hide() {
        _isVisibleFlow.value = false
        _isFanOpenFlow.value = false
        runOnMain {
            rootContainer?.let { view ->
                try {
                    windowManager?.removeView(view)
                } catch (_: Exception) {}
            }
            rootContainer = null
            fanContainer = null
            stopButtonView = null
            tabIndicatorView = null
            windowParams = null
        }
    }

    private fun attachOrUpdateWindow() {
        val d = context.resources.displayMetrics.density.coerceAtLeast(1f)
        val screenH = context.resources.displayMetrics.heightPixels.coerceAtLeast(640)
        if (anchorYOffsetPx < 0) {
            anchorYOffsetPx = (screenH * 0.36f).toInt()
        }

        if (rootContainer != null && windowParams != null) {
            val lp = windowParams!!
            lp.gravity = Gravity.TOP or if (edgeSide == EdgeSide.RIGHT) Gravity.END else Gravity.START
            lp.y = anchorYOffsetPx.coerceIn((64 * d).toInt(), (screenH - 220 * d).toInt().coerceAtLeast((64 * d).toInt()))
            try {
                windowManager?.updateViewLayout(rootContainer, lp)
            } catch (_: Exception) {}
            return
        }

        val root = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            contentDescription = NODE_TAG
        }

        // Quick-Summon Action Fan (opens inward from the edge tab)
        val fan = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding((8 * d).toInt(), (8 * d).toInt(), (8 * d).toInt(), (8 * d).toInt())
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = 18f * d
                setColor(Color.parseColor("#F5FFFFFF"))
                setStroke((1f * d).toInt().coerceAtLeast(1), Color.parseColor("#DDE4EE"))
            }
            elevation = 12f * d
            visibility = View.GONE
            contentDescription = "${NODE_TAG}_fan"
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                marginStart = (4 * d).toInt()
                marginEnd = (4 * d).toInt()
            }
        }

        fun fanActionBtn(
            label: String,
            desc: String,
            fillColor: Int,
            textColor: Int,
            onClick: () -> Unit
        ): TextView {
            return TextView(context).apply {
                text = label
                textSize = 12f
                setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
                setTextColor(textColor)
                gravity = Gravity.CENTER
                minWidth = (92 * d).toInt()
                minHeight = (44 * d).toInt()
                setPadding((12 * d).toInt(), (8 * d).toInt(), (12 * d).toInt(), (8 * d).toInt())
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = 999f * d
                    setColor(fillColor)
                    if (fillColor == Color.parseColor("#F3F6FA")) {
                        setStroke((0.8f * d).toInt().coerceAtLeast(1), Color.parseColor("#E2E8F0"))
                    }
                }
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply {
                    topMargin = (3 * d).toInt()
                    bottomMargin = (3 * d).toInt()
                }
                contentDescription = "${NODE_TAG}_$desc"
                setOnClickListener {
                    _isFanOpenFlow.value = false
                    refreshVisuals()
                    onClick()
                }
            }
        }

        fan.addView(fanActionBtn("✦ Ask", "ask_btn", Color.parseColor("#0095F6"), Color.WHITE) {
            callbacks.onAsk()
        })
        fan.addView(fanActionBtn("🎤 Voice", "voice_btn", Color.parseColor("#F3F6FA"), Color.parseColor("#0F172A")) {
            callbacks.onVoice()
        })
        fan.addView(fanActionBtn("✂ Snip", "snip_btn", Color.parseColor("#F3F6FA"), Color.parseColor("#0F172A")) {
            callbacks.onSnip()
        })
        fan.addView(fanActionBtn("⤢ Expand", "expand_btn", Color.parseColor("#F3F6FA"), Color.parseColor("#0F172A")) {
            callbacks.onExpand()
        })
        val stopBtn = fanActionBtn("■ Stop", "stop_btn", Color.parseColor("#E11D48"), Color.WHITE) {
            callbacks.onStop()
        }
        stopBtn.visibility = View.GONE
        stopButtonView = stopBtn
        fan.addView(stopBtn)
        fanContainer = fan

        // Generous 48dp × 84dp invisible touch wrapper containing the slim 7dp × 66dp visual handle
        val handleTouchBox = FrameLayout(context).apply {
            layoutParams = LinearLayout.LayoutParams((36 * d).toInt().coerceAtLeast((48 * d).toInt() - (12 * d).toInt()), (84 * d).toInt())
            minimumWidth = (48 * d).toInt()
            minimumHeight = (68 * d).toInt()
            contentDescription = "${NODE_TAG}_handle"
        }

        val tabPill = View(context).apply {
            layoutParams = FrameLayout.LayoutParams((7 * d).toInt().coerceAtLeast(6), (66 * d).toInt()).apply {
                gravity = Gravity.CENTER_VERTICAL or if (edgeSide == EdgeSide.RIGHT) Gravity.END else Gravity.START
                if (edgeSide == EdgeSide.RIGHT) marginEnd = (2 * d).toInt() else marginStart = (2 * d).toInt()
            }
            contentDescription = "${NODE_TAG}_pill"
        }
        tabIndicatorView = tabPill
        handleTouchBox.addView(tabPill)

        attachHandleTouchGestures(handleTouchBox, d, screenH)

        if (edgeSide == EdgeSide.RIGHT) {
            root.addView(fan)
            root.addView(handleTouchBox)
        } else {
            root.addView(handleTouchBox)
            root.addView(fan)
        }

        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or if (edgeSide == EdgeSide.RIGHT) Gravity.END else Gravity.START
            x = 0
            y = anchorYOffsetPx.coerceIn((64 * d).toInt(), (screenH - 180 * d).toInt().coerceAtLeast((64 * d).toInt()))
            title = NODE_TAG
        }

        try {
            windowManager?.addView(root, lp)
            rootContainer = root
            windowParams = lp
        } catch (e: Exception) {
            Log.w(TAG, "Failed adding edge handle overlay: ${e.message}")
        }
    }

    private fun attachHandleTouchGestures(handleView: View, d: Float, screenH: Int) {
        var downRawX = 0f
        var downRawY = 0f
        var startY = 0
        var draggingVertically = false
        val swipeThresholdPx = 22f * d
        val dragThresholdPx = 14f * d

        handleView.setOnTouchListener { _, event ->
            val lp = windowParams ?: return@setOnTouchListener false
            val root = rootContainer ?: return@setOnTouchListener false
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downRawX = event.rawX
                    downRawY = event.rawY
                    startY = lp.y
                    draggingVertically = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - downRawX
                    val dy = event.rawY - downRawY
                    if (!draggingVertically && abs(dy) > dragThresholdPx && abs(dy) > abs(dx)) {
                        draggingVertically = true
                    }
                    if (draggingVertically) {
                        val minY = (56 * d).toInt()
                        val maxY = (screenH - 160 * d).toInt().coerceAtLeast(minY)
                        lp.y = (startY + dy.toInt()).coerceIn(minY, maxY)
                        anchorYOffsetPx = lp.y
                        try {
                            windowManager?.updateViewLayout(root, lp)
                        } catch (_: Exception) {}
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    val dx = event.rawX - downRawX
                    val dy = event.rawY - downRawY
                    if (!draggingVertically) {
                        val swipedInward = if (edgeSide == EdgeSide.RIGHT) dx < -swipeThresholdPx else dx > swipeThresholdPx
                        val isTap = abs(dx) < dragThresholdPx && abs(dy) < dragThresholdPx
                        if (swipedInward) {
                            _isFanOpenFlow.value = true
                            refreshVisuals()
                        } else if (isTap) {
                            _isFanOpenFlow.value = !_isFanOpenFlow.value
                            refreshVisuals()
                        }
                    }
                    true
                }
                else -> false
            }
        }
    }

    private fun refreshVisuals() {
        val d = context.resources.displayMetrics.density.coerceAtLeast(1f)
        val fanOpen = _isFanOpenFlow.value
        fanContainer?.visibility = if (fanOpen) View.VISIBLE else View.GONE
        stopButtonView?.visibility = if (isAgentActive) View.VISIBLE else View.GONE

        val pillFill = when {
            isAgentActive -> Color.parseColor("#E60095F6")
            fanOpen -> Color.parseColor("#E64F46E5")
            else -> Color.parseColor("#CC0F172A")
        }
        val pillStroke = if (isAgentActive) Color.parseColor("#AA38BDF8") else Color.parseColor("#66FFFFFF")
        tabIndicatorView?.background = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = 999f * d
            setColor(pillFill)
            setStroke((1f * d).toInt().coerceAtLeast(1), pillStroke)
        }
    }
}
