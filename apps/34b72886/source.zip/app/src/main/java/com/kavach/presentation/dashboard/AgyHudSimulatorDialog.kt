package com.kavach.presentation.dashboard

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Rect
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowUpward
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.KeyboardArrowUp
import androidx.compose.material.icons.rounded.Layers
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.OpenWith
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material.icons.rounded.TouchApp
import androidx.core.content.ContextCompat
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.Shader
import androidx.compose.ui.graphics.ShaderBrush
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.LayoutCoordinates
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.kavach.accessibility.AccessibilityRepositoryImpl
import com.kavach.ui.overlay.AgyAppIconResolver
import com.kavach.ui.overlay.AgyHudOverlayManager
import com.kavach.ui.overlay.AgyVoiceInputController
import com.kavach.ui.theme.CrispAmber
import com.kavach.ui.theme.CrispBg
import com.kavach.ui.theme.CrispBlue
import com.kavach.ui.theme.CrispBorder
import com.kavach.ui.theme.CrispEmerald
import com.kavach.ui.theme.CrispHairline
import com.kavach.ui.theme.CrispIndigo
import com.kavach.ui.theme.CrispInkMuted
import com.kavach.ui.theme.CrispInkPrimary
import com.kavach.ui.theme.CrispInkSecondary
import com.kavach.ui.theme.CrispRose
import com.kavach.ui.theme.CrispSurface
import com.kavach.ui.theme.CrispSurfaceSubtle
import com.kavach.ui.theme.JetBrainsMonoFamily
import com.kavach.ui.theme.LiquidIconOrb
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

/**
 * Full Interactive Agy HUD Test Mode Simulator.
 * Drives the real AgyHudOverlayManager (floating overlay + /api/hud endpoints & command queue)
 * while mirroring live Window 2 (Task + Low-Poly Wireframe / Collapsed Pill) & Window 1 (Prompt)
 * inside a clean Crisp Light Mode sandbox so every feature can be tested without Termux running.
 */
@Composable
fun AgyHudSimulatorDialog(
    hudManager: AgyHudOverlayManager,
    onDismissRequest: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val hudState by hudManager.hudState.collectAsState()
    val isHudVisible by hudManager.isHudVisible.collectAsState()
    val isInputVisible by hudManager.isInputVisible.collectAsState()
    val isCollapsed by hudManager.isCollapsedFlow.collectAsState()
    val isOutputExpanded by hudManager.isOutputExpandedFlow.collectAsState()
    val elapsedMs by hudManager.elapsedMsFlow.collectAsState()
    val opacity by hudManager.opacityFlow.collectAsState()
    val ghostPassThrough by hudManager.ghostPassThroughFlow.collectAsState()
    val wireframeEnabled by hudManager.wireframeEnabledFlow.collectAsState()
    val edgeSnapEnabled by hudManager.edgeSnapEnabledFlow.collectAsState()
    val pointerEnabled by hudManager.pointerEnabledFlow.collectAsState()
    val pinnedMacros by hudManager.pinnedMacrosFlow.collectAsState()

    var isAutoPlaying by remember { mutableStateOf(false) }
    var activeFlowStep by remember { mutableStateOf("Ready to simulate Agy lifecycle") }
    var autoPlayJob by remember { mutableStateOf<Job?>(null) }
    var simulatedTurnJob by remember { mutableStateOf<Job?>(null) }
    var sandboxPrompt by remember { mutableStateOf("") }
    var isVoiceListening by remember { mutableStateOf(false) }
    var hasOverlayPerm by remember { mutableStateOf(hudManager.hasOverlayPermission()) }
    var dockOffsetX by remember { mutableFloatStateOf(0f) }
    var dockOffsetY by remember { mutableFloatStateOf(0f) }
    var isDraggingDock by remember { mutableStateOf(false) }
    var showDiagnostics by remember { mutableStateOf(false) }
    val haptic = LocalHapticFeedback.current

    val echoLogs = remember { mutableStateListOf<String>() }
    val timeFmt = remember { SimpleDateFormat("HH:mm:ss", Locale.US) }

    fun addLog(msg: String) {
        val ts = timeFmt.format(Date())
        echoLogs.add(0, "[$ts] $msg")
        if (echoLogs.size > 30) echoLogs.removeAt(echoLogs.lastIndex)
    }

    val voiceController = remember(context) {
        AgyVoiceInputController(
            context = context.applicationContext,
            onListeningChanged = { isVoiceListening = it },
            onPartialText = { partial -> if (partial.isNotBlank()) sandboxPrompt = partial },
            onFinalText = { finalTxt -> if (finalTxt.isNotBlank()) sandboxPrompt = finalTxt },
            onErrorMessage = { err -> addLog("VOICE -> $err") }
        )
    }
    val micPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            voiceController.startListening()
        } else {
            addLog("VOICE -> Microphone permission denied")
        }
    }

    fun pushStatePayload(label: String, json: JSONObject) {
        hasOverlayPerm = hudManager.hasOverlayPermission()
        val res = hudManager.updateState(json)
        activeFlowStep = label
        val overlayTag = if (res.optBoolean("overlayRendered")) "real HUD + sandbox" else "sandbox preview"
        addLog("STATE -> ${json.optString("state")} ($overlayTag)")
    }

    fun runSimulatedPromptTurn(promptText: String) {
        simulatedTurnJob?.cancel()
        simulatedTurnJob = scope.launch {
            pushStatePayload(
                "Simulating prompt: $promptText",
                buildWorkingPayload(promptText)
            )
            delay(1600L)
            pushStatePayload(
                "Screen Watch: Inspecting UI & targeting button",
                buildTapWatchPayload(promptText)
            )
            delay(1900L)
            pushStatePayload(
                "Task Complete — auto-collapsing in 4s",
                buildDonePayload("Finished: ${promptText.take(36)}")
            )
        }
    }

    // Live command echo loop: drains real HUD_COMMAND items submitted via Window 1 or Simulator bar
    LaunchedEffect(hudManager) {
        addLog("Simulator ready. Tap 'Play Full Flow' or type a prompt below.")
        while (isActive) {
            val pollRes = hudManager.pollCommands()
            val count = pollRes.optInt("count", 0)
            if (count > 0) {
                val arr = pollRes.optJSONArray("commands") ?: JSONArray()
                for (i in 0 until arr.length()) {
                    val cmd = arr.optJSONObject(i) ?: continue
                    val action = cmd.optString("action", "PROMPT")
                    val text = cmd.optString("text", "")
                    addLog("HUD_COMMAND [$action]: \"$text\"")
                    if (action == "STOP") {
                        autoPlayJob?.cancel()
                        simulatedTurnJob?.cancel()
                        isAutoPlaying = false
                        pushStatePayload("Stopped by user", buildIdlePayload("Stopped by user"))
                    } else if (action == "PAUSE") {
                        autoPlayJob?.cancel()
                        simulatedTurnJob?.cancel()
                        isAutoPlaying = false
                        activeFlowStep = "Paused — tap Resume to continue"
                    } else if (action == "RESUME") {
                        activeFlowStep = "Resumed task"
                    } else if (text.isNotBlank()) {
                        autoPlayJob?.cancel()
                        isAutoPlaying = false
                        runSimulatedPromptTurn(text)
                    }
                }
            }
            delay(300L)
        }
    }

    val isImeVisible = WindowInsets.ime.getBottom(LocalDensity.current) > 0

    // Suppress the real system floating overlay while the in-app Simulator is open so two HUDs never stack on top of each other
    DisposableEffect(Unit) {
        hudManager.setTemporarilySuppressed(true)
        onDispose {
            autoPlayJob?.cancel()
            simulatedTurnJob?.cancel()
            voiceController.release()
            hudManager.setTemporarilySuppressed(false)
        }
    }

    Dialog(
        onDismissRequest = onDismissRequest,
        properties = DialogProperties(
            usePlatformDefaultWidth = false,
            decorFitsSystemWindows = false
        )
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .fillMaxSize()
                .imePadding()
                .padding(horizontal = 10.dp, vertical = 12.dp)
        ) {
            Surface(
                color = CrispSurface,
                shape = RoundedCornerShape(28.dp),
                border = BorderStroke(1.dp, CrispHairline),
                shadowElevation = 6.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 780.dp)
                    .testTag("agy_hud_simulator_dialog")
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                        .verticalScroll(rememberScrollState(), enabled = !isDraggingDock),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        LiquidIconOrb(
                            icon = Icons.Rounded.AutoAwesome,
                            tint = CrispBlue,
                            size = 38.dp,
                            iconSize = 20.dp
                        )
                        Column {
                            Text(
                                text = "Agy HUD Simulator",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = CrispInkPrimary
                            )
                            Text(
                                text = activeFlowStep,
                                style = MaterialTheme.typography.labelSmall,
                                color = CrispInkSecondary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                    IconButton(
                        onClick = onDismissRequest,
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(CrispSurfaceSubtle)
                            .testTag("close_hud_simulator_button")
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Close,
                            contentDescription = "Close Simulator",
                            tint = CrispInkSecondary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                // Real Overlay Permission Banner
                if (!hasOverlayPerm) {
                    Surface(
                        color = CrispAmber.copy(alpha = 0.08f),
                        shape = RoundedCornerShape(16.dp),
                        border = BorderStroke(1.dp, CrispAmber.copy(alpha = 0.25f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Sandbox live. Grant overlay permission to float over Termux.",
                                style = MaterialTheme.typography.labelSmall,
                                color = CrispAmber,
                                modifier = Modifier.weight(1f)
                            )
                            Spacer(Modifier.width(8.dp))
                            Surface(
                                color = CrispAmber,
                                shape = RoundedCornerShape(50),
                                modifier = Modifier
                                    .clip(RoundedCornerShape(50))
                                    .clickable {
                                        hudManager.getOverlayPermissionIntent()?.let { intent ->
                                            try {
                                                context.startActivity(intent)
                                            } catch (_: Exception) {}
                                        }
                                    }
                            ) {
                                Text(
                                    text = "Grant",
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                    color = Color.White,
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp)
                                )
                            }
                        }
                    }
                }

                // 1. Calm Minimalist Interactive Hold-to-Drag Stage
                Surface(
                    color = Color(0xFFF6F7F9),
                    shape = RoundedCornerShape(22.dp),
                    border = BorderStroke(0.85.dp, Color(0xFFE8ECF1)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("simulator_live_preview_box")
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.OpenWith,
                                    contentDescription = null,
                                    tint = if (isDraggingDock) CrispBlue else CrispInkMuted,
                                    modifier = Modifier.size(13.dp)
                                )
                                Text(
                                    text = if (isDraggingDock) "Moving dock…" else "Hold HUD to drag",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontWeight = FontWeight.Medium,
                                        fontSize = 11.sp
                                    ),
                                    color = if (isDraggingDock) CrispBlue else CrispInkSecondary
                                )
                            }
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                if (dockOffsetX != 0f || dockOffsetY != 0f) {
                                    Text(
                                        text = "Reset",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontWeight = FontWeight.SemiBold,
                                            fontSize = 10.5.sp
                                        ),
                                        color = CrispBlue,
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(50))
                                            .background(CrispBlue.copy(alpha = 0.09f))
                                            .clickable {
                                                dockOffsetX = 0f
                                                dockOffsetY = 0f
                                            }
                                            .padding(horizontal = 9.dp, vertical = 3.dp)
                                            .testTag("simulator_reset_pos_button")
                                    )
                                }
                                Text(
                                    text = if (ghostPassThrough) "Ghost" else if (isHudVisible) "Live overlay" else "Preview",
                                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.5.sp),
                                    color = CrispInkMuted
                                )
                            }
                        }

                        // Spacious clean alabaster stage simulating Android viewport (compacts cleanly when keyboard opens)
                        BoxWithConstraints(
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(min = if (isImeVisible) 184.dp else 284.dp)
                                .clip(RoundedCornerShape(18.dp))
                                .background(Color(0xFFEDF0F4))
                        ) {
                            val density = LocalDensity.current
                            val holdSlopPx = with(density) { 16.dp.toPx() }
                            var stageSize by remember { mutableStateOf(IntSize.Zero) }
                            var dockSize by remember { mutableStateOf(IntSize.Zero) }
                            var dockCoords by remember { mutableStateOf<LayoutCoordinates?>(null) }
                            val dragScale by animateFloatAsState(
                                targetValue = if (isDraggingDock) 1.03f else 1f,
                                animationSpec = tween(durationMillis = 120),
                                label = "dock_drag_scale"
                            )

                            // Whisper-subtle micro-dot canvas so drag motion feels crisp
                            Canvas(
                                modifier = Modifier
                                    .matchParentSize()
                                    .onSizeChanged { stageSize = it }
                            ) {
                                val step = 22.dp.toPx()
                                val dotColor = Color(0xFFCBD5E1).copy(alpha = 0.45f)
                                var y = step * 0.6f
                                while (y < size.height) {
                                    var x = step * 0.6f
                                    while (x < size.width) {
                                        drawCircle(color = dotColor, radius = 1.dp.toPx(), center = Offset(x, y))
                                        x += step
                                    }
                                    y += step
                                }
                            }

                            Box(
                                modifier = Modifier
                                    .align(Alignment.BottomEnd)
                                    .padding(10.dp)
                                    .offset { IntOffset(dockOffsetX.roundToInt(), dockOffsetY.roundToInt()) }
                                    .graphicsLayer {
                                        scaleX = dragScale
                                        scaleY = dragScale
                                    }
                                    .onGloballyPositioned { coords ->
                                        dockCoords = coords
                                        dockSize = coords.size
                                    }
                                    .pointerInput(holdSlopPx) {
                                        awaitEachGesture {
                                            // Wait for initial DOWN without consuming so quick taps hit child buttons
                                            var downChange = awaitPointerEvent(PointerEventPass.Initial)
                                                .changes
                                                .firstOrNull { it.pressed && !it.previousPressed }
                                                ?: return@awaitEachGesture
                                            val pointerId = downChange.id
                                            val downWinPos = dockCoords?.localToWindow(downChange.position) ?: downChange.position
                                            var holdActivated = false
                                            var cancelledEarly = false

                                            // 180ms press-and-hold window (matches HoldDraggableDockLayout)
                                            withTimeoutOrNull(180L) {
                                                while (true) {
                                                    val ev = awaitPointerEvent(PointerEventPass.Initial)
                                                    val ch = ev.changes.firstOrNull { it.id == pointerId } ?: break
                                                    if (!ch.pressed) {
                                                        cancelledEarly = true
                                                        break
                                                    }
                                                    val curWin = dockCoords?.localToWindow(ch.position) ?: ch.position
                                                    if ((curWin - downWinPos).getDistance() > holdSlopPx) {
                                                        cancelledEarly = true
                                                        break
                                                    }
                                                    downChange = ch
                                                }
                                            }

                                            if (!cancelledEarly && downChange.pressed) {
                                                holdActivated = true
                                                isDraggingDock = true
                                                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                                var lastWinPos = dockCoords?.localToWindow(downChange.position) ?: downWinPos
                                                try {
                                                    while (true) {
                                                        val ev = awaitPointerEvent(PointerEventPass.Initial)
                                                        val ch = ev.changes.firstOrNull { it.id == pointerId } ?: break
                                                        ch.consume()
                                                        if (!ch.pressed) break
                                                        val curWin = dockCoords?.localToWindow(ch.position) ?: lastWinPos
                                                        val delta = curWin - lastWinPos
                                                        lastWinPos = curWin
                                                        if (delta.x != 0f || delta.y != 0f) {
                                                            val padPx = (20f * density.density)
                                                            val maxLeft = (stageSize.width - dockSize.width - padPx).coerceAtLeast(0f)
                                                            val maxUp = (stageSize.height - dockSize.height - padPx).coerceAtLeast(0f)
                                                            dockOffsetX = (dockOffsetX + delta.x).coerceIn(-maxLeft, 0f)
                                                            dockOffsetY = (dockOffsetY + delta.y).coerceIn(-maxUp, 0f)
                                                        }
                                                    }
                                                } finally {
                                                    if (holdActivated) {
                                                        isDraggingDock = false
                                                        if (hudManager.edgeSnapEnabledFlow.value) {
                                                            val padPx = (20f * density.density)
                                                            val maxLeft = (stageSize.width - dockSize.width - padPx).coerceAtLeast(0f)
                                                            val targetX = if (dockOffsetX < -maxLeft / 2f) -maxLeft else 0f
                                                            val startX = dockOffsetX
                                                            scope.launch {
                                                                Animatable(startX).animateTo(
                                                                    targetValue = targetX,
                                                                    animationSpec = spring(
                                                                        dampingRatio = 0.74f,
                                                                        stiffness = 340f
                                                                    )
                                                                ) {
                                                                    dockOffsetX = value
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    .testTag("simulator_draggable_hud_dock")
                            ) {
                                // Single Unified Gemini-Style Floating HUD (Collapsed Pill <-> Expanded Card + Built-In Bottom Composer)
                                SandboxWindow2Preview(
                                    state = hudState,
                                    isCollapsed = isCollapsed,
                                    isInputVisible = isInputVisible,
                                    isOutputExpanded = isOutputExpanded,
                                    elapsedMs = elapsedMs,
                                    opacity = opacity,
                                    ghostPassThrough = ghostPassThrough,
                                    wireframeEnabled = wireframeEnabled,
                                    edgeSnapEnabled = edgeSnapEnabled,
                                    sandboxPrompt = sandboxPrompt,
                                    isVoiceListening = isVoiceListening,
                                    pinnedMacros = pinnedMacros,
                                    collapsedRunningStep = hudManager.resolveCollapsedRunningStep(hudState),
                                    quickActions = hudManager.resolveQuickActions(hudState),
                                    formatElapsed = { ms, done -> hudManager.formatElapsed(ms, done) },
                                    fullOutputText = hudManager.getFullOutputCopyText(hudState),
                                    onPromptChange = { sandboxPrompt = it },
                                    onSubmitPrompt = { text ->
                                        val txt = text.trim().ifEmpty { "Check Wi-Fi & open Termux" }
                                        hudManager.enqueueAndBroadcastCommand(txt, "PROMPT")
                                        sandboxPrompt = ""
                                    },
                                    onToggleVoice = {
                                        if (isVoiceListening) {
                                            voiceController.stopListening()
                                        } else {
                                            val granted = ContextCompat.checkSelfPermission(
                                                context,
                                                Manifest.permission.RECORD_AUDIO
                                            ) == PackageManager.PERMISSION_GRANTED
                                            if (granted) {
                                                voiceController.startListening()
                                            } else {
                                                micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                            }
                                        }
                                    },
                                    onRunMacro = { macro ->
                                        hudManager.enqueueAndBroadcastCommand(macro.prompt, "PROMPT")
                                        addLog("MACRO -> ${macro.title}")
                                    },
                                    onCycleOpacity = {
                                        hudManager.handleRemoteCommand(JSONObject().put("action", "CYCLE_OPACITY"))
                                        addLog("OPACITY -> ${(hudManager.opacityFlow.value * 100).toInt()}%")
                                    },
                                    onToggleWireframe = {
                                        hudManager.handleRemoteCommand(JSONObject().put("action", "TOGGLE_WIREFRAME"))
                                    },
                                    onToggleGhost = {
                                        hudManager.handleRemoteCommand(JSONObject().put("action", "TOGGLE_GHOST"))
                                        addLog("GHOST PASS-THROUGH -> ${!ghostPassThrough}")
                                    },
                                    onToggleEdgeSnap = {
                                        hudManager.handleRemoteCommand(JSONObject().put("action", "TOGGLE_EDGE_SNAP"))
                                        addLog("EDGE SNAP -> ${!edgeSnapEnabled}")
                                    },
                                    pointerEnabled = pointerEnabled,
                                    onTogglePointer = {
                                        hudManager.handleRemoteCommand(JSONObject().put("action", "TOGGLE_POINTER"))
                                        addLog("POINTER CURSOR -> ${!pointerEnabled}")
                                    },
                                    onOpenInput = {
                                        hudManager.handleRemoteCommand(JSONObject().put("action", "OPEN_INPUT"))
                                    },
                                    onToggleCollapse = {
                                        val nextAction = if (isCollapsed) "EXPAND" else "COLLAPSE"
                                        hudManager.handleRemoteCommand(JSONObject().put("action", nextAction))
                                    },
                                    onToggleOutput = {
                                        hudManager.setOutputExpanded(!isOutputExpanded)
                                        addLog("OUTPUT DRAWER -> ${if (!isOutputExpanded) "EXPANDED" else "COLLAPSED"}")
                                    },
                                    onCopyOutput = {
                                        val ok = hudManager.copyDetailedOutputToClipboard()
                                        addLog(if (ok) "CLIPBOARD -> Copied detailed output ✓" else "CLIPBOARD -> Nothing to copy")
                                        ok
                                    },
                                    onQuickAction = { chip ->
                                        hudManager.executeQuickAction(chip)
                                        addLog("QUICK ACTION -> ${chip.label} (${chip.actionType})")
                                    },
                                    onResume = {
                                        hudManager.handleRemoteCommand(JSONObject().put("action", "RESUME"))
                                        addLog("CMD -> RESUME")
                                    },
                                    onStop = {
                                        autoPlayJob?.cancel()
                                        simulatedTurnJob?.cancel()
                                        isAutoPlaying = false
                                        val prevState = hudState.state
                                        hudManager.handleRemoteCommand(JSONObject().put("action", "STOP"))
                                        activeFlowStep = if (prevState == "STOPPING") {
                                            "Force-stopped locally"
                                        } else {
                                            "Stopping… tap Stop again to force-stop"
                                        }
                                        addLog(if (prevState == "STOPPING") "CMD -> FORCE_STOP" else "CMD -> STOP (tap again to force-stop)")
                                    }
                                )
                            }
                        }
                    }
                }

                // 2. One-Tap Auto-Play Full Flow CTA
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = {
                            if (isAutoPlaying) {
                                autoPlayJob?.cancel()
                                isAutoPlaying = false
                                activeFlowStep = "Auto-play stopped"
                                addLog("DEMO stopped")
                            } else {
                                simulatedTurnJob?.cancel()
                                isAutoPlaying = true
                                autoPlayJob = scope.launch {
                                    try {
                                        pushStatePayload("Step 1/5: WORKING (Task Checklist)", buildWorkingPayload("Deploy Termux Script"))
                                        delay(2200L)
                                        pushStatePayload("Step 2/5: SCREEN WATCH (TAP Reticle)", buildTapWatchPayload("Deploy Termux Script"))
                                        delay(2600L)
                                        pushStatePayload("Step 3/5: SCREEN WATCH (SWIPE Vector)", buildSwipeWatchPayload("Deploy Termux Script"))
                                        delay(2600L)
                                        pushStatePayload("Step 4/5: NEEDS_INPUT (Auto-Opens Window 1)", buildNeedsInputPayload())
                                        delay(2600L)
                                        pushStatePayload("Step 5/5: DONE (Auto-Collapses in 4s)", buildDonePayload("All tasks verified & deployed"))
                                        delay(4300L)
                                        activeFlowStep = "Completed — Collapsed to bottom-right pill"
                                        addLog("Auto-collapsed to compact bottom-right pill")
                                    } finally {
                                        isAutoPlaying = false
                                    }
                                }
                            }
                        },
                        shape = RoundedCornerShape(50),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isAutoPlaying) CrispRose else CrispBlue,
                            contentColor = Color.White
                        ),
                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 10.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(44.dp)
                            .testTag("simulator_autoplay_button")
                    ) {
                        Icon(
                            imageVector = if (isAutoPlaying) Icons.Rounded.Stop else Icons.Rounded.PlayArrow,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(Modifier.width(6.dp))
                        Text(
                            text = if (isAutoPlaying) "Stop Demo" else "Play Full Flow",
                            style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold)
                        )
                    }

                    Surface(
                        color = CrispSurfaceSubtle,
                        shape = RoundedCornerShape(50),
                        border = BorderStroke(1.dp, CrispHairline),
                        modifier = Modifier
                            .height(44.dp)
                            .clip(RoundedCornerShape(50))
                            .clickable {
                                autoPlayJob?.cancel()
                                simulatedTurnJob?.cancel()
                                isAutoPlaying = false
                                hudManager.hideAll()
                                activeFlowStep = "HUD hidden cleanly"
                                addLog("POST /api/hud/hide -> dismissed both windows")
                            }
                            .testTag("simulator_hide_button")
                    ) {
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier.padding(horizontal = 16.dp)
                        ) {
                            Text(
                                text = "Hide",
                                style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.SemiBold),
                                color = CrispInkSecondary
                            )
                        }
                    }
                }

                // 3. Clean Single-Row State Switcher
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Preview states",
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold),
                        color = CrispInkSecondary
                    )
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        SimChip("Working", CrispBlue, "sim_trigger_working") {
                            pushStatePayload("Working · YouTube + Termux", buildWorkingPayload("Play Lo-Fi on YouTube"))
                        }
                        SimChip(
                            label = if (hudState.state == "PAUSED") "Resume" else "Pause",
                            tint = CrispAmber,
                            tag = "sim_trigger_pause"
                        ) {
                            if (hudState.state == "PAUSED") {
                                hudManager.handleRemoteCommand(JSONObject().put("action", "RESUME"))
                                activeFlowStep = "Resumed task"
                                addLog("CMD -> RESUME")
                            } else {
                                if (hudState.state != "WORKING") {
                                    pushStatePayload("Working · YouTube + Termux", buildWorkingPayload("Play Lo-Fi on YouTube"))
                                }
                                hudManager.handleRemoteCommand(JSONObject().put("action", "PAUSE"))
                                activeFlowStep = "Paused — timer frozen"
                                addLog("CMD -> PAUSE")
                            }
                        }
                        SimChip("Tap Watch", CrispBlue, "sim_trigger_tap") {
                            pushStatePayload("Screen Watch · YouTube tap", buildTapWatchPayload("Search & Play on YouTube"))
                        }
                        SimChip("Swipe Watch", CrispIndigo, "sim_trigger_swipe") {
                            pushStatePayload("Screen Watch · Chrome + WhatsApp", buildSwipeWatchPayload("Share Link to WhatsApp"))
                        }
                        SimChip("Needs Input", CrispAmber, "sim_trigger_input") {
                            pushStatePayload("Needs input · Quick reply", buildNeedsInputPayload())
                        }
                        SimChip("Done", CrispEmerald, "sim_trigger_done") {
                            pushStatePayload("Done · Output ready", buildDonePayload("YouTube stream live & summary copied"))
                        }
                        SimChip("Dynamic Dark", Color(0xFF8B5CF6), "sim_trigger_dynamic_dark") {
                            pushStatePayload("Dynamic Dark · Custom widgets & theme", buildDynamicDarkPayload())
                        }
                        SimChip("Patch +15%", CrispBlue, "sim_trigger_patch_progress") {
                            val nextVal = ((hudState.progress.value.takeIf { it >= 0f } ?: 35f) + 15f).coerceAtMost(100f)
                            val patchObj = JSONObject().apply {
                                put("setProgress", JSONObject().apply {
                                    put("visible", true)
                                    put("value", nextVal.toDouble())
                                    put("label", if (nextVal >= 100f) "Complete · 100%" else "${nextVal.toInt()}% synced")
                                })
                                put("upsertMetric", JSONObject().apply {
                                    put("id", "progress_live")
                                    put("label", "Sync")
                                    put("value", "${nextVal.toInt()}%")
                                    put("accentColor", "#38BDF8")
                                })
                                put("appendLog", "[patch] Progress updated to ${nextVal.toInt()}%")
                            }
                            hudManager.patchState(patchObj)
                            activeFlowStep = "Patched progress -> ${nextVal.toInt()}%"
                            addLog("POST /api/hud/patch -> progress=${nextVal.toInt()}%")
                        }
                        SimChip("Output", CrispInkPrimary, "sim_cmd_output") {
                            hudManager.setOutputExpanded(!isOutputExpanded)
                            addLog("CMD -> TOGGLE_OUTPUT (${!isOutputExpanded})")
                        }
                    }
                }

                // 4. Collapsible Diagnostics, Controls & Command Echo
                Surface(
                    color = Color(0xFFF6F7F9),
                    shape = RoundedCornerShape(18.dp),
                    border = BorderStroke(0.85.dp, Color(0xFFE8ECF1)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { showDiagnostics = !showDiagnostics }
                                .padding(horizontal = 14.dp, vertical = 11.dp)
                                .testTag("simulator_diagnostics_toggle"),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Text(
                                    text = "Diagnostics & Echo",
                                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold),
                                    color = CrispInkPrimary
                                )
                                if (echoLogs.isNotEmpty()) {
                                    Surface(
                                        color = Color.White,
                                        shape = RoundedCornerShape(50),
                                        border = BorderStroke(0.75.dp, CrispHairline)
                                    ) {
                                        Text(
                                            text = "${echoLogs.size}",
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                fontFamily = JetBrainsMonoFamily,
                                                fontSize = 10.sp
                                            ),
                                            color = CrispInkSecondary,
                                            modifier = Modifier.padding(horizontal = 7.dp, vertical = 1.dp)
                                        )
                                    }
                                }
                            }
                            Icon(
                                imageVector = if (showDiagnostics) Icons.Rounded.KeyboardArrowUp else Icons.Rounded.KeyboardArrowDown,
                                contentDescription = "Toggle Diagnostics",
                                tint = CrispInkSecondary,
                                modifier = Modifier.size(18.dp)
                            )
                        }

                        AnimatedVisibility(
                            visible = showDiagnostics,
                            enter = fadeIn() + expandVertically(),
                            exit = fadeOut() + shrinkVertically()
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(start = 12.dp, end = 12.dp, bottom = 12.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                HorizontalDivider(color = Color(0xFFE8ECF1), thickness = 0.75.dp)

                                // Remote Commands Row
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .horizontalScroll(rememberScrollState()),
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    SimChip("Expand", CrispInkPrimary, "sim_cmd_expand") {
                                        hudManager.handleRemoteCommand(JSONObject().put("action", "EXPAND"))
                                        addLog("CMD -> EXPAND")
                                    }
                                    SimChip("Collapse", CrispInkPrimary, "sim_cmd_collapse") {
                                        hudManager.handleRemoteCommand(JSONObject().put("action", "COLLAPSE"))
                                        addLog("CMD -> COLLAPSE")
                                    }
                                    SimChip("Open Input", CrispBlue, "sim_cmd_open_input") {
                                        hudManager.handleRemoteCommand(JSONObject().put("action", "OPEN_INPUT"))
                                        addLog("CMD -> OPEN_INPUT")
                                    }
                                    SimChip("Opacity ${(opacity * 100).toInt()}%", CrispInkPrimary, "sim_cmd_opacity") {
                                        hudManager.handleRemoteCommand(JSONObject().put("action", "CYCLE_OPACITY"))
                                        addLog("CMD -> CYCLE_OPACITY (${(hudManager.opacityFlow.value * 100).toInt()}%)")
                                    }
                                    SimChip(if (ghostPassThrough) "Un-Ghost" else "Ghost", CrispAmber, "sim_cmd_ghost") {
                                        hudManager.handleRemoteCommand(JSONObject().put("action", "TOGGLE_GHOST"))
                                        addLog("CMD -> TOGGLE_GHOST")
                                    }
                                    SimChip(if (edgeSnapEnabled) "Snap On" else "Snap Off", CrispBlue, "sim_cmd_snap") {
                                        hudManager.handleRemoteCommand(JSONObject().put("action", "TOGGLE_EDGE_SNAP"))
                                        addLog("CMD -> TOGGLE_EDGE_SNAP")
                                    }
                                }

                                // Safety Hooks Verification
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Surface(
                                        color = Color.White,
                                        shape = RoundedCornerShape(50),
                                        border = BorderStroke(0.85.dp, CrispHairline),
                                        modifier = Modifier
                                            .weight(1f)
                                            .clip(RoundedCornerShape(50))
                                            .clickable {
                                                val repo = AccessibilityRepositoryImpl()
                                                val hudExcluded = repo.isAgyHudIdentifier("com.kavach:id/agy_hud_window2", "agy_hud_root")
                                                val termuxKept = !repo.isAgyHudIdentifier("com.termux:id/terminal_view", "Terminal")
                                                val status = if (hudExcluded && termuxKept) "PASS" else "FAIL"
                                                addLog("SAFETY [$status] Self-Exclusion: agy_hud_ filtered, Termux visible")
                                            }
                                            .testTag("sim_test_self_exclusion")
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.Center
                                        ) {
                                            Icon(
                                                imageVector = Icons.Rounded.Shield,
                                                contentDescription = null,
                                                tint = CrispEmerald,
                                                modifier = Modifier.size(14.dp)
                                            )
                                            Spacer(Modifier.width(5.dp))
                                            Text(
                                                text = "Self-Exclusion",
                                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Medium),
                                                color = CrispInkPrimary,
                                                maxLines = 1
                                            )
                                        }
                                    }

                                    Surface(
                                        color = Color.White,
                                        shape = RoundedCornerShape(50),
                                        border = BorderStroke(0.85.dp, CrispHairline),
                                        modifier = Modifier
                                            .weight(1f)
                                            .clip(RoundedCornerShape(50))
                                            .clickable {
                                                val sampleRects = hudManager.getOverlayBounds().ifEmpty {
                                                    listOf(Rect(640, 1800, 1060, 2320))
                                                }
                                                val hit = hudManager.coordinatesOverlapRects(820f, 2000f, 820f, 2000f, sampleRects)
                                                val miss = !hudManager.coordinatesOverlapRects(120f, 240f, 120f, 240f, sampleRects)
                                                val applied = hudManager.temporarilyPassThroughIfColliding(820f, 2000f)
                                                val status = if (hit && miss) "PASS" else "FAIL"
                                                addLog("SAFETY [$status] Touch Pass-Through: overlap=$hit, liveApplied=$applied (300ms)")
                                            }
                                            .testTag("sim_test_touch_passthrough")
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.Center
                                        ) {
                                            Icon(
                                                imageVector = Icons.Rounded.TouchApp,
                                                contentDescription = null,
                                                tint = CrispBlue,
                                                modifier = Modifier.size(14.dp)
                                            )
                                            Spacer(Modifier.width(5.dp))
                                            Text(
                                                text = "Pass-Through",
                                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Medium),
                                                color = CrispInkPrimary,
                                                maxLines = 1
                                            )
                                        }
                                    }
                                }

                                // Live Command Echo Console
                                Surface(
                                    color = Color.White,
                                    shape = RoundedCornerShape(14.dp),
                                    border = BorderStroke(0.85.dp, CrispHairline),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(10.dp),
                                        verticalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = "Command Echo",
                                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
                                                color = CrispInkSecondary
                                            )
                                            Text(
                                                text = "Clear",
                                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
                                                color = CrispBlue,
                                                modifier = Modifier
                                                    .clip(RoundedCornerShape(50))
                                                    .clickable { echoLogs.clear() }
                                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                                            )
                                        }
                                        if (echoLogs.isEmpty()) {
                                            Text(
                                                text = "No events yet.",
                                                style = MaterialTheme.typography.labelSmall.copy(fontFamily = JetBrainsMonoFamily),
                                                color = CrispInkMuted
                                            )
                                        } else {
                                            echoLogs.take(6).forEach { line ->
                                                Text(
                                                    text = line,
                                                    style = MaterialTheme.typography.labelSmall.copy(
                                                        fontFamily = JetBrainsMonoFamily,
                                                        fontSize = 10.sp,
                                                        lineHeight = 14.sp
                                                    ),
                                                    color = when {
                                                        line.contains("HUD_COMMAND") -> CrispBlue
                                                        line.contains("PASS") -> CrispEmerald
                                                        line.contains("NEEDS_INPUT") -> CrispAmber
                                                        else -> CrispInkSecondary
                                                    },
                                                    maxLines = 2,
                                                    overflow = TextOverflow.Ellipsis
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun SandboxWindow2Preview(
    state: AgyHudOverlayManager.AgyHudState,
    isCollapsed: Boolean,
    isInputVisible: Boolean,
    isOutputExpanded: Boolean,
    elapsedMs: Long,
    opacity: Float,
    ghostPassThrough: Boolean,
    wireframeEnabled: Boolean,
    edgeSnapEnabled: Boolean,
    sandboxPrompt: String,
    isVoiceListening: Boolean,
    pinnedMacros: List<AgyHudOverlayManager.MacroShortcut>,
    collapsedRunningStep: AgyHudOverlayManager.CollapsedRunningStep,
    quickActions: List<AgyHudOverlayManager.QuickActionChip>,
    formatElapsed: (Long, Boolean) -> String,
    fullOutputText: String,
    onPromptChange: (String) -> Unit,
    onSubmitPrompt: (String) -> Unit,
    onToggleVoice: () -> Unit,
    onRunMacro: (AgyHudOverlayManager.MacroShortcut) -> Unit,
    onCycleOpacity: () -> Unit,
    onToggleWireframe: () -> Unit,
    onToggleGhost: () -> Unit,
    onToggleEdgeSnap: () -> Unit,
    pointerEnabled: Boolean,
    onTogglePointer: () -> Unit,
    onOpenInput: () -> Unit,
    onToggleCollapse: () -> Unit,
    onToggleOutput: () -> Unit,
    onCopyOutput: () -> Boolean,
    onQuickAction: (AgyHudOverlayManager.QuickActionChip) -> Unit,
    onResume: () -> Unit,
    onStop: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var copiedFlash by remember { mutableStateOf(false) }
    var isToolsTrayOpen by remember { mutableStateOf(false) }
    var isInputFocused by remember { mutableStateOf(false) }
    var isDetailsExpanded by remember { mutableStateOf(false) }
    var isMacrosDrawerOpen by remember { mutableStateOf(false) }

    LaunchedEffect(isCollapsed) {
        if (isCollapsed) {
            isToolsTrayOpen = false
            isInputFocused = false
            isDetailsExpanded = false
            isMacrosDrawerOpen = false
        }
    }
    LaunchedEffect(isOutputExpanded) {
        if (isOutputExpanded) isDetailsExpanded = true
    }

    LaunchedEffect(state.layout.detailsExpanded) {
        state.layout.detailsExpanded?.let { isDetailsExpanded = it }
    }
    LaunchedEffect(state.layout.macrosDrawerOpen) {
        state.layout.macrosDrawerOpen?.let { isMacrosDrawerOpen = it }
    }

    val isWorking = state.state == "WORKING"
    val isPaused = state.state == "PAUSED"
    val isNeedsInput = state.state == "NEEDS_INPUT"
    val isStopping = state.state == "STOPPING"
    val isStopped = state.state == "STOPPED"
    val isDone = state.state == "DONE"
    val liveCollapsedMode = isCollapsed && (isWorking || isPaused || isStopping)
    val isImeOpen = WindowInsets.ime.getBottom(LocalDensity.current) > 0
    val isKeyboardCompactMode = isImeOpen || isInputFocused
    val inputGlowActive = isInputFocused
    val inlineBlocks = remember(state.blocks) { state.blocks.filter { !it.inDetails } }
    val detailBlocks = remember(state.blocks) { state.blocks.filter { it.inDetails } }
    val hasExpandableDetails = state.tasks.isNotEmpty() ||
        state.detailedOutput.isNotBlank() ||
        state.outputLogs.isNotEmpty() ||
        detailBlocks.isNotEmpty() ||
        (state.screenWatch.active && wireframeEnabled)

    val defaultStateAccentInt = when (state.state) {
        "WORKING" -> 0xFF0095F6.toInt()
        "PAUSED", "NEEDS_INPUT" -> 0xFFF59E0B.toInt()
        "STOPPING", "STOPPED" -> 0xFFEF4444.toInt()
        "DONE" -> 0xFF10B981.toInt()
        else -> 0xFF4F46E5.toInt()
    }
    val resolvedTheme = remember(state.theme, defaultStateAccentInt) {
        com.kavach.ui.overlay.AgyHudDynamicModels.resolveTheme(state.theme, defaultStateAccentInt)
    }
    val cardSurfaceColor = Color(resolvedTheme.surface)
    val cardSecondarySurface = Color(resolvedTheme.secondarySurface)
    val cardBorderColor = Color(resolvedTheme.border)
    val textPrimaryColor = Color(resolvedTheme.textPrimary)
    val textSecondaryColor = Color(resolvedTheme.textSecondary)
    val accent = if (isStopping || isStopped) CrispRose else Color(resolvedTheme.accent)
    val cornerDp = resolvedTheme.cornerRadiusDp.dp
    val effectiveOpacity = state.theme.opacity ?: opacity
    val visualAlpha = if (ghostPassThrough) (effectiveOpacity * 0.5f).coerceAtLeast(0.35f) else effectiveOpacity

    // One-shot emerald completion pulse when transitioning to DONE
    val donePulseAlpha = remember { Animatable(0f) }
    var prevStateForPulse by remember { mutableStateOf(state.state) }
    LaunchedEffect(state.state) {
        if (state.state == "DONE" && prevStateForPulse != "DONE") {
            donePulseAlpha.snapTo(1f)
            donePulseAlpha.animateTo(0f, animationSpec = tween(durationMillis = 560, easing = FastOutSlowInEasing))
        }
        prevStateForPulse = state.state
    }

    // Flowing Gemini-style Aurora sweep rotation (adapts speed for Voice / Working / Input Active)
    val auroraTransition = rememberInfiniteTransition(label = "aurora_border")
    val auroraAngle by auroraTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = when {
                    isVoiceListening -> 1500
                    isWorking -> 2500
                    else -> 3400
                },
                easing = LinearEasing
            ),
            repeatMode = RepeatMode.Restart
        ),
        label = "aurora_angle"
    )
    val amberPulse by auroraTransition.animateFloat(
        initialValue = 0.55f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 900, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "amber_pulse"
    )
    val stoppingPulse by auroraTransition.animateFloat(
        initialValue = 0.45f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 520, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "stopping_pulse"
    )

    val headerIcon = collapsedRunningStep.icon

    // Single Unified Gemini HUD: Fluid Spring Morph between Collapsed Pill and Expanded Unified Card + Built-In Bottom Input
    Box(
        contentAlignment = Alignment.BottomEnd,
        modifier = Modifier.alpha(visualAlpha)
    ) {
        AnimatedContent(
            targetState = isCollapsed,
            transitionSpec = {
                (fadeIn(animationSpec = tween(220)) +
                    scaleIn(
                        initialScale = 0.90f,
                        transformOrigin = TransformOrigin(1f, 1f),
                        animationSpec = spring(dampingRatio = 0.78f, stiffness = 360f)
                    ) +
                    expandVertically(
                        expandFrom = Alignment.Bottom,
                        animationSpec = spring(dampingRatio = 0.80f, stiffness = 360f)
                    )) togetherWith
                    (fadeOut(animationSpec = tween(150)) +
                        scaleOut(
                            targetScale = 0.90f,
                            transformOrigin = TransformOrigin(1f, 1f),
                            animationSpec = tween(160)
                        ) +
                        shrinkVertically(
                            shrinkTowards = Alignment.Bottom,
                            animationSpec = tween(170)
                        ))
            },
            label = "unified_hud_morph"
        ) { collapsed ->
            if (!collapsed) {
                // EXPANDED: Single Unified Compact Floating Card (Dynamic Theme + True Perimeter Aurora Glow)
                Surface(
                    color = cardSurfaceColor,
                    shape = RoundedCornerShape(cornerDp),
                    shadowElevation = 7.dp,
                    modifier = Modifier
                        .widthIn(min = 272.dp, max = 308.dp)
                        .animateContentSize(
                            animationSpec = spring(
                                dampingRatio = Spring.DampingRatioLowBouncy,
                                stiffness = Spring.StiffnessMediumLow
                            )
                        )
                        .drawWithContent {
                            drawContent()
                            val corner = CornerRadius(cornerDp.toPx(), cornerDp.toPx())
                            val customAurora = resolvedTheme.auroraIntColors?.map { Color(it) }
                            when {
                                isStopping -> {
                                    drawRoundRect(
                                        color = CrispRose.copy(alpha = 0.22f * stoppingPulse),
                                        cornerRadius = corner,
                                        style = Stroke(width = 5.5.dp.toPx())
                                    )
                                    drawRoundRect(
                                        color = CrispRose.copy(alpha = stoppingPulse),
                                        cornerRadius = corner,
                                        style = Stroke(width = 2.dp.toPx())
                                    )
                                }
                                isStopped -> {
                                    drawRoundRect(
                                        color = CrispRose.copy(alpha = 0.55f),
                                        cornerRadius = corner,
                                        style = Stroke(width = 1.4.dp.toPx())
                                    )
                                }
                                isVoiceListening -> {
                                    val voiceBrush = rotatingSweepBrush(
                                        colors = listOf(
                                            Color(0xFFFB7185),
                                            Color(0xFF8B5CF6),
                                            Color(0xFF38BDF8),
                                            Color(0xFFFB7185)
                                        ),
                                        angleDegrees = auroraAngle
                                    )
                                    drawRoundRect(
                                        brush = voiceBrush,
                                        cornerRadius = corner,
                                        alpha = 0.22f,
                                        style = Stroke(width = 5.dp.toPx())
                                    )
                                    drawRoundRect(
                                        brush = voiceBrush,
                                        cornerRadius = corner,
                                        style = Stroke(width = 2.dp.toPx())
                                    )
                                }
                                isWorking && resolvedTheme.auroraEnabled -> {
                                    val auroraBrush = rotatingSweepBrush(
                                        colors = customAurora ?: listOf(
                                            Color(0xFF0095F6),
                                            Color(0xFF4F46E5),
                                            Color(0xFF8B5CF6),
                                            Color(0xFF38BDF8),
                                            Color(0xFF0095F6)
                                        ),
                                        angleDegrees = auroraAngle
                                    )
                                    drawRoundRect(
                                        brush = auroraBrush,
                                        cornerRadius = corner,
                                        alpha = 0.20f,
                                        style = Stroke(width = 5.dp.toPx())
                                    )
                                    drawRoundRect(
                                        brush = auroraBrush,
                                        cornerRadius = corner,
                                        style = Stroke(width = 2.dp.toPx())
                                    )
                                }
                                isNeedsInput -> {
                                    drawRoundRect(
                                        color = CrispAmber.copy(alpha = 0.16f * amberPulse),
                                        cornerRadius = corner,
                                        style = Stroke(width = 5.dp.toPx())
                                    )
                                    drawRoundRect(
                                        color = CrispAmber.copy(alpha = amberPulse),
                                        cornerRadius = corner,
                                        style = Stroke(width = 1.8.dp.toPx())
                                    )
                                }
                                isPaused -> {
                                    drawRoundRect(
                                        color = CrispAmber.copy(alpha = 0.65f),
                                        cornerRadius = corner,
                                        style = Stroke(width = 1.6.dp.toPx())
                                    )
                                }
                                inputGlowActive && resolvedTheme.auroraEnabled -> {
                                    val geminiBrush = rotatingSweepBrush(
                                        colors = customAurora ?: listOf(
                                            Color(0xFF38BDF8),
                                            Color(0xFF0095F6),
                                            Color(0xFF6366F1),
                                            Color(0xFF8B5CF6),
                                            Color(0xFF38BDF8)
                                        ),
                                        angleDegrees = auroraAngle
                                    )
                                    drawRoundRect(
                                        brush = geminiBrush,
                                        cornerRadius = corner,
                                        alpha = 0.18f,
                                        style = Stroke(width = 4.5.dp.toPx())
                                    )
                                    drawRoundRect(
                                        brush = geminiBrush,
                                        cornerRadius = corner,
                                        style = Stroke(width = 1.8.dp.toPx())
                                    )
                                }
                                isDone -> {
                                    if (donePulseAlpha.value > 0.01f) {
                                        drawRoundRect(
                                            color = CrispEmerald.copy(alpha = 0.30f * donePulseAlpha.value),
                                            cornerRadius = corner,
                                            style = Stroke(width = 5.5.dp.toPx())
                                        )
                                    }
                                    drawRoundRect(
                                        color = CrispEmerald.copy(alpha = 0.55f),
                                        cornerRadius = corner,
                                        style = Stroke(width = 1.4.dp.toPx())
                                    )
                                }
                                else -> {
                                    drawRoundRect(
                                        color = cardBorderColor,
                                        cornerRadius = corner,
                                        style = Stroke(width = 1.dp.toPx())
                                    )
                                }
                            }
                        }
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // 1. Dynamic Progress Bar (Determinate 0..100% or Indeterminate Sliding Bar)
                        val showProgress = state.progress.visible || isWorking || isStopping
                        if (showProgress) {
                            val progressColor = com.kavach.ui.overlay.AgyHudDynamicModels
                                .parseColorOrNull(state.progress.color)?.let { Color(it) }
                                ?: if (isStopping) CrispRose else accent
                            val trackColor = if (resolvedTheme.isDark) Color(0xFF334155) else Color(0xFFE2E8F0)
                            Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                if (state.progress.visible && state.progress.isDeterminate) {
                                    ComposeDeterminateLoadingBar(
                                        fraction = state.progress.fraction,
                                        accentColor = progressColor,
                                        trackColor = trackColor,
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                } else {
                                    ComposeSlidingLoadingBar(
                                        accentColor = progressColor,
                                        trackColor = trackColor,
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                }
                                if (state.progress.visible && (state.progress.label.isNotBlank() || state.progress.isDeterminate)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = state.progress.label,
                                            style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.5.sp),
                                            color = textSecondaryColor,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis,
                                            modifier = Modifier.weight(1f)
                                        )
                                        if (state.progress.isDeterminate) {
                                            Text(
                                                text = "${state.progress.value.toInt()}%",
                                                style = MaterialTheme.typography.labelSmall.copy(
                                                    fontFamily = JetBrainsMonoFamily,
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 9.5.sp
                                                ),
                                                color = progressColor
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        // Ultra-Clean Header: Custom Emoji or App Icon + Single-Line Status & Timer + Quiet Controls
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                if (state.customEmoji.isNotBlank()) {
                                    Box(
                                        contentAlignment = Alignment.Center,
                                        modifier = Modifier
                                            .size(24.dp)
                                            .clip(CircleShape)
                                            .background(cardSecondarySurface)
                                    ) {
                                        Text(text = state.customEmoji, fontSize = 14.sp)
                                    }
                                } else {
                                    AgyComposeIconBadge(icon = headerIcon, size = 24.dp)
                                }
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(5.dp)
                                ) {
                                    if (isWorking || isStopping) {
                                        ComposeSpinnerRing(color = accent, size = 11.dp)
                                    } else {
                                        Box(
                                            modifier = Modifier
                                                .size(6.dp)
                                                .clip(CircleShape)
                                                .background(accent)
                                        )
                                    }
                                    val cleanStatus = state.statusLabel.ifBlank {
                                        when (state.state) {
                                            "WORKING" -> "Working"
                                            "PAUSED" -> "Paused"
                                            "NEEDS_INPUT" -> "Needs input"
                                            "STOPPING" -> "Stopping…"
                                            "STOPPED" -> "Stopped"
                                            "DONE" -> "Done"
                                            else -> "Ready"
                                        }
                                    }
                                    Text(
                                        text = cleanStatus,
                                        style = MaterialTheme.typography.labelMedium.copy(
                                            fontWeight = FontWeight.SemiBold,
                                            fontSize = 11.5.sp
                                        ),
                                        color = accent,
                                        maxLines = 1
                                    )
                                    val timerLabel = if (!state.timerVisible) {
                                        ""
                                    } else if (state.customTimerText.isNotBlank()) {
                                        "· ${state.customTimerText}"
                                    } else {
                                        when {
                                            isWorking || isPaused || isStopping -> "· ${formatElapsed(elapsedMs, false)}"
                                            isDone && elapsedMs > 0L -> "· ${formatElapsed(elapsedMs, true).removePrefix("Done ")}"
                                            (isNeedsInput || isStopped) && elapsedMs > 0L -> "· ${formatElapsed(elapsedMs, false)}"
                                            else -> ""
                                        }
                                    }
                                    if (timerLabel.isNotEmpty()) {
                                        Text(
                                            text = timerLabel,
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                fontFamily = JetBrainsMonoFamily,
                                                fontSize = 10.sp
                                            ),
                                            color = if (isPaused) CrispAmber else textSecondaryColor,
                                            maxLines = 1,
                                            modifier = Modifier.testTag("simulator_elapsed_timer")
                                        )
                                    }
                                }
                            }
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                if (hasExpandableDetails && state.layout.showStepsBadge) {
                                    val doneCount = state.tasks.count { it.status == "done" }
                                    val totalCount = state.tasks.size
                                    val activeDetails = isDetailsExpanded && !isKeyboardCompactMode
                                    val chevron = if (activeDetails) "▴" else "▾"
                                    val pillText = if (totalCount > 0) "$doneCount/$totalCount $chevron" else "Details $chevron"
                                    Surface(
                                        color = if (activeDetails) accent.copy(alpha = 0.14f) else cardSecondarySurface,
                                        shape = RoundedCornerShape(50),
                                        border = BorderStroke(
                                            0.75.dp,
                                            if (activeDetails) accent.copy(alpha = 0.38f) else cardBorderColor
                                        ),
                                        modifier = Modifier
                                            .height(26.dp)
                                            .clip(RoundedCornerShape(50))
                                            .clickable { isDetailsExpanded = !isDetailsExpanded }
                                            .testTag("simulator_steps_toggle_pill")
                                    ) {
                                        Box(
                                            contentAlignment = Alignment.Center,
                                            modifier = Modifier.padding(horizontal = 8.dp)
                                        ) {
                                            Text(
                                                text = pillText,
                                                style = MaterialTheme.typography.labelSmall.copy(
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 10.sp
                                                ),
                                                color = if (activeDetails) accent else textSecondaryColor,
                                                maxLines = 1
                                            )
                                        }
                                    }
                                }
                                if (state.layout.showOverflowMenu) {
                                    MiniHudChip(
                                        symbol = "···",
                                        active = isToolsTrayOpen,
                                        bgColor = if (isToolsTrayOpen) accent.copy(alpha = 0.16f) else cardSecondarySurface,
                                        tintColor = if (isToolsTrayOpen) accent else textSecondaryColor,
                                        onClick = { isToolsTrayOpen = !isToolsTrayOpen }
                                    )
                                }
                                if (state.layout.showCollapseButton) {
                                    MiniHudChip(
                                        symbol = "─",
                                        active = false,
                                        bgColor = cardSecondarySurface,
                                        tintColor = textSecondaryColor,
                                        onClick = {
                                            isToolsTrayOpen = false
                                            onToggleCollapse()
                                        }
                                    )
                                }
                            }
                        }

                        // Hidden-by-default Secondary Tools Tray (Opacity, Wireframe, Ghost, Snap)
                        AnimatedVisibility(
                            visible = isToolsTrayOpen,
                            enter = fadeIn(tween(180)) + expandVertically(
                                animationSpec = spring(dampingRatio = 0.82f, stiffness = 400f)
                            ),
                            exit = fadeOut(tween(140)) + shrinkVertically()
                        ) {
                            Surface(
                                color = cardSecondarySurface,
                                shape = RoundedCornerShape(12.dp),
                                border = BorderStroke(0.75.dp, cardBorderColor),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("simulator_hud_tools_tray")
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(4.dp),
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    HudTrayPill(
                                        label = "${(effectiveOpacity * 100).toInt()}%",
                                        active = false,
                                        accent = accent,
                                        onClick = onCycleOpacity,
                                        modifier = Modifier.weight(1f)
                                    )
                                    HudTrayPill(
                                        label = if (wireframeEnabled) "● Wire" else "Wire",
                                        active = wireframeEnabled,
                                        accent = accent,
                                        onClick = onToggleWireframe,
                                        modifier = Modifier.weight(1f)
                                    )
                                    HudTrayPill(
                                        label = if (ghostPassThrough) "● Ghost" else "Ghost",
                                        active = ghostPassThrough,
                                        accent = CrispAmber,
                                        onClick = onToggleGhost,
                                        modifier = Modifier.weight(1f)
                                    )
                                    HudTrayPill(
                                        label = if (edgeSnapEnabled) "● Snap" else "Snap",
                                        active = edgeSnapEnabled,
                                        accent = accent,
                                        onClick = onToggleEdgeSnap,
                                        modifier = Modifier.weight(1f)
                                    )
                                    HudTrayPill(
                                        label = if (pointerEnabled) "● 🖱" else "🖱",
                                        active = pointerEnabled,
                                        accent = accent,
                                        onClick = onTogglePointer,
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                            }
                        }

                        // Smooth Crossfading Task Title
                        AnimatedContent(
                            targetState = state.title,
                            transitionSpec = {
                                (fadeIn(tween(190)) + slideInVertically(tween(190)) { it / 4 }) togetherWith
                                    (fadeOut(tween(130)) + slideOutVertically(tween(130)) { -it / 4 })
                            },
                            label = "hud_title_crossfade"
                        ) { titleText ->
                            Text(
                                text = titleText,
                                style = MaterialTheme.typography.titleSmall.copy(
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 14.sp
                                ),
                                color = textPrimaryColor,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                        }

                        // Dynamic Alert Banner (info / success / warning / error)
                        if (state.banner.visible) {
                            SandboxBannerView(
                                banner = state.banner,
                                isDark = resolvedTheme.isDark
                            )
                        }

                        if (state.question.isNotBlank()) {
                            Surface(
                                color = if (resolvedTheme.isDark) Color(0xFF451A03) else Color(0xFFFEF3C7),
                                shape = RoundedCornerShape(12.dp),
                                border = BorderStroke(0.8.dp, if (resolvedTheme.isDark) Color(0xFF92400E) else Color(0xFFFDE68A)),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .clickable(onClick = onOpenInput)
                            ) {
                                Text(
                                    text = state.question,
                                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold),
                                    color = if (resolvedTheme.isDark) Color(0xFFFDE68A) else Color(0xFFB45309),
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp)
                                )
                            }
                        }

                        // Calm Active Step Line + 3 Animated Bouncing Dots while WORKING / STOPPING
                        val activeSubtitle = if (isStopping && state.currentAction.isBlank()) {
                            "Stopping… tap Stop again to force-stop"
                        } else {
                            state.currentAction
                        }
                        if (activeSubtitle.isNotBlank()) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Text(
                                    text = activeSubtitle,
                                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.5.sp),
                                    color = if (isStopping) CrispRose else textSecondaryColor,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.weight(1f, fill = false)
                                )
                                if (isWorking || isStopping) {
                                    ComposeBouncingDots(color = accent)
                                }
                            }
                        }

                        // Live Metric Pills Row (e.g., CPU 38%, Files 7/12, 48ms)
                        if (state.metrics.isNotEmpty() && !isKeyboardCompactMode) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .horizontalScroll(rememberScrollState())
                                    .testTag("simulator_metrics_row"),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                state.metrics.forEach { m ->
                                    val mAccent = com.kavach.ui.overlay.AgyHudDynamicModels
                                        .parseColorOrNull(m.accentColor)?.let { Color(it) } ?: accent
                                    Surface(
                                        color = cardSecondarySurface,
                                        shape = RoundedCornerShape(10.dp),
                                        border = BorderStroke(0.75.dp, cardBorderColor)
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                                        ) {
                                            if (m.icon.isNotBlank()) {
                                                Text(text = m.icon, fontSize = 10.sp)
                                            }
                                            if (m.label.isNotBlank()) {
                                                Text(
                                                    text = m.label,
                                                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.5.sp),
                                                    color = textSecondaryColor,
                                                    maxLines = 1
                                                )
                                            }
                                            if (m.value.isNotBlank()) {
                                                Text(
                                                    text = m.value,
                                                    style = MaterialTheme.typography.labelSmall.copy(
                                                        fontFamily = JetBrainsMonoFamily,
                                                        fontWeight = FontWeight.Bold,
                                                        fontSize = 10.sp
                                                    ),
                                                    color = mAccent,
                                                    maxLines = 1
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        // Inline Modular Content Blocks (inDetails == false)
                        if (inlineBlocks.isNotEmpty() && !isKeyboardCompactMode) {
                            Column(
                                modifier = Modifier.fillMaxWidth(),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                inlineBlocks.forEach { block ->
                                    SandboxContentBlockView(
                                        block = block,
                                        secondarySurface = cardSecondarySurface,
                                        borderColor = cardBorderColor,
                                        textPrimary = textPrimaryColor,
                                        textSecondary = textSecondaryColor,
                                        defaultAccent = accent,
                                        isDark = resolvedTheme.isDark
                                    )
                                }
                            }
                        }

                        if (state.nextAction.isNotBlank() && state.tasks.isEmpty()) {
                            Text(
                                text = "Next: ${state.nextAction}",
                                style = MaterialTheme.typography.labelSmall,
                                color = textSecondaryColor.copy(alpha = 0.8f),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }

                        // On-demand Staggered Checklist, Output Drawer, Quick Actions & Wireframe (auto-folds when keyboard opens)
                        AnimatedVisibility(
                            visible = isDetailsExpanded && !isKeyboardCompactMode,
                            enter = fadeIn(tween(190)) + expandVertically(
                                animationSpec = spring(dampingRatio = 0.84f, stiffness = 380f)
                            ),
                            exit = fadeOut(tween(130)) + shrinkVertically()
                        ) {
                            Column(
                                modifier = Modifier.fillMaxWidth(),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                // Staggered Airy Borderless Task Checklist with Hybrid App/Task Icons
                                if (state.tasks.isNotEmpty()) {
                                    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                        state.tasks.forEachIndexed { idx, task ->
                                            StaggeredSandboxTaskRow(
                                                task = task,
                                                index = idx,
                                                isWorking = isWorking
                                            )
                                        }
                                    }
                                }

                        // Quiet Neutral Expandable Detailed Output Drawer
                        val hasDetailedOutput = state.detailedOutput.isNotBlank() || state.outputLogs.isNotEmpty()
                        if (hasDetailedOutput) {
                            Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                                Surface(
                                    color = Color(0xFFF3F4F6),
                                    shape = RoundedCornerShape(12.dp),
                                    border = BorderStroke(0.75.dp, Color(0xFFE5E7EB)),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(12.dp))
                                        .clickable(onClick = onToggleOutput)
                                        .testTag("simulator_toggle_output_drawer")
                                ) {
                                    val logSuffix = if (state.outputLogs.isNotEmpty()) " · ${state.outputLogs.size} logs" else ""
                                    Text(
                                        text = if (isOutputExpanded) {
                                            "Hide Output$logSuffix ▴"
                                        } else {
                                            "Output$logSuffix ▾"
                                        },
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontWeight = FontWeight.SemiBold,
                                            fontSize = 11.sp
                                        ),
                                        color = CrispInkPrimary,
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                    )
                                }

                                AnimatedVisibility(
                                    visible = isOutputExpanded,
                                    enter = fadeIn(tween(180)) + expandVertically(
                                        animationSpec = spring(dampingRatio = 0.82f, stiffness = 380f)
                                    ),
                                    exit = fadeOut(tween(140)) + shrinkVertically()
                                ) {
                                    Surface(
                                        color = Color(0xFFF8FAFC),
                                        shape = RoundedCornerShape(12.dp),
                                        border = BorderStroke(0.75.dp, CrispHairline),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .testTag("simulator_output_drawer_content")
                                    ) {
                                        Column(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(10.dp),
                                            verticalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Text(
                                                    text = "OUTPUT & LOGS",
                                                    style = MaterialTheme.typography.labelSmall.copy(
                                                        fontFamily = JetBrainsMonoFamily,
                                                        fontWeight = FontWeight.Bold,
                                                        fontSize = 9.sp
                                                    ),
                                                    color = CrispInkMuted
                                                )
                                                Surface(
                                                    color = Color.White,
                                                    shape = RoundedCornerShape(50),
                                                    border = BorderStroke(0.8.dp, CrispHairline),
                                                    modifier = Modifier
                                                        .clip(RoundedCornerShape(50))
                                                        .clickable {
                                                            if (onCopyOutput()) {
                                                                copiedFlash = true
                                                                scope.launch {
                                                                    delay(1600L)
                                                                    copiedFlash = false
                                                                }
                                                            }
                                                        }
                                                        .testTag("simulator_copy_output_button")
                                                ) {
                                                    Text(
                                                        text = if (copiedFlash) "Copied ✓" else "Copy",
                                                        style = MaterialTheme.typography.labelSmall.copy(
                                                            fontWeight = FontWeight.Bold,
                                                            fontSize = 9.5.sp
                                                        ),
                                                        color = if (copiedFlash) CrispEmerald else CrispBlue,
                                                        modifier = Modifier.padding(horizontal = 9.dp, vertical = 2.dp)
                                                    )
                                                }
                                            }
                                            Box(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .heightIn(max = 120.dp)
                                                    .verticalScroll(rememberScrollState())
                                            ) {
                                                Text(
                                                    text = fullOutputText,
                                                    style = MaterialTheme.typography.labelSmall.copy(
                                                        fontFamily = JetBrainsMonoFamily,
                                                        fontSize = 10.sp,
                                                        lineHeight = 14.sp
                                                    ),
                                                    color = CrispInkPrimary
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        // Detail-only Modular Content Blocks (inDetails == true)
                        if (detailBlocks.isNotEmpty()) {
                            Column(
                                modifier = Modifier.fillMaxWidth(),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                detailBlocks.forEach { block ->
                                    SandboxContentBlockView(
                                        block = block,
                                        secondarySurface = cardSecondarySurface,
                                        borderColor = cardBorderColor,
                                        textPrimary = textPrimaryColor,
                                        textSecondary = textSecondaryColor,
                                        defaultAccent = accent,
                                        isDark = resolvedTheme.isDark
                                    )
                                }
                            }
                        }

                        // Contextual & Custom Styled Action Chips Strip
                        if (quickActions.isNotEmpty()) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .horizontalScroll(rememberScrollState())
                                    .testTag("simulator_quick_actions_row"),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                quickActions.forEachIndexed { idx, chip ->
                                    val styleNorm = chip.style.lowercase()
                                    val isDanger = styleNorm == "danger" || chip.actionType == "STOP" || chip.actionType == "FORCE_STOP"
                                    val isSuccess = styleNorm == "success"
                                    val isPrimary = styleNorm == "primary" || (styleNorm.isEmpty() && idx == 0 && !isDanger)
                                    val chipTint = when {
                                        isDanger -> CrispRose
                                        isSuccess -> CrispEmerald
                                        isPrimary -> accent
                                        else -> textPrimaryColor
                                    }
                                    Surface(
                                        color = when {
                                            isDanger -> CrispRose.copy(alpha = 0.14f)
                                            isSuccess -> CrispEmerald.copy(alpha = 0.14f)
                                            isPrimary -> accent.copy(alpha = 0.14f)
                                            else -> cardSecondarySurface
                                        },
                                        shape = RoundedCornerShape(50),
                                        border = BorderStroke(
                                            0.8.dp,
                                            when {
                                                isDanger -> CrispRose.copy(alpha = 0.40f)
                                                isSuccess -> CrispEmerald.copy(alpha = 0.40f)
                                                isPrimary -> accent.copy(alpha = 0.40f)
                                                else -> cardBorderColor
                                            }
                                        ),
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(50))
                                            .clickable { onQuickAction(chip) }
                                            .testTag("simulator_quick_chip_$idx")
                                    ) {
                                        Text(
                                            text = chip.label,
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 10.5.sp
                                            ),
                                            color = chipTint,
                                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                                        )
                                    }
                                }
                            }
                        }

                        // Miniature Low-Poly Wireframe Canvas (collapses to 0dp when screenWatch.active == false)
                        AnimatedVisibility(
                            visible = state.screenWatch.active && wireframeEnabled,
                            enter = fadeIn() + expandVertically(),
                            exit = fadeOut() + shrinkVertically()
                        ) {
                            Surface(
                                color = CrispSurfaceSubtle,
                                shape = RoundedCornerShape(14.dp),
                                border = BorderStroke(1.dp, CrispHairline),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 2.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(8.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    SandboxWireframeCanvas(watch = state.screenWatch)
                                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                        Text(
                                            text = state.screenWatch.label.ifBlank { "Screen Watch" },
                                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                            color = CrispInkPrimary
                                        )
                                        Text(
                                            text = "${state.screenWatch.zones.size} key zones${state.screenWatch.actionVector?.let { " • ${it.type}" } ?: ""}",
                                            style = MaterialTheme.typography.labelSmall.copy(fontFamily = JetBrainsMonoFamily),
                                            color = CrispInkSecondary
                                        )
                                    }
                                }
                            }
                        }
                            }
                        }

                        // === BUILT-IN GEMINI BOTTOM COMPOSER DOCK (respects layout.showComposer) ===
                        if (state.layout.showComposer) {
                            HorizontalDivider(
                                color = cardBorderColor,
                                thickness = 0.85.dp,
                                modifier = Modifier.padding(top = 1.dp)
                            )

                            Column(
                                modifier = Modifier.fillMaxWidth(),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                // On-demand Pinned Macros Strip (toggled via ⚡ button inside the prompt pill)
                                AnimatedVisibility(
                                    visible = isMacrosDrawerOpen && pinnedMacros.isNotEmpty() && state.layout.showMacros,
                                    enter = fadeIn(tween(170)) + expandVertically(
                                        animationSpec = spring(dampingRatio = 0.84f, stiffness = 400f)
                                    ),
                                    exit = fadeOut(tween(120)) + shrinkVertically()
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .horizontalScroll(rememberScrollState())
                                            .testTag("simulator_pinned_macros_row"),
                                        horizontalArrangement = Arrangement.spacedBy(5.dp)
                                    ) {
                                        pinnedMacros.forEachIndexed { idx, macro ->
                                            val macroIcon = remember(context, macro.iconHint, macro.title) {
                                                AgyAppIconResolver.resolve(
                                                    context = context,
                                                    explicitIcon = macro.iconHint,
                                                    explicitPackage = "",
                                                    fallbackText = "${macro.title} ${macro.prompt}"
                                                )
                                            }
                                            Surface(
                                                color = cardSecondarySurface,
                                                shape = RoundedCornerShape(50),
                                                border = BorderStroke(0.75.dp, cardBorderColor),
                                                modifier = Modifier
                                                    .clip(RoundedCornerShape(50))
                                                    .clickable {
                                                        isMacrosDrawerOpen = false
                                                        onRunMacro(macro)
                                                    }
                                                    .testTag("simulator_pinned_macro_$idx")
                                            ) {
                                                Row(
                                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    horizontalArrangement = Arrangement.spacedBy(5.dp)
                                                ) {
                                                    AgyComposeIconBadge(icon = macroIcon, size = 14.dp)
                                                    Text(
                                                        text = macro.title,
                                                        style = MaterialTheme.typography.labelSmall.copy(
                                                            fontWeight = FontWeight.SemiBold,
                                                            fontSize = 10.sp
                                                        ),
                                                        color = textPrimaryColor,
                                                        maxLines = 1
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }

                                // Optional Voice Status Micro-Hint
                                AnimatedVisibility(
                                    visible = isVoiceListening,
                                    enter = fadeIn(tween(150)) + expandVertically(),
                                    exit = fadeOut(tween(120)) + shrinkVertically()
                                ) {
                                    Text(
                                        text = "● Listening… speak your prompt",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontWeight = FontWeight.SemiBold,
                                            fontSize = 10.sp
                                        ),
                                        color = CrispRose,
                                        modifier = Modifier.padding(start = 6.dp)
                                    )
                                }

                                // Gemini Pill Composer Capsule
                                val capsuleBorderColor = when {
                                    isVoiceListening || isStopping -> CrispRose.copy(alpha = 0.75f)
                                    inputGlowActive -> accent.copy(alpha = 0.72f)
                                    isNeedsInput -> CrispAmber.copy(alpha = 0.75f)
                                    else -> cardBorderColor
                                }
                                Surface(
                                    color = if (inputGlowActive) cardSurfaceColor else cardSecondarySurface,
                                    shape = RoundedCornerShape(50),
                                    border = BorderStroke(
                                        width = if (inputGlowActive || isVoiceListening || isStopping) 1.25.dp else 0.9.dp,
                                        color = capsuleBorderColor
                                    ),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(horizontal = 5.dp, vertical = 4.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        // Circular Voice Mic Orb
                                        if (state.layout.showMic) {
                                            Surface(
                                                color = if (isVoiceListening) CrispRose.copy(alpha = 0.14f) else cardSurfaceColor,
                                                shape = CircleShape,
                                                border = BorderStroke(
                                                    0.85.dp,
                                                    if (isVoiceListening) CrispRose.copy(alpha = 0.45f) else cardBorderColor
                                                ),
                                                modifier = Modifier
                                                    .size(30.dp)
                                                    .clip(CircleShape)
                                                    .clickable(onClick = onToggleVoice)
                                                    .testTag("simulator_voice_mic_button")
                                            ) {
                                                Box(contentAlignment = Alignment.Center) {
                                                    Icon(
                                                        imageVector = Icons.Rounded.Mic,
                                                        contentDescription = if (isVoiceListening) "Stop Voice Input" else "Start Voice Input",
                                                        tint = if (isVoiceListening) CrispRose else textSecondaryColor,
                                                        modifier = Modifier.size(15.dp)
                                                    )
                                                }
                                            }
                                        }

                                        // Clean Inline Gemini Text Field
                                        Box(
                                            contentAlignment = Alignment.CenterStart,
                                            modifier = Modifier
                                                .weight(1f)
                                                .heightIn(min = 30.dp)
                                        ) {
                                            if (sandboxPrompt.isEmpty()) {
                                                Text(
                                                    text = when {
                                                        isVoiceListening -> "Listening…"
                                                        isStopping -> "Tap ■ to force-stop…"
                                                        state.layout.inputPlaceholder.isNotBlank() -> state.layout.inputPlaceholder
                                                        isNeedsInput -> "Reply to Agy…"
                                                        else -> "Ask Agy anything…"
                                                    },
                                                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 12.sp),
                                                    color = when {
                                                        isVoiceListening || isStopping -> CrispRose
                                                        else -> textSecondaryColor.copy(alpha = 0.8f)
                                                    },
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis
                                                )
                                            }
                                            BasicTextField(
                                                value = sandboxPrompt,
                                                onValueChange = onPromptChange,
                                                singleLine = true,
                                                textStyle = MaterialTheme.typography.bodySmall.copy(
                                                    color = textPrimaryColor,
                                                    fontSize = 12.sp
                                                ),
                                                cursorBrush = SolidColor(accent),
                                                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                                                keyboardActions = KeyboardActions(
                                                    onSend = {
                                                        if (sandboxPrompt.isNotBlank()) {
                                                            onSubmitPrompt(sandboxPrompt)
                                                        }
                                                    }
                                                ),
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .onFocusChanged { isInputFocused = it.isFocused }
                                                    .testTag("simulator_prompt_input")
                                            )
                                        }

                                        // Smart Clear Chip when text is present
                                        if (sandboxPrompt.isNotEmpty()) {
                                            Box(
                                                contentAlignment = Alignment.Center,
                                                modifier = Modifier
                                                    .size(22.dp)
                                                    .clip(CircleShape)
                                                    .background(cardBorderColor)
                                                    .clickable { onPromptChange("") }
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Rounded.Close,
                                                    contentDescription = "Clear Draft",
                                                    tint = textSecondaryColor,
                                                    modifier = Modifier.size(12.dp)
                                                )
                                            }
                                        }

                                        // On-demand Pinned Macros ⚡ Toggle Button
                                        if (pinnedMacros.isNotEmpty() && state.layout.showMacros) {
                                            Surface(
                                                color = if (isMacrosDrawerOpen) accent.copy(alpha = 0.14f) else cardSurfaceColor,
                                                shape = CircleShape,
                                                border = BorderStroke(
                                                    0.8.dp,
                                                    if (isMacrosDrawerOpen) accent.copy(alpha = 0.42f) else cardBorderColor
                                                ),
                                                modifier = Modifier
                                                    .size(28.dp)
                                                    .clip(CircleShape)
                                                    .clickable { isMacrosDrawerOpen = !isMacrosDrawerOpen }
                                                    .testTag("simulator_macros_toggle_button")
                                            ) {
                                                Box(contentAlignment = Alignment.Center) {
                                                    Icon(
                                                        imageVector = Icons.Rounded.Bolt,
                                                        contentDescription = "Toggle Quick Macros",
                                                        tint = if (isMacrosDrawerOpen) accent else textSecondaryColor,
                                                        modifier = Modifier.size(15.dp)
                                                    )
                                                }
                                            }
                                        }

                                        // Morphing Trailing Orb: ■ Stop (two-stage) when active with empty draft, ↑ Send otherwise
                                        val isActiveStoppable = isWorking || isPaused || isNeedsInput || isStopping
                                        val showStopOrb = state.layout.showStopButton && isActiveStoppable && sandboxPrompt.isBlank()
                                        AnimatedContent(
                                            targetState = showStopOrb to isStopping,
                                            transitionSpec = {
                                                (fadeIn(tween(150)) + scaleIn(
                                                    initialScale = 0.72f,
                                                    animationSpec = spring(dampingRatio = 0.65f, stiffness = 460f)
                                                )) togetherWith (fadeOut(tween(110)) + scaleOut(targetScale = 0.72f))
                                            },
                                            label = "composer_action_orb_morph"
                                        ) { (isStopMode, stoppingNow) ->
                                            if (isStopMode) {
                                                Surface(
                                                    color = if (stoppingNow) CrispRose else CrispRose.copy(alpha = 0.14f),
                                                    shape = CircleShape,
                                                    border = BorderStroke(
                                                        0.9.dp,
                                                        if (stoppingNow) Color(0xFFB91C1C) else CrispRose.copy(alpha = 0.45f)
                                                    ),
                                                    modifier = Modifier
                                                        .size(32.dp)
                                                        .clip(CircleShape)
                                                        .clickable(onClick = onStop)
                                                        .testTag("simulator_stop_button")
                                                ) {
                                                    Box(contentAlignment = Alignment.Center) {
                                                        Icon(
                                                            imageVector = Icons.Rounded.Stop,
                                                            contentDescription = if (stoppingNow) "Force-Stop Agy" else "Stop Agy",
                                                            tint = if (stoppingNow) Color.White else CrispRose,
                                                            modifier = Modifier.size(16.dp)
                                                        )
                                                    }
                                                }
                                            } else {
                                                Surface(
                                                    color = if (isNeedsInput) CrispAmber else accent,
                                                    shape = CircleShape,
                                                    modifier = Modifier
                                                        .size(32.dp)
                                                        .clip(CircleShape)
                                                        .clickable { onSubmitPrompt(sandboxPrompt) }
                                                        .testTag("simulator_send_button")
                                                ) {
                                                    Box(contentAlignment = Alignment.Center) {
                                                        Icon(
                                                            imageVector = Icons.Rounded.ArrowUpward,
                                                            contentDescription = "Send Prompt",
                                                            tint = Color.White,
                                                            modifier = Modifier.size(16.dp)
                                                        )
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                // COLLAPSED: Compact Morphing Floating Pill (Live Step Pill while running/paused, or ✦ Ask Agy Pill when idle/done)
                Surface(
                    color = CrispSurface,
                    shape = RoundedCornerShape(50),
                    shadowElevation = 4.dp,
                    border = BorderStroke(
                        if (isWorking || isPaused || isNeedsInput) 1.15.dp else 1.dp,
                        when {
                            isNeedsInput || isPaused -> CrispAmber
                            isWorking -> CrispBlue.copy(alpha = 0.48f)
                            isDone -> CrispEmerald.copy(alpha = 0.48f)
                            else -> CrispBorder
                        }
                    ),
                    modifier = Modifier
                        .animateContentSize(
                            animationSpec = spring(dampingRatio = 0.80f, stiffness = 380f)
                        )
                        .testTag("simulator_bottom_chat_dock")
                ) {
                    if (liveCollapsedMode) {
                        val pillStepText = if (isPaused) {
                            "Paused · ${collapsedRunningStep.label}"
                        } else {
                            collapsedRunningStep.label
                        }
                        Row(
                            modifier = Modifier
                                .widthIn(max = 292.dp)
                                .padding(start = 7.dp, end = 6.dp, top = 5.dp, bottom = 5.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier
                                    .weight(1f, fill = false)
                                    .clip(RoundedCornerShape(50))
                                    .clickable(onClick = onToggleCollapse)
                                    .padding(end = 2.dp)
                                    .testTag("simulator_collapsed_live_step_pill")
                            ) {
                                Box(
                                    contentAlignment = Alignment.Center,
                                    modifier = Modifier.size(26.dp)
                                ) {
                                    if (isPaused) {
                                        Canvas(modifier = Modifier.size(26.dp)) {
                                            val strokePx = 2.dp.toPx()
                                            val pad = strokePx * 0.6f
                                            drawArc(
                                                color = CrispAmber.copy(alpha = 0.85f),
                                                startAngle = 0f,
                                                sweepAngle = 360f,
                                                useCenter = false,
                                                topLeft = Offset(pad, pad),
                                                size = Size(size.width - pad * 2f, size.height - pad * 2f),
                                                style = Stroke(width = strokePx)
                                            )
                                        }
                                    } else {
                                        ComposeSpinnerRing(color = CrispBlue, size = 26.dp)
                                    }
                                    AgyComposeIconBadge(icon = collapsedRunningStep.icon, size = 18.dp)
                                }
                                AnimatedContent(
                                    targetState = pillStepText,
                                    transitionSpec = {
                                        (fadeIn(tween(190)) + slideInVertically(tween(190)) { it / 3 }) togetherWith
                                            (fadeOut(tween(140)) + slideOutVertically(tween(140)) { -it / 3 })
                                    },
                                    label = "collapsed_live_step_crossfade",
                                    modifier = Modifier
                                        .weight(1f, fill = false)
                                        .widthIn(min = 56.dp, max = 160.dp)
                                ) { stepLabel ->
                                    Text(
                                        text = stepLabel,
                                        style = MaterialTheme.typography.labelMedium.copy(
                                            fontWeight = FontWeight.SemiBold,
                                            fontSize = 12.sp
                                        ),
                                        color = if (isPaused) CrispAmber else CrispInkPrimary,
                                        maxLines = 1,
                                        softWrap = false,
                                        modifier = Modifier
                                            .graphicsLayer(compositingStrategy = CompositingStrategy.Offscreen)
                                            .drawWithContent {
                                                drawContent()
                                                val fadeW = 12.dp.toPx()
                                                if (size.width > fadeW * 2.5f) {
                                                    drawRect(
                                                        brush = Brush.horizontalGradient(
                                                            0f to Color.Transparent,
                                                            1f to Color.Black,
                                                            startX = size.width - fadeW,
                                                            endX = size.width
                                                        ),
                                                        blendMode = BlendMode.DstOut
                                                    )
                                                }
                                            }
                                            .basicMarquee(
                                                iterations = Int.MAX_VALUE,
                                                repeatDelayMillis = 1200,
                                                initialDelayMillis = 600,
                                                velocity = 34.dp
                                            )
                                            .testTag("simulator_collapsed_live_step_text")
                                    )
                                }
                                Text(
                                    text = formatElapsed(elapsedMs, false),
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontFamily = JetBrainsMonoFamily,
                                        fontSize = 10.5.sp
                                    ),
                                    color = if (isPaused) CrispAmber else CrispInkSecondary,
                                    maxLines = 1,
                                    modifier = Modifier.testTag("simulator_collapsed_live_timer")
                                )
                            }

                            if (isPaused) {
                                Surface(
                                    color = CrispBlue.copy(alpha = 0.12f),
                                    shape = CircleShape,
                                    border = BorderStroke(0.85.dp, CrispBlue.copy(alpha = 0.35f)),
                                    modifier = Modifier
                                        .size(28.dp)
                                        .clip(CircleShape)
                                        .clickable(onClick = onResume)
                                        .testTag("simulator_collapsed_resume_btn")
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(
                                            imageVector = Icons.Rounded.PlayArrow,
                                            contentDescription = "Resume Agy",
                                            tint = CrispBlue,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                            } else {
                                Surface(
                                    color = CrispRose.copy(alpha = 0.12f),
                                    shape = CircleShape,
                                    border = BorderStroke(0.85.dp, CrispRose.copy(alpha = 0.30f)),
                                    modifier = Modifier
                                        .size(28.dp)
                                        .clip(CircleShape)
                                        .clickable(onClick = onStop)
                                        .testTag("simulator_collapsed_stop_btn")
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(
                                            imageVector = Icons.Rounded.Stop,
                                            contentDescription = "Stop Agy",
                                            tint = CrispRose,
                                            modifier = Modifier.size(14.dp)
                                        )
                                    }
                                }
                            }
                        }
                    } else {
                        Row(
                            modifier = Modifier.padding(start = 10.dp, end = 6.dp, top = 5.dp, bottom = 5.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            val statusLabel = when (state.state) {
                                "WORKING" -> "Working ▲"
                                "PAUSED" -> "Paused ▲"
                                "NEEDS_INPUT" -> "? Reply ▲"
                                "DONE" -> if (elapsedMs > 0L) {
                                    "✓ Done · ${formatElapsed(elapsedMs, true).removePrefix("Done ")} ▲"
                                } else {
                                    "✓ Done ▲"
                                }
                                else -> "○ Ready ▲"
                            }
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                modifier = Modifier
                                    .clip(RoundedCornerShape(50))
                                    .clickable(onClick = onToggleCollapse)
                                    .padding(horizontal = 4.dp, vertical = 3.dp)
                                    .testTag("simulator_dock_status_toggle")
                            ) {
                                Text(
                                    text = statusLabel,
                                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                    color = if (isNeedsInput || isPaused) CrispAmber else CrispInkPrimary
                                )
                            }
                            Box(
                                modifier = Modifier
                                    .width(1.dp)
                                    .height(16.dp)
                                    .background(CrispHairline)
                            )
                            Surface(
                                color = if (isNeedsInput) CrispAmber else CrispBlue,
                                shape = RoundedCornerShape(50),
                                modifier = Modifier
                                    .clip(RoundedCornerShape(50))
                                    .clickable(onClick = onOpenInput)
                                    .testTag("simulator_bottom_chat_pill")
                            ) {
                                Text(
                                    text = if (isNeedsInput) "✦ Reply" else "✦ Ask Agy",
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                    color = Color.White,
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun rotatingSweepBrush(
    colors: List<Color>,
    angleDegrees: Float
): ShaderBrush = object : ShaderBrush() {
    override fun createShader(size: Size): Shader {
        val cx = size.width / 2f
        val cy = size.height / 2f
        val shader = android.graphics.SweepGradient(
            cx,
            cy,
            colors.map { it.toArgb() }.toIntArray(),
            null
        )
        val matrix = android.graphics.Matrix().apply {
            setRotate(angleDegrees, cx, cy)
        }
        shader.setLocalMatrix(matrix)
        return shader
    }
}

@Composable
private fun StaggeredSandboxTaskRow(
    task: AgyHudOverlayManager.AgyHudTask,
    index: Int,
    isWorking: Boolean
) {
    val context = LocalContext.current
    val (marker, color) = when (task.status) {
        "done" -> "✓" to CrispEmerald
        "doing" -> "•" to CrispBlue
        "needs_input" -> "?" to CrispAmber
        else -> "○" to CrispInkMuted
    }
    val taskIcon = remember(context, task.icon, task.appPackage, task.label, task.detail) {
        AgyAppIconResolver.resolve(
            context = context,
            explicitIcon = task.icon,
            explicitPackage = task.appPackage,
            fallbackText = "${task.label} ${task.detail}"
        )
    }

    // Staggered entrance reveal (35ms per step row, 10dp slide up + fade)
    val entranceProgress = remember(task.id, task.label) { Animatable(0f) }
    LaunchedEffect(task.id, task.label) {
        delay((index * 35L).coerceAtMost(210L))
        entranceProgress.animateTo(
            targetValue = 1f,
            animationSpec = spring(dampingRatio = 0.82f, stiffness = 360f)
        )
    }

    // Emerald checkmark pop on completion
    val doneScale = remember(task.id) { Animatable(1f) }
    var prevStatus by remember(task.id) { mutableStateOf(task.status) }
    LaunchedEffect(task.status) {
        if (task.status == "done" && prevStatus != "done") {
            doneScale.snapTo(0.55f)
            doneScale.animateTo(
                targetValue = 1f,
                animationSpec = spring(dampingRatio = 0.45f, stiffness = 520f)
            )
        }
        prevStatus = task.status
    }

    val density = LocalDensity.current
    val slideOffsetPx = with(density) { (10.dp * (1f - entranceProgress.value)).toPx() }

    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier
            .fillMaxWidth()
            .graphicsLayer {
                alpha = entranceProgress.value
                translationY = slideOffsetPx
            }
            .then(
                if (task.status == "doing" || task.status == "needs_input") {
                    Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(color.copy(alpha = 0.07f))
                        .padding(horizontal = 6.dp, vertical = 5.dp)
                } else {
                    Modifier.padding(horizontal = 4.dp, vertical = 3.dp)
                }
            )
    ) {
        AgyComposeIconBadge(icon = taskIcon, size = 19.dp)
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = task.label,
                style = MaterialTheme.typography.labelSmall.copy(
                    fontSize = 11.5.sp,
                    fontWeight = if (task.status == "doing") FontWeight.SemiBold else FontWeight.Normal
                ),
                color = if (task.status == "done") CrispInkSecondary else CrispInkPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            if (task.detail.isNotBlank()) {
                Text(
                    text = task.detail,
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontFamily = JetBrainsMonoFamily,
                        fontSize = 9.5.sp
                    ),
                    color = CrispInkMuted,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
        if (task.status == "doing" && isWorking) {
            ComposeSpinnerRing(color = CrispBlue, size = 12.dp)
        } else {
            Text(
                text = marker,
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                color = color,
                modifier = Modifier.graphicsLayer {
                    scaleX = doneScale.value
                    scaleY = doneScale.value
                }
            )
        }
    }
}

@Composable
private fun AgyComposeIconBadge(
    icon: AgyAppIconResolver.ResolvedIcon,
    size: Dp
) {
    Canvas(modifier = Modifier.size(size)) {
        drawIntoCanvas { canvas ->
            AgyAppIconResolver.drawBadgeOnCanvas(
                canvas = canvas.nativeCanvas,
                width = this.size.width,
                height = this.size.height,
                icon = icon
            )
        }
    }
}

@Composable
private fun ComposeSpinnerRing(color: Color, size: Dp) {
    val infinite = rememberInfiniteTransition(label = "spinner_ring")
    val angle by infinite.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 900, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "spinner_angle"
    )
    Canvas(modifier = Modifier.size(size)) {
        val strokePx = 2.dp.toPx()
        val pad = strokePx * 0.6f
        val arcSize = Size(this.size.width - pad * 2f, this.size.height - pad * 2f)
        drawArc(
            color = color.copy(alpha = 0.16f),
            startAngle = 0f,
            sweepAngle = 360f,
            useCenter = false,
            topLeft = Offset(pad, pad),
            size = arcSize,
            style = Stroke(width = strokePx)
        )
        drawArc(
            color = color,
            startAngle = angle - 90f,
            sweepAngle = 250f,
            useCenter = false,
            topLeft = Offset(pad, pad),
            size = arcSize,
            style = Stroke(width = strokePx, cap = StrokeCap.Round)
        )
    }
}

@Composable
private fun ComposeSlidingLoadingBar(
    accentColor: Color = CrispBlue,
    trackColor: Color = Color(0xFFE2E8F0),
    modifier: Modifier = Modifier
) {
    val infinite = rememberInfiniteTransition(label = "loading_bar")
    val progress by infinite.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1250, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "bar_progress"
    )
    Canvas(
        modifier = modifier
            .height(3.5.dp)
            .clip(RoundedCornerShape(50))
    ) {
        val w = size.width
        val h = size.height
        val r = CornerRadius(h * 0.5f, h * 0.5f)
        drawRoundRect(color = trackColor, cornerRadius = r)
        val segW = w * 0.38f
        val startX = -segW + (w + segW) * progress
        val left = startX.coerceIn(0f, w)
        val right = (startX + segW).coerceIn(0f, w)
        if (right > left) {
            drawRoundRect(
                brush = Brush.horizontalGradient(
                    colors = listOf(accentColor, accentColor.copy(alpha = 0.72f)),
                    startX = left,
                    endX = right
                ),
                topLeft = Offset(left, 0f),
                size = Size(right - left, h),
                cornerRadius = r
            )
        }
    }
}

@Composable
private fun ComposeDeterminateLoadingBar(
    fraction: Float,
    accentColor: Color,
    trackColor: Color,
    modifier: Modifier = Modifier
) {
    val animatedFraction by animateFloatAsState(
        targetValue = fraction.coerceIn(0f, 1f),
        animationSpec = tween(durationMillis = 280, easing = FastOutSlowInEasing),
        label = "det_progress"
    )
    Canvas(
        modifier = modifier
            .height(4.dp)
            .clip(RoundedCornerShape(50))
    ) {
        val r = CornerRadius(size.height * 0.5f, size.height * 0.5f)
        drawRoundRect(color = trackColor, cornerRadius = r)
        val fillW = (size.width * animatedFraction).coerceAtLeast(if (animatedFraction > 0f) size.height else 0f)
        if (fillW > 0f) {
            drawRoundRect(
                color = accentColor,
                size = Size(fillW, size.height),
                cornerRadius = r
            )
        }
    }
}

@Composable
private fun SandboxBannerView(
    banner: com.kavach.ui.overlay.AgyHudDynamicModels.HudBannerConfig,
    isDark: Boolean
) {
    val (bg, border, fg) = when (banner.level.lowercase()) {
        "success" -> Triple(
            if (isDark) Color(0xFF064E3B) else Color(0xFFECFDF5),
            if (isDark) Color(0xFF047857) else Color(0xFFA7F3D0),
            if (isDark) Color(0xFFA7F3D0) else Color(0xFF065F46)
        )
        "warning" -> Triple(
            if (isDark) Color(0xFF451A03) else Color(0xFFFFFBEB),
            if (isDark) Color(0xFF92400E) else Color(0xFFFDE68A),
            if (isDark) Color(0xFFFDE68A) else Color(0xFFB45309)
        )
        "error" -> Triple(
            if (isDark) Color(0xFF450A0A) else Color(0xFFFEF2F2),
            if (isDark) Color(0xFF991B1B) else Color(0xFFFECACA),
            if (isDark) Color(0xFFFECACA) else Color(0xFFB91C1C)
        )
        else -> Triple(
            if (isDark) Color(0xFF172554) else Color(0xFFEFF6FF),
            if (isDark) Color(0xFF1D4ED8) else Color(0xFFBFDBFE),
            if (isDark) Color(0xFFBFDBFE) else Color(0xFF1E40AF)
        )
    }
    Surface(
        color = bg,
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(0.8.dp, border),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("simulator_dynamic_banner")
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp),
            verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            if (banner.title.isNotBlank()) {
                Text(
                    text = banner.title,
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = FontWeight.Bold,
                        fontSize = 10.5.sp
                    ),
                    color = fg
                )
            }
            if (banner.message.isNotBlank()) {
                Text(
                    text = banner.message,
                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.5.sp),
                    color = fg.copy(alpha = 0.92f)
                )
            }
        }
    }
}

@Composable
private fun SandboxContentBlockView(
    block: com.kavach.ui.overlay.AgyHudDynamicModels.HudContentBlock,
    secondarySurface: Color,
    borderColor: Color,
    textPrimary: Color,
    textSecondary: Color,
    defaultAccent: Color,
    isDark: Boolean
) {
    val blockAccent = com.kavach.ui.overlay.AgyHudDynamicModels
        .parseColorOrNull(block.accentColor)?.let { Color(it) } ?: defaultAccent
    Surface(
        color = if (block.type == "code") {
            if (isDark) Color(0xFF020617) else Color(0xFF0F172A)
        } else {
            secondarySurface
        },
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(0.75.dp, borderColor),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            if (block.title.isNotBlank()) {
                Text(
                    text = block.title,
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = FontWeight.Bold,
                        fontSize = 10.sp
                    ),
                    color = if (block.type == "code") Color(0xFF94A3B8) else blockAccent
                )
            }
            when (block.type) {
                "kv" -> {
                    block.items.forEach { (k, v) ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = k,
                                style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                                color = textSecondary
                            )
                            Text(
                                text = v,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontFamily = JetBrainsMonoFamily,
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 10.sp
                                ),
                                color = textPrimary
                            )
                        }
                    }
                }
                "code" -> {
                    Text(
                        text = block.body,
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontFamily = JetBrainsMonoFamily,
                            fontSize = 9.5.sp,
                            lineHeight = 13.sp
                        ),
                        color = Color(0xFFE2E8F0)
                    )
                }
                "progress" -> {
                    val pct = (block.progressValue ?: 0f).coerceIn(0f, 100f)
                    ComposeDeterminateLoadingBar(
                        fraction = pct / 100f,
                        accentColor = blockAccent,
                        trackColor = borderColor,
                        modifier = Modifier.fillMaxWidth()
                    )
                    if (block.body.isNotBlank()) {
                        Text(
                            text = "${block.body} (${pct.toInt()}%)",
                            style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                            color = textSecondary
                        )
                    }
                }
                else -> {
                    if (block.body.isNotBlank()) {
                        Text(
                            text = block.body,
                            style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.5.sp),
                            color = textPrimary
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ComposeBouncingDots(color: Color) {
    val infinite = rememberInfiniteTransition(label = "bouncing_dots")
    val phase by infinite.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 960, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "dots_phase"
    )
    Canvas(modifier = Modifier.size(width = 24.dp, height = 14.dp)) {
        val r = 2.dp.toPx()
        val spacing = 6.5.dp.toPx()
        val baseY = size.height * 0.62f
        val lift = 3.2.dp.toPx()
        val startX = (size.width - spacing * 2f) * 0.5f
        for (i in 0 until 3) {
            val dotPhase = (phase + i * 0.22f) % 1f
            val wave = sin(dotPhase * 2.0 * PI).toFloat().coerceAtLeast(0f)
            val cy = baseY - wave * lift
            drawCircle(
                color = color.copy(alpha = (0.45f + 0.55f * wave).coerceIn(0.45f, 1f)),
                radius = r,
                center = Offset(startX + i * spacing, cy)
            )
        }
    }
}

@Composable
private fun SandboxWireframeCanvas(watch: AgyHudOverlayManager.ScreenWatchState) {
    val infinite = rememberInfiniteTransition(label = "wf_anim")
    val phase by infinite.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "wf_phase"
    )
    Canvas(
        modifier = Modifier
            .size(width = 48.dp, height = 88.dp)
    ) {
        val pad = 2.dp.toPx()
        val w = (size.width - pad * 2).coerceAtLeast(1f)
        val h = (size.height - pad * 2).coerceAtLeast(1f)
        drawRoundRect(
            color = Color(0xFFFFFFFF),
            topLeft = Offset(pad, pad),
            size = Size(w, h),
            cornerRadius = CornerRadius(8.dp.toPx(), 8.dp.toPx())
        )
        drawRoundRect(
            color = Color(0xFFCBD5E1),
            topLeft = Offset(pad, pad),
            size = Size(w, h),
            cornerRadius = CornerRadius(8.dp.toPx(), 8.dp.toPx()),
            style = Stroke(width = 1.2.dp.toPx())
        )

        val sw = watch.screenWidth.coerceAtLeast(1).toFloat()
        val sh = watch.screenHeight.coerceAtLeast(1).toFloat()
        val inset = 4.dp.toPx()
        val iw = (w - inset * 2).coerceAtLeast(1f)
        val ih = (h - inset * 2).coerceAtLeast(1f)
        fun mx(x: Float) = pad + inset + (x / sw).coerceIn(0f, 1f) * iw
        fun my(y: Float) = pad + inset + (y / sh).coerceIn(0f, 1f) * ih

        watch.zones.take(6).forEach { z ->
            val l = mx(min(z.x1, z.x2))
            val t = my(min(z.y1, z.y2))
            val r = max(l + 4.dp.toPx(), mx(max(z.x1, z.x2)))
            val b = max(t + 4.dp.toPx(), my(max(z.y1, z.y2)))
            val isTarget = z.role.contains("target", true) || z.role.contains("focus", true)
            val isAction = z.role.contains("button", true) || z.role.contains("input", true)
            val stroke = when {
                isTarget -> CrispAmber
                isAction -> CrispBlue
                else -> Color(0xFF94A3B8)
            }
            drawRoundRect(
                color = stroke.copy(alpha = 0.16f),
                topLeft = Offset(l, t),
                size = Size(r - l, b - t),
                cornerRadius = CornerRadius(3.dp.toPx(), 3.dp.toPx())
            )
            drawRoundRect(
                color = stroke,
                topLeft = Offset(l, t),
                size = Size(r - l, b - t),
                cornerRadius = CornerRadius(3.dp.toPx(), 3.dp.toPx()),
                style = Stroke(width = 1.dp.toPx())
            )
        }

        watch.actionVector?.let { vec ->
            val sx = mx(vec.x1)
            val sy = my(vec.y1)
            if (vec.type.equals("SWIPE", true) || vec.type.equals("DRAG", true)) {
                val ex = mx(vec.x2)
                val ey = my(vec.y2)
                drawLine(
                    color = CrispBlue,
                    start = Offset(sx, sy),
                    end = Offset(ex, ey),
                    strokeWidth = 1.6.dp.toPx(),
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 4f), 0f)
                )
                val angle = atan2((ey - sy).toDouble(), (ex - sx).toDouble())
                val head = 5.dp.toPx()
                val arrow = Path().apply {
                    moveTo(ex, ey)
                    lineTo((ex - head * cos(angle - 0.5)).toFloat(), (ey - head * sin(angle - 0.5)).toFloat())
                    lineTo((ex - head * cos(angle + 0.5)).toFloat(), (ey - head * sin(angle + 0.5)).toFloat())
                    close()
                }
                drawPath(arrow, color = CrispAmber)
                val bx = sx + (ex - sx) * phase
                val by = sy + (ey - sy) * phase
                drawCircle(color = CrispBlue, radius = 3.dp.toPx(), center = Offset(bx, by))
            } else {
                drawCircle(
                    color = CrispBlue.copy(alpha = (1f - phase).coerceIn(0.15f, 0.9f)),
                    radius = (3f + phase * 8f).dp.toPx(),
                    center = Offset(sx, sy),
                    style = Stroke(width = 1.4.dp.toPx())
                )
                drawCircle(color = CrispAmber, radius = 2.6.dp.toPx(), center = Offset(sx, sy))
            }
        }
    }
}

@Composable
private fun MiniHudChip(
    symbol: String,
    active: Boolean = false,
    bgColor: Color = if (active) Color(0xFFE0F2FE) else Color(0xFFF3F4F6),
    tintColor: Color = if (active) CrispBlue else CrispInkSecondary,
    onClick: () -> Unit
) {
    Surface(
        color = bgColor,
        shape = CircleShape,
        modifier = Modifier
            .size(26.dp)
            .clip(CircleShape)
            .clickable(onClick = onClick)
    ) {
        Box(contentAlignment = Alignment.Center) {
            Text(
                text = symbol,
                fontSize = 11.5.sp,
                fontWeight = FontWeight.SemiBold,
                color = tintColor
            )
        }
    }
}

@Composable
private fun HudTrayPill(
    label: String,
    active: Boolean,
    accent: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        color = Color.White,
        shape = RoundedCornerShape(50),
        border = BorderStroke(0.75.dp, if (active) accent.copy(alpha = 0.35f) else Color(0xFFE5E7EB)),
        modifier = modifier
            .clip(RoundedCornerShape(50))
            .clickable(onClick = onClick)
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 5.dp)
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall.copy(
                    fontSize = 10.sp,
                    fontWeight = FontWeight.SemiBold
                ),
                color = if (active) accent else CrispInkSecondary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun SimChip(label: String, tint: Color, tag: String, onClick: () -> Unit) {
    Surface(
        color = Color(0xFFF5F6F8),
        shape = RoundedCornerShape(50),
        border = BorderStroke(0.85.dp, Color(0xFFE8ECF1)),
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .clickable(onClick = onClick)
            .testTag(tag)
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
            color = tint,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp)
        )
    }
}

private fun buildIdlePayload(note: String): JSONObject = JSONObject().apply {
    put("state", "IDLE")
    put("title", "Agy Ready")
    put("icon", "spark_ai")
    put("currentAction", note)
    put("nextAction", "")
    put("question", "")
    put("autoCollapseSeconds", 3)
    put("detailedOutput", "")
    put("outputLogs", JSONArray())
    put("tasks", JSONArray())
    put("screenWatch", JSONObject().put("active", false))
}

private fun buildWorkingPayload(title: String): JSONObject = JSONObject().apply {
    put("state", "WORKING")
    put("title", title)
    put("icon", "youtube")
    put("appPackage", "com.google.android.youtube")
    put("currentAction", "Opening YouTube & preparing Termux bridge")
    put("nextAction", "Search target video & inspect playback UI")
    put("question", "")
    put("autoCollapseSeconds", 4)
    put("detailedOutput", "Launching multi-app automation pipeline across Termux, YouTube, and Chrome.")
    put("outputLogs", JSONArray().apply {
        put("[00:00.4] Termux: Loaded ~/.aura_token (200 OK)")
        put("[00:01.1] YouTube: Launching com.google.android.youtube")
    })
    put("tasks", JSONArray().apply {
        put(JSONObject().put("id", "s1").put("label", "Verify Termux bridge token").put("status", "done").put("icon", "termux").put("detail", "127.0.0.1:8080"))
        put(JSONObject().put("id", "s2").put("label", "Open YouTube & search playlist").put("status", "doing").put("icon", "youtube").put("appPackage", "com.google.android.youtube").put("detail", "Query: Lo-Fi Coding Beats"))
        put(JSONObject().put("id", "s3").put("label", "Verify stream metadata in Chrome").put("status", "pending").put("icon", "chrome"))
        put(JSONObject().put("id", "s4").put("label", "Send summary link via WhatsApp").put("status", "pending").put("icon", "whatsapp"))
    })
    put("screenWatch", JSONObject().put("active", false))
}

private fun buildTapWatchPayload(title: String): JSONObject = JSONObject().apply {
    put("state", "WORKING")
    put("title", title)
    put("icon", "youtube")
    put("appPackage", "com.google.android.youtube")
    put("currentAction", "Tapping YouTube Play CTA (pass-through safe)")
    put("nextAction", "Capture stream URL & verify in Chrome")
    put("question", "")
    put("autoCollapseSeconds", 4)
    put("detailedOutput", "Located top YouTube search result 'Lofi Hip Hop Radio — Beats to Code To'. Targeting Play button at [830, 1005] with 300ms HUD collision pass-through.")
    put("outputLogs", JSONArray().apply {
        put("[00:00.4] Termux: Loaded ~/.aura_token (200 OK)")
        put("[00:01.1] YouTube: Opened search bar & typed query")
        put("[00:02.3] UI Tree: Found 4 key zones (agy_hud_ excluded)")
        put("[00:02.6] Tap: Dispatched [830, 1005] -> Play")
    })
    put("tasks", JSONArray().apply {
        put(JSONObject().put("id", "s1").put("label", "Verify Termux bridge token").put("status", "done").put("icon", "termux"))
        put(JSONObject().put("id", "s2").put("label", "Tap Play in YouTube").put("status", "doing").put("icon", "youtube").put("appPackage", "com.google.android.youtube").put("detail", "Reticle [830, 1005]"))
        put(JSONObject().put("id", "s3").put("label", "Verify stream metadata in Chrome").put("status", "pending").put("icon", "chrome"))
        put(JSONObject().put("id", "s4").put("label", "Send summary link via WhatsApp").put("status", "pending").put("icon", "whatsapp"))
    })
    put("screenWatch", JSONObject().apply {
        put("active", true)
        put("label", "YouTube • Tap Play")
        put("screenWidth", 1080)
        put("screenHeight", 2400)
        put("zones", JSONArray().apply {
            put(JSONObject().put("x1", 60).put("y1", 160).put("x2", 1020).put("y2", 320).put("role", "header").put("tag", "YouTube"))
            put(JSONObject().put("x1", 80).put("y1", 460).put("x2", 1000).put("y2", 620).put("role", "input").put("tag", "Search"))
            put(JSONObject().put("x1", 660).put("y1", 920).put("x2", 1000).put("y2", 1090).put("role", "target").put("tag", "Play"))
            put(JSONObject().put("x1", 80).put("y1", 1220).put("x2", 1000).put("y2", 1740).put("role", "panel").put("tag", "Up Next"))
        })
        put("actionVector", JSONObject().put("type", "TAP").put("x1", 830).put("y1", 1005).put("x2", 830).put("y2", 1005))
    })
}

private fun buildSwipeWatchPayload(title: String): JSONObject = JSONObject().apply {
    put("state", "WORKING")
    put("title", title)
    put("icon", "chrome")
    put("appPackage", "com.android.chrome")
    put("currentAction", "Scrolling Chrome article & preparing WhatsApp share")
    put("nextAction", "Ask confirmation before sending message")
    put("question", "")
    put("autoCollapseSeconds", 4)
    put("detailedOutput", "Extracted video title, duration (LIVE), and clean share link in Chrome. Ready to draft WhatsApp share card.")
    put("outputLogs", JSONArray().apply {
        put("[00:00.4] Termux: Loaded ~/.aura_token (200 OK)")
        put("[00:02.6] YouTube: Playback started cleanly")
        put("[00:03.9] Chrome: Swiped feed [540,1820 -> 540,620]")
        put("[00:04.5] Parser: Captured clean URL & metadata")
    })
    put("tasks", JSONArray().apply {
        put(JSONObject().put("id", "s1").put("label", "Verify Termux bridge token").put("status", "done").put("icon", "termux"))
        put(JSONObject().put("id", "s2").put("label", "Open YouTube & start playback").put("status", "done").put("icon", "youtube"))
        put(JSONObject().put("id", "s3").put("label", "Scroll Chrome & extract summary").put("status", "doing").put("icon", "chrome").put("detail", "Swipe up gesture"))
        put(JSONObject().put("id", "s4").put("label", "Send summary link via WhatsApp").put("status", "pending").put("icon", "whatsapp"))
    })
    put("screenWatch", JSONObject().apply {
        put("active", true)
        put("label", "Chrome • Swipe Up")
        put("screenWidth", 1080)
        put("screenHeight", 2400)
        put("zones", JSONArray().apply {
            put(JSONObject().put("x1", 60).put("y1", 180).put("x2", 1020).put("y2", 340).put("role", "header").put("tag", "Chrome"))
            put(JSONObject().put("x1", 80).put("y1", 460).put("x2", 1000).put("y2", 1180).put("role", "panel").put("tag", "Article"))
            put(JSONObject().put("x1", 80).put("y1", 1260).put("x2", 1000).put("y2", 1980).put("role", "button").put("tag", "Share"))
        })
        put("actionVector", JSONObject().put("type", "SWIPE").put("x1", 540).put("y1", 1820).put("x2", 540).put("y2", 620))
    })
}

private fun buildNeedsInputPayload(): JSONObject = JSONObject().apply {
    put("state", "NEEDS_INPUT")
    put("title", "Confirm WhatsApp Share")
    put("icon", "whatsapp")
    put("appPackage", "com.whatsapp")
    put("currentAction", "Waiting for your confirmation...")
    put("nextAction", "Send message & complete workflow")
    put("question", "Share the YouTube link to your Dev Group on WhatsApp?")
    put("autoCollapseSeconds", 4)
    put("detailedOutput", "Draft message ready:\n\"Now playing: Lofi Hip Hop Radio — Beats to Code To (YouTube Live)\"")
    put("outputLogs", JSONArray().apply {
        put("[00:02.6] YouTube: Playback verified")
        put("[00:04.5] Chrome: Extracted title & canonical URL")
        put("[00:05.1] WhatsApp: Paused for user confirmation")
    })
    put("quickActions", JSONArray().apply {
        put(JSONObject().put("label", "Yes, send it").put("commandText", "Yes, send on WhatsApp").put("actionType", "PROMPT"))
        put(JSONObject().put("label", "Skip share").put("commandText", "Skip WhatsApp share").put("actionType", "PROMPT"))
        put(JSONObject().put("label", "Cancel").put("commandText", "STOP").put("actionType", "STOP"))
    })
    put("tasks", JSONArray().apply {
        put(JSONObject().put("id", "s1").put("label", "Verify Termux bridge token").put("status", "done").put("icon", "termux"))
        put(JSONObject().put("id", "s2").put("label", "Play stream on YouTube").put("status", "done").put("icon", "youtube"))
        put(JSONObject().put("id", "s3").put("label", "Confirm WhatsApp share").put("status", "needs_input").put("icon", "whatsapp"))
    })
    put("screenWatch", JSONObject().put("active", false))
}

private fun buildDonePayload(summary: String): JSONObject = JSONObject().apply {
    put("state", "DONE")
    put("title", "Workflow Completed")
    put("icon", "youtube")
    put("appPackage", "com.google.android.youtube")
    put("currentAction", summary)
    put("nextAction", "")
    put("question", "")
    put("autoCollapseSeconds", 5)
    put(
        "detailedOutput",
        "Result Summary:\n" +
            "• YouTube: 'Lofi Hip Hop Radio — Beats to Code To' playing smoothly.\n" +
            "• Chrome: Metadata verified (1080p60, live stream active).\n" +
            "• WhatsApp: Share link delivered cleanly.\n" +
            "• Safety: 0 overlay collisions; agy_hud_ nodes 100% self-excluded."
    )
    put("outputLogs", JSONArray().apply {
        put("[00:00.4] Termux: Auth verified via ~/.aura_token")
        put("[00:01.2] YouTube: Launched & searched target stream")
        put("[00:02.6] Tap: Clicked Play at [830, 1005] (pass-through OK)")
        put("[00:04.1] Chrome: Verified canonical share metadata")
        put("[00:05.8] WhatsApp: Delivered summary • exit code 0")
    })
    put("tasks", JSONArray().apply {
        put(JSONObject().put("id", "s1").put("label", "Verify Termux bridge token").put("status", "done").put("icon", "termux"))
        put(JSONObject().put("id", "s2").put("label", "Play stream on YouTube").put("status", "done").put("icon", "youtube"))
        put(JSONObject().put("id", "s3").put("label", "Verify stream metadata in Chrome").put("status", "done").put("icon", "chrome"))
        put(JSONObject().put("id", "s4").put("label", "Send summary link via WhatsApp").put("status", "done").put("icon", "whatsapp"))
    })
    put("screenWatch", JSONObject().put("active", false))
}

private fun buildDynamicDarkPayload(): JSONObject = JSONObject().apply {
    put("state", "WORKING")
    put("statusLabel", "Deploying")
    put("customEmoji", "🚀")
    put("title", "Termux APK Build & Push")
    put("currentAction", "Uploading signed release bundle to staging")
    put("theme", JSONObject().apply {
        put("mode", "dark")
        put("accentColor", "#38BDF8")
        put("auroraColors", JSONArray().apply {
            put("#38BDF8")
            put("#8B5CF6")
            put("#EC4899")
        })
        put("cornerRadiusDp", 22)
    })
    put("layout", JSONObject().apply {
        put("detailsExpanded", true)
        put("inputPlaceholder", "Send override command to build…")
    })
    put("progress", JSONObject().apply {
        put("visible", true)
        put("value", 62)
        put("label", "Uploading chunks (7/12)")
        put("color", "#38BDF8")
    })
    put("metrics", JSONArray().apply {
        put(JSONObject().put("id", "cpu").put("label", "CPU").put("value", "38%").put("accentColor", "#38BDF8"))
        put(JSONObject().put("id", "files").put("label", "Files").put("value", "7/12").put("accentColor", "#A78BFA"))
        put(JSONObject().put("id", "lat").put("label", "Ping").put("value", "48ms").put("accentColor", "#34D399"))
    })
    put("banner", JSONObject().apply {
        put("visible", true)
        put("level", "info")
        put("title", "Dynamic Agy Theme Active")
        put("message", "Tap Stop once for Stopping, tap again to Force-Stop.")
    })
    put("blocks", JSONArray().apply {
        put(JSONObject().apply {
            put("id", "env")
            put("type", "kv")
            put("title", "Target")
            put("items", JSONArray().apply {
                put(JSONObject().put("key", "Branch").put("value", "main"))
                put(JSONObject().put("key", "Artifact").put("value", "app-release.apk"))
            })
        })
        put(JSONObject().apply {
            put("id", "cmd_log")
            put("type", "code")
            put("title", "Shell")
            put("body", "$ gradle assembleRelease --parallel\n> Task :app:packageRelease OK")
            put("inDetails", true)
        })
    })
    put("quickActions", JSONArray().apply {
        put(JSONObject()
            .put("id", "btn_retry")
            .put("label", "Boost Workers")
            .put("style", "primary")
            .put("actionType", "CUSTOM")
            .put("payload", JSONObject().put("workers", 8)))
        put(JSONObject()
            .put("id", "btn_abort")
            .put("label", "Abort")
            .put("style", "danger")
            .put("actionType", "STOP"))
    })
    put("tasks", JSONArray().apply {
        put(JSONObject().put("id", "d1").put("label", "Compile Kotlin sources").put("status", "done").put("icon", "termux"))
        put(JSONObject().put("id", "d2").put("label", "Upload bundle to staging").put("status", "doing").put("icon", "chrome"))
    })
    put("screenWatch", JSONObject().put("active", false))
}

