package com.kavach.presentation.dashboard

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.ClearAll
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Devices
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Key
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.KeyboardArrowUp
import androidx.compose.material.icons.rounded.Laptop
import androidx.compose.material.icons.rounded.Link
import androidx.compose.material.icons.rounded.LinkOff
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Router
import androidx.compose.material.icons.rounded.Security
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material.icons.rounded.Terminal
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.kavach.aeroshare.models.AeroDevice
import com.kavach.capabilities.permissions.PermissionAlertEvent
import com.kavach.capabilities.permissions.PermissionManager
import com.kavach.domain.model.SessionState
import com.kavach.presentation.permissions.PermissionsManagerDialog
import com.kavach.security.AuraSecurityShield
import com.kavach.security.PairedClient
import com.kavach.security.PendingPairRequest
import com.kavach.services.RealtimeConnectionService
import com.kavach.ui.theme.CrispAmber
import com.kavach.ui.theme.CrispBg
import com.kavach.ui.theme.CrispBlue
import com.kavach.ui.theme.CrispBorder
import com.kavach.ui.theme.CrispEmerald
import com.kavach.ui.theme.CrispHairline
import com.kavach.ui.theme.CrispIndigo
import com.kavach.ui.theme.CrispInkPrimary
import com.kavach.ui.theme.CrispInkSecondary
import com.kavach.ui.theme.CrispPillSwitch
import com.kavach.ui.theme.CrispRose
import com.kavach.ui.theme.CrispSurface
import com.kavach.ui.theme.CrispSurfaceSubtle
import com.kavach.ui.theme.JetBrainsMonoFamily
import com.kavach.ui.theme.LiquidGlassCard
import com.kavach.ui.theme.LiquidGlassTokens
import com.kavach.ui.theme.LiquidIconOrb
import com.kavach.ui.theme.liquidObsidianBackground

internal val ConsoleBg = CrispBg
internal val CardBg = CrispSurface
internal val CardElevatedBg = CrispSurfaceSubtle
internal val BorderSubtleColor = CrispHairline
internal val EmeraldAccent = CrispEmerald
internal val CyanAccent = CrispBlue
internal val AmberAccent = CrispAmber
internal val PurpleAccent = CrispIndigo
internal val CoralError = CrispRose
internal val TextPrimaryColor = CrispInkPrimary
internal val TextSecondaryColor = CrispInkSecondary

private val DeepOledBg = LiquidGlassTokens.ObsidianVoid
private val GlassSurface = LiquidGlassTokens.GlassCardFill
private val GlassInner = LiquidGlassTokens.GlassCapsuleFill
private val GlassPillInput = LiquidGlassTokens.GlassPillInputFill
private val HairlineBorder = CrispHairline

@Composable
fun DashboardScreen(
    onNavigateToSettings: () -> Unit = {},
    onNavigateToDeveloper: () -> Unit = {},
    onNavigateToSpeechDiagnostics: () -> Unit = {},
    onNavigateToConversationEngine: () -> Unit = {},
    onNavigateToTimeline: () -> Unit = {},
    viewModel: DashboardViewModel
) {
    val wsState by viewModel.wsConnectionState.collectAsState()
    val activeUrl by viewModel.activeUrl.collectAsState()
    val latencyMs by viewModel.latencyMs.collectAsState()
    val vaultSummary by viewModel.vaultUiSummary.collectAsState()
    val logs by viewModel.connectionLogs.collectAsState()
    val lastFailure by viewModel.lastFailureReason.collectAsState()
    val lastCommandOutput by viewModel.lastCommandOutput.collectAsState()

    val isAppHidden by viewModel.isAppHidden.collectAsState()
    val isAgyHudActive by viewModel.isAgyHudActive.collectAsState()
    val agyMacros by viewModel.agyMacros.collectAsState()
    val agyRunHistory by viewModel.agyRunHistory.collectAsState()
    val runHistoryQuery by viewModel.runHistoryQuery.collectAsState()
    val isSyntheticIconForced by viewModel.isSyntheticIconForced.collectAsState()
    val authMode by viewModel.authMode.collectAsState()
    val isPanicLockdown by viewModel.isPanicLockdown.collectAsState()
    val pairingCode by viewModel.pairingCode.collectAsState()
    val pairedDevices by viewModel.pairedDevices.collectAsState()
    val pendingPairRequests by viewModel.pendingPairRequests.collectAsState()
    val discoveredPeers by viewModel.discoveredPeers.collectAsState()

    val context = LocalContext.current
    val permissionManager = remember(context) { PermissionManager(context.applicationContext) }

    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                viewModel.refreshStates()
                viewModel.refreshConnectedDevices()
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    var urlInput by remember { mutableStateOf(activeUrl) }
    var isEditingRelayDraft by remember { mutableStateOf(false) }
    LaunchedEffect(activeUrl) {
        if (!isEditingRelayDraft) {
            urlInput = activeUrl
        }
    }
    var selectedLogFilter by remember { mutableStateOf("ALL") }
    var shellInput by remember { mutableStateOf("") }
    var showShellInput by remember { mutableStateOf(false) }
    var showPermissionsDialog by remember { mutableStateOf(false) }
    var showAudioStationDialog by remember { mutableStateOf(false) }
    var showHudSimulatorDialog by remember { mutableStateOf(false) }
    var activePermissionAlert by remember { mutableStateOf<PermissionAlertEvent?>(null) }

    val dynamicPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { _ ->
        activePermissionAlert = null
    }

    LaunchedEffect(viewModel.permissionAlerts) {
        viewModel.permissionAlerts.collect { alert ->
            activePermissionAlert = alert
        }
    }

    if (showPermissionsDialog) {
        PermissionsManagerDialog(
            onDismissRequest = { showPermissionsDialog = false },
            permissionManager = permissionManager,
            onOpenMicStation = {
                showPermissionsDialog = false
                showAudioStationDialog = true
            }
        )
    }

    if (showAudioStationDialog) {
        AudioStationDialog(
            onDismissRequest = { showAudioStationDialog = false },
            viewModel = viewModel
        )
    }

    if (showHudSimulatorDialog) {
        val simHudManager = viewModel.agyHudOverlayManager ?: remember(context) {
            val appCtx = context.applicationContext
            com.kavach.ui.overlay.AgyHudOverlayManager(
                context = appCtx,
                floatingOverlayManager = com.kavach.ui.overlay.FloatingOverlayManager(appCtx)
            )
        }
        AgyHudSimulatorDialog(
            hudManager = simHudManager,
            onDismissRequest = { showHudSimulatorDialog = false }
        )
    }

    activePermissionAlert?.let { alert ->
        AlertDialog(
            onDismissRequest = { activePermissionAlert = null },
            containerColor = LiquidGlassTokens.GlassModalFill,
            shape = RoundedCornerShape(24.dp),
            modifier = Modifier.testTag("permission_warning_alert_dialog"),
            title = {
                Text(
                    text = alert.featureName,
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = AmberAccent
                )
            },
            text = {
                Text(
                    text = alert.reasonMessage,
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextPrimaryColor
                )
            },
            confirmButton = {
                Button(
                    onClick = { dynamicPermissionLauncher.launch(alert.permission) },
                    shape = RoundedCornerShape(50),
                    colors = ButtonDefaults.buttonColors(containerColor = CyanAccent, contentColor = Color.White),
                    modifier = Modifier.testTag("grant_permission_popup_button")
                ) { Text("Grant", fontWeight = FontWeight.Bold) }
            },
            dismissButton = {
                TextButton(
                    onClick = { activePermissionAlert = null },
                    modifier = Modifier.testTag("dismiss_permission_popup_button")
                ) { Text("Dismiss", color = TextSecondaryColor) }
            }
        )
    }

    val isWsConnected = wsState == SessionState.ConnectionState.CONNECTED
    val isWsConnecting = wsState == SessionState.ConnectionState.CONNECTING ||
            wsState == SessionState.ConnectionState.RECONNECTING ||
            wsState == SessionState.ConnectionState.AUTHENTICATING

    val filteredLogs = remember(logs, selectedLogFilter) {
        if (selectedLogFilter == "ALL") {
            logs
        } else {
            logs.filter { entry ->
                when (selectedLogFilter) {
                    "HTTP" -> entry.contains("HTTP", ignoreCase = true)
                    "WS" -> entry.contains("WS", ignoreCase = true) ||
                            entry.contains("WebSocket", ignoreCase = true) ||
                            entry.contains("Termux", ignoreCase = true)
                    "SHELL" -> entry.contains("SHELL", ignoreCase = true)
                    "SYS" -> entry.contains("SYSTEM", ignoreCase = true) ||
                            entry.contains("SECURITY", ignoreCase = true) ||
                            entry.contains("DEVICE", ignoreCase = true) ||
                            entry.contains("APP_VISIBILITY", ignoreCase = true)
                    else -> true
                }
            }
        }
    }

    Scaffold(
        containerColor = DeepOledBg,
        contentWindowInsets = WindowInsets(0, 0, 0, 0)
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .liquidObsidianBackground(
                    primaryAura = if (isWsConnected) EmeraldAccent else CyanAccent,
                    secondaryAura = PurpleAccent
                )
                .padding(innerPadding)
                .windowInsetsPadding(WindowInsets.safeDrawing),
            contentAlignment = Alignment.TopCenter
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 600.dp)
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp, vertical = 14.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                CompactHeaderBar(
                    wsState = wsState,
                    latencyMs = latencyMs,
                    onOpenPermissions = { showPermissionsDialog = true },
                    onRefreshAll = {
                        viewModel.refreshStates()
                        viewModel.refreshConnectedDevices()
                    }
                )

                AgyHudHeroCard(
                    isAgyHudActive = isAgyHudActive,
                    onToggleAgyHud = {
                        val ok = viewModel.toggleAgyHud(context)
                        if (!ok) {
                            Toast.makeText(
                                context,
                                "Enable 'Display over other apps' for Agy HUD",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    },
                    onOpenHudSimulator = { showHudSimulatorDialog = true }
                )

                AgyStudioCard(
                    macros = agyMacros,
                    runHistory = agyRunHistory,
                    searchQuery = runHistoryQuery,
                    onSearchQueryChange = { viewModel.updateRunHistoryQuery(it) },
                    onRunMacro = { macro ->
                        viewModel.runAgyMacro(macro)
                        Toast.makeText(context, "Dispatched: ${macro.title}", Toast.LENGTH_SHORT).show()
                    },
                    onSaveMacro = { id, title, prompt, iconHint, isPinned ->
                        viewModel.saveAgyMacro(id, title, prompt, iconHint, isPinned)
                    },
                    onToggleMacroPin = { macro ->
                        viewModel.toggleAgyMacroPin(macro)
                    },
                    onDeleteMacro = { id ->
                        viewModel.deleteAgyMacro(id)
                    },
                    onReplayRun = { run ->
                        viewModel.replayAgyRun(run)
                        Toast.makeText(context, "Replaying: ${run.title}", Toast.LENGTH_SHORT).show()
                    },
                    onCopyRunOutput = { text ->
                        viewModel.updateClipboard(text)
                        Toast.makeText(context, "Output copied", Toast.LENGTH_SHORT).show()
                    },
                    onDeleteRun = { id ->
                        viewModel.deleteAgyRun(id)
                    },
                    onClearHistory = {
                        viewModel.clearAgyRunHistory()
                    }
                )

                CompactBridgeBar(
                    urlInput = urlInput,
                    onUrlChange = { updated ->
                        isEditingRelayDraft = true
                        urlInput = updated
                    },
                    isConnected = isWsConnected,
                    isConnecting = isWsConnecting,
                    lastFailure = lastFailure,
                    onConnect = {
                        isEditingRelayDraft = false
                        viewModel.connectToServer(context, urlInput)
                    },
                    onDisconnect = {
                        isEditingRelayDraft = false
                        viewModel.disconnectServer(context)
                    }
                )

                CompactVaultTimelineBar(
                    vaultSummary = vaultSummary,
                    onOpenTimeline = onNavigateToTimeline
                )

                CompactSettingsPanel(
                    localEndpoint = "${viewModel.localIpAddress}:8080",
                    isAppHidden = isAppHidden,
                    isSyntheticIconForced = isSyntheticIconForced,
                    authMode = authMode,
                    isPanicLockdown = isPanicLockdown,
                    pairingCode = pairingCode,
                    onToggleAppHidden = { hide ->
                        if (viewModel.toggleAppHidden(hide)) {
                            Toast.makeText(
                                context,
                                if (hide) "Hidden" else "Visible",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    },
                    onCopyAdbFix = {
                        viewModel.updateClipboard(com.kavach.util.AppVisibilityManager.ADB_HIDE_SYNTHETIC_CMD)
                        Toast.makeText(context, "ADB command copied", Toast.LENGTH_SHORT).show()
                    },
                    onSelectAuthMode = { viewModel.setAuthMode(it) },
                    onTogglePanicLockdown = { viewModel.togglePanicLockdown(it) },
                    onRegenerateCode = {
                        viewModel.regeneratePairingCode()
                        Toast.makeText(context, "Code rotated", Toast.LENGTH_SHORT).show()
                    },
                    onCopyToken = {
                        viewModel.updateClipboard(viewModel.getMasterToken())
                        Toast.makeText(context, "Copied", Toast.LENGTH_SHORT).show()
                    },
                    onRotateKeys = {
                        viewModel.rotateSecurityKeys()
                        Toast.makeText(context, "Keys rotated & devices revoked", Toast.LENGTH_SHORT).show()
                    },
                    onExportScripts = {
                        viewModel.exportServerScripts()
                        Toast.makeText(context, "Exported (+ agy_hud_daemon.py)", Toast.LENGTH_SHORT).show()
                    },
                    onOpenPermissions = { showPermissionsDialog = true }
                )

                CompactDevicesPanel(
                    wsState = wsState,
                    bridgeUrl = activeUrl,
                    latencyMs = latencyMs,
                    pairedDevices = pairedDevices,
                    pendingRequests = pendingPairRequests,
                    discoveredPeers = discoveredPeers,
                    onRefresh = { viewModel.refreshConnectedDevices() },
                    onRevokeDevice = { deviceId ->
                        viewModel.revokePairedDevice(deviceId)
                        Toast.makeText(context, "Revoked", Toast.LENGTH_SHORT).show()
                    },
                    onApproveRequest = { viewModel.approvePairRequest(it) },
                    onDenyRequest = { viewModel.denyPairRequest(it) }
                )

                CompactLogsPanel(
                    logs = filteredLogs,
                    totalLogCount = logs.size,
                    selectedFilter = selectedLogFilter,
                    onFilterSelect = { selectedLogFilter = it },
                    showShellInput = showShellInput,
                    onToggleShellInput = { showShellInput = !showShellInput },
                    shellInput = shellInput,
                    onShellInputChange = { shellInput = it },
                    lastCommandOutput = lastCommandOutput,
                    onDismissCommandOutput = { viewModel.clearCommandOutput() },
                    onExecuteCommand = {
                        if (shellInput.isNotBlank()) {
                            viewModel.executeConsoleCommand(shellInput)
                            shellInput = ""
                        }
                    },
                    onClearLogs = { viewModel.clearLogs() }
                )
            }
        }
    }
}

/**
 * Crisp Light Mode elevated white card with subtle 1dp hairline border.
 */
@Composable
private fun GlassPanel(
    modifier: Modifier = Modifier,
    borderColor: Color = HairlineBorder,
    secondaryBorderColor: Color = HairlineBorder,
    content: @Composable () -> Unit
) {
    LiquidGlassCard(
        modifier = modifier,
        accentTint = borderColor,
        secondaryTint = secondaryBorderColor,
        shape = RoundedCornerShape(24.dp),
        containerColor = GlassSurface
    ) {
        content()
    }
}

@Composable
private fun CompactHeaderBar(
    wsState: SessionState.ConnectionState,
    latencyMs: Long,
    onOpenPermissions: () -> Unit,
    onRefreshAll: () -> Unit
) {
    val (statusText, statusColor) = when (wsState) {
        SessionState.ConnectionState.CONNECTED -> "Live" to EmeraldAccent
        SessionState.ConnectionState.CONNECTING,
        SessionState.ConnectionState.RECONNECTING,
        SessionState.ConnectionState.AUTHENTICATING -> "Sync" to AmberAccent
        SessionState.ConnectionState.ERROR -> "Retry" to CoralError
        SessionState.ConnectionState.DISCONNECTED -> ":8080" to CyanAccent
    }
    val animatedColor by animateColorAsState(
        targetValue = statusColor,
        animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
        label = "status_color"
    )

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 4.dp, vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(
                text = "AeroShare",
                style = MaterialTheme.typography.titleLarge.copy(
                    fontWeight = FontWeight.Bold,
                    letterSpacing = (-0.3).sp
                ),
                color = TextPrimaryColor
            )

            Surface(
                color = animatedColor.copy(alpha = 0.10f),
                shape = RoundedCornerShape(50)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 9.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(5.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .clip(CircleShape)
                            .background(animatedColor)
                    )
                    Text(
                        text = if (wsState == SessionState.ConnectionState.CONNECTED && latencyMs > 0) {
                            "$statusText · ${latencyMs}ms"
                        } else {
                            statusText
                        },
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontFamily = JetBrainsMonoFamily,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.SemiBold
                        ),
                        color = animatedColor
                    )
                }
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Surface(
                shape = CircleShape,
                color = CrispSurface,
                border = BorderStroke(0.85.dp, Color(0xFFE8ECF1))
            ) {
                IconButton(
                    onClick = onOpenPermissions,
                    modifier = Modifier
                        .size(38.dp)
                        .testTag("permissions_header_button")
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Security,
                        contentDescription = "Permissions",
                        tint = TextSecondaryColor,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
            Surface(
                shape = CircleShape,
                color = CrispSurface,
                border = BorderStroke(0.85.dp, Color(0xFFE8ECF1))
            ) {
                IconButton(
                    onClick = onRefreshAll,
                    modifier = Modifier
                        .size(38.dp)
                        .testTag("refresh_dashboard_button")
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Refresh,
                        contentDescription = "Refresh",
                        tint = TextPrimaryColor,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun AgyHudHeroCard(
    isAgyHudActive: Boolean,
    onToggleAgyHud: () -> Unit,
    onOpenHudSimulator: () -> Unit
) {
    GlassPanel(modifier = Modifier.testTag("agy_hud_toggle_row")) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable(onClick = onToggleAgyHud)
                    .padding(horizontal = 16.dp, vertical = 14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    LiquidIconOrb(
                        icon = Icons.Rounded.AutoAwesome,
                        tint = CyanAccent,
                        contentDescription = "Agy Floating HUD",
                        size = 38.dp,
                        iconSize = 19.dp
                    )
                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(
                            text = "Agy Floating HUD",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold),
                            color = TextPrimaryColor
                        )
                        Text(
                            text = if (isAgyHudActive) "Active over apps" else "Live tasks, icons & output",
                            style = MaterialTheme.typography.bodySmall.copy(fontSize = 12.sp),
                            color = if (isAgyHudActive) CyanAccent else TextSecondaryColor
                        )
                    }
                }
                CrispPillSwitch(
                    checked = isAgyHudActive,
                    onCheckedChange = { onToggleAgyHud() },
                    checkedTrackColor = CyanAccent,
                    switchContentDescription = "Toggle Agy Termux HUD",
                    modifier = Modifier.testTag("toggle_agy_hud_switch")
                )
            }

            HorizontalDivider(
                color = Color(0xFFF1F4F8),
                thickness = 0.75.dp,
                modifier = Modifier.padding(horizontal = 16.dp)
            )

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Interactive preview & sandbox",
                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 12.sp),
                    color = TextSecondaryColor,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                Spacer(Modifier.width(10.dp))
                Button(
                    onClick = onOpenHudSimulator,
                    shape = RoundedCornerShape(50),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = CyanAccent,
                        contentColor = Color.White
                    ),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 0.dp),
                    modifier = Modifier
                        .height(34.dp)
                        .testTag("open_hud_simulator_button")
                ) {
                    Icon(
                        imageVector = Icons.Rounded.PlayArrow,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(15.dp)
                    )
                    Spacer(Modifier.width(4.dp))
                    Text(
                        text = "Test HUD",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
                        color = Color.White
                    )
                }
            }
        }
    }
}

@Composable
private fun CompactVaultTimelineBar(
    vaultSummary: com.kavach.telemetry.VaultUiSummary,
    onOpenTimeline: () -> Unit
) {
    val badgeColor = when {
        vaultSummary.isSyncing -> CyanAccent
        vaultSummary.isBridgeConnected -> EmeraldAccent
        else -> AmberAccent
    }
    val statusLabel = when {
        vaultSummary.isSyncing -> "Syncing"
        vaultSummary.isBridgeConnected -> "Live"
        else -> "Offline"
    }

    GlassPanel {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clickable(onClick = onOpenTimeline)
                .padding(horizontal = 16.dp, vertical = 13.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.weight(1f)
            ) {
                LiquidIconOrb(
                    icon = Icons.Rounded.History,
                    tint = TextSecondaryColor,
                    contentDescription = "Offline Vault Timeline",
                    size = 36.dp,
                    iconSize = 18.dp
                )
                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(7.dp)
                    ) {
                        Text(
                            text = "State Vault",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold),
                            color = TextPrimaryColor
                        )
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(6.dp)
                                    .clip(CircleShape)
                                    .background(badgeColor)
                            )
                            Text(
                                text = statusLabel,
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Medium),
                                color = TextSecondaryColor
                            )
                        }
                    }
                    Text(
                        text = "${vaultSummary.totalEvents} events · ${vaultSummary.totalLocations} GPS · ${vaultSummary.pendingCount} queued",
                        style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.5.sp),
                        color = TextSecondaryColor,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            Surface(
                color = Color(0xFFF3F4F6),
                shape = RoundedCornerShape(50),
                modifier = Modifier
                    .minimumInteractiveComponentSize()
                    .clip(RoundedCornerShape(50))
                    .clickable(onClick = onOpenTimeline)
                    .testTag("open_timeline_button")
            ) {
                Text(
                    text = "Timeline",
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold),
                    color = TextPrimaryColor,
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                )
            }
        }
    }
}

private fun extractRelayPhoneKey(url: String): String {
    val trimmed = url.trim().trimEnd('/')
    val marker = "/p/"
    val idx = trimmed.indexOf(marker, ignoreCase = true)
    if (idx >= 0) {
        val afterMarker = trimmed.substring(idx + marker.length)
        val withoutWs = afterMarker.removeSuffix("/ws").removeSuffix("/WS")
        return withoutWs.substringBefore("?").trim('/')
    }
    return ""
}

private fun applyRelayPhoneKeyInput(rawInput: String, currentUrl: String): String {
    val input = rawInput.trim()
    if (input.startsWith("ws://", ignoreCase = true) ||
        input.startsWith("wss://", ignoreCase = true) ||
        input.startsWith("http://", ignoreCase = true) ||
        input.startsWith("https://", ignoreCase = true)
    ) {
        return input
    }
    val cleanKey = input
        .removePrefix("/p/")
        .removePrefix("p/")
        .removeSuffix("/ws")
        .trim('/')
    val baseHost = currentUrl
        .trim()
        .substringBefore("/p/", missingDelimiterValue = "wss://private-relay-bridge.onrender.com")
        .ifBlank { "wss://private-relay-bridge.onrender.com" }
        .let { host ->
            when {
                host.startsWith("https://", ignoreCase = true) -> "wss://" + host.substring(8)
                host.startsWith("http://", ignoreCase = true) -> "ws://" + host.substring(7)
                host.startsWith("wss://", ignoreCase = true) || host.startsWith("ws://", ignoreCase = true) -> host
                else -> "wss://$host"
            }
        }
        .trimEnd('/')
    return if (cleanKey.isEmpty()) {
        "$baseHost/p/"
    } else {
        "$baseHost/p/$cleanKey/ws"
    }
}

@Composable
private fun CompactBridgeBar(
    urlInput: String,
    onUrlChange: (String) -> Unit,
    isConnected: Boolean,
    isConnecting: Boolean,
    lastFailure: String?,
    onConnect: () -> Unit,
    onDisconnect: () -> Unit
) {
    val isLocalSelected = urlInput.contains("127.0.0.1") || urlInput.contains("localhost")
    val bridgeContext = LocalContext.current

    val cleanTrimmedUrl = remember(urlInput) { urlInput.trim().trimEnd('/') }
    val isIncompleteRelayUrl = remember(cleanTrimmedUrl) {
        cleanTrimmedUrl.endsWith("/p", ignoreCase = true) ||
            cleanTrimmedUrl.endsWith("/c", ignoreCase = true) ||
            cleanTrimmedUrl.endsWith("/p/ws", ignoreCase = true) ||
            cleanTrimmedUrl.endsWith("/c/ws", ignoreCase = true)
    }
    val extractedPhoneKey = remember(urlInput) { extractRelayPhoneKey(urlInput) }
    val isRenderRelayUrl = remember(urlInput, isLocalSelected) {
        !isLocalSelected && (
            urlInput.contains("onrender.com", ignoreCase = true) ||
                urlInput.contains("/p/", ignoreCase = true) ||
                urlInput.trimEnd('/').endsWith("/p", ignoreCase = true)
            )
    }

    var isExpanded by remember { mutableStateOf(isIncompleteRelayUrl) }
    var showRawUrlEditor by remember { mutableStateOf(false) }

    LaunchedEffect(isIncompleteRelayUrl) {
        if (isIncompleteRelayUrl) {
            isExpanded = true
        }
    }

    val shortHost = remember(urlInput, isIncompleteRelayUrl) {
        val host = urlInput
            .removePrefix("wss://")
            .removePrefix("ws://")
            .removePrefix("https://")
            .removePrefix("http://")
            .substringBefore("/")
            .ifBlank { "endpoint" }
        if (isIncompleteRelayUrl) "Enter PHONE_KEY" else host
    }

    GlassPanel(
        borderColor = when {
            isConnected -> EmeraldAccent
            isIncompleteRelayUrl -> AmberAccent
            else -> CyanAccent
        }
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Clean Instagram-Style Full-Pill Endpoint Selector
                Surface(
                    color = GlassPillInput,
                    shape = RoundedCornerShape(50),
                    border = BorderStroke(
                        width = 1.dp,
                        color = if (isIncompleteRelayUrl) AmberAccent.copy(alpha = 0.55f) else CrispBorder
                    ),
                    modifier = Modifier
                        .weight(1f)
                        .height(44.dp)
                        .clip(RoundedCornerShape(50))
                        .clickable { isExpanded = !isExpanded }
                        .testTag("toggle_url_editor_pill")
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(7.dp)
                                .clip(CircleShape)
                                .background(
                                    when {
                                        isConnected -> EmeraldAccent
                                        isIncompleteRelayUrl -> AmberAccent
                                        else -> CyanAccent
                                    }
                                )
                        )
                        Text(
                            text = if (isLocalSelected) "Local" else "Tunnel",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = if (isConnected) EmeraldAccent else CyanAccent
                        )
                        Text(
                            text = shortHost,
                            style = MaterialTheme.typography.bodySmall.copy(
                                fontFamily = JetBrainsMonoFamily,
                                fontSize = 11.sp
                            ),
                            color = if (isIncompleteRelayUrl) AmberAccent else TextSecondaryColor,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f)
                        )
                        Icon(
                            imageVector = if (isExpanded) Icons.Rounded.KeyboardArrowUp else Icons.Rounded.KeyboardArrowDown,
                            contentDescription = "Edit URL",
                            tint = TextSecondaryColor,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }

                // Crisp Cobalt Blue / Emerald Full-Pill Connect Button
                Button(
                    onClick = {
                        if (isIncompleteRelayUrl) {
                            isExpanded = true
                            Toast.makeText(
                                bridgeContext,
                                "Enter your Render PHONE_KEY in the box below",
                                Toast.LENGTH_SHORT
                            ).show()
                        } else {
                            onConnect()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isConnected) EmeraldAccent else CyanAccent,
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(50),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 0.dp),
                    modifier = Modifier
                        .height(44.dp)
                        .testTag("connect_bridge_button")
                ) {
                    Icon(
                        imageVector = if (isConnected) Icons.Rounded.CheckCircle else Icons.Rounded.Link,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(Modifier.width(6.dp))
                    Text(
                        text = when {
                            isConnected -> "Live"
                            isConnecting -> "..."
                            else -> "Connect"
                        },
                        color = Color.White,
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold)
                    )
                }

                if (isConnected) {
                    Surface(
                        color = GlassInner,
                        shape = CircleShape,
                        border = BorderStroke(1.dp, HairlineBorder),
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .clickable(onClick = onConnect)
                            .testTag("refresh_bridge_button")
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Rounded.Refresh,
                                contentDescription = "Reconnect",
                                tint = CyanAccent,
                                modifier = Modifier.size(17.dp)
                            )
                        }
                    }
                }

                Surface(
                    color = GlassInner,
                    shape = CircleShape,
                    border = BorderStroke(1.dp, HairlineBorder),
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .clickable(onClick = onDisconnect)
                        .testTag("disconnect_bridge_button")
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Rounded.LinkOff,
                            contentDescription = "Disconnect",
                            tint = TextSecondaryColor,
                            modifier = Modifier.size(17.dp)
                        )
                    }
                }
            }

            if (!lastFailure.isNullOrBlank() && !isConnected) {
                Text(
                    text = lastFailure,
                    style = MaterialTheme.typography.labelSmall,
                    color = AmberAccent.copy(alpha = 0.9f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(horizontal = 4.dp)
                )
            }

            AnimatedVisibility(
                visible = isExpanded,
                enter = fadeIn() + expandVertically(),
                exit = fadeOut() + shrinkVertically()
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        MiniSegmentTab(
                            label = "Tunnel",
                            selected = !isLocalSelected,
                            accent = CyanAccent,
                            onClick = {
                                if (!urlInput.contains("onrender.com") || isLocalSelected) {
                                    val savedTunnel = RealtimeConnectionService.getLastAuthenticatedTunnelUrl(bridgeContext)
                                    onUrlChange(savedTunnel ?: "wss://private-relay-bridge.onrender.com/p/")
                                }
                            },
                            modifier = Modifier.weight(1f)
                        )
                        MiniSegmentTab(
                            label = "Local",
                            selected = isLocalSelected,
                            accent = CyanAccent,
                            onClick = { onUrlChange("ws://127.0.0.1:8000/ws") },
                            modifier = Modifier.weight(1f)
                        )
                    }

                    if (isRenderRelayUrl) {
                        OutlinedTextField(
                            value = extractedPhoneKey,
                            onValueChange = { keyInput ->
                                onUrlChange(applyRelayPhoneKeyInput(keyInput, urlInput))
                            },
                            singleLine = true,
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Rounded.Key,
                                    contentDescription = "Render PHONE_KEY",
                                    tint = if (isIncompleteRelayUrl) AmberAccent else CyanAccent,
                                    modifier = Modifier.size(17.dp)
                                )
                            },
                            trailingIcon = {
                                Surface(
                                    color = CyanAccent.copy(alpha = 0.16f),
                                    shape = RoundedCornerShape(50),
                                    border = BorderStroke(0.8.dp, CyanAccent.copy(alpha = 0.45f)),
                                    modifier = Modifier
                                        .padding(end = 8.dp)
                                        .clip(RoundedCornerShape(50))
                                        .clickable {
                                            val cm = bridgeContext.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as? android.content.ClipboardManager
                                            val clipText = cm?.primaryClip?.getItemAt(0)?.coerceToText(bridgeContext)?.toString()?.trim().orEmpty()
                                            if (clipText.isNotEmpty()) {
                                                onUrlChange(applyRelayPhoneKeyInput(clipText, urlInput))
                                                Toast.makeText(bridgeContext, "PHONE_KEY pasted", Toast.LENGTH_SHORT).show()
                                            } else {
                                                Toast.makeText(bridgeContext, "Clipboard is empty", Toast.LENGTH_SHORT).show()
                                            }
                                        }
                                        .testTag("paste_phone_key_button")
                                ) {
                                    Text(
                                        text = "Paste",
                                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                        color = CyanAccent,
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                                    )
                                }
                            },
                            placeholder = {
                                Text(
                                    text = "Paste PHONE_KEY here",
                                    style = MaterialTheme.typography.bodySmall.copy(fontFamily = JetBrainsMonoFamily),
                                    color = TextSecondaryColor.copy(alpha = 0.55f)
                                )
                            },
                            textStyle = MaterialTheme.typography.bodySmall.copy(
                                fontFamily = JetBrainsMonoFamily,
                                color = TextPrimaryColor
                            ),
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                            keyboardActions = KeyboardActions(
                                onDone = {
                                    if (!isIncompleteRelayUrl) onConnect()
                                }
                            ),
                            shape = RoundedCornerShape(50),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = if (isIncompleteRelayUrl) AmberAccent else if (isConnected) EmeraldAccent else CyanAccent,
                                unfocusedBorderColor = if (isIncompleteRelayUrl) AmberAccent.copy(alpha = 0.6f) else CrispBorder,
                                focusedContainerColor = GlassPillInput,
                                unfocusedContainerColor = GlassPillInput
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("relay_phone_key_input")
                        )

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Render PHONE_KEY (/p/<key>/ws)",
                                style = MaterialTheme.typography.labelSmall,
                                color = TextSecondaryColor
                            )
                            Text(
                                text = if (showRawUrlEditor) "Hide URL" else "Edit full URL",
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                color = CyanAccent,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(50))
                                    .clickable { showRawUrlEditor = !showRawUrlEditor }
                                    .padding(horizontal = 8.dp, vertical = 2.dp)
                            )
                        }
                    }

                    if (!isRenderRelayUrl || showRawUrlEditor) {
                        OutlinedTextField(
                            value = urlInput,
                            onValueChange = onUrlChange,
                            singleLine = true,
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Rounded.Link,
                                    contentDescription = null,
                                    tint = CyanAccent,
                                    modifier = Modifier.size(17.dp)
                                )
                            },
                            placeholder = {
                                Text(
                                    text = "wss://private-relay-bridge.onrender.com/p/<PHONE_KEY>/ws",
                                    style = MaterialTheme.typography.bodySmall.copy(fontFamily = JetBrainsMonoFamily),
                                    color = TextSecondaryColor.copy(alpha = 0.55f)
                                )
                            },
                            textStyle = MaterialTheme.typography.bodySmall.copy(
                                fontFamily = JetBrainsMonoFamily,
                                color = TextPrimaryColor
                            ),
                            shape = RoundedCornerShape(50),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = if (isConnected) EmeraldAccent else CyanAccent,
                                unfocusedBorderColor = CrispBorder,
                                focusedContainerColor = GlassPillInput,
                                unfocusedContainerColor = GlassPillInput
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("server_url_input")
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun CompactSettingsPanel(
    localEndpoint: String,
    isAppHidden: Boolean,
    isSyntheticIconForced: Boolean,
    authMode: String,
    isPanicLockdown: Boolean,
    pairingCode: String,
    onToggleAppHidden: (Boolean) -> Unit,
    onCopyAdbFix: () -> Unit,
    onSelectAuthMode: (String) -> Unit,
    onTogglePanicLockdown: (Boolean) -> Unit,
    onRegenerateCode: () -> Unit,
    onCopyToken: () -> Unit,
    onRotateKeys: () -> Unit,
    onExportScripts: () -> Unit,
    onOpenPermissions: () -> Unit
) {
    val rowDividerColor = Color(0xFFF1F4F8)

    GlassPanel(
        borderColor = if (isPanicLockdown) CoralError else HairlineBorder,
        modifier = Modifier.testTag("settings_section_card")
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            // Clean Section Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 16.dp, end = 16.dp, top = 14.dp, bottom = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Controls & Security",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold),
                    color = TextPrimaryColor
                )
                Text(
                    text = localEndpoint,
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontFamily = JetBrainsMonoFamily,
                        fontSize = 10.5.sp
                    ),
                    color = TextSecondaryColor
                )
            }

            HorizontalDivider(color = rowDividerColor, thickness = 0.75.dp)

            // Row 1: Hide App (Apple-Settings flat grouped row)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
                    .testTag("app_visibility_card"),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = if (isAppHidden) Icons.Rounded.VisibilityOff else Icons.Rounded.Visibility,
                        contentDescription = "Hide Icon",
                        tint = if (isAppHidden) AmberAccent else TextSecondaryColor,
                        modifier = Modifier.size(18.dp)
                    )
                    Column {
                        Text(
                            text = "Hide App",
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium),
                            color = TextPrimaryColor
                        )
                        Text(
                            text = if (isAppHidden) "Launcher icon hidden" else "Visible in app drawer",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextSecondaryColor
                        )
                    }
                }
                CrispPillSwitch(
                    checked = isAppHidden,
                    onCheckedChange = onToggleAppHidden,
                    checkedTrackColor = AmberAccent,
                    switchContentDescription = "Toggle Hide App",
                    modifier = Modifier.testTag("toggle_hide_app_switch")
                )
            }

            if (isAppHidden && isSyntheticIconForced) {
                Surface(
                    color = Color(0xFFFEF3C7),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(start = 16.dp, end = 16.dp, bottom = 10.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .clickable(onClick = onCopyAdbFix)
                        .testTag("copy_adb_hide_fix")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "OS forces App Info icon · Needs ADB",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color(0xFFB45309)
                        )
                        Text(
                            text = "Copy ADB",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = TextPrimaryColor
                        )
                    }
                }
            }

            HorizontalDivider(
                color = rowDividerColor,
                thickness = 0.75.dp,
                modifier = Modifier.padding(horizontal = 16.dp)
            )

            // Row 2: Panic Lockdown
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onTogglePanicLockdown(!isPanicLockdown) }
                    .padding(horizontal = 16.dp, vertical = 8.dp)
                    .testTag("panic_lockdown_toggle"),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Lock,
                        contentDescription = "Lockdown",
                        tint = if (isPanicLockdown) CoralError else TextSecondaryColor,
                        modifier = Modifier.size(18.dp)
                    )
                    Column {
                        Text(
                            text = "Panic Lockdown",
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium),
                            color = if (isPanicLockdown) CoralError else TextPrimaryColor
                        )
                        Text(
                            text = if (isPanicLockdown) "All remote requests blocked" else "Allow authorized requests",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (isPanicLockdown) CoralError.copy(alpha = 0.8f) else TextSecondaryColor
                        )
                    }
                }
                CrispPillSwitch(
                    checked = isPanicLockdown,
                    onCheckedChange = onTogglePanicLockdown,
                    checkedTrackColor = CoralError,
                    switchContentDescription = "Toggle Panic Lockdown"
                )
            }

            HorizontalDivider(
                color = rowDividerColor,
                thickness = 0.75.dp,
                modifier = Modifier.padding(horizontal = 16.dp)
            )

            // Row 3: Auth Mode (Clean inline segmented control)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Shield,
                        contentDescription = "Auth Mode",
                        tint = TextSecondaryColor,
                        modifier = Modifier.size(18.dp)
                    )
                    Text(
                        text = "Auth Mode",
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium),
                        color = TextPrimaryColor
                    )
                }

                Surface(
                    color = Color(0xFFF3F4F6),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.width(152.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(3.dp),
                        horizontalArrangement = Arrangement.spacedBy(3.dp)
                    ) {
                        listOf(
                            "STRICT" to AuraSecurityShield.AUTH_MODE_STRICT,
                            "LOCAL" to AuraSecurityShield.AUTH_MODE_LOCAL_TRUST
                        ).forEach { (label, modeValue) ->
                            val selected = authMode == modeValue
                            val accent = if (modeValue == AuraSecurityShield.AUTH_MODE_STRICT) {
                                EmeraldAccent
                            } else {
                                CyanAccent
                            }
                            Surface(
                                color = if (selected) CrispSurface else Color.Transparent,
                                shadowElevation = if (selected) 0.8.dp else 0.dp,
                                shape = RoundedCornerShape(9.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(30.dp)
                                    .clip(RoundedCornerShape(9.dp))
                                    .clickable { onSelectAuthMode(modeValue) }
                                    .testTag("auth_mode_$label")
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Text(
                                        text = label,
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontFamily = JetBrainsMonoFamily,
                                            fontSize = 10.sp,
                                            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium
                                        ),
                                        color = if (selected) accent else TextSecondaryColor
                                    )
                                }
                            }
                        }
                    }
                }
            }

            HorizontalDivider(
                color = rowDividerColor,
                thickness = 0.75.dp,
                modifier = Modifier.padding(horizontal = 16.dp)
            )

            // Row 4: Pairing Code
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable(onClick = onRegenerateCode)
                    .padding(horizontal = 16.dp, vertical = 11.dp)
                    .testTag("regenerate_code_button"),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Key,
                        contentDescription = "Pairing Code",
                        tint = TextSecondaryColor,
                        modifier = Modifier.size(18.dp)
                    )
                    Column {
                        Text(
                            text = "Pairing Code",
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium),
                            color = TextPrimaryColor
                        )
                        Text(
                            text = "Tap to rotate",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextSecondaryColor
                        )
                    }
                }
                Surface(
                    color = Color(0xFFF3F4F6),
                    shape = RoundedCornerShape(50)
                ) {
                    Text(
                        text = pairingCode,
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontFamily = JetBrainsMonoFamily,
                            fontWeight = FontWeight.Bold
                        ),
                        color = TextPrimaryColor,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                    )
                }
            }

            HorizontalDivider(color = rowDividerColor, thickness = 0.75.dp)

            // Calm Monochrome Utility Row (Token, Rotate, Scripts, Access)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                CompactActionButton(
                    icon = Icons.Rounded.ContentCopy,
                    label = "Token",
                    tint = TextSecondaryColor,
                    testTag = "copy_token_button",
                    onClick = onCopyToken,
                    modifier = Modifier.weight(1f)
                )
                CompactActionButton(
                    icon = Icons.Rounded.Refresh,
                    label = "Rotate",
                    tint = TextSecondaryColor,
                    testTag = "rotate_keys_button",
                    onClick = onRotateKeys,
                    modifier = Modifier.weight(1f)
                )
                CompactActionButton(
                    icon = Icons.Rounded.Download,
                    label = "Scripts",
                    tint = TextSecondaryColor,
                    testTag = "export_scripts_button",
                    onClick = onExportScripts,
                    modifier = Modifier.weight(1f)
                )
                CompactActionButton(
                    icon = Icons.Rounded.Security,
                    label = "Access",
                    tint = TextSecondaryColor,
                    testTag = "open_permissions_button",
                    onClick = onOpenPermissions,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
private fun CompactActionButton(
    icon: ImageVector,
    label: String,
    tint: Color,
    testTag: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        color = Color(0xFFF5F6F8),
        shape = RoundedCornerShape(12.dp),
        modifier = modifier
            .height(38.dp)
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .testTag(testTag)
    ) {
        Row(
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 6.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = tint,
                modifier = Modifier.size(14.dp)
            )
            Spacer(Modifier.width(4.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Medium),
                color = TextPrimaryColor,
                maxLines = 1
            )
        }
    }
}

@Composable
private fun MiniSegmentTab(
    label: String,
    selected: Boolean,
    accent: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        color = if (selected) accent.copy(alpha = 0.12f) else GlassInner,
        shape = RoundedCornerShape(50),
        border = BorderStroke(1.dp, if (selected) accent.copy(alpha = 0.40f) else HairlineBorder),
        modifier = modifier
            .height(36.dp)
            .clip(RoundedCornerShape(50))
            .clickable(onClick = onClick)
    ) {
        Box(contentAlignment = Alignment.Center) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelMedium.copy(
                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium
                ),
                color = if (selected) accent else TextSecondaryColor
            )
        }
    }
}

@Composable
private fun CompactDevicesPanel(
    wsState: SessionState.ConnectionState,
    bridgeUrl: String,
    latencyMs: Long,
    pairedDevices: List<PairedClient>,
    pendingRequests: List<PendingPairRequest>,
    discoveredPeers: List<AeroDevice>,
    onRefresh: () -> Unit,
    onRevokeDevice: (String) -> Unit,
    onApproveRequest: (String) -> Unit,
    onDenyRequest: (String) -> Unit
) {
    val isBridgeActive = wsState == SessionState.ConnectionState.CONNECTED ||
            wsState == SessionState.ConnectionState.CONNECTING ||
            wsState == SessionState.ConnectionState.RECONNECTING
    val totalCount = pairedDevices.size + discoveredPeers.size +
            (if (wsState == SessionState.ConnectionState.CONNECTED) 1 else 0)

    GlassPanel(
        borderColor = if (pendingRequests.isNotEmpty()) AmberAccent else HairlineBorder,
        modifier = Modifier.testTag("connected_devices_card")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "Devices",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold),
                        color = TextPrimaryColor
                    )
                    Surface(
                        color = Color(0xFFF3F4F6),
                        shape = RoundedCornerShape(50)
                    ) {
                        Text(
                            text = "$totalCount",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontFamily = JetBrainsMonoFamily,
                                fontWeight = FontWeight.SemiBold
                            ),
                            color = if (totalCount > 0) EmeraldAccent else TextSecondaryColor,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                        )
                    }
                }

                IconButton(
                    onClick = onRefresh,
                    modifier = Modifier
                        .size(36.dp)
                        .testTag("refresh_devices_button")
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Refresh,
                        contentDescription = "Refresh Devices",
                        tint = TextSecondaryColor,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }

            pendingRequests.forEach { req ->
                HorizontalDivider(color = HairlineBorder)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(7.dp)
                                .clip(CircleShape)
                                .background(AmberAccent)
                        )
                        Column {
                            Text(
                                text = req.clientName,
                                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold),
                                color = TextPrimaryColor,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = req.clientIp,
                                style = MaterialTheme.typography.labelSmall.copy(fontFamily = JetBrainsMonoFamily),
                                color = AmberAccent
                            )
                        }
                    }
                    Row {
                        IconButton(
                            onClick = { onApproveRequest(req.requestId) },
                            modifier = Modifier
                                .minimumInteractiveComponentSize()
                                .testTag("approve_pair_${req.requestId}")
                        ) {
                            Icon(Icons.Rounded.Check, contentDescription = "Approve", tint = EmeraldAccent, modifier = Modifier.size(18.dp))
                        }
                        IconButton(
                            onClick = { onDenyRequest(req.requestId) },
                            modifier = Modifier
                                .minimumInteractiveComponentSize()
                                .testTag("deny_pair_${req.requestId}")
                        ) {
                            Icon(Icons.Rounded.Close, contentDescription = "Deny", tint = CoralError, modifier = Modifier.size(18.dp))
                        }
                    }
                }
            }

            if (isBridgeActive) {
                val bridgeHost = remember(bridgeUrl) {
                    bridgeUrl
                        .removePrefix("wss://")
                        .removePrefix("ws://")
                        .substringBefore("/")
                        .ifBlank { "Bridge" }
                }
                val isLive = wsState == SessionState.ConnectionState.CONNECTED
                HorizontalDivider(color = HairlineBorder)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 7.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(9.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Router,
                            contentDescription = "Relay",
                            tint = if (isLive) EmeraldAccent else AmberAccent,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = bridgeHost,
                            style = MaterialTheme.typography.bodySmall.copy(fontFamily = JetBrainsMonoFamily),
                            color = TextPrimaryColor,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    Text(
                        text = if (isLive && latencyMs > 0) "LIVE · ${latencyMs}ms" else if (isLive) "LIVE" else "SYNC",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontFamily = JetBrainsMonoFamily,
                            fontWeight = FontWeight.Bold
                        ),
                        color = if (isLive) EmeraldAccent else AmberAccent
                    )
                }
            }

            pairedDevices.forEach { client ->
                HorizontalDivider(color = HairlineBorder)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 2.dp)
                        .testTag("paired_device_${client.deviceId}"),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(9.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Laptop,
                            contentDescription = "Client",
                            tint = CyanAccent,
                            modifier = Modifier.size(16.dp)
                        )
                        Column {
                            Text(
                                text = client.clientName,
                                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold),
                                color = TextPrimaryColor,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "${client.clientIp.ifBlank { client.deviceId }} · ${formatRelativeTime(client.lastSeenAt)}",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontFamily = JetBrainsMonoFamily,
                                    fontSize = 10.sp
                                ),
                                color = TextSecondaryColor,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }

                    IconButton(
                        onClick = { onRevokeDevice(client.deviceId) },
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("revoke_device_${client.deviceId}")
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Close,
                            contentDescription = "Revoke ${client.clientName}",
                            tint = CoralError.copy(alpha = 0.85f),
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }

            discoveredPeers.forEach { peer ->
                HorizontalDivider(color = HairlineBorder)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 7.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(9.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Devices,
                            contentDescription = "LAN Peer",
                            tint = PurpleAccent,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = "${peer.name} · ${peer.ip}",
                            style = MaterialTheme.typography.bodySmall.copy(fontFamily = JetBrainsMonoFamily),
                            color = TextPrimaryColor,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    Text(
                        text = "LAN",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontFamily = JetBrainsMonoFamily,
                            fontWeight = FontWeight.Bold
                        ),
                        color = PurpleAccent
                    )
                }
            }

            if (totalCount == 0 && pendingRequests.isEmpty() && !isBridgeActive) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 10.dp),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Devices,
                        contentDescription = null,
                        tint = TextSecondaryColor.copy(alpha = 0.5f),
                        modifier = Modifier.size(15.dp)
                    )
                    Spacer(Modifier.width(6.dp))
                    Text(
                        text = "Empty",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondaryColor.copy(alpha = 0.7f)
                    )
                }
            }
        }
    }
}

@Composable
private fun CompactLogsPanel(
    logs: List<String>,
    totalLogCount: Int,
    selectedFilter: String,
    onFilterSelect: (String) -> Unit,
    showShellInput: Boolean,
    onToggleShellInput: () -> Unit,
    shellInput: String,
    onShellInputChange: (String) -> Unit,
    lastCommandOutput: String?,
    onDismissCommandOutput: () -> Unit,
    onExecuteCommand: () -> Unit,
    onClearLogs: () -> Unit
) {
    var isLogsExpanded by remember { mutableStateOf(false) }

    GlassPanel(modifier = Modifier.testTag("inline_logs_card")) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Clean Collapsible Activity Logs Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { isLogsExpanded = !isLogsExpanded },
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "Activity Logs",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold),
                        color = TextPrimaryColor
                    )
                    if (totalLogCount > 0) {
                        Surface(
                            shape = RoundedCornerShape(50),
                            color = Color(0xFFF3F4F6)
                        ) {
                            Text(
                                text = "${logs.size}",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontFamily = JetBrainsMonoFamily,
                                    fontWeight = FontWeight.SemiBold
                                ),
                                color = TextSecondaryColor,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                            )
                        }
                    }
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(2.dp)
                ) {
                    IconButton(
                        onClick = {
                            if (!isLogsExpanded) isLogsExpanded = true
                            onToggleShellInput()
                        },
                        modifier = Modifier
                            .size(36.dp)
                            .testTag("toggle_shell_input_button")
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Terminal,
                            contentDescription = "Shell",
                            tint = if (showShellInput) EmeraldAccent else TextSecondaryColor,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                    if (totalLogCount > 0) {
                        IconButton(
                            onClick = onClearLogs,
                            modifier = Modifier
                                .size(36.dp)
                                .testTag("clear_logs_button")
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.ClearAll,
                                contentDescription = "Clear",
                                tint = TextSecondaryColor,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                    Icon(
                        imageVector = if (isLogsExpanded) Icons.Rounded.KeyboardArrowUp else Icons.Rounded.KeyboardArrowDown,
                        contentDescription = if (isLogsExpanded) "Collapse Logs" else "Expand Logs",
                        tint = TextSecondaryColor,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            AnimatedVisibility(
                visible = isLogsExpanded || showShellInput,
                enter = fadeIn() + expandVertically(),
                exit = fadeOut() + shrinkVertically()
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    // Clean Apple-Style Segmented Filter Bar
                    Surface(
                        color = Color(0xFFF3F4F6),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(3.dp),
                            horizontalArrangement = Arrangement.spacedBy(3.dp)
                        ) {
                            listOf("ALL", "HTTP", "WS", "SHELL", "SYS").forEach { filter ->
                                val selected = selectedFilter == filter
                                Surface(
                                    color = if (selected) CrispSurface else Color.Transparent,
                                    shadowElevation = if (selected) 0.8.dp else 0.dp,
                                    shape = RoundedCornerShape(9.dp),
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(30.dp)
                                        .clip(RoundedCornerShape(9.dp))
                                        .clickable { onFilterSelect(filter) }
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Text(
                                            text = filter,
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                fontFamily = JetBrainsMonoFamily,
                                                fontSize = 10.sp,
                                                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium
                                            ),
                                            color = if (selected) TextPrimaryColor else TextSecondaryColor
                                        )
                                    }
                                }
                            }
                        }
                    }

            AnimatedVisibility(
                visible = showShellInput,
                enter = fadeIn() + expandVertically(),
                exit = fadeOut() + shrinkVertically()
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = shellInput,
                            onValueChange = onShellInputChange,
                            singleLine = true,
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Rounded.Terminal,
                                    contentDescription = null,
                                    tint = EmeraldAccent,
                                    modifier = Modifier.size(16.dp)
                                )
                            },
                            placeholder = {
                                Text(
                                    text = "$ ...",
                                    style = MaterialTheme.typography.bodySmall.copy(fontFamily = JetBrainsMonoFamily),
                                    color = TextSecondaryColor.copy(alpha = 0.55f)
                                )
                            },
                            textStyle = MaterialTheme.typography.bodySmall.copy(
                                fontFamily = JetBrainsMonoFamily,
                                color = TextPrimaryColor
                            ),
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                            keyboardActions = KeyboardActions(onSend = { onExecuteCommand() }),
                            shape = RoundedCornerShape(50),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = EmeraldAccent,
                                unfocusedBorderColor = CrispBorder,
                                focusedContainerColor = GlassPillInput,
                                unfocusedContainerColor = GlassPillInput
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("shell_command_input")
                        )
                        Surface(
                            color = EmeraldAccent,
                            shape = CircleShape,
                            modifier = Modifier
                                .size(48.dp)
                                .clip(CircleShape)
                                .clickable(onClick = onExecuteCommand)
                                .testTag("shell_exec_button")
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Rounded.Send,
                                    contentDescription = "Run",
                                    tint = Color.White,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }

                    if (!lastCommandOutput.isNullOrBlank()) {
                        Surface(
                            color = GlassInner,
                            shape = RoundedCornerShape(16.dp),
                            border = BorderStroke(1.dp, EmeraldAccent.copy(alpha = 0.35f)),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable(onClick = onDismissCommandOutput)
                        ) {
                            Text(
                                text = lastCommandOutput,
                                style = MaterialTheme.typography.bodySmall.copy(
                                    fontFamily = JetBrainsMonoFamily,
                                    fontSize = 10.sp,
                                    lineHeight = 14.sp
                                ),
                                color = TextPrimaryColor,
                                modifier = Modifier.padding(10.dp)
                            )
                        }
                    }
                }
            }

            // Crisp Soft-Slate Monospace Console Surface
            Surface(
                color = Color(0xFFF8FAFC),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, HairlineBorder),
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 170.dp, max = 280.dp)
            ) {
                if (logs.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "No logs yet",
                            style = MaterialTheme.typography.bodySmall.copy(fontFamily = JetBrainsMonoFamily),
                            color = TextSecondaryColor.copy(alpha = 0.7f)
                        )
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalArrangement = Arrangement.spacedBy(5.dp)
                    ) {
                        items(logs.take(150)) { entry ->
                            val lineColor = when {
                                entry.contains("ERR", ignoreCase = true) ||
                                        entry.contains("FAIL", ignoreCase = true) ||
                                        entry.contains("REVOKED", ignoreCase = true) ||
                                        entry.contains("DENIED", ignoreCase = true) -> CoralError
                                entry.contains("SHELL", ignoreCase = true) ||
                                        entry.contains("200 OK", ignoreCase = true) ||
                                        entry.contains("PAIRED", ignoreCase = true) -> EmeraldAccent
                                entry.contains("HTTP", ignoreCase = true) ||
                                        entry.contains("WS", ignoreCase = true) -> CyanAccent
                                entry.contains("SECURITY", ignoreCase = true) ||
                                        entry.contains("APP_VISIBILITY", ignoreCase = true) -> AmberAccent
                                else -> TextPrimaryColor.copy(alpha = 0.85f)
                            }
                            Text(
                                text = entry,
                                style = MaterialTheme.typography.bodySmall.copy(
                                    fontFamily = JetBrainsMonoFamily,
                                    fontSize = 10.5.sp,
                                    lineHeight = 14.sp
                                ),
                                color = lineColor
                            )
                            HorizontalDivider(
                                color = Color(0xFFF1F4F8),
                                thickness = 0.75.dp,
                                modifier = Modifier.padding(top = 4.dp)
                            )
                        }
                    }
                }
            }
                }
            }
        }
    }
}

private fun formatRelativeTime(timestampMs: Long): String {
    val diffSec = ((System.currentTimeMillis() - timestampMs) / 1000L).coerceAtLeast(0L)
    return when {
        diffSec < 60L -> "now"
        diffSec < 3600L -> "${diffSec / 60L}m"
        diffSec < 86400L -> "${diffSec / 3600L}h"
        else -> "${diffSec / 86400L}d"
    }
}

@Composable
fun borderBrush() = BorderStroke(
    width = 1.dp,
    color = BorderSubtleColor
)
