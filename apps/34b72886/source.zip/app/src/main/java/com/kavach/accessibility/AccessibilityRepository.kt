package com.kavach.accessibility

import com.kavach.accessibility.models.AccessibilityEventModel
import com.kavach.accessibility.models.AccessibilityNodeModel
import com.kavach.accessibility.models.AccessibilityServiceStatus
import com.kavach.accessibility.models.AccessibilityWindowModel
import com.kavach.accessibility.models.GestureRequestModel
import kotlinx.coroutines.flow.StateFlow

interface AccessibilityRepository {
    val serviceStatus: StateFlow<AccessibilityServiceStatus>
    val recentEvents: StateFlow<List<AccessibilityEventModel>>
    val logs: StateFlow<List<String>>

    fun triggerGesture(gesture: GestureRequestModel, onComplete: (Boolean) -> Unit)
    fun clickNodeByText(text: String, onComplete: (Boolean) -> Unit)
    fun performScroll(forward: Boolean, onComplete: (Boolean) -> Unit)
    fun inputText(text: String, targetLabel: String? = null, onComplete: (Boolean) -> Unit = {}) {
        onComplete(false)
    }
    fun takeScreenshotBase64(quality: Int = 75, maxDimension: Int = 1280): org.json.JSONObject {
        return org.json.JSONObject().apply {
            put("success", false)
            put("error", "Not implemented")
        }
    }
    fun getFullNodeTree(): List<AccessibilityNodeModel>
    fun getVisibleWindows(excludeHud: Boolean = true): List<AccessibilityWindowModel> = emptyList()
    fun searchNodes(text: String?, contentDescription: String?, viewId: String?): List<AccessibilityNodeModel>
    fun addLog(message: String)
    fun addEvent(event: AccessibilityEventModel)
}
