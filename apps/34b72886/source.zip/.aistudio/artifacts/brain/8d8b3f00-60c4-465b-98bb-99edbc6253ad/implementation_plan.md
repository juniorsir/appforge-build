# Apple PiP-Style Glass Overlay Player & Auto-Following HUD Dock

Redesign the left-window media player into an Apple Picture-in-Picture / QuickTime-inspired floating player with **translucent glass overlay controls and Apple SF-style vector SVG icons directly on the video surface**, **100% full window opacity**, **automatic side-by-side docking that follows just left of the main HUD window**, **automatic collapse into the background mini-pill when a new Agy task starts**, and hardened media/overlay lifecycle guards that prevent crashes or unexpected closures.

---

## User Review & Critical Decisions

> [!IMPORTANT]
> Your preferences from the questionnaire are locked into this plan:

- **Confirmed Decision 1 — Translucent Glass Overlay Controls on the Video Surface**: All playback, mode, and window controls use crisp Apple SF Symbols-style vector SVG icons (zero emojis) inside translucent frosted-glass inline pills overlaid directly on top of the video surface (top glass bar for Video/Audio switch, PiP Background Mini-Pill, Lightbox Expand, and Close; center glass transport cluster for Previous, Play/Pause, and Next; bottom glass bar for live scrubber, tabular timestamps, Speed, Loop, Mute/Volume, and Queue drawer toggle).
- **Confirmed Decision 2 — Auto-Follow Docked Just Left of the Main HUD at 100% Opacity**: The left window defaults to **100% (`1.0f`) full opacity** and automatically docks immediately to the left of the main HUD window (`mainHud.left - 12dp - leftWindow.width`, aligned with `mainHud.top`), following the main HUD smoothly whenever the main HUD moves, expands, or dodges the keyboard.
- **Confirmed Decision 3 — Auto-Collapse to Background Mini-Pill on New Task Start & Crash Prevention**:
  - When a new Agy task starts (`state == "WORKING"`) and the daemon pushes a standard HUD state update, the active player is **never wiped or closed**; instead, it automatically collapses into the compact background (`BG`) mini-pill (docked just left of the main HUD) and keeps playing uninterrupted.
  - Fixes overlay crashes by eliminating eager `WebView` instantiation in the background service context (creating it lazily and safely only for web embeds), guarding `MediaPlayer` `PREPARING` vs. `PREPARED` transitions, and opening local `/sdcard/...` files via `FileInputStream` file descriptors.

---

## 1. Overview & Core Concept

- **What It Does**: Replaces the emoji-based multi-row media card with an edge-to-edge Apple PiP-style video/audio canvas featuring translucent glass inline SVG controls overlaid directly on the media viewport, docked at full `100%` opacity right next to the main HUD window.
- **Target Audience / Persona**: Users watching videos or listening to music triggered by Agy across phones, foldables, and large-screen tablets while multitasking with Agy.
- **Key Value**: Delivers a clean Apple-grade visual aesthetic, keeps the left window paired right beside the main HUD on large screens instead of stranded at the far-left edge, and prevents playback from crashing or closing when Agy runs new commands.

---

## 2. User Experience & Visual Design

- **Key User Flows**:
  1. **Edge-to-Edge Media Canvas with Translucent Glass Overlay Controls**:
     - The player window renders at **`100%` opacity** with rounded `18dp` corners and a full-bleed `16:9` video surface (or Apple Music-style album artwork + live waveform canvas in Audio-Only mode).
     - **Top Translucent Glass Overlay Strip**: Floating at the top of the video canvas with a dark frosted-glass pill background (`#880F172A` with subtle white border), displaying the track title on the left and inline Apple SVG icon buttons on the right: **`[Video / Audio Mode SVG]`**, **`[PiP Background Mini-Pill SVG]`**, **`[Fullscreen Expand SVG]`**, and **`[Close XMark SVG]`**.
     - **Center Translucent Glass Transport Cluster**: Floating inline circular glass buttons over the center of the surface for **`[Backward.Fill SVG]`**, **`[Play.Fill / Pause.Fill SVG]`** (prominent accent/glass pill), and **`[Forward.Fill SVG]`**. Tapping the video background toggles control overlay visibility or play/pause smoothly.
     - **Bottom Translucent Glass Scrubber & Utility Strip**: Floating along the bottom of the surface with an inline seek bar, compact `00:42 / 03:15` monospace counter, and inline vector icon buttons for **`[Speaker.Wave / Mute SVG]`**, **`[Repeat SVG]`**, **`[Speed (1x)]`**, and **`[List.Bullet Queue SVG]`**.
  2. **Auto-Following Side-by-Side Docking**:
     - On large screens, tablets, foldables, and phones with horizontal room, the left window positions itself at `x = mainHud.left - 12dp - leftWindow.width` and `y = mainHud.top`.
     - Whenever you drag or move the main HUD window, the left window automatically follows along its left flank so the two windows behave as a cohesive paired HUD.
  3. **Auto-Collapse to Background Mini-Pill When a New Task Starts**:
     - When Agy begins a new prompt/task (`WORKING`), the player automatically transitions into its compact **Background Mini-Pill** (docked just left of the main HUD with a vector waveform/video icon, track title, and inline SVG **Play/Pause** and **Next** buttons) rather than closing. Tapping the mini-pill expands the full video canvas again at any time.

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1: Custom Canvas Apple SF-Style Vector SVG Renderer (`AgyAppleVectorIconView`)**
  - *Chosen Approach*: Implement a dedicated vector path renderer drawing crisp 24x24 viewport Apple SF Symbols-style icons (`PLAY_FILL`, `PAUSE_FILL`, `BACKWARD_FILL`, `FORWARD_FILL`, `VIDEO_FILL`, `MUSIC_NOTE`, `WAVEFORM`, `PIP_ENTER`, `ARROW_EXPAND`, `REPEAT`, `SPEAKER_WAVE`, `SPEAKER_SLASH`, `LIST_BULLET`, `MINUS`, `XMARK`) with smooth cubic Beziers and rounded stroke caps.
  - *Why*: Eliminates OEM-dependent emoji rendering and provides authentic Apple PiP / Control Center iconography at any DPI.
- **Decision 2: HUD-Relative Auto-Follow Anchor in Layout Coordinator**
  - *Chosen Approach*: Update the layout coordinator and left-window manager so `TASK_MAP` computes its default home anchor directly to the left of `HUD` (`hud.rect.left - gapPx - taskMapWidth`, `hud.rect.top`) and updates in lockstep when `HUD` moves, while still allowing independent dodging if space is constrained near the left screen boundary.
  - *Why*: Directly solves the large-screen issue where the left window was pinned to `x = safeLeft` far away from the main HUD.
- **Decision 3: Sticky Player Retention + Auto-Background on New Task + Fault-Tolerant MediaPlayer**
  - *Chosen Approach*:
    1. In both the Android HUD state parser and the Termux daemon state tracker, preserve the active `player` configuration across `/api/hud/state` updates unless `clearPlayer` is explicitly requested or a different active `TaskMap` mode is pushed.
    2. When HUD state transitions from `IDLE`/`DONE`/`STOPPED` into `WORKING` while the player is active, automatically collapse the player window to its background mini-pill (`backgroundMode = true, isCollapsed = true`) so playback continues hands-free.
    3. Guard all `MediaPlayer` lifecycle calls with explicit `isPreparing` / `isPrepared` state flags, use `FileInputStream.fd` for local `/sdcard/...` files, and lazy-create `WebView` only when a web-embed track is loaded.
  - *Why*: Eliminates both the unexpected closure when daemon state updates arrive and native/WebView crashes in `TYPE_APPLICATION_OVERLAY` windows.

---

## 4. Technical Architecture & Data Strategy *(Technical Reference)*

### Architecture & Component Diagram

```
┌──────────────────────────────────────────────────────────────────────────────┐
│                 Auto-Following Side-by-Side Overlay Workspace                │
│                                                                              │
│  ┌───────────────────────────────────────┐  12dp  ┌───────────────────────┐  │
│  │ Left Player Window (100% Opacity)     │◄──────►│   Main HUD Window     │  │
│  │ ┌───────────────────────────────────┐ │Follows │                       │  │
│  │ │ 16:9 Video / Artwork Canvas       │ │  HUD   │  Status & Tasks       │  │
│  │ │ ┌───────────────────────────────┐ │ │        │  Inline Composer      │  │
│  │ │ │[SVG] Title     [🎬][⧉][⤢][✕] │ │ │        │  Tools Tray           │  │
│  │ │ └───────────────────────────────┘ │ │        └───────────────────────┘  │
│  │ │        (⏮)    ( ⏸ )    (⏭)        │ │                                   │
│  │ │ ┌───────────────────────────────┐ │ │                                   │
│  │ │ │00:42 ━━━●──── 03:15 [🔊][🔁][☰]│ │ │                                   │
│  │ │ └───────────────────────────────┘ │ │                                   │
│  │ └───────────────────────────────────┘ │                                   │
│  └───────────────────────────────────────┘                                   │
└─────────────────────▲──────────────────────────────────────▲─────────────────┘
                      │                                      │
                      ▼                                      ▼
┌──────────────────────────────────────────┐  ┌────────────────────────────────┐
│  Apple Vector & Glass Overlay Engine     │  │  Auto-Follow & Task-Start      │
│ • AgyAppleVectorIconView (SF SVG paths)  │  │  Mini-Pill Coordinator         │
│ • Translucent frosted glass overlay bars │  │ • Home anchor = hud.left - 12dp│
│ • Lazy WebView + FD-backed MediaPlayer   │  │ • Auto-collapses player to BG  │
│ • Strict PREPARING / PREPARED guards     │  │   mini-pill on WORKING start   │
└──────────────────────────────────────────┘  └────────────────────────────────┘
```

### Interactive Component & State Mapping

- **Apple SF Vector SVG Component (`AgyAppleVectorIconView`)**:
  - Draws crisp vector iconography with configurable tint, stroke width, and optional translucent glass pill/circle background (`#8C0F172A` with `#38FFFFFF` 1dp border).
  - Used across all inline overlay controls on the video surface, the left window header, and the collapsed background mini-pill.
- **Translucent Glass Overlay Surface Layout**:
  - The 16:9 media viewport (`148dp` height in normal width, `172dp` in wide size) hosts the `TextureView` (native video), lazy `WebView` (web embeds), or Audio-Only artwork + live waveform deck as its base layer.
  - Overlaid directly inside the same `FrameLayout` are the **Top Glass Control Bar** (title + mode/PiP/fullscreen/close SVG buttons), **Center Glass Transport Row** (Previous, Play/Pause, Next SVG buttons), and **Bottom Glass Scrubber & Utility Bar** (SeekBar + time counter + Mute/Loop/Speed/Queue SVG buttons).
- **Auto-Follow Side-by-Side Docking & 100% Opacity**:
  - Default opacity in `AgyTaskMapOverlayManager` is updated to `1.0f` (`100%`) as the first preset (`1.0f, 0.85f, 0.65f`).
  - `AgyOverlayLayoutCoordinator` anchors `TASK_MAP` at `preferredLeft = hud.rect.left - viewport.gapPx - taskMapWidth` and `preferredTop = hud.rect.top` whenever `TASK_MAP` has not been manually dragged away by the user, and updates `TASK_MAP` to follow `HUD` whenever `HUD` is dragged or repositioned.
- **Sticky Player Persistence & Auto-Collapse on New Task**:
  - When `/api/hud/state` arrives with `state == "WORKING"` (a new task starting) while `current.taskMap.mode == "player"` and `current.taskMap.active` is true, the active player is preserved and automatically collapsed into its compact background mini-pill (`isCollapsed = true, backgroundMode = true`) instead of being overwritten by the daemon's default inactive `app_pane` `taskMap`.
