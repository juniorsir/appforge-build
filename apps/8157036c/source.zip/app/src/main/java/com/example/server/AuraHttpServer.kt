package com.example.server

import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStream
import java.net.ServerSocket
import java.net.Socket

class AuraHttpServer(
    private val scope: CoroutineScope,
    private val port: Int = 8080,
    private val securityShield: com.example.security.AuraSecurityShield? = null,
    private val onApiRequest: ((endpoint: String, jsonPayload: JSONObject) -> JSONObject)? = null
) {
    private val TAG = "AuraHttpServer"
    private var serverSocket: ServerSocket? = null
    private var serverJob: Job? = null

    fun start() {
        if (serverJob?.isActive == true) return
        serverJob = scope.launch(Dispatchers.IO) {
            try {
                serverSocket = ServerSocket(port)
                Log.i(TAG, "Aura Documentation & REST API HTTP Server listening on http://127.0.0.1:$port")

                while (isActive && serverSocket?.isClosed == false) {
                    try {
                        val clientSocket = serverSocket?.accept() ?: break
                        launch(Dispatchers.IO) {
                            handleClient(clientSocket)
                        }
                    } catch (e: Exception) {
                        if (isActive) {
                            Log.w(TAG, "Exception accepting connection: ${e.message}")
                        }
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Failed to bind AuraHttpServer to port $port: ${e.message}")
            }
        }
    }

    private val cachedHelpBytes by lazy {
        AuraManifestProvider.generateManifestJson().toByteArray(Charsets.UTF_8)
    }

    private val cachedCapabilitiesBytes by lazy {
        val manifest = JSONObject(AuraManifestProvider.generateManifestJson())
        val caps = manifest.optJSONArray("capabilities") ?: org.json.JSONArray()
        val responseObj = JSONObject().apply {
            put("totalCapabilities", manifest.optInt("totalCapabilitiesCount", 42))
            put("categories", manifest.optJSONArray("categories"))
            put("capabilities", caps)
        }
        responseObj.toString(2).toByteArray(Charsets.UTF_8)
    }

    private val cachedCommandsBytes by lazy {
        val manifest = JSONObject(AuraManifestProvider.generateManifestJson())
        val cmds = manifest.optJSONArray("commands") ?: org.json.JSONArray()
        val responseObj = JSONObject().apply {
            put("totalCommands", manifest.optInt("totalCommandsCount", 24))
            put("commands", cmds)
        }
        responseObj.toString(2).toByteArray(Charsets.UTF_8)
    }

    private val cachedHealthBytes by lazy {
        val statusObj = JSONObject().apply {
            put("status", "UP")
            put("server", "Aura Local Media & Device Engine")
            put("totalCapabilities", 42)
            put("totalCommands", 24)
            put("websocketPort", 8000)
            put("httpDocsPort", port)
            put("securityShield", securityShield?.authMode ?: "DISABLED")
        }
        statusObj.toString(2).toByteArray(Charsets.UTF_8)
    }

    private fun handleClient(socket: Socket) {
        socket.use { client ->
            try {
                client.soTimeout = 4000
                val clientIp = client.inetAddress?.hostAddress ?: "127.0.0.1"
                val rawInput = client.getInputStream()
                val out: OutputStream = client.getOutputStream()

                fun readHeaderLine(): String {
                    val sb = StringBuilder()
                    while (true) {
                        val b = rawInput.read()
                        if (b == -1) break
                        if (b == '\n'.code) {
                            if (sb.endsWith("\r")) sb.setLength(sb.length - 1)
                            break
                        }
                        sb.append(b.toChar())
                    }
                    return sb.toString()
                }

                val requestLine = readHeaderLine()
                if (requestLine.isBlank()) return
                val parts = requestLine.split(" ")
                if (parts.size < 2) return

                val method = parts[0].uppercase()
                val rawUri = parts[1]
                val path = rawUri.substringBefore("?")
                val queryString = if (rawUri.contains("?")) rawUri.substringAfter("?") else ""

                // Strict URL & Path Sanitization: Reject path traversal or malformed characters
                if (path.contains("..") || path.contains("\\") || path.contains("\u0000") || path.contains("%2e%2e", ignoreCase = true)) {
                    val badUrlObj = JSONObject().apply {
                        put("success", false)
                        put("error", "400 Bad Request: Malformed or unauthorized URL path detected.")
                    }
                    val badBytes = badUrlObj.toString(2).toByteArray(Charsets.UTF_8)
                    val header = "HTTP/1.1 400 Bad Request\r\nContent-Type: application/json\r\nContent-Length: ${badBytes.size}\r\nConnection: close\r\n\r\n"
                    out.write(header.toByteArray(Charsets.UTF_8))
                    out.write(badBytes)
                    out.flush()
                    return
                }

                // Read headers & capture Origin / Host / Auth
                var contentLength = 0
                var authHeader: String? = null
                var originHeader: String? = null
                var hostHeader: String? = null
                while (true) {
                    val line = readHeaderLine()
                    if (line.isEmpty()) break
                    val headerLower = line.lowercase()
                    if (headerLower.startsWith("content-length:")) {
                        contentLength = headerLower.substringAfter(":").trim().toIntOrNull() ?: 0
                    } else if (headerLower.startsWith("authorization:")) {
                        authHeader = line.substringAfter(":").trim()
                    } else if (headerLower.startsWith("x-api-key:")) {
                        authHeader = line.substringAfter(":").trim()
                    } else if (headerLower.startsWith("origin:")) {
                        originHeader = line.substringAfter(":").trim()
                    } else if (headerLower.startsWith("host:")) {
                        hostHeader = line.substringAfter(":").trim()
                    }
                }

                // Verify Origin URL: Reject unauthorized external web domains from triggering cross-origin actions
                if (!originHeader.isNullOrBlank()) {
                    val originLower = originHeader.lowercase()
                    val isAllowedOrigin = originLower.startsWith("http://127.0.0.1") ||
                            originLower.startsWith("https://127.0.0.1") ||
                            originLower.startsWith("http://localhost") ||
                            originLower.startsWith("https://localhost") ||
                            originLower.startsWith("http://192.168.") ||
                            originLower.startsWith("http://10.") ||
                            originLower.startsWith("http://172.")
                    if (!isAllowedOrigin) {
                        val unauthOriginObj = JSONObject().apply {
                            put("success", false)
                            put("error", "403 Forbidden: Unauthorized Origin URL '$originHeader'. Cross-Origin requests from untrusted domains are rejected.")
                        }
                        val unauthOriginBytes = unauthOriginObj.toString(2).toByteArray(Charsets.UTF_8)
                        val header = "HTTP/1.1 403 Forbidden\r\nContent-Type: application/json\r\nContent-Length: ${unauthOriginBytes.size}\r\nConnection: close\r\n\r\n"
                        out.write(header.toByteArray(Charsets.UTF_8))
                        out.write(unauthOriginBytes)
                        out.flush()
                        return
                    }
                }

                // Handle CORS preflight
                if (method == "OPTIONS") {
                    val header = "HTTP/1.1 204 No Content\r\n" +
                            "Access-Control-Allow-Origin: ${originHeader ?: "*"}\r\n" +
                            "Access-Control-Allow-Methods: GET, POST, OPTIONS\r\n" +
                            "Access-Control-Allow-Headers: Content-Type, Authorization, X-API-Key\r\n" +
                            "Connection: close\r\n\r\n"
                    out.write(header.toByteArray(Charsets.UTF_8))
                    out.flush()
                    return
                }

                // Rate limiting and Lockout check
                if (securityShield != null) {
                    if (securityShield.isIpLockedOut(clientIp)) {
                        val lockObj = JSONObject().apply {
                            put("success", false)
                            put("error", "403 Forbidden: Client IP temporarily locked out due to excessive failed auth attempts. Try again in 60s.")
                        }
                        val lockBytes = lockObj.toString(2).toByteArray(Charsets.UTF_8)
                        val header = buildString {
                            append("HTTP/1.1 403 Forbidden\r\n")
                            append("Content-Type: application/json; charset=utf-8\r\n")
                            append("Content-Length: ${lockBytes.size}\r\n")
                            append("Connection: close\r\n\r\n")
                        }
                        out.write(header.toByteArray(Charsets.UTF_8))
                        out.write(lockBytes)
                        out.flush()
                        return
                    }

                    if (!securityShield.checkRateLimit(clientIp)) {
                        val rateObj = JSONObject().apply {
                            put("success", false)
                            put("error", "429 Too Many Requests: Rate limit exceeded. Maximum 150 requests per minute.")
                        }
                        val rateBytes = rateObj.toString(2).toByteArray(Charsets.UTF_8)
                        val header = buildString {
                            append("HTTP/1.1 429 Too Many Requests\r\n")
                            append("Content-Type: application/json; charset=utf-8\r\n")
                            append("Content-Length: ${rateBytes.size}\r\n")
                            append("Retry-After: 60\r\n")
                            append("Connection: close\r\n\r\n")
                        }
                        out.write(header.toByteArray(Charsets.UTF_8))
                        out.write(rateBytes)
                        out.flush()
                        return
                    }
                }

                // Read body if POST/PUT (max 10MB payload protect)
                var bodyJson = JSONObject()
                val safeContentLength = contentLength.coerceAtMost(10 * 1024 * 1024)
                if (safeContentLength > 0) {
                    val bodyBytes = ByteArray(safeContentLength)
                    var readCount = 0
                    while (readCount < safeContentLength) {
                        val read = rawInput.read(bodyBytes, readCount, safeContentLength - readCount)
                        if (read <= 0) break
                        readCount += read
                    }
                    val bodyString = String(bodyBytes, 0, readCount, Charsets.UTF_8)
                    if (bodyString.isNotBlank()) {
                        try {
                            bodyJson = JSONObject(bodyString)
                        } catch (e: Exception) {
                            bodyJson.put("raw", bodyString)
                        }
                    }
                }

                var queryToken: String? = null
                // Populate query string parameters if not already in JSON body
                if (queryString.isNotBlank()) {
                    queryString.split("&").forEach { param ->
                        val kv = param.split("=", limit = 2)
                        if (kv.isNotEmpty()) {
                            val k = java.net.URLDecoder.decode(kv[0], "UTF-8")
                            val v = if (kv.size > 1) java.net.URLDecoder.decode(kv[1], "UTF-8") else "true"
                            if (k.equals("token", ignoreCase = true) || k.equals("apiKey", ignoreCase = true) || k.equals("api_key", ignoreCase = true)) {
                                queryToken = v
                            }
                            if (!bodyJson.has(k)) {
                                if (v.equals("true", ignoreCase = true)) bodyJson.put(k, true)
                                else if (v.equals("false", ignoreCase = true)) bodyJson.put(k, false)
                                else bodyJson.put(k, v)
                            }
                        }
                    }
                }

                // Authentication verification on /api/* endpoints
                if (path.startsWith("/api/") && securityShield != null) {
                    val isAuthorized = securityShield.verifyRequest(clientIp, authHeader, queryToken)
                    if (!isAuthorized) {
                        val unauthObj = JSONObject().apply {
                            put("success", false)
                            put("error", "401 Unauthorized: Valid Bearer token or API key required.")
                            put("authMode", securityShield.authMode)
                            put("hint", "Pass header 'Authorization: Bearer <token>' or query param '?token=<token>'.")
                        }
                        val unauthBytes = unauthObj.toString(2).toByteArray(Charsets.UTF_8)
                        val header = buildString {
                            append("HTTP/1.1 401 Unauthorized\r\n")
                            append("Content-Type: application/json; charset=utf-8\r\n")
                            append("Content-Length: ${unauthBytes.size}\r\n")
                            append("WWW-Authenticate: Bearer realm=\"AuraSecureAPI\"\r\n")
                            append("Connection: close\r\n\r\n")
                        }
                        out.write(header.toByteArray(Charsets.UTF_8))
                        out.write(unauthBytes)
                        out.flush()
                        return
                    }
                }

                val (statusCode, bodyBytes) = when {
                    path == "/" || path == "/help" || path == "/docs" || path == "/manifest" -> {
                        Pair("200 OK", cachedHelpBytes)
                    }
                    path == "/capabilities" -> {
                        Pair("200 OK", cachedCapabilitiesBytes)
                    }
                    path == "/commands" -> {
                        Pair("200 OK", cachedCommandsBytes)
                    }
                    path == "/health" || path == "/status" -> {
                        Pair("200 OK", cachedHealthBytes)
                    }
                    path.startsWith("/api/") && onApiRequest != null -> {
                        try {
                            val apiResult = onApiRequest.invoke(path, bodyJson)
                            Pair("200 OK", apiResult.toString(2).toByteArray(Charsets.UTF_8))
                        } catch (e: Exception) {
                            val errObj = JSONObject().apply {
                                put("success", false)
                                put("error", e.message ?: "API Error")
                            }
                            Pair("500 Internal Server Error", errObj.toString(2).toByteArray(Charsets.UTF_8))
                        }
                    }
                    else -> {
                        val notFoundObj = JSONObject().apply {
                            put("error", "Not Found")
                            put("availableEndpoints", listOf("/help", "/capabilities", "/commands", "/health", "/api/*"))
                        }
                        Pair("404 Not Found", notFoundObj.toString(2).toByteArray(Charsets.UTF_8))
                    }
                }

                val header = buildString {
                    append("HTTP/1.1 $statusCode\r\n")
                    append("Content-Type: application/json; charset=utf-8\r\n")
                    append("Content-Length: ${bodyBytes.size}\r\n")
                    append("Access-Control-Allow-Origin: *\r\n")
                    append("Access-Control-Allow-Methods: GET, POST, OPTIONS\r\n")
                    append("Access-Control-Allow-Headers: Content-Type, Authorization, X-API-Key\r\n")
                    // OWASP Hardened Security Headers
                    securityShield?.getSecurityHeaders()?.forEach { (k, v) ->
                        append("$k: $v\r\n")
                    }
                    append("Connection: close\r\n")
                    append("\r\n")
                }
                out.write(header.toByteArray(Charsets.UTF_8))
                out.write(bodyBytes)
                out.flush()
            } catch (e: Exception) {
                Log.e(TAG, "Error handling HTTP client request: ${e.message}")
            }
        }
    }

    fun stop() {
        try {
            serverSocket?.close()
        } catch (e: Exception) {
            // Ignore
        }
        serverJob?.cancel()
    }
}
