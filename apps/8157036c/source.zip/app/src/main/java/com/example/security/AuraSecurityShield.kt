package com.example.security

import android.content.Context
import android.os.Build
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.concurrent.ConcurrentHashMap
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

/**
 * Data class representing a registered / paired client device.
 */
data class PairedClient(
    val deviceId: String,
    val clientName: String,
    val clientToken: String,
    val clientIp: String,
    val pairedAt: Long,
    var lastSeenAt: Long = System.currentTimeMillis(),
    var isRevoked: Boolean = false
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("deviceId", deviceId)
        put("clientName", clientName)
        put("clientTokenPrefix", clientToken.take(12) + "...")
        put("clientIp", clientIp)
        put("pairedAt", pairedAt)
        put("lastSeenAt", lastSeenAt)
        put("isRevoked", isRevoked)
    }
}

/**
 * Data class representing an interactive 1-tap approval pairing request from a remote client.
 */
data class PendingPairRequest(
    val requestId: String,
    val clientName: String,
    val clientIp: String,
    val deviceId: String,
    val requestedAt: Long = System.currentTimeMillis(),
    var status: String = "PENDING", // PENDING, APPROVED, DENIED
    var clientToken: String? = null
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("requestId", requestId)
        put("clientName", clientName)
        put("clientIp", clientIp)
        put("deviceId", deviceId)
        put("requestedAt", requestedAt)
        put("status", status)
        if (clientToken != null) {
            put("clientToken", clientToken)
        }
    }
}

/**
 * High-Security, Zero-Friction Defense Shield for Aura HTTP REST API, WebSocket Automation Bridge, & AeroShare.
 *
 * Capabilities:
 * - 1-Tap Biometric / Notification Approval: Pair remote devices effortlessly from phone prompts.
 * - 6-Digit Dynamic Device Pairing fallback PIN.
 * - Persistent Paired Client Device Trust Registry with instant revocation.
 * - Panic Lockdown switch for instant remote freeze.
 * - Constant-time cryptographic token verification (Timing-attack resistant).
 * - Per-IP Sliding-Window Rate Limiting (150 req/min) & Brute-Force IP Lockouts.
 * - Biometric / Face Authentication status and policies.
 * - OWASP Hardened Security Headers on all HTTP responses.
 */
class AuraSecurityShield(private val context: Context) {

    private val TAG = "AuraSecurityShield"
    private val prefs = context.getSharedPreferences("aura_security_shield_v2", Context.MODE_PRIVATE)

    companion object {
        const val AUTH_MODE_STRICT = "STRICT"           // Every request requires registered token (Wi-Fi & LAN hardened)
        const val AUTH_MODE_LOCAL_TRUST = "LOCAL_TRUST" // Loopback (127.0.0.1) auto-authorized, Wi-Fi LAN strictly requires pairing
        const val AUTH_MODE_OPEN = "OPEN"               // Open development mode

        private const val MAX_REQUESTS_PER_MINUTE = 150
        private const val MAX_FAILED_ATTEMPTS = 5
        private const val LOCKOUT_DURATION_MS = 60_000L // 60s lockout
        private const val PAIRING_CODE_VALIDITY_MS = 5 * 60_000L // 5 minutes validity
    }

    // Dynamic Master Secret Token
    val masterApiToken: String
        get() = prefs.getString("master_api_token", null) ?: generateAndStoreMasterToken()

    var authMode: String
        get() = prefs.getString("auth_mode", AUTH_MODE_LOCAL_TRUST) ?: AUTH_MODE_LOCAL_TRUST
        set(value) = prefs.edit().putString("auth_mode", value).apply()

    var isPanicLockdown: Boolean
        get() = prefs.getBoolean("panic_lockdown", false)
        set(value) = prefs.edit().putBoolean("panic_lockdown", value).apply()

    var requireBiometricsForPairing: Boolean
        get() = prefs.getBoolean("require_biometric_pairing", true)
        set(value) = prefs.edit().putBoolean("require_biometric_pairing", value).apply()

    var requireBiometricsForRemoteActions: Boolean
        get() = prefs.getBoolean("require_biometric_actions", false)
        set(value) = prefs.edit().putBoolean("require_biometric_actions", value).apply()

    // 6-digit active pairing code & expiry timestamp
    @Volatile
    private var currentPairingCode: String? = null
    @Volatile
    private var pairingCodeExpiryMs: Long = 0L

    // Paired Clients Registry: deviceId -> PairedClient
    private val pairedClients = ConcurrentHashMap<String, PairedClient>()

    // Token -> deviceId mapping for ultra-fast constant-time lookups
    private val tokenToDeviceIdMap = ConcurrentHashMap<String, String>()

    // Pending 1-tap Pair Requests: requestId -> PendingPairRequest
    private val pendingPairRequests = ConcurrentHashMap<String, PendingPairRequest>()

    private val _latestPendingPairRequest = MutableStateFlow<PendingPairRequest?>(null)
    val latestPendingPairRequest: StateFlow<PendingPairRequest?> = _latestPendingPairRequest.asStateFlow()

    // Rate Limiting Storage: IP -> (windowStartTimeMs, requestCount)
    private val rateLimitMap = ConcurrentHashMap<String, Pair<Long, Int>>()

    // Brute-force Tracking: IP -> (failedCount, lockoutUntilMs)
    private val failedAttemptsMap = ConcurrentHashMap<String, Pair<Int, Long>>()

    init {
        if (!prefs.contains("master_api_token")) {
            generateAndStoreMasterToken()
        }
        loadPairedClients()
        generatePairingCode()
    }

    private fun generateAndStoreMasterToken(): String {
        val randomBytes = ByteArray(24)
        SecureRandom().nextBytes(randomBytes)
        val token = "aura_sec_" + randomBytes.joinToString("") { "%02x".format(it) }
        prefs.edit().putString("master_api_token", token).apply()
        Log.i(TAG, "Generated master secure API Token: ${token.take(15)}...")
        return token
    }

    /**
     * Generates a new 6-digit cryptographic pairing code valid for 5 minutes.
     */
    @Synchronized
    fun generatePairingCode(): String {
        val secureRandom = SecureRandom()
        val code = String.format("%06d", secureRandom.nextInt(1_000_000))
        currentPairingCode = code
        pairingCodeExpiryMs = System.currentTimeMillis() + PAIRING_CODE_VALIDITY_MS
        Log.i(TAG, "New 6-digit Device Pairing Code generated: $code (Valid for 5 mins)")
        return code
    }

    /**
     * Gets the active pairing code (regenerating if expired).
     */
    fun getActivePairingCode(): Pair<String, Long> {
        val now = System.currentTimeMillis()
        if (currentPairingCode == null || now > pairingCodeExpiryMs) {
            val newCode = generatePairingCode()
            return Pair(newCode, pairingCodeExpiryMs - now)
        }
        return Pair(currentPairingCode!!, (pairingCodeExpiryMs - now).coerceAtLeast(0L))
    }

    /**
     * Creates an interactive 1-tap pending pairing request from a remote device.
     */
    @Synchronized
    fun createPendingPairRequest(
        clientName: String,
        clientIp: String,
        providedDeviceId: String? = null
    ): PendingPairRequest {
        val reqId = "req_" + SecureRandom().nextInt(1_000_000)
        val devId = providedDeviceId?.ifBlank { null } ?: "dev_" + SecureRandom().nextInt(1_000_000)
        val request = PendingPairRequest(
            requestId = reqId,
            clientName = clientName.ifBlank { "Remote Device ($clientIp)" },
            clientIp = clientIp,
            deviceId = devId
        )
        pendingPairRequests[reqId] = request
        _latestPendingPairRequest.value = request
        Log.i(TAG, "Created 1-tap pending pair request: $reqId for ${request.clientName}")
        return request
    }

    /**
     * Approves a pending pair request and generates the permanent client token.
     */
    @Synchronized
    fun approvePendingPairRequest(requestId: String): Pair<Boolean, String?> {
        val req = pendingPairRequests[requestId] ?: return Pair(false, "Request ID not found")
        val now = System.currentTimeMillis()

        val randomBytes = ByteArray(24)
        SecureRandom().nextBytes(randomBytes)
        val clientToken = "aura_cli_" + randomBytes.joinToString("") { "%02x".format(it) }

        val paired = PairedClient(
            deviceId = req.deviceId,
            clientName = req.clientName,
            clientToken = clientToken,
            clientIp = req.clientIp,
            pairedAt = now,
            lastSeenAt = now,
            isRevoked = false
        )

        pairedClients[req.deviceId] = paired
        tokenToDeviceIdMap[clientToken] = req.deviceId
        savePairedClients()

        req.status = "APPROVED"
        req.clientToken = clientToken

        if (_latestPendingPairRequest.value?.requestId == requestId) {
            _latestPendingPairRequest.value = null
        }

        Log.i(TAG, "1-Tap Pair Request APPROVED: ${req.clientName} (Token: ${clientToken.take(12)}...)")
        return Pair(true, clientToken)
    }

    /**
     * Denies a pending pair request.
     */
    @Synchronized
    fun denyPendingPairRequest(requestId: String): Boolean {
        val req = pendingPairRequests[requestId] ?: return false
        req.status = "DENIED"
        if (_latestPendingPairRequest.value?.requestId == requestId) {
            _latestPendingPairRequest.value = null
        }
        Log.i(TAG, "1-Tap Pair Request DENIED: ${req.clientName}")
        return true
    }

    fun dismissPendingPairRequest() {
        _latestPendingPairRequest.value = null
    }

    fun getPendingPairRequest(requestId: String): PendingPairRequest? {
        return pendingPairRequests[requestId]
    }

    fun listPendingPairRequests(): List<PendingPairRequest> {
        return pendingPairRequests.values.filter { it.status == "PENDING" }
    }

    /**
     * Registers and pairs a new client device using the 6-digit pairing code or master token.
     */
    @Synchronized
    fun pairClientDevice(
        pairingCodeOrToken: String,
        clientName: String,
        clientIp: String,
        providedDeviceId: String? = null
    ): Pair<Boolean, String> {
        val now = System.currentTimeMillis()
        val candidate = pairingCodeOrToken.trim()

        val isCodeValid = currentPairingCode != null &&
                now <= pairingCodeExpiryMs &&
                constantTimeEquals(candidate, currentPairingCode!!)

        val isMasterToken = constantTimeEquals(candidate, masterApiToken)

        if (!isCodeValid && !isMasterToken) {
            recordFailedAttempt(clientIp)
            return Pair(false, "Invalid or expired pairing code.")
        }

        // Generate high-entropy client session token
        val deviceId = providedDeviceId?.ifBlank { null } ?: "dev_" + SecureRandom().nextInt(1_000_000)
        val randomBytes = ByteArray(24)
        SecureRandom().nextBytes(randomBytes)
        val clientToken = "aura_cli_" + randomBytes.joinToString("") { "%02x".format(it) }

        val paired = PairedClient(
            deviceId = deviceId,
            clientName = clientName.ifBlank { "Remote Client ($clientIp)" },
            clientToken = clientToken,
            clientIp = clientIp,
            pairedAt = now,
            lastSeenAt = now,
            isRevoked = false
        )

        pairedClients[deviceId] = paired
        tokenToDeviceIdMap[clientToken] = deviceId
        savePairedClients()

        // Rotate pairing code after successful pairing to prevent reuse
        generatePairingCode()
        failedAttemptsMap.remove(clientIp)

        Log.i(TAG, "Device successfully paired: ${paired.clientName} (ID: $deviceId)")
        return Pair(true, clientToken)
    }

    /**
     * Revokes access for a paired device ID.
     */
    @Synchronized
    fun revokeClientDevice(deviceId: String): Boolean {
        val client = pairedClients[deviceId] ?: return false
        client.isRevoked = true
        tokenToDeviceIdMap.remove(client.clientToken)
        pairedClients.remove(deviceId)
        savePairedClients()
        Log.i(TAG, "Device pairing revoked: $deviceId")
        return true
    }

    /**
     * Lists all currently registered paired devices.
     */
    fun listPairedDevices(): List<PairedClient> {
        return pairedClients.values.toList()
    }

    /**
     * Checks if client IP is temporarily locked out.
     */
    fun isIpLockedOut(clientIp: String): Boolean {
        if (isPanicLockdown && !isLoopback(clientIp)) {
            return true
        }

        val entry = failedAttemptsMap[clientIp] ?: return false
        val now = System.currentTimeMillis()
        if (entry.first >= MAX_FAILED_ATTEMPTS) {
            if (now < entry.second) {
                return true
            } else {
                failedAttemptsMap.remove(clientIp)
            }
        }
        return false
    }

    /**
     * Checks and increments rate limit for client IP.
     */
    fun checkRateLimit(clientIp: String): Boolean {
        val now = System.currentTimeMillis()
        val entry = rateLimitMap[clientIp]

        if (entry == null || now - entry.first > 60_000L) {
            rateLimitMap[clientIp] = Pair(now, 1)
            return true
        }

        val count = entry.second
        if (count >= MAX_REQUESTS_PER_MINUTE) {
            Log.w(TAG, "Rate limit exceeded for client: $clientIp ($count reqs/min)")
            return false
        }

        rateLimitMap[clientIp] = Pair(entry.first, count + 1)
        return true
    }

    /**
     * Verifies if an HTTP request is authorized.
     */
    fun verifyRequest(clientIp: String, providedAuthHeader: String?, providedQueryToken: String?): Boolean {
        if (isPanicLockdown && !isLoopback(clientIp)) {
            Log.w(TAG, "Blocked request during PANIC LOCKDOWN from IP: $clientIp")
            return false
        }

        if (isIpLockedOut(clientIp)) {
            Log.w(TAG, "Blocked request from locked-out IP: $clientIp")
            return false
        }

        val isLocal = isLoopback(clientIp)

        if (authMode == AUTH_MODE_OPEN) {
            return true
        }

        if (authMode == AUTH_MODE_LOCAL_TRUST && isLocal) {
            return true
        }

        val candidate = extractToken(providedAuthHeader, providedQueryToken)
        if (candidate.isNullOrBlank()) {
            recordFailedAttempt(clientIp)
            return false
        }

        val isAuthorized = verifyToken(candidate, clientIp)
        if (isAuthorized) {
            failedAttemptsMap.remove(clientIp)
            return true
        } else {
            recordFailedAttempt(clientIp)
            return false
        }
    }

    /**
     * Validates candidate token against master API token or active paired client tokens.
     */
    fun verifyToken(candidate: String, clientIp: String): Boolean {
        if (isPanicLockdown && !isLoopback(clientIp)) {
            return false
        }

        // 1. Check Master Token
        if (constantTimeEquals(candidate, masterApiToken)) {
            return true
        }

        // 2. Check Paired Clients Registry
        val deviceId = tokenToDeviceIdMap[candidate]
        if (deviceId != null) {
            val client = pairedClients[deviceId]
            if (client != null && !client.isRevoked) {
                client.lastSeenAt = System.currentTimeMillis()
                return true
            }
        }

        // Fallback linear scan with constant-time equality
        for (client in pairedClients.values) {
            if (!client.isRevoked && constantTimeEquals(candidate, client.clientToken)) {
                client.lastSeenAt = System.currentTimeMillis()
                tokenToDeviceIdMap[client.clientToken] = client.deviceId
                return true
            }
        }

        return false
    }

    private fun extractToken(authHeader: String?, queryToken: String?): String? {
        if (!authHeader.isNullOrBlank()) {
            val trimmed = authHeader.trim()
            if (trimmed.startsWith("Bearer ", ignoreCase = true)) {
                return trimmed.substring(7).trim()
            }
            if (trimmed.startsWith("ApiKey ", ignoreCase = true)) {
                return trimmed.substring(7).trim()
            }
            return trimmed
        }
        if (!queryToken.isNullOrBlank()) {
            return queryToken.trim()
        }
        return null
    }

    private fun recordFailedAttempt(clientIp: String) {
        val now = System.currentTimeMillis()
        val entry = failedAttemptsMap[clientIp]
        val currentCount = (entry?.first ?: 0) + 1
        val lockoutUntil = if (currentCount >= MAX_FAILED_ATTEMPTS) now + LOCKOUT_DURATION_MS else 0L

        failedAttemptsMap[clientIp] = Pair(currentCount, lockoutUntil)
        Log.w(TAG, "Failed auth attempt $currentCount/$MAX_FAILED_ATTEMPTS from IP: $clientIp")
    }

    fun isLoopback(ip: String): Boolean {
        return ip == "127.0.0.1" || ip == "0:0:0:0:0:0:0:1" || ip == "::1" || ip == "localhost"
    }

    /**
     * Constant-time equality check to eliminate timing side-channel attacks.
     */
    private fun constantTimeEquals(a: String, b: String): Boolean {
        val aBytes = a.toByteArray(Charsets.UTF_8)
        val bBytes = b.toByteArray(Charsets.UTF_8)
        return MessageDigest.isEqual(aBytes, bBytes)
    }

    /**
     * Computes HMAC-SHA256 signature for payload verification.
     */
    fun signPayload(payload: String): String {
        val mac = Mac.getInstance("HmacSHA256")
        val secretKey = SecretKeySpec(masterApiToken.toByteArray(Charsets.UTF_8), "HmacSHA256")
        mac.init(secretKey)
        val hash = mac.doFinal(payload.toByteArray(Charsets.UTF_8))
        return hash.joinToString("") { "%02x".format(it) }
    }

    /**
     * Verifies HMAC-SHA256 signature.
     */
    fun verifySignature(payload: String, signatureHex: String): Boolean {
        val expected = signPayload(payload)
        return constantTimeEquals(expected, signatureHex)
    }

    /**
     * Returns standard OWASP hardened security headers.
     */
    fun getSecurityHeaders(): Map<String, String> {
        return mapOf(
            "X-Content-Type-Options" to "nosniff",
            "X-Frame-Options" to "DENY",
            "X-XSS-Protection" to "1; mode=block",
            "Content-Security-Policy" to "default-src 'self'",
            "Strict-Transport-Security" to "max-age=31536000; includeSubDomains",
            "Cache-Control" to "no-store, no-cache, must-revalidate, private",
            "Server" to "AuraSecurityShield/3.0"
        )
    }

    /**
     * Saves paired devices to persistent SharedPreferences.
     */
    private fun savePairedClients() {
        try {
            val array = JSONArray()
            pairedClients.values.forEach { client ->
                val obj = JSONObject().apply {
                    put("deviceId", client.deviceId)
                    put("clientName", client.clientName)
                    put("clientToken", client.clientToken)
                    put("clientIp", client.clientIp)
                    put("pairedAt", client.pairedAt)
                    put("lastSeenAt", client.lastSeenAt)
                    put("isRevoked", client.isRevoked)
                }
                array.put(obj)
            }
            prefs.edit().putString("paired_clients_json", array.toString()).apply()
        } catch (e: Exception) {
            Log.e(TAG, "Failed to persist paired clients", e)
        }
    }

    /**
     * Loads paired devices from persistent storage.
     */
    private fun loadPairedClients() {
        try {
            val jsonStr = prefs.getString("paired_clients_json", null) ?: return
            val array = JSONArray(jsonStr)
            pairedClients.clear()
            tokenToDeviceIdMap.clear()
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                val client = PairedClient(
                    deviceId = obj.getString("deviceId"),
                    clientName = obj.optString("clientName", "Paired Client"),
                    clientToken = obj.getString("clientToken"),
                    clientIp = obj.optString("clientIp", ""),
                    pairedAt = obj.optLong("pairedAt", System.currentTimeMillis()),
                    lastSeenAt = obj.optLong("lastSeenAt", System.currentTimeMillis()),
                    isRevoked = obj.optBoolean("isRevoked", false)
                )
                if (!client.isRevoked) {
                    pairedClients[client.deviceId] = client
                    tokenToDeviceIdMap[client.clientToken] = client.deviceId
                }
            }
            Log.i(TAG, "Loaded ${pairedClients.size} active paired devices from secure storage.")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to load paired clients from storage", e)
        }
    }
}
