# How to Use Aura Companion & Termux Automation Bridge (`use.md`)

A comprehensive, step-by-step user manual and reference guide for the **Aura AI Companion & Termux Automation Bridge**.

---

## 📑 Table of Contents

1. [System Overview](#1-system-overview)
2. [First-Time Setup & Required Permissions](#2-first-time-setup--required-permissions)
3. [App UI Guide (Screens & Navigation)](#3-app-ui-guide-screens--navigation)
   - [Dashboard (Home Screen)](#31-dashboard-home-screen)
   - [Developer Screen & Terminal Monitor](#32-developer-screen--terminal-monitor)
   - [Capability Dashboard (52+ Hardware Modules)](#33-capability-dashboard-52-hardware-modules)
   - [Speech Diagnostics & PCM Audio Streaming](#34-speech-diagnostics--pcm-audio-streaming)
   - [Accessibility Dashboard (Screen Inspector & Gestures)](#35-accessibility-dashboard-screen-inspector--gestures)
   - [Tools & AIOS Multi-Agent Dashboard](#36-tools--aios-multi-agent-dashboard)
   - [Settings Screen](#37-settings-screen)
4. [Method 1: Instant Zero-Setup Local Control via HTTP REST (Port 8080)](#4-method-1-instant-zero-setup-local-control-via-http-rest-port-8080)
   - [Checking Server Status & Documentation](#41-checking-server-status--documentation)
   - [Text-to-Speech (TTS)](#42-text-to-speech-tts)
   - [Custom On-Screen Toasts](#43-custom-on-screen-toasts)
   - [Haptics & Vibration](#44-haptics--vibration)
   - [Camera Flashlight / Torch](#45-camera-flashlight--torch)
   - [Audio Playback & Volume Control](#46-audio-playback--volume-control)
   - [Floating HUD Overlay Over Any App](#47-floating-hud-overlay-over-any-app)
   - [Live Hardware Sensors Snapshot](#48-live-hardware-sensors-snapshot)
   - [Device Specs, Battery & Thermals](#49-device-specs-battery--thermals)
   - [Network Diagnostics & Telemetry](#410-network-diagnostics--telemetry)
   - [App Launcher & Process Manager](#411-app-launcher--process-manager)
   - [System Notifications](#412-system-notifications)
   - [AeroShare High-Speed P2P File Transfer & Device Discovery](#413-aeroshare-high-speed-p2p-file-transfer--device-discovery)
   - [Universal Intent & URL Opener](#414-universal-intent--url-opener)
   - [Audio Tone & Alert Frequency Generator](#415-audio-tone--alert-frequency-generator)
   - [Battery & Power Diagnostics](#416-battery--power-diagnostics)
   - [System Navigation & Accessibility Actions](#417-system-navigation--accessibility-actions)
   - [Media Playback Controls](#418-media-playback-controls)
   - [Device Storage & File System Explorer](#419-device-storage--file-system-explorer)
   - [SMS & Messages Composer](#420-sms--messages-composer)
   - [Endpoint Security Shield & Token Authentication](#421-endpoint-security-shield--token-authentication)
   - [Face & Biometric Device Authorization Workflow](#422-face--biometric-device-authorization-workflow)
   - [Battery Optimization & Background Execution Setup](#423-battery-optimization--background-execution-setup)
   - [Panic Lockdown & Device Revocation](#424-panic-lockdown--device-revocation)
5. [Method 2: Real-Time Full Automation via Termux WebSocket (Port 8000)](#5-method-2-real-time-full-automation-via-termux-websocket-port-8000)
   - [Step 1: Install Termux Dependencies](#step-1-install-termux-dependencies)
   - [Step 2: Start the WebSocket Relay Server](#step-2-start-the-websocket-relay-server)
   - [Step 3: Connect the Android App](#step-3-connect-the-android-app)
   - [Step 4: Automate Android via CLI (`send_cmd.py`)](#step-4-automate-android-via-cli-send_cmdpy)
6. [Real-Time Audio Streaming (Voice to Termux / AI)](#6-real-time-audio-streaming-voice-to-termux--ai)
7. [FFmpeg Media Processing Engine](#7-ffmpeg-media-processing-engine)
8. [Troubleshooting & FAQ](#8-troubleshooting--faq)

---

## 1. System Overview

Aura operates as a **dual-engine Android system**:

```text
┌────────────────────────────────────────────────────────────────────────┐
│                          ANDROID DEVICE (AURA)                         │
│                                                                        │
│   [Jetpack Compose UI] ◄──► [Aura Core Service & Background Engine]   │
│                                      │                                 │
│        ┌─────────────────────────────┴─────────────────────────────┐   │
│        ▼                                                           ▼   │
│  HTTP REST Server                                         WebSocket Client │
│  (Port 8080)                                              (Port 8000)  │
│  • Embedded documentation (/help)                         • Realtime PCM Audio│
│  • Instant curl commands                                  • Node Inspection │
│  • Zero dependencies needed                               • Touch Gestures  │
└────────▲───────────────────────────────────────────────────────────▲───┘
         │ curl http://127.0.0.1:8080/api/*                          │ ws://127.0.0.1:8000
┌────────┴───────────────────────────────────────────────────────────┴───┐
│                        TERMUX / LINUX / PYTHON                         │
│                                                                        │
│   • bash scripts with curl         • Python scripts (send_cmd.py)      │
│   • Background AI agents           • Cloudflare Tunnel (Remote Access) │
└────────────────────────────────────────────────────────────────────────┘
```

1. **Standalone Android Companion**: Features a Material Design 3 interface, multi-agent AI task planner (AIOS), local Room database persistence, and microphone audio capture.
2. **Embedded HTTP REST Server (Port 8080)**: Automatically starts whenever the app opens. Allows you to control hardware (flashlight, TTS, vibration, volume, toasts, sensors, HUDs) using standard `curl` commands directly from Termux without running any servers.
3. **Termux WebSocket Remote Bridge (Port 8000)**: Provides high-speed bi-directional telemetry, 16kHz raw PCM voice streaming, accessibility tree inspection (reading text and buttons on any Android app), and programmatic touch gestures (clicks, swipes, system back/home).

---

## 2. First-Time Setup & Required Permissions

When launching Aura for the first time, grant the necessary permissions to unlock hardware capabilities:

### Standard Android Permissions (Prompted in App)
- **Microphone (`RECORD_AUDIO`)**: For voice capture, live PCM audio streaming, and voice diagnostics.
- **Camera (`CAMERA`)**: For camera capture and flashlight/torch control.
- **Location (`ACCESS_FINE_LOCATION`)**: For GPS coordinates, altitude, and telemetry.
- **Notifications (`POST_NOTIFICATIONS`)**: For background service alerts and status notifications.

### Special System Permissions (Enabled via Android Settings)

1. **Accessibility Service (Required for Touch Gestures & Screen Reading)**:
   - Go to your Android device **Settings** ➔ **Accessibility** (or **Downloaded apps**).
   - Find **Termux Assistant** (or **Aura Accessibility Service**).
   - Toggle **ON** and confirm the dialog.
   - *Why:* This allows Aura to read on-screen UI hierarchies and dispatch taps, swipes, and hardware keypresses (Back, Home, Recents).

2. **Display Over Other Apps (Required for Floating HUDs / Overlays)**:
   - Go to **Settings** ➔ **Apps** ➔ **Special app access** ➔ **Display over other apps**.
   - Select **AI Companion** (or **Aura**).
   - Toggle **Allow display over other apps**.
   - *Why:* Enables draggable floating statistics, status pills, and developer HUDs while using other apps.

3. **Modify System Settings (Optional, for Screen Brightness)**:
   - Go to **Settings** ➔ **Apps** ➔ **Special app access** ➔ **Modify system settings**.
   - Enable for the app if you wish to adjust system screen brightness via remote commands.

---

## 3. App UI Guide (Screens & Navigation)

### 3.1 Dashboard (Home Screen)
The primary control center of the application:
- **Header Status**: Displays real-time engine health, connection indicator (Connected / Disconnected / Connecting), and round-trip latency.
- **Aura Hero Orb**: Reactive visualizer pulsing with voice amplitude and connection states.
- **Aura Voice Dock**: Bottom action bar containing the **Microphone Button**. Tap to begin streaming 16kHz 16-bit linear PCM audio.
- **Quick Cards**:
  - *Core Engine Card*: Shows active background threads, worker statuses, and memory footprint.
  - *Persistence Card*: Shows Room SQLite database records and cached telemetry events.
  - *Audio Diagnostics Card*: Displays active audio recording state, sample rate (16kHz), and buffer chunks.
  - *Service Status Card*: Displays the state of the Foreground Service ensuring background persistence.
- **Navigation Icons**:
  - `⚙️` **Settings**: Server URL, reconnect preferences, and theme options.
  - `{ }` **Developer Terminal**: Live WebSocket logs, RTT ping meter, and manual triggers.
  - `🎙️` **Speech Diagnostics**: Live waveform visualization and microphone telemetry.
  - `🧠` **Conversation Engine**: Direct chat interface with the multi-agent AI system.

### 3.2 Developer Screen & Terminal Monitor
Accessed via the `{ }` icon on the Dashboard:
- **Live Event Log Stream**: Real-time console showing all incoming and outgoing WebSocket frames, HTTP API requests, and system events.
- **Interactive Ping**: Sends an immediate keepalive `PING` packet and measures real-time RTT latency in milliseconds.
- **Quick Action Bar**: Buttons to trigger a quick Toast, test TTS speech, or inspect permissions.
- **Navigation Hub**: Direct links to **Capabilities**, **Tools Framework**, and **Accessibility**.

### 3.3 Capability Dashboard (52+ Hardware Modules)
Accessed from the Developer Screen:
- Displays all **52 hardware capabilities** categorized into:
  - `AUDIO`, `CAMERA`, `MEDIA`, `LOCATION`, `SENSORS`, `BLUETOOTH`, `NETWORK`, `NOTIFICATIONS`, `CLIPBOARD`, `DEVICE_INFO`, `ACCESSIBILITY`, `STORAGE`, `FFMPEG`.
- Displays real-time permission status: `AVAILABLE`, `PERMISSION_REQUIRED`, or `HARDWARE_MISSING`.
- Interactive testing cards allow you to directly trigger haptics, read accelerometer vectors, view battery temperature, and toggle the flashlight directly in the UI.

### 3.4 Speech Diagnostics & PCM Audio Streaming
Accessed via the microphone icon or Developer menu:
- **Live Waveform Display**: Renders real-time audio amplitude graphs as you speak.
- **Audio Stream Telemetry**: Displays chunk sequence numbers, Base64 payload throughput, and audio buffer duration.
- **Audio Controls**: Toggle recording or push-to-talk to stream raw audio over WebSocket.

### 3.5 Accessibility Dashboard (Screen Inspector & Gestures)
Accessed from the Developer Screen:
- **Service Status Banner**: Confirms whether the Accessibility Service is active in Android Settings.
- **Inspect Foreground Window**: Captures the current view hierarchy and lists every button, text field, content description, and clickable coordinate.
- **Gesture Simulation**: Test tapping specific coordinates or performing swipe actions.

### 3.6 Tools & AIOS Multi-Agent Dashboard
Accessed from the Developer Screen:
- Inspects the **15 specialized AI agents** (Conversation, Planner, Coding, Document, Media, Vision, Calendar, Notification, etc.).
- Displays the Task Planning DAG execution engine and active background event bus topics.

### 3.7 Settings Screen
Accessed via the `⚙️` gear icon on the Dashboard:
- **Server WebSocket URL**: Configure the server address (default: `ws://127.0.0.1:8000/ws` or a public Cloudflare tunnel `wss://...`).
- **Auto-Reconnect**: Enable automatic reconnection with exponential backoff.
- **Audio Sampling**: Toggle 16kHz audio streaming parameters.
- **Display & WakeLock**: Keep the screen awake during automation tasks.
- **App Permissions**: Quick shortcuts to review and grant any missing permissions.

---

## 4. Method 1: Instant Zero-Setup Local Control via HTTP REST (Port 8080)

> **No installation or Python scripts required!**
> As soon as the Aura app is opened on the phone, an embedded HTTP REST server automatically listens on **`http://127.0.0.1:8080`**.
> You can immediately execute commands from Termux using standard `curl`.

### 4.1 Checking Server Status & Documentation

```bash
# View complete live documentation and available endpoints
curl http://127.0.0.1:8080/help

# List all 52 supported hardware capabilities and their statuses
curl http://127.0.0.1:8080/capabilities

# List all supported remote commands and JSON schemas
curl http://127.0.0.1:8080/commands

# Quick health check
curl http://127.0.0.1:8080/health
```

---

### 4.2 Text-to-Speech (TTS)
Speak text aloud using Android's native voice engine:

```bash
# Speak with default pitch and rate
curl -X POST http://127.0.0.1:8080/api/tts \
  -H "Content-Type: application/json" \
  -d '{"text": "Build complete. All unit tests passed!"}'

# Speak with custom pitch and speed rate
curl -X POST http://127.0.0.1:8080/api/tts \
  -H "Content-Type: application/json" \
  -d '{"text": "Warning: High memory utilization detected.", "pitch": 1.2, "rate": 1.1}'
```

---

### 4.3 Custom On-Screen Toasts
Show beautiful custom toasts with customizable gravity and colors:

```bash
# Basic Toast
curl -X POST http://127.0.0.1:8080/api/toast \
  -H "Content-Type: application/json" \
  -d '{"message": "Deployment Successful!", "icon": "success"}'

# Styled Toast at the top of the screen
curl -X POST http://127.0.0.1:8080/api/toast \
  -H "Content-Type: application/json" \
  -d '{
    "message": "Downloading archive (45MB)...",
    "icon": "info",
    "gravity": "TOP",
    "backgroundColor": "#1E1E2E",
    "textColor": "#89B4FA"
  }'
```

---

### 4.4 Haptics & Vibration
Trigger precise tactile feedback on the phone:

```bash
# Built-in vibration presets: CLICK, DOUBLE_CLICK, HEAVY_CLICK, TICK, ERROR, SUCCESS
curl -X POST http://127.0.0.1:8080/api/vibrate \
  -H "Content-Type: application/json" \
  -d '{"preset": "HEAVY_CLICK"}'

# Custom duration in milliseconds
curl -X POST http://127.0.0.1:8080/api/vibrate \
  -H "Content-Type: application/json" \
  -d '{"durationMs": 300}'
```

---

### 4.5 Camera Flashlight / Torch
Turn the phone's physical flashlight on or off:

```bash
# Turn Flashlight ON
curl -X POST http://127.0.0.1:8080/api/torch \
  -H "Content-Type: application/json" \
  -d '{"enabled": true}'

# Turn Flashlight OFF
curl -X POST http://127.0.0.1:8080/api/torch \
  -H "Content-Type: application/json" \
  -d '{"enabled": false}'
```

---

### 4.6 Audio Playback & Volume Control

```bash
# Play system sound (notification, alarm, ringtone, beep)
curl -X POST http://127.0.0.1:8080/api/audio/play \
  -H "Content-Type: application/json" \
  -d '{"type": "notification"}'

# Stop any audio playback
curl -X POST http://127.0.0.1:8080/api/audio/stop

# Query all audio stream volumes and ringer mode
curl http://127.0.0.1:8080/api/volume

# Set media stream volume (e.g. volume level 12)
curl -X POST http://127.0.0.1:8080/api/volume \
  -H "Content-Type: application/json" \
  -d '{"stream": "MEDIA", "volume": 12}'

# Set device ringer mode: NORMAL, VIBRATE, or SILENT
curl -X POST http://127.0.0.1:8080/api/volume \
  -H "Content-Type: application/json" \
  -d '{"ringerMode": "VIBRATE"}'
```

---

### 4.7 Floating HUD Overlay Over Any App
Display a draggable, persistent floating card over any other app:

```bash
# Show a floating HUD showing Termux system monitor stats
curl -X POST http://127.0.0.1:8080/api/floating \
  -H "Content-Type: application/json" \
  -d '{
    "floatingId": "termux_stats",
    "title": "⚡ Termux System HUD",
    "text": "CPU: 14% | RAM: 1.8GB Free\nJob: In Progress",
    "type": "HUD",
    "isDraggable": true
  }'
```

---

### 4.8 Live Hardware Sensors Snapshot
Read all onboard sensors in one fast call:

```bash
curl http://127.0.0.1:8080/api/sensors
```
*Sample JSON Response:*
```json
{
  "success": true,
  "ambientLightLux": 342.0,
  "proximityCm": 5.0,
  "isNear": false,
  "pressureHpa": 1013.25,
  "compassHeadingDegrees": 184.5,
  "compassCardinal": "S",
  "accelerometer": { "x": 0.12, "y": 9.78, "z": 1.25 },
  "gyroscope": { "x": 0.01, "y": -0.02, "z": 0.00 }
}
```

---

### 4.9 Device Specs, Battery & Thermals
Retrieve comprehensive hardware metrics:

```bash
curl http://127.0.0.1:8080/api/device
```
*Sample JSON Response:*
```json
{
  "success": true,
  "manufacturer": "Google",
  "model": "Pixel 8 Pro",
  "androidVersion": "14",
  "sdkInt": 34,
  "cpuCores": 8,
  "ramTotalGb": 11.5,
  "ramAvailableGb": 4.8,
  "ramUsedPct": 58,
  "storageTotalGb": 128.0,
  "storageFreeGb": 64.2,
  "batteryPct": 88,
  "batteryTempC": 28.5,
  "isCharging": false,
  "isThermalThrottling": false
}
```

---

### 4.10 Network Diagnostics & Telemetry
Get Wi-Fi signal strength, link speed, and IP addresses:

```bash
curl http://127.0.0.1:8080/api/network
```
*Sample JSON Response:*
```json
{
  "success": true,
  "activeTransport": "WIFI",
  "isConnected": true,
  "isMetered": false,
  "localIpv4Addresses": ["192.168.1.105", "127.0.0.1"],
  "wifi": {
    "ssid": "Home-Network",
    "rssiDbm": -52,
    "signalLevel": 4,
    "linkSpeedMbps": 866,
    "wifiStandard": "Wi-Fi 6"
  }
}
```

---

### 4.11 App Launcher & Process Manager

```bash
# List all installed apps with package names and labels
curl http://127.0.0.1:8080/api/app/list

# Launch Termux
curl -X POST http://127.0.0.1:8080/api/app/launch \
  -H "Content-Type: application/json" \
  -d '{"packageName": "com.termux"}'

# Open a URL in the default browser
curl -X POST http://127.0.0.1:8080/api/app/launch \
  -H "Content-Type: application/json" \
  -d '{"url": "https://github.com"}'
```

---

### 4.12 System Notifications
Post an Android system notification:

```bash
curl -X POST http://127.0.0.1:8080/api/notification \
  -H "Content-Type: application/json" \
  -d '{"title": "Script Finished", "message": "All 120 files converted."}'
```

---

### 4.13 AeroShare High-Speed P2P File Transfer & Device Discovery

AeroShare provides zero-friction, intelligent local peer discovery and ultra-fast Wi-Fi/Hotspot file transfer between devices without internet access or manual pairing.

#### 1. Discover Nearby Peers on Local Network / Hotspot
```bash
curl http://127.0.0.1:8080/api/share/devices
```
*Sample JSON Response:*
```json
{
  "success": true,
  "count": 1,
  "localDeviceName": "Google Pixel 8 Pro",
  "localIp": "192.168.1.105",
  "isRadarActive": true,
  "devices": [
    {
      "id": "dev-192.168.1.140",
      "name": "Samsung Galaxy Tab S9",
      "ip": "192.168.1.140",
      "port": 8080,
      "deviceType": "TABLET",
      "rssi": -42,
      "isSecure": true
    }
  ]
}
```

#### 2. Send File to Nearby Device
Send any local file directly to a peer via high-speed chunked streaming:
```bash
curl -X POST http://127.0.0.1:8080/api/share/send \
  -H "Content-Type: application/json" \
  -d '{
    "filePath": "/sdcard/Download/presentation.mp4",
    "ip": "192.168.1.140",
    "peerName": "Galaxy Tab S9"
  }'
```
*Sample JSON Response:*
```json
{
  "success": true,
  "transferId": "tx-9a8b1c2d",
  "fileName": "presentation.mp4",
  "sizeBytes": 45829104,
  "targetIp": "192.168.1.140"
}
```

#### 3. Beam Shared Clipboard Snippet / Text
Beam text or links directly to peer clipboard with an instant native toast alert:
```bash
curl -X POST http://127.0.0.1:8080/api/share/clip \
  -H "Content-Type: application/json" \
  -d '{"text": "https://aeroshares.app/session/live-sync"}'
```

#### 4. Monitor Active Transfer Progress & Speeds
Inspect real-time progress percentage, transfer speed in MB/s, and ETA in seconds:
```bash
curl http://127.0.0.1:8080/api/share/transfers
```
*Sample JSON Response:*
```json
{
  "success": true,
  "count": 1,
  "transfers": [
    {
      "id": "tx-9a8b1c2d",
      "fileName": "presentation.mp4",
      "sizeBytes": 45829104,
      "transferredBytes": 22914552,
      "progressPct": 50,
      "speedBytesPerSec": 18450000,
      "etaSeconds": 1,
      "status": "TRANSFERRING",
      "direction": "SEND",
      "peerName": "Galaxy Tab S9",
      "peerIp": "192.168.1.140"
    }
  ]
}
```

#### 5. View Transfer History
```bash
curl http://127.0.0.1:8080/api/share/history
```

#### 6. Cancel Transfer
```bash
curl -X POST http://127.0.0.1:8080/api/share/cancel \
  -H "Content-Type: application/json" \
  -d '{"id": "tx-9a8b1c2d"}'
```

#### 7. Toggle Radar Discovery Engine
```bash
# Pause background radar scanning
curl -X POST http://127.0.0.1:8080/api/share/radar \
  -H "Content-Type: application/json" \
  -d '{"enabled": false}'

# Resume background radar scanning
curl -X POST http://127.0.0.1:8080/api/share/radar \
  -H "Content-Type: application/json" \
  -d '{"enabled": true}'
```

---

### 4.14 Universal Intent & URL Opener
Launch any browser URL, video stream, Google Maps location, phone dialer, or local file directly on Android:

```bash
# Open website in default browser
curl -X POST http://127.0.0.1:8080/api/open \
  -H "Content-Type: application/json" \
  -d '{"url": "https://github.com"}'

# Open YouTube video
curl -X POST http://127.0.0.1:8080/api/open \
  -H "Content-Type: application/json" \
  -d '{"url": "https://www.youtube.com/watch?v=dQw4w9WgXcQ"}'

# Open Google Maps search location
curl -X POST http://127.0.0.1:8080/api/open \
  -H "Content-Type: application/json" \
  -d '{"url": "geo:0,0?q=San+Francisco"}'

# Open Phone dialer with number
curl -X POST http://127.0.0.1:8080/api/open \
  -H "Content-Type: application/json" \
  -d '{"url": "tel:1234567890"}'
```

---

### 4.15 Audio Tone & Alert Frequency Generator
Generate pure sine wave audio tones and frequency alerts (ideal for acoustic signaling, diagnostics, or auditory cues):

```bash
# Play 440 Hz (Standard Concert A) tone for 500ms
curl -X POST http://127.0.0.1:8080/api/audio/tone \
  -H "Content-Type: application/json" \
  -d '{"frequency": 440, "durationMs": 500}'

# High-frequency alert beep (1000 Hz for 200ms)
curl -X POST http://127.0.0.1:8080/api/audio/tone \
  -H "Content-Type: application/json" \
  -d '{"frequency": 1000, "durationMs": 200}'
```

---

### 4.16 Battery & Power Diagnostics
Query device battery percentage, charging state, battery temperature in Celsius, and thermal throttling state:

```bash
curl http://127.0.0.1:8080/api/battery
```

*Sample JSON Response:*
```json
{
  "success": true,
  "batteryPct": 88,
  "isCharging": true,
  "batteryTempC": 29.4,
  "isThermalThrottling": false,
  "uptimeSeconds": 142050
}
```

---

### 4.17 System Navigation & Accessibility Actions
Trigger hardware system actions directly without touching the screen:

```bash
# Trigger Android Home
curl -X POST http://127.0.0.1:8080/api/system/action \
  -H "Content-Type: application/json" \
  -d '{"action": "HOME"}'

# Trigger Android Back
curl -X POST http://127.0.0.1:8080/api/system/action \
  -H "Content-Type: application/json" \
  -d '{"action": "BACK"}'

# Open Recent Apps switcher
curl -X POST http://127.0.0.1:8080/api/system/action \
  -H "Content-Type: application/json" \
  -d '{"action": "RECENTS"}'

# Pull down Notifications shade
curl -X POST http://127.0.0.1:8080/api/system/action \
  -H "Content-Type: application/json" \
  -d '{"action": "NOTIFICATIONS"}'
```

---

### 4.18 Media Playback Controls
Control background music and video playback (Spotify, YouTube Music, local media players):

```bash
# Toggle Play / Pause
curl -X POST http://127.0.0.1:8080/api/media/control \
  -H "Content-Type: application/json" \
  -d '{"command": "PLAY_PAUSE"}'

# Skip to Next Track
curl -X POST http://127.0.0.1:8080/api/media/control \
  -H "Content-Type: application/json" \
  -d '{"command": "NEXT"}'

# Skip to Previous Track
curl -X POST http://127.0.0.1:8080/api/media/control \
  -H "Content-Type: application/json" \
  -d '{"command": "PREV"}'
```

---

### 4.19 Device Storage & File System Explorer
List and explore files on Android storage (`DOWNLOADS`, `DCIM`, `DOCUMENTS`, `MOVIES`, `MUSIC`):

```bash
# Browse Downloads directory
curl -X POST http://127.0.0.1:8080/api/storage/files \
  -H "Content-Type: application/json" \
  -d '{"folder": "DOWNLOADS", "limit": 20}'

# Browse Camera Photos (DCIM)
curl -X POST http://127.0.0.1:8080/api/storage/files \
  -H "Content-Type: application/json" \
  -d '{"folder": "DCIM"}'
```

*Sample JSON Response:*
```json
{
  "success": true,
  "directory": "/storage/emulated/0/Download",
  "totalFiles": 12,
  "files": [
    {
      "name": "aeroshares_setup.zip",
      "path": "/storage/emulated/0/Download/aeroshares_setup.zip",
      "sizeBytes": 1459200,
      "isDirectory": false,
      "lastModified": 1727394821000
    }
  ]
}
```

---

### 4.20 SMS & Messages Composer
Open the native Android SMS messenger with a recipient number and optional pre-filled draft:

```bash
curl -X POST http://127.0.0.1:8080/api/sms/compose \
  -H "Content-Type: application/json" \
  -d '{"phone": "1234567890", "message": "Here is the shared AeroShare link: https://aeroshares.app"}'
```

---

### 4.21 Endpoint Security Shield, Device Pairing & Biometrics

Aura includes a multi-layered **Defense Security Shield** to prevent unauthorized network access over Wi-Fi, LAN, or external tools:

#### Security Highlights:
1. **6-Digit Dynamic Device Pairing Protocol**:
   - Remote terminals and Wi-Fi clients must register with a 6-digit cryptographic pairing code generated on the device.
   - Upon successful registration, a unique client session token (`aura_cli_...`) is issued and stored in the persistent Paired Devices registry.
2. **WebSocket Challenge-Response Authentication**:
   - WebSocket sessions require authentication handshake (`REGISTER_REQUEST` / `AUTH_REQUEST`) before executing privileged system commands. Unregistered connections are rejected.
3. **On-Device Biometric & Face Authentication Gate**:
   - Supports Face Unlock, Fingerprint, and Device PIN confirmation for client pairing and high-privilege operations.
4. **Constant-Time Token Verification**:
   - Eliminates timing side-channel attacks via `MessageDigest.isEqual`.
5. **Per-IP Rate Limiting (150 req/min) & Brute-Force Lockout**:
   - Automatically locks out malicious IP addresses for 60s after 5 failed attempts (`403 Forbidden`).
6. **OWASP Hardened Security Headers**:
   - Injected on all responses: `X-Content-Type-Options`, `X-Frame-Options: DENY`, `X-XSS-Protection`, `Content-Security-Policy`, `Strict-Transport-Security`.

---

#### 1. Quick Terminal Pairing (CLI)
```bash
# 1. View active 6-digit pairing code on the device
python server/send_cmd.py pair

# 2. Register/Pair your terminal with the 6-digit code
python server/send_cmd.py pair 849201 "Termux-Workstation"
# (Token is automatically saved to ~/.aura_token — no repeated manual entry needed!)

# 3. List all registered paired devices
python server/send_cmd.py pair devices

# 4. Revoke access for a specific device
python server/send_cmd.py pair revoke dev_948201
```

---

#### 2. REST API Device Registration & Pairing

```bash
# 1. Get current 6-digit pairing code
curl http://127.0.0.1:8080/api/security/pair/code

# 2. Register new client with 6-digit pairing code
curl -X POST http://127.0.0.1:8080/api/security/pair/register \
  -H "Content-Type: application/json" \
  -d '{"code": "849201", "clientName": "Laptop-Termux", "deviceId": "laptop_01"}'
```
*Sample JSON Response:*
```json
{
  "success": true,
  "clientToken": "aura_cli_7f8a1290bc44e89104",
  "deviceId": "laptop_01",
  "clientName": "Laptop-Termux",
  "message": "Device paired successfully! Store clientToken for Bearer authorization."
}
```

---

#### 3. Biometrics & Security Status
```bash
# Check Biometric capabilities (Face Unlock, Fingerprint, Device PIN)
curl http://127.0.0.1:8080/api/security/biometrics

# Check overall Security Shield status
curl http://127.0.0.1:8080/api/security/status
```

---

#### 4. Authenticated API Calls (Bearer Token)
```bash
# Using paired client token header
curl -X POST http://127.0.0.1:8080/api/tts \
  -H "Authorization: Bearer aura_cli_7f8a1290bc44e89104" \
  -H "Content-Type: application/json" \
  -d '{"text": "Secure authenticated execution"}'
```

---

#### 5. Strict Network Isolation Mode
```bash
# Enforce STRICT mode (blocks all unregistered requests across Wi-Fi & LAN)
curl -X POST http://127.0.0.1:8080/api/security/mode \
  -H "Authorization: Bearer aura_cli_7f8a1290bc44e89104" \
  -H "Content-Type: application/json" \
  -d '{"mode": "STRICT"}'
```

---

### 4.22 Face & Biometric Device Authorization Workflow

AeroShare protects all REST API, WebSocket, and P2P endpoints by requiring biometric or on-screen confirmation before any new device on Wi-Fi or LAN is granted an access token.

#### Step-by-Step Flow:
1. **Remote Request**: The client requests a pairing session via `POST /api/pair/request` (or runs `python server/send_cmd.py pair`).
2. **Interactive Phone Modal (`FaceDeviceAuthDialog`)**:
   - The phone screen pops up a modern Material 3 authorization dialog with an animated Face Scanner visualizer.
   - Shows the connecting device's name (`clientName`), IP address (`clientIp`), and timestamp.
3. **Face Verification**:
   - The user taps **"Verify Face"**.
   - Android Biometric / Face verification validates the user on-device.
   - Upon confirmation, a cryptographically secure token (`aura_cli_<hex>`) is generated and registered in the trust registry.
4. **Client Receives Token**: The client's polling request or CLI receives the token and caches it locally in `~/.aura_token` for all subsequent requests.

#### 1. Request Pairing via REST:
```bash
curl -X POST http://<PHONE_IP>:8080/api/pair/request \
  -H "Content-Type: application/json" \
  -d '{
    "clientName": "Alex MacBook Pro",
    "clientIp": "192.168.1.45",
    "deviceId": "macbook_pro_01"
  }'
```
*Sample JSON Response:*
```json
{
  "success": true,
  "requestId": "req_847192",
  "deviceId": "macbook_pro_01",
  "status": "PENDING",
  "message": "Pairing prompt sent to phone. Awaiting 1-tap approval."
}
```

#### 2. Poll for Approval:
```bash
curl -X POST http://<PHONE_IP>:8080/api/pair/poll \
  -H "Content-Type: application/json" \
  -d '{"requestId": "req_847192"}'
```
*Sample JSON Response (Once Approved via Face Unlock):*
```json
{
  "success": true,
  "requestId": "req_847192",
  "status": "APPROVED",
  "clientToken": "aura_cli_8f90ab12de34567890",
  "deviceId": "macbook_pro_01",
  "clientName": "Alex MacBook Pro"
}
```

---

### 4.23 Battery Optimization & Background Execution Setup

Android's **Doze Mode** and background power management aggressively sleep network sockets, background radars, and HTTP servers when the screen turns off unless the app is granted **Unrestricted Battery Exemption**.

#### Why the App Isn't Visible in the Android Battery List by Default
In Android 9 through 15 (Samsung, Pixel, Xiaomi, OnePlus), when you open **Settings ➔ Battery ➔ Battery Optimisation**:
- The screen opens with a top dropdown filter set to **"Not optimised"**.
- This filter **only lists apps that are already exempted**.
- Because the app has not been granted exemption yet, it is hidden from the default view.
- **To view it manually**: Tap the top dropdown menu and select **"All apps"**, then scroll down to **AeroShare** and select **"Don't optimise" / "Unrestricted"**.

#### 1-Tap In-App Configuration:
1. Open AeroShare ➔ **Companion Config / Settings** (`⚙️`).
2. Scroll to the **"Battery & Background Execution"** card.
3. Tap **"Allow Unrestricted"** ➔ The Android OS system prompt appears: *"Stop optimizing battery usage? AeroShare will be able to run in background"* ➔ Tap **Allow**.

#### Programmatic / REST API Battery Optimization Controls:

```bash
# 1. Check current Battery Optimization status (UNRESTRICTED vs OPTIMIZED)
curl http://127.0.0.1:8080/api/battery/optimization

# 2. Trigger the native Android OS battery exemption prompt on the device
curl -X POST http://127.0.0.1:8080/api/battery/optimization \
  -H "Content-Type: application/json" \
  -d '{"action": "REQUEST"}'

# 3. Open the Android System Battery Optimisation settings screen directly
curl -X POST http://127.0.0.1:8080/api/battery/optimization \
  -H "Content-Type: application/json" \
  -d '{"action": "SETTINGS"}'
```
*Sample JSON Response:*
```json
{
  "success": true,
  "isIgnoringBatteryOptimizations": true,
  "status": "UNRESTRICTED",
  "packageName": "com.aistudio.companion.app",
  "actionRequested": false,
  "hint": "AeroShare is unrestricted and allowed to run in the background."
}
```

---

### 4.24 Panic Lockdown & Device Revocation

AeroShare includes an instant security killswitch to freeze all remote network operations during an emergency.

#### 1. Instant Panic Lockdown:
```bash
# Freeze all remote Wi-Fi / LAN API & WebSocket connections
curl -X POST http://127.0.0.1:8080/api/security/lockdown \
  -H "Authorization: Bearer <MASTER_OR_CLIENT_TOKEN>" \
  -H "Content-Type: application/json" \
  -d '{"enabled": true}'

# Release Panic Lockdown
curl -X POST http://127.0.0.1:8080/api/security/lockdown \
  -H "Authorization: Bearer <MASTER_OR_CLIENT_TOKEN>" \
  -H "Content-Type: application/json" \
  -d '{"enabled": false}'
```

#### 2. Device Trust Registry & Instant Token Revocation:
```bash
# List all active paired devices
curl http://127.0.0.1:8080/api/security/devices \
  -H "Authorization: Bearer <MASTER_OR_CLIENT_TOKEN>"

# Revoke a compromised or lost device immediately
curl -X POST http://127.0.0.1:8080/api/security/revoke \
  -H "Authorization: Bearer <MASTER_OR_CLIENT_TOKEN>" \
  -H "Content-Type: application/json" \
  -d '{"deviceId": "laptop_01"}'
```

---

## 5. Method 2: Real-Time Full Automation via Termux WebSocket (Port 8000)

The WebSocket bridge enables full bi-directional communication, interactive screen reading, and remote gesture automation.

### Step 1: Install Termux Dependencies
Inside Termux, install Python and websockets:
```bash
pkg update -y
pkg install -y python cloudflared
pip install websockets
```

---

### Step 2: Start the WebSocket Relay Server
Run the provided `mock_server.py` inside Termux:
```bash
python server/mock_server.py
```
*Output:*
```text
==================================================
  Termux WebSocket Relay Server Active
  Listening on ws://127.0.0.1:8000
==================================================
```

*(Optional: If connecting over the internet, run `cloudflared tunnel --url http://127.0.0.1:8000` to get a public `wss://...` URL).*

---

### Step 3: Connect the Android App
1. Open the **AI Companion** app.
2. Go to **Settings** (`⚙️`) or the **Developer Screen** (`{ }`).
3. Set the Server URL to `ws://127.0.0.1:8000/ws` (or your Cloudflare tunnel URL).
4. Tap **Connect**. The indicator will turn **Green** (`CONNECTED`).
5. Ensure **Termux Assistant** is enabled in Android **Settings ➔ Accessibility**.

---

### Step 4: Automate Android via CLI (`send_cmd.py`)

Using the CLI script located in `server/send_cmd.py`:

```bash
# 1. AeroShare P2P Discovery & High-Speed File Transfer
python server/send_cmd.py devices             # Scan and discover nearby AeroShare peers
python server/send_cmd.py share ./file.mp4    # Beam file to nearest discovered peer
python server/send_cmd.py share ./doc.pdf 192.168.1.140 # Beam file to specific peer IP
python server/send_cmd.py share "Note text"   # Beam text snippet directly to peer
python server/send_cmd.py transfers           # Live transfer progress, speed, and ETA
python server/send_cmd.py history             # Transfer history log
python server/send_cmd.py cancel tx-9a8b1c2d  # Cancel an ongoing transfer
python server/send_cmd.py clip "Copied link"  # Sync clipboard across devices
python server/send_cmd.py radar on            # Turn on background peer discovery radar

# 2. List installed applications on the Android phone
python server/send_cmd.py apps                # List installed user apps
python server/send_cmd.py apps --system       # Include system apps
python server/send_cmd.py apps termux         # Filter apps matching 'termux'
python server/send_cmd.py apps --json         # Output raw JSON format

# 2. Launch an app by name, package name, or open a URL
python server/send_cmd.py open Termux         # Open app by name
python server/send_cmd.py open YouTube        # Case-insensitive app launch
python server/send_cmd.py open com.termux     # Open by package name
python server/send_cmd.py open https://github.com # Open URL in browser

# 3. Inspect the on-screen UI hierarchy of whatever app is currently open
# (Optional: specify a 3-second delay to give you time to switch apps)
python server/send_cmd.py inspect 3

# 4. Tap an element by visible text or content description
python server/send_cmd.py tap "Subscribe"
python server/send_cmd.py tap "Settings"

# 5. Tap exact screen coordinates (X, Y)
python server/send_cmd.py click 540 1200

# 6. Scroll to next post, video, or reel
python server/send_cmd.py next

# 7. Perform custom swipe gesture: swipe <startX> <startY> <endX> <endY> [durationMs]
python server/send_cmd.py swipe 500 1500 500 300 200

# 8. Trigger Android hardware navigation actions
python server/send_cmd.py back           # Press Android Back
python server/send_cmd.py home           # Go to Android Home screen
python server/send_cmd.py recents        # Open Recent Apps switcher
python server/send_cmd.py notifications  # Pull down notification shade

# 9. Hardware, Power & Battery Optimization
python server/send_cmd.py battery             # Battery %, temperature, charging state & Doze mode
python server/send_cmd.py battery-opt         # View background execution status (UNRESTRICTED vs OPTIMIZED)
python server/send_cmd.py battery-opt request # Trigger native Android OS battery exemption prompt on phone
python server/send_cmd.py battery-opt settings# Open Android system Battery Optimisation settings list
python server/send_cmd.py sensors             # Live light lux, compass, proximity, acc
python server/send_cmd.py torch on            # Turn camera flashlight on
python server/send_cmd.py torch off           # Turn camera flashlight off
python server/send_cmd.py vibrate 300         # Haptic vibration for 300ms

# 10. Device Security & Biometric Face Pairing
python server/send_cmd.py pair                # Trigger 1-tap Face Auth popup on phone screen
python server/send_cmd.py pair 482910         # Pair using 6-digit rotating PIN code
python server/send_cmd.py pair devices        # List all registered paired client devices
python server/send_cmd.py pair revoke dev_01  # Revoke access for a specific client device

# 11. Voice, Audio & HUD Controls
python server/send_cmd.py tts "System backup initialized" # Speak aloud
python server/send_cmd.py tone 880 300   # Play pure 880 Hz audio tone for 300ms
python server/send_cmd.py volume 80 MEDIA # Set media volume
python server/send_cmd.py media next     # Skip music track (play, pause, next, prev)
python server/send_cmd.py files DOWNLOADS # List files in Downloads folder
python server/send_cmd.py sms 1234567890 "Hello from Termux" # Open SMS messenger
python server/send_cmd.py hud "CPU: 14% | 4GB RAM" # Display floating HUD widget
python server/send_cmd.py notify "Build" "Deployment finished successfully"

# 11. Display quick pop-up toast message on the phone
python server/send_cmd.py "Batch process complete!"
```

---

## 6. Real-Time Audio Streaming (Voice to Termux / AI)

Aura captures studio-quality, low-latency audio for voice assistants and external STT/AI processors:
- **Audio Format**: 16-bit linear PCM, 16,000 Hz, mono channel.
- **Protocol**: Chunked Base64 frames sent via WebSocket type `AUDIO_STREAM`.

### How to Stream Audio:
1. Tap the **Microphone Button** in the Aura Voice Dock (or on the Speech Diagnostics screen).
2. The Hero visualizer begins pulsing in sync with your voice.
3. The frames are streamed in real time to the Termux server:
   ```text
   [AUDIO] Streaming active | Packets: 154
   ```
4. Tap the Microphone Button again to end recording (`AUDIO_END`).

---

## 7. FFmpeg Media Processing Engine

Aura includes a built-in media processing engine capable of processing video and audio files locally:

### Supported Media Operations:
- **`MEDIA_PROBE`**: Inspect container formats, video codecs, bitrates, audio channels, and duration.
- **`MEDIA_TRIM`**: Losslessly cut video segments without re-encoding using ultrafast stream copy.
- **`MEDIA_GIF`**: Convert short video clips into optimized animated GIFs using high-quality 2-pass palette generation.
- **`MEDIA_SPEED`**: Speed up (e.g. 2.0x) or slow down (0.5x) videos with audio pitch correction.
- **`MEDIA_MUTE`**: Strip audio tracks from videos instantly.

*Example WebSocket Payload for Trimming a Video:*
```json
{
  "type": "MEDIA_TRIM",
  "requestId": "trim_01",
  "mediaUri": "/sdcard/Download/input.mp4",
  "startSeconds": 5.0,
  "durationSeconds": 15.0
}
```

---

## 8. Troubleshooting & FAQ

### Q: `curl: (7) Failed to connect to 127.0.0.1 port 8080: Connection refused`
- **Cause**: The Aura app is not running in the foreground or background.
- **Fix**: Open the Aura application. The HTTP server starts automatically upon launch. Keep the app open or ensure battery optimization is disabled so Android doesn't kill the background service.

### Q: Gestures (`click`, `tap`, `next`) fail or don't do anything on screen
- **Cause**: The Accessibility Service is disabled in Android Settings.
- **Fix**: Open Android **Settings ➔ Accessibility** (or **Downloaded apps**). Locate **Termux Assistant** and enable it.

### Q: Floating HUD doesn't appear
- **Cause**: "Display over other apps" permission is not granted.
- **Fix**: Go to **Settings ➔ Apps ➔ Special app access ➔ Display over other apps** and toggle it **ON** for the app.

### Q: What is the difference between Port 8080 and Port 8000?
- **Port 8080 (HTTP REST)**: Hosted **directly by the Android app**. No server setup required. Best for one-off commands (`curl http://127.0.0.1:8080/api/tts`, flashlight, vibration, sensors).
- **Port 8000 (WebSocket)**: Hosted **by Termux** (`mock_server.py`). Best for full automation, continuous PCM audio streaming, and high-frequency UI inspection.

### Q: How do I test the connection without writing code?
- Open the app, navigate to the **Developer Screen** (`{ }`), and tap **Send Ping**. If connected, the RTT latency will immediately update (e.g. `RTT: 4ms`).
- In Termux, run:
  ```bash
  curl http://127.0.0.1:8080/health
  ```
  It will return `{"status": "UP", "server": "Aura Local Media & Device Engine"}`.

---

*Enjoy using the Aura Companion & Termux Automation Bridge!*
