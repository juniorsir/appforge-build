package com.example.ui

import androidx.compose.runtime.Composable

@Composable
fun TermsAndConditionsDialog(onDismiss: () -> Unit) {}

@Composable
fun PrivacyPolicyDialog(onDismiss: () -> Unit) {}

@Composable
fun InstagramIcon(modifier: androidx.compose.ui.Modifier = androidx.compose.ui.Modifier) {}

fun openInstagramProfile(context: android.content.Context) {}
