@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
package com.example.ui
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.type
import androidx.compose.ui.input.key.key
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.FocusRequester


import com.example.media.*
import com.example.player.gestures.*

import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRailItemDefaults
import android.content.Context
import android.util.Log
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures

import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.outlined.*
import androidx.compose.material3.*
import androidx.compose.material3.pulltorefresh.*
import androidx.compose.runtime.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.pager.PagerState
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.interaction.collectIsHoveredAsState
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import com.example.R
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.animation.core.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.PlaybackException
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.ui.PlayerView
import androidx.media3.ui.AspectRatioFrameLayout
import coil.compose.AsyncImage
import com.example.data.DownloadEntity
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.BackHandler
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.IntOffset
import kotlin.math.roundToInt
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.SpanStyle
import coil.imageLoader
// Theme Palette
data class SleekColors(
    val bg: Color,
    val card: Color,
    val surface: Color,
    val primary: Color,
    val accent: Color,
    val container: Color,
    val textPrimary: Color,
    val textSecondary: Color,
    val textMuted: Color,
    val border: Color,
    val failure: Color,
    val success: Color,
    val gradient: Brush
)
val LocalSleekColors = staticCompositionLocalOf<SleekColors> { error("No SleekColors provided") }

@Composable
fun getSleekColors(themeSettings: com.example.ui.theme.AppThemeSettings): SleekColors {
    val systemDark = isSystemInDarkTheme()
    return com.example.ui.theme.resolveSleekColorsFromSettings(themeSettings, systemDark)
}

@Composable
fun getSleekColors(themeMode: String): SleekColors {
    val mode = com.example.ui.theme.AppThemeMode.fromId(themeMode)
    val settings = com.example.ui.theme.AppThemeSettings(themeMode = mode)
    val systemDark = isSystemInDarkTheme()
    return com.example.ui.theme.resolveSleekColorsFromSettings(settings, systemDark)
}
// Global accessor shortcuts that bridge to the current theme
val SleekBg @Composable get() = LocalSleekColors.current.bg
val SleekCard @Composable get() = LocalSleekColors.current.card
val SleekCardDark @Composable get() = LocalSleekColors.current.surface
val SleekPurpleDark @Composable get() = LocalSleekColors.current.primary
val SleekPurpleLight @Composable get() = LocalSleekColors.current.accent
val SleekPurpleContainer @Composable get() = LocalSleekColors.current.container
val SleekTextPrimary @Composable get() = LocalSleekColors.current.textPrimary
val SleekTextSecondary @Composable get() = LocalSleekColors.current.textSecondary
val SleekTextMuted @Composable get() = LocalSleekColors.current.textMuted
val SleekBorderColor @Composable get() = LocalSleekColors.current.border
val CrimsonFailure @Composable get() = LocalSleekColors.current.failure
val EmeraldSuccess @Composable get() = LocalSleekColors.current.success
val HeroGradient @Composable get() = LocalSleekColors.current.gradient
// Backwards compatibility mappings for existing layouts
val SlateBg @Composable get() = SleekBg
val SlateCard @Composable get() = SleekCard
val SlateCardDark @Composable get() = SleekCardDark
val AmberAccent @Composable get() = SleekPurpleDark
val AmberAccentLight @Composable get() = SleekPurpleDark
val SilverText @Composable get() = SleekTextSecondary
val WhiteText @Composable get() = SleekTextPrimary

@OptIn(ExperimentalMaterial3Api::class, com.google.accompanist.permissions.ExperimentalPermissionsApi::class)
@Composable
fun VideoDownloaderScreen(
    viewModel: VideoDownloaderViewModel,
    modifier: Modifier = Modifier
) {
    val themeSettings by viewModel.appThemeSettings.collectAsStateWithLifecycle()
    val showAdvancedFormats by viewModel.showAdvancedFormats.collectAsStateWithLifecycle()
    val colors = getSleekColors(themeSettings)
    CompositionLocalProvider(LocalSleekColors provides colors) {
        val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current
    val initialPermissions = remember { com.example.util.DeviceCompatHelper.getRequiredPermissions() }
    val permissionState = com.google.accompanist.permissions.rememberMultiplePermissionsState(initialPermissions)
    var showPermissionDialog by remember { mutableStateOf(!permissionState.allPermissionsGranted) }
    LaunchedEffect(Unit) {
        if (!permissionState.allPermissionsGranted) {
            permissionState.launchMultiplePermissionRequest()
        }
    }
    if (!permissionState.allPermissionsGranted && showPermissionDialog) {
        androidx.compose.ui.window.Dialog(
            onDismissRequest = { showPermissionDialog = false },
            properties = androidx.compose.ui.window.DialogProperties(
                dismissOnBackPress = true,
                dismissOnClickOutside = false
            )
        ) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
                    .border(1.dp, SleekBorderColor, RoundedCornerShape(24.dp)),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = SleekCardDark)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(64.dp)
                            .background(SleekPurpleLight.copy(alpha = 0.1f), CircleShape)
                            .border(1.dp, SleekPurpleLight.copy(alpha = 0.3f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Lock,
                            contentDescription = null,
                            tint = SleekPurpleLight,
                            modifier = Modifier.size(32.dp)
                        )
                    }
                    Text(
                        text = "Permissions Required",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = SleekTextPrimary
                        ),
                        textAlign = TextAlign.Center
                    )
                    Text(
                        text = "To download media files, save them locally, convert to MP3, and post active download alerts, ꒯ꄲꅐꋊ꒒ꌦ needs storage and notifications access.",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = SleekTextSecondary,
                            lineHeight = 20.sp
                        ),
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = {
                                permissionState.launchMultiplePermissionRequest()
                                if (!permissionState.allPermissionsGranted) {
                                    try {
                                        val intent = android.content.Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                                            data = android.net.Uri.fromParts("package", context.packageName, null)
                                        }
                                        context.startActivity(intent)
                                    } catch (e: Exception) {
                                        // fallback ignore
                                    }
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color.White,
                                contentColor = Color.Black
                            ),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Default.Check, contentDescription = "Grant Access")
                        }
                        TextButton(
                            onClick = { showPermissionDialog = false },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.Close, contentDescription = "Skip for Now", tint = SleekTextMuted)
                        }
                    }
                }
            }
        }
    }
    val urlInput by viewModel.videoUrlInput.collectAsStateWithLifecycle()
    val isAnalyzing by viewModel.isAnalyzing.collectAsStateWithLifecycle()
    val analyzedVideo by viewModel.analyzedVideo.collectAsStateWithLifecycle()
    val analysisError by viewModel.analysisError.collectAsStateWithLifecycle()
    val activeDownloads by viewModel.activeDownloads.collectAsStateWithLifecycle()
    val downloadHistory by viewModel.downloadHistory.collectAsStateWithLifecycle()
    val deviceMedia by viewModel.deviceMedia.collectAsStateWithLifecycle()
    val searchHistory by viewModel.searchHistory.collectAsStateWithLifecycle()
    val browsingHistory by viewModel.browsingHistory.collectAsStateWithLifecycle()
    LaunchedEffect(permissionState.allPermissionsGranted) {
        if (permissionState.allPermissionsGranted) {
            viewModel.loadDeviceMedia(context)
        }
    }
    val executionLogs by viewModel.executionLogs.collectAsStateWithLifecycle()
    val isAudioOnly by viewModel.isAudioOnlyMode.collectAsStateWithLifecycle()
    val searchResults by viewModel.searchResults.collectAsStateWithLifecycle()
    val isSearching by viewModel.isSearching.collectAsStateWithLifecycle()
    val searchSuggestions by viewModel.searchSuggestions.collectAsStateWithLifecycle()
    val isIncognitoMode by viewModel.isIncognitoMode.collectAsStateWithLifecycle()
    val embedSubtitles by viewModel.embedSubtitles.collectAsStateWithLifecycle()
    val embedAutoSubtitles by viewModel.embedAutoSubtitles.collectAsStateWithLifecycle()
    val subtitleLanguages by viewModel.subtitleLanguages.collectAsStateWithLifecycle()
    val embedAudioMetadata by viewModel.embedAudioMetadata.collectAsStateWithLifecycle()
    val audioMultistreams by viewModel.audioMultistreams.collectAsStateWithLifecycle()
    val preferredAudioFormat by viewModel.preferredAudioFormat.collectAsStateWithLifecycle()
    val preferredAudioQuality by viewModel.preferredAudioQuality.collectAsStateWithLifecycle()
    val playerDecoderMode by viewModel.playerDecoderMode.collectAsStateWithLifecycle()
    val hardwareAcceleration by viewModel.hardwareAcceleration.collectAsStateWithLifecycle()
    val audioOutputMode by viewModel.audioOutputMode.collectAsStateWithLifecycle()
    val homeSelectedCategory by viewModel.homeSelectedCategory.collectAsStateWithLifecycle()
    val isYtdlpUpdateAvailable by viewModel.isYtdlpUpdateAvailable.collectAsStateWithLifecycle()
    val isYtdlpLoading by viewModel.isYtdlpLoading.collectAsStateWithLifecycle()
    val ytdlpLocalVersion by viewModel.ytdlpLocalVersion.collectAsStateWithLifecycle()
    
    val displayVersion = remember(ytdlpLocalVersion) {
        val pattern = java.util.regex.Pattern.compile("""\(([^)]+)\)""")
        val matcher = pattern.matcher(ytdlpLocalVersion)
        if (matcher.find()) {
            matcher.group(1)
        } else if (ytdlpLocalVersion.contains("JNI Core")) {
            "JNI"
        } else {
            ytdlpLocalVersion
        }
    }

    val playingMedia by viewModel.playingMedia.collectAsStateWithLifecycle()
    val currentWaveformData by viewModel.currentWaveformData.collectAsStateWithLifecycle()
    val isAudio = playingMedia?.let { isAudioMedia(it) } ?: false
    var isPlayerFullscreen by remember(playingMedia?.id, playingMedia?.localPath) {
        mutableStateOf(playingMedia != null && !isAudio)
    }

    val focusManager = androidx.compose.ui.platform.LocalFocusManager.current
    LaunchedEffect(isPlayerFullscreen) {
        if (isPlayerFullscreen) {
            focusManager.clearFocus()
        }
    }

    BackHandler(enabled = playingMedia != null && isPlayerFullscreen) {
        isPlayerFullscreen = false
    }

    var selectedTabIndex by remember { mutableStateOf(0) }
    
    LaunchedEffect(viewModel) {
        viewModel.navigateToTab.collect { tabIndex ->
            selectedTabIndex = tabIndex
        }
    }

    var showAboutDialog by remember { mutableStateOf(false) }
    var showTermsDialog by remember { mutableStateOf(false) }
    var showPrivacyDialog by remember { mutableStateOf(false) }
    var showAudioFxStudioDialog by remember { mutableStateOf(false) }
    var showBatchQueueModal by remember { mutableStateOf(false) }
    var editingMetadataItem by remember { mutableStateOf<DownloadEntity?>(null) }
    var schedulingVideoInfo by remember { mutableStateOf<Triple<String, String, VideoFormatUi>?>(null) }
    var playlistItemToAdd by remember { mutableStateOf<DownloadEntity?>(null) }
    var showCreatePlaylistModal by remember { mutableStateOf(false) }
    var isStreamLoading by remember { mutableStateOf(false) }
    var topBarOffsetHeightPx by remember { mutableFloatStateOf(0f) }
    val topBarHeightPx = with(androidx.compose.ui.platform.LocalDensity.current) { 100.dp.toPx() }
    val nestedScrollConnection = remember {
        object : androidx.compose.ui.input.nestedscroll.NestedScrollConnection {
            override fun onPreScroll(available: androidx.compose.ui.geometry.Offset, source: androidx.compose.ui.input.nestedscroll.NestedScrollSource): androidx.compose.ui.geometry.Offset {
                val delta = available.y
                val newOffset = topBarOffsetHeightPx + delta
                topBarOffsetHeightPx = newOffset.coerceIn(-topBarHeightPx, 0f)
                return androidx.compose.ui.geometry.Offset.Zero
            }
        }
    }
    val scope = rememberCoroutineScope()
    val isMobile = androidx.compose.ui.platform.LocalConfiguration.current.screenWidthDp < 600
    val isInSystemPipMode by viewModel.isInSystemPipMode.collectAsStateWithLifecycle()
    val activeTrimState by viewModel.activeTrimState.collectAsStateWithLifecycle()
    val activeCompressState by viewModel.activeCompressState.collectAsStateWithLifecycle()

    Scaffold(
        containerColor = SleekBg,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        topBar = {},
        bottomBar = {}
    ) { innerPadding ->
        if (isInSystemPipMode) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black)
            ) {
                playingMedia?.let { media ->
                    FloatingPlayerOverlay(
                        media = media,
                        isFullscreen = true,
                        onToggleFullscreen = {},
                        onClose = { viewModel.stopPlayingMedia() },
                        analyzedVideo = analyzedVideo,
                        onStreamFormat = null,
                        viewModel = viewModel
                    )
                } ?: Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "No active video",
                        color = Color.White,
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }
            return@Scaffold
        }

        Box(modifier = Modifier.fillMaxSize().nestedScroll(nestedScrollConnection)) {
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .background(SleekBg)
            ) {
            if (!isMobile && !isPlayerFullscreen) {
                LargeScreenNavigationDock(
                    selectedTabIndex = selectedTabIndex,
                    onTabSelected = { selectedTabIndex = it },
                    onQuickActionClick = {
                        selectedTabIndex = 0
                        if (urlInput.trim().isNotEmpty()) {
                            viewModel.analyzeVideo()
                        }
                    }
                )
            }
            Box(modifier = Modifier.weight(1f).fillMaxHeight()) {
                AnimatedContent(
                    targetState = selectedTabIndex,
                    transitionSpec = {
                        val isTowardsRight = targetState > initialState
                        val slideIn = androidx.compose.animation.slideInHorizontally(
                            animationSpec = androidx.compose.animation.core.spring(dampingRatio = 0.85f, stiffness = 400f)
                        ) { width -> if (isTowardsRight) (width * 0.12f).toInt() else -(width * 0.12f).toInt() } + 
                        androidx.compose.animation.fadeIn()
                        val slideOut = androidx.compose.animation.slideOutHorizontally(
                            animationSpec = androidx.compose.animation.core.spring(dampingRatio = 0.85f, stiffness = 400f)
                        ) { width -> if (isTowardsRight) -(width * 0.12f).toInt() else (width * 0.12f).toInt() } + 
                        androidx.compose.animation.fadeOut()
                        slideIn.togetherWith(slideOut).using(androidx.compose.animation.SizeTransform(clip = false))
                    },
                    label = "TabTransition"
                ) { targetTab ->
                    when (targetTab) {
                        0 -> DownloadTab(
                            urlInput = urlInput,
                            urlHistory = viewModel.urlHistory.collectAsStateWithLifecycle().value,
                            searchSuggestions = searchSuggestions,
                            isAnalyzing = isAnalyzing,
                            analyzedVideo = analyzedVideo,
                            analysisError = analysisError,
                            activeDownloads = activeDownloads,
                            executionLogs = executionLogs,
                            isAudioOnly = isAudioOnly,
                            searchResults = searchResults,
                            isSearching = isSearching,
                            onToggleAudioOnly = { viewModel.toggleAudioOnlyMode() },
                            onClearLogs = { viewModel.clearLogs() },
                            onUrlChange = { viewModel.updateUrlInput(it) },
                            onClearUrlHistory = { viewModel.clearUrlHistory() },
                            onPasteClick = {
                                clipboardManager.getText()?.text?.let { viewModel.updateUrlInput(it) }
                            },
                            onClearClick = { viewModel.updateUrlInput("") },
                            onAnalyzeClick = { viewModel.analyzeVideo() },
                            onDownloadFormat = { format ->
                                analyzedVideo?.let { video ->
                                    viewModel.startDownload(video, format)
                                }
                            },
                            onStreamFormat = { format ->
                                analyzedVideo?.let { video ->
                                    fun isAudioFormat(fmt: VideoFormatUi): Boolean {
                                        val type = fmt.type.lowercase()
                                        val qual = fmt.quality.lowercase()
                                        val ext = fmt.ext.lowercase()
                                        return type == "audio" || 
                                               (fmt.vcodec == "none" && fmt.acodec != null && fmt.acodec != "none") ||
                                               qual.contains("kbps") || qual.contains("audio") ||
                                               ext == "mp3" || ext == "m4a" || ext == "aac" || ext == "opus" || ext == "wav" || ext == "flac" || ext == "ogg"
                                    }

                                    val isAudio = isAudioFormat(format)
                                    val isVideoOnly = !isAudio && (format.acodec == "none" || format.acodec.isBlank() || !format.hasAudio || format.type == "video_only")
                                    val audioFormat = if (isVideoOnly) {
                                        video.formats.filter { isAudioFormat(it) }
                                            .maxByOrNull { it.audioBitrateKbps ?: 0 }
                                            ?: video.formats.filter { isAudioFormat(it) }
                                                .maxByOrNull { it.sizeBytes }
                                    } else {
                                        null
                                    }
                                    
                                    val videoUrl = format.downloadUrl.ifBlank { format.downloadUrl }.ifBlank { video.originalUrl }
                                    val streamUrl = if (audioFormat != null) {
                                        val audioUrl = audioFormat.downloadUrl.ifBlank { audioFormat.downloadUrl }.ifBlank { video.originalUrl }
                                        "$videoUrl|STREAM_AUDIO_URL|$audioUrl"
                                    } else {
                                        videoUrl
                                    }

                                    viewModel.startPlayingMedia(
                                        item = DownloadEntity(
                                            id = video.id,
                                            title = if (isAudio) "[Streaming Audio] ${video.title}" else "[Streaming Video] ${video.title}",
                                            author = video.author,
                                            durationText = video.durationText,
                                            thumbnailUrl = video.thumbnailUrl,
                                            localPath = streamUrl,
                                            fileSize = format.sizeBytes,
                                            downloadedAt = System.currentTimeMillis()
                                        ),
                                        originalUrl = video.originalUrl.ifBlank { "https://www.youtube.com/watch?v=${video.id}" }
                                    )
                                }
                            },
                            onCancelActiveTask = { taskId ->
                                viewModel.removeActiveTask(taskId)
                            },
                            onSearchResultClick = { result ->
                                viewModel.updateUrlInput(result.originalUrl)
                                viewModel.analyzeVideo()
                            },
                            showAdvancedFormats = showAdvancedFormats,
                            onToggleShowAdvancedFormats = { viewModel.updateShowAdvancedFormats(it) },
                            isIncognitoMode = isIncognitoMode,
                            onToggleIncognito = { viewModel.updateIncognitoMode(!isIncognitoMode) },
                            onScheduleFormat = { format ->
                                analyzedVideo?.let { video ->
                                    schedulingVideoInfo = Triple(video.title, video.originalUrl.ifBlank { "https://www.youtube.com/watch?v=${video.id}" }, format)
                                }
                            },
                            viewModel = viewModel
                        )
                        1 -> {
                            val activeMap by viewModel.activeDownloadsOnUi.collectAsStateWithLifecycle()
                            val failedTasks = remember(activeMap) {
                                activeMap.values.filter { it.status == com.example.ui.DownloadStatus.FAILED }
                            }
                            LibraryTab(
                                downloads = (downloadHistory + deviceMedia).distinctBy { it.localPath }.sortedByDescending { it.downloadedAt },
                                failedTasks = failedTasks,
                                appDownloadedPaths = downloadHistory.map { it.localPath }.toSet(),
                                onPlayClick = { 
                                    viewModel.startPlayingMedia(it)
                                },
                                onShareClick = { viewModel.shareVideo(context, it) },
                                onDeleteClick = { viewModel.deleteDownload(it) },
                                onDeleteFailedClick = { taskId -> viewModel.removeActiveTask(taskId) },
                                onConvertAudio = { item, codec -> viewModel.convertAudio(item, codec) },
                                onBulkDeleteClick = { selectedDownloads, selectedFailedIds ->
                                    selectedDownloads.forEach { viewModel.deleteDownload(it) }
                                    selectedFailedIds.forEach { viewModel.removeActiveTask(it) }
                                },
                                onEditMetadataClick = { editingMetadataItem = it },
                                onAddToPlaylistClick = { playlistItemToAdd = it },
                                viewModel = viewModel
                            )
                        }
                        2 -> HistoryTab(
                            historyList = viewModel.browsingHistory.collectAsStateWithLifecycle().value,
                            onPlayClick = { historyItem ->
                                if (historyItem.originalUrl.startsWith("http")) {
                                    viewModel.updateUrlInput(historyItem.originalUrl)
                                    selectedTabIndex = 0
                                    viewModel.analyzeVideo()
                                } else {
                                    viewModel.startPlayingMedia(com.example.data.DownloadEntity(
                                        id = historyItem.id,
                                        title = if (historyItem.title.startsWith("[Streaming")) historyItem.title else "[Streaming Video] ${historyItem.title}",
                                        author = historyItem.author,
                                        durationText = historyItem.durationText,
                                        thumbnailUrl = historyItem.thumbnailUrl,
                                        localPath = historyItem.originalUrl,
                                        fileSize = 0L,
                                        downloadedAt = historyItem.browsedAt
                                    ))
                                }
                            },
                            onDeleteClick = { id -> viewModel.deleteBrowsingRecord(id) },
                            onClearAllClick = { viewModel.clearAllBrowsingHistory() },
                            onRevisitClick = { historyItem ->
                                viewModel.updateUrlInput(historyItem.originalUrl)
                                selectedTabIndex = 0
                                viewModel.analyzeVideo()
                            }
                        )
                        3 -> SettingsTab(
                            downloads = (downloadHistory + deviceMedia).distinctBy { it.localPath }.sortedByDescending { it.downloadedAt },
                            onClearAllDownloads = { viewModel.clearAllDownloads() },
                            viewModel = viewModel
                        )
                    }
                }
            }
        }

            if (!isPlayerFullscreen && selectedTabIndex == 0) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .offset { IntOffset(0, topBarOffsetHeightPx.roundToInt()) }
                        .statusBarsPadding()
                        .padding(start = if (!isMobile) 130.dp else 16.dp, end = 16.dp, top = 16.dp, bottom = 4.dp)
                ) {
                    // Left side: Floating Text (Title & version badge in an elegant glassmorphic capsule)
                    Surface(
                        modifier = Modifier
                            .align(Alignment.CenterStart)
                            .shadow(
                                elevation = 12.dp,
                                shape = RoundedCornerShape(24.dp),
                                clip = false,
                                ambientColor = SleekPurpleLight.copy(alpha = 0.25f),
                                spotColor = SleekPurpleLight.copy(alpha = 0.45f)
                            ),
                        shape = RoundedCornerShape(24.dp),
                        color = Color(0xCC121218), // Deep glassmorphic background
                        border = BorderStroke(
                            width = 1.dp,
                            brush = Brush.linearGradient(
                                colors = listOf(
                                    SleekPurpleLight.copy(alpha = 0.5f),
                                    Color.Transparent,
                                    SleekPurpleDark.copy(alpha = 0.3f)
                                )
                            )
                        )
                    ) {
                        Row(
                            modifier = Modifier
                                .padding(horizontal = 16.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.CloudDownload,
                                contentDescription = "Logo Icon",
                                tint = SleekPurpleLight,
                                modifier = Modifier.size(18.dp)
                            )
                            Text(
                                text = "꒯ꄲꅐꋊ꒒ꌦ",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.ExtraBold,
                                    color = Color.White,
                                    fontSize = 18.sp,
                                    letterSpacing = (-0.5).sp
                                )
                            )
                            if (displayVersion.isNotEmpty() && displayVersion != "Not checked") {
                                Box(
                                    modifier = Modifier
                                        .height(18.dp)
                                        .background(
                                            color = SleekPurpleLight.copy(alpha = 0.15f),
                                            shape = RoundedCornerShape(6.dp)
                                        )
                                        .border(
                                            width = 0.5.dp,
                                            color = SleekPurpleLight.copy(alpha = 0.3f),
                                            shape = RoundedCornerShape(6.dp)
                                        )
                                        .padding(horizontal = 4.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = displayVersion,
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = SleekPurpleLight,
                                            fontSize = 9.sp
                                        )
                                    )
                                }
                            }
                        }
                    }

                    // Right side: Floating Action Buttons (independent floating circular widgets)
                    Row(
                        modifier = Modifier.align(Alignment.CenterEnd),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (isYtdlpUpdateAvailable || isYtdlpLoading) {
                            var showUpdateConfirmDialog by remember { mutableStateOf(false) }
                            
                            // Automatically dismiss the dialog when update finishes
                            LaunchedEffect(isYtdlpLoading) {
                                if (!isYtdlpLoading) {
                                    showUpdateConfirmDialog = false
                                }
                            }

                            Surface(
                                modifier = Modifier
                                    .shadow(
                                        elevation = 12.dp,
                                        shape = CircleShape,
                                        clip = false,
                                        ambientColor = SleekPurpleLight.copy(alpha = 0.25f),
                                        spotColor = SleekPurpleLight.copy(alpha = 0.45f)
                                    ),
                                shape = CircleShape,
                                color = Color(0xCC121218),
                                border = BorderStroke(
                                    width = 1.dp,
                                    brush = Brush.linearGradient(
                                        colors = listOf(
                                            SleekPurpleLight.copy(alpha = 0.5f),
                                            Color.Transparent,
                                            SleekPurpleDark.copy(alpha = 0.3f)
                                        )
                                    )
                                )
                            ) {
                                IconButton(
                                    onClick = {
                                        if (!isYtdlpLoading) {
                                            showUpdateConfirmDialog = true
                                        }
                                    },
                                    modifier = Modifier
                                        .size(38.dp)
                                        .testTag("ytdlp_update_icon"),
                                    enabled = !isYtdlpLoading
                                ) {
                                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                        if (isYtdlpLoading) {
                                            CircularProgressIndicator(
                                                modifier = Modifier.size(16.dp),
                                                color = SleekPurpleLight,
                                                strokeWidth = 2.dp
                                            )
                                        } else {
                                            Icon(
                                                imageVector = Icons.Default.SystemUpdateAlt,
                                                contentDescription = "Update Available",
                                                tint = SleekPurpleLight,
                                                modifier = Modifier.size(18.dp)
                                            )
                                            Box(
                                                modifier = Modifier
                                                    .size(6.dp)
                                                    .background(CrimsonFailure, shape = CircleShape)
                                                    .align(Alignment.TopEnd)
                                                    .offset(x = (-2).dp, y = 2.dp)
                                            )
                                        }
                                    }
                                }
                            }

                            if (showUpdateConfirmDialog) {
                                AlertDialog(
                                    onDismissRequest = {
                                        if (!isYtdlpLoading) {
                                            showUpdateConfirmDialog = false
                                        }
                                    },
                                    title = {
                                        Text(
                                            text = "Update yt-dlp Core",
                                            color = SleekTextPrimary,
                                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                        )
                                    },
                                    text = {
                                        Text(
                                            text = if (isYtdlpLoading) {
                                                "Updating yt-dlp core to the latest version... Please keep the app open and do not interrupt."
                                            } else {
                                                "A new version of yt-dlp is available online! Would you like to delete the old binaries and perform a clean install of the updated version?"
                                            },
                                            color = SleekTextSecondary,
                                            style = MaterialTheme.typography.bodyMedium
                                        )
                                    },
                                    containerColor = SleekCard,
                                    confirmButton = {
                                        Button(
                                            onClick = {
                                                viewModel.performYtdlpUpdateAndInstall(context)
                                            },
                                            enabled = !isYtdlpLoading,
                                            colors = ButtonDefaults.buttonColors(
                                                containerColor = Color.White,
                                                contentColor = Color.Black,
                                                disabledContainerColor = Color.White.copy(alpha = 0.5f)
                                            )
                                        ) {
                                            if (isYtdlpLoading) {
                                                CircularProgressIndicator(
                                                    modifier = Modifier.size(18.dp),
                                                    color = Color.Black,
                                                    strokeWidth = 2.dp
                                                )
                                            } else {
                                                Icon(Icons.Default.Download, contentDescription = "Update & Install")
                                            }
                                        }
                                    },
                                    dismissButton = {
                                        if (!isYtdlpLoading) {
                                            TextButton(
                                                onClick = { showUpdateConfirmDialog = false }
                                            ) {
                                                Icon(Icons.Default.Close, contentDescription = "Cancel", tint = SleekTextMuted)
                                            }
                                        }
                                    }
                                )
                            }
                        }

                        FluidIncognitoButton(
                            isIncognitoMode = isIncognitoMode,
                            onToggle = { viewModel.updateIncognitoMode(!isIncognitoMode) }
                        )

                        Surface(
                            modifier = Modifier
                                .shadow(
                                    elevation = 12.dp,
                                    shape = CircleShape,
                                    clip = false,
                                    ambientColor = SleekPurpleLight.copy(alpha = 0.15f),
                                    spotColor = SleekPurpleLight.copy(alpha = 0.25f)
                                ),
                            shape = CircleShape,
                            color = Color(0xCC121218),
                            border = BorderStroke(
                                width = 1.dp,
                                brush = Brush.linearGradient(
                                    colors = listOf(
                                        SleekPurpleLight.copy(alpha = 0.3f),
                                        Color.Transparent,
                                        SleekPurpleDark.copy(alpha = 0.15f)
                                    )
                                )
                            )
                        ) {
                            IconButton(
                                onClick = { showBatchQueueModal = true },
                                modifier = Modifier.size(38.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Queue,
                                    contentDescription = "Queue Settings",
                                    tint = SleekPurpleLight,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }

                        Surface(
                            modifier = Modifier
                                .shadow(
                                    elevation = 12.dp,
                                    shape = CircleShape,
                                    clip = false,
                                    ambientColor = SleekPurpleLight.copy(alpha = 0.15f),
                                    spotColor = SleekPurpleLight.copy(alpha = 0.25f)
                                ),
                            shape = CircleShape,
                            color = Color(0xCC121218),
                            border = BorderStroke(
                                width = 1.dp,
                                brush = Brush.linearGradient(
                                    colors = listOf(
                                        SleekPurpleLight.copy(alpha = 0.3f),
                                        Color.Transparent,
                                        SleekPurpleDark.copy(alpha = 0.15f)
                                    )
                                )
                            )
                        ) {
                            IconButton(
                                onClick = { showAboutDialog = true },
                                modifier = Modifier.size(38.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Info,
                                    contentDescription = "About App",
                                    tint = SleekPurpleLight,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }
                }
            }

            androidx.compose.animation.AnimatedVisibility(
                visible = playingMedia != null,
                enter = androidx.compose.animation.fadeIn(
                    animationSpec = androidx.compose.animation.core.tween(150, easing = androidx.compose.animation.core.FastOutLinearInEasing)
                ) + androidx.compose.animation.slideInVertically(
                    initialOffsetY = { it / 16 },
                    animationSpec = androidx.compose.animation.core.tween(160, easing = androidx.compose.animation.core.FastOutSlowInEasing)
                ),
                exit = androidx.compose.animation.fadeOut(
                    animationSpec = androidx.compose.animation.core.tween(120, easing = androidx.compose.animation.core.LinearOutSlowInEasing)
                ) + androidx.compose.animation.slideOutVertically(
                    targetOffsetY = { it / 16 },
                    animationSpec = androidx.compose.animation.core.tween(120, easing = androidx.compose.animation.core.LinearOutSlowInEasing)
                )
            ) {
                playingMedia?.let { media ->
                    FloatingPlayerOverlay(
                        media = media,
                        isFullscreen = isPlayerFullscreen,
                        onToggleFullscreen = { isPlayerFullscreen = !isPlayerFullscreen },
                        onClose = { viewModel.stopPlayingMedia() },
                        analyzedVideo = analyzedVideo,
                        onStreamFormat = { format ->
                            analyzedVideo?.let { video ->
                                val isAudio = isAudioFormat(format)
                                val isVideoOnly = !isAudio && (format.acodec == "none" || format.acodec.isBlank() || !format.hasAudio || format.type == "video_only")
                                val audioFormat = if (isVideoOnly) {
                                    video.formats.filter { isAudioFormat(it) }
                                        .maxByOrNull { it.audioBitrateKbps ?: 0 }
                                        ?: video.formats.filter { isAudioFormat(it) }
                                            .maxByOrNull { it.sizeBytes }
                                } else {
                                    null
                                }
                                
                                val videoUrl = format.downloadUrl.ifBlank { format.downloadUrl }.ifBlank { video.originalUrl }
                                val streamUrl = if (audioFormat != null) {
                                    val audioUrl = audioFormat.downloadUrl.ifBlank { audioFormat.downloadUrl }.ifBlank { video.originalUrl }
                                    "$videoUrl|STREAM_AUDIO_URL|$audioUrl"
                                } else {
                                    videoUrl
                                }

                                viewModel.startPlayingMedia(
                                    item = DownloadEntity(
                                        id = video.id,
                                        title = if (isAudio) "[Streaming Audio] ${video.title}" else "[Streaming Video] ${video.title}",
                                        author = video.author,
                                        durationText = video.durationText,
                                        thumbnailUrl = video.thumbnailUrl,
                                        localPath = streamUrl,
                                        fileSize = format.sizeBytes,
                                        downloadedAt = System.currentTimeMillis()
                                    ),
                                    originalUrl = video.originalUrl.ifBlank { "https://www.youtube.com/watch?v=${video.id}" }
                                )
                            }
                        },
                        viewModel = viewModel,
                        onOpenAudioFxStudio = { showAudioFxStudioDialog = true }
                    )
                }
            }
        }
    }

            activeTrimState?.let { trimState ->
                MediaTrimmerDialog(
                    state = trimState,
                    onUpdateRange = { start, end -> viewModel.updateTrimRange(start, end) },
                    onPreview = {
                        viewModel.startPlayingMedia(trimState.media)
                    },
                    onExport = { viewModel.executeMediaTrim() },
                    onCancelExport = { viewModel.cancelMediaTrim() },
                    onOpenExported = { entity ->
                        viewModel.closeMediaTrimmer()
                        viewModel.startPlayingMedia(entity)
                    },
                    onShareExported = { path ->
                        try {
                            val context = context
                            val file = java.io.File(path)
                            val uri = androidx.core.content.FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
                            val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                                type = "video/*"
                                putExtra(android.content.Intent.EXTRA_STREAM, uri)
                                addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            }
                            context.startActivity(android.content.Intent.createChooser(intent, "Share Exported Segment"))
                        } catch (e: Exception) {
                            android.widget.Toast.makeText(context, "Share error: ${e.message}", android.widget.Toast.LENGTH_SHORT).show()
                        }
                    },
                    onDismiss = { viewModel.closeMediaTrimmer() }
                )
            }

            activeCompressState?.let { compressState ->
                VideoCompressionDialog(
                    state = compressState,
                    onSelectPreset = { presetId -> viewModel.selectCompressPreset(presetId) },
                    onUpdateCustomOptions = { w, h, vKbps, aKbps, fps ->
                        viewModel.updateCustomCompressOptions(w, h, vKbps, aKbps, fps)
                    },
                    onCompress = { viewModel.executeVideoCompression() },
                    onCancelCompress = { viewModel.cancelVideoCompression() },
                    onOpenCompressed = { entity ->
                        viewModel.closeVideoCompressor()
                        viewModel.startPlayingMedia(entity)
                    },
                    onShareCompressed = { path ->
                        try {
                            val context = context
                            val file = java.io.File(path)
                            val uri = androidx.core.content.FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
                            val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                                type = "video/*"
                                putExtra(android.content.Intent.EXTRA_STREAM, uri)
                                addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            }
                            context.startActivity(android.content.Intent.createChooser(intent, "Share Compressed Video"))
                        } catch (e: Exception) {
                            android.widget.Toast.makeText(context, "Share error: ${e.message}", android.widget.Toast.LENGTH_SHORT).show()
                        }
                    },
                    onDismiss = { viewModel.closeVideoCompressor() }
                )
            }

            if (showAudioFxStudioDialog) {
                AudioFxStudioModal(
                    viewModel = viewModel,
                    onDismiss = { showAudioFxStudioDialog = false }
                )
            }

            if (showBatchQueueModal) {
                BatchQueueManagerModal(
                    viewModel = viewModel,
                    onDismiss = { showBatchQueueModal = false }
                )
            }

            editingMetadataItem?.let { item ->
                MetadataEditorModal(
                    item = item,
                    viewModel = viewModel,
                    onDismiss = { editingMetadataItem = null }
                )
            }

            schedulingVideoInfo?.let { triple ->
                DownloadSchedulerModal(
                    viewModel = viewModel,
                    videoTitle = triple.first,
                    videoUrl = triple.second,
                    formatQuality = triple.third.quality,
                    formatExt = triple.third.ext,
                    onDismiss = { schedulingVideoInfo = null }
                )
            }

            playlistItemToAdd?.let { item ->
                AddToPlaylistModal(
                    item = item,
                    viewModel = viewModel,
                    onCreateNewRequest = { showCreatePlaylistModal = true },
                    onDismiss = { playlistItemToAdd = null }
                )
            }

            if (showCreatePlaylistModal) {
                CreatePlaylistModal(
                    viewModel = viewModel,
                    onDismiss = { showCreatePlaylistModal = false }
                )
            }

            if (showAboutDialog) {
                AlertDialog(
                    onDismissRequest = { showAboutDialog = false },
                    title = {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(42.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .border(1.dp, SleekPurpleLight.copy(alpha = 0.4f), RoundedCornerShape(12.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Image(
                                    painter = painterResource(id = R.drawable.img_downly_logo_1787355493817),
                                    contentDescription = "Downly Logo",
                                    modifier = Modifier.fillMaxSize(),
                                    contentScale = ContentScale.Crop
                                )
                            }
                            Column {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Text(
                                        text = "About Downly",
                                        color = SleekTextPrimary,
                                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                                    )
                                    Surface(
                                        shape = RoundedCornerShape(6.dp),
                                        color = SleekPurpleLight.copy(alpha = 0.15f),
                                        border = BorderStroke(0.5.dp, SleekPurpleLight.copy(alpha = 0.3f))
                                    ) {
                                        Text(
                                            text = "v3.4.0 Pro",
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                fontWeight = FontWeight.Bold,
                                                color = SleekPurpleLight
                                            ),
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                                Text(
                                    text = "High-Performance Media Downloader",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = SleekTextSecondary
                                )
                            }
                        }
                    },
                    text = {
                        Column(
                            verticalArrangement = Arrangement.spacedBy(14.dp),
                            modifier = Modifier.verticalScroll(rememberScrollState())
                        ) {
                            Text(
                                text = "Downly is an ultra-fast offline media downloader and converter powered by standard yt-dlp & FFmpeg engines. Built for high-speed multi-threaded downloads, stream extraction, and zero-compromise privacy.",
                                color = SleekTextSecondary,
                                style = MaterialTheme.typography.bodyMedium,
                                lineHeight = 20.sp
                            )

                            // DEVELOPER CARD - CLEAN & SMOOTH
                            Surface(
                                onClick = {
                                    openInstagramProfile(context, "_junior_sir_")
                                },
                                shape = RoundedCornerShape(14.dp),
                                color = Color(0xFF1B1124),
                                border = BorderStroke(1.dp, Color(0xFFE1306C).copy(alpha = 0.35f)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(38.dp)
                                                .background(
                                                    Brush.linearGradient(
                                                        listOf(
                                                            Color(0xFF833AB4).copy(alpha = 0.2f),
                                                            Color(0xFFFD1D1D).copy(alpha = 0.2f),
                                                            Color(0xFFFCB045).copy(alpha = 0.2f)
                                                        )
                                                    ),
                                                    CircleShape
                                                )
                                                .border(1.dp, Color(0xFFFD1D1D).copy(alpha = 0.4f), CircleShape),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            InstagramIcon(modifier = Modifier.size(20.dp), useGradient = true)
                                        }
                                        Column {
                                            Text(
                                                text = "JuniorSir",
                                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                                color = Color.White
                                            )
                                            Text(
                                                text = "Lead Developer",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = Color(0xFFFCB045)
                                            )
                                        }
                                    }
                                    Box(
                                        modifier = Modifier
                                            .size(30.dp)
                                            .background(Color(0xFFFD1D1D).copy(alpha = 0.12f), CircleShape),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.ArrowForward,
                                            contentDescription = "Open Instagram Profile",
                                            tint = Color(0xFFFCAF45),
                                            modifier = Modifier.size(15.dp)
                                        )
                                    }
                                }
                            }

                            // HIGHLIGHT CHIPS
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                listOf("yt-dlp Core", "FFmpeg JNI", "100% Private").forEach { tag ->
                                    Surface(
                                        modifier = Modifier.weight(1f),
                                        shape = RoundedCornerShape(8.dp),
                                        color = SleekPurpleLight.copy(alpha = 0.08f),
                                        border = BorderStroke(0.5.dp, SleekPurpleLight.copy(alpha = 0.2f))
                                    ) {
                                        Text(
                                            text = tag,
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                fontWeight = FontWeight.SemiBold,
                                                fontSize = 10.sp
                                            ),
                                            color = SleekTextPrimary,
                                            textAlign = TextAlign.Center,
                                            modifier = Modifier.padding(vertical = 6.dp)
                                        )
                                    }
                                }
                            }

                            // TECH SPECS SUMMARY
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(Color.Black.copy(alpha = 0.25f), RoundedCornerShape(12.dp))
                                    .padding(horizontal = 12.dp, vertical = 10.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(Icons.Default.Email, contentDescription = null, tint = SleekPurpleLight, modifier = Modifier.size(15.dp))
                                    Text("Contact:", style = MaterialTheme.typography.labelSmall, color = SleekTextMuted)
                                    Text("officialmp4go@gmail.com", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Medium), color = SleekPurpleLight)
                                }
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(Icons.Default.Layers, contentDescription = null, tint = SleekPurpleLight, modifier = Modifier.size(15.dp))
                                    Text("Architecture:", style = MaterialTheme.typography.labelSmall, color = SleekTextMuted)
                                    Text("Jetpack Compose M3 & Room DB", style = MaterialTheme.typography.bodySmall, color = SleekTextSecondary)
                                }
                            }

                            // LEGAL POLICIES BUTTONS
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                OutlinedButton(
                                    onClick = {
                                        showAboutDialog = false
                                        showTermsDialog = true
                                    },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(10.dp),
                                    border = BorderStroke(1.dp, SleekPurpleLight.copy(alpha = 0.35f)),
                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = SleekPurpleLight),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp)
                                ) {
                                    Icon(Icons.Default.Security, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Terms", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                }

                                OutlinedButton(
                                    onClick = {
                                        showAboutDialog = false
                                        showPrivacyDialog = true
                                    },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(10.dp),
                                    border = BorderStroke(1.dp, SleekPurpleLight.copy(alpha = 0.35f)),
                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = SleekPurpleLight),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp)
                                ) {
                                    Icon(Icons.Default.Lock, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Privacy", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                }
                            }

                            Text(
                                text = "© 2026 Downly Media Tech. All rights reserved.",
                                style = MaterialTheme.typography.labelSmall,
                                color = SleekTextMuted,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.fillMaxWidth().padding(top = 2.dp)
                            )
                        }
                    },
                    containerColor = SleekCard,
                    confirmButton = {
                        Button(
                            onClick = { showAboutDialog = false },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color.White,
                                contentColor = Color.Black
                            ),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Default.Check, contentDescription = "Close")
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Close", fontWeight = FontWeight.Bold)
                        }
                    }
                )
            }

            if (showTermsDialog) {
                TermsAndConditionsDialog(onDismiss = { showTermsDialog = false })
            }

            if (showPrivacyDialog) {
                PrivacyPolicyDialog(onDismiss = { showPrivacyDialog = false })
            }

            // Mobile Bottom Floating Navigation Capsule
            if (isMobile && !isPlayerFullscreen) {
                val infiniteTransition = rememberInfiniteTransition(label = "FabGlowTransition")
                val fabScale by infiniteTransition.animateFloat(
                    initialValue = 1f,
                    targetValue = 1.04f,
                    animationSpec = infiniteRepeatable(
                        animation = tween(2000, easing = LinearEasing),
                        repeatMode = RepeatMode.Reverse
                    ),
                    label = "FabScale"
                )

                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.BottomCenter
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .navigationBarsPadding()
                            .padding(bottom = 12.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                    val isBgActive by (viewModel.isBackgroundPlaybackActive).collectAsStateWithLifecycle()
                    val bgMedia by (viewModel.backgroundMedia).collectAsStateWithLifecycle()
                    val isBgPlaying by (viewModel.isBackgroundPlaying).collectAsStateWithLifecycle()
                    val bgPos by (viewModel.backgroundPositionMs).collectAsStateWithLifecycle()
                    val bgDur by (viewModel.backgroundDurationMs).collectAsStateWithLifecycle()

                    androidx.compose.animation.AnimatedVisibility(
                        visible = isBgActive && bgMedia != null && playingMedia == null,
                        enter = fadeIn(tween(250)) + slideInVertically(initialOffsetY = { it }),
                        exit = fadeOut(tween(200)) + slideOutVertically(targetOffsetY = { it })
                    ) {
                        bgMedia?.let { media ->
                            YouTubeBackgroundMiniPlayerBar(
                                media = media,
                                isPlaying = isBgPlaying,
                                currentPosMs = bgPos,
                                durationMs = bgDur,
                                onTogglePlay = { viewModel.toggleBackgroundPlayPause() },
                                onSeekRelative = { delta -> viewModel.seekBackgroundBy(delta) },
                                onOpenFullPlayer = {
                                    com.example.media.BackgroundPlaybackManager.stop(context)
                                    viewModel.startPlayingMedia(media)
                                },
                                onClose = {
                                    viewModel.stopBackgroundPlayback()
                                },
                                modifier = Modifier
                                    .widthIn(max = 500.dp)
                                    .fillMaxWidth()
                                    .padding(horizontal = 16.dp, vertical = 6.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(2.dp))

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 12.dp),
                        contentAlignment = Alignment.BottomCenter
                    ) {
                    // Blurred Frosted Glass Background under Navigation Capsule
                    Box(
                        modifier = Modifier
                            .width(328.dp)
                            .height(72.dp)
                            .blur(20.dp)
                            .background(
                                brush = Brush.verticalGradient(
                                    colors = listOf(
                                        Color(0x801A1B23),
                                        Color(0x600F1015)
                                    )
                                ),
                                shape = RoundedCornerShape(36.dp)
                            )
                    )

                    // Complete Rounded Capsule Navigation Bar
                    Surface(
                        modifier = Modifier
                            .width(328.dp)
                            .height(72.dp)
                            .shadow(
                                elevation = 16.dp,
                                shape = RoundedCornerShape(36.dp),
                                spotColor = Color(0x55000000),
                                ambientColor = Color(0x55000000)
                            ),
                        shape = RoundedCornerShape(36.dp),
                        color = Color(0xB3121218),
                        border = BorderStroke(1.dp, Color(0x26FFFFFF))
                    ) {
                        Row(
                            modifier = Modifier.fillMaxSize(),
                            horizontalArrangement = Arrangement.SpaceEvenly,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Zone 1: Home
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .fillMaxHeight(),
                                contentAlignment = Alignment.Center
                            ) {
                                LiquidGlassIcon(
                                    imageVector = Icons.Default.Home,
                                    contentDescription = "Home",
                                    isSelected = selectedTabIndex == 0,
                                    containerSize = 46.dp,
                                    size = 24.dp,
                                    onClick = { selectedTabIndex = 0 }
                                )
                            }

                            // Zone 2: Library
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .fillMaxHeight(),
                                contentAlignment = Alignment.Center
                            ) {
                                LiquidGlassIcon(
                                    imageVector = Icons.Default.VideoLibrary,
                                    contentDescription = "Library",
                                    isSelected = selectedTabIndex == 1,
                                    containerSize = 46.dp,
                                    size = 24.dp,
                                    onClick = { selectedTabIndex = 1 }
                                )
                            }

                            // Zone 3: Placeholder Zone for Center FAB Alignment
                            Spacer(modifier = Modifier.weight(1f))

                            // Zone 4: History
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .fillMaxHeight(),
                                contentAlignment = Alignment.Center
                            ) {
                                LiquidGlassIcon(
                                    imageVector = Icons.Default.History,
                                    contentDescription = "History",
                                    isSelected = selectedTabIndex == 2,
                                    containerSize = 46.dp,
                                    size = 24.dp,
                                    onClick = { selectedTabIndex = 2 }
                                )
                            }

                            // Zone 5: Settings
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .fillMaxHeight(),
                                contentAlignment = Alignment.Center
                            ) {
                                LiquidGlassIcon(
                                    imageVector = Icons.Default.Settings,
                                    contentDescription = "Settings",
                                    isSelected = selectedTabIndex == 3,
                                    containerSize = 46.dp,
                                    size = 24.dp,
                                    onClick = { selectedTabIndex = 3 }
                                )
                            }
                        }
                    }

                    // Hovering Complete Circular Download FAB (using LiquidGlassIcon theme matching tablet)
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopCenter)
                            .offset(y = (-10).dp)
                            .graphicsLayer {
                                scaleX = fabScale
                                scaleY = fabScale
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        LiquidGlassIcon(
                            imageVector = Icons.Default.FileDownload,
                            contentDescription = "Download FAB",
                            isSelected = true,
                            containerSize = 58.dp,
                            size = 28.dp,
                            onClick = {
                                selectedTabIndex = 0
                                if (urlInput.trim().isNotEmpty()) {
                                    viewModel.analyzeVideo()
                                }
                            }
                        )
                    }
                }
            }
        }
    }
}
}

@Composable
fun LargeScreenNavigationDock(
    selectedTabIndex: Int,
    onTabSelected: (Int) -> Unit,
    onQuickActionClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val configuration = androidx.compose.ui.platform.LocalConfiguration.current
    val widthDp = configuration.screenWidthDp

    Surface(
        modifier = modifier
            .fillMaxHeight()
            .width(88.dp)
            .padding(start = 12.dp, top = 16.dp, bottom = 16.dp, end = 12.dp),
        shape = RoundedCornerShape(36.dp),
        color = Color(0xE6111216),
        border = BorderStroke(1.2.dp, Color.White.copy(alpha = 0.12f)),
        shadowElevation = 24.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(vertical = 24.dp, horizontal = 4.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Header Logo
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .border(1.dp, Color(0xFF8B5CF6).copy(alpha = 0.5f), RoundedCornerShape(14.dp)),
                contentAlignment = Alignment.Center
            ) {
                Image(
                    painter = painterResource(id = R.drawable.img_downly_logo_1787355493817),
                    contentDescription = "Downly Logo",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
            }

            // Central Navigation Tabs (Liquid Glass Icons without labels)
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(20.dp)
            ) {
                val navItems = listOf(
                    DownlyNavItem(0, Icons.Default.Home, "Home", 0),
                    DownlyNavItem(1, Icons.Default.Search, "Search", 0),
                    DownlyNavItem(2, Icons.Default.VideoLibrary, "Library", 1),
                    DownlyNavItem(3, Icons.Default.History, "History", 2),
                    DownlyNavItem(4, Icons.Default.FileDownload, "Downloads", 0),
                    DownlyNavItem(5, Icons.Default.Settings, "Settings", 3)
                )

                navItems.forEach { item ->
                    val isSelected = when (item.id) {
                        0 -> selectedTabIndex == 0
                        2 -> selectedTabIndex == 1
                        3 -> selectedTabIndex == 2
                        5 -> selectedTabIndex == 3
                        else -> false
                    }

                    LiquidGlassIcon(
                        imageVector = item.icon,
                        contentDescription = item.label,
                        isSelected = isSelected,
                        onClick = {
                            if (item.id == 1 || item.id == 4) {
                                onTabSelected(0)
                            } else {
                                onTabSelected(item.target)
                            }
                        }
                    )
                }
            }

            // Quick Download Action FAB Button
            LiquidGlassIcon(
                imageVector = Icons.Default.FileDownload,
                contentDescription = "Quick Download",
                isSelected = true,
                containerSize = 56.dp,
                size = 28.dp,
                onClick = onQuickActionClick
            )
        }
    }
}

data class DownlyNavItem(
    val id: Int,
    val icon: androidx.compose.ui.graphics.vector.ImageVector,
    val label: String,
    val target: Int
)

data class ThumbnailPreviewData(
    val isRecognized: Boolean,
    val platform: String,
    val thumbnailUrl: String?,
    val videoId: String?,
    val brandColor: Color,
    val icon: androidx.compose.ui.graphics.vector.ImageVector
)

fun extractYoutubeVideoId(url: String): String? {
    val patterns = listOf(
        "youtube\\.com/watch\\?v=([^&\\s]+)",
        "youtu\\.be/([^?\\s]+)",
        "youtube\\.com/shorts/([^?\\s]+)",
        "youtube\\.com/embed/([^?\\s]+)",
        "youtube\\.com/watch\\?.*v=([^&\\s]+)",
        "music\\.youtube\\.com/watch\\?v=([^&\\s]+)"
    )
    for (pattern in patterns) {
        val regex = Regex(pattern, RegexOption.IGNORE_CASE)
        val matchResult = regex.find(url)
        if (matchResult != null && matchResult.groupValues.size > 1) {
            return matchResult.groupValues[1]
        }
    }
    return null
}

fun getThumbnailPreviewData(url: String): ThumbnailPreviewData? {
    try {
        val trimmed = url.trim()
        if (trimmed.isEmpty()) return null
        if (!trimmed.startsWith("http://") && !trimmed.startsWith("https://")) return null

        // YouTube checks
        val ytVideoId = extractYoutubeVideoId(trimmed)
        if (ytVideoId != null) {
            return ThumbnailPreviewData(
                isRecognized = true,
                platform = "YouTube",
                thumbnailUrl = "https://img.youtube.com/vi/$ytVideoId/hqdefault.jpg",
                videoId = ytVideoId,
                brandColor = Color(0xFFFF0000),
                icon = Icons.Default.PlayCircleFilled
            )
        }

        // Instagram checks
        if (trimmed.contains("instagram.com", ignoreCase = true)) {
            return ThumbnailPreviewData(
                isRecognized = true,
                platform = "Instagram",
                thumbnailUrl = null,
                videoId = null,
                brandColor = Color(0xFFE1306C),
                icon = Icons.Default.CameraAlt
            )
        }

        // TikTok checks
        if (trimmed.contains("tiktok.com", ignoreCase = true)) {
            return ThumbnailPreviewData(
                isRecognized = true,
                platform = "TikTok",
                thumbnailUrl = null,
                videoId = null,
                brandColor = Color(0xFF00F2FE),
                icon = Icons.Default.MusicNote
            )
        }

        // Facebook checks
        if (trimmed.contains("facebook.com", ignoreCase = true) || trimmed.contains("fb.watch", ignoreCase = true)) {
            return ThumbnailPreviewData(
                isRecognized = true,
                platform = "Facebook",
                thumbnailUrl = null,
                videoId = null,
                brandColor = Color(0xFF1877F2),
                icon = Icons.Default.Public
            )
        }

        // X / Twitter checks
        if (trimmed.contains("twitter.com", ignoreCase = true) || trimmed.contains("x.com", ignoreCase = true)) {
            return ThumbnailPreviewData(
                isRecognized = true,
                platform = "X / Twitter",
                thumbnailUrl = null,
                videoId = null,
                brandColor = Color(0xFFFFFFFF),
                icon = Icons.Default.AlternateEmail
            )
        }

        // Generic
        return ThumbnailPreviewData(
            isRecognized = false,
            platform = "Web Video",
            thumbnailUrl = null,
            videoId = null,
            brandColor = Color(0xFFD97706),
            icon = Icons.Default.VideoLibrary
        )
    } catch (e: Throwable) {
        return null
    }
}

@Composable
fun VideoSelectionPreview(
    url: String,
    onAnalyzeClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val previewData = remember(url) { getThumbnailPreviewData(url) } ?: return

    AnimatedVisibility(
        visible = true,
        enter = expandVertically() + fadeIn(),
        exit = shrinkVertically() + fadeOut(),
        modifier = modifier
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 16.dp)
                .testTag("thumbnail_preview_card"),
            shape = RoundedCornerShape(20.dp),
            color = Color(0x1AFFFFFF),
            border = BorderStroke(
                width = 1.dp,
                brush = Brush.linearGradient(
                    colors = listOf(
                        previewData.brandColor.copy(alpha = 0.4f),
                        Color.Transparent,
                        Color(0x0DFFFFFF)
                    )
                )
            )
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Left side: 16:9 aspect ratio thumbnail or premium gradient placeholder
                Box(
                    modifier = Modifier
                        .size(width = 110.dp, height = 62.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(
                            Brush.linearGradient(
                                colors = listOf(
                                    previewData.brandColor.copy(alpha = 0.25f),
                                    Color(0x1AFFFFFF)
                                )
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    if (previewData.thumbnailUrl != null) {
                        AsyncImage(
                            model = previewData.thumbnailUrl,
                            contentDescription = "Cover Art Preview",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                        // Dark translucent overlay
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(Color.Black.copy(alpha = 0.2f))
                        )
                    } else {
                        // Brand colored radial glow
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(
                                    Brush.radialGradient(
                                        colors = listOf(
                                            previewData.brandColor.copy(alpha = 0.4f),
                                            Color.Transparent
                                        )
                                    )
                                )
                        )
                    }

                    // Floating platform icon
                    Box(
                        modifier = Modifier
                            .size(28.dp)
                            .background(Color.Black.copy(alpha = 0.65f), CircleShape)
                            .border(1.dp, Color.White.copy(alpha = 0.15f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = previewData.icon,
                            contentDescription = null,
                            tint = previewData.brandColor,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }

                // Middle: Text details
                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.Center
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .background(previewData.brandColor, CircleShape)
                        )
                        Text(
                            text = previewData.platform.uppercase(),
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp,
                                color = previewData.brandColor
                            )
                        )
                    }
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "Verify selection before starting the download. Ready to fetch details.",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = Color(0xFFB7BBC5).copy(alpha = 0.8f),
                            fontSize = 11.sp,
                            lineHeight = 14.sp
                        ),
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                // Right side: Quick Analyze/Confirm button
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(Color(0x1AFFFFFF))
                        .clickable { onAnalyzeClick() },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Bolt,
                        contentDescription = "Confirm and Analyze",
                        tint = Color.White,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun DownloadTab(
    urlInput: String,
    urlHistory: List<String>,
    searchSuggestions: List<String> = emptyList(),
    isAnalyzing: Boolean,
    analyzedVideo: AnalyzedVideo?,
    analysisError: String?,
    activeDownloads: Map<String, ActiveDownloadTask>,
    executionLogs: List<String>,
    isAudioOnly: Boolean,
    searchResults: List<YtdlpPipelineManager.SearchResult>,
    isSearching: Boolean,
    onToggleAudioOnly: () -> Unit,
    onClearLogs: () -> Unit,
    onUrlChange: (String) -> Unit,
    onClearUrlHistory: () -> Unit,
    onPasteClick: () -> Unit,
    onClearClick: () -> Unit,
    onAnalyzeClick: () -> Unit,
    onDownloadFormat: (VideoFormatUi) -> Unit,
    onStreamFormat: (VideoFormatUi) -> Unit,
    onCancelActiveTask: (String) -> Unit,
    onSearchResultClick: (YtdlpPipelineManager.SearchResult) -> Unit,
    showAdvancedFormats: Boolean = false,
    onToggleShowAdvancedFormats: (Boolean) -> Unit = {},
    isIncognitoMode: Boolean = false,
    onToggleIncognito: () -> Unit = {},
    onScheduleFormat: ((VideoFormatUi) -> Unit)? = null,
    viewModel: VideoDownloaderViewModel? = null
) {
    val searchFilterType by (viewModel?.searchFilterType ?: kotlinx.coroutines.flow.MutableStateFlow("ALL")).collectAsStateWithLifecycle()
    val embedSubtitles by (viewModel?.embedSubtitles ?: kotlinx.coroutines.flow.MutableStateFlow(true)).collectAsStateWithLifecycle()
    val embedAutoSubtitles by (viewModel?.embedAutoSubtitles ?: kotlinx.coroutines.flow.MutableStateFlow(true)).collectAsStateWithLifecycle()
    val embedAudioMetadata by (viewModel?.embedAudioMetadata ?: kotlinx.coroutines.flow.MutableStateFlow(true)).collectAsStateWithLifecycle()
    val audioMultistreams by (viewModel?.audioMultistreams ?: kotlinx.coroutines.flow.MutableStateFlow(false)).collectAsStateWithLifecycle()

    val configuration = androidx.compose.ui.platform.LocalConfiguration.current
    val screenWidthDp = configuration.screenWidthDp
    val columns = when {
        screenWidthDp < 600 -> 1
        screenWidthDp < 840 -> 2
        screenWidthDp < 1200 -> 3
        else -> 4
    }
    val maxContentWidth = (columns * 460).dp
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = false)
    var showDownloadSheet by remember { mutableStateOf(false) }
    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxHeight()
                .widthIn(max = maxContentWidth)
                .fillMaxWidth(),
            contentPadding = PaddingValues(
                start = 24.dp,
                end = 24.dp,
                top = 96.dp, // Generous padding to start below the floating top islands
                bottom = 140.dp // Generous bottom clearance for floating nav capsule
            ),
            verticalArrangement = Arrangement.spacedBy(28.dp)
        ) {
            // 1. Hero Header Card (32dp radius, 24dp internal padding, 18% height increase)
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.Transparent),
                    shape = RoundedCornerShape(32.dp),
                    border = BorderStroke(1.dp, Color(0x14FFFFFF)),
                    elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                Brush.radialGradient(
                                    colors = listOf(
                                        Color(0x288B1E2D),
                                        Color(0x28D97706),
                                        Color(0x14181820),
                                        Color(0x00000000)
                                    ),
                                    center = androidx.compose.ui.geometry.Offset(1000f, 0f),
                                    radius = 1200f
                                )
                            )
                            .background(Color(0x14FFFFFF))
                            .padding(24.dp)
                    ) {
                        Column {
                            // Ambient light highlight behind title
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 16.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                CrazyAnimationOrb()
                            }

                            Spacer(modifier = Modifier.height(24.dp))

                            var isIncognitoDetailExpanded by remember { mutableStateOf(false) }

                            // Expanded Incognito Band upside of Search Bar
                            androidx.compose.animation.AnimatedVisibility(
                                visible = isIncognitoMode,
                                enter = androidx.compose.animation.expandVertically(expandFrom = Alignment.Bottom) + androidx.compose.animation.fadeIn(),
                                exit = androidx.compose.animation.shrinkVertically(shrinkTowards = Alignment.Bottom) + androidx.compose.animation.fadeOut()
                            ) {
                                Surface(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(bottom = 14.dp)
                                        .shadow(
                                            elevation = 12.dp,
                                            shape = RoundedCornerShape(20.dp),
                                            spotColor = Color(0xFFFF4D5A).copy(alpha = 0.35f)
                                        ),
                                    shape = RoundedCornerShape(20.dp),
                                    color = Color(0xFF23161A),
                                    border = BorderStroke(1.dp, Color(0xFFFF4D5A).copy(alpha = 0.45f))
                                ) {
                                    Column(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .animateContentSize(animationSpec = tween(300))
                                            .padding(horizontal = 16.dp, vertical = 12.dp)
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clickable { isIncognitoDetailExpanded = !isIncognitoDetailExpanded },
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                                                modifier = Modifier.weight(1f)
                                            ) {
                                                // Glowing Goggles / Glasses Icon Badge
                                                Box(
                                                    modifier = Modifier
                                                        .size(40.dp)
                                                        .background(
                                                            Brush.radialGradient(
                                                                colors = listOf(Color(0xFFFF4D5A).copy(alpha = 0.4f), Color(0x1AFF4D5A))
                                                            ),
                                                            shape = CircleShape
                                                        )
                                                        .border(1.dp, Color(0xFFFF4D5A).copy(alpha = 0.6f), CircleShape),
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Default.VisibilityOff,
                                                        contentDescription = "Goggles Incognito Icon",
                                                        tint = Color(0xFFFF4D5A),
                                                        modifier = Modifier.size(22.dp)
                                                    )
                                                }

                                                Column {
                                                    Text(
                                                        text = "No one can see you",
                                                        style = MaterialTheme.typography.titleMedium.copy(
                                                            fontWeight = FontWeight.Bold,
                                                            fontSize = 15.sp,
                                                            letterSpacing = 0.2.sp
                                                        ),
                                                        color = Color.White
                                                    )
                                                    Text(
                                                        text = if (isIncognitoDetailExpanded) "Tap to collapse details" else "Incognito active • Tap expand icon for details",
                                                        style = MaterialTheme.typography.labelSmall,
                                                        color = Color(0xFFFF8A95)
                                                    )
                                                }
                                            }

                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(2.dp)
                                            ) {
                                                // Expand Icon for More Detail
                                                IconButton(
                                                    onClick = { isIncognitoDetailExpanded = !isIncognitoDetailExpanded },
                                                    modifier = Modifier.size(36.dp)
                                                ) {
                                                    Icon(
                                                        imageVector = if (isIncognitoDetailExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                                                        contentDescription = "Expand for details",
                                                        tint = Color(0xFFFF4D5A)
                                                    )
                                                }

                                                // Close / Turn off Incognito
                                                IconButton(
                                                    onClick = onToggleIncognito,
                                                    modifier = Modifier.size(36.dp)
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Default.Close,
                                                        contentDescription = "Turn off Incognito",
                                                        tint = Color(0xFFA5A5B2)
                                                    )
                                                }
                                            }
                                        }

                                        // Expandable Detail View
                                        if (isIncognitoDetailExpanded) {
                                            Spacer(modifier = Modifier.height(10.dp))
                                            HorizontalDivider(
                                                color = Color(0xFFFF4D5A).copy(alpha = 0.25f),
                                                thickness = 1.dp
                                            )
                                            Spacer(modifier = Modifier.height(10.dp))

                                            Column(
                                                verticalArrangement = Arrangement.spacedBy(8.dp),
                                                modifier = Modifier.fillMaxWidth()
                                            ) {
                                                Row(
                                                    verticalAlignment = Alignment.Top,
                                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Default.Security,
                                                        contentDescription = null,
                                                        tint = Color(0xFFFF4D5A),
                                                        modifier = Modifier.size(16.dp).padding(top = 2.dp)
                                                    )
                                                    Text(
                                                        text = "Search & browsing histories are strictly paused.",
                                                        style = MaterialTheme.typography.bodySmall,
                                                        color = Color(0xFFE2E8F0)
                                                    )
                                                }

                                                Row(
                                                    verticalAlignment = Alignment.Top,
                                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Default.Lock,
                                                        contentDescription = null,
                                                        tint = Color(0xFFFF4D5A),
                                                        modifier = Modifier.size(16.dp).padding(top = 2.dp)
                                                    )
                                                    Text(
                                                        text = "Downloads are saved privately in isolated storage.",
                                                        style = MaterialTheme.typography.bodySmall,
                                                        color = Color(0xFFE2E8F0)
                                                    )
                                                }

                                                Row(
                                                    verticalAlignment = Alignment.Top,
                                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Default.Shield,
                                                        contentDescription = null,
                                                        tint = Color(0xFFFF4D5A),
                                                        modifier = Modifier.size(16.dp).padding(top = 2.dp)
                                                    )
                                                    Text(
                                                        text = "Your identity and tracking cookies remain hidden.",
                                                        style = MaterialTheme.typography.bodySmall,
                                                        color = Color(0xFFE2E8F0)
                                                    )
                                                }

                                                Spacer(modifier = Modifier.height(4.dp))
                                                Row(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    horizontalArrangement = Arrangement.End
                                                ) {
                                                    TextButton(
                                                        onClick = onToggleIncognito
                                                    ) {
                                                        Text(
                                                            text = "Turn Off Incognito",
                                                            color = Color(0xFFFF4D5A),
                                                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
                                                        )
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                            // 2. Glass Search Input Card (64dp height, 24dp radius, glass styling)
                            var historyExpanded by remember { mutableStateOf(false) }
                            var isInputFocused by remember { mutableStateOf(false) }
                            val focusManager = androidx.compose.ui.platform.LocalFocusManager.current

                            Column(modifier = Modifier.fillMaxWidth()) {
                                OutlinedTextField(
                                    value = urlInput,
                                    onValueChange = { 
                                        onUrlChange(it) 
                                        historyExpanded = false 
                                    },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(64.dp)
                                        .onFocusChanged { state ->
                                            isInputFocused = state.isFocused
                                            if (state.isFocused && urlHistory.isNotEmpty() && urlInput.isEmpty()) {
                                                historyExpanded = true
                                            }
                                        }
                                        .testTag("url_input_field"),
                                    textStyle = MaterialTheme.typography.bodyLarge.copy(color = Color.White, fontSize = 15.sp),
                                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                                    keyboardActions = KeyboardActions(onSearch = { 
                                        focusManager.clearFocus()
                                        historyExpanded = false
                                        onAnalyzeClick() 
                                    }),
                                    placeholder = { 
                                        Text(
                                            "Search videos, playlists or URLs...", 
                                            color = Color(0xFFA5A5B2).copy(alpha = 0.55f), 
                                            maxLines = 1, 
                                            overflow = TextOverflow.Ellipsis, 
                                            fontSize = 14.sp
                                        ) 
                                    },
                                    leadingIcon = {
                                        Icon(
                                            imageVector = Icons.Default.Language,
                                            contentDescription = "Website",
                                            tint = Color(0xFFFF7A00),
                                            modifier = Modifier
                                                .padding(start = 12.dp)
                                                .size(24.dp)
                                        )
                                    },
                                    trailingIcon = {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                                            modifier = Modifier.padding(end = 8.dp)
                                        ) {
                                            if (urlInput.isNotEmpty()) {
                                                IconButton(
                                                    onClick = onClearClick,
                                                    modifier = Modifier.size(36.dp)
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Default.Clear,
                                                        contentDescription = "Clear",
                                                        tint = Color(0xFFA5A5B2),
                                                        modifier = Modifier.size(20.dp)
                                                    )
                                                }
                                            } else {
                                                androidx.compose.material3.TextButton(
                                                    onClick = onPasteClick,
                                                    contentPadding = PaddingValues(horizontal = 12.dp)
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Default.ContentPaste,
                                                        contentDescription = "Paste",
                                                        tint = Color(0xFFFF9D33),
                                                        modifier = Modifier.size(18.dp)
                                                    )
                                                    Spacer(modifier = Modifier.width(4.dp))
                                                    Text("Paste", color = Color(0xFFFF9D33), fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                                }
                                            }

                                            Box(
                                                modifier = Modifier
                                                    .size(44.dp)
                                                    .shadow(
                                                        elevation = 6.dp,
                                                        shape = CircleShape,
                                                        spotColor = Color(0xFFFF7A00).copy(alpha = 0.5f)
                                                    )
                                                    .clip(CircleShape)
                                                    .background(
                                                        brush = Brush.verticalGradient(
                                                            colors = listOf(Color(0xFFFF9D33), Color(0xFFFF7A00))
                                                        )
                                                    )
                                                    .clickable(
                                                        enabled = urlInput.trim().isNotEmpty() && !isAnalyzing,
                                                        onClick = {
                                                            focusManager.clearFocus()
                                                            historyExpanded = false
                                                            onAnalyzeClick()
                                                        }
                                                    ),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                if (isAnalyzing) {
                                                    CircularProgressIndicator(
                                                        modifier = Modifier.size(18.dp),
                                                        color = Color.White,
                                                        strokeWidth = 2.dp
                                                    )
                                                } else {
                                                    Icon(
                                                        imageVector = Icons.Default.ArrowForward,
                                                        contentDescription = "Analyze",
                                                        tint = Color.White,
                                                        modifier = Modifier.size(20.dp)
                                                    )
                                                }
                                            }
                                        }
                                    },
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedContainerColor = Color(0x14FFFFFF),
                                        unfocusedContainerColor = Color(0x0FFFFFFF),
                                        focusedBorderColor = Color(0xFFFF7A00),
                                        unfocusedBorderColor = Color(0x14FFFFFF),
                                        focusedTextColor = Color.White,
                                        unfocusedTextColor = Color.White,
                                        cursorColor = Color(0xFFFF7A00)
                                    ),
                                    shape = RoundedCornerShape(24.dp),
                                    singleLine = true
                                )

                                // 1. Live Search Suggestions Overlay
                                androidx.compose.animation.AnimatedVisibility(
                                    visible = isInputFocused && urlInput.isNotBlank() && searchSuggestions.isNotEmpty(),
                                    enter = androidx.compose.animation.expandVertically() + androidx.compose.animation.fadeIn(),
                                    exit = androidx.compose.animation.shrinkVertically() + androidx.compose.animation.fadeOut()
                                ) {
                                    Card(
                                        modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                                        colors = CardDefaults.cardColors(containerColor = Color(0xFF14151B)),
                                        shape = RoundedCornerShape(18.dp),
                                        border = BorderStroke(1.dp, Color(0x20FFFFFF))
                                    ) {
                                        Column(modifier = Modifier.padding(vertical = 6.dp)) {
                                            searchSuggestions.take(8).forEach { suggestion ->
                                                Row(
                                                    modifier = Modifier
                                                        .fillMaxWidth()
                                                        .clickable {
                                                            onUrlChange(suggestion)
                                                            historyExpanded = false
                                                            focusManager.clearFocus()
                                                            onAnalyzeClick()
                                                        }
                                                        .padding(horizontal = 16.dp, vertical = 12.dp),
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Default.Search,
                                                        contentDescription = null,
                                                        tint = Color(0xFFFF9D33),
                                                        modifier = Modifier.size(18.dp)
                                                    )
                                                    Spacer(modifier = Modifier.width(12.dp))
                                                    Text(
                                                        text = suggestion,
                                                        color = Color.White,
                                                        fontSize = 14.sp,
                                                        fontWeight = FontWeight.Medium,
                                                        maxLines = 1,
                                                        overflow = TextOverflow.Ellipsis,
                                                        modifier = Modifier.weight(1f)
                                                    )
                                                    Icon(
                                                        imageVector = Icons.Default.NorthWest,
                                                        contentDescription = null,
                                                        tint = Color(0xFFA5A5B2),
                                                        modifier = Modifier.size(14.dp)
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }

                                // 2. URL History Overlay
                                androidx.compose.animation.AnimatedVisibility(
                                    visible = historyExpanded && urlHistory.isNotEmpty() && urlInput.isBlank(),
                                    enter = androidx.compose.animation.expandVertically() + androidx.compose.animation.fadeIn(),
                                    exit = androidx.compose.animation.shrinkVertically() + androidx.compose.animation.fadeOut()
                                ) {
                                    Card(
                                        modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                                        colors = CardDefaults.cardColors(containerColor = Color(0xFF111216)),
                                        shape = RoundedCornerShape(16.dp),
                                        border = BorderStroke(1.dp, Color(0x14FFFFFF))
                                    ) {
                                        Column(modifier = Modifier.padding(vertical = 8.dp)) {
                                            urlHistory.forEach { historyUrl ->
                                                Row(
                                                    modifier = Modifier
                                                        .fillMaxWidth()
                                                        .clickable {
                                                            onUrlChange(historyUrl)
                                                            historyExpanded = false
                                                            focusManager.clearFocus()
                                                        }
                                                        .padding(horizontal = 16.dp, vertical = 12.dp),
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Icon(Icons.Default.History, contentDescription = null, tint = Color(0xFFA5A5B2))
                                                    Spacer(modifier = Modifier.width(12.dp))
                                                    Text(historyUrl, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                                }
                                            }
                                            HorizontalDivider(color = Color(0x14FFFFFF), modifier = Modifier.padding(vertical = 4.dp))
                                            Row(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .clickable {
                                                        onClearUrlHistory()
                                                        historyExpanded = false
                                                    }
                                                    .padding(horizontal = 16.dp, vertical = 12.dp),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Icon(Icons.Default.Delete, contentDescription = null, tint = Color(0xFFFF4D5A))
                                                Spacer(modifier = Modifier.width(12.dp))
                                                Text("Clear History", color = Color(0xFFFF4D5A))
                                            }
                                        }
                                    }
                                }
                            }

                            if (urlInput.isNotBlank() && analyzedVideo == null) {
                                VideoSelectionPreview(
                                    url = urlInput,
                                    onAnalyzeClick = onAnalyzeClick
                                )
                            }
                        }
                    }
                }
            }

            // Analyzed Video details card (Now right under the search bar for direct access!)
            if (isAnalyzing) {
                item {
                    SkeletonAnalyzedVideoCard()
                }
            } else if (analyzedVideo != null) {
                item {
                    AnalyzedVideoCard(
                        video = analyzedVideo,
                        onOpenDownloadOptions = {
                            showDownloadSheet = true
                        },
                        onStreamBestClick = {
                            val nonAudio = analyzedVideo.formats.filter { 
                                val type = it.type.lowercase()
                                val qual = it.quality.lowercase()
                                val ext = it.ext.lowercase()
                                val isAudio = type == "audio" || 
                                              (it.vcodec == "none" && it.acodec != null && it.acodec != "none") ||
                                              qual.contains("kbps") || qual.contains("audio") ||
                                              ext == "mp3" || ext == "m4a" || ext == "aac" || ext == "opus" || ext == "wav" || ext == "flac" || ext == "ogg"
                                !isAudio
                            }
                            val bestFormat = nonAudio.filter { (it.height ?: 0) <= 1080 }
                                .maxByOrNull { it.height ?: 0 }
                                ?: nonAudio.minByOrNull { it.height ?: 100000 }
                                ?: analyzedVideo.formats.firstOrNull { it.type == "combined" }
                                ?: analyzedVideo.formats.firstOrNull { it.type == "video_only" }
                                ?: analyzedVideo.formats.firstOrNull()
                            bestFormat?.let { onStreamFormat(it) }
                        }
                    )
                }
            }

            if (searchResults.isEmpty()) {
                item {
                    Text(
                        text = "Featured Spotlight",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontSize = 22.sp,
                            letterSpacing = (-0.5).sp
                        ),
                        modifier = Modifier.padding(start = 4.dp, bottom = 4.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    CoverflowCarousel(
                        onPlayClick = { item ->
                            onUrlChange(item.url)
                            onAnalyzeClick()
                        },
                        onDownloadClick = { item ->
                            onUrlChange(item.url)
                            onAnalyzeClick()
                        }
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                }
            }

            // 3. Quick Action Row (80x80dp cards, 18dp gap, 24dp radius, lift 4dp when selected)
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(18.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val actions = listOf(
                        Triple("Analyze", Icons.Default.Bolt, onAnalyzeClick),
                        Triple("Playlist", Icons.Default.QueueMusic, { onUrlChange("https://www.youtube.com/playlist?list=PLrEnWoR738-qA8mX_5B9nZ70xQ3qK03k4"); onAnalyzeClick() }),
                        Triple("Audio", Icons.Default.Headphones, onToggleAudioOnly),
                        Triple("History", Icons.Default.History, { onUrlChange(urlHistory.firstOrNull() ?: "") })
                    )

                    actions.forEach { (label, icon, onClick) ->
                        val isSelected = (label == "Audio" && isAudioOnly) || (label == "Analyze" && isAnalyzing)
                        val offsetAnim by animateDpAsState(
                            targetValue = if (isSelected) (-4).dp else 0.dp,
                            animationSpec = spring(dampingRatio = Spring.DampingRatioLowBouncy, stiffness = Spring.StiffnessMedium),
                            label = "ActionOffset_$label"
                        )
                        val selectedBgAlpha by animateFloatAsState(
                            targetValue = if (isSelected) 1f else 0f,
                            animationSpec = tween(durationMillis = 250),
                            label = "ActionBgAlpha_$label"
                        )
                        val borderColor by animateColorAsState(
                            targetValue = if (isSelected) Color(0xFFF59E0B) else Color.White.copy(alpha = 0.1f),
                            animationSpec = tween(durationMillis = 200),
                            label = "ActionBorderColor_$label"
                        )
                        val iconTint by animateColorAsState(
                            targetValue = if (isSelected) Color.White else Color(0xFFB7BBC5),
                            animationSpec = tween(durationMillis = 200),
                            label = "ActionIconTint_$label"
                        )
                        val textTint by animateColorAsState(
                            targetValue = if (isSelected) Color(0xFFF59E0B) else Color(0xFFB7BBC5),
                            animationSpec = tween(durationMillis = 200),
                            label = "ActionTextTint_$label"
                        )

                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Box(
                                modifier = Modifier
                                    .offset(y = offsetAnim)
                                    .size(80.dp)
                                    .clip(RoundedCornerShape(24.dp))
                                    .background(
                                        Brush.linearGradient(
                                            colors = listOf(Color(0x1AFFFFFF), Color(0x0FFFFFFF))
                                        )
                                    )
                                    .background(
                                        brush = Brush.linearGradient(
                                            colors = listOf(Color(0xFF8B1E2D), Color(0xFFD97706))
                                        ),
                                        alpha = selectedBgAlpha
                                    )
                                    .border(
                                        width = 1.dp,
                                        color = borderColor,
                                        shape = RoundedCornerShape(24.dp)
                                    )
                                    .clickable(onClick = onClick),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = icon,
                                    contentDescription = label,
                                    tint = iconTint,
                                    modifier = Modifier.size(30.dp)
                                )
                            }
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = label,
                                style = MaterialTheme.typography.labelMedium.copy(
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = textTint
                                )
                            )
                        }
                    }
                }
            }



            // Removed Recent Downloads Carousel Section as requested
        // 🔍 Keyword Search Progress Indicator
        if (isSearching) {
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "Searching YouTube keywords via JNI...",
                        color = SleekTextSecondary,
                        style = MaterialTheme.typography.bodyMedium.copy(
                            fontWeight = FontWeight.Medium,
                            fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
                        ),
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                }
            }
            items(3) {
                SkeletonSearchResultItem()
            }
        }
        // 🔍 Keyword Search Results Display
        if (!isSearching && searchResults.isNotEmpty()) {
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 4.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "SEARCH RESULTS",
                            style = MaterialTheme.typography.titleSmall.copy(
                                color = SleekPurpleDark,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                letterSpacing = 1.sp
                            )
                        )
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(2.dp),
                            modifier = Modifier.padding(start = 2.dp)
                        ) {
                            Text(
                                text = "video",
                                style = MaterialTheme.typography.labelMedium.copy(
                                    fontWeight = if (searchFilterType == "VIDEO") FontWeight.Bold else FontWeight.Medium,
                                    color = if (searchFilterType == "VIDEO") SleekPurpleLight else SleekTextSecondary
                                ),
                                modifier = Modifier
                                    .clickable(
                                        interactionSource = remember { MutableInteractionSource() },
                                        indication = null
                                    ) {
                                        viewModel?.setSearchFilterType("VIDEO")
                                    }
                                    .padding(horizontal = 4.dp, vertical = 2.dp)
                            )
                            Text(
                                text = "|",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = SleekTextMuted.copy(alpha = 0.5f)
                                )
                            )
                            Text(
                                text = "shorts",
                                style = MaterialTheme.typography.labelMedium.copy(
                                    fontWeight = if (searchFilterType == "SHORTS") FontWeight.Bold else FontWeight.Medium,
                                    color = if (searchFilterType == "SHORTS") SleekPurpleLight else SleekTextSecondary
                                ),
                                modifier = Modifier
                                    .clickable(
                                        interactionSource = remember { MutableInteractionSource() },
                                        indication = null
                                    ) {
                                        viewModel?.setSearchFilterType("SHORTS")
                                    }
                                    .padding(horizontal = 4.dp, vertical = 2.dp)
                            )
                        }
                    }
                    Text(
                        text = "Found ${searchResults.size}",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = SleekTextMuted,
                            fontWeight = FontWeight.SemiBold
                        )
                    )
                }
            }
            if (columns == 1) {
                itemsIndexed(searchResults, key = { index, result -> result.id + "_$index" }) { index, result ->
                    val context = LocalContext.current
                    LaunchedEffect(index, searchResults) {
                        // Debounce: Wait 1500ms. If user scrolls away, this coroutine is cancelled and no work occurs!
                        delay(1500)
                        val nextStart = index + 1
                        val nextEnd = minOf(searchResults.size, index + 3) // Limit to 2 videos max
                        if (nextStart < nextEnd) {
                            val urls = searchResults.subList(nextStart, nextEnd).map { it.originalUrl }
                            YtdlpPipelineManager.prefetchBatch(context, urls)
                        }
                    }
                    SearchResultItemRow(
                        result = result,
                        index = index,
                        onClick = { onSearchResultClick(result) },
                        modifier = Modifier.animateItem()
                    )
                }
            } else {
                val chunks = searchResults.chunked(columns)
                itemsIndexed(chunks, key = { index, _ -> "search_chunk_$index" }) { index, chunk ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(24.dp)
                    ) {
                        chunk.forEachIndexed { chunkIndex, result ->
                            val actualIndex = index * columns + chunkIndex
                            val context = LocalContext.current
                            LaunchedEffect(actualIndex, searchResults) {
                                delay(1500)
                                val nextStart = actualIndex + 1
                                val nextEnd = minOf(searchResults.size, actualIndex + 3)
                                if (nextStart < nextEnd) {
                                    val urls = searchResults.subList(nextStart, nextEnd).map { it.originalUrl }
                                    YtdlpPipelineManager.prefetchBatch(context, urls)
                                }
                            }
                            Box(modifier = Modifier.weight(1f)) {
                                SearchResultItemRow(
                                    result = result,
                                    index = actualIndex,
                                    onClick = { onSearchResultClick(result) },
                                    modifier = Modifier.animateItem()
                                )
                            }
                        }
                        val emptySlots = columns - chunk.size
                        repeat(emptySlots) {
                            Spacer(modifier = Modifier.weight(1f))
                        }
                    }
                }
            }
            if (searchFilterType == "VIDEO") {
                item {
                    val isLoadingMoreVideos by (viewModel?.isLoadingMoreVideos ?: kotlinx.coroutines.flow.MutableStateFlow(false)).collectAsStateWithLifecycle()
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 12.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Surface(
                            onClick = {
                                if (!isLoadingMoreVideos) {
                                    viewModel?.loadMoreVideos()
                                }
                            },
                            shape = RoundedCornerShape(24.dp),
                            color = Color(0xFF1E1F28),
                            border = BorderStroke(1.dp, SleekPurpleLight.copy(alpha = 0.5f)),
                            modifier = Modifier.padding(horizontal = 16.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 24.dp, vertical = 12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                if (isLoadingMoreVideos) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(18.dp),
                                        color = SleekPurpleLight,
                                        strokeWidth = 2.dp
                                    )
                                    Text(
                                        text = "Loading more videos...",
                                        color = SleekPurpleLight,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                } else {
                                    Icon(
                                        imageVector = Icons.Default.ExpandMore,
                                        contentDescription = "Load More Videos",
                                        tint = SleekPurpleLight,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Text(
                                        text = "Load More Videos",
                                        color = Color.White,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            } else if (searchFilterType == "SHORTS") {
                item {
                    val isLoadingMoreShorts by (viewModel?.isLoadingMoreShorts ?: kotlinx.coroutines.flow.MutableStateFlow(false)).collectAsStateWithLifecycle()
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 12.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Surface(
                            onClick = {
                                if (!isLoadingMoreShorts) {
                                    viewModel?.loadMoreShorts()
                                }
                            },
                            shape = RoundedCornerShape(24.dp),
                            color = Color(0xFF1E1F28),
                            border = BorderStroke(1.dp, SleekPurpleLight.copy(alpha = 0.5f)),
                            modifier = Modifier.padding(horizontal = 16.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 24.dp, vertical = 12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                if (isLoadingMoreShorts) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(18.dp),
                                        color = SleekPurpleLight,
                                        strokeWidth = 2.dp
                                    )
                                    Text(
                                        text = "Loading more shorts...",
                                        color = SleekPurpleLight,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                } else {
                                    Icon(
                                        imageVector = Icons.Default.ExpandMore,
                                        contentDescription = "Load More Shorts",
                                        tint = SleekPurpleLight,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Text(
                                        text = "Load More Shorts",
                                        color = Color.White,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
        // Active Diagnostics / Error Info
        if (analysisError != null) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = CrimsonFailure.copy(alpha = 0.15f)),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, CrimsonFailure.copy(alpha = 0.3f))
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Warning, contentDescription = "Error", tint = CrimsonFailure, modifier = Modifier.size(24.dp))
                        Text(
                            text = analysisError,
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = CrimsonFailure,
                                fontWeight = FontWeight.Medium
                            )
                        )
                    }
                }
            }
        }
        // Active Downloads section
        if (activeDownloads.isNotEmpty()) {
            val pausedBatteryCount = activeDownloads.values.count { it.status == DownloadStatus.PAUSED && (it.speedText.contains("Battery", ignoreCase = true) || it.speedText.contains("Charging", ignoreCase = true)) }
            if (pausedBatteryCount > 0) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(AmberAccent.copy(alpha = 0.15f), RoundedCornerShape(12.dp))
                            .border(1.dp, AmberAccent.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                            .padding(horizontal = 14.dp, vertical = 10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                modifier = Modifier.weight(1f),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.BatteryAlert, contentDescription = null, tint = AmberAccent, modifier = Modifier.size(20.dp))
                                Column {
                                    Text(
                                        text = "$pausedBatteryCount Large Download(s) Auto-Paused",
                                        style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                                        color = SleekTextPrimary
                                    )
                                    Text(
                                        text = "Paused to save battery (<20% or not charging). Connect charger or resume manually.",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = SleekTextSecondary
                                    )
                                }
                            }
                            TextButton(
                                onClick = { viewModel?.forceResumeAllDownloads() }
                            ) {
                                Text("Resume All", color = AmberAccent, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
            item {
                Text(
                    text = "ACTIVE DOWNLOADS",
                    style = MaterialTheme.typography.titleSmall.copy(
                        color = AmberAccent,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    ),
                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                )
            }
            val activeTasksList = activeDownloads.values.toList()
            if (columns == 1) {
                items(activeTasksList, key = { it.id }) { task ->
                    ActiveDownloadCard(
                        task = task, 
                        onCancelClick = { onCancelActiveTask(task.id) },
                        onResumeClick = { viewModel?.resumeDownload(task.id) },
                        modifier = Modifier.animateItem()
                    )
                }
            } else {
                val chunks = activeTasksList.chunked(columns)
                itemsIndexed(chunks, key = { index, _ -> "active_chunk_$index" }) { index, chunk ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(24.dp)
                    ) {
                        chunk.forEach { task ->
                            Box(modifier = Modifier.weight(1f)) {
                                ActiveDownloadCard(
                                    task = task, 
                                    onCancelClick = { onCancelActiveTask(task.id) },
                                    onResumeClick = { viewModel?.resumeDownload(task.id) },
                                    modifier = Modifier.animateItem()
                                )
                            }
                        }
                        val emptySlots = columns - chunk.size
                        repeat(emptySlots) {
                            Spacer(modifier = Modifier.weight(1f))
                        }
                    }
                }
            }

            // Live Engine & Download Logs (when logs are present)
            if (executionLogs.isNotEmpty()) {
                item {
                    val context = androidx.compose.ui.platform.LocalContext.current
                    val clipboard = androidx.compose.ui.platform.LocalClipboardManager.current
                    var isExpanded by remember { mutableStateOf(true) }

                    Card(
                        colors = CardDefaults.cardColors(containerColor = SleekCardDark),
                        shape = RoundedCornerShape(16.dp),
                        border = BorderStroke(1.dp, SleekBorderColor),
                        modifier = Modifier.fillMaxWidth().testTag("live_logs_card")
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    modifier = Modifier.clickable { isExpanded = !isExpanded }
                                ) {
                                    Icon(
                                        Icons.Default.Terminal,
                                        contentDescription = "Terminal Logs",
                                        tint = SleekPurpleLight,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Text(
                                        text = "LIVE CONSOLE LOGS (${executionLogs.size})",
                                        style = MaterialTheme.typography.labelMedium.copy(
                                            fontWeight = FontWeight.Bold,
                                            fontFamily = FontFamily.Monospace,
                                            letterSpacing = 1.sp
                                        ),
                                        color = SleekTextPrimary
                                    )
                                    Icon(
                                        if (isExpanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                                        contentDescription = "Toggle logs",
                                        tint = SleekTextMuted,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }

                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    OutlinedButton(
                                        onClick = {
                                            val logText = executionLogs.joinToString("\n")
                                            clipboard.setText(androidx.compose.ui.text.AnnotatedString(logText))
                                            android.widget.Toast.makeText(context, "Copied ${executionLogs.size} log lines", android.widget.Toast.LENGTH_SHORT).show()
                                        },
                                        shape = RoundedCornerShape(10.dp),
                                        border = BorderStroke(1.dp, SleekBorderColor),
                                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                        modifier = Modifier.height(34.dp).testTag("copy_logs_home_btn")
                                    ) {
                                        Icon(
                                            Icons.Default.ContentCopy,
                                            contentDescription = "Copy Logs",
                                            modifier = Modifier.size(14.dp),
                                            tint = SleekTextPrimary
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            "Copy",
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                color = SleekTextPrimary,
                                                fontWeight = FontWeight.SemiBold
                                            )
                                        )
                                    }

                                    IconButton(
                                        onClick = {
                                            onClearLogs()
                                            android.widget.Toast.makeText(context, "Logs cleared", android.widget.Toast.LENGTH_SHORT).show()
                                        },
                                        modifier = Modifier.size(34.dp).testTag("clear_logs_home_btn")
                                    ) {
                                        Icon(
                                            Icons.Default.DeleteSweep,
                                            contentDescription = "Clear Logs",
                                            modifier = Modifier.size(18.dp),
                                            tint = CrimsonFailure.copy(alpha = 0.8f)
                                        )
                                    }
                                }
                            }

                            if (isExpanded) {
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = Color.Black),
                                    shape = RoundedCornerShape(10.dp),
                                    border = BorderStroke(1.dp, Color.White.copy(alpha = 0.08f)),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .heightIn(min = 80.dp, max = 220.dp)
                                ) {
                                    SelectionContainer {
                                        LazyColumn(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(10.dp),
                                            verticalArrangement = Arrangement.spacedBy(3.dp)
                                        ) {
                                            items(executionLogs) { logLine ->
                                                val logColor = when {
                                                    logLine.contains("ERROR", ignoreCase = true) || logLine.contains("FAIL", ignoreCase = true) || logLine.contains("Exception", ignoreCase = true) -> CrimsonFailure
                                                    logLine.contains("WARN", ignoreCase = true) || logLine.contains("⚠️") -> AmberAccent
                                                    logLine.contains("SUCCESS", ignoreCase = true) || logLine.contains("COMPLETED", ignoreCase = true) || logLine.contains("100%") -> EmeraldSuccess
                                                    logLine.startsWith("[download]") -> SleekPurpleLight
                                                    else -> SleekTextSecondary
                                                }
                                                Text(
                                                    text = logLine,
                                                    color = logColor,
                                                    fontFamily = FontFamily.Monospace,
                                                    fontSize = 11.sp,
                                                    lineHeight = 14.sp
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showDownloadSheet && analyzedVideo != null) {
        var formatSearchQuery by remember { mutableStateOf("") }
        var formatSortBy by remember { mutableStateOf("Default") } // "Default", "Size (Desc)", "Size (Asc)", "Quality"
        var formatExtensionFilter by remember { mutableStateOf("All") } // "All", "MP4", "WebM", "MKV", "MP3", "M4A"

        ModalBottomSheet(
            onDismissRequest = { showDownloadSheet = false },
            sheetState = sheetState,
            containerColor = SleekCardDark,
            dragHandle = { BottomSheetDefaults.DragHandle(color = SleekTextSecondary) }
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
                    .padding(bottom = 32.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "DOWNLOAD OPTIONS",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = SleekPurpleDark,
                                letterSpacing = 1.sp
                            )
                        )
                        Text(
                            text = if (showAdvancedFormats) "Showing all raw formats" else "Showing optimized options",
                            style = MaterialTheme.typography.bodySmall.copy(color = SleekTextSecondary)
                        )
                    }
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "Show All",
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = if (showAdvancedFormats) SleekPurpleLight else SleekTextMuted
                            )
                        )
                        SmoothToggle(
                            checked = showAdvancedFormats,
                            onCheckedChange = { onToggleShowAdvancedFormats(it) }
                        )
                    }
                }
                val (videoFormats, audioFormats) = remember(analyzedVideo.formats, showAdvancedFormats, formatSearchQuery, formatSortBy, formatExtensionFilter) {
                    try {
                        fun isAudioFormat(fmt: VideoFormatUi): Boolean {
                            val type = fmt.type.lowercase()
                            val qual = fmt.quality.lowercase()
                            val ext = fmt.ext.lowercase()
                            return type == "audio" || 
                                   (fmt.vcodec == "none" && fmt.acodec != null && fmt.acodec != "none") ||
                                   qual.contains("kbps") || qual.contains("audio") ||
                                   ext == "mp3" || ext == "m4a" || ext == "aac" || ext == "opus" || ext == "wav" || ext == "flac" || ext == "ogg"
                        }

                        val rawVideos = analyzedVideo.formats.filter { 
                            !isAudioFormat(it) && 
                            !it.ext.equals("mhtml", ignoreCase = true) && 
                            it.formatId != 9999 && 
                            it.formatId != 9911 
                        }
                        val rawAudios = analyzedVideo.formats.filter { isAudioFormat(it) }

                        val bestAudioSource = rawAudios.maxByOrNull { it.sizeBytes } 
                            ?: rawVideos.maxByOrNull { it.sizeBytes } 
                            ?: analyzedVideo.formats.maxByOrNull { it.sizeBytes }

                        val (baseVideos, baseAudios) = if (showAdvancedFormats) {
                            val vList = if (rawVideos.isNotEmpty()) rawVideos else analyzedVideo.formats

                            val presets = if (bestAudioSource != null) {
                                listOf(
                                    "MP3" to "mp3",
                                    "M4A" to "m4a",
                                    "AAC" to "aac",
                                    "WAV" to "wav",
                                    "FLAC" to "flac",
                                    "OPUS" to "opus",
                                    "OGG" to "ogg"
                                ).map { (label, ext) ->
                                    bestAudioSource.copy(quality = label, ext = ext, type = "audio")
                                }
                            } else emptyList()

                            val aList = (rawAudios + presets).distinctBy { "${it.quality}_${it.ext}_${it.formatId}" }
                            Pair(vList, aList)
                        } else {
                            val groupedByHeight = rawVideos.mapNotNull { fmt ->
                                val h = fmt.height ?: run {
                                    val matcher = java.util.regex.Pattern.compile("""(\d+)p""", java.util.regex.Pattern.CASE_INSENSITIVE).matcher(fmt.quality)
                                    if (matcher.find()) matcher.group(1).toIntOrNull() else null
                                }
                                if (h != null) Pair(h, fmt) else null
                            }.groupBy({ it.first }, { it.second })

                            val cleanVideoFormats = if (groupedByHeight.isNotEmpty()) {
                                val bestVideos = groupedByHeight.values.mapNotNull { formatsAtRes ->
                                    formatsAtRes.maxByOrNull { fmt ->
                                        val extIsMp4 = fmt.ext.equals("mp4", ignoreCase = true)
                                        val extIsWebm = fmt.ext.equals("webm", ignoreCase = true)
                                        val hasAudio = fmt.type == "combined" || fmt.hasAudio
                                        val baseScore = when {
                                            extIsMp4 && hasAudio -> 4000L
                                            extIsMp4 && !hasAudio -> 3000L
                                            extIsWebm && hasAudio -> 2000L
                                            extIsWebm && !hasAudio -> 1000L
                                            else -> 500L
                                        }
                                        val detailScore = ((fmt.tbr ?: 0.0).toLong() * 10L) + (fmt.sizeBytes / 100000L)
                                        baseScore * 100000000L + detailScore
                                    }
                                }
                                bestVideos.sortedByDescending { fmt ->
                                    val h = fmt.height
                                    if (h != null) {
                                        h
                                    } else {
                                        val matcher = java.util.regex.Pattern.compile("""(\d+)p""", java.util.regex.Pattern.CASE_INSENSITIVE).matcher(fmt.quality)
                                        if (matcher.find()) matcher.group(1).toIntOrNull() ?: 0 else 0
                                    }
                                }.map { fmt ->
                                    val h = if (fmt.height != null) fmt.height else {
                                        val matcher = java.util.regex.Pattern.compile("""(\d+)p""", java.util.regex.Pattern.CASE_INSENSITIVE).matcher(fmt.quality)
                                        if (matcher.find()) matcher.group(1).toIntOrNull() ?: 360 else 360
                                    }
                                    fmt.copy(quality = "${h}p")
                                }
                            } else {
                                rawVideos.map { fmt ->
                                    val h = fmt.height ?: 360
                                    fmt.copy(quality = if (fmt.quality.contains("p")) fmt.quality else "${h}p")
                                }
                            }

                            val cleanAudioFormats = mutableListOf<VideoFormatUi>()
                            if (bestAudioSource != null) {
                                cleanAudioFormats.add(bestAudioSource.copy(quality = "MP3", ext = "mp3", type = "audio"))
                                cleanAudioFormats.add(bestAudioSource.copy(quality = "M4A", ext = "m4a", type = "audio"))
                                val topRaw = rawAudios.maxByOrNull { it.sizeBytes }
                                if (topRaw != null) {
                                    cleanAudioFormats.add(topRaw)
                                }
                            }

                            val finalCleanAudios = cleanAudioFormats.distinctBy { "${it.quality}_${it.ext}" }

                            Pair(cleanVideoFormats, finalCleanAudios)
                        }

                        // Apply Search Query Filter
                        var filteredV = baseVideos
                        var filteredA = baseAudios

                        if (formatSearchQuery.isNotBlank()) {
                            filteredV = filteredV.filter { 
                                it.quality.contains(formatSearchQuery, ignoreCase = true) || 
                                it.ext.contains(formatSearchQuery, ignoreCase = true) ||
                                it.sizeText.contains(formatSearchQuery, ignoreCase = true)
                            }
                            filteredA = filteredA.filter { 
                                it.quality.contains(formatSearchQuery, ignoreCase = true) || 
                                it.ext.contains(formatSearchQuery, ignoreCase = true) ||
                                it.sizeText.contains(formatSearchQuery, ignoreCase = true)
                            }
                        }

                        // Apply Extension Filter
                        if (formatExtensionFilter != "All") {
                            filteredV = filteredV.filter { it.ext.equals(formatExtensionFilter, ignoreCase = true) }
                            filteredA = filteredA.filter { it.ext.equals(formatExtensionFilter, ignoreCase = true) }
                        }

                        // Apply Sorting Options
                        when (formatSortBy) {
                            "Size (Desc)" -> {
                                filteredV = filteredV.sortedByDescending { it.sizeBytes }
                                filteredA = filteredA.sortedByDescending { it.sizeBytes }
                            }
                            "Size (Asc)" -> {
                                filteredV = filteredV.sortedBy { it.sizeBytes }
                                filteredA = filteredA.sortedBy { it.sizeBytes }
                            }
                            "Quality" -> {
                                filteredV = filteredV.sortedByDescending { it.height ?: 0 }
                                filteredA = filteredA.sortedByDescending { it.audioBitrateKbps ?: it.bitrateKbps ?: 0 }
                            }
                            else -> {
                                // Keep default ordering (quality-desc for video)
                            }
                        }

                        Pair(filteredV, filteredA)
                    } catch (e: Throwable) {
                        Pair(analyzedVideo.formats, emptyList<VideoFormatUi>())
                    }
                }
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 12.dp)
                                .clip(RoundedCornerShape(16.dp))
                                .background(Color.White.copy(alpha = 0.05f))
                                .border(1.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(16.dp))
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(width = 110.dp, height = 62.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(Color.Black)
                            ) {
                                if (!analyzedVideo.thumbnailUrl.isNullOrEmpty()) {
                                    AsyncImage(
                                        model = analyzedVideo.thumbnailUrl,
                                        contentDescription = "Content Thumbnail",
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier.fillMaxSize()
                                    )
                                } else {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .background(
                                                Brush.linearGradient(
                                                    colors = listOf(SleekPurpleLight, SleekPurpleDark)
                                                )
                                            ),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.VideoLibrary,
                                            contentDescription = null,
                                            tint = Color.White,
                                            modifier = Modifier.size(28.dp)
                                        )
                                    }
                                }

                                if (analyzedVideo.durationText.isNotBlank()) {
                                    Box(
                                        modifier = Modifier
                                            .align(Alignment.BottomEnd)
                                            .padding(4.dp)
                                            .background(Color.Black.copy(alpha = 0.8f), shape = RoundedCornerShape(4.dp))
                                            .padding(horizontal = 4.dp, vertical = 1.dp)
                                    ) {
                                        Text(
                                            text = analyzedVideo.durationText,
                                            color = Color.White,
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                fontSize = 8.sp,
                                                fontWeight = FontWeight.Bold,
                                                fontFamily = FontFamily.Monospace
                                            )
                                        )
                                    }
                                }
                            }

                            Column(
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(
                                    text = analyzedVideo.title,
                                    color = SleekTextPrimary,
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        lineHeight = 16.sp
                                    ),
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Person,
                                        contentDescription = null,
                                        tint = SleekPurpleLight,
                                        modifier = Modifier.size(11.dp)
                                    )
                                    Text(
                                        text = analyzedVideo.author.ifBlank { "Unknown Creator" },
                                        color = SleekTextSecondary,
                                        style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }
                    }

                    item {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            // Search field
                            OutlinedTextField(
                                value = formatSearchQuery,
                                onValueChange = { formatSearchQuery = it },
                                placeholder = { 
                                    Text(
                                        "Filter resolution or extension...", 
                                        color = SleekTextMuted,
                                        fontSize = 13.sp
                                    ) 
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(50.dp)
                                    .testTag("format_search_input"),
                                singleLine = true,
                                shape = RoundedCornerShape(12.dp),
                                textStyle = MaterialTheme.typography.bodyMedium.copy(color = Color.White),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White,
                                    focusedBorderColor = SleekPurpleLight,
                                    unfocusedBorderColor = Color.White.copy(alpha = 0.15f),
                                    focusedContainerColor = Color.Black.copy(alpha = 0.3f),
                                    unfocusedContainerColor = Color.Black.copy(alpha = 0.15f)
                                ),
                                leadingIcon = {
                                    Icon(
                                        imageVector = Icons.Default.Search, 
                                        contentDescription = null, 
                                        tint = SleekTextSecondary, 
                                        modifier = Modifier.size(18.dp)
                                    )
                                },
                                trailingIcon = if (formatSearchQuery.isNotEmpty()) {
                                    {
                                        IconButton(onClick = { formatSearchQuery = "" }) {
                                            Icon(
                                                imageVector = Icons.Default.Close, 
                                                contentDescription = "Clear", 
                                                tint = SleekTextSecondary, 
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }
                                    }
                                } else null
                            )

                            // Quick control chips row for sorting
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                // Sort Options Label
                                Row(
                                    modifier = Modifier
                                        .background(Color.White.copy(alpha = 0.04f), RoundedCornerShape(8.dp))
                                        .border(0.5.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(8.dp))
                                        .padding(horizontal = 8.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Sort,
                                        contentDescription = null,
                                        tint = SleekPurpleLight,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Text(
                                        text = "Sort:",
                                        color = SleekTextMuted,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Medium
                                    )
                                }

                                listOf("Default", "Size (Desc)", "Size (Asc)", "Quality").forEach { option ->
                                    SleekFilterChip(
                                        selected = formatSortBy == option,
                                        onClick = { formatSortBy = option },
                                        label = option
                                    )
                                }
                            }

                            // Quick control chips row for extension filtering
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                // Extension Filter Label
                                Row(
                                    modifier = Modifier
                                        .background(Color.White.copy(alpha = 0.04f), RoundedCornerShape(8.dp))
                                        .border(0.5.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(8.dp))
                                        .padding(horizontal = 8.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.FilterList,
                                        contentDescription = null,
                                        tint = SleekPurpleLight,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Text(
                                        text = "Ext:",
                                        color = SleekTextMuted,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Medium
                                    )
                                }

                                listOf("All", "MP4", "WebM", "MKV", "MP3", "M4A").forEach { ext ->
                                    SleekFilterChip(
                                        selected = formatExtensionFilter == ext,
                                        onClick = { formatExtensionFilter = ext },
                                        label = ext
                                    )
                                }
                            }

                            // Subtitle & Audio Feature Quick Controls
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    modifier = Modifier
                                        .background(Color.White.copy(alpha = 0.04f), RoundedCornerShape(8.dp))
                                        .border(0.5.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(8.dp))
                                        .padding(horizontal = 8.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.ClosedCaption,
                                        contentDescription = null,
                                        tint = SleekPurpleLight,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Text(
                                        text = "Features:",
                                        color = SleekTextMuted,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Medium
                                    )
                                }

                                SleekFilterChip(
                                    selected = embedSubtitles,
                                    onClick = { viewModel?.updateEmbedSubtitles(!embedSubtitles) },
                                    label = if (embedSubtitles) "Subtitles: ON" else "Subtitles: OFF"
                                )

                                SleekFilterChip(
                                    selected = embedAutoSubtitles,
                                    onClick = { viewModel?.updateEmbedAutoSubtitles(!embedAutoSubtitles) },
                                    label = if (embedAutoSubtitles) "Auto-Subs: ON" else "Auto-Subs: OFF"
                                )

                                SleekFilterChip(
                                    selected = embedAudioMetadata,
                                    onClick = { viewModel?.updateEmbedAudioMetadata(!embedAudioMetadata) },
                                    label = if (embedAudioMetadata) "Cover & Tags: ON" else "Cover & Tags: OFF"
                                )

                                SleekFilterChip(
                                    selected = audioMultistreams,
                                    onClick = { viewModel?.updateAudioMultistreams(!audioMultistreams) },
                                    label = if (audioMultistreams) "Multi-Audio: ON" else "Multi-Audio: OFF"
                                )
                            }
                        }
                    }

                    if (videoFormats.isNotEmpty()) {
                        item(key = "header_video_formats") {
                            Text(
                                text = "VIDEO",
                                style = MaterialTheme.typography.labelSmall.copy(color = SleekTextSecondary),
                                modifier = Modifier.padding(bottom = 4.dp)
                            )
                        }
                        items(
                            items = videoFormats,
                            key = { format -> "v_${format.formatId}_${format.quality}_${format.ext}_${format.sizeBytes}_${format.downloadUrl.hashCode()}" }
                        ) { format ->
                            FormatRowItem(
                                format = format, 
                                showAdvanced = showAdvancedFormats,
                                onDownloadClick = {
                                    onDownloadFormat(format)
                                    showDownloadSheet = false
                                },
                                onStreamClick = {
                                    onStreamFormat(format)
                                    showDownloadSheet = false
                                },
                                onScheduleClick = if (onScheduleFormat != null) {
                                    {
                                        onScheduleFormat(format)
                                        showDownloadSheet = false
                                    }
                                } else null
                            )
                        }
                    }
                    if (audioFormats.isNotEmpty()) {
                        item(key = "header_audio_formats") {
                            Spacer(Modifier.height(8.dp))
                            Text(
                                text = "AUDIO",
                                style = MaterialTheme.typography.labelSmall.copy(color = SleekTextSecondary),
                                modifier = Modifier.padding(bottom = 4.dp)
                            )
                        }
                        items(
                            items = audioFormats,
                            key = { format -> "a_${format.formatId}_${format.quality}_${format.ext}_${format.sizeBytes}_${format.downloadUrl.hashCode()}" }
                        ) { format ->
                            FormatRowItem(
                                format = format, 
                                showAdvanced = showAdvancedFormats,
                                onDownloadClick = {
                                    onDownloadFormat(format)
                                    showDownloadSheet = false
                                },
                                onStreamClick = {
                                    onStreamFormat(format)
                                    showDownloadSheet = false
                                },
                                onScheduleClick = if (onScheduleFormat != null) {
                                    {
                                        onScheduleFormat(format)
                                        showDownloadSheet = false
                                    }
                                } else null
                            )
                        }
                    }
                }
            }
        }
    }
}
}

@Composable
fun ActiveDownloadCard(
    task: ActiveDownloadTask,
    onCancelClick: () -> Unit,
    onResumeClick: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val slideInOffset = remember { Animatable(60f) }
    val opacity = remember { Animatable(0f) }

    LaunchedEffect(key1 = task.id) {
        launch {
            slideInOffset.animateTo(
                targetValue = 0f,
                animationSpec = spring(
                    dampingRatio = Spring.DampingRatioLowBouncy,
                    stiffness = Spring.StiffnessMediumLow
                )
            )
        }
        launch {
            opacity.animateTo(
                targetValue = 1f,
                animationSpec = tween(durationMillis = 300, easing = LinearOutSlowInEasing)
            )
        }
    }

    val infiniteTransition = androidx.compose.animation.core.rememberInfiniteTransition()
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.5f,
        targetValue = 1f,
        animationSpec = androidx.compose.animation.core.infiniteRepeatable(
            animation = androidx.compose.animation.core.tween(1000, easing = androidx.compose.animation.core.FastOutSlowInEasing),
            repeatMode = androidx.compose.animation.core.RepeatMode.Reverse
        ), label = "PulseAlpha"
    )
    val borderColor = when (task.status) {
        DownloadStatus.FAILED, DownloadStatus.CORRUPTED -> CrimsonFailure.copy(alpha = 0.6f)
        DownloadStatus.DOWNLOADING -> SleekPurpleLight.copy(alpha = pulseAlpha)
        DownloadStatus.COMPLETED -> EmeraldSuccess.copy(alpha = 0.8f)
        DownloadStatus.PENDING, DownloadStatus.QUEUED -> SleekTextSecondary.copy(alpha = 0.5f)
        DownloadStatus.PAUSED, DownloadStatus.INCOMPLETE -> AmberAccent.copy(alpha = 0.6f)
        DownloadStatus.RECOVERABLE -> Color(0xFF00E5FF).copy(alpha = 0.7f)
    }
    Card(
        modifier = modifier
            .fillMaxWidth()
            .graphicsLayer {
                translationY = slideInOffset.value
                alpha = opacity.value
            }
            .animateContentSize(
                animationSpec = spring(
                    dampingRatio = Spring.DampingRatioMediumBouncy,
                    stiffness = Spring.StiffnessLow
                )
            ),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        shape = RoundedCornerShape(18.dp),
        border = BorderStroke(1.dp, borderColor)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    brush = Brush.linearGradient(
                        colors = listOf(
                            Color.White.copy(alpha = 0.12f),
                            Color.White.copy(alpha = 0.03f)
                        )
                    )
                )
                .padding(14.dp)
        ) {
            Column(
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        modifier = Modifier.weight(1f),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Icon badge
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .background(
                                    when (task.status) {
                                        DownloadStatus.FAILED -> CrimsonFailure.copy(alpha = 0.18f)
                                        DownloadStatus.COMPLETED -> EmeraldSuccess.copy(alpha = 0.18f)
                                        DownloadStatus.PAUSED -> AmberAccent.copy(alpha = 0.2f)
                                        else -> SleekPurpleDark.copy(alpha = 0.25f)
                                    },
                                    CircleShape
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = when (task.status) {
                                    DownloadStatus.FAILED -> Icons.Default.Warning
                                    DownloadStatus.COMPLETED -> Icons.Default.Check
                                    DownloadStatus.PAUSED -> if (task.speedText.contains("Battery", ignoreCase = true) || task.speedText.contains("Charging", ignoreCase = true)) Icons.Default.BatteryAlert else Icons.Default.Pause
                                    else -> Icons.Default.Download
                                },
                                contentDescription = null,
                                tint = when (task.status) {
                                    DownloadStatus.FAILED -> CrimsonFailure
                                    DownloadStatus.COMPLETED -> EmeraldSuccess
                                    DownloadStatus.PAUSED -> AmberAccent
                                    else -> SleekPurpleLight
                                },
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = task.title,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                color = SleekTextPrimary,
                                style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold)
                            )
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .background(
                                            if (task.status == DownloadStatus.PAUSED) AmberAccent.copy(alpha = 0.25f) else SleekPurpleLight.copy(alpha = 0.25f),
                                            RoundedCornerShape(4.dp)
                                        )
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                    Text(
                                        text = task.ext.uppercase(),
                                        color = if (task.status == DownloadStatus.PAUSED) AmberAccent else SleekTextPrimary,
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontWeight = FontWeight.Bold,
                                            fontFamily = FontFamily.Monospace,
                                            fontSize = 9.sp
                                        )
                                    )
                                }
                                Text(
                                    text = task.speedText,
                                    color = if (task.status == DownloadStatus.PAUSED) AmberAccent else SleekTextSecondary,
                                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (task.status == DownloadStatus.PAUSED && onResumeClick != null) {
                            IconButton(
                                onClick = onResumeClick,
                                modifier = Modifier
                                    .size(32.dp)
                                    .background(EmeraldSuccess.copy(alpha = 0.18f), CircleShape)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.PlayArrow,
                                    contentDescription = "Resume Download",
                                    tint = EmeraldSuccess,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                        IconButton(
                            onClick = onCancelClick,
                            modifier = Modifier
                                .size(32.dp)
                                .background(Color.White.copy(alpha = 0.08f), CircleShape)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Cancel",
                                tint = if (task.status == DownloadStatus.FAILED) CrimsonFailure else SleekTextSecondary,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
                if (task.status == DownloadStatus.FAILED) {
                    Text(
                        text = task.error ?: "Download terminated unexpectedly.",
                        color = CrimsonFailure,
                        style = MaterialTheme.typography.bodySmall,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                } else {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        val progressPercent = (task.progress * 100).toInt()
                        LinearProgressIndicator(
                            progress = { task.progress },
                            modifier = Modifier
                                .weight(1f)
                                .height(6.dp)
                                .clip(RoundedCornerShape(3.dp)),
                            color = if (task.status == DownloadStatus.COMPLETED) EmeraldSuccess else SleekPurpleLight,
                            trackColor = Color.White.copy(alpha = 0.1f)
                        )
                        Text(
                            text = "$progressPercent%",
                            style = MaterialTheme.typography.titleSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = SleekPurpleLight,
                                fontFamily = FontFamily.Monospace
                            )
                        )
                    }
                }
            }
        }
    }
}
@Composable
fun shimmerBrush(
    targetValue: Float = 1200f
): Brush {
    val shimmerColors = listOf(
        Color(0xFF231C30),
        Color(0xFF3C2F52),
        Color(0xFF5A4678),
        Color(0xFF3C2F52),
        Color(0xFF231C30)
    )
    val transition = rememberInfiniteTransition(label = "shimmer_transition")
    val translateAnimation = transition.animateFloat(
        initialValue = 0f,
        targetValue = targetValue,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "shimmer_translate"
    )
    return Brush.linearGradient(
        colors = shimmerColors,
        start = Offset(translateAnimation.value - 400f, translateAnimation.value - 400f),
        end = Offset(translateAnimation.value, translateAnimation.value)
    )
}

@Composable
fun SkeletonVideoListItem(
    modifier: Modifier = Modifier
) {
    val brush = shimmerBrush()
    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp)
            .testTag("video_list_item_skeleton"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = SleekCardDark)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Box(
                modifier = Modifier
                    .width(110.dp)
                    .height(68.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(brush)
            )
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth(0.9f)
                        .height(16.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(brush)
                )
                Box(
                    modifier = Modifier
                        .fillMaxWidth(0.6f)
                        .height(12.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(brush)
                )
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .width(50.dp)
                            .height(10.dp)
                            .clip(RoundedCornerShape(3.dp))
                            .background(brush)
                    )
                    Box(
                        modifier = Modifier
                            .width(40.dp)
                            .height(10.dp)
                            .clip(RoundedCornerShape(3.dp))
                            .background(brush)
                    )
                }
            }
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .clip(CircleShape)
                    .background(brush)
            )
        }
    }
}

@Composable
fun SkeletonVideoPlayerOverlay(
    modifier: Modifier = Modifier
) {
    val brush = shimmerBrush()
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF0D0B12)),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(20.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(brush)
                )
                Box(
                    modifier = Modifier
                        .width(180.dp)
                        .height(18.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(brush)
                )
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(brush)
                )
            }

            Box(
                modifier = Modifier
                    .size(64.dp)
                    .align(Alignment.CenterHorizontally)
                    .clip(CircleShape)
                    .background(brush)
            )

            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(3.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    repeat(24) { i ->
                        val barHeight = (12 + (i * 7) % 20).dp
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(barHeight)
                                .clip(RoundedCornerShape(2.dp))
                                .background(brush)
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .width(60.dp)
                            .height(12.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(brush)
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                        repeat(3) {
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(CircleShape)
                                    .background(brush)
                            )
                        }
                    }
                    Box(
                        modifier = Modifier
                            .width(60.dp)
                            .height(12.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(brush)
                    )
                }
            }
        }
    }
}

@Composable
fun SkeletonAudioPlayerOverlay(
    isFullscreen: Boolean = false,
    modifier: Modifier = Modifier
) {
    val brush = shimmerBrush()
    if (!isFullscreen) {
        Row(
            modifier = modifier
                .fillMaxSize()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(52.dp)
                    .clip(CircleShape)
                    .background(brush)
            )
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth(0.85f)
                        .height(14.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(brush)
                )
                Box(
                    modifier = Modifier
                        .fillMaxWidth(0.5f)
                        .height(10.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(brush)
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(modifier = Modifier.size(28.dp).clip(CircleShape).background(brush))
                Box(modifier = Modifier.size(28.dp).clip(CircleShape).background(brush))
            }
        }
    } else {
        Column(
            modifier = modifier
                .fillMaxSize()
                .background(Color(0xFF0D0B12))
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(modifier = Modifier.size(36.dp).clip(CircleShape).background(brush))
                Box(modifier = Modifier.width(120.dp).height(16.dp).clip(RoundedCornerShape(4.dp)).background(brush))
                Box(modifier = Modifier.size(36.dp).clip(CircleShape).background(brush))
            }

            Box(
                modifier = Modifier
                    .size(200.dp)
                    .clip(CircleShape)
                    .background(brush)
            )

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(modifier = Modifier.width(200.dp).height(18.dp).clip(RoundedCornerShape(4.dp)).background(brush))
                Box(modifier = Modifier.width(120.dp).height(14.dp).clip(RoundedCornerShape(4.dp)).background(brush))
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(3.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                repeat(20) { i ->
                    val barHeight = (10 + (i * 9) % 24).dp
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(barHeight)
                            .clip(RoundedCornerShape(2.dp))
                            .background(brush)
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                repeat(5) {
                    Box(modifier = Modifier.size(44.dp).clip(CircleShape).background(brush))
                }
            }
        }
    }
}

@Composable
fun SkeletonAnalyzedVideoCard() {
    val brush = shimmerBrush()
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(130.dp)
            .testTag("analyzed_video_card_skeleton"),
        colors = CardDefaults.cardColors(containerColor = SleekPurpleContainer.copy(alpha = 0.5f)),
        shape = RoundedCornerShape(20.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxSize().padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxHeight()
                    .aspectRatio(16f/9f)
                    .clip(RoundedCornerShape(12.dp))
                    .background(brush)
            )
            Column(
                modifier = Modifier.weight(1f).fillMaxHeight(),
                verticalArrangement = Arrangement.Center
            ) {
                Box(modifier = Modifier.fillMaxWidth().height(18.dp).clip(RoundedCornerShape(4.dp)).background(brush))
                Spacer(modifier = Modifier.height(8.dp))
                Box(modifier = Modifier.fillMaxWidth(0.7f).height(18.dp).clip(RoundedCornerShape(4.dp)).background(brush))
                Spacer(modifier = Modifier.height(16.dp))
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Box(modifier = Modifier.size(16.dp).clip(CircleShape).background(brush))
                    Box(modifier = Modifier.width(80.dp).height(12.dp).clip(RoundedCornerShape(4.dp)).background(brush))
                }
            }
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .background(brush)
            )
        }
    }
}
@Composable
fun AnalyzedVideoCard(
    video: AnalyzedVideo,
    onOpenDownloadOptions: () -> Unit,
    onStreamBestClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(130.dp)
            .animateContentSize(animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow))
            .testTag("analyzed_video_card"),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        shape = RoundedCornerShape(20.dp),
        border = BorderStroke(1.dp, SleekPurpleLight.copy(alpha = 0.35f))
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    brush = Brush.linearGradient(
                        colors = listOf(
                            SleekPurpleContainer.copy(alpha = 0.5f),
                            Color.White.copy(alpha = 0.04f)
                        )
                    )
                )
        ) {
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Thumbnail
                Box(
                    modifier = Modifier
                        .fillMaxHeight()
                        .aspectRatio(16f / 9f)
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color.Black)
                        .clickable { onStreamBestClick() }
                ) {
                    AsyncImage(
                        model = video.thumbnailUrl,
                        contentDescription = "Video Thumbnail",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop,
                        alpha = 0.92f
                    )
                    // Play Overlay
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color.Black.copy(alpha = 0.25f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .background(
                                    brush = Brush.linearGradient(
                                        colors = listOf(SleekPurpleLight, SleekPurpleDark)
                                    ),
                                    shape = CircleShape
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.PlayArrow,
                                contentDescription = "Stream Best",
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                    // Duration Badge
                    if (video.durationText.isNotBlank()) {
                        Box(
                            modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .padding(6.dp)
                                .background(Color.Black.copy(alpha = 0.8f), shape = RoundedCornerShape(6.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = video.durationText,
                                color = Color.White,
                                style = MaterialTheme.typography.bodySmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 9.sp
                                )
                            )
                        }
                    }
                }
                // Details
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight(),
                    verticalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = video.title,
                        color = SleekTextPrimary,
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontWeight = FontWeight.Bold,
                            lineHeight = 18.sp
                        ),
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = "Channel",
                            tint = SleekPurpleLight,
                            modifier = Modifier.size(13.dp)
                        )
                        Text(
                            text = video.author,
                            color = SleekTextSecondary,
                            style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
                // Quick Actions column
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = onStreamBestClick,
                        modifier = Modifier
                            .size(42.dp)
                            .background(
                                color = SleekPurpleLight.copy(alpha = 0.25f),
                                shape = CircleShape
                            )
                            .border(1.dp, SleekPurpleLight.copy(alpha = 0.5f), CircleShape)
                    ) {
                        Icon(
                            imageVector = Icons.Default.PlayArrow,
                            contentDescription = "Stream Direct",
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    IconButton(
                        onClick = onOpenDownloadOptions,
                        modifier = Modifier
                            .size(42.dp)
                            .background(
                                color = Color.White,
                                shape = CircleShape
                            )
                    ) {
                        Icon(
                            imageVector = Icons.Default.Download,
                            contentDescription = "Download Options",
                            tint = Color.Black,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }
    }
}
@Composable
fun FormatRowItem(
    format: VideoFormatUi,
    onDownloadClick: () -> Unit,
    onStreamClick: () -> Unit,
    onScheduleClick: (() -> Unit)? = null,
    modifier: Modifier = Modifier,
    showAdvanced: Boolean = false
) {
    var expanded by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(
                brush = Brush.linearGradient(
                    colors = listOf(Color.White.copy(alpha = 0.1f), Color.White.copy(alpha = 0.02f))
                )
            )
            .border(1.dp, Color.White.copy(alpha = 0.2f), shape = RoundedCornerShape(16.dp))
            .clickable { expanded = !expanded }
            .padding(horizontal = 16.dp, vertical = 12.dp)
            .animateContentSize()
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .background(SleekPurpleContainer, shape = RoundedCornerShape(10.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (format.quality == "MP3" || format.type == "audio") Icons.Default.MusicNote else Icons.Default.PlayArrow,
                        contentDescription = null,
                        tint = SleekPurpleDark,
                        modifier = Modifier.size(18.dp)
                    )
                }
                Column {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = format.quality,
                            color = SleekTextPrimary,
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Box(
                            modifier = Modifier
                                .background(SleekPurpleLight.copy(alpha = 0.3f), shape = RoundedCornerShape(6.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = format.ext.uppercase(),
                                color = SleekTextPrimary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                        if (format.type == "video_only" && showAdvanced) {
                            Box(
                                modifier = Modifier
                                    .background(SleekPurpleLight, shape = RoundedCornerShape(6.dp))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = "⚡ MERGING",
                                    color = SleekTextPrimary,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = format.sizeText,
                            color = SleekTextSecondary,
                            style = MaterialTheme.typography.bodySmall
                        )
                        Icon(
                            imageVector = if (expanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                            contentDescription = "Show Details",
                            tint = SleekTextMuted,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (format.quality != "MP3") {
                    IconButton(
                        onClick = onStreamClick,
                        modifier = Modifier
                            .size(36.dp)
                            .background(Color.White.copy(alpha = 0.12f), CircleShape)
                            .border(1.dp, Color.White.copy(alpha = 0.25f), CircleShape)
                    ) {
                        Icon(
                            imageVector = Icons.Default.PlayArrow,
                            contentDescription = "Stream Direct",
                            tint = SleekTextPrimary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
                IconButton(
                    onClick = onDownloadClick,
                    modifier = Modifier
                        .size(36.dp)
                        .background(Color.White, CircleShape)
                ) {
                    Icon(
                        imageVector = Icons.Default.Download,
                        contentDescription = "Download",
                        tint = Color.Black,
                        modifier = Modifier.size(18.dp)
                    )
                }
                if (onScheduleClick != null) {
                    IconButton(
                        onClick = onScheduleClick,
                        modifier = Modifier
                            .size(36.dp)
                            .background(Color.White.copy(alpha = 0.12f), CircleShape)
                            .border(1.dp, Color.White.copy(alpha = 0.25f), CircleShape)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Schedule,
                            contentDescription = "Schedule Download",
                            tint = AmberAccent,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }

        AnimatedVisibility(
            visible = expanded,
            enter = expandVertically() + fadeIn(),
            exit = shrinkVertically() + fadeOut()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                HorizontalDivider(
                    color = Color.White.copy(alpha = 0.08f),
                    thickness = 1.dp
                )
                
                // Technical specifications scrollable row
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (format.fps != null && format.fps > 0) {
                        SpecBadge(label = "FPS", value = "${format.fps}")
                    }
                    if (format.isHdr) {
                        SpecBadge(label = "HDR", value = "Yes", containerColor = Color(0xFFFF4D5A).copy(alpha = 0.15f), contentColor = Color(0xFFFF4D5A))
                    }
                    if (format.bitrateKbps != null && format.bitrateKbps > 0) {
                        SpecBadge(label = "Video Bitrate", value = "${format.bitrateKbps} kbps")
                    }
                    if (format.audioBitrateKbps != null && format.audioBitrateKbps > 0) {
                        SpecBadge(label = "Audio Bitrate", value = "${format.audioBitrateKbps} kbps")
                    }
                    if (format.vcodec.isNotBlank() && format.vcodec != "none") {
                        SpecBadge(label = "Video Codec", value = format.vcodec)
                    }
                    if (format.acodec.isNotBlank() && format.acodec != "none") {
                        SpecBadge(label = "Audio Codec", value = format.acodec)
                    }
                    if (format.protocol.isNotBlank()) {
                        SpecBadge(label = "Protocol", value = format.protocol.uppercase())
                    }
                    if (format.sizeBytes > 0) {
                        val byteCountFormatted = java.text.NumberFormat.getInstance().format(format.sizeBytes)
                        SpecBadge(label = "Exact Size", value = "$byteCountFormatted bytes")
                    }
                }

                // Copy / Share Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val clipboardManager = LocalClipboardManager.current
                    val context = LocalContext.current
                    
                    // Copy URL Button
                    Button(
                        onClick = {
                            clipboardManager.setText(androidx.compose.ui.text.AnnotatedString(format.downloadUrl))
                            android.widget.Toast.makeText(context, "Stream URL copied!", android.widget.Toast.LENGTH_SHORT).show()
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color.White.copy(alpha = 0.08f),
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(0.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(36.dp)
                            .testTag("copy_url_btn_${format.formatId}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.ContentCopy,
                            contentDescription = "Copy URL",
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    // Share Stream Button
                    Button(
                        onClick = {
                            try {
                                val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                                    type = "text/plain"
                                    putExtra(android.content.Intent.EXTRA_SUBJECT, "Stream Link")
                                    putExtra(android.content.Intent.EXTRA_TEXT, format.downloadUrl)
                                }
                                context.startActivity(android.content.Intent.createChooser(intent, "Share Stream URL"))
                            } catch (e: Exception) {
                                android.widget.Toast.makeText(context, "Unable to share stream URL", android.widget.Toast.LENGTH_SHORT).show()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color.White.copy(alpha = 0.08f),
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(0.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(36.dp)
                            .testTag("share_url_btn_${format.formatId}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Share,
                            contentDescription = "Share Stream",
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun SpecBadge(
    label: String,
    value: String,
    containerColor: Color = Color.White.copy(alpha = 0.04f),
    contentColor: Color = SleekTextSecondary
) {
    Row(
        modifier = Modifier
            .background(containerColor, RoundedCornerShape(8.dp))
            .border(0.5.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(8.dp))
            .padding(horizontal = 8.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Text(
            text = "$label:",
            color = SleekTextMuted,
            style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp, fontWeight = FontWeight.Medium)
        )
        Text(
            text = value,
            color = contentColor,
            style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp, fontWeight = FontWeight.Bold)
        )
    }
}

@Composable
fun SleekFilterChip(
    selected: Boolean,
    onClick: () -> Unit,
    label: String,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(
                if (selected) SleekPurpleLight.copy(alpha = 0.25f) else Color.White.copy(alpha = 0.04f)
            )
            .border(
                width = 1.dp,
                color = if (selected) SleekPurpleLight else Color.White.copy(alpha = 0.12f),
                shape = RoundedCornerShape(8.dp)
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 6.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            color = if (selected) Color.White else SleekTextSecondary,
            fontSize = 11.sp,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium
        )
    }
}
@Composable
fun SearchResultItemRow(
    result: YtdlpPipelineManager.SearchResult,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    index: Int = 0
) {
    val slideInOffset = remember { Animatable(100f) }
    val opacity = remember { Animatable(0f) }

    LaunchedEffect(key1 = result.id) {
        val delayTime = (index * 45L).coerceAtMost(250L)
        delay(delayTime)
        launch {
            slideInOffset.animateTo(
                targetValue = 0f,
                animationSpec = spring(
                    dampingRatio = Spring.DampingRatioLowBouncy,
                    stiffness = Spring.StiffnessMediumLow
                )
            )
        }
        launch {
            opacity.animateTo(
                targetValue = 1f,
                animationSpec = tween(durationMillis = 300, easing = LinearOutSlowInEasing)
            )
        }
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp)
            .graphicsLayer {
                translationX = slideInOffset.value
                alpha = opacity.value
            }
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = SleekCard),
        border = BorderStroke(1.dp, Color(0x14FFFFFF))
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(12.dp)
        ) {
            // Thumbnail
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(16f / 9f)
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color.Black)
            ) {
                AsyncImage(
                    model = result.thumbnailUrl,
                    contentDescription = result.title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )

                // Top right: Floating glass download button!
                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(10.dp)
                        .size(38.dp)
                        .shadow(4.dp, CircleShape)
                        .clip(CircleShape)
                        .background(Color(0x99111216))
                        .border(1.dp, Color.White.copy(alpha = 0.25f), CircleShape)
                        .clickable { onClick() },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.ArrowDownward,
                        contentDescription = "Quick Download",
                        tint = Color(0xFFFF9D33),
                        modifier = Modifier.size(18.dp)
                    )
                }

                if (result.duration.isNotBlank()) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .padding(8.dp)
                            .background(Color.Black.copy(alpha = 0.75f), RoundedCornerShape(6.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = result.duration,
                            color = Color.White,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 11.sp
                            )
                        )
                    }
                }
            }

            // Details below thumbnail
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 12.dp, start = 4.dp, end = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Info left
                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = result.title,
                        color = SleekTextPrimary,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            lineHeight = 20.sp
                        ),
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = result.author,
                            color = SleekTextSecondary,
                            style = MaterialTheme.typography.bodySmall.copy(
                                fontWeight = FontWeight.Medium
                            ),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Box(
                            modifier = Modifier
                                .background(Color(0x1AFFFF9D), RoundedCornerShape(4.dp))
                                .padding(horizontal = 6.dp, vertical = 1.dp)
                        ) {
                            Text(
                                text = "1080p",
                                color = Color(0xFFFF9D33),
                                style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp, fontWeight = FontWeight.ExtraBold)
                            )
                        }
                    }
                }

                // Info right: Overflow/Analyze trigger button
                IconButton(
                    onClick = onClick,
                    modifier = Modifier
                        .size(40.dp)
                        .background(Color.White.copy(alpha = 0.05f), CircleShape)
                        .border(1.dp, Color.White.copy(alpha = 0.1f), CircleShape)
                ) {
                    Icon(
                        imageVector = Icons.Default.Bolt,
                        contentDescription = "Analyze",
                        tint = Color(0xFFFF7A00),
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }
    }
}
@Composable
fun SkeletonSearchResultItem() {
    val brush = shimmerBrush()
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent)
    ) {
        Column(
            modifier = Modifier.fillMaxWidth()
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(16f / 9f)
                    .clip(RoundedCornerShape(12.dp))
                    .background(brush)
            )
            
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 12.dp, bottom = 4.dp, start = 4.dp, end = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.Top
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(brush)
                )
                
                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(0.9f)
                            .height(18.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(brush)
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(0.6f)
                            .height(14.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(brush)
                    )
                }
                
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(brush)
                )
            }
        }
    }
}
@Composable
fun PremiumSeekBar(
    value: Float,
    onValueChange: (Float) -> Unit,
    valueRange: ClosedFloatingPointRange<Float>,
    modifier: Modifier = Modifier,
    activeColor: Color = Color.White,
    inactiveColor: Color = Color.White.copy(alpha = 0.24f)
) {
    val rangeMin = valueRange.start
    val rangeMax = valueRange.endInclusive
    val rangeLength = rangeMax - rangeMin
    val progressFraction = if (rangeLength > 0f) {
        ((value - rangeMin) / rangeLength).coerceIn(0f, 1f)
    } else {
        0f
    }
    var isDragging by remember { mutableStateOf(false) }
    // Modern progressive animation for track thick/thin and thumb size
    val thumbRadius by androidx.compose.animation.core.animateDpAsState(
        targetValue = if (isDragging) 8.dp else 4.dp,
        animationSpec = androidx.compose.animation.core.spring(
            dampingRatio = androidx.compose.animation.core.Spring.DampingRatioMediumBouncy,
            stiffness = androidx.compose.animation.core.Spring.StiffnessLow
        ),
        label = "thumb_radius"
    )
    val trackHeight by androidx.compose.animation.core.animateDpAsState(
        targetValue = if (isDragging) 6.dp else 3.dp,
        animationSpec = androidx.compose.animation.core.spring(
            stiffness = androidx.compose.animation.core.Spring.StiffnessMedium
        ),
        label = "track_height"
    )
    BoxWithConstraints(
        modifier = modifier
            .fillMaxWidth()
            .height(24.dp),
        contentAlignment = Alignment.CenterStart
    ) {
        val widthPx = constraints.maxWidth.toFloat()
        Box(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(rangeMin, rangeMax, widthPx) {
                    detectTapGestures(
                        onPress = { offset ->
                            val fraction = (offset.x / widthPx).coerceIn(0f, 1f)
                            val newValue = rangeMin + fraction * rangeLength
                            onValueChange(newValue)
                        }
                    )
                }
                .pointerInput(rangeMin, rangeMax, widthPx) {
                    detectHorizontalDragGestures(
                        onDragStart = { isDragging = true },
                        onDragEnd = { isDragging = false },
                        onDragCancel = { isDragging = false },
                        onHorizontalDrag = { change, _ ->
                            val fraction = (change.position.x / widthPx).coerceIn(0f, 1f)
                            val newValue = rangeMin + fraction * rangeLength
                            onValueChange(newValue)
                            change.consume()
                        }
                    )
                }
        ) {
            Canvas(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.Center)
                    .height(24.dp)
            ) {
                val canvasWidth = size.width
                val canvasHeight = size.height
                val centerY = canvasHeight / 2f
                val trackHeightPx = trackHeight.toPx()
                val activeEndX = canvasWidth * progressFraction
                // 1. Draw Inactive Track
                drawRoundRect(
                    color = inactiveColor,
                    topLeft = androidx.compose.ui.geometry.Offset(0f, centerY - trackHeightPx / 2f),
                    size = androidx.compose.ui.geometry.Size(canvasWidth, trackHeightPx),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(trackHeightPx / 2f)
                )
                // 2. Draw Active Seek progress status
                drawRoundRect(
                    brush = Brush.horizontalGradient(
                        colors = listOf(
                            activeColor.copy(alpha = 0.75f),
                            activeColor
                        )
                    ),
                    topLeft = androidx.compose.ui.geometry.Offset(0f, centerY - trackHeightPx / 2f),
                    size = androidx.compose.ui.geometry.Size(activeEndX, trackHeightPx),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(trackHeightPx / 2f)
                )
                // 3. Draw active focus glow halo
                if (isDragging) {
                    drawCircle(
                        color = activeColor.copy(alpha = 0.18f),
                        radius = thumbRadius.toPx() * 2.5f,
                        center = androidx.compose.ui.geometry.Offset(activeEndX, centerY)
                    )
                }
                // 4. Draw active thumb
                drawCircle(
                    color = Color.White,
                    radius = thumbRadius.toPx(),
                    center = androidx.compose.ui.geometry.Offset(activeEndX, centerY)
                )
            }
        }
    }
}
sealed interface LibraryItem {
    val id: String
    val title: String

    data class Completed(val entity: DownloadEntity) : LibraryItem {
        override val id: String get() = entity.id
        override val title: String get() = entity.title
    }

    data class Failed(val task: ActiveDownloadTask) : LibraryItem {
        override val id: String get() = task.id
        override val title: String get() = task.title
    }
}

@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
@Composable
fun FailedItemCard(
    task: ActiveDownloadTask? = null,
    entity: DownloadEntity? = null,
    onDeleteClick: () -> Unit,
    onResumeClick: (() -> Unit)? = null,
    onRefetchClick: (() -> Unit)? = null,
    selected: Boolean = false,
    onSelectedChange: ((Boolean) -> Unit)? = null,
    onLongClick: (() -> Unit)? = null,
    modifier: Modifier = Modifier,
    index: Int = 0
) {
    val slideInOffset = remember { Animatable(100f) }
    val opacity = remember { Animatable(0f) }
    val itemId = task?.id ?: entity?.id ?: "unknown"
    val itemTitle = task?.title ?: entity?.title ?: "Download"
    val itemExt = task?.ext ?: entity?.formatExt ?: ""
    val status = task?.status?.name ?: entity?.downloadStatus ?: "FAILED"
    val errorMsg = task?.error ?: entity?.statusMessage ?: ""
    val downloadedBytes = task?.downloadedBytes ?: entity?.fileSize ?: 0L
    val totalBytes = task?.totalBytes ?: entity?.expectedSize ?: 0L

    val statusColor = when (status) {
        "RECOVERABLE" -> Color(0xFF00E5FF)
        "INCOMPLETE" -> Color(0xFFFFB300)
        "CORRUPTED" -> CrimsonFailure
        else -> CrimsonFailure
    }
    val statusBg = statusColor.copy(alpha = 0.15f)

    LaunchedEffect(key1 = itemId) {
        val delayTime = (index * 45L).coerceAtMost(250L)
        delay(delayTime)
        launch {
            slideInOffset.animateTo(
                targetValue = 0f,
                animationSpec = spring(
                    dampingRatio = Spring.DampingRatioLowBouncy,
                    stiffness = Spring.StiffnessMediumLow
                )
            )
        }
        launch {
            opacity.animateTo(
                targetValue = 1f,
                animationSpec = tween(durationMillis = 300, easing = LinearOutSlowInEasing)
            )
        }
    }

    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp)
            .graphicsLayer {
                translationX = slideInOffset.value
                alpha = opacity.value
            },
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (onSelectedChange != null) {
            Checkbox(
                checked = selected,
                onCheckedChange = onSelectedChange,
                colors = CheckboxDefaults.colors(
                    checkedColor = SleekPurpleLight,
                    uncheckedColor = SleekTextSecondary
                ),
                modifier = Modifier.padding(end = 8.dp).testTag("checkbox_$itemId")
            )
        }

        Card(
            modifier = Modifier
                .weight(1f)
                .combinedClickable(
                    onClick = { },
                    onLongClick = { onLongClick?.invoke() }
                ),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = SleekCardDark),
            border = BorderStroke(1.dp, statusColor.copy(alpha = 0.35f))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .background(statusBg, RoundedCornerShape(8.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (status == "RECOVERABLE" || status == "INCOMPLETE") Icons.Default.Refresh else Icons.Default.Warning,
                            contentDescription = status,
                            tint = statusColor,
                            modifier = Modifier.size(24.dp)
                        )
                    }

                    Column(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = itemTitle,
                            color = Color.White,
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .background(statusBg, RoundedCornerShape(4.dp))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = status,
                                    color = statusColor,
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 9.sp
                                    )
                                )
                            }
                            if (itemExt.isNotBlank()) {
                                Text(
                                    text = itemExt.uppercase(),
                                    color = SleekTextSecondary,
                                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp, fontWeight = FontWeight.Medium)
                                )
                            }
                            if (downloadedBytes > 0L) {
                                val mbDownloaded = String.format(Locale.getDefault(), "%.1f", downloadedBytes / (1024f * 1024f))
                                val mbTotal = if (totalBytes > 0L) String.format(Locale.getDefault(), "%.1f MB", totalBytes / (1024f * 1024f)) else ""
                                val sizeText = if (mbTotal.isNotBlank()) "$mbDownloaded / $mbTotal" else "$mbDownloaded MB"
                                Text(
                                    text = sizeText,
                                    color = SleekTextSecondary,
                                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp)
                                )
                            }
                        }
                        if (errorMsg.isNotBlank()) {
                            Text(
                                text = errorMsg,
                                color = statusColor.copy(alpha = 0.85f),
                                style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }

                    IconButton(
                        onClick = onDeleteClick,
                        modifier = Modifier.size(36.dp).testTag("delete_broken_${itemId}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "Delete Task",
                            tint = CrimsonFailure
                        )
                    }
                }

                // Action controls: [Resume] [Re-fetch]
                if (onResumeClick != null || onRefetchClick != null) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (onResumeClick != null && (status == "RECOVERABLE" || status == "INCOMPLETE" || downloadedBytes > 0L)) {
                            FilledTonalButton(
                                onClick = onResumeClick,
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.filledTonalButtonColors(
                                    containerColor = SleekPurpleLight.copy(alpha = 0.2f),
                                    contentColor = SleekPurpleLight
                                ),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                                modifier = Modifier.padding(end = 8.dp).height(32.dp).testTag("resume_btn_${itemId}")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.PlayArrow,
                                    contentDescription = "Resume",
                                    modifier = Modifier.size(14.dp).padding(end = 4.dp)
                                )
                                Text("Resume", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold))
                            }
                        }

                        if (onRefetchClick != null) {
                            OutlinedButton(
                                onClick = onRefetchClick,
                                shape = RoundedCornerShape(8.dp),
                                border = BorderStroke(1.dp, SleekTextSecondary.copy(alpha = 0.4f)),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    contentColor = Color.White
                                ),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                                modifier = Modifier.height(32.dp).testTag("refetch_btn_${itemId}")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Refresh,
                                    contentDescription = "Re-fetch",
                                    modifier = Modifier.size(14.dp).padding(end = 4.dp)
                                )
                                Text("Re-fetch", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Medium))
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(com.google.accompanist.permissions.ExperimentalPermissionsApi::class)
@Composable
fun LibraryTab(
    downloads: List<DownloadEntity>,
    failedTasks: List<ActiveDownloadTask> = emptyList(),
    appDownloadedPaths: Set<String> = emptySet(),
    onPlayClick: (DownloadEntity) -> Unit,
    onShareClick: (DownloadEntity) -> Unit,
    onDeleteClick: (DownloadEntity) -> Unit,
    onDeleteFailedClick: (String) -> Unit = {},
    onConvertAudio: (DownloadEntity, String) -> Unit,
    onBulkDeleteClick: (List<DownloadEntity>, List<String>) -> Unit = { _, _ -> },
    onEditMetadataClick: ((DownloadEntity) -> Unit)? = null,
    onAddToPlaylistClick: ((DownloadEntity) -> Unit)? = null,
    viewModel: VideoDownloaderViewModel? = null
) {
    val isTabletOrWide = androidx.compose.ui.platform.LocalConfiguration.current.screenWidthDp >= 600
    val context = LocalContext.current
    val permissionState = com.google.accompanist.permissions.rememberMultiplePermissionsState(
        remember { com.example.util.DeviceCompatHelper.getRequiredPermissions() }
    )
    val isStoragePermissionGranted = remember(permissionState.allPermissionsGranted) {
        permissionState.allPermissionsGranted
    }

    LaunchedEffect(Unit) {
        viewModel?.triggerStorageCleanup()
        viewModel?.refreshWatchedCleanupList()
    }

    var selectedFilter by remember { mutableStateOf("All") }
    val filters = listOf("All", "Videos", "Audio", "Downloads", "Failed")

    val allItems = remember(downloads, failedTasks) {
        val list = mutableListOf<LibraryItem>()
        list.addAll(downloads.map { LibraryItem.Completed(it) })
        list.addAll(failedTasks.map { LibraryItem.Failed(it) })
        list
    }

    val filteredItems = remember(allItems, selectedFilter) {
        allItems.filter { item ->
            when (selectedFilter) {
                "Videos" -> item is LibraryItem.Completed && (
                    item.entity.localPath.endsWith(".mp4", true) || 
                    item.entity.localPath.endsWith(".webm", true) || 
                    item.entity.localPath.endsWith(".mkv", true)
                )
                "Audio" -> item is LibraryItem.Completed && (
                    item.entity.localPath.endsWith(".mp3", true) || 
                    item.entity.localPath.endsWith(".m4a", true) || 
                    item.entity.localPath.endsWith(".opus", true) || 
                    item.entity.localPath.endsWith(".wav", true)
                )
                "Downloads" -> item is LibraryItem.Completed && appDownloadedPaths.contains(item.entity.localPath)
                "Failed" -> item is LibraryItem.Failed
                else -> true
            }
        }
    }

    var selectedIds by remember { mutableStateOf(emptySet<String>()) }
    var isSelectionMode by remember { mutableStateOf(false) }
    var showBulkDeleteConfirm by remember { mutableStateOf(false) }
    var showFilterDropdownMenu by remember { mutableStateOf(false) }

    val configuration = androidx.compose.ui.platform.LocalConfiguration.current
    val screenWidthDp = configuration.screenWidthDp
    val columns = when {
        screenWidthDp < 600 -> 1
        screenWidthDp < 840 -> 2
        screenWidthDp < 1200 -> 3
        else -> 4
    }
    val maxContentWidth = (columns * 460).dp

    if (showBulkDeleteConfirm) {
        AlertDialog(
            onDismissRequest = { showBulkDeleteConfirm = false },
            title = {
                Text(
                    text = "Delete Selected Items?",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = Color.White
                )
            },
            text = {
                Text(
                    text = "Are you sure you want to delete the ${selectedIds.size} selected items? Completed items will be deleted from your storage.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = SleekTextSecondary
                )
            },
            containerColor = Color(0xFF1E2026),
            confirmButton = {
                Button(
                    onClick = {
                        val selectedCompleted = mutableListOf<DownloadEntity>()
                        val selectedFailed = mutableListOf<String>()
                        selectedIds.forEach { key ->
                            if (key.startsWith("completed_")) {
                                val id = key.substringAfter("completed_")
                                downloads.find { it.id == id }?.let { selectedCompleted.add(it) }
                            } else if (key.startsWith("failed_")) {
                                val id = key.substringAfter("failed_")
                                selectedFailed.add(id)
                            }
                        }
                        onBulkDeleteClick(selectedCompleted, selectedFailed)
                        selectedIds = emptySet()
                        showBulkDeleteConfirm = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CrimsonFailure)
                ) {
                    Icon(Icons.Default.Delete, contentDescription = "Delete")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { showBulkDeleteConfirm = false }
                ) {
                    Icon(Icons.Default.Close, contentDescription = "Cancel", tint = Color.White)
                }
            }
        )
    }

    BoxWithConstraints(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        val screenW = maxWidth
        val screenH = maxHeight
        val marginH = (screenW * 0.04f).coerceAtLeast(14.dp)
        val filterBarH = (screenH * 0.055f).coerceIn(38.dp, 52.dp)
        val filterBarRadius = filterBarH * 0.5f
        val filterButtonSize = (screenW * 0.065f).coerceIn(38.dp, 48.dp)
        val filterGap = (screenW * 0.012f).coerceIn(4.dp, 8.dp)
        val cardTopGap = (screenH * 0.04f).coerceIn(14.dp, 32.dp)

        val countAll = allItems.size
        val countVideos = allItems.count { it is LibraryItem.Completed && (it.entity.localPath.endsWith(".mp4", true) || it.entity.localPath.endsWith(".webm", true) || it.entity.localPath.endsWith(".mkv", true)) }
        val countAudio = allItems.count { it is LibraryItem.Completed && (it.entity.localPath.endsWith(".mp3", true) || it.entity.localPath.endsWith(".m4a", true) || it.entity.localPath.endsWith(".opus", true) || it.entity.localPath.endsWith(".wav", true)) }
        val countDownloads = allItems.count { it is LibraryItem.Completed && appDownloadedPaths.contains(it.entity.localPath) }
        val countFailed = allItems.count { it is LibraryItem.Failed }

        val filterList = listOf(
            "All" to countAll,
            "Videos" to countVideos,
            "Audio" to countAudio,
            "Downloads" to countDownloads,
            "Failed" to countFailed
        )

        Column(
            modifier = Modifier
                .fillMaxHeight()
                .widthIn(max = maxContentWidth)
                .fillMaxWidth()
                .statusBarsPadding()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = marginH)
                    .padding(top = (screenH * 0.052f).coerceIn(12.dp, 36.dp), bottom = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Rounded Filter Bar with 5 evenly distributed filters
                Row(
                    modifier = Modifier
                        .weight(1f)
                        .height(filterBarH)
                        .clip(RoundedCornerShape(filterBarRadius))
                        .background(Color(0xFF14161D).copy(alpha = 0.85f))
                        .border(1.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(filterBarRadius))
                        .padding(3.dp),
                    horizontalArrangement = Arrangement.spacedBy(2.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    filterList.forEach { (filterName, count) ->
                        val isSelected = selectedFilter == filterName
                        val filterBgColor by animateColorAsState(
                            targetValue = if (isSelected) Color(0xFFFF8A00) else Color.Transparent,
                            animationSpec = tween(durationMillis = 180),
                            label = "FilterBg_$filterName"
                        )
                        val filterTextColor by animateColorAsState(
                            targetValue = if (isSelected) Color.White else Color(0xFF8E95A2),
                            animationSpec = tween(durationMillis = 180),
                            label = "FilterText_$filterName"
                        )

                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxHeight()
                                .clip(RoundedCornerShape(filterBarRadius))
                                .background(filterBgColor)
                                .clickable { selectedFilter = filterName },
                            contentAlignment = Alignment.Center
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center,
                                modifier = Modifier.padding(horizontal = 2.dp)
                            ) {
                                Text(
                                    text = filterName,
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Medium,
                                        fontSize = 11.5.sp
                                    ),
                                    color = filterTextColor,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Spacer(modifier = Modifier.width(2.dp))
                                Text(
                                    text = "($count)",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal,
                                        fontSize = 10.sp
                                    ),
                                    color = if (isSelected) Color.White.copy(alpha = 0.9f) else Color(0xFF6B7280),
                                    maxLines = 1
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.width(filterGap))

                // Filter Button immediately to the right
                Box(
                    modifier = Modifier.size(filterButtonSize)
                ) {
                    Surface(
                        modifier = Modifier
                            .fillMaxSize()
                            .clip(CircleShape)
                            .clickable { showFilterDropdownMenu = !showFilterDropdownMenu },
                        shape = CircleShape,
                        color = Color(0xFF161820).copy(alpha = 0.85f),
                        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.08f))
                    ) {
                        Box(
                            modifier = Modifier.fillMaxSize(),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.FilterList,
                                contentDescription = "Filter Options",
                                tint = Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    if (selectedFilter != "All") {
                        Box(
                            modifier = Modifier
                                .align(Alignment.TopEnd)
                                .padding(3.dp)
                                .size(7.dp)
                                .background(Color(0xFFFF8A00), CircleShape)
                        )
                    }

                    DropdownMenu(
                        expanded = showFilterDropdownMenu,
                        onDismissRequest = { showFilterDropdownMenu = false },
                        modifier = Modifier
                            .background(Color(0xFF161820))
                            .border(1.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(12.dp))
                    ) {
                        filterList.forEach { (filterName, count) ->
                            DropdownMenuItem(
                                text = {
                                    Text(
                                        text = "$filterName ($count)",
                                        color = if (selectedFilter == filterName) Color(0xFFFF8A00) else Color.White,
                                        fontWeight = if (selectedFilter == filterName) FontWeight.Bold else FontWeight.Normal
                                    )
                                },
                                trailingIcon = {
                                    if (selectedFilter == filterName) {
                                        Icon(Icons.Default.Check, contentDescription = null, tint = Color(0xFFFF8A00), modifier = Modifier.size(16.dp))
                                    }
                                },
                                onClick = {
                                    selectedFilter = filterName
                                    showFilterDropdownMenu = false
                                }
                            )
                        }
                        if (selectedFilter != "All") {
                            HorizontalDivider(color = Color.White.copy(alpha = 0.08f))
                            DropdownMenuItem(
                                text = { Text("Reset Filter", color = Color(0xFFFF8A00), fontWeight = FontWeight.SemiBold) },
                                leadingIcon = { Icon(Icons.Default.Refresh, contentDescription = null, tint = Color(0xFFFF8A00), modifier = Modifier.size(16.dp)) },
                                onClick = {
                                    selectedFilter = "All"
                                    showFilterDropdownMenu = false
                                }
                            )
                        }
                    }
                }

                if (!isStoragePermissionGranted) {
                    Spacer(modifier = Modifier.width(filterGap))
                    IconButton(
                        onClick = { permissionState.launchMultiplePermissionRequest() },
                        modifier = Modifier
                            .size(filterButtonSize)
                            .background(Color(0xFF161820).copy(alpha = 0.85f), CircleShape)
                            .border(1.dp, Color.White.copy(alpha = 0.08f), CircleShape)
                    ) {
                        Icon(Icons.Default.Folder, contentDescription = "Request Storage", tint = Color(0xFFFF8A00), modifier = Modifier.size(18.dp))
                    }
                }
            }

            var isRefreshing by remember { mutableStateOf(false) }
            val coroutineScope = rememberCoroutineScope()
            @OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
            val pullRefreshState = androidx.compose.material3.pulltorefresh.rememberPullToRefreshState()
            
            @OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
            androidx.compose.material3.pulltorefresh.PullToRefreshBox(
                isRefreshing = isRefreshing,
                onRefresh = {
                    isRefreshing = true
                    coroutineScope.launch {
                        viewModel?.forceRefreshDownloads()
                        kotlinx.coroutines.delay(800)
                        isRefreshing = false
                    }
                },
                state = pullRefreshState,
                modifier = Modifier.weight(1f).fillMaxWidth()
            ) {
                if (filteredItems.isEmpty()) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = "Empty",
                        tint = SleekTextMuted.copy(alpha = 0.5f),
                        modifier = Modifier.size(80.dp)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "NO COMPATIBLE MEDIA",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = SleekTextPrimary,
                            letterSpacing = 1.sp
                        )
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = if (!isStoragePermissionGranted) "Grant storage access to see your device media, or download content." else "No media matches the currently selected filter.",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = SleekTextSecondary,
                            textAlign = TextAlign.Center
                        )
                    )
                    if (!isStoragePermissionGranted) {
                        Spacer(modifier = Modifier.height(16.dp))
                        Button(
                            onClick = { permissionState.launchMultiplePermissionRequest() },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color.White,
                                contentColor = Color.Black
                            ),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("Grant Permissions", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            } else {
                val showSelectionBoxes = isSelectionMode || selectedIds.isNotEmpty()

                val allVisibleSelected = filteredItems.isNotEmpty() && filteredItems.all { item ->
                    val key = when (item) {
                        is LibraryItem.Completed -> "completed_${item.entity.id}"
                        is LibraryItem.Failed -> "failed_${item.task.id}"
                    }
                    selectedIds.contains(key)
                }

                val onToggleSelectAll = {
                    if (allVisibleSelected) {
                        selectedIds = selectedIds - filteredItems.map { item ->
                            when (item) {
                                is LibraryItem.Completed -> "completed_${item.entity.id}"
                                is LibraryItem.Failed -> "failed_${item.task.id}"
                            }
                        }.toSet()
                        if (selectedIds.isEmpty()) isSelectionMode = false
                    } else {
                        selectedIds = selectedIds + filteredItems.map { item ->
                            when (item) {
                                is LibraryItem.Completed -> "completed_${item.entity.id}"
                                is LibraryItem.Failed -> "failed_${item.task.id}"
                            }
                        }.toSet()
                        isSelectionMode = true
                    }
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = marginH, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    if (showSelectionBoxes) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.clickable { onToggleSelectAll() }
                            ) {
                                Checkbox(
                                    checked = allVisibleSelected,
                                    onCheckedChange = { onToggleSelectAll() },
                                    colors = CheckboxDefaults.colors(
                                        checkedColor = Color(0xFFFF8A00),
                                        uncheckedColor = SleekTextSecondary
                                    ),
                                    modifier = Modifier.testTag("select_all_checkbox")
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Select All",
                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium),
                                    color = Color.White
                                )
                            }

                            Spacer(modifier = Modifier.width(16.dp))

                            TextButton(
                                onClick = {
                                    isSelectionMode = false
                                    selectedIds = emptySet()
                                }
                            ) {
                                Text("Cancel", color = SleekTextSecondary)
                            }
                        }
                    } else {
                        Spacer(modifier = Modifier.width(8.dp))
                    }

                    if (selectedIds.isNotEmpty()) {
                        Button(
                            onClick = { showBulkDeleteConfirm = true },
                            colors = ButtonDefaults.buttonColors(containerColor = CrimsonFailure),
                            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.testTag("bulk_delete_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Delete,
                                contentDescription = "Delete",
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Delete Selected (${selectedIds.size})",
                                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold)
                            )
                        }
                    }
                }

                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = marginH, end = marginH, top = cardTopGap, bottom = 140.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    if (columns == 1) {
                        itemsIndexed(filteredItems, key = { _, item -> item.id }) { index, item ->
                            val key = when (item) {
                                is LibraryItem.Completed -> "completed_${item.entity.id}"
                                is LibraryItem.Failed -> "failed_${item.task.id}"
                            }
                            val isSelected = selectedIds.contains(key)
                            
                            val itemOnSelectedChange: ((Boolean) -> Unit)? = if (showSelectionBoxes) {
                                { checked ->
                                    selectedIds = if (checked) selectedIds + key else selectedIds - key
                                    if (selectedIds.isEmpty()) isSelectionMode = false
                                }
                            } else null

                            val itemOnLongClick: () -> Unit = {
                                isSelectionMode = true
                                selectedIds = if (selectedIds.contains(key)) selectedIds - key else selectedIds + key
                            }

                            when (item) {
                                is LibraryItem.Completed -> {
                                    if (item.entity.downloadStatus in listOf("INCOMPLETE", "RECOVERABLE", "CORRUPTED", "FAILED")) {
                                        FailedItemCard(
                                            entity = item.entity,
                                            index = index,
                                            selected = isSelected,
                                            onSelectedChange = itemOnSelectedChange,
                                            onLongClick = itemOnLongClick,
                                            onResumeClick = { viewModel?.resumeDownloadItem(item.entity) },
                                            onRefetchClick = { viewModel?.refetchDownloadItem(item.entity) },
                                            onDeleteClick = { viewModel?.deleteIncompleteDownload(item.entity) },
                                            modifier = Modifier.animateItem()
                                        )
                                    } else {
                                        LibraryItemCard(
                                            item = item.entity,
                                            index = index,
                                            selected = isSelected,
                                            onSelectedChange = itemOnSelectedChange,
                                            onLongClick = itemOnLongClick,
                                            onPlayClick = { onPlayClick(item.entity) },
                                            onShareClick = { onShareClick(item.entity) },
                                            onDeleteClick = { onDeleteClick(item.entity) },
                                            onConvertAudio = { codec -> onConvertAudio(item.entity, codec) },
                                            onTrimClick = {
                                                viewModel?.openMediaTrimmer(item.entity)
                                            },
                                            onCompressClick = {
                                                viewModel?.openVideoCompressor(item.entity)
                                            },
                                            onEditMetadataClick = { onEditMetadataClick?.invoke(item.entity) },
                                            onAddToPlaylistClick = { onAddToPlaylistClick?.invoke(item.entity) },
                                            onUpdateThumbnail = { path -> viewModel?.updateMediaThumbnail(item.entity.id, path) },
                                            modifier = Modifier.animateItem()
                                        )
                                    }
                                }
                                is LibraryItem.Failed -> {
                                    FailedItemCard(
                                        task = item.task,
                                        index = index,
                                        selected = isSelected,
                                        onSelectedChange = itemOnSelectedChange,
                                        onLongClick = itemOnLongClick,
                                        onResumeClick = if (item.task.originalUrl.isNotBlank()) {
                                            {
                                                val entityFromTask = DownloadEntity(
                                                    id = item.task.id,
                                                    title = item.task.title,
                                                    author = item.task.author,
                                                    durationText = item.task.durationText,
                                                    thumbnailUrl = item.task.thumbnailUrl,
                                                    localPath = "",
                                                    fileSize = item.task.downloadedBytes,
                                                    expectedSize = item.task.totalBytes,
                                                    originalUrl = item.task.originalUrl,
                                                    formatId = item.task.formatId,
                                                    formatQuality = item.task.formatQuality,
                                                    formatExt = item.task.ext
                                                )
                                                viewModel?.resumeDownloadItem(entityFromTask)
                                            }
                                        } else null,
                                        onRefetchClick = if (item.task.originalUrl.isNotBlank()) {
                                            {
                                                val entityFromTask = DownloadEntity(
                                                    id = item.task.id,
                                                    title = item.task.title,
                                                    author = item.task.author,
                                                    durationText = item.task.durationText,
                                                    thumbnailUrl = item.task.thumbnailUrl,
                                                    localPath = "",
                                                    fileSize = 0L,
                                                    expectedSize = item.task.totalBytes,
                                                    originalUrl = item.task.originalUrl,
                                                    formatId = item.task.formatId,
                                                    formatQuality = item.task.formatQuality,
                                                    formatExt = item.task.ext
                                                )
                                                viewModel?.refetchDownloadItem(entityFromTask)
                                            }
                                        } else null,
                                        onDeleteClick = { onDeleteFailedClick(item.task.id) },
                                        modifier = Modifier.animateItem()
                                    )
                                }
                            }
                        }
                    } else {
                        val chunks = filteredItems.chunked(columns)
                        itemsIndexed(chunks, key = { _, chunk -> chunk.joinToString("_") { it.id } }) { index, chunk ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(16.dp)
                            ) {
                                chunk.forEachIndexed { chunkIndex, item ->
                                    val key = when (item) {
                                        is LibraryItem.Completed -> "completed_${item.entity.id}"
                                        is LibraryItem.Failed -> "failed_${item.task.id}"
                                    }
                                    val isSelected = selectedIds.contains(key)
                                    val overallIndex = index * columns + chunkIndex
                                    
                                    val itemOnSelectedChange: ((Boolean) -> Unit)? = if (showSelectionBoxes) {
                                        { checked ->
                                            selectedIds = if (checked) selectedIds + key else selectedIds - key
                                            if (selectedIds.isEmpty()) isSelectionMode = false
                                        }
                                    } else null

                                    val itemOnLongClick: () -> Unit = {
                                        isSelectionMode = true
                                        selectedIds = if (selectedIds.contains(key)) selectedIds - key else selectedIds + key
                                    }

                                    Box(modifier = Modifier.weight(1f)) {
                                        when (item) {
                                            is LibraryItem.Completed -> {
                                                if (item.entity.downloadStatus in listOf("INCOMPLETE", "RECOVERABLE", "CORRUPTED", "FAILED")) {
                                                    FailedItemCard(
                                                        entity = item.entity,
                                                        index = overallIndex,
                                                        selected = isSelected,
                                                        onSelectedChange = itemOnSelectedChange,
                                                        onLongClick = itemOnLongClick,
                                                        onResumeClick = { viewModel?.resumeDownloadItem(item.entity) },
                                                        onRefetchClick = { viewModel?.refetchDownloadItem(item.entity) },
                                                        onDeleteClick = { viewModel?.deleteIncompleteDownload(item.entity) },
                                                        modifier = Modifier.animateItem()
                                                    )
                                                } else {
                                                    LibraryItemCard(
                                                        item = item.entity,
                                                        index = overallIndex,
                                                        selected = isSelected,
                                                        onSelectedChange = itemOnSelectedChange,
                                                        onLongClick = itemOnLongClick,
                                                        onPlayClick = { onPlayClick(item.entity) },
                                                        onShareClick = { onShareClick(item.entity) },
                                                        onDeleteClick = { onDeleteClick(item.entity) },
                                                        onConvertAudio = { codec -> onConvertAudio(item.entity, codec) },
                                                        onTrimClick = {
                                                            viewModel?.openMediaTrimmer(item.entity)
                                                        },
                                                        onCompressClick = {
                                                            viewModel?.openVideoCompressor(item.entity)
                                                        },
                                                        onEditMetadataClick = { onEditMetadataClick?.invoke(item.entity) },
                                                        onAddToPlaylistClick = { onAddToPlaylistClick?.invoke(item.entity) },
                                                        onUpdateThumbnail = { path -> viewModel?.updateMediaThumbnail(item.entity.id, path) },
                                                        modifier = Modifier.animateItem()
                                                    )
                                                }
                                            }
                                            is LibraryItem.Failed -> {
                                                FailedItemCard(
                                                    task = item.task,
                                                    index = overallIndex,
                                                    selected = isSelected,
                                                    onSelectedChange = itemOnSelectedChange,
                                                    onLongClick = itemOnLongClick,
                                                    onResumeClick = if (item.task.originalUrl.isNotBlank()) {
                                                        {
                                                            val entityFromTask = DownloadEntity(
                                                                id = item.task.id,
                                                                title = item.task.title,
                                                                author = item.task.author,
                                                                durationText = item.task.durationText,
                                                                thumbnailUrl = item.task.thumbnailUrl,
                                                                localPath = "",
                                                                fileSize = item.task.downloadedBytes,
                                                                expectedSize = item.task.totalBytes,
                                                                originalUrl = item.task.originalUrl,
                                                                formatId = item.task.formatId,
                                                                formatQuality = item.task.formatQuality,
                                                                formatExt = item.task.ext
                                                            )
                                                            viewModel?.resumeDownloadItem(entityFromTask)
                                                        }
                                                    } else null,
                                                    onRefetchClick = if (item.task.originalUrl.isNotBlank()) {
                                                        {
                                                            val entityFromTask = DownloadEntity(
                                                                id = item.task.id,
                                                                title = item.task.title,
                                                                author = item.task.author,
                                                                durationText = item.task.durationText,
                                                                thumbnailUrl = item.task.thumbnailUrl,
                                                                localPath = "",
                                                                fileSize = 0L,
                                                                expectedSize = item.task.totalBytes,
                                                                originalUrl = item.task.originalUrl,
                                                                formatId = item.task.formatId,
                                                                formatQuality = item.task.formatQuality,
                                                                formatExt = item.task.ext
                                                            )
                                                            viewModel?.refetchDownloadItem(entityFromTask)
                                                        }
                                                    } else null,
                                                    onDeleteClick = { onDeleteFailedClick(item.task.id) },
                                                    modifier = Modifier.animateItem()
                                                )
                                            }
                                        }
                                    }
                                }
                                val emptySlots = columns - chunk.size
                                repeat(emptySlots) {
                                    Spacer(modifier = Modifier.weight(1f))
                                }
                            }
                        }
                    }
                }
            }
            }
        }
    }
}

enum class LibraryThumbnailState {
    VALID_THUMBNAIL,
    MISSING_THUMBNAIL,
    BLACK_THUMBNAIL,
    EXTRACTION_FAILED
}

suspend fun evaluateLibraryThumbnailState(
    context: android.content.Context,
    thumbnailUrl: String,
    isLocalVideo: Boolean
): LibraryThumbnailState {
    if (thumbnailUrl.isBlank()) {
        return if (isLocalVideo) LibraryThumbnailState.MISSING_THUMBNAIL else LibraryThumbnailState.EXTRACTION_FAILED
    }
    return kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
        try {
            val loader = context.imageLoader
            val request = coil.request.ImageRequest.Builder(context)
                .data(thumbnailUrl)
                .size(128, 128)
                .allowHardware(false)
                .build()
            val result = loader.execute(request)
            val drawable = result.drawable ?: return@withContext if (isLocalVideo) LibraryThumbnailState.EXTRACTION_FAILED else LibraryThumbnailState.EXTRACTION_FAILED
            val bitmap = if (drawable is android.graphics.drawable.BitmapDrawable) {
                drawable.bitmap
            } else {
                val bmp = android.graphics.Bitmap.createBitmap(
                    drawable.intrinsicWidth.coerceAtLeast(128),
                    drawable.intrinsicHeight.coerceAtLeast(128),
                    android.graphics.Bitmap.Config.ARGB_8888
                )
                val canvas = android.graphics.Canvas(bmp)
                drawable.setBounds(0, 0, canvas.width, canvas.height)
                drawable.draw(canvas)
                bmp
            }
            if (bitmap == null || bitmap.width == 0 || bitmap.height == 0) {
                return@withContext if (isLocalVideo) LibraryThumbnailState.EXTRACTION_FAILED else LibraryThumbnailState.EXTRACTION_FAILED
            }

            val width = bitmap.width
            val height = bitmap.height
            val totalPixels = width * height
            val pixels = IntArray(totalPixels)
            bitmap.getPixels(pixels, 0, width, 0, 0, width, height)

            var nearBlackCount = 0
            val veryLowThreshold = 12 // Very low luminance threshold for near-black pixels

            for (pixel in pixels) {
                val r = (pixel shr 16) and 0xFF
                val g = (pixel shr 8) and 0xFF
                val b = pixel and 0xFF
                val luminance = 0.299f * r + 0.587f * g + 0.114f * b
                if (luminance <= veryLowThreshold) {
                    nearBlackCount++
                }
            }

            val nearBlackRatio = nearBlackCount.toFloat() / totalPixels

            if (nearBlackRatio >= 0.95f) {
                LibraryThumbnailState.BLACK_THUMBNAIL
            } else {
                LibraryThumbnailState.VALID_THUMBNAIL
            }
        } catch (e: Exception) {
            if (isLocalVideo) LibraryThumbnailState.EXTRACTION_FAILED else LibraryThumbnailState.EXTRACTION_FAILED
        }
    }
}

@Composable
fun MediaCardThumbnailArea(
    item: DownloadEntity,
    durationString: String,
    modifier: Modifier = Modifier,
    onUpdateThumbnail: ((String) -> Unit)? = null
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val isAudio = item.isAudioOnly || 
        item.localPath.endsWith(".mp3", true) || 
        item.localPath.endsWith(".m4a", true) || 
        item.localPath.endsWith(".opus", true) || 
        item.localPath.endsWith(".wav", true) ||
        item.localPath.endsWith(".flac", true)

    val isLocalVideo = !isAudio && item.localPath.isNotBlank() && java.io.File(item.localPath).exists()

    var thumbnailState by remember(item.id, item.thumbnailUrl, item.localPath) {
        mutableStateOf<LibraryThumbnailState?>(
            if (item.thumbnailUrl.isBlank()) {
                if (isLocalVideo) LibraryThumbnailState.MISSING_THUMBNAIL else LibraryThumbnailState.EXTRACTION_FAILED
            } else null
        )
    }

    LaunchedEffect(item.id, item.thumbnailUrl, item.localPath) {
        val state = evaluateLibraryThumbnailState(context, item.thumbnailUrl, isLocalVideo)
        thumbnailState = state
    }

    val currentState = thumbnailState
    val stateLogStr = when (currentState) {
        LibraryThumbnailState.VALID_THUMBNAIL -> "VALID"
        LibraryThumbnailState.MISSING_THUMBNAIL -> "MISSING"
        LibraryThumbnailState.BLACK_THUMBNAIL -> "BLACK"
        LibraryThumbnailState.EXTRACTION_FAILED -> "FAILED"
        null -> "EVALUATING"
    }

    if (currentState != null) {
        android.util.Log.d("LIBRARY_THUMBNAIL", "id=${item.id} state=$stateLogStr")
    }

    val showGridFallback = isLocalVideo && (
        currentState == LibraryThumbnailState.MISSING_THUMBNAIL ||
        currentState == LibraryThumbnailState.BLACK_THUMBNAIL ||
        currentState == LibraryThumbnailState.EXTRACTION_FAILED
    )

    android.util.Log.d("FRAME_GRID", "id=${item.id} shown=$showGridFallback")

    val framePages = remember {
        listOf(
            listOf(0.10f, 0.35f, 0.65f, 0.90f),
            listOf(0.20f, 0.45f, 0.75f, 0.95f),
            listOf(0.05f, 0.25f, 0.55f, 0.80f),
            listOf(0.15f, 0.40f, 0.70f, 0.85f),
            listOf(0.02f, 0.30f, 0.60f, 0.98f)
        )
    }
    val totalPages = framePages.size
    var currentPage by remember(item.id) { mutableIntStateOf(0) }

    val cachedPages = remember(item.id, item.localPath) {
        androidx.compose.runtime.mutableStateMapOf<Int, List<com.example.data.ExtractedFrame>>()
    }

    var dragOffsetX by remember { mutableFloatStateOf(0f) }
    var temporarySelectedFrame by remember(item.id, item.thumbnailUrl) { mutableStateOf<String?>(null) }
    val tapBlockerInteractionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() }

    LaunchedEffect(showGridFallback, currentPage, item.id, item.localPath) {
        if (showGridFallback && !cachedPages.containsKey(currentPage)) {
            kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                val percentages = framePages.getOrElse(currentPage) { framePages[0] }
                val frames = com.example.data.MediaThumbnailExtractor.extractFramesAtPercentages(
                    context = context,
                    localPath = item.localPath,
                    mediaId = item.id,
                    percentages = percentages
                )
                kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
                    cachedPages[currentPage] = frames
                }
            }
        }
    }

    BoxWithConstraints(
        modifier = modifier
            .fillMaxWidth()
            .aspectRatio(16f / 9f)
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0xFF14161C))
            .then(
                if (showGridFallback) {
                    Modifier.clickable(
                        interactionSource = tapBlockerInteractionSource,
                        indication = null,
                        onClick = { /* Swallow taps to prevent parent card from consuming them */ }
                    )
                } else Modifier
            )
            .pointerInput(showGridFallback, totalPages) {
                if (showGridFallback && totalPages > 1) {
                    detectHorizontalDragGestures(
                        onDragEnd = {
                            if (dragOffsetX < -30f && currentPage < totalPages - 1) {
                                currentPage++
                            } else if (dragOffsetX > 30f && currentPage > 0) {
                                currentPage--
                            }
                            dragOffsetX = 0f
                        },
                        onDragCancel = { dragOffsetX = 0f },
                        onHorizontalDrag = { change, dragAmount ->
                            change.consume()
                            dragOffsetX += dragAmount
                        }
                    )
                }
            }
    ) {
        val areaWidth = maxWidth
        val areaHeight = maxHeight
        val internalGap = (areaWidth * 0.003f).coerceIn(1.dp, 2.5.dp)

        if (showGridFallback) {
            if (!cachedPages.containsKey(currentPage)) {
                // Lightweight loading state inside thumbnail area while frames generate
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color(0xFF14161C)),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator(
                        color = Color(0xFFFF8A00),
                        modifier = Modifier.size(24.dp),
                        strokeWidth = 2.dp
                    )
                }
            } else {
                // 2x2 Frame Grid Presentation
                AnimatedContent(
                    targetState = currentPage,
                    transitionSpec = {
                        if (targetState > initialState) {
                            (slideInHorizontally(animationSpec = tween(350, easing = EaseOut)) { width -> width } + fadeIn(animationSpec = tween(350))) togetherWith
                            (slideOutHorizontally(animationSpec = tween(350, easing = EaseOut)) { width -> -width } + fadeOut(animationSpec = tween(350)))
                        } else {
                            (slideInHorizontally(animationSpec = tween(350, easing = EaseOut)) { width -> -width } + fadeIn(animationSpec = tween(350))) togetherWith
                            (slideOutHorizontally(animationSpec = tween(350, easing = EaseOut)) { width -> width } + fadeOut(animationSpec = tween(350)))
                        }
                    },
                    modifier = Modifier.fillMaxSize(),
                    label = "GridSlide"
                ) { page ->
                    val currentFrames = cachedPages[page] ?: emptyList()
                    val row1 = listOf(0, 1)
                    val row2 = listOf(2, 3)

                    if (currentFrames.isEmpty()) {
                        // Fallback icon if extraction returned no frames
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(Color(0xFF1E2028)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Movie,
                                contentDescription = "Video Cover",
                                tint = Color(0xFFFF8A00),
                                modifier = Modifier.size(44.dp)
                            )
                        }
                    } else {
                        Column(
                            modifier = Modifier.fillMaxSize(),
                            verticalArrangement = Arrangement.spacedBy(internalGap)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .weight(1f),
                                horizontalArrangement = Arrangement.spacedBy(internalGap)
                            ) {
                                for (idx in row1) {
                                    val frame = currentFrames.getOrNull(idx)
                                    val isSelected = frame != null && frame.filePath == temporarySelectedFrame
                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .fillMaxHeight()
                                            .background(Color(0xFF181A22))
                                            .then(if (isSelected) Modifier.border(2.dp, Color(0xFFFF8A00)) else Modifier)
                                            .clickable(enabled = frame != null) {
                                                frame?.filePath?.let { 
                                                    temporarySelectedFrame = it
                                                    onUpdateThumbnail?.invoke(it) 
                                                }
                                            }
                                    ) {
                                        if (frame != null) {
                                            AsyncImage(
                                                model = frame.filePath,
                                                contentDescription = null,
                                                contentScale = ContentScale.Crop,
                                                modifier = Modifier.fillMaxSize()
                                            )
                                        }
                                    }
                                }
                            }
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .weight(1f),
                                horizontalArrangement = Arrangement.spacedBy(internalGap)
                            ) {
                                for (idx in row2) {
                                    val frame = currentFrames.getOrNull(idx)
                                    val isSelected = frame != null && frame.filePath == temporarySelectedFrame
                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .fillMaxHeight()
                                            .background(Color(0xFF181A22))
                                            .then(if (isSelected) Modifier.border(2.dp, Color(0xFFFF8A00)) else Modifier)
                                            .clickable(enabled = frame != null) {
                                                frame?.filePath?.let { 
                                                    temporarySelectedFrame = it
                                                    onUpdateThumbnail?.invoke(it) 
                                                }
                                            }
                                    ) {
                                        if (frame != null) {
                                            AsyncImage(
                                                model = frame.filePath,
                                                contentDescription = null,
                                                contentScale = ContentScale.Crop,
                                                modifier = Modifier.fillMaxSize()
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // Floating Pagination Dots
                if (totalPages > 1 && (cachedPages[currentPage]?.isNotEmpty() == true)) {
                    val activeDotSize = (areaWidth * 0.017f).coerceIn(5.5.dp, 7.5.dp)
                    val inactiveDotSize = (areaWidth * 0.0135f).coerceIn(4.dp, 5.5.dp)
                    val dotGap = (areaWidth * 0.012f).coerceIn(3.5.dp, 5.5.dp)
                    val bottomPadding = (areaHeight * 0.08f).coerceIn(6.dp, 12.dp)

                    Row(
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .padding(bottom = bottomPadding),
                        horizontalArrangement = Arrangement.spacedBy(dotGap),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        for (i in 0 until totalPages) {
                            val isDotActive = i == currentPage
                            val dotSize by animateDpAsState(
                                targetValue = if (isDotActive) activeDotSize else inactiveDotSize,
                                animationSpec = tween(durationMillis = 180),
                                label = "DotSize_$i"
                            )
                            val dotColor by animateColorAsState(
                                targetValue = if (isDotActive) Color(0xFFFF8A00) else Color.White.copy(alpha = 0.45f),
                                animationSpec = tween(durationMillis = 180),
                                label = "DotColor_$i"
                            )
                            Box(
                                modifier = Modifier
                                    .size(dotSize)
                                    .background(dotColor, CircleShape)
                            )
                        }
                    }
                }
            }
        } else if (item.thumbnailUrl.isNotBlank()) {
            AsyncImage(
                model = coil.request.ImageRequest.Builder(context)
                    .data(item.thumbnailUrl)
                    .crossfade(true)
                    .build(),
                contentDescription = "Cover",
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
        } else {
            // Fallback audio / placeholder
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xFF1E2028)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (isAudio) Icons.Default.MusicNote else Icons.Default.Movie,
                    contentDescription = if (isAudio) "Audio Cover" else "Video Cover",
                    tint = Color(0xFFFF8A00),
                    modifier = Modifier.size(44.dp)
                )
            }
        }

        // Duration badge
        if (durationString.isNotBlank()) {
            Box(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(8.dp)
                    .background(Color.Black.copy(alpha = 0.8f), RoundedCornerShape(4.dp))
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
                Text(
                    text = durationString,
                    color = Color.White,
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = FontWeight.SemiBold,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.5.sp
                    )
                )
            }
        }
    }
}

@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
@Composable
fun LibraryItemCard(
    item: DownloadEntity,
    onPlayClick: () -> Unit,
    onShareClick: () -> Unit,
    onDeleteClick: () -> Unit,
    onConvertAudio: (String) -> Unit,
    onTrimClick: (() -> Unit)? = null,
    onCompressClick: (() -> Unit)? = null,
    onEditMetadataClick: (() -> Unit)? = null,
    onAddToPlaylistClick: (() -> Unit)? = null,
    onUpdateThumbnail: ((String) -> Unit)? = null,
    selected: Boolean = false,
    onSelectedChange: ((Boolean) -> Unit)? = null,
    onLongClick: (() -> Unit)? = null,
    modifier: Modifier = Modifier,
    index: Int = 0
) {
    android.util.Log.d("MEDIA_CARD_RECOMPOSE", "LibraryItemCard recomposed: id=${item.id}, title=${item.title}, author=${item.author}, thumb=${item.thumbnailUrl}")
    var showDeleteConfirmDialog by remember { mutableStateOf(false) }
    var showConvertCodecDialog by remember { mutableStateOf(false) }
    var showOverflowMenu by remember { mutableStateOf(false) }
    var selectedCodec by remember { mutableStateOf("mp3") }

    val slideInOffset = remember { Animatable(100f) }
    val opacity = remember { Animatable(0f) }

    LaunchedEffect(key1 = item.id) {
        val delayTime = (index * 45L).coerceAtMost(250L)
        delay(delayTime)
        launch {
            slideInOffset.animateTo(
                targetValue = 0f,
                animationSpec = spring(
                    dampingRatio = Spring.DampingRatioLowBouncy,
                    stiffness = Spring.StiffnessMediumLow
                )
            )
        }
        launch {
            opacity.animateTo(
                targetValue = 1f,
                animationSpec = tween(durationMillis = 300, easing = LinearOutSlowInEasing)
            )
        }
    }

    val formattedSize = remember(item.fileSize) {
        if (item.fileSize > 0) {
            String.format(Locale.getDefault(), "%.1f MB", item.fileSize.toFloat() / (1024 * 1024))
        } else {
            "3.2 MB"
        }
    }

    val formattedDate = remember(item.downloadedAt) {
        val date = if (item.downloadedAt > 0) Date(item.downloadedAt) else Date()
        SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(date)
    }

    val durationString = item.durationText.ifBlank { "03:28" }
    val authorString = if (item.author.isNotBlank()) "Video by ${item.author}" else "Adaptive Stream"

    Row(
        modifier = modifier
            .fillMaxWidth()
            .graphicsLayer {
                translationX = slideInOffset.value
                alpha = opacity.value
            },
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (onSelectedChange != null) {
            Checkbox(
                checked = selected,
                onCheckedChange = onSelectedChange,
                colors = CheckboxDefaults.colors(
                    checkedColor = Color(0xFFFF8A00),
                    uncheckedColor = SleekTextSecondary
                ),
                modifier = Modifier.padding(end = 8.dp).testTag("checkbox_${item.id}")
            )
        }

        Card(
            modifier = Modifier
                .weight(1f)
                .padding(vertical = 4.dp)
                .combinedClickable(
                    onClick = onPlayClick,
                    onLongClick = { onLongClick?.invoke() }
                ),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF13151B).copy(alpha = 0.75f)),
            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.06f))
        ) {
            Column(
                modifier = Modifier.fillMaxWidth().padding(10.dp)
            ) {
                // Media Thumbnail Area with 2x2 Grid and Floating Pagination Dots
                MediaCardThumbnailArea(
                    item = item,
                    durationString = durationString,
                    onUpdateThumbnail = onUpdateThumbnail
                )
                
                // Details below thumbnail
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 10.dp, bottom = 2.dp, start = 2.dp, end = 2.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    // Channel Avatar placeholder
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF1E2128).copy(alpha = 0.85f)),
                        contentAlignment = Alignment.Center
                    ) {
                        val initial = authorString.firstOrNull()?.toString()?.uppercase() ?: "U"
                        Text(
                            text = initial,
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                    }
                    
                    Column(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(3.dp)
                    ) {
                        Text(
                            text = item.title,
                            color = Color(0xFFF2F4F8),
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.5.sp,
                                lineHeight = 20.sp
                            ),
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "$authorString • $formattedSize • $formattedDate",
                            color = Color(0xFF9AA0A6),
                            style = MaterialTheme.typography.bodySmall.copy(
                                fontWeight = FontWeight.Normal,
                                fontSize = 12.5.sp
                            ),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    
                    // Card Action Button (three-dots)
                    Box {
                        Surface(
                            shape = CircleShape,
                            color = Color(0xFF181A22).copy(alpha = 0.55f),
                            border = BorderStroke(0.5.dp, Color.White.copy(alpha = 0.06f)),
                            modifier = Modifier
                                .size(34.dp)
                                .clip(CircleShape)
                                .clickable { showOverflowMenu = true }
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.MoreVert,
                                    contentDescription = "More Options",
                                    tint = Color.White,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }

                        DropdownMenu(
                            expanded = showOverflowMenu,
                            onDismissRequest = { showOverflowMenu = false },
                            modifier = Modifier
                                .background(Color(0xFF161820))
                                .border(1.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(12.dp))
                        ) {
                            DropdownMenuItem(
                                text = { Text("Play Video", color = Color.White) },
                                leadingIcon = { Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Color(0xFFFF8A00)) },
                                onClick = {
                                    showOverflowMenu = false
                                    onPlayClick()
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Trim & Cut Clip", color = Color.White) },
                                leadingIcon = { Icon(Icons.Default.ContentCut, contentDescription = null, tint = Color(0xFFFF8A00)) },
                                onClick = {
                                    showOverflowMenu = false
                                    onTrimClick?.invoke()
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Compress Video", color = Color.White) },
                                leadingIcon = { Icon(Icons.Default.Compress, contentDescription = null, tint = Color(0xFFFF8A00)) },
                                onClick = {
                                    showOverflowMenu = false
                                    onCompressClick?.invoke()
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Extract Audio", color = Color.White) },
                                leadingIcon = { Icon(Icons.Default.MusicNote, contentDescription = null, tint = Color(0xFFFF8A00)) },
                                onClick = {
                                    showOverflowMenu = false
                                    showConvertCodecDialog = true
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Edit ID3 Tags & Cover", color = Color.White) },
                                leadingIcon = { Icon(Icons.Default.Edit, contentDescription = null, tint = Color(0xFFFF8A00)) },
                                onClick = {
                                    showOverflowMenu = false
                                    onEditMetadataClick?.invoke()
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Add to Playlist", color = Color.White) },
                                leadingIcon = { Icon(Icons.Default.PlaylistAdd, contentDescription = null, tint = Color(0xFF00E676)) },
                                onClick = {
                                    showOverflowMenu = false
                                    onAddToPlaylistClick?.invoke()
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Share", color = Color.White) },
                                leadingIcon = { Icon(Icons.Default.Share, contentDescription = null, tint = Color(0xFF3BA5FF)) },
                                onClick = {
                                    showOverflowMenu = false
                                    onShareClick()
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Delete", color = Color(0xFFFF4C4C)) },
                                leadingIcon = { Icon(Icons.Default.Delete, contentDescription = null, tint = Color(0xFFFF4C4C)) },
                                onClick = {
                                    showOverflowMenu = false
                                    showDeleteConfirmDialog = true
                                }
                            )
                        }
                    }
                }
            }
        }
    }

    if (showDeleteConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirmDialog = false },
            title = { Text("Delete downloaded file?", color = SleekTextPrimary, fontWeight = FontWeight.Bold) },
            text = { Text("This will permanently delete this video from your device storage and library cache.", color = SleekTextSecondary) },
            confirmButton = {
                TextButton(
                    onClick = {
                        showDeleteConfirmDialog = false
                        onDeleteClick()
                    }
                ) {
                    Icon(Icons.Default.Delete, contentDescription = "Delete", tint = CrimsonFailure)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirmDialog = false }) {
                    Icon(Icons.Default.Close, contentDescription = "Cancel", tint = SleekTextSecondary)
                }
            },
            containerColor = SleekCard,
            titleContentColor = SleekTextPrimary,
            textContentColor = SleekTextSecondary
        )
    }
    if (showConvertCodecDialog) {
        AlertDialog(
            onDismissRequest = { showConvertCodecDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(imageVector = Icons.Default.MusicNote, contentDescription = null, tint = SleekPurpleLight)
                    Text("Select Audio Codec Format", color = SleekTextPrimary, fontWeight = FontWeight.Bold)
                }
            },
            text = {
                Column(
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "Extract and convert the audio stream from this file into your preferred container / codec format:",
                        color = SleekTextSecondary,
                        fontSize = 13.sp,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                    val codecs = listOf(
                        "mp3" to "MP3 (Lame - High Compatibility)",
                        "m4a" to "M4A (AAC - Compact Quality)",
                        "aac" to "AAC (Native Audio Stream)",
                        "wav" to "WAV (Lossless Raw PCM)",
                        "flac" to "FLAC (High Fidelity Lossless)",
                        "opus" to "OPUS (Next-Gen low bitrate)",
                        "ogg" to "OGG Vorbis (Open Standard)"
                    )
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 240.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        items(codecs) { (key, label) ->
                            val isSelected = selectedCodec == key
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isSelected) SleekPurpleContainer.copy(alpha = 0.2f) else Color.Transparent)
                                    .clickable { selectedCodec = key }
                                    .padding(horizontal = 12.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                RadioButton(
                                    selected = isSelected,
                                    onClick = { selectedCodec = key },
                                    colors = RadioButtonDefaults.colors(
                                        selectedColor = SleekPurpleLight,
                                        unselectedColor = SleekTextSecondary
                                    )
                                )
                                Text(
                                    text = label,
                                    color = if (isSelected) SleekPurpleLight else SleekTextPrimary,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    fontSize = 14.sp
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showConvertCodecDialog = false
                        onConvertAudio(selectedCodec)
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color.White,
                        contentColor = Color.Black
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.LibraryMusic, contentDescription = "Extract")
                }
            },
            dismissButton = {
                TextButton(onClick = { showConvertCodecDialog = false }) {
                    Icon(Icons.Default.Close, contentDescription = "Cancel", tint = SleekTextSecondary)
                }
            },
            containerColor = SleekCard,
            titleContentColor = SleekTextPrimary,
            textContentColor = SleekTextSecondary
        )
    }
}

@Composable
fun HistoryTab(
    historyList: List<com.example.data.BrowsingHistoryEntity>,
    onPlayClick: (com.example.data.BrowsingHistoryEntity) -> Unit,
    onDeleteClick: (String) -> Unit,
    onClearAllClick: () -> Unit,
    onRevisitClick: (com.example.data.BrowsingHistoryEntity) -> Unit
) {
    val isTabletOrWide = androidx.compose.ui.platform.LocalConfiguration.current.screenWidthDp >= 600
    var showConfirmClearAll by remember { mutableStateOf(false) }

    if (showConfirmClearAll) {
        AlertDialog(
            onDismissRequest = { showConfirmClearAll = false },
            title = { Text("Clear Entire History?", fontWeight = FontWeight.Bold, color = SleekTextPrimary) },
            text = { Text("Are you sure you want to permanently clear your recently streamed/downloaded URLs history? This cannot be undone.", color = SleekTextSecondary) },
            confirmButton = {
                TextButton(onClick = {
                    showConfirmClearAll = false
                    onClearAllClick()
                }) {
                    Icon(Icons.Default.DeleteSweep, contentDescription = "Clear All", tint = CrimsonFailure)
                }
            },
            dismissButton = {
                TextButton(onClick = { showConfirmClearAll = false }) {
                    Icon(Icons.Default.Close, contentDescription = "Cancel", tint = SleekTextSecondary)
                }
            },
            containerColor = SleekCard,
            shape = RoundedCornerShape(16.dp)
        )
    }

    val configuration = androidx.compose.ui.platform.LocalConfiguration.current
    val screenWidthDp = configuration.screenWidthDp
    val columns = when {
        screenWidthDp < 600 -> 1
        screenWidthDp < 840 -> 2
        screenWidthDp < 1200 -> 3
        else -> 4
    }
    val maxContentWidth = (columns * 460).dp

    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier
                .fillMaxHeight()
                .widthIn(max = maxContentWidth)
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(top = 24.dp) // Generous padding to start below the floating top islands
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "RECENT HISTORY (${historyList.size})",
                    style = MaterialTheme.typography.titleSmall.copy(
                        color = SleekPurpleDark,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        letterSpacing = 1.sp,
                        fontSize = responsiveSp(18f, 26f)
                    ),
                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 4.dp)
                )

                if (historyList.isNotEmpty()) {
                    TextButton(
                        onClick = { showConfirmClearAll = true },
                        colors = ButtonDefaults.textButtonColors(contentColor = CrimsonFailure),
                        modifier = Modifier.height(48.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "Clear All",
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Clear All", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                }
            }

            if (historyList.isEmpty()) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = Icons.Default.History,
                        contentDescription = "Empty History",
                        tint = SleekTextMuted.copy(alpha = 0.5f),
                        modifier = Modifier.size(80.dp)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "NO RECENT HISTORY",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = SleekTextPrimary,
                            letterSpacing = 1.sp
                        )
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "URLs of videos you download or stream will appear here so you can revisit them anytime.",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = SleekTextSecondary,
                            textAlign = TextAlign.Center
                        ),
                        modifier = Modifier.padding(horizontal = 16.dp)
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = 24.dp, end = 24.dp, top = 24.dp, bottom = 140.dp),
                    verticalArrangement = Arrangement.spacedBy(24.dp)
                ) {
                    if (columns == 1) {
                        itemsIndexed(historyList, key = { index, item -> item.id + "_$index" }) { index, item ->
                            HistoryItemCard(
                                item = item,
                                index = index,
                                onPlayClick = { onPlayClick(item) },
                                onRevisitClick = { onRevisitClick(item) },
                                onDeleteClick = { onDeleteClick(item.id) },
                                modifier = Modifier.animateItem()
                            )
                        }
                    } else {
                        val chunks = historyList.chunked(columns)
                        itemsIndexed(chunks, key = { index, _ -> "history_chunk_$index" }) { index, chunk ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(24.dp)
                            ) {
                                chunk.forEachIndexed { chunkIndex, item ->
                                    Box(modifier = Modifier.weight(1f)) {
                                        HistoryItemCard(
                                            item = item,
                                            index = index * columns + chunkIndex,
                                            onPlayClick = { onPlayClick(item) },
                                            onRevisitClick = { onRevisitClick(item) },
                                            onDeleteClick = { onDeleteClick(item.id) },
                                            modifier = Modifier.animateItem()
                                        )
                                    }
                                }
                                val emptySlots = columns - chunk.size
                                repeat(emptySlots) {
                                    Spacer(modifier = Modifier.weight(1f))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun HistoryItemCard(
    item: com.example.data.BrowsingHistoryEntity,
    onPlayClick: () -> Unit,
    onRevisitClick: () -> Unit,
    onDeleteClick: () -> Unit,
    modifier: Modifier = Modifier,
    index: Int = 0
) {
    var showDeleteConfirmDialog by remember { mutableStateOf(false) }
    var showOverflowMenu by remember { mutableStateOf(false) }

    val slideInOffset = remember { Animatable(100f) }
    val opacity = remember { Animatable(0f) }

    LaunchedEffect(key1 = item.id) {
        val delayTime = (index * 45L).coerceAtMost(250L)
        delay(delayTime)
        launch {
            slideInOffset.animateTo(
                targetValue = 0f,
                animationSpec = spring(
                    dampingRatio = Spring.DampingRatioLowBouncy,
                    stiffness = Spring.StiffnessMediumLow
                )
            )
        }
        launch {
            opacity.animateTo(
                targetValue = 1f,
                animationSpec = tween(durationMillis = 300, easing = LinearOutSlowInEasing)
            )
        }
    }

    if (showDeleteConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirmDialog = false },
            title = { Text("Delete History Record?", fontWeight = FontWeight.Bold, color = SleekTextPrimary) },
            text = { Text("Are you sure you want to remove this item from your stream history?", color = SleekTextSecondary) },
            confirmButton = {
                TextButton(onClick = {
                    showDeleteConfirmDialog = false
                    onDeleteClick()
                }) {
                    Icon(Icons.Default.Delete, contentDescription = "Remove", tint = CrimsonFailure)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirmDialog = false }) {
                    Icon(Icons.Default.Close, contentDescription = "Cancel", tint = SleekTextSecondary)
                }
            },
            containerColor = SleekCard,
            shape = RoundedCornerShape(16.dp)
        )
    }

    val formattedDate = remember(item.browsedAt) {
        val sdf = java.text.SimpleDateFormat("MMM dd, HH:mm", Locale.getDefault())
        sdf.format(java.util.Date(item.browsedAt))
    }
    val durationString = item.durationText.orEmpty().ifBlank { "03:28" }
    val authorString = if (item.author.isNullOrBlank()) "Unknown Creator" else item.author

    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp)
            .graphicsLayer {
                translationX = slideInOffset.value
                alpha = opacity.value
            }
            .clickable(onClick = onPlayClick),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent)
    ) {
        Column(
            modifier = Modifier.fillMaxWidth()
        ) {
            // Thumbnail
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(16f / 9f)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color.Black)
            ) {
                if (!item.thumbnailUrl.isNullOrEmpty()) {
                    AsyncImage(
                        model = item.thumbnailUrl,
                        contentDescription = "Cover",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                } else {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color(0xFF2A2D35)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.VideoLibrary,
                            contentDescription = "Video Cover",
                            tint = SleekPurpleLight,
                            modifier = Modifier.size(48.dp)
                        )
                    }
                }

                if (durationString.isNotBlank()) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .padding(8.dp)
                            .background(Color.Black.copy(alpha = 0.8f), RoundedCornerShape(4.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = durationString,
                            color = Color.White,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.SemiBold,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 11.sp
                            )
                        )
                    }
                }
            }

            // Details below thumbnail
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 12.dp, bottom = 4.dp, start = 4.dp, end = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.Top
            ) {
                // Channel Avatar placeholder
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .background(Color(0xFF2D2D2D), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    val initial = authorString.firstOrNull()?.toString()?.uppercase() ?: "U"
                    Text(
                        text = initial,
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                }

                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = item.title,
                        color = Color.White,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            lineHeight = 22.sp
                        ),
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = "$authorString • $formattedDate",
                        color = Color(0xFFB0B0B0),
                        style = MaterialTheme.typography.bodyMedium.copy(
                            fontWeight = FontWeight.Normal,
                            fontSize = 13.sp
                        ),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Box {
                    IconButton(
                        onClick = { showOverflowMenu = true },
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.MoreVert,
                            contentDescription = "More Options",
                            tint = Color.White
                        )
                    }
                    DropdownMenu(
                        expanded = showOverflowMenu,
                        onDismissRequest = { showOverflowMenu = false },
                        modifier = Modifier.background(Color(0xFF1E2026))
                    ) {
                        DropdownMenuItem(
                            text = { Text("Stream Now", color = Color.White) },
                            leadingIcon = { Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Color(0xFFFF8A00)) },
                            onClick = {
                                showOverflowMenu = false
                                onPlayClick()
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Analyze Url", color = Color.White) },
                            leadingIcon = { Icon(Icons.Default.Refresh, contentDescription = null, tint = SleekPurpleLight) },
                            onClick = {
                                showOverflowMenu = false
                                onRevisitClick()
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Remove from History", color = Color(0xFFFF4C4C)) },
                            leadingIcon = { Icon(Icons.Default.Delete, contentDescription = null, tint = Color(0xFFFF4C4C)) },
                            onClick = {
                                showOverflowMenu = false
                                showDeleteConfirmDialog = true
                            }
                        )
                    }
                }
            }
        }
    }
}

fun triggerClickHaptic(view: android.view.View) {
    try {
        val prefs = view.context.getSharedPreferences("꒯ꄲꅐꋊ꒒ꌦPrefs", android.content.Context.MODE_PRIVATE)
        if (prefs.getBoolean("enableHapticFeedback", true)) {
            view.performHapticFeedback(
                android.view.HapticFeedbackConstants.KEYBOARD_TAP,
                android.view.HapticFeedbackConstants.FLAG_IGNORE_GLOBAL_SETTING
            )
        }
    } catch (_: Exception) {}
}

@Composable
fun SmoothToggle(
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    val view = androidx.compose.ui.platform.LocalView.current
    val offset by animateFloatAsState(
        targetValue = if (checked) 24f else 4f,
        animationSpec = tween(durationMillis = 250),
        label = "toggle_offset"
    )
    val trackColor = if (checked) SleekPurpleDark else SleekCardDark.copy(alpha = 0.5f)
    val thumbColor = if (checked) SleekBg else SleekTextSecondary.copy(alpha = 0.7f)
    Box(
        modifier = modifier
            .size(width = 50.dp, height = 28.dp)
            .clip(RoundedCornerShape(50))
            .background(trackColor)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null
            ) {
                triggerClickHaptic(view)
                onCheckedChange(!checked)
            }
    ) {
        Box(
            modifier = Modifier
                .offset(x = offset.dp)
                .align(Alignment.CenterStart)
                .size(20.dp)
                .clip(CircleShape)
                .background(thumbColor)
        )
    }
}
@Composable
fun SettingRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    description: String,
    onClick: (() -> Unit)? = null,
    showDivider: Boolean = true,
    action: @Composable RowScope.() -> Unit
) {
    val view = androidx.compose.ui.platform.LocalView.current
    Column {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .then(
                    if (onClick != null) Modifier.clickable(onClick = {
                        triggerClickHaptic(view)
                        onClick()
                    })
                    else Modifier
                )
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .background(SleekPurpleContainer.copy(alpha = 0.3f), CircleShape)
                    .border(1.dp, SleekPurpleLight.copy(alpha = 0.15f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = SleekPurpleLight,
                    modifier = Modifier.size(18.dp)
                )
            }
            Spacer(modifier = Modifier.width(14.dp))
            Column(
                modifier = Modifier
                    .weight(1f)
                    .padding(end = 12.dp)
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        letterSpacing = 0.1.sp
                    ),
                    color = SleekTextPrimary
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = description,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        fontSize = 11.sp,
                        lineHeight = 15.sp
                    ),
                    color = SleekTextSecondary
                )
            }
            Row(
                verticalAlignment = Alignment.CenterVertically,
                content = action
            )
        }
        if (showDivider) {
            HorizontalDivider(
                color = SleekBorderColor.copy(alpha = 0.2f),
                thickness = 0.5.dp,
                modifier = Modifier.padding(horizontal = 16.dp)
            )
        }
    }
}
@Composable
fun SettingsSectionCard(
    title: String,
    content: @Composable ColumnScope.() -> Unit
) {
    Column(
        verticalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.labelLarge.copy(
                fontWeight = FontWeight.Bold,
                color = SleekPurpleDark,
                letterSpacing = 1.sp
            ),
            modifier = Modifier.padding(start = 4.dp, bottom = 4.dp)
        )
        Card(
            colors = CardDefaults.cardColors(containerColor = SleekCard),
            shape = RoundedCornerShape(20.dp),
            border = BorderStroke(1.dp, SleekBorderColor.copy(alpha = 0.35f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(vertical = 4.dp)
            ) {
                content()
            }
        }
    }
}
@Composable
fun SettingsTab(
    downloads: List<com.example.data.DownloadEntity>,
    onClearAllDownloads: () -> Unit,
    viewModel: VideoDownloaderViewModel
) {
    com.example.ui.settings.HierarchicalSettingsScreen(
        downloads = downloads,
        onClearAllDownloads = onClearAllDownloads,
        viewModel = viewModel
    )
}

fun isAudioMedia(media: DownloadEntity): Boolean {
    val title = media.title.lowercase()
    val path = media.localPath.lowercase()

    if (title.contains("[streaming audio]")) return true
    if (title.contains("[streaming video]")) return false
    if (title.contains("(audio)") || title.contains(" [audio]")) return true

    val cleanPath = path.substringBefore("?").substringBefore("#")

    if (cleanPath.endsWith(".mp3") ||
        cleanPath.endsWith(".m4a") ||
        cleanPath.endsWith(".aac") ||
        cleanPath.endsWith(".wav") ||
        cleanPath.endsWith(".flac") ||
        cleanPath.endsWith(".opus") ||
        cleanPath.endsWith(".ogg") ||
        cleanPath.endsWith(".wma")) {
        return true
    }

    if (cleanPath.endsWith(".mp4") ||
        cleanPath.endsWith(".mkv") ||
        cleanPath.endsWith(".webm") ||
        cleanPath.endsWith(".avi") ||
        cleanPath.endsWith(".mov") ||
        cleanPath.endsWith(".3gp") ||
        cleanPath.endsWith(".flv") ||
        cleanPath.endsWith(".ts")) {
        return false
    }

    if (cleanPath.contains("/audio/") || cleanPath.endsWith("/audio")) {
        return true
    }

    if (path.contains("mime=audio/") || path.contains("type=audio/")) {
        return true
    }

    return false
}

fun formatTimeMs(ms: Long): String {
    val totalSeconds = (ms / 1000).coerceAtLeast(0)
    val seconds = totalSeconds % 60
    val minutes = (totalSeconds / 60) % 60
    val hours = totalSeconds / 3600
    return if (hours > 0) {
        String.format("%d:%02d:%02d", hours, minutes, seconds)
    } else {
        String.format("%02d:%02d", minutes, seconds)
    }
}

fun formatBytes(bytes: Long): String {
    if (bytes <= 0L) return "0 B"
    val kb = bytes / 1024.0
    val mb = kb / 1024.0
    val gb = mb / 1024.0
    return when {
        gb >= 1.0 -> String.format(Locale.US, "%.2f GB", gb)
        mb >= 1.0 -> String.format(Locale.US, "%.1f MB", mb)
        kb >= 1.0 -> String.format(Locale.US, "%.1f KB", kb)
        else -> "$bytes B"
    }
}

@Composable
fun AudioEqualizerVisualizer(
    isPlaying: Boolean,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "eq")
    val barHeights = (0..15).map { index ->
        if (isPlaying) {
            val duration = remember(index) { 300 + (index * 70) % 500 }
            val anim by infiniteTransition.animateFloat(
                initialValue = 0.15f,
                targetValue = 0.95f,
                animationSpec = infiniteRepeatable(
                    animation = tween(duration, easing = LinearOutSlowInEasing),
                    repeatMode = RepeatMode.Reverse
                ),
                label = "bar_$index"
            )
            anim
        } else {
            0.2f
        }
    }

    Row(
        modifier = modifier,
        horizontalArrangement = Arrangement.spacedBy(4.dp),
        verticalAlignment = Alignment.Bottom
    ) {
        barHeights.forEach { heightFactor ->
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight(heightFactor)
                    .clip(RoundedCornerShape(2.dp))
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(SleekPurpleDark, SleekPurpleLight)
                        )
                    )
            )
        }
    }
}

@Composable
fun SleekAudioMusicPlayer(
    media: DownloadEntity,
    isFullscreen: Boolean,
    onToggleFullscreen: () -> Unit,
    onClose: () -> Unit,
    viewModel: VideoDownloaderViewModel? = null
) {
    val context = LocalContext.current
    val currentWaveformData = viewModel?.currentWaveformData?.collectAsStateWithLifecycle()?.value
    val mediaPlayer = remember { android.media.MediaPlayer() }
    var isPrepared by remember { mutableStateOf(false) }
    var isPlaying by remember { mutableStateOf(false) }
    var currentPosMs by remember { mutableLongStateOf(0L) }
    var durationMs by remember { mutableLongStateOf(0L) }
    var isLooping by remember { mutableStateOf(false) }
    var speed by remember { mutableFloatStateOf(1.0f) }

    // Advanced audio player states
    var isMuted by remember { mutableStateOf(false) }
    var sleepTimerMinutes by remember { mutableIntStateOf(0) }
    var sleepSecondsRemaining by remember { mutableIntStateOf(0) }
    var showSleepTimerDialog by remember { mutableStateOf(false) }
    var soundPreset by remember { mutableStateOf("Normal") }
    var toastMessage by remember { mutableStateOf<String?>(null) }

    val mediaUri = remember(media.localPath, media.id) {
        if (media.id.startsWith("device_audio_")) {
            val audioId = media.id.substringAfter("device_audio_").toLongOrNull() ?: 0L
            android.content.ContentUris.withAppendedId(
                android.provider.MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                audioId
            )
        } else if (media.id.startsWith("device_video_")) {
            val videoId = media.id.substringAfter("device_video_").toLongOrNull() ?: 0L
            android.content.ContentUris.withAppendedId(
                android.provider.MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                videoId
            )
        } else if (media.localPath.startsWith("http://") || media.localPath.startsWith("https://")) {
            android.net.Uri.parse(media.localPath)
        } else {
            val file = java.io.File(media.localPath)
            if (file.exists()) {
                android.net.Uri.fromFile(file)
            } else {
                android.net.Uri.parse(media.localPath)
            }
        }
    }

    val streamHeaders = remember(media.localPath) {
        val map = HashMap<String, String>()
        if (media.localPath.contains("googlevideo") || media.localPath.contains("youtube")) {
            map["User-Agent"] = "Mozilla/5.0 (Linux; Android 11; Pixel 5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Mobile Safari/537.36"
            map["Referer"] = "https://www.youtube.com/"
        } else if (media.localPath.contains("instagram")) {
            map["User-Agent"] = "Mozilla/5.0 (iPhone; CPU iPhone OS 16_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1"
            map["Referer"] = "https://www.instagram.com/"
        } else if (media.localPath.contains("tiktok")) {
            map["User-Agent"] = "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
            map["Referer"] = "https://www.tiktok.com/"
        } else {
            map["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
            map["Referer"] = "https://www.google.com/"
        }
        map["Accept"] = "*/*"
        map
    }

    DisposableEffect(mediaUri) {
        if (com.example.media.BackgroundPlaybackManager.isBackgroundActive.value) {
            com.example.media.BackgroundPlaybackManager.stop(context)
        }
        try {
            mediaPlayer.reset()
            if (media.localPath.startsWith("http://") || media.localPath.startsWith("https://")) {
                mediaPlayer.setDataSource(context, mediaUri, streamHeaders)
            } else {
                val file = java.io.File(media.localPath)
                if (file.exists()) {
                    mediaPlayer.setDataSource(file.absolutePath)
                } else {
                    mediaPlayer.setDataSource(context, mediaUri)
                }
            }
            mediaPlayer.prepareAsync()
            mediaPlayer.setOnPreparedListener { mp ->
                isPrepared = true
                durationMs = mp.duration.toLong().coerceAtLeast(0L)
                mp.start()
                isPlaying = true
            }
            mediaPlayer.setOnCompletionListener {
                if (!isLooping) {
                    isPlaying = false
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        onDispose {
            try {
                if (mediaPlayer.isPlaying) mediaPlayer.stop()
                mediaPlayer.release()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    LaunchedEffect(isPlaying, isPrepared) {
        while (isPlaying && isPrepared) {
            try {
                currentPosMs = mediaPlayer.currentPosition.toLong()
            } catch (e: Exception) {}
            kotlinx.coroutines.delay(200)
        }
    }

    // Sound mute control
    LaunchedEffect(isMuted) {
        try {
            if (isMuted) {
                mediaPlayer.setVolume(0f, 0f)
            } else {
                mediaPlayer.setVolume(1f, 1f)
            }
        } catch (e: Exception) {}
    }

    val lifecycleOwner = androidx.lifecycle.compose.LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner, mediaPlayer) {
        val observer = androidx.lifecycle.LifecycleEventObserver { _, event ->
            val activity = context as? android.app.Activity
            val isActivityValid = activity == null || (!activity.isFinishing && !activity.isDestroyed)

            when (event) {
                androidx.lifecycle.Lifecycle.Event.ON_PAUSE,
                androidx.lifecycle.Lifecycle.Event.ON_STOP -> {
                    val bgAllowed = viewModel?.youtubeBackgroundPlayEnabled?.value ?: true
                    val isAppLeaving = activity != null && !activity.isChangingConfigurations
                    if (bgAllowed && isAppLeaving && isPlaying) {
                        val currentPos = try { mediaPlayer.currentPosition.toLong().coerceAtLeast(0L) } catch (e: Exception) { 0L }
                        viewModel?.startBackgroundPlayback(media, currentPos, speed) ?: run {
                            com.example.media.BackgroundPlaybackManager.startBackgroundPlayback(context, media, currentPos, speed)
                        }
                        try {
                            if (mediaPlayer.isPlaying) mediaPlayer.pause()
                        } catch (e: Exception) {}
                    }
                }
                androidx.lifecycle.Lifecycle.Event.ON_RESUME -> {
                    if (isActivityValid) {
                        if (com.example.media.BackgroundPlaybackManager.isBackgroundActive.value) {
                            if (com.example.media.BackgroundPlaybackManager.currentMedia.value?.id == media.id) {
                                val bgPos = com.example.media.BackgroundPlaybackManager.currentPositionMs.value
                                val bgPlaying = com.example.media.BackgroundPlaybackManager.isPlaying.value
                                com.example.media.BackgroundPlaybackManager.stop(context)
                                if (bgPos > 0L) {
                                    try { mediaPlayer.seekTo(bgPos.toInt()) } catch (e: Exception) {}
                                }
                                if (bgPlaying && isPrepared) {
                                    try { mediaPlayer.start(); isPlaying = true } catch (e: Exception) {}
                                }
                            } else {
                                com.example.media.BackgroundPlaybackManager.stop(context)
                            }
                        }
                    }
                }
                else -> {}
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    // Sleep Timer background countdown with smooth volume attenuation (fade-out)
    LaunchedEffect(sleepTimerMinutes, isPlaying, isMuted) {
        if (sleepTimerMinutes > 0) {
            if (sleepSecondsRemaining <= 0) {
                sleepSecondsRemaining = sleepTimerMinutes * 60
            }
            val fadeDurationSecs = 30
            while (sleepSecondsRemaining > 0 && isPlaying) {
                kotlinx.coroutines.delay(1000)
                sleepSecondsRemaining--

                if (!isMuted) {
                    if (sleepSecondsRemaining <= fadeDurationSecs) {
                        val fadeFactor = (sleepSecondsRemaining.toFloat() / fadeDurationSecs).coerceIn(0f, 1f)
                        mediaPlayer.setVolume(fadeFactor, fadeFactor)
                    } else {
                        mediaPlayer.setVolume(1.0f, 1.0f)
                    }
                }
            }
            if (sleepSecondsRemaining <= 0 && isPlaying) {
                isPlaying = false
                if (mediaPlayer.isPlaying) {
                    mediaPlayer.pause()
                }
                sleepTimerMinutes = 0
                if (!isMuted) {
                    mediaPlayer.setVolume(1.0f, 1.0f)
                }
                toastMessage = "Sleep Timer Expired (Fade Out Complete)"
            }
        } else {
            sleepSecondsRemaining = 0
            if (!isMuted) {
                mediaPlayer.setVolume(1.0f, 1.0f)
            }
        }
    }

    LaunchedEffect(sleepTimerMinutes) {
        if (sleepTimerMinutes > 0) {
            toastMessage = "Sleep Timer: ${sleepTimerMinutes}m"
        } else if (sleepTimerMinutes == 0 && sleepSecondsRemaining == 0 && isPrepared) {
            toastMessage = "Sleep Timer Off"
        }
    }

    LaunchedEffect(soundPreset) {
        if (soundPreset != "Normal") {
            toastMessage = "Preset: $soundPreset"
        }
    }

    LaunchedEffect(toastMessage) {
        if (toastMessage != null) {
            kotlinx.coroutines.delay(1500)
            toastMessage = null
        }
    }

    var offsetX by remember { mutableStateOf(0f) }
    var offsetY by remember { mutableStateOf(0f) }

    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = if (isFullscreen) Alignment.Center else Alignment.BottomEnd
    ) {
        if (isFullscreen) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.95f))
            )
        }

        Card(
            modifier = if (isFullscreen) {
                Modifier.fillMaxSize()
            } else {
                Modifier
                    .offset { IntOffset(offsetX.roundToInt(), offsetY.roundToInt()) }
                    .padding(16.dp)
                    .width(320.dp)
                    .height(200.dp)
                    .pointerInput(Unit) {
                        detectDragGestures { change, dragAmount ->
                            change.consume()
                            offsetX += dragAmount.x
                            offsetY += dragAmount.y
                        }
                    }
                    .clip(RoundedCornerShape(20.dp))
                    .border(1.dp, SleekPurpleDark.copy(alpha = 0.5f), RoundedCornerShape(20.dp))
                    .shadow(20.dp, RoundedCornerShape(20.dp))
            },
            colors = CardDefaults.cardColors(containerColor = SleekCardDark),
            shape = if (isFullscreen) RoundedCornerShape(0.dp) else RoundedCornerShape(20.dp)
        ) {
            Box(modifier = Modifier.fillMaxSize()) {
                if (!isPrepared) {
                    SkeletonAudioPlayerOverlay(
                        isFullscreen = isFullscreen,
                        modifier = Modifier.fillMaxSize()
                    )
                } else if (!isFullscreen) {
                    // Mini Floating Audio Player
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(12.dp),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    // Top header
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = Icons.Default.MusicNote,
                                contentDescription = "Music",
                                tint = SleekPurpleLight,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = media.title.removePrefix("[Streaming Audio] ").trim(),
                                style = MaterialTheme.typography.bodySmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = SleekTextPrimary
                                ),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = onToggleFullscreen, modifier = Modifier.size(28.dp)) {
                                Icon(Icons.Default.Fullscreen, contentDescription = "Expand", tint = SleekTextPrimary, modifier = Modifier.size(18.dp))
                            }
                            IconButton(onClick = onClose, modifier = Modifier.size(28.dp)) {
                                Icon(Icons.Default.Close, contentDescription = "Close", tint = CrimsonFailure, modifier = Modifier.size(18.dp))
                            }
                        }
                    }

                    // Content row
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Artwork or vinyl
                        val infiniteTransition = rememberInfiniteTransition(label = "mini_disc")
                        val discAngle by infiniteTransition.animateFloat(
                            initialValue = 0f,
                            targetValue = 360f,
                            animationSpec = infiniteRepeatable(
                                animation = tween(6000, easing = LinearEasing)
                            ), label = "disc_angle"
                        )

                        Box(
                            modifier = Modifier
                                .size(56.dp)
                                .clip(CircleShape)
                                .background(SleekBg)
                                .border(2.dp, SleekPurpleLight, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            if (media.thumbnailUrl.isNotBlank()) {
                                coil.compose.AsyncImage(
                                    model = media.thumbnailUrl,
                                    contentDescription = "Cover",
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .clip(CircleShape)
                                        .rotate(if (isPlaying) discAngle else 0f)
                                )
                            } else {
                                Icon(
                                    imageVector = Icons.Default.MusicNote,
                                    contentDescription = null,
                                    tint = SleekPurpleLight,
                                    modifier = Modifier
                                        .size(28.dp)
                                        .rotate(if (isPlaying) discAngle else 0f)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (media.author.isNotBlank()) media.author else "Audio Track",
                                style = MaterialTheme.typography.labelSmall,
                                color = SleekTextSecondary,
                                maxLines = 1
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            // Visualizer bars
                            AudioEqualizerVisualizer(
                                isPlaying = isPlaying,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(24.dp)
                            )
                        }
                    }

                    // Seekbar & Controls
                    Column(modifier = Modifier.fillMaxWidth()) {
                        val progress = if (durationMs > 0) (currentPosMs.toFloat() / durationMs.toFloat()).coerceIn(0f, 1f) else 0f
                        LinearProgressIndicator(
                            progress = { progress },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(4.dp)
                                .clip(RoundedCornerShape(2.dp)),
                            color = SleekPurpleLight,
                            trackColor = SleekBorderColor
                        )

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "${formatTimeMs(currentPosMs)} / ${formatTimeMs(durationMs)}",
                                style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                                color = SleekTextMuted
                            )

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                IconButton(
                                    onClick = {
                                        val target = (currentPosMs - 10000L).coerceAtLeast(0L)
                                        mediaPlayer.seekTo(target.toInt())
                                        currentPosMs = target
                                    },
                                    modifier = Modifier.size(28.dp)
                                ) {
                                    Icon(Icons.Default.FastRewind, contentDescription = "-10s", tint = SleekTextPrimary, modifier = Modifier.size(16.dp))
                                }

                                IconButton(
                                    onClick = {
                                        if (isPlaying) {
                                            mediaPlayer.pause()
                                            isPlaying = false
                                        } else {
                                            mediaPlayer.start()
                                            isPlaying = true
                                        }
                                    },
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(
                                        imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                        contentDescription = "Play/Pause",
                                        tint = SleekPurpleLight,
                                        modifier = Modifier.size(24.dp)
                                    )
                                }

                                IconButton(
                                    onClick = {
                                        val target = (currentPosMs + 10000L).coerceAtMost(durationMs)
                                        mediaPlayer.seekTo(target.toInt())
                                        currentPosMs = target
                                    },
                                    modifier = Modifier.size(28.dp)
                                ) {
                                    Icon(Icons.Default.FastForward, contentDescription = "+10s", tint = SleekTextPrimary, modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }
                }
            } else {
                // Full Screen Music Player Screen
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(
                                    SleekBg,
                                    SleekCardDark,
                                    Color.Black
                                )
                            )
                        )
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    // Floating Header Bar
                    Surface(
                        modifier = Modifier
                            .statusBarsPadding()
                            .fillMaxWidth()
                            .shadow(
                                elevation = 12.dp,
                                shape = RoundedCornerShape(24.dp),
                                clip = false,
                                ambientColor = SleekPurpleLight.copy(alpha = 0.2f),
                                spotColor = SleekPurpleLight.copy(alpha = 0.4f)
                            ),
                        shape = RoundedCornerShape(24.dp),
                        color = Color(0xCC121218), // Deep glassmorphic background
                        border = BorderStroke(1.dp, SleekBorderColor.copy(alpha = 0.3f))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(onClick = onToggleFullscreen) {
                                Icon(Icons.Default.KeyboardArrowDown, contentDescription = "Minimize", tint = SleekTextPrimary, modifier = Modifier.size(32.dp))
                            }

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.MusicNote, contentDescription = null, tint = SleekPurpleLight, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "MUSIC PLAYER",
                                    style = MaterialTheme.typography.labelLarge.copy(
                                        fontWeight = FontWeight.ExtraBold,
                                        letterSpacing = 1.2.sp,
                                        color = SleekPurpleLight
                                    )
                                )
                            }

                            IconButton(onClick = onClose) {
                                Icon(Icons.Default.Close, contentDescription = "Close", tint = CrimsonFailure, modifier = Modifier.size(28.dp))
                            }
                        }
                    }

                    // Large Album Artwork Center with Art Canvas Gradient
                    val infiniteTransition = rememberInfiniteTransition(label = "full_disc")
                    val fullDiscAngle by infiniteTransition.animateFloat(
                        initialValue = 0f,
                        targetValue = 360f,
                        animationSpec = infiniteRepeatable(
                            animation = tween(12000, easing = LinearEasing)
                        ), label = "disc_angle"
                    )
                    var isCanvasArtMode by remember { mutableStateOf(false) }

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        // Sleep countdown badge & Notification Active Pill above disc
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.padding(bottom = 12.dp)
                        ) {
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = SleekPurpleDark.copy(alpha = 0.85f),
                                border = BorderStroke(1.dp, SleekPurpleLight.copy(alpha = 0.5f))
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(6.dp)
                                            .background(if (isPlaying) Color(0xFF10B981) else Color(0xFFF59E0B), CircleShape)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "NOTIFICATION ACTIVE",
                                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, fontSize = 9.sp),
                                        color = Color.White
                                    )
                                }
                            }

                            if (sleepSecondsRemaining > 0) {
                                val min = sleepSecondsRemaining / 60
                                val sec = sleepSecondsRemaining % 60
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = SleekPurpleDark.copy(alpha = 0.85f),
                                    border = BorderStroke(1.dp, SleekPurpleLight.copy(alpha = 0.5f))
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Timer,
                                            contentDescription = "Sleep Timer",
                                            tint = Color.White,
                                            modifier = Modifier.size(12.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = String.format("%02d:%02d", min, sec),
                                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, fontSize = 10.sp),
                                            color = Color.White
                                        )
                                    }
                                }
                            }

                            // Art Canvas Mode Toggle
                            IconButton(
                                onClick = { isCanvasArtMode = !isCanvasArtMode },
                                modifier = Modifier.size(28.dp)
                            ) {
                                Icon(
                                    imageVector = if (isCanvasArtMode) Icons.Default.Album else Icons.Default.CropOriginal,
                                    contentDescription = "Art Mode",
                                    tint = SleekPurpleLight,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }

                        // Ambient Gradient Glow Canvas Container
                        Box(
                            modifier = Modifier
                                .size(240.dp)
                                .shadow(28.dp, if (isCanvasArtMode) RoundedCornerShape(24.dp) else CircleShape, spotColor = SleekPurpleLight)
                                .clip(if (isCanvasArtMode) RoundedCornerShape(24.dp) else CircleShape)
                                .background(
                                    Brush.radialGradient(
                                        colors = listOf(
                                            Color(0xFF9333EA),
                                            Color(0xFF3B82F6),
                                            Color(0xFF0F0C20)
                                        )
                                    )
                                )
                                .border(3.dp, SleekPurpleLight, if (isCanvasArtMode) RoundedCornerShape(24.dp) else CircleShape)
                                .clickable { isCanvasArtMode = !isCanvasArtMode },
                            contentAlignment = Alignment.Center
                        ) {
                            if (media.thumbnailUrl.isNotBlank()) {
                                coil.compose.AsyncImage(
                                    model = media.thumbnailUrl,
                                    contentDescription = "Album Art Preview",
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .clip(if (isCanvasArtMode) RoundedCornerShape(24.dp) else CircleShape)
                                        .rotate(if (isPlaying && !isCanvasArtMode) fullDiscAngle else 0f)
                                )
                            } else {
                                Icon(
                                    imageVector = Icons.Default.MusicNote,
                                    contentDescription = null,
                                    tint = SleekPurpleLight,
                                    modifier = Modifier
                                        .size(96.dp)
                                        .rotate(if (isPlaying && !isCanvasArtMode) fullDiscAngle else 0f)
                                )
                            }
                            if (!isCanvasArtMode) {
                                // Center vinyl hole detail
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(CircleShape)
                                        .background(Color.Black)
                                        .border(2.dp, SleekBorderColor, CircleShape)
                                )
                            }
                        }
                    }

                    // Title & Artist section
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = media.title.removePrefix("[Streaming Audio] ").trim(),
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Bold,
                                color = SleekTextPrimary
                            ),
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (media.author.isNotBlank()) media.author else "Audio Stream",
                            style = MaterialTheme.typography.bodyMedium,
                            color = SleekTextSecondary,
                            textAlign = TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        // Equalizer Visualizer
                        AudioEqualizerVisualizer(
                            isPlaying = isPlaying,
                            modifier = Modifier
                                .width(200.dp)
                                .height(32.dp)
                        )
                    }

                    // Transient Toast overlay above slider
                    toastMessage?.let { msg ->
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = Color.Black.copy(alpha = 0.8f),
                            border = BorderStroke(1.dp, SleekBorderColor)
                        ) {
                            Text(
                                text = msg,
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                color = Color.White,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }
                    }

                    // Progress SineWaveSeekBar
                    Column(modifier = Modifier.fillMaxWidth()) {
                        SineWaveSeekBar(
                            currentPosMs = currentPosMs,
                            durationMs = durationMs,
                            waveformData = currentWaveformData,
                            onSeekTo = { targetMs ->
                                currentPosMs = targetMs
                                mediaPlayer.seekTo(targetMs.toInt())
                            },
                            modifier = Modifier.fillMaxWidth()
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(formatTimeMs(currentPosMs), style = MaterialTheme.typography.labelMedium, color = SleekTextSecondary)
                            Text(formatTimeMs(durationMs), style = MaterialTheme.typography.labelMedium, color = SleekTextSecondary)
                        }
                    }

                    // Floating double-tier Controls Bar Container
                    Surface(
                        modifier = Modifier
                            .navigationBarsPadding()
                            .fillMaxWidth()
                            .shadow(
                                elevation = 12.dp,
                                shape = RoundedCornerShape(28.dp),
                                clip = false,
                                ambientColor = SleekPurpleLight.copy(alpha = 0.2f),
                                spotColor = SleekPurpleLight.copy(alpha = 0.4f)
                            ),
                        shape = RoundedCornerShape(28.dp),
                        color = Color(0xCC121218), // Deep glassmorphic background
                        border = BorderStroke(1.dp, SleekBorderColor.copy(alpha = 0.3f))
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 16.dp),
                            verticalArrangement = Arrangement.spacedBy(14.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            // Tier 1: Utility Controls (Loop, Speed, Sound Preset, Sleep Timer, Mute)
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceEvenly,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                // Repeat toggle
                                IconButton(
                                    onClick = {
                                        isLooping = !isLooping
                                        mediaPlayer.isLooping = isLooping
                                    }
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Repeat,
                                        contentDescription = "Loop",
                                        tint = if (isLooping) SleekPurpleLight else SleekTextMuted,
                                        modifier = Modifier.size(22.dp)
                                    )
                                }

                                // Speed Selector
                                Surface(
                                    onClick = {
                                        speed = when (speed) {
                                            1.0f -> 1.25f
                                            1.25f -> 1.5f
                                            1.5f -> 2.0f
                                            else -> 1.0f
                                        }
                                        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M && isPrepared) {
                                            try {
                                                mediaPlayer.playbackParams = mediaPlayer.playbackParams.setSpeed(speed)
                                            } catch (e: Exception) {}
                                        }
                                    },
                                    shape = RoundedCornerShape(8.dp),
                                    color = SleekCardDark,
                                    border = BorderStroke(1.dp, SleekBorderColor)
                                ) {
                                    Text(
                                        text = "${speed}x",
                                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, fontSize = 10.sp),
                                        color = SleekPurpleLight,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                                    )
                                }

                                // Sound Preset Selection
                                IconButton(
                                    onClick = {
                                        soundPreset = when (soundPreset) {
                                            "Normal" -> "Bass Boost"
                                            "Bass Boost" -> "Pop"
                                            "Pop" -> "Vocal"
                                            else -> "Normal"
                                        }
                                    }
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Tune,
                                        contentDescription = "Sound Presets",
                                        tint = if (soundPreset == "Normal") SleekTextMuted else SleekPurpleLight,
                                        modifier = Modifier.size(22.dp)
                                    )
                                }

                                // Sleep Timer Button
                                IconButton(
                                    onClick = {
                                        showSleepTimerDialog = true
                                    }
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Timer,
                                        contentDescription = "Sleep Timer Selection",
                                        tint = if (sleepSecondsRemaining > 0) SleekPurpleLight else SleekTextMuted,
                                        modifier = Modifier.size(22.dp)
                                    )
                                }

                                // Mute/Volume
                                IconButton(
                                    onClick = {
                                        isMuted = !isMuted
                                    }
                                ) {
                                    Icon(
                                        imageVector = if (isMuted) Icons.Default.VolumeOff else Icons.Default.VolumeUp,
                                        contentDescription = "Mute Toggle",
                                        tint = if (isMuted) CrimsonFailure else SleekPurpleLight,
                                        modifier = Modifier.size(22.dp)
                                    )
                                }
                            }

                            // Tier 2: Core Playback Buttons
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.Center,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                // Skip -10s
                                IconButton(
                                    onClick = {
                                        val target = (currentPosMs - 10000L).coerceAtLeast(0L)
                                        mediaPlayer.seekTo(target.toInt())
                                        currentPosMs = target
                                    },
                                    modifier = Modifier.size(48.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.FastRewind,
                                        contentDescription = "Rewind 10s",
                                        tint = SleekTextPrimary,
                                        modifier = Modifier.size(28.dp)
                                    )
                                }

                                Spacer(modifier = Modifier.width(24.dp))

                                // Play/Pause Big Center Pill
                                Surface(
                                    onClick = {
                                        if (isPlaying) {
                                            mediaPlayer.pause()
                                            isPlaying = false
                                        } else {
                                            mediaPlayer.start()
                                            isPlaying = true
                                        }
                                    },
                                    shape = CircleShape,
                                    color = SleekPurpleLight,
                                    shadowElevation = 8.dp,
                                    modifier = Modifier.size(64.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
                                        Icon(
                                            imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                            contentDescription = "Play/Pause",
                                            tint = Color.White,
                                            modifier = Modifier.size(36.dp)
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.width(24.dp))

                                // Skip +10s
                                IconButton(
                                    onClick = {
                                        val target = (currentPosMs + 10000L).coerceAtMost(durationMs)
                                        mediaPlayer.seekTo(target.toInt())
                                        currentPosMs = target
                                    },
                                    modifier = Modifier.size(48.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.FastForward,
                                        contentDescription = "Forward 10s",
                                        tint = SleekTextPrimary,
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showSleepTimerDialog) {
        SleepTimerDialog(
            currentMinutes = sleepTimerMinutes,
            currentSecondsRemaining = sleepSecondsRemaining,
            onSelectMinutes = { mins ->
                sleepTimerMinutes = mins
                sleepSecondsRemaining = mins * 60
                toastMessage = if (mins > 0) "Sleep Timer: ${mins}m with Fade-Out" else "Sleep Timer Off"
            },
            onDismiss = { showSleepTimerDialog = false }
        )
    }
}
}

data class PlayerAudioTrack(
    val group: androidx.media3.common.Tracks.Group,
    val trackIndex: Int,
    val name: String,
    val language: String,
    val isSelected: Boolean,
    val isSupported: Boolean
)

data class PlayerSubtitleTrack(
    val group: androidx.media3.common.Tracks.Group,
    val trackIndex: Int,
    val name: String,
    val language: String,
    val isSelected: Boolean
)

data class PlaybackCodecInfo(
    val container: String = "MKV / MP4 / Stream",
    val videoMime: String = "N/A",
    val videoDecoder: String = "MediaCodec HW",
    val videoResolution: String = "N/A",
    val videoFps: String = "N/A",
    val videoBitrate: String = "N/A",
    val isVideoHw: Boolean = true,
    val audioMime: String = "N/A",
    val audioDecoder: String = "MediaCodec HW",
    val audioChannels: String = "N/A",
    val audioSampleRate: String = "N/A",
    val audioBitrate: String = "N/A",
    val isAudioHw: Boolean = true,
    val engineMode: String = "Auto (HW + SW)",
    val audioOutputMode: String = "Auto (PCM/Passthrough)"
)

enum class MiniPlayerState {
    IDLE,
    DRAGGING,
    PINCHING,
    SNAPPING
}

@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
fun SleekVideoPlayerOverlay(
    media: DownloadEntity,
    isFullscreen: Boolean,
    onToggleFullscreen: () -> Unit,
    onClose: () -> Unit,
    analyzedVideo: AnalyzedVideo? = null,
    onStreamFormat: ((VideoFormatUi) -> Unit)? = null,
    viewModel: VideoDownloaderViewModel? = null,
    onOpenAudioFxStudio: (() -> Unit)? = null
) {
    val context = LocalContext.current
    var topBarOffsetHeightPx by remember { mutableFloatStateOf(0f) }
    val topBarHeightPx = with(androidx.compose.ui.platform.LocalDensity.current) { 100.dp.toPx() }
    val nestedScrollConnection = remember {
        object : androidx.compose.ui.input.nestedscroll.NestedScrollConnection {
            override fun onPreScroll(available: androidx.compose.ui.geometry.Offset, source: androidx.compose.ui.input.nestedscroll.NestedScrollSource): androidx.compose.ui.geometry.Offset {
                val delta = available.y
                val newOffset = topBarOffsetHeightPx + delta
                topBarOffsetHeightPx = newOffset.coerceIn(-topBarHeightPx, 0f)
                return androidx.compose.ui.geometry.Offset.Zero
            }
        }
    }
    val scope = rememberCoroutineScope()
    var isPaused by remember(media.id, media.localPath) { mutableStateOf(false) }
    var mediaVideoWidth by remember(media.id, media.localPath) { mutableIntStateOf(0) }
    var mediaVideoHeight by remember(media.id, media.localPath) { mutableIntStateOf(0) }

    LaunchedEffect(media.id, media.localPath) {
        mediaVideoWidth = 0
        mediaVideoHeight = 0
        val videoPath = media.localPath.substringBefore("|STREAM_AUDIO_URL|")
        if (!videoPath.startsWith("http://") && !videoPath.startsWith("https://") && videoPath.isNotBlank()) {
            try {
                val retriever = android.media.MediaMetadataRetriever()
                retriever.setDataSource(videoPath)
                val wStr = retriever.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)
                val hStr = retriever.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)
                val rotStr = retriever.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)
                retriever.release()
                val w = wStr?.toIntOrNull() ?: 0
                val h = hStr?.toIntOrNull() ?: 0
                val rot = rotStr?.toIntOrNull() ?: 0
                if (w > 0 && h > 0) {
                    if (rot == 90 || rot == 270) {
                        mediaVideoWidth = h
                        mediaVideoHeight = w
                    } else {
                        mediaVideoWidth = w
                        mediaVideoHeight = h
                    }
                }
            } catch (_: Exception) {}
        }
    }
    var hasRenderedFirstFrame by remember(media.id, media.localPath) { mutableStateOf(false) }
    var isBufferLoading by remember(media.id, media.localPath) { mutableStateOf(true) }
    var playerError by remember(media.id, media.localPath) { mutableStateOf<String?>(null) }
    var showExternalPlayerAlert by remember(media.id, media.localPath) { mutableStateOf(false) }

    val showPipControlsOnPlayer = viewModel?.showPipControlsOnPlayer?.collectAsStateWithLifecycle()?.value ?: true
    val isCustomPipMini = viewModel?.isCustomPipMini?.collectAsStateWithLifecycle()?.value ?: false
    val currentWaveformData = viewModel?.currentWaveformData?.collectAsStateWithLifecycle()?.value

    val activity = context as? android.app.Activity
    DisposableEffect(isFullscreen) {
        if (isFullscreen) {
            activity?.requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        } else {
            activity?.requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
        onDispose {
            activity?.requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
    }

    var offsetX by remember { mutableStateOf(0f) }
    var offsetY by remember { mutableStateOf(0f) }

    var showLeftIndicator by remember { mutableStateOf(false) }
    var showRightIndicator by remember { mutableStateOf(false) }
    var showQuickGuide by remember { mutableStateOf(false) }
    val overlayFocusRequester = remember { androidx.compose.ui.focus.FocusRequester() }

    LaunchedEffect(Unit) {
        try {
            overlayFocusRequester.requestFocus()
        } catch (e: Exception) {}
    }

    LaunchedEffect(showQuickGuide) {
        if (showQuickGuide) {
            delay(2500)
            showQuickGuide = false
        }
    }

    var isVolumeDrag by remember { mutableStateOf(false) }
    var isBrightnessDrag by remember { mutableStateOf(false) }
    var isSeekDrag by remember { mutableStateOf(false) }
    var initialVolume by remember { mutableIntStateOf(0) }
    var initialVolumeBoost by remember { mutableFloatStateOf(0f) }
    var initialBrightness by remember { mutableFloatStateOf(-1f) }
    var initialSeekPos by remember { mutableLongStateOf(0L) }
    var totalDragY by remember { mutableFloatStateOf(0f) }
    var totalDragX by remember { mutableFloatStateOf(0f) }
    var swipeDirectionResolved by remember { mutableStateOf(false) }
    var isVerticalSwipe by remember { mutableStateOf(false) }
    var isHorizontalSwipe by remember { mutableStateOf(false) }
    val audioManager = remember { context.getSystemService(android.content.Context.AUDIO_SERVICE) as android.media.AudioManager }
    val maxVolume = remember { audioManager.getStreamMaxVolume(android.media.AudioManager.STREAM_MUSIC) }

    LaunchedEffect(showLeftIndicator) {
        if (showLeftIndicator) {
            delay(650)
            showLeftIndicator = false
        }
    }
    LaunchedEffect(showRightIndicator) {
        if (showRightIndicator) {
            delay(650)
            showRightIndicator = false
        }
    }

    var miniPlayerState by remember { mutableStateOf(MiniPlayerState.IDLE) }
    var isDragging by remember { mutableStateOf(false) }
    var isPinching by remember { mutableStateOf(false) }
    var userMiniScale by remember { mutableFloatStateOf(1.00f) }

    LaunchedEffect(miniPlayerState) {
        isDragging = (miniPlayerState == MiniPlayerState.DRAGGING)
        isPinching = (miniPlayerState == MiniPlayerState.PINCHING)
        if (miniPlayerState == MiniPlayerState.SNAPPING) {
            kotlinx.coroutines.delay(300)
            miniPlayerState = MiniPlayerState.IDLE
        }
    }

    val isMiniMode = (!isFullscreen || isCustomPipMini)
    val isGestureActive = miniPlayerState == MiniPlayerState.DRAGGING || miniPlayerState == MiniPlayerState.PINCHING

    val animOffsetX by animateFloatAsState(
        targetValue = if (isMiniMode) offsetX else 0f,
        animationSpec = if (isGestureActive) snap() else spring(dampingRatio = Spring.DampingRatioLowBouncy, stiffness = Spring.StiffnessMediumLow),
        label = "animOffsetX"
    )
    val animOffsetY by animateFloatAsState(
        targetValue = if (isMiniMode) offsetY else 0f,
        animationSpec = if (isGestureActive) snap() else spring(dampingRatio = Spring.DampingRatioLowBouncy, stiffness = Spring.StiffnessMediumLow),
        label = "animOffsetY"
    )

    val swipeProgress = if (isFullscreen && !isCustomPipMini && isDragging && offsetY > 0f) {
        (offsetY / 200f).coerceIn(0f, 1f)
    } else {
        0f
    }

    val playerScale by animateFloatAsState(
        targetValue = when {
            isMiniMode && isGestureActive -> 1.05f
            isFullscreen && !isCustomPipMini && isDragging && offsetY > 0f -> (1f - (swipeProgress * 0.18f)).coerceIn(0.78f, 1f)
            else -> 1f
        },
        animationSpec = if (isGestureActive) snap() else spring(dampingRatio = Spring.DampingRatioNoBouncy, stiffness = Spring.StiffnessMediumLow),
        label = "playerScale"
    )

    val backdropAlpha by animateFloatAsState(
        targetValue = if (isFullscreen && !isCustomPipMini) {
            if (isDragging && offsetY > 0f) (1f - swipeProgress * 0.85f).coerceIn(0f, 1f) else 1f
        } else {
            0f
        },
        animationSpec = if (isDragging) snap() else tween(durationMillis = 280, easing = FastOutSlowInEasing),
        label = "backdropAlpha"
    )

    val density = androidx.compose.ui.platform.LocalDensity.current
    val configuration = androidx.compose.ui.platform.LocalConfiguration.current
    val isMobile = configuration.screenWidthDp < 600

    val currentMiniScale = if (isMiniMode) userMiniScale else 1.00f

    val defaultMiniWidthDp = if (isMobile) 180.dp else 220.dp
    val defaultMiniHeightDp = if (isMobile) 102.dp else 124.dp
    val defaultAspectRatio = defaultMiniWidthDp.value / defaultMiniHeightDp.value

    val aspectRatio = if (mediaVideoWidth > 0 && mediaVideoHeight > 0) {
        mediaVideoWidth.toFloat() / mediaVideoHeight.toFloat()
    } else {
        defaultAspectRatio
    }

    val maxMiniWidthDp = configuration.screenWidthDp.dp * 0.75f
    val maxMiniHeightDp = configuration.screenHeightDp.dp * 0.75f

    val (baseWidthDp, baseHeightDp) = if (isFullscreen && !isCustomPipMini) {
        Pair(configuration.screenWidthDp.dp, configuration.screenHeightDp.dp)
    } else {
        var calcWidth = defaultMiniWidthDp
        var calcHeight = calcWidth / aspectRatio

        if (calcHeight > maxMiniHeightDp) {
            calcHeight = maxMiniHeightDp
            calcWidth = calcHeight * aspectRatio
        }
        if (calcWidth > maxMiniWidthDp) {
            calcWidth = maxMiniWidthDp
            calcHeight = calcWidth / aspectRatio
        }

        Pair(calcWidth, calcHeight)
    }

    val widthDp by animateDpAsState(
        targetValue = baseWidthDp * currentMiniScale,
        animationSpec = if (isGestureActive) snap() else spring(dampingRatio = Spring.DampingRatioNoBouncy, stiffness = Spring.StiffnessMediumLow),
        label = "playerWidth"
    )
    val heightDp by animateDpAsState(
        targetValue = baseHeightDp * currentMiniScale,
        animationSpec = if (isGestureActive) snap() else spring(dampingRatio = Spring.DampingRatioNoBouncy, stiffness = Spring.StiffnessMediumLow),
        label = "playerHeight"
    )
    val cornerRadius by animateDpAsState(
        targetValue = if (isFullscreen && !isCustomPipMini) {
            if (isDragging && offsetY > 0f) (swipeProgress * 16f).dp else 0.dp
        } else {
            16.dp
        },
        animationSpec = if (isGestureActive) snap() else spring(dampingRatio = Spring.DampingRatioNoBouncy, stiffness = Spring.StiffnessMediumLow),
        label = "playerCorner"
    )
    val shadowElevationDp by animateDpAsState(
        targetValue = when {
            isMiniMode && isGestureActive -> 24.dp
            isMiniMode -> 12.dp
            isFullscreen && cornerRadius < 1.dp -> 0.dp
            else -> 16.dp
        },
        animationSpec = if (isGestureActive) snap() else spring(dampingRatio = Spring.DampingRatioNoBouncy, stiffness = Spring.StiffnessMediumLow),
        label = "shadowElevation"
    )
    val paddingDp by animateDpAsState(
        targetValue = 0.dp,
        animationSpec = spring(dampingRatio = Spring.DampingRatioNoBouncy, stiffness = Spring.StiffnessMediumLow),
        label = "playerPadding"
    )

    val playerDecoderModeSetting by (viewModel?.playerDecoderMode?.collectAsStateWithLifecycle() ?: remember { mutableStateOf("Auto (HW + SW Fallback)") })
    val hardwareAccelerationSetting by (viewModel?.hardwareAcceleration?.collectAsStateWithLifecycle() ?: remember { mutableStateOf(true) })
    val audioOutputModeSetting by (viewModel?.audioOutputMode?.collectAsStateWithLifecycle() ?: remember { mutableStateOf("Auto (PCM/Passthrough)") })
    val hardwareAccelerationModeSetting by (viewModel?.hardwareAccelerationMode?.collectAsStateWithLifecycle() ?: remember { mutableStateOf("Auto") })
    val audioPassthroughModeSetting by (viewModel?.audioPassthroughMode?.collectAsStateWithLifecycle() ?: remember { mutableStateOf("Auto") })
    val autoDimEnabled by (viewModel?.autoDimScreenOnInactivity?.collectAsStateWithLifecycle() ?: remember { mutableStateOf(true) })
    val autoDimTimeoutSeconds by (viewModel?.autoDimInactivitySeconds?.collectAsStateWithLifecycle() ?: remember { mutableIntStateOf(30) })

    var isScreenAutoDimmed by remember { mutableStateOf(false) }
    var lastInteractionTime by remember { mutableLongStateOf(System.currentTimeMillis()) }
    val originalWindowBrightness = remember { (context as? android.app.Activity)?.window?.attributes?.screenBrightness ?: android.view.WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE }
    var userCustomBrightness by remember { mutableStateOf<Float?>(null) }

    fun applyWindowBrightness(targetBrightness: Float) {
        try {
            val window = (context as? android.app.Activity)?.window ?: return
            val lp = window.attributes
            lp.screenBrightness = targetBrightness
            window.attributes = lp
        } catch (_: Exception) {}
    }

    fun registerUserActivity() {
        lastInteractionTime = System.currentTimeMillis()
        if (isScreenAutoDimmed) {
            isScreenAutoDimmed = false
            if (isPaused) {
                applyWindowBrightness(originalWindowBrightness)
            } else {
                applyWindowBrightness(userCustomBrightness ?: originalWindowBrightness)
            }
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            try {
                val window = (context as? android.app.Activity)?.window
                if (window != null) {
                    val lp = window.attributes
                    lp.screenBrightness = originalWindowBrightness
                    window.attributes = lp
                }
            } catch (e: Exception) {}
        }
    }

    var isSoftwareFallbackActive by remember { mutableStateOf(false) }
    var showCodecSpecsDialog by remember { mutableStateOf(false) }
    var showAdvancedPlayerSettings by remember { mutableStateOf(false) }
    var playbackCodecInfo by remember {
        mutableStateOf(
            PlaybackCodecInfo(
                engineMode = playerDecoderModeSetting,
                audioOutputMode = audioOutputModeSetting
            )
        )
    }

    val orchestrator = remember(playerDecoderModeSetting) {
        com.example.media.orchestration.DecoderOrchestrator().apply {
            profile.videoDecoderMode = playerDecoderModeSetting
            profile.audioDecoderMode = playerDecoderModeSetting
        }
    }

    val vocalReductionProcessor = remember { com.example.media.audiofx.VocalReductionAudioProcessor() }

    val renderersFactory = remember(context, playerDecoderModeSetting, orchestrator) {
        object : androidx.media3.exoplayer.DefaultRenderersFactory(context) {
            override fun buildAudioSink(
                context: android.content.Context,
                enableFloatOutput: Boolean,
                enableAudioTrackPlaybackParams: Boolean
            ): androidx.media3.exoplayer.audio.AudioSink? {
                return androidx.media3.exoplayer.audio.DefaultAudioSink.Builder(context)
                    .setEnableFloatOutput(enableFloatOutput)
                    .setEnableAudioTrackPlaybackParams(enableAudioTrackPlaybackParams)
                    .setAudioProcessors(arrayOf(vocalReductionProcessor))
                    .build()
            }
        }.apply {
            setEnableDecoderFallback(true)
            setExtensionRendererMode(androidx.media3.exoplayer.DefaultRenderersFactory.EXTENSION_RENDERER_MODE_ON)
            setEnableAudioTrackPlaybackParams(true)
        }
    }

    val trackSelector = remember(context) {
        androidx.media3.exoplayer.trackselection.DefaultTrackSelector(context).apply {
            parameters = buildUponParameters()
                .setSelectUndeterminedTextLanguage(true)
                .build()
        }
    }

    var audioTracks by remember(media.id, media.localPath) { mutableStateOf<List<PlayerAudioTrack>>(emptyList()) }
    var subtitleTracks by remember(media.id, media.localPath) { mutableStateOf<List<PlayerSubtitleTrack>>(emptyList()) }
    var isAudioDisabled by remember { mutableStateOf(false) }
    var isSubtitleDisabled by remember { mutableStateOf(false) }
    var showAudioTrackMenu by remember { mutableStateOf(false) }
    var showSubtitleTrackMenu by remember { mutableStateOf(false) }
    var toastMessage by remember { mutableStateOf<String?>(null) }

    var externalSubtitleUri by remember(media.id, media.localPath) { mutableStateOf<String?>(null) }

    val subtitlePickerLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        contract = androidx.activity.result.contract.ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            externalSubtitleUri = uri.toString()
        }
    }

    val mediaEngine = remember(orchestrator) {
        com.example.media.DefaultMediaEngine(context, renderersFactory, trackSelector, orchestrator).apply {
            player.playWhenReady = true
            player.repeatMode = androidx.media3.common.Player.REPEAT_MODE_ONE
        }
    }
    
    val exoPlayer = mediaEngine.player as androidx.media3.exoplayer.ExoPlayer
    if (viewModel != null) {
        ExoPlayerAudioFxEngine(exoPlayer = exoPlayer, viewModel = viewModel)
    }

    LaunchedEffect(media.id, media.localPath, externalSubtitleUri) {
        val rawVideoPath = media.localPath.substringBefore("|STREAM_AUDIO_URL|")
        val audioPath = if (media.localPath.contains("|STREAM_AUDIO_URL|")) media.localPath.substringAfter("|STREAM_AUDIO_URL|") else null
        
        hasRenderedFirstFrame = false
        isBufferLoading = true
        playerError = null
        showExternalPlayerAlert = false
        
        val bgActive = com.example.media.BackgroundPlaybackManager.isBackgroundActive.value
        val bgMedia = com.example.media.BackgroundPlaybackManager.currentMedia.value
        val bgPos = if (bgActive) {
            if (bgMedia?.id == media.id) {
                val p = com.example.media.BackgroundPlaybackManager.currentPositionMs.value
                com.example.media.BackgroundPlaybackManager.stop(context)
                p
            } else {
                com.example.media.BackgroundPlaybackManager.stop(context)
                0L
            }
        } else 0L

        var videoPath = rawVideoPath
        var activeFallbackSessionId: Long? = null

        // 1. Evaluate fallback strategy
        if (!videoPath.startsWith("http://") && !videoPath.startsWith("https://") && videoPath.isNotBlank() && audioPath == null) {
            val fileUri = android.net.Uri.fromFile(java.io.File(videoPath))
            val strategyResult = com.example.media.playback.PlaybackFallbackEngine.evaluatePlaybackStrategy(context, fileUri)
            
            if (strategyResult.strategy == com.example.media.playback.PlaybackStrategy.REMUX_REQUIRED) {
                toastMessage = "Incompatible container detected. Remuxing to MP4 for hardware playback..."
                val tmpOut = com.example.media.storage.TemporaryMediaManager.createTempFile(context, "remux_", ".mp4")
                
                try {
                    val flow = com.example.media.operations.RemuxEngine.remuxToMp4(context, fileUri, tmpOut)
                    flow.collect { progress ->
                        if (progress.state == com.example.media.ffmpeg.FFmpegState.COMPLETED) {
                            videoPath = tmpOut.absolutePath
                        } else if (progress.state == com.example.media.ffmpeg.FFmpegState.FAILED) {
                            toastMessage = "Remux failed. Falling back to direct playback."
                            com.example.media.storage.TemporaryMediaManager.deleteSilently(tmpOut)
                        } else if (progress.state == com.example.media.ffmpeg.FFmpegState.RUNNING) {
                            activeFallbackSessionId = progress.sessionId
                        }
                    }
                } catch (e: Exception) {
                    toastMessage = "Remux error: ${e.message}"
                }
            } else if (strategyResult.strategy == com.example.media.playback.PlaybackStrategy.TRANSCODE_REQUIRED) {
                toastMessage = "Unsupported codecs detected. Transcoding for hardware playback..."
                val tmpOut = com.example.media.storage.TemporaryMediaManager.createTempFile(context, "transcode_", ".mp4")
                
                val req = com.example.media.operations.MediaConversionRequest(
                    inputUri = fileUri,
                    outputFile = tmpOut,
                    videoCodec = if (strategyResult.videoCodec in setOf("h264", "avc1", "hevc", "h265", "vp8", "vp9", "av01", "av1")) "copy" else "libx264",
                    audioCodec = if (strategyResult.audioCodec in setOf("aac", "mp3", "opus", "vorbis", "flac")) "copy" else "aac",
                    preset = "fast"
                )
                
                try {
                    val flow = com.example.media.operations.MediaConverter.convertMedia(context, req)
                    flow.collect { progress ->
                        if (progress.state == com.example.media.ffmpeg.FFmpegState.COMPLETED) {
                            videoPath = tmpOut.absolutePath
                        } else if (progress.state == com.example.media.ffmpeg.FFmpegState.FAILED) {
                            toastMessage = "Transcode failed. Falling back to direct playback."
                            com.example.media.storage.TemporaryMediaManager.deleteSilently(tmpOut)
                        } else if (progress.state == com.example.media.ffmpeg.FFmpegState.RUNNING) {
                            activeFallbackSessionId = progress.sessionId
                        }
                    }
                } catch (e: Exception) {
                    toastMessage = "Transcode error: ${e.message}"
                }
            }
        }

        try {
            exoPlayer.stop()
            exoPlayer.clearMediaItems()
            mediaEngine.prepareMedia(videoPath, audioPath, externalSubtitleUri)
            if (bgPos > 0L) {
                exoPlayer.seekTo(bgPos)
            }
            exoPlayer.playWhenReady = true
            exoPlayer.repeatMode = androidx.media3.common.Player.REPEAT_MODE_ONE
            exoPlayer.prepare()
            exoPlayer.play()
            val initSize = exoPlayer.videoSize
            if (initSize.width > 0 && initSize.height > 0) {
                val rot = initSize.unappliedRotationDegrees
                if (rot == 90 || rot == 270) {
                    mediaVideoWidth = initSize.height
                    mediaVideoHeight = initSize.width
                } else {
                    mediaVideoWidth = initSize.width
                    mediaVideoHeight = initSize.height
                }
            }
        } catch (e: Exception) {
            playerError = mediaEngine.formatPlaybackErrorLog(androidx.media3.common.PlaybackException(e.message, e, androidx.media3.common.PlaybackException.ERROR_CODE_UNSPECIFIED))
            showExternalPlayerAlert = true
        }
    }

    val playbackScope = rememberCoroutineScope()
    DisposableEffect(mediaEngine) {
        var hasLoggedSuccess = false
        var recoveryAttempts = 0
        val listener = object : androidx.media3.common.Player.Listener {
            private fun updateVideoDimensionsFromPlayer() {
                val size = exoPlayer.videoSize
                val w = size.width
                val h = size.height
                val rotation = size.unappliedRotationDegrees
                if (w > 0 && h > 0) {
                    if (rotation == 90 || rotation == 270) {
                        mediaVideoWidth = h
                        mediaVideoHeight = w
                    } else {
                        mediaVideoWidth = w
                        mediaVideoHeight = h
                    }
                }
            }

            override fun onVideoSizeChanged(videoSize: androidx.media3.common.VideoSize) {
                updateVideoDimensionsFromPlayer()
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                updateVideoDimensionsFromPlayer()
                when (playbackState) {
                    androidx.media3.common.Player.STATE_BUFFERING -> {
                        if (!hasRenderedFirstFrame && !exoPlayer.isPlaying && exoPlayer.currentPosition < 200L) {
                            isBufferLoading = true
                        }
                    }
                    androidx.media3.common.Player.STATE_READY -> {
                        hasRenderedFirstFrame = true
                        isBufferLoading = false
                        playerError = null
                        recoveryAttempts = 0
                        showExternalPlayerAlert = false
                        hasLoggedSuccess = true
                    }
                    androidx.media3.common.Player.STATE_ENDED, androidx.media3.common.Player.STATE_IDLE -> {
                        isBufferLoading = false
                    }
                }
            }

            override fun onIsPlayingChanged(isPlaying: Boolean) {
                if (isPlaying) {
                    updateVideoDimensionsFromPlayer()
                    hasRenderedFirstFrame = true
                    isBufferLoading = false
                }
            }

            override fun onRenderedFirstFrame() {
                updateVideoDimensionsFromPlayer()
                hasRenderedFirstFrame = true
                isBufferLoading = false
            }

            override fun onTracksChanged(tracks: androidx.media3.common.Tracks) {
                updateVideoDimensionsFromPlayer()
                val newAudioTracks = mutableListOf<PlayerAudioTrack>()
                val newSubtitleTracks = mutableListOf<PlayerSubtitleTrack>()
                var hasActiveAudio = false

                for (group in tracks.groups) {
                    if (group.type == androidx.media3.common.C.TRACK_TYPE_AUDIO) {
                        for (i in 0 until group.length) {
                            val format = group.getTrackFormat(i)
                            val lang = format.language?.uppercase()?.ifBlank { "UND" } ?: "UND"
                            val channelStr = if (format.channelCount > 0) " (${format.channelCount}ch)" else ""
                            val mime = format.sampleMimeType?.substringAfter("/")?.uppercase() ?: ""
                            val mimeStr = if (mime.isNotBlank()) " [$mime]" else ""
                            val trackLabel = format.label?.ifBlank { null }
                                ?: "Audio Stream #${newAudioTracks.size + 1} ($lang$channelStr$mimeStr)"

                            val isSel = group.isTrackSelected(i)
                            if (isSel) hasActiveAudio = true

                            newAudioTracks.add(
                                PlayerAudioTrack(
                                    group = group,
                                    trackIndex = i,
                                    name = trackLabel,
                                    language = lang,
                                    isSelected = isSel,
                                    isSupported = group.isTrackSupported(i)
                                )
                            )
                        }
                    } else if (group.type == androidx.media3.common.C.TRACK_TYPE_TEXT) {
                        for (i in 0 until group.length) {
                            val format = group.getTrackFormat(i)
                            val lang = format.language?.uppercase()?.ifBlank { "UND" } ?: "UND"
                            val trackLabel = format.label?.ifBlank { null } ?: "Subtitle Stream #${newSubtitleTracks.size + 1} ($lang)"
                            val isSel = group.isTrackSelected(i)
                            
                            newSubtitleTracks.add(
                                PlayerSubtitleTrack(
                                    group = group,
                                    trackIndex = i,
                                    name = trackLabel,
                                    language = lang,
                                    isSelected = isSel
                                )
                            )
                        }
                    }
                }
                
                audioTracks = newAudioTracks
                subtitleTracks = newSubtitleTracks
                
                isAudioDisabled = exoPlayer.trackSelectionParameters.disabledTrackTypes.contains(androidx.media3.common.C.TRACK_TYPE_AUDIO)
                isSubtitleDisabled = exoPlayer.trackSelectionParameters.disabledTrackTypes.contains(androidx.media3.common.C.TRACK_TYPE_TEXT)
                
                if (!hasActiveAudio && newAudioTracks.isNotEmpty() && !isAudioDisabled) {
                    val bestTrack = newAudioTracks.firstOrNull { it.isSupported } ?: newAudioTracks.first()
                    exoPlayer.trackSelectionParameters = exoPlayer.trackSelectionParameters
                        .buildUpon()
                        .clearOverridesOfType(androidx.media3.common.C.TRACK_TYPE_AUDIO)
                    .addOverride(
                            androidx.media3.common.TrackSelectionOverride(
                                bestTrack.group.mediaTrackGroup,
                                listOf(bestTrack.trackIndex)
                            )
                        )
                        .build()
                }
            }

            override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                isBufferLoading = false
                
                // Record decoder failure into Orchestrator to automatically trigger software decoding fallback upon first init failure
                val cause = error.cause ?: error
                val currentDiagnostics = mediaEngine.getDiagnostics()
                val activeVideoMime = currentDiagnostics.videoTracks.firstOrNull()?.mimeType ?: "video/mp4"
                val activeVideoDecoder = playbackCodecInfo.videoDecoder.ifBlank { null }
                
                orchestrator.reportDecoderFailure(
                    decoderName = activeVideoDecoder,
                    mimeType = activeVideoMime,
                    cause = cause
                )

                if (recoveryAttempts >= 2) {
                    playerError = "Playback failed after 2 recovery attempts.\nPlease open this file in an external system player."
                    showExternalPlayerAlert = true
                    return
                }
                recoveryAttempts++
                
                toastMessage = "Decoder initialization failure detected. Falling back to software decoding & retrying ($recoveryAttempts/2)..."
                
                val videoPath = media.localPath.substringBefore("|STREAM_AUDIO_URL|")
                val audioPath = if (media.localPath.contains("|STREAM_AUDIO_URL|")) media.localPath.substringAfter("|STREAM_AUDIO_URL|") else null
                val savedPosition = exoPlayer.currentPosition.coerceAtLeast(0L)

                try {
                    exoPlayer.stop()
                    exoPlayer.clearMediaItems()
                    mediaEngine.prepareMedia(videoPath, audioPath, externalSubtitleUri)
                    exoPlayer.seekTo(savedPosition)
                    exoPlayer.playWhenReady = true
                    exoPlayer.prepare()
                    exoPlayer.play()
                } catch (e: Exception) {
                    playbackScope.launch {
                        playerError = mediaEngine.formatPlaybackErrorLog(error)
                        showExternalPlayerAlert = true
                    }
                }
            }
        }

        val analyticsListener = object : androidx.media3.exoplayer.analytics.AnalyticsListener {
            override fun onVideoInputFormatChanged(eventTime: androidx.media3.exoplayer.analytics.AnalyticsListener.EventTime, format: androidx.media3.common.Format, decoderReuseEvaluation: androidx.media3.exoplayer.DecoderReuseEvaluation?) {
                val decoderName = format.sampleMimeType ?: "Unknown"
                val isHw = !decoderName.lowercase().contains("ffmpeg") && !decoderName.lowercase().contains("sw") && !decoderName.lowercase().contains("raw")
                playbackCodecInfo = playbackCodecInfo.copy(
                    videoDecoder = decoderName,
                    isVideoHw = isHw
                )
            }

            override fun onAudioInputFormatChanged(eventTime: androidx.media3.exoplayer.analytics.AnalyticsListener.EventTime, format: androidx.media3.common.Format, decoderReuseEvaluation: androidx.media3.exoplayer.DecoderReuseEvaluation?) {
                val decoderName = format.sampleMimeType ?: "Unknown"
                val isHw = !decoderName.lowercase().contains("ffmpeg") && !decoderName.lowercase().contains("sw") && !decoderName.lowercase().contains("raw")
                playbackCodecInfo = playbackCodecInfo.copy(
                    audioDecoder = decoderName,
                    isAudioHw = isHw
                )
            }
        }

        exoPlayer.addListener(listener)
        exoPlayer.addAnalyticsListener(analyticsListener)

        onDispose {
            try {
                exoPlayer.removeAnalyticsListener(analyticsListener)
                exoPlayer.removeListener(listener)
                mediaEngine.release()
            } catch (e: Exception) {
                // Safeguard against invalid state during release
            }
        }
    }

    val lifecycleOwner = androidx.lifecycle.compose.LocalLifecycleOwner.current

    val onTriggerBackgroundPlay: () -> Unit = {
        val currentPos = exoPlayer.currentPosition.coerceAtLeast(0L)
        val spd = exoPlayer.playbackParameters.speed
        viewModel?.startBackgroundPlayback(media, currentPos, spd) ?: run {
            com.example.media.BackgroundPlaybackManager.startBackgroundPlayback(context, media, currentPos, spd)
        }
        toastMessage = "🎧 Playing in background (YouTube Mode)"
        onClose()
    }

    DisposableEffect(lifecycleOwner, exoPlayer) {
        val observer = androidx.lifecycle.LifecycleEventObserver { _, event ->
            val activity = context as? android.app.Activity
            val isActivityValid = activity == null || (!activity.isFinishing && !activity.isDestroyed)

            when (event) {
                androidx.lifecycle.Lifecycle.Event.ON_PAUSE,
                androidx.lifecycle.Lifecycle.Event.ON_STOP -> {
                    val bgAllowed = viewModel?.youtubeBackgroundPlayEnabled?.value ?: true
                    val isAppLeaving = activity != null && !activity.isChangingConfigurations
                    if (bgAllowed && isAppLeaving && !isPaused && exoPlayer.isPlaying) {
                        val currentPos = exoPlayer.currentPosition.coerceAtLeast(0L)
                        val spd = exoPlayer.playbackParameters.speed
                        viewModel?.startBackgroundPlayback(media, currentPos, spd) ?: run {
                            com.example.media.BackgroundPlaybackManager.startBackgroundPlayback(context, media, currentPos, spd)
                        }
                    }
                    try {
                        exoPlayer.pause()
                    } catch (e: Exception) {
                        // Avoid crashing on invalid player state
                    }
                }
                androidx.lifecycle.Lifecycle.Event.ON_RESUME -> {
                    if (isActivityValid) {
                        if (com.example.media.BackgroundPlaybackManager.isBackgroundActive.value) {
                            if (com.example.media.BackgroundPlaybackManager.currentMedia.value?.id == media.id) {
                                val bgPos = com.example.media.BackgroundPlaybackManager.currentPositionMs.value
                                val bgPlaying = com.example.media.BackgroundPlaybackManager.isPlaying.value
                                com.example.media.BackgroundPlaybackManager.stop(context)
                                if (bgPos > 0L) {
                                    exoPlayer.seekTo(bgPos)
                                }
                                if (bgPlaying && !isPaused) {
                                    exoPlayer.play()
                                }
                            } else {
                                com.example.media.BackgroundPlaybackManager.stop(context)
                                try {
                                    if (exoPlayer.playbackState != androidx.media3.common.Player.STATE_ENDED && !isPaused) {
                                        exoPlayer.play()
                                    }
                                } catch (e: Exception) {}
                            }
                        } else {
                            try {
                                if (exoPlayer.playbackState != androidx.media3.common.Player.STATE_ENDED && !isPaused) {
                                    exoPlayer.play()
                                }
                            } catch (e: Exception) {}
                        }
                    }
                }
                else -> {}
            }
        }

        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }
    // Advanced video player states
    var currentPosMs by remember { mutableLongStateOf(0L) }
    var bufferedPosMs by remember { mutableLongStateOf(0L) }
    var durationMs by remember { mutableLongStateOf(0L) }
    var isMuted by remember { mutableStateOf(false) }
    var speed by remember { mutableFloatStateOf(1.0f) }
    var resizeModeState by remember { mutableIntStateOf(AspectRatioFrameLayout.RESIZE_MODE_FIT) }
    var showVideoAdjustmentsPanel by remember { mutableStateOf(false) }
    val colorAdjustments = viewModel?.videoColorAdjustments?.collectAsStateWithLifecycle()?.value
        ?: VideoColorAdjustments()
    var compareSplitRatio by remember { mutableFloatStateOf(1.0f) }
    var isHoldOriginalActive by remember { mutableStateOf(false) }
    var showAudioEffectsPanel by remember { mutableStateOf(false) }
    val audioEffectConfig = viewModel?.audioEffectConfig?.collectAsStateWithLifecycle()?.value
        ?: AudioEffectConfig()
    val vocalReductionConfig = viewModel?.vocalReductionConfig?.collectAsStateWithLifecycle()?.value
        ?: VocalReductionConfig()
    var isStereoSourceCompatible by remember { mutableStateOf(true) }

    DisposableEffect(vocalReductionProcessor) {
        vocalReductionProcessor.onCompatibilityChanged = { compatible ->
            isStereoSourceCompatible = compatible
        }
        onDispose {
            vocalReductionProcessor.onCompatibilityChanged = null
        }
    }

    LaunchedEffect(vocalReductionConfig.strength, vocalReductionConfig.mode) {
        vocalReductionProcessor.strength = if (vocalReductionConfig.mode == VocalReductionMode.OFF) 0.0f else vocalReductionConfig.strength
    }

    // --- SMART PLAYBACK STATES & PERSISTENCE ---
    var resumePromptPosMs by remember(media.id) { mutableStateOf<Long?>(null) }
    var showAddMarkerDialog by remember { mutableStateOf(false) }
    var showMarkerListDialog by remember { mutableStateOf(false) }
    val markers = if (viewModel != null) {
        viewModel.getMarkersFlow(media.id).collectAsStateWithLifecycle(initialValue = emptyList()).value
    } else emptyList()

    LaunchedEffect(media.id) {
        if (viewModel != null) {
            val saved = viewModel.getSavedPlaybackProgress(media.id)
            if (saved != null && saved.lastPositionMs > 3000L && !saved.isCompleted) {
                resumePromptPosMs = saved.lastPositionMs
            }
        }
    }

    DisposableEffect(media.id, media.localPath) {
        onDispose {
            if (viewModel != null) {
                val pos = exoPlayer.currentPosition.coerceAtLeast(0L)
                val dur = exoPlayer.duration.coerceAtLeast(0L)
                viewModel.savePlaybackPosition(media.id, media.localPath, dur, pos)
            }
        }
    }

    LaunchedEffect(isPaused) {
        if (isPaused) {
            exoPlayer.pause()
            if (!isScreenAutoDimmed) {
                applyWindowBrightness(originalWindowBrightness)
            }
        } else {
            exoPlayer.play()
            if (!isScreenAutoDimmed) {
                val activeBrightness = userCustomBrightness ?: originalWindowBrightness
                applyWindowBrightness(activeBrightness)
            }
        }
    }

    // Continuous progress tracking
    LaunchedEffect(exoPlayer, isPaused, media.id, media.localPath) {
        var saveCounter = 0
        while (true) {
            val pos = exoPlayer.currentPosition.coerceAtLeast(0L)
            val dur = exoPlayer.duration.coerceAtLeast(0L)
            if (!isSeekDrag) {
                currentPosMs = pos
            }
            bufferedPosMs = exoPlayer.bufferedPosition.coerceAtLeast(0L)
            durationMs = dur
            if (hasRenderedFirstFrame || pos > 150L || exoPlayer.isPlaying || exoPlayer.playbackState == androidx.media3.common.Player.STATE_READY || exoPlayer.playbackState == androidx.media3.common.Player.STATE_ENDED) {
                if (isBufferLoading) {
                    isBufferLoading = false
                }
            }
            saveCounter++
            if (saveCounter % 20 == 0 && pos > 0L && viewModel != null) {
                viewModel.savePlaybackPosition(media.id, media.localPath, dur, pos)
            }
            delay(150)
        }
    }

    // Sound volumes
    LaunchedEffect(isMuted) {
        exoPlayer.volume = if (isMuted) 0f else 1f
    }

    // Playback speed
    LaunchedEffect(speed) {
        exoPlayer.setPlaybackSpeed(speed)
    }

    // Auto-hiding transient toasts
    LaunchedEffect(toastMessage) {
        if (toastMessage != null) {
            delay(1500)
            toastMessage = null
        }
    }

    var showHeader by remember { mutableStateOf(true) }

    var isLocked by remember { mutableStateOf(false) }
    var isFavorite by remember { mutableStateOf(false) }
    var sleepTimerMinutes by remember { mutableIntStateOf(0) }
    var sleepSecondsRemaining by remember { mutableIntStateOf(0) }
    var showSleepTimerDialog by remember { mutableStateOf(false) }

    val isAnyMenuOrDialogActive = showVideoAdjustmentsPanel ||
        showAudioEffectsPanel ||
        showSleepTimerDialog ||
        showAddMarkerDialog ||
        showMarkerListDialog ||
        showAudioTrackMenu ||
        showSubtitleTrackMenu ||
        showAdvancedPlayerSettings ||
        showCodecSpecsDialog ||
        showExternalPlayerAlert

    // Auto-hide controls after 5 seconds of inactivity
    LaunchedEffect(showHeader, lastInteractionTime, isSeekDrag, isAnyMenuOrDialogActive) {
        if (showHeader) {
            if (!isSeekDrag && !isAnyMenuOrDialogActive) {
                delay(5000L)
                showHeader = false
            }
        }
    }

    LaunchedEffect(sleepTimerMinutes, isPaused) {
        if (sleepTimerMinutes > 0 && !isPaused) {
            if (sleepSecondsRemaining <= 0) {
                sleepSecondsRemaining = sleepTimerMinutes * 60
            }
            val fadeDurationSecs = 30
            while (sleepSecondsRemaining > 0 && !isPaused) {
                delay(1000)
                sleepSecondsRemaining--

                if (sleepSecondsRemaining <= fadeDurationSecs) {
                    val fadeFactor = (sleepSecondsRemaining.toFloat() / fadeDurationSecs).coerceIn(0f, 1f)
                    exoPlayer.volume = fadeFactor
                } else {
                    exoPlayer.volume = 1.0f
                }
            }

            if (sleepSecondsRemaining <= 0 && !isPaused) {
                isPaused = true
                exoPlayer.pause()
                sleepTimerMinutes = 0
                exoPlayer.volume = 1.0f
                toastMessage = "Sleep timer expired. Playback paused with volume fade-out."
            }
        } else if (sleepTimerMinutes == 0) {
            sleepSecondsRemaining = 0
            exoPlayer.volume = 1.0f
        }
    }

    // Auto-dim screen brightness after 30 seconds of inactivity during video playback to save battery
    LaunchedEffect(isPaused, autoDimEnabled, autoDimTimeoutSeconds, lastInteractionTime, isScreenAutoDimmed) {
        if (!isPaused && autoDimEnabled && !isScreenAutoDimmed) {
            val elapsed = System.currentTimeMillis() - lastInteractionTime
            val targetTimeoutMs = autoDimTimeoutSeconds * 1000L
            if (elapsed < targetTimeoutMs) {
                delay(targetTimeoutMs - elapsed)
            }
            if (!isPaused && autoDimEnabled && !isScreenAutoDimmed && (System.currentTimeMillis() - lastInteractionTime >= targetTimeoutMs)) {
                applyWindowBrightness(0.05f) // Dimmed level (5% brightness) to save battery
                isScreenAutoDimmed = true
            }
        }
    }

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .focusRequester(overlayFocusRequester)
            .focusable()
            .onKeyEvent { event ->
                if (event.type == KeyEventType.KeyDown) {
                    registerUserActivity()
                    if (event.key == Key.VolumeUp || event.key == Key.VolumeDown) {
                        showQuickGuide = true
                        false // let system handle it
                    } else false
                } else false
            },
        contentAlignment = if (isMiniMode) Alignment.TopStart else Alignment.Center
    ) {
        val systemInsets = androidx.compose.foundation.layout.WindowInsets.systemBars.asPaddingValues()
        val topInsetPx = with(density) { systemInsets.calculateTopPadding().toPx() }
        val bottomInsetPx = with(density) { systemInsets.calculateBottomPadding().toPx() }
        val leftInsetPx = with(density) { systemInsets.calculateLeftPadding(androidx.compose.ui.unit.LayoutDirection.Ltr).toPx() }
        val rightInsetPx = with(density) { systemInsets.calculateRightPadding(androidx.compose.ui.unit.LayoutDirection.Ltr).toPx() }

        val marginPx = with(density) { 12.dp.toPx() }

        val wPx = with(density) { widthDp.toPx() }
        val hPx = with(density) { heightDp.toPx() }

        val containerWPx = with(density) { maxWidth.toPx() }
        val containerHPx = with(density) { maxHeight.toPx() }

        val minL = leftInsetPx + marginPx
        val maxL = (containerWPx - rightInsetPx - marginPx - wPx).coerceAtLeast(minL)
        val minT = topInsetPx + marginPx
        val maxT = (containerHPx - bottomInsetPx - marginPx - hPx).coerceAtLeast(minT)

        var isMiniPositionInitialized by remember { mutableStateOf(false) }
        var prevWPx by remember { mutableFloatStateOf(0f) }
        var prevHPx by remember { mutableFloatStateOf(0f) }

        LaunchedEffect(isMiniMode, containerWPx, containerHPx, wPx, hPx) {
            if (isMiniMode) {
                if (!isMiniPositionInitialized) {
                    offsetX = maxL
                    offsetY = maxT
                    isMiniPositionInitialized = true
                } else if (miniPlayerState != MiniPlayerState.DRAGGING && miniPlayerState != MiniPlayerState.PINCHING) {
                    if (prevWPx > 0f && prevHPx > 0f && (prevWPx != wPx || prevHPx != hPx)) {
                        val centerX = offsetX + prevWPx / 2f
                        val centerY = offsetY + prevHPx / 2f
                        offsetX = (centerX - wPx / 2f).coerceIn(minL, maxL)
                        offsetY = (centerY - hPx / 2f).coerceIn(minT, maxT)
                    } else {
                        offsetX = offsetX.coerceIn(minL, maxL)
                        offsetY = offsetY.coerceIn(minT, maxT)
                    }
                }
                prevWPx = wPx
                prevHPx = hPx
            } else {
                isMiniPositionInitialized = false
                prevWPx = 0f
                prevHPx = 0f
            }
        }

        if (backdropAlpha > 0.001f) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = backdropAlpha))
            )
        }

        Card(
            modifier = Modifier
                .offset {
                    if (isGestureActive) {
                        IntOffset(offsetX.roundToInt(), offsetY.roundToInt())
                    } else {
                        IntOffset(animOffsetX.roundToInt(), animOffsetY.roundToInt())
                    }
                }
                .padding(paddingDp)
                .size(widthDp, heightDp)
                .graphicsLayer {
                    scaleX = playerScale
                    scaleY = playerScale
                }
                .pointerInput(Unit) {
                    awaitPointerEventScope {
                        while (true) {
                            val event = awaitPointerEvent(androidx.compose.ui.input.pointer.PointerEventPass.Initial)
                            if (event.changes.any { it.pressed }) {
                                registerUserActivity()
                            }
                        }
                    }
                }
                .pointerInput(isFullscreen, isMiniMode, baseWidthDp, baseHeightDp) {
                    if (isMiniMode) {
                        awaitPointerEventScope {
                            var primaryPointerId: androidx.compose.ui.input.pointer.PointerId? = null
                            var secondaryPointerId: androidx.compose.ui.input.pointer.PointerId? = null

                            var initialPinchDistance = 1f
                            var initialScale = 1f
                            var initialPinchCenter = androidx.compose.ui.geometry.Offset.Zero
                            var initialPlayerPos = androidx.compose.ui.geometry.Offset.Zero
                            var isPinchConfirmed = false

                            fun performCornerDocking() {
                                android.util.Log.d("MiniPlayer", "SNAP")
                                miniPlayerState = MiniPlayerState.SNAPPING
                                isDragging = false
                                isPinching = false

                                val baseW = with(density) { baseWidthDp.toPx() }
                                val baseH = with(density) { baseHeightDp.toPx() }
                                val currentWPx = baseW * userMiniScale
                                val currentHPx = baseH * userMiniScale

                                val currentMinL = leftInsetPx + marginPx
                                val currentMaxL = (containerWPx - rightInsetPx - marginPx - currentWPx).coerceAtLeast(currentMinL)
                                val currentMinT = topInsetPx + marginPx
                                val currentMaxT = (containerHPx - bottomInsetPx - marginPx - currentHPx).coerceAtLeast(currentMinT)

                                val boundedX = offsetX.coerceIn(currentMinL, currentMaxL)
                                val boundedY = offsetY.coerceIn(currentMinT, currentMaxT)

                                val cx = boundedX + currentWPx / 2f
                                val cy = boundedY + currentHPx / 2f

                                val corners = listOf(
                                    Pair(currentMinL, currentMinT), // TOP-LEFT
                                    Pair(currentMaxL, currentMinT), // TOP-RIGHT
                                    Pair(currentMinL, currentMaxT), // BOTTOM-LEFT
                                    Pair(currentMaxL, currentMaxT)  // BOTTOM-RIGHT
                                )

                                val nearest = corners.minByOrNull { (cL, cT) ->
                                    val cornerCenterX = cL + currentWPx / 2f
                                    val cornerCenterY = cT + currentHPx / 2f
                                    val dx = cx - cornerCenterX
                                    val dy = cy - cornerCenterY
                                    dx * dx + dy * dy
                                } ?: Pair(currentMaxL, currentMaxT)

                                offsetX = nearest.first
                                offsetY = nearest.second
                            }

                            while (true) {
                                val event = awaitPointerEvent(androidx.compose.ui.input.pointer.PointerEventPass.Main)
                                val pressedChanges = event.changes.filter { it.pressed }

                                val baseW = with(density) { baseWidthDp.toPx() }
                                val baseH = with(density) { baseHeightDp.toPx() }
                                val currentWPx = baseW * userMiniScale
                                val currentHPx = baseH * userMiniScale

                                if (primaryPointerId == null) {
                                    val p = pressedChanges.firstOrNull { change ->
                                        change.position.x in 0f..currentWPx && change.position.y in 0f..currentHPx
                                    }
                                    if (p != null) {
                                        primaryPointerId = p.id
                                        miniPlayerState = MiniPlayerState.DRAGGING
                                        isDragging = true
                                        isPinching = false
                                        isPinchConfirmed = false
                                        p.consume()
                                        android.util.Log.d("MiniPlayer", "ACTION_DOWN")
                                    }
                                } else if (secondaryPointerId == null) {
                                    val p1 = pressedChanges.firstOrNull { it.id == primaryPointerId }
                                    if (p1 == null) {
                                        primaryPointerId = null
                                        android.util.Log.d("MiniPlayer", "ACTION_UP")
                                        if (miniPlayerState == MiniPlayerState.DRAGGING) {
                                            performCornerDocking()
                                        } else {
                                            miniPlayerState = MiniPlayerState.IDLE
                                            isDragging = false
                                            isPinching = false
                                        }
                                    } else {
                                        val p2 = pressedChanges.firstOrNull { change ->
                                            change.id != primaryPointerId &&
                                            (change.pressed && !change.previousPressed)
                                        }
                                        if (p2 != null) {
                                            secondaryPointerId = p2.id
                                            isPinchConfirmed = false

                                            p1.consume()
                                            p2.consume()

                                            val pos1 = androidx.compose.ui.geometry.Offset(offsetX + p1.position.x, offsetY + p1.position.y)
                                            val pos2 = androidx.compose.ui.geometry.Offset(offsetX + p2.position.x, offsetY + p2.position.y)

                                            initialPinchDistance = (pos1 - pos2).getDistance().coerceAtLeast(10f)
                                            initialScale = userMiniScale
                                            initialPinchCenter = androidx.compose.ui.geometry.Offset((pos1.x + pos2.x) / 2f, (pos1.y + pos2.y) / 2f)
                                            initialPlayerPos = androidx.compose.ui.geometry.Offset(offsetX, offsetY)
                                        } else {
                                            val delta = p1.position - p1.previousPosition
                                            p1.consume()

                                            val currentMinL = leftInsetPx + marginPx
                                            val currentMaxL = (containerWPx - rightInsetPx - marginPx - currentWPx).coerceAtLeast(currentMinL)
                                            val currentMinT = topInsetPx + marginPx
                                            val currentMaxT = (containerHPx - bottomInsetPx - marginPx - currentHPx).coerceAtLeast(currentMinT)

                                            if (delta.x != 0f || delta.y != 0f) {
                                                offsetX = (offsetX + delta.x).coerceIn(currentMinL, currentMaxL)
                                                offsetY = (offsetY + delta.y).coerceIn(currentMinT, currentMaxT)
                                                android.util.Log.d("MiniPlayer", "ACTION_MOVE x=$offsetX y=$offsetY")
                                            }
                                        }
                                    }
                                } else {
                                    val p1 = pressedChanges.firstOrNull { it.id == primaryPointerId }
                                    val p2 = pressedChanges.firstOrNull { it.id == secondaryPointerId }

                                    if (p1 != null && p2 != null) {
                                        p1.consume()
                                        p2.consume()

                                        val pos1 = androidx.compose.ui.geometry.Offset(offsetX + p1.position.x, offsetY + p1.position.y)
                                        val pos2 = androidx.compose.ui.geometry.Offset(offsetX + p2.position.x, offsetY + p2.position.y)

                                        val currentDistance = (pos1 - pos2).getDistance()
                                        val pinchThresholdPx = with(density) { 12.dp.toPx() }

                                        if (!isPinchConfirmed) {
                                            if (kotlin.math.abs(currentDistance - initialPinchDistance) > pinchThresholdPx) {
                                                isPinchConfirmed = true
                                                miniPlayerState = MiniPlayerState.PINCHING
                                                isPinching = true
                                                isDragging = false
                                            }
                                        }

                                        if (isPinchConfirmed) {
                                            val scaleFactor = currentDistance / initialPinchDistance
                                            val newScale = (initialScale * scaleFactor).coerceIn(0.50f, 2.50f)
                                            userMiniScale = newScale

                                            val oldWPx = baseW * initialScale
                                            val oldHPx = baseH * initialScale
                                            val newWPx = baseW * newScale
                                            val newHPx = baseH * newScale

                                            val normX = if (oldWPx > 0f) (initialPinchCenter.x - initialPlayerPos.x) / oldWPx else 0.5f
                                            val normY = if (oldHPx > 0f) (initialPinchCenter.y - initialPlayerPos.y) / oldHPx else 0.5f

                                            val currentPinchCenter = androidx.compose.ui.geometry.Offset((pos1.x + pos2.x) / 2f, (pos1.y + pos2.y) / 2f)
                                            val proposedOffsetX = currentPinchCenter.x - normX * newWPx
                                            val proposedOffsetY = currentPinchCenter.y - normY * newHPx

                                            val currentMinL = leftInsetPx + marginPx
                                            val currentMaxL = (containerWPx - rightInsetPx - marginPx - newWPx).coerceAtLeast(currentMinL)
                                            val currentMinT = topInsetPx + marginPx
                                            val currentMaxT = (containerHPx - bottomInsetPx - marginPx - newHPx).coerceAtLeast(currentMinT)

                                            offsetX = proposedOffsetX.coerceIn(currentMinL, currentMaxL)
                                            offsetY = proposedOffsetY.coerceIn(currentMinT, currentMaxT)
                                        } else {
                                            val delta = p1.position - p1.previousPosition
                                            val currentMinL = leftInsetPx + marginPx
                                            val currentMaxL = (containerWPx - rightInsetPx - marginPx - currentWPx).coerceAtLeast(currentMinL)
                                            val currentMinT = topInsetPx + marginPx
                                            val currentMaxT = (containerHPx - bottomInsetPx - marginPx - currentHPx).coerceAtLeast(currentMinT)

                                            if (delta.x != 0f || delta.y != 0f) {
                                                offsetX = (offsetX + delta.x).coerceIn(currentMinL, currentMaxL)
                                                offsetY = (offsetY + delta.y).coerceIn(currentMinT, currentMaxT)
                                                android.util.Log.d("MiniPlayer", "ACTION_MOVE x=$offsetX y=$offsetY")
                                            }
                                        }
                                    } else if (p1 != null && p2 == null) {
                                        secondaryPointerId = null
                                        isPinchConfirmed = false
                                        miniPlayerState = MiniPlayerState.DRAGGING
                                        isPinching = false
                                        isDragging = true
                                        p1.consume()
                                    } else if (p1 == null && p2 != null) {
                                        primaryPointerId = p2.id
                                        secondaryPointerId = null
                                        isPinchConfirmed = false
                                        miniPlayerState = MiniPlayerState.DRAGGING
                                        isPinching = false
                                        isDragging = true
                                        p2.consume()
                                    } else {
                                        primaryPointerId = null
                                        secondaryPointerId = null
                                        isPinchConfirmed = false
                                        android.util.Log.d("MiniPlayer", "ACTION_UP")
                                        if (miniPlayerState == MiniPlayerState.DRAGGING) {
                                            performCornerDocking()
                                        } else {
                                            miniPlayerState = MiniPlayerState.IDLE
                                            isDragging = false
                                            isPinching = false
                                        }
                                    }
                                }
                            }
                        }
                    } else if (isFullscreen) {
                        detectDragGestures(
                            onDragStart = { isDragging = true },
                            onDragEnd = {
                                isDragging = false
                                if (offsetY > 100f) {
                                    onToggleFullscreen()
                                    offsetX = 0f
                                    offsetY = 0f
                                } else {
                                    offsetX = 0f
                                    offsetY = 0f
                                }
                            },
                            onDragCancel = {
                                isDragging = false
                                offsetX = 0f
                                offsetY = 0f
                            },
                            onDrag = { change, dragAmount ->
                                change.consume()
                                if (dragAmount.y > 0 || offsetY > 0) {
                                    offsetX += dragAmount.x * 0.5f
                                    offsetY = (offsetY + dragAmount.y).coerceAtLeast(0f)
                                }
                            }
                        )
                    }
                }
                .clip(RoundedCornerShape(cornerRadius))
                .border(1.dp, if (isFullscreen && cornerRadius < 1.dp) Color.Transparent else SleekBorderColor, RoundedCornerShape(cornerRadius))
                .shadow(shadowElevationDp, RoundedCornerShape(cornerRadius)),
            colors = CardDefaults.cardColors(containerColor = SleekCardDark),
            shape = RoundedCornerShape(cornerRadius)
        ) {
            Box(modifier = Modifier.fillMaxSize()) {
                val allowPlayerGestures = isFullscreen && !isCustomPipMini && !isLocked
                val playerGestureSettings = viewModel?.playerGestureSettings?.collectAsStateWithLifecycle()?.value ?: PlayerGestureSettings()

                val executeCustomGestureAction: (PlayerGesture) -> Unit = { gesture ->
                    val action = playerGestureSettings.getActionFor(gesture)
                    when (action) {
                        PlayerGestureAction.NONE -> {}
                        PlayerGestureAction.PLAY_PAUSE -> {
                            isPaused = !isPaused
                            toastMessage = if (isPaused) "Paused" else "Playing"
                            registerUserActivity()
                        }
                        PlayerGestureAction.MUTE_UNMUTE -> {
                            isMuted = !isMuted
                            toastMessage = if (isMuted) "Muted" else "Unmuted"
                            registerUserActivity()
                        }
                        PlayerGestureAction.NEXT_MEDIA -> {
                            val nextMarker = markers.filter { it.positionMs > currentPosMs + 1000L }.minByOrNull { it.positionMs }
                            if (nextMarker != null) {
                                exoPlayer.seekTo(nextMarker.positionMs)
                                currentPosMs = nextMarker.positionMs
                                toastMessage = "Marker: ${nextMarker.note.ifBlank { "Next" }}"
                            } else {
                                val target = (currentPosMs + 30000L).coerceAtMost(durationMs)
                                exoPlayer.seekTo(target)
                                currentPosMs = target
                                toastMessage = "Jump +30s"
                            }
                            registerUserActivity()
                        }
                        PlayerGestureAction.PREVIOUS_MEDIA -> {
                            val prevMarker = markers.filter { it.positionMs < currentPosMs - 1000L }.maxByOrNull { it.positionMs }
                            if (prevMarker != null) {
                                exoPlayer.seekTo(prevMarker.positionMs)
                                currentPosMs = prevMarker.positionMs
                                toastMessage = "Marker: ${prevMarker.note.ifBlank { "Previous" }}"
                            } else {
                                val target = (currentPosMs - 30000L).coerceAtLeast(0L)
                                exoPlayer.seekTo(target)
                                currentPosMs = target
                                toastMessage = "Jump -30s"
                            }
                            registerUserActivity()
                        }
                        PlayerGestureAction.SEEK_FORWARD_10 -> {
                            val target = (currentPosMs + 10000L).coerceAtMost(durationMs)
                            exoPlayer.seekTo(target)
                            currentPosMs = target
                            toastMessage = "Forward 10s"
                            showRightIndicator = true
                            showLeftIndicator = false
                            registerUserActivity()
                        }
                        PlayerGestureAction.SEEK_BACKWARD_10 -> {
                            val target = (currentPosMs - 10000L).coerceAtLeast(0L)
                            exoPlayer.seekTo(target)
                            currentPosMs = target
                            toastMessage = "Rewind 10s"
                            showLeftIndicator = true
                            showRightIndicator = false
                            registerUserActivity()
                        }
                        PlayerGestureAction.SPEED_TOGGLE -> {
                            val nextSpeed = when (speed) {
                                1.0f -> 1.25f
                                1.25f -> 1.5f
                                1.5f -> 2.0f
                                2.0f -> 0.5f
                                0.5f -> 0.75f
                                else -> 1.0f
                            }
                            speed = nextSpeed
                            toastMessage = "Speed: ${nextSpeed}x"
                            registerUserActivity()
                        }
                        PlayerGestureAction.OPEN_CONTROLS -> {
                            showHeader = !showHeader
                            registerUserActivity()
                        }
                        PlayerGestureAction.LOCK_PLAYER -> {
                            isLocked = !isLocked
                            toastMessage = if (isLocked) "Player Locked" else "Player Unlocked"
                            registerUserActivity()
                        }
                        PlayerGestureAction.SCREENSHOT -> {
                            scope.launch {
                                val (ok, msg) = PlayerGestureActionsDispatcher.captureFrameScreenshot(
                                    context = context,
                                    localPath = media.localPath,
                                    positionMs = currentPosMs
                                )
                                toastMessage = msg
                            }
                            registerUserActivity()
                        }
                    }
                }

                // Video Surface (Always spans the full background)
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black)
                        .playerCustomGestures(
                            enabled = allowPlayerGestures,
                            settings = playerGestureSettings,
                            onTriggerGesture = executeCustomGestureAction
                        )
                        .pointerInput(allowPlayerGestures, isMiniMode) {
                            if (allowPlayerGestures) {
                                detectTapGestures(
                                    onDoubleTap = { offset ->
                                        val w = size.width.toFloat()
                                        if (offset.x >= 0.3f * w && offset.x <= 0.7f * w) {
                                            val isLeft = offset.x < 0.5f * w
                                            if (isLeft) {
                                                val target = (currentPosMs - 10000L).coerceAtLeast(0L)
                                                exoPlayer.seekTo(target)
                                                currentPosMs = target
                                                toastMessage = "Rewind 10s"
                                                showLeftIndicator = true
                                                showRightIndicator = false
                                            } else {
                                                val target = (currentPosMs + 10000L).coerceAtMost(durationMs)
                                                exoPlayer.seekTo(target)
                                                currentPosMs = target
                                                toastMessage = "Forward 10s"
                                                showRightIndicator = true
                                                showLeftIndicator = false
                                            }
                                        }
                                    },
                                    onLongPress = { offset ->
                                        val w = size.width.toFloat()
                                        if (offset.x >= 0.3f * w && offset.x <= 0.7f * w) {
                                            if (playerGestureSettings.getActionFor(PlayerGesture.LONG_PRESS) != PlayerGestureAction.NONE) {
                                                executeCustomGestureAction(PlayerGesture.LONG_PRESS)
                                            }
                                        }
                                    },
                                    onTap = { offset ->
                                        showHeader = !showHeader
                                        registerUserActivity()
                                    }
                                )
                            } else if (isMiniMode) {
                                detectTapGestures(
                                    onTap = {
                                        registerUserActivity()
                                    },
                                    onDoubleTap = {
                                        viewModel?.setCustomPipMini(false)
                                        if (!isFullscreen) {
                                            onToggleFullscreen()
                                        }
                                        registerUserActivity()
                                    }
                                )
                            } else {
                                detectTapGestures(
                                    onTap = {
                                        showHeader = !showHeader
                                        registerUserActivity()
                                    }
                                )
                            }
                        }
                        .pointerInput(allowPlayerGestures) {
                            if (allowPlayerGestures) {
                                detectDragGestures(
                                    onDragStart = { offset ->
                                        totalDragY = 0f
                                        totalDragX = 0f
                                        val x = offset.x
                                        val w = size.width.toFloat()
                                        
                                        isBrightnessDrag = x < 0.30f * w
                                        isVolumeDrag = x > 0.70f * w
                                        isSeekDrag = !isBrightnessDrag && !isVolumeDrag
                                        swipeDirectionResolved = false
                                        isVerticalSwipe = false
                                        isHorizontalSwipe = false
                                        
                                        if (isBrightnessDrag) {
                                            initialBrightness = userCustomBrightness ?: run {
                                                val window = (context as? android.app.Activity)?.window
                                                val br = window?.attributes?.screenBrightness ?: -1f
                                                if (br >= 0f) br else {
                                                    try {
                                                        val sysBrightness = android.provider.Settings.System.getInt(context.contentResolver, android.provider.Settings.System.SCREEN_BRIGHTNESS)
                                                        sysBrightness / 255f
                                                    } catch (e: Exception) {
                                                        0.5f
                                                    }
                                                }
                                            }
                                        } else if (isVolumeDrag) {
                                            initialVolume = audioManager.getStreamVolume(android.media.AudioManager.STREAM_MUSIC)
                                            initialVolumeBoost = viewModel?.volumeBoost?.value ?: 0f
                                        } else if (isSeekDrag) {
                                            initialSeekPos = currentPosMs
                                        }
                                    },
                                    onDragEnd = {
                                        isBrightnessDrag = false
                                        isVolumeDrag = false
                                        if (isSeekDrag && swipeDirectionResolved && isHorizontalSwipe) {
                                            exoPlayer.seekTo(currentPosMs)
                                        }
                                        isSeekDrag = false
                                    },
                                    onDragCancel = {
                                        isBrightnessDrag = false
                                        isVolumeDrag = false
                                        if (isSeekDrag && swipeDirectionResolved && isHorizontalSwipe) {
                                            exoPlayer.seekTo(initialSeekPos)
                                            currentPosMs = initialSeekPos
                                        }
                                        isSeekDrag = false
                                    },
                                    onDrag = { change, dragAmount ->
                                        change.consume()
                                        totalDragX += dragAmount.x
                                        totalDragY += dragAmount.y
                                        
                                        if (!swipeDirectionResolved) {
                                            val minSwipeDistance = with(density) { 24.dp.toPx() }
                                            if (kotlin.math.abs(totalDragY) >= minSwipeDistance || kotlin.math.abs(totalDragX) >= minSwipeDistance) {
                                                swipeDirectionResolved = true
                                                if (kotlin.math.abs(totalDragY) > kotlin.math.abs(totalDragX)) {
                                                    isVerticalSwipe = true
                                                } else {
                                                    isHorizontalSwipe = true
                                                }
                                            }
                                        }
                                        
                                        if (swipeDirectionResolved) {
                                            if (isVerticalSwipe) {
                                                val height = size.height.toFloat()
                                                val deltaRatio = -(totalDragY / height) * 1.5f
                                                if (isBrightnessDrag) {
                                                    val newBrightness = (initialBrightness + deltaRatio).coerceIn(0f, 1f)
                                                    userCustomBrightness = newBrightness
                                                    if (!isPaused && !isScreenAutoDimmed) {
                                                        applyWindowBrightness(newBrightness)
                                                    }
                                                    registerUserActivity()
                                                } else if (isVolumeDrag) {
                                                    val currentSystemRatio = initialVolume.toFloat() / maxVolume
                                                    val currentBoostRatio = initialVolumeBoost / 100f
                                                    val currentTotalRatio = currentSystemRatio + currentBoostRatio
                                                    
                                                    val rawTotalRatio = (currentTotalRatio + deltaRatio).coerceIn(0f, 2f)
                                                    
                                                    val newTotalRatio = if (rawTotalRatio > 1f) {
                                                        if (rawTotalRatio <= 1.125f) 1f
                                                        else if (rawTotalRatio <= 1.375f) 1.25f
                                                        else if (rawTotalRatio <= 1.75f) 1.5f
                                                        else 2f
                                                    } else {
                                                        rawTotalRatio
                                                    }
                                                    
                                                    val newSystemRatio = newTotalRatio.coerceIn(0f, 1f)
                                                    val newBoostRatio = (newTotalRatio - 1f).coerceIn(0f, 1f)
                                                    
                                                    audioManager.setStreamVolume(android.media.AudioManager.STREAM_MUSIC, (newSystemRatio * maxVolume).toInt(), 0)
                                                    viewModel?.updateVolumeBoost(newBoostRatio * 100f)
                                                    registerUserActivity()
                                                }
                                            } else if (isHorizontalSwipe && isSeekDrag) {
                                                val width = size.width.toFloat()
                                                val seekDeltaMs = (totalDragX / width) * 90000f
                                                val target = (initialSeekPos + seekDeltaMs.toLong()).coerceIn(0L, durationMs)
                                                currentPosMs = target
                                                registerUserActivity()
                                            }
                                        }
                                    }
                                )
                            }
                        },
                    contentAlignment = Alignment.Center
                ) {
                    AndroidView<PlayerView>(
                        factory = { ctx ->
                            (android.view.LayoutInflater.from(ctx).inflate(com.example.R.layout.media_player_texture_view, null) as PlayerView).apply {
                                layoutParams = android.view.ViewGroup.LayoutParams(
                                    android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                                    android.view.ViewGroup.LayoutParams.MATCH_PARENT
                                )
                                useController = false
                                resizeMode = resizeModeState
                                player = exoPlayer

                                addOnAttachStateChangeListener(object : android.view.View.OnAttachStateChangeListener {
                                    override fun onViewAttachedToWindow(v: android.view.View) {
                                        val act = v.context as? android.app.Activity
                                        val isValid = act == null || (!act.isFinishing && !act.isDestroyed)
                                        if (isValid && (v as? PlayerView)?.player != exoPlayer) {
                                            (v as? PlayerView)?.player = exoPlayer
                                        }
                                    }

                                    override fun onViewDetachedFromWindow(v: android.view.View) {
                                    }
                                })
                            }
                        },
                        update = { view ->
                            val act = view.context as? android.app.Activity
                            val isValid = act == null || (!act.isFinishing && !act.isDestroyed)
                            view.resizeMode = resizeModeState
                            if (isValid) {
                                if (view.player != exoPlayer) {
                                    view.player = exoPlayer
                                }
                            }

                            // Real-time GPU Color Adjustments on TextureView surface
                            val targetView = view.videoSurfaceView ?: view
                            val activeAdjustments = if (isHoldOriginalActive) {
                                VideoColorAdjustments()
                            } else if (compareSplitRatio < 1.0f) {
                                val def = VideoColorAdjustments()
                                VideoColorAdjustments(
                                    brightness = def.brightness + (colorAdjustments.brightness - def.brightness) * compareSplitRatio,
                                    contrast = def.contrast + (colorAdjustments.contrast - def.contrast) * compareSplitRatio,
                                    saturation = def.saturation + (colorAdjustments.saturation - def.saturation) * compareSplitRatio,
                                    gamma = def.gamma + (colorAdjustments.gamma - def.gamma) * compareSplitRatio,
                                    sharpness = def.sharpness + (colorAdjustments.sharpness - def.sharpness) * compareSplitRatio,
                                    temperature = def.temperature + (colorAdjustments.temperature - def.temperature) * compareSplitRatio,
                                    highlights = def.highlights + (colorAdjustments.highlights - def.highlights) * compareSplitRatio,
                                    shadows = def.shadows + (colorAdjustments.shadows - def.shadows) * compareSplitRatio,
                                    vibrance = def.vibrance + (colorAdjustments.vibrance - def.vibrance) * compareSplitRatio,
                                    tint = def.tint + (colorAdjustments.tint - def.tint) * compareSplitRatio
                                )
                            } else {
                                colorAdjustments
                            }

                            if (activeAdjustments.isDefault) {
                                targetView.setLayerType(android.view.View.LAYER_TYPE_NONE, null)
                                view.setLayerType(android.view.View.LAYER_TYPE_NONE, null)
                                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S) {
                                    targetView.setRenderEffect(null)
                                    view.setRenderEffect(null)
                                }
                            } else {
                                val cm = calculateVideoColorMatrix(
                                    brightness = activeAdjustments.brightness,
                                    contrast = activeAdjustments.contrast,
                                    saturation = activeAdjustments.saturation,
                                    gamma = activeAdjustments.gamma,
                                    sharpness = activeAdjustments.sharpness,
                                    temperature = activeAdjustments.temperature,
                                    highlights = activeAdjustments.highlights,
                                    shadows = activeAdjustments.shadows,
                                    vibrance = activeAdjustments.vibrance,
                                    tint = activeAdjustments.tint
                                )
                                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S) {
                                    val effect = android.graphics.RenderEffect.createColorFilterEffect(
                                        android.graphics.ColorMatrixColorFilter(cm)
                                    )
                                    targetView.setRenderEffect(effect)
                                } else {
                                    val paint = android.graphics.Paint().apply {
                                        colorFilter = android.graphics.ColorMatrixColorFilter(cm)
                                    }
                                    targetView.setLayerType(android.view.View.LAYER_TYPE_HARDWARE, paint)
                                }
                            }
                        },
                        onRelease = { view ->
                            view.player = null
                        },
                        modifier = Modifier.fillMaxSize()
                    )

                    // Middle Split Comparison Line & Handle Overlay
                    if (showVideoAdjustmentsPanel && (!colorAdjustments.isDefault || compareSplitRatio < 1.0f)) {
                        BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
                            val wPx = constraints.maxWidth.toFloat()
                            val splitX = (wPx * compareSplitRatio).coerceIn(0f, wPx)

                            // Vertical divider line
                            Box(
                                modifier = Modifier
                                    .offset { androidx.compose.ui.unit.IntOffset(splitX.toInt(), 0) }
                                    .width(2.dp)
                                    .fillMaxHeight()
                                    .background(Color(0xFFFFAB40))
                            )

                            // Draggable Handle Badge
                            Surface(
                                shape = RoundedCornerShape(20.dp),
                                color = Color(0xEC10141D),
                                border = BorderStroke(1.5.dp, Color(0xFFFFAB40)),
                                shadowElevation = 8.dp,
                                modifier = Modifier
                                    .align(Alignment.CenterStart)
                                    .offset { androidx.compose.ui.unit.IntOffset((splitX - 60.dp.toPx()).toInt().coerceIn(16, (wPx - 120.dp.toPx()).toInt().coerceAtLeast(16)), 0) }
                                    .pointerInput(Unit) {
                                        detectHorizontalDragGestures { change, dragAmount ->
                                            change.consume()
                                            val newRatio = ((splitX + dragAmount) / wPx).coerceIn(0f, 1f)
                                            compareSplitRatio = newRatio
                                        }
                                    }
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Text("BEFORE", fontSize = 9.sp, fontWeight = FontWeight.ExtraBold, color = SleekTextMuted)
                                    Icon(Icons.Default.SwapHoriz, contentDescription = null, tint = Color(0xFFFFAB40), modifier = Modifier.size(14.dp))
                                    Text("AFTER", fontSize = 9.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFFFFAB40))
                                }
                            }
                        }
                    }

                    // Left Double Tap Feedback Overlay
                    androidx.compose.animation.AnimatedVisibility(
                        visible = showLeftIndicator,
                        enter = fadeIn() + scaleIn(initialScale = 0.8f),
                        exit = fadeOut(),
                        modifier = Modifier.align(Alignment.CenterStart)
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxHeight()
                                .fillMaxWidth(0.45f)
                                .background(
                                    Brush.horizontalGradient(
                                        colors = listOf(
                                            Color.White.copy(alpha = 0.15f),
                                            Color.Transparent
                                        )
                                    )
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(
                                    imageVector = Icons.Default.FastRewind,
                                    contentDescription = "Rewind",
                                    tint = Color.White,
                                    modifier = Modifier.size(36.dp)
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "Rewind 10s",
                                    color = Color.White,
                                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
                                )
                            }
                        }
                    }

                    // Right Double Tap Feedback Overlay
                    androidx.compose.animation.AnimatedVisibility(
                        visible = showRightIndicator,
                        enter = fadeIn() + scaleIn(initialScale = 0.8f),
                        exit = fadeOut(),
                        modifier = Modifier.align(Alignment.CenterEnd)
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxHeight()
                                .fillMaxWidth(0.45f)
                                .background(
                                    Brush.horizontalGradient(
                                        colors = listOf(
                                            Color.Transparent,
                                            Color.White.copy(alpha = 0.15f)
                                        )
                                    )
                                ),
                            contentAlignment = Alignment.Center
                        ) {
}
}
}
}
}
}

        if (showExternalPlayerAlert) {
            androidx.compose.material3.AlertDialog(
                onDismissRequest = { showExternalPlayerAlert = false },
                title = { androidx.compose.material3.Text("Playback Error") },
                text = { androidx.compose.material3.Text(playerError ?: "Unknown Error") },
                confirmButton = {
                    androidx.compose.material3.TextButton(onClick = { showExternalPlayerAlert = false }) {
                        androidx.compose.material3.Text("Dismiss")
                    }
                },
                dismissButton = {
                    androidx.compose.material3.TextButton(onClick = {
                        val report = com.example.ui.DiagnosticReportGenerator.generateReport(context, media, playerError)
                        val clipboard = context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                        val clip = android.content.ClipData.newPlainText("Codec Report", report)
                        clipboard.setPrimaryClip(clip)
                        android.widget.Toast.makeText(context, "Codec report copied", android.widget.Toast.LENGTH_SHORT).show()
                    }) {
                        androidx.compose.material3.Text("COPY CODEC REPORT")
                    }
                }
            )
        }
}
