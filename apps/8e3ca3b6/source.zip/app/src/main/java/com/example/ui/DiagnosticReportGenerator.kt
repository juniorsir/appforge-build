package com.example.ui

import android.content.Context
import android.os.Build
import com.example.data.DownloadEntity
import com.arthenica.ffmpegkit.FFmpegKitConfig

object DiagnosticReportGenerator {
    fun generateReport(
        context: Context,
        media: DownloadEntity,
        playerError: String?
    ): String {
        val sb = StringBuilder()
        sb.appendLine("--- CODEC DIAGNOSTIC REPORT ---")
        sb.appendLine("Device: ${Build.MANUFACTURER} ${Build.MODEL} (${Build.DEVICE})")
        sb.appendLine("Android API: ${Build.VERSION.SDK_INT}")
        sb.appendLine("Supported ABIs: ${Build.SUPPORTED_ABIS.joinToString(", ")}")
        sb.appendLine("FFmpegKit Version: ${FFmpegKitConfig.getFFmpegVersion()}")
        
        sb.appendLine()
        sb.appendLine("--- FILE INFORMATION ---")
        sb.appendLine("Title: ${media.title}")
        // Redact local path for privacy, just show extension
        val extension = media.localPath.substringAfterLast('.', "")
        sb.appendLine("Container/Extension: $extension")
        
        sb.appendLine()
        sb.appendLine("--- PLAYBACK STATUS ---")
        sb.appendLine("Player Compatibility: ${if (playerError == null) "Supported" else "Failed"}")
        if (playerError != null) {
            sb.appendLine("Failure Reason: $playerError")
            sb.appendLine("Root-cause Analysis: Incompatible codec or container format for device decoders.")
            sb.appendLine("Recommendation: Remux or transcode the file using the app's fallback engine.")
        } else {
            sb.appendLine("Recommendation: File is supported by direct playback.")
        }
        
        return sb.toString()
    }
}
