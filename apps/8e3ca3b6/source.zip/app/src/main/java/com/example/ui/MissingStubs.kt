package com.example.ui

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import android.content.Context
import android.graphics.ColorMatrix
import com.example.data.DownloadEntity
import com.example.ui.VideoFormatUi

val InstagramSunsetGradient = Brush.linearGradient(listOf(Color.Red, Color.Yellow))

@Composable
fun VideoCompressionDialog(
    state: Any? = null,
    onSelectPreset: (String) -> Unit = {},
    onUpdateCustomOptions: (Int, Int, Int, Int, Int) -> Unit = {_,_,_,_,_->},
    onCompress: () -> Unit = {},
    onCancelCompress: () -> Unit = {},
    onOpenCompressed: (DownloadEntity) -> Unit = {},
    onShareCompressed: (String) -> Unit = {},
    onDismiss: () -> Unit = {},
    media: Any? = null
) {}

@Composable fun MediaTrimmerDialog(
    state: Any? = null,
    onSelectPreset: (String) -> Unit = {},
    onUpdateCustomOptions: (Int, Int, Int, Int, Int) -> Unit = {_,_,_,_,_->},
    onCompress: () -> Unit = {},
    onCancelCompress: () -> Unit = {},
    onOpenCompressed: (Any?) -> Unit = {},
    onShareCompressed: (String) -> Unit = {},
    onShareExported: (String) -> Unit = {},
    onExportAudio: () -> Unit = {},
    onExportVideo: () -> Unit = {},
    onTrim: () -> Unit = {},
    onDismiss: () -> Unit = {},
    onUpdateRange: (Long, Long) -> Unit = {_,_->},
    onPreview: () -> Unit = {},
    onExport: () -> Unit = {},
    onCancelExport: () -> Unit = {},
    onOpenExported: (DownloadEntity) -> Unit = {}
) {}

@Composable fun AudioFxStudioModal(onDismiss: () -> Unit = {}, viewModel: Any? = null) {}
@Composable fun BatchQueueManagerModal(onDismiss: () -> Unit = {}, viewModel: Any? = null) {}
@Composable fun MetadataEditorModal(media: Any? = null, onDismiss: () -> Unit = {}, item: Any? = null, viewModel: Any? = null) {}
@Composable fun DownloadSchedulerModal(media: Any? = null, onDismiss: () -> Unit = {}, viewModel: Any? = null, videoTitle: Any? = null, videoUrl: Any? = null, formatQuality: Any? = null, formatExt: Any? = null) {}
@Composable fun AddToPlaylistModal(media: Any? = null, onDismiss: () -> Unit = {}, item: Any? = null, viewModel: Any? = null, onCreateNewRequest: Any? = null) {}
@Composable fun CreatePlaylistModal(onDismiss: () -> Unit = {}, viewModel: Any? = null) {}

@Composable fun FloatingPlayerOverlay(media: Any? = null, isFullscreen: Boolean = false, analyzedVideo: Any? = null, onStreamFormat: ((VideoFormatUi) -> Unit)? = null, onToggleFullscreen: () -> Unit = {}, onClose: () -> Unit = {}, viewModel: Any? = null, onOpenAudioFxStudio: () -> Unit = {}) {}
@Composable fun FluidIncognitoButton(onClick: () -> Unit = {}, modifier: Modifier = Modifier, isActive: Boolean = false, isIncognitoMode: Boolean = false, onToggle: () -> Unit = {}) {}

@Composable fun YouTubeBackgroundMiniPlayerBar(
    media: Any? = null,
    isPlaying: Boolean = false,
    currentPosMs: Long = 0,
    durationMs: Long = 0,
    onTogglePlay: () -> Unit = {},
    onSeekRelative: (Long) -> Unit = {},
    onOpenFullPlayer: () -> Unit = {},
    onClose: () -> Unit = {},
    modifier: Modifier = Modifier
) {}

@Composable fun LiquidGlassIcon(
    imageVector: ImageVector,
    contentDescription: String?,
    isSelected: Boolean = false,
    containerSize: Dp = 0.dp,
    size: Dp = 0.dp,
    onClick: () -> Unit = {}
) {}

@Composable fun CrazyAnimationOrb() {}

@Composable fun CoverflowCarousel(
    items: List<Any?> = emptyList(),
    onItemClick: (String) -> Unit = {},
    onPlayClick: (Any?) -> Unit = {},
    onDownloadClick: (Any?) -> Unit = {}
) {}

@Composable fun SleepTimerDialog(
    onDismiss: () -> Unit = {},
    onSetTimer: (Int) -> Unit = {},
    currentMinutes: Int = 0,
    currentSecondsRemaining: Int = 0,
    onSelectMinutes: (Int) -> Unit = {}
) {}

class ExoPlayerAudioFxEngine(player: Any? = null, exoPlayer: Any? = null, viewModel: Any? = null) {
    fun release() {}
}

fun calculateVideoColorMatrix(
    brightness: Float = 1f,
    contrast: Float = 1f,
    saturation: Float = 1f,
    gamma: Float = 1f,
    sharpness: Float = 0f,
    temperature: Float = 0f,
    highlights: Float = 0f,
    shadows: Float = 0f,
    vibrance: Float = 0f,
    tint: Float = 0f
): ColorMatrix = ColorMatrix()

fun openInstagramProfile(context: Context, username: String) {}

@Composable fun InstagramIcon(modifier: Modifier = Modifier, useGradient: Boolean = false) {}

val Any?.url: String get() = ""
fun Any?.downloadUrl(): String = ""
fun Any?.sizeBytes(): Long = 0L
fun isAudioFormat(format: Any?): Boolean = false
val VideoFormatUi.acodec: String get() = ""
val Any?.hasAudio: Boolean get() = false

fun responsiveSp(min: Float, max: Float): TextUnit = min.sp
