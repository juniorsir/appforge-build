package com.example.media.playback

import android.content.Context
import android.net.Uri
import android.util.Log
import com.example.media.DecoderCapabilityManager
import com.example.media.probe.MediaProbeEngine
import com.example.media.probe.MediaProbeInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object PlaybackFallbackEngine {
    private const val TAG = "PlaybackFallbackEngine"

    suspend fun evaluatePlaybackStrategy(context: Context, uri: Uri): PlaybackCompatibilityResult = withContext(Dispatchers.IO) {
        com.example.media.preview.FrpPreviewEngine.setActivePlaybackSource(uri, uri.path)
        val probeResult = MediaProbeEngine.probeMedia(context, uri)

        if (probeResult.isFailure) {
            return@withContext PlaybackCompatibilityResult(
                strategy = PlaybackStrategy.DIRECT_HARDWARE,
                reason = "Probe skipped; attempting default ExoPlayer hardware playback",
                containerFormat = "unknown",
                videoCodec = "unknown",
                audioCodec = "unknown"
            )
        }

        val probeInfo = probeResult.getOrThrow()
        val format = probeInfo.format.lowercase()
        val video = probeInfo.primaryVideo
        val audio = probeInfo.primaryAudio

        val videoCodec = video?.codec?.lowercase() ?: "none"
        val audioCodec = audio?.codec?.lowercase() ?: "none"

        Log.d(TAG, "Evaluating playback: format=$format, video=$videoCodec, audio=$audioCodec")

        // Analyze hardware capabilities
        val isVideoHardwareSupported = video?.decoderEvaluation?.isSupported ?: true // Assume true if missing or none
        val isAudioHardwareSupported = audio?.decoderEvaluation?.isSupported ?: true
        
        // 1. Direct hardware playback checks
        val isStandardContainer = format.contains("mp4") ||
                format.contains("matroska") ||
                format.contains("webm") ||
                format.contains("mov") ||
                format.contains("mp3") ||
                format.contains("aac") ||
                format.contains("ogg") ||
                format.contains("flac") ||
                format.contains("mpegts")

        if (isStandardContainer && isVideoHardwareSupported && isAudioHardwareSupported) {
            return@withContext PlaybackCompatibilityResult(
                strategy = PlaybackStrategy.DIRECT_HARDWARE,
                reason = "Codecs are hardware-compatible; attempting direct playback.",
                containerFormat = format,
                videoCodec = videoCodec,
                audioCodec = audioCodec
            )
        }

        // 2. Container problem, but codecs supported -> Remux!
        if (isVideoHardwareSupported && isAudioHardwareSupported) {
            return@withContext PlaybackCompatibilityResult(
                strategy = PlaybackStrategy.REMUX_REQUIRED,
                reason = "Codecs supported but container is problematic ($format); remuxing to MP4 container.",
                containerFormat = format,
                videoCodec = videoCodec,
                audioCodec = audioCodec,
                requiresRemux = true
            )
        }

        // 3. Audio unsupported, Video supported -> Transcode audio only
        if (isVideoHardwareSupported && !isAudioHardwareSupported) {
            return@withContext PlaybackCompatibilityResult(
                strategy = PlaybackStrategy.TRANSCODE_REQUIRED,
                reason = "Unsupported audio codec ($audioCodec); transcoding audio stream only (copying video).",
                containerFormat = format,
                videoCodec = videoCodec,
                audioCodec = audioCodec,
                requiresTranscode = true
            )
        }

        // 4. Video unsupported -> Transcode
        return@withContext PlaybackCompatibilityResult(
            strategy = PlaybackStrategy.TRANSCODE_REQUIRED,
            reason = "Unsupported video codec ($videoCodec); full transcode required.",
            containerFormat = format,
            videoCodec = videoCodec,
            audioCodec = audioCodec,
            requiresTranscode = true
        )
    }
}
