lines = File.readlines("app/src/main/java/com/example/ui/VideoDownloaderScreen.kt")
lines.each_with_index do |line, index|
  if line.include?("showExternalPlayerAlert") && !line.include?("var showExternalPlayerAlert") && !line.include?("showExternalPlayerAlert =")
    puts "#{index + 1}: #{line}"
  end
end
