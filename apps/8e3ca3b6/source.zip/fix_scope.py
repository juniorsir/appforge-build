with open("app/src/main/java/com/example/ui/VideoDownloaderScreen.kt", "r") as f:
    content = f.read()

# Fix the first catch block (remove playbackScope.launch)
old_catch = """        } catch (e: Exception) {
            playbackScope.launch {
                playerError = mediaEngine.formatPlaybackErrorLog(androidx.media3.common.PlaybackException(e.message, e, androidx.media3.common.PlaybackException.ERROR_CODE_UNSPECIFIED))
                showExternalPlayerAlert = true
            }
        }"""
new_catch = """        } catch (e: Exception) {
            playerError = mediaEngine.formatPlaybackErrorLog(androidx.media3.common.PlaybackException(e.message, e, androidx.media3.common.PlaybackException.ERROR_CODE_UNSPECIFIED))
            showExternalPlayerAlert = true
        }"""
content = content.replace(old_catch, new_catch)

# Move playbackScope before LaunchedEffect!
# Actually, I don't need to move it since the second catch is inside DisposableEffect, which can access `playbackScope` if it is declared before DisposableEffect (which it is).

with open("app/src/main/java/com/example/ui/VideoDownloaderScreen.kt", "w") as f:
    f.write(content)
