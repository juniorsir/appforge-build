# AeroShare Liquid Glass Power Bundle

A focused three-feature upgrade that elevates the Single-Window Floating HUD and AeroShare Dashboard with hidden fluid gestures, instant system-wide summoning, and live Liquid Glass appearance personalization—without adding a single extra button or visual clutter to the floating HUD.

---

## User Review & Critical Decisions

> [!IMPORTANT]
> Because you selected four feature ideas and chose a **Balanced bundle of 2 to 3 features** while keeping the **HUD minimal with hidden gestures**, this plan delivers the three most cohesive, zero-clutter upgrades together now and queues **Snip Highlighter & Instant Text Copy** as a dedicated next drop. Let me know via **Revise** if you'd prefer to swap Snip Highlighter into this release or build all four at once.

- **Confirmed Scope (Balanced 3-Feature Bundle)**:
  1. **Gesture & Magnetic Edge Dock** — Hidden spring-physics gestures directly on the floating HUD (magnetic left/right edge snap when collapsed, swipe down/up to collapse/expand, double-tap pill for instant voice input, and horizontal header swipe to recall recent prompts).
  2. **Quick Settings Tile & Shake-to-Summon** — Native Android Notification Shade tile to toggle the HUD from any app, paired with an optional double-shake wrist gesture toggle.
  3. **Adaptive Glass & Accent Personalizer** — Live glass frost/opacity control, four curated accent themes, and White / Smoked / Auto glass modes configured from the Dashboard and applied instantly to both Dashboard and HUD.
- **Confirmed UI Posture**: **Keep HUD minimal with hidden gestures** — zero new persistent chrome or icon clutter on the floating HUD; all personalization toggles and sliders live cleanly inside a collapsible Liquid Glass card on the AeroShare Dashboard.
- **Queued for Next Release (Default)**: **Snip Highlighter & Instant Text Copy** (interactive markup strokes + instant text extraction on snipped previews) is deferred to keep this bundle tight, fast, and zero-dependency.

---

## 1. Overview & Core Concept

- **What It Does**: Transforms the floating HUD from a manually positioned overlay into an effortless, gesture-driven companion that can be summoned from anywhere in Android, snaps gracefully out of the way to screen edges, and adapts its translucent Liquid Glass aesthetic to match your mood or lighting.
- **Target Audience / Persona**: Everyday AeroShare power users running Agy over Termux, Chess, browsers, and messaging apps who want instant hands-free access and fluid physical interactions without sacrificing screen real estate.
- **Key Value**: Cuts the friction of opening, collapsing, repositioning, and repeating prompts to a single swipe, double-tap, or shade tile press—while keeping the interface serenely minimal.

---

## 2. User Experience & Visual Design

### Key User Flows

1. **Magnetic Edge Dock & Hidden HUD Gestures**:
   - *Collapse & Snap*: Swipe downward on the expanded HUD header (or tap Collapse). The window morphs in place into the compact draggable pill and springs magnetically toward the nearest left or right screen edge with a clean safe-margin cushion.
   - *Expand*: Single-tap or swipe upward on the docked pill to spring-expand back into the centered or user-positioned card.
   - *Instant Voice*: Double-tap the collapsed pill from any app; the pill expands with spring overshoot and immediately activates voice-to-text listening with a soft haptic pulse.
   - *Prompt Recall*: Swipe left or right along the expanded HUD header to cycle through recent prompts right inside the input pill, showing a subtle one-line subtitle hint (`Prompt 2/8`) that fades back cleanly.
2. **System-Wide Summon (Quick Settings Tile & Shake)**:
   - *Notification Shade Tile*: Pull down Android Quick Settings and tap the **Agy HUD** tile to summon or hide the HUD immediately from any foreground app. The tile reflects live state (`Active` / `Collapsed` / `Off`) and gracefully guides the user if overlay permission is missing.
   - *Double-Shake Summon (Opt-In)*: Enable **Shake to Summon** in the Dashboard's HUD appearance card. A deliberate double-shake while the screen is awake summons or collapses the HUD with a crisp haptic tick and a cooldown guard to prevent accidental pocket triggers.
3. **Adaptive Glass & Accent Personalization**:
   - Open the collapsible **Liquid Glass Style** panel inside the AeroShare Dashboard.
   - Pick from 4 translucent accent moods (**Sky Blue**, **Violet Mist**, **Mint Jade**, **Sunset Coral**), drag the **Glass Frost** slider (`72%` crystal-clear to `95%` porcelain frosted), and switch **Surface Mode** between **White**, **Auto** (tracks system dark/light theme), and **Smoked**.
   - Changes animate smoothly in real time across both the Dashboard ambient canvas/cards and the active Floating HUD overlay, and persist automatically across app restarts.

### Visual Identity & Theme

- **Aesthetic Direction**: Continues the **Apple Liquid Glass** design language—luminous translucent surfaces, specular top-edge refraction highlights, dual-tone rim strokes, and cool ambient light orbs.
- **Color Palette & Mood**:
  - *White Liquid Glass (Default)*: Translucent milky-white surface fills (`#CCFFFFFF`–`#F2FFFFFF`), porcelain-sky background atmosphere, charcoal primary ink (`#0F172A`), and cool slate secondary ink (`#475569`).
  - *Smoked Liquid Glass (Dark / Auto-Night)*: Translucent smoked-slate glass (`#C8101828`–`#EB0B1220`), icy top-edge refraction highlight (`#33FFFFFF`), crisp white ink (`#F8FAFC`), and cool silver secondary ink (`#94A3B8`).
  - *Selectable Accent Tokens*:
    - **Sky Blue** (Default): `#0EA5E9` primary / `#0284C7` deep / `#38BDF8` soft glow
    - **Violet Mist**: `#8B5CF6` primary / `#6D28D9` deep / `#A78BFA` soft glow
    - **Mint Jade**: `#10B981` primary / `#047857` deep / `#34D399` soft glow
    - **Sunset Coral**: `#F43F5E` primary / `#BE123C` deep / `#FB7185` soft glow
- **Typography & Hierarchy**: Crisp sans-serif hierarchy (`13.5sp` bold titles, `11.5sp` medium status subtitles, `12sp` uppercase micro-labels) with generous `8dp` grid spacing and `48dp` minimum touch targets on every Dashboard control.
- **Component Styling & Layout**: Collapsible Material 3 Liquid Glass personalization card placed neatly beneath the HUD hero card on the Dashboard, featuring circular color-swatch orbs with animated selection rings, segmented glass-mode pills, and a custom glass-styled frost slider.

### Interactive Feedback & Motion

- **Magnetic Snap Physics**: Releasing the dragged collapsed pill animates `WindowManager` X coordinates with an overshoot spring curve (`~260ms`) into the left or right screen margin, plus a subtle haptic tick upon docking.
- **Gesture Confirmation**: Double-tap voice launch and swipe-to-cycle prompt recall emit light haptic feedback and brief header status text transitions so hidden gestures always feel responsive and discoverable.
- **Live Theme Crossfade**: Switching accent or glass mode smoothly animates Dashboard colors and ambient orb tints while immediately repainting the live floating HUD canvas and borders without detaching or flickering the overlay window.
- **Reduced Motion Compliance**: Respects system animator duration scale (`rememberReducedMotion()` / `ANIMATOR_DURATION_SCALE`), replacing spring overshoots and drifting orbs with crisp instant transitions when reduced motion is enabled.

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1: Local Preferences Persistence (Jetpack DataStore)**
  - *Chosen Approach*: Persist glass mode, frost opacity, selected accent, magnetic edge snap toggle, shake-to-summon toggle, and recent prompt ring buffer in local Jetpack Preferences DataStore.
  - *Why*: Appearance settings and gesture ergonomics are strictly device-local UI preferences that need instant offline startup and zero sign-in friction.
  - *Alternatives Considered*: Cloud Firestore sync (unnecessary sign-in gate for local overlay styling) or in-memory only (loses user preferences on reboot).

- **Decision 2: Battery-Safe Screen-Awake Shake Detection**
  - *Chosen Approach*: Register a low-frequency accelerometer listener (`SENSOR_DELAY_UI`) only when **Shake to Summon** is enabled AND the screen is on (`ACTION_SCREEN_ON` / `ACTION_SCREEN_OFF` receiver), requiring two acceleration peaks within a tight `180ms–650ms` window plus a `1.4s` cooldown.
  - *Why*: Prevents battery drain while the phone sleeps and eliminates single-jolt false positives when walking or setting the phone down.
  - *Alternatives Considered*: Always-on high-rate sensor polling (excessive battery drain and false triggers).

- **Decision 3: Hidden Gestures Over Extra HUD Buttons**
  - *Chosen Approach*: Keep the HUD top bar to `[Logo] [Title/Subtitle] [Stop?] [Collapse/Expand]` and expose edge docking, swipe-collapse, double-tap voice, and prompt history cycling purely through natural touch gestures, with a brief collapsible gesture legend inside the Dashboard card.
  - *Why*: Directly honors your preference for a serene, minimal floating HUD while unlocking power-user speed.
  - *Alternatives Considered*: Adding extra history/settings icons directly on the HUD header (creates visual crowding and reduces title readability).

---

## 4. Technical Architecture & Data Strategy *(Technical Reference)*

### System & Component Architecture

```text
┌─────────────────────────────────────────────────────────────────────────┐
│                    Jetpack DataStore (Appearance & Prefs)               │
│   accentPreset | glassMode | frostAlpha | magneticDock | shakeEnabled   │
└───────────────────────────────┬─────────────────────────────────────────┘
                                │ StateFlow<HudAppearanceConfig>
        ┌───────────────────────┼───────────────────────┐
        ▼                       ▼                       ▼
┌───────────────────┐  ┌─────────────────────┐  ┌─────────────────────────┐
│ AeroShare         │  │ Floating HUD v2     │  │ System Summon Triggers  │
│ Dashboard         │  │ Window Controller   │  │                         │
│                   │  │                     │  │ • Quick Settings Tile   │
│ • Ambient Canvas  │  │ • Dynamic Liquid    │  │   (TileService)         │
│   (dynamic orbs)  │  │   Glass Canvas      │  │                         │
│ • Collapsible     │  │   (White / Smoked / │  │ • Screen-Awake Shake    │
│   Glass Style     │  │    Auto + Frost +   │  │   Detector              │
│   Card & Gesture  │  │    Accent Tokens)   │  │   (SensorManager)       │
│   Cheat Sheet     │  │ • Gesture & Edge    │  └────────────┬────────────┘
│ • Shake Toggle    │  │   Dock Physics      │               │
└─────────┬─────────┘  │ • Prompt History    │               │
          │            │   Swipe Recaller    │               │
          └───────────►└──────────┬──────────┘◄──────────────┘
                                  │
                                  ▼
                       ┌─────────────────────┐
                       │      HudStore       │
                       │ (StateFlow + Queue  │
                       │  + Prompt History)  │
                       └─────────────────────┘
```

### Data Model & State

- **Appearance & Ergonomics State (`HudAppearanceConfig`)**:
  - `accent`: `SKY_BLUE` | `VIOLET_MIST` | `MINT_JADE` | `SUNSET_CORAL`
  - `surfaceMode`: `WHITE` | `AUTO` | `SMOKED`
  - `frostStrength`: Float in `0.72f..0.95f` (controls glass opacity & sheen balance)
  - `magneticEdgeDock`: Boolean (default `true`)
  - `shakeToSummon`: Boolean (default `false`, opt-in)
- **Prompt History Ring Buffer (inside `HudStore`)**:
  - Stores the latest 12 non-empty user prompts submitted via the HUD input box or voice input, with a cursor index reset whenever the user edits or submits a new prompt.
- **Resolved Glass Palette (`ResolvedHudPalette`)**:
  - Pure computed palette mapping `(HudAppearanceConfig, isSystemDark)` to concrete color tokens for both Jetpack Compose (`AuraGlass`) and the Android `View` canvas (`HudWindowController` + `HudMiddleStageViews`), guaranteeing 100% visual consistency across both UI layers.

### Interactive Component & State Mapping

- **HUD Header & Pill Gesture Handler**:
  - *Drag & Release (Collapsed)*: Computes velocity and final X relative to screen midpoint; when magnetic docking is enabled, animates `lp.x` via spring overshoot to the nearest safe left/right margin and performs a light haptic tick.
  - *Vertical Swipe*: Downward fling (`dy > threshold && abs(dy) > abs(dx)`) on expanded header collapses in place (and snaps to edge); upward fling or single tap on collapsed pill expands.
  - *Double-Tap on Collapsed Pill*: Uses a lightweight tap-timestamp discriminator (`< 280ms` gap) to expand and call the voice-input toggle immediately (single tap waits briefly or expands cleanly with zero lag when tapping the Expand button directly).
  - *Horizontal Swipe on Expanded Header*: Left/right swipe steps backward/forward through `HudStore.recentPrompts`, populates the input box without stealing Termux focus until tapped, and flashes a subtle subtitle cue (`History 1/5`).
- **Quick Settings Tile (`AgyHudTileService`)**:
  - Listens to `HudStore.state` while listening, syncing `Tile.STATE_ACTIVE` when HUD is visible and `Tile.STATE_INACTIVE` when hidden, with subtitle `"Expanded"`, `"Docked"`, or `"Off"`.
  - Tapping toggles `HudWindowController.show()` / `hide()` and collapses the notification shade cleanly; if overlay permission isn't granted, launches the overlay permission screen.
- **Shake Detector (`HudShakeSummonController`)**:
  - Lifecycle-managed by the application container; automatically binds/unbinds its `SensorEventListener` when `shakeToSummon` changes or when the display turns off/on.
  - On valid double-shake detection, toggles the HUD between visible/expanded and collapsed/hidden with haptic confirmation.
- **Dashboard Liquid Glass Style Card**:
  - Reactive controls (4 accent swatches, 3-way glass mode selector, frost slider, magnetic dock switch, shake-to-summon switch, and a compact 4-row hidden-gesture quick guide) write directly to the appearance repository, updating both the Dashboard theme and the active HUD overlay live.

### Verification Plan

- Compile the full Android app cleanly (`compile_applet`).
- Extend unit tests to verify:
  1. Appearance palette resolution across all 4 accents, `WHITE`/`SMOKED`/`AUTO` surface modes, and frost bounds.
  2. Prompt history ring-buffer deduplication, capping, and forward/backward cycling in `HudStore`.
  3. Magnetic edge-dock side calculation and double-shake peak-window / cooldown filtering logic.
  4. Existing HUD v2 & Pointer overlay unit tests remain green.
