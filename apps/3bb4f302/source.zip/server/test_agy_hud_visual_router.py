import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(__file__))
import agy_hud_daemon as daemon


class AgyHudVisualRouterTests(unittest.TestCase):
    def test_plain_text_never_opens_left_window(self):
        tracker = daemon.HudStateTracker(auto_collapse_seconds=4)
        begin_payload = tracker.begin_prompt("Summarize SOLID principles")
        self.assertFalse(begin_payload["taskMap"]["active"])

        msg_payload, sw_active = tracker.apply_agy_event(
            {"type": "assistant", "text": "Single responsibility keeps classes modular and testable."}
        )
        self.assertFalse(sw_active)
        self.assertFalse(msg_payload["taskMap"]["active"])

        done_payload = tracker.mark_done("Summary ready")
        self.assertFalse(done_payload["taskMap"]["active"])

    def test_video_only_urls_auto_launch_player_for_youtube_hls_and_mp4(self):
        for url in [
            "https://www.youtube.com/watch?v=jfKfPfyJRdk",
            "https://youtu.be/dQw4w9WgXcQ",
            "https://cdn.example.org/stream/live.m3u8",
            "https://cdn.example.org/clips/demo.mp4",
        ]:
            tracker = daemon.HudStateTracker(auto_collapse_seconds=4)
            tracker.begin_prompt("Play media")
            payload, _ = tracker.apply_agy_event({"type": "assistant", "text": f"Playing {url}"})
            tm = payload["taskMap"]
            self.assertTrue(tm["active"], f"Expected active player for {url}")
            self.assertEqual(tm["mode"], "player")
            self.assertEqual(tm["player"]["mediaMode"], "video")
            self.assertTrue(tm["player"]["playing"])
            self.assertEqual(tm["player"]["playlist"][0]["uri"], url)

            done_tm = tracker.mark_done("Playing")["taskMap"]
            self.assertTrue(done_tm["active"])
            self.assertEqual(done_tm["mode"], "player")

    def test_mixed_media_carousel_strips_summary_text_and_keeps_visuals(self):
        tracker = daemon.HudStateTracker(auto_collapse_seconds=4)
        tracker.begin_prompt("who is miya")
        tracker.apply_agy_event(
            {
                "type": "assistant",
                "text": (
                    "Miya is an engineer. "
                    "![Portrait](https://example.org/miya.png) "
                    "Video: https://example.org/clip.mp4"
                ),
            }
        )
        done_tm = tracker.mark_done("Ready")["taskMap"]
        self.assertTrue(done_tm["active"])
        self.assertEqual(done_tm["mode"], "results")
        self.assertEqual(done_tm["results"]["summaryText"], "")
        self.assertEqual(len(done_tm["results"]["items"]), 2)

    def test_mermaid_flowchart_sequence_pie_and_arrow_chains(self):
        flow = daemon.extract_diagram_from_text(
            "```mermaid\ngraph TD\nClient[Client App] --> Auth[OAuth]\nAuth --> API[Backend]\n```",
            "OAuth Flow",
        )
        self.assertIsNotNone(flow)
        self.assertEqual(flow["diagramType"], "flowchart")
        self.assertEqual(len(flow["nodes"]), 3)
        self.assertEqual(len(flow["edges"]), 2)

        seq = daemon.extract_diagram_from_text(
            "```mermaid\nsequenceDiagram\nUser->>HUD: Prompt\nHUD-->>Agy: Dispatch\n```",
            "Prompt Lifecycle",
        )
        self.assertIsNotNone(seq)
        self.assertEqual(seq["diagramType"], "sequence")
        self.assertEqual(len(seq["edges"]), 2)

        pie = daemon.extract_diagram_from_text(
            '```mermaid\npie title Usage\n"Video" : 60\n"Charts" : 40\n```',
            "Visual Share",
        )
        self.assertIsNotNone(pie)
        self.assertEqual(pie["diagramType"], "chart")
        self.assertEqual(pie["subChartType"], "radial")

        arrows = daemon.extract_diagram_from_text("Ingest -> Transform -> Index -> Serve", "Pipeline")
        self.assertIsNotNone(arrows)
        self.assertEqual(arrows["diagramType"], "flowchart")
        self.assertEqual(len(arrows["nodes"]), 4)

    def test_percentage_metrics_auto_synthesize_radial_or_bar_chart(self):
        radial_tm = daemon.VisualIntentRouter.route(
            query="System Load",
            items=[],
            detailed_output="CPU: 42%, Memory: 68%, GPU: 55%",
            tasks=[],
        )
        self.assertTrue(radial_tm["active"])
        self.assertEqual(radial_tm["mode"], "diagram")
        self.assertEqual(radial_tm["diagram"]["diagramType"], "chart")
        self.assertEqual(radial_tm["diagram"]["subChartType"], "radial")
        self.assertEqual(len(radial_tm["diagram"]["series"]), 3)

        bar_tm = daemon.VisualIntentRouter.route(
            query="Weekly Progress",
            items=[],
            detailed_output="Mon: 40%, Tue: 55%, Wed: 70%, Thu: 90%",
            tasks=[],
        )
        self.assertTrue(bar_tm["active"])
        self.assertEqual(bar_tm["diagram"]["subChartType"], "bar")
        self.assertEqual(len(bar_tm["diagram"]["series"]), 4)

    def test_live_automation_app_pane_closes_cleanly_on_done_without_leaking_diagram(self):
        tracker = daemon.HudStateTracker(auto_collapse_seconds=4)
        tracker.begin_prompt("Open Wi-Fi settings")
        tracker.apply_agy_event(
            {
                "type": "step_update",
                "steps": [
                    {"id": "s1", "label": "Open Settings", "status": "done"},
                    {"id": "s2", "label": "Tap Wi-Fi", "status": "doing"},
                ],
            }
        )
        tracker.update_wireframe(
            {"active": True, "label": "Settings"},
            task_map_payload={"active": True, "mode": "app_pane", "title": "Settings"},
            detected_target_package="com.android.settings",
        )
        done_payload = tracker.mark_done("Connected")
        self.assertEqual(done_payload["state"], "DONE")
        self.assertFalse(done_payload["taskMap"]["active"])


if __name__ == "__main__":
    unittest.main()
