#!/usr/bin/env python3
"""
Termux-First Dual-Window Agy HUD Companion Daemon (agy_hud_daemon.py)

Connects to KaVach / AeroShare locally on http://127.0.0.1:8080 (with Bearer token from
~/.aura_token) over both RFC 6455 WebSocket (instant HUD_COMMAND push) and /api/hud/poll
fallback. Manages a Termux `agy` CLI session (`-p= --input-format stream-json
--output-format stream-json --dangerously-skip-permissions` with sticky conversation ID
reuse via ~/.agy_hud_conversation_id and `--continue` fallback), streams structured
step_update / tool_use / telemetry into POST /api/hud/state, extracts task-specific maps
(`chess`, `media`, `telemetry`, `app_pane`) with split-screen / rotation intelligence for
Window 3 (`agy_task_map`), and confirms stop / completion states cleanly.

Usage in Termux:
    python agy_hud_daemon.py
    python agy_hud_daemon.py --new
    python agy_hud_daemon.py --url http://127.0.0.1:8080 --mode auto
    python agy_hud_daemon.py --self-test
"""

from __future__ import annotations

import argparse
import base64
import hashlib
import json
import os
import queue
import re
import signal
import socket
import struct
import subprocess
import sys
import tempfile
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid
from typing import Any, Dict, List, Optional, Tuple

DEFAULT_HTTP_URL = os.environ.get("AURA_HTTP_URL", "http://127.0.0.1:8080").rstrip("/")
CONVERSATION_ID_PATH = os.path.expanduser("~/.agy_hud_conversation_id")
BRIDGE_RUNTIME_PREFIX = (
    "Use KaVach local bridge (http://127.0.0.1:8080) with token from ~/.aura_token "
    "when device/UI control is needed.\n"
)

TOKEN_CANDIDATES = [
    os.path.expanduser("~/.aura_token"),
    os.path.join(os.path.dirname(os.path.abspath(__file__)), ".aura_token"),
]
BOUNDS_RE = re.compile(r"\[(-?\d+),(-?\d+)\]\[(-?\d+),(-?\d+)\]")
CHESS_SQUARE_RE = re.compile(
    r"\b(white|black)\s+(king|queen|rook|bishop|knight|pawn)\s+on\s+([a-h][1-8])\b",
    re.IGNORECASE,
)
CHESS_EVAL_RE = re.compile(r"^\s*(?:[+-]?\d+(?:\.\d+)?|#?-?M\d+)\s*$", re.IGNORECASE)
CHESS_MOVE_RE = re.compile(r"\b([a-h][1-8])\s*(?:->|-|to)?\s*([a-h][1-8])\b", re.IGNORECASE)
MEDIA_TIME_RE = re.compile(r"\b(\d{1,2}:\d{2}(?::\d{2})?)\b")
QUERY_PREFIX_RE = re.compile(
    r"^\s*(?:who|what|where|when|why|how|tell me|explain|find|search|lookup|show me|list|photos? of|images? of|videos? of|files? (?:for|about|in))\b",
    re.IGNORECASE,
)
MD_LINK_RE = re.compile(r"!\[([^\]]*)\]\(([^)\s]+)\)|\[([^\]]+)\]\(([^)\s]+)\)")
RAW_URL_RE = re.compile(r"(https?://[^\s<>\"')]+)", re.IGNORECASE)
LOCAL_PATH_RE = re.compile(
    r"((?:/sdcard|/storage|/data|~/)[A-Za-z0-9_./\-+%]+\.(?:jpg|jpeg|png|webp|gif|bmp|mp4|mov|webm|mkv|m4v|pdf|txt|md|apk|py|kt|json|csv|log|zip))",
    re.IGNORECASE,
)
IMAGE_EXTS = (".jpg", ".jpeg", ".png", ".webp", ".gif", ".bmp")
VIDEO_EXTS = (".mp4", ".mov", ".webm", ".mkv", ".m4v", ".m3u8")
FILE_EXTS = (".pdf", ".txt", ".md", ".apk", ".py", ".kt", ".json", ".csv", ".log", ".zip", ".doc", ".docx")
YOUTUBE_URL_RE = re.compile(
    r"(?:youtube\.com/(?:watch\?[^\s]*v=|embed/|shorts/)|youtu\.be/)([A-Za-z0-9_-]{6,})",
    re.IGNORECASE,
)

SCREEN_TOOL_KEYWORDS = (
    "ui_tree",
    "ui_action",
    "tap",
    "click",
    "swipe",
    "drag",
    "screen",
    "screenshot",
    "inspect",
    "accessibility",
    "scroll",
    "chess",
    "youtube",
    "spotify",
    "vlc",
)


def is_informational_query(prompt_text: str) -> bool:
    cleaned = (prompt_text or "").strip()
    if not cleaned:
        return False
    low = cleaned.lower()
    if any(k in low for k in ("tap ", "click ", "open ", "launch ", "swipe ", "scroll ", "turn on", "turn off", "play chess")):
        return False
    return bool(QUERY_PREFIX_RE.search(cleaned)) or cleaned.endswith("?")


def _infer_media_kind(uri: str) -> Optional[str]:
    clean = (uri or "").split("?", 1)[0].split("#", 1)[0].lower()
    if uri.lower().startswith("data:image/") or any(clean.endswith(ext) for ext in IMAGE_EXTS):
        return "image"
    if any(clean.endswith(ext) for ext in VIDEO_EXTS) or YOUTUBE_URL_RE.search(uri or ""):
        return "video"
    if any(clean.endswith(ext) for ext in FILE_EXTS):
        return "file"
    return None


def _guess_mime_for_kind(uri: str, kind: str) -> str:
    clean = (uri or "").split("?", 1)[0].split("#", 1)[0].lower()
    if clean.endswith(".png"):
        return "image/png"
    if clean.endswith(".webp"):
        return "image/webp"
    if clean.endswith(".gif"):
        return "image/gif"
    if kind == "image":
        return "image/jpeg"
    if clean.endswith(".webm"):
        return "video/webm"
    if kind == "video":
        return "video/mp4"
    if clean.endswith(".pdf"):
        return "application/pdf"
    if clean.endswith(".apk"):
        return "application/vnd.android.package-archive"
    if clean.endswith((".txt", ".md", ".py", ".kt", ".json", ".csv", ".log")):
        return "text/plain"
    return "*/*"


def extract_media_items_from_text(text: str, max_items: int = 8) -> List[Dict[str, Any]]:
    """Extracts image, video, and document/file URLs or Android paths for the Window 3 carousel."""
    if not text:
        return []
    found: List[Tuple[str, str]] = []
    seen_uris = set()

    for m in MD_LINK_RE.finditer(text):
        label = (m.group(1) or m.group(3) or "").strip()
        uri = (m.group(2) or m.group(4) or "").strip().rstrip(".,;:")
        if uri and uri not in seen_uris and _infer_media_kind(uri) is not None:
            seen_uris.add(uri)
            found.append((uri, label))

    for m in RAW_URL_RE.finditer(text):
        uri = m.group(1).strip().rstrip(".,;:")
        if uri and uri not in seen_uris and _infer_media_kind(uri) is not None:
            seen_uris.add(uri)
            found.append((uri, ""))

    for m in LOCAL_PATH_RE.finditer(text):
        uri = m.group(1).strip()
        if uri and uri not in seen_uris and _infer_media_kind(uri) is not None:
            seen_uris.add(uri)
            found.append((uri, ""))

    items: List[Dict[str, Any]] = []
    for idx, (uri, raw_label) in enumerate(found[:max_items]):
        kind = _infer_media_kind(uri) or "file"
        tail = uri.split("?", 1)[0].split("#", 1)[0].rstrip("/").split("/")[-1]
        title = (raw_label or tail or f"{kind.capitalize()} {idx + 1}")[:48]
        source_sub = urllib.parse.urlparse(uri).netloc if uri.startswith(("http://", "https://")) else os.path.dirname(uri)
        items.append(
            {
                "id": f"res_{idx + 1}",
                "kind": kind,
                "title": title,
                "subtitle": source_sub or ("Local file" if uri.startswith("/") else ""),
                "uri": uri,
                "mimeType": _guess_mime_for_kind(uri, kind),
            }
        )
    return items


def build_results_task_map(
    query: str,
    summary_text: str,
    items: List[Dict[str, Any]],
    loading: bool = False,
    source_label: str = "",
) -> Dict[str, Any]:
    clean_query = (query or "").strip()[:64] or "Visuals"
    clean_summary = (summary_text or "").strip()[:1200]
    headline = clean_query.rstrip("?").strip()
    if len(headline) > 40:
        headline = headline[:39] + "…"
    src = source_label or (f"{len(items)} media" if items else "")
    return {
        "active": bool(items),
        "mode": "results",
        "title": clean_query[:48],
        "widthDp": 224,
        "persistOnDone": True,
        "results": {
            "query": clean_query,
            "summaryTitle": headline or "Visuals",
            "summaryText": clean_summary,
            "sourceLabel": src,
            "loading": bool(loading),
            "items": list(items),
        },
    }


MERMAID_BLOCK_RE = re.compile(r"```mermaid\s*\n([\s\S]*?)```", re.IGNORECASE)
MERMAID_SEQ_RE = re.compile(
    r"^\s*([A-Za-z0-9_.\- ]+?)\s*(-+>>?|--+>>?|-+>|-->)\s*([A-Za-z0-9_.\- ]+?)\s*:\s*(.+)$"
)
MERMAID_FLOW_RE = re.compile(
    r"^\s*([A-Za-z0-9_.\-]+)(?:\[([^\]]+)\]|\(([^)]+)\)|\{([^}]+)\})?\s*(?:--+>|==+>|-.+->)\s*(?:\|([^|]+)\|\s*)?([A-Za-z0-9_.\-]+)(?:\[([^\]]+)\]|\(([^)]+)\)|\{([^}]+)\})?"
)
MERMAID_PIE_RE = re.compile(r'^\s*"([^"]+)"\s*:\s*([0-9]+(?:\.[0-9]+)?)')


def extract_diagram_from_text(text: str, title: str = "Visual Diagram") -> Optional[Dict[str, Any]]:
    """Extracts Mermaid (flowchart/sequence/pie) or A -> B -> C flows into a DiagramTaskMapData dict."""
    cleaned = (text or "").strip()
    if not cleaned:
        return None
    m_block = MERMAID_BLOCK_RE.search(cleaned)
    body = m_block.group(1).strip() if m_block else cleaned
    lines = [ln.strip() for ln in body.splitlines() if ln.strip() and not ln.strip().startswith("%%")]
    if not lines:
        return None
    first_low = lines[0].lower()

    if first_low.startswith("sequencediagram") or (m_block is not None and any(MERMAID_SEQ_RE.match(ln) for ln in lines)):
        actors: Dict[str, Dict[str, Any]] = {}
        edges: List[Dict[str, Any]] = []
        for ln in lines:
            if ln.lower().startswith(("participant ", "actor ")):
                rest = ln.split(" ", 1)[1].split(" as ", 1)
                aid = rest[0].strip()
                albl = (rest[1] if len(rest) > 1 else aid).strip()
                if aid:
                    actors[aid] = {"id": aid, "label": albl[:20], "role": "actor", "status": "done"}
                continue
            m = MERMAID_SEQ_RE.match(ln)
            if not m:
                continue
            frm, arrow, to, msg = m.group(1).strip(), m.group(2), m.group(3).strip(), m.group(4).strip()
            actors.setdefault(frm, {"id": frm, "label": frm[:20], "role": "actor", "status": "done"})
            actors.setdefault(to, {"id": to, "label": to[:20], "role": "actor", "status": "done"})
            edges.append({"from": frm, "to": to, "label": msg[:28], "active": len(edges) == 0, "dashed": arrow.startswith("--")})
        if len(actors) >= 2 and edges:
            return {
                "diagramType": "sequence",
                "title": (title or "Sequence")[:48],
                "nodes": list(actors.values())[:8],
                "edges": edges[:14],
            }

    if first_low.startswith("pie"):
        pts: List[Dict[str, Any]] = []
        for ln in lines[1:]:
            pm = MERMAID_PIE_RE.match(ln)
            if pm:
                pts.append({"label": pm.group(1).strip()[:16], "value": float(pm.group(2))})
        if len(pts) >= 2:
            total = max(1.0, sum(p["value"] for p in pts))
            for p in pts:
                p["maxValue"] = total
            return {
                "diagramType": "chart",
                "subChartType": "radial",
                "title": (title or "Breakdown")[:48],
                "series": pts[:8],
            }

    if first_low.startswith(("graph ", "flowchart ")) or m_block is not None:
        nodes: Dict[str, Dict[str, Any]] = {}
        edges: List[Dict[str, Any]] = []
        for ln in lines:
            fm = MERMAID_FLOW_RE.match(ln)
            if not fm:
                continue
            fid = fm.group(1).strip()
            flbl = next((g.strip() for g in (fm.group(2), fm.group(3), fm.group(4)) if g and g.strip()), fid)
            frole = "decision" if fm.group(4) else ("start" if fm.group(3) else "step")
            elbl = (fm.group(5) or "").strip()
            tid = fm.group(6).strip()
            tlbl = next((g.strip() for g in (fm.group(7), fm.group(8), fm.group(9)) if g and g.strip()), tid)
            trole = "decision" if fm.group(9) else ("end" if fm.group(8) else "step")
            nodes.setdefault(fid, {"id": fid, "label": flbl[:28], "role": frole, "status": "done"})
            nodes.setdefault(tid, {"id": tid, "label": tlbl[:28], "role": trole, "status": "doing"})
            edges.append({"from": fid, "to": tid, "label": elbl[:22], "active": ("--" in ln or "==" in ln)})
        if len(nodes) >= 2:
            node_list = list(nodes.values())[:14]
            return {
                "diagramType": "flowchart",
                "title": (title or "Flowchart")[:48],
                "nodes": node_list,
                "edges": edges[:20],
                "activeNodeId": node_list[-1]["id"],
            }

    # Plain-text arrow chains (`Client -> API -> Database`)
    arrow_nodes: Dict[str, Dict[str, Any]] = {}
    arrow_edges: List[Dict[str, Any]] = []
    for ln in lines[:12]:
        if not any(sym in ln for sym in ("->", "-->", "→", "➜")):
            continue
        parts = [p.strip(' "`*-') for p in re.split(r"\s*(?:-->|->|=>|➜|→)\s*", ln)]
        parts = [p for p in parts if 2 <= len(p) <= 36]
        if len(parts) >= 2:
            for i in range(len(parts) - 1):
                a, b = parts[i], parts[i + 1]
                aid = "n_" + re.sub(r"[^a-z0-9]+", "_", a.lower()).strip("_")
                bid = "n_" + re.sub(r"[^a-z0-9]+", "_", b.lower()).strip("_")
                if aid not in arrow_nodes:
                    arrow_nodes[aid] = {"id": aid, "label": a[:26], "role": "start" if not arrow_nodes else "step", "status": "done"}
                if bid not in arrow_nodes:
                    arrow_nodes[bid] = {"id": bid, "label": b[:26], "role": "end" if i == len(parts) - 2 else "step", "status": "doing"}
                arrow_edges.append({"from": aid, "to": bid, "active": True})
    if len(arrow_nodes) >= 3 and len(arrow_edges) >= 2:
        node_list = list(arrow_nodes.values())[:12]
        return {
            "diagramType": "flowchart",
            "title": (title or "Architecture Flow")[:48],
            "nodes": node_list,
            "edges": arrow_edges[:18],
            "activeNodeId": node_list[-1]["id"],
        }
    return None


def build_diagram_from_tasks(tasks: List[Dict[str, Any]], title: str = "Task Flow") -> Optional[Dict[str, Any]]:
    if not tasks or len(tasks) < 2:
        return None
    nodes: List[Dict[str, Any]] = []
    active_id = ""
    for idx, t in enumerate(tasks[:10]):
        st = str(t.get("status") or "pending").lower()
        norm_st = "done" if st == "done" else ("doing" if st == "doing" else ("error" if st in ("stopped", "needs_input") else "pending"))
        nid = str(t.get("id") or f"step_{idx + 1}")
        if norm_st == "doing" and not active_id:
            active_id = nid
        nodes.append(
            {
                "id": nid,
                "label": str(t.get("label") or f"Step {idx + 1}")[:28],
                "role": "start" if idx == 0 else ("end" if idx == len(tasks) - 1 else "step"),
                "status": norm_st,
                "layer": idx,
            }
        )
    edges = [
        {
            "from": nodes[i]["id"],
            "to": nodes[i + 1]["id"],
            "active": nodes[i]["status"] == "doing" or nodes[i + 1]["status"] == "doing",
        }
        for i in range(len(nodes) - 1)
    ]
    return {
        "diagramType": "flowchart",
        "title": (title or "Task Flow")[:48],
        "nodes": nodes,
        "edges": edges,
        "activeNodeId": active_id,
    }


METRIC_PERCENT_TEXT_RE = re.compile(
    r"(?:^|[,;\n•\-*]\s*)([A-Za-z][A-Za-z0-9 /_-]{1,18})\s*[:=]\s*([-+]?\d+(?:\.\d+)?)\s*%"
)


def extract_chart_from_text(text: str, title: str = "Breakdown") -> Optional[Dict[str, Any]]:
    """Extracts 2-6 percentage metrics (e.g. 'CPU: 45%, RAM: 72%') into a radial/bar chart diagram."""
    cleaned = (text or "").strip()
    if not cleaned:
        return None
    pts: List[Dict[str, Any]] = []
    seen: set = set()
    for m in METRIC_PERCENT_TEXT_RE.finditer(cleaned):
        lbl = m.group(1).strip()
        key = lbl.lower()
        if not lbl or key in seen:
            continue
        seen.add(key)
        val = max(0.0, min(100.0, float(m.group(2))))
        pts.append(
            {
                "label": lbl[:16],
                "value": val,
                "maxValue": 100.0,
                "status": "highlight" if val >= 80.0 else "doing",
            }
        )
        if len(pts) >= 6:
            break
    if len(pts) < 2:
        return None
    return {
        "diagramType": "chart",
        "subChartType": "radial" if len(pts) <= 3 else "bar",
        "title": (title or "Metrics")[:48],
        "series": pts,
    }


def build_diagram_task_map(
    diagram_obj: Dict[str, Any],
    title: str = "",
    persist_on_done: bool = True,
) -> Dict[str, Any]:
    resolved_title = (title or diagram_obj.get("title") or "Visual Diagram")[:48]
    return {
        "active": True,
        "mode": "diagram",
        "title": resolved_title,
        "widthDp": 236,
        "persistOnDone": bool(persist_on_done),
        "diagram": dict(diagram_obj),
    }


class VisualIntentRouter:
    """Deterministic priority router for the Visual-Only Left Window (`agy_task_map`)."""

    @staticmethod
    def route(
        query: str,
        items: List[Dict[str, Any]],
        detailed_output: str,
        tasks: List[Dict[str, Any]],
        persist_on_done: bool = True,
    ) -> Dict[str, Any]:
        # 1. Video-only items -> Auto-launch playing Video Player
        video_items = [it for it in items if it.get("kind") == "video" and it.get("uri")]
        has_images = any(it.get("kind") == "image" for it in items)
        if video_items and not has_images:
            playlist = [
                {
                    "id": it.get("id") or f"vid_{idx}",
                    "title": it.get("title") or f"Video {idx + 1}",
                    "subtitle": it.get("subtitle") or "",
                    "uri": it["uri"],
                    "mimeType": it.get("mimeType") or "video/mp4",
                    "isVideo": True,
                }
                for idx, it in enumerate(video_items)
            ]
            return build_player_task_map(
                build_player_payload(
                    uri=playlist[0]["uri"],
                    title=playlist[0]["title"],
                    media_mode="video",
                    bg=False,
                    playing=True,
                    playlist=playlist,
                )
            )

        # 2. Images / mixed visual items -> Visual Media Carousel (summary text stays in Main HUD)
        if items:
            return build_results_task_map(
                query=query,
                summary_text="",
                items=items,
                loading=False,
            )

        # 3. Structured Mermaid / arrow diagram from assistant output
        extracted_diag = extract_diagram_from_text(detailed_output, title=query or "Visual Diagram")
        if extracted_diag is not None:
            return build_diagram_task_map(extracted_diag, title=query, persist_on_done=persist_on_done)

        # 4. Percentage/metric breakdown extracted from assistant output -> Radial/Bar Chart
        extracted_chart = extract_chart_from_text(detailed_output, title=query or "Metrics")
        if extracted_chart is not None:
            return build_diagram_task_map(extracted_chart, title=query, persist_on_done=persist_on_done)

        # 5. Multi-step plan/tasks -> Step Flowchart
        task_diag = build_diagram_from_tasks(tasks, title=query or "Task Flow")
        if task_diag is not None:
            return build_diagram_task_map(task_diag, title=query, persist_on_done=persist_on_done)

        # 6. Plain-text output -> Main HUD only
        return {"active": False, "mode": "app_pane"}


def build_visual_left_window_task_map(
    query: str,
    items: List[Dict[str, Any]],
    detailed_output: str,
    tasks: List[Dict[str, Any]],
    persist_on_done: bool = True,
) -> Dict[str, Any]:
    """Routes Left Window strictly to auto-play video, visual media carousel, or auto-generated diagram (never plain text)."""
    return VisualIntentRouter.route(
        query=query,
        items=items,
        detailed_output=detailed_output,
        tasks=tasks,
        persist_on_done=persist_on_done,
    )


SENSITIVE_HIGH_RISK_PATTERNS = [
    re.compile(r"\brm\s+-[a-zA-Z]*[rf]", re.I),
    re.compile(r"\b(delete\s+all|wipe\s+data|factory\s+reset|format\s+disk|drop\s+table|reboot|shutdown)\b", re.I),
    re.compile(r"\b(pay|purchase|checkout|transfer\s+money|send\s+money|wire\s+funds)\b", re.I),
]
SENSITIVE_MEDIUM_RISK_PATTERNS = [
    re.compile(r"\b(send\s+(message|whatsapp|email|sms|reply)|post\s+tweet|uninstall)\b", re.I),
    re.compile(r"\b(delete|remove)\s+(file|folder|contact|chat|photo)\b", re.I),
]


def detect_sensitive_prompt_risk(text: str) -> Optional[Dict[str, Any]]:
    """Classifies potentially destructive or irreversible user/agent actions for the Safety Approval Gate."""
    clean = (text or "").strip()
    if not clean:
        return None
    for pat in SENSITIVE_HIGH_RISK_PATTERNS:
        if pat.search(clean):
            return {
                "riskLevel": "high",
                "title": "High-Risk Action Requires Approval",
                "description": "This command may modify/delete data or perform an irreversible action.",
                "commandPreview": clean[:240],
            }
    for pat in SENSITIVE_MEDIUM_RISK_PATTERNS:
        if pat.search(clean):
            return {
                "riskLevel": "medium",
                "title": "Confirm Sensitive Action",
                "description": "Review this external or destructive action before Agy executes it.",
                "commandPreview": clean[:240],
            }
    return None


def format_region_context_for_prompt(
    text: str,
    payload: Optional[Dict[str, Any]],
    action: str = "PROMPT",
) -> str:
    """Enriches a user prompt with Region Snip, Demonstration Recording, or Screen Watchdog context."""
    base = (text or "").strip()
    if not isinstance(payload, dict):
        return base

    extra_blocks: List[str] = []
    act_upper = (action or "PROMPT").strip().upper()

    # 1. Demonstration Recorder context (DEMO_RECORDED)
    demo_obj = payload.get("demo") if isinstance(payload.get("demo"), dict) else None
    macro_prompt = str(
        payload.get("macroPrompt")
        or (demo_obj.get("macroPrompt") if demo_obj else "")
        or ""
    ).strip()
    demo_steps = (
        demo_obj.get("steps")
        if (demo_obj and isinstance(demo_obj.get("steps"), list))
        else (payload.get("steps") if isinstance(payload.get("steps"), list) else [])
    )
    if act_upper == "DEMO_RECORDED" or demo_obj is not None or macro_prompt:
        if not base and macro_prompt:
            base = macro_prompt
        step_lines: List[str] = []
        for idx, st in enumerate(demo_steps[:20]):
            if not isinstance(st, dict):
                continue
            s_act = str(st.get("action") or "TAP").upper()
            s_lbl = str(st.get("nodeLabel") or st.get("viewId") or "").strip()
            s_pkg = str(st.get("packageName") or "").strip()
            s_x = int(st.get("x", 0))
            s_y = int(st.get("y", 0))
            desc = f"{idx + 1}. {s_act}"
            if s_lbl:
                desc += f' "{s_lbl}"'
            desc += f" @({s_x},{s_y})"
            if s_pkg:
                desc += f" [{s_pkg}]"
            step_lines.append(desc)
        if step_lines:
            extra_blocks.append("[Recorded Demonstration Steps]\n" + "\n".join(step_lines))

    # 2. Live Screen Diff & Visual Watchdog context (WATCHDOG_TRIGGERED)
    wd_obj = payload.get("watchdog") if isinstance(payload.get("watchdog"), dict) else None
    diff_summary = str(
        payload.get("diffSummary")
        or (wd_obj.get("lastDiffSummary") if wd_obj else "")
        or ""
    ).strip()
    if act_upper == "WATCHDOG_TRIGGERED" or wd_obj is not None or diff_summary:
        rule = str((wd_obj or {}).get("rule") or payload.get("rule") or "any_change")
        target_txt = str((wd_obj or {}).get("targetText") or payload.get("targetText") or "").strip()
        trig_prompt = str((wd_obj or {}).get("triggerPrompt") or payload.get("triggerPrompt") or "").strip()
        if not base:
            base = trig_prompt or f"Screen Watchdog triggered ({rule}): {diff_summary or target_txt}"
        wd_line = f"[Screen Watchdog Triggered: rule={rule}"
        if target_txt:
            wd_line += f' target="{target_txt}"'
        wd_line += "]"
        if diff_summary:
            wd_line += f"\nDiff Summary: {diff_summary}"
        extra_blocks.append(wd_line)

    # 3. Snipped Screen Region context (supports both v2 'snip' and legacy 'regionContext')
    region = payload.get("snip") if isinstance(payload.get("snip"), dict) else payload.get("regionContext")
    if not isinstance(region, dict) and wd_obj and isinstance(wd_obj.get("region"), dict):
        region = wd_obj.get("region")
    if isinstance(region, dict):
        try:
            x1 = int(region.get("x1", 0))
            y1 = int(region.get("y1", 0))
            x2 = int(region.get("x2", 0))
            y2 = int(region.get("y2", 0))
        except (TypeError, ValueError):
            x1 = y1 = x2 = y2 = 0
        if x2 > x1 and y2 > y1:
            pkg = str(region.get("packageName") or "").strip()
            sw = int(region.get("screenWidth") or 1080)
            sh = int(region.get("screenHeight") or 2400)
            nodes = region.get("nodes") if isinstance(region.get("nodes"), list) else []
            lines = [
                f"[Snipped Screen Region: [{x1},{y1}]-[{x2},{y2}] on {sw}x{sh}"
                + (f" ({pkg})" if pkg else "")
                + "]"
            ]
            shot_b64 = str(region.get("screenshotBase64") or "").strip()
            if shot_b64:
                try:
                    snips_dir = os.path.join(os.path.expanduser("~"), ".aura_snips")
                    os.makedirs(snips_dir, exist_ok=True)
                    ext = "png" if "png" in str(region.get("screenshotMimeType") or "").lower() else "jpg"
                    snip_path = os.path.join(snips_dir, f"snip_{int(time.time() * 1000)}.{ext}")
                    with open(snip_path, "wb") as _sf:
                        _sf.write(base64.b64decode(shot_b64))
                    sw_px = int(region.get("screenshotWidth") or (x2 - x1))
                    sh_px = int(region.get("screenshotHeight") or (y2 - y1))
                    lines.append(f"Cropped screenshot saved at: {snip_path} ({sw_px}x{sh_px})")
                except Exception:
                    pass
            if nodes:
                node_summaries = []
                for n in nodes[:12]:
                    if not isinstance(n, dict):
                        continue
                    label = str(n.get("text") or n.get("contentDescription") or n.get("viewId") or "").strip()
                    cx = n.get("centerX")
                    cy = n.get("centerY")
                    click_tag = " clickable" if n.get("clickable") else ""
                    if label:
                        node_summaries.append(f'"{label[:60]}" @({cx},{cy}){click_tag}')
                if node_summaries:
                    lines.append("Visible elements in region: " + "; ".join(node_summaries))
            extra_blocks.append("\n".join(lines))

    if not extra_blocks:
        return base
    if not base:
        return "\n\n".join(extra_blocks)
    return f"{base}\n\n" + "\n\n".join(extra_blocks)



def build_spotlight_payload(
    targets: List[Dict[str, Any]],
    title: str = "Co-Pilot Guide",
    dim_alpha: float = 0.55,
    auto_hide_seconds: int = 0,
) -> Dict[str, Any]:
    """Builds a normalized /api/hud/spotlight payload for touch-pass-through guided pins."""
    norm_targets: List[Dict[str, Any]] = []
    for idx, t in enumerate(targets or []):
        if not isinstance(t, dict):
            continue
        x1 = int(t.get("x1", t.get("left", 0)))
        y1 = int(t.get("y1", t.get("top", 0)))
        x2 = int(t.get("x2", t.get("right", 0)))
        y2 = int(t.get("y2", t.get("bottom", 0)))
        if x2 <= x1 or y2 <= y1:
            continue
        item: Dict[str, Any] = {
            "id": str(t.get("id") or f"spot_{idx + 1}"),
            "x1": min(x1, x2),
            "y1": min(y1, y2),
            "x2": max(x1, x2),
            "y2": max(y1, y2),
            "label": str(t.get("label") or t.get("tooltip") or "").strip(),
            "stepNumber": int(t.get("stepNumber", idx + 1)),
            "calloutPosition": str(t.get("calloutPosition") or "auto"),
        }
        if t.get("accentColor"):
            item["accentColor"] = str(t["accentColor"])
        norm_targets.append(item)
    return {
        "active": len(norm_targets) > 0,
        "title": (title or "Co-Pilot Guide").strip(),
        "dimAlpha": max(0.15, min(0.85, float(dim_alpha))),
        "autoHideSeconds": max(0, int(auto_hide_seconds)),
        "targets": norm_targets,
    }


def build_player_payload(
    uri: str = "",
    title: str = "",
    subtitle: str = "",
    media_mode: str = "",
    bg: bool = False,
    playing: bool = True,
    loop: bool = False,
    muted: bool = False,
    volume: float = 1.0,
    speed: float = 1.0,
    playlist: Optional[List[Dict[str, Any]]] = None,
    action: str = "",
    seek_ms: Optional[int] = None,
) -> Dict[str, Any]:
    """Builds a normalized /api/hud/player payload for the Left-Window Custom Media Player."""
    norm_playlist: List[Dict[str, Any]] = []
    for idx, item in enumerate(playlist or []):
        if isinstance(item, str) and item.strip():
            norm_playlist.append({"id": f"trk_{idx}", "uri": item.strip()})
        elif isinstance(item, dict):
            u = str(item.get("uri") or item.get("url") or item.get("path") or "").strip()
            t = str(item.get("title") or item.get("name") or "").strip()
            if u or t:
                row: Dict[str, Any] = {"id": str(item.get("id") or f"trk_{idx}"), "uri": u}
                if t:
                    row["title"] = t
                if item.get("subtitle") or item.get("artist"):
                    row["subtitle"] = str(item.get("subtitle") or item.get("artist")).strip()
                if "isVideo" in item:
                    row["isVideo"] = bool(item["isVideo"])
                if "durationMs" in item:
                    row["durationMs"] = int(item["durationMs"])
                norm_playlist.append(row)
    clean_uri = (uri or "").strip()
    if clean_uri and not norm_playlist:
        single: Dict[str, Any] = {"id": "trk_0", "uri": clean_uri}
        if title.strip():
            single["title"] = title.strip()
        if subtitle.strip():
            single["subtitle"] = subtitle.strip()
        norm_playlist.append(single)

    inferred_mode = (media_mode or "").strip().lower()
    if inferred_mode not in ("video", "audio"):
        first_uri = (norm_playlist[0].get("uri", "") if norm_playlist else clean_uri).lower().split("?")[0]
        if first_uri.endswith((".mp3", ".m4a", ".wav", ".ogg", ".flac", ".aac", ".opus")):
            inferred_mode = "audio"
        else:
            inferred_mode = "video"

    payload: Dict[str, Any] = {
        "active": True,
        "mediaMode": inferred_mode,
        "backgroundMode": bool(bg),
        "bg": bool(bg),
        "playing": bool(playing),
        "loop": bool(loop),
        "muted": bool(muted),
        "volume": max(0.0, min(1.0, float(volume))),
        "speed": max(0.5, min(2.5, float(speed))),
    }
    if clean_uri:
        payload["uri"] = clean_uri
    if title.strip():
        payload["title"] = title.strip()
    if subtitle.strip():
        payload["subtitle"] = subtitle.strip()
    if norm_playlist:
        payload["playlist"] = norm_playlist
    if action.strip():
        payload["action"] = action.strip().lower()
    if seek_ms is not None:
        payload["seekMs"] = max(0, int(seek_ms))
    return payload


def build_player_task_map(player_obj: Dict[str, Any]) -> Dict[str, Any]:
    """Wraps a player payload in a Window 3 TaskMapConfig with mode='player' and persistOnDone=True."""
    title = str(player_obj.get("title") or "").strip()
    if not title:
        pl = player_obj.get("playlist")
        if isinstance(pl, list) and pl and isinstance(pl[0], dict):
            title = str(pl[0].get("title") or "Agy Player").strip()
    return {
        "active": bool(player_obj.get("active", True)),
        "mode": "player",
        "title": title or "Agy Player",
        "widthDp": 228.0,
        "persistOnDone": True,
        "player": player_obj,
    }


def load_auth_token(explicit_token: Optional[str] = None) -> str:
    if explicit_token:
        return explicit_token.strip()
    for env_key in ("AURA_API_TOKEN", "AERO_TOKEN"):
        val = os.environ.get(env_key, "").strip()
        if val:
            return val
    for path in TOKEN_CANDIDATES:
        if os.path.exists(path):
            try:
                with open(path, "r", encoding="utf-8") as f:
                    val = f.read().strip()
                    if val:
                        return val
            except OSError:
                pass
    return ""


def load_conversation_id(path: str = CONVERSATION_ID_PATH) -> str:
    try:
        if os.path.exists(path):
            with open(path, "r", encoding="utf-8") as f:
                return f.read().strip()
    except OSError:
        pass
    return ""


def save_conversation_id(conv_id: str, path: str = CONVERSATION_ID_PATH) -> None:
    cleaned = (conv_id or "").strip()
    if not cleaned:
        return
    try:
        parent = os.path.dirname(os.path.abspath(path))
        if parent:
            os.makedirs(parent, exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            f.write(cleaned + "\n")
    except OSError:
        pass


def clear_conversation_id(path: str = CONVERSATION_ID_PATH) -> None:
    try:
        if os.path.exists(path):
            os.remove(path)
    except OSError:
        pass


def extract_conversation_id(event: Dict[str, Any]) -> str:
    if not isinstance(event, dict):
        return ""
    for key in ("conversation_id", "conversationId", "session_id", "sessionId"):
        val = event.get(key)
        if isinstance(val, str) and val.strip():
            return val.strip()
    for nested_key in ("session", "metadata", "result"):
        nested = event.get(nested_key)
        if isinstance(nested, dict):
            cid = extract_conversation_id(nested)
            if cid:
                return cid
    return ""


class KavachHudClient:
    """Zero-dependency HTTP + RFC 6455 WebSocket client for KaVach /api/hud/* endpoints."""

    def __init__(self, base_url: str, token: str, timeout: float = 5.0) -> None:
        self.base_url = base_url.rstrip("/")
        self.token = token.strip()
        self.timeout = timeout

    def _headers(self, json_body: bool = True) -> Dict[str, str]:
        headers = {
            "User-Agent": "AgyHudDaemon/2.0",
            "Accept": "application/json",
        }
        if json_body:
            headers["Content-Type"] = "application/json"
        if self.token:
            headers["Authorization"] = f"Bearer {self.token}"
            headers["X-API-Key"] = self.token
        return headers

    def request_json(
        self,
        method: str,
        path: str,
        payload: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        url = f"{self.base_url}{path}"
        data = json.dumps(payload).encode("utf-8") if payload is not None else None
        req = urllib.request.Request(
            url=url,
            data=data,
            headers=self._headers(json_body=payload is not None),
            method=method.upper(),
        )
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                raw = resp.read().decode("utf-8", errors="replace").strip()
                return json.loads(raw) if raw else {"success": True}
        except urllib.error.HTTPError as e:
            body = ""
            try:
                body = e.read().decode("utf-8", errors="replace")
                parsed = json.loads(body)
                if isinstance(parsed, dict):
                    parsed.setdefault("httpStatus", e.code)
                    return parsed
            except Exception:
                pass
            return {"success": False, "httpStatus": e.code, "error": body or str(e)}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def push_hud_state(self, state_payload: Dict[str, Any]) -> Dict[str, Any]:
        return self.request_json("POST", "/api/hud/state", state_payload)

    def patch_hud_state(self, patch_payload: Dict[str, Any]) -> Dict[str, Any]:
        return self.request_json("POST", "/api/hud/patch", patch_payload)

    def poll_hud_commands(self) -> Dict[str, Any]:
        return self.request_json("GET", "/api/hud/poll")

    def hide_hud(self) -> Dict[str, Any]:
        return self.request_json("POST", "/api/hud/hide", {})

    def reset_hud(self) -> Dict[str, Any]:
        return self.request_json("POST", "/api/hud/reset", {})

    def set_pointer_config(
        self,
        enabled: Optional[bool] = None,
        show_label: Optional[bool] = None,
    ) -> Dict[str, Any]:
        body: Dict[str, Any] = {}
        if enabled is not None:
            body["enabled"] = bool(enabled)
        if show_label is not None:
            body["showLabel"] = bool(show_label)
        return self.request_json("POST", "/api/hud/pointer", body)

    def push_approval(
        self,
        approval_id: str,
        title: str,
        description: str = "",
        command_preview: str = "",
        risk_level: str = "medium",
        allow_edit: bool = True,
        editable_text: str = "",
        timeout_seconds: int = 30,
    ) -> Dict[str, Any]:
        return self.request_json(
            "POST",
            "/api/hud/approval",
            {
                "active": True,
                "id": approval_id,
                "title": title,
                "description": description,
                "commandPreview": command_preview,
                "riskLevel": risk_level,
                "allowEdit": bool(allow_edit),
                "editableText": editable_text or command_preview,
                "timeoutSeconds": int(timeout_seconds),
            },
        )

    def clear_approval(self) -> Dict[str, Any]:
        return self.request_json("POST", "/api/hud/approval", {"clear": True, "active": False})

    def fetch_ui_tree(self) -> Dict[str, Any]:
        return self.request_json("GET", "/api/ui/tree")


class StdlibWebSocketListener:
    """
    Lightweight pure-stdlib RFC 6455 WebSocket client so the daemon runs in Termux
    without needing `pip install websockets`. Delivers real-time `HUD_COMMAND` frames
    and automatically reconnects on drop.
    """

    def __init__(
        self,
        base_http_url: str,
        token: str,
        on_message,
        stop_event: threading.Event,
    ) -> None:
        self.base_http_url = base_http_url.rstrip("/")
        self.token = token
        self.on_message = on_message
        self.stop_event = stop_event
        self.connected = False
        self._sock: Optional[socket.socket] = None
        self._thread: Optional[threading.Thread] = None

    def start(self) -> None:
        self._thread = threading.Thread(target=self._run_loop, name="agy-ws-listener", daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self.connected = False
        sock = self._sock
        if sock is not None:
            try:
                sock.close()
            except OSError:
                pass

    def _connect_and_read(self) -> None:
        parsed = urllib.parse.urlparse(self.base_http_url)
        host = parsed.hostname or "127.0.0.1"
        port = parsed.port or (443 if parsed.scheme == "https" else 8080)
        ws_path = "/ws"
        if self.token:
            ws_path = f"/ws?token={urllib.parse.quote(self.token)}"

        sock = socket.create_connection((host, port), timeout=5.0)
        self._sock = sock
        key = base64.b64encode(os.urandom(16)).decode("ascii")
        headers = [
            f"GET {ws_path} HTTP/1.1",
            f"Host: {host}:{port}",
            "Upgrade: websocket",
            "Connection: Upgrade",
            f"Sec-WebSocket-Key: {key}",
            "Sec-WebSocket-Version: 13",
        ]
        if self.token:
            headers.append(f"Authorization: Bearer {self.token}")
            headers.append(f"X-API-Key: {self.token}")
        req_bytes = ("\r\n".join(headers) + "\r\n\r\n").encode("utf-8")
        sock.sendall(req_bytes)

        resp_buf = b""
        while b"\r\n\r\n" not in resp_buf and len(resp_buf) < 8192:
            chunk = sock.recv(1024)
            if not chunk:
                raise ConnectionError("WebSocket closed during handshake")
            resp_buf += chunk
        status_line = resp_buf.split(b"\r\n", 1)[0].decode("utf-8", errors="replace")
        if "101" not in status_line:
            raise ConnectionError(f"WebSocket handshake rejected: {status_line}")

        expected_accept = base64.b64encode(
            hashlib.sha1((key + "258EAFA5-E914-47DA-95CA-C5AB0DC85B11").encode("utf-8")).digest()
        ).decode("ascii")
        if expected_accept.encode("ascii") not in resp_buf:
            raise ConnectionError("Invalid Sec-WebSocket-Accept")

        sock.settimeout(2.0)
        self.connected = True
        leftover = resp_buf.split(b"\r\n\r\n", 1)[1]

        def read_exact(n: int) -> bytes:
            nonlocal leftover
            while len(leftover) < n:
                if self.stop_event.is_set():
                    raise ConnectionAbortedError("Stopping")
                try:
                    data = sock.recv(max(4096, n - len(leftover)))
                except socket.timeout:
                    continue
                if not data:
                    raise ConnectionError("Socket EOF")
                leftover += data
            out = leftover[:n]
            leftover = leftover[n:]
            return out

        while not self.stop_event.is_set():
            hdr = read_exact(2)
            b0, b1 = hdr[0], hdr[1]
            opcode = b0 & 0x0F
            masked = (b1 & 0x80) != 0
            length = b1 & 0x7F
            if length == 126:
                length = struct.unpack("!H", read_exact(2))[0]
            elif length == 127:
                length = struct.unpack("!Q", read_exact(8))[0]
            mask_key = read_exact(4) if masked else b""
            payload = read_exact(length) if length > 0 else b""
            if masked and payload:
                payload = bytes(b ^ mask_key[i % 4] for i, b in enumerate(payload))

            if opcode == 0x8:
                break
            elif opcode == 0x9:
                self._send_ws_frame(sock, 0xA, payload)
            elif opcode == 0x1:
                try:
                    msg = json.loads(payload.decode("utf-8", errors="replace"))
                    if isinstance(msg, dict):
                        self.on_message(msg)
                except Exception:
                    pass

    @staticmethod
    def _send_ws_frame(sock: socket.socket, opcode: int, payload: bytes) -> None:
        mask = os.urandom(4)
        masked_payload = bytes(b ^ mask[i % 4] for i, b in enumerate(payload))
        header = bytearray([0x80 | (opcode & 0x0F)])
        length = len(payload)
        if length <= 125:
            header.append(0x80 | length)
        elif length <= 65535:
            header.append(0x80 | 126)
            header.extend(struct.pack("!H", length))
        else:
            header.append(0x80 | 127)
            header.extend(struct.pack("!Q", length))
        header.extend(mask)
        sock.sendall(bytes(header) + masked_payload)

    def _run_loop(self) -> None:
        backoff = 1.0
        while not self.stop_event.is_set():
            try:
                self._connect_and_read()
                backoff = 1.0
            except Exception:
                self.connected = False
            finally:
                if self._sock is not None:
                    try:
                        self._sock.close()
                    except OSError:
                        pass
                    self._sock = None
            if not self.stop_event.is_set():
                self.stop_event.wait(backoff)
                backoff = min(backoff * 1.5, 6.0)


def parse_bounds(bounds_str: str) -> Optional[Tuple[int, int, int, int]]:
    m = BOUNDS_RE.search(bounds_str or "")
    if not m:
        return None
    x1, y1, x2, y2 = (int(m.group(i)) for i in range(1, 5))
    if x2 <= x1 or y2 <= y1:
        return None
    return x1, y1, x2, y2


def _iter_tree_nodes(tree_response: Dict[str, Any]):
    """Yields visible non-HUD nodes across single or multi-window trees."""
    nodes_root = tree_response.get("tree") or tree_response.get("nodes") or tree_response.get("uiTree") or []
    if isinstance(nodes_root, dict):
        nodes_root = [nodes_root]
    stack: List[Dict[str, Any]] = list(reversed(nodes_root))
    while stack:
        node = stack.pop()
        if not isinstance(node, dict):
            continue
        view_id = str(node.get("viewId") or node.get("viewIdResourceName") or "")
        desc = str(node.get("contentDescription") or "")
        if "agy_hud_" in view_id.lower() or "agy_hud_" in desc.lower():
            continue
        yield node
        children = node.get("children") or []
        for child in reversed(children):
            stack.append(child)


def detect_split_and_pane(
    tree_response: Dict[str, Any],
) -> Tuple[str, Optional[Dict[str, int]], str]:
    """
    Inspects `/api/ui/tree` `display`, `windows`, and `splitScreen` fields to compute:
      `(split_label, pane_bounds, target_package)`
    Always excludes `com.termux` and `agy_hud_*` when selecting the target app pane.
    """
    display = tree_response.get("display") or {}
    disp_w = int(display.get("width") or 1080)
    disp_h = int(display.get("height") or 2400)
    rotation = display.get("rotation")
    orientation = str(display.get("orientation") or "").lower().strip()
    if rotation is None and orientation == "landscape":
        rotation = 90
    rot_int = int(rotation) if isinstance(rotation, (int, float)) else 0

    windows = tree_response.get("windows") or []
    split_info = tree_response.get("splitScreen") or {}

    target_pkg = str(split_info.get("targetPackage") or "").strip()
    if target_pkg in ("com.termux", "") or target_pkg.startswith("agy_hud_"):
        target_pkg = ""

    raw_pane = split_info.get("paneBounds")
    pane_bounds: Optional[Dict[str, int]] = None
    if isinstance(raw_pane, dict):
        px1 = int(raw_pane.get("x1", raw_pane.get("left", 0)))
        py1 = int(raw_pane.get("y1", raw_pane.get("top", 0)))
        px2 = int(raw_pane.get("x2", raw_pane.get("right", disp_w)))
        py2 = int(raw_pane.get("y2", raw_pane.get("bottom", disp_h)))
        if px2 > px1 and py2 > py1:
            pane_bounds = {
                "x1": px1,
                "y1": py1,
                "x2": px2,
                "y2": py2,
                "screenWidth": int(raw_pane.get("screenWidth") or disp_w),
                "screenHeight": int(raw_pane.get("screenHeight") or disp_h),
            }

    # Inspect non-Termux, non-HUD windows if pane_bounds or target_pkg missing
    non_termux_windows: List[Dict[str, Any]] = []
    for win in windows:
        if not isinstance(win, dict):
            continue
        pkg = str(win.get("packageName") or "").strip()
        if not pkg or "agy_hud_" in pkg.lower() or pkg == "com.termux":
            continue
        non_termux_windows.append(win)

    if not target_pkg and non_termux_windows:
        focused = next((w for w in non_termux_windows if w.get("isFocused") or w.get("isActive")), None)
        chosen = focused or non_termux_windows[0]
        target_pkg = str(chosen.get("packageName") or "").strip()

    if pane_bounds is None and non_termux_windows:
        chosen = next(
            (w for w in non_termux_windows if str(w.get("packageName") or "").strip() == target_pkg),
            non_termux_windows[0],
        )
        wb = parse_bounds(str(chosen.get("bounds") or ""))
        if wb:
            wx1, wy1, wx2, wy2 = wb
        elif all(k in chosen for k in ("left", "top", "right", "bottom")):
            wx1 = int(chosen["left"])
            wy1 = int(chosen["top"])
            wx2 = int(chosen["right"])
            wy2 = int(chosen["bottom"])
        else:
            wx1, wy1, wx2, wy2 = 0, 0, disp_w, disp_h
        if wx2 > wx1 and wy2 > wy1:
            pane_bounds = {
                "x1": wx1,
                "y1": wy1,
                "x2": wx2,
                "y2": wy2,
                "screenWidth": disp_w,
                "screenHeight": disp_h,
            }

    # Infer target package from tree nodes if still blank
    if not target_pkg:
        pkg_counts: Dict[str, int] = {}
        for node in _iter_tree_nodes(tree_response):
            pkg = str(node.get("packageName") or "").strip()
            if pkg and pkg != "com.termux" and not pkg.startswith("agy_hud_") and "systemui" not in pkg:
                pkg_counts[pkg] = pkg_counts.get(pkg, 0) + 1
        if pkg_counts:
            target_pkg = max(pkg_counts.items(), key=lambda item: item[1])[0]

    # Build concise orientation / split badge e.g. "SPLIT R • 90°" or "PORTRAIT"
    is_split = bool(split_info.get("active")) or (
        pane_bounds is not None
        and (
            (pane_bounds["x2"] - pane_bounds["x1"]) < int(disp_w * 0.85)
            or (pane_bounds["y2"] - pane_bounds["y1"]) < int(disp_h * 0.85)
        )
    )
    axis = str(split_info.get("axis") or "").lower().strip()
    split_prefix = ""
    if is_split and pane_bounds is not None:
        pw = pane_bounds["x2"] - pane_bounds["x1"]
        ph = pane_bounds["y2"] - pane_bounds["y1"]
        if axis == "horizontal" or (not axis and pw < int(disp_w * 0.85)):
            split_prefix = "SPLIT R" if pane_bounds["x1"] > int(disp_w * 0.30) else "SPLIT L"
        else:
            split_prefix = "SPLIT B" if pane_bounds["y1"] > int(disp_h * 0.30) else "SPLIT T"

    if split_prefix:
        split_label = f"{split_prefix} • {rot_int}°" if rot_int else split_prefix
    elif rot_int in (90, 270) or orientation == "landscape" or disp_w > disp_h:
        split_label = f"LANDSCAPE • {rot_int}°" if rot_int else "LANDSCAPE"
    elif rot_int == 180:
        split_label = "PORTRAIT • 180°"
    else:
        split_label = "PORTRAIT"

    return split_label, pane_bounds, target_pkg


def _piece_char(color: str, piece_name: str) -> str:
    table = {
        "king": "k",
        "queen": "q",
        "rook": "r",
        "bishop": "b",
        "knight": "n",
        "pawn": "p",
    }
    ch = table.get(piece_name.lower(), "p")
    return ch.upper() if color.lower() == "white" else ch


def _board_to_fen(board: List[List[str]]) -> str:
    rows: List[str] = []
    for r in range(8):
        empty = 0
        row_str = []
        for c in range(8):
            cell = board[r][c]
            if not cell:
                empty += 1
            else:
                if empty > 0:
                    row_str.append(str(empty))
                    empty = 0
                row_str.append(cell)
        if empty > 0:
            row_str.append(str(empty))
        rows.append("".join(row_str))
    return "/".join(rows)


def detect_chess_task_map(
    tree_response: Dict[str, Any],
    target_pkg: str = "",
    title_hint: str = "",
) -> Optional[Dict[str, Any]]:
    """
    Detects Chess apps (`com.chess`, `org.lichess.mobileapp`, `chess_autopilot`) or piece
    descriptions `(White|Black) <Piece> on <square>` and reconstructs an 8x8 FEN board.
    """
    board: List[List[str]] = [["" for _ in range(8)] for _ in range(8)]
    piece_count = 0
    white_y_sum = 0.0
    white_n = 0
    black_y_sum = 0.0
    black_n = 0
    eval_cp = ""
    turn_label = ""
    detected_move: Optional[Dict[str, str]] = None

    for node in _iter_tree_nodes(tree_response):
        pkg = str(node.get("packageName") or "").strip().lower()
        if pkg == "com.termux":
            continue
        for field in (node.get("contentDescription"), node.get("text")):
            val = str(field or "").strip()
            if not val:
                continue
            m = CHESS_SQUARE_RE.search(val)
            if m:
                color_str, piece_name, sq = m.group(1), m.group(2), m.group(3).lower()
                file_idx = ord(sq[0]) - ord("a")
                rank_from_top = ord("8") - ord(sq[1])
                if 0 <= file_idx < 8 and 0 <= rank_from_top < 8:
                    board[rank_from_top][file_idx] = _piece_char(color_str, piece_name)
                    piece_count += 1
                    b = parse_bounds(str(node.get("bounds") or node.get("boundsInScreen") or ""))
                    if b:
                        cy = (b[1] + b[3]) * 0.5
                        if color_str.lower() == "white":
                            white_y_sum += cy
                            white_n += 1
                        else:
                            black_y_sum += cy
                            black_n += 1
            elif not eval_cp and CHESS_EVAL_RE.match(val):
                eval_cp = val
            elif not turn_label and any(k in val.lower() for k in ("your turn", "white to move", "black to move", "opponent's turn")):
                turn_label = val[:24]
            elif detected_move is None:
                mv = CHESS_MOVE_RE.search(val)
                if mv and ("move" in val.lower() or "best" in val.lower()):
                    detected_move = {"from": mv.group(1).lower(), "to": mv.group(2).lower()}

    is_chess_pkg = any(k in (target_pkg or "").lower() for k in ("com.chess", "lichess", "chess"))
    if piece_count == 0 and not is_chess_pkg:
        return None

    fen = _board_to_fen(board) if piece_count >= 2 else "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR"
    if white_n > 0 and black_n > 0:
        player_color = "white" if (white_y_sum / white_n) >= (black_y_sum / black_n) else "black"
    else:
        player_color = "black" if "black" in (title_hint or "").lower() else "white"

    chess_obj: Dict[str, Any] = {
        "fen": fen,
        "playerColor": player_color,
        "evalCp": eval_cp or "+0.0",
    }
    if turn_label:
        chess_obj["turnLabel"] = turn_label
    if detected_move:
        chess_obj["bestMove"] = detected_move

    return {
        "active": True,
        "mode": "chess",
        "title": "Chess Board",
        "chess": chess_obj,
    }


def _parse_time_to_seconds(ts: str) -> int:
    parts = [int(p) for p in ts.split(":")]
    if len(parts) == 2:
        return parts[0] * 60 + parts[1]
    if len(parts) == 3:
        return parts[0] * 3600 + parts[1] * 60 + parts[2]
    return 0


def detect_media_task_map(
    tree_response: Dict[str, Any],
    target_pkg: str = "",
) -> Optional[Dict[str, Any]]:
    """
    Detects YouTube / Spotify / VLC playback screens from active package or transport nodes
    and extracts a sleek Now-Playing card instead of duplicating Termux/boxes.
    """
    pkg_low = (target_pkg or "").lower()
    provider = ""
    if "youtube" in pkg_low:
        provider = "youtube"
    elif "spotify" in pkg_low:
        provider = "spotify"
    elif "videolan" in pkg_low or "vlc" in pkg_low:
        provider = "vlc"

    has_transport_btn = False
    is_playing = True
    times_found: List[str] = []
    text_candidates: List[Tuple[int, str]] = []

    for node in _iter_tree_nodes(tree_response):
        node_pkg = str(node.get("packageName") or "").lower()
        if node_pkg == "com.termux":
            continue
        desc = str(node.get("contentDescription") or "").strip()
        text = str(node.get("text") or "").strip()
        view_id = str(node.get("viewId") or node.get("viewIdResourceName") or "").lower()

        for candidate in (desc, text):
            low = candidate.lower()
            if not candidate:
                continue
            if low in ("pause", "pause video", "pause track"):
                has_transport_btn = True
                is_playing = True
            elif low in ("play", "play video", "resume"):
                has_transport_btn = True
                is_playing = False
            for m in MEDIA_TIME_RE.findall(candidate):
                if m not in times_found:
                    times_found.append(m)

        if text and len(text) >= 4 and not MEDIA_TIME_RE.match(text):
            score = len(text)
            if "title" in view_id or "song" in view_id:
                score += 60
            elif "channel" in view_id or "artist" in view_id or "subtitle" in view_id:
                score += 30
            text_candidates.append((score, text))

    if not provider and not (has_transport_btn and times_found):
        return None
    if not provider:
        provider = "media"

    # Sort unique candidates while preserving clean top title / subtitle
    seen_txt: List[str] = []
    for _, t in sorted(text_candidates, key=lambda x: x[0], reverse=True):
        if t not in seen_txt and t.lower() not in ("pause", "play", "next", "previous", "skip"):
            seen_txt.append(t)

    title = seen_txt[0][:44] if seen_txt else f"{provider.capitalize()} Playback"
    subtitle = seen_txt[1][:36] if len(seen_txt) > 1 else ""

    elapsed_text = times_found[0] if len(times_found) >= 1 else ""
    duration_text = times_found[1] if len(times_found) >= 2 else ""
    progress_pct = 0.0
    if elapsed_text and duration_text:
        e_sec = _parse_time_to_seconds(elapsed_text)
        d_sec = _parse_time_to_seconds(duration_text)
        if d_sec > 0:
            progress_pct = round(min(100.0, max(0.0, (e_sec / d_sec) * 100.0)), 1)

    return {
        "active": True,
        "mode": "media",
        "title": f"▶ {provider.capitalize()}" if provider != "media" else "▶ Media",
        "media": {
            "provider": provider,
            "title": title,
            "subtitle": subtitle,
            "appPackage": target_pkg,
            "progressPercent": progress_pct,
            "elapsedText": elapsed_text,
            "durationText": duration_text,
            "playing": is_playing,
        },
    }


def _rects_overlap(ax1: int, ay1: int, ax2: int, ay2: int, bx1: int, by1: int, bx2: int, by2: int) -> bool:
    return ax1 < bx2 and ax2 > bx1 and ay1 < by2 and ay2 > by1


def extract_wireframe_from_ui_tree(
    tree_response: Dict[str, Any],
    action_vector: Optional[Dict[str, Any]] = None,
    label: str = "Watching Screen",
    max_zones: int = 8,
    pane_bounds: Optional[Dict[str, int]] = None,
    target_pkg: str = "",
) -> Dict[str, Any]:
    """
    Extracts compact semantic zones from `/api/ui/tree` (excluding `agy_hud_*` and excluding
    `com.termux` when another app pane is active), producing rich semantic roles:
    `search_bar`, `toggle`, `input`, `list_row`, `cta_button`, `target`, `header`, `card`.
    """
    candidates: List[Tuple[float, Dict[str, Any]]] = []
    display = tree_response.get("display") or {}
    max_x = int(display.get("width") or 1080)
    max_y = int(display.get("height") or 2400)
    pane_top = int(pane_bounds["y1"]) if pane_bounds else 0

    for node in _iter_tree_nodes(tree_response):
        node_pkg = str(node.get("packageName") or "").strip()
        if target_pkg and target_pkg != "com.termux" and node_pkg == "com.termux":
            continue

        view_id = str(node.get("viewId") or node.get("viewIdResourceName") or "")
        desc = str(node.get("contentDescription") or "")
        text = str(node.get("text") or "")

        b = parse_bounds(str(node.get("bounds") or node.get("boundsInScreen") or ""))
        if b is None:
            continue
        x1, y1, x2, y2 = b
        max_x = max(max_x, x2)
        max_y = max(max_y, y2)

        if pane_bounds is not None:
            if not _rects_overlap(
                x1,
                y1,
                x2,
                y2,
                pane_bounds["x1"],
                pane_bounds["y1"],
                pane_bounds["x2"],
                pane_bounds["y2"],
            ):
                continue

        w, h = x2 - x1, y2 - y1
        area = w * h
        pane_area = (
            (pane_bounds["x2"] - pane_bounds["x1"]) * (pane_bounds["y2"] - pane_bounds["y1"])
            if pane_bounds
            else (max_x * max_y)
        )
        if w < 36 or h < 28 or area >= pane_area * 0.85:
            continue

        is_clickable = bool(node.get("isClickable"))
        is_editable = bool(node.get("isEditable"))
        is_focused = bool(node.get("isFocused"))
        is_checkable = bool(node.get("isCheckable"))
        is_checked = node.get("isChecked")
        cls = str(node.get("className") or "").split(".")[-1].lower()
        tag = (text or desc or view_id.split("/")[-1]).strip()
        hint_hay = f"{view_id} {desc} {text} {cls}".lower()

        score = 0.0
        role = "panel"
        checked_val: Optional[bool] = None

        if is_checkable or any(k in cls for k in ("switch", "checkbox", "toggle", "radiobutton")):
            score += 4.6
            role = "toggle"
            checked_val = bool(is_checked) if is_checked is not None else False
        elif (is_editable or "edittext" in cls) and ("search" in hint_hay or "query" in hint_hay):
            score += 5.2
            role = "search_bar"
        elif "search" in hint_hay and y1 - pane_top < 380 and (is_clickable or "search" in view_id.lower()):
            score += 4.8
            role = "search_bar"
        elif is_editable or "edittext" in cls:
            score += 4.4
            role = "input"
        elif is_focused:
            score += 5.0
            role = "target"
        elif is_clickable or "button" in cls:
            if w > (pane_bounds["x2"] - pane_bounds["x1"] if pane_bounds else max_x) * 0.55 and h <= 220 and text:
                score += 3.2
                role = "list_row"
            else:
                score += 3.6
                role = "cta_button"
        elif (y1 - pane_top) < 240 and tag:
            score += 1.9
            role = "header"
        elif tag:
            score += 1.4
            role = "card"

        if tag:
            score += 1.0
        if action_vector:
            vx = float(action_vector.get("x1", -1))
            vy = float(action_vector.get("y1", -1))
            if x1 <= vx <= x2 and y1 <= vy <= y2:
                score += 9.0
                role = "target"

        if score >= 2.0:
            zone_obj: Dict[str, Any] = {
                "x1": x1,
                "y1": y1,
                "x2": x2,
                "y2": y2,
                "role": role,
                "tag": tag[:20],
            }
            if checked_val is not None:
                zone_obj["checked"] = checked_val
            candidates.append((score, zone_obj))

    candidates.sort(key=lambda item: item[0], reverse=True)
    selected: List[Dict[str, Any]] = []
    for _, zone in candidates:
        if len(selected) >= max_zones:
            break
        duplicate = False
        for existing in selected:
            if (
                abs(existing["x1"] - zone["x1"]) < 24
                and abs(existing["y1"] - zone["y1"]) < 24
                and abs(existing["x2"] - zone["x2"]) < 24
                and abs(existing["y2"] - zone["y2"]) < 24
            ):
                duplicate = True
                break
        if not duplicate:
            selected.append(zone)

    payload: Dict[str, Any] = {
        "active": True,
        "label": label,
        "screenWidth": max_x,
        "screenHeight": max_y,
        "zones": selected,
    }
    if action_vector:
        payload["actionVector"] = action_vector
    return payload


def build_task_map_from_ui_tree(
    tree_response: Dict[str, Any],
    action_vector: Optional[Dict[str, Any]] = None,
    label: str = "Watching Screen",
    title_hint: str = "",
    max_zones: int = 8,
) -> Tuple[Dict[str, Any], Dict[str, Any], str]:
    """
    Combines split-screen/rotation detection + task-specific extractors (`chess`, `media`,
    `app_pane`) to produce `(task_map_payload, screen_watch_payload, detected_target_package)`.
    """
    split_label, pane_bounds, target_pkg = detect_split_and_pane(tree_response)

    wf = extract_wireframe_from_ui_tree(
        tree_response=tree_response,
        action_vector=action_vector,
        label=label,
        max_zones=max_zones,
        pane_bounds=pane_bounds,
        target_pkg=target_pkg,
    )

    chess_map = detect_chess_task_map(tree_response, target_pkg=target_pkg, title_hint=title_hint)
    if chess_map is not None:
        chess_map["splitLabel"] = split_label
        if pane_bounds:
            chess_map["paneBounds"] = pane_bounds
        return chess_map, wf, target_pkg or "com.chess"

    media_map = detect_media_task_map(tree_response, target_pkg=target_pkg)
    if media_map is not None:
        media_map["splitLabel"] = split_label
        if pane_bounds:
            media_map["paneBounds"] = pane_bounds
        return media_map, wf, target_pkg

    app_pane_map: Dict[str, Any] = {
        "active": True,
        "mode": "app_pane",
        "title": label if label and label != "Watching Screen" else (target_pkg.split(".")[-1].capitalize() if target_pkg else "App Pane"),
        "splitLabel": split_label,
        "paneMode": "pane" if pane_bounds and "SPLIT" in split_label else "full",
        "appPane": {
            "targetPackage": target_pkg,
            "screenWidth": wf["screenWidth"],
            "screenHeight": wf["screenHeight"],
            "zones": wf["zones"],
        },
    }
    if pane_bounds:
        app_pane_map["paneBounds"] = pane_bounds
    if action_vector:
        app_pane_map["appPane"]["actionVector"] = action_vector
    return app_pane_map, wf, target_pkg


# Weighted (base_priority, keywords, icon_key, app_package) rules.
# Concrete apps (chess, youtube, vlc, calculator, etc.) intentionally outrank generic verbs
# (`python`, `script`, `tap`, `search`) and `"video"` does NOT map to Camera!
WEIGHTED_APP_ICON_RULES: List[Tuple[int, Tuple[str, ...], str, str]] = [
    (12, ("chess", "chess.com", "chessboard", "grandmaster", "checkmate", "com.chess"), "chess", "com.chess"),
    (12, ("lichess", "org.lichess.mobileapp"), "lichess", "org.lichess.mobileapp"),
    (11, ("youtube", "youtu.be", "yt", "com.google.android.youtube", "playlist", "shorts"), "youtube", "com.google.android.youtube"),
    (11, ("whatsapp", "wa", "wa.me", "com.whatsapp"), "whatsapp", "com.whatsapp"),
    (11, ("spotify", "music", "podcast", "com.spotify.music"), "spotify", "com.spotify.music"),
    (11, ("vlc", "videolan", "org.videolan.vlc"), "vlc", "org.videolan.vlc"),
    (11, ("calculator", "calc", "com.google.android.calculator", "com.android.calculator2"), "calculator", "com.google.android.calculator"),
    (10, ("chrome", "browser", "http://", "https://", "webpage", "website", "com.android.chrome"), "chrome", "com.android.chrome"),
    (10, ("instagram", "insta", "reels", "com.instagram.android"), "instagram", "com.instagram.android"),
    (10, ("telegram", "t.me", "org.telegram.messenger"), "telegram", "org.telegram.messenger"),
    (10, ("gmail", "email", "inbox", "mail", "com.google.android.gm"), "gmail", "com.google.android.gm"),
    (10, ("maps", "navigation", "directions", "gps", "com.google.android.apps.maps"), "maps", "com.google.android.apps.maps"),
    (10, ("settings", "wi-fi", "wifi", "bluetooth", "accessibility", "com.android.settings"), "settings", "com.android.settings"),
    (10, ("github", "git ", "repo", "commit", "pull request", "com.github.android"), "github", "com.github.android"),
    (10, ("play store", "playstore", "install app", "com.android.vending"), "play_store", "com.android.vending"),
    (10, ("clock", "alarm", "timer", "stopwatch", "deskclock", "com.google.android.deskclock"), "clock", "com.google.android.deskclock"),
    (8, ("camera", "photo", "selfie", "take picture", "take a photo", "camera capture"), "camera", ""),
    (8, ("call ", "dial", "phone", "sms", "contact"), "phone", ""),
    (5, ("token", "auth", "security", "shield", "lock", "audit"), "security", ""),
    (4, ("file", "folder", "download", "storage", "vault", "backup"), "files", ""),
    (3, ("termux", "bash", "shell", "terminal", "cli", "daemon", "ssh", "com.termux"), "termux", "com.termux"),
    (2, ("code", "python", "script", "build", "compile", "kotlin", "gradle", "debug", "test"), "code", ""),
    (2, ("tap ", "swipe", "scroll", "click", "gesture", "screen", "ui_"), "tap", ""),
    (2, ("search", "query", "lookup", "find", "google"), "search", ""),
]


def _keyword_matches(haystack: str, kw: str) -> bool:
    if len(kw.strip()) <= 3:
        return bool(re.search(rf"(^|[^a-z0-9]){re.escape(kw.strip())}([^a-z0-9]|$)", haystack))
    return kw in haystack


def infer_app_icon(
    text: str,
    explicit_icon: str = "",
    explicit_package: str = "",
    preserve_package: str = "",
) -> Tuple[str, str]:
    """
    Infers `(icon_key, app_package)` using weighted matching so target apps (e.g. Chess,
    YouTube) beat generic script/action verbs (e.g. python, tap), and `com.termux` never
    clobbers a non-Termux active target package.
    """
    clean_icon = explicit_icon.strip()
    clean_pkg = explicit_package.strip()
    if clean_pkg == "com.termux" and preserve_package and preserve_package != "com.termux":
        clean_pkg = ""
    if clean_icon or (clean_pkg and clean_pkg != "com.termux"):
        return clean_icon, clean_pkg

    hay = f" {(text or '').lower()} "
    best_score = 0
    best_pair: Tuple[str, str] = ("spark", "")
    for priority, keywords, icon_key, pkg in WEIGHTED_APP_ICON_RULES:
        for kw in keywords:
            if _keyword_matches(hay, kw):
                word_bonus = 4 if re.search(rf"(^|[^a-z0-9]){re.escape(kw.strip())}([^a-z0-9]|$)", hay) else 1
                score = priority + word_bonus
                if score > best_score:
                    best_score = score
                    best_pair = (icon_key, pkg)
                break

    if best_score > 0:
        if best_pair[1] == "com.termux" and preserve_package and preserve_package != "com.termux":
            return best_pair[0], preserve_package
        return best_pair
    if preserve_package and preserve_package != "com.termux":
        return clean_icon, preserve_package
    if explicit_package.strip():
        return clean_icon, explicit_package.strip()
    return "spark", ""


def infer_action_kind(text: str = "", tool_name: str = "", evt_type: str = "") -> str:
    """
    Infers live ActionKind sub-badge key for the 13dp corner indicator:
    `watching` | `tapping` | `typing` | `coding` | `searching` | `playing` | `security` | ``
    """
    hay = f" {evt_type} {tool_name} {text} ".lower()
    if any(k in hay for k in ("input_text", "typing", "type ", "enter text")):
        return "typing"
    if any(k in hay for k in ("ui_tree", "inspect", "watching", "screen watch", "reading screen")):
        return "watching"
    if any(k in hay for k in ("ui_action", "tap", "click", "swipe", "drag", "scroll", "move ")):
        return "tapping"
    if any(k in hay for k in ("playing", "now playing", "playback", "music", "youtube", "spotify", "vlc", "video")):
        return "playing"
    if any(k in hay for k in ("search", "lookup", "query", "find ")):
        return "searching"
    if any(k in hay for k in ("token", "auth", "shield", "audit", "verify", "security")):
        return "security"
    if any(k in hay for k in ("python", "gradle", "compile", "script", "bash", "shell", "code", "daemon")):
        return "coding"
    return ""


class HudStateTracker:
    """Maintains structured Agy HUD & Window 3 TaskMap state and maps agy JSON events."""

    def __init__(self, auto_collapse_seconds: int = 4) -> None:
        self.auto_collapse_seconds = auto_collapse_seconds
        self.state = "IDLE"
        self.title = "Agy Ready"
        self.current_action = ""
        self.next_action = ""
        self.question = ""
        self.icon = "spark"
        self.app_package = ""
        self.action_kind = ""
        self.active_target_package = ""
        self.detailed_output = ""
        self.output_logs: List[str] = []
        self.quick_actions: List[Dict[str, str]] = []
        self.tasks: List[Dict[str, str]] = []
        self.screen_watch: Dict[str, Any] = {
            "active": False,
            "label": "",
            "screenWidth": 1080,
            "screenHeight": 2400,
            "zones": [],
        }
        self.task_map: Dict[str, Any] = {
            "active": False,
            "mode": "app_pane",
        }
        self.prompt_text = ""
        self.is_query_mode = False
        self.collected_result_items: List[Dict[str, Any]] = []
        self._lock = threading.Lock()

    def _append_log_locked(self, line: str) -> None:
        cleaned = (line or "").strip()
        if not cleaned:
            return
        ts = time.strftime("%H:%M:%S")
        entry = f"[{ts}] {cleaned[:180]}"
        if self.output_logs and self.output_logs[-1].endswith(cleaned[:180]):
            return
        self.output_logs.append(entry)
        if len(self.output_logs) > 24:
            self.output_logs = self.output_logs[-24:]

    def _default_quick_actions_locked(self) -> List[Dict[str, str]]:
        if self.state == "NEEDS_INPUT":
            return [
                {"label": "Yes, proceed", "commandText": "Yes, proceed", "actionType": "PROMPT"},
                {"label": "Skip step", "commandText": "Skip this step", "actionType": "PROMPT"},
                {"label": "Stop", "commandText": "", "actionType": "STOP"},
            ]
        if self.state == "DONE":
            actions: List[Dict[str, str]] = []
            if self.detailed_output or self.output_logs:
                actions.append({"label": "Copy Output", "commandText": "", "actionType": "COPY_OUTPUT"})
                actions.append({"label": "View Output", "commandText": "", "actionType": "TOGGLE_OUTPUT"})
            actions.append({"label": "Run Again", "commandText": f"Run again: {self.title}", "actionType": "PROMPT"})
            return actions
        if self.state == "STOPPED":
            actions = []
            if self.detailed_output or self.output_logs:
                actions.append({"label": "Copy Output", "commandText": "", "actionType": "COPY_OUTPUT"})
            actions.append({"label": "Run Again", "commandText": f"Run again: {self.title}", "actionType": "PROMPT"})
            return actions
        if self.state == "WORKING":
            actions = [{"label": "Pause", "commandText": "", "actionType": "PAUSE"}]
            if self.detailed_output or self.output_logs:
                actions.append({"label": "Live Logs", "commandText": "", "actionType": "TOGGLE_OUTPUT"})
            actions.append({"label": "Stop", "commandText": "", "actionType": "STOP"})
            return actions
        if self.state == "PAUSED":
            actions = [{"label": "Resume", "commandText": "", "actionType": "RESUME"}]
            if self.detailed_output or self.output_logs:
                actions.append({"label": "Logs", "commandText": "", "actionType": "TOGGLE_OUTPUT"})
            actions.append({"label": "Stop", "commandText": "", "actionType": "STOP"})
            return actions
        return []

    def _merge_result_items_locked(self, new_items: List[Dict[str, Any]]) -> None:
        if not new_items:
            return
        seen = {str(it.get("uri") or "") for it in self.collected_result_items}
        for item in new_items:
            uri = str(item.get("uri") or "")
            if uri and uri not in seen:
                seen.add(uri)
                item_copy = dict(item)
                item_copy.setdefault("id", f"res_{len(self.collected_result_items) + 1}")
                self.collected_result_items.append(item_copy)

    def begin_prompt(self, prompt_text: str) -> Dict[str, Any]:
        with self._lock:
            self.state = "WORKING"
            self.prompt_text = prompt_text.strip()
            self.is_query_mode = is_informational_query(self.prompt_text)
            self.collected_result_items = []
            self.title = self.prompt_text[:64] or "Running Task"
            self.current_action = "Searching & gathering answer..." if self.is_query_mode else "Analyzing request..."
            self.next_action = "Summarizing results" if self.is_query_mode else "Planning execution steps"
            self.question = ""
            self.icon, self.app_package = infer_app_icon(prompt_text)
            self.active_target_package = self.app_package if self.app_package != "com.termux" else ""
            self.action_kind = "searching" if self.is_query_mode else infer_action_kind(prompt_text)
            self.detailed_output = f"Prompt: {self.prompt_text}"
            self.output_logs = []
            self._append_log_locked(f"Prompt queued: {self.title}")
            self.quick_actions = []
            self.tasks = [
                {
                    "id": "step_1",
                    "label": "Search & prepare response" if self.is_query_mode else "Understand & plan task",
                    "status": "doing",
                    "icon": "search" if self.is_query_mode and self.icon == "spark" else self.icon,
                    "appPackage": self.app_package,
                    "actionKind": self.action_kind,
                },
            ]
            self.screen_watch = {
                "active": False,
                "label": "",
                "screenWidth": 1080,
                "screenHeight": 2400,
                "zones": [],
            }
            if self.task_map.get("mode") == "player" and self.task_map.get("active"):
                # Keep the active player alive and auto-collapse it into the background mini-pill when a new task starts
                self.task_map["active"] = True
                self.task_map.setdefault("persistOnDone", True)
                player_inner = self.task_map.get("player")
                if isinstance(player_inner, dict):
                    player_inner["backgroundMode"] = True
                    player_inner["bg"] = True
            else:
                # Visual-only Left Window: stay inactive until visuals, video, wireframe, or multi-step diagram exist
                self.task_map = {
                    "active": False,
                    "mode": "app_pane",
                }
            return self.to_payload_locked()

    def apply_agy_event(self, event: Dict[str, Any]) -> Tuple[Dict[str, Any], bool]:
        """
        Applies a parsed `agy` JSON event to HUD state.
        Returns `(hud_payload, screen_watch_active)`.
        """
        with self._lock:
            evt_type = str(event.get("type") or event.get("event") or "").lower()

            if event.get("icon") or event.get("appPackage"):
                self.icon, self.app_package = infer_app_icon(
                    self.title,
                    str(event.get("icon") or ""),
                    str(event.get("appPackage") or ""),
                    preserve_package=self.active_target_package,
                )
                if self.app_package and self.app_package != "com.termux":
                    self.active_target_package = self.app_package
            if isinstance(event.get("actionKind"), str) and event["actionKind"].strip():
                self.action_kind = event["actionKind"].strip().lower()
            if isinstance(event.get("detailedOutput"), str) and event["detailedOutput"].strip():
                self.detailed_output = event["detailedOutput"].strip()[:2400]
                self._merge_result_items_locked(extract_media_items_from_text(self.detailed_output))
            if isinstance(event.get("outputLogs"), list):
                for entry in event["outputLogs"]:
                    if isinstance(entry, str) and entry.strip():
                        self._append_log_locked(entry)
            if isinstance(event.get("quickActions"), list):
                parsed_qa: List[Dict[str, str]] = []
                for qa in event["quickActions"]:
                    if isinstance(qa, dict) and qa.get("label"):
                        parsed_qa.append(
                            {
                                "label": str(qa.get("label")).strip(),
                                "commandText": str(qa.get("commandText") or "").strip(),
                                "actionType": str(qa.get("actionType") or "PROMPT").strip().upper(),
                            }
                        )
                self.quick_actions = parsed_qa
            if isinstance(event.get("results"), dict):
                res_obj = event["results"]
                if isinstance(res_obj.get("items"), list):
                    self._merge_result_items_locked([x for x in res_obj["items"] if isinstance(x, dict)])
                self.task_map = build_visual_left_window_task_map(
                    query=str(res_obj.get("query") or self.prompt_text or self.title),
                    items=self.collected_result_items or list(res_obj.get("items") or []),
                    detailed_output=self.detailed_output,
                    tasks=self.tasks,
                )
            if isinstance(event.get("diagram"), dict):
                self.task_map = build_diagram_task_map(event["diagram"], title=self.title)
            if isinstance(event.get("player"), dict):
                self.task_map = build_player_task_map(event["player"])
            if isinstance(event.get("taskMap"), dict):
                self.task_map = dict(event["taskMap"])
                if self.task_map.get("mode") in ("results", "player", "diagram"):
                    self.task_map.setdefault("persistOnDone", True)
                    res_inner = self.task_map.get("results")
                    if isinstance(res_inner, dict) and isinstance(res_inner.get("items"), list):
                        self._merge_result_items_locked([x for x in res_inner["items"] if isinstance(x, dict)])

            # 1. Step / Checklist updates (update_steps / step_update / steps / tasks)
            steps = event.get("steps") or event.get("tasks") or event.get("checklist")
            if steps is None and evt_type == "step_update":
                single_step = event.get("step") if isinstance(event.get("step"), dict) else (
                    event if (event.get("label") or event.get("title") or event.get("id")) else None
                )
                if isinstance(single_step, dict):
                    tid = str(single_step.get("id") or f"step_{len(self.tasks) + 1}")
                    status_raw = str(single_step.get("status") or single_step.get("state") or "doing").lower()
                    status = self._normalize_task_status(status_raw)
                    label = str(single_step.get("label") or single_step.get("title") or "").strip()
                    t_icon, t_pkg = infer_app_icon(
                        label,
                        str(single_step.get("icon") or ""),
                        str(single_step.get("appPackage") or ""),
                        preserve_package=self.active_target_package,
                    )
                    t_ak = str(single_step.get("actionKind") or infer_action_kind(label))
                    updated_step: Dict[str, str] = {
                        "id": tid,
                        "label": label or tid,
                        "status": status,
                        "icon": t_icon,
                        "appPackage": t_pkg,
                        "actionKind": t_ak,
                    }
                    replaced = False
                    for idx, existing in enumerate(self.tasks):
                        if existing.get("id") == tid:
                            if not label:
                                updated_step["label"] = existing.get("label", tid)
                            self.tasks[idx] = updated_step
                            replaced = True
                            break
                    if not replaced:
                        self.tasks.append(updated_step)
                    if status == "doing":
                        self.current_action = updated_step["label"]
                        self.action_kind = t_ak or self.action_kind
                        self._append_log_locked(f"Step active: {updated_step['label']}")
                    self.state = "WORKING"

            if isinstance(steps, list):
                parsed_tasks: List[Dict[str, str]] = []
                doing_label = ""
                doing_ak = ""
                next_label = ""
                for idx, item in enumerate(steps):
                    if isinstance(item, dict):
                        status_raw = str(item.get("status") or item.get("state") or "pending").lower()
                        status = self._normalize_task_status(status_raw)
                        label = str(item.get("label") or item.get("title") or item.get("description") or f"Step {idx + 1}").strip()
                        tid = str(item.get("id") or f"step_{idx + 1}")
                        t_icon, t_pkg = infer_app_icon(
                            label,
                            str(item.get("icon") or ""),
                            str(item.get("appPackage") or ""),
                            preserve_package=self.active_target_package,
                        )
                        t_ak = str(item.get("actionKind") or infer_action_kind(label))
                        task_obj: Dict[str, str] = {
                            "id": tid,
                            "label": label,
                            "status": status,
                            "icon": t_icon,
                            "appPackage": t_pkg,
                            "actionKind": t_ak,
                        }
                        detail = str(item.get("detail") or "").strip()
                        if detail:
                            task_obj["detail"] = detail
                        parsed_tasks.append(task_obj)
                        if status == "doing" and not doing_label:
                            doing_label = label
                            doing_ak = t_ak
                        elif status == "pending" and not next_label:
                            next_label = label
                    elif isinstance(item, str):
                        t_icon, t_pkg = infer_app_icon(item, preserve_package=self.active_target_package)
                        parsed_tasks.append(
                            {
                                "id": f"step_{idx + 1}",
                                "label": item.strip(),
                                "status": "pending",
                                "icon": t_icon,
                                "appPackage": t_pkg,
                                "actionKind": infer_action_kind(item),
                            }
                        )
                if parsed_tasks:
                    self.tasks = parsed_tasks
                    if doing_label:
                        self.current_action = doing_label
                        if doing_ak:
                            self.action_kind = doing_ak
                        self._append_log_locked(f"Step active: {doing_label}")
                    if next_label:
                        self.next_action = next_label
                    self.state = "WORKING"
                    if (
                        len(self.tasks) >= 2
                        and not self.screen_watch.get("active")
                        and not (self.task_map.get("active") and self.task_map.get("mode") in ("player", "chess", "media", "results"))
                    ):
                        diag = build_diagram_from_tasks(self.tasks, title=self.title or "Task Flow")
                        if diag is not None:
                            self.task_map = build_diagram_task_map(diag, title=self.title, persist_on_done=False)

            # 2. Active Tool Call inspection
            tool_name = str(
                event.get("tool")
                or event.get("tool_name")
                or event.get("name")
                or (event.get("tool_use") or {}).get("name", "")
            ).strip()
            tool_args = (
                event.get("arguments")
                or event.get("args")
                or event.get("input")
                or (event.get("tool_use") or {}).get("input")
                or {}
            )
            if isinstance(tool_args, str):
                try:
                    tool_args = json.loads(tool_args)
                except Exception:
                    tool_args = {"raw": tool_args}

            if tool_name or evt_type in ("tool_use", "tool_call", "function_call"):
                self.state = "WORKING"
                display_tool = tool_name or "tool"
                self.current_action = f"Running {display_tool}"
                args_str = json.dumps(tool_args, default=str)
                t_icon, t_pkg = infer_app_icon(
                    f"{display_tool} {args_str}",
                    preserve_package=self.active_target_package,
                )
                if t_pkg and t_pkg != "com.termux":
                    self.active_target_package = t_pkg
                if (self.icon in ("spark", "termux", "code", "tap", "search") and t_icon not in ("spark", "termux")):
                    self.icon, self.app_package = t_icon, (t_pkg or self.app_package)
                self.action_kind = infer_action_kind(args_str, tool_name=display_tool, evt_type=evt_type) or self.action_kind
                self._append_log_locked(f"tool:{display_tool} {args_str[:110]}")
                if self._is_screen_tool(display_tool, tool_args):
                    action_vec = self._extract_action_vector(display_tool, tool_args)
                    self.screen_watch["active"] = True
                    self.screen_watch["label"] = f"Tool: {display_tool}"
                    if action_vec:
                        self.screen_watch["actionVector"] = action_vec
                    self.task_map["active"] = True
                else:
                    self.screen_watch["active"] = False
                    self.screen_watch.pop("actionVector", None)
                    if self.task_map.get("mode") == "app_pane":
                        self.task_map["active"] = False

            # 3. Direct question / NEEDS_INPUT escalation
            if evt_type in ("needs_input", "question", "ask_user", "input_required") or event.get("needs_input"):
                q = str(event.get("question") or event.get("text") or event.get("message") or "Agy needs your input").strip()
                self.state = "NEEDS_INPUT"
                self.question = q
                self.current_action = "Waiting for your reply..."
                self.screen_watch["active"] = False
                if self.task_map.get("mode") != "player":
                    self.task_map["active"] = False
                self._append_log_locked(f"Needs input: {q}")

            # 4. Turn / Task Completion
            elif evt_type in ("result", "done", "complete", "completed", "turn_complete", "final"):
                summary = str(event.get("summary") or event.get("text") or event.get("result") or "Task completed").strip()
                self.state = "DONE"
                self.current_action = summary[:80]
                self.next_action = ""
                self.question = ""
                if summary:
                    self.detailed_output = summary[:2400]
                    self._merge_result_items_locked(extract_media_items_from_text(summary))
                    self._append_log_locked(f"Done: {summary[:140]}")
                self.screen_watch["active"] = False
                self.screen_watch.pop("actionVector", None)
                was_live_pane = self.task_map.get("mode") in ("app_pane", "chess", "media", "telemetry")
                if isinstance(explicit_tm, dict):
                    if self.task_map.get("mode") in ("results", "player", "diagram"):
                        self.task_map["active"] = True
                        self.task_map.setdefault("persistOnDone", True)
                elif self.task_map.get("mode") == "player" and self.task_map.get("persistOnDone", True):
                    self.task_map["active"] = True
                    self.task_map.setdefault("persistOnDone", True)
                elif self.task_map.get("mode") == "diagram" and self.task_map.get("persistOnDone", True):
                    self.task_map["active"] = True
                    self.task_map.setdefault("persistOnDone", True)
                elif was_live_pane and not self.collected_result_items and extract_diagram_from_text(self.detailed_output) is None:
                    self.task_map["active"] = False
                else:
                    self.task_map = build_visual_left_window_task_map(
                        query=self.prompt_text or self.title,
                        items=self.collected_result_items,
                        detailed_output=self.detailed_output,
                        tasks=self.tasks,
                        persist_on_done=True,
                    )
                for t in self.tasks:
                    if t["status"] in ("doing", "pending"):
                        t["status"] = "done"

            # 5. Plain text delta / status updates
            elif evt_type in ("status", "assistant", "message", "text", "delta"):
                txt = str(event.get("text") or event.get("content") or event.get("message") or "").strip()
                if txt:
                    self._append_log_locked(txt.splitlines()[0])
                    if len(txt) > len(self.detailed_output) or evt_type in ("assistant", "message"):
                        self.detailed_output = txt[:2400]
                    self._merge_result_items_locked(extract_media_items_from_text(txt))
                    if txt.endswith("?") and len(txt) < 160 and event.get("awaiting_reply"):
                        self.state = "NEEDS_INPUT"
                        self.question = txt
                        if self.task_map.get("mode") != "player":
                            self.task_map["active"] = False
                    else:
                        self.state = "WORKING"
                        self.current_action = txt.splitlines()[0][:80]
                        ak = infer_action_kind(txt)
                        if ak:
                            self.action_kind = ak
                        if not (self.task_map.get("active") and self.task_map.get("mode") == "player"):
                            self.task_map = build_visual_left_window_task_map(
                                query=self.prompt_text or self.title,
                                items=self.collected_result_items,
                                detailed_output=self.detailed_output,
                                tasks=self.tasks,
                                persist_on_done=True,
                            )

            should_watch_screen = bool(
                self.screen_watch.get("active")
                or (
                    self.task_map.get("active")
                    and self.task_map.get("mode") in ("app_pane", "chess", "media")
                )
            )
            return self.to_payload_locked(), should_watch_screen

    def update_wireframe(
        self,
        wireframe_payload: Dict[str, Any],
        task_map_payload: Optional[Dict[str, Any]] = None,
        detected_target_package: str = "",
    ) -> Dict[str, Any]:
        with self._lock:
            self.screen_watch = wireframe_payload
            if task_map_payload is not None:
                self.task_map = task_map_payload
            if detected_target_package and detected_target_package != "com.termux":
                self.active_target_package = detected_target_package
                t_icon, t_pkg = infer_app_icon(
                    "",
                    explicit_package=detected_target_package,
                    preserve_package=self.active_target_package,
                )
                if t_icon != "spark":
                    self.icon = t_icon
                self.app_package = t_pkg or detected_target_package
            return self.to_payload_locked()

    def mark_done(self, summary: str = "Completed") -> Dict[str, Any]:
        with self._lock:
            self.state = "DONE"
            self.current_action = summary[:80]
            self.next_action = ""
            self.question = ""
            if summary and not self.detailed_output:
                self.detailed_output = summary[:2400]
            self._merge_result_items_locked(extract_media_items_from_text(summary))
            self._append_log_locked(f"Completed: {summary[:140]}")
            self.screen_watch["active"] = False
            self.screen_watch.pop("actionVector", None)
            was_live_pane = self.task_map.get("mode") in ("app_pane", "chess", "media", "telemetry")
            if self.task_map.get("mode") == "player" and self.task_map.get("persistOnDone", True):
                self.task_map["active"] = True
                self.task_map.setdefault("persistOnDone", True)
            elif self.task_map.get("mode") == "diagram" and self.task_map.get("persistOnDone", True):
                # Refresh diagram from final tasks/output if it came from tasks
                for t in self.tasks:
                    if t["status"] in ("doing", "pending"):
                        t["status"] = "done"
                extracted = extract_diagram_from_text(self.detailed_output, title=self.title)
                if extracted is not None:
                    self.task_map = build_diagram_task_map(extracted, title=self.title, persist_on_done=True)
                elif len(self.tasks) >= 2:
                    diag = build_diagram_from_tasks(self.tasks, title=self.title)
                    if diag is not None:
                        self.task_map = build_diagram_task_map(diag, title=self.title, persist_on_done=True)
                else:
                    self.task_map["active"] = True
            elif was_live_pane and not self.collected_result_items and extract_diagram_from_text(self.detailed_output) is None:
                self.task_map["active"] = False
            else:
                self.task_map = build_visual_left_window_task_map(
                    query=self.prompt_text or self.title,
                    items=self.collected_result_items,
                    detailed_output=self.detailed_output,
                    tasks=self.tasks,
                    persist_on_done=True,
                )
            for t in self.tasks:
                if t["status"] in ("doing", "pending"):
                    t["status"] = "done"
            return self.to_payload_locked()

    def mark_paused(self) -> Dict[str, Any]:
        with self._lock:
            if self.state == "WORKING":
                self.state = "PAUSED"
                self._append_log_locked("Paused by user")
                self.screen_watch["active"] = False
                if self.task_map.get("mode") != "player":
                    self.task_map["active"] = False
            return self.to_payload_locked()

    def mark_resumed(self) -> Dict[str, Any]:
        with self._lock:
            if self.state == "PAUSED":
                self.state = "WORKING"
                self._append_log_locked("Resumed by user")
            return self.to_payload_locked()

    def mark_stopped(self, force: bool = False) -> Dict[str, Any]:
        with self._lock:
            self.state = "STOPPED"
            self.current_action = "Force-stopped by user" if force else "Stopped by user"
            self.next_action = ""
            self.question = ""
            self._append_log_locked(self.current_action)
            self.screen_watch["active"] = False
            self.screen_watch.pop("actionVector", None)
            if self.task_map.get("mode") != "player":
                self.task_map["active"] = False
            for t in self.tasks:
                if t["status"] == "doing":
                    t["status"] = "stopped"
            return self.to_payload_locked()

    def to_payload(self) -> Dict[str, Any]:
        with self._lock:
            return self.to_payload_locked()

    def to_payload_locked(self) -> Dict[str, Any]:
        resolved_actions = list(self.quick_actions) if self.quick_actions else self._default_quick_actions_locked()
        payload: Dict[str, Any] = {
            "state": self.state,
            "title": self.title,
            "currentAction": self.current_action,
            "nextAction": self.next_action,
            "question": self.question,
            "icon": self.icon,
            "appPackage": self.app_package,
            "actionKind": self.action_kind,
            "detailedOutput": self.detailed_output,
            "outputLogs": list(self.output_logs),
            "quickActions": resolved_actions,
            "autoCollapseSeconds": self.auto_collapse_seconds,
            "tasks": list(self.tasks),
            "screenWatch": dict(self.screen_watch),
            "taskMap": dict(self.task_map),
        }
        return payload

    @staticmethod
    def _normalize_task_status(raw: str) -> str:
        if raw in ("done", "completed", "complete", "success", "x"):
            return "done"
        if raw in ("doing", "in_progress", "active", "running", "working"):
            return "doing"
        if raw in ("needs_input", "blocked", "question", "waiting"):
            return "needs_input"
        if raw in ("stopped", "cancelled", "canceled", "aborted"):
            return "stopped"
        return "pending"

    @staticmethod
    def _is_screen_tool(tool_name: str, tool_args: Dict[str, Any]) -> bool:
        haystack = f"{tool_name} {json.dumps(tool_args, default=str)}".lower()
        return any(kw in haystack for kw in SCREEN_TOOL_KEYWORDS)

    @staticmethod
    def _extract_action_vector(tool_name: str, tool_args: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        if not isinstance(tool_args, dict):
            return None
        action_name = str(tool_args.get("action") or tool_name).upper()
        if all(k in tool_args for k in ("x1", "y1", "x2", "y2")):
            return {
                "type": "DRAG" if "DRAG" in action_name else "SWIPE",
                "x1": float(tool_args["x1"]),
                "y1": float(tool_args["y1"]),
                "x2": float(tool_args["x2"]),
                "y2": float(tool_args["y2"]),
            }
        if "x" in tool_args and "y" in tool_args:
            return {
                "type": "TAP",
                "x1": float(tool_args["x"]),
                "y1": float(tool_args["y"]),
                "x2": float(tool_args["x"]),
                "y2": float(tool_args["y"]),
            }
        return None


class AgySessionRunner:
    """
    Manages the Termux `agy` CLI process with sticky conversation ID reuse
    (`~/.agy_hud_conversation_id`), `-p= --input-format stream-json --output-format stream-json
    --dangerously-skip-permissions`, `cwd=~`, `BRIDGE_RUNTIME_PREFIX`, and `--continue` fallback.
    """

    def __init__(
        self,
        agy_bin: str,
        mode: str,
        on_event,
        on_turn_finished,
        new_conversation: bool = False,
        conversation_id_file: str = CONVERSATION_ID_PATH,
    ) -> None:
        self.agy_bin = agy_bin
        self.requested_mode = mode  # auto | stream | continue
        self.conversation_id_file = conversation_id_file
        if new_conversation:
            clear_conversation_id(self.conversation_id_file)
            self.conversation_id = ""
        else:
            self.conversation_id = load_conversation_id(self.conversation_id_file)

        self.resolved_mode = self._detect_mode()
        self.on_event = on_event
        self.on_turn_finished = on_turn_finished

        self._proc: Optional[subprocess.Popen] = None
        self._proc_lock = threading.Lock()
        self._has_started_conversation = bool(self.conversation_id)
        self._stream_reader_thread: Optional[threading.Thread] = None

    def _detect_mode(self) -> str:
        if self.requested_mode in ("stream", "continue"):
            return self.requested_mode
        try:
            res = subprocess.run(
                [self.agy_bin, "--help"],
                capture_output=True,
                text=True,
                timeout=3.0,
                check=False,
            )
            help_text = (res.stdout or "") + "\n" + (res.stderr or "")
            if "--input-format" in help_text and "stream-json" in help_text:
                return "stream"
        except Exception:
            pass
        return "continue"

    @staticmethod
    def format_prompt_for_agy(prompt_text: str) -> str:
        stripped = (prompt_text or "").strip()
        if not stripped:
            return ""
        if "127.0.0.1:8080" in stripped or ".aura_token" in stripped:
            return stripped
        return f"{BRIDGE_RUNTIME_PREFIX}{stripped}"

    def build_stream_command(self) -> List[str]:
        cmd = [
            self.agy_bin,
            "-p=",
            "--input-format",
            "stream-json",
            "--output-format",
            "stream-json",
            "--dangerously-skip-permissions",
        ]
        if self.conversation_id:
            cmd.extend(["--conversation", self.conversation_id])
        elif self._has_started_conversation:
            cmd.append("--continue")
        return cmd

    def build_continue_command(self, formatted_prompt: str) -> List[str]:
        cmd = [self.agy_bin, "--dangerously-skip-permissions"]
        if self.conversation_id:
            cmd.extend(["--conversation", self.conversation_id])
        elif self._has_started_conversation:
            cmd.append("--continue")
        cmd.append(formatted_prompt)
        return cmd

    @staticmethod
    def build_stream_stdin_envelope(formatted_prompt: str) -> Dict[str, Any]:
        return {
            "event": "user",
            "type": "user",
            "content": formatted_prompt,
            "message": {
                "role": "user",
                "content": formatted_prompt,
            },
        }

    def _capture_conversation_id(self, evt: Dict[str, Any]) -> None:
        cid = extract_conversation_id(evt)
        if cid and cid != self.conversation_id:
            self.conversation_id = cid
            self._has_started_conversation = True
            save_conversation_id(cid, self.conversation_id_file)

    def send_prompt(self, prompt_text: str) -> None:
        formatted = self.format_prompt_for_agy(prompt_text)
        if self.resolved_mode == "stream":
            if self._send_prompt_stream_json(formatted):
                return
            self.resolved_mode = "continue"
        self._run_prompt_continue(formatted)

    def stop_active(self, force: bool = False) -> None:
        with self._proc_lock:
            proc = self._proc
        if proc is not None and proc.poll() is None:
            try:
                if force:
                    proc.kill()
                    return
                if hasattr(signal, "SIGCONT"):
                    try:
                        proc.send_signal(signal.SIGCONT)
                    except Exception:
                        pass
                proc.send_signal(signal.SIGINT)
                try:
                    proc.wait(timeout=1.5)
                except subprocess.TimeoutExpired:
                    proc.terminate()
            except Exception:
                pass

    def pause_active(self) -> None:
        with self._proc_lock:
            proc = self._proc
        if proc is not None and proc.poll() is None and hasattr(signal, "SIGSTOP"):
            try:
                proc.send_signal(signal.SIGSTOP)
            except Exception:
                pass

    def resume_active(self) -> None:
        with self._proc_lock:
            proc = self._proc
        if proc is not None and proc.poll() is None and hasattr(signal, "SIGCONT"):
            try:
                proc.send_signal(signal.SIGCONT)
            except Exception:
                pass

    def _ensure_stream_process(self) -> Optional[subprocess.Popen]:
        with self._proc_lock:
            if self._proc is not None and self._proc.poll() is None:
                return self._proc
            try:
                proc = subprocess.Popen(
                    self.build_stream_command(),
                    stdin=subprocess.PIPE,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT,
                    cwd=os.path.expanduser("~"),
                    text=True,
                    bufsize=1,
                )
                self._proc = proc
                self._stream_reader_thread = threading.Thread(
                    target=self._read_stream_stdout,
                    args=(proc,),
                    name="agy-stream-stdout",
                    daemon=True,
                )
                self._stream_reader_thread.start()
                return proc
            except Exception:
                return None

    def _send_prompt_stream_json(self, formatted_prompt: str) -> bool:
        proc = self._ensure_stream_process()
        if proc is None or proc.stdin is None:
            return False
        try:
            msg = json.dumps(self.build_stream_stdin_envelope(formatted_prompt))
            proc.stdin.write(msg + "\n")
            proc.stdin.flush()
            self._has_started_conversation = True
            return True
        except Exception:
            return False

    def _read_stream_stdout(self, proc: subprocess.Popen) -> None:
        assert proc.stdout is not None
        for raw_line in proc.stdout:
            line = raw_line.strip()
            if not line:
                continue
            evt = self._parse_output_line(line)
            self._capture_conversation_id(evt)
            self.on_event(evt)
        self.on_turn_finished("Stream session closed")

    def _run_prompt_continue(self, formatted_prompt: str) -> None:
        cmd = self.build_continue_command(formatted_prompt)
        try:
            proc = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                cwd=os.path.expanduser("~"),
                text=True,
                bufsize=1,
            )
        except FileNotFoundError:
            self.on_event(
                {
                    "type": "done",
                    "summary": f"'{self.agy_bin}' binary not found in PATH",
                }
            )
            self.on_turn_finished(f"'{self.agy_bin}' not found")
            return
        except Exception as e:
            self.on_event({"type": "done", "summary": f"Launch error: {e}"})
            self.on_turn_finished(str(e))
            return

        with self._proc_lock:
            self._proc = proc
        self._has_started_conversation = True

        last_line = "Task completed"
        assert proc.stdout is not None
        for raw_line in proc.stdout:
            line = raw_line.strip()
            if not line:
                continue
            last_line = line
            evt = self._parse_output_line(line)
            self._capture_conversation_id(evt)
            self.on_event(evt)
        proc.wait()
        self.on_turn_finished(last_line[:80])

    @staticmethod
    def _parse_output_line(line: str) -> Dict[str, Any]:
        if line.startswith("{") and line.endswith("}"):
            try:
                parsed = json.loads(line)
                if isinstance(parsed, dict):
                    return parsed
            except Exception:
                pass
        return {"type": "status", "text": line}


class AgyHudDaemon:
    """Orchestrates WS + poll command intake, AgySessionRunner, and throttled TaskMap sampling."""

    def __init__(
        self,
        base_url: str,
        token: str,
        agy_bin: str = "agy",
        mode: str = "auto",
        poll_interval: float = 0.75,
        auto_collapse_seconds: int = 4,
        new_conversation: bool = False,
        safe_guard: bool = False,
    ) -> None:
        self.client = KavachHudClient(base_url, token)
        self.tracker = HudStateTracker(auto_collapse_seconds=auto_collapse_seconds)
        self.poll_interval = poll_interval
        self.safe_guard = bool(safe_guard)
        self.stop_event = threading.Event()
        self.command_queue: "queue.Queue[Dict[str, Any]]" = queue.Queue()
        self._seen_cmd_ids: List[str] = []
        self._seen_lock = threading.Lock()
        self._approval_lock = threading.Lock()
        self._pending_approvals: Dict[str, Tuple[threading.Event, Dict[str, Any]]] = {}
        self._screen_watch_active = False
        self._last_hud_push_ts = 0.0

        self.runner = AgySessionRunner(
            agy_bin=agy_bin,
            mode=mode,
            on_event=self._handle_agy_event,
            on_turn_finished=self._handle_turn_finished,
            new_conversation=new_conversation,
        )
        self.ws_listener = StdlibWebSocketListener(
            base_http_url=base_url,
            token=token,
            on_message=self._handle_ws_message,
            stop_event=self.stop_event,
        )

    def _enqueue_unique_command(self, cmd: Dict[str, Any]) -> bool:
        if cmd.get("type") != "HUD_COMMAND":
            return False
        cmd_id = str(cmd.get("id") or f"{cmd.get('timestamp')}:{cmd.get('action')}:{cmd.get('text')}")
        with self._seen_lock:
            if cmd_id in self._seen_cmd_ids:
                return False
            self._seen_cmd_ids.append(cmd_id)
            if len(self._seen_cmd_ids) > 256:
                self._seen_cmd_ids = self._seen_cmd_ids[-128:]

        action = str(cmd.get("action") or "PROMPT").upper()
        # Handle control commands and approval responses immediately without blocking behind a turn
        if action == "APPROVAL_RESPONSE":
            self._resolve_approval_response(cmd)
            return True
        if action in ("STOP", "FORCE_STOP", "PAUSE", "RESUME"):
            self._handle_control_command(action)
            return True

        self.command_queue.put(cmd)
        return True

    def _resolve_approval_response(self, cmd: Dict[str, Any]) -> bool:
        payload = cmd.get("payload") if isinstance(cmd.get("payload"), dict) else {}
        approval_id = str(payload.get("approvalId") or cmd.get("buttonId") or "").strip()
        decision = str(payload.get("decision") or "deny").lower().strip()
        edited_text = str(payload.get("editedCommand") or payload.get("editedText") or "").strip()
        with self._approval_lock:
            entry = self._pending_approvals.get(approval_id)
            if entry is None and len(self._pending_approvals) == 1:
                only_id = next(iter(self._pending_approvals.keys()))
                approval_id = only_id
                entry = self._pending_approvals.get(only_id)
            if entry is None:
                return False
            evt, result_box = entry
            result_box["approvalId"] = approval_id
            result_box["decision"] = decision if decision in ("approve", "edit", "deny") else "deny"
            if edited_text:
                result_box["editedText"] = edited_text
            evt.set()
            return True

    def request_approval(
        self,
        title: str,
        description: str = "",
        command_preview: str = "",
        risk_level: str = "medium",
        allow_edit: bool = True,
        timeout_seconds: float = 30.0,
        approval_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Blocks until the user taps Approve / Edit / Deny in the Android HUD, defaulting safely to deny on timeout."""
        aid = (approval_id or f"apr_{uuid.uuid4().hex[:8]}").strip()
        evt = threading.Event()
        result_box: Dict[str, Any] = {"approvalId": aid, "decision": "deny", "timedOut": False}
        with self._approval_lock:
            self._pending_approvals[aid] = (evt, result_box)

        try:
            self.client.push_approval(
                approval_id=aid,
                title=title,
                description=description,
                command_preview=command_preview,
                risk_level=risk_level,
                allow_edit=allow_edit,
                editable_text=command_preview,
                timeout_seconds=max(0, int(round(timeout_seconds))),
            )
            waited = evt.wait(timeout=max(0.05, float(timeout_seconds)))
            if not waited:
                result_box["decision"] = "deny"
                result_box["timedOut"] = True
                self.client.clear_approval()
            return dict(result_box)
        finally:
            with self._approval_lock:
                self._pending_approvals.pop(aid, None)

    def _cancel_all_pending_approvals(self) -> None:
        with self._approval_lock:
            for aid, (evt, box) in list(self._pending_approvals.items()):
                box["approvalId"] = aid
                box["decision"] = "deny"
                box["cancelled"] = True
                evt.set()
            self._pending_approvals.clear()

    def _handle_control_command(self, action: str) -> None:
        if action in ("STOP", "FORCE_STOP"):
            force = action == "FORCE_STOP"
            self._cancel_all_pending_approvals()
            self.runner.stop_active(force=force)
            self._screen_watch_active = False
            self.client.push_hud_state(self.tracker.mark_stopped(force=force))
        elif action == "PAUSE":
            self.runner.pause_active()
            self._screen_watch_active = False
            self.client.push_hud_state(self.tracker.mark_paused())
        elif action == "RESUME":
            self.runner.resume_active()
            self.client.push_hud_state(self.tracker.mark_resumed())

    def _handle_ws_message(self, msg: Dict[str, Any]) -> None:
        self._enqueue_unique_command(msg)

    def _handle_agy_event(self, evt: Dict[str, Any]) -> None:
        payload, sw_active = self.tracker.apply_agy_event(evt)
        self._screen_watch_active = sw_active
        self.client.push_hud_state(payload)
        self._last_hud_push_ts = time.time()

    def _handle_turn_finished(self, summary: str) -> None:
        self._screen_watch_active = False
        if self.tracker.state not in ("DONE", "IDLE", "STOPPED"):
            payload = self.tracker.mark_done(summary)
            self.client.push_hud_state(payload)

    def _poll_loop(self) -> None:
        while not self.stop_event.is_set():
            wait_s = self.poll_interval * 2.5 if self.ws_listener.connected else self.poll_interval
            res = self.client.poll_hud_commands()
            if res.get("success") and isinstance(res.get("commands"), list):
                for cmd in res["commands"]:
                    if isinstance(cmd, dict):
                        self._enqueue_unique_command(cmd)
            self.stop_event.wait(wait_s)

    def _screen_watch_loop(self) -> None:
        """Throttled /api/ui/tree sampler active ONLY while screenWatch/taskMap mode is enabled."""
        while not self.stop_event.is_set():
            if self._screen_watch_active:
                tree_res = self.client.fetch_ui_tree()
                if tree_res.get("success", True) and (
                    tree_res.get("tree") or tree_res.get("nodes") or tree_res.get("uiTree")
                ):
                    current_vec = self.tracker.screen_watch.get("actionVector")
                    label = self.tracker.screen_watch.get("label") or "Screen Watch"
                    task_map, wf, detected_pkg = build_task_map_from_ui_tree(
                        tree_res,
                        action_vector=current_vec,
                        label=label,
                        title_hint=self.tracker.title,
                    )
                    payload = self.tracker.update_wireframe(
                        wf,
                        task_map_payload=task_map,
                        detected_target_package=detected_pkg,
                    )
                    self.client.push_hud_state(payload)
            self.stop_event.wait(1.2)

    def _worker_loop(self) -> None:
        while not self.stop_event.is_set():
            try:
                cmd = self.command_queue.get(timeout=0.5)
            except queue.Empty:
                continue
            action = str(cmd.get("action") or "PROMPT").upper()
            text = str(cmd.get("text") or "").strip()
            cmd_payload = cmd.get("payload") if isinstance(cmd.get("payload"), dict) else None
            if action in ("STOP", "FORCE_STOP", "PAUSE", "RESUME"):
                self._handle_control_command(action)
            elif text or action in ("DEMO_RECORDED", "WATCHDOG_TRIGGERED"):
                enriched = format_region_context_for_prompt(text, cmd_payload, action=action)
                display_prompt = text or enriched.splitlines()[0][:80] or action
                if self.safe_guard and display_prompt:
                    risk = detect_sensitive_prompt_risk(display_prompt)
                    if risk is not None:
                        decision_res = self.request_approval(
                            title=risk["title"],
                            description=risk["description"],
                            command_preview=risk["commandPreview"],
                            risk_level=risk["riskLevel"],
                            allow_edit=True,
                            timeout_seconds=30.0,
                        )
                        dec = decision_res.get("decision", "deny")
                        if dec == "deny":
                            self.client.push_hud_state(self.tracker.mark_stopped(force=False))
                            continue
                        if dec == "edit" and decision_res.get("editedText"):
                            display_prompt = str(decision_res["editedText"]).strip()
                            enriched = format_region_context_for_prompt(display_prompt, cmd_payload, action=action)
                if enriched:
                    payload = self.tracker.begin_prompt(display_prompt)
                    self.client.push_hud_state(payload)
                    self.runner.send_prompt(enriched)

    def run(self) -> None:
        conv_msg = self.runner.conversation_id or "(new)"
        print(
            f"[AgyHudDaemon] Connected target={self.client.base_url} | agy_mode={self.runner.resolved_mode} | conv={conv_msg}",
            flush=True,
        )
        self.client.push_hud_state(self.tracker.to_payload())

        self.ws_listener.start()
        poll_thread = threading.Thread(target=self._poll_loop, name="agy-hud-poll", daemon=True)
        screen_thread = threading.Thread(target=self._screen_watch_loop, name="agy-screen-watch", daemon=True)
        worker_thread = threading.Thread(target=self._worker_loop, name="agy-worker", daemon=True)
        poll_thread.start()
        screen_thread.start()
        worker_thread.start()

        try:
            while not self.stop_event.is_set():
                time.sleep(0.5)
        except KeyboardInterrupt:
            print("\n[AgyHudDaemon] Shutting down HUD...", flush=True)
        finally:
            self.stop_event.set()
            self.ws_listener.stop()
            self.runner.stop_active()
            self.client.hide_hud()


def run_self_test() -> int:
    """
    Runs a complete local mock HTTP + RFC 6455 WebSocket integration test verifying Single-Window HUD v2:
    - Bearer auth + 5 v2 endpoints: /api/hud/state, /api/hud/patch, /api/hud/approval, /api/hud/poll, /api/hud/hide
      (plus /api/hud/reset & independent /api/hud/pointer)
    - Weighted infer_app_icon & infer_action_kind
    - Chess 8x8 FEN reconstruction & YouTube media card extraction
    - Region Snip enrichment (v2 'snip' and legacy 'regionContext'), Approval Gate blocking handshake, & WS HUD_COMMAND
    """
    from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

    # 1. Pure function assertions: Weighted icon & action_kind resolution
    assert infer_app_icon("Write a python script to play chess") == ("chess", "com.chess"), (
        f"Unexpected chess icon match: {infer_app_icon('Write a python script to play chess')}"
    )
    assert infer_app_icon("Open YouTube and play lo-fi video") == ("youtube", "com.google.android.youtube"), (
        f"Unexpected youtube icon match: {infer_app_icon('Open YouTube and play lo-fi video')}"
    )
    assert infer_app_icon("Run bash python daemon in Termux", preserve_package="com.chess")[1] == "com.chess", (
        "Termux must never overwrite active non-Termux target package"
    )
    assert infer_action_kind("Running ui_tree inspect") == "watching"
    assert infer_action_kind("Typing Hello World", tool_name="input_text") == "typing"
    assert infer_action_kind("Tap Connect", tool_name="ui_action") == "tapping"
    assert infer_action_kind("Play Spotify playlist") == "playing"

    # 2. Sticky conversation ID & CLI command builder assertions
    with tempfile.TemporaryDirectory() as tmpdir:
        cid_path = os.path.join(tmpdir, ".agy_hud_conversation_id")
        save_conversation_id("conv_abc_987", cid_path)
        assert load_conversation_id(cid_path) == "conv_abc_987"
        runner = AgySessionRunner(
            agy_bin="agy",
            mode="stream",
            on_event=lambda _: None,
            on_turn_finished=lambda _: None,
            new_conversation=False,
            conversation_id_file=cid_path,
        )
        stream_cmd = runner.build_stream_command()
        assert "-p=" in stream_cmd
        assert "--input-format" in stream_cmd and "stream-json" in stream_cmd
        assert "--dangerously-skip-permissions" in stream_cmd
        assert "--conversation" in stream_cmd and "conv_abc_987" in stream_cmd
        env = runner.build_stream_stdin_envelope(runner.format_prompt_for_agy("Open Settings"))
        assert env["event"] == "user" and env["type"] == "user"
        assert BRIDGE_RUNTIME_PREFIX.strip() in env["content"]
        clear_conversation_id(cid_path)
        assert load_conversation_id(cid_path) == ""

    # 3. Chess FEN extraction self-test
    chess_tree = {
        "display": {"width": 1080, "height": 2400, "rotation": 0, "orientation": "portrait"},
        "windows": [{"id": 1, "packageName": "com.chess", "bounds": "[0,0][1080,2400]", "isFocused": True}],
        "tree": {
            "className": "android.widget.FrameLayout",
            "packageName": "com.chess",
            "bounds": "[0,0][1080,2400]",
            "children": [
                {"packageName": "com.chess", "contentDescription": "Black King on e8", "bounds": "[500,300][620,420]"},
                {"packageName": "com.chess", "contentDescription": "White King on e1", "bounds": "[500,1500][620,1620]"},
                {"packageName": "com.chess", "contentDescription": "White Pawn on e4", "bounds": "[500,980][620,1100]"},
                {"packageName": "com.chess", "text": "+1.4", "bounds": "[40,280][120,340]"},
                {"packageName": "com.chess", "text": "White to move", "bounds": "[200,180][600,240]"},
            ],
        },
    }
    chess_tm, _, chess_pkg = build_task_map_from_ui_tree(chess_tree)
    assert chess_tm["mode"] == "chess" and chess_tm["active"] is True
    assert chess_tm["chess"]["playerColor"] == "white"
    assert chess_tm["chess"]["evalCp"] == "+1.4"
    assert "4k3/8/8/8/4P3/8/8/4K3" == chess_tm["chess"]["fen"]
    assert chess_pkg == "com.chess"

    # 4. Media extraction self-test
    yt_tree = {
        "display": {"width": 1080, "height": 2400, "rotation": 0, "orientation": "portrait"},
        "windows": [{"id": 2, "packageName": "com.google.android.youtube", "bounds": "[0,0][1080,2400]", "isFocused": True}],
        "tree": {
            "className": "android.widget.FrameLayout",
            "packageName": "com.google.android.youtube",
            "bounds": "[0,0][1080,2400]",
            "children": [
                {"packageName": "com.google.android.youtube", "viewId": "com.google.android.youtube:id/video_title", "text": "Lofi Hip Hop Radio - Beats to Study", "bounds": "[40,700][1040,800]"},
                {"packageName": "com.google.android.youtube", "viewId": "com.google.android.youtube:id/channel_name", "text": "Lofi Girl", "bounds": "[40,810][500,870]"},
                {"packageName": "com.google.android.youtube", "contentDescription": "Pause video", "bounds": "[490,340][590,440]"},
                {"packageName": "com.google.android.youtube", "text": "1:30", "bounds": "[40,620][140,670]"},
                {"packageName": "com.google.android.youtube", "text": "3:00", "bounds": "[920,620][1040,670]"},
            ],
        },
    }
    yt_tm, _, _ = build_task_map_from_ui_tree(yt_tree)
    assert yt_tm["mode"] == "media"
    assert yt_tm["media"]["provider"] == "youtube"
    assert yt_tm["media"]["playing"] is True
    assert abs(yt_tm["media"]["progressPercent"] - 50.0) < 0.2

    # 5. HTTP + WebSocket Single-Window HUD v2 integration self-test
    state_history: List[Dict[str, Any]] = []
    patch_history: List[Dict[str, Any]] = []
    pointer_history: List[Dict[str, Any]] = []
    approval_history: List[Dict[str, Any]] = []
    poll_queue: List[Dict[str, Any]] = []
    ws_clients: List[socket.socket] = []
    test_token = "aura_test_token_12345"

    def _broadcast_ws_cmd(cmd: Dict[str, Any]) -> None:
        poll_queue.append(cmd)
        raw_frame = json.dumps(cmd).encode("utf-8")
        hdr = bytearray([0x81])
        if len(raw_frame) <= 125:
            hdr.append(len(raw_frame))
        else:
            hdr.append(126)
            hdr.extend(struct.pack("!H", len(raw_frame)))
        for sock in list(ws_clients):
            try:
                sock.sendall(bytes(hdr) + raw_frame)
            except Exception:
                pass

    class MockKavachV2Handler(BaseHTTPRequestHandler):
        def log_message(self, format: str, *args: Any) -> None:
            return

        def _send_json(self, code: int, obj: Dict[str, Any]) -> None:
            raw = json.dumps(obj).encode("utf-8")
            self.send_response(code)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(raw)))
            self.end_headers()
            self.wfile.write(raw)

        def _check_auth(self) -> bool:
            auth = self.headers.get("Authorization", "")
            parsed = urllib.parse.urlparse(self.path)
            q_tok = urllib.parse.parse_qs(parsed.query).get("token", [""])[0]
            return auth == f"Bearer {test_token}" or q_tok == test_token

        def do_GET(self) -> None:
            if not self._check_auth():
                self._send_json(401, {"success": False, "error": "UNAUTHORIZED_DEVICE"})
                return
            path = urllib.parse.urlparse(self.path).path
            if path == "/ws" and self.headers.get("Upgrade", "").lower() == "websocket":
                key = self.headers.get("Sec-WebSocket-Key", "").strip()
                accept = base64.b64encode(
                    hashlib.sha1((key + "258EAFA5-E914-47DA-95CA-C5AB0DC85B11").encode("utf-8")).digest()
                ).decode("ascii")
                resp = (
                    "HTTP/1.1 101 Switching Protocols\r\n"
                    "Upgrade: websocket\r\n"
                    "Connection: Upgrade\r\n"
                    f"Sec-WebSocket-Accept: {accept}\r\n\r\n"
                ).encode("utf-8")
                self.connection.sendall(resp)
                ws_clients.append(self.connection)
                try:
                    self.connection.settimeout(3.0)
                    self.connection.recv(1024)
                except Exception:
                    pass
                return
            elif path == "/api/hud/poll":
                drained = list(poll_queue)
                poll_queue.clear()
                self._send_json(200, {"success": True, "count": len(drained), "commands": drained})
            elif path == "/api/ui/tree":
                self._send_json(
                    200,
                    {
                        "success": True,
                        "display": {"width": 2400, "height": 1080, "rotation": 90, "orientation": "landscape"},
                        "splitScreen": {
                            "active": True,
                            "axis": "horizontal",
                            "targetPackage": "com.android.settings",
                            "paneBounds": {"x1": 1200, "y1": 0, "x2": 2400, "y2": 1080},
                        },
                        "windows": [
                            {"id": 10, "packageName": "com.termux", "bounds": "[0,0][1190,1080]", "isFocused": False},
                            {"id": 11, "packageName": "com.android.settings", "bounds": "[1200,0][2400,1080]", "isFocused": True},
                        ],
                        "tree": {
                            "className": "android.widget.FrameLayout",
                            "bounds": "[0,0][2400,1080]",
                            "children": [
                                {
                                    "packageName": "com.termux",
                                    "className": "android.widget.Button",
                                    "text": "TermuxShell",
                                    "isClickable": True,
                                    "bounds": "[40,120][400,220]",
                                },
                                {
                                    "viewId": "com.example:id/agy_hud_window",
                                    "contentDescription": "agy_hud_window",
                                    "text": "Should Be Filtered",
                                    "isClickable": True,
                                    "bounds": "[1250,200][1600,600]",
                                },
                                {
                                    "packageName": "com.android.settings",
                                    "viewId": "com.android.settings:id/search_action_bar",
                                    "className": "android.widget.EditText",
                                    "text": "Search settings",
                                    "isEditable": True,
                                    "bounds": "[1240,80][2340,180]",
                                },
                                {
                                    "packageName": "com.android.settings",
                                    "className": "android.widget.Switch",
                                    "text": "Wi-Fi",
                                    "isCheckable": True,
                                    "isChecked": True,
                                    "bounds": "[1240,240][2340,340]",
                                },
                                {
                                    "packageName": "com.android.settings",
                                    "className": "android.widget.Button",
                                    "text": "Connect",
                                    "isClickable": True,
                                    "bounds": "[1900,420][2300,520]",
                                },
                            ],
                        },
                    },
                )
            else:
                self._send_json(404, {"success": False})

        def do_POST(self) -> None:
            if not self._check_auth():
                self._send_json(401, {"success": False, "error": "UNAUTHORIZED_DEVICE"})
                return
            length = int(self.headers.get("Content-Length", "0"))
            body = json.loads(self.rfile.read(length).decode("utf-8") or "{}")
            path = urllib.parse.urlparse(self.path).path
            if path == "/api/hud/state":
                state_history.append(body)
                self._send_json(200, {"success": True, "state": body.get("state")})
            elif path == "/api/hud/patch":
                patch_history.append(body)
                self._send_json(200, {"success": True, "patched": True})
            elif path == "/api/hud/approval":
                approval_history.append(body)
                self._send_json(200, {"success": True, "approvalActive": bool(body.get("active", False) and not body.get("clear", False))})
            elif path == "/api/hud/hide":
                self._send_json(200, {"success": True, "visible": False})
            elif path == "/api/hud/reset":
                state_history.append({"state": "IDLE", "reset": True})
                self._send_json(200, {"success": True, "state": "IDLE"})
            elif path == "/api/hud/pointer":
                pointer_history.append(body)
                self._send_json(200, {"success": True, **body})
            else:
                self._send_json(404, {"success": False})

    server = ThreadingHTTPServer(("127.0.0.1", 0), MockKavachV2Handler)
    port = server.server_address[1]
    srv_thread = threading.Thread(target=server.serve_forever, daemon=True)
    srv_thread.start()

    base_url = f"http://127.0.0.1:{port}"
    client = KavachHudClient(base_url, test_token)
    tracker = HudStateTracker(auto_collapse_seconds=4)

    received_ws: List[Dict[str, Any]] = []
    stop_evt = threading.Event()
    ws = StdlibWebSocketListener(base_url, test_token, received_ws.append, stop_evt)
    ws.start()
    time.sleep(0.25)
    assert ws.connected, "WebSocket failed to connect to mock KaVach v2 server"

    _broadcast_ws_cmd({
        "id": "cmd_ws_1",
        "type": "HUD_COMMAND",
        "action": "PROMPT",
        "text": "Open Wi-Fi settings",
        "timestamp": int(time.time() * 1000),
    })
    time.sleep(0.2)
    assert len(received_ws) == 1 and received_ws[0]["text"] == "Open Wi-Fi settings"

    poll_res = client.poll_hud_commands()
    assert poll_res.get("success") is True and poll_res.get("count") == 1

    ptr_res = client.set_pointer_config(enabled=True, show_label=False)
    assert ptr_res.get("success") is True and pointer_history[-1]["showLabel"] is False

    client.push_hud_state(tracker.begin_prompt("Open Wi-Fi settings"))
    patch_res = client.patch_hud_state({"appendLog": "Inspecting settings pane", "progress": 0.5, "currentAction": "Checking Wi-Fi"})
    assert patch_res.get("success") is True and len(patch_history) == 1

    payload, sw_active = tracker.apply_agy_event(
        {
            "type": "step_update",
            "steps": [
                {"id": "s1", "label": "Inspect screen", "status": "done"},
                {"id": "s2", "label": "Tap Connect button", "status": "doing"},
                {"id": "s3", "label": "Verify status", "status": "pending"},
            ],
        }
    )
    assert payload["tasks"][0]["status"] == "done"
    assert payload["tasks"][1]["status"] == "doing"
    assert payload["actionKind"] == "tapping"
    assert not sw_active
    client.push_hud_state(payload)

    tree = client.fetch_ui_tree()
    task_map, wf, target_pkg = build_task_map_from_ui_tree(tree)
    assert target_pkg == "com.android.settings"
    zones = task_map["appPane"]["zones"]
    assert all("Should Be Filtered" not in z["tag"] for z in zones), "HUD v2 node leaked!"
    assert all("TermuxShell" not in z["tag"] for z in zones), "Termux node leaked!"

    # Media Carousel via /api/hud/state + /api/hud/patch (no legacy /api/hud/player)
    media_state_res = client.push_hud_state(
        {
            "state": "DONE",
            "title": "Media Carousel",
            "thinkingText": "Showing 2 items",
            "mediaItems": [
                {"id": "m1", "kind": "image", "title": "Screenshot", "uri": "https://example.org/shot.jpg"},
                {"id": "m2", "kind": "audio", "title": "Lofi Mix", "subtitle": "Agy Radio", "uri": "https://example.org/lofi.mp3"},
            ],
            "mediaPlaying": True,
            "mediaMuted": False,
        }
    )
    assert media_state_res.get("success") is True
    media_patch_res = client.patch_hud_state({"mediaPlaying": False, "mediaMuted": True})
    assert media_patch_res.get("success") is True

    # 6. Region Snip enrichment (both v2 'snip' and legacy 'regionContext')
    snip_v2_enriched = format_region_context_for_prompt(
        "Explain this button",
        {
            "snip": {
                "x1": 120,
                "y1": 300,
                "x2": 520,
                "y2": 460,
                "screenWidth": 1080,
                "screenHeight": 2400,
                "packageName": "com.android.settings",
                "nodes": [
                    {"text": "Battery Saver", "centerX": 320, "centerY": 380, "clickable": True}
                ],
            }
        },
    )
    assert "[Snipped Screen Region: [120,300]-[520,460]" in snip_v2_enriched
    assert "Battery Saver" in snip_v2_enriched and "@(320,380)" in snip_v2_enriched

    assert detect_sensitive_prompt_risk("rm -rf /sdcard/tmp")["riskLevel"] == "high"
    assert detect_sensitive_prompt_risk("Send WhatsApp message to Alex")["riskLevel"] == "medium"
    assert detect_sensitive_prompt_risk("What is the weather today?") is None

    # 7. Approval Gate blocking handshake: approve, edit (editedCommand), and timeout -> safe auto-deny
    daemon_test = AgyHudDaemon(base_url=base_url, token=test_token, safe_guard=True)

    def _approve_async():
        time.sleep(0.08)
        daemon_test._enqueue_unique_command(
            {
                "id": "cmd_apr_ok",
                "type": "HUD_COMMAND",
                "action": "APPROVAL_RESPONSE",
                "buttonId": "apr_test_1",
                "payload": {"approvalId": "apr_test_1", "decision": "APPROVE"},
            }
        )

    t_apr = threading.Thread(target=_approve_async, daemon=True)
    t_apr.start()
    apr_out = daemon_test.request_approval(
        title="Confirm Shell Command",
        command_preview="rm -rf /tmp/cache",
        risk_level="high",
        timeout_seconds=2.0,
        approval_id="apr_test_1",
    )
    t_apr.join(timeout=1.0)
    assert apr_out["decision"] == "approve" and apr_out["approvalId"] == "apr_test_1"

    def _edit_async():
        time.sleep(0.08)
        daemon_test._enqueue_unique_command(
            {
                "id": "cmd_apr_edit",
                "type": "HUD_COMMAND",
                "action": "APPROVAL_RESPONSE",
                "buttonId": "apr_test_2",
                "payload": {"approvalId": "apr_test_2", "decision": "EDIT", "editedCommand": "ls -la /tmp/cache"},
            }
        )

    t_edit = threading.Thread(target=_edit_async, daemon=True)
    t_edit.start()
    edit_out = daemon_test.request_approval(
        title="Confirm Shell Command",
        command_preview="rm -rf /tmp/cache",
        risk_level="high",
        timeout_seconds=2.0,
        approval_id="apr_test_2",
    )
    t_edit.join(timeout=1.0)
    assert edit_out["decision"] == "edit" and edit_out.get("editedText") == "ls -la /tmp/cache"

    timeout_out = daemon_test.request_approval(
        title="Auto-Deny Timeout Test",
        command_preview="factory reset",
        risk_level="high",
        timeout_seconds=0.12,
        approval_id="apr_test_timeout",
    )
    assert timeout_out["decision"] == "deny" and timeout_out.get("timedOut") is True
    assert len(approval_history) >= 3

    reset_res = client.reset_hud()
    assert reset_res.get("success") is True and reset_res.get("state") == "IDLE"

    hide_res = client.hide_hud()
    assert hide_res.get("success") is True

    stop_evt.set()
    ws.stop()
    server.shutdown()
    server.server_close()

    print(
        f"HUD V2 SELF-TEST PASSED: {len(state_history)} state pushes, {len(patch_history)} patches, "
        f"{len(approval_history)} approvals, {len(pointer_history)} pointer updates, Chess FEN + Media Carousel + Snip OK."
    )
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description="Termux-First Dual-Window Agy HUD Daemon")
    parser.add_argument("--url", default=DEFAULT_HTTP_URL, help="KaVach HTTP base URL (default: http://127.0.0.1:8080)")
    parser.add_argument("--token", default=None, help="Bearer token (defaults to ~/.aura_token)")
    parser.add_argument("--agy-bin", default="agy", help="Path or command name for agy CLI")
    parser.add_argument(
        "--mode",
        choices=("auto", "stream", "continue"),
        default="auto",
        help="Session mode: auto-detect stream-json with fallback to --continue",
    )
    parser.add_argument("--poll-interval", type=float, default=0.75, help="Fallback /api/hud/poll interval in seconds")
    parser.add_argument("--auto-collapse", type=int, default=4, help="Auto-collapse delay in seconds after DONE")
    parser.add_argument("--new", action="store_true", help="Clear saved ~/.agy_hud_conversation_id and start a fresh Agy session")
    parser.add_argument("--safe-guard", action="store_true", help="Prompt for HUD approval before high/medium-risk actions")
    parser.add_argument("--self-test", action="store_true", help="Run built-in mock HTTP/WS integration test")
    args = parser.parse_args()

    if args.self_test:
        return run_self_test()

    token = load_auth_token(args.token)
    if not token:
        print("[AgyHudDaemon] Warning: No ~/.aura_token found. Run `python send_cmd.py login` first if STRICT auth is enabled.", file=sys.stderr)

    daemon = AgyHudDaemon(
        base_url=args.url,
        token=token,
        agy_bin=args.agy_bin,
        mode=args.mode,
        poll_interval=args.poll_interval,
        auto_collapse_seconds=args.auto_collapse,
        new_conversation=args.new,
        safe_guard=args.safe_guard,
    )
    daemon.run()
    return 0


if __name__ == "__main__":
    sys.exit(main())
