package com.kavach.ui.overlay.hud

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.util.Log
import kotlin.math.sqrt

/**
 * Pure double-shake peak detector with tight inter-peak window and cooldown guard
 * to avoid single-jolt false positives.
 */
class DoubleShakeDetector(
    private val thresholdG: Float = 2.3f,
    private val minGapMs: Long = 160L,
    private val maxGapMs: Long = 680L,
    private val cooldownMs: Long = 1400L
) {
    private var firstPeakMs: Long = 0L
    private var lastTriggerMs: Long = 0L

    fun onAcceleration(ax: Float, ay: Float, az: Float, timestampMs: Long): Boolean {
        val gX = ax / SensorManager.GRAVITY_EARTH
        val gY = ay / SensorManager.GRAVITY_EARTH
        val gZ = az / SensorManager.GRAVITY_EARTH
        val gForce = sqrt(gX * gX + gY * gY + gZ * gZ)

        if (gForce < thresholdG) return false
        if (lastTriggerMs > 0L && (timestampMs - lastTriggerMs) < cooldownMs) return false

        val elapsedSinceFirst = timestampMs - firstPeakMs
        return if (firstPeakMs == 0L || elapsedSinceFirst > maxGapMs) {
            firstPeakMs = timestampMs
            false
        } else if (elapsedSinceFirst >= minGapMs) {
            firstPeakMs = 0L
            lastTriggerMs = timestampMs
            true
        } else {
            // Still inside the same physical acceleration spike; ignore.
            false
        }
    }

    fun reset() {
        firstPeakMs = 0L
    }
}

/**
 * Battery-safe, screen-awake accelerometer double-shake controller for summoning/collapsing
 * the Floating HUD hands-free.
 *
 * Automatically unregisters the accelerometer when the display turns off or when the user
 * disables Shake-to-Summon in the Dashboard.
 */
class HudShakeSummonController(
    private val context: Context,
    private val onShakeTriggered: () -> Unit
) : SensorEventListener {

    companion object {
        private const val TAG = "HudShakeSummon"
    }

    private val sensorManager: SensorManager? by lazy {
        context.getSystemService(Context.SENSOR_SERVICE) as? SensorManager
    }
    private val powerManager: PowerManager? by lazy {
        context.getSystemService(Context.POWER_SERVICE) as? PowerManager
    }
    private val detector = DoubleShakeDetector()

    @Volatile
    private var enabled: Boolean = false
    private var isSensorRegistered: Boolean = false
    private var isScreenReceiverRegistered: Boolean = false

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context?, intent: Intent?) {
            when (intent?.action) {
                Intent.ACTION_SCREEN_ON -> updateSensorRegistration()
                Intent.ACTION_SCREEN_OFF -> unregisterSensor()
            }
        }
    }

    fun setEnabled(enable: Boolean) {
        if (enabled == enable) return
        enabled = enable
        if (enable) {
            registerScreenReceiverIfNeeded()
            updateSensorRegistration()
        } else {
            unregisterSensor()
            unregisterScreenReceiverIfNeeded()
        }
    }

    fun release() {
        enabled = false
        unregisterSensor()
        unregisterScreenReceiverIfNeeded()
    }

    private fun isScreenInteractive(): Boolean {
        return try {
            powerManager?.isInteractive ?: true
        } catch (_: Throwable) {
            true
        }
    }

    private fun registerScreenReceiverIfNeeded() {
        if (isScreenReceiverRegistered) return
        try {
            val filter = IntentFilter().apply {
                addAction(Intent.ACTION_SCREEN_ON)
                addAction(Intent.ACTION_SCREEN_OFF)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                context.registerReceiver(screenReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
            } else {
                @Suppress("DEPRECATION")
                context.registerReceiver(screenReceiver, filter)
            }
            isScreenReceiverRegistered = true
        } catch (t: Throwable) {
            Log.w(TAG, "Failed registering screen receiver: ${t.message}")
        }
    }

    private fun unregisterScreenReceiverIfNeeded() {
        if (!isScreenReceiverRegistered) return
        try {
            context.unregisterReceiver(screenReceiver)
        } catch (_: Throwable) {}
        isScreenReceiverRegistered = false
    }

    private fun updateSensorRegistration() {
        if (!enabled || !isScreenInteractive()) {
            unregisterSensor()
            return
        }
        if (isSensorRegistered) return
        val sm = sensorManager ?: return
        val accel = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER) ?: return
        detector.reset()
        isSensorRegistered = try {
            sm.registerListener(this, accel, SensorManager.SENSOR_DELAY_UI)
        } catch (t: Throwable) {
            Log.w(TAG, "Failed registering accelerometer: ${t.message}")
            false
        }
    }

    private fun unregisterSensor() {
        if (!isSensorRegistered) return
        try {
            sensorManager?.unregisterListener(this)
        } catch (_: Throwable) {}
        detector.reset()
        isSensorRegistered = false
    }

    override fun onSensorChanged(event: SensorEvent?) {
        if (!enabled || event == null || event.sensor.type != Sensor.TYPE_ACCELEROMETER) return
        if (event.values.size < 3) return
        val triggered = detector.onAcceleration(
            ax = event.values[0],
            ay = event.values[1],
            az = event.values[2],
            timestampMs = System.currentTimeMillis()
        )
        if (triggered) {
            triggerHapticTick()
            onShakeTriggered()
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit

    private fun triggerHapticTick() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vm = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vm?.defaultVibrator?.vibrate(
                    VibrationEffect.createOneShot(28L, VibrationEffect.DEFAULT_AMPLITUDE)
                )
            } else {
                @Suppress("DEPRECATION")
                val v = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    v?.vibrate(VibrationEffect.createOneShot(28L, VibrationEffect.DEFAULT_AMPLITUDE))
                } else {
                    @Suppress("DEPRECATION")
                    v?.vibrate(28L)
                }
            }
        } catch (_: Throwable) {}
    }
}
