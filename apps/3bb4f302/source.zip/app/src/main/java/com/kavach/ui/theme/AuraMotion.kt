package com.kavach.ui.theme

import android.provider.Settings
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.Easing
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.interaction.InteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.delay

/**
 * Centralized Liquid Glass Motion & Spring Physics Tokens.
 */
@Immutable
object AuraMotion {
    // Animation Durations (ms)
    const val DurationMicro: Int = 150
    const val DurationStandard: Int = 280
    const val DurationExtended: Int = 420
    const val DurationLiquid: Int = 7200
    const val DurationStateTransition: Int = 360

    // Press Scale Values
    const val PressScaleNormal: Float = 1.0f
    const val PressScalePressed: Float = 0.95f

    // Standard Easings
    val EasingStandard: Easing = CubicBezierEasing(0.2f, 0.0f, 0.0f, 1.0f)
    val EasingEmphasized: Easing = FastOutSlowInEasing
    val EasingDecelerate: Easing = LinearOutSlowInEasing
    val EasingLinear: Easing = LinearEasing

    // Tween Specs
    fun <T> microTween() = tween<T>(durationMillis = DurationMicro, easing = EasingStandard)
    fun <T> standardTween() = tween<T>(durationMillis = DurationStandard, easing = EasingStandard)
    fun <T> extendedTween() = tween<T>(durationMillis = DurationExtended, easing = EasingStandard)
    fun <T> stateTransitionTween() = tween<T>(durationMillis = DurationStateTransition, easing = EasingStandard)

    // Spring Physics Specs (Apple Liquid Glass tactile feel)
    val PressSpring = spring<Float>(
        dampingRatio = 0.56f,
        stiffness = 540f
    )

    val EntranceSpring = spring<Float>(
        dampingRatio = 0.78f,
        stiffness = 380f
    )

    val MorphSpring = spring<Float>(
        dampingRatio = Spring.DampingRatioLowBouncy,
        stiffness = Spring.StiffnessMediumLow
    )
}

@Composable
fun rememberReducedMotion(): Boolean {
    val context = LocalContext.current
    return remember(context) {
        val durationScale = Settings.Global.getFloat(
            context.contentResolver,
            Settings.Global.ANIMATOR_DURATION_SCALE,
            1.0f
        )
        durationScale == 0f
    }
}

/**
 * Applies tactile Apple-style spring press bounce using an existing InteractionSource.
 */
fun Modifier.liquidSpringPress(
    interactionSource: InteractionSource,
    pressedScale: Float = AuraMotion.PressScalePressed
): Modifier = composed {
    val reducedMotion = rememberReducedMotion()
    val isPressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (isPressed && !reducedMotion) pressedScale else 1f,
        animationSpec = AuraMotion.PressSpring,
        label = "liquid_spring_press"
    )
    this.graphicsLayer {
        scaleX = scale
        scaleY = scale
    }
}

/**
 * Staggered spring-physics entrance wrapper for Dashboard Liquid Glass cards.
 */
@Composable
fun LiquidGlassStaggeredItem(
    index: Int,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    val reducedMotion = rememberReducedMotion()
    var revealed by remember { mutableStateOf(reducedMotion) }

    LaunchedEffect(reducedMotion) {
        if (!reducedMotion && !revealed) {
            delay((index.coerceIn(0, 6) * 42L))
            revealed = true
        }
    }

    val progress by animateFloatAsState(
        targetValue = if (revealed) 1f else 0f,
        animationSpec = AuraMotion.EntranceSpring,
        label = "stagger_reveal_$index"
    )

    Box(
        modifier = modifier.graphicsLayer {
            alpha = progress.coerceIn(0f, 1f)
            translationY = (1f - progress) * 28f
            val s = 0.965f + (0.035f * progress)
            scaleX = s
            scaleY = s
        }
    ) {
        content()
    }
}
