package com.kavach.services

import android.annotation.SuppressLint
import android.app.PendingIntent
import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import android.util.Log
import androidx.annotation.RequiresApi
import com.kavach.BaseApplication
import com.kavach.R
import com.kavach.ui.overlay.hud.HudUiState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/**
 * Native Android Notification Shade Quick Settings Tile for summoning or hiding
 * the Single-Window Liquid Glass Agy HUD from any foreground app.
 */
@RequiresApi(Build.VERSION_CODES.N)
class AgyHudTileService : TileService() {

    companion object {
        private const val TAG = "AgyHudTileService"
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var stateJob: Job? = null

    override fun onStartListening() {
        super.onStartListening()
        val controller = (application as? BaseApplication)?.container?.hudWindowController
        if (controller == null) {
            renderTile(visible = false, collapsed = false)
            return
        }
        stateJob?.cancel()
        stateJob = scope.launch {
            controller.stateFlow.collect { uiState ->
                renderTile(uiState.visible, uiState.collapsed)
            }
        }
    }

    override fun onStopListening() {
        stateJob?.cancel()
        stateJob = null
        super.onStopListening()
    }

    @SuppressLint("StartActivityAndCollapseDeprecated")
    override fun onClick() {
        super.onClick()
        val container = (application as? BaseApplication)?.container ?: return
        val controller = container.hudWindowController

        if (!controller.hasOverlayPermission()) {
            val permIntent = controller.getOverlayPermissionIntent()
            if (permIntent != null) {
                try {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                        val pi = PendingIntent.getActivity(
                            this,
                            4041,
                            permIntent,
                            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                        )
                        startActivityAndCollapse(pi)
                    } else {
                        @Suppress("DEPRECATION")
                        startActivityAndCollapse(permIntent)
                    }
                } catch (t: Throwable) {
                    Log.w(TAG, "Failed opening overlay permission from tile: ${t.message}")
                }
            }
            renderTile(visible = false, collapsed = false)
            return
        }

        val current: HudUiState = controller.stateFlow.value
        when {
            !current.visible -> {
                controller.show(collapsed = false)
                renderTile(visible = true, collapsed = false)
            }
            current.collapsed -> {
                controller.expand()
                renderTile(visible = true, collapsed = false)
            }
            else -> {
                controller.hide()
                renderTile(visible = false, collapsed = false)
            }
        }
    }

    private fun renderTile(visible: Boolean, collapsed: Boolean) {
        val tile = qsTile ?: return
        tile.label = getString(R.string.qs_tile_agy_hud_label)
        tile.state = if (visible) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            tile.subtitle = when {
                visible && collapsed -> getString(R.string.qs_tile_agy_hud_docked)
                visible -> getString(R.string.qs_tile_agy_hud_expanded)
                else -> getString(R.string.qs_tile_agy_hud_off)
            }
        }
        try {
            tile.updateTile()
        } catch (_: Throwable) {}
    }
}
