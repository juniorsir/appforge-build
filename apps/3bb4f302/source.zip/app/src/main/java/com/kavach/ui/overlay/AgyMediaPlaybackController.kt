package com.kavach.ui.overlay

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.SystemClock
import android.util.Log
import android.view.KeyEvent
import android.view.Surface
import com.kavach.ui.overlay.hud.MediaCarouselItem
import java.io.File
import java.io.FileInputStream

/**
 * Lean, focused Media Playback Controller for Single-Window HUD v2 Media Carousel.
 *
 * Exposes ONLY Play/Pause and Mute/Unmute controls:
 * - Direct local/HTTP media URIs (`video` / `audio`) play inline via Android [MediaPlayer].
 * - Device "Now Playing" items (no direct URI or `isNowPlaying == true`) route cleanly to
 *   system media session (`KEYCODE_MEDIA_PLAY_PAUSE`) and `STREAM_MUSIC` mute toggle.
 */
class AgyMediaPlaybackController(
    private val context: Context
) {
    companion object {
        private const val TAG = "AgyMediaPlaybackCtrl"
    }

    private val audioManager: AudioManager? by lazy {
        context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
    }

    private var mediaPlayer: MediaPlayer? = null
    @Volatile
    private var isPreparing: Boolean = false
    @Volatile
    private var isPrepared: Boolean = false
    private var loadedSignature: String = ""
    private var currentItem: MediaCarouselItem? = null
    private var videoSurface: Surface? = null

    @Volatile
    var isPlaying: Boolean = false
        private set

    @Volatile
    var isMuted: Boolean = false
        private set

    var onPlaybackStateChanged: ((playing: Boolean, muted: Boolean) -> Unit)? = null

    fun bindVideoSurface(surface: Surface?) {
        videoSurface = surface
        val mp = mediaPlayer ?: return
        try {
            if (surface == null || surface.isValid) {
                mp.setSurface(surface)
            }
        } catch (t: Throwable) {
            Log.w(TAG, "Unable to bind video surface: ${t.message}")
        }
    }

    /**
     * Loads or syncs the active [MediaCarouselItem]. Preserves playback if item URI did not change.
     */
    fun bindItem(item: MediaCarouselItem?, autoPlay: Boolean, muted: Boolean) {
        currentItem = item
        isMuted = muted
        if (item == null || item.isImage) {
            release()
            return
        }

        if (item.isNowPlaying || item.uri.isBlank()) {
            releaseNativePlayerOnly()
            loadedSignature = "now_playing|${item.id}"
            isPlaying = autoPlay
            return
        }

        val sig = "${item.id}|${item.uri}"
        if (sig != loadedSignature) {
            loadDirectUri(item, autoPlay, muted)
        } else {
            applyDirectControls(play = autoPlay, muted = muted)
        }
    }

    fun togglePlayPause(): Boolean {
        val item = currentItem
        val nextPlaying = !isPlaying
        isPlaying = nextPlaying
        if (item == null || item.isNowPlaying || item.uri.isBlank()) {
            dispatchSystemMediaPlayPause()
        } else {
            applyDirectControls(play = nextPlaying, muted = isMuted)
        }
        onPlaybackStateChanged?.invoke(isPlaying, isMuted)
        return isPlaying
    }

    fun toggleMute(): Boolean {
        val item = currentItem
        val nextMuted = !isMuted
        isMuted = nextMuted
        if (item == null || item.isNowPlaying || item.uri.isBlank()) {
            toggleSystemMusicMute()
        } else {
            applyDirectControls(play = isPlaying, muted = nextMuted)
        }
        onPlaybackStateChanged?.invoke(isPlaying, isMuted)
        return isMuted
    }

    fun release() {
        releaseNativePlayerOnly()
        loadedSignature = ""
        currentItem = null
        isPlaying = false
    }

    private fun loadDirectUri(item: MediaCarouselItem, autoPlay: Boolean, muted: Boolean) {
        releaseNativePlayerOnly()
        loadedSignature = "${item.id}|${item.uri}"
        isPlaying = autoPlay
        isMuted = muted

        try {
            val mp = MediaPlayer()
            mediaPlayer = mp
            isPreparing = true
            isPrepared = false

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                mp.setAudioAttributes(
                    AudioAttributes.Builder()
                        .setContentType(
                            if (item.isVideo) AudioAttributes.CONTENT_TYPE_MOVIE
                            else AudioAttributes.CONTENT_TYPE_MUSIC
                        )
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .build()
                )
            }
            videoSurface?.takeIf { it.isValid }?.let { mp.setSurface(it) }
            val vol = if (muted) 0f else 1f
            mp.setVolume(vol, vol)

            mp.setOnPreparedListener { player ->
                if (player !== mediaPlayer) return@setOnPreparedListener
                isPreparing = false
                isPrepared = true
                videoSurface?.takeIf { it.isValid }?.let {
                    try { player.setSurface(it) } catch (_: Throwable) {}
                }
                val v = if (isMuted) 0f else 1f
                try { player.setVolume(v, v) } catch (_: Throwable) {}
                if (isPlaying) {
                    try { player.start() } catch (_: Throwable) {}
                }
                onPlaybackStateChanged?.invoke(isPlaying, isMuted)
            }

            mp.setOnCompletionListener { player ->
                if (player !== mediaPlayer) return@setOnCompletionListener
                isPlaying = false
                onPlaybackStateChanged?.invoke(false, isMuted)
            }

            mp.setOnErrorListener { player, what, extra ->
                if (player === mediaPlayer) {
                    isPreparing = false
                    isPrepared = false
                }
                Log.w(TAG, "MediaPlayer error what=$what extra=$extra uri=${item.uri}")
                true
            }

            configureDataSource(mp, item.uri.trim())
            mp.prepareAsync()
        } catch (t: Throwable) {
            isPreparing = false
            isPrepared = false
            Log.w(TAG, "Failed preparing inline media ${item.uri}: ${t.message}")
        }
    }

    private fun applyDirectControls(play: Boolean, muted: Boolean) {
        isPlaying = play
        isMuted = muted
        val mp = mediaPlayer ?: return
        if (!isPrepared || isPreparing) return
        try {
            val v = if (muted) 0f else 1f
            mp.setVolume(v, v)
            if (play && !mp.isPlaying) {
                mp.start()
            } else if (!play && mp.isPlaying) {
                mp.pause()
            }
        } catch (_: Throwable) {}
    }

    private fun configureDataSource(mp: MediaPlayer, rawUri: String) {
        val localFile: File? = when {
            rawUri.startsWith("/") -> File(rawUri)
            rawUri.startsWith("file://", ignoreCase = true) -> Uri.parse(rawUri).path?.let { File(it) }
            else -> null
        }
        if (localFile != null && localFile.exists() && localFile.canRead()) {
            FileInputStream(localFile).use { fis ->
                mp.setDataSource(fis.fd)
            }
            return
        }
        if (rawUri.startsWith("http://", ignoreCase = true) || rawUri.startsWith("https://", ignoreCase = true)) {
            try {
                mp.setDataSource(rawUri)
                return
            } catch (_: Throwable) {
                mp.setDataSource(context, Uri.parse(rawUri))
                return
            }
        }
        mp.setDataSource(context, Uri.parse(rawUri))
    }

    private fun dispatchSystemMediaPlayPause() {
        val am = audioManager ?: return
        try {
            val now = SystemClock.uptimeMillis()
            am.dispatchMediaKeyEvent(KeyEvent(now, now, KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE, 0))
            am.dispatchMediaKeyEvent(KeyEvent(now, now, KeyEvent.ACTION_UP, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE, 0))
        } catch (t: Throwable) {
            Log.w(TAG, "Unable to dispatch system media play/pause: ${t.message}")
        }
    }

    private fun toggleSystemMusicMute() {
        val am = audioManager ?: return
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_TOGGLE_MUTE, 0)
            } else {
                @Suppress("DEPRECATION")
                am.setStreamMute(AudioManager.STREAM_MUSIC, isMuted)
            }
        } catch (t: Throwable) {
            Log.w(TAG, "Unable to toggle system music mute: ${t.message}")
        }
    }

    private fun releaseNativePlayerOnly() {
        val mp = mediaPlayer
        mediaPlayer = null
        val wasPrepared = isPrepared && !isPreparing
        isPreparing = false
        isPrepared = false
        if (mp != null) {
            try {
                mp.setOnPreparedListener(null)
                mp.setOnCompletionListener(null)
                mp.setOnErrorListener(null)
                mp.setSurface(null)
                if (wasPrepared) mp.stop()
                mp.reset()
                mp.release()
            } catch (_: Throwable) {}
        }
    }
}
