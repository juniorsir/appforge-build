package com.kavach.ui.overlay.hud

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * Thread-safe state store, HTTP/WS reducer, command queue, approval latch, and
 * Termux-safe input focus tracker for Single-Window HUD v2.
 */
class HudStore(
    var onCommandBroadcast: ((JSONObject) -> Unit)? = null
) {
    data class ApprovalResolution(
        val approvalId: String,
        val decision: String, // APPROVE | EDIT | DENY | TIMEOUT
        val approved: Boolean,
        val editedCommand: String? = null
    )

    private val _state = MutableStateFlow(HudUiState())
    val state: StateFlow<HudUiState> = _state.asStateFlow()

    private val commandQueue = ConcurrentLinkedQueue<HudCommand>()
    private val approvalLatches = ConcurrentHashMap<String, CountDownLatch>()
    private val approvalResults = ConcurrentHashMap<String, ApprovalResolution>()

    data class PromptHistoryStep(
        val text: String,
        val index: Int,
        val total: Int
    )

    private val promptHistoryLock = Any()
    private val promptHistory = ArrayDeque<String>()
    private var promptHistoryCursor: Int = -1

    fun currentState(): HudUiState = _state.value

    fun getRecentPrompts(): List<String> = synchronized(promptHistoryLock) {
        promptHistory.toList()
    }

    fun recordPromptHistory(rawText: String) {
        val clean = rawText.trim()
        if (clean.isEmpty()) return
        synchronized(promptHistoryLock) {
            promptHistory.removeAll { it.equals(clean, ignoreCase = true) }
            promptHistory.addFirst(clean)
            while (promptHistory.size > 12) {
                promptHistory.removeLast()
            }
            promptHistoryCursor = -1
        }
    }

    /**
     * Cycles through recent submitted prompts.
     * [delta] > 0 moves older (0 -> 1 -> 2), [delta] < 0 moves newer (2 -> 1 -> 0).
     */
    fun stepPromptHistory(delta: Int): PromptHistoryStep? = synchronized(promptHistoryLock) {
        if (promptHistory.isEmpty()) return null
        val size = promptHistory.size
        val nextIdx = when {
            promptHistoryCursor < 0 -> if (delta >= 0) 0 else size - 1
            else -> ((promptHistoryCursor + delta) % size + size) % size
        }
        promptHistoryCursor = nextIdx
        PromptHistoryStep(
            text = promptHistory[nextIdx],
            index = nextIdx + 1,
            total = size
        )
    }

    fun resetPromptHistoryCursor() {
        synchronized(promptHistoryLock) {
            promptHistoryCursor = -1
        }
    }

    // -------------------------------------------------------------------------
    // Window visibility, collapse, & Termux-safe focus state
    // -------------------------------------------------------------------------

    fun show(collapsed: Boolean = false) {
        _state.update { prev ->
            prev.copy(
                visible = true,
                collapsed = collapsed,
                inputFocused = if (collapsed) false else prev.inputFocused
            )
        }
    }

    fun hide(): JSONObject {
        _state.update { prev ->
            prev.copy(
                visible = false,
                inputFocused = false,
                snipPreviewExpanded = false
            )
        }
        return JSONObject().apply {
            put("success", true)
            put("visible", false)
            put("state", _state.value.status.name)
        }
    }

    fun setCollapsed(collapsed: Boolean) {
        _state.update { prev ->
            prev.copy(
                collapsed = collapsed,
                inputFocused = if (collapsed) false else prev.inputFocused,
                snipPreviewExpanded = if (collapsed) false else prev.snipPreviewExpanded
            )
        }
    }

    fun toggleCollapsed(): Boolean {
        val next = !_state.value.collapsed
        setCollapsed(next)
        return next
    }

    /**
     * Enforces Termux-safe keyboard focus:
     * focus is allowed ONLY when the HUD is visible and expanded;
     * collapsing, hiding, or submitting always releases focus back to Termux.
     */
    fun setInputFocused(focused: Boolean) {
        _state.update { prev ->
            val allowed = focused && prev.visible && !prev.collapsed
            if (prev.inputFocused == allowed) prev else prev.copy(inputFocused = allowed)
        }
    }

    fun resetToIdle(): JSONObject {
        clearPendingApprovalLatches("DENY")
        _state.value = HudUiState(
            visible = true,
            collapsed = false,
            inputFocused = false,
            status = HudStatus.IDLE,
            title = "Agy",
            thinkingText = "Ready"
        )
        return buildStateResponse()
    }

    // -------------------------------------------------------------------------
    // POST /api/hud/state — full state reducer (with backward-compatible aliases)
    // -------------------------------------------------------------------------

    fun applyFullState(json: JSONObject): JSONObject {
        if (json.optBoolean("reset", false)) {
            return resetToIdle()
        }

        val prev = _state.value
        val nextStatus = HudStatus.fromRaw(
            json.optString("state", json.optString("status", "")),
            fallback = if (json.has("approval") && !json.isNull("approval")) HudStatus.NEEDS_INPUT else HudStatus.IDLE
        )
        val title = json.optString("title", "").trim().ifBlank { "Agy" }
        val thinking = firstNonBlank(
            json.optString("thinkingText", ""),
            json.optString("currentAction", ""),
            json.optString("subtitle", ""),
            json.optString("stepText", "")
        ).ifBlank { defaultSubtitleFor(nextStatus) }
        val summary = firstNonBlank(
            json.optString("summaryText", ""),
            json.optString("detailedOutput", ""),
            json.optString("output", "")
        )
        val appPackage = firstNonBlank(
            json.optString("appPackage", ""),
            json.optString("packageName", ""),
            json.optString("targetPackage", "")
        )
        val iconHint = firstNonBlank(
            json.optString("iconHint", ""),
            json.optString("icon", "")
        )
        val actionKind = json.optString("actionKind", "").trim()
        val progress = parseProgress(json)
        val autoHideSeconds = json.optInt("autoHideSeconds", 0).coerceAtLeast(0)
        val collapsed = if (json.has("collapsed")) json.optBoolean("collapsed", false) else prev.collapsed

        val tasks = parseTasks(json.optJSONArray("tasks"))
        val mediaItems = extractMediaItems(json)
        val mediaPlaying = resolveMediaPlaying(json, mediaItems, fallback = false)
        val mediaMuted = resolveMediaMuted(json, fallback = false)
        val chess = extractChessState(json)
        val approval = if (json.has("approval") && !json.isNull("approval")) {
            parseApproval(json.optJSONObject("approval"))
        } else null
        val hardwareChip = parseHardwareChip(json.optJSONObject("hardwareChip"))
            ?: inferNowPlayingChip(json, mediaItems)
        val quickActions = parseQuickActions(json)
        val logs = parseLogs(json.optJSONArray("logs"))

        val activeIdx = if (mediaItems.isEmpty()) 0 else {
            json.optInt("mediaActiveIndex", 0).coerceIn(0, mediaItems.lastIndex)
        }

        _state.value = HudUiState(
            visible = json.optBoolean("visible", true),
            collapsed = if (approval != null) false else collapsed,
            inputFocused = false,
            status = if (approval != null && nextStatus == HudStatus.IDLE) HudStatus.NEEDS_INPUT else nextStatus,
            title = title,
            thinkingText = thinking,
            summaryText = summary,
            appPackage = appPackage,
            iconHint = iconHint,
            actionKind = actionKind,
            progress = progress,
            tasks = tasks,
            mediaItems = mediaItems,
            mediaActiveIndex = activeIdx,
            mediaPlaying = mediaPlaying,
            mediaMuted = mediaMuted,
            chess = chess,
            approval = approval,
            hardwareChip = hardwareChip,
            quickActions = quickActions,
            attachedSnip = prev.attachedSnip,
            snipPreviewExpanded = prev.snipPreviewExpanded,
            autoHideSeconds = autoHideSeconds,
            logs = logs
        )

        approval?.let { ensureApprovalLatch(it.id) }
        return buildStateResponse()
    }

    // -------------------------------------------------------------------------
    // POST /api/hud/patch — surgical updates without resetting untouched fields
    // -------------------------------------------------------------------------

    fun applyPatch(json: JSONObject): JSONObject {
        if (json.optBoolean("reset", false)) {
            return resetToIdle()
        }

        _state.update { prev ->
            var next = prev.copy(visible = json.optBoolean("visible", true))

            val rawState = json.optString("state", json.optString("status", "")).trim()
            if (rawState.isNotEmpty()) {
                next = next.copy(status = HudStatus.fromRaw(rawState, prev.status))
            }

            if (json.has("title")) {
                val t = json.optString("title", "").trim()
                if (t.isNotEmpty()) next = next.copy(title = t)
            }

            val thinkingPatch = firstNonBlank(
                if (json.has("thinkingText")) json.optString("thinkingText", "") else "",
                if (json.has("currentAction")) json.optString("currentAction", "") else "",
                if (json.has("subtitle")) json.optString("subtitle", "") else ""
            )
            if (thinkingPatch.isNotEmpty()) {
                next = next.copy(thinkingText = thinkingPatch)
            }

            val summaryKeyPresent = json.has("summaryText") || json.has("detailedOutput") || json.has("output")
            if (summaryKeyPresent) {
                val s = firstNonBlank(
                    json.optString("summaryText", ""),
                    json.optString("detailedOutput", ""),
                    json.optString("output", "")
                )
                next = next.copy(summaryText = s)
            }

            if (json.has("appPackage") || json.has("packageName")) {
                next = next.copy(
                    appPackage = firstNonBlank(
                        json.optString("appPackage", ""),
                        json.optString("packageName", "")
                    )
                )
            }

            if (json.has("iconHint") || json.has("icon")) {
                next = next.copy(
                    iconHint = firstNonBlank(
                        json.optString("iconHint", ""),
                        json.optString("icon", "")
                    )
                )
            }

            if (json.has("actionKind")) {
                next = next.copy(actionKind = json.optString("actionKind", "").trim())
            }

            if (json.has("progress") || json.has("setProgress")) {
                next = next.copy(progress = parseProgress(json))
            }

            if (json.has("collapsed")) {
                val c = json.optBoolean("collapsed", next.collapsed)
                next = next.copy(
                    collapsed = c,
                    inputFocused = if (c) false else next.inputFocused
                )
            }

            if (json.has("autoHideSeconds")) {
                next = next.copy(autoHideSeconds = json.optInt("autoHideSeconds", 0).coerceAtLeast(0))
            }

            // Logs append
            val appendedLogs = mutableListOf<String>()
            val singleLog = json.optString("appendLog", "").trim()
            if (singleLog.isNotEmpty()) appendedLogs.add(singleLog)
            val multiLogs = json.optJSONArray("appendLogs")
            if (multiLogs != null) {
                for (i in 0 until multiLogs.length()) {
                    val line = multiLogs.optString(i, "").trim()
                    if (line.isNotEmpty()) appendedLogs.add(line)
                }
            }
            if (appendedLogs.isNotEmpty()) {
                next = next.copy(logs = (next.logs + appendedLogs).takeLast(40))
                if (thinkingPatch.isEmpty()) {
                    next = next.copy(thinkingText = appendedLogs.last().take(120))
                }
            }

            // Tasks replace or upsert
            if (json.has("tasks")) {
                next = next.copy(tasks = parseTasks(json.optJSONArray("tasks")))
            }
            val upsertTaskObj = json.optJSONObject("upsertTask") ?: json.optJSONObject("updateTask")
            if (upsertTaskObj != null) {
                val item = parseTaskItem(upsertTaskObj)
                if (item != null) {
                    val list = next.tasks.toMutableList()
                    val idx = list.indexOfFirst { it.id == item.id }
                    if (idx >= 0) list[idx] = item else list.add(item)
                    next = next.copy(tasks = list)
                }
            }

            // Chess patch
            if (json.optBoolean("clearChess", false)) {
                next = next.copy(chess = null)
            } else if (hasChessPayload(json)) {
                next = next.copy(chess = extractChessState(json, fallback = next.chess))
            }

            // Media patch
            if (json.optBoolean("clearMedia", false) || json.optBoolean("clearResults", false)) {
                next = next.copy(mediaItems = emptyList(), mediaActiveIndex = 0, mediaPlaying = false)
            } else if (hasMediaPayload(json)) {
                val parsedMedia = extractMediaItems(json)
                val safeIdx = if (parsedMedia.isEmpty()) 0 else {
                    json.optInt("mediaActiveIndex", next.mediaActiveIndex).coerceIn(0, parsedMedia.lastIndex)
                }
                next = next.copy(
                    mediaItems = parsedMedia,
                    mediaActiveIndex = safeIdx,
                    mediaPlaying = resolveMediaPlaying(json, parsedMedia, fallback = next.mediaPlaying),
                    mediaMuted = resolveMediaMuted(json, fallback = next.mediaMuted)
                )
            } else {
                if (json.has("mediaPlaying") || json.has("playing")) {
                    next = next.copy(mediaPlaying = json.optBoolean("mediaPlaying", json.optBoolean("playing", next.mediaPlaying)))
                }
                if (json.has("mediaMuted") || json.has("muted")) {
                    next = next.copy(mediaMuted = json.optBoolean("mediaMuted", json.optBoolean("muted", next.mediaMuted)))
                }
            }

            // Hardware chip patch
            if (json.has("hardwareChip")) {
                next = next.copy(
                    hardwareChip = if (json.isNull("hardwareChip")) null else parseHardwareChip(json.optJSONObject("hardwareChip"))
                )
            }

            // Quick actions patch
            if (json.has("quickActions") || json.has("smartSuggestions")) {
                next = next.copy(quickActions = parseQuickActions(json))
            }

            next
        }

        return buildStateResponse().apply { put("patched", true) }
    }

    // -------------------------------------------------------------------------
    // POST /api/hud/approval — inline approval prompt + blocking latch
    // -------------------------------------------------------------------------

    fun setApproval(json: JSONObject): JSONObject {
        val clearRequested = json.optBoolean("clear", false) ||
            json.optString("action", "").equals("clear", ignoreCase = true) ||
            (json.has("active") && !json.optBoolean("active", true))

        if (clearRequested) {
            clearPendingApprovalLatches("DENY")
            _state.update { prev ->
                prev.copy(
                    approval = null,
                    status = if (prev.status == HudStatus.NEEDS_INPUT) HudStatus.IDLE else prev.status
                )
            }
            return JSONObject().apply {
                put("success", true)
                put("approvalActive", false)
                put("state", _state.value.status.name)
            }
        }

        val prompt = parseApproval(json) ?: ApprovalPrompt(
            title = json.optString("title", "Approval Required").ifBlank { "Approval Required" },
            description = json.optString("description", ""),
            commandPreview = json.optString("commandPreview", json.optString("command", "")),
            riskLevel = json.optString("riskLevel", "MEDIUM"),
            allowEdit = json.optBoolean("allowEdit", true),
            timeoutSeconds = json.optInt("timeoutSeconds", 60).coerceIn(5, 300)
        )

        ensureApprovalLatch(prompt.id)
        _state.update { prev ->
            prev.copy(
                visible = true,
                collapsed = false,
                status = HudStatus.NEEDS_INPUT,
                title = prompt.title.ifBlank { prev.title },
                thinkingText = prompt.description.ifBlank { "Awaiting approval..." },
                approval = prompt
            )
        }

        return JSONObject().apply {
            put("success", true)
            put("approvalActive", true)
            put("approvalId", prompt.id)
            put("state", _state.value.status.name)
        }
    }

    fun respondToApproval(decisionRaw: String, editedCommand: String? = null): JSONObject {
        val active = _state.value.approval
        val decision = when (decisionRaw.trim().uppercase()) {
            "APPROVE", "APPROVED", "ALLOW", "YES" -> "APPROVE"
            "EDIT", "EDITED", "MODIFY" -> "EDIT"
            else -> "DENY"
        }
        val approved = decision == "APPROVE" || decision == "EDIT"
        val approvalId = active?.id ?: "approval"
        val finalCmd = editedCommand?.trim()?.takeIf { it.isNotEmpty() } ?: active?.commandPreview.orEmpty()

        val resolution = ApprovalResolution(
            approvalId = approvalId,
            decision = decision,
            approved = approved,
            editedCommand = if (decision == "EDIT") finalCmd else null
        )
        approvalResults[approvalId] = resolution
        approvalLatches.remove(approvalId)?.countDown()

        val payload = JSONObject().apply {
            put("approvalId", approvalId)
            put("decision", decision)
            put("approved", approved)
            if (finalCmd.isNotBlank()) put("command", finalCmd)
            if (decision == "EDIT") {
                put("editedCommand", finalCmd)
                put("editedText", finalCmd)
            }
        }
        enqueueCommand(
            action = "APPROVAL_RESPONSE",
            text = finalCmd,
            buttonId = approvalId,
            payload = payload
        )

        _state.update { prev ->
            prev.copy(
                approval = null,
                inputFocused = false,
                status = if (approved) HudStatus.WORKING else HudStatus.PAUSED,
                thinkingText = when (decision) {
                    "APPROVE" -> "Approved"
                    "EDIT" -> "Approved (edited)"
                    else -> "Denied"
                }
            )
        }

        return JSONObject().apply {
            put("success", true)
            put("approvalId", approvalId)
            put("decision", decision)
            put("approved", approved)
        }
    }

    fun awaitApprovalResult(approvalId: String, timeoutMs: Long): ApprovalResolution? {
        approvalResults[approvalId]?.let { return it }
        val latch = approvalLatches[approvalId] ?: return approvalResults[approvalId]
        val completed = try {
            latch.await(timeoutMs.coerceAtLeast(1L), TimeUnit.MILLISECONDS)
        } catch (_: InterruptedException) {
            false
        }
        if (!completed) {
            return ApprovalResolution(approvalId = approvalId, decision = "TIMEOUT", approved = false)
        }
        return approvalResults[approvalId]
    }

    // -------------------------------------------------------------------------
    // Command Queue + GET /api/hud/poll
    // -------------------------------------------------------------------------

    fun submitPrompt(
        rawText: String,
        action: String = "PROMPT",
        buttonId: String = "",
        extraPayload: JSONObject? = null
    ): HudCommand? {
        val cleanText = rawText.trim()
        val snip = _state.value.attachedSnip
        if (cleanText.isEmpty() && snip == null && action == "PROMPT") return null

        val payload = JSONObject().apply {
            if (extraPayload != null) {
                val keys = extraPayload.keys()
                while (keys.hasNext()) {
                    val k = keys.next()
                    put(k, extraPayload.get(k))
                }
            }
            if (snip != null) {
                put("snip", snip.toJson())
                put("hasSnip", true)
            }
        }

        val finalPromptText = cleanText.ifBlank {
            if (snip != null) "Inspect this snipped screen region" else ""
        }

        if (action == "PROMPT" && cleanText.isNotEmpty()) {
            recordPromptHistory(cleanText)
        }

        _state.update { prev ->
            prev.copy(
                attachedSnip = null,
                snipPreviewExpanded = false,
                inputFocused = false,
                status = if (action == "PROMPT") HudStatus.WORKING else prev.status,
                thinkingText = if (action == "PROMPT") "Sending prompt..." else prev.thinkingText
            )
        }

        return enqueueCommand(
            action = action,
            text = finalPromptText,
            buttonId = buttonId,
            payload = if (payload.length() > 0) payload else null
        )
    }

    fun enqueueCommand(
        action: String,
        text: String = "",
        buttonId: String = "",
        payload: JSONObject? = null
    ): HudCommand {
        val normalizedAction = action.trim().uppercase().ifBlank { "PROMPT" }
        val cmd = HudCommand(
            action = normalizedAction,
            text = text.trim(),
            buttonId = buttonId.trim(),
            payload = payload
        )
        while (commandQueue.size >= 64) {
            commandQueue.poll()
        }
        commandQueue.offer(cmd)

        when (normalizedAction) {
            "STOP", "FORCE_STOP" -> {
                _state.update { prev ->
                    prev.copy(
                        status = HudStatus.STOPPED,
                        thinkingText = "Stopped",
                        inputFocused = false,
                        chess = prev.chess?.copy(autopilotState = "IDLE")
                    )
                }
            }
            "PAUSE" -> {
                _state.update { prev ->
                    prev.copy(
                        status = HudStatus.PAUSED,
                        thinkingText = "Paused",
                        chess = prev.chess?.copy(autopilotState = "PAUSED")
                    )
                }
            }
            "RESUME" -> {
                _state.update { prev ->
                    prev.copy(
                        status = HudStatus.WORKING,
                        thinkingText = "Resuming...",
                        chess = prev.chess?.copy(autopilotState = "RUNNING")
                    )
                }
            }
        }

        try {
            onCommandBroadcast?.invoke(cmd.toJson())
        } catch (_: Throwable) {}
        return cmd
    }

    fun handleRemoteCommand(json: JSONObject): JSONObject {
        val action = json.optString("action", "PROMPT").trim().uppercase()
        val text = json.optString("text", "")
        val buttonId = json.optString("buttonId", "")
        val payload = json.optJSONObject("payload")
        val cmd = enqueueCommand(action = action, text = text, buttonId = buttonId, payload = payload)
        return JSONObject().apply {
            put("success", true)
            put("commandId", cmd.id)
            put("action", cmd.action)
            put("state", _state.value.status.name)
        }
    }

    fun pollCommands(): JSONObject {
        val drained = JSONArray()
        while (true) {
            val next = commandQueue.poll() ?: break
            drained.put(next.toJson())
        }
        val cur = _state.value
        return JSONObject().apply {
            put("success", true)
            put("count", drained.length())
            put("commands", drained)
            put("state", cur.status.name)
            put("visible", cur.visible)
            put("collapsed", cur.collapsed)
        }
    }

    // -------------------------------------------------------------------------
    // Media Carousel & Snip state mutations
    // -------------------------------------------------------------------------

    fun setMediaActiveIndex(index: Int) {
        _state.update { prev ->
            if (prev.mediaItems.isEmpty()) prev
            else prev.copy(mediaActiveIndex = index.coerceIn(0, prev.mediaItems.lastIndex))
        }
    }

    fun toggleMediaPlayPause(): Boolean {
        val next = !_state.value.mediaPlaying
        _state.update { it.copy(mediaPlaying = next) }
        return next
    }

    fun setMediaPlaying(playing: Boolean) {
        _state.update { if (it.mediaPlaying == playing) it else it.copy(mediaPlaying = playing) }
    }

    fun toggleMediaMute(): Boolean {
        val next = !_state.value.mediaMuted
        _state.update { it.copy(mediaMuted = next) }
        return next
    }

    fun setMediaMuted(muted: Boolean) {
        _state.update { if (it.mediaMuted == muted) it else it.copy(mediaMuted = muted) }
    }

    fun attachSnip(snip: SnippedRegionContext?) {
        _state.update { prev ->
            prev.copy(
                visible = if (snip != null) true else prev.visible,
                collapsed = if (snip != null) false else prev.collapsed,
                attachedSnip = snip,
                snipPreviewExpanded = false
            )
        }
    }

    fun toggleSnipPreviewExpanded(expanded: Boolean? = null): Boolean {
        val cur = _state.value
        val next = if (cur.attachedSnip == null) false else (expanded ?: !cur.snipPreviewExpanded)
        _state.update { it.copy(snipPreviewExpanded = next) }
        return next
    }

    fun updateForegroundQuickActions(appPackage: String?, resolvedActions: List<QuickAction>) {
        _state.update { prev ->
            val pkg = appPackage?.trim().orEmpty()
            if (prev.quickActions.isNotEmpty() && prev.appPackage == pkg) prev
            else prev.copy(
                appPackage = pkg.ifBlank { prev.appPackage },
                quickActions = if (prev.quickActions.isEmpty()) resolvedActions.take(3) else prev.quickActions
            )
        }
    }

    // -------------------------------------------------------------------------
    // Parsing Helpers (v2 schema + backward-compatible aliases)
    // -------------------------------------------------------------------------

    private fun buildStateResponse(): JSONObject {
        val cur = _state.value
        return JSONObject().apply {
            put("success", true)
            put("visible", cur.visible)
            put("collapsed", cur.collapsed)
            put("state", cur.status.name)
            put("title", cur.title)
            put("thinkingText", cur.thinkingText)
            put("mediaCount", cur.mediaItems.size)
            put("hasChess", cur.chess != null)
            put("approvalActive", cur.approval != null)
        }
    }

    private fun ensureApprovalLatch(id: String) {
        approvalResults.remove(id)
        approvalLatches[id] = CountDownLatch(1)
    }

    private fun clearPendingApprovalLatches(decision: String) {
        val keys = approvalLatches.keys.toList()
        for (k in keys) {
            approvalResults.putIfAbsent(
                k,
                ApprovalResolution(approvalId = k, decision = decision, approved = false)
            )
            approvalLatches.remove(k)?.countDown()
        }
    }

    private fun defaultSubtitleFor(status: HudStatus): String = when (status) {
        HudStatus.IDLE -> "Ready"
        HudStatus.WORKING -> "Working..."
        HudStatus.PAUSED -> "Paused"
        HudStatus.NEEDS_INPUT -> "Approval needed"
        HudStatus.STOPPED -> "Stopped"
        HudStatus.DONE -> "Done"
        HudStatus.ERROR -> "Error"
    }

    private fun firstNonBlank(vararg values: String?): String {
        for (v in values) {
            val clean = v?.trim().orEmpty()
            if (clean.isNotEmpty()) return clean
        }
        return ""
    }

    private fun parseProgress(json: JSONObject): Float? {
        val key = when {
            json.has("progress") && !json.isNull("progress") -> "progress"
            json.has("setProgress") && !json.isNull("setProgress") -> "setProgress"
            else -> return null
        }
        val raw = json.optDouble(key, Double.NaN)
        if (raw.isNaN()) return null
        val normalized = if (raw > 1.0) (raw / 100.0) else raw
        return normalized.toFloat().coerceIn(0f, 1f)
    }

    private fun parseTasks(arr: JSONArray?): List<HudTaskItem> {
        if (arr == null) return emptyList()
        return buildList {
            for (i in 0 until arr.length()) {
                val obj = arr.optJSONObject(i)
                if (obj != null) {
                    parseTaskItem(obj)?.let { add(it) }
                } else {
                    val text = arr.optString(i, "").trim()
                    if (text.isNotEmpty()) {
                        add(HudTaskItem(id = "task_$i", title = text))
                    }
                }
            }
        }
    }

    private fun parseTaskItem(obj: JSONObject): HudTaskItem? {
        val title = firstNonBlank(obj.optString("title", ""), obj.optString("label", ""), obj.optString("name", ""))
        if (title.isEmpty()) return null
        val id = obj.optString("id", title.lowercase().take(16)).ifBlank { UUID.randomUUID().toString().take(8) }
        val status = obj.optString("status", "PENDING").trim().uppercase().ifBlank { "PENDING" }
        val detail = obj.optString("detail", obj.optString("subtitle", "")).trim()
        return HudTaskItem(id = id, title = title, status = status, detail = detail)
    }

    private fun hasChessPayload(json: JSONObject): Boolean {
        if (json.has("chess") && !json.isNull("chess")) return true
        val tm = json.optJSONObject("taskMap")
        return tm != null && tm.has("chess") && !tm.isNull("chess")
    }

    private fun extractChessState(json: JSONObject, fallback: ChessBoardState? = null): ChessBoardState? {
        val obj = json.optJSONObject("chess")
            ?: json.optJSONObject("taskMap")?.optJSONObject("chess")
            ?: return fallback
        val fen = obj.optString("fen", fallback?.fen ?: "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1")
            .trim()
            .ifBlank { fallback?.fen ?: "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1" }
        val playerColor = firstNonBlank(
            obj.optString("playerColor", ""),
            obj.optString("perspective", ""),
            obj.optString("orientation", ""),
            fallback?.playerColor ?: "white"
        )
        val evalCp = when {
            obj.has("evalCp") -> obj.optInt("evalCp", fallback?.evalCp ?: 0)
            obj.has("eval") -> (obj.optDouble("eval", 0.0) * 100.0).toInt()
            else -> fallback?.evalCp ?: 0
        }
        val lastMove = extractMoveString(obj, "lastMove", fallback?.lastMove ?: "")
        val bestMove = extractMoveString(obj, "bestMove", fallback?.bestMove ?: "")
        val turnLabel = firstNonBlank(
            obj.optString("turnLabel", ""),
            obj.optString("turn", ""),
            fallback?.turnLabel ?: if (fen.contains(" b ")) "Black to move" else "White to move"
        )
        val autopilotState = firstNonBlank(
            obj.optString("autopilotState", ""),
            obj.optString("autopilot", ""),
            fallback?.autopilotState ?: "IDLE"
        )
        val statusText = firstNonBlank(
            obj.optString("statusText", ""),
            obj.optString("status", ""),
            fallback?.statusText ?: ""
        )
        return ChessBoardState(
            fen = fen,
            playerColor = playerColor,
            evalCp = evalCp,
            lastMove = lastMove,
            bestMove = bestMove,
            turnLabel = turnLabel,
            autopilotState = autopilotState,
            statusText = statusText
        )
    }

    private fun extractMoveString(obj: JSONObject, key: String, fallback: String): String {
        if (!obj.has(key) || obj.isNull(key)) return fallback
        val sub = obj.optJSONObject(key)
        if (sub != null) {
            val from = sub.optString("from", "").trim()
            val to = sub.optString("to", "").trim()
            val combined = "$from$to"
            return combined.ifBlank { fallback }
        }
        return obj.optString(key, "").trim().ifBlank { fallback }
    }

    private fun hasMediaPayload(json: JSONObject): Boolean {
        if (json.has("mediaItems")) return true
        val tm = json.optJSONObject("taskMap")
        if (tm != null && (tm.has("results") || tm.has("player") || tm.has("media"))) return true
        return json.has("results") || json.has("player") || json.has("media")
    }

    private fun extractMediaItems(json: JSONObject): List<MediaCarouselItem> {
        val out = mutableListOf<MediaCarouselItem>()

        // 1. Primary v2 key: mediaItems[]
        val directArr = json.optJSONArray("mediaItems")
        if (directArr != null) {
            for (i in 0 until directArr.length()) {
                parseMediaItem(directArr.optJSONObject(i), i)?.let { out.add(it) }
            }
        }

        // 2. Backward-compatible alias: taskMap.results.items[] or results.items[]
        val resultsObj = json.optJSONObject("taskMap")?.optJSONObject("results")
            ?: json.optJSONObject("results")
        val resultsItems = resultsObj?.optJSONArray("items")
        if (resultsItems != null && out.isEmpty()) {
            for (i in 0 until resultsItems.length()) {
                parseMediaItem(resultsItems.optJSONObject(i), i)?.let { out.add(it) }
            }
        }

        // 3. Backward-compatible alias: taskMap.player.playlist[] or player.playlist[]
        val playerObj = json.optJSONObject("taskMap")?.optJSONObject("player")
            ?: json.optJSONObject("player")
        if (playerObj != null && out.isEmpty()) {
            val pl = playerObj.optJSONArray("playlist")
            if (pl != null && pl.length() > 0) {
                for (i in 0 until pl.length()) {
                    parseMediaItem(pl.optJSONObject(i), i, defaultKind = playerObj.optString("mediaMode", "audio"))
                        ?.let { out.add(it) }
                }
            } else {
                val uri = playerObj.optString("uri", playerObj.optString("url", "")).trim()
                val title = playerObj.optString("title", "").trim()
                if (uri.isNotEmpty() || title.isNotEmpty()) {
                    out.add(
                        MediaCarouselItem(
                            id = "player_0",
                            kind = playerObj.optString("mediaMode", "audio"),
                            title = title.ifBlank { "Media" },
                            subtitle = playerObj.optString("subtitle", playerObj.optString("artist", "")),
                            uri = uri,
                            thumbnailUri = playerObj.optString("thumbnailUri", playerObj.optString("artworkUrl", "")),
                            isNowPlaying = uri.isEmpty(),
                            durationMs = playerObj.optLong("durationMs", 0L)
                        )
                    )
                }
            }
        }

        // 4. Backward-compatible alias: taskMap.media or media ("Now Playing")
        val mediaObj = json.optJSONObject("taskMap")?.optJSONObject("media")
            ?: json.optJSONObject("media")
        if (mediaObj != null && out.isEmpty()) {
            val title = firstNonBlank(mediaObj.optString("trackTitle", ""), mediaObj.optString("title", ""))
            val artist = firstNonBlank(mediaObj.optString("artist", ""), mediaObj.optString("subtitle", ""))
            if (title.isNotEmpty() || artist.isNotEmpty()) {
                out.add(
                    MediaCarouselItem(
                        id = "now_playing",
                        kind = "audio",
                        title = title.ifBlank { "Now Playing" },
                        subtitle = artist,
                        uri = mediaObj.optString("uri", mediaObj.optString("url", "")).trim(),
                        thumbnailUri = mediaObj.optString("thumbnailUri", mediaObj.optString("artworkUrl", "")),
                        isNowPlaying = true
                    )
                )
            }
        }

        return out.take(12)
    }

    private fun parseMediaItem(
        obj: JSONObject?,
        index: Int,
        defaultKind: String = "image"
    ): MediaCarouselItem? {
        if (obj == null) return null
        val kindRaw = firstNonBlank(obj.optString("kind", ""), obj.optString("type", ""), defaultKind)
        val uri = firstNonBlank(obj.optString("uri", ""), obj.optString("url", ""), obj.optString("src", ""))
        val thumb = firstNonBlank(obj.optString("thumbnailUri", ""), obj.optString("thumbnail", ""), obj.optString("artworkUrl", ""))
        val title = firstNonBlank(obj.optString("title", ""), obj.optString("label", ""), obj.optString("name", ""))
        val subtitle = firstNonBlank(obj.optString("subtitle", ""), obj.optString("artist", ""), obj.optString("source", ""))
        val isNowPlaying = obj.optBoolean("isNowPlaying", false) || (kindRaw.equals("audio", true) && uri.isBlank())
        if (uri.isEmpty() && thumb.isEmpty() && title.isEmpty()) return null
        return MediaCarouselItem(
            id = obj.optString("id", "media_$index").ifBlank { "media_$index" },
            kind = kindRaw,
            title = title,
            subtitle = subtitle,
            uri = uri,
            thumbnailUri = thumb,
            isNowPlaying = isNowPlaying,
            durationMs = obj.optLong("durationMs", 0L)
        )
    }

    private fun resolveMediaPlaying(
        json: JSONObject,
        items: List<MediaCarouselItem>,
        fallback: Boolean
    ): Boolean {
        if (json.has("mediaPlaying")) return json.optBoolean("mediaPlaying", fallback)
        if (json.has("playing")) return json.optBoolean("playing", fallback)
        val playerObj = json.optJSONObject("taskMap")?.optJSONObject("player") ?: json.optJSONObject("player")
        if (playerObj != null && playerObj.has("playing")) return playerObj.optBoolean("playing", fallback)
        val mediaObj = json.optJSONObject("taskMap")?.optJSONObject("media") ?: json.optJSONObject("media")
        if (mediaObj != null && mediaObj.has("isPlaying")) return mediaObj.optBoolean("isPlaying", fallback)
        return if (items.isEmpty()) false else fallback
    }

    private fun resolveMediaMuted(json: JSONObject, fallback: Boolean): Boolean {
        if (json.has("mediaMuted")) return json.optBoolean("mediaMuted", fallback)
        if (json.has("muted")) return json.optBoolean("muted", fallback)
        val playerObj = json.optJSONObject("taskMap")?.optJSONObject("player") ?: json.optJSONObject("player")
        if (playerObj != null && playerObj.has("muted")) return playerObj.optBoolean("muted", fallback)
        return fallback
    }

    private fun parseApproval(obj: JSONObject?): ApprovalPrompt? {
        if (obj == null) return null
        val title = obj.optString("title", "").trim()
        val cmd = firstNonBlank(obj.optString("commandPreview", ""), obj.optString("command", ""), obj.optString("actionPreview", ""))
        val desc = obj.optString("description", obj.optString("message", "")).trim()
        if (title.isEmpty() && cmd.isEmpty() && desc.isEmpty()) return null
        return ApprovalPrompt(
            id = obj.optString("id", UUID.randomUUID().toString().take(8)).ifBlank { UUID.randomUUID().toString().take(8) },
            title = title.ifBlank { "Approval Required" },
            description = desc,
            commandPreview = cmd,
            riskLevel = obj.optString("riskLevel", "MEDIUM"),
            allowEdit = obj.optBoolean("allowEdit", true),
            timeoutSeconds = obj.optInt("timeoutSeconds", 60).coerceIn(5, 300)
        )
    }

    private fun parseHardwareChip(obj: JSONObject?): HardwareChip? {
        if (obj == null) return null
        val label = firstNonBlank(obj.optString("label", ""), obj.optString("title", ""), obj.optString("text", ""))
        if (label.isEmpty()) return null
        return HardwareChip(
            label = label,
            detail = obj.optString("detail", obj.optString("value", "")).trim(),
            kind = obj.optString("kind", "info").trim().lowercase()
        )
    }

    private fun inferNowPlayingChip(json: JSONObject, mediaItems: List<MediaCarouselItem>): HardwareChip? {
        val rawChip = json.optString("hardwareChip", "").trim()
        if (rawChip.isNotEmpty() && !rawChip.startsWith("{")) {
            return HardwareChip(label = rawChip, kind = "info")
        }
        val np = mediaItems.firstOrNull { it.isNowPlaying }
        if (np != null && np.title.isNotBlank()) {
            return HardwareChip(label = np.title, detail = np.subtitle, kind = "media")
        }
        return null
    }

    private fun parseQuickActions(json: JSONObject): List<QuickAction> {
        val arr = json.optJSONArray("quickActions")
            ?: json.optJSONArray("smartSuggestions")
            ?: json.optJSONArray("buttons")
            ?: return emptyList()
        return buildList {
            for (i in 0 until arr.length()) {
                val obj = arr.optJSONObject(i)
                if (obj != null) {
                    val label = firstNonBlank(obj.optString("label", ""), obj.optString("title", ""), obj.optString("text", ""))
                    if (label.isNotEmpty()) {
                        add(
                            QuickAction(
                                id = obj.optString("id", "qa_$i").ifBlank { "qa_$i" },
                                label = label,
                                prompt = firstNonBlank(obj.optString("prompt", ""), obj.optString("command", ""), label),
                                action = obj.optString("action", "PROMPT").trim().uppercase().ifBlank { "PROMPT" },
                                iconHint = obj.optString("iconHint", ""),
                                appPackage = obj.optString("appPackage", "")
                            )
                        )
                    }
                } else {
                    val label = arr.optString(i, "").trim()
                    if (label.isNotEmpty()) {
                        add(QuickAction(id = "qa_$i", label = label, prompt = label))
                    }
                }
            }
        }.take(3)
    }

    private fun parseLogs(arr: JSONArray?): List<String> {
        if (arr == null) return emptyList()
        return buildList {
            for (i in 0 until arr.length()) {
                val line = arr.optString(i, "").trim()
                if (line.isNotEmpty()) add(line)
            }
        }.takeLast(40)
    }
}
