package com.kavach.ui.theme

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * White Apple Liquid Glass & Spring Component Specifications:
 * Luminous translucent frosted white surfaces, top-edge specular refraction sheen,
 * cool sky-blue ambient atmosphere, and crisp spring-animated controls.
 */
@Immutable
enum class AuraGlassLevel(
    val bgAlpha: Float,
    val borderAlpha: Float,
    val highlightAlpha: Float
) {
    LEVEL_1(bgAlpha = 0.72f, borderAlpha = 0.10f, highlightAlpha = 0.55f),
    LEVEL_2(bgAlpha = 0.80f, borderAlpha = 0.12f, highlightAlpha = 0.68f),
    LEVEL_3(bgAlpha = 0.86f, borderAlpha = 0.14f, highlightAlpha = 0.78f),
    ELEVATED(bgAlpha = 0.90f, borderAlpha = 0.16f, highlightAlpha = 0.86f),
    ACTIVE(bgAlpha = 0.92f, borderAlpha = 0.22f, highlightAlpha = 0.92f);

    fun backgroundColor(): Color = Color.White.copy(alpha = bgAlpha)
    fun borderColor(): Color = Color(0xFF0F172A).copy(alpha = borderAlpha)

    fun createHighlightBrush(): Brush = Brush.verticalGradient(
        0.0f to Color.White.copy(alpha = highlightAlpha),
        0.45f to Color.White.copy(alpha = highlightAlpha * 0.25f),
        1.0f to Color.Transparent
    )
}

object LiquidGlassTokens {
    val ObsidianVoid = Color(0xFFF6FAFF)            // Luminous porcelain-sky canvas
    val GlassCardFill = Color(0xCCFFFFFF)           // 80% frosted milky white glass card
    val GlassModalFill = Color(0xEBFFFFFF)          // 92% frosted white glass modal
    val GlassCapsuleFill = Color(0xB8F1F7FD)        // Soft ice-frosted pill/row
    val GlassPillInputFill = Color(0xD4FFFFFF)      // Frosted white input capsule
    val HairlineStroke = Color(0xFFE2ECF8)          // Crisp light sky-tinted hairline

    val SkyAccent = Color(0xFF0EA5E9)               // Luminous Sky Blue primary
    val SkyAccentDeep = Color(0xFF0284C7)           // Pressed / high-contrast Sky Blue
    val SkyAccentSoft = Color(0xFF38BDF8)           // Soft sky refraction highlight

    val CyanGlow = SkyAccent
    val VioletGlow = CrispIndigo
    val EmeraldGlow = CrispEmerald
    val AmberGlow = CrispAmber
    val CoralGlow = CrispRose

    val OuterCardShape = RoundedCornerShape(24.dp)
    val InnerCapsuleShape = RoundedCornerShape(16.dp)
    val FullPillShape = RoundedCornerShape(50)

    fun specularBorder(
        primaryTint: Color = HairlineStroke,
        secondaryTint: Color = CrispBorder,
        width: Dp = 1.dp,
        intensity: Float = 1f,
        isDark: Boolean = false
    ): BorderStroke {
        val isNeutral = primaryTint == HairlineStroke || primaryTint == CrispBorder || primaryTint == CrispHairline
        val brush = when {
            isDark && isNeutral -> Brush.linearGradient(
                colors = listOf(
                    Color.White.copy(alpha = 0.24f),
                    Color(0xFF94A3B8).copy(alpha = 0.16f),
                    Color.White.copy(alpha = 0.10f)
                )
            )
            isDark -> Brush.linearGradient(
                colors = listOf(
                    Color.White.copy(alpha = 0.34f),
                    primaryTint.copy(alpha = (0.50f * intensity).coerceAtMost(0.65f)),
                    primaryTint.copy(alpha = (0.28f * intensity).coerceAtMost(0.45f))
                )
            )
            !isNeutral -> Brush.linearGradient(
                colors = listOf(
                    Color.White.copy(alpha = 0.96f),
                    primaryTint.copy(alpha = (0.42f * intensity).coerceAtMost(0.58f)),
                    primaryTint.copy(alpha = (0.24f * intensity).coerceAtMost(0.38f))
                )
            )
            else -> Brush.linearGradient(
                colors = listOf(
                    Color.White.copy(alpha = 0.96f),
                    Color(0xFFDCE7F5).copy(alpha = 0.62f),
                    Color(0xFFCBD9EC).copy(alpha = 0.45f)
                )
            )
        }
        return BorderStroke(width = width, brush = brush)
    }

    val TopRefractionSheen = Brush.verticalGradient(
        0.0f to Color.White.copy(alpha = 0.85f),
        0.35f to Color.White.copy(alpha = 0.24f),
        1.0f to Color.Transparent
    )

    val SmokedTopRefractionSheen = Brush.verticalGradient(
        0.0f to Color.White.copy(alpha = 0.14f),
        0.38f to Color.White.copy(alpha = 0.04f),
        1.0f to Color.Transparent
    )

    val SkyButtonGradient = Brush.horizontalGradient(
        colors = listOf(SkyAccentSoft, SkyAccent, SkyAccentDeep)
    )

    fun accentButtonGradient(soft: Color, primary: Color, deep: Color): Brush =
        Brush.horizontalGradient(colors = listOf(soft, primary, deep))
}

/**
 * Soft luminous porcelain-white canvas with a delicate sky-mist top wash.
 */
fun Modifier.liquidObsidianBackground(
    primaryAura: Color = LiquidGlassTokens.SkyAccentSoft,
    secondaryAura: Color = Color(0xFF93C5FD)
): Modifier = this.background(
    Brush.verticalGradient(
        0.0f to Color(0xFFF4F9FF),
        0.42f to Color(0xFFF8FBFF),
        1.0f to Color(0xFFEFF5FC)
    )
).drawBehind {
    drawCircle(
        brush = Brush.radialGradient(
            colors = listOf(primaryAura.copy(alpha = 0.11f), Color.Transparent),
            center = Offset(size.width * 0.16f, size.height * 0.10f),
            radius = size.width * 0.72f
        ),
        radius = size.width * 0.72f,
        center = Offset(size.width * 0.16f, size.height * 0.10f)
    )
    drawCircle(
        brush = Brush.radialGradient(
            colors = listOf(secondaryAura.copy(alpha = 0.09f), Color.Transparent),
            center = Offset(size.width * 0.88f, size.height * 0.46f),
            radius = size.width * 0.68f
        ),
        radius = size.width * 0.68f,
        center = Offset(size.width * 0.88f, size.height * 0.46f)
    )
}

/**
 * Animated ambient Sky Mist & Ice Periwinkle glass atmosphere canvas so translucent
 * white frosted cards visibly catch and refract soft moving light.
 */
@Composable
fun LiquidGlassAmbientCanvas(
    modifier: Modifier = Modifier,
    primaryOrbColor: Color = LiquidGlassTokens.SkyAccentSoft,
    secondaryOrbColor: Color = Color(0xFF93C5FD),
    isDark: Boolean = false,
    content: @Composable BoxScope.() -> Unit
) {
    val reducedMotion = rememberReducedMotion()
    val drift = if (reducedMotion) {
        0.5f
    } else {
        val transition = rememberInfiniteTransition(label = "ambient_glass_orbs")
        val anim by transition.animateFloat(
            initialValue = 0f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(
                animation = tween(durationMillis = AuraMotion.DurationLiquid, easing = FastOutSlowInEasing),
                repeatMode = RepeatMode.Reverse
            ),
            label = "orb_drift"
        )
        anim
    }

    val animPrimaryOrb by animateColorAsState(
        targetValue = primaryOrbColor,
        animationSpec = spring(stiffness = Spring.StiffnessLow),
        label = "ambient_primary_orb"
    )
    val animSecondaryOrb by animateColorAsState(
        targetValue = secondaryOrbColor,
        animationSpec = spring(stiffness = Spring.StiffnessLow),
        label = "ambient_secondary_orb"
    )
    val bgTop by animateColorAsState(
        targetValue = if (isDark) Color(0xFF0A101D) else Color(0xFFF3F8FF),
        animationSpec = spring(stiffness = Spring.StiffnessLow),
        label = "ambient_bg_top"
    )
    val bgMid by animateColorAsState(
        targetValue = if (isDark) Color(0xFF0E1729) else Color(0xFFF9FBFF),
        animationSpec = spring(stiffness = Spring.StiffnessLow),
        label = "ambient_bg_mid"
    )
    val bgBot by animateColorAsState(
        targetValue = if (isDark) Color(0xFF0B1324) else Color(0xFFEDF4FC),
        animationSpec = spring(stiffness = Spring.StiffnessLow),
        label = "ambient_bg_bot"
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    0.0f to bgTop,
                    0.5f to bgMid,
                    1.0f to bgBot
                )
            )
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            val orb1Alpha = if (isDark) 0.22f else 0.18f
            val orb2Alpha = if (isDark) 0.18f else 0.15f
            val orb3Alpha = if (isDark) 0.14f else 0.18f
            val orb1Center = Offset(
                x = w * (0.14f + 0.12f * drift),
                y = h * (0.09f + 0.05f * drift)
            )
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(animPrimaryOrb.copy(alpha = orb1Alpha), Color.Transparent),
                    center = orb1Center,
                    radius = w * 0.72f
                ),
                radius = w * 0.72f,
                center = orb1Center
            )

            val orb2Center = Offset(
                x = w * (0.88f - 0.10f * drift),
                y = h * (0.38f + 0.07f * drift)
            )
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(animSecondaryOrb.copy(alpha = orb2Alpha), Color.Transparent),
                    center = orb2Center,
                    radius = w * 0.65f
                ),
                radius = w * 0.65f,
                center = orb2Center
            )

            val orb3Center = Offset(
                x = w * (0.30f + 0.14f * (1f - drift)),
                y = h * (0.82f - 0.06f * drift)
            )
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(animPrimaryOrb.copy(alpha = orb3Alpha), Color.Transparent),
                    center = orb3Center,
                    radius = w * 0.62f
                ),
                radius = w * 0.62f,
                center = orb3Center
            )
        }
        content()
    }
}

/**
 * Apple Liquid Glass translucent frosted card with specular top sheen,
 * dual-tone luminous rim border, and soft tinted elevation shadow.
 */
@Composable
fun LiquidGlassCard(
    modifier: Modifier = Modifier,
    accentTint: Color = LiquidGlassTokens.HairlineStroke,
    secondaryTint: Color = LiquidGlassTokens.HairlineStroke,
    shape: Shape = LiquidGlassTokens.OuterCardShape,
    containerColor: Color = LiquidGlassTokens.GlassCardFill,
    isDark: Boolean = false,
    content: @Composable BoxScope.() -> Unit
) {
    Surface(
        color = containerColor,
        shape = shape,
        shadowElevation = 0.dp,
        border = LiquidGlassTokens.specularBorder(
            primaryTint = accentTint,
            secondaryTint = secondaryTint,
            width = 1.dp,
            isDark = isDark
        ),
        modifier = modifier
            .fillMaxWidth()
            .shadow(
                elevation = 10.dp,
                shape = shape,
                ambientColor = if (isDark) Color(0x44020617) else Color(0x220284C7),
                spotColor = if (isDark) Color(0x55020617) else Color(0x1C0F172A)
            )
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    if (isDark) LiquidGlassTokens.SmokedTopRefractionSheen
                    else LiquidGlassTokens.TopRefractionSheen
                ),
            content = content
        )
    }
}

/**
 * Frosted sky-tinted glass icon badge with subtle luminous white rim.
 */
@Composable
fun LiquidIconOrb(
    icon: ImageVector,
    tint: Color,
    contentDescription: String? = null,
    size: Dp = 36.dp,
    iconSize: Dp = 18.dp,
    isCircle: Boolean = false,
    modifier: Modifier = Modifier
) {
    val shape = if (isCircle) CircleShape else RoundedCornerShape((size.value * 0.30f).dp)
    Box(
        modifier = modifier
            .size(size)
            .clip(shape)
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        tint.copy(alpha = 0.16f),
                        tint.copy(alpha = 0.08f)
                    )
                )
            )
            .border(
                width = 0.85.dp,
                brush = Brush.verticalGradient(
                    colors = listOf(
                        Color.White.copy(alpha = 0.85f),
                        tint.copy(alpha = 0.22f)
                    )
                ),
                shape = shape
            ),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = contentDescription,
            tint = tint,
            modifier = Modifier.size(iconSize)
        )
    }
}

/**
 * Breathing luminous status dot for live indicators (Sync / Live / Active).
 */
@Composable
fun PulsingStatusDot(
    color: Color,
    modifier: Modifier = Modifier,
    dotSize: Dp = 6.dp,
    pulsing: Boolean = true
) {
    val reducedMotion = rememberReducedMotion()
    val pulse = if (!pulsing || reducedMotion) {
        0f
    } else {
        val transition = rememberInfiniteTransition(label = "status_dot_pulse")
        val anim by transition.animateFloat(
            initialValue = 0f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(
                animation = tween(durationMillis = 1400, easing = FastOutSlowInEasing),
                repeatMode = RepeatMode.Restart
            ),
            label = "dot_halo"
        )
        anim
    }

    Box(
        modifier = modifier.size(dotSize * 2.2f),
        contentAlignment = Alignment.Center
    ) {
        if (pulsing && !reducedMotion) {
            Box(
                modifier = Modifier
                    .size(dotSize)
                    .graphicsLayer {
                        val s = 1f + pulse * 1.45f
                        scaleX = s
                        scaleY = s
                        alpha = (1f - pulse) * 0.55f
                    }
                    .clip(CircleShape)
                    .background(color)
            )
        }
        Box(
            modifier = Modifier
                .size(dotSize)
                .clip(CircleShape)
                .background(color)
        )
    }
}

/**
 * Sleek Apple Liquid Glass spring-animated pill switch with 48dp accessible touch target.
 */
@Composable
fun CrispPillSwitch(
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    modifier: Modifier = Modifier,
    checkedTrackColor: Color = LiquidGlassTokens.SkyAccent,
    uncheckedTrackColor: Color = Color(0xFFD5DFEC),
    thumbColor: Color = Color.White,
    enabled: Boolean = true,
    switchContentDescription: String? = null
) {
    val trackColor by animateColorAsState(
        targetValue = if (checked) checkedTrackColor else uncheckedTrackColor,
        animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
        label = "pill_switch_track"
    )
    val thumbOffset by animateDpAsState(
        targetValue = if (checked) 20.dp else 0.dp,
        animationSpec = spring(
            dampingRatio = 0.65f,
            stiffness = Spring.StiffnessMedium
        ),
        label = "pill_switch_thumb"
    )

    val interactionSource = remember { MutableInteractionSource() }
    Box(
        contentAlignment = Alignment.Center,
        modifier = modifier
            .size(width = 52.dp, height = 40.dp)
            .liquidSpringPress(interactionSource, pressedScale = 0.94f)
            .semantics {
                if (switchContentDescription != null) {
                    contentDescription = switchContentDescription
                }
            }
            .clickable(
                enabled = enabled,
                role = Role.Switch,
                interactionSource = interactionSource,
                indication = null,
                onClick = { onCheckedChange(!checked) }
            )
    ) {
        Box(
            modifier = Modifier
                .width(48.dp)
                .height(28.dp)
                .clip(RoundedCornerShape(50))
                .background(if (enabled) trackColor else trackColor.copy(alpha = 0.5f))
                .border(
                    width = 0.75.dp,
                    color = Color.White.copy(alpha = if (checked) 0.35f else 0.75f),
                    shape = RoundedCornerShape(50)
                )
                .padding(3.dp),
            contentAlignment = Alignment.CenterStart
        ) {
            Box(
                modifier = Modifier
                    .offset(x = thumbOffset)
                    .size(22.dp)
                    .shadow(
                        elevation = 3.dp,
                        shape = CircleShape,
                        ambientColor = Color(0x330284C7),
                        spotColor = Color(0x280F172A)
                    )
                    .clip(CircleShape)
                    .background(thumbColor)
            )
        }
    }
}
