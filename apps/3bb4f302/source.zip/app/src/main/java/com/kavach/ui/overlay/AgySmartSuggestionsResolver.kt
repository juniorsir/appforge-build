package com.kavach.ui.overlay

import com.kavach.ui.overlay.hud.QuickAction

/**
 * Pure app-aware contextual suggestion chip resolver for the Agy HUD composer.
 *
 * When Agy supplies explicit [explicitSuggestions], those take precedence. Otherwise,
 * resolves 2–3 high-signal one-tap prompts tailored to the active foreground [appPackage].
 */
object AgySmartSuggestionsResolver {

    fun resolve(
        appPackage: String?,
        explicitSuggestions: List<QuickAction> = emptyList(),
        maxItems: Int = 3
    ): List<QuickAction> {
        if (explicitSuggestions.isNotEmpty()) {
            return explicitSuggestions.take(maxItems.coerceIn(1, 5))
        }
        val pkg = appPackage?.lowercase()?.trim().orEmpty()
        val chips = when {
            pkg.contains("youtube") || pkg.contains("revanced") || pkg.contains("newpipe") -> listOf(
                QuickAction(
                    id = "yt_summarize",
                    label = "Summarize video",
                    prompt = "Summarize the current YouTube video and key takeaways",
                    iconHint = "youtube",
                    appPackage = pkg
                ),
                QuickAction(
                    id = "yt_skip_ad",
                    label = "Skip ad / Play",
                    prompt = "Skip any ad on YouTube and ensure playback is running",
                    iconHint = "youtube",
                    appPackage = pkg
                ),
                QuickAction(
                    id = "yt_chapters",
                    label = "Find key moment",
                    prompt = "Inspect the current YouTube video chapters and jump to the main section",
                    iconHint = "youtube",
                    appPackage = pkg
                )
            )

            pkg.contains("chrome") || pkg.contains("firefox") || pkg.contains("brave") ||
                pkg.contains("edge") || pkg.contains("opera") || pkg.contains("browser") -> listOf(
                QuickAction(
                    id = "web_tldr",
                    label = "TL;DR this page",
                    prompt = "Read the active browser page and give me a concise TL;DR summary",
                    iconHint = "chrome",
                    appPackage = pkg
                ),
                QuickAction(
                    id = "web_extract",
                    label = "Extract key facts",
                    prompt = "Extract the key facts, links, and numbers from the visible webpage",
                    iconHint = "chrome",
                    appPackage = pkg
                ),
                QuickAction(
                    id = "web_translate",
                    label = "Explain simply",
                    prompt = "Explain what is on this browser screen in simple terms",
                    iconHint = "chrome",
                    appPackage = pkg
                )
            )

            pkg.contains("whatsapp") || pkg.contains("telegram") || pkg.contains("messaging") ||
                pkg.contains("mms") || pkg.contains("discord") || pkg.contains("slack") -> listOf(
                QuickAction(
                    id = "chat_reply",
                    label = "Draft reply",
                    prompt = "Read the latest chat messages and draft a helpful reply without sending it yet",
                    iconHint = "chat",
                    appPackage = pkg
                ),
                QuickAction(
                    id = "chat_summarize",
                    label = "Summarize chat",
                    prompt = "Summarize the visible conversation thread and any action items",
                    iconHint = "chat",
                    appPackage = pkg
                ),
                QuickAction(
                    id = "chat_unread",
                    label = "Key dates & tasks",
                    prompt = "Pull out any dates, names, or tasks mentioned in this chat",
                    iconHint = "chat",
                    appPackage = pkg
                )
            )

            pkg.contains("settings") -> listOf(
                QuickAction(
                    id = "set_explain",
                    label = "Explain setting",
                    prompt = "Explain the settings currently shown on screen and recommended values",
                    iconHint = "settings",
                    appPackage = pkg
                ),
                QuickAction(
                    id = "set_battery",
                    label = "Optimize battery",
                    prompt = "Guide me with spotlight pins to optimize battery and background usage",
                    iconHint = "settings",
                    appPackage = pkg
                ),
                QuickAction(
                    id = "set_wifi",
                    label = "Check network",
                    prompt = "Check my current network and connectivity status",
                    iconHint = "settings",
                    appPackage = pkg
                )
            )

            pkg.contains("chess") || pkg.contains("lichess") -> listOf(
                QuickAction(
                    id = "chess_best",
                    label = "Best move",
                    prompt = "Analyze the visible chess position and suggest the strongest next move",
                    iconHint = "chess",
                    appPackage = pkg
                ),
                QuickAction(
                    id = "chess_threat",
                    label = "Spot threats",
                    prompt = "Check what opponent threats or tactics exist in the current chess board",
                    iconHint = "chess",
                    appPackage = pkg
                ),
                QuickAction(
                    id = "chess_eval",
                    label = "Evaluate position",
                    prompt = "Evaluate who is better in this chess position and explain the plan",
                    iconHint = "chess",
                    appPackage = pkg
                )
            )

            pkg.contains("termux") -> listOf(
                QuickAction(
                    id = "term_error",
                    label = "Explain output",
                    prompt = "Inspect the current Termux output and explain any errors or next steps",
                    iconHint = "termux",
                    appPackage = pkg
                ),
                QuickAction(
                    id = "term_status",
                    label = "System status",
                    prompt = "Check running background processes, battery, and memory status",
                    iconHint = "termux",
                    appPackage = pkg
                ),
                QuickAction(
                    id = "term_git",
                    label = "Git summary",
                    prompt = "Summarize current git status and recent changes in the active workspace",
                    iconHint = "termux",
                    appPackage = pkg
                )
            )

            pkg.contains("instagram") || pkg.contains("twitter") || pkg.contains("reddit") ||
                pkg.contains("tiktok") -> listOf(
                QuickAction(
                    id = "social_explain",
                    label = "What's this post?",
                    prompt = "Read the visible post and explain the context or key points",
                    iconHint = "search",
                    appPackage = pkg
                ),
                QuickAction(
                    id = "social_fact",
                    label = "Fact-check claim",
                    prompt = "Inspect the claim shown on screen and verify it with sources",
                    iconHint = "search",
                    appPackage = pkg
                ),
                QuickAction(
                    id = "social_save",
                    label = "Save summary",
                    prompt = "Summarize the key takeaway from this screen so I can reference it later",
                    iconHint = "spark_ai",
                    appPackage = pkg
                )
            )

            pkg.contains("gmail") || pkg.contains("mail") || pkg.contains("outlook") -> listOf(
                QuickAction(
                    id = "mail_summary",
                    label = "Summarize email",
                    prompt = "Summarize the currently open email and highlight deadlines",
                    iconHint = "mail",
                    appPackage = pkg
                ),
                QuickAction(
                    id = "mail_reply",
                    label = "Draft reply",
                    prompt = "Draft a concise professional reply to this email without sending yet",
                    iconHint = "mail",
                    appPackage = pkg
                ),
                QuickAction(
                    id = "mail_tasks",
                    label = "Extract tasks",
                    prompt = "Extract action items and follow-ups from this email",
                    iconHint = "mail",
                    appPackage = pkg
                )
            )

            else -> listOf(
                QuickAction(
                    id = "gen_screen",
                    label = "Explain screen",
                    prompt = "Inspect what is currently on my screen and summarize it",
                    iconHint = "spark_ai",
                    appPackage = pkg
                ),
                QuickAction(
                    id = "gen_guide",
                    label = "Guide me here",
                    prompt = "Look at this screen and guide me step-by-step with spotlight highlights",
                    iconHint = "spark_ai",
                    appPackage = pkg
                ),
                QuickAction(
                    id = "gen_status",
                    label = "Device status",
                    prompt = "Give me a quick overview of battery, network, and active apps",
                    iconHint = "spark_ai",
                    appPackage = pkg
                )
            )
        }
        return chips.take(maxItems.coerceIn(1, 5))
    }

    fun shortAppLabel(appPackage: String?): String {
        val pkg = appPackage?.lowercase()?.trim().orEmpty()
        return when {
            pkg.isEmpty() -> ""
            pkg.contains("youtube") -> "YouTube"
            pkg.contains("chrome") -> "Chrome"
            pkg.contains("firefox") -> "Firefox"
            pkg.contains("brave") -> "Brave"
            pkg.contains("whatsapp") -> "WhatsApp"
            pkg.contains("telegram") -> "Telegram"
            pkg.contains("settings") -> "Settings"
            pkg.contains("chess") || pkg.contains("lichess") -> "Chess"
            pkg.contains("termux") -> "Termux"
            pkg.contains("instagram") -> "Instagram"
            pkg.contains("gmail") -> "Gmail"
            pkg.contains("discord") -> "Discord"
            else -> pkg.substringAfterLast('.').replaceFirstChar { it.uppercase() }.take(14)
        }
    }
}
