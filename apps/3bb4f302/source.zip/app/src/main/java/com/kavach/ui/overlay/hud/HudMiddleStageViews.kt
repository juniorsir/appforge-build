package com.kavach.ui.overlay.hud

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.SurfaceTexture
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.TextUtils
import android.transition.AutoTransition
import android.transition.TransitionManager
import android.util.Base64
import android.util.LruCache
import android.view.Gravity
import android.view.MotionEvent
import android.view.Surface
import android.view.TextureView
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.kavach.ui.overlay.AgyAppleVectorIconView
import com.kavach.ui.overlay.AgyMediaPlaybackController
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.min

/**
 * Adaptive Compact Content Stage (`maxHeight <= 210dp`, hidden when empty/idle)
 * for Single-Window HUD v2 — White Apple Liquid Glass Edition.
 *
 * Renders only useful contextual views for the active state:
 * - Attached Snip thumbnail preview (tap to expand inline with smooth transition)
 * - Inline Approval Gate (Approve / Edit / Deny)
 * - Live Compact 8x8 Chess Board + chess_autopilot controls
 * - Swipeable Media Carousel (Image / Video / Audio with ONLY Play/Pause & Mute/Unmute controls)
 * - Compact Answer Summary (tap to copy), Hardware/Media chip, Task progress, & Quick Actions
 */
class HudMiddleStageViews(
    private val context: Context,
    private val mediaController: AgyMediaPlaybackController,
    private val callbacks: Callbacks
) : FrameLayout(context) {

    interface Callbacks {
        fun onToggleSnipExpand()
        fun onClearSnip()
        fun onMediaPageSelected(index: Int)
        fun onMediaPlayPause()
        fun onMediaMuteToggle()
        fun onChessAction(action: String, text: String, buttonId: String)
        fun onApprovalDecision(decision: String, editedCommand: String?)
        fun onQuickActionClick(action: QuickAction)
        fun onRequestInputFocus(editText: EditText)
    }

    companion object {
        private const val MAX_STAGE_HEIGHT_DP = 210
        private val CARD_BG = Color.parseColor("#D4FFFFFF")
        private val INNER_BG = Color.parseColor("#CCF1F6FD")
        private val BORDER_COLOR = Color.parseColor("#200F172A")
        private val BORDER_SKY = Color.parseColor("#3D0EA5E9")
        private val TEXT_PRIMARY = Color.parseColor("#0F172A")
        private val TEXT_SECONDARY = Color.parseColor("#475569")
        private val ACCENT_SKY = Color.parseColor("#0284C7")
        private val ACCENT_SKY_FILL = Color.parseColor("#0EA5E9")
        private val ACCENT_EMERALD = Color.parseColor("#15803D")
        private val ACCENT_AMBER = Color.parseColor("#D97706")
        private val ACCENT_ROSE = Color.parseColor("#E11D48")

        private val imageExecutor = Executors.newFixedThreadPool(2)
        private val bitmapCache = object : LruCache<String, Bitmap>(24) {
            override fun sizeOf(key: String, value: Bitmap): Int = 1
        }
    }

    private val d = context.resources.displayMetrics.density.coerceAtLeast(1f)
    private val mainHandler = Handler(Looper.getMainLooper())

    private val scrollView: ScrollView
    private val contentColumn: LinearLayout

    // Render signature tracking to avoid tearing down active surfaces/inputs unnecessarily
    private var lastRenderKey: String = ""
    private var lastSnipTimestamp: Long = -1L
    private var cachedSnipBitmap: Bitmap? = null
    private var approvalEditVisible: Boolean = false
    private var activeVideoSurface: Surface? = null

    // Live references for lightweight transport icon updates without rebuilding carousel
    private var playPauseBtnRef: AgyAppleVectorIconView? = null
    private var muteBtnRef: AgyAppleVectorIconView? = null
    private var dotsRowRef: LinearLayout? = null
    private var activePalette: ResolvedHudPalette = ResolvedHudPalette.resolve(HudAppearanceConfig(), isSystemDark = false)

    init {
        contentDescription = "${HudModels.HUD_NODE_TAG_PREFIX}middle_stage"
        layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        visibility = View.GONE

        contentColumn = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            contentDescription = "${HudModels.HUD_NODE_TAG_PREFIX}middle_column"
        }

        scrollView = object : ScrollView(context) {
            override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
                val maxH = (MAX_STAGE_HEIGHT_DP * d).toInt()
                val constrainedH = MeasureSpec.makeMeasureSpec(maxH, MeasureSpec.AT_MOST)
                super.onMeasure(widthMeasureSpec, constrainedH)
            }
        }.apply {
            isVerticalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            contentDescription = "${HudModels.HUD_NODE_TAG_PREFIX}middle_scroll"
            addView(
                contentColumn,
                LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            )
        }

        addView(
            scrollView,
            LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        )
    }

    fun render(
        state: HudUiState,
        cardInnerWidthPx: Int,
        palette: ResolvedHudPalette = activePalette
    ) {
        activePalette = palette
        if (!state.hasMiddleContent || state.collapsed) {
            if (visibility != View.GONE) {
                visibility = View.GONE
            }
            if (state.mediaItems.isEmpty()) {
                mediaController.release()
            }
            return
        }

        visibility = View.VISIBLE

        val structuralKey = buildStructuralKey(state, cardInnerWidthPx, palette)
        if (structuralKey == lastRenderKey) {
            updateTransportButtons(state.mediaPlaying, state.mediaMuted)
            updateCarouselDots(state.mediaItems.size, state.mediaActiveIndex)
            return
        }
        val shouldAnimateLayout = lastRenderKey.isNotEmpty() && !isReducedMotionEnabled()
        lastRenderKey = structuralKey

        if (shouldAnimateLayout) {
            try {
                val transition = AutoTransition().apply {
                    duration = 220L
                    interpolator = OvershootInterpolator(0.5f)
                }
                TransitionManager.beginDelayedTransition(contentColumn, transition)
            } catch (_: Throwable) {}
        }

        releaseVideoSurface()
        playPauseBtnRef = null
        muteBtnRef = null
        dotsRowRef = null
        contentColumn.removeAllViews()

        var addedSection = false
        fun addSection(view: View) {
            val lp = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                if (addedSection) topMargin = (8 * d).toInt()
            }
            contentColumn.addView(view, lp)
            addedSection = true
        }

        // 1. Attached Snip Preview (Thumbnail + tap to expand inline)
        state.attachedSnip?.let { snip ->
            addSection(buildSnipPreviewCard(snip, state.snipPreviewExpanded))
        }

        // 2. Inline Approval Gate (highest interaction priority)
        state.approval?.let { approval ->
            addSection(buildApprovalCard(approval))
        }

        // 3. Live Compact Chess Board + autopilot controls
        state.chess?.let { chess ->
            addSection(buildChessCard(chess))
        }

        // 4. Swipeable Media Carousel (ONLY Play/Pause + Mute/Unmute controls)
        if (state.mediaItems.isNotEmpty()) {
            addSection(buildMediaCarousel(state, cardInnerWidthPx))
        }

        // 5. Compact Answer Summary (tap to copy)
        if (state.summaryText.isNotBlank()) {
            addSection(buildSummaryCard(state.summaryText))
        }

        // 6. Compact Task Step List (if provided and not overshadowed by approval/chess)
        if (state.tasks.isNotEmpty() && state.approval == null) {
            addSection(buildTasksCard(state.tasks))
        }

        // 7. Hardware / Media Chip + Screen-Aware Quick Actions
        if (state.hardwareChip != null || state.quickActions.isNotEmpty()) {
            addSection(buildChipAndActionsRow(state.hardwareChip, state.quickActions))
        }
    }

    fun release() {
        releaseVideoSurface()
        mediaController.release()
    }

    private fun buildStructuralKey(state: HudUiState, widthPx: Int, palette: ResolvedHudPalette): String {
        return buildString {
            append(widthPx).append('|')
            append(palette.signature).append('|')
            append(state.attachedSnip?.capturedAtMs ?: 0L).append('|')
            append(state.snipPreviewExpanded).append('|')
            append(state.approval?.hashCode() ?: 0).append('|')
            append(approvalEditVisible).append('|')
            append(state.chess?.hashCode() ?: 0).append('|')
            append(state.mediaItems.hashCode()).append('|')
            append(state.summaryText).append('|')
            append(state.tasks.hashCode()).append('|')
            append(state.hardwareChip?.hashCode() ?: 0).append('|')
            append(state.quickActions.hashCode())
        }
    }

    // -------------------------------------------------------------------------
    // 1. Attached Snip Thumbnail + Tap-to-Expand Preview
    // -------------------------------------------------------------------------

    private fun decodeSnipBitmap(snip: SnippedRegionContext): Bitmap? {
        if (!snip.hasScreenshot) return null
        if (snip.capturedAtMs == lastSnipTimestamp && cachedSnipBitmap != null && cachedSnipBitmap?.isRecycled == false) {
            return cachedSnipBitmap
        }
        val decoded = try {
            val bytes = Base64.decode(snip.screenshotBase64, Base64.DEFAULT)
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
        } catch (_: Throwable) {
            null
        }
        lastSnipTimestamp = snip.capturedAtMs
        cachedSnipBitmap = decoded
        return decoded
    }

    private fun buildSnipPreviewCard(snip: SnippedRegionContext, expanded: Boolean): View {
        val p = activePalette
        val bmp = decodeSnipBitmap(snip)
        val container = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            background = frostedGlassCard(p.cardBgBottom, p.borderAccent, 16f)
            setPadding((10 * d).toInt(), (9 * d).toInt(), (10 * d).toInt(), (9 * d).toInt())
            contentDescription = "${HudModels.HUD_NODE_TAG_PREFIX}snip_preview_card"
        }

        if (expanded && bmp != null) {
            val header = LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            val label = TextView(context).apply {
                text = "Snip ${snip.widthPx}×${snip.heightPx}"
                textSize = 11.5f
                setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
                setTextColor(p.textPrimary)
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            }
            val collapsePill = pillTextButtonColor("Collapse", p.accentDeep, p.accentPillBg, p.accentPillBorder) {
                callbacks.onToggleSnipExpand()
            }
            val removeBtn = pillTextButton("✕", ACCENT_ROSE, "#1AE11D48", "#38E11D48") {
                callbacks.onClearSnip()
            }
            header.addView(label)
            header.addView(collapsePill)
            header.addView(removeBtn, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                marginStart = (6 * d).toInt()
            })
            container.addView(header)

            val fullImg = ImageView(context).apply {
                setImageBitmap(bmp)
                scaleType = ImageView.ScaleType.FIT_CENTER
                background = roundedBox(p.innerBg, p.borderNeutral, 12f)
                clipToOutline = true
                contentDescription = "${HudModels.HUD_NODE_TAG_PREFIX}snip_expanded_image"
                setOnClickListener { callbacks.onToggleSnipExpand() }
            }
            container.addView(
                fullImg,
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (150 * d).toInt()).apply {
                    topMargin = (7 * d).toInt()
                }
            )
            return container
        }

        val row = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setOnClickListener { if (bmp != null) callbacks.onToggleSnipExpand() }
        }

        if (bmp != null) {
            val thumb = ImageView(context).apply {
                setImageBitmap(bmp)
                scaleType = ImageView.ScaleType.CENTER_CROP
                background = roundedBox(p.innerBg, p.borderAccent, 11f)
                clipToOutline = true
                contentDescription = "${HudModels.HUD_NODE_TAG_PREFIX}snip_thumbnail"
            }
            row.addView(
                thumb,
                LinearLayout.LayoutParams((50 * d).toInt(), (50 * d).toInt()).apply {
                    marginEnd = (10 * d).toInt()
                }
            )
        }

        val metaCol = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        val titleTv = TextView(context).apply {
            text = snip.summaryLabel
            textSize = 12f
            setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
            setTextColor(p.textPrimary)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        val subTv = TextView(context).apply {
            text = when {
                bmp != null -> "Tap thumbnail to expand • ${snip.nodes.size} UI nodes"
                snip.nodes.isNotEmpty() -> "${snip.nodes.size} UI elements captured"
                else -> "Region attached to next prompt"
            }
            textSize = 10.5f
            setTextColor(p.textSecondary)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        metaCol.addView(titleTv)
        metaCol.addView(subTv)
        row.addView(metaCol)

        if (bmp != null) {
            row.addView(
                pillTextButtonColor("View", p.accentDeep, p.accentPillBg, p.accentPillBorder) {
                    callbacks.onToggleSnipExpand()
                }
            )
        }
        row.addView(
            pillTextButtonColor("✕", p.textSecondary, p.iconSurfaceFill, p.iconSurfaceBorder) {
                callbacks.onClearSnip()
            },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                marginStart = (6 * d).toInt()
            }
        )

        container.addView(row)
        return container
    }

    // -------------------------------------------------------------------------
    // 2. Inline Approval Gate
    // -------------------------------------------------------------------------

    private fun buildApprovalCard(approval: ApprovalPrompt): View {
        val p = activePalette
        val riskColor = when (approval.normalizedRisk) {
            "HIGH" -> ACCENT_ROSE
            "LOW" -> ACCENT_EMERALD
            else -> ACCENT_AMBER
        }

        val card = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            background = frostedGlassCard(
                p.cardBgBottom,
                Color.argb(115, Color.red(riskColor), Color.green(riskColor), Color.blue(riskColor)),
                16f
            )
            setPadding((10 * d).toInt(), (9 * d).toInt(), (10 * d).toInt(), (9 * d).toInt())
            contentDescription = "${HudModels.HUD_NODE_TAG_PREFIX}approval_card"
        }

        val topRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val riskBadge = TextView(context).apply {
            text = approval.normalizedRisk
            textSize = 9.5f
            setTypeface(Typeface.MONOSPACE, Typeface.BOLD)
            setTextColor(riskColor)
            background = roundedBox(
                Color.argb(30, Color.red(riskColor), Color.green(riskColor), Color.blue(riskColor)),
                Color.argb(85, Color.red(riskColor), Color.green(riskColor), Color.blue(riskColor)),
                999f
            )
            setPadding((7 * d).toInt(), (2 * d).toInt(), (7 * d).toInt(), (2 * d).toInt())
        }
        val titleTv = TextView(context).apply {
            text = approval.title
            textSize = 12f
            setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
            setTextColor(p.textPrimary)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                marginStart = (8 * d).toInt()
            }
        }
        topRow.addView(riskBadge)
        topRow.addView(titleTv)
        card.addView(topRow)

        if (approval.description.isNotBlank()) {
            val descTv = TextView(context).apply {
                text = approval.description
                textSize = 11f
                setTextColor(p.textSecondary)
                maxLines = 2
                ellipsize = TextUtils.TruncateAt.END
            }
            card.addView(
                descTv,
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                    topMargin = (4 * d).toInt()
                }
            )
        }

        var editField: EditText? = null
        if (approvalEditVisible && approval.allowEdit) {
            editField = EditText(context).apply {
                tag = "approval_edit"
                setText(approval.commandPreview)
                setTextColor(p.textPrimary)
                setHintTextColor(p.textPlaceholder)
                hint = "Edit command..."
                textSize = 11.5f
                typeface = Typeface.MONOSPACE
                background = roundedBox(p.inputPillBg, p.borderAccent, 11f)
                setPadding((8 * d).toInt(), (6 * d).toInt(), (8 * d).toInt(), (6 * d).toInt())
                maxLines = 2
                contentDescription = "${HudModels.HUD_NODE_TAG_PREFIX}approval_edit_input"
                setOnClickListener { callbacks.onRequestInputFocus(this) }
            }
            card.addView(
                editField,
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                    topMargin = (6 * d).toInt()
                }
            )
        } else if (approval.commandPreview.isNotBlank()) {
            val cmdTv = TextView(context).apply {
                text = approval.commandPreview
                textSize = 11f
                typeface = Typeface.MONOSPACE
                setTextColor(p.accentDeep)
                background = roundedBox(p.innerBg, p.borderNeutral, 11f)
                setPadding((8 * d).toInt(), (6 * d).toInt(), (8 * d).toInt(), (6 * d).toInt())
                maxLines = 2
                ellipsize = TextUtils.TruncateAt.END
            }
            card.addView(
                cmdTv,
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                    topMargin = (6 * d).toInt()
                }
            )
        }

        val btnRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.END
        }
        val approveLabel = if (approvalEditVisible) "Send Edit" else "Approve"
        val approveBtn = pillTextButton(approveLabel, Color.WHITE, "#FF16A34A", null) {
            val edited = editField?.text?.toString()?.trim()
            val decision = if (approvalEditVisible && !edited.isNullOrBlank()) "EDIT" else "APPROVE"
            approvalEditVisible = false
            callbacks.onApprovalDecision(decision, edited)
        }.apply { contentDescription = "${HudModels.HUD_NODE_TAG_PREFIX}approval_approve_btn" }
        btnRow.addView(approveBtn)

        if (approval.allowEdit && !approvalEditVisible) {
            val editBtn = pillTextButtonColor("Edit", p.accentDeep, p.accentPillBg, p.accentPillBorder) {
                approvalEditVisible = true
                lastRenderKey = ""
                post {
                    val parentEdit = findViewWithTag<EditText>("approval_edit")
                    parentEdit?.let { callbacks.onRequestInputFocus(it) }
                }
                callbacks.onChessAction("APPROVAL_EDIT_OPEN", "", approval.id)
            }.apply { contentDescription = "${HudModels.HUD_NODE_TAG_PREFIX}approval_edit_btn" }
            btnRow.addView(
                editBtn,
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                    marginStart = (6 * d).toInt()
                }
            )
        }

        val denyBtn = pillTextButton("Deny", ACCENT_ROSE, "#1CE11D48", "#3CE11D48") {
            approvalEditVisible = false
            callbacks.onApprovalDecision("DENY", null)
        }.apply { contentDescription = "${HudModels.HUD_NODE_TAG_PREFIX}approval_deny_btn" }
        btnRow.addView(
            denyBtn,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                marginStart = (6 * d).toInt()
            }
        )

        card.addView(
            btnRow,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                topMargin = (8 * d).toInt()
            }
        )
        return card
    }

    // -------------------------------------------------------------------------
    // 3. Live Compact Chess Board & chess_autopilot Controls
    // -------------------------------------------------------------------------

    private fun buildChessCard(chess: ChessBoardState): View {
        val p = activePalette
        val card = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = frostedGlassCard(p.cardBgBottom, p.borderNeutral, 16f)
            setPadding((9 * d).toInt(), (8 * d).toInt(), (9 * d).toInt(), (8 * d).toInt())
            contentDescription = "${HudModels.HUD_NODE_TAG_PREFIX}chess_card"
        }

        val boardSize = (116 * d).toInt()
        val boardView = CompactChessBoardView(context, chess, p.accentPrimary).apply {
            contentDescription = "${HudModels.HUD_NODE_TAG_PREFIX}chess_board"
        }
        card.addView(boardView, LinearLayout.LayoutParams(boardSize + (12 * d).toInt(), boardSize))

        val rightCol = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                marginStart = (10 * d).toInt()
            }
        }

        val evalPawns = chess.evalCp / 100.0
        val evalText = String.format(Locale.US, "%+.1f", evalPawns)
        val headerTv = TextView(context).apply {
            text = "${chess.turnLabel} • $evalText"
            textSize = 11.5f
            setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
            setTextColor(p.textPrimary)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        rightCol.addView(headerTv)

        val moveLine = buildString {
            if (chess.bestMove.isNotBlank()) append("Best: ${chess.bestMove}")
            if (chess.lastMove.isNotBlank()) {
                if (isNotEmpty()) append("  •  ")
                append("Last: ${chess.lastMove}")
            }
            if (isEmpty() && chess.statusText.isNotBlank()) append(chess.statusText)
        }
        if (moveLine.isNotBlank()) {
            val moveTv = TextView(context).apply {
                text = moveLine
                textSize = 10.5f
                typeface = Typeface.MONOSPACE
                setTextColor(p.accentDeep)
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
            }
            rightCol.addView(
                moveTv,
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                    topMargin = (2 * d).toInt()
                }
            )
        }

        // Row 1: Best Move + Play 1 Move
        val row1 = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
        }
        row1.addView(
            pillTextButtonColor("Best Move", p.accentDeep, p.accentPillBg, p.accentPillBorder) {
                callbacks.onChessAction("PROMPT", "chess_autopilot: best move", "chess_best_move")
            }
        )
        row1.addView(
            pillTextButtonColor("Play 1 Move", p.textPrimary, p.iconSurfaceFill, p.iconSurfaceBorder) {
                callbacks.onChessAction("PROMPT", "chess_autopilot: play 1 move", "chess_play_one")
            },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                marginStart = (6 * d).toInt()
            }
        )
        rightCol.addView(
            row1,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                topMargin = (7 * d).toInt()
            }
        )

        // Row 2: Auto Play / Pause / Resume / Stop
        val row2 = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
        }
        when (chess.normalizedAutopilotState) {
            "RUNNING" -> {
                row2.addView(
                    pillTextButton("Pause", ACCENT_AMBER, "#22D97706", "#44D97706") {
                        callbacks.onChessAction("PAUSE", "chess_autopilot: pause", "chess_pause")
                    }
                )
                row2.addView(
                    pillTextButton("Stop", ACCENT_ROSE, "#1CE11D48", "#3CE11D48") {
                        callbacks.onChessAction("STOP", "chess_autopilot: stop", "chess_stop")
                    },
                    LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                        marginStart = (6 * d).toInt()
                    }
                )
            }
            "PAUSED" -> {
                row2.addView(
                    pillTextButton("Resume", ACCENT_EMERALD, "#2016A34A", "#4016A34A") {
                        callbacks.onChessAction("RESUME", "chess_autopilot: resume", "chess_resume")
                    }
                )
                row2.addView(
                    pillTextButton("Stop", ACCENT_ROSE, "#1CE11D48", "#3CE11D48") {
                        callbacks.onChessAction("STOP", "chess_autopilot: stop", "chess_stop")
                    },
                    LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                        marginStart = (6 * d).toInt()
                    }
                )
            }
            else -> {
                row2.addView(
                    pillTextButtonColor("Auto Play", Color.WHITE, p.accentPrimary, null) {
                        callbacks.onChessAction("PROMPT", "chess_autopilot: start auto play", "chess_auto_play")
                    }
                )
            }
        }
        rightCol.addView(
            row2,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                topMargin = (6 * d).toInt()
            }
        )

        card.addView(rightCol)
        return card
    }

    // -------------------------------------------------------------------------
    // 4. Swipeable Media Carousel (ONLY Play/Pause + Mute/Unmute controls)
    // -------------------------------------------------------------------------

    private fun buildMediaCarousel(state: HudUiState, cardInnerWidthPx: Int): View {
        val pageWidth = cardInnerWidthPx.coerceAtLeast((240 * d).toInt())
        val items = state.mediaItems
        val activeIdx = state.mediaActiveIndex.coerceIn(0, (items.size - 1).coerceAtLeast(0))
        val activeItem = items.getOrNull(activeIdx)

        mediaController.bindItem(activeItem, autoPlay = state.mediaPlaying, muted = state.mediaMuted)

        val wrapper = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            contentDescription = "${HudModels.HUD_NODE_TAG_PREFIX}media_carousel"
        }

        val pagerRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
        }

        val horizontalPager = HorizontalScrollView(context).apply {
            isHorizontalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            contentDescription = "${HudModels.HUD_NODE_TAG_PREFIX}media_pager"
            addView(pagerRow, LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }

        items.forEachIndexed { idx, item ->
            val pageCard = buildMediaPageCard(
                item = item,
                pageWidth = pageWidth,
                isActive = idx == activeIdx,
                isPlaying = state.mediaPlaying,
                isMuted = state.mediaMuted
            )
            pagerRow.addView(pageCard, LinearLayout.LayoutParams(pageWidth, ViewGroup.LayoutParams.WRAP_CONTENT))
        }

        horizontalPager.setOnTouchListener { v, event ->
            if (event.actionMasked == MotionEvent.ACTION_UP || event.actionMasked == MotionEvent.ACTION_CANCEL) {
                val targetIndex = ((v.scrollX + pageWidth / 2f) / pageWidth).toInt()
                    .coerceIn(0, (items.size - 1).coerceAtLeast(0))
                horizontalPager.smoothScrollTo(targetIndex * pageWidth, 0)
                if (targetIndex != state.mediaActiveIndex) {
                    callbacks.onMediaPageSelected(targetIndex)
                }
                true
            } else {
                false
            }
        }

        horizontalPager.post {
            horizontalPager.scrollTo(activeIdx * pageWidth, 0)
        }

        wrapper.addView(horizontalPager)

        if (items.size > 1) {
            val dotsRow = LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
                setPadding(0, (6 * d).toInt(), 0, 0)
                contentDescription = "${HudModels.HUD_NODE_TAG_PREFIX}media_dots"
            }
            dotsRowRef = dotsRow
            updateCarouselDots(items.size, activeIdx)
            wrapper.addView(dotsRow)
        }

        return wrapper
    }

    private fun buildMediaPageCard(
        item: MediaCarouselItem,
        pageWidth: Int,
        isActive: Boolean,
        isPlaying: Boolean,
        isMuted: Boolean
    ): View {
        val p = activePalette
        val mediaHeight = if (item.isAudio && item.thumbnailUri.isBlank()) (72 * d).toInt() else (136 * d).toInt()

        val frame = FrameLayout(context).apply {
            background = frostedGlassCard(p.cardBgBottom, p.borderNeutral, 16f)
            clipToOutline = true
            layoutParams = ViewGroup.LayoutParams(pageWidth, mediaHeight)
            contentDescription = "${HudModels.HUD_NODE_TAG_PREFIX}media_item_${item.id}"
        }

        when {
            item.isVideo && isActive && item.uri.isNotBlank() && !item.isNowPlaying -> {
                val textureView = TextureView(context).apply {
                    contentDescription = "${HudModels.HUD_NODE_TAG_PREFIX}media_video_surface"
                    surfaceTextureListener = object : TextureView.SurfaceTextureListener {
                        override fun onSurfaceTextureAvailable(st: SurfaceTexture, width: Int, height: Int) {
                            releaseVideoSurface()
                            val surface = Surface(st)
                            activeVideoSurface = surface
                            mediaController.bindVideoSurface(surface)
                        }
                        override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, width: Int, height: Int) {}
                        override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean {
                            releaseVideoSurface()
                            return true
                        }
                        override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
                    }
                }
                frame.addView(textureView, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, mediaHeight))
            }
            item.isAudio -> {
                val audioRow = LinearLayout(context).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding((12 * d).toInt(), (10 * d).toInt(), (92 * d).toInt(), (10 * d).toInt())
                }
                val artUrl = item.thumbnailUri.ifBlank { "" }
                if (artUrl.isNotBlank()) {
                    val artView = ImageView(context).apply {
                        scaleType = ImageView.ScaleType.CENTER_CROP
                        background = roundedBox(p.innerBg, p.borderAccent, 11f)
                        clipToOutline = true
                    }
                    loadBitmapAsync(artUrl, artView)
                    audioRow.addView(artView, LinearLayout.LayoutParams((46 * d).toInt(), (46 * d).toInt()))
                } else {
                    val noteIcon = AgyAppleVectorIconView(context, AgyAppleVectorIconView.IconType.MUSIC_NOTE).apply {
                        glassStyle = AgyAppleVectorIconView.GlassStyle.GLASS_CIRCLE
                        glassFillColor = p.accentPillBg
                        glassBorderColor = p.accentPillBorder
                        iconTint = p.accentDeep
                        iconSizeDp = 18f
                        minTouchSizeDp = 42f
                    }
                    audioRow.addView(noteIcon, LinearLayout.LayoutParams((42 * d).toInt(), (42 * d).toInt()))
                }

                val infoCol = LinearLayout(context).apply {
                    orientation = LinearLayout.VERTICAL
                    layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                        marginStart = (10 * d).toInt()
                    }
                }
                infoCol.addView(TextView(context).apply {
                    text = item.title.ifBlank { if (item.isNowPlaying) "Now Playing" else "Audio Track" }
                    textSize = 12.5f
                    setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
                    setTextColor(p.textPrimary)
                    maxLines = 1
                    ellipsize = TextUtils.TruncateAt.END
                })
                val sub = item.subtitle.ifBlank { if (item.isNowPlaying) "System Media" else "Inline Audio" }
                infoCol.addView(TextView(context).apply {
                    text = sub
                    textSize = 11f
                    setTextColor(p.textSecondary)
                    maxLines = 1
                    ellipsize = TextUtils.TruncateAt.END
                })
                audioRow.addView(infoCol)
                frame.addView(audioRow, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, mediaHeight))
            }
            else -> {
                val imgView = ImageView(context).apply {
                    scaleType = ImageView.ScaleType.CENTER_CROP
                    setBackgroundColor(p.innerBg)
                    contentDescription = "${HudModels.HUD_NODE_TAG_PREFIX}media_image"
                }
                val imgSource = item.uri.ifBlank { item.thumbnailUri }
                if (imgSource.isNotBlank()) {
                    loadBitmapAsync(imgSource, imgView)
                }
                frame.addView(imgView, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, mediaHeight))

                if (item.title.isNotBlank()) {
                    val caption = TextView(context).apply {
                        text = item.title
                        textSize = 11f
                        setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
                        setTextColor(p.textPrimary)
                        maxLines = 1
                        ellipsize = TextUtils.TruncateAt.END
                        setBackgroundColor(p.cardBgTop)
                        setPadding((10 * d).toInt(), (5 * d).toInt(), (10 * d).toInt(), (5 * d).toInt())
                    }
                    frame.addView(
                        caption,
                        LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM)
                    )
                }
            }
        }

        // Overlay transport controls: STRICTLY ONLY Play/Pause and Mute/Unmute (zero extra chrome)
        if (item.hasPlayableTransport) {
            val controlsRow = LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                contentDescription = "${HudModels.HUD_NODE_TAG_PREFIX}media_controls"
            }

            val playPauseBtn = AgyAppleVectorIconView(
                context,
                if (isPlaying) AgyAppleVectorIconView.IconType.PAUSE_FILL else AgyAppleVectorIconView.IconType.PLAY_FILL
            ).apply {
                glassStyle = AgyAppleVectorIconView.GlassStyle.ACCENT_CIRCLE
                accentColor = p.accentPrimary
                iconTint = Color.WHITE
                iconSizeDp = 13f
                minTouchSizeDp = 34f
                contentDescription = "${HudModels.HUD_NODE_TAG_PREFIX}media_play_pause_btn"
                setOnClickListener { callbacks.onMediaPlayPause() }
                attachSpringPress(this)
            }

            val muteBtn = AgyAppleVectorIconView(
                context,
                if (isMuted) AgyAppleVectorIconView.IconType.SPEAKER_SLASH else AgyAppleVectorIconView.IconType.SPEAKER_WAVE
            ).apply {
                glassStyle = AgyAppleVectorIconView.GlassStyle.GLASS_CIRCLE
                glassFillColor = p.iconSurfaceFill
                glassBorderColor = p.iconSurfaceBorder
                iconTint = if (isMuted) ACCENT_AMBER else p.textPrimary
                iconSizeDp = 13f
                minTouchSizeDp = 34f
                contentDescription = "${HudModels.HUD_NODE_TAG_PREFIX}media_mute_btn"
                setOnClickListener { callbacks.onMediaMuteToggle() }
                attachSpringPress(this)
            }

            if (isActive) {
                playPauseBtnRef = playPauseBtn
                muteBtnRef = muteBtn
            }

            controlsRow.addView(playPauseBtn)
            controlsRow.addView(
                muteBtn,
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                    marginStart = (6 * d).toInt()
                }
            )

            val grav = if (item.isAudio && item.thumbnailUri.isBlank()) {
                Gravity.END or Gravity.CENTER_VERTICAL
            } else {
                Gravity.END or Gravity.BOTTOM
            }
            frame.addView(
                controlsRow,
                LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, grav).apply {
                    marginEnd = (8 * d).toInt()
                    bottomMargin = if (item.isAudio && item.thumbnailUri.isBlank()) 0 else (8 * d).toInt()
                }
            )
        }

        return frame
    }

    private fun updateTransportButtons(playing: Boolean, muted: Boolean) {
        playPauseBtnRef?.iconType = if (playing) {
            AgyAppleVectorIconView.IconType.PAUSE_FILL
        } else {
            AgyAppleVectorIconView.IconType.PLAY_FILL
        }
        muteBtnRef?.apply {
            iconType = if (muted) {
                AgyAppleVectorIconView.IconType.SPEAKER_SLASH
            } else {
                AgyAppleVectorIconView.IconType.SPEAKER_WAVE
            }
            iconTint = if (muted) ACCENT_AMBER else activePalette.textPrimary
        }
    }

    private fun updateCarouselDots(count: Int, activeIndex: Int) {
        val p = activePalette
        val row = dotsRowRef ?: return
        row.removeAllViews()
        for (i in 0 until count) {
            val active = i == activeIndex
            val dot = View(context).apply {
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = 99f * d
                    setColor(if (active) p.accentPrimary else p.borderNeutral)
                }
            }
            row.addView(
                dot,
                LinearLayout.LayoutParams(
                    if (active) (16 * d).toInt() else (5 * d).toInt(),
                    (5 * d).toInt()
                ).apply {
                    marginStart = (3 * d).toInt()
                    marginEnd = (3 * d).toInt()
                }
            )
        }
    }

    // -------------------------------------------------------------------------
    // 5. Summary Card, Task List, Hardware Chip & Quick Actions
    // -------------------------------------------------------------------------

    private fun buildSummaryCard(summaryText: String): View {
        val p = activePalette
        val tv = TextView(context).apply {
            text = summaryText
            textSize = 12f
            setTextColor(p.textPrimary)
            setLineSpacing(2.2f * d, 1f)
            maxLines = 5
            ellipsize = TextUtils.TruncateAt.END
            background = frostedGlassCard(p.cardBgBottom, p.borderNeutral, 16f)
            setPadding((12 * d).toInt(), (9 * d).toInt(), (12 * d).toInt(), (9 * d).toInt())
            contentDescription = "${HudModels.HUD_NODE_TAG_PREFIX}summary_card"
            setOnClickListener {
                try {
                    val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
                    cm?.setPrimaryClip(ClipData.newPlainText("Agy Summary", summaryText))
                    Toast.makeText(context, "Copied summary", Toast.LENGTH_SHORT).show()
                } catch (_: Throwable) {}
            }
            attachSpringPress(this, 0.97f)
        }
        return tv
    }

    private fun buildTasksCard(tasks: List<HudTaskItem>): View {
        val p = activePalette
        val col = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            background = frostedGlassCard(p.cardBgBottom, p.borderNeutral, 14f)
            setPadding((10 * d).toInt(), (8 * d).toInt(), (10 * d).toInt(), (8 * d).toInt())
            contentDescription = "${HudModels.HUD_NODE_TAG_PREFIX}tasks_card"
        }
        tasks.take(3).forEachIndexed { idx, task ->
            val bullet = when (task.status.uppercase()) {
                "DONE", "COMPLETED" -> "✓"
                "RUNNING", "WORKING", "IN_PROGRESS" -> "●"
                "FAILED", "ERROR" -> "✕"
                else -> "○"
            }
            val color = when (task.status.uppercase()) {
                "DONE", "COMPLETED" -> ACCENT_EMERALD
                "RUNNING", "WORKING", "IN_PROGRESS" -> p.accentDeep
                "FAILED", "ERROR" -> ACCENT_ROSE
                else -> p.textSecondary
            }
            val line = TextView(context).apply {
                text = "$bullet  ${task.title}"
                textSize = 11.5f
                setTypeface(Typeface.SANS_SERIF, if (task.status.uppercase() in setOf("RUNNING", "WORKING")) Typeface.BOLD else Typeface.NORMAL)
                setTextColor(color)
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
            }
            col.addView(
                line,
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                    if (idx > 0) topMargin = (3 * d).toInt()
                }
            )
        }
        return col
    }

    private fun buildChipAndActionsRow(chip: HardwareChip?, actions: List<QuickAction>): View {
        val p = activePalette
        val hScroll = HorizontalScrollView(context).apply {
            isHorizontalScrollBarEnabled = false
            isHorizontalFadingEdgeEnabled = true
            setFadingEdgeLength((14 * d).toInt())
            overScrollMode = View.OVER_SCROLL_NEVER
            contentDescription = "${HudModels.HUD_NODE_TAG_PREFIX}actions_row"
        }
        val row = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        if (chip != null) {
            val chipLabel = if (chip.detail.isNotBlank()) "${chip.label} • ${chip.detail}" else chip.label
            val chipTv = TextView(context).apply {
                text = chipLabel
                textSize = 10.5f
                setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
                setTextColor(ACCENT_EMERALD)
                background = roundedBox(Color.parseColor("#1A16A34A"), Color.parseColor("#4416A34A"), 999f)
                setPadding((10 * d).toInt(), (5 * d).toInt(), (10 * d).toInt(), (5 * d).toInt())
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
                contentDescription = "${HudModels.HUD_NODE_TAG_PREFIX}hardware_chip"
            }
            row.addView(
                chipTv,
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                    marginEnd = (6 * d).toInt()
                }
            )
        }

        actions.take(3).forEachIndexed { idx, qa ->
            val btn = TextView(context).apply {
                text = "✦ ${qa.label}"
                textSize = 11f
                setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
                setTextColor(p.textPrimary)
                background = roundedBox(p.cardBgTop, p.borderAccent, 999f)
                setPadding((12 * d).toInt(), (6 * d).toInt(), (12 * d).toInt(), (6 * d).toInt())
                maxLines = 1
                contentDescription = "${HudModels.HUD_NODE_TAG_PREFIX}quick_action_${qa.id}"
                setOnClickListener { callbacks.onQuickActionClick(qa) }
                attachSpringPress(this)
            }
            row.addView(
                btn,
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                    if (idx < actions.size - 1) marginEnd = (6 * d).toInt()
                }
            )
        }

        hScroll.addView(row)
        return hScroll
    }

    // -------------------------------------------------------------------------
    // Helpers
    // -------------------------------------------------------------------------

    private fun releaseVideoSurface() {
        try {
            mediaController.bindVideoSurface(null)
            activeVideoSurface?.release()
        } catch (_: Throwable) {}
        activeVideoSurface = null
    }

    private fun loadBitmapAsync(source: String, target: ImageView) {
        bitmapCache.get(source)?.let { cached ->
            if (!cached.isRecycled) {
                target.setImageBitmap(cached)
                return
            }
        }
        target.tag = source
        imageExecutor.execute {
            val bmp = try {
                when {
                    source.startsWith("data:image", ignoreCase = true) -> {
                        val b64 = source.substringAfter("base64,", "")
                        val bytes = Base64.decode(b64, Base64.DEFAULT)
                        BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                    }
                    source.startsWith("/") || source.startsWith("file://", ignoreCase = true) -> {
                        val path = if (source.startsWith("file://", ignoreCase = true)) {
                            source.removePrefix("file://")
                        } else source
                        val f = File(path)
                        if (f.exists()) BitmapFactory.decodeFile(f.absolutePath) else null
                    }
                    source.startsWith("http://", ignoreCase = true) || source.startsWith("https://", ignoreCase = true) -> {
                        val conn = (URL(source).openConnection() as HttpURLConnection).apply {
                            connectTimeout = 4500
                            readTimeout = 4500
                            instanceFollowRedirects = true
                        }
                        conn.inputStream.use { BitmapFactory.decodeStream(it) }
                    }
                    else -> null
                }
            } catch (_: Throwable) {
                null
            }
            if (bmp != null) {
                bitmapCache.put(source, bmp)
                mainHandler.post {
                    if (target.tag == source) {
                        target.setImageBitmap(bmp)
                    }
                }
            }
        }
    }

    private fun frostedGlassCard(fillColor: Int, strokeColor: Int, radiusDp: Float): GradientDrawable {
        return GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(
                activePalette.cardBgTop,
                fillColor
            )
        ).apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = radiusDp * d
            setStroke((1f * d).toInt().coerceAtLeast(1), strokeColor)
        }
    }

    private fun roundedBox(fillColor: Int, strokeColor: Int, radiusDp: Float): GradientDrawable {
        return GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = radiusDp * d
            setColor(fillColor)
            setStroke((1f * d).toInt().coerceAtLeast(1), strokeColor)
        }
    }

    private fun pillTextButton(
        label: String,
        textColor: Int,
        bgHex: String,
        strokeHex: String? = null,
        onClick: () -> Unit
    ): TextView = pillTextButtonColor(
        label = label,
        textColor = textColor,
        bgColor = Color.parseColor(bgHex),
        strokeColor = strokeHex?.let { Color.parseColor(it) },
        onClick = onClick
    )

    private fun pillTextButtonColor(
        label: String,
        textColor: Int,
        bgColor: Int,
        strokeColor: Int? = null,
        onClick: () -> Unit
    ): TextView {
        return TextView(context).apply {
            text = label
            textSize = 10.5f
            setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
            setTextColor(textColor)
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = 999f * d
                setColor(bgColor)
                if (strokeColor != null) {
                    setStroke((1f * d).toInt().coerceAtLeast(1), strokeColor)
                }
            }
            setPadding((10 * d).toInt(), (5 * d).toInt(), (10 * d).toInt(), (5 * d).toInt())
            setOnClickListener { onClick() }
            attachSpringPress(this)
        }
    }

    private fun attachSpringPress(view: View, pressedScale: Float = 0.92f) {
        view.setOnTouchListener { v, event ->
            if (!isReducedMotionEnabled()) {
                when (event.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        v.animate()
                            .scaleX(pressedScale)
                            .scaleY(pressedScale)
                            .setDuration(90L)
                            .setInterpolator(DecelerateInterpolator())
                            .start()
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        v.animate()
                            .scaleX(1f)
                            .scaleY(1f)
                            .setDuration(190L)
                            .setInterpolator(OvershootInterpolator(1.35f))
                            .start()
                    }
                }
            }
            false
        }
    }

    private fun isReducedMotionEnabled(): Boolean {
        return try {
            Settings.Global.getFloat(
                context.contentResolver,
                Settings.Global.ANIMATOR_DURATION_SCALE,
                1.0f
            ) == 0f
        } catch (_: Throwable) {
            false
        }
    }

    /**
     * Compact 8x8 Canvas Chess Board in fresh frosted ivory & cool sky-slate with vertical evalCp bar,
     * lastMove + bestMove highlights, rounded framing, and white/black orientation flip.
     */
    private class CompactChessBoardView(
        context: Context,
        private val chess: ChessBoardState,
        accentColor: Int = Color.parseColor("#0EA5E9")
    ) : View(context) {
        private val d = context.resources.displayMetrics.density.coerceAtLeast(1f)
        private val lightSqPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#F8FAFC") }
        private val darkSqPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#94A3B8") }
        private val lastMovePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#77F59E0B") }
        private val bestMovePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = ResolvedHudPalette.withAlpha(accentColor, 0.54f)
        }
        private val evalWhitePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#FFFFFF") }
        private val evalBlackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#334155") }
        private val evalBorderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 0.8f * d
            color = Color.parseColor("#330F172A")
        }
        private val piecePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textAlign = Paint.Align.CENTER
            typeface = Typeface.SANS_SERIF
        }
        private val clipPath = Path()

        private val board: Array<CharArray> = parseFenBoard(chess.fen)

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val w = width.toFloat()
            val h = height.toFloat()
            if (w <= 0f || h <= 0f) return

            val barW = 7f * d
            val gap = 4f * d
            val boardSide = min(w - barW - gap, h)
            val boardLeft = barW + gap
            val boardTop = (h - boardSide) / 2f

            // Eval bar
            val clampedCp = chess.evalCp.coerceIn(-800, 800)
            val whiteRatio = ((clampedCp + 800f) / 1600f).coerceIn(0.06f, 0.94f)
            val barRect = RectF(0f, boardTop, barW, boardTop + boardSide)
            canvas.drawRoundRect(barRect, 3.5f * d, 3.5f * d, evalBlackPaint)
            val whiteTop = boardTop + boardSide * (1f - whiteRatio)
            canvas.drawRoundRect(RectF(0f, whiteTop, barW, boardTop + boardSide), 3.5f * d, 3.5f * d, evalWhitePaint)
            canvas.drawRoundRect(barRect, 3.5f * d, 3.5f * d, evalBorderPaint)

            val sq = boardSide / 8f
            val flip = chess.isBlackPerspective
            val lastSquares = parseUciSquares(chess.lastMove)
            val bestSquares = parseUciSquares(chess.bestMove)

            piecePaint.textSize = sq * 0.78f
            val fm = piecePaint.fontMetrics

            canvas.save()
            clipPath.reset()
            clipPath.addRoundRect(
                RectF(boardLeft, boardTop, boardLeft + boardSide, boardTop + boardSide),
                8f * d,
                8f * d,
                Path.Direction.CW
            )
            canvas.clipPath(clipPath)

            for (row in 0 until 8) {
                for (col in 0 until 8) {
                    val fenRow = if (flip) 7 - row else row
                    val fenCol = if (flip) 7 - col else col
                    val left = boardLeft + col * sq
                    val top = boardTop + row * sq

                    val isLight = (fenRow + fenCol) % 2 == 0
                    canvas.drawRect(left, top, left + sq, top + sq, if (isLight) lightSqPaint else darkSqPaint)

                    val sqKey = "${('a' + fenCol)}${8 - fenRow}"
                    if (sqKey in lastSquares) {
                        canvas.drawRect(left, top, left + sq, top + sq, lastMovePaint)
                    }
                    if (sqKey in bestSquares) {
                        canvas.drawRect(left, top, left + sq, top + sq, bestMovePaint)
                    }

                    val piece = board[fenRow][fenCol]
                    if (piece != ' ') {
                        val glyph = pieceToUnicode(piece)
                        piecePaint.color = if (piece.isUpperCase()) Color.parseColor("#0F172A") else Color.parseColor("#020617")
                        val cx = left + sq * 0.5f
                        val cy = top + sq * 0.5f - (fm.ascent + fm.descent) * 0.5f
                        canvas.drawText(glyph, cx, cy, piecePaint)
                    }
                }
            }
            canvas.restore()
        }

        private fun parseFenBoard(fen: String): Array<CharArray> {
            val grid = Array(8) { CharArray(8) { ' ' } }
            val ranks = fen.trim().substringBefore(' ').split('/')
            for (r in 0 until min(8, ranks.size)) {
                var c = 0
                for (ch in ranks[r]) {
                    if (c >= 8) break
                    if (ch in '1'..'8') {
                        c += (ch - '0')
                    } else {
                        grid[r][c] = ch
                        c++
                    }
                }
            }
            return grid
        }

        private fun parseUciSquares(move: String): Set<String> {
            val clean = move.trim().lowercase()
            if (clean.length < 4) return emptySet()
            return setOf(clean.substring(0, 2), clean.substring(2, 4))
        }

        private fun pieceToUnicode(ch: Char): String = when (ch) {
            'K' -> "♔"
            'Q' -> "♕"
            'R' -> "♖"
            'B' -> "♗"
            'N' -> "♘"
            'P' -> "♙"
            'k' -> "♚"
            'q' -> "♛"
            'r' -> "♜"
            'b' -> "♝"
            'n' -> "♞"
            'p' -> "♟"
            else -> ""
        }
    }
}
