package com.kavach.ui.overlay

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.util.Log
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import com.kavach.accessibility.models.AccessibilityNodeModel
import com.kavach.ui.overlay.hud.HudModels
import com.kavach.ui.overlay.hud.SnippedRegionContext
import com.kavach.ui.overlay.hud.SnippedUiNode
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONObject
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Full-screen translucent draw-box overlay (`agy_hud_snip`) allowing the user to lasso any
 * screen region and extract intersecting live Accessibility UI nodes with zero extra
 * MediaProjection permission prompts.
 */
class AgyRegionSnipOverlayManager(
    private val context: Context
) {
    companion object {
        private const val TAG = "AgyRegionSnipOverlay"
        const val NODE_TAG = "${HudModels.HUD_NODE_TAG_PREFIX}snip"
        private const val MIN_SELECTION_DP = 18f
        private val BOUNDS_REGEX = Regex("\\[(-?\\d+),(-?\\d+)]\\[(-?\\d+),(-?\\d+)]")

        fun parseBoundsRect(boundsStr: String?): Rect? {
            if (boundsStr.isNullOrBlank()) return null
            val m = BOUNDS_REGEX.find(boundsStr) ?: return null
            val l = m.groupValues[1].toIntOrNull() ?: return null
            val t = m.groupValues[2].toIntOrNull() ?: return null
            val r = m.groupValues[3].toIntOrNull() ?: return null
            val b = m.groupValues[4].toIntOrNull() ?: return null
            if (r <= l || b <= t) return null
            return Rect(l, t, r, b)
        }

        /**
         * Pure node-intersection extractor from live [AccessibilityNodeModel] trees.
         * Filters out any `agy_hud_*` self-overlay nodes, normalizes bounds, deduplicates
         * repetitive container labels, and caps results to [maxNodes] sorted by visual order.
         */
        fun extractNodesInRegion(
            roots: List<AccessibilityNodeModel>,
            x1: Int,
            y1: Int,
            x2: Int,
            y2: Int,
            screenWidth: Int,
            screenHeight: Int,
            fallbackPackage: String = "",
            maxNodes: Int = 24
        ): SnippedRegionContext {
            val sel = Rect(min(x1, x2), min(y1, y2), max(x1, x2), max(y1, y2))
            val collected = mutableListOf<SnippedUiNode>()
            val seenKeys = HashSet<String>()
            var detectedPkg = fallbackPackage.trim()

            fun walk(node: AccessibilityNodeModel) {
                val vid = node.viewId.orEmpty()
                val desc = node.contentDescription.orEmpty()
                val prefix = HudModels.HUD_NODE_TAG_PREFIX
                if (vid.contains(prefix, ignoreCase = true) || desc.contains(prefix, ignoreCase = true)) {
                    return
                }
                val r = parseBoundsRect(node.bounds)
                val intersects = r != null && Rect.intersects(r, sel)
                if (intersects && r != null) {
                    val pkg = node.packageName?.trim().orEmpty()
                    if (detectedPkg.isBlank() && pkg.isNotBlank() && pkg != contextPackagePlaceholder()) {
                        detectedPkg = pkg
                    }
                    val txt = node.text?.trim().orEmpty()
                    val cleanDesc = desc.trim()
                    val cleanVid = vid.trim()
                    val hasSignal = txt.isNotEmpty() || cleanDesc.isNotEmpty() || (node.isClickable && cleanVid.isNotEmpty())
                    if (hasSignal) {
                        val cx = (r.left + r.right) / 2
                        val cy = (r.top + r.bottom) / 2
                        val dedupKey = "${txt.lowercase()}|${cleanDesc.lowercase()}|${cx / 16}|${cy / 16}"
                        if (seenKeys.add(dedupKey)) {
                            collected.add(
                                SnippedUiNode(
                                    text = txt.take(160),
                                    contentDescription = cleanDesc.take(160),
                                    viewId = cleanVid.take(96),
                                    className = node.className.orEmpty().substringAfterLast('.').take(48),
                                    bounds = node.bounds,
                                    centerX = cx,
                                    centerY = cy,
                                    clickable = node.isClickable
                                )
                            )
                        }
                    }
                }
                for (child in node.children) {
                    walk(child)
                }
            }

            for (root in roots) {
                walk(root)
            }

            val sorted = collected
                .sortedWith(compareBy<SnippedUiNode> { it.centerY / 24 }.thenBy { it.centerX })
                .take(maxNodes)

            return SnippedRegionContext(
                x1 = sel.left,
                y1 = sel.top,
                x2 = sel.right,
                y2 = sel.bottom,
                screenWidth = screenWidth.coerceAtLeast(1),
                screenHeight = screenHeight.coerceAtLeast(1),
                packageName = detectedPkg,
                nodes = sorted
            )
        }

        /**
         * Overload accepting a JSON snapshot like `/api/ui/tree` (`{"nodes":[...]}`).
         */
        fun extractNodesFromTreeJson(
            treeJson: JSONObject?,
            x1: Int,
            y1: Int,
            x2: Int,
            y2: Int,
            screenWidth: Int,
            screenHeight: Int,
            fallbackPackage: String = "",
            maxNodes: Int = 24
        ): SnippedRegionContext {
            val sel = Rect(min(x1, x2), min(y1, y2), max(x1, x2), max(y1, y2))
            if (treeJson == null) {
                return SnippedRegionContext(
                    x1 = sel.left,
                    y1 = sel.top,
                    x2 = sel.right,
                    y2 = sel.bottom,
                    screenWidth = screenWidth.coerceAtLeast(1),
                    screenHeight = screenHeight.coerceAtLeast(1),
                    packageName = fallbackPackage.trim(),
                    nodes = emptyList()
                )
            }
            val roots = mutableListOf<AccessibilityNodeModel>()
            fun parseNode(obj: JSONObject?): AccessibilityNodeModel? {
                if (obj == null) return null
                val childrenArr = obj.optJSONArray("children")
                val kids = buildList {
                    if (childrenArr != null) {
                        for (i in 0 until childrenArr.length()) {
                            parseNode(childrenArr.optJSONObject(i))?.let { add(it) }
                        }
                    }
                }
                return AccessibilityNodeModel(
                    text = obj.optString("text", "").takeIf { it.isNotBlank() },
                    contentDescription = obj.optString("contentDescription", obj.optString("desc", "")).takeIf { it.isNotBlank() },
                    viewId = obj.optString("viewId", obj.optString("id", "")).takeIf { it.isNotBlank() },
                    className = obj.optString("className", obj.optString("class", "")).takeIf { it.isNotBlank() },
                    isClickable = obj.optBoolean("clickable", obj.optBoolean("isClickable", false)),
                    isScrollable = obj.optBoolean("scrollable", false),
                    isEditable = obj.optBoolean("editable", false),
                    isFocused = obj.optBoolean("focused", false),
                    bounds = obj.optString("bounds", ""),
                    children = kids,
                    packageName = obj.optString("packageName", "").takeIf { it.isNotBlank() }
                )
            }
            val arr = treeJson.optJSONArray("nodes")
            if (arr != null) {
                for (i in 0 until arr.length()) {
                    parseNode(arr.optJSONObject(i))?.let { roots.add(it) }
                }
            }
            val pkgFromTree = treeJson.optJSONObject("splitScreen")?.optString("targetPackage", "").orEmpty()
                .ifBlank { fallbackPackage }
            return extractNodesInRegion(
                roots = roots,
                x1 = x1,
                y1 = y1,
                x2 = x2,
                y2 = y2,
                screenWidth = screenWidth,
                screenHeight = screenHeight,
                fallbackPackage = pkgFromTree,
                maxNodes = maxNodes
            )
        }

        private fun contextPackagePlaceholder(): String = ""
    }

    data class CapturedRegionBitmap(
        val base64: String,
        val width: Int = 0,
        val height: Int = 0,
        val mimeType: String = "image/jpeg"
    )

    private val mainHandler = Handler(Looper.getMainLooper())
    private val captureExecutor = java.util.concurrent.Executors.newSingleThreadExecutor()
    private val windowManager: WindowManager? by lazy {
        context.getSystemService(Context.WINDOW_SERVICE) as? WindowManager
    }

    private val _isSnippingFlow = MutableStateFlow(false)
    val isSnippingFlow: StateFlow<Boolean> = _isSnippingFlow.asStateFlow()

    @Volatile
    private var rootOverlay: FrameLayout? = null

    @Volatile
    private var activeOnComplete: ((SnippedRegionContext) -> Unit)? = null

    @Volatile
    private var activeOnCancel: (() -> Unit)? = null

    private fun hasOverlayPermission(): Boolean {
        return Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(context)
    }

    private fun runOnMain(block: () -> Unit) {
        if (Looper.myLooper() == Looper.getMainLooper()) block() else mainHandler.post(block)
    }

    private fun resolveRealScreenSize(): Pair<Int, Int> {
        val wm = windowManager
        if (wm != null) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                try {
                    val b = wm.maximumWindowMetrics.bounds
                    if (b.width() > 0 && b.height() > 0) {
                        return b.width() to b.height()
                    }
                } catch (_: Throwable) {}
            } else {
                try {
                    val realDm = android.util.DisplayMetrics()
                    @Suppress("DEPRECATION")
                    wm.defaultDisplay?.getRealMetrics(realDm)
                    if (realDm.widthPixels > 0 && realDm.heightPixels > 0) {
                        return realDm.widthPixels to realDm.heightPixels
                    }
                } catch (_: Throwable) {}
            }
        }
        val dm = context.resources.displayMetrics
        return dm.widthPixels.coerceAtLeast(360) to dm.heightPixels.coerceAtLeast(640)
    }

    /**
     * Starts the full-screen region snip session.
     * [nodeTreeProvider] and [screenshotProvider] are queried right after release (and after the
     * scrim overlay is removed so the screenshot contains zero snip overlay artifacts).
     */
    fun startSnip(
        nodeTreeProvider: (() -> List<AccessibilityNodeModel>)? = null,
        foregroundPackageProvider: (() -> String?)? = null,
        screenshotProvider: ((x1: Int, y1: Int, x2: Int, y2: Int, screenWidth: Int, screenHeight: Int) -> CapturedRegionBitmap?)? = null,
        onComplete: (SnippedRegionContext) -> Unit,
        onCancel: () -> Unit = {}
    ): Boolean {
        if (!hasOverlayPermission()) {
            onCancel()
            return false
        }
        activeOnComplete = onComplete
        activeOnCancel = onCancel
        _isSnippingFlow.value = true

        runOnMain {
            removeOverlayViewOnly()
            val d = context.resources.displayMetrics.density.coerceAtLeast(1f)
            val (screenW, screenH) = resolveRealScreenSize()

            val root = FrameLayout(context).apply {
                contentDescription = NODE_TAG
                isClickable = true
                isFocusable = false
            }

            val canvasView = SnipDrawCanvasView(
                context = context,
                minDragPx = MIN_SELECTION_DP * d,
                onRegionCommitted = { rect ->
                    val selX1 = min(rect.left, rect.right).coerceIn(0, screenW)
                    val selY1 = min(rect.top, rect.bottom).coerceIn(0, screenH)
                    val selX2 = max(rect.left, rect.right).coerceIn(0, screenW)
                    val selY2 = max(rect.top, rect.bottom).coerceIn(0, screenH)

                    val cb = activeOnComplete
                    activeOnCancel = null

                    if (screenshotProvider == null) {
                        val nodes = try {
                            nodeTreeProvider?.invoke().orEmpty()
                        } catch (_: Throwable) {
                            emptyList()
                        }
                        val fgPkg = try {
                            foregroundPackageProvider?.invoke().orEmpty()
                        } catch (_: Throwable) {
                            ""
                        }
                        val captured = extractNodesInRegion(
                            roots = nodes,
                            x1 = selX1,
                            y1 = selY1,
                            x2 = selX2,
                            y2 = selY2,
                            screenWidth = screenW,
                            screenHeight = screenH,
                            fallbackPackage = fgPkg
                        )
                        dismissInternal(notifyCancel = false)
                        cb?.invoke(captured)
                    } else {
                        // Remove the translucent scrim overlay first so the screenshot is completely clean.
                        activeOnComplete = null
                        _isSnippingFlow.value = false
                        removeOverlayViewOnly()
                        mainHandler.postDelayed({
                            captureExecutor.execute {
                                val shot = try {
                                    screenshotProvider.invoke(selX1, selY1, selX2, selY2, screenW, screenH)
                                } catch (_: Throwable) {
                                    null
                                }
                                val nodes = try {
                                    nodeTreeProvider?.invoke().orEmpty()
                                } catch (_: Throwable) {
                                    emptyList()
                                }
                                val fgPkg = try {
                                    foregroundPackageProvider?.invoke().orEmpty()
                                } catch (_: Throwable) {
                                    ""
                                }
                                val baseCaptured = extractNodesInRegion(
                                    roots = nodes,
                                    x1 = selX1,
                                    y1 = selY1,
                                    x2 = selX2,
                                    y2 = selY2,
                                    screenWidth = screenW,
                                    screenHeight = screenH,
                                    fallbackPackage = fgPkg
                                )
                                val finalCaptured = if (shot != null && shot.base64.isNotBlank()) {
                                    baseCaptured.copy(
                                        screenshotBase64 = shot.base64,
                                        screenshotWidth = shot.width,
                                        screenshotHeight = shot.height,
                                        screenshotMimeType = shot.mimeType
                                    )
                                } else {
                                    baseCaptured
                                }
                                cb?.invoke(finalCaptured)
                            }
                        }, 95L)
                    }
                }
            ).apply {
                contentDescription = "${NODE_TAG}_canvas"
                layoutParams = FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
            }
            root.addView(canvasView)

            // Floating top instruction + Cancel bar (≥48dp touch target)
            val topBar = LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding((14 * d).toInt(), (8 * d).toInt(), (8 * d).toInt(), (8 * d).toInt())
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = 999f * d
                    setColor(Color.parseColor("#E60F172A"))
                    setStroke((1f * d).toInt().coerceAtLeast(1), Color.parseColor("#6600D4FF"))
                }
                elevation = 10f * d
                contentDescription = "${NODE_TAG}_topbar"
                layoutParams = FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply {
                    gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
                    topMargin = (42 * d).toInt()
                }
            }

            val hintTv = TextView(context).apply {
                text = "✂ Drag to snip any region"
                textSize = 12.5f
                setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
                setTextColor(Color.WHITE)
                setPadding(0, 0, (10 * d).toInt(), 0)
            }

            val cancelBtn = TextView(context).apply {
                text = "✕ Cancel"
                textSize = 12f
                setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
                setTextColor(Color.WHITE)
                gravity = Gravity.CENTER
                minWidth = (48 * d).toInt()
                minHeight = (48 * d).toInt()
                setPadding((14 * d).toInt(), (8 * d).toInt(), (14 * d).toInt(), (8 * d).toInt())
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = 999f * d
                    setColor(Color.parseColor("#E11D48"))
                }
                contentDescription = "${NODE_TAG}_cancel_btn"
                setOnClickListener {
                    dismissInternal(notifyCancel = true)
                }
            }

            topBar.addView(hintTv)
            topBar.addView(cancelBtn)
            root.addView(topBar)

            val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            } else {
                @Suppress("DEPRECATION")
                WindowManager.LayoutParams.TYPE_PHONE
            }
            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                overlayType,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.START
                title = NODE_TAG
            }

            try {
                windowManager?.addView(root, lp)
                rootOverlay = root
            } catch (e: Exception) {
                Log.w(TAG, "Failed adding snip overlay: ${e.message}")
                dismissInternal(notifyCancel = true)
            }
        }
        return true
    }

    fun cancelSnip() {
        runOnMain { dismissInternal(notifyCancel = true) }
    }

    fun hide() {
        runOnMain { dismissInternal(notifyCancel = false) }
    }

    private fun dismissInternal(notifyCancel: Boolean) {
        val cancelCb = activeOnCancel
        activeOnComplete = null
        activeOnCancel = null
        _isSnippingFlow.value = false
        removeOverlayViewOnly()
        if (notifyCancel) {
            cancelCb?.invoke()
        }
    }

    private fun removeOverlayViewOnly() {
        rootOverlay?.let { v ->
            try {
                windowManager?.removeView(v)
            } catch (_: Exception) {}
        }
        rootOverlay = null
    }

    /**
     * Full-screen drawing surface for interactive lasso selection with rounded cutout scrim,
     * animated-look corner brackets, and live dimension badge.
     */
    internal class SnipDrawCanvasView(
        context: Context,
        private val minDragPx: Float,
        private val onRegionCommitted: (Rect) -> Unit
    ) : View(context) {
        private val d = context.resources.displayMetrics.density.coerceAtLeast(1f)
        private val scrimPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(118, 10, 16, 28)
            style = Paint.Style.FILL
        }
        private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(90, 0, 212, 255)
            style = Paint.Style.STROKE
            strokeWidth = 7f * d
        }
        private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#00D4FF")
            style = Paint.Style.STROKE
            strokeWidth = 2.2f * d
            pathEffect = DashPathEffect(floatArrayOf(10f * d, 6f * d), 0f)
        }
        private val cornerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            style = Paint.Style.STROKE
            strokeWidth = 3.2f * d
            strokeCap = Paint.Cap.ROUND
        }
        private val badgeBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#E60F172A")
            style = Paint.Style.FILL
        }
        private val badgeTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#38BDF8")
            textSize = 11.5f * d
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        }
        private val scrimPath = Path()
        private val selectionRect = RectF()
        private var startX = 0f
        private var startY = 0f
        private var isDragging = false

        override fun onTouchEvent(event: MotionEvent): Boolean {
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    startX = event.rawX
                    startY = event.rawY
                    selectionRect.set(startX, startY, startX, startY)
                    isDragging = true
                    invalidate()
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    if (isDragging) {
                        val cx = event.rawX
                        val cy = event.rawY
                        selectionRect.set(
                            min(startX, cx),
                            min(startY, cy),
                            max(startX, cx),
                            max(startY, cy)
                        )
                        invalidate()
                    }
                    return true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (isDragging) {
                        isDragging = false
                        val w = abs(selectionRect.width())
                        val h = abs(selectionRect.height())
                        if (w >= minDragPx && h >= minDragPx) {
                            onRegionCommitted(
                                Rect(
                                    selectionRect.left.toInt(),
                                    selectionRect.top.toInt(),
                                    selectionRect.right.toInt(),
                                    selectionRect.bottom.toInt()
                                )
                            )
                        } else {
                            selectionRect.setEmpty()
                            invalidate()
                        }
                    }
                    return true
                }
            }
            return super.onTouchEvent(event)
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            scrimPath.reset()
            scrimPath.fillType = Path.FillType.EVEN_ODD
            scrimPath.addRect(0f, 0f, width.toFloat(), height.toFloat(), Path.Direction.CW)
            val hasBox = isDragging && selectionRect.width() > 4f && selectionRect.height() > 4f
            if (hasBox) {
                val r = 14f * d
                scrimPath.addRoundRect(selectionRect, r, r, Path.Direction.CW)
            }
            canvas.drawPath(scrimPath, scrimPaint)

            if (hasBox) {
                val r = 14f * d
                canvas.drawRoundRect(selectionRect, r, r, glowPaint)
                canvas.drawRoundRect(selectionRect, r, r, borderPaint)

                // Crisp L-brackets at corners
                val len = (14f * d).coerceAtMost(min(selectionRect.width(), selectionRect.height()) * 0.35f)
                val l = selectionRect.left
                val t = selectionRect.top
                val ri = selectionRect.right
                val b = selectionRect.bottom
                canvas.drawLine(l, t + len, l, t, cornerPaint)
                canvas.drawLine(l, t, l + len, t, cornerPaint)
                canvas.drawLine(ri - len, t, ri, t, cornerPaint)
                canvas.drawLine(ri, t, ri, t + len, cornerPaint)
                canvas.drawLine(l, b - len, l, b, cornerPaint)
                canvas.drawLine(l, b, l + len, b, cornerPaint)
                canvas.drawLine(ri - len, b, ri, b, cornerPaint)
                canvas.drawLine(ri, b, ri, b - len, cornerPaint)

                // Dimension pill above or inside selection
                val dimLabel = "${selectionRect.width().toInt()}×${selectionRect.height().toInt()}"
                val textW = badgeTextPaint.measureText(dimLabel)
                val padX = 10f * d
                val padY = 6f * d
                val pillW = textW + padX * 2f
                val pillH = badgeTextPaint.textSize + padY * 2f
                val pillLeft = l.coerceIn(8f * d, (width - pillW - 8f * d).coerceAtLeast(8f * d))
                val pillTop = if (t - pillH - 8f * d > 88f * d) t - pillH - 8f * d else t + 8f * d
                val pillRect = RectF(pillLeft, pillTop, pillLeft + pillW, pillTop + pillH)
                canvas.drawRoundRect(pillRect, 999f, 999f, badgeBgPaint)
                canvas.drawText(
                    dimLabel,
                    pillLeft + padX,
                    pillTop + padY + badgeTextPaint.textSize * 0.82f,
                    badgeTextPaint
                )
            }
        }
    }
}
