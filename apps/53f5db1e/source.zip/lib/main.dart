import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';

// The main quick-access buttons
const List<Permission> quickPermissions = [
  Permission.camera,
  Permission.location,
  Permission.microphone,
  Permission.photos,
  Permission.contacts,
  Permission.sensors,
  Permission.notification,
  Permission.bluetooth,
];

void main() {
  runApp(const PermissionTesterApp());
}

class PermissionTesterApp extends StatelessWidget {
  const PermissionTesterApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'AppForge Console',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
      home: const HomePage(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final Map<Permission, PermissionStatus> _statuses = {};
  
  // Console State
  final List<String> _logs = [];
  final TextEditingController _cmdController = TextEditingController();
  final ScrollController _scrollController = ScrollController();

  @override
  void initState() {
    super.initState();
    _log('AppForge Native Tester Initialized.');
    _log('Type "help" to see available commands.');
    
    for (var permission in quickPermissions) {
      _statuses[permission] = PermissionStatus.denied;
    }
    _checkInitialStatuses();
  }

  // --- CONSOLE LOGIC ---
  void _log(String message) {
    setState(() {
      _logs.add(message);
    });
    // Auto-scroll to bottom
    Future.delayed(const Duration(milliseconds: 50), () {
      if (_scrollController.hasClients) {
        _scrollController.jumpTo(_scrollController.position.maxScrollExtent);
      }
    });
  }

  void _handleCommand(String cmd) async {
    final command = cmd.trim();
    if (command.isEmpty) return;

    _log('> $command');
    _cmdController.clear();

    final parts = command.toLowerCase().split(' ');
    final action = parts[0];

    if (action == 'help') {
      _log('AVAILABLE COMMANDS:');
      _log('  request <permission>  (e.g., request sms)');
      _log('  status <permission>   (e.g., status location)');
      _log('  settings              (Opens app settings)');
      _log('  clear                 (Clears console)');
    } else if (action == 'clear') {
      setState(() => _logs.clear());
      _log('Console cleared.');
    } else if (action == 'settings') {
      _log('Opening Android OS App Settings...');
      await openAppSettings();
    } else if (action == 'request' && parts.length > 1) {
      await _executeDynamicPermission(parts[1], isRequest: true);
    } else if (action == 'status' && parts.length > 1) {
      await _executeDynamicPermission(parts[1], isRequest: false);
    } else {
      _log('Unknown command: "$action". Type "help".');
    }
  }

  Future<void> _requestFromButton(Permission permission) async {
    final name = permission.toString().split('.').last;
    _log('Button clicked: Requesting $name...');
    
    PermissionStatus status;

    // --- CRITICAL ANDROID 13+ LOGIC ---
    if (permission == Permission.photos) {
      // On Android 13+, asking for "storage" is banned. You must ask for photos.
      // But just to be safe, we ask for both, and if either is granted, it's a win.
      Map<Permission, PermissionStatus> statuses = await [
        Permission.photos,
        Permission.storage, // Fallback for Android 12 and below
      ].request();
      
      if (statuses[Permission.photos]!.isGranted || statuses[Permission.storage]!.isGranted) {
          status = PermissionStatus.granted;
      } else {
          status = PermissionStatus.denied;
      }
    } else {
      // Normal permission request
      status = await permission.request();
    }
    // -----------------------------------

    _log('Result for $name: ${status.name.toUpperCase()}');
    setState(() {
      _statuses[permission] = status;
    });
  }

  // --- BUTTON LOGIC ---
  Future<void> _checkInitialStatuses() async {
    _log('Checking quick-access statuses...');
    for (var permission in quickPermissions) {
      final status = await permission.status;
      setState(() {
        _statuses[permission] = status;
      });
    }
  }

  Future<void> _requestFromButton(Permission permission) async {
    final name = permission.toString().split('.').last;
    _log('Button clicked: Requesting $name...');
    final status = await permission.request();
    _log('Result for $name: ${status.name.toUpperCase()}');
    setState(() {
      _statuses[permission] = status;
    });
  }

  Color _getStatusColor(PermissionStatus status) {
    if (status.isGranted) return Colors.green;
    if (status.isPermanentlyDenied) return Colors.redAccent;
    if (status.isDenied) return Colors.orange;
    return Colors.grey;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
        title: const Text('AppForge Permission Tester'),
      ),
      body: Column(
        children: [
          // TOP HALF: Quick Access Buttons
          Expanded(
            flex: 3,
            child: ListView.builder(
              itemCount: quickPermissions.length,
              itemBuilder: (context, index) {
                final permission = quickPermissions[index];
                final status = _statuses[permission] ?? PermissionStatus.denied;
                final name = permission.toString().split('.').last.toUpperCase();

                return Card(
                  margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                  child: ListTile(
                    title: Text(name, style: const TextStyle(fontWeight: FontWeight.bold)),
                    subtitle: Text('Status: ${status.name}', style: TextStyle(color: _getStatusColor(status))),
                    trailing: ElevatedButton(
                      onPressed: status.isGranted ? null : () => _requestFromButton(permission),
                      child: const Text('Request'),
                    ),
                  ),
                );
              },
            ),
          ),
          
          // BOTTOM HALF: The Terminal Console
          Expanded(
            flex: 2,
            child: Container(
              color: Colors.black87,
              child: Column(
                children: [
                  // Log Output Area
                  Expanded(
                    child: ListView.builder(
                      controller: _scrollController,
                      padding: const EdgeInsets.all(8),
                      itemCount: _logs.length,
                      itemBuilder: (context, index) {
                        return Padding(
                          padding: const EdgeInsets.only(bottom: 4),
                          child: Text(
                            _logs[index],
                            style: const TextStyle(
                              fontFamily: 'monospace',
                              color: Colors.greenAccent,
                              fontSize: 13,
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                  
                  // Command Input Field
                  Container(
                    color: Colors.black,
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    child: Row(
                      children: [
                        const Text('> ', style: TextStyle(color: Colors.greenAccent, fontFamily: 'monospace', fontSize: 16)),
                        Expanded(
                          child: TextField(
                            controller: _cmdController,
                            style: const TextStyle(color: Colors.white, fontFamily: 'monospace'),
                            decoration: const InputDecoration(
                              border: InputBorder.none,
                              hintText: 'Enter command...',
                              hintStyle: TextStyle(color: Colors.white30),
                            ),
                            textInputAction: TextInputAction.send,
                            onSubmitted: _handleCommand,
                          ),
                        ),
                        IconButton(
                          icon: const Icon(Icons.send, color: Colors.greenAccent),
                          onPressed: () => _handleCommand(_cmdController.text),
                        )
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
