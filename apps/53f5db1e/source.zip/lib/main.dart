import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';

// This list defines all the permissions our app will test.
const List<Permission> permissionsToTest = [
  Permission.camera,
  Permission.location,
  Permission.microphone,
  Permission.photos,
  Permission.contacts,
  Permission.calendar,
  Permission.sensors,
  Permission.notification,
  Permission.bluetooth,
];

void main() {
  runApp(const PermissionTesterApp());
}

class PermissionTesterApp extends StatelessWidget {
  const PermissionTesterApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'AppForge Permission Tester',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
      home: const HomePage(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  // A map to store the current status of each permission.
  final Map<Permission, PermissionStatus> _statuses = {};

  @override
  void initState() {
    super.initState();
    // Initialize all statuses to a default value.
    for (var permission in permissionsToTest) {
      _statuses[permission] = PermissionStatus.denied;
    }
    _checkInitialStatuses();
  }

  // Check statuses when the app starts.
  Future<void> _checkInitialStatuses() async {
    for (var permission in permissionsToTest) {
      final status = await permission.status;
      setState(() {
        _statuses[permission] = status;
      });
    }
  }

  // The function that gets called when a button is tapped.
  Future<void> _requestPermission(Permission permission) async {
    final status = await permission.request();
    setState(() {
      _statuses[permission] = status;
    });
  }

  // Helper to get a readable name for each permission.
  String _getPermissionName(Permission permission) {
    return permission.toString().split('.').last.replaceAll('_', ' ').toUpperCase();
  }

  // Helper to color the status text.
  Color _getStatusColor(PermissionStatus status) {
    if (status.isGranted) return Colors.green.shade700;
    if (status.isPermanentlyDenied) return Colors.red.shade700;
    if (status.isDenied) return Colors.orange.shade700;
    return Colors.grey;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
        title: const Text('AppForge Permission Tester'),
      ),
      body: ListView.builder(
        itemCount: permissionsToTest.length,
        itemBuilder: (context, index) {
          final permission = permissionsToTest[index];
          final status = _statuses[permission]!;

          return Card(
            margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: ListTile(
              title: Text(
                _getPermissionName(permission),
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
              subtitle: Text(
                'Status: ${status.name}',
                style: TextStyle(
                  color: _getStatusColor(status),
                  fontWeight: FontWeight.w500,
                ),
              ),
              trailing: ElevatedButton(
                onPressed: () => _requestPermission(permission),
                style: ElevatedButton.styleFrom(
                  backgroundColor: status.isGranted ? Colors.grey : Theme.of(context).colorScheme.primary,
                  foregroundColor: Colors.white,
                ),
                child: const Text('Request'),
              ),
            ),
          );
        },
      ),
    );
  }
}
