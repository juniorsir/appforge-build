import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    code = f.read()

# Replace EditorHighlightTheme.DARK with EditorHighlightTheme.VS_CODE_DARK
code = code.replace("EditorHighlightTheme.DARK", "EditorHighlightTheme.VS_CODE_DARK")

# Now, add the other dark themes to all the `when` blocks that have VS_CODE_DARK -> ...
code = re.sub(
    r"(EditorHighlightTheme\.VS_CODE_DARK\s*->\s*(.+))",
    r"\1\n              EditorHighlightTheme.MONOKAI -> \2\n              EditorHighlightTheme.GITHUB_DARK -> \2\n              EditorHighlightTheme.ONE_DARK_PRO -> \2",
    code
)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(code)
