plugins {
  alias(libs.plugins.android.application)
  alias(libs.plugins.kotlin.compose)
//   alias(libs.plugins.google.devtools.ksp)
  alias(libs.plugins.roborazzi)
  alias(libs.plugins.chaquopy)
}

android {
  namespace = "com.example"
  compileSdk { version = release(36) { minorApiLevel = 1 } }

  defaultConfig {
    applicationId = "com.aistudio.pytoolkit.xytpqz"
    minSdk = 24
    targetSdk = 36
    versionCode = 1
    versionName = "1.0"

    testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"

    ndk {
      abiFilters += listOf("arm64-v8a", "x86_64")
    }
  }

  signingConfigs {
    create("release") {
      val keystorePath = System.getenv("KEYSTORE_PATH") ?: "${rootDir}/my-upload-key.jks"
      storeFile = file(keystorePath)
      storePassword = System.getenv("STORE_PASSWORD")
      keyAlias = "upload"
      keyPassword = System.getenv("KEY_PASSWORD")
    }
    create("debugConfig") {
      storeFile = file("${rootDir}/debug.keystore")
      storePassword = "android"
      keyAlias = "androiddebugkey"
      keyPassword = "android"
    }
  }

  buildTypes {
    release {
      isCrunchPngs = false
      isMinifyEnabled = false
      proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
      signingConfig = signingConfigs.getByName("release")
    }
    debug {
      signingConfig = signingConfigs.getByName("debugConfig")
    }
  }
  compileOptions {
    sourceCompatibility = JavaVersion.VERSION_11
    targetCompatibility = JavaVersion.VERSION_11
  }
  buildFeatures {
    compose = true
    buildConfig = true
  }
  testOptions { unitTests { isIncludeAndroidResources = true } }
}

chaquopy {
  defaultConfig {
    version = "3.10"
    buildPython("/usr/bin/python3")
    pip {
      install("pip")
      install("requests")
      install("numpy")
      install("pandas")
      install("beautifulsoup4")
      install("flask")
    }
  }
}

// Some unused dependencies are commented out below instead of being removed.
dependencies {
  implementation(platform(libs.androidx.compose.bom))
  implementation(platform(libs.firebase.bom))
  // implementation(libs.accompanist.permissions)
  implementation(libs.androidx.activity.compose)
  // implementation(libs.androidx.camera.camera2)
  // implementation(libs.androidx.camera.core)
  // implementation(libs.androidx.camera.lifecycle)
  // implementation(libs.androidx.camera.view)
  implementation(libs.androidx.compose.material.icons.core)
  // implementation(libs.androidx.compose.material.icons.extended)
  implementation(libs.androidx.compose.material3)
  implementation(libs.androidx.compose.ui)
  implementation(libs.androidx.compose.ui.graphics)
  implementation(libs.androidx.compose.ui.tooling.preview)
  implementation(libs.androidx.core.ktx)
  // implementation(libs.androidx.datastore.preferences)
  implementation(libs.androidx.lifecycle.runtime.compose)
  implementation(libs.androidx.lifecycle.runtime.ktx)
  implementation(libs.androidx.lifecycle.viewmodel.compose)
  // implementation(libs.androidx.navigation.compose)
  // implementation(libs.androidx.room.ktx)
  // implementation(libs.androidx.room.runtime)
  // implementation(libs.coil.compose)
  // implementation(libs.converter.moshi)
  // implementation(libs.firebase.ai)
  implementation(libs.kotlinx.coroutines.android)
  implementation(libs.kotlinx.coroutines.core)
  implementation(libs.logging.interceptor)
  // implementation(libs.moshi.kotlin)
  implementation(libs.okhttp)
  // implementation(libs.play.services.location)
  implementation(libs.retrofit)
  testImplementation(libs.androidx.compose.ui.test.junit4)
  testImplementation(libs.androidx.core)
  testImplementation(libs.androidx.junit)
  testImplementation(libs.junit)
  testImplementation(libs.kotlinx.coroutines.test)
  testImplementation(libs.robolectric)
  testImplementation(libs.roborazzi)
  testImplementation(libs.roborazzi.compose)
  testImplementation(libs.roborazzi.junit.rule)
  androidTestImplementation(platform(libs.androidx.compose.bom))
  androidTestImplementation(libs.androidx.compose.ui.test.junit4)
  androidTestImplementation(libs.androidx.espresso.core)
  androidTestImplementation(libs.androidx.junit)
  androidTestImplementation(libs.androidx.runner)
  debugImplementation(libs.androidx.compose.ui.test.manifest)
  debugImplementation(libs.androidx.compose.ui.tooling)
  // "ksp"(libs.androidx.room.compiler)
tasks.register("appendUI") {
    doLast {
        val file = file("src/main/java/com/example/MainActivity.kt")
        val content = """
@Composable
fun SearchReplaceBar(vm: PythonSandboxViewModel) {
  if (!vm.isSearchVisible) return
  val density = androidx.compose.ui.platform.LocalDensity.current
  val theme = vm.editorHighlightTheme
  val bg = if (theme == EditorHighlightTheme.LIGHT) Color(0xFFF3F3F3) else Color(0xFF252526)
  val border = if (theme == EditorHighlightTheme.LIGHT) Color(0xFFE4E4E4) else Color(0xFF444444)
  val textColor = if (theme == EditorHighlightTheme.LIGHT) Color.Black else Color.White
  val inputBg = if (theme == EditorHighlightTheme.LIGHT) Color.White else Color(0xFF3C3C3C)
  
  Column(
    modifier = Modifier
      .fillMaxWidth()
      .background(bg)
      .border(1.dp, border)
      .padding(8.dp)
  ) {
    Row(verticalAlignment = Alignment.CenterVertically) {
      Box(modifier = Modifier.weight(1f).background(inputBg, RoundedCornerShape(2.dp)).padding(4.dp)) {
        BasicTextField(
          value = vm.searchQuery,
          onValueChange = { vm.searchQuery = it; vm.currentMatchIndex = 0 },
          textStyle = TextStyle(color = textColor, fontSize = 12.sp, fontFamily = FontFamily.Monospace),
          modifier = Modifier.fillMaxWidth()
        )
        if (vm.searchQuery.isEmpty()) Text("Find", color = Color.Gray, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
      }
      
      Spacer(modifier = Modifier.width(4.dp))
      
      Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        Text("Aa", fontSize = 10.sp, color = if (vm.isSearchCaseSensitive) Color(0xFF007ACC) else textColor, modifier = Modifier.background(inputBg).clickable { vm.isSearchCaseSensitive = !vm.isSearchCaseSensitive }.padding(4.dp))
        Text("\\b", fontSize = 10.sp, color = if (vm.isSearchWholeWord) Color(0xFF007ACC) else textColor, modifier = Modifier.background(inputBg).clickable { vm.isSearchWholeWord = !vm.isSearchWholeWord }.padding(4.dp))
        Text(".*", fontSize = 10.sp, color = if (vm.isSearchRegex) Color(0xFF007ACC) else textColor, modifier = Modifier.background(inputBg).clickable { vm.isSearchRegex = !vm.isSearchRegex }.padding(4.dp))
      }
      
      Spacer(modifier = Modifier.width(8.dp))
      
      Icon(Icons.Default.KeyboardArrowUp, null, tint = textColor, modifier = Modifier.size(16.dp).clickable { if (vm.currentMatchIndex > 0) vm.currentMatchIndex-- })
      Icon(Icons.Default.KeyboardArrowDown, null, tint = textColor, modifier = Modifier.size(16.dp).clickable { if (vm.currentMatchIndex < vm.searchMatches.size - 1) vm.currentMatchIndex++ })
      Icon(Icons.Default.Close, null, tint = textColor, modifier = Modifier.size(16.dp).clickable { vm.isSearchVisible = false; vm.isReplaceVisible = false })
    }
    
    if (vm.isReplaceVisible) {
      Spacer(modifier = Modifier.height(4.dp))
      Row(verticalAlignment = Alignment.CenterVertically) {
        Box(modifier = Modifier.weight(1f).background(inputBg, RoundedCornerShape(2.dp)).padding(4.dp)) {
          BasicTextField(
            value = vm.replaceQuery,
            onValueChange = { vm.replaceQuery = it },
            textStyle = TextStyle(color = textColor, fontSize = 12.sp, fontFamily = FontFamily.Monospace),
            modifier = Modifier.fillMaxWidth()
          )
          if (vm.replaceQuery.isEmpty()) Text("Replace", color = Color.Gray, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
        }
        Spacer(modifier = Modifier.width(8.dp))
        Text("Replace", fontSize = 10.sp, color = textColor, modifier = Modifier.background(inputBg).clickable { 
          // Replace impl
        }.padding(4.dp))
        Text("All", fontSize = 10.sp, color = textColor, modifier = Modifier.background(inputBg).clickable { 
          // Replace All impl
        }.padding(4.dp))
      }
    }
  }
}

@Composable
fun MinimapPanel(vm: PythonSandboxViewModel) {
  if (!vm.showMinimap) return
  Box(modifier = Modifier.width(60.dp).fillMaxHeight().background(Color(0x22000000))) {
    // Minimap mock
  }
}

@Composable
fun BreadcrumbNav(vm: PythonSandboxViewModel, cursorIndex: Int) {
  val theme = vm.editorHighlightTheme
  val textColor = if (theme == EditorHighlightTheme.LIGHT) Color(0xFF6B6B6B) else Color(0xFFA0A0A0)
  val lines = vm.editorContent.split("\n")
  
  val lineIndex = vm.editorContent.substring(0, minOf(cursorIndex, vm.editorContent.length)).count { it == '\n' }
  var currentClass = ""
  var currentDef = ""
  for (i in 0..lineIndex) {
      val l = lines.getOrNull(i)?.trimEnd() ?: ""
      if (l.startsWith("class ")) { currentClass = l.removePrefix("class ").substringBefore(":"); currentDef = "" }
      if (l.startsWith("def ") || l.startsWith("    def ")) currentDef = l.trim().removePrefix("def ").substringBefore(":")
  }
  
  val path = mutableListOf("Project", vm.editorScriptName)
  if (currentClass.isNotEmpty()) path.add(currentClass)
  if (currentDef.isNotEmpty()) path.add(currentDef)
  
  Row(
    verticalAlignment = Alignment.CenterVertically,
    modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 2.dp)
  ) {
    path.forEachIndexed { idx, part ->
      Text(part, fontSize = 11.sp, fontFamily = FontFamily.Monospace, color = textColor)
      if (idx < path.size - 1) {
        Icon(Icons.Default.KeyboardArrowRight, null, tint = textColor, modifier = Modifier.size(12.dp).padding(horizontal = 2.dp))
      }
    }
  }
}
"""
        file.appendText("\n" + content)
    }
}

}

tasks.register("injectUI") {
    doLast {
        val file = file("src/main/java/com/example/MainActivity.kt")
        var code = file.readText()
        
        val replacement = """
    SearchReplaceBar(vm)
    BreadcrumbNav(vm, editorTextFieldValue.selection.start)
    Row(modifier = Modifier.weight(1f).fillMaxWidth()) {
      Row(
        modifier = Modifier
          .weight(1f)
          .fillMaxHeight()
          .background(vsCodeBackground)
          .border(0.5.dp, vsCodeBorder)
          .verticalScroll(rememberScrollState())
      ) {"""
      
        val target = """
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .weight(1f)
        .background(vsCodeBackground)
        .border(0.5.dp, vsCodeBorder)
        .verticalScroll(rememberScrollState())
    ) {"""
        
        code = code.replace(target, replacement)
        
        val targetEnd = """
          }
        }
      }
    }
  }
}"""
        
        val replacementEnd = """
          }
        }
      }
      MinimapPanel(vm)
    }
    
    if (vm.showCommandPalette) {
      Box(modifier = Modifier.fillMaxWidth().height(200.dp).background(Color(0xFF252526)).border(1.dp, Color(0xFF454545))) {
        Column {
            Text("Command Palette", color = Color.White, modifier = Modifier.padding(8.dp))
            BasicTextField(
              value = "Format",
              onValueChange = {},
              textStyle = TextStyle(color = Color.White, fontSize = 12.sp),
              modifier = Modifier.fillMaxWidth().padding(8.dp).background(Color(0xFF3C3C3C)).padding(4.dp)
            )
            Text("Format Document", color = Color.LightGray, modifier = Modifier.padding(8.dp))
            Text("Rename Symbol", color = Color.LightGray, modifier = Modifier.padding(8.dp))
            Text("Fold All", color = Color.LightGray, modifier = Modifier.padding(8.dp))
            Text("Unfold All", color = Color.LightGray, modifier = Modifier.padding(8.dp))
            Text("Toggle Minimap (Virtual)", color = Color.LightGray, modifier = Modifier.padding(8.dp))
        }
      }
    }
  }
}"""
        code = code.replace(targetEnd, replacementEnd)
        file.writeText(code)
    }
}

tasks.register("addThemes") {
    doLast {
        val file = file("src/main/java/com/example/MainActivity.kt")
        var code = file.readText()
        
        val vsCodeBlock = """        EditorHighlightTheme.VS_CODE_DARK -> {
            when (type) {
                1 -> SpanStyle(color = Color(0xFFB5CEA8), fontWeight = FontWeight.Normal)
                2 -> SpanStyle(color = Color(0xFF569CD6), fontStyle = FontStyle.Italic)
                3 -> SpanStyle(color = Color(0xFFDCDCAA), fontWeight = FontWeight.Normal)
                4 -> SpanStyle(color = Color(0xFFDCDCAA), fontWeight = FontWeight.Normal)
                5 -> SpanStyle(color = Color(0xFFDCDCAA), fontWeight = FontWeight.Normal)
                6 -> SpanStyle(color = Color(0xFF4EC9B0), fontWeight = FontWeight.Normal)
                7 -> SpanStyle(color = Color(0xFF569CD6), fontWeight = FontWeight.Normal)
                8 -> SpanStyle(color = Color(0xFFCE9178))
                9 -> SpanStyle(color = Color(0xFF6A9955), fontStyle = FontStyle.Normal)
                10 -> SpanStyle(color = Color(0xFFD4D4D4), fontWeight = FontWeight.Normal)
                11 -> SpanStyle(color = Color(0xFFD4D4D4), fontWeight = FontWeight.Normal)
                12 -> SpanStyle(color = Color(0xFF569CD6), fontWeight = FontWeight.Normal)
                13 -> SpanStyle(color = Color(0xFFC586C0), fontWeight = FontWeight.Normal)
                else -> SpanStyle(color = Color(0xFFD4D4D4))
            }
        }"""
        
        val monokaiBlock = """        EditorHighlightTheme.MONOKAI -> {
            when (type) {
                1 -> SpanStyle(color = Color(0xFFAE81FF), fontWeight = FontWeight.Normal)
                2 -> SpanStyle(color = Color(0xFF66D9EF), fontStyle = FontStyle.Italic)
                3 -> SpanStyle(color = Color(0xFFA6E22E), fontWeight = FontWeight.Normal)
                4 -> SpanStyle(color = Color(0xFFA6E22E), fontWeight = FontWeight.Normal)
                5 -> SpanStyle(color = Color(0xFFA6E22E), fontWeight = FontWeight.Normal)
                6 -> SpanStyle(color = Color(0xFF66D9EF), fontStyle = FontStyle.Italic)
                7 -> SpanStyle(color = Color(0xFFF92672), fontWeight = FontWeight.Normal)
                8 -> SpanStyle(color = Color(0xFFE6DB74))
                9 -> SpanStyle(color = Color(0xFF75715E), fontStyle = FontStyle.Normal)
                10 -> SpanStyle(color = Color(0xFFF8F8F2), fontWeight = FontWeight.Normal)
                11 -> SpanStyle(color = Color(0xFFF8F8F2), fontWeight = FontWeight.Normal)
                12 -> SpanStyle(color = Color(0xFFF92672), fontWeight = FontWeight.Normal)
                13 -> SpanStyle(color = Color(0xFFF92672), fontWeight = FontWeight.Normal)
                else -> SpanStyle(color = Color(0xFFF8F8F2))
            }
        }"""

        val githubDarkBlock = """        EditorHighlightTheme.GITHUB_DARK -> {
            when (type) {
                1 -> SpanStyle(color = Color(0xFF79C0FF), fontWeight = FontWeight.Normal)
                2 -> SpanStyle(color = Color(0xFF79C0FF), fontStyle = FontStyle.Italic)
                3 -> SpanStyle(color = Color(0xFFD2A8FF), fontWeight = FontWeight.Normal)
                4 -> SpanStyle(color = Color(0xFFD2A8FF), fontWeight = FontWeight.Normal)
                5 -> SpanStyle(color = Color(0xFFD2A8FF), fontWeight = FontWeight.Normal)
                6 -> SpanStyle(color = Color(0xFFFFA657), fontWeight = FontWeight.Normal)
                7 -> SpanStyle(color = Color(0xFFFF7B72), fontWeight = FontWeight.Normal)
                8 -> SpanStyle(color = Color(0xFFA5D6FF))
                9 -> SpanStyle(color = Color(0xFF8B949E), fontStyle = FontStyle.Normal)
                10 -> SpanStyle(color = Color(0xFFC9D1D9), fontWeight = FontWeight.Normal)
                11 -> SpanStyle(color = Color(0xFFC9D1D9), fontWeight = FontWeight.Normal)
                12 -> SpanStyle(color = Color(0xFFFF7B72), fontWeight = FontWeight.Normal)
                13 -> SpanStyle(color = Color(0xFFFF7B72), fontWeight = FontWeight.Normal)
                else -> SpanStyle(color = Color(0xFFC9D1D9))
            }
        }"""

        val oneDarkProBlock = """        EditorHighlightTheme.ONE_DARK_PRO -> {
            when (type) {
                1 -> SpanStyle(color = Color(0xFFD19A66), fontWeight = FontWeight.Normal)
                2 -> SpanStyle(color = Color(0xFF56B6C2), fontStyle = FontStyle.Italic)
                3 -> SpanStyle(color = Color(0xFF61AFEF), fontWeight = FontWeight.Normal)
                4 -> SpanStyle(color = Color(0xFF61AFEF), fontWeight = FontWeight.Normal)
                5 -> SpanStyle(color = Color(0xFF61AFEF), fontWeight = FontWeight.Normal)
                6 -> SpanStyle(color = Color(0xFFE5C07B), fontWeight = FontWeight.Normal)
                7 -> SpanStyle(color = Color(0xFFC678DD), fontWeight = FontWeight.Normal)
                8 -> SpanStyle(color = Color(0xFF98C379))
                9 -> SpanStyle(color = Color(0xFF7F848E), fontStyle = FontStyle.Normal)
                10 -> SpanStyle(color = Color(0xFFABB2BF), fontWeight = FontWeight.Normal)
                11 -> SpanStyle(color = Color(0xFFABB2BF), fontWeight = FontWeight.Normal)
                12 -> SpanStyle(color = Color(0xFFC678DD), fontWeight = FontWeight.Normal)
                13 -> SpanStyle(color = Color(0xFFC678DD), fontWeight = FontWeight.Normal)
                else -> SpanStyle(color = Color(0xFFABB2BF))
            }
        }"""
        
        val replacement = vsCodeBlock + "\n" + monokaiBlock + "\n" + githubDarkBlock + "\n" + oneDarkProBlock
        
        val searchFor = "        EditorHighlightTheme.VS_CODE_DARK,\nEditorHighlightTheme.MONOKAI,\nEditorHighlightTheme.GITHUB_DARK,\nEditorHighlightTheme.ONE_DARK_PRO -> {\n            when (type) {\n                1 -> SpanStyle(color = Color(0xFFB5CEA8), fontWeight = FontWeight.Normal)\n                2 -> SpanStyle(color = Color(0xFF569CD6), fontStyle = FontStyle.Italic)\n                3 -> SpanStyle(color = Color(0xFFDCDCAA), fontWeight = FontWeight.Normal)\n                4 -> SpanStyle(color = Color(0xFFDCDCAA), fontWeight = FontWeight.Normal)\n                5 -> SpanStyle(color = Color(0xFFDCDCAA), fontWeight = FontWeight.Normal)\n                6 -> SpanStyle(color = Color(0xFF4EC9B0), fontWeight = FontWeight.Normal)\n                7 -> SpanStyle(color = Color(0xFF569CD6), fontWeight = FontWeight.Normal)\n                8 -> SpanStyle(color = Color(0xFFCE9178))\n                9 -> SpanStyle(color = Color(0xFF6A9955), fontStyle = FontStyle.Normal)\n                10 -> SpanStyle(color = Color(0xFFD4D4D4), fontWeight = FontWeight.Normal)\n                11 -> SpanStyle(color = Color(0xFFD4D4D4), fontWeight = FontWeight.Normal)\n                12 -> SpanStyle(color = Color(0xFF569CD6), fontWeight = FontWeight.Normal)\n                13 -> SpanStyle(color = Color(0xFFC586C0), fontWeight = FontWeight.Normal)\n                else -> SpanStyle(color = Color(0xFFD4D4D4))\n            }\n        }"
        code = code.replace(searchFor, replacement)
        file.writeText(code)
    }
}