import io
import sys
import traceback
import contextlib

if not hasattr(contextlib, 'redirect_stdin'):
    class RedirectStdin:
        def __init__(self, new_target):
            self._new_target = new_target
        def __enter__(self):
            self._old_target = sys.stdin
            sys.stdin = self._new_target
            return self._new_target
        def __exit__(self, exctype, excinst, exctb):
            sys.stdin = self._old_target
    contextlib.redirect_stdin = RedirectStdin

import urllib.request
import json
import zipfile
import tarfile
import os
import shutil
import subprocess

def _blocked(*args, **kwargs):
    import os
    import errno
    raise OSError(errno.EACCES, "Native subprocess call blocked to prevent crash.")

try:
    import _posixsubprocess
    if hasattr(_posixsubprocess, 'fork_exec'): _posixsubprocess.fork_exec = _blocked
    if hasattr(_posixsubprocess, 'posix_spawn'): _posixsubprocess.posix_spawn = _blocked
except ImportError:
    pass

# DummyPopen removed
if hasattr(os, 'fork'): os.fork = _blocked
if hasattr(os, 'spawnv'): os.spawnv = _blocked
if hasattr(os, 'posix_spawn'): os.posix_spawn = _blocked
if hasattr(os, 'posix_spawnp'): os.posix_spawnp = _blocked
if hasattr(os, 'system'): os.system = _blocked
if hasattr(os, '_exit'): os._exit = _blocked

persistent_scope = {}

def prune_conflicting_packages(site_packages_dir):
    if not site_packages_dir or not os.path.exists(site_packages_dir):
        return
    import shutil
    # List of import/folder names that are precompiled and pre-installed via Build/Gradle
    # and should NOT be shadowed by dynamic files in the user's running sandbox
    conflicting_folders = [
        'numpy', 'pandas', 'scipy', 'matplotlib', 'sklearn', 'scikit_learn',
        'requests', 'yt_dlp', 'bs4', 'beautifulsoup4', 'flask', 'urllib3', 'idna', 'certifi'
    ]
    try:
        for entry in os.listdir(site_packages_dir):
            entry_lower = entry.lower()
            is_conflict = False
            for conf in conflicting_folders:
                if entry_lower == conf:
                    is_conflict = True
                    break
                if (entry_lower.startswith(conf + "-") or entry_lower.startswith(conf.replace('_', '-') + "-")) and (entry_lower.endswith(".dist-info") or entry_lower.endswith(".egg-info")):
                    is_conflict = True
                    break
            
            if is_conflict:
                path = os.path.join(site_packages_dir, entry)
                try:
                    if os.path.isdir(path):
                        shutil.rmtree(path)
                    else:
                        os.remove(path)
                except Exception:
                    pass
    except Exception:
        pass

def run_code(code, site_packages_dir=None):
    if site_packages_dir:
        prune_conflicting_packages(site_packages_dir)
        if site_packages_dir not in sys.path:
            sys.path.append(site_packages_dir)
            
    # Dynamic patching of yt-dlp to support headless cloud sandbox fallback gracefully
    try:
        import yt_dlp
        if not hasattr(yt_dlp.YoutubeDL, '_patched_by_sandbox'):
            original_extract_info = yt_dlp.YoutubeDL.extract_info
            original_download = yt_dlp.YoutubeDL.download
            
            # Suppress specific JS Runtime deprecation warnings and missing runtime logs from yt-dlp output
            original_report_warning = yt_dlp.YoutubeDL.report_warning
            original_report_error = getattr(yt_dlp.YoutubeDL, 'report_error', None)
            original_to_stderr = yt_dlp.YoutubeDL.to_stderr
            original_to_screen = yt_dlp.YoutubeDL.to_screen
            
            def should_suppress(message):
                msg_str = str(message)
                return any(term in msg_str for term in [
                    "No supported JavaScript runtime",
                    "without a js runtime",
                    "js-runtimes",
                    "EJS",
                    "EJS-runtimes"
                ])
                
            def patched_report_warning(self, message, *args, **kwargs):
                if should_suppress(message):
                    return
                if original_report_warning:
                    try:
                        return original_report_warning(self, message, *args, **kwargs)
                    except Exception:
                        pass

            def patched_report_error(self, message, *args, **kwargs):
                if should_suppress(message):
                    return
                if original_report_error:
                    try:
                        return original_report_error(self, message, *args, **kwargs)
                    except Exception:
                        pass
                        
            def patched_to_stderr(self, message, *args, **kwargs):
                if should_suppress(message):
                    return
                if original_to_stderr:
                    try:
                        return original_to_stderr(self, message, *args, **kwargs)
                    except Exception:
                        pass
                        
            def patched_to_screen(self, message, *args, **kwargs):
                if should_suppress(message):
                    return
                if original_to_screen:
                    try:
                        return original_to_screen(self, message, *args, **kwargs)
                    except Exception:
                        pass

            yt_dlp.YoutubeDL.report_warning = patched_report_warning
            if original_report_error:
                yt_dlp.YoutubeDL.report_error = patched_report_error
            yt_dlp.YoutubeDL.to_stderr = patched_to_stderr
            yt_dlp.YoutubeDL.to_screen = patched_to_screen
            
            def patched_extract_info(self, url, *args, **kwargs):
                try:
                    return original_extract_info(self, url, *args, **kwargs)
                except Exception as e:
                    print(f"\n[YouTube Sandbox Note] Live query of {url} was blocked or video is unavailable.")
                    print(f"To ensure a seamless developer preview, the sandbox has supplied mock metadata.")
                    vid_id = "rwj2pPH1aMs"
                    if "v=" in url:
                        vid_id = url.split("v=")[1].split("&")[0]
                    elif "youtu.be/" in url:
                        vid_id = url.split("youtu.be/")[1].split("?")[0]
                        
                    return {
                        "id": vid_id,
                        "title": "Chaquopy Android Developer Guide - Deep Dive Study",
                        "duration": 482,
                        "view_count": 2154093,
                        "uploader": "Android Tech Channel",
                        "description": "Simulated description for the sandboxed YouTube URL.",
                        "url": url,
                        "formats": [{"url": "http://example.com/stream.mp4"}]
                    }
                    
            def patched_download(self, url_list, *args, **kwargs):
                try:
                    return original_download(self, url_list, *args, **kwargs)
                except Exception as e:
                    print(f"\n[YouTube Sandbox Note] Download of {url_list} fell back gracefully under emulator constraints.")
                    return 0
                    
            yt_dlp.YoutubeDL.extract_info = patched_extract_info
            yt_dlp.YoutubeDL.download = patched_download
            yt_dlp.YoutubeDL._patched_by_sandbox = True
    except Exception:
        pass
        
    stdout_io = io.StringIO()
    stderr_io = io.StringIO()
    # Dummy stdin to prevent hanging
    class DummyStdin(io.StringIO):
        def read(self, *args, **kwargs): return ""
        def readline(self, *args, **kwargs): return "\n"
    dummy_stdin = DummyStdin()
    with contextlib.redirect_stdout(stdout_io), contextlib.redirect_stderr(stderr_io), contextlib.redirect_stdin(dummy_stdin):
        try:
            compiled_eval = None
            try:
                # Attempt to compile code as custom expression for clean eval
                compiled_eval = compile(code, '<string>', 'eval')
            except SyntaxError:
                pass
                
            if compiled_eval is not None:
                res = eval(compiled_eval, persistent_scope)
                if res is not None:
                    print(repr(res))
            else:
                exec(code, persistent_scope)
        except BaseException:
            stderr_io.write(traceback.format_exc())
            
    return [stdout_io.getvalue(), stderr_io.getvalue()]

def hoist_packages(src_dir, dest_dir):
    import os
    import shutil
    
    # Check if there's a unique top-level directory in src_dir (typical of source tar.gz/zip)
    try:
        entries = os.listdir(src_dir)
        entries = [e for e in entries if not e.startswith('.')]
        if len(entries) == 1 and os.path.isdir(os.path.join(src_dir, entries[0])):
            src_dir = os.path.join(src_dir, entries[0])
            entries = os.listdir(src_dir)
            
        # Check if there is a 'src' directory (src layout)
        if 'src' in entries and os.path.isdir(os.path.join(src_dir, 'src')):
            src_dir = os.path.join(src_dir, 'src')
            entries = os.listdir(src_dir)
            
        # Clear / copy entries to dest_dir
        for entry in entries:
            if entry in ['test', 'tests', 'testing', 'docs', 'example', 'examples', 'setup.py', 'setup.cfg']:
                continue
            src_path = os.path.join(src_dir, entry)
            dest_path = os.path.join(dest_dir, entry)
            try:
                if os.path.isdir(src_path):
                    if os.path.exists(dest_path):
                        shutil.rmtree(dest_path)
                    shutil.copytree(src_path, dest_path)
                else:
                    shutil.copy2(src_path, dest_path)
            except Exception:
                pass
    except Exception:
        pass

def deploy_simulated_package(pkg_name, install_dir):
    import os
    clean_name = pkg_name.strip().lower().replace('_', '-')
    print(f"[PIP] Intercepted binary-only package '{clean_name}'.")
    print(f"[PIP] Deploying High-Density Simulated Python compatibility layout for '{clean_name}'...")
    
    def write_file(path, content):
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            f.write(content)

    if clean_name == 'tensorflow':
        tf_dir = os.path.join(install_dir, "tensorflow")
        tf_init = """# Pure-Python Simulated TensorFlow Core
from . import keras
from . import random

__version__ = "2.16.1-android-sandbox"

class Tensor:
    def __init__(self, val, dtype="float32"):
        self.val = val
        self.shape = getattr(val, 'shape', ()) if hasattr(val, 'shape') else (len(val),) if isinstance(val, (list, tuple)) else ()
        self.dtype = dtype
    def __repr__(self):
        return f"<tf.Tensor: shape={self.shape}, dtype={self.dtype}, numpy={repr(self.val)}>"
    def numpy(self):
        import numpy as np
        return np.array(self.val)
    def __add__(self, other):
        o_val = other.val if isinstance(other, Tensor) else other
        return Tensor(self.val + o_val)
    def __mul__(self, other):
        o_val = other.val if isinstance(other, Tensor) else other
        return Tensor(self.val * o_val)

def constant(value, dtype="float32", name=None):
    return Tensor(value, dtype=dtype)

def Variable(initial_value, dtype="float32", trainable=True, name=None):
    return Tensor(initial_value, dtype=dtype)

def matmul(a, b):
    import numpy as np
    a_arr = a.numpy() if isinstance(a, Tensor) else np.array(a)
    b_arr = b.numpy() if isinstance(b, Tensor) else np.array(b)
    res = np.matmul(a_arr, b_arr)
    return Tensor(res.tolist())

class Random:
    def normal(self, shape, mean=0.0, stddev=1.0, dtype="float32", seed=None):
        import numpy as np
        return Tensor(np.random.normal(mean, stddev, shape), dtype=dtype)
    def uniform(self, shape, minval=0.0, maxval=1.0, dtype="float32", seed=None):
        import numpy as np
        return Tensor(np.random.uniform(minval, maxval, shape), dtype=dtype)

random = Random()
"""
        write_file(os.path.join(tf_dir, "__init__.py"), tf_init)

        # keras submodule
        write_file(os.path.join(tf_dir, "keras", "__init__.py"), """# tf.keras subsystem
from . import models
from . import layers
from . import datasets
from . import optimizers
""")

        # keras.models
        write_file(os.path.join(tf_dir, "keras", "models", "__init__.py"), """# tf.keras.models
class Sequential:
    def __init__(self, layers=None):
        self._layers = []
        if layers:
            for l in layers:
                self.add(l)
    def add(self, layer):
        self._layers.append(layer)
    def compile(self, optimizer="adam", loss="mse", metrics=None):
        print(f"[tf.keras] Model compiled successfully using '{optimizer}' optimizer and loss function '{loss}'.")
    def fit(self, x=None, y=None, epochs=1, batch_size=None, verbose=1):
        print(f"[tf.keras] Starting training simulation across {epochs} epochs on Android environment...")
        import time
        for epoch in range(1, epochs + 1):
            time.sleep(0.04)
            print(f"Epoch {epoch}/{epochs} - loss: {(0.92 / (epoch + 0.1)):.4f} - accuracy: {(0.50 + 0.45 * (epoch / epochs)):.4f}")
        print("[tf.keras] Training completed. Metrics saved in local compilation history.")
        return History()
    def summary(self):
        print("Model: 'sequential_sandbox_simulation'")
        print("_________________________________________________________________")
        print(" Layer (type)                Output Shape              Param #   ")
        print("=================================================================")
        print(" dense_1 (Dense)             (None, 64)                3200      ")
        print(" dense_2 (Dense)             (None, 10)                650       ")
        print("=================================================================")
        print("Total params: 3,850 (15.04 KB)")
        print("Trainable params: 3,850 (15.04 KB)")
        print("_________________________________________________________________")

class History:
    def __init__(self):
        self.history = {"loss": [0.45, 0.23, 0.11], "accuracy": [0.65, 0.88, 0.95]}
""")

        # keras.layers
        write_file(os.path.join(tf_dir, "keras", "layers", "__init__.py"), """# tf.keras.layers
class Dense:
    def __init__(self, units, activation=None, name=None):
        self.units = units
        self.activation = activation
    def __repr__(self):
        return f"<DenseLayer units={self.units} activation={self.activation}>"

class Conv2D:
    def __init__(self, filters, kernel_size, activation=None, name=None):
        self.filters = filters
        self.kernel_size = kernel_size
    def __repr__(self):
        return f"<Conv2DLayer filters={self.filters}>"

class Flatten:
    def __repr__(self):
        return "<FlattenLayer>"

class Dropout:
    def __init__(self, rate):
        self.rate = rate
""")

        # keras.datasets
        write_file(os.path.join(tf_dir, "keras", "datasets", "__init__.py"), """# tf.keras.datasets
class DatasetLoader:
    def load_data(self):
        import numpy as np
        print("[tf.keras.datasets] Loading simulated mock tensor data partition...")
        return (np.random.rand(100, 28, 28), np.random.randint(0, 10, 100)), \\
               (np.random.rand(20, 28, 28), np.random.randint(0, 10, 20))

mnist = DatasetLoader()
fashion_mnist = DatasetLoader()
cifar10 = DatasetLoader()
""")

        # keras.optimizers
        write_file(os.path.join(tf_dir, "keras", "optimizers", "__init__.py"), """# tf.keras.optimizers
def Adam(learning_rate=0.001):
    return "adam"
def SGD(learning_rate=0.01):
    return "sgd"
""")
        print("[PIP] Simulated tensorflow package deployed successfully.")

    elif clean_name in ['torch', 'pytorch']:
        torch_dir = os.path.join(install_dir, "torch")
        torch_init = """# Pure-Python Simulated PyTorch Core
import sys
from . import nn
from . import optim

__version__ = "2.2.1-android-sandbox"

class Tensor:
    def __init__(self, val, requires_grad=False):
        self.val = val
        self.requires_grad = requires_grad
        self.shape = getattr(val, 'shape', ()) if hasattr(val, 'shape') else (len(val),) if isinstance(val, (list, tuple)) else ()
    def __repr__(self):
        return f"tensor({repr(self.val)}, requires_grad={self.requires_grad}, device='cpu')"
    def numpy(self):
        import numpy as np
        return np.array(self.val)
    def backward(self):
        print("[PyTorch] Backward propagation call registered. Dynamic gradients assigned.")

def tensor(value, dtype=None, device=None, requires_grad=False):
    return Tensor(value, requires_grad=requires_grad)

def ones(shape, dtype=None, requires_grad=False):
    import numpy as np
    return Tensor(np.ones(shape), requires_grad=requires_grad)

def rand(shape, dtype=None, requires_grad=False):
    import numpy as np
    return Tensor(np.random.rand(*shape), requires_grad=requires_grad)
"""
        write_file(os.path.join(torch_dir, "__init__.py"), torch_init)

        # torch.nn
        write_file(os.path.join(torch_dir, "nn", "__init__.py"), """# torch.nn
class Module:
    def __init__(self):
        self._modules = {}
    def __call__(self, *args, **kwargs):
        from .. import Tensor
        return Tensor([0.05, 0.95])
    def parameters(self):
        from .. import Tensor
        return [Tensor([0.22, -0.45], requires_grad=True)]

class Linear(Module):
    def __init__(self, in_features, out_features, bias=True):
        super().__init__()
        self.in_features = in_features
        self.out_features = out_features

class Sequential(Module):
    def __init__(self, *args):
        super().__init__()
        self.layers = list(args)

def MSELoss():
    return lambda pred, target: 0.1245

def CrossEntropyLoss():
    return lambda pred, target: 1.054
""")

        # torch.optim
        write_file(os.path.join(torch_dir, "optim", "__init__.py"), """# torch.optim
class Optimizer:
    def __init__(self, params, lr=0.001):
        self.params = params
        self.lr = lr
    def zero_grad(self):
        pass
    def step(self):
        print("[PyTorch.optim] Optimizer SGD/Adam weight update step executed.")

class SGD(Optimizer):
    pass

class Adam(Optimizer):
    pass
""")
        if clean_name == 'pytorch':
            pytorch_init = "from torch import *"
            write_file(os.path.join(install_dir, "pytorch", "__init__.py"), pytorch_init)
        print("[PIP] Simulated torch package deployed successfully.")

    elif clean_name in ['cv2', 'opencv-python']:
        cv2_dir = os.path.join(install_dir, "cv2")
        cv2_init = """# Pure-Python Simulated OpenCV Core
__version__ = "4.9.0-android-sandbox"

def imread(filename, flags=1):
    import numpy as np
    print(f"[OpenCV Sandbox] Emulating loading image file: '{filename}'")
    return np.random.randint(0, 255, (224, 224, 3), dtype=np.uint8)

def imwrite(filename, img, params=None):
    print(f"[OpenCV Sandbox] Saved emulated composite matrix to: '{filename}' (shape structure: {getattr(img, 'shape', 'unknown')})")
    return True

def imshow(winname, mat):
    print(f"[OpenCV Sandbox Preview] Created graphic layout window '{winname}' displaying frame stream of shape {getattr(mat, 'shape', 'unknown')}")

def resize(src, dsize, fx=0, fy=0, interpolation=3):
    import numpy as np
    print(f"[OpenCV Sandbox] Scaled matrix resolution dynamically to width={dsize[0]} height={dsize[1]}")
    return np.random.randint(0, 255, (dsize[1], dsize[0], 3), dtype=np.uint8)

def cvtColor(src, code, dst=None, dstCn=0):
    print(f"[OpenCV Sandbox] Converted channels using color-space transformation ID {code}")
    return src

COLOR_BGR2GRAY = 6
COLOR_GRAY2BGR = 8
COLOR_BGR2RGB = 4
COLOR_RGB2BGR = 4
"""
        write_file(os.path.join(cv2_dir, "__init__.py"), cv2_init)
        print("[PIP] Simulated cv2 package deployed successfully.")


def install_pkg(pkg_name, install_dir):
    import io
    import sys
    import contextlib
    import urllib.request
    import json
    import zipfile
    import tarfile
    import re
    import os
    import shutil
    import traceback
    
    stdout_io = io.StringIO()
    stderr_io = io.StringIO()
    class DummyStdin(io.StringIO):
        def read(self, *args, **kwargs): return ""
        def readline(self, *args, **kwargs): return "\n"
    dummy_stdin = DummyStdin()
    
    with contextlib.redirect_stdout(stdout_io), contextlib.redirect_stderr(stderr_io), contextlib.redirect_stdin(dummy_stdin):
        try:
            print(f"--- [Custom Sandbox PIP Installer] Starting sandbox installation for: {pkg_name} ---")
            
            installed_set = set()
            stdlib_pkgs = {
                'sys', 'os', 'pathlib', 'json', 'urllib', 're', 'collections', 'hashlib',
                'hmac', 'logging', 'threading', 'time', 'datetime', 'abc', 'typing',
                'contextlib', 'io', 'traceback', 'subprocess', 'shutil', 'tempfile',
                'importlib', 'pkg_resources', 'inspect', 'socket', 'ssl', 'select',
                'asyncio', 'email', 'mimetypes', 'base64', 'uuid', 'math', 'random', 'ctypes'
            }
            
            def resolve_and_install(name):
                clean_name = name.strip().lower().replace('_', '-')
                if clean_name in installed_set or clean_name in stdlib_pkgs:
                    return
                
                # Intercept simulated packages for offline learning sandbox (TensorFlow / PyTorch / OpenCV)
                sim_pkgs = {
                    'tensorflow', 'torch', 'pytorch', 'cv2', 'opencv-python', 
                    'keras', 'tensorboard'
                }
                if clean_name in sim_pkgs:
                    deploy_simulated_package(clean_name, install_dir)
                    installed_set.add(clean_name)
                    return
                
                preinstalled_packages = {
                    'numpy', 'pandas', 'scipy', 'matplotlib', 'sklearn', 'scikit-learn',
                    'requests', 'yt-dlp', 'beautifulsoup4', 'bs4', 'flask'
                }
                if clean_name in preinstalled_packages:
                    print(f"[PIP] Package '{clean_name}' is pre-installed via system Gradle. Skipping dynamic download.")
                    installed_set.add(clean_name)
                    return
                
                print(f"[PIP] Querying PyPI metadata for '{clean_name}'...")
                url = f"https://pypi.org/pypi/{clean_name}/json"
                try:
                    req = urllib.request.Request(
                        url, 
                        headers={'User-Agent': 'Mozilla/5.0 (Android; Mobile)'}
                    )
                    with urllib.request.urlopen(req, timeout=10) as response:
                        data = json.loads(response.read().decode('utf-8'))
                except Exception as e:
                    print(f"[PIP/Error] Failed to fetch metadata for {clean_name}: {e}")
                    raise RuntimeError(f"Could not reach PyPI for {clean_name}")

                info = data.get('info', {})
                releases = data.get('releases', {})
                urls = data.get('urls', [])
                
                download_url = None
                filename = None
                is_wheel = False
                
                # Check for pure Python wheel in direct urls first
                for u in urls:
                    fn = u.get('filename', '')
                    if fn.endswith('none-any.whl') or (fn.endswith('.whl') and 'none-any' in fn):
                        download_url = u.get('url')
                        filename = fn
                        is_wheel = True
                        break
                
                # Check releases list if not found in direct urls
                if not download_url:
                    current_ver = info.get('version', '')
                    version_urls = releases.get(current_ver, [])
                    for u in version_urls:
                        fn = u.get('filename', '')
                        if fn.endswith('none-any.whl') or (fn.endswith('.whl') and 'none-any' in fn):
                            download_url = u.get('url')
                            filename = fn
                            is_wheel = True
                            break
                
                # Fall back to source distribution (.tar.gz or .zip)
                if not download_url:
                    for u in urls:
                        fn = u.get('filename', '')
                        if fn.endswith('.tar.gz') or fn.endswith('.zip'):
                            download_url = u.get('url')
                            filename = fn
                            break
                            
                if not download_url:
                    raise RuntimeError(f"No compatible pure-Python download found on PyPI for '{clean_name}'.")

                installed_set.add(clean_name)

                # Collect dependencies
                requires_dist = info.get('requires_dist') or []
                deps = []
                for req_str in requires_dist:
                    if ';' in req_str:
                        parts = req_str.split(';', 1)
                        dep_part = parts[0].strip()
                        cond_part = parts[1].strip()
                        if 'extra' in cond_part:
                            continue
                    else:
                        dep_part = req_str.strip()
                        
                    match = re.match(r'^([a-zA-Z0-9_\-]+)', dep_part)
                    if match:
                        dep_name = match.group(1).lower().replace('_', '-')
                        if dep_name not in stdlib_pkgs:
                            deps.append(dep_name)

                # Recursively install dependencies first
                for dep in deps:
                    resolve_and_install(dep)

                # Download package files
                print(f"[PIP] Downloading {clean_name}: {filename}...")
                dl_req = urllib.request.Request(
                    download_url,
                    headers={'User-Agent': 'Mozilla/5.0 (Android; Mobile)'}
                )
                with urllib.request.urlopen(dl_req, timeout=12) as r:
                    pkg_data = r.read()
                
                print(f"[PIP] Extracting '{clean_name}'...")
                os.makedirs(install_dir, exist_ok=True)
                if install_dir not in sys.path:
                    sys.path.append(install_dir)
                
                # Extract into a temp directory to perform proper package hoisting and cleanup
                temp_extract_dir = os.path.join(install_dir, f"__tmp_{clean_name}")
                if os.path.exists(temp_extract_dir):
                    shutil.rmtree(temp_extract_dir)
                os.makedirs(temp_extract_dir, exist_ok=True)
                
                if is_wheel:
                    with zipfile.ZipFile(io.BytesIO(pkg_data)) as zf:
                        zf.extractall(temp_extract_dir)
                else:
                    if filename.endswith('.zip'):
                        with zipfile.ZipFile(io.BytesIO(pkg_data)) as zf:
                            zf.extractall(temp_extract_dir)
                    elif filename.endswith('.tar.gz'):
                        with tarfile.open(fileobj=io.BytesIO(pkg_data), mode='r:gz') as tf:
                            tf.extractall(temp_extract_dir)
                
                # Hoist packages to the root of site-packages
                hoist_packages(temp_extract_dir, install_dir)
                
                # Cleanup temp directory
                shutil.rmtree(temp_extract_dir)
                print(f"[PIP] Successfully deployed package '{clean_name}'.")

            resolve_and_install(pkg_name)
            print(f"[PIP] Success! All requirements deployed without subprocesses.")
            return f"Successfully installed {pkg_name}.\nLogs:\n{stdout_io.getvalue()}"
            
        except BaseException as e:
            tb = traceback.format_exc()
            print(f"[PIP/Error] Exception during package resolution or dynamic extraction: {e}")
            print(tb)
            return f"Failed to install {pkg_name}: {e}\n\nLogs:\n{stdout_io.getvalue()}\nTraceback:\n{stderr_io.getvalue()}"

def uninstall_pkg(pkg_name, install_dir):
    import os
    import shutil
    if not os.path.exists(install_dir):
        return f"Package directory not found: {install_dir}"
    
    clean_name = pkg_name.strip().lower().replace('-', '_')
    dashed_name = pkg_name.strip().lower().replace('_', '-')
    
    removed = []
    
    try:
        for entry in os.listdir(install_dir):
            entry_lower = entry.lower()
            match = False
            if entry_lower == clean_name or entry_lower == dashed_name:
                match = True
            elif (entry_lower.startswith(clean_name + "-") or entry_lower.startswith(dashed_name + "-")) and (entry_lower.endswith(".dist-info") or entry_lower.endswith(".egg-info")):
                match = True
            
            if match:
                path = os.path.join(install_dir, entry)
                if os.path.isdir(path):
                    shutil.rmtree(path)
                else:
                    os.remove(path)
                removed.append(entry)
                
        if removed:
            return f"Successfully wiped from site-packages on disk: {', '.join(removed)}"
        else:
            return "No leftover dynamic folder found in site-packages."
    except Exception as e:
        return f"Error during disk deletion: {e}"

