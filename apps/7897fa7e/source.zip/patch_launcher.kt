        val videoPath = media.localPath.substringBefore("|STREAM_AUDIO_URL|")
        val audioPath = if (media.localPath.contains("|STREAM_AUDIO_URL|")) media.localPath.substringAfter("|STREAM_AUDIO_URL|") else null
        
        hasRenderedFirstFrame = false
        isBufferLoading = true
        playerError = null
        showExternalPlayerAlert = false
        fallbackFailureReport = null
        
        val fallbackOutputFileName = "playable_fallback_${media.id.hashCode()}.mp4"
        val fallbackOutputFile = java.io.File(context.cacheDir, fallbackOutputFileName)
        if (fallbackOutputFile.exists() && fallbackOutputFile.length() > 0) {
            cachedFallbackPath = fallbackOutputFile.absolutePath
        } else {
            cachedFallbackPath = null
        }

        val bgActive = com.example.media.BackgroundPlaybackManager.isBackgroundActive.value
        val bgMedia = com.example.media.BackgroundPlaybackManager.currentMedia.value
        val bgPos = if (bgActive) {
            if (bgMedia?.id == media.id) {
                val p = com.example.media.BackgroundPlaybackManager.currentPositionMs.value
                com.example.media.BackgroundPlaybackManager.stop(context)
                p
            } else {
                com.example.media.BackgroundPlaybackManager.stop(context)
                0L
            }
        } else 0L

        try {
            exoPlayer.stop()
            exoPlayer.clearMediaItems()
            
            if (cachedFallbackPath != null) {
                // Play from cache
                mediaEngine.prepareMedia(cachedFallbackPath!!, null, externalSubtitleUri)
            } else {
                val probeUri = when {
                    videoPath.startsWith("content://") || videoPath.startsWith("file://") || videoPath.startsWith("http://") || videoPath.startsWith("https://") -> android.net.Uri.parse(videoPath)
                    videoPath.startsWith("/") -> android.net.Uri.fromFile(java.io.File(videoPath))
                    else -> android.net.Uri.parse(videoPath)
                }
                
                isFallbackAnalysisInProgress = true
                val probeRes = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                    com.example.media.probe.MediaProbeEngine.probeMedia(context, probeUri)
                }
                
                if (probeRes.isSuccess) {
                    val pInfo = probeRes.getOrNull()
                    mediaEngine.setActiveProbeInfo(pInfo)
                    probeInfo = pInfo
                    
                    val strategy = mediaEngine.evaluatePlaybackStrategy(probeUri, null)
                    fallbackCompatibilityPlan = strategy
                    
                    if (strategy.strategy == com.example.media.playback.PlaybackStrategy.DIRECT_HARDWARE || strategy.strategy == com.example.media.playback.PlaybackStrategy.UNSUPPORTED) {
                        isFallbackAnalysisInProgress = false
                        mediaEngine.prepareMedia(videoPath, audioPath, externalSubtitleUri)
                    } else {
                        // Needs fallback
                        isFallbackAnalysisInProgress = false
                        isFallbackProcessingActive = true
                        
                        val flow = mediaEngine.executePlaybackFix(probeUri, fallbackOutputFile, strategy)
                        activeFallbackJob = kotlinx.coroutines.launch(kotlinx.coroutines.Dispatchers.IO) {
                            try {
                                flow.collect { progress ->
                                    fallbackProcessingProgress = progress
                                }
                                // Success
                                kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
                                    isFallbackProcessingActive = false
                                    cachedFallbackPath = fallbackOutputFile.absolutePath
                                    mediaEngine.prepareMedia(cachedFallbackPath!!, null, externalSubtitleUri)
                                    if (bgPos > 0L) exoPlayer.seekTo(bgPos)
                                    exoPlayer.playWhenReady = true
                                    exoPlayer.prepare()
                                    exoPlayer.play()
                                }
                            } catch (e: Exception) {
                                kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
                                    isFallbackProcessingActive = false
                                    fallbackFailureReport = e.message ?: "Fallback processing failed"
                                    showExternalPlayerAlert = true
                                }
                            }
                        }
                        return@LaunchedEffect // Don't proceed to play immediately
                    }
                } else {
                    isFallbackAnalysisInProgress = false
                    // Probe failed, attempt direct playback
                    mediaEngine.prepareMedia(videoPath, audioPath, externalSubtitleUri)
                }
            }
            
            if (bgPos > 0L) {
                exoPlayer.seekTo(bgPos)
            }
            exoPlayer.playWhenReady = true
            exoPlayer.repeatMode = androidx.media3.common.Player.REPEAT_MODE_ONE
            exoPlayer.prepare()
            exoPlayer.play()
            val initSize = exoPlayer.videoSize
            if (initSize.width > 0 && initSize.height > 0) {
                val rot = initSize.unappliedRotationDegrees
                if (rot == 90 || rot == 270) {
                    mediaVideoWidth = initSize.height
                    mediaVideoHeight = initSize.width
                } else {
                    mediaVideoWidth = initSize.width
                    mediaVideoHeight = initSize.height
                }
            }
        } catch (e: Exception) {
            val analysisReport = mediaEngine.analyzePlaybackFailure(
                androidx.media3.common.PlaybackException(e.message, e, androidx.media3.common.PlaybackException.ERROR_CODE_UNSPECIFIED),
                probeInfo
            )
            lastPlaybackReport = analysisReport
            playerError = analysisReport.toFormattedReport()
            showExternalPlayerAlert = true
        }
