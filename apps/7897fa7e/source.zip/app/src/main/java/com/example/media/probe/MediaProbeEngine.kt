package com.example.media.probe

import android.content.Context
import android.net.Uri
import android.util.Log
import com.example.media.storage.MediaUriResolver
import com.example.media.storage.TemporaryMediaManager
import com.arthenica.ffmpegkit.FFprobeKit
import com.arthenica.ffmpegkit.ReturnCode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject

object MediaProbeEngine {
    private const val TAG = "MediaProbeEngine"

    suspend fun probeMedia(context: Context, uri: Uri): Result<MediaProbeInfo> = withContext(Dispatchers.IO) {
        var resolvedSource = MediaUriResolver.resolveUriForFFmpeg(context, uri)
        if (resolvedSource == null) {
            return@withContext Result.failure(IllegalArgumentException("Could not resolve URI for probing: $uri"))
        }

        try {
            val pathOrSaf = resolvedSource.pathOrSaf
            Log.d(TAG, "Probing media at: $pathOrSaf")

            val session = FFprobeKit.getMediaInformation(pathOrSaf)
            val returnCode = session.returnCode
            val mediaInfo = session.mediaInformation

            if (!ReturnCode.isSuccess(returnCode) || mediaInfo == null) {
                val errorMsg = session.failStackTrace ?: session.allLogsAsString ?: "FFprobe returned error code: ${returnCode?.value}"
                Log.e(TAG, "FFprobe inspection failed: $errorMsg")
                return@withContext Result.failure(IllegalStateException("FFprobe failed to inspect media: $errorMsg"))
            }

            val format = mediaInfo.format ?: "unknown"
            val formatLongName = mediaInfo.longFormat
            val durationSec = mediaInfo.duration?.toDoubleOrNull() ?: 0.0
            val durationMs = (durationSec * 1000.0).toLong()
            val sizeBytes = mediaInfo.size?.toLongOrNull() ?: resolvedSource.sizeBytes
            val overallBitrate = mediaInfo.bitrate?.toLongOrNull() ?: 0L

            val videoStreams = mutableListOf<VideoStreamInfo>()
            val audioStreams = mutableListOf<AudioStreamInfo>()
            val subtitleStreams = mutableListOf<SubtitleStreamInfo>()
            val otherStreams = mutableListOf<OtherStreamInfo>()

            val streams = mediaInfo.streams ?: emptyList()
            for (stream in streams) {
                val type = stream.type?.lowercase()
                val index = stream.index?.toInt() ?: 0
                val codec = stream.codec ?: "unknown"
                val allProps = stream.allProperties
                val codecLong = allProps?.optString("codec_long_name") ?: stream.codec
                val codecTag = allProps?.optString("codec_tag_string")

                when (type) {
                    "video" -> {
                        val width = stream.width?.toInt() ?: 0
                        val height = stream.height?.toInt() ?: 0
                        val rFrameRate = stream.realFrameRate ?: stream.averageFrameRate ?: "0/1"
                        val fps = parseFpsFraction(rFrameRate)
                        val avgFps = parseFpsFraction(stream.averageFrameRate ?: "0/1")
                        val bitrate = stream.bitrate?.toLongOrNull() ?: 0L
                        val pixelFormat = allProps?.optString("pix_fmt")
                        val profile = allProps?.optString("profile")
                        val level = allProps?.optString("level")
                        val colorSpace = allProps?.optString("color_space")
                        val colorPrimaries = allProps?.optString("color_primaries")
                        val transferCharacteristics = allProps?.optString("color_transfer")
                        val streamDurationSec = allProps?.optString("duration")?.toDoubleOrNull() ?: 0.0
                        val streamDurationMs = (streamDurationSec * 1000.0).toLong()
                        val rotation = parseRotation(allProps)

                        val bitDepth = parseBitDepth(pixelFormat, allProps)
                        val chromaSubsampling = parseChromaSubsampling(pixelFormat)
                        val profileId = allProps?.optInt("profile", -1).takeIf { it != null && it >= 0 }
                        val levelId = allProps?.optInt("level", -1).takeIf { it != null && it >= 0 }
                        val hdrFormat = parseHdrFormat(transferCharacteristics, colorPrimaries, colorSpace)
                        
                        val tags = allProps?.optJSONObject("tags")
                        val lang = tags?.optString("language", "und") ?: "und"

                        val disposition = allProps?.optJSONObject("disposition")
                        val isDefault = disposition?.optInt("default") == 1
                        val isForced = disposition?.optInt("forced") == 1

                        videoStreams.add(
                            VideoStreamInfo(
                                index = index,
                                codec = codec,
                                codecLongName = codecLong,
                                codecTag = codecTag,
                                profile = profile,
                                level = level,
                                profileId = profileId,
                                levelId = levelId,
                                bitDepth = bitDepth,
                                chromaSubsampling = chromaSubsampling,
                                hdrFormat = hdrFormat,
                                width = width,
                                height = height,
                                frameRate = fps,
                                averageFrameRate = avgFps,
                                bitrate = bitrate,
                                durationMs = streamDurationMs,
                                pixelFormat = pixelFormat,
                                colorSpace = colorSpace,
                                colorPrimaries = colorPrimaries,
                                transferCharacteristics = transferCharacteristics,
                                rotation = rotation,
                                language = lang,
                                isDefault = isDefault,
                                isForced = isForced
                            )
                        )
                    }
                    "audio" -> {
                        val sampleRate = stream.sampleRate?.toIntOrNull() ?: 0
                        val channels = allProps?.optInt("channels") ?: 2
                        val channelLayout = allProps?.optString("channel_layout")
                        val sampleFormat = allProps?.optString("sample_fmt")
                        val profile = allProps?.optString("profile")
                        val bitrate = stream.bitrate?.toLongOrNull() ?: 0L
                        val streamDurationSec = allProps?.optString("duration")?.toDoubleOrNull() ?: 0.0
                        val streamDurationMs = (streamDurationSec * 1000.0).toLong()
                        
                        val tags = allProps?.optJSONObject("tags")
                        val lang = tags?.optString("language", "und") ?: "und"
                        val title = tags?.optString("title")
                        
                        val disposition = allProps?.optJSONObject("disposition")
                        val isDefault = disposition?.optInt("default") == 1
                        val isForced = disposition?.optInt("forced") == 1

                        audioStreams.add(
                            AudioStreamInfo(
                                index = index,
                                codec = codec,
                                codecLongName = codecLong,
                                codecTag = codecTag,
                                profile = profile,
                                sampleRate = sampleRate,
                                channels = channels,
                                channelLayout = channelLayout,
                                sampleFormat = sampleFormat,
                                bitrate = bitrate,
                                durationMs = streamDurationMs,
                                language = lang,
                                title = title,
                                isDefault = isDefault,
                                isForced = isForced
                            )
                        )
                    }
                    "subtitle" -> {
                        val tags = allProps?.optJSONObject("tags")
                        val lang = tags?.optString("language", "und") ?: "und"
                        val title = tags?.optString("title")
                        
                        val disposition = allProps?.optJSONObject("disposition")
                        val isDefault = disposition?.optInt("default") == 1
                        val isForced = disposition?.optInt("forced") == 1

                        subtitleStreams.add(
                            SubtitleStreamInfo(
                                index = index,
                                codec = codec,
                                language = lang,
                                title = title,
                                isDefault = isDefault,
                                isForced = isForced
                            )
                        )
                    }
                    else -> {
                        otherStreams.add(
                            OtherStreamInfo(
                                index = index,
                                type = type ?: "unknown",
                                codec = codec
                            )
                        )
                    }
                }
            }

            val metadataTags = mutableMapOf<String, String>()
            val tagsObj = mediaInfo.allProperties?.optJSONObject("format")?.optJSONObject("tags")
            if (tagsObj != null) {
                val keys = tagsObj.keys()
                while (keys.hasNext()) {
                    val key = keys.next()
                    metadataTags[key] = tagsObj.optString(key)
                }
            }

            val decoderCaps = try {
                com.example.media.DecoderCapabilityManager.detectAndroidDecoderCapabilities(videoStreams, audioStreams)
            } catch (t: Throwable) {
                null
            }

            val probeInfo = MediaProbeInfo(
                pathOrUri = uri.toString(),
                format = format,
                formatLongName = formatLongName,
                durationMs = durationMs,
                sizeBytes = sizeBytes,
                overallBitrate = overallBitrate,
                streamCount = streams.size,
                videoStreams = videoStreams,
                audioStreams = audioStreams,
                subtitleStreams = subtitleStreams,
                otherStreams = otherStreams,
                metadataTags = metadataTags,
                rawProperties = mediaInfo.allProperties?.toString(),
                androidDecoderCapability = decoderCaps
            )

            Log.i(TAG, "Successfully probed media: ${probeInfo.format}, ${videoStreams.size} video, ${audioStreams.size} audio")
            Result.success(probeInfo)

        } catch (e: Exception) {
            Log.e(TAG, "Exception during media probe: ${e.message}", e)
            Result.failure(e)
        } finally {
            if (resolvedSource?.isTemporaryFile == true) {
                TemporaryMediaManager.deleteSilently(resolvedSource.temporaryFile)
            }
        }
    }

    private fun parseFpsFraction(fraction: String): Float {
        return try {
            if (fraction.contains("/")) {
                val parts = fraction.split("/")
                val num = parts[0].toFloat()
                val den = parts[1].toFloat()
                if (den > 0) num / den else 0f
            } else {
                fraction.toFloat()
            }
        } catch (e: Exception) {
            0f
        }
    }

    private fun parseRotation(properties: JSONObject?): Int {
        if (properties == null) return 0
        try {
            val tags = properties.optJSONObject("tags")
            val rotate = tags?.optString("rotate")
            if (!rotate.isNullOrBlank()) {
                return rotate.toIntOrNull() ?: 0
            }

            val sideData = properties.optJSONArray("side_data_list")
            if (sideData != null) {
                for (i in 0 until sideData.length()) {
                    val item = sideData.optJSONObject(i)
                    val rotation = item?.optInt("rotation")
                    if (rotation != null && rotation != 0) return rotation
                }
            }
        } catch (_: Exception) {}
        return 0
    }

    private fun parseBitDepth(pixFmt: String?, allProps: JSONObject?): Int {
        val bitsFromProp = allProps?.optInt("bits_per_raw_sample", 0) ?: 0
        if (bitsFromProp > 0) return bitsFromProp

        val fmt = (pixFmt ?: "").lowercase()
        return when {
            fmt.contains("16") -> 16
            fmt.contains("14") -> 14
            fmt.contains("12") -> 12
            fmt.contains("10") -> 10
            fmt.contains("9") -> 9
            else -> 8
        }
    }

    private fun parseChromaSubsampling(pixFmt: String?): String {
        val fmt = (pixFmt ?: "").lowercase()
        return when {
            fmt.contains("444") -> "4:4:4"
            fmt.contains("422") -> "4:2:2"
            fmt.contains("420") -> "4:2:0"
            fmt.contains("411") -> "4:1:1"
            fmt.contains("410") -> "4:1:0"
            fmt.contains("nv12") || fmt.contains("nv21") -> "4:2:0"
            else -> "4:2:0"
        }
    }

    private fun parseHdrFormat(colorTransfer: String?, colorPrimaries: String?, colorSpace: String?): String? {
        val transfer = (colorTransfer ?: "").lowercase()
        val primaries = (colorPrimaries ?: "").lowercase()
        return when {
            transfer.contains("smpte2084") || transfer.contains("pq") -> "HDR10 / PQ"
            transfer.contains("arib-std-b67") || transfer.contains("hlg") -> "HLG"
            primaries.contains("bt2020") -> "BT.2020 (Wide Color Gamut)"
            else -> null
        }
    }
}
