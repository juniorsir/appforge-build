@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
package com.example.ui
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.type
import androidx.compose.ui.input.key.key
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.FocusRequester


import com.example.media.*
import com.example.player.gestures.*

import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRailItemDefaults
import android.content.Context
import android.util.Log
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures

import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.outlined.*
import androidx.compose.material3.*
import androidx.compose.material3.pulltorefresh.*
import androidx.compose.runtime.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.pager.PagerState
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.interaction.collectIsHoveredAsState
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import com.example.R
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.animation.core.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.PlaybackException
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.ui.PlayerView
import androidx.media3.ui.AspectRatioFrameLayout
import coil.compose.AsyncImage
import com.example.data.DownloadEntity
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.BackHandler
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.IntOffset
import kotlin.math.roundToInt
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.SpanStyle
import coil.imageLoader
// Theme Palette
data class SleekColors(
    val bg: Color,
    val card: Color,
    val surface: Color,
    val primary: Color,
    val accent: Color,
    val container: Color,
    val textPrimary: Color,
    val textSecondary: Color,
    val textMuted: Color,
    val border: Color,
    val failure: Color,
    val success: Color,
    val gradient: Brush
)
val LocalSleekColors = staticCompositionLocalOf<SleekColors> { error("No SleekColors provided") }

@Composable
fun getSleekColors(themeSettings: com.example.ui.theme.AppThemeSettings): SleekColors {
    val systemDark = isSystemInDarkTheme()
    return com.example.ui.theme.resolveSleekColorsFromSettings(themeSettings, systemDark)
}

@Composable
fun getSleekColors(themeMode: String): SleekColors {
    val mode = com.example.ui.theme.AppThemeMode.fromId(themeMode)
    val settings = com.example.ui.theme.AppThemeSettings(themeMode = mode)
    val systemDark = isSystemInDarkTheme()
    return com.example.ui.theme.resolveSleekColorsFromSettings(settings, systemDark)
}
// Global accessor shortcuts that bridge to the current theme
val SleekBg @Composable get() = LocalSleekColors.current.bg
val SleekCard @Composable get() = LocalSleekColors.current.card
val SleekCardDark @Composable get() = LocalSleekColors.current.surface
val SleekPurpleDark @Composable get() = LocalSleekColors.current.primary
val SleekPurpleLight @Composable get() = LocalSleekColors.current.accent
val SleekPurpleContainer @Composable get() = LocalSleekColors.current.container
val SleekTextPrimary @Composable get() = LocalSleekColors.current.textPrimary
val SleekTextSecondary @Composable get() = LocalSleekColors.current.textSecondary
val SleekTextMuted @Composable get() = LocalSleekColors.current.textMuted
val SleekBorderColor @Composable get() = LocalSleekColors.current.border
val CrimsonFailure @Composable get() = LocalSleekColors.current.failure
val EmeraldSuccess @Composable get() = LocalSleekColors.current.success
val HeroGradient @Composable get() = LocalSleekColors.current.gradient
// Backwards compatibility mappings for existing layouts
val SlateBg @Composable get() = SleekBg
val SlateCard @Composable get() = SleekCard
val SlateCardDark @Composable get() = SleekCardDark
val AmberAccent @Composable get() = SleekPurpleDark
val AmberAccentLight @Composable get() = SleekPurpleDark
val SilverText @Composable get() = SleekTextSecondary
val WhiteText @Composable get() = SleekTextPrimary

@OptIn(ExperimentalMaterial3Api::class, com.google.accompanist.permissions.ExperimentalPermissionsApi::class)
@Composable
fun VideoDownloaderScreen(
    viewModel: VideoDownloaderViewModel,
    modifier: Modifier = Modifier
) {
    val themeSettings by viewModel.appThemeSettings.collectAsStateWithLifecycle()
    val showAdvancedFormats by viewModel.showAdvancedFormats.collectAsStateWithLifecycle()
    val colors = getSleekColors(themeSettings)
    CompositionLocalProvider(LocalSleekColors provides colors) {
        val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current
    val initialPermissions = remember { com.example.util.DeviceCompatHelper.getRequiredPermissions() }
    val permissionState = com.google.accompanist.permissions.rememberMultiplePermissionsState(initialPermissions)
    var showPermissionDialog by remember { mutableStateOf(!permissionState.allPermissionsGranted) }
    LaunchedEffect(Unit) {
        if (!permissionState.allPermissionsGranted) {
            permissionState.launchMultiplePermissionRequest()
        }
    }
    if (!permissionState.allPermissionsGranted && showPermissionDialog) {
        androidx.compose.ui.window.Dialog(
            onDismissRequest = { showPermissionDialog = false },
            properties = androidx.compose.ui.window.DialogProperties(
                dismissOnBackPress = true,
                dismissOnClickOutside = false
            )
        ) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
                    .border(1.dp, SleekBorderColor, RoundedCornerShape(24.dp)),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = SleekCardDark)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(64.dp)
                            .background(SleekPurpleLight.copy(alpha = 0.1f), CircleShape)
                            .border(1.dp, SleekPurpleLight.copy(alpha = 0.3f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Lock,
                            contentDescription = null,
                            tint = SleekPurpleLight,
                            modifier = Modifier.size(32.dp)
                        )
                    }
                    Text(
                        text = "Permissions Required",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = SleekTextPrimary
                        ),
                        textAlign = TextAlign.Center
                    )
                    Text(
                        text = "To download media files, save them locally, convert to MP3, and post active download alerts, ꒯ꄲꅐꋊ꒒ꌦ needs storage and notifications access.",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = SleekTextSecondary,
                            lineHeight = 20.sp
                        ),
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = {
                                permissionState.launchMultiplePermissionRequest()
                                if (!permissionState.allPermissionsGranted) {
                                    try {
                                        val intent = android.content.Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                                            data = android.net.Uri.fromParts("package", context.packageName, null)
                                        }
                                        context.startActivity(intent)
                                    } catch (e: Exception) {
                                        // fallback ignore
                                    }
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color.White,
                                contentColor = Color.Black
                            ),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Default.Check, contentDescription = "Grant Access")
                        }
                        TextButton(
                            onClick = { showPermissionDialog = false },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.Close, contentDescription = "Skip for Now", tint = SleekTextMuted)
                        }
                    }
                }
            }
        }
    }
    val urlInput by viewModel.videoUrlInput.collectAsStateWithLifecycle()
    val isAnalyzing by viewModel.isAnalyzing.collectAsStateWithLifecycle()
    val analyzedVideo by viewModel.analyzedVideo.collectAsStateWithLifecycle()
    val analysisError by viewModel.analysisError.collectAsStateWithLifecycle()
    val activeDownloads by viewModel.activeDownloads.collectAsStateWithLifecycle()
    val downloadHistory by viewModel.downloadHistory.collectAsStateWithLifecycle()
    val deviceMedia by viewModel.deviceMedia.collectAsStateWithLifecycle()
    val searchHistory by viewModel.searchHistory.collectAsStateWithLifecycle()
    val browsingHistory by viewModel.browsingHistory.collectAsStateWithLifecycle()
    LaunchedEffect(permissionState.allPermissionsGranted) {
        if (permissionState.allPermissionsGranted) {
            viewModel.loadDeviceMedia(context)
        }
    }
    val executionLogs by viewModel.executionLogs.collectAsStateWithLifecycle()
    val isAudioOnly by viewModel.isAudioOnlyMode.collectAsStateWithLifecycle()
    val searchResults by viewModel.searchResults.collectAsStateWithLifecycle()
    val isSearching by viewModel.isSearching.collectAsStateWithLifecycle()
    val searchSuggestions by viewModel.searchSuggestions.collectAsStateWithLifecycle()
    val isIncognitoMode by viewModel.isIncognitoMode.collectAsStateWithLifecycle()
    val embedSubtitles by viewModel.embedSubtitles.collectAsStateWithLifecycle()
    val embedAutoSubtitles by viewModel.embedAutoSubtitles.collectAsStateWithLifecycle()
    val subtitleLanguages by viewModel.subtitleLanguages.collectAsStateWithLifecycle()
    val embedAudioMetadata by viewModel.embedAudioMetadata.collectAsStateWithLifecycle()
    val audioMultistreams by viewModel.audioMultistreams.collectAsStateWithLifecycle()
    val preferredAudioFormat by viewModel.preferredAudioFormat.collectAsStateWithLifecycle()
    val preferredAudioQuality by viewModel.preferredAudioQuality.collectAsStateWithLifecycle()
    val playerDecoderMode by viewModel.playerDecoderMode.collectAsStateWithLifecycle()
    val hardwareAcceleration by viewModel.hardwareAcceleration.collectAsStateWithLifecycle()
    val audioOutputMode by viewModel.audioOutputMode.collectAsStateWithLifecycle()
    val homeSelectedCategory by viewModel.homeSelectedCategory.collectAsStateWithLifecycle()
    val isYtdlpUpdateAvailable by viewModel.isYtdlpUpdateAvailable.collectAsStateWithLifecycle()
    val isYtdlpLoading by viewModel.isYtdlpLoading.collectAsStateWithLifecycle()
    val ytdlpLocalVersion by viewModel.ytdlpLocalVersion.collectAsStateWithLifecycle()
    
    val displayVersion = remember(ytdlpLocalVersion) {
        val pattern = java.util.regex.Pattern.compile("""\(([^)]+)\)""")
        val matcher = pattern.matcher(ytdlpLocalVersion)
        if (matcher.find()) {
            matcher.group(1)
        } else if (ytdlpLocalVersion.contains("JNI Core")) {
            "JNI"
        } else {
            ytdlpLocalVersion
        }
    }

    val playingMedia by viewModel.playingMedia.collectAsStateWithLifecycle()
    val currentWaveformData by viewModel.currentWaveformData.collectAsStateWithLifecycle()
    val isAudio = playingMedia?.let { isAudioMedia(it) } ?: false
    var isPlayerFullscreen by remember(playingMedia?.id, playingMedia?.localPath) {
        mutableStateOf(playingMedia != null && !isAudio)
    }

    val focusManager = androidx.compose.ui.platform.LocalFocusManager.current
    LaunchedEffect(isPlayerFullscreen) {
        if (isPlayerFullscreen) {
            focusManager.clearFocus()
        }
    }

    BackHandler(enabled = playingMedia != null && isPlayerFullscreen) {
        isPlayerFullscreen = false
    }

    var selectedTabIndex by remember { mutableStateOf(0) }
    
    LaunchedEffect(viewModel) {
        viewModel.navigateToTab.collect { tabIndex ->
            selectedTabIndex = tabIndex
        }
    }

    var showAboutDialog by remember { mutableStateOf(false) }
    var showTermsDialog by remember { mutableStateOf(false) }
    var showPrivacyDialog by remember { mutableStateOf(false) }
    var showAudioFxStudioDialog by remember { mutableStateOf(false) }
    var showBatchQueueModal by remember { mutableStateOf(false) }
    var editingMetadataItem by remember { mutableStateOf<DownloadEntity?>(null) }
    var schedulingVideoInfo by remember { mutableStateOf<Triple<String, String, VideoFormatUi>?>(null) }
    var playlistItemToAdd by remember { mutableStateOf<DownloadEntity?>(null) }
    var showCreatePlaylistModal by remember { mutableStateOf(false) }
    var isStreamLoading by remember { mutableStateOf(false) }
    var topBarOffsetHeightPx by remember { mutableFloatStateOf(0f) }
    val topBarHeightPx = with(androidx.compose.ui.platform.LocalDensity.current) { 100.dp.toPx() }
    val nestedScrollConnection = remember {
        object : androidx.compose.ui.input.nestedscroll.NestedScrollConnection {
            override fun onPreScroll(available: androidx.compose.ui.geometry.Offset, source: androidx.compose.ui.input.nestedscroll.NestedScrollSource): androidx.compose.ui.geometry.Offset {
                val delta = available.y
                val newOffset = topBarOffsetHeightPx + delta
                topBarOffsetHeightPx = newOffset.coerceIn(-topBarHeightPx, 0f)
                return androidx.compose.ui.geometry.Offset.Zero
            }
        }
    }
    val scope = rememberCoroutineScope()
    val isMobile = androidx.compose.ui.platform.LocalConfiguration.current.screenWidthDp < 600
    val isInSystemPipMode by viewModel.isInSystemPipMode.collectAsStateWithLifecycle()
    val activeTrimState by viewModel.activeTrimState.collectAsStateWithLifecycle()
    val activeCompressState by viewModel.activeCompressState.collectAsStateWithLifecycle()

    Scaffold(
        containerColor = SleekBg,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        topBar = {},
        bottomBar = {}
    ) { innerPadding ->
        if (isInSystemPipMode) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black)
            ) {
                playingMedia?.let { media ->
                    FloatingPlayerOverlay(
                        media = media,
                        isFullscreen = true,
                        onToggleFullscreen = {},
                        onClose = { viewModel.stopPlayingMedia() },
                        analyzedVideo = analyzedVideo,
                        onStreamFormat = null,
                        viewModel = viewModel
                    )
                } ?: Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "No active video",
                        color = Color.White,
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }
            return@Scaffold
        }

        Box(modifier = Modifier.fillMaxSize().nestedScroll(nestedScrollConnection)) {
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .background(SleekBg)
            ) {
            if (!isMobile && !isPlayerFullscreen) {
                LargeScreenNavigationDock(
                    selectedTabIndex = selectedTabIndex,
                    onTabSelected = { selectedTabIndex = it },
                    onQuickActionClick = {
                        selectedTabIndex = 0
                        if (urlInput.trim().isNotEmpty()) {
                            viewModel.analyzeVideo()
                        }
                    }
                )
            }
            Box(modifier = Modifier.weight(1f).fillMaxHeight()) {
                AnimatedContent(
                    targetState = selectedTabIndex,
                    transitionSpec = {
                        val isTowardsRight = targetState > initialState
                        val slideIn = androidx.compose.animation.slideInHorizontally(
                            animationSpec = androidx.compose.animation.core.spring(dampingRatio = 0.85f, stiffness = 400f)
                        ) { width -> if (isTowardsRight) (width * 0.12f).toInt() else -(width * 0.12f).toInt() } + 
                        androidx.compose.animation.fadeIn()
                        val slideOut = androidx.compose.animation.slideOutHorizontally(
                            animationSpec = androidx.compose.animation.core.spring(dampingRatio = 0.85f, stiffness = 400f)
                        ) { width -> if (isTowardsRight) -(width * 0.12f).toInt() else (width * 0.12f).toInt() } + 
                        androidx.compose.animation.fadeOut()
                        slideIn.togetherWith(slideOut).using(androidx.compose.animation.SizeTransform(clip = false))
                    },
                    label = "TabTransition"
                ) { targetTab ->
                    when (targetTab) {
                        0 -> DownloadTab(
                            urlInput = urlInput,
                            urlHistory = viewModel.urlHistory.collectAsStateWithLifecycle().value,
                            searchSuggestions = searchSuggestions,
                            isAnalyzing = isAnalyzing,
                            analyzedVideo = analyzedVideo,
                            analysisError = analysisError,
                            activeDownloads = activeDownloads,
                            executionLogs = executionLogs,
                            isAudioOnly = isAudioOnly,
                            searchResults = searchResults,
                            isSearching = isSearching,
                            onToggleAudioOnly = { viewModel.toggleAudioOnlyMode() },
                            onClearLogs = { viewModel.clearLogs() },
                            onUrlChange = { viewModel.updateUrlInput(it) },
                            onClearUrlHistory = { viewModel.clearUrlHistory() },
                            onPasteClick = {
                                clipboardManager.getText()?.text?.let { viewModel.updateUrlInput(it) }
                            },
                            onClearClick = { viewModel.updateUrlInput("") },
                            onAnalyzeClick = { viewModel.analyzeVideo() },
                            onDownloadFormat = { format ->
                                analyzedVideo?.let { video ->
                                    viewModel.startDownload(video, format)
                                }
                            },
                            onStreamFormat = { format ->
                                analyzedVideo?.let { video ->
                                    fun isAudioFormat(fmt: VideoFormatUi): Boolean {
                                        val type = fmt.type.lowercase()
                                        val qual = fmt.quality.lowercase()
                                        val ext = fmt.ext.lowercase()
                                        return type == "audio" || 
                                               (fmt.vcodec == "none" && fmt.acodec != null && fmt.acodec != "none") ||
                                               qual.contains("kbps") || qual.contains("audio") ||
                                               ext == "mp3" || ext == "m4a" || ext == "aac" || ext == "opus" || ext == "wav" || ext == "flac" || ext == "ogg"
                                    }

                                    val isAudio = isAudioFormat(format)
                                    val isVideoOnly = !isAudio && (format.acodec == "none" || format.acodec.isBlank() || !format.hasAudio || format.type == "video_only")
                                    val audioFormat = if (isVideoOnly) {
                                        video.formats.filter { isAudioFormat(it) }
                                            .maxByOrNull { it.audioBitrateKbps ?: 0 }
                                            ?: video.formats.filter { isAudioFormat(it) }
                                                .maxByOrNull { it.sizeBytes }
                                    } else {
                                        null
                                    }
                                    
                                    val videoUrl = format.downloadUrl.ifBlank { format.downloadUrl }.ifBlank { video.originalUrl }
                                    val streamUrl = if (audioFormat != null) {
                                        val audioUrl = audioFormat.downloadUrl.ifBlank { audioFormat.downloadUrl }.ifBlank { video.originalUrl }
                                        "$videoUrl|STREAM_AUDIO_URL|$audioUrl"
                                    } else {
                                        videoUrl
                                    }

                                    viewModel.startPlayingMedia(
                                        item = DownloadEntity(
                                            id = video.id,
                                            title = if (isAudio) "[Streaming Audio] ${video.title}" else "[Streaming Video] ${video.title}",
                                            author = video.author,
                                            durationText = video.durationText,
                                            thumbnailUrl = video.thumbnailUrl,
                                            localPath = streamUrl,
                                            fileSize = format.sizeBytes,
                                            downloadedAt = System.currentTimeMillis()
                                        ),
                                        originalUrl = video.originalUrl.ifBlank { "https://www.youtube.com/watch?v=${video.id}" }
                                    )
                                }
                            },
                            onCancelActiveTask = { taskId ->
                                viewModel.removeActiveTask(taskId)
                            },
                            onSearchResultClick = { result ->
                                viewModel.updateUrlInput(result.originalUrl)
                                viewModel.analyzeVideo()
                            },
                            showAdvancedFormats = showAdvancedFormats,
                            onToggleShowAdvancedFormats = { viewModel.updateShowAdvancedFormats(it) },
                            isIncognitoMode = isIncognitoMode,
                            onToggleIncognito = { viewModel.updateIncognitoMode(!isIncognitoMode) },
                            onScheduleFormat = { format ->
                                analyzedVideo?.let { video ->
                                    schedulingVideoInfo = Triple(video.title, video.originalUrl.ifBlank { "https://www.youtube.com/watch?v=${video.id}" }, format)
                                }
                            },
                            viewModel = viewModel
                        )
                        1 -> {
                            val activeMap by viewModel.activeDownloadsOnUi.collectAsStateWithLifecycle()
                            val failedTasks = remember(activeMap) {
                                activeMap.values.filter { it.status == com.example.ui.DownloadStatus.FAILED }
                            }
                            LibraryTab(
                                downloads = (downloadHistory + deviceMedia).distinctBy { it.localPath }.sortedByDescending { it.downloadedAt },
                                failedTasks = failedTasks,
                                appDownloadedPaths = downloadHistory.map { it.localPath }.toSet(),
                                onPlayClick = { 
                                    viewModel.startPlayingMedia(it)
                                },
                                onShareClick = { viewModel.shareVideo(context, it) },
                                onDeleteClick = { viewModel.deleteDownload(it) },
                                onDeleteFailedClick = { taskId -> viewModel.removeActiveTask(taskId) },
                                onConvertAudio = { item, codec -> viewModel.convertAudio(item, codec) },
                                onBulkDeleteClick = { selectedDownloads, selectedFailedIds ->
                                    selectedDownloads.forEach { viewModel.deleteDownload(it) }
                                    selectedFailedIds.forEach { viewModel.removeActiveTask(it) }
                                },
                                onEditMetadataClick = { editingMetadataItem = it },
                                onAddToPlaylistClick = { playlistItemToAdd = it },
                                viewModel = viewModel
                            )
                        }
                        2 -> HistoryTab(
                            historyList = viewModel.browsingHistory.collectAsStateWithLifecycle().value,
                            onPlayClick = { historyItem ->
                                if (historyItem.originalUrl.startsWith("http")) {
                                    viewModel.updateUrlInput(historyItem.originalUrl)
                                    selectedTabIndex = 0
                                    viewModel.analyzeVideo()
                                } else {
                                    viewModel.startPlayingMedia(com.example.data.DownloadEntity(
                                        id = historyItem.id,
                                        title = if (historyItem.title.startsWith("[Streaming")) historyItem.title else "[Streaming Video] ${historyItem.title}",
                                        author = historyItem.author,
                                        durationText = historyItem.durationText,
                                        thumbnailUrl = historyItem.thumbnailUrl,
                                        localPath = historyItem.originalUrl,
                                        fileSize = 0L,
                                        downloadedAt = historyItem.browsedAt
                                    ))
                                }
                            },
                            onDeleteClick = { id -> viewModel.deleteBrowsingRecord(id) },
                            onClearAllClick = { viewModel.clearAllBrowsingHistory() },
                            onRevisitClick = { historyItem ->
                                viewModel.updateUrlInput(historyItem.originalUrl)
                                selectedTabIndex = 0
                                viewModel.analyzeVideo()
                            }
                        )
                        3 -> SettingsTab(
                            downloads = (downloadHistory + deviceMedia).distinctBy { it.localPath }.sortedByDescending { it.downloadedAt },
                            onClearAllDownloads = { viewModel.clearAllDownloads() },
                            viewModel = viewModel
                        )
                    }
                }
            }
        }

            if (!isPlayerFullscreen && selectedTabIndex == 0) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .offset { IntOffset(0, topBarOffsetHeightPx.roundToInt()) }
                        .statusBarsPadding()
                        .padding(start = if (!isMobile) 130.dp else 16.dp, end = 16.dp, top = 16.dp, bottom = 4.dp)
                ) {
                    // Left side: Floating Text (Title & version badge in an elegant glassmorphic capsule)
                    Surface(
                        modifier = Modifier
                            .align(Alignment.CenterStart)
                            .shadow(
                                elevation = 12.dp,
                                shape = RoundedCornerShape(24.dp),
                                clip = false,
                                ambientColor = SleekPurpleLight.copy(alpha = 0.25f),
                                spotColor = SleekPurpleLight.copy(alpha = 0.45f)
                            ),
                        shape = RoundedCornerShape(24.dp),
                        color = Color(0xCC121218), // Deep glassmorphic background
                        border = BorderStroke(
                            width = 1.dp,
                            brush = Brush.linearGradient(
                                colors = listOf(
                                    SleekPurpleLight.copy(alpha = 0.5f),
                                    Color.Transparent,
                                    SleekPurpleDark.copy(alpha = 0.3f)
                                )
                            )
                        )
                    ) {
                        Row(
                            modifier = Modifier
                                .padding(horizontal = 16.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.CloudDownload,
                                contentDescription = "Logo Icon",
                                tint = SleekPurpleLight,
                                modifier = Modifier.size(18.dp)
                            )
                            Text(
                                text = "꒯ꄲꅐꋊ꒒ꌦ",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.ExtraBold,
                                    color = Color.White,
                                    fontSize = 18.sp,
                                    letterSpacing = (-0.5).sp
                                )
                            )
                            if (displayVersion.isNotEmpty() && displayVersion != "Not checked") {
                                Box(
                                    modifier = Modifier
                                        .height(18.dp)
                                        .background(
                                            color = SleekPurpleLight.copy(alpha = 0.15f),
                                            shape = RoundedCornerShape(6.dp)
                                        )
                                        .border(
                                            width = 0.5.dp,
                                            color = SleekPurpleLight.copy(alpha = 0.3f),
                                            shape = RoundedCornerShape(6.dp)
                                        )
                                        .padding(horizontal = 4.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = displayVersion,
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = SleekPurpleLight,
                                            fontSize = 9.sp
                                        )
                                    )
                                }
                            }
                        }
                    }

                    // Right side: Floating Action Buttons (independent floating circular widgets)
                    Row(
                        modifier = Modifier.align(Alignment.CenterEnd),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (isYtdlpUpdateAvailable || isYtdlpLoading) {
                            var showUpdateConfirmDialog by remember { mutableStateOf(false) }
                            
                            // Automatically dismiss the dialog when update finishes
                            LaunchedEffect(isYtdlpLoading) {
                                if (!isYtdlpLoading) {
                                    showUpdateConfirmDialog = false
                                }
                            }

                            Surface(
                                modifier = Modifier
                                    .shadow(
                                        elevation = 12.dp,
                                        shape = CircleShape,
                                        clip = false,
                                        ambientColor = SleekPurpleLight.copy(alpha = 0.25f),
                                        spotColor = SleekPurpleLight.copy(alpha = 0.45f)
                                    ),
                                shape = CircleShape,
                                color = Color(0xCC121218),
                                border = BorderStroke(
                                    width = 1.dp,
                                    brush = Brush.linearGradient(
                                        colors = listOf(
                                            SleekPurpleLight.copy(alpha = 0.5f),
                                            Color.Transparent,
                                            SleekPurpleDark.copy(alpha = 0.3f)
                                        )
                                    )
                                )
                            ) {
                                IconButton(
                                    onClick = {
                                        if (!isYtdlpLoading) {
                                            showUpdateConfirmDialog = true
                                        }
                                    },
                                    modifier = Modifier
                                        .size(38.dp)
                                        .testTag("ytdlp_update_icon"),
                                    enabled = !isYtdlpLoading
                                ) {
                                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                        if (isYtdlpLoading) {
                                            CircularProgressIndicator(
                                                modifier = Modifier.size(16.dp),
                                                color = SleekPurpleLight,
                                                strokeWidth = 2.dp
                                            )
                                        } else {
                                            Icon(
                                                imageVector = Icons.Default.SystemUpdateAlt,
                                                contentDescription = "Update Available",
                                                tint = SleekPurpleLight,
                                                modifier = Modifier.size(18.dp)
                                            )
                                            Box(
                                                modifier = Modifier
                                                    .size(6.dp)
                                                    .background(CrimsonFailure, shape = CircleShape)
                                                    .align(Alignment.TopEnd)
                                                    .offset(x = (-2).dp, y = 2.dp)
                                            )
                                        }
                                    }
                                }
                            }

                            if (showUpdateConfirmDialog) {
                                AlertDialog(
                                    onDismissRequest = {
                                        if (!isYtdlpLoading) {
                                            showUpdateConfirmDialog = false
                                        }
                                    },
                                    title = {
                                        Text(
                                            text = "Update yt-dlp Core",
                                            color = SleekTextPrimary,
                                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                        )
                                    },
                                    text = {
                                        Text(
                                            text = if (isYtdlpLoading) {
                                                "Updating yt-dlp core to the latest version... Please keep the app open and do not interrupt."
                                            } else {
                                                "A new version of yt-dlp is available online! Would you like to delete the old binaries and perform a clean install of the updated version?"
                                            },
                                            color = SleekTextSecondary,
                                            style = MaterialTheme.typography.bodyMedium
                                        )
                                    },
                                    containerColor = SleekCard,
                                    confirmButton = {
                                        Button(
                                            onClick = {
                                                viewModel.performYtdlpUpdateAndInstall(context)
                                            },
                                            enabled = !isYtdlpLoading,
                                            colors = ButtonDefaults.buttonColors(
                                                containerColor = Color.White,
                                                contentColor = Color.Black,
                                                disabledContainerColor = Color.White.copy(alpha = 0.5f)
                                            )
                                        ) {
                                            if (isYtdlpLoading) {
                                                CircularProgressIndicator(
                                                    modifier = Modifier.size(18.dp),
                                                    color = Color.Black,
                                                    strokeWidth = 2.dp
                                                )
                                            } else {
                                                Icon(Icons.Default.Download, contentDescription = "Update & Install")
                                            }
                                        }
                                    },
                                    dismissButton = {
                                        if (!isYtdlpLoading) {
                                            TextButton(
                                                onClick = { showUpdateConfirmDialog = false }
                                            ) {
                                                Icon(Icons.Default.Close, contentDescription = "Cancel", tint = SleekTextMuted)
                                            }
                                        }
                                    }
                                )
                            }
                        }

                        FluidIncognitoButton(
                            isIncognitoMode = isIncognitoMode,
                            onToggle = { viewModel.updateIncognitoMode(!isIncognitoMode) }
                        )

                        Surface(
                            modifier = Modifier
                                .shadow(
                                    elevation = 12.dp,
                                    shape = CircleShape,
                                    clip = false,
                                    ambientColor = SleekPurpleLight.copy(alpha = 0.15f),
                                    spotColor = SleekPurpleLight.copy(alpha = 0.25f)
                                ),
                            shape = CircleShape,
                            color = Color(0xCC121218),
                            border = BorderStroke(
                                width = 1.dp,
                                brush = Brush.linearGradient(
                                    colors = listOf(
                                        SleekPurpleLight.copy(alpha = 0.3f),
                                        Color.Transparent,
                                        SleekPurpleDark.copy(alpha = 0.15f)
                                    )
                                )
                            )
                        ) {
                            IconButton(
                                onClick = { showBatchQueueModal = true },
                                modifier = Modifier.size(38.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Queue,
                                    contentDescription = "Queue Settings",
                                    tint = SleekPurpleLight,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }

                        Surface(
                            modifier = Modifier
                                .shadow(
                                    elevation = 12.dp,
                                    shape = CircleShape,
                                    clip = false,
                                    ambientColor = SleekPurpleLight.copy(alpha = 0.15f),
                                    spotColor = SleekPurpleLight.copy(alpha = 0.25f)
                                ),
                            shape = CircleShape,
                            color = Color(0xCC121218),
                            border = BorderStroke(
                                width = 1.dp,
                                brush = Brush.linearGradient(
                                    colors = listOf(
                                        SleekPurpleLight.copy(alpha = 0.3f),
                                        Color.Transparent,
                                        SleekPurpleDark.copy(alpha = 0.15f)
                                    )
                                )
                            )
                        ) {
                            IconButton(
                                onClick = { showAboutDialog = true },
                                modifier = Modifier.size(38.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Info,
                                    contentDescription = "About App",
                                    tint = SleekPurpleLight,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }
                }
            }

            androidx.compose.animation.AnimatedVisibility(
                visible = playingMedia != null,
                enter = androidx.compose.animation.fadeIn(
                    animationSpec = androidx.compose.animation.core.tween(150, easing = androidx.compose.animation.core.FastOutLinearInEasing)
                ) + androidx.compose.animation.slideInVertically(
                    initialOffsetY = { it / 16 },
                    animationSpec = androidx.compose.animation.core.tween(160, easing = androidx.compose.animation.core.FastOutSlowInEasing)
                ),
                exit = androidx.compose.animation.fadeOut(
                    animationSpec = androidx.compose.animation.core.tween(120, easing = androidx.compose.animation.core.LinearOutSlowInEasing)
                ) + androidx.compose.animation.slideOutVertically(
                    targetOffsetY = { it / 16 },
                    animationSpec = androidx.compose.animation.core.tween(120, easing = androidx.compose.animation.core.LinearOutSlowInEasing)
                )
            ) {
                playingMedia?.let { media ->
                    FloatingPlayerOverlay(
                        media = media,
                        isFullscreen = isPlayerFullscreen,
                        onToggleFullscreen = { isPlayerFullscreen = !isPlayerFullscreen },
                        onClose = { viewModel.stopPlayingMedia() },
                        analyzedVideo = analyzedVideo,
                        onStreamFormat = { format ->
                            analyzedVideo?.let { video ->
                                val isAudio = isAudioFormat(format)
                                val isVideoOnly = !isAudio && (format.acodec == "none" || format.acodec.isBlank() || !format.hasAudio || format.type == "video_only")
                                val audioFormat = if (isVideoOnly) {
                                    video.formats.filter { isAudioFormat(it) }
                                        .maxByOrNull { it.audioBitrateKbps ?: 0 }
                                        ?: video.formats.filter { isAudioFormat(it) }
                                            .maxByOrNull { it.sizeBytes }
                                } else {
                                    null
                                }
                                
                                val videoUrl = format.downloadUrl.ifBlank { format.downloadUrl }.ifBlank { video.originalUrl }
                                val streamUrl = if (audioFormat != null) {
                                    val audioUrl = audioFormat.downloadUrl.ifBlank { audioFormat.downloadUrl }.ifBlank { video.originalUrl }
                                    "$videoUrl|STREAM_AUDIO_URL|$audioUrl"
                                } else {
                                    videoUrl
                                }

                                viewModel.startPlayingMedia(
                                    item = DownloadEntity(
                                        id = video.id,
                                        title = if (isAudio) "[Streaming Audio] ${video.title}" else "[Streaming Video] ${video.title}",
                                        author = video.author,
                                        durationText = video.durationText,
                                        thumbnailUrl = video.thumbnailUrl,
                                        localPath = streamUrl,
                                        fileSize = format.sizeBytes,
                                        downloadedAt = System.currentTimeMillis()
                                    ),
                                    originalUrl = video.originalUrl.ifBlank { "https://www.youtube.com/watch?v=${video.id}" }
                                )
                            }
                        },
                        viewModel = viewModel,
                        onOpenAudioFxStudio = { showAudioFxStudioDialog = true }
                    )
                }
            }
        }
    }

            activeTrimState?.let { trimState ->
                MediaTrimmerDialog(
                    state = trimState,
                    onUpdateRange = { start, end -> viewModel.updateTrimRange(start, end) },
                    onPreview = {
                        viewModel.startPlayingMedia(trimState.media)
                    },
                    onExport = { viewModel.executeMediaTrim() },
                    onCancelExport = { viewModel.cancelMediaTrim() },
                    onOpenExported = { entity ->
                        viewModel.closeMediaTrimmer()
                        viewModel.startPlayingMedia(entity)
                    },
                    onShareExported = { path ->
                        try {
                            val context = context
                            val file = java.io.File(path)
                            val uri = androidx.core.content.FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
                            val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                                type = "video/*"
                                putExtra(android.content.Intent.EXTRA_STREAM, uri)
                                addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            }
                            context.startActivity(android.content.Intent.createChooser(intent, "Share Exported Segment"))
                        } catch (e: Exception) {
                            android.widget.Toast.makeText(context, "Share error: ${e.message}", android.widget.Toast.LENGTH_SHORT).show()
                        }
                    },
                    onDismiss = { viewModel.closeMediaTrimmer() }
                )
            }

            activeCompressState?.let { compressState ->
                VideoCompressionDialog(
                    state = compressState,
                    onSelectPreset = { presetId -> viewModel.selectCompressPreset(presetId) },
                    onUpdateCustomOptions = { w, h, vKbps, aKbps, fps ->
                        viewModel.updateCustomCompressOptions(w, h, vKbps, aKbps, fps)
                    },
                    onCompress = { viewModel.executeVideoCompression() },
                    onCancelCompress = { viewModel.cancelVideoCompression() },
                    onOpenCompressed = { entity ->
                        viewModel.closeVideoCompressor()
                        viewModel.startPlayingMedia(entity)
                    },
                    onShareCompressed = { path ->
                        try {
                            val context = context
                            val file = java.io.File(path)
                            val uri = androidx.core.content.FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
                            val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                                type = "video/*"
                                putExtra(android.content.Intent.EXTRA_STREAM, uri)
                                addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            }
                            context.startActivity(android.content.Intent.createChooser(intent, "Share Compressed Video"))
                        } catch (e: Exception) {
                            android.widget.Toast.makeText(context, "Share error: ${e.message}", android.widget.Toast.LENGTH_SHORT).show()
                        }
                    },
                    onDismiss = { viewModel.closeVideoCompressor() }
                )
            }

            if (showAudioFxStudioDialog) {
                AudioFxStudioModal(
                    viewModel = viewModel,
                    onDismiss = { showAudioFxStudioDialog = false }
                )
            }

            if (showBatchQueueModal) {
                BatchQueueManagerModal(
                    viewModel = viewModel,
                    onDismiss = { showBatchQueueModal = false }
                )
            }

            editingMetadataItem?.let { item ->
                MetadataEditorModal(
                    item = item,
                    viewModel = viewModel,
                    onDismiss = { editingMetadataItem = null }
                )
            }

            schedulingVideoInfo?.let { triple ->
                DownloadSchedulerModal(
                    viewModel = viewModel,
                    videoTitle = triple.first,
                    videoUrl = triple.second,
                    formatQuality = triple.third.quality,
                    formatExt = triple.third.ext,
                    onDismiss = { schedulingVideoInfo = null }
                )
            }

            playlistItemToAdd?.let { item ->
                AddToPlaylistModal(
                    item = item,
                    viewModel = viewModel,
                    onCreateNewRequest = { showCreatePlaylistModal = true },
                    onDismiss = { playlistItemToAdd = null }
                )
            }

            if (showCreatePlaylistModal) {
                CreatePlaylistModal(
                    viewModel = viewModel,
                    onDismiss = { showCreatePlaylistModal = false }
                )
            }

            if (showAboutDialog) {
                AlertDialog(
                    onDismissRequest = { showAboutDialog = false },
                    title = {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(42.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .border(1.dp, SleekPurpleLight.copy(alpha = 0.4f), RoundedCornerShape(12.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Image(
                                    painter = painterResource(id = R.drawable.img_downly_logo_1787355493817),
                                    contentDescription = "Downly Logo",
                                    modifier = Modifier.fillMaxSize(),
                                    contentScale = ContentScale.Crop
                                )
                            }
                            Column {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Text(
                                        text = "About Downly",
                                        color = SleekTextPrimary,
                                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                                    )
                                    Surface(
                                        shape = RoundedCornerShape(6.dp),
                                        color = SleekPurpleLight.copy(alpha = 0.15f),
                                        border = BorderStroke(0.5.dp, SleekPurpleLight.copy(alpha = 0.3f))
                                    ) {
                                        Text(
                                            text = "v${com.example.BuildConfig.VERSION_NAME} Pro",
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                fontWeight = FontWeight.Bold,
                                                color = SleekPurpleLight
                                            ),
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                                Text(
                                    text = "High-Performance Media Downloader",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = SleekTextSecondary
                                )
                            }
                        }
                    },
                    text = {
                        Column(
                            verticalArrangement = Arrangement.spacedBy(14.dp),
                            modifier = Modifier.verticalScroll(rememberScrollState())
                        ) {
                            Text(
                                text = "Downly is an ultra-fast offline media downloader and converter powered by standard yt-dlp & FFmpeg engines. Built for high-speed multi-threaded downloads, stream extraction, and zero-compromise privacy.",
                                color = SleekTextSecondary,
                                style = MaterialTheme.typography.bodyMedium,
                                lineHeight = 20.sp
                            )

                            // DEVELOPER CARD - CLEAN & SMOOTH
                            Surface(
                                onClick = {
                                    openInstagramProfile(context, "_junior_sir_")
                                },
                                shape = RoundedCornerShape(14.dp),
                                color = Color(0xFF1B1124),
                                border = BorderStroke(1.dp, Color(0xFFE1306C).copy(alpha = 0.35f)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(38.dp)
                                                .background(
                                                    Brush.linearGradient(
                                                        listOf(
                                                            Color(0xFF833AB4).copy(alpha = 0.2f),
                                                            Color(0xFFFD1D1D).copy(alpha = 0.2f),
                                                            Color(0xFFFCB045).copy(alpha = 0.2f)
                                                        )
                                                    ),
                                                    CircleShape
                                                )
                                                .border(1.dp, Color(0xFFFD1D1D).copy(alpha = 0.4f), CircleShape),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            InstagramIcon(modifier = Modifier.size(20.dp), useGradient = true)
                                        }
                                        Column {
                                            Text(
                                                text = "JuniorSir",
                                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                                color = Color.White
                                            )
                                            Text(
                                                text = "Lead Developer",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = Color(0xFFFCB045)
                                            )
                                        }
                                    }
                                    Box(
                                        modifier = Modifier
                                            .size(30.dp)
                                            .background(Color(0xFFFD1D1D).copy(alpha = 0.12f), CircleShape),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.ArrowForward,
                                            contentDescription = "Open Instagram Profile",
                                            tint = Color(0xFFFCAF45),
                                            modifier = Modifier.size(15.dp)
                                        )
                                    }
                                }
                            }

                            // HIGHLIGHT CHIPS
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                listOf("yt-dlp Core", "FFmpeg JNI", "100% Private").forEach { tag ->
                                    Surface(
                                        modifier = Modifier.weight(1f),
                                        shape = RoundedCornerShape(8.dp),
                                        color = SleekPurpleLight.copy(alpha = 0.08f),
                                        border = BorderStroke(0.5.dp, SleekPurpleLight.copy(alpha = 0.2f))
                                    ) {
                                        Text(
                                            text = tag,
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                fontWeight = FontWeight.SemiBold,
                                                fontSize = 10.sp
                                            ),
                                            color = SleekTextPrimary,
                                            textAlign = TextAlign.Center,
                                            modifier = Modifier.padding(vertical = 6.dp)
                                        )
                                    }
                                }
                            }

                            // TECH SPECS SUMMARY
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(Color.Black.copy(alpha = 0.25f), RoundedCornerShape(12.dp))
                                    .padding(horizontal = 12.dp, vertical = 10.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(Icons.Default.Email, contentDescription = null, tint = SleekPurpleLight, modifier = Modifier.size(15.dp))
                                    Text("Contact:", style = MaterialTheme.typography.labelSmall, color = SleekTextMuted)
                                    Text("officialmp4go@gmail.com", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Medium), color = SleekPurpleLight)
                                }
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(Icons.Default.Layers, contentDescription = null, tint = SleekPurpleLight, modifier = Modifier.size(15.dp))
                                    Text("Architecture:", style = MaterialTheme.typography.labelSmall, color = SleekTextMuted)
                                    Text("Jetpack Compose M3 & Room DB", style = MaterialTheme.typography.bodySmall, color = SleekTextSecondary)
                                }
                            }

                            // LEGAL POLICIES BUTTONS
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                OutlinedButton(
                                    onClick = {
                                        showAboutDialog = false
                                        showTermsDialog = true
                                    },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(10.dp),
                                    border = BorderStroke(1.dp, SleekPurpleLight.copy(alpha = 0.35f)),
                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = SleekPurpleLight),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp)
                                ) {
                                    Icon(Icons.Default.Security, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Terms", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                }

                                OutlinedButton(
                                    onClick = {
                                        showAboutDialog = false
                                        showPrivacyDialog = true
                                    },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(10.dp),
                                    border = BorderStroke(1.dp, SleekPurpleLight.copy(alpha = 0.35f)),
                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = SleekPurpleLight),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp)
                                ) {
                                    Icon(Icons.Default.Lock, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Privacy", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                }
                            }

                            Text(
                                text = "© 2026 Downly Media Tech. All rights reserved.",
                                style = MaterialTheme.typography.labelSmall,
                                color = SleekTextMuted,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.fillMaxWidth().padding(top = 2.dp)
                            )
                        }
                    },
                    containerColor = SleekCard,
                    confirmButton = {
                        Button(
                            onClick = { showAboutDialog = false },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color.White,
                                contentColor = Color.Black
                            ),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Default.Check, contentDescription = "Close")
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Close", fontWeight = FontWeight.Bold)
                        }
                    }
                )
            }

            if (showTermsDialog) {
                TermsAndConditionsDialog(onDismiss = { showTermsDialog = false })
            }

            if (showPrivacyDialog) {
                PrivacyPolicyDialog(onDismiss = { showPrivacyDialog = false })
            }

            // Mobile Bottom Floating Navigation Capsule
            if (isMobile && !isPlayerFullscreen) {
                val infiniteTransition = rememberInfiniteTransition(label = "FabGlowTransition")
                val fabScale by infiniteTransition.animateFloat(
                    initialValue = 1f,
                    targetValue = 1.04f,
                    animationSpec = infiniteRepeatable(
                        animation = tween(2000, easing = LinearEasing),
                        repeatMode = RepeatMode.Reverse
                    ),
                    label = "FabScale"
                )

                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.BottomCenter
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .navigationBarsPadding()
                            .padding(bottom = 12.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                    val isBgActive by (viewModel.isBackgroundPlaybackActive).collectAsStateWithLifecycle()
                    val bgMedia by (viewModel.backgroundMedia).collectAsStateWithLifecycle()
                    val isBgPlaying by (viewModel.isBackgroundPlaying).collectAsStateWithLifecycle()
                    val bgPos by (viewModel.backgroundPositionMs).collectAsStateWithLifecycle()
                    val bgDur by (viewModel.backgroundDurationMs).collectAsStateWithLifecycle()

                    androidx.compose.animation.AnimatedVisibility(
                        visible = isBgActive && bgMedia != null && playingMedia == null,
                        enter = fadeIn(tween(250)) + slideInVertically(initialOffsetY = { it }),
                        exit = fadeOut(tween(200)) + slideOutVertically(targetOffsetY = { it })
                    ) {
                        bgMedia?.let { media ->
                            YouTubeBackgroundMiniPlayerBar(
                                media = media,
                                isPlaying = isBgPlaying,
                                currentPosMs = bgPos,
                                durationMs = bgDur,
                                onTogglePlay = { viewModel.toggleBackgroundPlayPause() },
                                onSeekRelative = { delta -> viewModel.seekBackgroundBy(delta) },
                                onOpenFullPlayer = {
                                    com.example.media.BackgroundPlaybackManager.stop(context)
                                    viewModel.startPlayingMedia(media)
                                },
                                onClose = {
                                    viewModel.stopBackgroundPlayback()
                                },
                                modifier = Modifier
                                    .widthIn(max = 500.dp)
                                    .fillMaxWidth()
                                    .padding(horizontal = 16.dp, vertical = 6.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(2.dp))

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 12.dp),
                        contentAlignment = Alignment.BottomCenter
                    ) {
                    // Blurred Frosted Glass Background under Navigation Capsule
                    Box(
                        modifier = Modifier
                            .width(328.dp)
                            .height(72.dp)
                            .blur(20.dp)
                            .background(
                                brush = Brush.verticalGradient(
                                    colors = listOf(
                                        Color(0x801A1B23),
                                        Color(0x600F1015)
                                    )
                                ),
                                shape = RoundedCornerShape(36.dp)
                            )
                    )

                    // Complete Rounded Capsule Navigation Bar
                    Surface(
                        modifier = Modifier
                            .width(328.dp)
                            .height(72.dp)
                            .shadow(
                                elevation = 16.dp,
                                shape = RoundedCornerShape(36.dp),
                                spotColor = Color(0x55000000),
                                ambientColor = Color(0x55000000)
                            ),
                        shape = RoundedCornerShape(36.dp),
                        color = Color(0xB3121218),
                        border = BorderStroke(1.dp, Color(0x26FFFFFF))
                    ) {
                        Row(
                            modifier = Modifier.fillMaxSize(),
                            horizontalArrangement = Arrangement.SpaceEvenly,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Zone 1: Home
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .fillMaxHeight(),
                                contentAlignment = Alignment.Center
                            ) {
                                LiquidGlassIcon(
                                    imageVector = Icons.Default.Home,
                                    contentDescription = "Home",
                                    isSelected = selectedTabIndex == 0,
                                    containerSize = 46.dp,
                                    size = 24.dp,
                                    onClick = { selectedTabIndex = 0 }
                                )
                            }

                            // Zone 2: Library
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .fillMaxHeight(),
                                contentAlignment = Alignment.Center
                            ) {
                                LiquidGlassIcon(
                                    imageVector = Icons.Default.VideoLibrary,
                                    contentDescription = "Library",
                                    isSelected = selectedTabIndex == 1,
                                    containerSize = 46.dp,
                                    size = 24.dp,
                                    onClick = { selectedTabIndex = 1 }
                                )
                            }

                            // Zone 3: Placeholder Zone for Center FAB Alignment
                            Spacer(modifier = Modifier.weight(1f))

                            // Zone 4: History
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .fillMaxHeight(),
                                contentAlignment = Alignment.Center
                            ) {
                                LiquidGlassIcon(
                                    imageVector = Icons.Default.History,
                                    contentDescription = "History",
                                    isSelected = selectedTabIndex == 2,
                                    containerSize = 46.dp,
                                    size = 24.dp,
                                    onClick = { selectedTabIndex = 2 }
                                )
                            }

                            // Zone 5: Settings
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .fillMaxHeight(),
                                contentAlignment = Alignment.Center
                            ) {
                                LiquidGlassIcon(
                                    imageVector = Icons.Default.Settings,
                                    contentDescription = "Settings",
                                    isSelected = selectedTabIndex == 3,
                                    containerSize = 46.dp,
                                    size = 24.dp,
                                    onClick = { selectedTabIndex = 3 }
                                )
                            }
                        }
                    }

                    // Hovering Complete Circular Download FAB (using LiquidGlassIcon theme matching tablet)
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopCenter)
                            .offset(y = (-10).dp)
                            .graphicsLayer {
                                scaleX = fabScale
                                scaleY = fabScale
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        LiquidGlassIcon(
                            imageVector = Icons.Default.FileDownload,
                            contentDescription = "Download FAB",
                            isSelected = true,
                            containerSize = 58.dp,
                            size = 28.dp,
                            onClick = {
                                selectedTabIndex = 0
                                if (urlInput.trim().isNotEmpty()) {
                                    viewModel.analyzeVideo()
                                }
                            }
                        )
                    }
                }
            }
        }
    }
}
}

@Composable
fun LargeScreenNavigationDock(
    selectedTabIndex: Int,
    onTabSelected: (Int) -> Unit,
    onQuickActionClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val configuration = androidx.compose.ui.platform.LocalConfiguration.current
    val widthDp = configuration.screenWidthDp

    Surface(
        modifier = modifier
            .fillMaxHeight()
            .width(88.dp)
            .padding(start = 12.dp, top = 16.dp, bottom = 16.dp, end = 12.dp),
        shape = RoundedCornerShape(36.dp),
        color = Color(0xE6111216),
        border = BorderStroke(1.2.dp, Color.White.copy(alpha = 0.12f)),
        shadowElevation = 24.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(vertical = 24.dp, horizontal = 4.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Header Logo
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .border(1.dp, Color(0xFF8B5CF6).copy(alpha = 0.5f), RoundedCornerShape(14.dp)),
                contentAlignment = Alignment.Center
            ) {
                Image(
                    painter = painterResource(id = R.drawable.img_downly_logo_1787355493817),
                    contentDescription = "Downly Logo",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
            }

            // Central Navigation Tabs (Liquid Glass Icons without labels)
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(20.dp)
            ) {
                val navItems = listOf(
                    DownlyNavItem(0, Icons.Default.Home, "Home", 0),
                    DownlyNavItem(1, Icons.Default.Search, "Search", 0),
                    DownlyNavItem(2, Icons.Default.VideoLibrary, "Library", 1),
                    DownlyNavItem(3, Icons.Default.History, "History", 2),
                    DownlyNavItem(4, Icons.Default.FileDownload, "Downloads", 0),
                    DownlyNavItem(5, Icons.Default.Settings, "Settings", 3)
                )

                navItems.forEach { item ->
                    val isSelected = when (item.id) {
                        0 -> selectedTabIndex == 0
                        2 -> selectedTabIndex == 1
                        3 -> selectedTabIndex == 2
                        5 -> selectedTabIndex == 3
                        else -> false
                    }

                    LiquidGlassIcon(
                        imageVector = item.icon,
                        contentDescription = item.label,
                        isSelected = isSelected,
                        onClick = {
                            if (item.id == 1 || item.id == 4) {
                                onTabSelected(0)
                            } else {
                                onTabSelected(item.target)
                            }
                        }
                    )
                }
            }

            // Quick Download Action FAB Button
            LiquidGlassIcon(
                imageVector = Icons.Default.FileDownload,
                contentDescription = "Quick Download",
                isSelected = true,
                containerSize = 56.dp,
                size = 28.dp,
                onClick = onQuickActionClick
            )
        }
    }
}

data class DownlyNavItem(
    val id: Int,
    val icon: androidx.compose.ui.graphics.vector.ImageVector,
    val label: String,
    val target: Int
)

data class ThumbnailPreviewData(
    val isRecognized: Boolean,
    val platform: String,
    val thumbnailUrl: String?,
    val videoId: String?,
    val brandColor: Color,
    val icon: androidx.compose.ui.graphics.vector.ImageVector
)

fun extractYoutubeVideoId(url: String): String? {
    val patterns = listOf(
        "youtube\\.com/watch\\?v=([^&\\s]+)",
        "youtu\\.be/([^?\\s]+)",
        "youtube\\.com/shorts/([^?\\s]+)",
        "youtube\\.com/embed/([^?\\s]+)",
        "youtube\\.com/watch\\?.*v=([^&\\s]+)",
        "music\\.youtube\\.com/watch\\?v=([^&\\s]+)"
    )
    for (pattern in patterns) {
        val regex = Regex(pattern, RegexOption.IGNORE_CASE)
        val matchResult = regex.find(url)
        if (matchResult != null && matchResult.groupValues.size > 1) {
            return matchResult.groupValues[1]
        }
    }
    return null
}

fun getThumbnailPreviewData(url: String): ThumbnailPreviewData? {
    try {
        val trimmed = url.trim()
        if (trimmed.isEmpty()) return null
        if (!trimmed.startsWith("http://") && !trimmed.startsWith("https://")) return null

        // YouTube checks
        val ytVideoId = extractYoutubeVideoId(trimmed)
        if (ytVideoId != null) {
            return ThumbnailPreviewData(
                isRecognized = true,
                platform = "YouTube",
                thumbnailUrl = "https://img.youtube.com/vi/$ytVideoId/hqdefault.jpg",
                videoId = ytVideoId,
                brandColor = Color(0xFFFF0000),
                icon = Icons.Default.PlayCircleFilled
            )
        }

        // Instagram checks
        if (trimmed.contains("instagram.com", ignoreCase = true)) {
            return ThumbnailPreviewData(
                isRecognized = true,
                platform = "Instagram",
                thumbnailUrl = null,
                videoId = null,
                brandColor = Color(0xFFE1306C),
                icon = Icons.Default.CameraAlt
            )
        }

        // TikTok checks
        if (trimmed.contains("tiktok.com", ignoreCase = true)) {
            return ThumbnailPreviewData(
                isRecognized = true,
                platform = "TikTok",
                thumbnailUrl = null,
                videoId = null,
                brandColor = Color(0xFF00F2FE),
                icon = Icons.Default.MusicNote
            )
        }

        // Facebook checks
        if (trimmed.contains("facebook.com", ignoreCase = true) || trimmed.contains("fb.watch", ignoreCase = true)) {
            return ThumbnailPreviewData(
                isRecognized = true,
                platform = "Facebook",
                thumbnailUrl = null,
                videoId = null,
                brandColor = Color(0xFF1877F2),
                icon = Icons.Default.Public
            )
        }

        // X / Twitter checks
        if (trimmed.contains("twitter.com", ignoreCase = true) || trimmed.contains("x.com", ignoreCase = true)) {
            return ThumbnailPreviewData(
                isRecognized = true,
                platform = "X / Twitter",
                thumbnailUrl = null,
                videoId = null,
                brandColor = Color(0xFFFFFFFF),
                icon = Icons.Default.AlternateEmail
            )
        }

        // Generic
        return ThumbnailPreviewData(
            isRecognized = false,
            platform = "Web Video",
            thumbnailUrl = null,
            videoId = null,
            brandColor = Color(0xFFD97706),
            icon = Icons.Default.VideoLibrary
        )
    } catch (e: Throwable) {
        return null
    }
}

@Composable
fun VideoSelectionPreview(
    url: String,
    onAnalyzeClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val previewData = remember(url) { getThumbnailPreviewData(url) } ?: return

    AnimatedVisibility(
        visible = true,
        enter = expandVertically() + fadeIn(),
        exit = shrinkVertically() + fadeOut(),
        modifier = modifier
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 16.dp)
                .testTag("thumbnail_preview_card"),
            shape = RoundedCornerShape(20.dp),
            color = Color(0x1AFFFFFF),
            border = BorderStroke(
                width = 1.dp,
                brush = Brush.linearGradient(
                    colors = listOf(
                        previewData.brandColor.copy(alpha = 0.4f),
                        Color.Transparent,
                        Color(0x0DFFFFFF)
                    )
                )
            )
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Left side: 16:9 aspect ratio thumbnail or premium gradient placeholder
                Box(
                    modifier = Modifier
                        .size(width = 110.dp, height = 62.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(
                            Brush.linearGradient(
                                colors = listOf(
                                    previewData.brandColor.copy(alpha = 0.25f),
                                    Color(0x1AFFFFFF)
                                )
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    if (previewData.thumbnailUrl != null) {
                        AsyncImage(
                            model = previewData.thumbnailUrl,
                            contentDescription = "Cover Art Preview",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                        // Dark translucent overlay
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(Color.Black.copy(alpha = 0.2f))
                        )
                    } else {
                        // Brand colored radial glow
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(
                                    Brush.radialGradient(
                                        colors = listOf(
                                            previewData.brandColor.copy(alpha = 0.4f),
                                            Color.Transparent
                                        )
                                    )
                                )
                        )
                    }

                    // Floating platform icon
                    Box(
                        modifier = Modifier
                            .size(28.dp)
                            .background(Color.Black.copy(alpha = 0.65f), CircleShape)
                            .border(1.dp, Color.White.copy(alpha = 0.15f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = previewData.icon,
                            contentDescription = null,
                            tint = previewData.brandColor,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }

                // Middle: Text details
                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.Center
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .background(previewData.brandColor, CircleShape)
                        )
                        Text(
                            text = previewData.platform.uppercase(),
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp,
                                color = previewData.brandColor
                            )
                        )
                    }
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "Verify selection before starting the download. Ready to fetch details.",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = Color(0xFFB7BBC5).copy(alpha = 0.8f),
                            fontSize = 11.sp,
                            lineHeight = 14.sp
                        ),
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                // Right side: Quick Analyze/Confirm button
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(Color(0x1AFFFFFF))
                        .clickable { onAnalyzeClick() },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Bolt,
                        contentDescription = "Confirm and Analyze",
                        tint = Color.White,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun DownloadTab(
    urlInput: String,
    urlHistory: List<String>,
    searchSuggestions: List<String> = emptyList(),
    isAnalyzing: Boolean,
    analyzedVideo: AnalyzedVideo?,
    analysisError: String?,
    activeDownloads: Map<String, ActiveDownloadTask>,
    executionLogs: List<String>,
    isAudioOnly: Boolean,
    searchResults: List<YtdlpPipelineManager.SearchResult>,
    isSearching: Boolean,
    onToggleAudioOnly: () -> Unit,
    onClearLogs: () -> Unit,
    onUrlChange: (String) -> Unit,
    onClearUrlHistory: () -> Unit,
    onPasteClick: () -> Unit,
    onClearClick: () -> Unit,
    onAnalyzeClick: () -> Unit,
    onDownloadFormat: (VideoFormatUi) -> Unit,
    onStreamFormat: (VideoFormatUi) -> Unit,
    onCancelActiveTask: (String) -> Unit,
    onSearchResultClick: (YtdlpPipelineManager.SearchResult) -> Unit,
    showAdvancedFormats: Boolean = false,
    onToggleShowAdvancedFormats: (Boolean) -> Unit = {},
    isIncognitoMode: Boolean = false,
    onToggleIncognito: () -> Unit = {},
    onScheduleFormat: ((VideoFormatUi) -> Unit)? = null,
    viewModel: VideoDownloaderViewModel? = null
) {
    val searchFilterType by (viewModel?.searchFilterType ?: kotlinx.coroutines.flow.MutableStateFlow("ALL")).collectAsStateWithLifecycle()
    val embedSubtitles by (viewModel?.embedSubtitles ?: kotlinx.coroutines.flow.MutableStateFlow(true)).collectAsStateWithLifecycle()
    val embedAutoSubtitles by (viewModel?.embedAutoSubtitles ?: kotlinx.coroutines.flow.MutableStateFlow(true)).collectAsStateWithLifecycle()
    val embedAudioMetadata by (viewModel?.embedAudioMetadata ?: kotlinx.coroutines.flow.MutableStateFlow(true)).collectAsStateWithLifecycle()
    val audioMultistreams by (viewModel?.audioMultistreams ?: kotlinx.coroutines.flow.MutableStateFlow(false)).collectAsStateWithLifecycle()

    val configuration = androidx.compose.ui.platform.LocalConfiguration.current
    val screenWidthDp = configuration.screenWidthDp
    val columns = when {
        screenWidthDp < 600 -> 1
        screenWidthDp < 840 -> 2
        screenWidthDp < 1200 -> 3
        else -> 4
    }
    val maxContentWidth = (columns * 460).dp
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = false)
    var showDownloadSheet by remember { mutableStateOf(false) }
    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxHeight()
                .widthIn(max = maxContentWidth)
                .fillMaxWidth(),
            contentPadding = PaddingValues(
                start = 24.dp,
                end = 24.dp,
                top = 96.dp, // Generous padding to start below the floating top islands
                bottom = 140.dp // Generous bottom clearance for floating nav capsule
            ),
            verticalArrangement = Arrangement.spacedBy(28.dp)
        ) {
            // 1. Hero Header Card (32dp radius, 24dp internal padding, 18% height increase)
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.Transparent),
                    shape = RoundedCornerShape(32.dp),
                    border = BorderStroke(1.dp, Color(0x14FFFFFF)),
                    elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                Brush.radialGradient(
                                    colors = listOf(
                                        Color(0x288B1E2D),
                                        Color(0x28D97706),
                                        Color(0x14181820),
                                        Color(0x00000000)
                                    ),
                                    center = androidx.compose.ui.geometry.Offset(1000f, 0f),
                                    radius = 1200f
                                )
                            )
                            .background(Color(0x14FFFFFF))
                            .padding(24.dp)
                    ) {
                        Column {
                            // Ambient light highlight behind title
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 16.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                CrazyAnimationOrb()
                            }

                            Spacer(modifier = Modifier.height(24.dp))

                            var isIncognitoDetailExpanded by remember { mutableStateOf(false) }

                            // Expanded Incognito Band upside of Search Bar
                            androidx.compose.animation.AnimatedVisibility(
                                visible = isIncognitoMode,
                                enter = androidx.compose.animation.expandVertically(expandFrom = Alignment.Bottom) + androidx.compose.animation.fadeIn(),
                                exit = androidx.compose.animation.shrinkVertically(shrinkTowards = Alignment.Bottom) + androidx.compose.animation.fadeOut()
                            ) {
                                Surface(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(bottom = 14.dp)
                                        .shadow(
                                            elevation = 12.dp,
                                            shape = RoundedCornerShape(20.dp),
                                            spotColor = Color(0xFFFF4D5A).copy(alpha = 0.35f)
                                        ),
                                    shape = RoundedCornerShape(20.dp),
                                    color = Color(0xFF23161A),
                                    border = BorderStroke(1.dp, Color(0xFFFF4D5A).copy(alpha = 0.45f))
                                ) {
                                    Column(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .animateContentSize(animationSpec = tween(300))
                                            .padding(horizontal = 16.dp, vertical = 12.dp)
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clickable { isIncognitoDetailExpanded = !isIncognitoDetailExpanded },
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                                                modifier = Modifier.weight(1f)
                                            ) {
                                                // Glowing Goggles / Glasses Icon Badge
                                                Box(
                                                    modifier = Modifier
                                                        .size(40.dp)
                                                        .background(
                                                            Brush.radialGradient(
                                                                colors = listOf(Color(0xFFFF4D5A).copy(alpha = 0.4f), Color(0x1AFF4D5A))
                                                            ),
                                                            shape = CircleShape
                                                        )
                                                        .border(1.dp, Color(0xFFFF4D5A).copy(alpha = 0.6f), CircleShape),
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Default.VisibilityOff,
                                                        contentDescription = "Goggles Incognito Icon",
                                                        tint = Color(0xFFFF4D5A),
                                                        modifier = Modifier.size(22.dp)
                                                    )
                                                }

                                                Column {
                                                    Text(
                                                        text = "No one can see you",
                                                        style = MaterialTheme.typography.titleMedium.copy(
                                                            fontWeight = FontWeight.Bold,
                                                            fontSize = 15.sp,
                                                            letterSpacing = 0.2.sp
                                                        ),
                                                        color = Color.White
                                                    )
                                                    Text(
                                                        text = if (isIncognitoDetailExpanded) "Tap to collapse details" else "Incognito active • Tap expand icon for details",
                                                        style = MaterialTheme.typography.labelSmall,
                                                        color = Color(0xFFFF8A95)
                                                    )
                                                }
                                            }

                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(2.dp)
                                            ) {
                                                // Expand Icon for More Detail
                                                IconButton(
                                                    onClick = { isIncognitoDetailExpanded = !isIncognitoDetailExpanded },
                                                    modifier = Modifier.size(36.dp)
                                                ) {
                                                    Icon(
                                                        imageVector = if (isIncognitoDetailExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                                                        contentDescription = "Expand for details",
                                                        tint = Color(0xFFFF4D5A)
                                                    )
                                                }

                                                // Close / Turn off Incognito
                                                IconButton(
                                                    onClick = onToggleIncognito,
                                                    modifier = Modifier.size(36.dp)
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Default.Close,
                                                        contentDescription = "Turn off Incognito",
                                                        tint = Color(0xFFA5A5B2)
                                                    )
                                                }
                                            }
                                        }

                                        // Expandable Detail View
                                        if (isIncognitoDetailExpanded) {
                                            Spacer(modifier = Modifier.height(10.dp))
                                            HorizontalDivider(
                                                color = Color(0xFFFF4D5A).copy(alpha = 0.25f),
                                                thickness = 1.dp
                                            )
                                            Spacer(modifier = Modifier.height(10.dp))

                                            Column(
                                                verticalArrangement = Arrangement.spacedBy(8.dp),
                                                modifier = Modifier.fillMaxWidth()
                                            ) {
                                                Row(
                                                    verticalAlignment = Alignment.Top,
                                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Default.Security,
                                                        contentDescription = null,
                                                        tint = Color(0xFFFF4D5A),
                                                        modifier = Modifier.size(16.dp).padding(top = 2.dp)
                                                    )
                                                    Text(
                                                        text = "Search & browsing histories are strictly paused.",
                                                        style = MaterialTheme.typography.bodySmall,
                                                        color = Color(0xFFE2E8F0)
                                                    )
                                                }

                                                Row(
                                                    verticalAlignment = Alignment.Top,
                                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Default.Lock,
                                                        contentDescription = null,
                                                        tint = Color(0xFFFF4D5A),
                                                        modifier = Modifier.size(16.dp).padding(top = 2.dp)
                                                    )
                                                    Text(
                                                        text = "Downloads are saved privately in isolated storage.",
                                                        style = MaterialTheme.typography.bodySmall,
                                                        color = Color(0xFFE2E8F0)
                                                    )
                                                }

                                                Row(
                                                    verticalAlignment = Alignment.Top,
                                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Default.Shield,
                                                        contentDescription = null,
                                                        tint = Color(0xFFFF4D5A),
                                                        modifier = Modifier.size(16.dp).padding(top = 2.dp)
                                                    )
                                                    Text(
                                                        text = "Your identity and tracking cookies remain hidden.",
                                                        style = MaterialTheme.typography.bodySmall,
                                                        color = Color(0xFFE2E8F0)
                                                    )
                                                }

                                                Spacer(modifier = Modifier.height(4.dp))
                                                Row(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    horizontalArrangement = Arrangement.End
                                                ) {
                                                    TextButton(
                                                        onClick = onToggleIncognito
                                                    ) {
                                                        Text(
                                                            text = "Turn Off Incognito",
                                                            color = Color(0xFFFF4D5A),
                                                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
                                                        )
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                            // 2. Glass Search Input Card (64dp height, 24dp radius, glass styling)
                            var historyExpanded by remember { mutableStateOf(false) }
                            var isInputFocused by remember { mutableStateOf(false) }
                            val focusManager = androidx.compose.ui.platform.LocalFocusManager.current

                            Column(modifier = Modifier.fillMaxWidth()) {
                                OutlinedTextField(
                                    value = urlInput,
                                    onValueChange = { 
                                        onUrlChange(it) 
                                        historyExpanded = false 
                                    },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(64.dp)
                                        .onFocusChanged { state ->
                                            isInputFocused = state.isFocused
                                            if (state.isFocused && urlHistory.isNotEmpty() && urlInput.isEmpty()) {
                                                historyExpanded = true
                                            }
                                        }
                                        .testTag("url_input_field"),
                                    textStyle = MaterialTheme.typography.bodyLarge.copy(color = Color.White, fontSize = 15.sp),
                                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                                    keyboardActions = KeyboardActions(onSearch = { 
                                        focusManager.clearFocus()
                                        historyExpanded = false
                                        onAnalyzeClick() 
                                    }),
                                    placeholder = { 
                                        Text(
                                            "Search videos, playlists or URLs...", 
                                            color = Color(0xFFA5A5B2).copy(alpha = 0.55f), 
                                            maxLines = 1, 
                                            overflow = TextOverflow.Ellipsis, 
                                            fontSize = 14.sp
                                        ) 
                                    },
                                    leadingIcon = {
                                        Icon(
                                            imageVector = Icons.Default.Language,
                                            contentDescription = "Website",
                                            tint = Color(0xFFFF7A00),
                                            modifier = Modifier
                                                .padding(start = 12.dp)
                                                .size(24.dp)
                                        )
                                    },
                                    trailingIcon = {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                                            modifier = Modifier.padding(end = 8.dp)
                                        ) {
                                            if (urlInput.isNotEmpty()) {
                                                IconButton(
                                                    onClick = onClearClick,
                                                    modifier = Modifier.size(36.dp)
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Default.Clear,
                                                        contentDescription = "Clear",
                                                        tint = Color(0xFFA5A5B2),
                                                        modifier = Modifier.size(20.dp)
                                                    )
                                                }
                                            } else {
                                                androidx.compose.material3.TextButton(
                                                    onClick = onPasteClick,
                                                    contentPadding = PaddingValues(horizontal = 12.dp)
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Default.ContentPaste,
                                                        contentDescription = "Paste",
                                                        tint = Color(0xFFFF9D33),
                                                        modifier = Modifier.size(18.dp)
                                                    )
                                                    Spacer(modifier = Modifier.width(4.dp))
                                                    Text("Paste", color = Color(0xFFFF9D33), fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                                }
                                            }

                                            Box(
                                                modifier = Modifier
                                                    .size(44.dp)
                                                    .shadow(
                                                        elevation = 6.dp,
                                                        shape = CircleShape,
                                                        spotColor = Color(0xFFFF7A00).copy(alpha = 0.5f)
                                                    )
                                                    .clip(CircleShape)
                                                    .background(
                                                        brush = Brush.verticalGradient(
                                                            colors = listOf(Color(0xFFFF9D33), Color(0xFFFF7A00))
                                                        )
                                                    )
                                                    .clickable(
                                                        enabled = urlInput.trim().isNotEmpty() && !isAnalyzing,
                                                        onClick = {
                                                            focusManager.clearFocus()
                                                            historyExpanded = false
                                                            onAnalyzeClick()
                                                        }
                                                    ),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                if (isAnalyzing) {
                                                    CircularProgressIndicator(
                                                        modifier = Modifier.size(18.dp),
                                                        color = Color.White,
                                                        strokeWidth = 2.dp
                                                    )
                                                } else {
                                                    Icon(
                                                        imageVector = Icons.Default.ArrowForward,
                                                        contentDescription = "Analyze",
                                                        tint = Color.White,
                                                        modifier = Modifier.size(20.dp)
                                                    )
                                                }
                                            }
                                        }
                                    },
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedContainerColor = Color(0x14FFFFFF),
                                        unfocusedContainerColor = Color(0x0FFFFFFF),
                                        focusedBorderColor = Color(0xFFFF7A00),
                                        unfocusedBorderColor = Color(0x14FFFFFF),
                                        focusedTextColor = Color.White,
                                        unfocusedTextColor = Color.White,
                                        cursorColor = Color(0xFFFF7A00)
                                    ),
                                    shape = RoundedCornerShape(24.dp),
                                    singleLine = true
                                )

                                // 1. Live Search Suggestions Overlay
                                androidx.compose.animation.AnimatedVisibility(
                                    visible = isInputFocused && urlInput.isNotBlank() && searchSuggestions.isNotEmpty(),
                                    enter = androidx.compose.animation.expandVertically() + androidx.compose.animation.fadeIn(),
                                    exit = androidx.compose.animation.shrinkVertically() + androidx.compose.animation.fadeOut()
                                ) {
                                    Card(
                                        modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                                        colors = CardDefaults.cardColors(containerColor = Color(0xFF14151B)),
                                        shape = RoundedCornerShape(18.dp),
                                        border = BorderStroke(1.dp, Color(0x20FFFFFF))
                                    ) {
                                        Column(modifier = Modifier.padding(vertical = 6.dp)) {
                                            searchSuggestions.take(8).forEach { suggestion ->
                                                Row(
                                                    modifier = Modifier
                                                        .fillMaxWidth()
                                                        .clickable {
                                                            onUrlChange(suggestion)
                                                            historyExpanded = false
                                                            focusManager.clearFocus()
                                                            onAnalyzeClick()
                                                        }
                                                        .padding(horizontal = 16.dp, vertical = 12.dp),
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Default.Search,
                                                        contentDescription = null,
                                                        tint = Color(0xFFFF9D33),
                                                        modifier = Modifier.size(18.dp)
                                                    )
                                                    Spacer(modifier = Modifier.width(12.dp))
                                                    Text(
                                                        text = suggestion,
                                                        color = Color.White,
                                                        fontSize = 14.sp,
                                                        fontWeight = FontWeight.Medium,
                                                        maxLines = 1,
                                                        overflow = TextOverflow.Ellipsis,
                                                        modifier = Modifier.weight(1f)
                                                    )
                                                    Icon(
                                                        imageVector = Icons.Default.NorthWest,
                                                        contentDescription = null,
                                                        tint = Color(0xFFA5A5B2),
                                                        modifier = Modifier.size(14.dp)
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }

                                // 2. URL History Overlay
                                androidx.compose.animation.AnimatedVisibility(
                                    visible = historyExpanded && urlHistory.isNotEmpty() && urlInput.isBlank(),
                                    enter = androidx.compose.animation.expandVertically() + androidx.compose.animation.fadeIn(),
                                    exit = androidx.compose.animation.shrinkVertically() + androidx.compose.animation.fadeOut()
                                ) {
                                    Card(
                                        modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                                        colors = CardDefaults.cardColors(containerColor = Color(0xFF111216)),
                                        shape = RoundedCornerShape(16.dp),
                                        border = BorderStroke(1.dp, Color(0x14FFFFFF))
                                    ) {
                                        Column(modifier = Modifier.padding(vertical = 8.dp)) {
                                            urlHistory.forEach { historyUrl ->
                                                Row(
                                                    modifier = Modifier
                                                        .fillMaxWidth()
                                                        .clickable {
                                                            onUrlChange(historyUrl)
                                                            historyExpanded = false
                                                            focusManager.clearFocus()
                                                        }
                                                        .padding(horizontal = 16.dp, vertical = 12.dp),
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Icon(Icons.Default.History, contentDescription = null, tint = Color(0xFFA5A5B2))
                                                    Spacer(modifier = Modifier.width(12.dp))
                                                    Text(historyUrl, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                                }
                                            }
                                            HorizontalDivider(color = Color(0x14FFFFFF), modifier = Modifier.padding(vertical = 4.dp))
                                            Row(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .clickable {
                                                        onClearUrlHistory()
                                                        historyExpanded = false
                                                    }
                                                    .padding(horizontal = 16.dp, vertical = 12.dp),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Icon(Icons.Default.Delete, contentDescription = null, tint = Color(0xFFFF4D5A))
                                                Spacer(modifier = Modifier.width(12.dp))
                                                Text("Clear History", color = Color(0xFFFF4D5A))
                                            }
                                        }
                                    }
                                }
                            }

                            if (urlInput.isNotBlank() && analyzedVideo == null) {
                                VideoSelectionPreview(
                                    url = urlInput,
                                    onAnalyzeClick = onAnalyzeClick
                                )
                            }
                        }
                    }
                }
            }

            // Analyzed Video details card (Now right under the search bar for direct access!)
            if (isAnalyzing) {
                item {
                    SkeletonAnalyzedVideoCard()
                }
            } else if (analyzedVideo != null) {
                item {
                    AnalyzedVideoCard(
                        video = analyzedVideo,
                        onOpenDownloadOptions = {
                            showDownloadSheet = true
                        },
                        onStreamBestClick = {
                            val nonAudio = analyzedVideo.formats.filter { 
                                val type = it.type.lowercase()
                                val qual = it.quality.lowercase()
                                val ext = it.ext.lowercase()
                                val isAudio = type == "audio" || 
                                              (it.vcodec == "none" && it.acodec != null && it.acodec != "none") ||
                                              qual.contains("kbps") || qual.contains("audio") ||
                                              ext == "mp3" || ext == "m4a" || ext == "aac" || ext == "opus" || ext == "wav" || ext == "flac" || ext == "ogg"
                                !isAudio
                            }
                            val bestFormat = nonAudio.filter { (it.height ?: 0) <= 1080 }
                                .maxByOrNull { it.height ?: 0 }
                                ?: nonAudio.minByOrNull { it.height ?: 100000 }
                                ?: analyzedVideo.formats.firstOrNull { it.type == "combined" }
                                ?: analyzedVideo.formats.firstOrNull { it.type == "video_only" }
                                ?: analyzedVideo.formats.firstOrNull()
                            bestFormat?.let { onStreamFormat(it) }
                        }
                    )
                }
            }

            if (searchResults.isEmpty()) {
                item {
                    Text(
                        text = "Featured Spotlight",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontSize = 22.sp,
                            letterSpacing = (-0.5).sp
                        ),
                        modifier = Modifier.padding(start = 4.dp, bottom = 4.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    CoverflowCarousel(
                        onPlayClick = { item ->
                            onUrlChange(item.url)
                            onAnalyzeClick()
                        },
                        onDownloadClick = { item ->
                            onUrlChange(item.url)
                            onAnalyzeClick()
                        }
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                }
            }

            // 3. Quick Action Row (80x80dp cards, 18dp gap, 24dp radius, lift 4dp when selected)
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(18.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val actions = listOf(
                        Triple("Analyze", Icons.Default.Bolt, onAnalyzeClick),
                        Triple("Playlist", Icons.Default.QueueMusic, { onUrlChange("https://www.youtube.com/playlist?list=PLrEnWoR738-qA8mX_5B9nZ70xQ3qK03k4"); onAnalyzeClick() }),
                        Triple("Audio", Icons.Default.Headphones, onToggleAudioOnly),
                        Triple("History", Icons.Default.History, { onUrlChange(urlHistory.firstOrNull() ?: "") })
                    )

                    actions.forEach { (label, icon, onClick) ->
                        val isSelected = (label == "Audio" && isAudioOnly) || (label == "Analyze" && isAnalyzing)
                        val offsetAnim by animateDpAsState(
                            targetValue = if (isSelected) (-4).dp else 0.dp,
                            animationSpec = spring(dampingRatio = Spring.DampingRatioLowBouncy, stiffness = Spring.StiffnessMedium),
                            label = "ActionOffset_$label"
                        )
                        val selectedBgAlpha by animateFloatAsState(
                            targetValue = if (isSelected) 1f else 0f,
                            animationSpec = tween(durationMillis = 250),
                            label = "ActionBgAlpha_$label"
                        )
                        val borderColor by animateColorAsState(
                            targetValue = if (isSelected) Color(0xFFF59E0B) else Color.White.copy(alpha = 0.1f),
                            animationSpec = tween(durationMillis = 200),
                            label = "ActionBorderColor_$label"
                        )
                        val iconTint by animateColorAsState(
                            targetValue = if (isSelected) Color.White else Color(0xFFB7BBC5),
                            animationSpec = tween(durationMillis = 200),
                            label = "ActionIconTint_$label"
                        )
                        val textTint by animateColorAsState(
                            targetValue = if (isSelected) Color(0xFFF59E0B) else Color(0xFFB7BBC5),
                            animationSpec = tween(durationMillis = 200),
                            label = "ActionTextTint_$label"
                        )

                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Box(
                                modifier = Modifier
                                    .offset(y = offsetAnim)
                                    .size(80.dp)
                                    .clip(RoundedCornerShape(24.dp))
                                    .background(
                                        Brush.linearGradient(
                                            colors = listOf(Color(0x1AFFFFFF), Color(0x0FFFFFFF))
                                        )
                                    )
                                    .background(
                                        brush = Brush.linearGradient(
                                            colors = listOf(Color(0xFF8B1E2D), Color(0xFFD97706))
                                        ),
                                        alpha = selectedBgAlpha
                                    )
                                    .border(
                                        width = 1.dp,
                                        color = borderColor,
                                        shape = RoundedCornerShape(24.dp)
                                    )
                                    .clickable(onClick = onClick),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = icon,
                                    contentDescription = label,
                                    tint = iconTint,
                                    modifier = Modifier.size(30.dp)
                                )
                            }
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = label,
                                style = MaterialTheme.typography.labelMedium.copy(
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = textTint
                                )
                            )
                        }
                    }
                }
            }



            // Removed Recent Downloads Carousel Section as requested
        // 🔍 Keyword Search Progress Indicator
        if (isSearching) {
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "Searching YouTube keywords via JNI...",
                        color = SleekTextSecondary,
                        style = MaterialTheme.typography.bodyMedium.copy(
                            fontWeight = FontWeight.Medium,
                            fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
                        ),
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                }
            }
            items(3) {
                SkeletonSearchResultItem()
            }
        }
        // 🔍 Keyword Search Results Display
        if (!isSearching && searchResults.isNotEmpty()) {
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 4.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "SEARCH RESULTS",
                            style = MaterialTheme.typography.titleSmall.copy(
                                color = SleekPurpleDark,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                letterSpacing = 1.sp
                            )
                        )
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(2.dp),
                            modifier = Modifier.padding(start = 2.dp)
                        ) {
                            Text(
                                text = "video",
                                style = MaterialTheme.typography.labelMedium.copy(
                                    fontWeight = if (searchFilterType == "VIDEO") FontWeight.Bold else FontWeight.Medium,
                                    color = if (searchFilterType == "VIDEO") SleekPurpleLight else SleekTextSecondary
                                ),
                                modifier = Modifier
                                    .clickable(
                                        interactionSource = remember { MutableInteractionSource() },
                                        indication = null
                                    ) {
                                        viewModel?.setSearchFilterType("VIDEO")
                                    }
                                    .padding(horizontal = 4.dp, vertical = 2.dp)
                            )
                            Text(
                                text = "|",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = SleekTextMuted.copy(alpha = 0.5f)
                                )
                            )
                            Text(
                                text = "shorts",
                                style = MaterialTheme.typography.labelMedium.copy(
                                    fontWeight = if (searchFilterType == "SHORTS") FontWeight.Bold else FontWeight.Medium,
                                    color = if (searchFilterType == "SHORTS") SleekPurpleLight else SleekTextSecondary
                                ),
                                modifier = Modifier
                                    .clickable(
                                        interactionSource = remember { MutableInteractionSource() },
                                        indication = null
                                    ) {
                                        viewModel?.setSearchFilterType("SHORTS")
                                    }
                                    .padding(horizontal = 4.dp, vertical = 2.dp)
                            )
                        }
                    }
                    Text(
                        text = "Found ${searchResults.size}",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = SleekTextMuted,
                            fontWeight = FontWeight.SemiBold
                        )
                    )
                }
            }
            if (columns == 1) {
                itemsIndexed(searchResults, key = { index, result -> result.id + "_$index" }) { index, result ->
                    val context = LocalContext.current
                    LaunchedEffect(index, searchResults) {
                        // Debounce: Wait 1500ms. If user scrolls away, this coroutine is cancelled and no work occurs!
                        delay(1500)
                        val nextStart = index + 1
                        val nextEnd = minOf(searchResults.size, index + 3) // Limit to 2 videos max
                        if (nextStart < nextEnd) {
                            val urls = searchResults.subList(nextStart, nextEnd).map { it.originalUrl }
                            YtdlpPipelineManager.prefetchBatch(context, urls)
                        }
                    }
                    SearchResultItemRow(
                        result = result,
                        index = index,
                        onClick = { onSearchResultClick(result) },
                        modifier = Modifier.animateItem()
                    )
                }
            } else {
                val chunks = searchResults.chunked(columns)
                itemsIndexed(chunks, key = { index, _ -> "search_chunk_$index" }) { index, chunk ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(24.dp)
                    ) {
                        chunk.forEachIndexed { chunkIndex, result ->
                            val actualIndex = index * columns + chunkIndex
                            val context = LocalContext.current
                            LaunchedEffect(actualIndex, searchResults) {
                                delay(1500)
                                val nextStart = actualIndex + 1
                                val nextEnd = minOf(searchResults.size, actualIndex + 3)
                                if (nextStart < nextEnd) {
                                    val urls = searchResults.subList(nextStart, nextEnd).map { it.originalUrl }
                                    YtdlpPipelineManager.prefetchBatch(context, urls)
                                }
                            }
                            Box(modifier = Modifier.weight(1f)) {
                                SearchResultItemRow(
                                    result = result,
                                    index = actualIndex,
                                    onClick = { onSearchResultClick(result) },
                                    modifier = Modifier.animateItem()
                                )
                            }
                        }
                        val emptySlots = columns - chunk.size
                        repeat(emptySlots) {
                            Spacer(modifier = Modifier.weight(1f))
                        }
                    }
                }
            }
            if (searchFilterType == "VIDEO") {
                item {
                    val isLoadingMoreVideos by (viewModel?.isLoadingMoreVideos ?: kotlinx.coroutines.flow.MutableStateFlow(false)).collectAsStateWithLifecycle()
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 12.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Surface(
                            onClick = {
                                if (!isLoadingMoreVideos) {
                                    viewModel?.loadMoreVideos()
                                }
                            },
                            shape = RoundedCornerShape(24.dp),
                            color = Color(0xFF1E1F28),
                            border = BorderStroke(1.dp, SleekPurpleLight.copy(alpha = 0.5f)),
                            modifier = Modifier.padding(horizontal = 16.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 24.dp, vertical = 12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                if (isLoadingMoreVideos) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(18.dp),
                                        color = SleekPurpleLight,
                                        strokeWidth = 2.dp
                                    )
                                    Text(
                                        text = "Loading more videos...",
                                        color = SleekPurpleLight,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                } else {
                                    Icon(
                                        imageVector = Icons.Default.ExpandMore,
                                        contentDescription = "Load More Videos",
                                        tint = SleekPurpleLight,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Text(
                                        text = "Load More Videos",
                                        color = Color.White,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            } else if (searchFilterType == "SHORTS") {
                item {
                    val isLoadingMoreShorts by (viewModel?.isLoadingMoreShorts ?: kotlinx.coroutines.flow.MutableStateFlow(false)).collectAsStateWithLifecycle()
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 12.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Surface(
                            onClick = {
                                if (!isLoadingMoreShorts) {
                                    viewModel?.loadMoreShorts()
                                }
                            },
                            shape = RoundedCornerShape(24.dp),
                            color = Color(0xFF1E1F28),
                            border = BorderStroke(1.dp, SleekPurpleLight.copy(alpha = 0.5f)),
                            modifier = Modifier.padding(horizontal = 16.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 24.dp, vertical = 12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                if (isLoadingMoreShorts) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(18.dp),
                                        color = SleekPurpleLight,
                                        strokeWidth = 2.dp
                                    )
                                    Text(
                                        text = "Loading more shorts...",
                                        color = SleekPurpleLight,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                } else {
                                    Icon(
                                        imageVector = Icons.Default.ExpandMore,
                                        contentDescription = "Load More Shorts",
                                        tint = SleekPurpleLight,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Text(
                                        text = "Load More Shorts",
                                        color = Color.White,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
        // Active Diagnostics / Error Info
        if (analysisError != null) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = CrimsonFailure.copy(alpha = 0.15f)),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, CrimsonFailure.copy(alpha = 0.3f))
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Warning, contentDescription = "Error", tint = CrimsonFailure, modifier = Modifier.size(24.dp))
                        Text(
                            text = analysisError,
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = CrimsonFailure,
                                fontWeight = FontWeight.Medium
                            )
                        )
                    }
                }
            }
        }
        // Active Downloads section
        if (activeDownloads.isNotEmpty()) {
            val pausedBatteryCount = activeDownloads.values.count { it.status == DownloadStatus.PAUSED && (it.speedText.contains("Battery", ignoreCase = true) || it.speedText.contains("Charging", ignoreCase = true)) }
            if (pausedBatteryCount > 0) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(AmberAccent.copy(alpha = 0.15f), RoundedCornerShape(12.dp))
                            .border(1.dp, AmberAccent.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                            .padding(horizontal = 14.dp, vertical = 10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                modifier = Modifier.weight(1f),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.BatteryAlert, contentDescription = null, tint = AmberAccent, modifier = Modifier.size(20.dp))
                                Column {
                                    Text(
                                        text = "$pausedBatteryCount Large Download(s) Auto-Paused",
                                        style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                                        color = SleekTextPrimary
                                    )
                                    Text(
                                        text = "Paused to save battery (<20% or not charging). Connect charger or resume manually.",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = SleekTextSecondary
                                    )
                                }
                            }
                            TextButton(
                                onClick = { viewModel?.forceResumeAllDownloads() }
                            ) {
                                Text("Resume All", color = AmberAccent, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
            item {
                Text(
                    text = "ACTIVE DOWNLOADS",
                    style = MaterialTheme.typography.titleSmall.copy(
                        color = AmberAccent,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    ),
                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                )
            }
            val activeTasksList = activeDownloads.values.toList()
            if (columns == 1) {
                items(activeTasksList, key = { it.id }) { task ->
                    ActiveDownloadCard(
                        task = task, 
                        onCancelClick = { onCancelActiveTask(task.id) },
                        onResumeClick = { viewModel?.resumeDownload(task.id) },
                        modifier = Modifier.animateItem()
                    )
                }
            } else {
                val chunks = activeTasksList.chunked(columns)
                itemsIndexed(chunks, key = { index, _ -> "active_chunk_$index" }) { index, chunk ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(24.dp)
                    ) {
                        chunk.forEach { task ->
                            Box(modifier = Modifier.weight(1f)) {
                                ActiveDownloadCard(
                                    task = task, 
                                    onCancelClick = { onCancelActiveTask(task.id) },
                                    onResumeClick = { viewModel?.resumeDownload(task.id) },
                                    modifier = Modifier.animateItem()
                                )
                            }
                        }
                        val emptySlots = columns - chunk.size
                        repeat(emptySlots) {
                            Spacer(modifier = Modifier.weight(1f))
                        }
                    }
                }
            }

            // Live Engine & Download Logs (when logs are present)
            if (executionLogs.isNotEmpty()) {
                item {
                    val context = androidx.compose.ui.platform.LocalContext.current
                    val clipboard = androidx.compose.ui.platform.LocalClipboardManager.current
                    var isExpanded by remember { mutableStateOf(true) }

                    Card(
                        colors = CardDefaults.cardColors(containerColor = SleekCardDark),
                        shape = RoundedCornerShape(16.dp),
                        border = BorderStroke(1.dp, SleekBorderColor),
                        modifier = Modifier.fillMaxWidth().testTag("live_logs_card")
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    modifier = Modifier.clickable { isExpanded = !isExpanded }
                                ) {
                                    Icon(
                                        Icons.Default.Terminal,
                                        contentDescription = "Terminal Logs",
                                        tint = SleekPurpleLight,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Text(
                                        text = "LIVE CONSOLE LOGS (${executionLogs.size})",
                                        style = MaterialTheme.typography.labelMedium.copy(
                                            fontWeight = FontWeight.Bold,
                                            fontFamily = FontFamily.Monospace,
                                            letterSpacing = 1.sp
                                        ),
                                        color = SleekTextPrimary
                                    )
                                    Icon(
                                        if (isExpanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                                        contentDescription = "Toggle logs",
                                        tint = SleekTextMuted,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }

                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    OutlinedButton(
                                        onClick = {
                                            val logText = executionLogs.joinToString("\n")
                                            clipboard.setText(androidx.compose.ui.text.AnnotatedString(logText))
                                            android.widget.Toast.makeText(context, "Copied ${executionLogs.size} log lines", android.widget.Toast.LENGTH_SHORT).show()
                                        },
                                        shape = RoundedCornerShape(10.dp),
                                        border = BorderStroke(1.dp, SleekBorderColor),
                                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                        modifier = Modifier.height(34.dp).testTag("copy_logs_home_btn")
                                    ) {
                                        Icon(
                                            Icons.Default.ContentCopy,
                                            contentDescription = "Copy Logs",
                                            modifier = Modifier.size(14.dp),
                                            tint = SleekTextPrimary
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            "Copy",
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                color = SleekTextPrimary,
                                                fontWeight = FontWeight.SemiBold
                                            )
                                        )
                                    }

                                    IconButton(
                                        onClick = {
                                            onClearLogs()
                                            android.widget.Toast.makeText(context, "Logs cleared", android.widget.Toast.LENGTH_SHORT).show()
                                        },
                                        modifier = Modifier.size(34.dp).testTag("clear_logs_home_btn")
                                    ) {
                                        Icon(
                                            Icons.Default.DeleteSweep,
                                            contentDescription = "Clear Logs",
                                            modifier = Modifier.size(18.dp),
                                            tint = CrimsonFailure.copy(alpha = 0.8f)
                                        )
                                    }
                                }
                            }

                            if (isExpanded) {
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = Color.Black),
                                    shape = RoundedCornerShape(10.dp),
                                    border = BorderStroke(1.dp, Color.White.copy(alpha = 0.08f)),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .heightIn(min = 80.dp, max = 220.dp)
                                ) {
                                    SelectionContainer {
                                        LazyColumn(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(10.dp),
                                            verticalArrangement = Arrangement.spacedBy(3.dp)
                                        ) {
                                            items(executionLogs) { logLine ->
                                                val logColor = when {
                                                    logLine.contains("ERROR", ignoreCase = true) || logLine.contains("FAIL", ignoreCase = true) || logLine.contains("Exception", ignoreCase = true) -> CrimsonFailure
                                                    logLine.contains("WARN", ignoreCase = true) || logLine.contains("⚠️") -> AmberAccent
                                                    logLine.contains("SUCCESS", ignoreCase = true) || logLine.contains("COMPLETED", ignoreCase = true) || logLine.contains("100%") -> EmeraldSuccess
                                                    logLine.startsWith("[download]") -> SleekPurpleLight
                                                    else -> SleekTextSecondary
                                                }
                                                Text(
                                                    text = logLine,
                                                    color = logColor,
                                                    fontFamily = FontFamily.Monospace,
                                                    fontSize = 11.sp,
                                                    lineHeight = 14.sp
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showDownloadSheet && analyzedVideo != null) {
        var formatSearchQuery by remember { mutableStateOf("") }
        var formatSortBy by remember { mutableStateOf("Default") } // "Default", "Size (Desc)", "Size (Asc)", "Quality"
        var formatExtensionFilter by remember { mutableStateOf("All") } // "All", "MP4", "WebM", "MKV", "MP3", "M4A"

        ModalBottomSheet(
            onDismissRequest = { showDownloadSheet = false },
            sheetState = sheetState,
            containerColor = SleekCardDark,
            dragHandle = { BottomSheetDefaults.DragHandle(color = SleekTextSecondary) }
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
                    .padding(bottom = 32.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "DOWNLOAD OPTIONS",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = SleekPurpleDark,
                                letterSpacing = 1.sp
                            )
                        )
                        Text(
                            text = if (showAdvancedFormats) "Showing all raw formats" else "Showing optimized options",
                            style = MaterialTheme.typography.bodySmall.copy(color = SleekTextSecondary)
                        )
                    }
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "Show All",
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = if (showAdvancedFormats) SleekPurpleLight else SleekTextMuted
                            )
                        )
                        SmoothToggle(
                            checked = showAdvancedFormats,
                            onCheckedChange = { onToggleShowAdvancedFormats(it) }
                        )
                    }
                }
                val (videoFormats, audioFormats) = remember(analyzedVideo.formats, showAdvancedFormats, formatSearchQuery, formatSortBy, formatExtensionFilter) {
                    try {
                        fun isAudioFormat(fmt: VideoFormatUi): Boolean {
                            val type = fmt.type.lowercase()
                            val qual = fmt.quality.lowercase()
                            val ext = fmt.ext.lowercase()
                            return type == "audio" || 
                                   (fmt.vcodec == "none" && fmt.acodec != null && fmt.acodec != "none") ||
                                   qual.contains("kbps") || qual.contains("audio") ||
                                   ext == "mp3" || ext == "m4a" || ext == "aac" || ext == "opus" || ext == "wav" || ext == "flac" || ext == "ogg"
                        }

                        val rawVideos = analyzedVideo.formats.filter { 
                            !isAudioFormat(it) && 
                            !it.ext.equals("mhtml", ignoreCase = true) && 
                            it.formatId != 9999 && 
                            it.formatId != 9911 
                        }
                        val rawAudios = analyzedVideo.formats.filter { isAudioFormat(it) }

                        val bestAudioSource = rawAudios.maxByOrNull { it.sizeBytes } 
                            ?: rawVideos.maxByOrNull { it.sizeBytes } 
                            ?: analyzedVideo.formats.maxByOrNull { it.sizeBytes }

                        val (baseVideos, baseAudios) = if (showAdvancedFormats) {
                            val vList = if (rawVideos.isNotEmpty()) rawVideos else analyzedVideo.formats

                            val presets = if (bestAudioSource != null) {
                                listOf(
                                    "MP3" to "mp3",
                                    "M4A" to "m4a",
                                    "AAC" to "aac",
                                    "WAV" to "wav",
                                    "FLAC" to "flac",
                                    "OPUS" to "opus",
                                    "OGG" to "ogg"
                                ).map { (label, ext) ->
                                    bestAudioSource.copy(quality = label, ext = ext, type = "audio")
                                }
                            } else emptyList()

                            val aList = (rawAudios + presets).distinctBy { "${it.quality}_${it.ext}_${it.formatId}" }
                            Pair(vList, aList)
                        } else {
                            val groupedByHeight = rawVideos.mapNotNull { fmt ->
                                val h = fmt.height ?: run {
                                    val matcher = java.util.regex.Pattern.compile("""(\d+)p""", java.util.regex.Pattern.CASE_INSENSITIVE).matcher(fmt.quality)
                                    if (matcher.find()) matcher.group(1).toIntOrNull() else null
                                }
                                if (h != null) Pair(h, fmt) else null
                            }.groupBy({ it.first }, { it.second })

                            val cleanVideoFormats = if (groupedByHeight.isNotEmpty()) {
                                val bestVideos = groupedByHeight.values.mapNotNull { formatsAtRes ->
                                    formatsAtRes.maxByOrNull { fmt ->
                                        val extIsMp4 = fmt.ext.equals("mp4", ignoreCase = true)
                                        val extIsWebm = fmt.ext.equals("webm", ignoreCase = true)
                                        val hasAudio = fmt.type == "combined" || fmt.hasAudio
                                        val baseScore = when {
                                            extIsMp4 && hasAudio -> 4000L
                                            extIsMp4 && !hasAudio -> 3000L
                                            extIsWebm && hasAudio -> 2000L
                                            extIsWebm && !hasAudio -> 1000L
                                            else -> 500L
                                        }
                                        val detailScore = ((fmt.tbr ?: 0.0).toLong() * 10L) + (fmt.sizeBytes / 100000L)
                                        baseScore * 100000000L + detailScore
                                    }
                                }
                                bestVideos.sortedByDescending { fmt ->
                                    val h = fmt.height
                                    if (h != null) {
                                        h
                                    } else {
                                        val matcher = java.util.regex.Pattern.compile("""(\d+)p""", java.util.regex.Pattern.CASE_INSENSITIVE).matcher(fmt.quality)
                                        if (matcher.find()) matcher.group(1).toIntOrNull() ?: 0 else 0
                                    }
                                }.map { fmt ->
                                    val h = if (fmt.height != null) fmt.height else {
                                        val matcher = java.util.regex.Pattern.compile("""(\d+)p""", java.util.regex.Pattern.CASE_INSENSITIVE).matcher(fmt.quality)
                                        if (matcher.find()) matcher.group(1).toIntOrNull() ?: 360 else 360
                                    }
                                    fmt.copy(quality = "${h}p")
                                }
                            } else {
                                rawVideos.map { fmt ->
                                    val h = fmt.height ?: 360
                                    fmt.copy(quality = if (fmt.quality.contains("p")) fmt.quality else "${h}p")
                                }
                            }

                            val cleanAudioFormats = mutableListOf<VideoFormatUi>()
                            if (bestAudioSource != null) {
                                cleanAudioFormats.add(bestAudioSource.copy(quality = "MP3", ext = "mp3", type = "audio"))
                                cleanAudioFormats.add(bestAudioSource.copy(quality = "M4A", ext = "m4a", type = "audio"))
                                val topRaw = rawAudios.maxByOrNull { it.sizeBytes }
                                if (topRaw != null) {
                                    cleanAudioFormats.add(topRaw)
                                }
                            }

                            val finalCleanAudios = cleanAudioFormats.distinctBy { "${it.quality}_${it.ext}" }

                            Pair(cleanVideoFormats, finalCleanAudios)
                        }

                        // Apply Search Query Filter
                        var filteredV = baseVideos
                        var filteredA = baseAudios

                        if (formatSearchQuery.isNotBlank()) {
                            filteredV = filteredV.filter { 
                                it.quality.contains(formatSearchQuery, ignoreCase = true) || 
                                it.ext.contains(formatSearchQuery, ignoreCase = true) ||
                                it.sizeText.contains(formatSearchQuery, ignoreCase = true)
                            }
                            filteredA = filteredA.filter { 
                                it.quality.contains(formatSearchQuery, ignoreCase = true) || 
                                it.ext.contains(formatSearchQuery, ignoreCase = true) ||
                                it.sizeText.contains(formatSearchQuery, ignoreCase = true)
                            }
                        }

                        // Apply Extension Filter
                        if (formatExtensionFilter != "All") {
                            filteredV = filteredV.filter { it.ext.equals(formatExtensionFilter, ignoreCase = true) }
                            filteredA = filteredA.filter { it.ext.equals(formatExtensionFilter, ignoreCase = true) }
                        }

                        // Apply Sorting Options
                        when (formatSortBy) {
                            "Size (Desc)" -> {
                                filteredV = filteredV.sortedByDescending { it.sizeBytes }
                                filteredA = filteredA.sortedByDescending { it.sizeBytes }
                            }
                            "Size (Asc)" -> {
                                filteredV = filteredV.sortedBy { it.sizeBytes }
                                filteredA = filteredA.sortedBy { it.sizeBytes }
                            }
                            "Quality" -> {
                                filteredV = filteredV.sortedByDescending { it.height ?: 0 }
                                filteredA = filteredA.sortedByDescending { it.audioBitrateKbps ?: it.bitrateKbps ?: 0 }
                            }
                            else -> {
                                // Keep default ordering (quality-desc for video)
                            }
                        }

                        Pair(filteredV, filteredA)
                    } catch (e: Throwable) {
                        Pair(analyzedVideo.formats, emptyList<VideoFormatUi>())
                    }
                }
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 12.dp)
                                .clip(RoundedCornerShape(16.dp))
                                .background(Color.White.copy(alpha = 0.05f))
                                .border(1.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(16.dp))
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(width = 110.dp, height = 62.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(Color.Black)
                            ) {
                                if (!analyzedVideo.thumbnailUrl.isNullOrEmpty()) {
                                    AsyncImage(
                                        model = analyzedVideo.thumbnailUrl,
                                        contentDescription = "Content Thumbnail",
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier.fillMaxSize()
                                    )
                                } else {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .background(
                                                Brush.linearGradient(
                                                    colors = listOf(SleekPurpleLight, SleekPurpleDark)
                                                )
                                            ),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.VideoLibrary,
                                            contentDescription = null,
                                            tint = Color.White,
                                            modifier = Modifier.size(28.dp)
                                        )
                                    }
                                }

                                if (analyzedVideo.durationText.isNotBlank()) {
                                    Box(
                                        modifier = Modifier
                                            .align(Alignment.BottomEnd)
                                            .padding(4.dp)
                                            .background(Color.Black.copy(alpha = 0.8f), shape = RoundedCornerShape(4.dp))
                                            .padding(horizontal = 4.dp, vertical = 1.dp)
                                    ) {
                                        Text(
                                            text = analyzedVideo.durationText,
                                            color = Color.White,
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                fontSize = 8.sp,
                                                fontWeight = FontWeight.Bold,
                                                fontFamily = FontFamily.Monospace
                                            )
                                        )
                                    }
                                }
                            }

                            Column(
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(
                                    text = analyzedVideo.title,
                                    color = SleekTextPrimary,
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        lineHeight = 16.sp
                                    ),
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Person,
                                        contentDescription = null,
                                        tint = SleekPurpleLight,
                                        modifier = Modifier.size(11.dp)
                                    )
                                    Text(
                                        text = analyzedVideo.author.ifBlank { "Unknown Creator" },
                                        color = SleekTextSecondary,
                                        style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }
                    }

                    item {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            // Search field
                            OutlinedTextField(
                                value = formatSearchQuery,
                                onValueChange = { formatSearchQuery = it },
                                placeholder = { 
                                    Text(
                                        "Filter resolution or extension...", 
                                        color = SleekTextMuted,
                                        fontSize = 13.sp
                                    ) 
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(50.dp)
                                    .testTag("format_search_input"),
                                singleLine = true,
                                shape = RoundedCornerShape(12.dp),
                                textStyle = MaterialTheme.typography.bodyMedium.copy(color = Color.White),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White,
                                    focusedBorderColor = SleekPurpleLight,
                                    unfocusedBorderColor = Color.White.copy(alpha = 0.15f),
                                    focusedContainerColor = Color.Black.copy(alpha = 0.3f),
                                    unfocusedContainerColor = Color.Black.copy(alpha = 0.15f)
                                ),
                                leadingIcon = {
                                    Icon(
                                        imageVector = Icons.Default.Search, 
                                        contentDescription = null, 
                                        tint = SleekTextSecondary, 
                                        modifier = Modifier.size(18.dp)
                                    )
                                },
                                trailingIcon = if (formatSearchQuery.isNotEmpty()) {
                                    {
                                        IconButton(onClick = { formatSearchQuery = "" }) {
                                            Icon(
                                                imageVector = Icons.Default.Close, 
                                                contentDescription = "Clear", 
                                                tint = SleekTextSecondary, 
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }
                                    }
                                } else null
                            )

                            // Quick control chips row for sorting
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                // Sort Options Label
                                Row(
                                    modifier = Modifier
                                        .background(Color.White.copy(alpha = 0.04f), RoundedCornerShape(8.dp))
                                        .border(0.5.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(8.dp))
                                        .padding(horizontal = 8.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Sort,
                                        contentDescription = null,
                                        tint = SleekPurpleLight,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Text(
                                        text = "Sort:",
                                        color = SleekTextMuted,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Medium
                                    )
                                }

                                listOf("Default", "Size (Desc)", "Size (Asc)", "Quality").forEach { option ->
                                    SleekFilterChip(
                                        selected = formatSortBy == option,
                                        onClick = { formatSortBy = option },
                                        label = option
                                    )
                                }
                            }

                            // Quick control chips row for extension filtering
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                // Extension Filter Label
                                Row(
                                    modifier = Modifier
                                        .background(Color.White.copy(alpha = 0.04f), RoundedCornerShape(8.dp))
                                        .border(0.5.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(8.dp))
                                        .padding(horizontal = 8.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.FilterList,
                                        contentDescription = null,
                                        tint = SleekPurpleLight,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Text(
                                        text = "Ext:",
                                        color = SleekTextMuted,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Medium
                                    )
                                }

                                listOf("All", "MP4", "WebM", "MKV", "MP3", "M4A").forEach { ext ->
                                    SleekFilterChip(
                                        selected = formatExtensionFilter == ext,
                                        onClick = { formatExtensionFilter = ext },
                                        label = ext
                                    )
                                }
                            }

                            // Subtitle & Audio Feature Quick Controls
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    modifier = Modifier
                                        .background(Color.White.copy(alpha = 0.04f), RoundedCornerShape(8.dp))
                                        .border(0.5.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(8.dp))
                                        .padding(horizontal = 8.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.ClosedCaption,
                                        contentDescription = null,
                                        tint = SleekPurpleLight,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Text(
                                        text = "Features:",
                                        color = SleekTextMuted,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Medium
                                    )
                                }

                                SleekFilterChip(
                                    selected = embedSubtitles,
                                    onClick = { viewModel?.updateEmbedSubtitles(!embedSubtitles) },
                                    label = if (embedSubtitles) "Subtitles: ON" else "Subtitles: OFF"
                                )

                                SleekFilterChip(
                                    selected = embedAutoSubtitles,
                                    onClick = { viewModel?.updateEmbedAutoSubtitles(!embedAutoSubtitles) },
                                    label = if (embedAutoSubtitles) "Auto-Subs: ON" else "Auto-Subs: OFF"
                                )

                                SleekFilterChip(
                                    selected = embedAudioMetadata,
                                    onClick = { viewModel?.updateEmbedAudioMetadata(!embedAudioMetadata) },
                                    label = if (embedAudioMetadata) "Cover & Tags: ON" else "Cover & Tags: OFF"
                                )

                                SleekFilterChip(
                                    selected = audioMultistreams,
                                    onClick = { viewModel?.updateAudioMultistreams(!audioMultistreams) },
                                    label = if (audioMultistreams) "Multi-Audio: ON" else "Multi-Audio: OFF"
                                )
                            }
                        }
                    }

                    if (videoFormats.isNotEmpty()) {
                        item(key = "header_video_formats") {
                            Text(
                                text = "VIDEO",
                                style = MaterialTheme.typography.labelSmall.copy(color = SleekTextSecondary),
                                modifier = Modifier.padding(bottom = 4.dp)
                            )
                        }
                        items(
                            items = videoFormats,
                            key = { format -> "v_${format.formatId}_${format.quality}_${format.ext}_${format.sizeBytes}_${format.downloadUrl.hashCode()}" }
                        ) { format ->
                            FormatRowItem(
                                format = format, 
                                showAdvanced = showAdvancedFormats,
                                onDownloadClick = {
                                    onDownloadFormat(format)
                                    showDownloadSheet = false
                                },
                                onStreamClick = {
                                    onStreamFormat(format)
                                    showDownloadSheet = false
                                },
                                onScheduleClick = if (onScheduleFormat != null) {
                                    {
                                        onScheduleFormat(format)
                                        showDownloadSheet = false
                                    }
                                } else null
                            )
                        }
                    }
                    if (audioFormats.isNotEmpty()) {
                        item(key = "header_audio_formats") {
                            Spacer(Modifier.height(8.dp))
                            Text(
                                text = "AUDIO",
                                style = MaterialTheme.typography.labelSmall.copy(color = SleekTextSecondary),
                                modifier = Modifier.padding(bottom = 4.dp)
                            )
                        }
                        items(
                            items = audioFormats,
                            key = { format -> "a_${format.formatId}_${format.quality}_${format.ext}_${format.sizeBytes}_${format.downloadUrl.hashCode()}" }
                        ) { format ->
                            FormatRowItem(
                                format = format, 
                                showAdvanced = showAdvancedFormats,
                                onDownloadClick = {
                                    onDownloadFormat(format)
                                    showDownloadSheet = false
                                },
                                onStreamClick = {
                                    onStreamFormat(format)
                                    showDownloadSheet = false
                                },
                                onScheduleClick = if (onScheduleFormat != null) {
                                    {
                                        onScheduleFormat(format)
                                        showDownloadSheet = false
                                    }
                                } else null
                            )
                        }
                    }
                }
            }
        }
    }
}
}

@Composable
fun ActiveDownloadCard(
    task: ActiveDownloadTask,
    onCancelClick: () -> Unit,
    onResumeClick: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val slideInOffset = remember { Animatable(60f) }
    val opacity = remember { Animatable(0f) }

    LaunchedEffect(key1 = task.id) {
        launch {
            slideInOffset.animateTo(
                targetValue = 0f,
                animationSpec = spring(
                    dampingRatio = Spring.DampingRatioLowBouncy,
                    stiffness = Spring.StiffnessMediumLow
                )
            )
        }
        launch {
            opacity.animateTo(
                targetValue = 1f,
                animationSpec = tween(durationMillis = 300, easing = LinearOutSlowInEasing)
            )
        }
    }

    val infiniteTransition = androidx.compose.animation.core.rememberInfiniteTransition()
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.5f,
        targetValue = 1f,
        animationSpec = androidx.compose.animation.core.infiniteRepeatable(
            animation = androidx.compose.animation.core.tween(1000, easing = androidx.compose.animation.core.FastOutSlowInEasing),
            repeatMode = androidx.compose.animation.core.RepeatMode.Reverse
        ), label = "PulseAlpha"
    )
    val borderColor = when (task.status) {
        DownloadStatus.FAILED, DownloadStatus.CORRUPTED -> CrimsonFailure.copy(alpha = 0.6f)
        DownloadStatus.DOWNLOADING -> SleekPurpleLight.copy(alpha = pulseAlpha)
        DownloadStatus.COMPLETED -> EmeraldSuccess.copy(alpha = 0.8f)
        DownloadStatus.PENDING, DownloadStatus.QUEUED -> SleekTextSecondary.copy(alpha = 0.5f)
        DownloadStatus.PAUSED, DownloadStatus.INCOMPLETE -> AmberAccent.copy(alpha = 0.6f)
        DownloadStatus.RECOVERABLE -> Color(0xFF00E5FF).copy(alpha = 0.7f)
    }
    Card(
        modifier = modifier
            .fillMaxWidth()
            .graphicsLayer {
                translationY = slideInOffset.value
                alpha = opacity.value
            }
            .animateContentSize(
                animationSpec = spring(
                    dampingRatio = Spring.DampingRatioMediumBouncy,
                    stiffness = Spring.StiffnessLow
                )
            ),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        shape = RoundedCornerShape(18.dp),
        border = BorderStroke(1.dp, borderColor)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    brush = Brush.linearGradient(
                        colors = listOf(
                            Color.White.copy(alpha = 0.12f),
                            Color.White.copy(alpha = 0.03f)
                        )
                    )
                )
                .padding(14.dp)
        ) {
            Column(
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        modifier = Modifier.weight(1f),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Icon badge
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .background(
                                    when (task.status) {
                                        DownloadStatus.FAILED -> CrimsonFailure.copy(alpha = 0.18f)
                                        DownloadStatus.COMPLETED -> EmeraldSuccess.copy(alpha = 0.18f)
                                        DownloadStatus.PAUSED -> AmberAccent.copy(alpha = 0.2f)
                                        else -> SleekPurpleDark.copy(alpha = 0.25f)
                                    },
                                    CircleShape
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = when (task.status) {
                                    DownloadStatus.FAILED -> Icons.Default.Warning
                                    DownloadStatus.COMPLETED -> Icons.Default.Check
                                    DownloadStatus.PAUSED -> if (task.speedText.contains("Battery", ignoreCase = true) || task.speedText.contains("Charging", ignoreCase = true)) Icons.Default.BatteryAlert else Icons.Default.Pause
                                    else -> Icons.Default.Download
                                },
                                contentDescription = null,
                                tint = when (task.status) {
                                    DownloadStatus.FAILED -> CrimsonFailure
                                    DownloadStatus.COMPLETED -> EmeraldSuccess
                                    DownloadStatus.PAUSED -> AmberAccent
                                    else -> SleekPurpleLight
                                },
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = task.title,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                color = SleekTextPrimary,
                                style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold)
                            )
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .background(
                                            if (task.status == DownloadStatus.PAUSED) AmberAccent.copy(alpha = 0.25f) else SleekPurpleLight.copy(alpha = 0.25f),
                                            RoundedCornerShape(4.dp)
                                        )
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                    Text(
                                        text = task.ext.uppercase(),
                                        color = if (task.status == DownloadStatus.PAUSED) AmberAccent else SleekTextPrimary,
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontWeight = FontWeight.Bold,
                                            fontFamily = FontFamily.Monospace,
                                            fontSize = 9.sp
                                        )
                                    )
                                }
                                Text(
                                    text = task.speedText,
                                    color = if (task.status == DownloadStatus.PAUSED) AmberAccent else SleekTextSecondary,
                                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (task.status == DownloadStatus.PAUSED && onResumeClick != null) {
                            IconButton(
                                onClick = onResumeClick,
                                modifier = Modifier
                                    .size(32.dp)
                                    .background(EmeraldSuccess.copy(alpha = 0.18f), CircleShape)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.PlayArrow,
                                    contentDescription = "Resume Download",
                                    tint = EmeraldSuccess,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                        IconButton(
                            onClick = onCancelClick,
                            modifier = Modifier
                                .size(32.dp)
                                .background(Color.White.copy(alpha = 0.08f), CircleShape)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Cancel",
                                tint = if (task.status == DownloadStatus.FAILED) CrimsonFailure else SleekTextSecondary,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
                if (task.status == DownloadStatus.FAILED) {
                    Text(
                        text = task.error ?: "Download terminated unexpectedly.",
                        color = CrimsonFailure,
                        style = MaterialTheme.typography.bodySmall,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                } else {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        val progressPercent = (task.progress * 100).toInt()
                        LinearProgressIndicator(
                            progress = { task.progress },
                            modifier = Modifier
                                .weight(1f)
                                .height(6.dp)
                                .clip(RoundedCornerShape(3.dp)),
                            color = if (task.status == DownloadStatus.COMPLETED) EmeraldSuccess else SleekPurpleLight,
                            trackColor = Color.White.copy(alpha = 0.1f)
                        )
                        Text(
                            text = "$progressPercent%",
                            style = MaterialTheme.typography.titleSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = SleekPurpleLight,
                                fontFamily = FontFamily.Monospace
                            )
                        )
                    }
                }
            }
        }
    }
}
@Composable
fun shimmerBrush(
    targetValue: Float = 1200f
): Brush {
    val shimmerColors = listOf(
        Color(0xFF231C30),
        Color(0xFF3C2F52),
        Color(0xFF5A4678),
        Color(0xFF3C2F52),
        Color(0xFF231C30)
    )
    val transition = rememberInfiniteTransition(label = "shimmer_transition")
    val translateAnimation = transition.animateFloat(
        initialValue = 0f,
        targetValue = targetValue,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "shimmer_translate"
    )
    return Brush.linearGradient(
        colors = shimmerColors,
        start = Offset(translateAnimation.value - 400f, translateAnimation.value - 400f),
        end = Offset(translateAnimation.value, translateAnimation.value)
    )
}

@Composable
fun SkeletonVideoListItem(
    modifier: Modifier = Modifier
) {
    val brush = shimmerBrush()
    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp)
            .testTag("video_list_item_skeleton"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = SleekCardDark)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Box(
                modifier = Modifier
                    .width(110.dp)
                    .height(68.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(brush)
            )
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth(0.9f)
                        .height(16.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(brush)
                )
                Box(
                    modifier = Modifier
                        .fillMaxWidth(0.6f)
                        .height(12.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(brush)
                )
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .width(50.dp)
                            .height(10.dp)
                            .clip(RoundedCornerShape(3.dp))
                            .background(brush)
                    )
                    Box(
                        modifier = Modifier
                            .width(40.dp)
                            .height(10.dp)
                            .clip(RoundedCornerShape(3.dp))
                            .background(brush)
                    )
                }
            }
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .clip(CircleShape)
                    .background(brush)
            )
        }
    }
}

@Composable
fun SkeletonVideoPlayerOverlay(
    modifier: Modifier = Modifier
) {
    val brush = shimmerBrush()
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF0D0B12)),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(20.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(brush)
                )
                Box(
                    modifier = Modifier
                        .width(180.dp)
                        .height(18.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(brush)
                )
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(brush)
                )
            }

            Box(
                modifier = Modifier
                    .size(64.dp)
                    .align(Alignment.CenterHorizontally)
                    .clip(CircleShape)
                    .background(brush)
            )

            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(3.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    repeat(24) { i ->
                        val barHeight = (12 + (i * 7) % 20).dp
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(barHeight)
                                .clip(RoundedCornerShape(2.dp))
                                .background(brush)
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .width(60.dp)
                            .height(12.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(brush)
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                        repeat(3) {
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(CircleShape)
                                    .background(brush)
                            )
                        }
                    }
                    Box(
                        modifier = Modifier
                            .width(60.dp)
                            .height(12.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(brush)
                    )
                }
            }
        }
    }
}

@Composable
fun SkeletonAudioPlayerOverlay(
    isFullscreen: Boolean = false,
    modifier: Modifier = Modifier
) {
    val brush = shimmerBrush()
    if (!isFullscreen) {
        Row(
            modifier = modifier
                .fillMaxSize()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(52.dp)
                    .clip(CircleShape)
                    .background(brush)
            )
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth(0.85f)
                        .height(14.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(brush)
                )
                Box(
                    modifier = Modifier
                        .fillMaxWidth(0.5f)
                        .height(10.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(brush)
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(modifier = Modifier.size(28.dp).clip(CircleShape).background(brush))
                Box(modifier = Modifier.size(28.dp).clip(CircleShape).background(brush))
            }
        }
    } else {
        Column(
            modifier = modifier
                .fillMaxSize()
                .background(Color(0xFF0D0B12))
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(modifier = Modifier.size(36.dp).clip(CircleShape).background(brush))
                Box(modifier = Modifier.width(120.dp).height(16.dp).clip(RoundedCornerShape(4.dp)).background(brush))
                Box(modifier = Modifier.size(36.dp).clip(CircleShape).background(brush))
            }

            Box(
                modifier = Modifier
                    .size(200.dp)
                    .clip(CircleShape)
                    .background(brush)
            )

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(modifier = Modifier.width(200.dp).height(18.dp).clip(RoundedCornerShape(4.dp)).background(brush))
                Box(modifier = Modifier.width(120.dp).height(14.dp).clip(RoundedCornerShape(4.dp)).background(brush))
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(3.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                repeat(20) { i ->
                    val barHeight = (10 + (i * 9) % 24).dp
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(barHeight)
                            .clip(RoundedCornerShape(2.dp))
                            .background(brush)
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                repeat(5) {
                    Box(modifier = Modifier.size(44.dp).clip(CircleShape).background(brush))
                }
            }
        }
    }
}

@Composable
fun SkeletonAnalyzedVideoCard() {
    val brush = shimmerBrush()
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(130.dp)
            .testTag("analyzed_video_card_skeleton"),
        colors = CardDefaults.cardColors(containerColor = SleekPurpleContainer.copy(alpha = 0.5f)),
        shape = RoundedCornerShape(20.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxSize().padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxHeight()
                    .aspectRatio(16f/9f)
                    .clip(RoundedCornerShape(12.dp))
                    .background(brush)
            )
            Column(
                modifier = Modifier.weight(1f).fillMaxHeight(),
                verticalArrangement = Arrangement.Center
            ) {
                Box(modifier = Modifier.fillMaxWidth().height(18.dp).clip(RoundedCornerShape(4.dp)).background(brush))
                Spacer(modifier = Modifier.height(8.dp))
                Box(modifier = Modifier.fillMaxWidth(0.7f).height(18.dp).clip(RoundedCornerShape(4.dp)).background(brush))
                Spacer(modifier = Modifier.height(16.dp))
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Box(modifier = Modifier.size(16.dp).clip(CircleShape).background(brush))
                    Box(modifier = Modifier.width(80.dp).height(12.dp).clip(RoundedCornerShape(4.dp)).background(brush))
                }
            }
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .background(brush)
            )
        }
    }
}
@Composable
fun AnalyzedVideoCard(
    video: AnalyzedVideo,
    onOpenDownloadOptions: () -> Unit,
    onStreamBestClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(130.dp)
            .animateContentSize(animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow))
            .testTag("analyzed_video_card"),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        shape = RoundedCornerShape(20.dp),
        border = BorderStroke(1.dp, SleekPurpleLight.copy(alpha = 0.35f))
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    brush = Brush.linearGradient(
                        colors = listOf(
                            SleekPurpleContainer.copy(alpha = 0.5f),
                            Color.White.copy(alpha = 0.04f)
                        )
                    )
                )
        ) {
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Thumbnail
                Box(
                    modifier = Modifier
                        .fillMaxHeight()
                        .aspectRatio(16f / 9f)
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color.Black)
                        .clickable { onStreamBestClick() }
                ) {
                    AsyncImage(
                        model = video.thumbnailUrl,
                        contentDescription = "Video Thumbnail",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop,
                        alpha = 0.92f
                    )
                    // Play Overlay
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color.Black.copy(alpha = 0.25f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .background(
                                    brush = Brush.linearGradient(
                                        colors = listOf(SleekPurpleLight, SleekPurpleDark)
                                    ),
                                    shape = CircleShape
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.PlayArrow,
                                contentDescription = "Stream Best",
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                    // Duration Badge
                    if (video.durationText.isNotBlank()) {
                        Box(
                            modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .padding(6.dp)
                                .background(Color.Black.copy(alpha = 0.8f), shape = RoundedCornerShape(6.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = video.durationText,
                                color = Color.White,
                                style = MaterialTheme.typography.bodySmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 9.sp
                                )
                            )
                        }
                    }
                }
                // Details
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight(),
                    verticalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = video.title,
                        color = SleekTextPrimary,
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontWeight = FontWeight.Bold,
                            lineHeight = 18.sp
                        ),
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = "Channel",
                            tint = SleekPurpleLight,
                            modifier = Modifier.size(13.dp)
                        )
                        Text(
                            text = video.author,
                            color = SleekTextSecondary,
                            style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
                // Quick Actions column
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = onStreamBestClick,
                        modifier = Modifier
                            .size(42.dp)
                            .background(
                                color = SleekPurpleLight.copy(alpha = 0.25f),
                                shape = CircleShape
                            )
                            .border(1.dp, SleekPurpleLight.copy(alpha = 0.5f), CircleShape)
                    ) {
                        Icon(
                            imageVector = Icons.Default.PlayArrow,
                            contentDescription = "Stream Direct",
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    IconButton(
                        onClick = onOpenDownloadOptions,
                        modifier = Modifier
                            .size(42.dp)
                            .background(
                                color = Color.White,
                                shape = CircleShape
                            )
                    ) {
                        Icon(
                            imageVector = Icons.Default.Download,
                            contentDescription = "Download Options",
                            tint = Color.Black,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }
    }
}
@Composable
fun FormatRowItem(
    format: VideoFormatUi,
    onDownloadClick: () -> Unit,
    onStreamClick: () -> Unit,
    onScheduleClick: (() -> Unit)? = null,
    modifier: Modifier = Modifier,
    showAdvanced: Boolean = false
) {
    var expanded by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(
                brush = Brush.linearGradient(
                    colors = listOf(Color.White.copy(alpha = 0.1f), Color.White.copy(alpha = 0.02f))
                )
            )
            .border(1.dp, Color.White.copy(alpha = 0.2f), shape = RoundedCornerShape(16.dp))
            .clickable { expanded = !expanded }
            .padding(horizontal = 16.dp, vertical = 12.dp)
            .animateContentSize()
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .background(SleekPurpleContainer, shape = RoundedCornerShape(10.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (format.quality == "MP3" || format.type == "audio") Icons.Default.MusicNote else Icons.Default.PlayArrow,
                        contentDescription = null,
                        tint = SleekPurpleDark,
                        modifier = Modifier.size(18.dp)
                    )
                }
                Column {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = format.quality,
                            color = SleekTextPrimary,
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Box(
                            modifier = Modifier
                                .background(SleekPurpleLight.copy(alpha = 0.3f), shape = RoundedCornerShape(6.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = format.ext.uppercase(),
                                color = SleekTextPrimary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                        if (format.type == "video_only" && showAdvanced) {
                            Box(
                                modifier = Modifier
                                    .background(SleekPurpleLight, shape = RoundedCornerShape(6.dp))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = "⚡ MERGING",
                                    color = SleekTextPrimary,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = format.sizeText,
                            color = SleekTextSecondary,
                            style = MaterialTheme.typography.bodySmall
                        )
                        Icon(
                            imageVector = if (expanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                            contentDescription = "Show Details",
                            tint = SleekTextMuted,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (format.quality != "MP3") {
                    IconButton(
                        onClick = onStreamClick,
                        modifier = Modifier
                            .size(36.dp)
                            .background(Color.White.copy(alpha = 0.12f), CircleShape)
                            .border(1.dp, Color.White.copy(alpha = 0.25f), CircleShape)
                    ) {
                        Icon(
                            imageVector = Icons.Default.PlayArrow,
                            contentDescription = "Stream Direct",
                            tint = SleekTextPrimary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
                IconButton(
                    onClick = onDownloadClick,
                    modifier = Modifier
                        .size(36.dp)
                        .background(Color.White, CircleShape)
                ) {
                    Icon(
                        imageVector = Icons.Default.Download,
                        contentDescription = "Download",
                        tint = Color.Black,
                        modifier = Modifier.size(18.dp)
                    )
                }
                if (onScheduleClick != null) {
                    IconButton(
                        onClick = onScheduleClick,
                        modifier = Modifier
                            .size(36.dp)
                            .background(Color.White.copy(alpha = 0.12f), CircleShape)
                            .border(1.dp, Color.White.copy(alpha = 0.25f), CircleShape)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Schedule,
                            contentDescription = "Schedule Download",
                            tint = AmberAccent,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }

        AnimatedVisibility(
            visible = expanded,
            enter = expandVertically() + fadeIn(),
            exit = shrinkVertically() + fadeOut()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                HorizontalDivider(
                    color = Color.White.copy(alpha = 0.08f),
                    thickness = 1.dp
                )
                
                // Technical specifications scrollable row
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (format.fps != null && format.fps > 0) {
                        SpecBadge(label = "FPS", value = "${format.fps}")
                    }
                    if (format.isHdr) {
                        SpecBadge(label = "HDR", value = "Yes", containerColor = Color(0xFFFF4D5A).copy(alpha = 0.15f), contentColor = Color(0xFFFF4D5A))
                    }
                    if (format.bitrateKbps != null && format.bitrateKbps > 0) {
                        SpecBadge(label = "Video Bitrate", value = "${format.bitrateKbps} kbps")
                    }
                    if (format.audioBitrateKbps != null && format.audioBitrateKbps > 0) {
                        SpecBadge(label = "Audio Bitrate", value = "${format.audioBitrateKbps} kbps")
                    }
                    if (format.vcodec.isNotBlank() && format.vcodec != "none") {
                        SpecBadge(label = "Video Codec", value = format.vcodec)
                    }
                    if (format.acodec.isNotBlank() && format.acodec != "none") {
                        SpecBadge(label = "Audio Codec", value = format.acodec)
                    }
                    if (format.protocol.isNotBlank()) {
                        SpecBadge(label = "Protocol", value = format.protocol.uppercase())
                    }
                    if (format.sizeBytes > 0) {
                        val byteCountFormatted = java.text.NumberFormat.getInstance().format(format.sizeBytes)
                        SpecBadge(label = "Exact Size", value = "$byteCountFormatted bytes")
                    }
                }

                // Copy / Share Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val clipboardManager = LocalClipboardManager.current
                    val context = LocalContext.current
                    
                    // Copy URL Button
                    Button(
                        onClick = {
                            clipboardManager.setText(androidx.compose.ui.text.AnnotatedString(format.downloadUrl))
                            android.widget.Toast.makeText(context, "Stream URL copied!", android.widget.Toast.LENGTH_SHORT).show()
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color.White.copy(alpha = 0.08f),
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(0.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(36.dp)
                            .testTag("copy_url_btn_${format.formatId}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.ContentCopy,
                            contentDescription = "Copy URL",
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    // Share Stream Button
                    Button(
                        onClick = {
                            try {
                                val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                                    type = "text/plain"
                                    putExtra(android.content.Intent.EXTRA_SUBJECT, "Stream Link")
                                    putExtra(android.content.Intent.EXTRA_TEXT, format.downloadUrl)
                                }
                                context.startActivity(android.content.Intent.createChooser(intent, "Share Stream URL"))
                            } catch (e: Exception) {
                                android.widget.Toast.makeText(context, "Unable to share stream URL", android.widget.Toast.LENGTH_SHORT).show()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color.White.copy(alpha = 0.08f),
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(0.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(36.dp)
                            .testTag("share_url_btn_${format.formatId}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Share,
                            contentDescription = "Share Stream",
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun SpecBadge(
    label: String,
    value: String,
    containerColor: Color = Color.White.copy(alpha = 0.04f),
    contentColor: Color = SleekTextSecondary
) {
    Row(
        modifier = Modifier
            .background(containerColor, RoundedCornerShape(8.dp))
            .border(0.5.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(8.dp))
            .padding(horizontal = 8.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Text(
            text = "$label:",
            color = SleekTextMuted,
            style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp, fontWeight = FontWeight.Medium)
        )
        Text(
            text = value,
            color = contentColor,
            style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp, fontWeight = FontWeight.Bold)
        )
    }
}

@Composable
fun SleekFilterChip(
    selected: Boolean,
    onClick: () -> Unit,
    label: String,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(
                if (selected) SleekPurpleLight.copy(alpha = 0.25f) else Color.White.copy(alpha = 0.04f)
            )
            .border(
                width = 1.dp,
                color = if (selected) SleekPurpleLight else Color.White.copy(alpha = 0.12f),
                shape = RoundedCornerShape(8.dp)
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 6.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            color = if (selected) Color.White else SleekTextSecondary,
            fontSize = 11.sp,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium
        )
    }
}
@Composable
fun SearchResultItemRow(
    result: YtdlpPipelineManager.SearchResult,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    index: Int = 0
) {
    val slideInOffset = remember { Animatable(100f) }
    val opacity = remember { Animatable(0f) }

    LaunchedEffect(key1 = result.id) {
        val delayTime = (index * 45L).coerceAtMost(250L)
        delay(delayTime)
        launch {
            slideInOffset.animateTo(
                targetValue = 0f,
                animationSpec = spring(
                    dampingRatio = Spring.DampingRatioLowBouncy,
                    stiffness = Spring.StiffnessMediumLow
                )
            )
        }
        launch {
            opacity.animateTo(
                targetValue = 1f,
                animationSpec = tween(durationMillis = 300, easing = LinearOutSlowInEasing)
            )
        }
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp)
            .graphicsLayer {
                translationX = slideInOffset.value
                alpha = opacity.value
            }
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = SleekCard),
        border = BorderStroke(1.dp, Color(0x14FFFFFF))
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(12.dp)
        ) {
            // Thumbnail
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(16f / 9f)
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color.Black)
            ) {
                AsyncImage(
                    model = result.thumbnailUrl,
                    contentDescription = result.title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )

                // Top right: Floating glass download button!
                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(10.dp)
                        .size(38.dp)
                        .shadow(4.dp, CircleShape)
                        .clip(CircleShape)
                        .background(Color(0x99111216))
                        .border(1.dp, Color.White.copy(alpha = 0.25f), CircleShape)
                        .clickable { onClick() },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.ArrowDownward,
                        contentDescription = "Quick Download",
                        tint = Color(0xFFFF9D33),
                        modifier = Modifier.size(18.dp)
                    )
                }

                if (result.duration.isNotBlank()) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .padding(8.dp)
                            .background(Color.Black.copy(alpha = 0.75f), RoundedCornerShape(6.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = result.duration,
                            color = Color.White,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 11.sp
                            )
                        )
                    }
                }
            }

            // Details below thumbnail
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 12.dp, start = 4.dp, end = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Info left
                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = result.title,
                        color = SleekTextPrimary,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            lineHeight = 20.sp
                        ),
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = result.author,
                            color = SleekTextSecondary,
                            style = MaterialTheme.typography.bodySmall.copy(
                                fontWeight = FontWeight.Medium
                            ),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Box(
                            modifier = Modifier
                                .background(Color(0x1AFFFF9D), RoundedCornerShape(4.dp))
                                .padding(horizontal = 6.dp, vertical = 1.dp)
                        ) {
                            Text(
                                text = "1080p",
                                color = Color(0xFFFF9D33),
                                style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp, fontWeight = FontWeight.ExtraBold)
                            )
                        }
                    }
                }

                // Info right: Overflow/Analyze trigger button
                IconButton(
                    onClick = onClick,
                    modifier = Modifier
                        .size(40.dp)
                        .background(Color.White.copy(alpha = 0.05f), CircleShape)
                        .border(1.dp, Color.White.copy(alpha = 0.1f), CircleShape)
                ) {
                    Icon(
                        imageVector = Icons.Default.Bolt,
                        contentDescription = "Analyze",
                        tint = Color(0xFFFF7A00),
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }
    }
}
@Composable
fun SkeletonSearchResultItem() {
    val brush = shimmerBrush()
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent)
    ) {
        Column(
            modifier = Modifier.fillMaxWidth()
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(16f / 9f)
                    .clip(RoundedCornerShape(12.dp))
                    .background(brush)
            )
            
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 12.dp, bottom = 4.dp, start = 4.dp, end = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.Top
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(brush)
                )
                
                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(0.9f)
                            .height(18.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(brush)
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(0.6f)
                            .height(14.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(brush)
                    )
                }
                
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(brush)
                )
            }
        }
    }
}
@Composable
fun PremiumSeekBar(
    value: Float,
    onValueChange: (Float) -> Unit,
    valueRange: ClosedFloatingPointRange<Float>,
    modifier: Modifier = Modifier,
    activeColor: Color = Color.White,
    inactiveColor: Color = Color.White.copy(alpha = 0.24f)
) {
    val rangeMin = valueRange.start
    val rangeMax = valueRange.endInclusive
    val rangeLength = rangeMax - rangeMin
    val progressFraction = if (rangeLength > 0f) {
        ((value - rangeMin) / rangeLength).coerceIn(0f, 1f)
    } else {
        0f
    }
    var isDragging by remember { mutableStateOf(false) }
    // Modern progressive animation for track thick/thin and thumb size
    val thumbRadius by androidx.compose.animation.core.animateDpAsState(
        targetValue = if (isDragging) 8.dp else 4.dp,
        animationSpec = androidx.compose.animation.core.spring(
            dampingRatio = androidx.compose.animation.core.Spring.DampingRatioMediumBouncy,
            stiffness = androidx.compose.animation.core.Spring.StiffnessLow
        ),
        label = "thumb_radius"
    )
    val trackHeight by androidx.compose.animation.core.animateDpAsState(
        targetValue = if (isDragging) 6.dp else 3.dp,
        animationSpec = androidx.compose.animation.core.spring(
            stiffness = androidx.compose.animation.core.Spring.StiffnessMedium
        ),
        label = "track_height"
    )
    BoxWithConstraints(
        modifier = modifier
            .fillMaxWidth()
            .height(24.dp),
        contentAlignment = Alignment.CenterStart
    ) {
        val widthPx = constraints.maxWidth.toFloat()
        Box(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(rangeMin, rangeMax, widthPx) {
                    detectTapGestures(
                        onPress = { offset ->
                            val fraction = (offset.x / widthPx).coerceIn(0f, 1f)
                            val newValue = rangeMin + fraction * rangeLength
                            onValueChange(newValue)
                        }
                    )
                }
                .pointerInput(rangeMin, rangeMax, widthPx) {
                    detectHorizontalDragGestures(
                        onDragStart = { isDragging = true },
                        onDragEnd = { isDragging = false },
                        onDragCancel = { isDragging = false },
                        onHorizontalDrag = { change, _ ->
                            val fraction = (change.position.x / widthPx).coerceIn(0f, 1f)
                            val newValue = rangeMin + fraction * rangeLength
                            onValueChange(newValue)
                            change.consume()
                        }
                    )
                }
        ) {
            Canvas(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.Center)
                    .height(24.dp)
            ) {
                val canvasWidth = size.width
                val canvasHeight = size.height
                val centerY = canvasHeight / 2f
                val trackHeightPx = trackHeight.toPx()
                val activeEndX = canvasWidth * progressFraction
                // 1. Draw Inactive Track
                drawRoundRect(
                    color = inactiveColor,
                    topLeft = androidx.compose.ui.geometry.Offset(0f, centerY - trackHeightPx / 2f),
                    size = androidx.compose.ui.geometry.Size(canvasWidth, trackHeightPx),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(trackHeightPx / 2f)
                )
                // 2. Draw Active Seek progress status
                drawRoundRect(
                    brush = Brush.horizontalGradient(
                        colors = listOf(
                            activeColor.copy(alpha = 0.75f),
                            activeColor
                        )
                    ),
                    topLeft = androidx.compose.ui.geometry.Offset(0f, centerY - trackHeightPx / 2f),
                    size = androidx.compose.ui.geometry.Size(activeEndX, trackHeightPx),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(trackHeightPx / 2f)
                )
                // 3. Draw active focus glow halo
                if (isDragging) {
                    drawCircle(
                        color = activeColor.copy(alpha = 0.18f),
                        radius = thumbRadius.toPx() * 2.5f,
                        center = androidx.compose.ui.geometry.Offset(activeEndX, centerY)
                    )
                }
                // 4. Draw active thumb
                drawCircle(
                    color = Color.White,
                    radius = thumbRadius.toPx(),
                    center = androidx.compose.ui.geometry.Offset(activeEndX, centerY)
                )
            }
        }
    }
}
sealed interface LibraryItem {
    val id: String
    val title: String

    data class Completed(val entity: DownloadEntity) : LibraryItem {
        override val id: String get() = entity.id
        override val title: String get() = entity.title
    }

    data class Failed(val task: ActiveDownloadTask) : LibraryItem {
        override val id: String get() = task.id
        override val title: String get() = task.title
    }
}

@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
@Composable
fun FailedItemCard(
    task: ActiveDownloadTask? = null,
    entity: DownloadEntity? = null,
    onDeleteClick: () -> Unit,
    onResumeClick: (() -> Unit)? = null,
    onRefetchClick: (() -> Unit)? = null,
    selected: Boolean = false,
    onSelectedChange: ((Boolean) -> Unit)? = null,
    onLongClick: (() -> Unit)? = null,
    modifier: Modifier = Modifier,
    index: Int = 0
) {
    val slideInOffset = remember { Animatable(100f) }
    val opacity = remember { Animatable(0f) }
    val itemId = task?.id ?: entity?.id ?: "unknown"
    val itemTitle = task?.title ?: entity?.title ?: "Download"
    val itemExt = task?.ext ?: entity?.formatExt ?: ""
    val status = task?.status?.name ?: entity?.downloadStatus ?: "FAILED"
    val errorMsg = task?.error ?: entity?.statusMessage ?: ""
    val downloadedBytes = task?.downloadedBytes ?: entity?.fileSize ?: 0L
    val totalBytes = task?.totalBytes ?: entity?.expectedSize ?: 0L

    val statusColor = when (status) {
        "RECOVERABLE" -> Color(0xFF00E5FF)
        "INCOMPLETE" -> Color(0xFFFFB300)
        "CORRUPTED" -> CrimsonFailure
        else -> CrimsonFailure
    }
    val statusBg = statusColor.copy(alpha = 0.15f)

    LaunchedEffect(key1 = itemId) {
        val delayTime = (index * 45L).coerceAtMost(250L)
        delay(delayTime)
        launch {
            slideInOffset.animateTo(
                targetValue = 0f,
                animationSpec = spring(
                    dampingRatio = Spring.DampingRatioLowBouncy,
                    stiffness = Spring.StiffnessMediumLow
                )
            )
        }
        launch {
            opacity.animateTo(
                targetValue = 1f,
                animationSpec = tween(durationMillis = 300, easing = LinearOutSlowInEasing)
            )
        }
    }

    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp)
            .graphicsLayer {
                translationX = slideInOffset.value
                alpha = opacity.value
            },
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (onSelectedChange != null) {
            Checkbox(
                checked = selected,
                onCheckedChange = onSelectedChange,
                colors = CheckboxDefaults.colors(
                    checkedColor = SleekPurpleLight,
                    uncheckedColor = SleekTextSecondary
                ),
                modifier = Modifier.padding(end = 8.dp).testTag("checkbox_$itemId")
            )
        }

        Card(
            modifier = Modifier
                .weight(1f)
                .combinedClickable(
                    onClick = { },
                    onLongClick = { onLongClick?.invoke() }
                ),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = SleekCardDark),
            border = BorderStroke(1.dp, statusColor.copy(alpha = 0.35f))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .background(statusBg, RoundedCornerShape(8.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (status == "RECOVERABLE" || status == "INCOMPLETE") Icons.Default.Refresh else Icons.Default.Warning,
                            contentDescription = status,
                            tint = statusColor,
                            modifier = Modifier.size(24.dp)
                        )
                    }

                    Column(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = itemTitle,
                            color = Color.White,
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .background(statusBg, RoundedCornerShape(4.dp))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = status,
                                    color = statusColor,
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 9.sp
                                    )
                                )
                            }
                            if (itemExt.isNotBlank()) {
                                Text(
                                    text = itemExt.uppercase(),
                                    color = SleekTextSecondary,
                                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp, fontWeight = FontWeight.Medium)
                                )
                            }
                            if (downloadedBytes > 0L) {
                                val mbDownloaded = String.format(Locale.getDefault(), "%.1f", downloadedBytes / (1024f * 1024f))
                                val mbTotal = if (totalBytes > 0L) String.format(Locale.getDefault(), "%.1f MB", totalBytes / (1024f * 1024f)) else ""
                                val sizeText = if (mbTotal.isNotBlank()) "$mbDownloaded / $mbTotal" else "$mbDownloaded MB"
                                Text(
                                    text = sizeText,
                                    color = SleekTextSecondary,
                                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp)
                                )
                            }
                        }
                        if (errorMsg.isNotBlank()) {
                            Text(
                                text = errorMsg,
                                color = statusColor.copy(alpha = 0.85f),
                                style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }

                    IconButton(
                        onClick = onDeleteClick,
                        modifier = Modifier.size(36.dp).testTag("delete_broken_${itemId}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "Delete Task",
                            tint = CrimsonFailure
                        )
                    }
                }

                // Action controls: [Resume] [Re-fetch]
                if (onResumeClick != null || onRefetchClick != null) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (onResumeClick != null && (status == "RECOVERABLE" || status == "INCOMPLETE" || downloadedBytes > 0L)) {
                            FilledTonalButton(
                                onClick = onResumeClick,
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.filledTonalButtonColors(
                                    containerColor = SleekPurpleLight.copy(alpha = 0.2f),
                                    contentColor = SleekPurpleLight
                                ),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                                modifier = Modifier.padding(end = 8.dp).height(32.dp).testTag("resume_btn_${itemId}")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.PlayArrow,
                                    contentDescription = "Resume",
                                    modifier = Modifier.size(14.dp).padding(end = 4.dp)
                                )
                                Text("Resume", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold))
                            }
                        }

                        if (onRefetchClick != null) {
                            OutlinedButton(
                                onClick = onRefetchClick,
                                shape = RoundedCornerShape(8.dp),
                                border = BorderStroke(1.dp, SleekTextSecondary.copy(alpha = 0.4f)),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    contentColor = Color.White
                                ),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                                modifier = Modifier.height(32.dp).testTag("refetch_btn_${itemId}")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Refresh,
                                    contentDescription = "Re-fetch",
                                    modifier = Modifier.size(14.dp).padding(end = 4.dp)
                                )
                                Text("Re-fetch", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Medium))
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(com.google.accompanist.permissions.ExperimentalPermissionsApi::class)
@Composable
fun LibraryTab(
    downloads: List<DownloadEntity>,
    failedTasks: List<ActiveDownloadTask> = emptyList(),
    appDownloadedPaths: Set<String> = emptySet(),
    onPlayClick: (DownloadEntity) -> Unit,
    onShareClick: (DownloadEntity) -> Unit,
    onDeleteClick: (DownloadEntity) -> Unit,
    onDeleteFailedClick: (String) -> Unit = {},
    onConvertAudio: (DownloadEntity, String) -> Unit,
    onBulkDeleteClick: (List<DownloadEntity>, List<String>) -> Unit = { _, _ -> },
    onEditMetadataClick: ((DownloadEntity) -> Unit)? = null,
    onAddToPlaylistClick: ((DownloadEntity) -> Unit)? = null,
    viewModel: VideoDownloaderViewModel? = null
) {
    val isTabletOrWide = androidx.compose.ui.platform.LocalConfiguration.current.screenWidthDp >= 600
    val context = LocalContext.current
    val permissionState = com.google.accompanist.permissions.rememberMultiplePermissionsState(
        remember { com.example.util.DeviceCompatHelper.getRequiredPermissions() }
    )
    val isStoragePermissionGranted = remember(permissionState.allPermissionsGranted) {
        permissionState.allPermissionsGranted
    }

    LaunchedEffect(Unit) {
        viewModel?.triggerStorageCleanup()
        viewModel?.refreshWatchedCleanupList()
    }

    var selectedFilter by remember { mutableStateOf("All") }
    val filters = listOf("All", "Videos", "Audio", "Downloads", "Failed")

    val allItems = remember(downloads, failedTasks) {
        val list = mutableListOf<LibraryItem>()
        list.addAll(downloads.map { LibraryItem.Completed(it) })
        list.addAll(failedTasks.map { LibraryItem.Failed(it) })
        list
    }

    val filteredItems = remember(allItems, selectedFilter) {
        allItems.filter { item ->
            when (selectedFilter) {
                "Videos" -> item is LibraryItem.Completed && (
                    item.entity.localPath.endsWith(".mp4", true) || 
                    item.entity.localPath.endsWith(".webm", true) || 
                    item.entity.localPath.endsWith(".mkv", true)
                )
                "Audio" -> item is LibraryItem.Completed && (
                    item.entity.localPath.endsWith(".mp3", true) || 
                    item.entity.localPath.endsWith(".m4a", true) || 
                    item.entity.localPath.endsWith(".opus", true) || 
                    item.entity.localPath.endsWith(".wav", true)
                )
                "Downloads" -> item is LibraryItem.Completed && appDownloadedPaths.contains(item.entity.localPath)
                "Failed" -> item is LibraryItem.Failed
                else -> true
            }
        }
    }

    var selectedIds by remember { mutableStateOf(emptySet<String>()) }
    var isSelectionMode by remember { mutableStateOf(false) }
    var showBulkDeleteConfirm by remember { mutableStateOf(false) }
    var showFilterDropdownMenu by remember { mutableStateOf(false) }

    val configuration = androidx.compose.ui.platform.LocalConfiguration.current
    val screenWidthDp = configuration.screenWidthDp
    val columns = when {
        screenWidthDp < 600 -> 1
        screenWidthDp < 840 -> 2
        screenWidthDp < 1200 -> 3
        else -> 4
    }
    val maxContentWidth = (columns * 460).dp

    if (showBulkDeleteConfirm) {
        AlertDialog(
            onDismissRequest = { showBulkDeleteConfirm = false },
            title = {
                Text(
                    text = "Delete Selected Items?",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = Color.White
                )
            },
            text = {
                Text(
                    text = "Are you sure you want to delete the ${selectedIds.size} selected items? Completed items will be deleted from your storage.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = SleekTextSecondary
                )
            },
            containerColor = Color(0xFF1E2026),
            confirmButton = {
                Button(
                    onClick = {
                        val selectedCompleted = mutableListOf<DownloadEntity>()
                        val selectedFailed = mutableListOf<String>()
                        selectedIds.forEach { key ->
                            if (key.startsWith("completed_")) {
                                val id = key.substringAfter("completed_")
                                downloads.find { it.id == id }?.let { selectedCompleted.add(it) }
                            } else if (key.startsWith("failed_")) {
                                val id = key.substringAfter("failed_")
                                selectedFailed.add(id)
                            }
                        }
                        onBulkDeleteClick(selectedCompleted, selectedFailed)
                        selectedIds = emptySet()
                        showBulkDeleteConfirm = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CrimsonFailure)
                ) {
                    Icon(Icons.Default.Delete, contentDescription = "Delete")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { showBulkDeleteConfirm = false }
                ) {
                    Icon(Icons.Default.Close, contentDescription = "Cancel", tint = Color.White)
                }
            }
        )
    }

    BoxWithConstraints(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        val screenW = maxWidth
        val screenH = maxHeight
        val marginH = (screenW * 0.04f).coerceAtLeast(14.dp)
        val filterBarH = (screenH * 0.055f).coerceIn(38.dp, 52.dp)
        val filterBarRadius = filterBarH * 0.5f
        val filterButtonSize = (screenW * 0.065f).coerceIn(38.dp, 48.dp)
        val filterGap = (screenW * 0.012f).coerceIn(4.dp, 8.dp)
        val cardTopGap = (screenH * 0.04f).coerceIn(14.dp, 32.dp)

        val countAll = allItems.size
        val countVideos = allItems.count { it is LibraryItem.Completed && (it.entity.localPath.endsWith(".mp4", true) || it.entity.localPath.endsWith(".webm", true) || it.entity.localPath.endsWith(".mkv", true)) }
        val countAudio = allItems.count { it is LibraryItem.Completed && (it.entity.localPath.endsWith(".mp3", true) || it.entity.localPath.endsWith(".m4a", true) || it.entity.localPath.endsWith(".opus", true) || it.entity.localPath.endsWith(".wav", true)) }
        val countDownloads = allItems.count { it is LibraryItem.Completed && appDownloadedPaths.contains(it.entity.localPath) }
        val countFailed = allItems.count { it is LibraryItem.Failed }

        val filterList = listOf(
            "All" to countAll,
            "Videos" to countVideos,
            "Audio" to countAudio,
            "Downloads" to countDownloads,
            "Failed" to countFailed
        )

        Column(
            modifier = Modifier
                .fillMaxHeight()
                .widthIn(max = maxContentWidth)
                .fillMaxWidth()
                .statusBarsPadding()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = marginH)
                    .padding(top = (screenH * 0.052f).coerceIn(12.dp, 36.dp), bottom = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Rounded Filter Bar with 5 evenly distributed filters
                Row(
                    modifier = Modifier
                        .weight(1f)
                        .height(filterBarH)
                        .clip(RoundedCornerShape(filterBarRadius))
                        .background(Color(0xFF14161D).copy(alpha = 0.85f))
                        .border(1.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(filterBarRadius))
                        .padding(3.dp),
                    horizontalArrangement = Arrangement.spacedBy(2.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    filterList.forEach { (filterName, count) ->
                        val isSelected = selectedFilter == filterName
                        val filterBgColor by animateColorAsState(
                            targetValue = if (isSelected) Color(0xFFFF8A00) else Color.Transparent,
                            animationSpec = tween(durationMillis = 180),
                            label = "FilterBg_$filterName"
                        )
                        val filterTextColor by animateColorAsState(
                            targetValue = if (isSelected) Color.White else Color(0xFF8E95A2),
                            animationSpec = tween(durationMillis = 180),
                            label = "FilterText_$filterName"
                        )

                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxHeight()
                                .clip(RoundedCornerShape(filterBarRadius))
                                .background(filterBgColor)
                                .clickable { selectedFilter = filterName },
                            contentAlignment = Alignment.Center
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center,
                                modifier = Modifier.padding(horizontal = 2.dp)
                            ) {
                                Text(
                                    text = filterName,
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Medium,
                                        fontSize = 11.5.sp
                                    ),
                                    color = filterTextColor,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Spacer(modifier = Modifier.width(2.dp))
                                Text(
                                    text = "($count)",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal,
                                        fontSize = 10.sp
                                    ),
                                    color = if (isSelected) Color.White.copy(alpha = 0.9f) else Color(0xFF6B7280),
                                    maxLines = 1
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.width(filterGap))

                // Filter Button immediately to the right
                Box(
                    modifier = Modifier.size(filterButtonSize)
                ) {
                    Surface(
                        modifier = Modifier
                            .fillMaxSize()
                            .clip(CircleShape)
                            .clickable { showFilterDropdownMenu = !showFilterDropdownMenu },
                        shape = CircleShape,
                        color = Color(0xFF161820).copy(alpha = 0.85f),
                        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.08f))
                    ) {
                        Box(
                            modifier = Modifier.fillMaxSize(),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.FilterList,
                                contentDescription = "Filter Options",
                                tint = Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    if (selectedFilter != "All") {
                        Box(
                            modifier = Modifier
                                .align(Alignment.TopEnd)
                                .padding(3.dp)
                                .size(7.dp)
                                .background(Color(0xFFFF8A00), CircleShape)
                        )
                    }

                    DropdownMenu(
                        expanded = showFilterDropdownMenu,
                        onDismissRequest = { showFilterDropdownMenu = false },
                        modifier = Modifier
                            .background(Color(0xFF161820))
                            .border(1.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(12.dp))
                    ) {
                        filterList.forEach { (filterName, count) ->
                            DropdownMenuItem(
                                text = {
                                    Text(
                                        text = "$filterName ($count)",
                                        color = if (selectedFilter == filterName) Color(0xFFFF8A00) else Color.White,
                                        fontWeight = if (selectedFilter == filterName) FontWeight.Bold else FontWeight.Normal
                                    )
                                },
                                trailingIcon = {
                                    if (selectedFilter == filterName) {
                                        Icon(Icons.Default.Check, contentDescription = null, tint = Color(0xFFFF8A00), modifier = Modifier.size(16.dp))
                                    }
                                },
                                onClick = {
                                    selectedFilter = filterName
                                    showFilterDropdownMenu = false
                                }
                            )
                        }
                        if (selectedFilter != "All") {
                            HorizontalDivider(color = Color.White.copy(alpha = 0.08f))
                            DropdownMenuItem(
                                text = { Text("Reset Filter", color = Color(0xFFFF8A00), fontWeight = FontWeight.SemiBold) },
                                leadingIcon = { Icon(Icons.Default.Refresh, contentDescription = null, tint = Color(0xFFFF8A00), modifier = Modifier.size(16.dp)) },
                                onClick = {
                                    selectedFilter = "All"
                                    showFilterDropdownMenu = false
                                }
                            )
                        }
                    }
                }

                if (!isStoragePermissionGranted) {
                    Spacer(modifier = Modifier.width(filterGap))
                    IconButton(
                        onClick = { permissionState.launchMultiplePermissionRequest() },
                        modifier = Modifier
                            .size(filterButtonSize)
                            .background(Color(0xFF161820).copy(alpha = 0.85f), CircleShape)
                            .border(1.dp, Color.White.copy(alpha = 0.08f), CircleShape)
                    ) {
                        Icon(Icons.Default.Folder, contentDescription = "Request Storage", tint = Color(0xFFFF8A00), modifier = Modifier.size(18.dp))
                    }
                }
            }

            var isRefreshing by remember { mutableStateOf(false) }
            val coroutineScope = rememberCoroutineScope()
            @OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
            val pullRefreshState = androidx.compose.material3.pulltorefresh.rememberPullToRefreshState()
            
            @OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
            androidx.compose.material3.pulltorefresh.PullToRefreshBox(
                isRefreshing = isRefreshing,
                onRefresh = {
                    isRefreshing = true
                    coroutineScope.launch {
                        viewModel?.forceRefreshDownloads()
                        kotlinx.coroutines.delay(800)
                        isRefreshing = false
                    }
                },
                state = pullRefreshState,
                modifier = Modifier.weight(1f).fillMaxWidth()
            ) {
                if (filteredItems.isEmpty()) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = "Empty",
                        tint = SleekTextMuted.copy(alpha = 0.5f),
                        modifier = Modifier.size(80.dp)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "NO COMPATIBLE MEDIA",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = SleekTextPrimary,
                            letterSpacing = 1.sp
                        )
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = if (!isStoragePermissionGranted) "Grant storage access to see your device media, or download content." else "No media matches the currently selected filter.",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = SleekTextSecondary,
                            textAlign = TextAlign.Center
                        )
                    )
                    if (!isStoragePermissionGranted) {
                        Spacer(modifier = Modifier.height(16.dp))
                        Button(
                            onClick = { permissionState.launchMultiplePermissionRequest() },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color.White,
                                contentColor = Color.Black
                            ),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("Grant Permissions", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            } else {
                val showSelectionBoxes = isSelectionMode || selectedIds.isNotEmpty()

                val allVisibleSelected = filteredItems.isNotEmpty() && filteredItems.all { item ->
                    val key = when (item) {
                        is LibraryItem.Completed -> "completed_${item.entity.id}"
                        is LibraryItem.Failed -> "failed_${item.task.id}"
                    }
                    selectedIds.contains(key)
                }

                val onToggleSelectAll = {
                    if (allVisibleSelected) {
                        selectedIds = selectedIds - filteredItems.map { item ->
                            when (item) {
                                is LibraryItem.Completed -> "completed_${item.entity.id}"
                                is LibraryItem.Failed -> "failed_${item.task.id}"
                            }
                        }.toSet()
                        if (selectedIds.isEmpty()) isSelectionMode = false
                    } else {
                        selectedIds = selectedIds + filteredItems.map { item ->
                            when (item) {
                                is LibraryItem.Completed -> "completed_${item.entity.id}"
                                is LibraryItem.Failed -> "failed_${item.task.id}"
                            }
                        }.toSet()
                        isSelectionMode = true
                    }
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = marginH, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    if (showSelectionBoxes) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.clickable { onToggleSelectAll() }
                            ) {
                                Checkbox(
                                    checked = allVisibleSelected,
                                    onCheckedChange = { onToggleSelectAll() },
                                    colors = CheckboxDefaults.colors(
                                        checkedColor = Color(0xFFFF8A00),
                                        uncheckedColor = SleekTextSecondary
                                    ),
                                    modifier = Modifier.testTag("select_all_checkbox")
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Select All",
                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium),
                                    color = Color.White
                                )
                            }

                            Spacer(modifier = Modifier.width(16.dp))

                            TextButton(
                                onClick = {
                                    isSelectionMode = false
                                    selectedIds = emptySet()
                                }
                            ) {
                                Text("Cancel", color = SleekTextSecondary)
                            }
                        }
                    } else {
                        Spacer(modifier = Modifier.width(8.dp))
                    }

                    if (selectedIds.isNotEmpty()) {
                        Button(
                            onClick = { showBulkDeleteConfirm = true },
                            colors = ButtonDefaults.buttonColors(containerColor = CrimsonFailure),
                            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.testTag("bulk_delete_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Delete,
                                contentDescription = "Delete",
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Delete Selected (${selectedIds.size})",
                                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold)
                            )
                        }
                    }
                }

                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = marginH, end = marginH, top = cardTopGap, bottom = 140.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    if (columns == 1) {
                        itemsIndexed(filteredItems, key = { _, item -> item.id }) { index, item ->
                            val key = when (item) {
                                is LibraryItem.Completed -> "completed_${item.entity.id}"
                                is LibraryItem.Failed -> "failed_${item.task.id}"
                            }
                            val isSelected = selectedIds.contains(key)
                            
                            val itemOnSelectedChange: ((Boolean) -> Unit)? = if (showSelectionBoxes) {
                                { checked ->
                                    selectedIds = if (checked) selectedIds + key else selectedIds - key
                                    if (selectedIds.isEmpty()) isSelectionMode = false
                                }
                            } else null

                            val itemOnLongClick: () -> Unit = {
                                isSelectionMode = true
                                selectedIds = if (selectedIds.contains(key)) selectedIds - key else selectedIds + key
                            }

                            when (item) {
                                is LibraryItem.Completed -> {
                                    if (item.entity.downloadStatus in listOf("INCOMPLETE", "RECOVERABLE", "CORRUPTED", "FAILED")) {
                                        FailedItemCard(
                                            entity = item.entity,
                                            index = index,
                                            selected = isSelected,
                                            onSelectedChange = itemOnSelectedChange,
                                            onLongClick = itemOnLongClick,
                                            onResumeClick = { viewModel?.resumeDownloadItem(item.entity) },
                                            onRefetchClick = { viewModel?.refetchDownloadItem(item.entity) },
                                            onDeleteClick = { viewModel?.deleteIncompleteDownload(item.entity) },
                                            modifier = Modifier.animateItem()
                                        )
                                    } else {
                                        LibraryItemCard(
                                            item = item.entity,
                                            index = index,
                                            selected = isSelected,
                                            onSelectedChange = itemOnSelectedChange,
                                            onLongClick = itemOnLongClick,
                                            onPlayClick = { onPlayClick(item.entity) },
                                            onShareClick = { onShareClick(item.entity) },
                                            onDeleteClick = { onDeleteClick(item.entity) },
                                            onConvertAudio = { codec -> onConvertAudio(item.entity, codec) },
                                            onTrimClick = {
                                                viewModel?.openMediaTrimmer(item.entity)
                                            },
                                            onCompressClick = {
                                                viewModel?.openVideoCompressor(item.entity)
                                            },
                                            onEditMetadataClick = { onEditMetadataClick?.invoke(item.entity) },
                                            onAddToPlaylistClick = { onAddToPlaylistClick?.invoke(item.entity) },
                                            onUpdateThumbnail = { path -> viewModel?.updateMediaThumbnail(item.entity.id, path) },
                                            modifier = Modifier.animateItem()
                                        )
                                    }
                                }
                                is LibraryItem.Failed -> {
                                    FailedItemCard(
                                        task = item.task,
                                        index = index,
                                        selected = isSelected,
                                        onSelectedChange = itemOnSelectedChange,
                                        onLongClick = itemOnLongClick,
                                        onResumeClick = if (item.task.originalUrl.isNotBlank()) {
                                            {
                                                val entityFromTask = DownloadEntity(
                                                    id = item.task.id,
                                                    title = item.task.title,
                                                    author = item.task.author,
                                                    durationText = item.task.durationText,
                                                    thumbnailUrl = item.task.thumbnailUrl,
                                                    localPath = "",
                                                    fileSize = item.task.downloadedBytes,
                                                    expectedSize = item.task.totalBytes,
                                                    originalUrl = item.task.originalUrl,
                                                    formatId = item.task.formatId,
                                                    formatQuality = item.task.formatQuality,
                                                    formatExt = item.task.ext
                                                )
                                                viewModel?.resumeDownloadItem(entityFromTask)
                                            }
                                        } else null,
                                        onRefetchClick = if (item.task.originalUrl.isNotBlank()) {
                                            {
                                                val entityFromTask = DownloadEntity(
                                                    id = item.task.id,
                                                    title = item.task.title,
                                                    author = item.task.author,
                                                    durationText = item.task.durationText,
                                                    thumbnailUrl = item.task.thumbnailUrl,
                                                    localPath = "",
                                                    fileSize = 0L,
                                                    expectedSize = item.task.totalBytes,
                                                    originalUrl = item.task.originalUrl,
                                                    formatId = item.task.formatId,
                                                    formatQuality = item.task.formatQuality,
                                                    formatExt = item.task.ext
                                                )
                                                viewModel?.refetchDownloadItem(entityFromTask)
                                            }
                                        } else null,
                                        onDeleteClick = { onDeleteFailedClick(item.task.id) },
                                        modifier = Modifier.animateItem()
                                    )
                                }
                            }
                        }
                    } else {
                        val chunks = filteredItems.chunked(columns)
                        itemsIndexed(chunks, key = { _, chunk -> chunk.joinToString("_") { it.id } }) { index, chunk ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(16.dp)
                            ) {
                                chunk.forEachIndexed { chunkIndex, item ->
                                    val key = when (item) {
                                        is LibraryItem.Completed -> "completed_${item.entity.id}"
                                        is LibraryItem.Failed -> "failed_${item.task.id}"
                                    }
                                    val isSelected = selectedIds.contains(key)
                                    val overallIndex = index * columns + chunkIndex
                                    
                                    val itemOnSelectedChange: ((Boolean) -> Unit)? = if (showSelectionBoxes) {
                                        { checked ->
                                            selectedIds = if (checked) selectedIds + key else selectedIds - key
                                            if (selectedIds.isEmpty()) isSelectionMode = false
                                        }
                                    } else null

                                    val itemOnLongClick: () -> Unit = {
                                        isSelectionMode = true
                                        selectedIds = if (selectedIds.contains(key)) selectedIds - key else selectedIds + key
                                    }

                                    Box(modifier = Modifier.weight(1f)) {
                                        when (item) {
                                            is LibraryItem.Completed -> {
                                                if (item.entity.downloadStatus in listOf("INCOMPLETE", "RECOVERABLE", "CORRUPTED", "FAILED")) {
                                                    FailedItemCard(
                                                        entity = item.entity,
                                                        index = overallIndex,
                                                        selected = isSelected,
                                                        onSelectedChange = itemOnSelectedChange,
                                                        onLongClick = itemOnLongClick,
                                                        onResumeClick = { viewModel?.resumeDownloadItem(item.entity) },
                                                        onRefetchClick = { viewModel?.refetchDownloadItem(item.entity) },
                                                        onDeleteClick = { viewModel?.deleteIncompleteDownload(item.entity) },
                                                        modifier = Modifier.animateItem()
                                                    )
                                                } else {
                                                    LibraryItemCard(
                                                        item = item.entity,
                                                        index = overallIndex,
                                                        selected = isSelected,
                                                        onSelectedChange = itemOnSelectedChange,
                                                        onLongClick = itemOnLongClick,
                                                        onPlayClick = { onPlayClick(item.entity) },
                                                        onShareClick = { onShareClick(item.entity) },
                                                        onDeleteClick = { onDeleteClick(item.entity) },
                                                        onConvertAudio = { codec -> onConvertAudio(item.entity, codec) },
                                                        onTrimClick = {
                                                            viewModel?.openMediaTrimmer(item.entity)
                                                        },
                                                        onCompressClick = {
                                                            viewModel?.openVideoCompressor(item.entity)
                                                        },
                                                        onEditMetadataClick = { onEditMetadataClick?.invoke(item.entity) },
                                                        onAddToPlaylistClick = { onAddToPlaylistClick?.invoke(item.entity) },
                                                        onUpdateThumbnail = { path -> viewModel?.updateMediaThumbnail(item.entity.id, path) },
                                                        modifier = Modifier.animateItem()
                                                    )
                                                }
                                            }
                                            is LibraryItem.Failed -> {
                                                FailedItemCard(
                                                    task = item.task,
                                                    index = overallIndex,
                                                    selected = isSelected,
                                                    onSelectedChange = itemOnSelectedChange,
                                                    onLongClick = itemOnLongClick,
                                                    onResumeClick = if (item.task.originalUrl.isNotBlank()) {
                                                        {
                                                            val entityFromTask = DownloadEntity(
                                                                id = item.task.id,
                                                                title = item.task.title,
                                                                author = item.task.author,
                                                                durationText = item.task.durationText,
                                                                thumbnailUrl = item.task.thumbnailUrl,
                                                                localPath = "",
                                                                fileSize = item.task.downloadedBytes,
                                                                expectedSize = item.task.totalBytes,
                                                                originalUrl = item.task.originalUrl,
                                                                formatId = item.task.formatId,
                                                                formatQuality = item.task.formatQuality,
                                                                formatExt = item.task.ext
                                                            )
                                                            viewModel?.resumeDownloadItem(entityFromTask)
                                                        }
                                                    } else null,
                                                    onRefetchClick = if (item.task.originalUrl.isNotBlank()) {
                                                        {
                                                            val entityFromTask = DownloadEntity(
                                                                id = item.task.id,
                                                                title = item.task.title,
                                                                author = item.task.author,
                                                                durationText = item.task.durationText,
                                                                thumbnailUrl = item.task.thumbnailUrl,
                                                                localPath = "",
                                                                fileSize = 0L,
                                                                expectedSize = item.task.totalBytes,
                                                                originalUrl = item.task.originalUrl,
                                                                formatId = item.task.formatId,
                                                                formatQuality = item.task.formatQuality,
                                                                formatExt = item.task.ext
                                                            )
                                                            viewModel?.refetchDownloadItem(entityFromTask)
                                                        }
                                                    } else null,
                                                    onDeleteClick = { onDeleteFailedClick(item.task.id) },
                                                    modifier = Modifier.animateItem()
                                                )
                                            }
                                        }
                                    }
                                }
                                val emptySlots = columns - chunk.size
                                repeat(emptySlots) {
                                    Spacer(modifier = Modifier.weight(1f))
                                }
                            }
                        }
                    }
                }
            }
            }
        }
    }
}

enum class LibraryThumbnailState {
    VALID_THUMBNAIL,
    MISSING_THUMBNAIL,
    BLACK_THUMBNAIL,
    EXTRACTION_FAILED
}

suspend fun evaluateLibraryThumbnailState(
    context: android.content.Context,
    thumbnailUrl: String,
    isLocalVideo: Boolean
): LibraryThumbnailState {
    if (thumbnailUrl.isBlank()) {
        return if (isLocalVideo) LibraryThumbnailState.MISSING_THUMBNAIL else LibraryThumbnailState.EXTRACTION_FAILED
    }
    return kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
        try {
            val loader = context.imageLoader
            val request = coil.request.ImageRequest.Builder(context)
                .data(thumbnailUrl)
                .size(128, 128)
                .allowHardware(false)
                .build()
            val result = loader.execute(request)
            val drawable = result.drawable ?: return@withContext if (isLocalVideo) LibraryThumbnailState.EXTRACTION_FAILED else LibraryThumbnailState.EXTRACTION_FAILED
            val bitmap = if (drawable is android.graphics.drawable.BitmapDrawable) {
                drawable.bitmap
            } else {
                val bmp = android.graphics.Bitmap.createBitmap(
                    drawable.intrinsicWidth.coerceAtLeast(128),
                    drawable.intrinsicHeight.coerceAtLeast(128),
                    android.graphics.Bitmap.Config.ARGB_8888
                )
                val canvas = android.graphics.Canvas(bmp)
                drawable.setBounds(0, 0, canvas.width, canvas.height)
                drawable.draw(canvas)
                bmp
            }
            if (bitmap == null || bitmap.width == 0 || bitmap.height == 0) {
                return@withContext if (isLocalVideo) LibraryThumbnailState.EXTRACTION_FAILED else LibraryThumbnailState.EXTRACTION_FAILED
            }

            val width = bitmap.width
            val height = bitmap.height
            val totalPixels = width * height
            val pixels = IntArray(totalPixels)
            bitmap.getPixels(pixels, 0, width, 0, 0, width, height)

            var nearBlackCount = 0
            val veryLowThreshold = 12 // Very low luminance threshold for near-black pixels

            for (pixel in pixels) {
                val r = (pixel shr 16) and 0xFF
                val g = (pixel shr 8) and 0xFF
                val b = pixel and 0xFF
                val luminance = 0.299f * r + 0.587f * g + 0.114f * b
                if (luminance <= veryLowThreshold) {
                    nearBlackCount++
                }
            }

            val nearBlackRatio = nearBlackCount.toFloat() / totalPixels

            if (nearBlackRatio >= 0.95f) {
                LibraryThumbnailState.BLACK_THUMBNAIL
            } else {
                LibraryThumbnailState.VALID_THUMBNAIL
            }
        } catch (e: Exception) {
            if (isLocalVideo) LibraryThumbnailState.EXTRACTION_FAILED else LibraryThumbnailState.EXTRACTION_FAILED
        }
    }
}

@Composable
fun MediaCardThumbnailArea(
    item: DownloadEntity,
    durationString: String,
    modifier: Modifier = Modifier,
    onUpdateThumbnail: ((String) -> Unit)? = null
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val isAudio = item.isAudioOnly || 
        item.localPath.endsWith(".mp3", true) || 
        item.localPath.endsWith(".m4a", true) || 
        item.localPath.endsWith(".opus", true) || 
        item.localPath.endsWith(".wav", true) ||
        item.localPath.endsWith(".flac", true)

    val isLocalVideo = !isAudio && item.localPath.isNotBlank() && java.io.File(item.localPath).exists()

    var thumbnailState by remember(item.id, item.thumbnailUrl, item.localPath) {
        mutableStateOf<LibraryThumbnailState?>(
            if (item.thumbnailUrl.isBlank()) {
                if (isLocalVideo) LibraryThumbnailState.MISSING_THUMBNAIL else LibraryThumbnailState.EXTRACTION_FAILED
            } else null
        )
    }

    LaunchedEffect(item.id, item.thumbnailUrl, item.localPath) {
        val state = evaluateLibraryThumbnailState(context, item.thumbnailUrl, isLocalVideo)
        thumbnailState = state
    }

    val currentState = thumbnailState
    val stateLogStr = when (currentState) {
        LibraryThumbnailState.VALID_THUMBNAIL -> "VALID"
        LibraryThumbnailState.MISSING_THUMBNAIL -> "MISSING"
        LibraryThumbnailState.BLACK_THUMBNAIL -> "BLACK"
        LibraryThumbnailState.EXTRACTION_FAILED -> "FAILED"
        null -> "EVALUATING"
    }

    if (currentState != null) {
        android.util.Log.d("LIBRARY_THUMBNAIL", "id=${item.id} state=$stateLogStr")
    }

    val showGridFallback = isLocalVideo && (
        currentState == LibraryThumbnailState.MISSING_THUMBNAIL ||
        currentState == LibraryThumbnailState.BLACK_THUMBNAIL ||
        currentState == LibraryThumbnailState.EXTRACTION_FAILED
    )

    android.util.Log.d("FRAME_GRID", "id=${item.id} shown=$showGridFallback")

    val framePages = remember {
        listOf(
            listOf(0.10f, 0.35f, 0.65f, 0.90f),
            listOf(0.20f, 0.45f, 0.75f, 0.95f),
            listOf(0.05f, 0.25f, 0.55f, 0.80f),
            listOf(0.15f, 0.40f, 0.70f, 0.85f),
            listOf(0.02f, 0.30f, 0.60f, 0.98f)
        )
    }
    val totalPages = framePages.size
    var currentPage by remember(item.id) { mutableIntStateOf(0) }

    val cachedPages = remember(item.id, item.localPath) {
        androidx.compose.runtime.mutableStateMapOf<Int, List<com.example.data.ExtractedFrame>>()
    }

    var dragOffsetX by remember { mutableFloatStateOf(0f) }
    var temporarySelectedFrame by remember(item.id, item.thumbnailUrl) { mutableStateOf<String?>(null) }
    val tapBlockerInteractionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() }

    LaunchedEffect(showGridFallback, currentPage, item.id, item.localPath) {
        if (showGridFallback && !cachedPages.containsKey(currentPage)) {
            kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                val percentages = framePages.getOrElse(currentPage) { framePages[0] }
                val frames = com.example.data.MediaThumbnailExtractor.extractFramesAtPercentages(
                    context = context,
                    localPath = item.localPath,
                    mediaId = item.id,
                    percentages = percentages
                )
                kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
                    cachedPages[currentPage] = frames
                }
            }
        }
    }

    BoxWithConstraints(
        modifier = modifier
            .fillMaxWidth()
            .aspectRatio(16f / 9f)
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0xFF14161C))
            .then(
                if (showGridFallback) {
                    Modifier.clickable(
                        interactionSource = tapBlockerInteractionSource,
                        indication = null,
                        onClick = { /* Swallow taps to prevent parent card from consuming them */ }
                    )
                } else Modifier
            )
            .pointerInput(showGridFallback, totalPages) {
                if (showGridFallback && totalPages > 1) {
                    detectHorizontalDragGestures(
                        onDragEnd = {
                            if (dragOffsetX < -30f && currentPage < totalPages - 1) {
                                currentPage++
                            } else if (dragOffsetX > 30f && currentPage > 0) {
                                currentPage--
                            }
                            dragOffsetX = 0f
                        },
                        onDragCancel = { dragOffsetX = 0f },
                        onHorizontalDrag = { change, dragAmount ->
                            change.consume()
                            dragOffsetX += dragAmount
                        }
                    )
                }
            }
    ) {
        val areaWidth = maxWidth
        val areaHeight = maxHeight
        val internalGap = (areaWidth * 0.003f).coerceIn(1.dp, 2.5.dp)

        if (showGridFallback) {
            if (!cachedPages.containsKey(currentPage)) {
                // Lightweight loading state inside thumbnail area while frames generate
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color(0xFF14161C)),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator(
                        color = Color(0xFFFF8A00),
                        modifier = Modifier.size(24.dp),
                        strokeWidth = 2.dp
                    )
                }
            } else {
                // 2x2 Frame Grid Presentation
                AnimatedContent(
                    targetState = currentPage,
                    transitionSpec = {
                        if (targetState > initialState) {
                            (slideInHorizontally(animationSpec = tween(350, easing = EaseOut)) { width -> width } + fadeIn(animationSpec = tween(350))) togetherWith
                            (slideOutHorizontally(animationSpec = tween(350, easing = EaseOut)) { width -> -width } + fadeOut(animationSpec = tween(350)))
                        } else {
                            (slideInHorizontally(animationSpec = tween(350, easing = EaseOut)) { width -> -width } + fadeIn(animationSpec = tween(350))) togetherWith
                            (slideOutHorizontally(animationSpec = tween(350, easing = EaseOut)) { width -> width } + fadeOut(animationSpec = tween(350)))
                        }
                    },
                    modifier = Modifier.fillMaxSize(),
                    label = "GridSlide"
                ) { page ->
                    val currentFrames = cachedPages[page] ?: emptyList()
                    val row1 = listOf(0, 1)
                    val row2 = listOf(2, 3)

                    if (currentFrames.isEmpty()) {
                        // Fallback icon if extraction returned no frames
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(Color(0xFF1E2028)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Movie,
                                contentDescription = "Video Cover",
                                tint = Color(0xFFFF8A00),
                                modifier = Modifier.size(44.dp)
                            )
                        }
                    } else {
                        Column(
                            modifier = Modifier.fillMaxSize(),
                            verticalArrangement = Arrangement.spacedBy(internalGap)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .weight(1f),
                                horizontalArrangement = Arrangement.spacedBy(internalGap)
                            ) {
                                for (idx in row1) {
                                    val frame = currentFrames.getOrNull(idx)
                                    val isSelected = frame != null && frame.filePath == temporarySelectedFrame
                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .fillMaxHeight()
                                            .background(Color(0xFF181A22))
                                            .then(if (isSelected) Modifier.border(2.dp, Color(0xFFFF8A00)) else Modifier)
                                            .clickable(enabled = frame != null) {
                                                frame?.filePath?.let { 
                                                    temporarySelectedFrame = it
                                                    onUpdateThumbnail?.invoke(it) 
                                                }
                                            }
                                    ) {
                                        if (frame != null) {
                                            AsyncImage(
                                                model = frame.filePath,
                                                contentDescription = null,
                                                contentScale = ContentScale.Crop,
                                                modifier = Modifier.fillMaxSize()
                                            )
                                        }
                                    }
                                }
                            }
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .weight(1f),
                                horizontalArrangement = Arrangement.spacedBy(internalGap)
                            ) {
                                for (idx in row2) {
                                    val frame = currentFrames.getOrNull(idx)
                                    val isSelected = frame != null && frame.filePath == temporarySelectedFrame
                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .fillMaxHeight()
                                            .background(Color(0xFF181A22))
                                            .then(if (isSelected) Modifier.border(2.dp, Color(0xFFFF8A00)) else Modifier)
                                            .clickable(enabled = frame != null) {
                                                frame?.filePath?.let { 
                                                    temporarySelectedFrame = it
                                                    onUpdateThumbnail?.invoke(it) 
                                                }
                                            }
                                    ) {
                                        if (frame != null) {
                                            AsyncImage(
                                                model = frame.filePath,
                                                contentDescription = null,
                                                contentScale = ContentScale.Crop,
                                                modifier = Modifier.fillMaxSize()
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // Floating Pagination Dots
                if (totalPages > 1 && (cachedPages[currentPage]?.isNotEmpty() == true)) {
                    val activeDotSize = (areaWidth * 0.017f).coerceIn(5.5.dp, 7.5.dp)
                    val inactiveDotSize = (areaWidth * 0.0135f).coerceIn(4.dp, 5.5.dp)
                    val dotGap = (areaWidth * 0.012f).coerceIn(3.5.dp, 5.5.dp)
                    val bottomPadding = (areaHeight * 0.08f).coerceIn(6.dp, 12.dp)

                    Row(
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .padding(bottom = bottomPadding),
                        horizontalArrangement = Arrangement.spacedBy(dotGap),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        for (i in 0 until totalPages) {
                            val isDotActive = i == currentPage
                            val dotSize by animateDpAsState(
                                targetValue = if (isDotActive) activeDotSize else inactiveDotSize,
                                animationSpec = tween(durationMillis = 180),
                                label = "DotSize_$i"
                            )
                            val dotColor by animateColorAsState(
                                targetValue = if (isDotActive) Color(0xFFFF8A00) else Color.White.copy(alpha = 0.45f),
                                animationSpec = tween(durationMillis = 180),
                                label = "DotColor_$i"
                            )
                            Box(
                                modifier = Modifier
                                    .size(dotSize)
                                    .background(dotColor, CircleShape)
                            )
                        }
                    }
                }
            }
        } else if (item.thumbnailUrl.isNotBlank()) {
            AsyncImage(
                model = coil.request.ImageRequest.Builder(context)
                    .data(item.thumbnailUrl)
                    .crossfade(true)
                    .build(),
                contentDescription = "Cover",
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
        } else {
            // Fallback audio / placeholder
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xFF1E2028)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (isAudio) Icons.Default.MusicNote else Icons.Default.Movie,
                    contentDescription = if (isAudio) "Audio Cover" else "Video Cover",
                    tint = Color(0xFFFF8A00),
                    modifier = Modifier.size(44.dp)
                )
            }
        }

        // Duration badge
        if (durationString.isNotBlank()) {
            Box(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(8.dp)
                    .background(Color.Black.copy(alpha = 0.8f), RoundedCornerShape(4.dp))
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
                Text(
                    text = durationString,
                    color = Color.White,
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = FontWeight.SemiBold,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.5.sp
                    )
                )
            }
        }
    }
}

@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
@Composable
fun LibraryItemCard(
    item: DownloadEntity,
    onPlayClick: () -> Unit,
    onShareClick: () -> Unit,
    onDeleteClick: () -> Unit,
    onConvertAudio: (String) -> Unit,
    onTrimClick: (() -> Unit)? = null,
    onCompressClick: (() -> Unit)? = null,
    onEditMetadataClick: (() -> Unit)? = null,
    onAddToPlaylistClick: (() -> Unit)? = null,
    onUpdateThumbnail: ((String) -> Unit)? = null,
    selected: Boolean = false,
    onSelectedChange: ((Boolean) -> Unit)? = null,
    onLongClick: (() -> Unit)? = null,
    modifier: Modifier = Modifier,
    index: Int = 0
) {
    android.util.Log.d("MEDIA_CARD_RECOMPOSE", "LibraryItemCard recomposed: id=${item.id}, title=${item.title}, author=${item.author}, thumb=${item.thumbnailUrl}")
    var showDeleteConfirmDialog by remember { mutableStateOf(false) }
    var showConvertCodecDialog by remember { mutableStateOf(false) }
    var showOverflowMenu by remember { mutableStateOf(false) }
    var selectedCodec by remember { mutableStateOf("mp3") }

    val slideInOffset = remember { Animatable(100f) }
    val opacity = remember { Animatable(0f) }

    LaunchedEffect(key1 = item.id) {
        val delayTime = (index * 45L).coerceAtMost(250L)
        delay(delayTime)
        launch {
            slideInOffset.animateTo(
                targetValue = 0f,
                animationSpec = spring(
                    dampingRatio = Spring.DampingRatioLowBouncy,
                    stiffness = Spring.StiffnessMediumLow
                )
            )
        }
        launch {
            opacity.animateTo(
                targetValue = 1f,
                animationSpec = tween(durationMillis = 300, easing = LinearOutSlowInEasing)
            )
        }
    }

    val formattedSize = remember(item.fileSize) {
        if (item.fileSize > 0) {
            String.format(Locale.getDefault(), "%.1f MB", item.fileSize.toFloat() / (1024 * 1024))
        } else {
            "3.2 MB"
        }
    }

    val formattedDate = remember(item.downloadedAt) {
        val date = if (item.downloadedAt > 0) Date(item.downloadedAt) else Date()
        SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(date)
    }

    val durationString = item.durationText.ifBlank { "03:28" }
    val authorString = if (item.author.isNotBlank()) "Video by ${item.author}" else "Adaptive Stream"

    Row(
        modifier = modifier
            .fillMaxWidth()
            .graphicsLayer {
                translationX = slideInOffset.value
                alpha = opacity.value
            },
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (onSelectedChange != null) {
            Checkbox(
                checked = selected,
                onCheckedChange = onSelectedChange,
                colors = CheckboxDefaults.colors(
                    checkedColor = Color(0xFFFF8A00),
                    uncheckedColor = SleekTextSecondary
                ),
                modifier = Modifier.padding(end = 8.dp).testTag("checkbox_${item.id}")
            )
        }

        Card(
            modifier = Modifier
                .weight(1f)
                .padding(vertical = 4.dp)
                .combinedClickable(
                    onClick = onPlayClick,
                    onLongClick = { onLongClick?.invoke() }
                ),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF13151B).copy(alpha = 0.75f)),
            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.06f))
        ) {
            Column(
                modifier = Modifier.fillMaxWidth().padding(10.dp)
            ) {
                // Media Thumbnail Area with 2x2 Grid and Floating Pagination Dots
                MediaCardThumbnailArea(
                    item = item,
                    durationString = durationString,
                    onUpdateThumbnail = onUpdateThumbnail
                )
                
                // Details below thumbnail
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 10.dp, bottom = 2.dp, start = 2.dp, end = 2.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    // Channel Avatar placeholder
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF1E2128).copy(alpha = 0.85f)),
                        contentAlignment = Alignment.Center
                    ) {
                        val initial = authorString.firstOrNull()?.toString()?.uppercase() ?: "U"
                        Text(
                            text = initial,
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                    }
                    
                    Column(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(3.dp)
                    ) {
                        Text(
                            text = item.title,
                            color = Color(0xFFF2F4F8),
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.5.sp,
                                lineHeight = 20.sp
                            ),
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "$authorString • $formattedSize • $formattedDate",
                            color = Color(0xFF9AA0A6),
                            style = MaterialTheme.typography.bodySmall.copy(
                                fontWeight = FontWeight.Normal,
                                fontSize = 12.5.sp
                            ),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    
                    // Card Action Button (three-dots)
                    Box {
                        Surface(
                            shape = CircleShape,
                            color = Color(0xFF181A22).copy(alpha = 0.55f),
                            border = BorderStroke(0.5.dp, Color.White.copy(alpha = 0.06f)),
                            modifier = Modifier
                                .size(34.dp)
                                .clip(CircleShape)
                                .clickable { showOverflowMenu = true }
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.MoreVert,
                                    contentDescription = "More Options",
                                    tint = Color.White,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }

                        DropdownMenu(
                            expanded = showOverflowMenu,
                            onDismissRequest = { showOverflowMenu = false },
                            modifier = Modifier
                                .background(Color(0xFF161820))
                                .border(1.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(12.dp))
                        ) {
                            DropdownMenuItem(
                                text = { Text("Play Video", color = Color.White) },
                                leadingIcon = { Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Color(0xFFFF8A00)) },
                                onClick = {
                                    showOverflowMenu = false
                                    onPlayClick()
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Trim & Cut Clip", color = Color.White) },
                                leadingIcon = { Icon(Icons.Default.ContentCut, contentDescription = null, tint = Color(0xFFFF8A00)) },
                                onClick = {
                                    showOverflowMenu = false
                                    onTrimClick?.invoke()
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Compress Video", color = Color.White) },
                                leadingIcon = { Icon(Icons.Default.Compress, contentDescription = null, tint = Color(0xFFFF8A00)) },
                                onClick = {
                                    showOverflowMenu = false
                                    onCompressClick?.invoke()
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Extract Audio", color = Color.White) },
                                leadingIcon = { Icon(Icons.Default.MusicNote, contentDescription = null, tint = Color(0xFFFF8A00)) },
                                onClick = {
                                    showOverflowMenu = false
                                    showConvertCodecDialog = true
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Edit ID3 Tags & Cover", color = Color.White) },
                                leadingIcon = { Icon(Icons.Default.Edit, contentDescription = null, tint = Color(0xFFFF8A00)) },
                                onClick = {
                                    showOverflowMenu = false
                                    onEditMetadataClick?.invoke()
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Add to Playlist", color = Color.White) },
                                leadingIcon = { Icon(Icons.Default.PlaylistAdd, contentDescription = null, tint = Color(0xFF00E676)) },
                                onClick = {
                                    showOverflowMenu = false
                                    onAddToPlaylistClick?.invoke()
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Share", color = Color.White) },
                                leadingIcon = { Icon(Icons.Default.Share, contentDescription = null, tint = Color(0xFF3BA5FF)) },
                                onClick = {
                                    showOverflowMenu = false
                                    onShareClick()
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Delete", color = Color(0xFFFF4C4C)) },
                                leadingIcon = { Icon(Icons.Default.Delete, contentDescription = null, tint = Color(0xFFFF4C4C)) },
                                onClick = {
                                    showOverflowMenu = false
                                    showDeleteConfirmDialog = true
                                }
                            )
                        }
                    }
                }
            }
        }
    }

    if (showDeleteConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirmDialog = false },
            title = { Text("Delete downloaded file?", color = SleekTextPrimary, fontWeight = FontWeight.Bold) },
            text = { Text("This will permanently delete this video from your device storage and library cache.", color = SleekTextSecondary) },
            confirmButton = {
                TextButton(
                    onClick = {
                        showDeleteConfirmDialog = false
                        onDeleteClick()
                    }
                ) {
                    Icon(Icons.Default.Delete, contentDescription = "Delete", tint = CrimsonFailure)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirmDialog = false }) {
                    Icon(Icons.Default.Close, contentDescription = "Cancel", tint = SleekTextSecondary)
                }
            },
            containerColor = SleekCard,
            titleContentColor = SleekTextPrimary,
            textContentColor = SleekTextSecondary
        )
    }
    if (showConvertCodecDialog) {
        AlertDialog(
            onDismissRequest = { showConvertCodecDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(imageVector = Icons.Default.MusicNote, contentDescription = null, tint = SleekPurpleLight)
                    Text("Select Audio Codec Format", color = SleekTextPrimary, fontWeight = FontWeight.Bold)
                }
            },
            text = {
                Column(
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "Extract and convert the audio stream from this file into your preferred container / codec format:",
                        color = SleekTextSecondary,
                        fontSize = 13.sp,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                    val codecs = listOf(
                        "mp3" to "MP3 (Lame - High Compatibility)",
                        "m4a" to "M4A (AAC - Compact Quality)",
                        "aac" to "AAC (Native Audio Stream)",
                        "wav" to "WAV (Lossless Raw PCM)",
                        "flac" to "FLAC (High Fidelity Lossless)",
                        "opus" to "OPUS (Next-Gen low bitrate)",
                        "ogg" to "OGG Vorbis (Open Standard)"
                    )
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 240.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        items(codecs) { (key, label) ->
                            val isSelected = selectedCodec == key
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isSelected) SleekPurpleContainer.copy(alpha = 0.2f) else Color.Transparent)
                                    .clickable { selectedCodec = key }
                                    .padding(horizontal = 12.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                RadioButton(
                                    selected = isSelected,
                                    onClick = { selectedCodec = key },
                                    colors = RadioButtonDefaults.colors(
                                        selectedColor = SleekPurpleLight,
                                        unselectedColor = SleekTextSecondary
                                    )
                                )
                                Text(
                                    text = label,
                                    color = if (isSelected) SleekPurpleLight else SleekTextPrimary,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    fontSize = 14.sp
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showConvertCodecDialog = false
                        onConvertAudio(selectedCodec)
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color.White,
                        contentColor = Color.Black
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.LibraryMusic, contentDescription = "Extract")
                }
            },
            dismissButton = {
                TextButton(onClick = { showConvertCodecDialog = false }) {
                    Icon(Icons.Default.Close, contentDescription = "Cancel", tint = SleekTextSecondary)
                }
            },
            containerColor = SleekCard,
            titleContentColor = SleekTextPrimary,
            textContentColor = SleekTextSecondary
        )
    }
}

@Composable
fun HistoryTab(
    historyList: List<com.example.data.BrowsingHistoryEntity>,
    onPlayClick: (com.example.data.BrowsingHistoryEntity) -> Unit,
    onDeleteClick: (String) -> Unit,
    onClearAllClick: () -> Unit,
    onRevisitClick: (com.example.data.BrowsingHistoryEntity) -> Unit
) {
    val isTabletOrWide = androidx.compose.ui.platform.LocalConfiguration.current.screenWidthDp >= 600
    var showConfirmClearAll by remember { mutableStateOf(false) }

    if (showConfirmClearAll) {
        AlertDialog(
            onDismissRequest = { showConfirmClearAll = false },
            title = { Text("Clear Entire History?", fontWeight = FontWeight.Bold, color = SleekTextPrimary) },
            text = { Text("Are you sure you want to permanently clear your recently streamed/downloaded URLs history? This cannot be undone.", color = SleekTextSecondary) },
            confirmButton = {
                TextButton(onClick = {
                    showConfirmClearAll = false
                    onClearAllClick()
                }) {
                    Icon(Icons.Default.DeleteSweep, contentDescription = "Clear All", tint = CrimsonFailure)
                }
            },
            dismissButton = {
                TextButton(onClick = { showConfirmClearAll = false }) {
                    Icon(Icons.Default.Close, contentDescription = "Cancel", tint = SleekTextSecondary)
                }
            },
            containerColor = SleekCard,
            shape = RoundedCornerShape(16.dp)
        )
    }

    val configuration = androidx.compose.ui.platform.LocalConfiguration.current
    val screenWidthDp = configuration.screenWidthDp
    val columns = when {
        screenWidthDp < 600 -> 1
        screenWidthDp < 840 -> 2
        screenWidthDp < 1200 -> 3
        else -> 4
    }
    val maxContentWidth = (columns * 460).dp

    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier
                .fillMaxHeight()
                .widthIn(max = maxContentWidth)
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(top = 24.dp) // Generous padding to start below the floating top islands
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "RECENT HISTORY (${historyList.size})",
                    style = MaterialTheme.typography.titleSmall.copy(
                        color = SleekPurpleDark,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        letterSpacing = 1.sp,
                        fontSize = responsiveSp(18f, 26f)
                    ),
                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 4.dp)
                )

                if (historyList.isNotEmpty()) {
                    TextButton(
                        onClick = { showConfirmClearAll = true },
                        colors = ButtonDefaults.textButtonColors(contentColor = CrimsonFailure),
                        modifier = Modifier.height(48.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "Clear All",
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Clear All", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                }
            }

            if (historyList.isEmpty()) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = Icons.Default.History,
                        contentDescription = "Empty History",
                        tint = SleekTextMuted.copy(alpha = 0.5f),
                        modifier = Modifier.size(80.dp)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "NO RECENT HISTORY",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = SleekTextPrimary,
                            letterSpacing = 1.sp
                        )
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "URLs of videos you download or stream will appear here so you can revisit them anytime.",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = SleekTextSecondary,
                            textAlign = TextAlign.Center
                        ),
                        modifier = Modifier.padding(horizontal = 16.dp)
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = 24.dp, end = 24.dp, top = 24.dp, bottom = 140.dp),
                    verticalArrangement = Arrangement.spacedBy(24.dp)
                ) {
                    if (columns == 1) {
                        itemsIndexed(historyList, key = { index, item -> item.id + "_$index" }) { index, item ->
                            HistoryItemCard(
                                item = item,
                                index = index,
                                onPlayClick = { onPlayClick(item) },
                                onRevisitClick = { onRevisitClick(item) },
                                onDeleteClick = { onDeleteClick(item.id) },
                                modifier = Modifier.animateItem()
                            )
                        }
                    } else {
                        val chunks = historyList.chunked(columns)
                        itemsIndexed(chunks, key = { index, _ -> "history_chunk_$index" }) { index, chunk ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(24.dp)
                            ) {
                                chunk.forEachIndexed { chunkIndex, item ->
                                    Box(modifier = Modifier.weight(1f)) {
                                        HistoryItemCard(
                                            item = item,
                                            index = index * columns + chunkIndex,
                                            onPlayClick = { onPlayClick(item) },
                                            onRevisitClick = { onRevisitClick(item) },
                                            onDeleteClick = { onDeleteClick(item.id) },
                                            modifier = Modifier.animateItem()
                                        )
                                    }
                                }
                                val emptySlots = columns - chunk.size
                                repeat(emptySlots) {
                                    Spacer(modifier = Modifier.weight(1f))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun HistoryItemCard(
    item: com.example.data.BrowsingHistoryEntity,
    onPlayClick: () -> Unit,
    onRevisitClick: () -> Unit,
    onDeleteClick: () -> Unit,
    modifier: Modifier = Modifier,
    index: Int = 0
) {
    var showDeleteConfirmDialog by remember { mutableStateOf(false) }
    var showOverflowMenu by remember { mutableStateOf(false) }

    val slideInOffset = remember { Animatable(100f) }
    val opacity = remember { Animatable(0f) }

    LaunchedEffect(key1 = item.id) {
        val delayTime = (index * 45L).coerceAtMost(250L)
        delay(delayTime)
        launch {
            slideInOffset.animateTo(
                targetValue = 0f,
                animationSpec = spring(
                    dampingRatio = Spring.DampingRatioLowBouncy,
                    stiffness = Spring.StiffnessMediumLow
                )
            )
        }
        launch {
            opacity.animateTo(
                targetValue = 1f,
                animationSpec = tween(durationMillis = 300, easing = LinearOutSlowInEasing)
            )
        }
    }

    if (showDeleteConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirmDialog = false },
            title = { Text("Delete History Record?", fontWeight = FontWeight.Bold, color = SleekTextPrimary) },
            text = { Text("Are you sure you want to remove this item from your stream history?", color = SleekTextSecondary) },
            confirmButton = {
                TextButton(onClick = {
                    showDeleteConfirmDialog = false
                    onDeleteClick()
                }) {
                    Icon(Icons.Default.Delete, contentDescription = "Remove", tint = CrimsonFailure)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirmDialog = false }) {
                    Icon(Icons.Default.Close, contentDescription = "Cancel", tint = SleekTextSecondary)
                }
            },
            containerColor = SleekCard,
            shape = RoundedCornerShape(16.dp)
        )
    }

    val formattedDate = remember(item.browsedAt) {
        val sdf = java.text.SimpleDateFormat("MMM dd, HH:mm", Locale.getDefault())
        sdf.format(java.util.Date(item.browsedAt))
    }
    val durationString = item.durationText.orEmpty().ifBlank { "03:28" }
    val authorString = if (item.author.isNullOrBlank()) "Unknown Creator" else item.author

    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp)
            .graphicsLayer {
                translationX = slideInOffset.value
                alpha = opacity.value
            }
            .clickable(onClick = onPlayClick),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent)
    ) {
        Column(
            modifier = Modifier.fillMaxWidth()
        ) {
            // Thumbnail
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(16f / 9f)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color.Black)
            ) {
                if (!item.thumbnailUrl.isNullOrEmpty()) {
                    AsyncImage(
                        model = item.thumbnailUrl,
                        contentDescription = "Cover",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                } else {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color(0xFF2A2D35)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.VideoLibrary,
                            contentDescription = "Video Cover",
                            tint = SleekPurpleLight,
                            modifier = Modifier.size(48.dp)
                        )
                    }
                }

                if (durationString.isNotBlank()) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .padding(8.dp)
                            .background(Color.Black.copy(alpha = 0.8f), RoundedCornerShape(4.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = durationString,
                            color = Color.White,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.SemiBold,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 11.sp
                            )
                        )
                    }
                }
            }

            // Details below thumbnail
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 12.dp, bottom = 4.dp, start = 4.dp, end = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.Top
            ) {
                // Channel Avatar placeholder
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .background(Color(0xFF2D2D2D), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    val initial = authorString.firstOrNull()?.toString()?.uppercase() ?: "U"
                    Text(
                        text = initial,
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                }

                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = item.title,
                        color = Color.White,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            lineHeight = 22.sp
                        ),
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = "$authorString • $formattedDate",
                        color = Color(0xFFB0B0B0),
                        style = MaterialTheme.typography.bodyMedium.copy(
                            fontWeight = FontWeight.Normal,
                            fontSize = 13.sp
                        ),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Box {
                    IconButton(
                        onClick = { showOverflowMenu = true },
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.MoreVert,
                            contentDescription = "More Options",
                            tint = Color.White
                        )
                    }
                    DropdownMenu(
                        expanded = showOverflowMenu,
                        onDismissRequest = { showOverflowMenu = false },
                        modifier = Modifier.background(Color(0xFF1E2026))
                    ) {
                        DropdownMenuItem(
                            text = { Text("Stream Now", color = Color.White) },
                            leadingIcon = { Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Color(0xFFFF8A00)) },
                            onClick = {
                                showOverflowMenu = false
                                onPlayClick()
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Analyze Url", color = Color.White) },
                            leadingIcon = { Icon(Icons.Default.Refresh, contentDescription = null, tint = SleekPurpleLight) },
                            onClick = {
                                showOverflowMenu = false
                                onRevisitClick()
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Remove from History", color = Color(0xFFFF4C4C)) },
                            leadingIcon = { Icon(Icons.Default.Delete, contentDescription = null, tint = Color(0xFFFF4C4C)) },
                            onClick = {
                                showOverflowMenu = false
                                showDeleteConfirmDialog = true
                            }
                        )
                    }
                }
            }
        }
    }
}

fun triggerClickHaptic(view: android.view.View) {
    try {
        val prefs = view.context.getSharedPreferences("꒯ꄲꅐꋊ꒒ꌦPrefs", android.content.Context.MODE_PRIVATE)
        if (prefs.getBoolean("enableHapticFeedback", true)) {
            view.performHapticFeedback(
                android.view.HapticFeedbackConstants.KEYBOARD_TAP,
                android.view.HapticFeedbackConstants.FLAG_IGNORE_GLOBAL_SETTING
            )
        }
    } catch (_: Exception) {}
}

@Composable
fun SmoothToggle(
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    val view = androidx.compose.ui.platform.LocalView.current
    val offset by animateFloatAsState(
        targetValue = if (checked) 24f else 4f,
        animationSpec = tween(durationMillis = 250),
        label = "toggle_offset"
    )
    val trackColor = if (checked) SleekPurpleDark else SleekCardDark.copy(alpha = 0.5f)
    val thumbColor = if (checked) SleekBg else SleekTextSecondary.copy(alpha = 0.7f)
    Box(
        modifier = modifier
            .size(width = 50.dp, height = 28.dp)
            .clip(RoundedCornerShape(50))
            .background(trackColor)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null
            ) {
                triggerClickHaptic(view)
                onCheckedChange(!checked)
            }
    ) {
        Box(
            modifier = Modifier
                .offset(x = offset.dp)
                .align(Alignment.CenterStart)
                .size(20.dp)
                .clip(CircleShape)
                .background(thumbColor)
        )
    }
}
@Composable
fun SettingRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    description: String,
    onClick: (() -> Unit)? = null,
    showDivider: Boolean = true,
    action: @Composable RowScope.() -> Unit
) {
    val view = androidx.compose.ui.platform.LocalView.current
    Column {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .then(
                    if (onClick != null) Modifier.clickable(onClick = {
                        triggerClickHaptic(view)
                        onClick()
                    })
                    else Modifier
                )
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .background(SleekPurpleContainer.copy(alpha = 0.3f), CircleShape)
                    .border(1.dp, SleekPurpleLight.copy(alpha = 0.15f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = SleekPurpleLight,
                    modifier = Modifier.size(18.dp)
                )
            }
            Spacer(modifier = Modifier.width(14.dp))
            Column(
                modifier = Modifier
                    .weight(1f)
                    .padding(end = 12.dp)
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        letterSpacing = 0.1.sp
                    ),
                    color = SleekTextPrimary
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = description,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        fontSize = 11.sp,
                        lineHeight = 15.sp
                    ),
                    color = SleekTextSecondary
                )
            }
            Row(
                verticalAlignment = Alignment.CenterVertically,
                content = action
            )
        }
        if (showDivider) {
            HorizontalDivider(
                color = SleekBorderColor.copy(alpha = 0.2f),
                thickness = 0.5.dp,
                modifier = Modifier.padding(horizontal = 16.dp)
            )
        }
    }
}
@Composable
fun SettingsSectionCard(
    title: String,
    content: @Composable ColumnScope.() -> Unit
) {
    Column(
        verticalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.labelLarge.copy(
                fontWeight = FontWeight.Bold,
                color = SleekPurpleDark,
                letterSpacing = 1.sp
            ),
            modifier = Modifier.padding(start = 4.dp, bottom = 4.dp)
        )
        Card(
            colors = CardDefaults.cardColors(containerColor = SleekCard),
            shape = RoundedCornerShape(20.dp),
            border = BorderStroke(1.dp, SleekBorderColor.copy(alpha = 0.35f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(vertical = 4.dp)
            ) {
                content()
            }
        }
    }
}
@Composable
fun SettingsTab(
    downloads: List<com.example.data.DownloadEntity>,
    onClearAllDownloads: () -> Unit,
    viewModel: VideoDownloaderViewModel
) {
    com.example.ui.settings.HierarchicalSettingsScreen(
        downloads = downloads,
        onClearAllDownloads = onClearAllDownloads,
        viewModel = viewModel
    )
}

fun isAudioMedia(media: DownloadEntity): Boolean {
    val title = media.title.lowercase()
    val path = media.localPath.lowercase()

    if (title.contains("[streaming audio]")) return true
    if (title.contains("[streaming video]")) return false
    if (title.contains("(audio)") || title.contains(" [audio]")) return true

    val cleanPath = path.substringBefore("?").substringBefore("#")

    if (cleanPath.endsWith(".mp3") ||
        cleanPath.endsWith(".m4a") ||
        cleanPath.endsWith(".aac") ||
        cleanPath.endsWith(".wav") ||
        cleanPath.endsWith(".flac") ||
        cleanPath.endsWith(".opus") ||
        cleanPath.endsWith(".ogg") ||
        cleanPath.endsWith(".wma")) {
        return true
    }

    if (cleanPath.endsWith(".mp4") ||
        cleanPath.endsWith(".mkv") ||
        cleanPath.endsWith(".webm") ||
        cleanPath.endsWith(".avi") ||
        cleanPath.endsWith(".mov") ||
        cleanPath.endsWith(".3gp") ||
        cleanPath.endsWith(".flv") ||
        cleanPath.endsWith(".ts")) {
        return false
    }

    if (cleanPath.contains("/audio/") || cleanPath.endsWith("/audio")) {
        return true
    }

    if (path.contains("mime=audio/") || path.contains("type=audio/")) {
        return true
    }

    return false
}

fun formatTimeMs(ms: Long): String {
    val totalSeconds = (ms / 1000).coerceAtLeast(0)
    val seconds = totalSeconds % 60
    val minutes = (totalSeconds / 60) % 60
    val hours = totalSeconds / 3600
    return if (hours > 0) {
        String.format("%d:%02d:%02d", hours, minutes, seconds)
    } else {
        String.format("%02d:%02d", minutes, seconds)
    }
}

fun formatBytes(bytes: Long): String {
    if (bytes <= 0L) return "0 B"
    val kb = bytes / 1024.0
    val mb = kb / 1024.0
    val gb = mb / 1024.0
    return when {
        gb >= 1.0 -> String.format(Locale.US, "%.2f GB", gb)
        mb >= 1.0 -> String.format(Locale.US, "%.1f MB", mb)
        kb >= 1.0 -> String.format(Locale.US, "%.1f KB", kb)
        else -> "$bytes B"
    }
}

@Composable
fun AudioEqualizerVisualizer(
    isPlaying: Boolean,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "eq")
    val barHeights = (0..15).map { index ->
        if (isPlaying) {
            val duration = remember(index) { 300 + (index * 70) % 500 }
            val anim by infiniteTransition.animateFloat(
                initialValue = 0.15f,
                targetValue = 0.95f,
                animationSpec = infiniteRepeatable(
                    animation = tween(duration, easing = LinearOutSlowInEasing),
                    repeatMode = RepeatMode.Reverse
                ),
                label = "bar_$index"
            )
            anim
        } else {
            0.2f
        }
    }

    Row(
        modifier = modifier,
        horizontalArrangement = Arrangement.spacedBy(4.dp),
        verticalAlignment = Alignment.Bottom
    ) {
        barHeights.forEach { heightFactor ->
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight(heightFactor)
                    .clip(RoundedCornerShape(2.dp))
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(SleekPurpleDark, SleekPurpleLight)
                        )
                    )
            )
        }
    }
}

@Composable
fun SleekAudioMusicPlayer(
    media: DownloadEntity,
    isFullscreen: Boolean,
    onToggleFullscreen: () -> Unit,
    onClose: () -> Unit,
    viewModel: VideoDownloaderViewModel? = null
) {
    val context = LocalContext.current
    val currentWaveformData = viewModel?.currentWaveformData?.collectAsStateWithLifecycle()?.value
    val mediaPlayer = remember { android.media.MediaPlayer() }
    var isPrepared by remember { mutableStateOf(false) }
    var isPlaying by remember { mutableStateOf(false) }
    var currentPosMs by remember { mutableLongStateOf(0L) }
    var durationMs by remember { mutableLongStateOf(0L) }
    var isLooping by remember { mutableStateOf(false) }
    var speed by remember { mutableFloatStateOf(1.0f) }

    // Advanced audio player states
    var isMuted by remember { mutableStateOf(false) }
    var sleepTimerMinutes by remember { mutableIntStateOf(0) }
    var sleepSecondsRemaining by remember { mutableIntStateOf(0) }
    var showSleepTimerDialog by remember { mutableStateOf(false) }
    var soundPreset by remember { mutableStateOf("Normal") }
    var toastMessage by remember { mutableStateOf<String?>(null) }

    val mediaUri = remember(media.localPath, media.id) {
        if (media.id.startsWith("device_audio_")) {
            val audioId = media.id.substringAfter("device_audio_").toLongOrNull() ?: 0L
            android.content.ContentUris.withAppendedId(
                android.provider.MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                audioId
            )
        } else if (media.id.startsWith("device_video_")) {
            val videoId = media.id.substringAfter("device_video_").toLongOrNull() ?: 0L
            android.content.ContentUris.withAppendedId(
                android.provider.MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                videoId
            )
        } else if (media.localPath.startsWith("http://") || media.localPath.startsWith("https://")) {
            android.net.Uri.parse(media.localPath)
        } else {
            val file = java.io.File(media.localPath)
            if (file.exists()) {
                android.net.Uri.fromFile(file)
            } else {
                android.net.Uri.parse(media.localPath)
            }
        }
    }

    val streamHeaders = remember(media.localPath) {
        val map = HashMap<String, String>()
        if (media.localPath.contains("googlevideo") || media.localPath.contains("youtube")) {
            map["User-Agent"] = "Mozilla/5.0 (Linux; Android 11; Pixel 5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Mobile Safari/537.36"
            map["Referer"] = "https://www.youtube.com/"
        } else if (media.localPath.contains("instagram")) {
            map["User-Agent"] = "Mozilla/5.0 (iPhone; CPU iPhone OS 16_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1"
            map["Referer"] = "https://www.instagram.com/"
        } else if (media.localPath.contains("tiktok")) {
            map["User-Agent"] = "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
            map["Referer"] = "https://www.tiktok.com/"
        } else {
            map["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
            map["Referer"] = "https://www.google.com/"
        }
        map["Accept"] = "*/*"
        map
    }

    DisposableEffect(mediaUri) {
        if (com.example.media.BackgroundPlaybackManager.isBackgroundActive.value) {
            com.example.media.BackgroundPlaybackManager.stop(context)
        }
        try {
            mediaPlayer.reset()
            if (media.localPath.startsWith("http://") || media.localPath.startsWith("https://")) {
                mediaPlayer.setDataSource(context, mediaUri, streamHeaders)
            } else {
                val file = java.io.File(media.localPath)
                if (file.exists()) {
                    mediaPlayer.setDataSource(file.absolutePath)
                } else {
                    mediaPlayer.setDataSource(context, mediaUri)
                }
            }
            mediaPlayer.prepareAsync()
            mediaPlayer.setOnPreparedListener { mp ->
                isPrepared = true
                durationMs = mp.duration.toLong().coerceAtLeast(0L)
                mp.start()
                isPlaying = true
            }
            mediaPlayer.setOnCompletionListener {
                if (!isLooping) {
                    isPlaying = false
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        onDispose {
            try {
                if (mediaPlayer.isPlaying) mediaPlayer.stop()
                mediaPlayer.release()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    LaunchedEffect(isPlaying, isPrepared) {
        while (isPlaying && isPrepared) {
            try {
                currentPosMs = mediaPlayer.currentPosition.toLong()
            } catch (e: Exception) {}
            kotlinx.coroutines.delay(200)
        }
    }

    // Sound mute control
    LaunchedEffect(isMuted) {
        try {
            if (isMuted) {
                mediaPlayer.setVolume(0f, 0f)
            } else {
                mediaPlayer.setVolume(1f, 1f)
            }
        } catch (e: Exception) {}
    }

    val lifecycleOwner = androidx.lifecycle.compose.LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner, mediaPlayer) {
        val observer = androidx.lifecycle.LifecycleEventObserver { _, event ->
            val activity = context as? android.app.Activity
            val isActivityValid = activity == null || (!activity.isFinishing && !activity.isDestroyed)

            when (event) {
                androidx.lifecycle.Lifecycle.Event.ON_PAUSE,
                androidx.lifecycle.Lifecycle.Event.ON_STOP -> {
                    val bgAllowed = viewModel?.youtubeBackgroundPlayEnabled?.value ?: true
                    val isAppLeaving = activity != null && !activity.isChangingConfigurations
                    if (bgAllowed && isAppLeaving && isPlaying) {
                        val currentPos = try { mediaPlayer.currentPosition.toLong().coerceAtLeast(0L) } catch (e: Exception) { 0L }
                        viewModel?.startBackgroundPlayback(media, currentPos, speed) ?: run {
                            com.example.media.BackgroundPlaybackManager.startBackgroundPlayback(context, media, currentPos, speed)
                        }
                        try {
                            if (mediaPlayer.isPlaying) mediaPlayer.pause()
                        } catch (e: Exception) {}
                    }
                }
                androidx.lifecycle.Lifecycle.Event.ON_RESUME -> {
                    if (isActivityValid) {
                        if (com.example.media.BackgroundPlaybackManager.isBackgroundActive.value) {
                            if (com.example.media.BackgroundPlaybackManager.currentMedia.value?.id == media.id) {
                                val bgPos = com.example.media.BackgroundPlaybackManager.currentPositionMs.value
                                val bgPlaying = com.example.media.BackgroundPlaybackManager.isPlaying.value
                                com.example.media.BackgroundPlaybackManager.stop(context)
                                if (bgPos > 0L) {
                                    try { mediaPlayer.seekTo(bgPos.toInt()) } catch (e: Exception) {}
                                }
                                if (bgPlaying && isPrepared) {
                                    try { mediaPlayer.start(); isPlaying = true } catch (e: Exception) {}
                                }
                            } else {
                                com.example.media.BackgroundPlaybackManager.stop(context)
                            }
                        }
                    }
                }
                else -> {}
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    // Sleep Timer background countdown with smooth volume attenuation (fade-out)
    LaunchedEffect(sleepTimerMinutes, isPlaying, isMuted) {
        if (sleepTimerMinutes > 0) {
            if (sleepSecondsRemaining <= 0) {
                sleepSecondsRemaining = sleepTimerMinutes * 60
            }
            val fadeDurationSecs = 30
            while (sleepSecondsRemaining > 0 && isPlaying) {
                kotlinx.coroutines.delay(1000)
                sleepSecondsRemaining--

                if (!isMuted) {
                    if (sleepSecondsRemaining <= fadeDurationSecs) {
                        val fadeFactor = (sleepSecondsRemaining.toFloat() / fadeDurationSecs).coerceIn(0f, 1f)
                        mediaPlayer.setVolume(fadeFactor, fadeFactor)
                    } else {
                        mediaPlayer.setVolume(1.0f, 1.0f)
                    }
                }
            }
            if (sleepSecondsRemaining <= 0 && isPlaying) {
                isPlaying = false
                if (mediaPlayer.isPlaying) {
                    mediaPlayer.pause()
                }
                sleepTimerMinutes = 0
                if (!isMuted) {
                    mediaPlayer.setVolume(1.0f, 1.0f)
                }
                toastMessage = "Sleep Timer Expired (Fade Out Complete)"
            }
        } else {
            sleepSecondsRemaining = 0
            if (!isMuted) {
                mediaPlayer.setVolume(1.0f, 1.0f)
            }
        }
    }

    LaunchedEffect(sleepTimerMinutes) {
        if (sleepTimerMinutes > 0) {
            toastMessage = "Sleep Timer: ${sleepTimerMinutes}m"
        } else if (sleepTimerMinutes == 0 && sleepSecondsRemaining == 0 && isPrepared) {
            toastMessage = "Sleep Timer Off"
        }
    }

    LaunchedEffect(soundPreset) {
        if (soundPreset != "Normal") {
            toastMessage = "Preset: $soundPreset"
        }
    }

    LaunchedEffect(toastMessage) {
        if (toastMessage != null) {
            kotlinx.coroutines.delay(1500)
            toastMessage = null
        }
    }

    var offsetX by remember { mutableStateOf(0f) }
    var offsetY by remember { mutableStateOf(0f) }

    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = if (isFullscreen) Alignment.Center else Alignment.BottomEnd
    ) {
        if (isFullscreen) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.95f))
            )
        }

        Card(
            modifier = if (isFullscreen) {
                Modifier.fillMaxSize()
            } else {
                Modifier
                    .offset { IntOffset(offsetX.roundToInt(), offsetY.roundToInt()) }
                    .padding(16.dp)
                    .width(320.dp)
                    .height(200.dp)
                    .pointerInput(Unit) {
                        detectDragGestures { change, dragAmount ->
                            change.consume()
                            offsetX += dragAmount.x
                            offsetY += dragAmount.y
                        }
                    }
                    .clip(RoundedCornerShape(20.dp))
                    .border(1.dp, SleekPurpleDark.copy(alpha = 0.5f), RoundedCornerShape(20.dp))
                    .shadow(20.dp, RoundedCornerShape(20.dp))
            },
            colors = CardDefaults.cardColors(containerColor = SleekCardDark),
            shape = if (isFullscreen) RoundedCornerShape(0.dp) else RoundedCornerShape(20.dp)
        ) {
            Box(modifier = Modifier.fillMaxSize()) {
                if (!isPrepared) {
                    SkeletonAudioPlayerOverlay(
                        isFullscreen = isFullscreen,
                        modifier = Modifier.fillMaxSize()
                    )
                } else if (!isFullscreen) {
                    // Mini Floating Audio Player
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(12.dp),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    // Top header
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = Icons.Default.MusicNote,
                                contentDescription = "Music",
                                tint = SleekPurpleLight,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = media.title.removePrefix("[Streaming Audio] ").trim(),
                                style = MaterialTheme.typography.bodySmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = SleekTextPrimary
                                ),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = onToggleFullscreen, modifier = Modifier.size(28.dp)) {
                                Icon(Icons.Default.Fullscreen, contentDescription = "Expand", tint = SleekTextPrimary, modifier = Modifier.size(18.dp))
                            }
                            IconButton(onClick = onClose, modifier = Modifier.size(28.dp)) {
                                Icon(Icons.Default.Close, contentDescription = "Close", tint = CrimsonFailure, modifier = Modifier.size(18.dp))
                            }
                        }
                    }

                    // Content row
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Artwork or vinyl
                        val infiniteTransition = rememberInfiniteTransition(label = "mini_disc")
                        val discAngle by infiniteTransition.animateFloat(
                            initialValue = 0f,
                            targetValue = 360f,
                            animationSpec = infiniteRepeatable(
                                animation = tween(6000, easing = LinearEasing)
                            ), label = "disc_angle"
                        )

                        Box(
                            modifier = Modifier
                                .size(56.dp)
                                .clip(CircleShape)
                                .background(SleekBg)
                                .border(2.dp, SleekPurpleLight, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            if (media.thumbnailUrl.isNotBlank()) {
                                coil.compose.AsyncImage(
                                    model = media.thumbnailUrl,
                                    contentDescription = "Cover",
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .clip(CircleShape)
                                        .rotate(if (isPlaying) discAngle else 0f)
                                )
                            } else {
                                Icon(
                                    imageVector = Icons.Default.MusicNote,
                                    contentDescription = null,
                                    tint = SleekPurpleLight,
                                    modifier = Modifier
                                        .size(28.dp)
                                        .rotate(if (isPlaying) discAngle else 0f)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (media.author.isNotBlank()) media.author else "Audio Track",
                                style = MaterialTheme.typography.labelSmall,
                                color = SleekTextSecondary,
                                maxLines = 1
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            // Visualizer bars
                            AudioEqualizerVisualizer(
                                isPlaying = isPlaying,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(24.dp)
                            )
                        }
                    }

                    // Seekbar & Controls
                    Column(modifier = Modifier.fillMaxWidth()) {
                        val progress = if (durationMs > 0) (currentPosMs.toFloat() / durationMs.toFloat()).coerceIn(0f, 1f) else 0f
                        LinearProgressIndicator(
                            progress = { progress },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(4.dp)
                                .clip(RoundedCornerShape(2.dp)),
                            color = SleekPurpleLight,
                            trackColor = SleekBorderColor
                        )

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "${formatTimeMs(currentPosMs)} / ${formatTimeMs(durationMs)}",
                                style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                                color = SleekTextMuted
                            )

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                IconButton(
                                    onClick = {
                                        val target = (currentPosMs - 10000L).coerceAtLeast(0L)
                                        mediaPlayer.seekTo(target.toInt())
                                        currentPosMs = target
                                    },
                                    modifier = Modifier.size(28.dp)
                                ) {
                                    Icon(Icons.Default.FastRewind, contentDescription = "-10s", tint = SleekTextPrimary, modifier = Modifier.size(16.dp))
                                }

                                IconButton(
                                    onClick = {
                                        if (isPlaying) {
                                            mediaPlayer.pause()
                                            isPlaying = false
                                        } else {
                                            mediaPlayer.start()
                                            isPlaying = true
                                        }
                                    },
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(
                                        imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                        contentDescription = "Play/Pause",
                                        tint = SleekPurpleLight,
                                        modifier = Modifier.size(24.dp)
                                    )
                                }

                                IconButton(
                                    onClick = {
                                        val target = (currentPosMs + 10000L).coerceAtMost(durationMs)
                                        mediaPlayer.seekTo(target.toInt())
                                        currentPosMs = target
                                    },
                                    modifier = Modifier.size(28.dp)
                                ) {
                                    Icon(Icons.Default.FastForward, contentDescription = "+10s", tint = SleekTextPrimary, modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }
                }
            } else {
                // Full Screen Music Player Screen
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(
                                    SleekBg,
                                    SleekCardDark,
                                    Color.Black
                                )
                            )
                        )
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    // Floating Header Bar
                    Surface(
                        modifier = Modifier
                            .statusBarsPadding()
                            .fillMaxWidth()
                            .shadow(
                                elevation = 12.dp,
                                shape = RoundedCornerShape(24.dp),
                                clip = false,
                                ambientColor = SleekPurpleLight.copy(alpha = 0.2f),
                                spotColor = SleekPurpleLight.copy(alpha = 0.4f)
                            ),
                        shape = RoundedCornerShape(24.dp),
                        color = Color(0xCC121218), // Deep glassmorphic background
                        border = BorderStroke(1.dp, SleekBorderColor.copy(alpha = 0.3f))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(onClick = onToggleFullscreen) {
                                Icon(Icons.Default.KeyboardArrowDown, contentDescription = "Minimize", tint = SleekTextPrimary, modifier = Modifier.size(32.dp))
                            }

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.MusicNote, contentDescription = null, tint = SleekPurpleLight, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "MUSIC PLAYER",
                                    style = MaterialTheme.typography.labelLarge.copy(
                                        fontWeight = FontWeight.ExtraBold,
                                        letterSpacing = 1.2.sp,
                                        color = SleekPurpleLight
                                    )
                                )
                            }

                            IconButton(onClick = onClose) {
                                Icon(Icons.Default.Close, contentDescription = "Close", tint = CrimsonFailure, modifier = Modifier.size(28.dp))
                            }
                        }
                    }

                    // Large Album Artwork Center with Art Canvas Gradient
                    val infiniteTransition = rememberInfiniteTransition(label = "full_disc")
                    val fullDiscAngle by infiniteTransition.animateFloat(
                        initialValue = 0f,
                        targetValue = 360f,
                        animationSpec = infiniteRepeatable(
                            animation = tween(12000, easing = LinearEasing)
                        ), label = "disc_angle"
                    )
                    var isCanvasArtMode by remember { mutableStateOf(false) }

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        // Sleep countdown badge & Notification Active Pill above disc
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.padding(bottom = 12.dp)
                        ) {
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = SleekPurpleDark.copy(alpha = 0.85f),
                                border = BorderStroke(1.dp, SleekPurpleLight.copy(alpha = 0.5f))
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(6.dp)
                                            .background(if (isPlaying) Color(0xFF10B981) else Color(0xFFF59E0B), CircleShape)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "NOTIFICATION ACTIVE",
                                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, fontSize = 9.sp),
                                        color = Color.White
                                    )
                                }
                            }

                            if (sleepSecondsRemaining > 0) {
                                val min = sleepSecondsRemaining / 60
                                val sec = sleepSecondsRemaining % 60
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = SleekPurpleDark.copy(alpha = 0.85f),
                                    border = BorderStroke(1.dp, SleekPurpleLight.copy(alpha = 0.5f))
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Timer,
                                            contentDescription = "Sleep Timer",
                                            tint = Color.White,
                                            modifier = Modifier.size(12.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = String.format("%02d:%02d", min, sec),
                                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, fontSize = 10.sp),
                                            color = Color.White
                                        )
                                    }
                                }
                            }

                            // Art Canvas Mode Toggle
                            IconButton(
                                onClick = { isCanvasArtMode = !isCanvasArtMode },
                                modifier = Modifier.size(28.dp)
                            ) {
                                Icon(
                                    imageVector = if (isCanvasArtMode) Icons.Default.Album else Icons.Default.CropOriginal,
                                    contentDescription = "Art Mode",
                                    tint = SleekPurpleLight,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }

                        // Ambient Gradient Glow Canvas Container
                        Box(
                            modifier = Modifier
                                .size(240.dp)
                                .shadow(28.dp, if (isCanvasArtMode) RoundedCornerShape(24.dp) else CircleShape, spotColor = SleekPurpleLight)
                                .clip(if (isCanvasArtMode) RoundedCornerShape(24.dp) else CircleShape)
                                .background(
                                    Brush.radialGradient(
                                        colors = listOf(
                                            Color(0xFF9333EA),
                                            Color(0xFF3B82F6),
                                            Color(0xFF0F0C20)
                                        )
                                    )
                                )
                                .border(3.dp, SleekPurpleLight, if (isCanvasArtMode) RoundedCornerShape(24.dp) else CircleShape)
                                .clickable { isCanvasArtMode = !isCanvasArtMode },
                            contentAlignment = Alignment.Center
                        ) {
                            if (media.thumbnailUrl.isNotBlank()) {
                                coil.compose.AsyncImage(
                                    model = media.thumbnailUrl,
                                    contentDescription = "Album Art Preview",
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .clip(if (isCanvasArtMode) RoundedCornerShape(24.dp) else CircleShape)
                                        .rotate(if (isPlaying && !isCanvasArtMode) fullDiscAngle else 0f)
                                )
                            } else {
                                Icon(
                                    imageVector = Icons.Default.MusicNote,
                                    contentDescription = null,
                                    tint = SleekPurpleLight,
                                    modifier = Modifier
                                        .size(96.dp)
                                        .rotate(if (isPlaying && !isCanvasArtMode) fullDiscAngle else 0f)
                                )
                            }
                            if (!isCanvasArtMode) {
                                // Center vinyl hole detail
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(CircleShape)
                                        .background(Color.Black)
                                        .border(2.dp, SleekBorderColor, CircleShape)
                                )
                            }
                        }
                    }

                    // Title & Artist section
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = media.title.removePrefix("[Streaming Audio] ").trim(),
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Bold,
                                color = SleekTextPrimary
                            ),
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (media.author.isNotBlank()) media.author else "Audio Stream",
                            style = MaterialTheme.typography.bodyMedium,
                            color = SleekTextSecondary,
                            textAlign = TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        // Equalizer Visualizer
                        AudioEqualizerVisualizer(
                            isPlaying = isPlaying,
                            modifier = Modifier
                                .width(200.dp)
                                .height(32.dp)
                        )
                    }

                    // Transient Toast overlay above slider
                    toastMessage?.let { msg ->
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = Color.Black.copy(alpha = 0.8f),
                            border = BorderStroke(1.dp, SleekBorderColor)
                        ) {
                            Text(
                                text = msg,
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                color = Color.White,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }
                    }

                    // Progress SineWaveSeekBar
                    Column(modifier = Modifier.fillMaxWidth()) {
                        SineWaveSeekBar(
                            currentPosMs = currentPosMs,
                            durationMs = durationMs,
                            waveformData = currentWaveformData,
                            onSeekTo = { targetMs ->
                                currentPosMs = targetMs
                                mediaPlayer.seekTo(targetMs.toInt())
                            },
                            modifier = Modifier.fillMaxWidth()
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(formatTimeMs(currentPosMs), style = MaterialTheme.typography.labelMedium, color = SleekTextSecondary)
                            Text(formatTimeMs(durationMs), style = MaterialTheme.typography.labelMedium, color = SleekTextSecondary)
                        }
                    }

                    // Floating double-tier Controls Bar Container
                    Surface(
                        modifier = Modifier
                            .navigationBarsPadding()
                            .fillMaxWidth()
                            .shadow(
                                elevation = 12.dp,
                                shape = RoundedCornerShape(28.dp),
                                clip = false,
                                ambientColor = SleekPurpleLight.copy(alpha = 0.2f),
                                spotColor = SleekPurpleLight.copy(alpha = 0.4f)
                            ),
                        shape = RoundedCornerShape(28.dp),
                        color = Color(0xCC121218), // Deep glassmorphic background
                        border = BorderStroke(1.dp, SleekBorderColor.copy(alpha = 0.3f))
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 16.dp),
                            verticalArrangement = Arrangement.spacedBy(14.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            // Tier 1: Utility Controls (Loop, Speed, Sound Preset, Sleep Timer, Mute)
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceEvenly,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                // Repeat toggle
                                IconButton(
                                    onClick = {
                                        isLooping = !isLooping
                                        mediaPlayer.isLooping = isLooping
                                    }
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Repeat,
                                        contentDescription = "Loop",
                                        tint = if (isLooping) SleekPurpleLight else SleekTextMuted,
                                        modifier = Modifier.size(22.dp)
                                    )
                                }

                                // Speed Selector
                                Surface(
                                    onClick = {
                                        speed = when (speed) {
                                            1.0f -> 1.25f
                                            1.25f -> 1.5f
                                            1.5f -> 2.0f
                                            else -> 1.0f
                                        }
                                        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M && isPrepared) {
                                            try {
                                                mediaPlayer.playbackParams = mediaPlayer.playbackParams.setSpeed(speed)
                                            } catch (e: Exception) {}
                                        }
                                    },
                                    shape = RoundedCornerShape(8.dp),
                                    color = SleekCardDark,
                                    border = BorderStroke(1.dp, SleekBorderColor)
                                ) {
                                    Text(
                                        text = "${speed}x",
                                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, fontSize = 10.sp),
                                        color = SleekPurpleLight,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                                    )
                                }

                                // Sound Preset Selection
                                IconButton(
                                    onClick = {
                                        soundPreset = when (soundPreset) {
                                            "Normal" -> "Bass Boost"
                                            "Bass Boost" -> "Pop"
                                            "Pop" -> "Vocal"
                                            else -> "Normal"
                                        }
                                    }
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Tune,
                                        contentDescription = "Sound Presets",
                                        tint = if (soundPreset == "Normal") SleekTextMuted else SleekPurpleLight,
                                        modifier = Modifier.size(22.dp)
                                    )
                                }

                                // Sleep Timer Button
                                IconButton(
                                    onClick = {
                                        showSleepTimerDialog = true
                                    }
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Timer,
                                        contentDescription = "Sleep Timer Selection",
                                        tint = if (sleepSecondsRemaining > 0) SleekPurpleLight else SleekTextMuted,
                                        modifier = Modifier.size(22.dp)
                                    )
                                }

                                // Mute/Volume
                                IconButton(
                                    onClick = {
                                        isMuted = !isMuted
                                    }
                                ) {
                                    Icon(
                                        imageVector = if (isMuted) Icons.Default.VolumeOff else Icons.Default.VolumeUp,
                                        contentDescription = "Mute Toggle",
                                        tint = if (isMuted) CrimsonFailure else SleekPurpleLight,
                                        modifier = Modifier.size(22.dp)
                                    )
                                }
                            }

                            // Tier 2: Core Playback Buttons
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.Center,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                // Skip -10s
                                IconButton(
                                    onClick = {
                                        val target = (currentPosMs - 10000L).coerceAtLeast(0L)
                                        mediaPlayer.seekTo(target.toInt())
                                        currentPosMs = target
                                    },
                                    modifier = Modifier.size(48.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.FastRewind,
                                        contentDescription = "Rewind 10s",
                                        tint = SleekTextPrimary,
                                        modifier = Modifier.size(28.dp)
                                    )
                                }

                                Spacer(modifier = Modifier.width(24.dp))

                                // Play/Pause Big Center Pill
                                Surface(
                                    onClick = {
                                        if (isPlaying) {
                                            mediaPlayer.pause()
                                            isPlaying = false
                                        } else {
                                            mediaPlayer.start()
                                            isPlaying = true
                                        }
                                    },
                                    shape = CircleShape,
                                    color = SleekPurpleLight,
                                    shadowElevation = 8.dp,
                                    modifier = Modifier.size(64.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
                                        Icon(
                                            imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                            contentDescription = "Play/Pause",
                                            tint = Color.White,
                                            modifier = Modifier.size(36.dp)
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.width(24.dp))

                                // Skip +10s
                                IconButton(
                                    onClick = {
                                        val target = (currentPosMs + 10000L).coerceAtMost(durationMs)
                                        mediaPlayer.seekTo(target.toInt())
                                        currentPosMs = target
                                    },
                                    modifier = Modifier.size(48.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.FastForward,
                                        contentDescription = "Forward 10s",
                                        tint = SleekTextPrimary,
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showSleepTimerDialog) {
        SleepTimerDialog(
            currentMinutes = sleepTimerMinutes,
            currentSecondsRemaining = sleepSecondsRemaining,
            onSelectMinutes = { mins ->
                sleepTimerMinutes = mins
                sleepSecondsRemaining = mins * 60
                toastMessage = if (mins > 0) "Sleep Timer: ${mins}m with Fade-Out" else "Sleep Timer Off"
            },
            onDismiss = { showSleepTimerDialog = false }
        )
    }
}
}

data class PlayerAudioTrack(
    val group: androidx.media3.common.Tracks.Group,
    val trackIndex: Int,
    val name: String,
    val language: String,
    val isSelected: Boolean,
    val isSupported: Boolean
)

data class PlayerSubtitleTrack(
    val group: androidx.media3.common.Tracks.Group,
    val trackIndex: Int,
    val name: String,
    val language: String,
    val isSelected: Boolean
)

data class PlaybackCodecInfo(
    val container: String = "MKV / MP4 / Stream",
    val videoMime: String = "N/A",
    val videoDecoder: String = "MediaCodec HW",
    val videoResolution: String = "N/A",
    val videoFps: String = "N/A",
    val videoBitrate: String = "N/A",
    val isVideoHw: Boolean = true,
    val audioMime: String = "N/A",
    val audioDecoder: String = "MediaCodec HW",
    val audioChannels: String = "N/A",
    val audioSampleRate: String = "N/A",
    val audioBitrate: String = "N/A",
    val isAudioHw: Boolean = true,
    val engineMode: String = "Auto (HW + SW)",
    val audioOutputMode: String = "Auto (PCM/Passthrough)"
)

enum class MiniPlayerState {
    IDLE,
    DRAGGING,
    PINCHING,
    SNAPPING
}

@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
fun SleekVideoPlayerOverlay(
    media: DownloadEntity,
    isFullscreen: Boolean,
    onToggleFullscreen: () -> Unit,
    onClose: () -> Unit,
    analyzedVideo: AnalyzedVideo? = null,
    onStreamFormat: ((VideoFormatUi) -> Unit)? = null,
    viewModel: VideoDownloaderViewModel? = null,
    onOpenAudioFxStudio: (() -> Unit)? = null
) {
    val context = LocalContext.current
    var topBarOffsetHeightPx by remember { mutableFloatStateOf(0f) }
    val topBarHeightPx = with(androidx.compose.ui.platform.LocalDensity.current) { 100.dp.toPx() }
    val nestedScrollConnection = remember {
        object : androidx.compose.ui.input.nestedscroll.NestedScrollConnection {
            override fun onPreScroll(available: androidx.compose.ui.geometry.Offset, source: androidx.compose.ui.input.nestedscroll.NestedScrollSource): androidx.compose.ui.geometry.Offset {
                val delta = available.y
                val newOffset = topBarOffsetHeightPx + delta
                topBarOffsetHeightPx = newOffset.coerceIn(-topBarHeightPx, 0f)
                return androidx.compose.ui.geometry.Offset.Zero
            }
        }
    }
    val scope = rememberCoroutineScope()
    var isPaused by remember(media.id, media.localPath) { mutableStateOf(false) }
    var mediaVideoWidth by remember(media.id, media.localPath) { mutableIntStateOf(0) }
    var mediaVideoHeight by remember(media.id, media.localPath) { mutableIntStateOf(0) }

    LaunchedEffect(media.id, media.localPath) {
        mediaVideoWidth = 0
        mediaVideoHeight = 0
        val videoPath = media.localPath.substringBefore("|STREAM_AUDIO_URL|")
        if (!videoPath.startsWith("http://") && !videoPath.startsWith("https://") && videoPath.isNotBlank()) {
            try {
                val retriever = android.media.MediaMetadataRetriever()
                retriever.setDataSource(videoPath)
                val wStr = retriever.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)
                val hStr = retriever.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)
                val rotStr = retriever.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)
                retriever.release()
                val w = wStr?.toIntOrNull() ?: 0
                val h = hStr?.toIntOrNull() ?: 0
                val rot = rotStr?.toIntOrNull() ?: 0
                if (w > 0 && h > 0) {
                    if (rot == 90 || rot == 270) {
                        mediaVideoWidth = h
                        mediaVideoHeight = w
                    } else {
                        mediaVideoWidth = w
                        mediaVideoHeight = h
                    }
                }
            } catch (_: Exception) {}
        }
    }
    var hasRenderedFirstFrame by remember(media.id, media.localPath) { mutableStateOf(false) }
    var isBufferLoading by remember(media.id, media.localPath) { mutableStateOf(true) }
    var playerError by remember(media.id, media.localPath) { mutableStateOf<String?>(null) }
    var lastPlaybackReport by remember(media.id, media.localPath) { mutableStateOf<com.example.media.playback.PlaybackAnalysisReport?>(null) }
    var probeInfo by remember(media.id, media.localPath) { mutableStateOf<com.example.media.probe.MediaProbeInfo?>(null) }
    var showExternalPlayerAlert by remember(media.id, media.localPath) { mutableStateOf(false) }
    var isFallbackAnalysisInProgress by remember(media.id, media.localPath) { mutableStateOf(false) }
    var fallbackCompatibilityPlan by remember(media.id, media.localPath) { mutableStateOf<com.example.media.playback.PlaybackCompatibilityResult?>(null) }
    var fallbackProcessingProgress by remember(media.id, media.localPath) { mutableStateOf<com.example.media.ffmpeg.FFmpegProgress?>(null) }
    var isFallbackProcessingActive by remember(media.id, media.localPath) { mutableStateOf(false) }
    var activeFallbackJob by remember(media.id, media.localPath) { mutableStateOf<kotlinx.coroutines.Job?>(null) }
    var cachedFallbackPath by remember(media.id, media.localPath) { mutableStateOf<String?>(null) }
    var fallbackFailureReport by remember(media.id, media.localPath) { mutableStateOf<String?>(null) }


    val showPipControlsOnPlayer = viewModel?.showPipControlsOnPlayer?.collectAsStateWithLifecycle()?.value ?: true
    val isCustomPipMini = viewModel?.isCustomPipMini?.collectAsStateWithLifecycle()?.value ?: false
    val currentWaveformData = viewModel?.currentWaveformData?.collectAsStateWithLifecycle()?.value

    val activity = context as? android.app.Activity
    DisposableEffect(isFullscreen) {
        if (isFullscreen) {
            activity?.requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        } else {
            activity?.requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
        onDispose {
            activity?.requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
    }

    var offsetX by remember { mutableStateOf(0f) }
    var offsetY by remember { mutableStateOf(0f) }

    var showLeftIndicator by remember { mutableStateOf(false) }
    var showRightIndicator by remember { mutableStateOf(false) }
    var showQuickGuide by remember { mutableStateOf(false) }
    val overlayFocusRequester = remember { androidx.compose.ui.focus.FocusRequester() }

    LaunchedEffect(Unit) {
        try {
            overlayFocusRequester.requestFocus()
        } catch (e: Exception) {}
    }

    LaunchedEffect(showQuickGuide) {
        if (showQuickGuide) {
            delay(2500)
            showQuickGuide = false
        }
    }

    var isVolumeDrag by remember { mutableStateOf(false) }
    var isBrightnessDrag by remember { mutableStateOf(false) }
    var isSeekDrag by remember { mutableStateOf(false) }
    var initialVolume by remember { mutableIntStateOf(0) }
    var initialVolumeBoost by remember { mutableFloatStateOf(0f) }
    var initialBrightness by remember { mutableFloatStateOf(-1f) }
    var initialSeekPos by remember { mutableLongStateOf(0L) }
    var totalDragY by remember { mutableFloatStateOf(0f) }
    var totalDragX by remember { mutableFloatStateOf(0f) }
    var swipeDirectionResolved by remember { mutableStateOf(false) }
    var isVerticalSwipe by remember { mutableStateOf(false) }
    var isHorizontalSwipe by remember { mutableStateOf(false) }
    val audioManager = remember { context.getSystemService(android.content.Context.AUDIO_SERVICE) as android.media.AudioManager }
    val maxVolume = remember { audioManager.getStreamMaxVolume(android.media.AudioManager.STREAM_MUSIC) }

    LaunchedEffect(showLeftIndicator) {
        if (showLeftIndicator) {
            delay(650)
            showLeftIndicator = false
        }
    }
    LaunchedEffect(showRightIndicator) {
        if (showRightIndicator) {
            delay(650)
            showRightIndicator = false
        }
    }

    var miniPlayerState by remember { mutableStateOf(MiniPlayerState.IDLE) }
    var isDragging by remember { mutableStateOf(false) }
    var isPinching by remember { mutableStateOf(false) }
    var userMiniScale by remember { mutableFloatStateOf(1.00f) }

    LaunchedEffect(miniPlayerState) {
        isDragging = (miniPlayerState == MiniPlayerState.DRAGGING)
        isPinching = (miniPlayerState == MiniPlayerState.PINCHING)
        if (miniPlayerState == MiniPlayerState.SNAPPING) {
            kotlinx.coroutines.delay(300)
            miniPlayerState = MiniPlayerState.IDLE
        }
    }

    val isMiniMode = (!isFullscreen || isCustomPipMini)
    val isGestureActive = miniPlayerState == MiniPlayerState.DRAGGING || miniPlayerState == MiniPlayerState.PINCHING

    val animOffsetX by animateFloatAsState(
        targetValue = if (isMiniMode) offsetX else 0f,
        animationSpec = if (isGestureActive) snap() else spring(dampingRatio = Spring.DampingRatioLowBouncy, stiffness = Spring.StiffnessMediumLow),
        label = "animOffsetX"
    )
    val animOffsetY by animateFloatAsState(
        targetValue = if (isMiniMode) offsetY else 0f,
        animationSpec = if (isGestureActive) snap() else spring(dampingRatio = Spring.DampingRatioLowBouncy, stiffness = Spring.StiffnessMediumLow),
        label = "animOffsetY"
    )

    val swipeProgress = if (isFullscreen && !isCustomPipMini && isDragging && offsetY > 0f) {
        (offsetY / 200f).coerceIn(0f, 1f)
    } else {
        0f
    }

    val playerScale by animateFloatAsState(
        targetValue = when {
            isMiniMode && isGestureActive -> 1.05f
            isFullscreen && !isCustomPipMini && isDragging && offsetY > 0f -> (1f - (swipeProgress * 0.18f)).coerceIn(0.78f, 1f)
            else -> 1f
        },
        animationSpec = if (isGestureActive) snap() else spring(dampingRatio = Spring.DampingRatioNoBouncy, stiffness = Spring.StiffnessMediumLow),
        label = "playerScale"
    )

    val backdropAlpha by animateFloatAsState(
        targetValue = if (isFullscreen && !isCustomPipMini) {
            if (isDragging && offsetY > 0f) (1f - swipeProgress * 0.85f).coerceIn(0f, 1f) else 1f
        } else {
            0f
        },
        animationSpec = if (isDragging) snap() else tween(durationMillis = 280, easing = FastOutSlowInEasing),
        label = "backdropAlpha"
    )

    val density = androidx.compose.ui.platform.LocalDensity.current
    val configuration = androidx.compose.ui.platform.LocalConfiguration.current
    val isMobile = configuration.screenWidthDp < 600

    val currentMiniScale = if (isMiniMode) userMiniScale else 1.00f

    val defaultMiniWidthDp = if (isMobile) 180.dp else 220.dp
    val defaultMiniHeightDp = if (isMobile) 102.dp else 124.dp
    val defaultAspectRatio = defaultMiniWidthDp.value / defaultMiniHeightDp.value

    val aspectRatio = if (mediaVideoWidth > 0 && mediaVideoHeight > 0) {
        mediaVideoWidth.toFloat() / mediaVideoHeight.toFloat()
    } else {
        defaultAspectRatio
    }

    val maxMiniWidthDp = configuration.screenWidthDp.dp * 0.75f
    val maxMiniHeightDp = configuration.screenHeightDp.dp * 0.75f

    val (baseWidthDp, baseHeightDp) = if (isFullscreen && !isCustomPipMini) {
        Pair(configuration.screenWidthDp.dp, configuration.screenHeightDp.dp)
    } else {
        var calcWidth = defaultMiniWidthDp
        var calcHeight = calcWidth / aspectRatio

        if (calcHeight > maxMiniHeightDp) {
            calcHeight = maxMiniHeightDp
            calcWidth = calcHeight * aspectRatio
        }
        if (calcWidth > maxMiniWidthDp) {
            calcWidth = maxMiniWidthDp
            calcHeight = calcWidth / aspectRatio
        }

        Pair(calcWidth, calcHeight)
    }

    val widthDp by animateDpAsState(
        targetValue = baseWidthDp * currentMiniScale,
        animationSpec = if (isGestureActive) snap() else spring(dampingRatio = Spring.DampingRatioNoBouncy, stiffness = Spring.StiffnessMediumLow),
        label = "playerWidth"
    )
    val heightDp by animateDpAsState(
        targetValue = baseHeightDp * currentMiniScale,
        animationSpec = if (isGestureActive) snap() else spring(dampingRatio = Spring.DampingRatioNoBouncy, stiffness = Spring.StiffnessMediumLow),
        label = "playerHeight"
    )
    val cornerRadius by animateDpAsState(
        targetValue = if (isFullscreen && !isCustomPipMini) {
            if (isDragging && offsetY > 0f) (swipeProgress * 16f).dp else 0.dp
        } else {
            16.dp
        },
        animationSpec = if (isGestureActive) snap() else spring(dampingRatio = Spring.DampingRatioNoBouncy, stiffness = Spring.StiffnessMediumLow),
        label = "playerCorner"
    )
    val shadowElevationDp by animateDpAsState(
        targetValue = when {
            isMiniMode && isGestureActive -> 24.dp
            isMiniMode -> 12.dp
            isFullscreen && cornerRadius < 1.dp -> 0.dp
            else -> 16.dp
        },
        animationSpec = if (isGestureActive) snap() else spring(dampingRatio = Spring.DampingRatioNoBouncy, stiffness = Spring.StiffnessMediumLow),
        label = "shadowElevation"
    )
    val paddingDp by animateDpAsState(
        targetValue = 0.dp,
        animationSpec = spring(dampingRatio = Spring.DampingRatioNoBouncy, stiffness = Spring.StiffnessMediumLow),
        label = "playerPadding"
    )

    val playerDecoderModeSetting by (viewModel?.playerDecoderMode?.collectAsStateWithLifecycle() ?: remember { mutableStateOf("Auto (HW + SW Fallback)") })
    val hardwareAccelerationSetting by (viewModel?.hardwareAcceleration?.collectAsStateWithLifecycle() ?: remember { mutableStateOf(true) })
    val audioOutputModeSetting by (viewModel?.audioOutputMode?.collectAsStateWithLifecycle() ?: remember { mutableStateOf("Auto (PCM/Passthrough)") })
    val hardwareAccelerationModeSetting by (viewModel?.hardwareAccelerationMode?.collectAsStateWithLifecycle() ?: remember { mutableStateOf("Auto") })
    val audioPassthroughModeSetting by (viewModel?.audioPassthroughMode?.collectAsStateWithLifecycle() ?: remember { mutableStateOf("Auto") })
    val autoDimEnabled by (viewModel?.autoDimScreenOnInactivity?.collectAsStateWithLifecycle() ?: remember { mutableStateOf(true) })
    val autoDimTimeoutSeconds by (viewModel?.autoDimInactivitySeconds?.collectAsStateWithLifecycle() ?: remember { mutableIntStateOf(30) })

    var isScreenAutoDimmed by remember { mutableStateOf(false) }
    var lastInteractionTime by remember { mutableLongStateOf(System.currentTimeMillis()) }
    val originalWindowBrightness = remember { (context as? android.app.Activity)?.window?.attributes?.screenBrightness ?: android.view.WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE }
    var userCustomBrightness by remember { mutableStateOf<Float?>(null) }

    fun applyWindowBrightness(targetBrightness: Float) {
        try {
            val window = (context as? android.app.Activity)?.window ?: return
            val lp = window.attributes
            lp.screenBrightness = targetBrightness
            window.attributes = lp
        } catch (_: Exception) {}
    }

    fun registerUserActivity() {
        lastInteractionTime = System.currentTimeMillis()
        if (isScreenAutoDimmed) {
            isScreenAutoDimmed = false
            if (isPaused) {
                applyWindowBrightness(originalWindowBrightness)
            } else {
                applyWindowBrightness(userCustomBrightness ?: originalWindowBrightness)
            }
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            try {
                val window = (context as? android.app.Activity)?.window
                if (window != null) {
                    val lp = window.attributes
                    lp.screenBrightness = originalWindowBrightness
                    window.attributes = lp
                }
            } catch (e: Exception) {}
        }
    }

    var isSoftwareFallbackActive by remember { mutableStateOf(false) }
    var showCodecSpecsDialog by remember { mutableStateOf(false) }
    var showAdvancedPlayerSettings by remember { mutableStateOf(false) }
    var playbackCodecInfo by remember {
        mutableStateOf(
            PlaybackCodecInfo(
                engineMode = playerDecoderModeSetting,
                audioOutputMode = audioOutputModeSetting
            )
        )
    }

    val orchestrator = remember(playerDecoderModeSetting) {
        com.example.media.orchestration.DecoderOrchestrator().apply {
            profile.videoDecoderMode = playerDecoderModeSetting
            profile.audioDecoderMode = playerDecoderModeSetting
        }
    }

    val vocalReductionProcessor = remember { com.example.media.audiofx.VocalReductionAudioProcessor() }

    val renderersFactory = remember(context, playerDecoderModeSetting, orchestrator) {
        object : androidx.media3.exoplayer.DefaultRenderersFactory(context) {
            override fun buildAudioSink(
                context: android.content.Context,
                enableFloatOutput: Boolean,
                enableAudioTrackPlaybackParams: Boolean
            ): androidx.media3.exoplayer.audio.AudioSink? {
                return androidx.media3.exoplayer.audio.DefaultAudioSink.Builder(context)
                    .setEnableFloatOutput(enableFloatOutput)
                    .setEnableAudioTrackPlaybackParams(enableAudioTrackPlaybackParams)
                    .setAudioProcessors(arrayOf(vocalReductionProcessor))
                    .build()
            }
        }.apply {
            setEnableDecoderFallback(true)
            setExtensionRendererMode(androidx.media3.exoplayer.DefaultRenderersFactory.EXTENSION_RENDERER_MODE_ON)
            setEnableAudioTrackPlaybackParams(true)
        }
    }

    val trackSelector = remember(context) {
        androidx.media3.exoplayer.trackselection.DefaultTrackSelector(context).apply {
            parameters = buildUponParameters()
                .setSelectUndeterminedTextLanguage(true)
                .build()
        }
    }

    var audioTracks by remember(media.id, media.localPath) { mutableStateOf<List<PlayerAudioTrack>>(emptyList()) }
    var subtitleTracks by remember(media.id, media.localPath) { mutableStateOf<List<PlayerSubtitleTrack>>(emptyList()) }
    var isAudioDisabled by remember { mutableStateOf(false) }
    var isSubtitleDisabled by remember { mutableStateOf(false) }
    var showAudioTrackMenu by remember { mutableStateOf(false) }
    var showSubtitleTrackMenu by remember { mutableStateOf(false) }
    var toastMessage by remember { mutableStateOf<String?>(null) }

    var externalSubtitleUri by remember(media.id, media.localPath) { mutableStateOf<String?>(null) }

    val subtitlePickerLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        contract = androidx.activity.result.contract.ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            externalSubtitleUri = uri.toString()
        }
    }

    val mediaEngine = remember(orchestrator) {
        com.example.media.DefaultMediaEngine(context, renderersFactory, trackSelector, orchestrator).apply {
            player.playWhenReady = true
            player.repeatMode = androidx.media3.common.Player.REPEAT_MODE_ONE
        }
    }
    
    val exoPlayer = mediaEngine.player as androidx.media3.exoplayer.ExoPlayer
    if (viewModel != null) {
        ExoPlayerAudioFxEngine(exoPlayer = exoPlayer, viewModel = viewModel)
    }

    LaunchedEffect(media.id, media.localPath, externalSubtitleUri) {
        val videoPath = media.localPath.substringBefore("|STREAM_AUDIO_URL|")
        val audioPath = if (media.localPath.contains("|STREAM_AUDIO_URL|")) media.localPath.substringAfter("|STREAM_AUDIO_URL|") else null
        
        hasRenderedFirstFrame = false
        isBufferLoading = true
        playerError = null
        showExternalPlayerAlert = false
        fallbackFailureReport = null
        
        val fallbackOutputFileName = "playable_fallback_${media.id.hashCode()}.mp4"
        val fallbackOutputFile = java.io.File(context.cacheDir, fallbackOutputFileName)
        if (fallbackOutputFile.exists() && fallbackOutputFile.length() > 0) {
            cachedFallbackPath = fallbackOutputFile.absolutePath
        } else {
            cachedFallbackPath = null
        }

        val bgActive = com.example.media.BackgroundPlaybackManager.isBackgroundActive.value
        val bgMedia = com.example.media.BackgroundPlaybackManager.currentMedia.value
        val bgPos = if (bgActive) {
            if (bgMedia?.id == media.id) {
                val p = com.example.media.BackgroundPlaybackManager.currentPositionMs.value
                com.example.media.BackgroundPlaybackManager.stop(context)
                p
            } else {
                com.example.media.BackgroundPlaybackManager.stop(context)
                0L
            }
        } else 0L

        try {
            exoPlayer.stop()
            exoPlayer.clearMediaItems()
            
            if (cachedFallbackPath != null) {
                // Play from cache
                mediaEngine.prepareMedia(cachedFallbackPath!!, null, externalSubtitleUri)
            } else {
                val probeUri = when {
                    videoPath.startsWith("content://") || videoPath.startsWith("file://") || videoPath.startsWith("http://") || videoPath.startsWith("https://") -> android.net.Uri.parse(videoPath)
                    videoPath.startsWith("/") -> android.net.Uri.fromFile(java.io.File(videoPath))
                    else -> android.net.Uri.parse(videoPath)
                }
                
                isFallbackAnalysisInProgress = true
                val probeRes = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                    com.example.media.probe.MediaProbeEngine.probeMedia(context, probeUri)
                }
                
                if (probeRes.isSuccess) {
                    val pInfo = probeRes.getOrNull()
                    mediaEngine.setActiveProbeInfo(pInfo)
                    probeInfo = pInfo
                    
                    val strategy = mediaEngine.evaluatePlaybackStrategy(probeUri, null)
                    fallbackCompatibilityPlan = strategy
                    
                    if (strategy.strategy == com.example.media.playback.PlaybackStrategy.DIRECT_HARDWARE || strategy.strategy == com.example.media.playback.PlaybackStrategy.UNSUPPORTED) {
                        isFallbackAnalysisInProgress = false
                        mediaEngine.prepareMedia(videoPath, audioPath, externalSubtitleUri)
                    } else {
                        // Needs fallback
                        isFallbackAnalysisInProgress = false
                        isFallbackProcessingActive = true
                        
                        val flow = mediaEngine.executePlaybackFix(probeUri, fallbackOutputFile, strategy)
                        activeFallbackJob = launch(kotlinx.coroutines.Dispatchers.IO) {
                            try {
                                flow.collect { progress ->
                                    fallbackProcessingProgress = progress
                                }
                                // Success
                                kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
                                    isFallbackProcessingActive = false
                                    cachedFallbackPath = fallbackOutputFile.absolutePath
                                    mediaEngine.prepareMedia(cachedFallbackPath!!, null, externalSubtitleUri)
                                    if (bgPos > 0L) exoPlayer.seekTo(bgPos)
                                    exoPlayer.playWhenReady = true
                                    exoPlayer.repeatMode = androidx.media3.common.Player.REPEAT_MODE_ONE
                                    exoPlayer.prepare()
                                    exoPlayer.play()
                                }
                            } catch (e: Exception) {
                                kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
                                    isFallbackProcessingActive = false
                                    fallbackFailureReport = e.message ?: "Fallback processing failed"
                                    showExternalPlayerAlert = true
                                }
                            }
                        }
                        return@LaunchedEffect // Don't proceed to play immediately
                    }
                } else {
                    isFallbackAnalysisInProgress = false
                    // Probe failed, attempt direct playback
                    mediaEngine.prepareMedia(videoPath, audioPath, externalSubtitleUri)
                }
            }
            
            if (bgPos > 0L) {
                exoPlayer.seekTo(bgPos)
            }
            exoPlayer.playWhenReady = true
            exoPlayer.repeatMode = androidx.media3.common.Player.REPEAT_MODE_ONE
            exoPlayer.prepare()
            exoPlayer.play()
            val initSize = exoPlayer.videoSize
            if (initSize.width > 0 && initSize.height > 0) {
                val rot = initSize.unappliedRotationDegrees
                if (rot == 90 || rot == 270) {
                    mediaVideoWidth = initSize.height
                    mediaVideoHeight = initSize.width
                } else {
                    mediaVideoWidth = initSize.width
                    mediaVideoHeight = initSize.height
                }
            }
        } catch (e: Exception) {
            val analysisReport = mediaEngine.analyzePlaybackFailure(
                androidx.media3.common.PlaybackException(e.message, e, androidx.media3.common.PlaybackException.ERROR_CODE_UNSPECIFIED),
                probeInfo
            )
            lastPlaybackReport = analysisReport
            playerError = analysisReport.toFormattedReport()
            showExternalPlayerAlert = true
        }
    }

    DisposableEffect(mediaEngine) {
        var hasLoggedSuccess = false
        var recoveryAttempts = 0
        val listener = object : androidx.media3.common.Player.Listener {
            private fun updateVideoDimensionsFromPlayer() {
                val size = exoPlayer.videoSize
                val w = size.width
                val h = size.height
                val rotation = size.unappliedRotationDegrees
                if (w > 0 && h > 0) {
                    if (rotation == 90 || rotation == 270) {
                        mediaVideoWidth = h
                        mediaVideoHeight = w
                    } else {
                        mediaVideoWidth = w
                        mediaVideoHeight = h
                    }
                }
            }

            override fun onVideoSizeChanged(videoSize: androidx.media3.common.VideoSize) {
                updateVideoDimensionsFromPlayer()
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                updateVideoDimensionsFromPlayer()
                when (playbackState) {
                    androidx.media3.common.Player.STATE_BUFFERING -> {
                        if (!hasRenderedFirstFrame && !exoPlayer.isPlaying && exoPlayer.currentPosition < 200L) {
                            isBufferLoading = true
                        }
                    }
                    androidx.media3.common.Player.STATE_READY -> {
                        hasRenderedFirstFrame = true
                        isBufferLoading = false
                        playerError = null
                        recoveryAttempts = 0
                        showExternalPlayerAlert = false
                        if (!hasLoggedSuccess) {
                            hasLoggedSuccess = true
                            lastPlaybackReport = mediaEngine.analyzePlaybackSuccess(probeInfo)
                        }
                    }
                    androidx.media3.common.Player.STATE_ENDED, androidx.media3.common.Player.STATE_IDLE -> {
                        isBufferLoading = false
                    }
                }
            }

            override fun onIsPlayingChanged(isPlaying: Boolean) {
                if (isPlaying) {
                    updateVideoDimensionsFromPlayer()
                    hasRenderedFirstFrame = true
                    isBufferLoading = false
                }
            }

            override fun onRenderedFirstFrame() {
                updateVideoDimensionsFromPlayer()
                hasRenderedFirstFrame = true
                isBufferLoading = false
            }

            override fun onTracksChanged(tracks: androidx.media3.common.Tracks) {
                updateVideoDimensionsFromPlayer()
                val newAudioTracks = mutableListOf<PlayerAudioTrack>()
                val newSubtitleTracks = mutableListOf<PlayerSubtitleTrack>()
                var hasActiveAudio = false

                for (group in tracks.groups) {
                    if (group.type == androidx.media3.common.C.TRACK_TYPE_AUDIO) {
                        for (i in 0 until group.length) {
                            val format = group.getTrackFormat(i)
                            val lang = format.language?.uppercase()?.ifBlank { "UND" } ?: "UND"
                            val channelStr = if (format.channelCount > 0) " (${format.channelCount}ch)" else ""
                            val mime = format.sampleMimeType?.substringAfter("/")?.uppercase() ?: ""
                            val mimeStr = if (mime.isNotBlank()) " [$mime]" else ""
                            val trackLabel = format.label?.ifBlank { null }
                                ?: "Audio Stream #${newAudioTracks.size + 1} ($lang$channelStr$mimeStr)"

                            val isSel = group.isTrackSelected(i)
                            if (isSel) hasActiveAudio = true

                            newAudioTracks.add(
                                PlayerAudioTrack(
                                    group = group,
                                    trackIndex = i,
                                    name = trackLabel,
                                    language = lang,
                                    isSelected = isSel,
                                    isSupported = group.isTrackSupported(i)
                                )
                            )
                        }
                    } else if (group.type == androidx.media3.common.C.TRACK_TYPE_TEXT) {
                        for (i in 0 until group.length) {
                            val format = group.getTrackFormat(i)
                            val lang = format.language?.uppercase()?.ifBlank { "UND" } ?: "UND"
                            val trackLabel = format.label?.ifBlank { null } ?: "Subtitle Stream #${newSubtitleTracks.size + 1} ($lang)"
                            val isSel = group.isTrackSelected(i)
                            
                            newSubtitleTracks.add(
                                PlayerSubtitleTrack(
                                    group = group,
                                    trackIndex = i,
                                    name = trackLabel,
                                    language = lang,
                                    isSelected = isSel
                                )
                            )
                        }
                    }
                }
                
                audioTracks = newAudioTracks
                subtitleTracks = newSubtitleTracks
                
                isAudioDisabled = exoPlayer.trackSelectionParameters.disabledTrackTypes.contains(androidx.media3.common.C.TRACK_TYPE_AUDIO)
                isSubtitleDisabled = exoPlayer.trackSelectionParameters.disabledTrackTypes.contains(androidx.media3.common.C.TRACK_TYPE_TEXT)
                
                if (!hasActiveAudio && newAudioTracks.isNotEmpty() && !isAudioDisabled) {
                    val bestTrack = newAudioTracks.firstOrNull { it.isSupported } ?: newAudioTracks.first()
                    exoPlayer.trackSelectionParameters = exoPlayer.trackSelectionParameters
                        .buildUpon()
                        .clearOverridesOfType(androidx.media3.common.C.TRACK_TYPE_AUDIO)
                    .addOverride(
                            androidx.media3.common.TrackSelectionOverride(
                                bestTrack.group.mediaTrackGroup,
                                listOf(bestTrack.trackIndex)
                            )
                        )
                        .build()
                }
            }

            override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                isBufferLoading = false
                
                // Record decoder failure into Orchestrator to automatically trigger software decoding fallback upon first init failure
                val cause = error.cause ?: error
                val currentDiagnostics = mediaEngine.getDiagnostics()
                val activeVideoMime = currentDiagnostics.videoTracks.firstOrNull()?.mimeType ?: "video/mp4"
                val activeVideoDecoder = playbackCodecInfo.videoDecoder.ifBlank { null }
                
                orchestrator.reportDecoderFailure(
                    decoderName = activeVideoDecoder,
                    mimeType = activeVideoMime,
                    cause = cause
                )

                if (recoveryAttempts >= 2) {
                    val analysisReport = mediaEngine.analyzePlaybackFailure(error, probeInfo)
                    lastPlaybackReport = analysisReport
                    playerError = analysisReport.toFormattedReport()
                    showExternalPlayerAlert = true
                    return
                }
                recoveryAttempts++
                
                toastMessage = "Decoder initialization failure detected. Falling back to software decoding & retrying ($recoveryAttempts/2)..."
                
                val videoPath = media.localPath.substringBefore("|STREAM_AUDIO_URL|")
                val audioPath = if (media.localPath.contains("|STREAM_AUDIO_URL|")) media.localPath.substringAfter("|STREAM_AUDIO_URL|") else null
                val savedPosition = exoPlayer.currentPosition.coerceAtLeast(0L)

                try {
                    exoPlayer.stop()
                    exoPlayer.clearMediaItems()
                    mediaEngine.prepareMedia(videoPath, audioPath, externalSubtitleUri)
                    exoPlayer.seekTo(savedPosition)
                    exoPlayer.playWhenReady = true
                    exoPlayer.prepare()
                    exoPlayer.play()
                } catch (e: Exception) {
                    val analysisReport = mediaEngine.analyzePlaybackFailure(error, probeInfo)
                    lastPlaybackReport = analysisReport
                    playerError = analysisReport.toFormattedReport()
                    showExternalPlayerAlert = true
                }
            }
        }

        val analyticsListener = object : androidx.media3.exoplayer.analytics.AnalyticsListener {
            override fun onVideoInputFormatChanged(eventTime: androidx.media3.exoplayer.analytics.AnalyticsListener.EventTime, format: androidx.media3.common.Format, decoderReuseEvaluation: androidx.media3.exoplayer.DecoderReuseEvaluation?) {
                val decoderName = format.sampleMimeType ?: "Unknown"
                val isHw = !decoderName.lowercase().contains("ffmpeg") && !decoderName.lowercase().contains("sw") && !decoderName.lowercase().contains("raw")
                playbackCodecInfo = playbackCodecInfo.copy(
                    videoDecoder = decoderName,
                    isVideoHw = isHw
                )
            }

            override fun onAudioInputFormatChanged(eventTime: androidx.media3.exoplayer.analytics.AnalyticsListener.EventTime, format: androidx.media3.common.Format, decoderReuseEvaluation: androidx.media3.exoplayer.DecoderReuseEvaluation?) {
                val decoderName = format.sampleMimeType ?: "Unknown"
                val isHw = !decoderName.lowercase().contains("ffmpeg") && !decoderName.lowercase().contains("sw") && !decoderName.lowercase().contains("raw")
                playbackCodecInfo = playbackCodecInfo.copy(
                    audioDecoder = decoderName,
                    isAudioHw = isHw
                )
            }
        }

        exoPlayer.addListener(listener)
        exoPlayer.addAnalyticsListener(analyticsListener)

        onDispose {
            try {
                exoPlayer.removeAnalyticsListener(analyticsListener)
                exoPlayer.removeListener(listener)
                mediaEngine.release()
            } catch (e: Exception) {
                // Safeguard against invalid state during release
            }
        }
    }

    val lifecycleOwner = androidx.lifecycle.compose.LocalLifecycleOwner.current

    val onTriggerBackgroundPlay: () -> Unit = {
        val currentPos = exoPlayer.currentPosition.coerceAtLeast(0L)
        val spd = exoPlayer.playbackParameters.speed
        viewModel?.startBackgroundPlayback(media, currentPos, spd) ?: run {
            com.example.media.BackgroundPlaybackManager.startBackgroundPlayback(context, media, currentPos, spd)
        }
        toastMessage = "🎧 Playing in background (YouTube Mode)"
        onClose()
    }

    DisposableEffect(lifecycleOwner, exoPlayer) {
        val observer = androidx.lifecycle.LifecycleEventObserver { _, event ->
            val activity = context as? android.app.Activity
            val isActivityValid = activity == null || (!activity.isFinishing && !activity.isDestroyed)

            when (event) {
                androidx.lifecycle.Lifecycle.Event.ON_PAUSE,
                androidx.lifecycle.Lifecycle.Event.ON_STOP -> {
                    val bgAllowed = viewModel?.youtubeBackgroundPlayEnabled?.value ?: true
                    val isAppLeaving = activity != null && !activity.isChangingConfigurations
                    if (bgAllowed && isAppLeaving && !isPaused && exoPlayer.isPlaying) {
                        val currentPos = exoPlayer.currentPosition.coerceAtLeast(0L)
                        val spd = exoPlayer.playbackParameters.speed
                        viewModel?.startBackgroundPlayback(media, currentPos, spd) ?: run {
                            com.example.media.BackgroundPlaybackManager.startBackgroundPlayback(context, media, currentPos, spd)
                        }
                    }
                    try {
                        exoPlayer.pause()
                    } catch (e: Exception) {
                        // Avoid crashing on invalid player state
                    }
                }
                androidx.lifecycle.Lifecycle.Event.ON_RESUME -> {
                    if (isActivityValid) {
                        if (com.example.media.BackgroundPlaybackManager.isBackgroundActive.value) {
                            if (com.example.media.BackgroundPlaybackManager.currentMedia.value?.id == media.id) {
                                val bgPos = com.example.media.BackgroundPlaybackManager.currentPositionMs.value
                                val bgPlaying = com.example.media.BackgroundPlaybackManager.isPlaying.value
                                com.example.media.BackgroundPlaybackManager.stop(context)
                                if (bgPos > 0L) {
                                    exoPlayer.seekTo(bgPos)
                                }
                                if (bgPlaying && !isPaused) {
                                    exoPlayer.play()
                                }
                            } else {
                                com.example.media.BackgroundPlaybackManager.stop(context)
                                try {
                                    if (exoPlayer.playbackState != androidx.media3.common.Player.STATE_ENDED && !isPaused) {
                                        exoPlayer.play()
                                    }
                                } catch (e: Exception) {}
                            }
                        } else {
                            try {
                                if (exoPlayer.playbackState != androidx.media3.common.Player.STATE_ENDED && !isPaused) {
                                    exoPlayer.play()
                                }
                            } catch (e: Exception) {}
                        }
                    }
                }
                else -> {}
            }
        }

        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }
    // Advanced video player states
    var currentPosMs by remember { mutableLongStateOf(0L) }
    var bufferedPosMs by remember { mutableLongStateOf(0L) }
    var durationMs by remember { mutableLongStateOf(0L) }
    var isMuted by remember { mutableStateOf(false) }
    var speed by remember { mutableFloatStateOf(1.0f) }
    var resizeModeState by remember { mutableIntStateOf(AspectRatioFrameLayout.RESIZE_MODE_FIT) }
    var showVideoAdjustmentsPanel by remember { mutableStateOf(false) }
    val colorAdjustments = viewModel?.videoColorAdjustments?.collectAsStateWithLifecycle()?.value
        ?: VideoColorAdjustments()
    var compareSplitRatio by remember { mutableFloatStateOf(1.0f) }
    var isHoldOriginalActive by remember { mutableStateOf(false) }
    var showAudioEffectsPanel by remember { mutableStateOf(false) }
    val audioEffectConfig = viewModel?.audioEffectConfig?.collectAsStateWithLifecycle()?.value
        ?: AudioEffectConfig()
    val vocalReductionConfig = viewModel?.vocalReductionConfig?.collectAsStateWithLifecycle()?.value
        ?: VocalReductionConfig()
    var isStereoSourceCompatible by remember { mutableStateOf(true) }

    DisposableEffect(vocalReductionProcessor) {
        vocalReductionProcessor.onCompatibilityChanged = { compatible ->
            isStereoSourceCompatible = compatible
        }
        onDispose {
            vocalReductionProcessor.onCompatibilityChanged = null
        }
    }

    LaunchedEffect(vocalReductionConfig.strength, vocalReductionConfig.mode) {
        vocalReductionProcessor.strength = if (vocalReductionConfig.mode == VocalReductionMode.OFF) 0.0f else vocalReductionConfig.strength
    }

    // --- SMART PLAYBACK STATES & PERSISTENCE ---
    var resumePromptPosMs by remember(media.id) { mutableStateOf<Long?>(null) }
    var showAddMarkerDialog by remember { mutableStateOf(false) }
    var showMarkerListDialog by remember { mutableStateOf(false) }
    val markers = if (viewModel != null) {
        viewModel.getMarkersFlow(media.id).collectAsStateWithLifecycle(initialValue = emptyList()).value
    } else emptyList()

    LaunchedEffect(media.id) {
        if (viewModel != null) {
            val saved = viewModel.getSavedPlaybackProgress(media.id)
            if (saved != null && saved.lastPositionMs > 3000L && !saved.isCompleted) {
                resumePromptPosMs = saved.lastPositionMs
            }
        }
    }

    DisposableEffect(media.id, media.localPath) {
        onDispose {
            if (viewModel != null) {
                val pos = exoPlayer.currentPosition.coerceAtLeast(0L)
                val dur = exoPlayer.duration.coerceAtLeast(0L)
                viewModel.savePlaybackPosition(media.id, media.localPath, dur, pos)
            }
        }
    }

    LaunchedEffect(isPaused) {
        if (isPaused) {
            exoPlayer.pause()
            if (!isScreenAutoDimmed) {
                applyWindowBrightness(originalWindowBrightness)
            }
        } else {
            exoPlayer.play()
            if (!isScreenAutoDimmed) {
                val activeBrightness = userCustomBrightness ?: originalWindowBrightness
                applyWindowBrightness(activeBrightness)
            }
        }
    }

    // Continuous progress tracking
    LaunchedEffect(exoPlayer, isPaused, media.id, media.localPath) {
        var saveCounter = 0
        while (true) {
            val pos = exoPlayer.currentPosition.coerceAtLeast(0L)
            val dur = exoPlayer.duration.coerceAtLeast(0L)
            if (!isSeekDrag) {
                currentPosMs = pos
            }
            bufferedPosMs = exoPlayer.bufferedPosition.coerceAtLeast(0L)
            durationMs = dur
            if (hasRenderedFirstFrame || pos > 150L || exoPlayer.isPlaying || exoPlayer.playbackState == androidx.media3.common.Player.STATE_READY || exoPlayer.playbackState == androidx.media3.common.Player.STATE_ENDED) {
                if (isBufferLoading) {
                    isBufferLoading = false
                }
            }
            saveCounter++
            if (saveCounter % 20 == 0 && pos > 0L && viewModel != null) {
                viewModel.savePlaybackPosition(media.id, media.localPath, dur, pos)
            }
            delay(150)
        }
    }

    // Sound volumes
    LaunchedEffect(isMuted) {
        exoPlayer.volume = if (isMuted) 0f else 1f
    }

    // Playback speed
    LaunchedEffect(speed) {
        exoPlayer.setPlaybackSpeed(speed)
    }

    // Auto-hiding transient toasts
    LaunchedEffect(toastMessage) {
        if (toastMessage != null) {
            delay(1500)
            toastMessage = null
        }
    }

    var showHeader by remember { mutableStateOf(true) }

    var isLocked by remember { mutableStateOf(false) }
    var isFavorite by remember { mutableStateOf(false) }
    var sleepTimerMinutes by remember { mutableIntStateOf(0) }
    var sleepSecondsRemaining by remember { mutableIntStateOf(0) }
    var showSleepTimerDialog by remember { mutableStateOf(false) }

    val isAnyMenuOrDialogActive = showVideoAdjustmentsPanel ||
        showAudioEffectsPanel ||
        showSleepTimerDialog ||
        showAddMarkerDialog ||
        showMarkerListDialog ||
        showAudioTrackMenu ||
        showSubtitleTrackMenu ||
        showAdvancedPlayerSettings ||
        showCodecSpecsDialog ||
        showExternalPlayerAlert

    // Auto-hide controls after 5 seconds of inactivity
    LaunchedEffect(showHeader, lastInteractionTime, isSeekDrag, isAnyMenuOrDialogActive) {
        if (showHeader) {
            if (!isSeekDrag && !isAnyMenuOrDialogActive) {
                delay(5000L)
                showHeader = false
            }
        }
    }

    LaunchedEffect(sleepTimerMinutes, isPaused) {
        if (sleepTimerMinutes > 0 && !isPaused) {
            if (sleepSecondsRemaining <= 0) {
                sleepSecondsRemaining = sleepTimerMinutes * 60
            }
            val fadeDurationSecs = 30
            while (sleepSecondsRemaining > 0 && !isPaused) {
                delay(1000)
                sleepSecondsRemaining--

                if (sleepSecondsRemaining <= fadeDurationSecs) {
                    val fadeFactor = (sleepSecondsRemaining.toFloat() / fadeDurationSecs).coerceIn(0f, 1f)
                    exoPlayer.volume = fadeFactor
                } else {
                    exoPlayer.volume = 1.0f
                }
            }

            if (sleepSecondsRemaining <= 0 && !isPaused) {
                isPaused = true
                exoPlayer.pause()
                sleepTimerMinutes = 0
                exoPlayer.volume = 1.0f
                toastMessage = "Sleep timer expired. Playback paused with volume fade-out."
            }
        } else if (sleepTimerMinutes == 0) {
            sleepSecondsRemaining = 0
            exoPlayer.volume = 1.0f
        }
    }

    // Auto-dim screen brightness after 30 seconds of inactivity during video playback to save battery
    LaunchedEffect(isPaused, autoDimEnabled, autoDimTimeoutSeconds, lastInteractionTime, isScreenAutoDimmed) {
        if (!isPaused && autoDimEnabled && !isScreenAutoDimmed) {
            val elapsed = System.currentTimeMillis() - lastInteractionTime
            val targetTimeoutMs = autoDimTimeoutSeconds * 1000L
            if (elapsed < targetTimeoutMs) {
                delay(targetTimeoutMs - elapsed)
            }
            if (!isPaused && autoDimEnabled && !isScreenAutoDimmed && (System.currentTimeMillis() - lastInteractionTime >= targetTimeoutMs)) {
                applyWindowBrightness(0.05f) // Dimmed level (5% brightness) to save battery
                isScreenAutoDimmed = true
            }
        }
    }

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .focusRequester(overlayFocusRequester)
            .focusable()
            .onKeyEvent { event ->
                if (event.type == KeyEventType.KeyDown) {
                    registerUserActivity()
                    if (event.key == Key.VolumeUp || event.key == Key.VolumeDown) {
                        showQuickGuide = true
                        false // let system handle it
                    } else false
                } else false
            },
        contentAlignment = if (isMiniMode) Alignment.TopStart else Alignment.Center
    ) {
        val systemInsets = androidx.compose.foundation.layout.WindowInsets.systemBars.asPaddingValues()
        val topInsetPx = with(density) { systemInsets.calculateTopPadding().toPx() }
        val bottomInsetPx = with(density) { systemInsets.calculateBottomPadding().toPx() }
        val leftInsetPx = with(density) { systemInsets.calculateLeftPadding(androidx.compose.ui.unit.LayoutDirection.Ltr).toPx() }
        val rightInsetPx = with(density) { systemInsets.calculateRightPadding(androidx.compose.ui.unit.LayoutDirection.Ltr).toPx() }

        val marginPx = with(density) { 12.dp.toPx() }

        val wPx = with(density) { widthDp.toPx() }
        val hPx = with(density) { heightDp.toPx() }

        val containerWPx = with(density) { maxWidth.toPx() }
        val containerHPx = with(density) { maxHeight.toPx() }

        val minL = leftInsetPx + marginPx
        val maxL = (containerWPx - rightInsetPx - marginPx - wPx).coerceAtLeast(minL)
        val minT = topInsetPx + marginPx
        val maxT = (containerHPx - bottomInsetPx - marginPx - hPx).coerceAtLeast(minT)

        var isMiniPositionInitialized by remember { mutableStateOf(false) }
        var prevWPx by remember { mutableFloatStateOf(0f) }
        var prevHPx by remember { mutableFloatStateOf(0f) }

        LaunchedEffect(isMiniMode, containerWPx, containerHPx, wPx, hPx) {
            if (isMiniMode) {
                if (!isMiniPositionInitialized) {
                    offsetX = maxL
                    offsetY = maxT
                    isMiniPositionInitialized = true
                } else if (miniPlayerState != MiniPlayerState.DRAGGING && miniPlayerState != MiniPlayerState.PINCHING) {
                    if (prevWPx > 0f && prevHPx > 0f && (prevWPx != wPx || prevHPx != hPx)) {
                        val centerX = offsetX + prevWPx / 2f
                        val centerY = offsetY + prevHPx / 2f
                        offsetX = (centerX - wPx / 2f).coerceIn(minL, maxL)
                        offsetY = (centerY - hPx / 2f).coerceIn(minT, maxT)
                    } else {
                        offsetX = offsetX.coerceIn(minL, maxL)
                        offsetY = offsetY.coerceIn(minT, maxT)
                    }
                }
                prevWPx = wPx
                prevHPx = hPx
            } else {
                isMiniPositionInitialized = false
                prevWPx = 0f
                prevHPx = 0f
            }
        }

        if (backdropAlpha > 0.001f) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = backdropAlpha))
            )
        }

        Card(
            modifier = Modifier
                .offset {
                    if (isGestureActive) {
                        IntOffset(offsetX.roundToInt(), offsetY.roundToInt())
                    } else {
                        IntOffset(animOffsetX.roundToInt(), animOffsetY.roundToInt())
                    }
                }
                .padding(paddingDp)
                .size(widthDp, heightDp)
                .graphicsLayer {
                    scaleX = playerScale
                    scaleY = playerScale
                }
                .pointerInput(Unit) {
                    awaitPointerEventScope {
                        while (true) {
                            val event = awaitPointerEvent(androidx.compose.ui.input.pointer.PointerEventPass.Initial)
                            if (event.changes.any { it.pressed }) {
                                registerUserActivity()
                            }
                        }
                    }
                }
                .pointerInput(isFullscreen, isMiniMode, baseWidthDp, baseHeightDp) {
                    if (isMiniMode) {
                        awaitPointerEventScope {
                            var primaryPointerId: androidx.compose.ui.input.pointer.PointerId? = null
                            var secondaryPointerId: androidx.compose.ui.input.pointer.PointerId? = null

                            var initialPinchDistance = 1f
                            var initialScale = 1f
                            var initialPinchCenter = androidx.compose.ui.geometry.Offset.Zero
                            var initialPlayerPos = androidx.compose.ui.geometry.Offset.Zero
                            var isPinchConfirmed = false

                            fun performCornerDocking() {
                                android.util.Log.d("MiniPlayer", "SNAP")
                                miniPlayerState = MiniPlayerState.SNAPPING
                                isDragging = false
                                isPinching = false

                                val baseW = with(density) { baseWidthDp.toPx() }
                                val baseH = with(density) { baseHeightDp.toPx() }
                                val currentWPx = baseW * userMiniScale
                                val currentHPx = baseH * userMiniScale

                                val currentMinL = leftInsetPx + marginPx
                                val currentMaxL = (containerWPx - rightInsetPx - marginPx - currentWPx).coerceAtLeast(currentMinL)
                                val currentMinT = topInsetPx + marginPx
                                val currentMaxT = (containerHPx - bottomInsetPx - marginPx - currentHPx).coerceAtLeast(currentMinT)

                                val boundedX = offsetX.coerceIn(currentMinL, currentMaxL)
                                val boundedY = offsetY.coerceIn(currentMinT, currentMaxT)

                                val cx = boundedX + currentWPx / 2f
                                val cy = boundedY + currentHPx / 2f

                                val corners = listOf(
                                    Pair(currentMinL, currentMinT), // TOP-LEFT
                                    Pair(currentMaxL, currentMinT), // TOP-RIGHT
                                    Pair(currentMinL, currentMaxT), // BOTTOM-LEFT
                                    Pair(currentMaxL, currentMaxT)  // BOTTOM-RIGHT
                                )

                                val nearest = corners.minByOrNull { (cL, cT) ->
                                    val cornerCenterX = cL + currentWPx / 2f
                                    val cornerCenterY = cT + currentHPx / 2f
                                    val dx = cx - cornerCenterX
                                    val dy = cy - cornerCenterY
                                    dx * dx + dy * dy
                                } ?: Pair(currentMaxL, currentMaxT)

                                offsetX = nearest.first
                                offsetY = nearest.second
                            }

                            while (true) {
                                val event = awaitPointerEvent(androidx.compose.ui.input.pointer.PointerEventPass.Main)
                                val pressedChanges = event.changes.filter { it.pressed }

                                val baseW = with(density) { baseWidthDp.toPx() }
                                val baseH = with(density) { baseHeightDp.toPx() }
                                val currentWPx = baseW * userMiniScale
                                val currentHPx = baseH * userMiniScale

                                if (primaryPointerId == null) {
                                    val p = pressedChanges.firstOrNull { change ->
                                        change.position.x in 0f..currentWPx && change.position.y in 0f..currentHPx
                                    }
                                    if (p != null) {
                                        primaryPointerId = p.id
                                        miniPlayerState = MiniPlayerState.DRAGGING
                                        isDragging = true
                                        isPinching = false
                                        isPinchConfirmed = false
                                        p.consume()
                                        android.util.Log.d("MiniPlayer", "ACTION_DOWN")
                                    }
                                } else if (secondaryPointerId == null) {
                                    val p1 = pressedChanges.firstOrNull { it.id == primaryPointerId }
                                    if (p1 == null) {
                                        primaryPointerId = null
                                        android.util.Log.d("MiniPlayer", "ACTION_UP")
                                        if (miniPlayerState == MiniPlayerState.DRAGGING) {
                                            performCornerDocking()
                                        } else {
                                            miniPlayerState = MiniPlayerState.IDLE
                                            isDragging = false
                                            isPinching = false
                                        }
                                    } else {
                                        val p2 = pressedChanges.firstOrNull { change ->
                                            change.id != primaryPointerId &&
                                            (change.pressed && !change.previousPressed)
                                        }
                                        if (p2 != null) {
                                            secondaryPointerId = p2.id
                                            isPinchConfirmed = false

                                            p1.consume()
                                            p2.consume()

                                            val pos1 = androidx.compose.ui.geometry.Offset(offsetX + p1.position.x, offsetY + p1.position.y)
                                            val pos2 = androidx.compose.ui.geometry.Offset(offsetX + p2.position.x, offsetY + p2.position.y)

                                            initialPinchDistance = (pos1 - pos2).getDistance().coerceAtLeast(10f)
                                            initialScale = userMiniScale
                                            initialPinchCenter = androidx.compose.ui.geometry.Offset((pos1.x + pos2.x) / 2f, (pos1.y + pos2.y) / 2f)
                                            initialPlayerPos = androidx.compose.ui.geometry.Offset(offsetX, offsetY)
                                        } else {
                                            val delta = p1.position - p1.previousPosition
                                            p1.consume()

                                            val currentMinL = leftInsetPx + marginPx
                                            val currentMaxL = (containerWPx - rightInsetPx - marginPx - currentWPx).coerceAtLeast(currentMinL)
                                            val currentMinT = topInsetPx + marginPx
                                            val currentMaxT = (containerHPx - bottomInsetPx - marginPx - currentHPx).coerceAtLeast(currentMinT)

                                            if (delta.x != 0f || delta.y != 0f) {
                                                offsetX = (offsetX + delta.x).coerceIn(currentMinL, currentMaxL)
                                                offsetY = (offsetY + delta.y).coerceIn(currentMinT, currentMaxT)
                                                android.util.Log.d("MiniPlayer", "ACTION_MOVE x=$offsetX y=$offsetY")
                                            }
                                        }
                                    }
                                } else {
                                    val p1 = pressedChanges.firstOrNull { it.id == primaryPointerId }
                                    val p2 = pressedChanges.firstOrNull { it.id == secondaryPointerId }

                                    if (p1 != null && p2 != null) {
                                        p1.consume()
                                        p2.consume()

                                        val pos1 = androidx.compose.ui.geometry.Offset(offsetX + p1.position.x, offsetY + p1.position.y)
                                        val pos2 = androidx.compose.ui.geometry.Offset(offsetX + p2.position.x, offsetY + p2.position.y)

                                        val currentDistance = (pos1 - pos2).getDistance()
                                        val pinchThresholdPx = with(density) { 12.dp.toPx() }

                                        if (!isPinchConfirmed) {
                                            if (kotlin.math.abs(currentDistance - initialPinchDistance) > pinchThresholdPx) {
                                                isPinchConfirmed = true
                                                miniPlayerState = MiniPlayerState.PINCHING
                                                isPinching = true
                                                isDragging = false
                                            }
                                        }

                                        if (isPinchConfirmed) {
                                            val scaleFactor = currentDistance / initialPinchDistance
                                            val newScale = (initialScale * scaleFactor).coerceIn(0.50f, 2.50f)
                                            userMiniScale = newScale

                                            val oldWPx = baseW * initialScale
                                            val oldHPx = baseH * initialScale
                                            val newWPx = baseW * newScale
                                            val newHPx = baseH * newScale

                                            val normX = if (oldWPx > 0f) (initialPinchCenter.x - initialPlayerPos.x) / oldWPx else 0.5f
                                            val normY = if (oldHPx > 0f) (initialPinchCenter.y - initialPlayerPos.y) / oldHPx else 0.5f

                                            val currentPinchCenter = androidx.compose.ui.geometry.Offset((pos1.x + pos2.x) / 2f, (pos1.y + pos2.y) / 2f)
                                            val proposedOffsetX = currentPinchCenter.x - normX * newWPx
                                            val proposedOffsetY = currentPinchCenter.y - normY * newHPx

                                            val currentMinL = leftInsetPx + marginPx
                                            val currentMaxL = (containerWPx - rightInsetPx - marginPx - newWPx).coerceAtLeast(currentMinL)
                                            val currentMinT = topInsetPx + marginPx
                                            val currentMaxT = (containerHPx - bottomInsetPx - marginPx - newHPx).coerceAtLeast(currentMinT)

                                            offsetX = proposedOffsetX.coerceIn(currentMinL, currentMaxL)
                                            offsetY = proposedOffsetY.coerceIn(currentMinT, currentMaxT)
                                        } else {
                                            val delta = p1.position - p1.previousPosition
                                            val currentMinL = leftInsetPx + marginPx
                                            val currentMaxL = (containerWPx - rightInsetPx - marginPx - currentWPx).coerceAtLeast(currentMinL)
                                            val currentMinT = topInsetPx + marginPx
                                            val currentMaxT = (containerHPx - bottomInsetPx - marginPx - currentHPx).coerceAtLeast(currentMinT)

                                            if (delta.x != 0f || delta.y != 0f) {
                                                offsetX = (offsetX + delta.x).coerceIn(currentMinL, currentMaxL)
                                                offsetY = (offsetY + delta.y).coerceIn(currentMinT, currentMaxT)
                                                android.util.Log.d("MiniPlayer", "ACTION_MOVE x=$offsetX y=$offsetY")
                                            }
                                        }
                                    } else if (p1 != null && p2 == null) {
                                        secondaryPointerId = null
                                        isPinchConfirmed = false
                                        miniPlayerState = MiniPlayerState.DRAGGING
                                        isPinching = false
                                        isDragging = true
                                        p1.consume()
                                    } else if (p1 == null && p2 != null) {
                                        primaryPointerId = p2.id
                                        secondaryPointerId = null
                                        isPinchConfirmed = false
                                        miniPlayerState = MiniPlayerState.DRAGGING
                                        isPinching = false
                                        isDragging = true
                                        p2.consume()
                                    } else {
                                        primaryPointerId = null
                                        secondaryPointerId = null
                                        isPinchConfirmed = false
                                        android.util.Log.d("MiniPlayer", "ACTION_UP")
                                        if (miniPlayerState == MiniPlayerState.DRAGGING) {
                                            performCornerDocking()
                                        } else {
                                            miniPlayerState = MiniPlayerState.IDLE
                                            isDragging = false
                                            isPinching = false
                                        }
                                    }
                                }
                            }
                        }
                    } else if (isFullscreen) {
                        detectDragGestures(
                            onDragStart = { isDragging = true },
                            onDragEnd = {
                                isDragging = false
                                if (offsetY > 100f) {
                                    onToggleFullscreen()
                                    offsetX = 0f
                                    offsetY = 0f
                                } else {
                                    offsetX = 0f
                                    offsetY = 0f
                                }
                            },
                            onDragCancel = {
                                isDragging = false
                                offsetX = 0f
                                offsetY = 0f
                            },
                            onDrag = { change, dragAmount ->
                                change.consume()
                                if (dragAmount.y > 0 || offsetY > 0) {
                                    offsetX += dragAmount.x * 0.5f
                                    offsetY = (offsetY + dragAmount.y).coerceAtLeast(0f)
                                }
                            }
                        )
                    }
                }
                .clip(RoundedCornerShape(cornerRadius))
                .border(1.dp, if (isFullscreen && cornerRadius < 1.dp) Color.Transparent else SleekBorderColor, RoundedCornerShape(cornerRadius))
                .shadow(shadowElevationDp, RoundedCornerShape(cornerRadius)),
            colors = CardDefaults.cardColors(containerColor = SleekCardDark),
            shape = RoundedCornerShape(cornerRadius)
        ) {
            Box(modifier = Modifier.fillMaxSize()) {
                val allowPlayerGestures = isFullscreen && !isCustomPipMini && !isLocked
                val playerGestureSettings = viewModel?.playerGestureSettings?.collectAsStateWithLifecycle()?.value ?: PlayerGestureSettings()

                val executeCustomGestureAction: (PlayerGesture) -> Unit = { gesture ->
                    val action = playerGestureSettings.getActionFor(gesture)
                    when (action) {
                        PlayerGestureAction.NONE -> {}
                        PlayerGestureAction.PLAY_PAUSE -> {
                            isPaused = !isPaused
                            toastMessage = if (isPaused) "Paused" else "Playing"
                            registerUserActivity()
                        }
                        PlayerGestureAction.MUTE_UNMUTE -> {
                            isMuted = !isMuted
                            toastMessage = if (isMuted) "Muted" else "Unmuted"
                            registerUserActivity()
                        }
                        PlayerGestureAction.NEXT_MEDIA -> {
                            val nextMarker = markers.filter { it.positionMs > currentPosMs + 1000L }.minByOrNull { it.positionMs }
                            if (nextMarker != null) {
                                exoPlayer.seekTo(nextMarker.positionMs)
                                currentPosMs = nextMarker.positionMs
                                toastMessage = "Marker: ${nextMarker.note.ifBlank { "Next" }}"
                            } else {
                                val target = (currentPosMs + 30000L).coerceAtMost(durationMs)
                                exoPlayer.seekTo(target)
                                currentPosMs = target
                                toastMessage = "Jump +30s"
                            }
                            registerUserActivity()
                        }
                        PlayerGestureAction.PREVIOUS_MEDIA -> {
                            val prevMarker = markers.filter { it.positionMs < currentPosMs - 1000L }.maxByOrNull { it.positionMs }
                            if (prevMarker != null) {
                                exoPlayer.seekTo(prevMarker.positionMs)
                                currentPosMs = prevMarker.positionMs
                                toastMessage = "Marker: ${prevMarker.note.ifBlank { "Previous" }}"
                            } else {
                                val target = (currentPosMs - 30000L).coerceAtLeast(0L)
                                exoPlayer.seekTo(target)
                                currentPosMs = target
                                toastMessage = "Jump -30s"
                            }
                            registerUserActivity()
                        }
                        PlayerGestureAction.SEEK_FORWARD_10 -> {
                            val target = (currentPosMs + 10000L).coerceAtMost(durationMs)
                            exoPlayer.seekTo(target)
                            currentPosMs = target
                            toastMessage = "Forward 10s"
                            showRightIndicator = true
                            showLeftIndicator = false
                            registerUserActivity()
                        }
                        PlayerGestureAction.SEEK_BACKWARD_10 -> {
                            val target = (currentPosMs - 10000L).coerceAtLeast(0L)
                            exoPlayer.seekTo(target)
                            currentPosMs = target
                            toastMessage = "Rewind 10s"
                            showLeftIndicator = true
                            showRightIndicator = false
                            registerUserActivity()
                        }
                        PlayerGestureAction.SPEED_TOGGLE -> {
                            val nextSpeed = when (speed) {
                                1.0f -> 1.25f
                                1.25f -> 1.5f
                                1.5f -> 2.0f
                                2.0f -> 0.5f
                                0.5f -> 0.75f
                                else -> 1.0f
                            }
                            speed = nextSpeed
                            toastMessage = "Speed: ${nextSpeed}x"
                            registerUserActivity()
                        }
                        PlayerGestureAction.OPEN_CONTROLS -> {
                            showHeader = !showHeader
                            registerUserActivity()
                        }
                        PlayerGestureAction.LOCK_PLAYER -> {
                            isLocked = !isLocked
                            toastMessage = if (isLocked) "Player Locked" else "Player Unlocked"
                            registerUserActivity()
                        }
                        PlayerGestureAction.SCREENSHOT -> {
                            scope.launch {
                                val (ok, msg) = PlayerGestureActionsDispatcher.captureFrameScreenshot(
                                    context = context,
                                    localPath = media.localPath,
                                    positionMs = currentPosMs
                                )
                                toastMessage = msg
                            }
                            registerUserActivity()
                        }
                    }
                }

                // Video Surface (Always spans the full background)
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black)
                        .playerCustomGestures(
                            enabled = allowPlayerGestures,
                            settings = playerGestureSettings,
                            onTriggerGesture = executeCustomGestureAction
                        )
                        .pointerInput(allowPlayerGestures, isMiniMode) {
                            if (allowPlayerGestures) {
                                detectTapGestures(
                                    onDoubleTap = { offset ->
                                        val w = size.width.toFloat()
                                        if (offset.x >= 0.3f * w && offset.x <= 0.7f * w) {
                                            val isLeft = offset.x < 0.5f * w
                                            if (isLeft) {
                                                val target = (currentPosMs - 10000L).coerceAtLeast(0L)
                                                exoPlayer.seekTo(target)
                                                currentPosMs = target
                                                toastMessage = "Rewind 10s"
                                                showLeftIndicator = true
                                                showRightIndicator = false
                                            } else {
                                                val target = (currentPosMs + 10000L).coerceAtMost(durationMs)
                                                exoPlayer.seekTo(target)
                                                currentPosMs = target
                                                toastMessage = "Forward 10s"
                                                showRightIndicator = true
                                                showLeftIndicator = false
                                            }
                                        }
                                    },
                                    onLongPress = { offset ->
                                        val w = size.width.toFloat()
                                        if (offset.x >= 0.3f * w && offset.x <= 0.7f * w) {
                                            if (playerGestureSettings.getActionFor(PlayerGesture.LONG_PRESS) != PlayerGestureAction.NONE) {
                                                executeCustomGestureAction(PlayerGesture.LONG_PRESS)
                                            }
                                        }
                                    },
                                    onTap = { offset ->
                                        showHeader = !showHeader
                                        registerUserActivity()
                                    }
                                )
                            } else if (isMiniMode) {
                                detectTapGestures(
                                    onTap = {
                                        registerUserActivity()
                                    },
                                    onDoubleTap = {
                                        viewModel?.setCustomPipMini(false)
                                        if (!isFullscreen) {
                                            onToggleFullscreen()
                                        }
                                        registerUserActivity()
                                    }
                                )
                            } else {
                                detectTapGestures(
                                    onTap = {
                                        showHeader = !showHeader
                                        registerUserActivity()
                                    }
                                )
                            }
                        }
                        .pointerInput(allowPlayerGestures) {
                            if (allowPlayerGestures) {
                                detectDragGestures(
                                    onDragStart = { offset ->
                                        totalDragY = 0f
                                        totalDragX = 0f
                                        val x = offset.x
                                        val w = size.width.toFloat()
                                        
                                        isBrightnessDrag = x < 0.30f * w
                                        isVolumeDrag = x > 0.70f * w
                                        isSeekDrag = !isBrightnessDrag && !isVolumeDrag
                                        swipeDirectionResolved = false
                                        isVerticalSwipe = false
                                        isHorizontalSwipe = false
                                        
                                        if (isBrightnessDrag) {
                                            initialBrightness = userCustomBrightness ?: run {
                                                val window = (context as? android.app.Activity)?.window
                                                val br = window?.attributes?.screenBrightness ?: -1f
                                                if (br >= 0f) br else {
                                                    try {
                                                        val sysBrightness = android.provider.Settings.System.getInt(context.contentResolver, android.provider.Settings.System.SCREEN_BRIGHTNESS)
                                                        sysBrightness / 255f
                                                    } catch (e: Exception) {
                                                        0.5f
                                                    }
                                                }
                                            }
                                        } else if (isVolumeDrag) {
                                            initialVolume = audioManager.getStreamVolume(android.media.AudioManager.STREAM_MUSIC)
                                            initialVolumeBoost = viewModel?.volumeBoost?.value ?: 0f
                                        } else if (isSeekDrag) {
                                            initialSeekPos = currentPosMs
                                        }
                                    },
                                    onDragEnd = {
                                        isBrightnessDrag = false
                                        isVolumeDrag = false
                                        if (isSeekDrag && swipeDirectionResolved && isHorizontalSwipe) {
                                            exoPlayer.seekTo(currentPosMs)
                                        }
                                        isSeekDrag = false
                                    },
                                    onDragCancel = {
                                        isBrightnessDrag = false
                                        isVolumeDrag = false
                                        if (isSeekDrag && swipeDirectionResolved && isHorizontalSwipe) {
                                            exoPlayer.seekTo(initialSeekPos)
                                            currentPosMs = initialSeekPos
                                        }
                                        isSeekDrag = false
                                    },
                                    onDrag = { change, dragAmount ->
                                        change.consume()
                                        totalDragX += dragAmount.x
                                        totalDragY += dragAmount.y
                                        
                                        if (!swipeDirectionResolved) {
                                            val minSwipeDistance = with(density) { 24.dp.toPx() }
                                            if (kotlin.math.abs(totalDragY) >= minSwipeDistance || kotlin.math.abs(totalDragX) >= minSwipeDistance) {
                                                swipeDirectionResolved = true
                                                if (kotlin.math.abs(totalDragY) > kotlin.math.abs(totalDragX)) {
                                                    isVerticalSwipe = true
                                                } else {
                                                    isHorizontalSwipe = true
                                                }
                                            }
                                        }
                                        
                                        if (swipeDirectionResolved) {
                                            if (isVerticalSwipe) {
                                                val height = size.height.toFloat()
                                                val deltaRatio = -(totalDragY / height) * 1.5f
                                                if (isBrightnessDrag) {
                                                    val newBrightness = (initialBrightness + deltaRatio).coerceIn(0f, 1f)
                                                    userCustomBrightness = newBrightness
                                                    if (!isPaused && !isScreenAutoDimmed) {
                                                        applyWindowBrightness(newBrightness)
                                                    }
                                                    registerUserActivity()
                                                } else if (isVolumeDrag) {
                                                    val currentSystemRatio = initialVolume.toFloat() / maxVolume
                                                    val currentBoostRatio = initialVolumeBoost / 100f
                                                    val currentTotalRatio = currentSystemRatio + currentBoostRatio
                                                    
                                                    val rawTotalRatio = (currentTotalRatio + deltaRatio).coerceIn(0f, 2f)
                                                    
                                                    val newTotalRatio = if (rawTotalRatio > 1f) {
                                                        if (rawTotalRatio <= 1.125f) 1f
                                                        else if (rawTotalRatio <= 1.375f) 1.25f
                                                        else if (rawTotalRatio <= 1.75f) 1.5f
                                                        else 2f
                                                    } else {
                                                        rawTotalRatio
                                                    }
                                                    
                                                    val newSystemRatio = newTotalRatio.coerceIn(0f, 1f)
                                                    val newBoostRatio = (newTotalRatio - 1f).coerceIn(0f, 1f)
                                                    
                                                    audioManager.setStreamVolume(android.media.AudioManager.STREAM_MUSIC, (newSystemRatio * maxVolume).toInt(), 0)
                                                    viewModel?.updateVolumeBoost(newBoostRatio * 100f)
                                                    registerUserActivity()
                                                }
                                            } else if (isHorizontalSwipe && isSeekDrag) {
                                                val width = size.width.toFloat()
                                                val seekDeltaMs = (totalDragX / width) * 90000f
                                                val target = (initialSeekPos + seekDeltaMs.toLong()).coerceIn(0L, durationMs)
                                                currentPosMs = target
                                                registerUserActivity()
                                            }
                                        }
                                    }
                                )
                            }
                        },
                    contentAlignment = Alignment.Center
                ) {
                    AndroidView<PlayerView>(
                        factory = { ctx ->
                            (android.view.LayoutInflater.from(ctx).inflate(com.example.R.layout.media_player_texture_view, null) as PlayerView).apply {
                                layoutParams = android.view.ViewGroup.LayoutParams(
                                    android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                                    android.view.ViewGroup.LayoutParams.MATCH_PARENT
                                )
                                useController = false
                                resizeMode = resizeModeState
                                player = exoPlayer

                                addOnAttachStateChangeListener(object : android.view.View.OnAttachStateChangeListener {
                                    override fun onViewAttachedToWindow(v: android.view.View) {
                                        val act = v.context as? android.app.Activity
                                        val isValid = act == null || (!act.isFinishing && !act.isDestroyed)
                                        if (isValid && (v as? PlayerView)?.player != exoPlayer) {
                                            (v as? PlayerView)?.player = exoPlayer
                                        }
                                    }

                                    override fun onViewDetachedFromWindow(v: android.view.View) {
                                    }
                                })
                            }
                        },
                        update = { view ->
                            val act = view.context as? android.app.Activity
                            val isValid = act == null || (!act.isFinishing && !act.isDestroyed)
                            view.resizeMode = resizeModeState
                            if (isValid) {
                                if (view.player != exoPlayer) {
                                    view.player = exoPlayer
                                }
                            }

                            // Real-time GPU Color Adjustments on TextureView surface
                            val targetView = view.videoSurfaceView ?: view
                            val activeAdjustments = if (isHoldOriginalActive) {
                                VideoColorAdjustments()
                            } else if (compareSplitRatio < 1.0f) {
                                val def = VideoColorAdjustments()
                                VideoColorAdjustments(
                                    brightness = def.brightness + (colorAdjustments.brightness - def.brightness) * compareSplitRatio,
                                    contrast = def.contrast + (colorAdjustments.contrast - def.contrast) * compareSplitRatio,
                                    saturation = def.saturation + (colorAdjustments.saturation - def.saturation) * compareSplitRatio,
                                    gamma = def.gamma + (colorAdjustments.gamma - def.gamma) * compareSplitRatio,
                                    sharpness = def.sharpness + (colorAdjustments.sharpness - def.sharpness) * compareSplitRatio,
                                    temperature = def.temperature + (colorAdjustments.temperature - def.temperature) * compareSplitRatio,
                                    highlights = def.highlights + (colorAdjustments.highlights - def.highlights) * compareSplitRatio,
                                    shadows = def.shadows + (colorAdjustments.shadows - def.shadows) * compareSplitRatio,
                                    vibrance = def.vibrance + (colorAdjustments.vibrance - def.vibrance) * compareSplitRatio,
                                    tint = def.tint + (colorAdjustments.tint - def.tint) * compareSplitRatio
                                )
                            } else {
                                colorAdjustments
                            }

                            if (activeAdjustments.isDefault) {
                                targetView.setLayerType(android.view.View.LAYER_TYPE_NONE, null)
                                view.setLayerType(android.view.View.LAYER_TYPE_NONE, null)
                                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S) {
                                    targetView.setRenderEffect(null)
                                    view.setRenderEffect(null)
                                }
                            } else {
                                val cm = calculateVideoColorMatrix(
                                    brightness = activeAdjustments.brightness,
                                    contrast = activeAdjustments.contrast,
                                    saturation = activeAdjustments.saturation,
                                    gamma = activeAdjustments.gamma,
                                    sharpness = activeAdjustments.sharpness,
                                    temperature = activeAdjustments.temperature,
                                    highlights = activeAdjustments.highlights,
                                    shadows = activeAdjustments.shadows,
                                    vibrance = activeAdjustments.vibrance,
                                    tint = activeAdjustments.tint
                                )
                                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S) {
                                    val effect = android.graphics.RenderEffect.createColorFilterEffect(
                                        android.graphics.ColorMatrixColorFilter(cm)
                                    )
                                    targetView.setRenderEffect(effect)
                                } else {
                                    val paint = android.graphics.Paint().apply {
                                        colorFilter = android.graphics.ColorMatrixColorFilter(cm)
                                    }
                                    targetView.setLayerType(android.view.View.LAYER_TYPE_HARDWARE, paint)
                                }
                            }
                        },
                        onRelease = { view ->
                            view.player = null
                        },
                        modifier = Modifier.fillMaxSize()
                    )

                    // Middle Split Comparison Line & Handle Overlay
                    if (showVideoAdjustmentsPanel && (!colorAdjustments.isDefault || compareSplitRatio < 1.0f)) {
                        BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
                            val wPx = constraints.maxWidth.toFloat()
                            val splitX = (wPx * compareSplitRatio).coerceIn(0f, wPx)

                            // Vertical divider line
                            Box(
                                modifier = Modifier
                                    .offset { androidx.compose.ui.unit.IntOffset(splitX.toInt(), 0) }
                                    .width(2.dp)
                                    .fillMaxHeight()
                                    .background(Color(0xFFFFAB40))
                            )

                            // Draggable Handle Badge
                            Surface(
                                shape = RoundedCornerShape(20.dp),
                                color = Color(0xEC10141D),
                                border = BorderStroke(1.5.dp, Color(0xFFFFAB40)),
                                shadowElevation = 8.dp,
                                modifier = Modifier
                                    .align(Alignment.CenterStart)
                                    .offset { androidx.compose.ui.unit.IntOffset((splitX - 60.dp.toPx()).toInt().coerceIn(16, (wPx - 120.dp.toPx()).toInt().coerceAtLeast(16)), 0) }
                                    .pointerInput(Unit) {
                                        detectHorizontalDragGestures { change, dragAmount ->
                                            change.consume()
                                            val newRatio = ((splitX + dragAmount) / wPx).coerceIn(0f, 1f)
                                            compareSplitRatio = newRatio
                                        }
                                    }
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Text("BEFORE", fontSize = 9.sp, fontWeight = FontWeight.ExtraBold, color = SleekTextMuted)
                                    Icon(Icons.Default.SwapHoriz, contentDescription = null, tint = Color(0xFFFFAB40), modifier = Modifier.size(14.dp))
                                    Text("AFTER", fontSize = 9.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFFFFAB40))
                                }
                            }
                        }
                    }

                    // Left Double Tap Feedback Overlay
                    androidx.compose.animation.AnimatedVisibility(
                        visible = showLeftIndicator,
                        enter = fadeIn() + scaleIn(initialScale = 0.8f),
                        exit = fadeOut(),
                        modifier = Modifier.align(Alignment.CenterStart)
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxHeight()
                                .fillMaxWidth(0.45f)
                                .background(
                                    Brush.horizontalGradient(
                                        colors = listOf(
                                            Color.White.copy(alpha = 0.15f),
                                            Color.Transparent
                                        )
                                    )
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(
                                    imageVector = Icons.Default.FastRewind,
                                    contentDescription = "Rewind",
                                    tint = Color.White,
                                    modifier = Modifier.size(36.dp)
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "Rewind 10s",
                                    color = Color.White,
                                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
                                )
                            }
                        }
                    }

                    // Right Double Tap Feedback Overlay
                    androidx.compose.animation.AnimatedVisibility(
                        visible = showRightIndicator,
                        enter = fadeIn() + scaleIn(initialScale = 0.8f),
                        exit = fadeOut(),
                        modifier = Modifier.align(Alignment.CenterEnd)
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxHeight()
                                .fillMaxWidth(0.45f)
                                .background(
                                    Brush.horizontalGradient(
                                        colors = listOf(
                                            Color.Transparent,
                                            Color.White.copy(alpha = 0.15f)
                                        )
                                    )
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(
                                    imageVector = Icons.Default.FastForward,
                                    contentDescription = "Fast Forward",
                                    tint = Color.White,
                                    modifier = Modifier.size(36.dp)
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "Forward 10s",
                                    color = Color.White,
                                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
                                )
                            }
                        }
                    }

                    // Buffering Skeleton loading state with smooth transition
                    androidx.compose.animation.AnimatedVisibility(
                        visible = isBufferLoading && playerError == null && !isFallbackAnalysisInProgress && !isFallbackProcessingActive,
                        enter = fadeIn(animationSpec = tween(300)),
                        exit = fadeOut(animationSpec = tween(300))
                    ) {
                        SkeletonVideoPlayerOverlay(
                            modifier = Modifier.fillMaxSize()
                        )
                    }

                    // Fallback Engine UI
                    if (isFallbackAnalysisInProgress || isFallbackProcessingActive) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(Color.Black.copy(alpha = 0.85f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier
                                    .fillMaxWidth(0.8f)
                                    .padding(24.dp)
                            ) {
                                CircularProgressIndicator(
                                    color = SleekPurpleLight,
                                    strokeWidth = 3.dp,
                                    modifier = Modifier.size(48.dp)
                                )
                                Spacer(modifier = Modifier.height(24.dp))
                                
                                if (isFallbackAnalysisInProgress) {
                                    Text(
                                        text = "Analyzing media compatibility...",
                                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                        color = Color.White
                                    )
                                } else if (isFallbackProcessingActive) {
                                    val plan = fallbackCompatibilityPlan
                                    val title = when (plan?.strategy) {
                                        com.example.media.playback.PlaybackStrategy.REMUX_REQUIRED -> "Remuxing Container"
                                        com.example.media.playback.PlaybackStrategy.TARGETED_AUDIO_TRANSCODE -> "Transcoding Audio (Lossless Video)"
                                        com.example.media.playback.PlaybackStrategy.TARGETED_VIDEO_TRANSCODE -> "Transcoding Video (Lossless Audio)"
                                        com.example.media.playback.PlaybackStrategy.FULL_TRANSCODE_REQUIRED,
                                        com.example.media.playback.PlaybackStrategy.TRANSCODE_REQUIRED -> "Full Stream Transcoding"
                                        else -> "Processing Media"
                                    }
                                    Text(
                                        text = title,
                                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                        color = Color.White
                                    )
                                    
                                    if (plan != null) {
                                        Spacer(modifier = Modifier.height(8.dp))
                                        Text(
                                            text = plan.reason,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = SleekTextSecondary,
                                            textAlign = TextAlign.Center
                                        )
                                    }
                                    
                                    Spacer(modifier = Modifier.height(24.dp))
                                    
                                    val currentProgress = fallbackProcessingProgress
                                    val progressPct = currentProgress?.progressPercentage ?: 0f
                                    val currentSeconds = (currentProgress?.currentTimestampMs ?: 0L) / 1000
                                    val totalSeconds = (currentProgress?.totalDurationMs ?: 0L) / 1000
                                    val durationStr = String.format("%02d:%02d / %02d:%02d", currentSeconds / 60, currentSeconds % 60, totalSeconds / 60, totalSeconds % 60)
                                    
                                    LinearProgressIndicator(
                                        progress = progressPct / 100f,
                                        modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
                                        color = SleekPurpleLight,
                                        trackColor = SleekCardDark
                                    )
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text(
                                            text = "${progressPct.toInt()}%",
                                            style = MaterialTheme.typography.labelMedium.copy(fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace),
                                            color = SleekPurpleLight
                                        )
                                        Text(
                                            text = durationStr,
                                            style = MaterialTheme.typography.labelMedium.copy(fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace),
                                            color = SleekTextSecondary
                                        )
                                    }
                                    
                                    Spacer(modifier = Modifier.height(24.dp))
                                    OutlinedButton(
                                        onClick = {
                                            activeFallbackJob?.cancel()
                                            isFallbackProcessingActive = false
                                            showExternalPlayerAlert = true
                                        },
                                        colors = ButtonDefaults.outlinedButtonColors(contentColor = CrimsonFailure),
                                        border = BorderStroke(1.dp, CrimsonFailure.copy(alpha = 0.5f))
                                    ) {
                                        Text("Cancel Processing", fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }


                    // Transient Toast overlay in center (adjusted top padding to avoid floating header)
                    toastMessage?.let { msg ->
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = Color.Black.copy(alpha = 0.75f),
                            border = BorderStroke(1.dp, SleekBorderColor),
                            modifier = Modifier
                                .align(Alignment.TopCenter)
                                .padding(top = 90.dp)
                        ) {
                            Text(
                                text = msg,
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                color = Color.White,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }
                    }

                    // Playback error overlay
                    if (playerError != null) {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(SleekCardDark)
                                .padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Warning,
                                contentDescription = null,
                                tint = CrimsonFailure,
                                modifier = Modifier.size(40.dp)
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = "Decoder / Playback Notice",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = Color.White
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .weight(1f, fill = false)
                                    .background(Color(0xFF14171F), shape = androidx.compose.foundation.shape.RoundedCornerShape(8.dp))
                                    .padding(12.dp)
                                    .verticalScroll(rememberScrollState())
                            ) {
                                Text(
                                    text = playerError ?: "Playback Error",
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                                        fontSize = 11.sp
                                    ),
                                    color = Color(0xFFE2E8F0),
                                    textAlign = TextAlign.Start
                                )
                            }
                            Spacer(modifier = Modifier.height(16.dp))
                            Button(
                                onClick = {
                                    val fullReport = com.example.media.playback.CodecReportGenerator.generateCompleteCodecReport(
                                        context = context,
                                        report = lastPlaybackReport,
                                        probeInfo = probeInfo,
                                        fileName = media.title,
                                        fileSizeBytes = if (media.fileSize > 0) media.fileSize else media.expectedSize,
                                        durationMs = durationMs,
                                        mediaUriString = media.localPath,
                                        hardwareAccelerationMode = hardwareAccelerationModeSetting
                                    )
                                    val copied = com.example.media.playback.CodecReportGenerator.copyReportToClipboard(context, fullReport)
                                    if (copied) {
                                        toastMessage = "Codec report copied"
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = Color(0xFF2563EB),
                                    contentColor = Color.White
                                ),
                                shape = androidx.compose.foundation.shape.RoundedCornerShape(8.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("copy_codec_report_button")
                            ) {
                                Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("COPY CODEC REPORT", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            }
                            Spacer(modifier = Modifier.height(12.dp))
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Button(
                                    onClick = {
                                        playerError = null
                                        isSoftwareFallbackActive = true
                                        viewModel?.updateHardwareAccelerationMode("Off")
                                        val safeParams = trackSelector.buildUponParameters()
                                            .setTunnelingEnabled(false)
                                            .setForceHighestSupportedBitrate(false)
                                            .build()
                                        trackSelector.parameters = safeParams
                                        exoPlayer.trackSelectionParameters = safeParams
                                        exoPlayer.prepare()
                                        exoPlayer.play()
                                        toastMessage = "Retrying in Software Safe Mode..."
                                    },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = SleekPurpleLight,
                                        contentColor = Color.White
                                    )
                                ) {
                                    Icon(Icons.Default.Build, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Retry in Safe Mode", fontWeight = FontWeight.Bold)
                                }

                                OutlinedButton(
                                    onClick = onClose,
                                    colors = ButtonDefaults.outlinedButtonColors(
                                        contentColor = Color.White
                                    ),
                                    border = BorderStroke(1.dp, SleekBorderColor)
                                ) {
                                    Text("Close Player", fontWeight = FontWeight.Bold)
                                }
                                
                                Button(
                                    onClick = {
                                        val path = media.localPath.substringBefore("|STREAM_AUDIO_URL|")
                                        val intent = android.content.Intent(android.content.Intent.ACTION_VIEW).apply {
                                            val fileUri = if (path.startsWith("/")) {
                                                androidx.core.content.FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", java.io.File(path))
                                            } else {
                                                android.net.Uri.parse(path)
                                            }
                                            setDataAndType(fileUri, "video/*")
                                            addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                        }
                                        try {
                                            context.startActivity(android.content.Intent.createChooser(intent, "Open with"))
                                        } catch (e: Exception) {
                                            toastMessage = "No system player found"
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = SleekPurpleDark,
                                        contentColor = Color.White
                                    )
                                ) {
                                    Icon(Icons.Default.OpenInNew, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("System Player", fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }

                // DOWNLY Futuristic Video Player HUD Overlay
                val hudDragAlpha = if (isFullscreen && isDragging && offsetY > 0f) {
                    (1f - swipeProgress * 2.2f).coerceIn(0f, 1f)
                } else {
                    1f
                }

                androidx.compose.animation.AnimatedVisibility(
                    visible = (isCustomPipMini || showHeader || isLocked),
                    enter = fadeIn(tween(200, easing = FastOutSlowInEasing)) + scaleIn(initialScale = 0.94f, animationSpec = tween(200, easing = FastOutSlowInEasing)),
                    exit = fadeOut(tween(180, easing = FastOutSlowInEasing)) + scaleOut(targetScale = 0.96f, animationSpec = tween(180, easing = FastOutSlowInEasing)),
                    modifier = Modifier
                        .fillMaxSize()
                        .graphicsLayer { alpha = hudDragAlpha }
                ) {
                    DownlyFuturisticControlsOverlay(
                        media = media,
                        currentPosMs = currentPosMs,
                        bufferedPosMs = bufferedPosMs,
                        durationMs = durationMs,
                        isPaused = isPaused,
                        isMuted = isMuted,
                        speed = speed,
                        resizeModeState = resizeModeState,
                        isLocked = isLocked,
                        isFavorite = isFavorite,
                        sleepTimerMinutes = sleepTimerMinutes,
                        audioTracksCount = audioTracks.size,
                        subtitleTracksCount = subtitleTracks.size,
                        isFullscreen = isFullscreen,
                        showPipControlsOnPlayer = showPipControlsOnPlayer,
                        isCustomPipMini = isCustomPipMini,
                        waveformData = currentWaveformData,
                        markers = markers,
                        onTogglePlay = {
                            isPaused = !isPaused
                            registerUserActivity()
                        },
                        onSeekTo = { newPos ->
                            exoPlayer.seekTo(newPos)
                            currentPosMs = newPos
                            registerUserActivity()
                        },
                        onSeekRelative = { deltaMs ->
                            val target = (currentPosMs + deltaMs).coerceIn(0L, durationMs)
                            exoPlayer.seekTo(target)
                            currentPosMs = target
                            toastMessage = if (deltaMs > 0) "+10s" else "-10s"
                            registerUserActivity()
                        },
                        onToggleMute = {
                            isMuted = !isMuted
                            toastMessage = if (isMuted) "Muted" else "Unmuted"
                            registerUserActivity()
                        },
                        onChangeSpeed = {
                            speed = when (speed) {
                                0.5f -> 1.0f
                                1.0f -> 1.25f
                                1.25f -> 1.5f
                                1.5f -> 2.0f
                                else -> 0.5f
                            }
                            toastMessage = "Speed: ${speed}x"
                            registerUserActivity()
                        },
                        onCycleResizeMode = {
                            resizeModeState = when (resizeModeState) {
                                AspectRatioFrameLayout.RESIZE_MODE_FIT -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                                AspectRatioFrameLayout.RESIZE_MODE_ZOOM -> AspectRatioFrameLayout.RESIZE_MODE_FILL
                                else -> AspectRatioFrameLayout.RESIZE_MODE_FIT
                            }
                            val modeStr = when (resizeModeState) {
                                AspectRatioFrameLayout.RESIZE_MODE_ZOOM -> "Zoom"
                                AspectRatioFrameLayout.RESIZE_MODE_FILL -> "Fill"
                                else -> "Fit"
                            }
                            toastMessage = "Aspect Ratio: $modeStr"
                            registerUserActivity()
                        },
                        onToggleLock = {
                            isLocked = !isLocked
                            toastMessage = if (isLocked) "Controls Locked" else "Controls Unlocked"
                            registerUserActivity()
                        },
                        onToggleFavorite = {
                            isFavorite = !isFavorite
                            toastMessage = if (isFavorite) "Saved to Favorites" else "Removed from Favorites"
                            registerUserActivity()
                        },
                        onCycleSleepTimer = {
                            showSleepTimerDialog = true
                            registerUserActivity()
                        },
                        onOpenAudioFxStudio = {
                            onOpenAudioFxStudio?.invoke()
                            registerUserActivity()
                        },
                        onOpenAdvancedSettings = {
                            showAdvancedPlayerSettings = true
                            registerUserActivity()
                        },
                        onOpenAudioTracks = {
                            showAudioTrackMenu = true
                            registerUserActivity()
                        },
                        onOpenSubtitles = {
                            showSubtitleTrackMenu = true
                            registerUserActivity()
                        },
                        onOpenTrimmer = {
                            viewModel?.openMediaTrimmer(media)
                            registerUserActivity()
                        },
                        onTogglePipMini = {
                            viewModel?.setCustomPipMini(false)
                            if (!isFullscreen) {
                                onToggleFullscreen()
                            }
                            registerUserActivity()
                        },
                        onTriggerBackgroundPlay = {
                            onTriggerBackgroundPlay()
                            registerUserActivity()
                        },
                        onOpenAddMarker = {
                            showAddMarkerDialog = true
                            registerUserActivity()
                        },
                        onOpenMarkerList = {
                            showMarkerListDialog = true
                            registerUserActivity()
                        },
                        onOpenVideoAdjustments = {
                            showVideoAdjustmentsPanel = true
                            registerUserActivity()
                        },
                        colorAdjustments = colorAdjustments,
                        onOpenAudioEffects = {
                            showAudioEffectsPanel = true
                            registerUserActivity()
                        },
                        audioEffectConfig = audioEffectConfig,
                        onToggleFullscreen = {
                            onToggleFullscreen()
                            registerUserActivity()
                        },
                        onCopyCodecReport = {
                            val fullReport = com.example.media.playback.CodecReportGenerator.generateCompleteCodecReport(
                                context = context,
                                report = lastPlaybackReport ?: mediaEngine.analyzePlaybackSuccess(probeInfo),
                                probeInfo = probeInfo,
                                fileName = media.title,
                                fileSizeBytes = if (media.fileSize > 0) media.fileSize else media.expectedSize,
                                durationMs = durationMs,
                                mediaUriString = media.localPath,
                                hardwareAccelerationMode = hardwareAccelerationModeSetting
                            )
                            val copied = com.example.media.playback.CodecReportGenerator.copyReportToClipboard(context, fullReport)
                            if (copied) {
                                toastMessage = "Codec report copied"
                            }
                        },
                        onClose = onClose
                    )
                }

                // --- RESUME PROMPT CARD OVERLAY ---
                resumePromptPosMs?.let { savedPos ->
                    Box(
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .padding(bottom = if (isFullscreen) 90.dp else 40.dp)
                    ) {
                        ResumePromptCard(
                            positionMs = savedPos,
                            onResume = {
                                exoPlayer.seekTo(savedPos)
                                currentPosMs = savedPos
                                resumePromptPosMs = null
                                toastMessage = "Resumed from saved position"
                            },
                            onStartOver = {
                                exoPlayer.seekTo(0L)
                                currentPosMs = 0L
                                resumePromptPosMs = null
                                if (viewModel != null) {
                                    viewModel.clearPlaybackProgress(media.id)
                                }
                                toastMessage = "Started from beginning"
                            },
                            onDismiss = {
                                resumePromptPosMs = null
                            }
                        )
                    }
                }



                BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
                    val preciseHeight = constraints.maxHeight.toFloat()
                    
                    val derivedBrightness = if (isBrightnessDrag && initialBrightness >= 0f) {
                        val deltaRatio = -(totalDragY / preciseHeight) * 1.5f
                        (initialBrightness + deltaRatio).coerceIn(0f, 1f)
                    } else {
                        userCustomBrightness ?: run {
                            val act = context as? android.app.Activity
                            val br = act?.window?.attributes?.screenBrightness ?: -1f
                            if (br >= 0f) br else {
                                try {
                                    val sysBrightness = android.provider.Settings.System.getInt(context.contentResolver, android.provider.Settings.System.SCREEN_BRIGHTNESS)
                                    sysBrightness / 255f
                                } catch (e: Exception) {
                                    0.5f
                                }
                            }
                        }
                    }
                    
                    val derivedVolume = if (isVolumeDrag) {
                        val currentSystemRatio = initialVolume.toFloat() / maxVolume
                        val currentBoostRatio = initialVolumeBoost / 100f
                        val currentTotalRatio = currentSystemRatio + currentBoostRatio
                        val deltaRatio = -(totalDragY / preciseHeight) * 1.5f
                        val rawTotalRatio = (currentTotalRatio + deltaRatio).coerceIn(0f, 2f)
                        val newTotalRatio = if (rawTotalRatio > 1f) {
                            if (rawTotalRatio <= 1.125f) 1f
                            else if (rawTotalRatio <= 1.375f) 1.25f
                            else if (rawTotalRatio <= 1.75f) 1.5f
                            else 2f
                        } else {
                            rawTotalRatio
                        }
                        newTotalRatio / 2f
                    } else {
                        val sysVol = audioManager.getStreamVolume(android.media.AudioManager.STREAM_MUSIC).toFloat() / maxVolume
                        val boostVol = (viewModel?.volumeBoost?.value ?: 0f) / 100f
                        ((sysVol + boostVol) / 2f).coerceIn(0f, 1f)
                    }
                    
                    LiquidGlassGestureIndicator(
                        type = 0,
                        isActive = isBrightnessDrag || showQuickGuide,
                        currentValue = derivedBrightness,
                        displayValue = "${(derivedBrightness * 100).toInt()}%",
                        modifier = Modifier.align(Alignment.CenterStart).padding(start = 24.dp)
                    )
                    
                    LiquidGlassGestureIndicator(
                        type = 1,
                        isActive = isVolumeDrag || showQuickGuide,
                        currentValue = derivedVolume,
                        displayValue = "${(derivedVolume * 200).toInt()}%",
                        modifier = Modifier.align(Alignment.CenterEnd).padding(end = 24.dp)
                    )
                }

                // Battery Saver Auto-Dim Notification Badge
                androidx.compose.animation.AnimatedVisibility(
                    visible = isScreenAutoDimmed,
                    enter = fadeIn(tween(400)) + slideInVertically(initialOffsetY = { -it }),
                    exit = fadeOut(tween(250)) + slideOutVertically(targetOffsetY = { -it }),
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .padding(top = if (isFullscreen) 28.dp else 12.dp)
                ) {
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = Color(0xD910141D),
                        border = BorderStroke(1.dp, Color(0xFF10B981).copy(alpha = 0.7f)),
                        shadowElevation = 8.dp,
                        modifier = Modifier.clickable { registerUserActivity() }
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(7.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.BatterySaver,
                                contentDescription = "Battery Saver Auto-Dim Active",
                                tint = Color(0xFF10B981),
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = "Auto-Dim Active (${autoDimTimeoutSeconds}s Inactivity) • Tap to restore",
                                color = Color(0xFFE2E8F0),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }

                // Floating Moveable 9x9 Player Settings Window
                androidx.compose.animation.AnimatedVisibility(
                    visible = showAdvancedPlayerSettings,
                    enter = fadeIn(tween(200)) + scaleIn(initialScale = 0.88f),
                    exit = fadeOut(tween(160)) + scaleOut(targetScale = 0.92f),
                    modifier = Modifier.align(Alignment.Center)
                ) {
                    FloatingMovable9x9PlayerSettingsWindow(
                        hardwareAccelerationMode = hardwareAccelerationModeSetting,
                        onHardwareAccelerationModeChanged = { newMode ->
                            viewModel?.updateHardwareAccelerationMode(newMode)
                            toastMessage = "Hardware Acceleration: $newMode"
                        },
                        audioPassthroughMode = audioPassthroughModeSetting,
                        onAudioPassthroughModeChanged = { newMode ->
                            viewModel?.updateAudioPassthroughMode(newMode)
                            toastMessage = "Audio Passthrough: $newMode"
                        },
                        autoDimEnabled = autoDimEnabled,
                        onToggleAutoDim = { enabled ->
                            viewModel?.updateAutoDimScreenOnInactivity(enabled)
                            toastMessage = if (enabled) "Auto-Dim: Enabled (${autoDimTimeoutSeconds}s)" else "Auto-Dim: Disabled"
                        },
                        autoDimSeconds = autoDimTimeoutSeconds,
                        onCycleAutoDimSeconds = {
                            val nextSec = when (autoDimTimeoutSeconds) {
                                15 -> 30
                                30 -> 60
                                60 -> 120
                                else -> 15
                            }
                            viewModel?.updateAutoDimInactivitySeconds(nextSec)
                            toastMessage = "Auto-Dim Timeout: ${nextSec}s"
                        },
                        speed = speed,
                        onChangeSpeed = {
                            speed = when (speed) {
                                0.5f -> 1.0f
                                1.0f -> 1.25f
                                1.25f -> 1.5f
                                1.5f -> 2.0f
                                else -> 0.5f
                            }
                            toastMessage = "Speed: ${speed}x"
                        },
                        sleepTimerMinutes = sleepTimerMinutes,
                        onCycleSleepTimer = {
                            showSleepTimerDialog = true
                        },
                        resizeModeState = resizeModeState,
                        onCycleResizeMode = {
                            resizeModeState = when (resizeModeState) {
                                AspectRatioFrameLayout.RESIZE_MODE_FIT -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                                AspectRatioFrameLayout.RESIZE_MODE_ZOOM -> AspectRatioFrameLayout.RESIZE_MODE_FILL
                                else -> AspectRatioFrameLayout.RESIZE_MODE_FIT
                            }
                            val modeStr = when (resizeModeState) {
                                AspectRatioFrameLayout.RESIZE_MODE_ZOOM -> "Zoom"
                                AspectRatioFrameLayout.RESIZE_MODE_FILL -> "Fill"
                                else -> "Fit"
                            }
                            toastMessage = "Aspect Ratio: $modeStr"
                        },
                        audioTracksCount = audioTracks.size,
                        onOpenAudioTracks = { showAudioTrackMenu = true },
                        subtitleTracksCount = subtitleTracks.size,
                        onOpenSubtitles = { showSubtitleTrackMenu = true },
                        onOpenAudioFxStudio = onOpenAudioFxStudio,
                        onOpenVideoAdjustments = {
                            showAdvancedPlayerSettings = false
                            showVideoAdjustmentsPanel = true
                        },
                        colorAdjustments = colorAdjustments,
                        onOpenAudioEffects = {
                            showAdvancedPlayerSettings = false
                            showAudioEffectsPanel = true
                        },
                        audioEffectConfig = audioEffectConfig,
                        codecInfo = playbackCodecInfo,
                        onGenerateReport = {
                            com.example.media.playback.CodecReportGenerator.generateCompleteCodecReport(
                                context = context,
                                report = lastPlaybackReport ?: mediaEngine.analyzePlaybackSuccess(probeInfo),
                                probeInfo = probeInfo,
                                fileName = media.title,
                                fileSizeBytes = if (media.fileSize > 0) media.fileSize else media.expectedSize,
                                durationMs = durationMs,
                                mediaUriString = media.localPath,
                                hardwareAccelerationMode = hardwareAccelerationModeSetting
                            )
                        },
                        onClose = { showAdvancedPlayerSettings = false }
                    )
                }

                // --- VIDEO COLOR ADJUSTMENTS PANEL OVERLAY ---
                if (showVideoAdjustmentsPanel) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp),
                        contentAlignment = Alignment.CenterEnd
                    ) {
                        VideoAdjustmentsPanel(
                            adjustments = colorAdjustments,
                            compareRatio = compareSplitRatio,
                            onUpdateBrightness = { viewModel?.updateVideoBrightness(it) },
                            onUpdateContrast = { viewModel?.updateVideoContrast(it) },
                            onUpdateSaturation = { viewModel?.updateVideoSaturation(it) },
                            onUpdateGamma = { viewModel?.updateVideoGamma(it) },
                            onUpdateSharpness = { viewModel?.updateVideoSharpness(it) },
                            onUpdateTemperature = { viewModel?.updateVideoTemperature(it) },
                            onUpdateHighlights = { viewModel?.updateVideoHighlights(it) },
                            onUpdateShadows = { viewModel?.updateVideoShadows(it) },
                            onUpdateVibrance = { viewModel?.updateVideoVibrance(it) },
                            onUpdateTint = { viewModel?.updateVideoTint(it) },
                            onSelectPreset = { viewModel?.applyColorPreset(it) },
                            onUpdateCompareRatio = { compareSplitRatio = it },
                            isHoldOriginalActive = isHoldOriginalActive,
                            onHoldOriginalChange = { isHoldOriginalActive = it },
                            onReset = {
                                viewModel?.resetVideoColorAdjustments()
                                compareSplitRatio = 1.0f
                            },
                            onDismiss = { showVideoAdjustmentsPanel = false }
                        )
                    }
                }

                // --- AUDIO EFFECTS PANEL OVERLAY ---
                if (showAudioEffectsPanel) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp),
                        contentAlignment = Alignment.CenterEnd
                    ) {
                        AudioEffectsPanel(
                            config = audioEffectConfig,
                            vocalConfig = vocalReductionConfig,
                            isStereoCompatible = isStereoSourceCompatible,
                            onSelectPreset = { viewModel?.selectAudioEffectPreset(it) },
                            onUpdateIntensity = { viewModel?.updateAudioEffectIntensity(it) },
                            onSelectVocalMode = { viewModel?.selectVocalReductionMode(it) },
                            onUpdateVocalStrength = { viewModel?.updateVocalReductionStrength(it) },
                            onReset = {
                                viewModel?.resetAudioEffects()
                                viewModel?.resetVocalReduction()
                            },
                            onDismiss = { showAudioEffectsPanel = false }
                        )
                    }
                }
            }
        }
    }

    if (showSleepTimerDialog) {
        SleepTimerDialog(
            currentMinutes = sleepTimerMinutes,
            currentSecondsRemaining = sleepSecondsRemaining,
            onSelectMinutes = { mins ->
                sleepTimerMinutes = mins
                sleepSecondsRemaining = mins * 60
                toastMessage = if (mins > 0) "Sleep Timer: ${mins}m with Fade-Out" else "Sleep Timer Off"
            },
            onDismiss = { showSleepTimerDialog = false }
        )
    }

    if (showExternalPlayerAlert) {
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { showExternalPlayerAlert = false },
            icon = {
                Icon(
                    imageVector = Icons.Default.Warning,
                    contentDescription = "Playback Error Warning",
                    tint = CrimsonFailure,
                    modifier = Modifier.size(36.dp)
                )
            },
            title = {
                Text(
                    text = "External Player Recommended",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = Color.White
                )
            },
            text = {
                Text(
                    text = "Playback failed after 2 automatic recovery attempts. Would you like to open this file in an external system player?",
                    style = MaterialTheme.typography.bodyMedium,
                    color = SleekTextSecondary
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showExternalPlayerAlert = false
                        val path = media.localPath.substringBefore("|STREAM_AUDIO_URL|")
                        val intent = android.content.Intent(android.content.Intent.ACTION_VIEW).apply {
                            val fileUri = if (path.startsWith("/")) {
                                androidx.core.content.FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", java.io.File(path))
                            } else {
                                android.net.Uri.parse(path)
                            }
                            setDataAndType(fileUri, "video/*")
                            addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        }
                        try {
                            context.startActivity(android.content.Intent.createChooser(intent, "Open with"))
                        } catch (e: Exception) {
                            toastMessage = "No system player found"
                        }
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = SleekPurpleDark,
                        contentColor = Color.White
                    )
                ) {
                    Icon(Icons.Default.OpenInNew, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Open System Player", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = {
                        showExternalPlayerAlert = false
                        onClose()
                    },
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                    border = BorderStroke(1.dp, SleekBorderColor)
                ) {
                    Text("Cancel", fontWeight = FontWeight.Bold)
                }
            },
            containerColor = SleekCardDark,
            titleContentColor = Color.White,
            textContentColor = SleekTextSecondary
        )
    }

    if (showAudioTrackMenu) {
        AudioStreamSelectionDialog(
            audioTracks = audioTracks,
            isAudioDisabled = isAudioDisabled,
            onDisableAudio = {
                isAudioDisabled = true
                exoPlayer.trackSelectionParameters = exoPlayer.trackSelectionParameters
                    .buildUpon()
                    .clearOverridesOfType(androidx.media3.common.C.TRACK_TYPE_AUDIO)
                    .setTrackTypeDisabled(androidx.media3.common.C.TRACK_TYPE_AUDIO, true)
                    .build()
                toastMessage = "Audio Off (Disabled)"
                showAudioTrackMenu = false
            },
            onSelectTrack = { track: PlayerAudioTrack ->
                isAudioDisabled = false
                exoPlayer.trackSelectionParameters = exoPlayer.trackSelectionParameters
                    .buildUpon()
                    .setTrackTypeDisabled(androidx.media3.common.C.TRACK_TYPE_AUDIO, false)
                    .clearOverridesOfType(androidx.media3.common.C.TRACK_TYPE_AUDIO)
                    .addOverride(
                        androidx.media3.common.TrackSelectionOverride(
                            track.group.mediaTrackGroup,
                            listOf(track.trackIndex)
                        )
                    )
                    .build()
                toastMessage = "Audio Track: ${track.name}"
                showAudioTrackMenu = false
            },
            onDismiss = { showAudioTrackMenu = false }
        )
    }

    if (showSubtitleTrackMenu) {
        SubtitleStreamSelectionDialog(
            subtitleTracks = subtitleTracks,
            isSubtitleDisabled = isSubtitleDisabled,
            externalSubtitleUri = externalSubtitleUri,
            onDisableSubtitles = {
                isSubtitleDisabled = true
                externalSubtitleUri = null
                exoPlayer.trackSelectionParameters = exoPlayer.trackSelectionParameters
                    .buildUpon()
                    .clearOverridesOfType(androidx.media3.common.C.TRACK_TYPE_TEXT)
                    .setTrackTypeDisabled(androidx.media3.common.C.TRACK_TYPE_TEXT, true)
                    .build()
                toastMessage = "Subtitles Off (Disabled)"
                showSubtitleTrackMenu = false
            },
            onSelectTrack = { track: PlayerSubtitleTrack ->
                isSubtitleDisabled = false
                externalSubtitleUri = null
                exoPlayer.trackSelectionParameters = exoPlayer.trackSelectionParameters
                    .buildUpon()
                    .setTrackTypeDisabled(androidx.media3.common.C.TRACK_TYPE_TEXT, false)
                    .clearOverridesOfType(androidx.media3.common.C.TRACK_TYPE_TEXT)
                    .addOverride(
                        androidx.media3.common.TrackSelectionOverride(
                            track.group.mediaTrackGroup,
                            listOf(track.trackIndex)
                        )
                    )
                    .build()
                toastMessage = "Subtitle Track: ${track.name}"
                showSubtitleTrackMenu = false
            },
            onPickExternalSubtitle = {
                showSubtitleTrackMenu = false
                try {
                    subtitlePickerLauncher.launch("*/*")
                } catch (e: Exception) {
                    toastMessage = "Unable to launch file picker"
                }
            },
            onDismiss = { showSubtitleTrackMenu = false }
        )
    }

    if (showAddMarkerDialog) {
        AddMarkerDialog(
            positionMs = currentPosMs,
            onSaveMarker = { noteText ->
                if (viewModel != null) {
                    viewModel.addMarker(
                        mediaId = media.id,
                        positionMs = currentPosMs,
                        note = noteText
                    )
                    toastMessage = "Bookmark added at ${formatTimeMs(currentPosMs)}"
                }
                showAddMarkerDialog = false
            },
            onDismiss = { showAddMarkerDialog = false }
        )
    }

    if (showMarkerListDialog) {
        MarkerListDialog(
            markers = markers,
            onSelectMarker = { markerPosMs ->
                exoPlayer.seekTo(markerPosMs)
                currentPosMs = markerPosMs
                showMarkerListDialog = false
                toastMessage = "Jumped to marker at ${formatTimeMs(markerPosMs)}"
            },
            onEditMarker = { marker, newNote ->
                if (viewModel != null) {
                    viewModel.updateMarker(marker.copy(note = newNote))
                    toastMessage = "Marker updated"
                }
            },
            onDeleteMarker = { markerId ->
                if (viewModel != null) {
                    viewModel.deleteMarker(markerId)
                    toastMessage = "Marker deleted"
                }
            },
            onDismiss = { showMarkerListDialog = false }
        )
    }
}

enum class FloatingSettingsWindowMode {
    MINIMIZED,
    MATRIX_9X9,
    EXPANDED
}

@Composable
fun FloatingSettingsFutton(
    isOpen: Boolean,
    onToggle: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = CircleShape,
        color = Color(0xCC181922),
        border = BorderStroke(1.5.dp, Brush.linearGradient(listOf(SleekPurpleLight, Color(0xFFFF7A00)))),
        shadowElevation = 10.dp,
        modifier = modifier
            .size(46.dp)
            .testTag("floating_settings_futton")
    ) {
        IconButton(
            onClick = onToggle,
            modifier = Modifier.fillMaxSize()
        ) {
            Icon(
                imageVector = if (isOpen) Icons.Default.Close else Icons.Default.Tune,
                contentDescription = if (isOpen) "Collapse Settings Window" else "Expand 9x9 Settings Window",
                tint = if (isOpen) CrimsonFailure else SleekPurpleLight,
                modifier = Modifier.size(22.dp)
            )
        }
    }
}

@Composable
fun FloatingMovable9x9PlayerSettingsWindow(
    hardwareAccelerationMode: String,
    onHardwareAccelerationModeChanged: (String) -> Unit,
    audioPassthroughMode: String,
    onAudioPassthroughModeChanged: (String) -> Unit,
    autoDimEnabled: Boolean = true,
    onToggleAutoDim: (Boolean) -> Unit = {},
    autoDimSeconds: Int = 30,
    onCycleAutoDimSeconds: () -> Unit = {},
    speed: Float,
    onChangeSpeed: () -> Unit,
    sleepTimerMinutes: Int,
    onCycleSleepTimer: () -> Unit,
    resizeModeState: Int,
    onCycleResizeMode: () -> Unit,
    audioTracksCount: Int,
    onOpenAudioTracks: () -> Unit,
    subtitleTracksCount: Int,
    onOpenSubtitles: () -> Unit,
    onOpenAudioFxStudio: (() -> Unit)?,
    onOpenVideoAdjustments: () -> Unit = {},
    colorAdjustments: VideoColorAdjustments = VideoColorAdjustments(),
    onOpenAudioEffects: () -> Unit = {},
    audioEffectConfig: AudioEffectConfig = AudioEffectConfig(),
    codecInfo: PlaybackCodecInfo,
    onGenerateReport: () -> String,
    initialMode: FloatingSettingsWindowMode = FloatingSettingsWindowMode.MATRIX_9X9,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val density = androidx.compose.ui.platform.LocalDensity.current
    val prefs = remember(context) { context.getSharedPreferences("꒯ꄲꅐꋊ꒒ꌦPrefs", Context.MODE_PRIVATE) }

    var offsetX by remember { mutableFloatStateOf(0f) }
    var offsetY by remember { mutableFloatStateOf(0f) }
    var windowMode by remember { mutableStateOf(initialMode) }
    var showReportDialog by remember { mutableStateOf(false) }

    // Persistent chosen window dimensions (stored in SharedPreferences & remembered in state)
    var windowWidthDp by androidx.compose.runtime.saveable.rememberSaveable {
        mutableFloatStateOf(prefs.getFloat("floating_settings_window_width_dp", 335f).coerceIn(270f, 560f))
    }
    var windowHeightDp by androidx.compose.runtime.saveable.rememberSaveable {
        mutableFloatStateOf(prefs.getFloat("floating_settings_window_height_dp", 350f).coerceIn(200f, 650f))
    }
    var isResizing by remember { mutableStateOf(false) }

    val dragModifier = Modifier.pointerInput(Unit) {
        detectDragGestures { change, dragAmount ->
            change.consume()
            offsetX += dragAmount.x
            offsetY += dragAmount.y
        }
    }

    val resizeCornerModifier = Modifier.pointerInput(density) {
        detectDragGestures(
            onDragStart = { isResizing = true },
            onDragEnd = {
                isResizing = false
                prefs.edit()
                    .putFloat("floating_settings_window_width_dp", windowWidthDp)
                    .putFloat("floating_settings_window_height_dp", windowHeightDp)
                    .apply()
            },
            onDragCancel = { isResizing = false }
        ) { change, dragAmount ->
            change.consume()
            val deltaXDp = with(density) { dragAmount.x.toDp().value }
            val deltaYDp = with(density) { dragAmount.y.toDp().value }
            windowWidthDp = (windowWidthDp + deltaXDp).coerceIn(270f, 560f)
            windowHeightDp = (windowHeightDp + deltaYDp).coerceIn(200f, 650f)
        }
    }

    if (windowMode == FloatingSettingsWindowMode.MINIMIZED) {
        // Minimized Floating Pill
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = Color(0xEE14151B),
            border = BorderStroke(1.5.dp, SleekPurpleLight),
            shadowElevation = 12.dp,
            modifier = modifier
                .offset { IntOffset(offsetX.roundToInt(), offsetY.roundToInt()) }
                .then(dragModifier)
                .testTag("floating_settings_window_minimized")
        ) {
            Row(
                modifier = Modifier
                    .padding(horizontal = 12.dp, vertical = 6.dp)
                    .clickable { windowMode = FloatingSettingsWindowMode.MATRIX_9X9 },
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.DragIndicator,
                    contentDescription = "Drag to Move",
                    tint = SleekTextSecondary,
                    modifier = Modifier.size(16.dp)
                )
                Icon(
                    imageVector = Icons.Default.Tune,
                    contentDescription = null,
                    tint = SleekPurpleLight,
                    modifier = Modifier.size(18.dp)
                )
                Text(
                    text = "9x9 Settings",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp
                )
                IconButton(
                    onClick = { windowMode = FloatingSettingsWindowMode.MATRIX_9X9 },
                    modifier = Modifier.size(24.dp).testTag("floating_settings_expand_futton")
                ) {
                    Icon(
                        imageVector = Icons.Default.UnfoldMore,
                        contentDescription = "Expand to 9x9 Grid",
                        tint = Color.White,
                        modifier = Modifier.size(16.dp)
                    )
                }
                IconButton(
                    onClick = onClose,
                    modifier = Modifier.size(24.dp).testTag("floating_settings_minimized_close")
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Close",
                        tint = CrimsonFailure,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    } else {
        // 9x9 Matrix or Expanded Floating Window
        Surface(
            shape = RoundedCornerShape(18.dp),
            color = Color(0xF2121319),
            border = BorderStroke(
                if (isResizing) 2.dp else 1.5.dp,
                Brush.linearGradient(
                    if (isResizing) listOf(AmberAccent, SleekPurpleLight, EmeraldSuccess)
                    else listOf(SleekPurpleLight, SleekPurpleDark, Color(0xFFFF7A00))
                )
            ),
            shadowElevation = if (isResizing) 24.dp else 18.dp,
            modifier = modifier
                .offset { IntOffset(offsetX.roundToInt(), offsetY.roundToInt()) }
                .width(windowWidthDp.dp)
                .heightIn(min = 200.dp, max = windowHeightDp.dp)
                .testTag("floating_settings_window")
        ) {
            Box(modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(start = 14.dp, top = 14.dp, end = 14.dp, bottom = 12.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    // Header & Drag Handle Bar
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .then(dragModifier)
                            .padding(bottom = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.DragHandle,
                                contentDescription = "Drag to Move Window",
                                tint = SleekTextSecondary,
                                modifier = Modifier.size(20.dp)
                            )
                            Text(
                                text = "9x9 PLAYER MATRIX",
                                style = MaterialTheme.typography.labelMedium.copy(
                                    fontWeight = FontWeight.ExtraBold,
                                    letterSpacing = 1.sp,
                                    color = Color.White
                                )
                            )
                        }

                        // Window Action Buttons (Expand/Collapse Futton + Minimize + Close)
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            // Expand / Collapse Futton (Toggles between 9x9 matrix and detailed view)
                            IconButton(
                                onClick = {
                                    windowMode = if (windowMode == FloatingSettingsWindowMode.EXPANDED) {
                                        FloatingSettingsWindowMode.MATRIX_9X9
                                    } else {
                                        FloatingSettingsWindowMode.EXPANDED
                                    }
                                },
                                modifier = Modifier
                                    .size(28.dp)
                                    .testTag("floating_settings_expand_collapse_futton")
                            ) {
                                Icon(
                                    imageVector = if (windowMode == FloatingSettingsWindowMode.EXPANDED) Icons.Default.UnfoldLess else Icons.Default.UnfoldMore,
                                    contentDescription = if (windowMode == FloatingSettingsWindowMode.EXPANDED) "Collapse to 9x9 Grid" else "Expand Detailed Settings",
                                    tint = SleekPurpleLight,
                                    modifier = Modifier.size(18.dp)
                                )
                            }

                            // Minimize to Floating Pill
                            IconButton(
                                onClick = { windowMode = FloatingSettingsWindowMode.MINIMIZED },
                                modifier = Modifier
                                    .size(28.dp)
                                    .testTag("floating_settings_minimize_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Remove,
                                    contentDescription = "Minimize Floating Window",
                                    tint = SleekTextSecondary,
                                    modifier = Modifier.size(18.dp)
                                )
                            }

                            // Close Button
                            IconButton(
                                onClick = onClose,
                                modifier = Modifier
                                    .size(28.dp)
                                    .testTag("floating_settings_close_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "Close Settings",
                                    tint = SleekTextSecondary,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }

                    HorizontalDivider(color = Color.White.copy(alpha = 0.12f), modifier = Modifier.padding(bottom = 10.dp))

                    // 9x9 Quick Matrix (3x3 Grid of 9 Modular Controls)
                    Column(
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        // Row 1: Decoder, Passthrough, Speed
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Matrix9x9Tile(
                                icon = Icons.Default.Memory,
                                title = "Decoder",
                                value = "HW: $hardwareAccelerationMode",
                                isActive = hardwareAccelerationMode.equals("On", true),
                                onClick = {
                                    val next = when (hardwareAccelerationMode) {
                                        "Auto" -> "On"
                                        "On" -> "Off"
                                        else -> "Auto"
                                    }
                                    onHardwareAccelerationModeChanged(next)
                                },
                                modifier = Modifier.weight(1f).testTag("floating_settings_tile_1")
                            )

                            Matrix9x9Tile(
                                icon = Icons.Default.SurroundSound,
                                title = "Passthrough",
                                value = audioPassthroughMode,
                                isActive = audioPassthroughMode.equals("On", true),
                                onClick = {
                                    val next = when (audioPassthroughMode) {
                                        "Auto" -> "On"
                                        "On" -> "Off"
                                        else -> "Auto"
                                    }
                                    onAudioPassthroughModeChanged(next)
                                },
                                modifier = Modifier.weight(1f).testTag("floating_settings_tile_2")
                            )

                            Matrix9x9Tile(
                                icon = Icons.Default.Speed,
                                title = "Speed",
                                value = "${speed}x",
                                isActive = speed != 1.0f,
                                onClick = onChangeSpeed,
                                modifier = Modifier.weight(1f).testTag("floating_settings_tile_3")
                            )
                        }

                        // Row 2: Audio FX, Sleep Timer, Aspect Ratio
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Matrix9x9Tile(
                                icon = Icons.Default.GraphicEq,
                                title = "Audio FX",
                                value = "Studio",
                                isActive = onOpenAudioFxStudio != null,
                                onClick = { onOpenAudioFxStudio?.invoke() },
                                modifier = Modifier.weight(1f).testTag("floating_settings_tile_4")
                            )

                            Matrix9x9Tile(
                                icon = Icons.Default.Timer,
                                title = "Timer",
                                value = if (sleepTimerMinutes > 0) "${sleepTimerMinutes}m" else "Off",
                                isActive = sleepTimerMinutes > 0,
                                onClick = onCycleSleepTimer,
                                modifier = Modifier.weight(1f).testTag("floating_settings_tile_5")
                            )

                            val aspectLabel = when (resizeModeState) {
                                AspectRatioFrameLayout.RESIZE_MODE_ZOOM -> "Zoom"
                                AspectRatioFrameLayout.RESIZE_MODE_FILL -> "Fill"
                                else -> "Fit"
                            }
                            Matrix9x9Tile(
                                icon = Icons.Default.AspectRatio,
                                title = "Aspect",
                                value = aspectLabel,
                                isActive = resizeModeState != AspectRatioFrameLayout.RESIZE_MODE_FIT,
                                onClick = onCycleResizeMode,
                                modifier = Modifier.weight(1f).testTag("floating_settings_tile_6")
                            )
                        }

                        // Row 3: Subtitles, Audio Tracks, Codec HUD / Telemetry
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Matrix9x9Tile(
                                icon = Icons.Default.ClosedCaption,
                                title = "Subtitles",
                                value = if (subtitleTracksCount > 0) "$subtitleTracksCount Tracks" else "None",
                                isActive = subtitleTracksCount > 0,
                                onClick = onOpenSubtitles,
                                modifier = Modifier.weight(1f).testTag("floating_settings_tile_7")
                            )

                            Matrix9x9Tile(
                                icon = Icons.Default.Audiotrack,
                                title = "Audio",
                                value = if (audioTracksCount > 0) "$audioTracksCount Tracks" else "Default",
                                isActive = audioTracksCount > 1,
                                onClick = onOpenAudioTracks,
                                modifier = Modifier.weight(1f).testTag("floating_settings_tile_8")
                            )

                            Matrix9x9Tile(
                                icon = Icons.Default.BugReport,
                                title = "Codec HUD",
                                value = "Report",
                                isActive = true,
                                onClick = { showReportDialog = true },
                                modifier = Modifier.weight(1f).testTag("floating_settings_tile_9")
                            )
                        }
                    }

                    // Expanded Deep Configuration Pane
                    if (windowMode == FloatingSettingsWindowMode.EXPANDED) {
                        Spacer(modifier = Modifier.height(12.dp))
                        HorizontalDivider(color = Color.White.copy(alpha = 0.1f))
                        Spacer(modifier = Modifier.height(10.dp))

                        Column(
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            // Hardware Acceleration Mode Detailed Switcher
                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text(
                                    text = "Hardware Acceleration Tuning",
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                    color = SleekTextPrimary
                                )
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(Color.White.copy(alpha = 0.05f), RoundedCornerShape(8.dp))
                                        .padding(3.dp),
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    listOf("Auto", "On", "Off").forEach { mode ->
                                        val isSel = hardwareAccelerationMode.equals(mode, ignoreCase = true)
                                        Box(
                                            modifier = Modifier
                                                .weight(1f)
                                                .clip(RoundedCornerShape(6.dp))
                                                .background(if (isSel) SleekPurpleLight else Color.Transparent)
                                                .clickable { onHardwareAccelerationModeChanged(mode) }
                                                .padding(vertical = 6.dp),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(
                                                text = mode,
                                                color = if (isSel) Color.White else SleekTextSecondary,
                                                fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                                                fontSize = 11.sp
                                            )
                                        }
                                    }
                                }
                            }

                            // Audio Passthrough Detailed Switcher
                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text(
                                    text = "Audio Passthrough Mode",
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                    color = SleekTextPrimary
                                )
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(Color.White.copy(alpha = 0.05f), RoundedCornerShape(8.dp))
                                        .padding(3.dp),
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    listOf("Auto", "On", "Off").forEach { mode ->
                                        val isSel = audioPassthroughMode.equals(mode, ignoreCase = true)
                                        Box(
                                            modifier = Modifier
                                                .weight(1f)
                                                .clip(RoundedCornerShape(6.dp))
                                                .background(if (isSel) SleekPurpleLight else Color.Transparent)
                                                .clickable { onAudioPassthroughModeChanged(mode) }
                                                .padding(vertical = 6.dp),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(
                                                text = mode,
                                                color = if (isSel) Color.White else SleekTextSecondary,
                                                fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                                                fontSize = 11.sp
                                            )
                                        }
                                    }
                                }
                            }

                            // Auto-Dim Inactivity (Battery Saver) Setting Card
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = Color.White.copy(alpha = 0.03f),
                                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.06f)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(
                                    modifier = Modifier.padding(10.dp),
                                    verticalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.BatterySaver,
                                                contentDescription = null,
                                                tint = Color(0xFF10B981),
                                                modifier = Modifier.size(16.dp)
                                            )
                                            Text(
                                                "Auto-Dim Battery Saver",
                                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                                color = SleekTextPrimary
                                            )
                                        }
                                        SmoothToggle(
                                            checked = autoDimEnabled,
                                            onCheckedChange = { onToggleAutoDim(it) }
                                        )
                                    }
                                    if (autoDimEnabled) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                "Inactivity Timeout",
                                                fontSize = 11.sp,
                                                color = SleekTextSecondary
                                            )
                                            Surface(
                                                shape = RoundedCornerShape(6.dp),
                                                color = Color.White.copy(alpha = 0.08f),
                                                border = BorderStroke(1.dp, Color(0xFF10B981).copy(alpha = 0.3f)),
                                                modifier = Modifier.clickable { onCycleAutoDimSeconds() }
                                            ) {
                                                Text(
                                                    text = "${autoDimSeconds}s ▾",
                                                    color = Color(0xFF10B981),
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 11.sp,
                                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                            }

                            // Video Color Adjustments Tuning Card
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = Color.White.copy(alpha = 0.03f),
                                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.06f)),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { onOpenVideoAdjustments() }
                                    .testTag("floating_settings_video_adjustments_card")
                            ) {
                                Row(
                                    modifier = Modifier.padding(10.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Tune,
                                            contentDescription = null,
                                            tint = SleekPurpleLight,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Text(
                                            "Video Color Adjustments",
                                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                            color = SleekTextPrimary
                                        )
                                    }
                                    Surface(
                                        shape = RoundedCornerShape(4.dp),
                                        color = if (!colorAdjustments.isDefault) SleekPurpleDark else Color.White.copy(alpha = 0.08f)
                                    ) {
                                        Text(
                                            if (!colorAdjustments.isDefault) "Custom" else "Default",
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (!colorAdjustments.isDefault) Color(0xFFFFAB40) else SleekTextMuted,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                            }

                            // Audio Effects Room Profiles Card
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = Color.White.copy(alpha = 0.03f),
                                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.06f)),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { onOpenAudioEffects() }
                            ) {
                                Row(
                                    modifier = Modifier
                                        .padding(10.dp)
                                        .fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Icon(
                                            Icons.Default.SurroundSound,
                                            contentDescription = null,
                                            tint = if (audioEffectConfig.isEnabled) SleekPurpleLight else SleekTextMuted,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Text(
                                            "Audio Effects",
                                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                            color = SleekTextPrimary
                                        )
                                    }
                                    Surface(
                                        shape = RoundedCornerShape(4.dp),
                                        color = if (audioEffectConfig.isEnabled) SleekPurpleDark else Color.White.copy(alpha = 0.08f)
                                    ) {
                                        Text(
                                            if (audioEffectConfig.isEnabled) "${audioEffectConfig.preset.displayName} (${(audioEffectConfig.intensity * 100).toInt()}%)" else "Off",
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (audioEffectConfig.isEnabled) Color(0xFFFFAB40) else SleekTextMuted,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                            }

                            // Live Media3 Engine Specs Card
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = Color.White.copy(alpha = 0.03f),
                                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.06f)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(
                                    modifier = Modifier.padding(10.dp),
                                    verticalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Text("Live Codec Diagnostics", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = SleekPurpleLight)
                                    Text("Video Decoder: ${codecInfo.videoDecoder}", fontSize = 10.sp, color = SleekTextPrimary)
                                    Text("Resolution / MIME: ${codecInfo.videoResolution} (${codecInfo.videoMime})", fontSize = 10.sp, color = SleekTextSecondary)
                                    Text("Audio Decoder: ${codecInfo.audioDecoder}", fontSize = 10.sp, color = SleekTextPrimary)
                                    Text("Audio Channels: ${codecInfo.audioChannels} (${codecInfo.audioMime})", fontSize = 10.sp, color = SleekTextSecondary)
                                }
                            }
                        }
                    }
                }

                // Live Resizing Dimension Pill (Displayed while user drags corner)
                if (isResizing) {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = Color(0xEE000000),
                        border = BorderStroke(1.dp, AmberAccent),
                        modifier = Modifier
                            .align(Alignment.TopCenter)
                            .padding(top = 6.dp)
                    ) {
                        Text(
                            text = "${windowWidthDp.roundToInt()} × ${windowHeightDp.roundToInt()} dp",
                            color = AmberAccent,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                        )
                    }
                }

                // Bottom-Right Corner Resize Drag Handle
                val handleGripColor = if (isResizing) AmberAccent else SleekPurpleLight.copy(alpha = 0.8f)
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .size(36.dp)
                        .clip(RoundedCornerShape(bottomEnd = 18.dp))
                        .background(
                            if (isResizing) AmberAccent.copy(alpha = 0.25f)
                            else Color.White.copy(alpha = 0.03f)
                        )
                        .then(resizeCornerModifier)
                        .testTag("floating_settings_resize_handle"),
                    contentAlignment = Alignment.BottomEnd
                ) {
                    Canvas(
                        modifier = Modifier
                            .size(20.dp)
                            .padding(end = 4.dp, bottom = 4.dp)
                    ) {
                        val strokeW = 2.dp.toPx()
                        // Diagonal corner grip stripes
                        drawLine(
                            color = handleGripColor,
                            start = Offset(size.width, size.height * 0.25f),
                            end = Offset(size.width * 0.25f, size.height),
                            strokeWidth = strokeW,
                            cap = androidx.compose.ui.graphics.StrokeCap.Round
                        )
                        drawLine(
                            color = handleGripColor,
                            start = Offset(size.width, size.height * 0.60f),
                            end = Offset(size.width * 0.60f, size.height),
                            strokeWidth = strokeW,
                            cap = androidx.compose.ui.graphics.StrokeCap.Round
                        )
                    }
                }
            }
        }
    }

    // Developer Decoder Report Dialog
    if (showReportDialog) {
        val fullReport = remember { onGenerateReport() }
        androidx.compose.ui.window.Dialog(onDismissRequest = { showReportDialog = false }) {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = SleekCardDark,
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.15f)),
                modifier = Modifier.fillMaxWidth().padding(16.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "DEVELOPER DECODER REPORT",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, color = SleekTextPrimary)
                        )
                        IconButton(onClick = { showReportDialog = false }, modifier = Modifier.size(24.dp)) {
                            Icon(Icons.Default.Close, contentDescription = "Close", tint = SleekTextSecondary)
                        }
                    }
                    HorizontalDivider(color = Color.White.copy(alpha = 0.1f))
                    Box(
                        modifier = Modifier
                            .heightIn(max = 380.dp)
                            .fillMaxWidth()
                            .background(Color.Black.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                            .padding(8.dp)
                    ) {
                        LazyColumn {
                            item {
                                Text(
                                    text = fullReport,
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                                        fontSize = 11.sp,
                                        color = Color.Green.copy(alpha = 0.9f)
                                    )
                                )
                            }
                        }
                    }
                    Button(
                        onClick = {
                            com.example.media.playback.CodecReportGenerator.copyReportToClipboard(context, fullReport)
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF2563EB),
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("copy_codec_report_dialog_button")
                    ) {
                        Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("COPY CODEC REPORT", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun Matrix9x9Tile(
    icon: ImageVector,
    title: String,
    value: String,
    isActive: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = if (isActive) SleekPurpleDark.copy(alpha = 0.35f) else Color.White.copy(alpha = 0.04f),
        border = BorderStroke(
            1.dp,
            if (isActive) SleekPurpleLight.copy(alpha = 0.6f) else Color.White.copy(alpha = 0.08f)
        ),
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .clickable(onClick = onClick)
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 4.dp, vertical = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = if (isActive) SleekPurpleLight else SleekTextSecondary,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.height(3.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.labelSmall.copy(
                    fontSize = 9.5.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isActive) Color.White else SleekTextSecondary
                ),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = value,
                style = MaterialTheme.typography.labelSmall.copy(
                    fontSize = 8.5.sp,
                    color = if (isActive) Color(0xFFFFAB40) else SleekTextSecondary.copy(alpha = 0.7f)
                ),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun AdvancedPlayerSettingsSheetContent(
    hardwareAccelerationMode: String,
    onHardwareAccelerationModeChanged: (String) -> Unit,
    audioPassthroughMode: String,
    onAudioPassthroughModeChanged: (String) -> Unit,
    codecInfo: PlaybackCodecInfo,
    onGenerateReport: () -> String,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp)
            .padding(bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        // Header Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .background(SleekPurpleLight.copy(alpha = 0.2f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Tune,
                        contentDescription = null,
                        tint = SleekPurpleLight,
                        modifier = Modifier.size(20.dp)
                    )
                }
                Column {
                    Text(
                        text = "ADVANCED PLAYER SETTINGS",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = SleekTextPrimary
                        )
                    )
                    Text(
                        text = "Live Media3 Engine Configuration (No Playback Interruption)",
                        style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                        color = SleekTextSecondary
                    )
                }
            }
            IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = "Close",
                    tint = SleekTextSecondary,
                    modifier = Modifier.size(18.dp)
                )
            }
        }

        HorizontalDivider(color = Color.White.copy(alpha = 0.1f))

        // 1. Hardware Acceleration Mode
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Speed,
                    contentDescription = null,
                    tint = SleekPurpleLight,
                    modifier = Modifier.size(18.dp)
                )
                Text(
                    text = "Hardware Acceleration",
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                    color = SleekTextPrimary
                )
            }
            Text(
                text = "GPU surface tunneling and MediaCodec HW decoding priority",
                style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                color = SleekTextSecondary
            )
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.White.copy(alpha = 0.04f), RoundedCornerShape(12.dp))
                    .padding(4.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                listOf("Auto", "On", "Off").forEach { mode ->
                    val isSelected = hardwareAccelerationMode.equals(mode, ignoreCase = true)
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (isSelected) SleekPurpleLight else Color.Transparent)
                            .clickable { onHardwareAccelerationModeChanged(mode) }
                            .padding(vertical = 10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = mode,
                            color = if (isSelected) Color.White else SleekTextSecondary,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            fontSize = 13.sp
                        )
                    }
                }
            }
        }

        // 2. Audio Passthrough Mode
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.SurroundSound,
                    contentDescription = null,
                    tint = SleekPurpleLight,
                    modifier = Modifier.size(18.dp)
                )
                Text(
                    text = "Audio Passthrough",
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                    color = SleekTextPrimary
                )
            }
            Text(
                text = "Route surround multi-channel streams directly or downmix to 2ch PCM",
                style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                color = SleekTextSecondary
            )
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.White.copy(alpha = 0.04f), RoundedCornerShape(12.dp))
                    .padding(4.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                listOf("Auto", "On", "Off").forEach { mode ->
                    val isSelected = audioPassthroughMode.equals(mode, ignoreCase = true)
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (isSelected) SleekPurpleLight else Color.Transparent)
                            .clickable { onAudioPassthroughModeChanged(mode) }
                            .padding(vertical = 10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = mode,
                            color = if (isSelected) Color.White else SleekTextSecondary,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            fontSize = 13.sp
                        )
                    }
                }
            }
        }

        // 3. Live Media3 Decoder & Codec Info Card
        Surface(
            shape = RoundedCornerShape(14.dp),
            color = Color.White.copy(alpha = 0.03f),
            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.08f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Memory,
                        contentDescription = null,
                        tint = SleekPurpleLight,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = "LIVE MEDIA3 ENGINE STATUS",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = SleekPurpleLight
                        )
                    )
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Video Decoder:", style = MaterialTheme.typography.labelSmall, color = SleekTextSecondary)
                    Text(codecInfo.videoDecoder, style = MaterialTheme.typography.labelSmall, color = SleekTextPrimary, fontWeight = FontWeight.Bold)
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Video Format / Res:", style = MaterialTheme.typography.labelSmall, color = SleekTextSecondary)
                    Text("${codecInfo.videoMime} (${codecInfo.videoResolution})", style = MaterialTheme.typography.labelSmall, color = SleekTextPrimary)
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Audio Decoder:", style = MaterialTheme.typography.labelSmall, color = SleekTextSecondary)
                    Text(codecInfo.audioDecoder, style = MaterialTheme.typography.labelSmall, color = SleekTextPrimary, fontWeight = FontWeight.Bold)
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Audio Format / Channels:", style = MaterialTheme.typography.labelSmall, color = SleekTextSecondary)
                    Text("${codecInfo.audioMime} / ${codecInfo.audioChannels}", style = MaterialTheme.typography.labelSmall, color = SleekTextPrimary)
                }

                var showFullReportDialog by remember { mutableStateOf(false) }

                Button(
                    onClick = { showFullReportDialog = true },
                    colors = ButtonDefaults.buttonColors(containerColor = SleekPurpleLight.copy(alpha = 0.2f)),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth().padding(top = 4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.BugReport,
                        contentDescription = null,
                        tint = SleekPurpleLight,
                        modifier = Modifier.size(16.dp).padding(end = 4.dp)
                    )
                    Text(
                        text = "VIEW RUNTIME DECODER REPORT",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = SleekPurpleLight)
                    )
                }

                if (showFullReportDialog) {
                    val fullReport = remember { onGenerateReport() }
                    androidx.compose.ui.window.Dialog(onDismissRequest = { showFullReportDialog = false }) {
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = SleekCardDark,
                            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.15f)),
                            modifier = Modifier.fillMaxWidth().padding(16.dp)
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "DEVELOPER DECODER REPORT",
                                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, color = SleekTextPrimary)
                                    )
                                    IconButton(onClick = { showFullReportDialog = false }, modifier = Modifier.size(24.dp)) {
                                        Icon(Icons.Default.Close, contentDescription = "Close", tint = SleekTextSecondary)
                                    }
                                }
                                HorizontalDivider(color = Color.White.copy(alpha = 0.1f))
                                Box(
                                    modifier = Modifier
                                        .heightIn(max = 400.dp)
                                        .fillMaxWidth()
                                        .background(Color.Black.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                                        .padding(8.dp)
                                ) {
                                    LazyColumn {
                                        item {
                                            Text(
                                                text = fullReport,
                                                style = MaterialTheme.typography.bodySmall.copy(
                                                    fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                                                    fontSize = 11.sp,
                                                    color = Color.Green.copy(alpha = 0.9f)
                                                )
                                            )
                                        }
                                    }
                                }
                                Button(
                                    onClick = {
                                        com.example.media.playback.CodecReportGenerator.copyReportToClipboard(context, fullReport)
                                    },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = Color(0xFF2563EB),
                                        contentColor = Color.White
                                    ),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("copy_codec_report_full_dialog_button")
                                ) {
                                    Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("COPY CODEC REPORT", fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun isAudioFormat(fmt: VideoFormatUi): Boolean {
    val type = fmt.type.lowercase()
    val qual = fmt.quality.lowercase()
    val ext = fmt.ext.lowercase()
    return type == "audio" || 
           (fmt.vcodec == "none" && fmt.acodec != null && fmt.acodec != "none") ||
           qual.contains("kbps") || qual.contains("audio") ||
           ext == "mp3" || ext == "m4a" || ext == "aac" || ext == "opus" || ext == "wav" || ext == "flac" || ext == "ogg"
}

@Composable
fun FloatingPlayerOverlay(
    media: DownloadEntity,
    isFullscreen: Boolean,
    onToggleFullscreen: () -> Unit,
    onClose: () -> Unit,
    analyzedVideo: AnalyzedVideo? = null,
    onStreamFormat: ((VideoFormatUi) -> Unit)? = null,
    viewModel: VideoDownloaderViewModel? = null,
    onOpenAudioFxStudio: (() -> Unit)? = null
) {
    val isAudio = isAudioMedia(media)

    if (isAudio) {
        SleekAudioMusicPlayer(
            media = media,
            isFullscreen = isFullscreen,
            onToggleFullscreen = onToggleFullscreen,
            onClose = onClose,
            viewModel = viewModel
        )
    } else {
        SleekVideoPlayerOverlay(
            media = media,
            isFullscreen = isFullscreen,
            onToggleFullscreen = onToggleFullscreen,
            onClose = onClose,
            analyzedVideo = analyzedVideo,
            onStreamFormat = onStreamFormat,
            viewModel = viewModel,
            onOpenAudioFxStudio = onOpenAudioFxStudio
        )
    }
}

@Composable
fun FolderPickerDialog(
    initialDir: String,
    onDismiss: () -> Unit,
    onFolderSelected: (String) -> Unit
) {
    val rootDir = android.os.Environment.getExternalStorageDirectory() ?: java.io.File("/storage/emulated/0")
    var currentDir by remember {
        mutableStateOf(
            if (initialDir.isNotEmpty()) {
                val f = java.io.File(initialDir)
                if (f.exists() && f.isDirectory) f else rootDir
            } else {
                rootDir
            }
        )
    }

    var subfolders by remember(currentDir) {
        mutableStateOf(
            try {
                currentDir.listFiles { file -> file.isDirectory }?.toList()?.sortedBy { it.name.lowercase() } ?: emptyList()
            } catch (e: Exception) {
                emptyList()
            }
        )
    }

    var showCreateFolderDialog by remember { mutableStateOf(false) }
    var newFolderName by remember { mutableStateOf("") }

    if (showCreateFolderDialog) {
        AlertDialog(
            onDismissRequest = { showCreateFolderDialog = false },
            title = { Text("Create New Folder", fontWeight = FontWeight.Bold, color = SleekTextPrimary) },
            text = {
                OutlinedTextField(
                    value = newFolderName,
                    onValueChange = { newFolderName = it },
                    label = { Text("Folder Name", color = SleekTextSecondary) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = SleekTextPrimary,
                        unfocusedTextColor = SleekTextPrimary,
                        focusedContainerColor = Color.Transparent,
                        unfocusedContainerColor = Color.Transparent,
                        focusedBorderColor = SleekPurpleLight,
                        unfocusedBorderColor = SleekBorderColor
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        if (newFolderName.isNotBlank()) {
                            val newDir = java.io.File(currentDir, newFolderName.trim())
                            try {
                                if (!newDir.exists()) {
                                    newDir.mkdirs()
                                    // Refresh subfolders list
                                    subfolders = currentDir.listFiles { file -> file.isDirectory }?.toList()?.sortedBy { it.name.lowercase() } ?: emptyList()
                                }
                            } catch (e: Exception) {
                                // Ignore
                            }
                        }
                        newFolderName = ""
                        showCreateFolderDialog = false
                    }
                ) {
                    Icon(Icons.Default.CreateNewFolder, contentDescription = "Create", tint = SleekPurpleLight)
                }
            },
            dismissButton = {
                TextButton(onClick = { showCreateFolderDialog = false }) {
                    Icon(Icons.Default.Close, contentDescription = "Cancel", tint = SleekTextSecondary)
                }
            },
            containerColor = SleekCard,
            titleContentColor = SleekTextPrimary,
            textContentColor = SleekTextSecondary,
            shape = RoundedCornerShape(24.dp)
        )
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Select Download Folder", fontWeight = FontWeight.Bold, color = SleekTextPrimary, style = MaterialTheme.typography.titleLarge)
                Text(
                    text = currentDir.absolutePath,
                    style = MaterialTheme.typography.bodySmall.copy(fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace),
                    color = SleekPurpleLight,
                    maxLines = 2,
                    overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                )
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(320.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Back button to go parent
                    TextButton(
                        onClick = {
                            val parent = currentDir.parentFile
                            if (parent != null && parent.exists()) {
                                currentDir = parent
                            }
                        },
                        enabled = currentDir.absolutePath != "/"
                    ) {
                        // Use ArrowForward with 180 degree rotation to get a back arrow safely
                        Icon(
                            imageVector = Icons.Default.ArrowForward,
                            contentDescription = "Up",
                            tint = if (currentDir.absolutePath != "/") SleekPurpleLight else SleekTextMuted,
                            modifier = Modifier
                                .size(20.dp)
                                .rotate(180f)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Go Up", fontWeight = FontWeight.Bold, color = if (currentDir.absolutePath != "/") SleekPurpleLight else SleekTextMuted)
                    }

                    // Create new folder button
                    IconButton(
                        onClick = { showCreateFolderDialog = true }
                    ) {
                        Icon(Icons.Default.Add, contentDescription = "Create New Folder", tint = SleekPurpleLight)
                    }
                }

                HorizontalDivider(color = SleekBorderColor.copy(alpha = 0.3f))

                if (subfolders.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth(),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("No subfolders here", color = SleekTextSecondary, style = MaterialTheme.typography.bodyMedium)
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        items(subfolders) { folder ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { currentDir = folder }
                                    .padding(vertical = 10.dp, horizontal = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Folder,
                                    contentDescription = null,
                                    tint = SleekPurpleLight,
                                    modifier = Modifier.size(24.dp)
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Text(
                                    text = folder.name,
                                    color = SleekTextPrimary,
                                    style = MaterialTheme.typography.bodyMedium,
                                    maxLines = 1,
                                    overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onFolderSelected(currentDir.absolutePath) },
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color.White,
                    contentColor = Color.Black
                )
            ) {
                Icon(Icons.Default.Check, contentDescription = "Select This Folder")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Icon(Icons.Default.Close, contentDescription = "Cancel", tint = SleekTextSecondary)
            }
        },
        containerColor = SleekCard,
        shape = RoundedCornerShape(24.dp)
    )
}

@Composable
fun responsiveSp(min: Float, max: Float): androidx.compose.ui.unit.TextUnit {
    val configuration = androidx.compose.ui.platform.LocalConfiguration.current
    val screenWidth = configuration.screenWidthDp
    val fraction = ((screenWidth - 360f) / (1200f - 360f)).coerceIn(0f, 1f)
    val size = min + (max - min) * fraction
    return size.sp
}

@Composable
fun LiquidGlassIcon(
    imageVector: androidx.compose.ui.graphics.vector.ImageVector,
    contentDescription: String?,
    modifier: Modifier = Modifier,
    isSelected: Boolean = false,
    size: Dp = 28.dp,
    containerSize: Dp = 52.dp,
    onClick: (() -> Unit)? = null
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val isHovered by interactionSource.collectIsHoveredAsState()
    
    val scale by animateFloatAsState(
        targetValue = if (isPressed) 0.96f else if (isHovered) 1.04f else 1.0f,
        animationSpec = spring(dampingRatio = 0.8f, stiffness = 400f),
        label = "LiquidIconScale"
    )
    
    val glowIntensity by animateFloatAsState(
        targetValue = if (isSelected) 0.8f else if (isHovered) 0.4f else 0.15f,
        animationSpec = tween(300),
        label = "GlowIntensity"
    )

    val shadowElevation by animateDpAsState(
        targetValue = if (isSelected) 12.dp else if (isHovered) 8.dp else 4.dp,
        label = "GlowShadow"
    )

    val view = androidx.compose.ui.platform.LocalView.current
    Box(
        modifier = modifier
            .scale(scale)
            .size(containerSize)
            .shadow(
                elevation = shadowElevation,
                shape = CircleShape,
                spotColor = Color(0xFFFF7A00).copy(alpha = glowIntensity),
                ambientColor = Color(0xFFFF9D33).copy(alpha = glowIntensity)
            )
            .clip(CircleShape)
            .background(
                brush = if (isSelected) {
                    Brush.verticalGradient(
                        colors = listOf(Color(0xFFFF9D33), Color(0xFFFF7A00))
                    )
                } else {
                    Brush.verticalGradient(
                        colors = listOf(Color(0x33FFFFFF), Color(0x0FFFFFFF))
                    )
                }
            )
            .drawBehind {
                drawOval(
                    color = Color.White.copy(alpha = 0.35f),
                    topLeft = androidx.compose.ui.geometry.Offset(containerSize.toPx() * 0.25f, containerSize.toPx() * 0.1f),
                    size = Size(containerSize.toPx() * 0.5f, containerSize.toPx() * 0.2f)
                )
                drawCircle(
                    color = Color.Black.copy(alpha = 0.25f),
                    radius = containerSize.toPx() / 2f,
                    style = Stroke(width = 1.dp.toPx())
                )
            }
            .border(
                width = 1.2.dp,
                brush = if (isSelected) {
                    Brush.linearGradient(
                        colors = listOf(Color(0xFFFFFFFF).copy(alpha = 0.8f), Color(0xFFFF9D33).copy(alpha = 0.3f))
                    )
                } else {
                    Brush.verticalGradient(
                        colors = listOf(Color.White.copy(alpha = 0.3f), Color.White.copy(alpha = 0.05f))
                    )
                },
                shape = CircleShape
            )
            .let {
                if (onClick != null) {
                    it.clickable(
                        interactionSource = interactionSource,
                        indication = null,
                        onClick = {
                            triggerClickHaptic(view)
                            onClick()
                        }
                    )
                } else it
            },
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = imageVector,
            contentDescription = contentDescription,
            tint = if (isSelected) Color.White else Color(0xFFFF9D33).copy(alpha = 0.85f),
            modifier = Modifier
                .size(size)
                .offset(y = (0.5).dp)
        )
    }
}

@Composable
fun LiquidGlassButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    text: String = "",
    icon: androidx.compose.ui.graphics.vector.ImageVector? = null,
    isSecondary: Boolean = false,
    height: Dp = 56.dp
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val isHovered by interactionSource.collectIsHoveredAsState()

    val scale by animateFloatAsState(
        targetValue = if (!enabled) 1.0f else if (isPressed) 0.96f else if (isHovered) 1.04f else 1.0f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioLowBouncy, stiffness = Spring.StiffnessMedium),
        label = "ButtonScale"
    )

    val shadowElevation by animateDpAsState(
        targetValue = if (isPressed) 2.dp else if (isHovered) 14.dp else 4.dp,
        label = "ButtonGlow"
    )

    val glowAlpha by animateFloatAsState(
        targetValue = if (isPressed) 0.2f else if (isHovered) 0.7f else 0.35f,
        label = "ButtonGlowAlpha"
    )

    val view = androidx.compose.ui.platform.LocalView.current
    Box(
        modifier = modifier
            .scale(scale)
            .height(height)
            .shadow(
                elevation = if (enabled && !isSecondary) shadowElevation else 0.dp,
                shape = RoundedCornerShape(24.dp),
                spotColor = Color(0xFFFF7A00).copy(alpha = glowAlpha),
                ambientColor = Color(0xFFFF9D33).copy(alpha = glowAlpha)
            )
            .clip(RoundedCornerShape(24.dp))
            .background(
                brush = if (isSecondary) {
                    Brush.verticalGradient(
                        colors = listOf(Color(0x24FFFFFF), Color(0x0FFFFFFF))
                    )
                } else {
                    Brush.verticalGradient(
                        colors = listOf(Color(0xFFFF9D33), Color(0xFFFF7A00))
                    )
                },
                alpha = if (enabled) 1f else 0.5f
            )
            .border(
                width = 1.2.dp,
                brush = if (isSecondary) {
                    Brush.verticalGradient(
                        colors = listOf(Color.White.copy(alpha = 0.2f), Color.White.copy(alpha = 0.05f))
                    )
                } else {
                    Brush.verticalGradient(
                        colors = listOf(Color.White.copy(alpha = 0.35f), Color.White.copy(alpha = 0.1f))
                    )
                },
                shape = RoundedCornerShape(24.dp)
            )
            .clickable(
                enabled = enabled,
                interactionSource = interactionSource,
                indication = null,
                onClick = {
                    triggerClickHaptic(view)
                    onClick()
                }
            ),
        contentAlignment = Alignment.Center
    ) {
        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 24.dp)
        ) {
            if (icon != null) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = if (isSecondary) Color(0xFFFF9D33) else Color.White,
                    modifier = Modifier.size(20.dp)
                )
            }
            if (text.isNotEmpty()) {
                Text(
                    text = text,
                    style = MaterialTheme.typography.titleSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        fontSize = 15.sp,
                        letterSpacing = 0.25.sp
                    )
                )
            }
        }
    }
}

data class CoverflowItem(
    val title: String,
    val creator: String,
    val resolution: String,
    val size: String,
    val duration: String,
    val url: String,
    val thumbnailUrl: String
)

private fun customLerp(start: Float, stop: Float, fraction: Float): Float {
    return start + fraction * (stop - start)
}

@Composable
fun CoverflowCarousel(
    onPlayClick: (CoverflowItem) -> Unit,
    onDownloadClick: (CoverflowItem) -> Unit,
    modifier: Modifier = Modifier
) {
    val items = remember {
        listOf(
            CoverflowItem(
                title = "Dune: Part Two (Official Trailer)",
                creator = "Warner Bros. Pictures",
                resolution = "4K HDR",
                size = "184 MB",
                duration = "3:02",
                url = "https://www.youtube.com/watch?v=Way9Dexky3w",
                thumbnailUrl = "https://images.unsplash.com/photo-1547483238-f400e65ccd56?auto=format&fit=crop&q=80&w=600"
            ),
            CoverflowItem(
                title = "Cyberpunk 2077: Phantom Liberty Cinematic Trailer",
                creator = "CD PROJEKT RED",
                resolution = "1080p 60fps",
                size = "142 MB",
                duration = "2:15",
                url = "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
                thumbnailUrl = "https://images.unsplash.com/photo-1578632767115-351597cf2477?auto=format&fit=crop&q=80&w=600"
            ),
            CoverflowItem(
                title = "Nothing OS 3.0 Concept Showcase",
                creator = "Nothing Tech",
                resolution = "4K Ultra",
                size = "68 MB",
                duration = "1:45",
                url = "https://www.youtube.com/watch?v=O12_7QZfKoo",
                thumbnailUrl = "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&q=80&w=600"
            ),
            CoverflowItem(
                title = "Interstellar - No Time For Caution Live Orchestra",
                creator = "Hans Zimmer",
                resolution = "1440p",
                size = "95 MB",
                duration = "4:02",
                url = "https://www.youtube.com/watch?v=m3zvVGJR9ic",
                thumbnailUrl = "https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&q=80&w=600"
            )
        )
    }

    val pagerState = rememberPagerState(initialPage = 1000, pageCount = { 2000 })

    val configuration = androidx.compose.ui.platform.LocalConfiguration.current
    val screenWidth = configuration.screenWidthDp
    val isMobile = screenWidth < 600

    val carouselHeight = if (isMobile) 320.dp else 440.dp
    val contentPadding = if (isMobile) PaddingValues(horizontal = 44.dp) else PaddingValues(horizontal = 140.dp)

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(carouselHeight),
        contentAlignment = Alignment.Center
    ) {
        HorizontalPager(
            state = pagerState,
            modifier = Modifier.fillMaxSize(),
            contentPadding = contentPadding,
            verticalAlignment = Alignment.CenterVertically
        ) { page ->
            val actualIndex = page % items.size
            val item = items[actualIndex]

            val pageOffset = ((pagerState.currentPage - page) + pagerState.currentPageOffsetFraction)
            val absOffset = kotlin.math.abs(pageOffset)

            val scale = customLerp(0.88f, 1.0f, (1f - absOffset).coerceIn(0f, 1f))
            val rotationY = pageOffset * -14f
            val opacity = customLerp(0.65f, 1.0f, (1f - absOffset).coerceIn(0f, 1f))
            val elevation = customLerp(4f, 20f, (1f - absOffset).coerceIn(0f, 1f)).dp
            val blurPx = customLerp(3f, 0f, (1f - absOffset).coerceIn(0f, 1f)).dp

            val cardModifier = if (isMobile) {
                Modifier
                    .fillMaxWidth()
                    .height(280.dp)
            } else {
                Modifier
                    .width(420.dp)
                    .height(380.dp)
            }

            val cardPadding = if (isMobile) 14.dp else 20.dp
            val playButtonSize = if (isMobile) 56.dp else 72.dp
            val playIconSize = if (isMobile) 28.dp else 36.dp
            val playOffsetY = if (isMobile) (-15).dp else (-30).dp
            val titleFontSize = if (isMobile) 15.sp else 18.sp
            val titleLineHeight = if (isMobile) 19.sp else 22.sp
            val creatorLetterSpacing = if (isMobile) 0.8.sp else 1.2.sp
            val buttonHeight = if (isMobile) 40.dp else 48.dp

            Card(
                modifier = cardModifier
                    .graphicsLayer {
                        scaleX = scale
                        scaleY = scale
                        this.rotationY = rotationY
                        this.alpha = opacity
                        shadowElevation = elevation.toPx()
                        cameraDistance = 12 * density
                    }
                    .let {
                        if (absOffset > 0.01f) {
                            it.blur(blurPx)
                        } else it
                    },
                shape = RoundedCornerShape(if (isMobile) 22.dp else 30.dp),
                border = BorderStroke(1.2.dp, Color.White.copy(alpha = if (absOffset < 0.2f) 0.18f else 0.08f)),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF111216))
            ) {
                Box(modifier = Modifier.fillMaxSize()) {
                    AsyncImage(
                        model = item.thumbnailUrl,
                        contentDescription = item.title,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .fillMaxSize()
                            .drawWithContent {
                                drawContent()
                                drawRect(
                                    brush = Brush.verticalGradient(
                                        colors = listOf(Color.White.copy(alpha = 0.08f), Color.Transparent, Color.Black.copy(alpha = 0.85f))
                                    )
                                )
                            }
                    )

                    Box(
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(if (isMobile) 12.dp else 16.dp)
                            .background(Color(0x33000000), RoundedCornerShape(12.dp))
                            .border(1.dp, Color.White.copy(alpha = 0.15f), RoundedCornerShape(12.dp))
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = item.duration,
                            color = Color.White,
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold)
                        )
                    }

                    Box(
                        modifier = Modifier
                            .align(Alignment.Center)
                            .offset(y = playOffsetY)
                            .size(playButtonSize)
                            .shadow(
                                elevation = 16.dp,
                                shape = CircleShape,
                                spotColor = Color(0xFFFF7A00).copy(alpha = 0.6f),
                                ambientColor = Color(0xFFFF9D33).copy(alpha = 0.6f)
                            )
                            .clip(CircleShape)
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(Color(0xFFFF9D33), Color(0xFFFF7A00))
                                )
                            )
                            .border(1.2.dp, Color.White.copy(alpha = 0.35f), CircleShape)
                            .clickable { onPlayClick(item) },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = androidx.compose.material.icons.Icons.Default.PlayArrow,
                            contentDescription = "Play",
                            tint = Color.White,
                            modifier = Modifier.size(playIconSize)
                        )
                    }

                    Column(
                        modifier = Modifier
                            .align(Alignment.BottomStart)
                            .fillMaxWidth()
                            .padding(cardPadding),
                        verticalArrangement = Arrangement.spacedBy(if (isMobile) 8.dp else 12.dp)
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Text(
                                text = item.creator.uppercase(),
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = Color(0xFFFF9D33),
                                    fontWeight = FontWeight.ExtraBold,
                                    letterSpacing = creatorLetterSpacing
                                )
                            )
                            Text(
                                text = item.title,
                                style = MaterialTheme.typography.titleMedium.copy(
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = titleFontSize,
                                    lineHeight = titleLineHeight
                                ),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            LiquidGlassButton(
                                onClick = { onPlayClick(item) },
                                modifier = Modifier.weight(1f),
                                icon = androidx.compose.material.icons.Icons.Default.PlayArrow,
                                isSecondary = true,
                                height = buttonHeight
                            )
                            LiquidGlassButton(
                                onClick = { onDownloadClick(item) },
                                modifier = Modifier.weight(1f),
                                icon = androidx.compose.material.icons.Icons.Default.ArrowDownward,
                                isSecondary = false,
                                height = buttonHeight
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CrazyAnimationOrb() {
    CyberneticDownloadVisualizer()
}

@Composable
fun CyberneticDownloadVisualizer(
    modifier: Modifier = Modifier
) {
    var isBoosted by remember { mutableStateOf(false) }
    val infiniteTransition = rememberInfiniteTransition(label = "cyber_download_engine")

    // Rotation rates
    val rotationSlow by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(if (isBoosted) 3000 else 8000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotationSlow"
    )

    val rotationFast by infiniteTransition.animateFloat(
        initialValue = 360f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(if (isBoosted) 2000 else 5000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotationFast"
    )

    // Pulse & energy surge
    val energyPulse by infiniteTransition.animateFloat(
        initialValue = 0.92f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "energyPulse"
    )

    // Vertical arrow trajectory bounce & plunge
    val arrowFloatOffset by infiniteTransition.animateFloat(
        initialValue = -10f,
        targetValue = 10f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "arrowFloatOffset"
    )

    // Expanding ripple waves
    val waveProgress by infiniteTransition.animateFloat(
        initialValue = 0.2f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1600, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "waveProgress"
    )

    val particleFlow by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1400, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "particleFlow"
    )

    // Reset boost after 3 seconds
    LaunchedEffect(isBoosted) {
        if (isBoosted) {
            delay(3000)
            isBoosted = false
        }
    }

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier
            .fillMaxWidth()
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null
            ) {
                isBoosted = true
            }
    ) {
        // Main Futuristic Download Graphic Core
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .size(190.dp)
                .padding(6.dp)
        ) {
            // Ambient Radial Backdrop Bloom
            Canvas(modifier = Modifier.fillMaxSize()) {
                val centerOffset = Offset(size.width / 2f, size.height / 2f)
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            Color(0x55FF7A00),
                            Color(0x33A855F7),
                            Color(0x1100E5FF),
                            Color.Transparent
                        ),
                        center = centerOffset,
                        radius = size.width * 0.48f * energyPulse
                    ),
                    radius = size.width * 0.48f * energyPulse,
                    center = centerOffset
                )

                // Expanding ultrasonic download pulse wave
                val waveRadius = (size.width * 0.25f) + (size.width * 0.22f * waveProgress)
                val waveAlpha = (1f - waveProgress).coerceIn(0f, 1f) * 0.65f
                drawCircle(
                    color = Color(0xFFFF9D33).copy(alpha = waveAlpha),
                    radius = waveRadius,
                    center = centerOffset,
                    style = androidx.compose.ui.graphics.drawscope.Stroke(
                        width = 2.dp.toPx(),
                        pathEffect = androidx.compose.ui.graphics.PathEffect.dashPathEffect(floatArrayOf(15f, 10f), 0f)
                    )
                )

                // High-Tech Outer Tachometer Dashed Arc Segments
                val strokeW = 2.5.dp.toPx()
                val outerRadius = size.width * 0.42f
                val dashCount = 24
                for (i in 0 until dashCount) {
                    val angleDeg = (i * (360f / dashCount)) + rotationSlow
                    val angleRad = Math.toRadians(angleDeg.toDouble())
                    val isMajor = i % 4 == 0
                    val innerR = if (isMajor) outerRadius - 10.dp.toPx() else outerRadius - 5.dp.toPx()
                    val start = Offset(
                        (centerOffset.x + innerR * kotlin.math.cos(angleRad)).toFloat(),
                        (centerOffset.y + innerR * kotlin.math.sin(angleRad)).toFloat()
                    )
                    val end = Offset(
                        (centerOffset.x + outerRadius * kotlin.math.cos(angleRad)).toFloat(),
                        (centerOffset.y + outerRadius * kotlin.math.sin(angleRad)).toFloat()
                    )
                    val segColor = if (isMajor) Color(0xFFFF7A00).copy(alpha = 0.9f) else Color(0xFF8B1E2D).copy(alpha = 0.4f)
                    drawLine(
                        color = segColor,
                        start = start,
                        end = end,
                        strokeWidth = if (isMajor) 2.dp.toPx() else 1.2.dp.toPx(),
                        cap = androidx.compose.ui.graphics.StrokeCap.Round
                    )
                }

                // Orbiting Energy Particle Nodes
                val orbitCount = 4
                for (i in 0 until orbitCount) {
                    val angle = Math.toRadians(((i * 90f) + rotationFast).toDouble())
                    val pX = (centerOffset.x + (outerRadius * 0.92f) * kotlin.math.cos(angle)).toFloat()
                    val pY = (centerOffset.y + (outerRadius * 0.92f) * kotlin.math.sin(angle)).toFloat()
                    drawCircle(
                        color = if (i % 2 == 0) Color(0xFF00E5FF) else Color(0xFFFFD54F),
                        radius = 3.5.dp.toPx(),
                        center = Offset(pX, pY)
                    )
                    drawCircle(
                        color = (if (i % 2 == 0) Color(0xFF00E5FF) else Color(0xFFFFD54F)).copy(alpha = 0.35f),
                        radius = 7.dp.toPx(),
                        center = Offset(pX, pY)
                    )
                }

                // Streaming Vertical Quantum Data Beams (Falling into core)
                val beamCount = 6
                for (b in 0 until beamCount) {
                    val relX = (b - 2.5f) * 16.dp.toPx()
                    val beamX = centerOffset.x + relX
                    val flowOffset = (particleFlow * 40.dp.toPx() + b * 10f) % 40.dp.toPx()
                    val beamStartY = centerOffset.y - 38.dp.toPx() + flowOffset
                    val beamEndY = beamStartY + 14.dp.toPx()
                    val beamAlpha = (1f - (beamEndY - (centerOffset.y - 38.dp.toPx())) / 40.dp.toPx()).coerceIn(0.1f, 0.8f)
                    drawLine(
                        brush = Brush.verticalGradient(
                            colors = listOf(Color.Transparent, Color(0xFFFF9D33).copy(alpha = beamAlpha), Color.White.copy(alpha = beamAlpha))
                        ),
                        start = Offset(beamX, beamStartY),
                        end = Offset(beamX, beamEndY),
                        strokeWidth = 2.dp.toPx(),
                        cap = androidx.compose.ui.graphics.StrokeCap.Round
                    )
                }
            }

            // Outer Neon Dual Orbit Ring
            Box(
                modifier = Modifier
                    .size(136.dp)
                    .graphicsLayer {
                        rotationZ = rotationSlow
                        scaleX = energyPulse
                        scaleY = energyPulse
                    }
                    .border(
                        width = 1.5.dp,
                        brush = Brush.sweepGradient(
                            colors = listOf(
                                Color(0xFFFF7A00),
                                Color(0xFFA855F7),
                                Color(0xFF00E5FF),
                                Color(0xFFFF9D33),
                                Color(0xFFFF7A00)
                            )
                        ),
                        shape = CircleShape
                    )
            )

            // Inner Counter-Rotating Hexagonal Glass Hull
            Box(
                modifier = Modifier
                    .size(108.dp)
                    .graphicsLayer {
                        rotationZ = rotationFast
                    }
                    .background(
                        brush = Brush.radialGradient(
                            colors = listOf(
                                Color(0x3DFF7A00),
                                Color(0x24111216),
                                Color(0x05000000)
                            )
                        ),
                        shape = CircleShape
                    )
                    .border(
                        width = 1.2.dp,
                        brush = Brush.sweepGradient(
                            colors = listOf(
                                Color(0x9900E5FF),
                                Color(0x22FFFFFF),
                                Color(0x99FFA800),
                                Color(0x22FFFFFF),
                                Color(0x9900E5FF)
                            )
                        ),
                        shape = CircleShape
                    )
            )

            // Central Glowing Reactor Core Vessel
            Box(
                modifier = Modifier
                    .size(76.dp)
                    .graphicsLayer {
                        scaleX = energyPulse
                        scaleY = energyPulse
                    }
                    .shadow(
                        elevation = 16.dp,
                        shape = CircleShape,
                        spotColor = Color(0xFFFF7A00).copy(alpha = 0.6f)
                    )
                    .background(
                        brush = Brush.radialGradient(
                            colors = listOf(
                                Color(0xFFFF8A00),
                                Color(0xFF8B1E2D),
                                Color(0xFF1E1318)
                            )
                        ),
                        shape = CircleShape
                    )
                    .border(
                        width = 1.5.dp,
                        brush = Brush.linearGradient(
                            colors = listOf(Color(0xFFFFD54F), Color(0xFFFF7A00).copy(alpha = 0.5f))
                        ),
                        shape = CircleShape
                    ),
                contentAlignment = Alignment.Center
            ) {
                // Central High-Tech Animated Download Arrow
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                    modifier = Modifier.graphicsLayer {
                        translationY = arrowFloatOffset
                    }
                ) {
                    Icon(
                        imageVector = Icons.Default.ArrowDownward,
                        contentDescription = "Active Download Engine",
                        tint = Color.White,
                        modifier = Modifier
                            .size(34.dp)
                            .shadow(8.dp, CircleShape, spotColor = Color(0xFFFFD54F))
                    )
                    // Quantum Catch Tray Base Line
                    Box(
                        modifier = Modifier
                            .width(26.dp)
                            .height(2.5.dp)
                            .background(
                                brush = Brush.horizontalGradient(
                                    listOf(Color.Transparent, Color(0xFFFFD54F), Color.White, Color(0xFFFFD54F), Color.Transparent)
                                ),
                                shape = RoundedCornerShape(2.dp)
                            )
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Dynamic Frequency Spectrum Equalizer Bars
        Row(
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.height(18.dp)
        ) {
            val barCount = 9
            for (i in 0 until barCount) {
                val delayOffset = i * 140
                val barHeight by infiniteTransition.animateFloat(
                    initialValue = 4f,
                    targetValue = if (i == 4) 18f else if (i % 2 == 0) 14f else 9f,
                    animationSpec = infiniteRepeatable(
                        animation = tween(600 + (i % 3) * 120, delayMillis = delayOffset, easing = FastOutSlowInEasing),
                        repeatMode = RepeatMode.Reverse
                    ),
                    label = "bar_$i"
                )
                Box(
                    modifier = Modifier
                        .width(3.dp)
                        .height(barHeight.dp)
                        .background(
                            brush = Brush.verticalGradient(
                                colors = listOf(
                                    Color(0xFFFFB74D),
                                    Color(0xFFFF7A00),
                                    Color(0xFF8B1E2D)
                                )
                            ),
                            shape = RoundedCornerShape(2.dp)
                        )
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Futuristic Engine Status Badge
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = Color(0x331F1419),
            border = BorderStroke(1.dp, Color(0x33FF7A00)),
            modifier = Modifier.padding(horizontal = 8.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 5.dp)
            ) {
                // Pulsing Live Indicator
                val pulseAlpha by infiniteTransition.animateFloat(
                    initialValue = 0.4f,
                    targetValue = 1f,
                    animationSpec = infiniteRepeatable(
                        animation = tween(800, easing = LinearEasing),
                        repeatMode = RepeatMode.Reverse
                    ),
                    label = "pulseAlpha"
                )
                Box(
                    modifier = Modifier
                        .size(7.dp)
                        .background(Color(0xFF00E676).copy(alpha = pulseAlpha), CircleShape)
                        .border(1.dp, Color(0xFF00E676), CircleShape)
                )
                Text(
                    text = if (isBoosted) "HYPER-SPEED ENGINE ACTIVE • 4K READY" else "QUANTUM DOWNLOAD ENGINE",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = FontWeight.ExtraBold,
                        letterSpacing = 1.1.sp,
                        fontSize = 10.sp
                    ),
                    color = if (isBoosted) Color(0xFFFFD54F) else Color(0xFFFFB74D)
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // High-Tech Feature Chips Tagline
        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            listOf("4K ULTRA HD", "60 FPS", "MULTI-STREAM", "ZERO LOSS").forEach { tag ->
                Text(
                    text = "• $tag",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontSize = 9.5.sp,
                        fontWeight = FontWeight.SemiBold,
                        letterSpacing = 0.5.sp
                    ),
                    color = Color(0xFFA5A5B2)
                )
            }
        }
    }
}

@Composable
fun FluidIncognitoButton(
    isIncognitoMode: Boolean,
    onToggle: () -> Unit,
    modifier: Modifier = Modifier
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()

    // Breathing glow animation when incognito is active
    val infiniteTransition = rememberInfiniteTransition(label = "incognito_pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = 1.45f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1800, easing = EaseOutSine),
            repeatMode = RepeatMode.Restart
        ),
        label = "pulse_scale"
    )
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.5f,
        targetValue = 0.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1800, easing = EaseOutSine),
            repeatMode = RepeatMode.Restart
        ),
        label = "pulse_alpha"
    )

    // Scale spring animation on press or mode active
    val scaleMultiplier by animateFloatAsState(
        targetValue = when {
            isPressed -> 0.85f
            isIncognitoMode -> 1.08f
            else -> 1.0f
        },
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMedium
        ),
        label = "scale_multiplier"
    )

    // Rotate icon 360 degrees when toggled
    val iconRotation by animateFloatAsState(
        targetValue = if (isIncognitoMode) 360f else 0f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioLowBouncy,
            stiffness = Spring.StiffnessLow
        ),
        label = "icon_rotation"
    )

    val containerColor by animateColorAsState(
        targetValue = if (isIncognitoMode) Color(0xFF2E1C1F) else Color(0xCC121218),
        animationSpec = tween(durationMillis = 400, easing = FastOutSlowInEasing),
        label = "container_color"
    )

    val shadowColor by animateColorAsState(
        targetValue = if (isIncognitoMode) Color(0xFFFF4D5A) else SleekPurpleLight,
        animationSpec = tween(durationMillis = 450),
        label = "shadow_color"
    )

    val iconColor by animateColorAsState(
        targetValue = if (isIncognitoMode) Color(0xFFFF4D5A) else SleekPurpleLight,
        animationSpec = spring(dampingRatio = Spring.DampingRatioNoBouncy),
        label = "icon_color"
    )

    Box(
        modifier = modifier,
        contentAlignment = Alignment.Center
    ) {
        if (isIncognitoMode) {
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .graphicsLayer {
                        scaleX = pulseScale
                        scaleY = pulseScale
                        alpha = pulseAlpha
                    }
                    .background(Color(0xFFFF4D5A).copy(alpha = 0.3f), CircleShape)
            )
        }

        Surface(
            modifier = Modifier
                .scale(scaleMultiplier)
                .shadow(
                    elevation = if (isIncognitoMode) 16.dp else 10.dp,
                    shape = CircleShape,
                    clip = false,
                    ambientColor = shadowColor.copy(alpha = 0.3f),
                    spotColor = shadowColor.copy(alpha = 0.5f)
                ),
            shape = CircleShape,
            color = containerColor,
            border = BorderStroke(
                width = 1.dp,
                brush = Brush.linearGradient(
                    colors = if (isIncognitoMode) {
                        listOf(Color(0xFFFF4D5A).copy(alpha = 0.7f), Color(0xFFFF4D5A).copy(alpha = 0.2f))
                    } else {
                        listOf(SleekPurpleLight.copy(alpha = 0.4f), Color.Transparent, SleekPurpleDark.copy(alpha = 0.2f))
                    }
                )
            )
        ) {
            IconButton(
                onClick = onToggle,
                interactionSource = interactionSource,
                modifier = Modifier
                    .size(38.dp)
                    .testTag("incognito_toggle_icon")
            ) {
                Icon(
                    imageVector = if (isIncognitoMode) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                    contentDescription = "Incognito Mode",
                    tint = iconColor,
                    modifier = Modifier
                        .size(19.dp)
                        .graphicsLayer {
                            rotationZ = iconRotation
                        }
                )
            }
        }
    }
}

// =========================================================================
// FEATURE 3: Smart Video Compression Dialog
// =========================================================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VideoCompressionDialog(
    state: VideoDownloaderViewModel.CompressTaskState,
    onSelectPreset: (String) -> Unit,
    onUpdateCustomOptions: (width: Int, height: Int, videoKbps: Int, audioKbps: Int, fps: Int) -> Unit,
    onCompress: () -> Unit,
    onCancelCompress: () -> Unit,
    onOpenCompressed: (com.example.data.DownloadEntity) -> Unit,
    onShareCompressed: (String) -> Unit,
    onDismiss: () -> Unit
) {
    androidx.compose.ui.window.Dialog(
        onDismissRequest = {
            if (!state.isProcessing) onDismiss()
        },
        properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = Color(0xFF14151F),
            border = BorderStroke(1.2.dp, SleekPurpleDark.copy(alpha = 0.8f)),
            shadowElevation = 16.dp,
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .padding(vertical = 16.dp)
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = SleekPurpleDark.copy(alpha = 0.5f),
                            modifier = Modifier.size(40.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.Compress,
                                    contentDescription = null,
                                    tint = SleekPurpleLight,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                        }
                        Column {
                            Text(
                                text = "Smart Video Compressor",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = SleekTextPrimary
                            )
                            Text(
                                text = "Reduce file size with visual clarity",
                                style = MaterialTheme.typography.labelSmall,
                                color = SleekPurpleLight
                            )
                        }
                    }

                    if (!state.isProcessing) {
                        IconButton(
                            onClick = onDismiss,
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Close",
                                tint = SleekTextSecondary
                            )
                        }
                    }
                }

                HorizontalDivider(color = Color.White.copy(alpha = 0.12f))

                // Source File summary
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = Color.White.copy(alpha = 0.05f),
                    border = BorderStroke(1.dp, Color.White.copy(alpha = 0.08f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = state.media.title,
                                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                color = Color.White,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "Source: ${state.sourceWidth}x${state.sourceHeight} • ${formatBytes(state.sourceSizeBytes)}",
                                style = MaterialTheme.typography.labelSmall,
                                color = SleekTextSecondary
                            )
                        }
                    }
                }

                // Error message display
                state.errorMessage?.let { err ->
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.2f),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.5f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = err,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.error,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(10.dp)
                        )
                    }
                }

                if (state.isProcessing) {
                    // COMPRESSING PROGRESS STATE
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = state.statusMessage ?: "Compressing...",
                                style = MaterialTheme.typography.labelMedium,
                                color = SleekPurpleLight,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "${state.progressPercent}%",
                                style = MaterialTheme.typography.labelLarge,
                                color = Color.White,
                                fontWeight = FontWeight.ExtraBold
                            )
                        }

                        LinearProgressIndicator(
                            progress = { state.progressPercent / 100f },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp)),
                            color = SleekPurpleLight,
                            trackColor = Color.White.copy(alpha = 0.15f)
                        )

                        val remSec = state.remainingTimeSec
                        val remMin = remSec / 60
                        val remS = remSec % 60
                        val timeStr = String.format(java.util.Locale.US, "%02d:%02d", remMin, remS)

                        Text(
                            text = "Estimated remaining time: $timeStr",
                            style = MaterialTheme.typography.labelSmall,
                            color = SleekTextSecondary
                        )

                        OutlinedButton(
                            onClick = onCancelCompress,
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.5f)),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error)
                        ) {
                            Icon(imageVector = Icons.Default.Close, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Cancel Compression", fontWeight = FontWeight.Bold)
                        }
                    }
                } else if (state.exportedEntity != null && state.exportedFilePath != null) {
                    // COMPLETED STATE
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = Color(0xFF4CAF50).copy(alpha = 0.2f),
                            modifier = Modifier.size(48.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.Check,
                                    contentDescription = null,
                                    tint = Color(0xFF4CAF50),
                                    modifier = Modifier.size(28.dp)
                                )
                            }
                        }

                        Text(
                            text = "Compression complete",
                            style = MaterialTheme.typography.titleMedium,
                            color = Color(0xFF4CAF50),
                            fontWeight = FontWeight.Bold
                        )

                        val origSize = formatBytes(state.originalSizeBytes)
                        val newSize = formatBytes(state.compressedSizeBytes)
                        val savedBytes = (state.originalSizeBytes - state.compressedSizeBytes).coerceAtLeast(0L)
                        val savedSize = formatBytes(savedBytes)
                        val reductionPct = if (state.originalSizeBytes > 0) {
                            (((state.originalSizeBytes - state.compressedSizeBytes).toDouble() / state.originalSizeBytes) * 100).toInt().coerceAtLeast(0)
                        } else 0

                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = Color.White.copy(alpha = 0.06f),
                            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.12f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(14.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("Original:", style = MaterialTheme.typography.bodySmall, color = SleekTextSecondary)
                                    Text(origSize, style = MaterialTheme.typography.bodySmall, color = Color.White, fontWeight = FontWeight.Bold)
                                }
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("New:", style = MaterialTheme.typography.bodySmall, color = SleekTextSecondary)
                                    Text(newSize, style = MaterialTheme.typography.bodySmall, color = SleekPurpleLight, fontWeight = FontWeight.Bold)
                                }
                                HorizontalDivider(color = Color.White.copy(alpha = 0.1f))
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("Saved:", style = MaterialTheme.typography.bodySmall, color = SleekTextSecondary)
                                    Text("$savedSize ($reductionPct% smaller)", style = MaterialTheme.typography.bodySmall, color = Color(0xFF4CAF50), fontWeight = FontWeight.ExtraBold)
                                }
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = { onOpenCompressed(state.exportedEntity) },
                                modifier = Modifier.weight(1f).height(46.dp),
                                shape = RoundedCornerShape(14.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = SleekPurpleLight, contentColor = Color.White)
                            ) {
                                Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Open", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            }

                            OutlinedButton(
                                onClick = { onShareCompressed(state.exportedFilePath) },
                                modifier = Modifier.weight(1f).height(46.dp),
                                shape = RoundedCornerShape(14.dp),
                                border = BorderStroke(1.dp, SleekPurpleLight.copy(alpha = 0.6f)),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = SleekPurpleLight)
                            ) {
                                Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Share", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            }

                            Button(
                                onClick = onDismiss,
                                modifier = Modifier.weight(1f).height(46.dp),
                                shape = RoundedCornerShape(14.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = Color.White.copy(alpha = 0.15f), contentColor = Color.White)
                            ) {
                                Text("Done", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            }
                        }
                    }
                } else {
                    // PRESET SELECTION & CUSTOMIZATION
                    Text(
                        text = "Select Preset Quality:",
                        style = MaterialTheme.typography.labelMedium,
                        color = SleekTextSecondary,
                        modifier = Modifier.align(Alignment.Start)
                    )

                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        state.availablePresets.forEach { preset ->
                            val isSel = state.selectedPresetId == preset.id
                            Surface(
                                onClick = { onSelectPreset(preset.id) },
                                shape = RoundedCornerShape(12.dp),
                                color = if (isSel) SleekPurpleDark.copy(alpha = 0.4f) else Color.White.copy(alpha = 0.05f),
                                border = BorderStroke(1.dp, if (isSel) SleekPurpleLight else Color.White.copy(alpha = 0.1f)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = preset.name,
                                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                            color = if (isSel) Color.White else SleekTextPrimary
                                        )
                                        Text(
                                            text = preset.description,
                                            style = MaterialTheme.typography.labelSmall,
                                            color = SleekTextSecondary
                                        )
                                    }
                                    RadioButton(
                                        selected = isSel,
                                        onClick = { onSelectPreset(preset.id) },
                                        colors = RadioButtonDefaults.colors(
                                            selectedColor = SleekPurpleLight,
                                            unselectedColor = SleekTextSecondary
                                        )
                                    )
                                }
                            }
                        }
                    }

                    // CUSTOM OPTIONS PANEL
                    if (state.selectedPresetId == "custom") {
                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = Color.White.copy(alpha = 0.04f),
                            border = BorderStroke(1.dp, SleekPurpleLight.copy(alpha = 0.3f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(12.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Text("Custom Settings", style = MaterialTheme.typography.labelMedium, color = SleekPurpleLight, fontWeight = FontWeight.Bold)

                                Column {
                                    Text("Video Bitrate: ${state.customVideoBitrateKbps} kbps", style = MaterialTheme.typography.labelSmall, color = Color.White)
                                    Slider(
                                        value = state.customVideoBitrateKbps.toFloat(),
                                        onValueChange = { vKbps ->
                                            onUpdateCustomOptions(state.customWidth, state.customHeight, vKbps.toInt(), state.customAudioBitrateKbps, state.customFps)
                                        },
                                        valueRange = 500f..8000f,
                                        colors = SliderDefaults.colors(thumbColor = SleekPurpleLight, activeTrackColor = SleekPurpleLight)
                                    )
                                }

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text("Audio Bitrate", style = MaterialTheme.typography.labelSmall, color = SleekTextSecondary)
                                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                            listOf(64, 96, 128, 192).forEach { ab ->
                                                val sel = state.customAudioBitrateKbps == ab
                                                FilterChip(
                                                    selected = sel,
                                                    onClick = { onUpdateCustomOptions(state.customWidth, state.customHeight, state.customVideoBitrateKbps, ab, state.customFps) },
                                                    label = { Text("${ab}k", fontSize = 10.sp) }
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // ESTIMATED FILE SIZE CARD
                    val selectedPreset = state.availablePresets.firstOrNull { it.id == state.selectedPresetId }
                        ?: VideoDownloaderViewModel.CompressPreset("custom", "Custom", state.customWidth, state.customHeight, state.customVideoBitrateKbps, state.customAudioBitrateKbps, state.customFps, "Custom")

                    val targetW = if (selectedPreset.id == "custom") state.customWidth else selectedPreset.targetWidth
                    val targetH = if (selectedPreset.id == "custom") state.customHeight else selectedPreset.targetHeight
                    val targetVKbps = if (selectedPreset.id == "custom") state.customVideoBitrateKbps else selectedPreset.videoBitrateKbps
                    val targetAKbps = if (selectedPreset.id == "custom") state.customAudioBitrateKbps else selectedPreset.audioBitrateKbps

                    val durSec = (state.sourceDurationMs / 1000.0).coerceAtLeast(1.0)
                    val estBitrateBps = (targetVKbps + targetAKbps) * 1000L
                    val estBytes = ((estBitrateBps * durSec) / 8.0).toLong().coerceAtMost(state.sourceSizeBytes)
                    val estReductionPct = if (state.sourceSizeBytes > 0) {
                        (((state.sourceSizeBytes - estBytes).toDouble() / state.sourceSizeBytes) * 100).toInt().coerceIn(0, 95)
                    } else 0

                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = SleekPurpleDark.copy(alpha = 0.25f),
                        border = BorderStroke(1.dp, SleekPurpleLight.copy(alpha = 0.3f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text("Estimated Before Export", style = MaterialTheme.typography.labelMedium, color = SleekPurpleLight, fontWeight = FontWeight.Bold)

                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Original size:", style = MaterialTheme.typography.bodySmall, color = SleekTextSecondary)
                                Text(formatBytes(state.sourceSizeBytes), style = MaterialTheme.typography.bodySmall, color = Color.White, fontWeight = FontWeight.Bold)
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Estimated size:", style = MaterialTheme.typography.bodySmall, color = SleekTextSecondary)
                                Text("~${formatBytes(estBytes)}", style = MaterialTheme.typography.bodySmall, color = SleekPurpleLight, fontWeight = FontWeight.Bold)
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Target Resolution:", style = MaterialTheme.typography.bodySmall, color = SleekTextSecondary)
                                Text("${targetH}p (${targetW}x${targetH})", style = MaterialTheme.typography.bodySmall, color = Color.White, fontWeight = FontWeight.Bold)
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Estimated reduction:", style = MaterialTheme.typography.bodySmall, color = SleekTextSecondary)
                                Text("~$estReductionPct% smaller", style = MaterialTheme.typography.bodySmall, color = Color(0xFF4CAF50), fontWeight = FontWeight.Bold)
                            }

                            Text(
                                text = "* Note: Final file size is an estimate and may vary slightly based on video content complexity.",
                                style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                                color = SleekTextMuted
                            )
                        }
                    }

                    // Action Button
                    Button(
                        onClick = onCompress,
                        modifier = Modifier.fillMaxWidth().height(48.dp),
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = SleekPurpleLight,
                            contentColor = Color.White
                        )
                    ) {
                        Icon(imageVector = Icons.Default.Compress, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Compress Video",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    }
                }
            }
        }
    }
}

// =========================================================================
// FEATURE 2: Studio Media Trimmer & GIF / Ringtone Converter Dialog
// =========================================================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MediaTrimmerDialog(
    state: VideoDownloaderViewModel.TrimTaskState,
    onUpdateRange: (Long, Long) -> Unit,
    onPreview: () -> Unit,
    onExport: () -> Unit,
    onCancelExport: () -> Unit,
    onOpenExported: (com.example.data.DownloadEntity) -> Unit,
    onShareExported: (String) -> Unit,
    onDismiss: () -> Unit
) {
    androidx.compose.ui.window.Dialog(
        onDismissRequest = { if (!state.isProcessing) onDismiss() },
        properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .wrapContentHeight()
                .padding(16.dp)
                .shadow(24.dp, RoundedCornerShape(28.dp)),
            shape = RoundedCornerShape(28.dp),
            color = SleekCardDark,
            border = BorderStroke(1.dp, SleekPurpleLight.copy(alpha = 0.4f))
        ) {
            Column(
                modifier = Modifier
                    .padding(22.dp)
                    .fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = SleekPurpleLight.copy(alpha = 0.2f),
                            modifier = Modifier.size(38.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.ContentCut,
                                    contentDescription = null,
                                    tint = SleekPurpleLight,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                        Column {
                            Text(
                                text = "Video Segment Cutter",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = SleekTextPrimary
                            )
                            Text(
                                text = "Trim & Export Clips Losslessly",
                                style = MaterialTheme.typography.labelSmall,
                                color = SleekPurpleLight
                            )
                        }
                    }

                    if (!state.isProcessing) {
                        IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                            Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = SleekTextMuted)
                        }
                    }
                }

                HorizontalDivider(color = SleekBorderColor.copy(alpha = 0.5f))

                // Title preview
                Text(
                    text = state.media.title,
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                    color = SleekTextPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.fillMaxWidth()
                )

                // Range calculations
                val startSec = state.startTimeMs / 1000f
                val endSec = state.endTimeMs / 1000f
                val totalSec = (state.totalDurationMs / 1000f).coerceAtLeast(1f)
                val lengthSec = (endSec - startSec).coerceAtLeast(0f)

                fun formatTime(sec: Float): String {
                    val totalS = sec.toInt()
                    val m = totalS / 60
                    val s = totalS % 60
                    return String.format(java.util.Locale.US, "%02d:%02d", m, s)
                }

                // Stats Display Card
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color.Black.copy(alpha = 0.35f), RoundedCornerShape(16.dp))
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Start: ${formatTime(startSec)}",
                                style = MaterialTheme.typography.labelMedium,
                                color = SleekPurpleLight,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "End:   ${formatTime(endSec)}",
                                style = MaterialTheme.typography.labelMedium,
                                color = SleekPurpleLight,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = SleekPurpleLight.copy(alpha = 0.2f),
                            border = BorderStroke(1.dp, SleekPurpleLight.copy(alpha = 0.4f))
                        ) {
                            Column(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = "Length",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = SleekTextMuted
                                )
                                Text(
                                    text = formatTime(lengthSec),
                                    style = MaterialTheme.typography.titleSmall,
                                    color = Color.White,
                                    fontWeight = FontWeight.ExtraBold
                                )
                            }
                        }
                    }

                    RangeSlider(
                        value = startSec..endSec,
                        onValueChange = { range ->
                            val startMs = (range.start * 1000).toLong()
                            val endMs = (range.endInclusive * 1000).toLong()
                            onUpdateRange(startMs, endMs)
                        },
                        valueRange = 0f..totalSec,
                        modifier = Modifier.fillMaxWidth(),
                        enabled = !state.isProcessing && state.exportedEntity == null,
                        colors = SliderDefaults.colors(
                            thumbColor = SleekPurpleLight,
                            activeTrackColor = SleekPurpleLight,
                            inactiveTrackColor = Color.White.copy(alpha = 0.2f)
                        )
                    )

                    // Fine tuning adjusters
                    if (!state.isProcessing && state.exportedEntity == null) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                OutlinedButton(
                                    onClick = { onUpdateRange((state.startTimeMs - 1000L).coerceAtLeast(0L), state.endTimeMs) },
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                    modifier = Modifier.height(30.dp),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text("-1s", fontSize = 11.sp, color = SleekTextSecondary)
                                }
                                OutlinedButton(
                                    onClick = { onUpdateRange((state.startTimeMs + 1000L).coerceAtMost(state.endTimeMs - 1000L), state.endTimeMs) },
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                    modifier = Modifier.height(30.dp),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text("+1s", fontSize = 11.sp, color = SleekTextSecondary)
                                }
                            }

                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                OutlinedButton(
                                    onClick = { onUpdateRange(state.startTimeMs, (state.endTimeMs - 1000L).coerceAtLeast(state.startTimeMs + 1000L)) },
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                    modifier = Modifier.height(30.dp),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text("-1s", fontSize = 11.sp, color = SleekTextSecondary)
                                }
                                OutlinedButton(
                                    onClick = { onUpdateRange(state.startTimeMs, (state.endTimeMs + 1000L).coerceAtMost(state.totalDurationMs)) },
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                    modifier = Modifier.height(30.dp),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text("+1s", fontSize = 11.sp, color = SleekTextSecondary)
                                }
                            }
                        }
                    }
                }

                state.errorMessage?.let { err ->
                    Text(
                        text = err,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                // Progress state
                if (state.isProcessing) {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Exporting...",
                                style = MaterialTheme.typography.labelMedium,
                                color = SleekPurpleLight,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "${state.progressPercent}%",
                                style = MaterialTheme.typography.labelLarge,
                                color = Color.White,
                                fontWeight = FontWeight.ExtraBold
                            )
                        }

                        LinearProgressIndicator(
                            progress = { state.progressPercent / 100f },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp)),
                            color = SleekPurpleLight,
                            trackColor = Color.White.copy(alpha = 0.15f)
                        )

                        OutlinedButton(
                            onClick = onCancelExport,
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.5f)),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error)
                        ) {
                            Icon(imageVector = Icons.Default.Close, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Cancel Export", fontWeight = FontWeight.Bold)
                        }
                    }
                } else if (state.exportedEntity != null && state.exportedFilePath != null) {
                    // Export Success View
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = Color(0xFF4CAF50).copy(alpha = 0.2f),
                            modifier = Modifier.size(44.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.Check,
                                    contentDescription = null,
                                    tint = Color(0xFF4CAF50),
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                        }

                        Text(
                            text = "Segment exported",
                            style = MaterialTheme.typography.titleMedium,
                            color = Color(0xFF4CAF50),
                            fontWeight = FontWeight.Bold
                        )

                        Text(
                            text = java.io.File(state.exportedFilePath).name,
                            style = MaterialTheme.typography.bodySmall,
                            color = SleekTextSecondary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Button(
                                onClick = { onOpenExported(state.exportedEntity) },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(46.dp),
                                shape = RoundedCornerShape(14.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = SleekPurpleLight,
                                    contentColor = Color.White
                                )
                            ) {
                                Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Open", fontWeight = FontWeight.Bold)
                            }

                            OutlinedButton(
                                onClick = { onShareExported(state.exportedFilePath) },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(46.dp),
                                shape = RoundedCornerShape(14.dp),
                                border = BorderStroke(1.dp, SleekPurpleLight.copy(alpha = 0.6f)),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = SleekPurpleLight)
                            ) {
                                Icon(imageVector = Icons.Default.Share, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Share", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                } else {
                    // Action Buttons
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedButton(
                            onClick = onPreview,
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp),
                            shape = RoundedCornerShape(16.dp),
                            border = BorderStroke(1.dp, SleekPurpleLight.copy(alpha = 0.6f)),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = SleekPurpleLight)
                        ) {
                            Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Preview", fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = onExport,
                            modifier = Modifier
                                .weight(1.3f)
                                .height(48.dp),
                            shape = RoundedCornerShape(16.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = SleekPurpleLight,
                                contentColor = Color.White
                            )
                        ) {
                            Icon(imageVector = Icons.Default.ContentCut, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Export Segment", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                    }
                }
            }
        }
    }
}

// =========================================================================
// FEATURE 4: A-B Precision Practice Looper & 5-Band Equalizer FX Modal
// =========================================================================
@Composable
fun AudioFxStudioModal(
    viewModel: VideoDownloaderViewModel,
    onDismiss: () -> Unit
) {
    val abPointA by viewModel.abPointA.collectAsStateWithLifecycle()
    val abPointB by viewModel.abPointB.collectAsStateWithLifecycle()
    val isAbLoopActive by viewModel.isAbLoopActive.collectAsStateWithLifecycle()
    val speed by viewModel.playbackSpeed.collectAsStateWithLifecycle()

    val preset by viewModel.eqPresetName.collectAsStateWithLifecycle()
    val volumeBoost by viewModel.volumeBoost.collectAsStateWithLifecycle()
    val virtualizer by viewModel.eqVirtualizer.collectAsStateWithLifecycle()
    val bassBoost by viewModel.eqBassBoost.collectAsStateWithLifecycle()

    val b60 by viewModel.eqBand60Hz.collectAsStateWithLifecycle()
    val b230 by viewModel.eqBand230Hz.collectAsStateWithLifecycle()
    val b910 by viewModel.eqBand910Hz.collectAsStateWithLifecycle()
    val b3k by viewModel.eqBand3kHz.collectAsStateWithLifecycle()
    val b14k by viewModel.eqBand14kHz.collectAsStateWithLifecycle()

    androidx.compose.ui.window.Dialog(
        onDismissRequest = onDismiss,
        properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.94f)
                .wrapContentHeight()
                .padding(12.dp)
                .shadow(24.dp, RoundedCornerShape(28.dp)),
            shape = RoundedCornerShape(28.dp),
            color = SleekCardDark,
            border = BorderStroke(1.dp, SleekPurpleLight.copy(alpha = 0.4f))
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = SleekPurpleLight.copy(alpha = 0.2f),
                            modifier = Modifier.size(38.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.GraphicEq,
                                    contentDescription = null,
                                    tint = SleekPurpleLight,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                        Column {
                            Text(
                                text = "A-B Looper & Equalizer FX Studio",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = SleekTextPrimary
                            )
                            Text(
                                text = "Precision Practice & Pro Audio Engine",
                                style = MaterialTheme.typography.labelSmall,
                                color = SleekPurpleLight
                            )
                        }
                    }

                    IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = SleekTextMuted)
                    }
                }

                HorizontalDivider(color = SleekBorderColor.copy(alpha = 0.4f))

                // SECTION 1: A-B PRECISION PRACTICE LOOPER
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color.Black.copy(alpha = 0.35f), RoundedCornerShape(16.dp))
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Icon(imageVector = Icons.Default.Repeat, contentDescription = null, tint = SleekPurpleLight, modifier = Modifier.size(18.dp))
                            Text("A-B Loop Practice Mode", fontWeight = FontWeight.Bold, color = SleekTextPrimary, fontSize = 13.sp)
                        }
                        if (isAbLoopActive) {
                            Surface(
                                color = Color(0xFF4CAF50).copy(alpha = 0.2f),
                                border = BorderStroke(1.dp, Color(0xFF4CAF50)),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text("ACTIVE LOOP", color = Color(0xFF4CAF50), fontWeight = FontWeight.Bold, fontSize = 10.sp, modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp))
                            }
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { viewModel.setAbPointA(5000L) },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (abPointA != null) SleekPurpleLight else Color.White.copy(alpha = 0.1f)
                            )
                        ) {
                            Text(
                                text = abPointA?.let { "Point A: ${it / 1000}s" } ?: "Set Point A",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Button(
                            onClick = { viewModel.setAbPointB(25000L) },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (abPointB != null) SleekPurpleLight else Color.White.copy(alpha = 0.1f)
                            )
                        ) {
                            Text(
                                text = abPointB?.let { "Point B: ${it / 1000}s" } ?: "Set Point B",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    if (abPointA != null || abPointB != null) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            TextButton(onClick = { viewModel.toggleAbLoop() }) {
                                Text(if (isAbLoopActive) "Pause Loop" else "Enable Loop", color = SleekPurpleLight, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                            TextButton(onClick = { viewModel.clearAbLoop() }) {
                                Text("Reset Points", color = CrimsonFailure, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                        }
                    }
                }

                // SECTION 2: PLAYBACK SPEED
                Column(modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Playback Speed (${speed}x):", style = MaterialTheme.typography.labelMedium, color = SleekTextSecondary)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf(0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 2.0f).forEach { s ->
                            val isSel = speed == s
                            Surface(
                                onClick = { viewModel.setPlaybackSpeed(s) },
                                shape = RoundedCornerShape(10.dp),
                                color = if (isSel) SleekPurpleLight else Color.White.copy(alpha = 0.08f),
                                modifier = Modifier.weight(1f)
                            ) {
                                Box(contentAlignment = Alignment.Center, modifier = Modifier.padding(vertical = 8.dp)) {
                                    Text("${s}x", fontSize = 11.sp, fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal, color = if (isSel) Color.White else SleekTextSecondary)
                                }
                            }
                        }
                    }
                }

                // SECTION 3: EQUALIZER PRESETS
                Column(modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Audio EQ Presets:", style = MaterialTheme.typography.labelMedium, color = SleekTextSecondary)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        listOf("Flat", "Bass Booster", "Vocal Enhancer", "Rock", "Pop", "Electronic").forEach { pr ->
                            val isSel = preset == pr
                            Surface(
                                onClick = { viewModel.applyEqPreset(pr) },
                                shape = RoundedCornerShape(10.dp),
                                color = if (isSel) SleekPurpleLight else Color.White.copy(alpha = 0.08f),
                                border = BorderStroke(1.dp, if (isSel) SleekPurpleLight else Color.Transparent),
                                modifier = Modifier.weight(1f)
                            ) {
                                Box(contentAlignment = Alignment.Center, modifier = Modifier.padding(vertical = 6.dp)) {
                                    Text(pr.take(6), fontSize = 10.sp, fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal, color = if (isSel) Color.White else SleekTextSecondary)
                                }
                            }
                        }
                    }
                }

                // SECTION 4: 5-BAND SLIDERS & BASS BOOST
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color.Black.copy(alpha = 0.25f), RoundedCornerShape(16.dp))
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text("Volume Booster, Virtualizer & Equalizer FX", fontWeight = FontWeight.Bold, color = SleekTextPrimary, fontSize = 12.sp)

                    // Volume Boost
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                        Text("Volume", fontSize = 11.sp, color = CrimsonFailure, modifier = Modifier.width(80.dp), fontWeight = FontWeight.Bold)
                        Slider(
                            value = volumeBoost,
                            onValueChange = { viewModel.updateVolumeBoost(it) },
                            valueRange = 0f..100f,
                            colors = SliderDefaults.colors(thumbColor = CrimsonFailure, activeTrackColor = CrimsonFailure),
                            modifier = Modifier.weight(1f)
                        )
                        Text("${volumeBoost.toInt()}%", fontSize = 11.sp, color = Color.White, modifier = Modifier.width(40.dp), textAlign = TextAlign.End)
                    }

                    // Virtualizer
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                        Text("3D Virtual", fontSize = 11.sp, color = SleekPurpleLight, modifier = Modifier.width(80.dp), fontWeight = FontWeight.Bold)
                        Slider(
                            value = virtualizer,
                            onValueChange = { viewModel.updateEqVirtualizer(it) },
                            valueRange = 0f..100f,
                            colors = SliderDefaults.colors(thumbColor = SleekPurpleLight, activeTrackColor = SleekPurpleLight),
                            modifier = Modifier.weight(1f)
                        )
                        Text("${virtualizer.toInt()}%", fontSize = 11.sp, color = Color.White, modifier = Modifier.width(40.dp), textAlign = TextAlign.End)
                    }

                    // Bass boost
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                        Text("Bass Boost", fontSize = 11.sp, color = SleekPurpleLight, modifier = Modifier.width(80.dp), fontWeight = FontWeight.Bold)
                        Slider(
                            value = bassBoost,
                            onValueChange = { viewModel.updateEqBassBoost(it) },
                            valueRange = 0f..100f,
                            colors = SliderDefaults.colors(thumbColor = SleekPurpleLight, activeTrackColor = SleekPurpleLight),
                            modifier = Modifier.weight(1f)
                        )
                        Text("${bassBoost.toInt()}%", fontSize = 11.sp, color = Color.White, modifier = Modifier.width(40.dp), textAlign = TextAlign.End)
                    }

                    val bands = listOf("60Hz" to b60, "230Hz" to b230, "910Hz" to b910, "3.6kHz" to b3k, "14kHz" to b14k)
                    bands.forEachIndexed { index, (label, valHz) ->
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                            Text(label, fontSize = 11.sp, color = SleekTextSecondary, modifier = Modifier.width(80.dp))
                            Slider(
                                value = valHz,
                                onValueChange = { viewModel.updateEqBand(index, it) },
                                valueRange = -10f..10f,
                                colors = SliderDefaults.colors(thumbColor = SleekPurpleLight, activeTrackColor = SleekPurpleLight),
                                modifier = Modifier.weight(1f)
                            )
                            Text(String.format(java.util.Locale.US, "%+.1fdB", valHz), fontSize = 10.sp, color = SleekTextSecondary, modifier = Modifier.width(45.dp), textAlign = TextAlign.End)
                        }
                    }
                }

                Button(
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth().height(48.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = SleekPurpleLight, contentColor = Color.White)
                ) {
                    Text("Apply & Close Studio", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }
            }
        }
    }
}

@Composable
fun BatchQueueManagerModal(
    viewModel: VideoDownloaderViewModel,
    onDismiss: () -> Unit
) {
    val activeDownloads by viewModel.activeDownloads.collectAsStateWithLifecycle()
    val maxConcurrent by viewModel.maxConcurrentDownloads.collectAsStateWithLifecycle()
    val pauseOnCellular by viewModel.pauseOnCellular.collectAsStateWithLifecycle()
    val autoResumeOnWifi by viewModel.autoResumeOnWifi.collectAsStateWithLifecycle()
    val batteryInfo by viewModel.batteryInfo.collectAsStateWithLifecycle()
    val autoPauseBattery by viewModel.autoPauseOnLowBatteryOrDischarging.collectAsStateWithLifecycle()
    val batterySaverThreshold by viewModel.batterySaverThreshold.collectAsStateWithLifecycle()
    val pauseIfNotCharging by viewModel.pauseIfNotCharging.collectAsStateWithLifecycle()
    val largeFileThresholdMb by viewModel.largeFileThresholdMb.collectAsStateWithLifecycle()
    val autoResumeOnPower by viewModel.autoResumeOnPowerConnected.collectAsStateWithLifecycle()

    androidx.compose.ui.window.Dialog(
        onDismissRequest = onDismiss,
        properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .widthIn(max = 520.dp)
                .wrapContentHeight(),
            shape = RoundedCornerShape(28.dp),
            color = Color(0xFF1B1D22),
            border = BorderStroke(1.dp, SleekBorderColor)
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .background(SleekPurpleLight.copy(alpha = 0.15f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.FormatListNumbered, contentDescription = null, tint = SleekPurpleLight)
                        }
                        Column {
                            Text("Batch Queue Manager", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.ExtraBold), color = Color.White)
                            Text("${activeDownloads.size} active download tasks", style = MaterialTheme.typography.bodySmall, color = SleekTextSecondary)
                        }
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = SleekTextMuted)
                    }
                }

                Divider(color = Color.White.copy(alpha = 0.08f))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = { viewModel.pauseAllQueue() },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2A2D36)),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.Pause, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Pause All", fontSize = 12.sp, color = Color.White)
                    }
                    Button(
                        onClick = { viewModel.resumeAllQueue() },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = SleekPurpleLight),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Resume All", fontSize = 12.sp, color = Color.White)
                    }
                    Button(
                        onClick = { viewModel.clearQueueInactive() },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2A2D36)),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.CleaningServices, contentDescription = null, tint = SleekTextSecondary, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Clear", fontSize = 12.sp, color = SleekTextSecondary)
                    }
                }

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color.White.copy(alpha = 0.04f), RoundedCornerShape(16.dp))
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Max Parallel Downloads", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold), color = Color.White)
                        Text("$maxConcurrent Active", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold), color = SleekPurpleLight)
                    }
                    Slider(
                        value = maxConcurrent.toFloat(),
                        onValueChange = { viewModel.setMaxConcurrentDownloads(it.toInt()) },
                        valueRange = 1f..10f,
                        steps = 8,
                        colors = SliderDefaults.colors(thumbColor = SleekPurpleLight, activeTrackColor = SleekPurpleLight)
                    )
                }

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color.White.copy(alpha = 0.04f), RoundedCornerShape(16.dp))
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text("Auto-Sync & Network Guard", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold), color = Color.White)

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Pause on Cellular Data", fontSize = 13.sp, color = Color.White)
                            Text("Save mobile data bandwidth", fontSize = 11.sp, color = SleekTextSecondary)
                        }
                        Switch(
                            checked = pauseOnCellular,
                            onCheckedChange = { viewModel.setPauseOnCellular(it) },
                            colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = SleekPurpleLight)
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Auto-Resume on Wi-Fi", fontSize = 13.sp, color = Color.White)
                            Text("Automatically resume queue when Wi-Fi connects", fontSize = 11.sp, color = SleekTextSecondary)
                        }
                        Switch(
                            checked = autoResumeOnWifi,
                            onCheckedChange = { viewModel.setAutoResumeOnWifi(it) },
                            colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = SleekPurpleLight)
                        )
                    }
                }

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color.White.copy(alpha = 0.04f), RoundedCornerShape(16.dp))
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Battery & Power Guard", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold), color = Color.White)
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = if (batteryInfo.isCharging) Icons.Default.BatteryChargingFull else if (batteryInfo.isLowBattery) Icons.Default.BatteryAlert else Icons.Default.BatteryStd,
                                contentDescription = null,
                                tint = if (batteryInfo.isCharging) EmeraldSuccess else if (batteryInfo.isLowBattery) AmberAccent else SleekPurpleLight,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = "${batteryInfo.batteryPercentage}% ${if (batteryInfo.isCharging) "(Charging)" else ""}",
                                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, fontSize = 11.sp),
                                color = if (batteryInfo.isCharging) EmeraldSuccess else if (batteryInfo.isLowBattery) AmberAccent else Color.White
                            )
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Auto-Pause Large Downloads", fontSize = 13.sp, color = Color.White)
                            Text("Pause files >= ${largeFileThresholdMb}MB when battery <= ${batterySaverThreshold}% or unplugged", fontSize = 11.sp, color = SleekTextSecondary)
                        }
                        Switch(
                            checked = autoPauseBattery,
                            onCheckedChange = { viewModel.setAutoPauseOnLowBatteryOrDischarging(it) },
                            colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = SleekPurpleLight)
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Auto-Resume on Charger", fontSize = 13.sp, color = Color.White)
                            Text("Instantly resume queue when connected to power", fontSize = 11.sp, color = SleekTextSecondary)
                        }
                        Switch(
                            checked = autoResumeOnPower,
                            onCheckedChange = { viewModel.setAutoResumeOnPowerConnected(it) },
                            colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = SleekPurpleLight)
                        )
                    }
                }

                Button(
                    onClick = onDismiss,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = SleekPurpleLight)
                ) {
                    Text("Done", fontWeight = FontWeight.Bold, color = Color.White)
                }
            }
        }
    }
}

@Composable
fun Id3TextField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier,
    singleLine: Boolean = true,
    maxLines: Int = 1,
    leadingIcon: @Composable (() -> Unit)? = null
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label, color = SleekTextSecondary) },
        singleLine = singleLine,
        maxLines = maxLines,
        leadingIcon = leadingIcon,
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = Color(0xFFFF8A00),
            unfocusedBorderColor = Color.White.copy(alpha = 0.08f),
            focusedContainerColor = Color(0xFF14161C),
            unfocusedContainerColor = Color(0xFF14161C),
            focusedTextColor = Color.White,
            unfocusedTextColor = Color.White
        )
    )
}

@Composable
fun MetadataEditorModal(
    item: DownloadEntity,
    viewModel: VideoDownloaderViewModel,
    onDismiss: () -> Unit
) {
    var title by remember { mutableStateOf(item.title) }
    var artist by remember { mutableStateOf(item.author) }
    var album by remember { mutableStateOf("Downly Downloads") }
    var genre by remember { mutableStateOf("Music & Video") }
    var year by remember { mutableStateOf("2026") }
    var lyrics by remember { mutableStateOf("") }
    var coverUrl by remember { mutableStateOf(item.thumbnailUrl) }

    androidx.compose.ui.window.Dialog(
        onDismissRequest = onDismiss,
        properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .widthIn(max = 520.dp)
                .wrapContentHeight(),
            shape = RoundedCornerShape(28.dp),
            color = Color(0xFF1B1D22),
            border = BorderStroke(1.dp, SleekBorderColor)
        ) {
            Column(
                modifier = Modifier
                    .padding(24.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .background(SleekPurpleLight.copy(alpha = 0.15f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Edit, contentDescription = null, tint = SleekPurpleLight)
                        }
                        Column {
                            Text("ID3 Tag & Metadata Editor", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.ExtraBold), color = Color.White)
                            Text("Customize song & video info", style = MaterialTheme.typography.bodySmall, color = SleekTextSecondary)
                        }
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = SleekTextMuted)
                    }
                }

                Divider(color = Color.White.copy(alpha = 0.08f))

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    AsyncImage(
                        model = coverUrl.ifBlank { item.thumbnailUrl },
                        contentDescription = "Cover Art",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .size(80.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .border(1.dp, Color.White.copy(alpha = 0.1f), RoundedCornerShape(14.dp))
                    )
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Active Thumbnail / Cover", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Medium), color = Color.White)
                        Spacer(modifier = Modifier.height(6.dp))
                        Id3TextField(
                            value = coverUrl,
                            onValueChange = { coverUrl = it },
                            label = "Image URL or file path..."
                        )
                    }
                }

                // 2x2 Frame Thumbnail Picker for local video media
                val isLocalVideo = !item.isAudioOnly && item.localPath.isNotBlank() && java.io.File(item.localPath).exists()
                if (isLocalVideo) {
                    VideoThumbnail2x2Picker(
                        item = item,
                        currentSelectedUrl = coverUrl,
                        onFrameSelected = { selectedPath ->
                            coverUrl = selectedPath
                            viewModel.updateMediaThumbnail(item.id, selectedPath)
                        }
                    )
                }

                Id3TextField(
                    value = title,
                    onValueChange = { title = it },
                    label = "Track Title"
                )

                Id3TextField(
                    value = artist,
                    onValueChange = { artist = it },
                    label = "Artist / Author"
                )

                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Id3TextField(
                        value = album,
                        onValueChange = { album = it },
                        label = "Album",
                        modifier = Modifier.weight(1f)
                    )
                    Id3TextField(
                        value = genre,
                        onValueChange = { genre = it },
                        label = "Genre",
                        modifier = Modifier.weight(1f)
                    )
                }

                Id3TextField(
                    value = lyrics,
                    onValueChange = { lyrics = it },
                    label = "Lyrics / Description",
                    singleLine = false,
                    maxLines = 4
                )

                Button(
                    onClick = {
                        viewModel.saveMetadataTags(
                            id = item.id,
                            newTitle = title,
                            newAuthor = artist,
                            album = album,
                            genre = genre,
                            year = year,
                            lyrics = lyrics,
                            coverUrl = coverUrl
                        )
                        onDismiss()
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp)
                        .padding(top = 8.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF8A00))
                ) {
                    Icon(Icons.Default.Save, contentDescription = null, tint = Color.White)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Save ID3 Tags", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 16.sp)
                }
            }
        }
    }
}

@Composable
fun VideoThumbnail2x2Picker(
    item: DownloadEntity,
    currentSelectedUrl: String,
    onFrameSelected: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val framePages = remember {
        listOf(
            listOf(0.10f, 0.35f, 0.65f, 0.90f),
            listOf(0.20f, 0.45f, 0.75f, 0.95f),
            listOf(0.05f, 0.25f, 0.55f, 0.80f),
            listOf(0.15f, 0.40f, 0.70f, 0.85f),
            listOf(0.02f, 0.30f, 0.60f, 0.98f)
        )
    }
    var currentPage by remember { mutableIntStateOf(0) }
    val totalPages = framePages.size

    var pageFrames by remember(currentPage, item.id, item.localPath) {
        mutableStateOf<List<com.example.data.ExtractedFrame>>(emptyList())
    }
    var isLoading by remember(currentPage, item.id, item.localPath) {
        mutableStateOf(true)
    }

    LaunchedEffect(currentPage, item.id, item.localPath) {
        isLoading = true
        kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            val percentages = framePages.getOrElse(currentPage) { framePages[0] }
            val frames = com.example.data.MediaThumbnailExtractor.extractFramesAtPercentages(
                context = context,
                localPath = item.localPath,
                mediaId = item.id,
                percentages = percentages
            )
            kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
                pageFrames = frames
                isLoading = false
            }
        }
    }

    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(
                    Icons.Default.GridOn,
                    contentDescription = null,
                    tint = SleekPurpleLight,
                    modifier = Modifier.size(16.dp)
                )
                Text(
                    "Video Frame Thumbnail Picker",
                    style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                    color = Color.White
                )
            }
            Text(
                "Page ${currentPage + 1}/$totalPages",
                style = MaterialTheme.typography.labelSmall,
                color = SleekTextMuted
            )
        }

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(Color(0xFF141518))
                .border(1.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(16.dp))
                .padding(8.dp)
        ) {
            // 2x2 Grid
            Column(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                val row1 = listOf(0, 1)
                val row2 = listOf(2, 3)

                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    for (index in row1) {
                        val frame = pageFrames.getOrNull(index)
                        ThumbnailFrameCell(
                            frame = frame,
                            isLoading = isLoading && frame == null,
                            isSelected = frame != null && (currentSelectedUrl == frame.filePath || (currentSelectedUrl.isNotBlank() && currentSelectedUrl == item.thumbnailUrl && frame.filePath == item.thumbnailUrl)),
                            onClick = {
                                if (frame != null) {
                                    onFrameSelected(frame.filePath)
                                }
                            },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    for (index in row2) {
                        val frame = pageFrames.getOrNull(index)
                        ThumbnailFrameCell(
                            frame = frame,
                            isLoading = isLoading && frame == null,
                            isSelected = frame != null && (currentSelectedUrl == frame.filePath || (currentSelectedUrl.isNotBlank() && currentSelectedUrl == item.thumbnailUrl && frame.filePath == item.thumbnailUrl)),
                            onClick = {
                                if (frame != null) {
                                    onFrameSelected(frame.filePath)
                                }
                            },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }

            // Left Navigation Button (centered vertically on left edge)
            val canGoPrev = currentPage > 0
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = if (canGoPrev) Color.Black.copy(alpha = 0.65f) else Color.Black.copy(alpha = 0.25f),
                border = BorderStroke(0.5.dp, Color.White.copy(alpha = if (canGoPrev) 0.2f else 0.05f)),
                modifier = Modifier
                    .align(Alignment.CenterStart)
                    .padding(start = 2.dp)
                    .size(28.dp)
                    .clickable(enabled = canGoPrev) {
                        if (currentPage > 0) currentPage--
                    }
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        Icons.Default.ArrowBack,
                        contentDescription = "Previous frames",
                        tint = if (canGoPrev) Color.White else Color.White.copy(alpha = 0.2f),
                        modifier = Modifier.size(14.dp)
                    )
                }
            }

            // Right Navigation Button (centered vertically on right edge)
            val canGoNext = currentPage < totalPages - 1
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = if (canGoNext) Color.Black.copy(alpha = 0.65f) else Color.Black.copy(alpha = 0.25f),
                border = BorderStroke(0.5.dp, Color.White.copy(alpha = if (canGoNext) 0.2f else 0.05f)),
                modifier = Modifier
                    .align(Alignment.CenterEnd)
                    .padding(end = 2.dp)
                    .size(28.dp)
                    .clickable(enabled = canGoNext) {
                        if (currentPage < totalPages - 1) currentPage++
                    }
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        Icons.Default.ArrowForward,
                        contentDescription = "Next frames",
                        tint = if (canGoNext) Color.White else Color.White.copy(alpha = 0.2f),
                        modifier = Modifier.size(14.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun ThumbnailFrameCell(
    frame: com.example.data.ExtractedFrame?,
    isLoading: Boolean,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .aspectRatio(16f / 9f)
            .clip(RoundedCornerShape(10.dp))
            .background(Color(0xFF22252A))
            .border(
                if (isSelected) BorderStroke(2.dp, SleekPurpleLight)
                else BorderStroke(1.dp, Color.White.copy(alpha = 0.08f)),
                RoundedCornerShape(10.dp)
            )
            .clickable(enabled = frame != null, onClick = onClick)
    ) {
        if (frame != null) {
            AsyncImage(
                model = frame.filePath,
                contentDescription = "Video Frame ${(frame.percentage * 100).toInt()}%",
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
            
            // Percentage badge
            Box(
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(4.dp)
                    .background(Color.Black.copy(alpha = 0.65f), RoundedCornerShape(4.dp))
                    .padding(horizontal = 4.dp, vertical = 2.dp)
            ) {
                Text(
                    "${(frame.percentage * 100).toInt()}%",
                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp),
                    color = Color.White.copy(alpha = 0.9f)
                )
            }

            // Selected check indicator
            if (isSelected) {
                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(4.dp)
                        .size(18.dp)
                        .background(SleekPurpleLight, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Default.Check,
                        contentDescription = "Active thumbnail",
                        tint = Color.White,
                        modifier = Modifier.size(12.dp)
                    )
                }
            }
        } else if (isLoading) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator(
                    modifier = Modifier.size(16.dp),
                    strokeWidth = 1.5.dp,
                    color = SleekPurpleLight
                )
            }
        } else {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Default.Movie,
                    contentDescription = null,
                    tint = SleekTextMuted,
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}

@Composable
fun DownloadSchedulerModal(
    viewModel: VideoDownloaderViewModel,
    videoTitle: String,
    videoUrl: String,
    formatQuality: String,
    formatExt: String,
    onDismiss: () -> Unit
) {
    var selectedOption by remember { mutableStateOf("Tonight 02:00 AM (Off-Peak)") }
    var wifiOnly by remember { mutableStateOf(true) }

    val options = listOf(
        "In 1 Hour",
        "In 3 Hours",
        "Tonight 02:00 AM (Off-Peak)",
        "Tomorrow 08:00 AM"
    )

    androidx.compose.ui.window.Dialog(
        onDismissRequest = onDismiss,
        properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .widthIn(max = 500.dp)
                .wrapContentHeight(),
            shape = RoundedCornerShape(28.dp),
            color = Color(0xFF1B1D22),
            border = BorderStroke(1.dp, SleekBorderColor)
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .background(Color(0xFFFF8A00).copy(alpha = 0.15f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Schedule, contentDescription = null, tint = Color(0xFFFF8A00))
                        }
                        Column {
                            Text("Schedule Download", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.ExtraBold), color = Color.White)
                            Text(videoTitle, style = MaterialTheme.typography.bodySmall, color = SleekTextSecondary, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = SleekTextMuted)
                    }
                }

                Divider(color = Color.White.copy(alpha = 0.08f))

                Text("Select Scheduled Execution Window:", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold), color = SleekTextPrimary)

                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    options.forEach { opt ->
                        val isSelected = selectedOption == opt
                        Surface(
                            onClick = { selectedOption = opt },
                            shape = RoundedCornerShape(12.dp),
                            color = if (isSelected) SleekPurpleLight.copy(alpha = 0.2f) else Color.White.copy(alpha = 0.04f),
                            border = BorderStroke(1.dp, if (isSelected) SleekPurpleLight else Color.Transparent)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(opt, color = Color.White, fontSize = 13.sp, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal)
                                if (isSelected) {
                                    Icon(Icons.Default.Check, contentDescription = null, tint = SleekPurpleLight, modifier = Modifier.size(18.dp))
                                }
                            }
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Wi-Fi Only Mode", fontSize = 13.sp, color = Color.White)
                        Text("Only download when Wi-Fi is active", fontSize = 11.sp, color = SleekTextSecondary)
                    }
                    Switch(
                        checked = wifiOnly,
                        onCheckedChange = { wifiOnly = it },
                        colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = SleekPurpleLight)
                    )
                }

                Button(
                    onClick = {
                        val offsetMs = when (selectedOption) {
                            "In 1 Hour" -> 3600_000L
                            "In 3 Hours" -> 3 * 3600_000L
                            "Tomorrow 08:00 AM" -> 16 * 3600_000L
                            else -> 7 * 3600_000L
                        }
                        viewModel.scheduleDownload(
                            title = videoTitle,
                            url = videoUrl,
                            quality = formatQuality,
                            ext = formatExt,
                            scheduledTimeMs = System.currentTimeMillis() + offsetMs,
                            wifiOnly = wifiOnly,
                            isNightMode = selectedOption.contains("Off-Peak")
                        )
                        onDismiss()
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF8A00))
                ) {
                    Icon(Icons.Default.AlarmOn, contentDescription = null, tint = Color.White)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Confirm Schedule", fontWeight = FontWeight.Bold, color = Color.White)
                }
            }
        }
    }
}

@Composable
fun AddToPlaylistModal(
    item: DownloadEntity,
    viewModel: VideoDownloaderViewModel,
    onCreateNewRequest: () -> Unit,
    onDismiss: () -> Unit
) {
    val playlists by viewModel.playlists.collectAsStateWithLifecycle()

    androidx.compose.ui.window.Dialog(
        onDismissRequest = onDismiss,
        properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .widthIn(max = 480.dp)
                .wrapContentHeight(),
            shape = RoundedCornerShape(28.dp),
            color = Color(0xFF1B1D22),
            border = BorderStroke(1.dp, SleekBorderColor)
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .background(Color(0xFF00E676).copy(alpha = 0.15f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.PlaylistAdd, contentDescription = null, tint = Color(0xFF00E676))
                        }
                        Column {
                            Text("Add to Playlist", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.ExtraBold), color = Color.White)
                            Text(item.title, style = MaterialTheme.typography.bodySmall, color = SleekTextSecondary, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = SleekTextMuted)
                    }
                }

                Divider(color = Color.White.copy(alpha = 0.08f))

                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.heightIn(max = 240.dp)
                ) {
                    items(playlists) { pl ->
                        val contains = pl.mediaIds.contains(item.id)
                        Surface(
                            onClick = {
                                if (contains) {
                                    viewModel.removeFromPlaylist(pl.id, item.id)
                                } else {
                                    viewModel.addToPlaylist(pl.id, item.id)
                                }
                            },
                            shape = RoundedCornerShape(12.dp),
                            color = Color.White.copy(alpha = 0.04f),
                            border = BorderStroke(1.dp, if (contains) Color(0xFF00E676) else Color.Transparent)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text(pl.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    if (pl.description.isNotBlank()) {
                                        Text(pl.description, color = SleekTextSecondary, fontSize = 11.sp)
                                    }
                                }
                                Checkbox(
                                    checked = contains,
                                    onCheckedChange = {
                                        if (it) viewModel.addToPlaylist(pl.id, item.id)
                                        else viewModel.removeFromPlaylist(pl.id, item.id)
                                    },
                                    colors = CheckboxDefaults.colors(checkedColor = Color(0xFF00E676))
                                )
                            }
                        }
                    }
                }

                OutlinedButton(
                    onClick = {
                        onDismiss()
                        onCreateNewRequest()
                    },
                    modifier = Modifier.fillMaxWidth().height(44.dp),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, SleekPurpleLight)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, tint = SleekPurpleLight)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Create New Playlist", color = SleekPurpleLight, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun CreatePlaylistModal(
    viewModel: VideoDownloaderViewModel,
    onDismiss: () -> Unit
) {
    var name by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }

    androidx.compose.ui.window.Dialog(
        onDismissRequest = onDismiss,
        properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .widthIn(max = 460.dp)
                .wrapContentHeight(),
            shape = RoundedCornerShape(28.dp),
            color = Color(0xFF1B1D22),
            border = BorderStroke(1.dp, SleekBorderColor)
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text("Create New Playlist", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.ExtraBold), color = Color.White)

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Playlist Name", color = SleekTextSecondary) },
                    placeholder = { Text("e.g. Gym Beats", color = SleekTextMuted) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = SleekPurpleLight,
                        unfocusedBorderColor = Color.White.copy(alpha = 0.12f),
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    )
                )

                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Description (Optional)", color = SleekTextSecondary) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = SleekPurpleLight,
                        unfocusedBorderColor = Color.White.copy(alpha = 0.12f),
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    )
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    TextButton(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Cancel", color = SleekTextSecondary)
                    }
                    Button(
                        onClick = {
                            if (name.isNotBlank()) {
                                viewModel.createPlaylist(name, description)
                                onDismiss()
                            }
                        },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = SleekPurpleLight),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("Create", fontWeight = FontWeight.Bold, color = Color.White)
                    }
                }
            }
        }
    }
}

val InstagramSunsetGradient = Brush.linearGradient(
    colors = listOf(
        Color(0xFF833AB4),
        Color(0xFFC13584),
        Color(0xFFE1306C),
        Color(0xFFFD1D1D),
        Color(0xFFFCAF45)
    )
)

@OptIn(androidx.compose.animation.ExperimentalAnimationApi::class)
@Composable
fun InstagramSmoothIconPack(
    icon: ImageVector,
    contentDescription: String? = null,
    modifier: Modifier = Modifier,
    iconSize: Dp = 22.dp,
    containerSize: Dp = 46.dp,
    isSelected: Boolean = false,
    badgeText: String? = null,
    onClick: (() -> Unit)? = null
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (isPressed) 0.88f else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMediumLow),
        label = "instaIconScale"
    )

    Box(
        modifier = modifier
            .size(containerSize)
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            }
            .then(if (onClick != null) Modifier.clickable(interactionSource = interactionSource, indication = null) { onClick() } else Modifier),
        contentAlignment = Alignment.Center
    ) {
        // Soft blurred glow aura background (simulating cut and blurred glowing Instagram boundaries)
        Box(
            modifier = Modifier
                .fillMaxSize(0.96f)
                .graphicsLayer { alpha = if (isSelected) 0.85f else 0.40f }
                .background(
                    brush = InstagramSunsetGradient,
                    shape = RoundedCornerShape(16.dp)
                )
        )

        // Frosted translucent cutout container
        Surface(
            shape = RoundedCornerShape(14.dp),
            color = if (isSelected) Color(0xD9220D32) else Color(0x66121324),
            border = BorderStroke(
                width = 1.2.dp,
                brush = InstagramSunsetGradient
            ),
            shadowElevation = if (isSelected) 8.dp else 2.dp,
            modifier = Modifier.fillMaxSize(0.88f)
        ) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier.fillMaxSize()
            ) {
                androidx.compose.animation.AnimatedContent(
                    targetState = icon,
                    transitionSpec = {
                        (scaleIn(animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy)) + fadeIn(tween(140))) togetherWith
                        (scaleOut(animationSpec = tween(120)) + fadeOut(tween(120)))
                    },
                    label = "InstaIconAnim"
                ) { currentIcon ->
                    Icon(
                        imageVector = currentIcon,
                        contentDescription = contentDescription,
                        tint = Color.White,
                        modifier = Modifier.size(iconSize)
                    )
                }

                if (badgeText != null) {
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = Color(0xFFE1306C),
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(2.dp)
                    ) {
                        Text(
                            text = badgeText,
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                        )
                    }
                }
            }
        }
    }
}

@OptIn(androidx.compose.animation.ExperimentalAnimationApi::class)
@Composable
fun FuturisticGlassButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    size: Dp = 52.dp,
    icon: ImageVector,
    iconSize: Dp = 24.dp,
    contentDescription: String? = null,
    isPrimary: Boolean = false,
    isGlowing: Boolean = false,
    tint: Color = Color.White,
    badgeText: String? = null,
    enabled: Boolean = true
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()

    val scale by animateFloatAsState(
        targetValue = if (isPressed) 0.86f else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMediumLow),
        label = "btnScale"
    )

    val rotation by animateFloatAsState(
        targetValue = if (isPressed) 7f else 0f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
        label = "btnRotation"
    )

    val infiniteTransition = rememberInfiniteTransition(label = "PrimaryGlow")
    val glowAlpha by if (isGlowing || isPrimary) {
        infiniteTransition.animateFloat(
            initialValue = 0.35f,
            targetValue = 0.88f,
            animationSpec = infiniteRepeatable(
                animation = tween(1100, easing = FastOutSlowInEasing),
                repeatMode = RepeatMode.Reverse
            ),
            label = "GlowAlpha"
        )
    } else {
        remember { mutableFloatStateOf(0f) }
    }

    Box(
        modifier = modifier
            .sizeIn(minWidth = 44.dp, minHeight = 44.dp)
            .size(size)
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
                rotationZ = rotation
            },
        contentAlignment = Alignment.Center
    ) {
        if (isPrimary || isGlowing) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer { alpha = glowAlpha }
                    .background(
                        brush = Brush.radialGradient(
                            colors = listOf(
                                Color(0xFFE1306C).copy(alpha = 0.65f),
                                Color(0xFF833AB4).copy(alpha = 0.25f),
                                Color.Transparent
                            )
                        ),
                        shape = CircleShape
                    )
            )
        }

        Surface(
            onClick = onClick,
            enabled = enabled,
            interactionSource = interactionSource,
            shape = CircleShape,
            color = if (isPrimary) Color(0xFFC13584).copy(alpha = 0.94f) else Color(0x59181828),
            border = BorderStroke(
                width = 1.2.dp,
                brush = if (isPrimary) {
                    InstagramSunsetGradient
                } else {
                    Brush.linearGradient(
                        colors = listOf(
                            Color.White.copy(alpha = 0.42f),
                            Color.White.copy(alpha = 0.12f)
                        )
                    )
                }
            ),
            shadowElevation = if (isPrimary) 14.dp else 4.dp,
            modifier = Modifier.fillMaxSize()
        ) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier.fillMaxSize()
            ) {
                androidx.compose.animation.AnimatedContent(
                    targetState = icon,
                    transitionSpec = {
                        (scaleIn(animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMediumLow)) + fadeIn(tween(150))) togetherWith
                        (scaleOut(animationSpec = tween(120)) + fadeOut(tween(120)))
                    },
                    label = "GlassButtonIconAnim"
                ) { currentIcon ->
                    Icon(
                        imageVector = currentIcon,
                        contentDescription = contentDescription,
                        tint = tint,
                        modifier = Modifier.size(iconSize)
                    )
                }

                if (badgeText != null) {
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = Color(0xFFE1306C),
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(2.dp)
                    ) {
                        Text(
                            text = badgeText,
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                        )
                    }
                }
            }
        }
    }
}

@OptIn(androidx.compose.animation.ExperimentalAnimationApi::class)
@Composable
fun DockControlItem(
    icon: ImageVector,
    label: String,
    onClick: () -> Unit,
    isActive: Boolean = false
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (isPressed) 0.90f else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMediumLow),
        label = "dockItemScale"
    )

    Surface(
        onClick = onClick,
        interactionSource = interactionSource,
        shape = RoundedCornerShape(18.dp),
        color = if (isActive) Color(0xFFC13584).copy(alpha = 0.28f) else Color(0x42202038),
        border = BorderStroke(
            1.dp,
            if (isActive) {
                InstagramSunsetGradient
            } else {
                Brush.linearGradient(listOf(Color.White.copy(alpha = 0.22f), Color.White.copy(alpha = 0.08f)))
            }
        ),
        shadowElevation = if (isActive) 6.dp else 2.dp,
        modifier = Modifier
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            }
            .padding(horizontal = 3.dp, vertical = 2.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp)
        ) {
            androidx.compose.animation.AnimatedContent(
                targetState = icon,
                transitionSpec = {
                    (scaleIn(animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy)) + fadeIn(tween(140))) togetherWith
                    (scaleOut(animationSpec = tween(120)) + fadeOut(tween(120)))
                },
                label = "DockIconAnim"
            ) { currentIcon ->
                Icon(
                    imageVector = currentIcon,
                    contentDescription = label,
                    tint = if (isActive) Color(0xFFFCAF45) else Color.White,
                    modifier = Modifier.size(16.dp)
                )
            }

            androidx.compose.animation.AnimatedContent(
                targetState = label,
                transitionSpec = {
                    (fadeIn(animationSpec = tween(180)) + slideInVertically { -it / 2 }) togetherWith
                    (fadeOut(animationSpec = tween(140)) + slideOutVertically { it / 2 })
                },
                label = "DockLabelAnim"
            ) { currentLabel ->
                Text(
                    text = currentLabel,
                    fontSize = 11.sp,
                    fontWeight = if (isActive) FontWeight.Bold else FontWeight.SemiBold,
                    color = if (isActive) Color(0xFFFCAF45) else Color.White.copy(alpha = 0.95f),
                    maxLines = 1
                )
            }
        }
    }
}

/**
 * YouTube-style floating background audio mini-player bar shown above bottom navigation
 */
@Composable
fun YouTubeBackgroundMiniPlayerBar(
    media: DownloadEntity,
    isPlaying: Boolean,
    currentPosMs: Long,
    durationMs: Long,
    onTogglePlay: () -> Unit,
    onSeekRelative: (Long) -> Unit,
    onOpenFullPlayer: () -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    val progress = if (durationMs > 0L) (currentPosMs.toFloat() / durationMs.toFloat()).coerceIn(0f, 1f) else 0f

    Surface(
        shape = RoundedCornerShape(18.dp),
        color = Color(0xEB181926),
        border = BorderStroke(1.dp, Color(0x33A855F7)),
        shadowElevation = 12.dp,
        modifier = modifier
            .clip(RoundedCornerShape(18.dp))
            .clickable { onOpenFullPlayer() }
    ) {
        Column {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Thumbnail
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color(0xFF24273A)),
                    contentAlignment = Alignment.Center
                ) {
                    if (media.thumbnailUrl.isNotEmpty()) {
                        coil.compose.AsyncImage(
                            model = media.thumbnailUrl,
                            contentDescription = null,
                            modifier = Modifier.fillMaxSize(),
                            contentScale = androidx.compose.ui.layout.ContentScale.Crop
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Default.Headphones,
                            contentDescription = null,
                            tint = SleekPurpleLight,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    // Mini indicator badge
                    Box(
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .padding(2.dp)
                            .size(8.dp)
                            .background(if (isPlaying) Color(0xFF10B981) else Color(0xFFF59E0B), CircleShape)
                    )
                }

                // Title + Author + Background badge
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = media.title,
                        style = MaterialTheme.typography.bodyMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        ),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = SleekPurpleLight.copy(alpha = 0.2f),
                            border = BorderStroke(0.5.dp, SleekPurpleLight.copy(alpha = 0.5f))
                        ) {
                            Text(
                                "BACKGROUND",
                                fontSize = 8.sp,
                                fontWeight = FontWeight.Bold,
                                color = SleekPurpleLight,
                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                            )
                        }
                        Text(
                            text = if (media.author.isNotEmpty()) media.author else "Background Audio",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = Color.White.copy(alpha = 0.7f),
                                fontSize = 11.sp
                            ),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                // Fast Rewind 10s
                IconButton(
                    onClick = { onSeekRelative(-10000L) },
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.FastRewind,
                        contentDescription = "Rewind 10s",
                        tint = Color.White.copy(alpha = 0.85f),
                        modifier = Modifier.size(20.dp)
                    )
                }

                // Play / Pause
                FilledIconButton(
                    onClick = onTogglePlay,
                    colors = IconButtonDefaults.filledIconButtonColors(
                        containerColor = SleekPurpleLight,
                        contentColor = Color.White
                    ),
                    modifier = Modifier.size(38.dp)
                ) {
                    Icon(
                        imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                        contentDescription = if (isPlaying) "Pause" else "Play",
                        modifier = Modifier.size(20.dp)
                    )
                }

                // Fast Forward 10s
                IconButton(
                    onClick = { onSeekRelative(10000L) },
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.FastForward,
                        contentDescription = "Forward 10s",
                        tint = Color.White.copy(alpha = 0.85f),
                        modifier = Modifier.size(20.dp)
                    )
                }

                // Close Background Play
                IconButton(
                    onClick = onClose,
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Close Background Play",
                        tint = Color.White.copy(alpha = 0.6f),
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            // Progress bar at the bottom edge
            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(2.5.dp),
                color = SleekPurpleLight,
                trackColor = Color.White.copy(alpha = 0.1f)
            )
        }
    }
}

/**
 * Dedicated MiniPlayerOverlay component displaying exactly four corner-aligned control buttons:
 * - Top-Left: Play / Pause toggle
 * - Top-Right: Close player
 * - Bottom-Left: Return to Full Player
 * - Bottom-Right: Background Play
 */
@Composable
fun MiniPlayerOverlay(
    isPaused: Boolean,
    onTogglePlay: () -> Unit,
    onClose: () -> Unit,
    onReturnToFullPlayer: () -> Unit,
    onBackgroundPlay: () -> Unit,
    modifier: Modifier = Modifier
) {
    BoxWithConstraints(
        modifier = modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.38f))
            .padding(6.dp)
            .testTag("mini_player_overlay")
            .pointerInput(Unit) {
                detectTapGestures(
                    onDoubleTap = {
                        onReturnToFullPlayer()
                    }
                )
            }
    ) {
        val W = maxWidth
        val H = maxHeight
        val btnSize = minOf((W.value * 0.24f).dp, (H.value * 0.40f).dp).coerceIn(32.dp, 44.dp)
        val iconSize = (btnSize.value * 0.52f).dp.coerceIn(16.dp, 22.dp)

        // Top-Left: Play / Pause
        Box(modifier = Modifier.align(Alignment.TopStart)) {
            FuturisticGlassButton(
                onClick = onTogglePlay,
                size = btnSize,
                icon = if (isPaused) Icons.Default.PlayArrow else Icons.Default.Pause,
                iconSize = iconSize,
                contentDescription = if (isPaused) "Play" else "Pause",
                tint = Color.White,
                modifier = Modifier.testTag("mini_player_play_pause_button")
            )
        }

        // Top-Right: Close
        Box(modifier = Modifier.align(Alignment.TopEnd)) {
            FuturisticGlassButton(
                onClick = onClose,
                size = btnSize,
                icon = Icons.Default.Close,
                iconSize = iconSize,
                contentDescription = "Close Player",
                tint = CrimsonFailure,
                modifier = Modifier.testTag("mini_player_close_button")
            )
        }

        // Bottom-Left: Return to Full Player
        Box(modifier = Modifier.align(Alignment.BottomStart)) {
            FuturisticGlassButton(
                onClick = onReturnToFullPlayer,
                size = btnSize,
                icon = Icons.Default.Fullscreen,
                iconSize = iconSize,
                contentDescription = "Return to Full Player",
                tint = SleekPurpleLight,
                modifier = Modifier.testTag("mini_player_return_full_button")
            )
        }

        // Bottom-Right: Background Play
        Box(modifier = Modifier.align(Alignment.BottomEnd)) {
            FuturisticGlassButton(
                onClick = onBackgroundPlay,
                size = btnSize,
                icon = Icons.Default.Headphones,
                iconSize = iconSize,
                contentDescription = "Background Play",
                tint = Color(0xFFFFAB40),
                modifier = Modifier.testTag("mini_player_bg_play_button")
            )
        }
    }
}

@OptIn(androidx.compose.animation.ExperimentalAnimationApi::class)
@Composable
fun YouTubeStyleSeekBar(
    currentPosMs: Long,
    bufferedPosMs: Long,
    durationMs: Long,
    onSeekTo: (Long) -> Unit,
    modifier: Modifier = Modifier,
    isPlaying: Boolean = true,
    waveformData: AudioWaveformData? = null
) {
    SineWaveSeekBar(
        currentPosMs = currentPosMs,
        durationMs = durationMs,
        bufferedPosMs = bufferedPosMs,
        onSeekTo = onSeekTo,
        isPlaying = isPlaying,
        waveformData = waveformData,
        modifier = modifier
    )
}

@Composable
fun DownlyFuturisticControlsOverlay(
    media: DownloadEntity,
    currentPosMs: Long,
    bufferedPosMs: Long = 0L,
    durationMs: Long,
    isPaused: Boolean,
    isMuted: Boolean,
    speed: Float,
    resizeModeState: Int,
    isLocked: Boolean,
    isFavorite: Boolean,
    sleepTimerMinutes: Int,
    audioTracksCount: Int,
    subtitleTracksCount: Int,
    isFullscreen: Boolean,
    showPipControlsOnPlayer: Boolean,
    isCustomPipMini: Boolean,
    waveformData: AudioWaveformData? = null,
    markers: List<com.example.data.MediaMarkerEntity> = emptyList(),
    onTogglePlay: () -> Unit,
    onSeekTo: (Long) -> Unit,
    onSeekRelative: (Long) -> Unit,
    onToggleMute: () -> Unit,
    onChangeSpeed: () -> Unit,
    onCycleResizeMode: () -> Unit,
    onToggleLock: () -> Unit,
    onToggleFavorite: () -> Unit,
    onCycleSleepTimer: () -> Unit,
    onOpenAudioFxStudio: (() -> Unit)?,
    onOpenAdvancedSettings: () -> Unit,
    onOpenAudioTracks: () -> Unit,
    onOpenSubtitles: () -> Unit,
    onOpenTrimmer: () -> Unit,
    onTogglePipMini: () -> Unit,
    onTriggerBackgroundPlay: () -> Unit = {},
    onOpenAddMarker: () -> Unit = {},
    onOpenMarkerList: () -> Unit = {},
    onOpenVideoAdjustments: () -> Unit = {},
    colorAdjustments: VideoColorAdjustments = VideoColorAdjustments(),
    onOpenAudioEffects: () -> Unit = {},
    audioEffectConfig: AudioEffectConfig = AudioEffectConfig(),
    onToggleFullscreen: () -> Unit,
    onCopyCodecReport: (() -> Unit)? = null,
    onClose: () -> Unit
) {
    val context = LocalContext.current
    var showMetadataOverlay by remember { mutableStateOf(false) }
    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val W = maxWidth
        val H = maxHeight
        val isMobile = W < 600.dp
        
        Crossfade(
            targetState = (!isFullscreen || isCustomPipMini),
            animationSpec = tween(250, easing = FastOutSlowInEasing),
            label = "MiniVsFullOverlayTransition",
            modifier = Modifier.fillMaxSize()
        ) { isMiniMode ->
            if (isMiniMode) {
                MiniPlayerOverlay(
                    isPaused = isPaused,
                    onTogglePlay = onTogglePlay,
                    onClose = onClose,
                    onReturnToFullPlayer = onTogglePipMini,
                    onBackgroundPlay = onTriggerBackgroundPlay
                )
            } else if (isLocked) {
                Box(
                    modifier = Modifier.fillMaxSize().padding(top = 24.dp),
                    contentAlignment = Alignment.TopCenter
                ) {
                    Surface(
                        shape = RoundedCornerShape(24.dp),
                        color = Color(8, 8, 12, 210),
                        border = BorderStroke(1.dp, Color(0xFFFF6D00).copy(alpha = 0.6f)),
                        modifier = Modifier.padding(16.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            FuturisticGlassButton(
                                onClick = onToggleLock,
                                size = 48.dp,
                                icon = Icons.Default.Lock,
                                iconSize = 22.dp,
                                contentDescription = "Unlock Controls",
                                isGlowing = true,
                                tint = Color(0xFFFF6D00)
                            )
                            Column {
                                Text("Player Locked", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold), color = Color.White)
                                Text("Tap lock icon to unlock controls", style = MaterialTheme.typography.labelSmall, color = SleekTextMuted)
                            }
                        }
                    }
                }
            } else {
                Box(modifier = Modifier.fillMaxSize()) {
                    // Dimmed background
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color(8, 8, 12, 115))
                    )
                    
                    // TOP BAR
                    val headerMarginX = (W * 0.028f).coerceIn(12.dp, 32.dp)
                    val headerMarginTop = (H * 0.025f).coerceIn(8.dp, 20.dp)
                    val headerIconBtnSize = if (isMobile) 36.dp else 42.dp
                    val headerIconSize = if (isMobile) 20.dp else 24.dp

                    Row(
                        modifier = Modifier
                            .align(Alignment.TopCenter)
                            .statusBarsPadding()
                            .padding(start = headerMarginX, end = headerMarginX, top = headerMarginTop)
                            .fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        // Left: Large smooth back arrow + Filename/Title
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f, fill = false)
                        ) {
                            IconButton(
                                onClick = onClose,
                                modifier = Modifier.size(if (isMobile) 42.dp else 48.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                    contentDescription = "Back",
                                    tint = Color.White,
                                    modifier = Modifier.size(if (isMobile) 28.dp else 32.dp)
                                )
                            }

                            Spacer(modifier = Modifier.width(if (isMobile) 6.dp else 10.dp))

                            Column(
                                verticalArrangement = Arrangement.Center,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .clickable { showMetadataOverlay = !showMetadataOverlay }
                                    .padding(horizontal = 4.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = media.title,
                                    style = MaterialTheme.typography.titleLarge.copy(
                                        color = Color.White,
                                        fontSize = if (isMobile) 17.sp else 21.sp,
                                        fontWeight = FontWeight.Bold,
                                        shadow = androidx.compose.ui.graphics.Shadow(
                                            color = Color.Black.copy(alpha = 0.85f),
                                            offset = androidx.compose.ui.geometry.Offset(0f, 1f),
                                            blurRadius = 6f
                                        )
                                    ),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                if (sleepTimerMinutes > 0) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.clickable { onCycleSleepTimer() }
                                    ) {
                                        Icon(Icons.Default.Timer, contentDescription = null, tint = SleekPurpleLight, modifier = Modifier.size(12.dp))
                                        Spacer(modifier = Modifier.width(3.dp))
                                        Text(
                                            "${sleepTimerMinutes}m",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color.White,
                                            style = MaterialTheme.typography.bodySmall.copy(
                                                shadow = androidx.compose.ui.graphics.Shadow(
                                                    color = Color.Black.copy(alpha = 0.85f),
                                                    blurRadius = 4f
                                                )
                                            )
                                        )
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        // Right: 9 Header Buttons (No background, no borders, clean white icons)
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(if (isMobile) 2.dp else 6.dp)
                        ) {
                            IconButton(
                                onClick = onOpenAddMarker,
                                modifier = Modifier.size(headerIconBtnSize)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.BookmarkAdd,
                                    contentDescription = "Add Marker",
                                    tint = Color(0xFFFFAB40),
                                    modifier = Modifier.size(headerIconSize)
                                )
                            }

                            IconButton(
                                onClick = onOpenMarkerList,
                                modifier = Modifier.size(headerIconBtnSize)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Bookmarks,
                                    contentDescription = "Marker List",
                                    tint = Color.White,
                                    modifier = Modifier.size(headerIconSize)
                                )
                            }

                            IconButton(
                                onClick = onToggleLock,
                                modifier = Modifier.size(headerIconBtnSize)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.LockOpen,
                                    contentDescription = "Lock Player",
                                    tint = Color.White,
                                    modifier = Modifier.size(headerIconSize)
                                )
                            }

                            IconButton(
                                onClick = onTriggerBackgroundPlay,
                                modifier = Modifier.size(headerIconBtnSize)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Headphones,
                                    contentDescription = "Background Audio Play",
                                    tint = Color(0xFFFFAB40),
                                    modifier = Modifier.size(headerIconSize)
                                )
                            }

                            IconButton(
                                onClick = onOpenVideoAdjustments,
                                modifier = Modifier.size(headerIconBtnSize)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Tune,
                                    contentDescription = "Video Adjustments",
                                    tint = if (!colorAdjustments.isDefault) Color(0xFFFFAB40) else Color.White,
                                    modifier = Modifier.size(headerIconSize)
                                )
                            }

                            IconButton(
                                onClick = onOpenAudioEffects,
                                modifier = Modifier.size(headerIconBtnSize)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.SurroundSound,
                                    contentDescription = "Audio Effects",
                                    tint = if (audioEffectConfig.isEnabled) Color(0xFFFFAB40) else Color.White,
                                    modifier = Modifier.size(headerIconSize)
                                )
                            }

                            IconButton(
                                onClick = onToggleMute,
                                modifier = Modifier.size(headerIconBtnSize)
                            ) {
                                Icon(
                                    imageVector = if (isMuted) Icons.Default.VolumeOff else Icons.Default.VolumeUp,
                                    contentDescription = "Toggle Mute",
                                    tint = if (isMuted) Color(0xFFFF5A5F) else Color.White,
                                    modifier = Modifier.size(headerIconSize)
                                )
                            }

                            IconButton(
                                onClick = onToggleFavorite,
                                modifier = Modifier.size(headerIconBtnSize)
                            ) {
                                Icon(
                                    imageVector = if (isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                                    contentDescription = "Toggle Favorite",
                                    tint = if (isFavorite) Color(0xFFFF5A5F) else Color.White,
                                    modifier = Modifier.size(headerIconSize)
                                )
                            }

                            IconButton(
                                onClick = onOpenAdvancedSettings,
                                modifier = Modifier.size(headerIconBtnSize)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.MoreVert,
                                    contentDescription = "Advanced Settings",
                                    tint = Color.White,
                                    modifier = Modifier.size(headerIconSize)
                                )
                            }
                        }
                    }
                
                    // CENTER CONTROLS
                    val playBtnSize = if (isMobile) (if (isFullscreen) 80.dp else 72.dp) else (if (isFullscreen) 96.dp else 88.dp)
                    val secBtnSize = if (isMobile) (if (isFullscreen) 56.dp else 48.dp) else (if (isFullscreen) 64.dp else 56.dp)
                
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .align(Alignment.Center)
                            .offset(y = (-4).dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(if (isMobile) 16.dp else 24.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            FuturisticGlassButton(onClick = { onSeekRelative(-10000L) }, size = secBtnSize, icon = Icons.Default.FastRewind)
                            FuturisticGlassButton(onClick = { onSeekTo(0L) }, size = secBtnSize, icon = Icons.Default.SkipPrevious)
                            FuturisticGlassButton(
                                onClick = onTogglePlay, 
                                size = playBtnSize, 
                                icon = if (isPaused) Icons.Default.PlayArrow else Icons.Default.Pause, 
                                iconSize = (playBtnSize.value * 0.45f).dp, 
                                isGlowing = true, 
                                isPrimary = true
                            )
                            FuturisticGlassButton(onClick = { onSeekTo(durationMs) }, size = secBtnSize, icon = Icons.Default.SkipNext)
                            FuturisticGlassButton(onClick = { onSeekRelative(10000L) }, size = secBtnSize, icon = Icons.Default.FastForward)
                        }
                    }
                
                    // BOTTOM AREA
                    val markerPositions = remember(markers, durationMs) {
                        if (durationMs > 0L) {
                            markers.map { (it.positionMs.toFloat() / durationMs.toFloat()).coerceIn(0f, 1f) }
                        } else emptyList()
                    }

                    Box(
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .fillMaxWidth()
                            .padding(start = 16.dp, end = 16.dp, bottom = 24.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Box(modifier = Modifier.weight(1f)) {
                                SineWaveSeekBar(
                                    currentPosMs = currentPosMs,
                                    durationMs = durationMs,
                                    bufferedPosMs = bufferedPosMs,
                                    waveformData = waveformData,
                                    onSeekTo = onSeekTo,
                                    isPlaying = !isPaused,
                                    markerPositions = markerPositions
                                )
                            }

                            Text(
                                text = "${formatTimeMs(currentPosMs)} / ${formatTimeMs(durationMs)}",
                                style = MaterialTheme.typography.labelMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    fontFamily = FontFamily.Monospace
                                ),
                                color = Color.White.copy(alpha = 0.9f),
                                maxLines = 1
                            )
                            
                            FuturisticGlassButton(
                                onClick = onToggleFullscreen,
                                size = 52.dp,
                                icon = if (isFullscreen) Icons.Default.FullscreenExit else Icons.Default.Fullscreen
                            )
                        }
                    }

                    // MEDIA METADATA OVERLAY
                    if (showMetadataOverlay) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .pointerInput(Unit) {
                                    detectTapGestures {
                                        showMetadataOverlay = false
                                    }
                                }
                        )

                        AnimatedVisibility(
                            visible = showMetadataOverlay,
                            enter = fadeIn(animationSpec = tween(220, easing = FastOutSlowInEasing)) +
                                    slideInVertically(animationSpec = tween(220, easing = FastOutSlowInEasing)) { -30 },
                            exit = fadeOut(animationSpec = tween(180, easing = FastOutSlowInEasing)) +
                                   slideOutVertically(animationSpec = tween(180, easing = FastOutSlowInEasing)) { -20 },
                            modifier = Modifier
                                .align(Alignment.TopStart)
                                .statusBarsPadding()
                                .padding(start = headerMarginX, top = headerMarginTop + (if (isMobile) 48.dp else 56.dp))
                        ) {
                            MediaMetadataCardOverlay(
                                media = media,
                                durationMs = durationMs,
                                maxWidth = (W * 0.88f).coerceAtMost(380.dp),
                                maxHeight = H * 0.65f,
                                onDismiss = { showMetadataOverlay = false },
                                onCopyCodecReport = onCopyCodecReport
                            )
                        }
                    }
                }
            }
        }
    }
}

private data class MetadataRowData(
    val icon: androidx.compose.ui.graphics.vector.ImageVector,
    val label: String,
    val value: String,
    val actionIcon: androidx.compose.ui.graphics.vector.ImageVector? = null,
    val onClick: (() -> Unit)? = null
)

@Composable
fun MediaMetadataCardOverlay(
    media: DownloadEntity,
    durationMs: Long,
    maxWidth: Dp,
    maxHeight: Dp,
    onDismiss: () -> Unit,
    onCopyCodecReport: (() -> Unit)? = null
) {
    val context = LocalContext.current
    val openUrl = remember(context) {
        { url: String ->
            if (url.isNotBlank() && (url.startsWith("http://") || url.startsWith("https://"))) {
                try {
                    val intent = android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(url))
                    context.startActivity(intent)
                } catch (e: Exception) {
                    // Ignore
                }
            }
        }
    }

    val rows = remember(media, durationMs, openUrl) {
        val list = mutableListOf<MetadataRowData>()

        // Source Platform
        val platformName = when {
            media.originalUrl.contains("instagram.com", ignoreCase = true) -> "Instagram"
            media.originalUrl.contains("youtube.com", ignoreCase = true) || media.originalUrl.contains("youtu.be", ignoreCase = true) -> "YouTube"
            media.originalUrl.contains("tiktok.com", ignoreCase = true) -> "TikTok"
            media.originalUrl.contains("twitter.com", ignoreCase = true) || media.originalUrl.contains("x.com", ignoreCase = true) -> "X"
            media.originalUrl.contains("facebook.com", ignoreCase = true) -> "Facebook"
            media.originalUrl.contains("vimeo.com", ignoreCase = true) -> "Vimeo"
            media.originalUrl.contains("reddit.com", ignoreCase = true) -> "Reddit"
            media.originalUrl.isNotBlank() -> try {
                val uri = android.net.Uri.parse(media.originalUrl)
                uri.host?.removePrefix("www.")?.replaceFirstChar { if (it.isLowerCase()) it.titlecase(java.util.Locale.getDefault()) else it.toString() } ?: "Direct Website"
            } catch (e: Exception) { "Direct Website" }
            else -> ""
        }
        if (platformName.isNotBlank()) {
            val hasValidUrl = media.originalUrl.startsWith("http://") || media.originalUrl.startsWith("https://")
            list.add(
                MetadataRowData(
                    icon = Icons.Outlined.CameraAlt,
                    label = "Source",
                    value = platformName,
                    actionIcon = if (hasValidUrl) Icons.AutoMirrored.Outlined.OpenInNew else null,
                    onClick = if (hasValidUrl) { { openUrl(media.originalUrl) } } else null
                )
            )
        }

        // Download Date
        if (media.downloadedAt > 0L) {
            val formattedDate = try {
                val sdf = java.text.SimpleDateFormat("MMM dd, yyyy · hh:mm a", java.util.Locale.getDefault())
                sdf.format(java.util.Date(media.downloadedAt))
            } catch (e: Exception) { "" }
            if (formattedDate.isNotBlank()) {
                list.add(
                    MetadataRowData(
                        icon = Icons.Outlined.FileDownload,
                        label = "Downloaded on",
                        value = formattedDate
                    )
                )
            }
        }

        // Duration
        val durationStr = when {
            media.durationText.isNotBlank() && media.durationText != "00:00" -> media.durationText
            durationMs > 0 -> formatTimeMs(durationMs)
            else -> ""
        }
        if (durationStr.isNotBlank()) {
            list.add(
                MetadataRowData(
                    icon = Icons.Outlined.Schedule,
                    label = "Duration",
                    value = durationStr
                )
            )
        }

        // File name
        if (media.title.isNotBlank()) {
            list.add(
                MetadataRowData(
                    icon = Icons.AutoMirrored.Outlined.InsertDriveFile,
                    label = "File name",
                    value = media.title
                )
            )
        }

        // File size
        val sizeBytes = if (media.fileSize > 0) media.fileSize else if (media.expectedSize > 0) media.expectedSize else 0L
        if (sizeBytes > 0) {
            list.add(
                MetadataRowData(
                    icon = Icons.Outlined.SdCard,
                    label = "File size",
                    value = formatBytes(sizeBytes)
                )
            )
        }

        list
    }

    Surface(
        shape = RoundedCornerShape(24.dp),
        color = Color(0xD90A0A0A), // Dark translucent glass surface
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.08f)),
        modifier = Modifier
            .widthIn(max = maxWidth)
            .heightIn(max = maxHeight)
            .pointerInput(Unit) { detectTapGestures { } } // Block touches
    ) {
        Column(
            modifier = Modifier.verticalScroll(rememberScrollState())
        ) {
            // Drag handle
            Box(
                modifier = Modifier
                    .padding(top = 16.dp, bottom = 12.dp)
                    .width(40.dp)
                    .height(4.dp)
                    .background(Color.White.copy(alpha = 0.3f), CircleShape)
                    .align(Alignment.CenterHorizontally)
            )

            // Title
            val titleText = if (media.author.isNotBlank() && !media.author.contains("Unknown", ignoreCase = true)) {
                "Video by ${media.author}"
            } else {
                media.title
            }
            Text(
                text = titleText,
                color = Color.White,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 24.dp, vertical = 12.dp)
            )

            Spacer(Modifier.height(8.dp))

            // Creator Row
            if (media.author.isNotBlank() && !media.author.contains("Unknown", ignoreCase = true)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(horizontal = 24.dp).fillMaxWidth()
                ) {
                    Box(
                        modifier = Modifier
                            .size(60.dp)
                            .border(1.5.dp, Color(0xFFF91854), CircleShape) // Thin accent-colored outline
                            .padding(4.dp)
                            .clip(CircleShape)
                            .background(Color.DarkGray)
                    ) {
                        if (media.thumbnailUrl.isNotBlank()) {
                            AsyncImage(
                                model = media.thumbnailUrl,
                                contentDescription = null,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                        }
                    }
                    Spacer(Modifier.width(16.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = media.author,
                            color = Color.White,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(Modifier.width(12.dp))
                    val hasValidUrl = media.originalUrl.startsWith("http://") || media.originalUrl.startsWith("https://")
                    if (hasValidUrl) {
                        Surface(
                            shape = CircleShape,
                            color = Color.Transparent,
                            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.2f)),
                            modifier = Modifier.clickable { openUrl(media.originalUrl) }
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                            ) {
                                Text("View Page", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                                Spacer(Modifier.width(2.dp))
                                Icon(Icons.Default.ChevronRight, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                            }
                        }
                    }
                }
                Spacer(Modifier.height(24.dp))
            }

            // Metadata Rows
            rows.forEachIndexed { index, row ->
                HorizontalDivider(color = Color.White.copy(alpha = 0.08f), thickness = 0.5.dp)
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .then(
                            if (row.onClick != null) Modifier.clickable { row.onClick.invoke() }
                            else Modifier
                        )
                        .padding(horizontal = 24.dp, vertical = 18.dp)
                ) {
                    Icon(row.icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(24.dp))
                    Spacer(Modifier.width(24.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = row.label,
                            color = Color.White.copy(alpha = 0.6f),
                            fontSize = 13.sp
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            text = row.value,
                            color = Color.White,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                    if (row.actionIcon != null) {
                        Icon(row.actionIcon, contentDescription = null, tint = Color.White, modifier = Modifier.size(22.dp))
                    }
                }
            }

            if (onCopyCodecReport != null) {
                HorizontalDivider(color = Color.White.copy(alpha = 0.08f), thickness = 0.5.dp)
                Button(
                    onClick = onCopyCodecReport,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF2563EB),
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 24.dp, vertical = 14.dp)
                        .testTag("copy_codec_report_metadata_button")
                ) {
                    Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("COPY CODEC REPORT", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }
            }

            HorizontalDivider(color = Color.White.copy(alpha = 0.08f), thickness = 0.5.dp)

            // Bottom Chevron
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable(onClick = onDismiss)
                    .padding(16.dp),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.KeyboardArrowUp, contentDescription = "Close", tint = Color.White, modifier = Modifier.size(28.dp))
            }
        }
    }
}
@Composable
fun AudioStreamSelectionDialog(
    audioTracks: List<PlayerAudioTrack>,
    isAudioDisabled: Boolean,
    onDisableAudio: () -> Unit,
    onSelectTrack: (PlayerAudioTrack) -> Unit,
    onDismiss: () -> Unit
) {
    androidx.compose.ui.window.Dialog(
        onDismissRequest = onDismiss
    ) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = Color(0xFF14151F),
            border = BorderStroke(1.2.dp, SleekPurpleDark.copy(alpha = 0.6f)),
            shadowElevation = 16.dp,
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .testTag("audio_stream_selection_dialog")
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .background(SleekPurpleDark.copy(alpha = 0.3f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.GraphicEq,
                            contentDescription = null,
                            tint = SleekPurpleLight,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Audio Stream & Track",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = Color.White
                        )
                        Text(
                            text = "Switch audio language or turn off audio stream",
                            style = MaterialTheme.typography.labelMedium,
                            color = SleekTextSecondary
                        )
                    }
                    IconButton(onClick = onDismiss, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = SleekTextSecondary)
                    }
                }

                HorizontalDivider(color = SleekBorderColor.copy(alpha = 0.5f))

                // Option 1: Audio Off
                Surface(
                    onClick = onDisableAudio,
                    shape = RoundedCornerShape(14.dp),
                    color = if (isAudioDisabled) SleekPurpleDark.copy(alpha = 0.35f) else Color(0xFF1D1F2E),
                    border = BorderStroke(
                        1.2.dp,
                        if (isAudioDisabled) SleekPurpleLight else SleekBorderColor.copy(alpha = 0.4f)
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("option_audio_off")
                ) {
                    Row(
                        modifier = Modifier
                            .padding(14.dp)
                            .fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.VolumeOff,
                            contentDescription = null,
                            tint = if (isAudioDisabled) CrimsonFailure else SleekTextSecondary,
                            modifier = Modifier.size(22.dp)
                        )
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Audio Off (Disable Stream)",
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                color = if (isAudioDisabled) Color.White else SleekTextPrimary
                            )
                            Text(
                                text = "Mute audio output completely",
                                style = MaterialTheme.typography.labelSmall,
                                color = SleekTextSecondary
                            )
                        }
                        RadioButton(
                            selected = isAudioDisabled,
                            onClick = onDisableAudio,
                            colors = RadioButtonDefaults.colors(
                                selectedColor = SleekPurpleLight,
                                unselectedColor = SleekTextSecondary
                            )
                        )
                    }
                }

                if (audioTracks.isNotEmpty()) {
                    Text(
                        text = "Embedded Audio Tracks (${audioTracks.size})",
                        style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                        color = SleekTextSecondary,
                        modifier = Modifier.padding(top = 4.dp)
                    )

                    audioTracks.forEachIndexed { idx, track ->
                        val isSel = !isAudioDisabled && track.isSelected
                        Surface(
                            onClick = { onSelectTrack(track) },
                            shape = RoundedCornerShape(14.dp),
                            color = if (isSel) SleekPurpleDark.copy(alpha = 0.35f) else Color(0xFF1D1F2E),
                            border = BorderStroke(
                                1.2.dp,
                                if (isSel) SleekPurpleLight else SleekBorderColor.copy(alpha = 0.4f)
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("audio_track_item_$idx")
                        ) {
                            Row(
                                modifier = Modifier
                                    .padding(14.dp)
                                    .fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Audiotrack,
                                    contentDescription = null,
                                    tint = if (isSel) SleekPurpleLight else SleekTextSecondary,
                                    modifier = Modifier.size(22.dp)
                                )
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = track.name,
                                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                        color = if (isSel) Color.White else SleekTextPrimary
                                    )
                                    Row(
                                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.padding(top = 2.dp)
                                    ) {
                                        Text(
                                            text = "Lang: ${track.language}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = SleekTextSecondary
                                        )
                                        if (track.isSupported) {
                                            Surface(
                                                shape = RoundedCornerShape(6.dp),
                                                color = Color(0xFF10281E)
                                            ) {
                                                Text(
                                                    text = "Supported",
                                                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp),
                                                    color = Color(0xFF34D399),
                                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                                RadioButton(
                                    selected = isSel,
                                    onClick = { onSelectTrack(track) },
                                    colors = RadioButtonDefaults.colors(
                                        selectedColor = SleekPurpleLight,
                                        unselectedColor = SleekTextSecondary
                                    )
                                )
                            }
                        }
                    }
                } else {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 12.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "No additional audio tracks found in this media stream.",
                            style = MaterialTheme.typography.bodySmall,
                            color = SleekTextSecondary
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun SubtitleStreamSelectionDialog(
    subtitleTracks: List<PlayerSubtitleTrack>,
    isSubtitleDisabled: Boolean,
    externalSubtitleUri: String?,
    onDisableSubtitles: () -> Unit,
    onSelectTrack: (PlayerSubtitleTrack) -> Unit,
    onPickExternalSubtitle: () -> Unit,
    onDismiss: () -> Unit
) {
    androidx.compose.ui.window.Dialog(
        onDismissRequest = onDismiss
    ) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = Color(0xFF14151F),
            border = BorderStroke(1.2.dp, SleekPurpleDark.copy(alpha = 0.6f)),
            shadowElevation = 16.dp,
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .testTag("subtitle_stream_selection_dialog")
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .background(SleekPurpleDark.copy(alpha = 0.3f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.ClosedCaption,
                            contentDescription = null,
                            tint = SleekPurpleLight,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Subtitle Stream & Options",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = Color.White
                        )
                        Text(
                            text = "Select subtitle stream, load external file, or turn off",
                            style = MaterialTheme.typography.labelMedium,
                            color = SleekTextSecondary
                        )
                    }
                    IconButton(onClick = onDismiss, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = SleekTextSecondary)
                    }
                }

                HorizontalDivider(color = SleekBorderColor.copy(alpha = 0.5f))

                // Option 1: Subtitles Off
                val isOffSelected = isSubtitleDisabled && externalSubtitleUri == null
                Surface(
                    onClick = onDisableSubtitles,
                    shape = RoundedCornerShape(14.dp),
                    color = if (isOffSelected) SleekPurpleDark.copy(alpha = 0.35f) else Color(0xFF1D1F2E),
                    border = BorderStroke(
                        1.2.dp,
                        if (isOffSelected) SleekPurpleLight else SleekBorderColor.copy(alpha = 0.4f)
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("option_subtitles_off")
                ) {
                    Row(
                        modifier = Modifier
                            .padding(14.dp)
                            .fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.SubtitlesOff,
                            contentDescription = null,
                            tint = if (isOffSelected) CrimsonFailure else SleekTextSecondary,
                            modifier = Modifier.size(22.dp)
                        )
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Subtitles Off",
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                color = if (isOffSelected) Color.White else SleekTextPrimary
                            )
                            Text(
                                text = "Disable subtitle overlay on screen",
                                style = MaterialTheme.typography.labelSmall,
                                color = SleekTextSecondary
                            )
                        }
                        RadioButton(
                            selected = isOffSelected,
                            onClick = onDisableSubtitles,
                            colors = RadioButtonDefaults.colors(
                                selectedColor = SleekPurpleLight,
                                unselectedColor = SleekTextSecondary
                            )
                        )
                    }
                }

                // Option 2: Load External Subtitle File (.srt, .vtt, .ass)
                Surface(
                    onClick = onPickExternalSubtitle,
                    shape = RoundedCornerShape(14.dp),
                    color = if (externalSubtitleUri != null) SleekPurpleDark.copy(alpha = 0.35f) else Color(0xFF1D1F2E),
                    border = BorderStroke(
                        1.2.dp,
                        if (externalSubtitleUri != null) SleekPurpleLight else SleekBorderColor.copy(alpha = 0.4f)
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("option_load_external_subtitle")
                ) {
                    Row(
                        modifier = Modifier
                            .padding(14.dp)
                            .fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.FolderOpen,
                            contentDescription = null,
                            tint = SleekPurpleLight,
                            modifier = Modifier.size(22.dp)
                        )
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Load External Subtitle File",
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                color = Color.White
                            )
                            Text(
                                text = if (externalSubtitleUri != null)
                                    "Loaded: ${externalSubtitleUri.substringAfterLast("/")}"
                                else
                                    "Import .srt, .vtt, or .ass file from device storage",
                                style = MaterialTheme.typography.labelSmall,
                                color = if (externalSubtitleUri != null) SleekPurpleLight else SleekTextSecondary
                            )
                        }
                        Icon(
                            imageVector = Icons.Default.FileUpload,
                            contentDescription = null,
                            tint = SleekPurpleLight,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }

                // Embedded Subtitles List
                if (subtitleTracks.isNotEmpty()) {
                    Text(
                        text = "Embedded Subtitle Streams (${subtitleTracks.size})",
                        style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                        color = SleekTextSecondary,
                        modifier = Modifier.padding(top = 4.dp)
                    )

                    subtitleTracks.forEachIndexed { idx, track ->
                        val isSel = !isSubtitleDisabled && externalSubtitleUri == null && track.isSelected
                        Surface(
                            onClick = { onSelectTrack(track) },
                            shape = RoundedCornerShape(14.dp),
                            color = if (isSel) SleekPurpleDark.copy(alpha = 0.35f) else Color(0xFF1D1F2E),
                            border = BorderStroke(
                                1.2.dp,
                                if (isSel) SleekPurpleLight else SleekBorderColor.copy(alpha = 0.4f)
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("subtitle_track_item_$idx")
                        ) {
                            Row(
                                modifier = Modifier
                                    .padding(14.dp)
                                    .fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Subtitles,
                                    contentDescription = null,
                                    tint = if (isSel) SleekPurpleLight else SleekTextSecondary,
                                    modifier = Modifier.size(22.dp)
                                )
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = track.name,
                                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                        color = if (isSel) Color.White else SleekTextPrimary
                                    )
                                    Text(
                                        text = "Language: ${track.language}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = SleekTextSecondary
                                    )
                                }
                                RadioButton(
                                    selected = isSel,
                                    onClick = { onSelectTrack(track) },
                                    colors = RadioButtonDefaults.colors(
                                        selectedColor = SleekPurpleLight,
                                        unselectedColor = SleekTextSecondary
                                    )
                                )
                            }
                        }
                    }
                } else {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "No embedded subtitle streams detected.",
                            style = MaterialTheme.typography.bodySmall,
                            color = SleekTextSecondary
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun SleepTimerDialog(
    currentMinutes: Int,
    currentSecondsRemaining: Int,
    onSelectMinutes: (Int) -> Unit,
    onDismiss: () -> Unit
) {
    androidx.compose.material3.AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF1C1B20),
        shape = RoundedCornerShape(24.dp),
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .background(SleekPurpleDark, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Timer,
                        contentDescription = null,
                        tint = SleekPurpleLight,
                        modifier = Modifier.size(20.dp)
                    )
                }
                Column {
                    Text(
                        text = "Sleep Timer",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = Color.White
                    )
                    Text(
                        text = "Auto-stop with smooth volume fade-out",
                        style = MaterialTheme.typography.bodySmall,
                        color = SleekTextMuted
                    )
                }
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (currentSecondsRemaining > 0) {
                    val m = currentSecondsRemaining / 60
                    val s = currentSecondsRemaining % 60
                    val isFading = currentSecondsRemaining <= 30
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = if (isFading) CrimsonFailure.copy(alpha = 0.2f) else SleekPurpleDark.copy(alpha = 0.5f),
                        border = BorderStroke(1.dp, if (isFading) CrimsonFailure.copy(alpha = 0.6f) else SleekPurpleLight.copy(alpha = 0.4f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = if (isFading) "Fading Out Volume..." else "Active Countdown:",
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                                color = if (isFading) Color(0xFFFF8A80) else Color.White
                            )
                            Text(
                                text = String.format("%02d:%02d", m, s),
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = if (isFading) Color(0xFFFF8A80) else SleekPurpleLight
                            )
                        }
                    }
                }

                Text(
                    text = "Select duration:",
                    style = MaterialTheme.typography.labelMedium,
                    color = Color.White.copy(alpha = 0.8f),
                    modifier = Modifier.padding(top = 4.dp)
                )

                val options = listOf(
                    0 to "Turn Off Timer",
                    15 to "15 Minutes",
                    30 to "30 Minutes",
                    60 to "1 Hour (60m)",
                    120 to "2 Hours (120m)"
                )

                options.forEach { (mins, label) ->
                    val isSelected = currentMinutes == mins
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = if (isSelected) SleekPurpleDark else Color(0xFF282730),
                        border = BorderStroke(
                            1.dp,
                            if (isSelected) SleekPurpleLight else Color.Transparent
                        ),
                        onClick = {
                            onSelectMinutes(mins)
                            onDismiss()
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = label,
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                ),
                                color = if (isSelected) Color.White else SleekTextMuted
                            )
                            if (isSelected) {
                                Icon(
                                    imageVector = Icons.Default.Check,
                                    contentDescription = null,
                                    tint = SleekPurpleLight,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }
                }

                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = Color.White.copy(alpha = 0.05f),
                    modifier = Modifier.fillMaxWidth().padding(top = 4.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.VolumeUp,
                            contentDescription = null,
                            tint = SleekPurpleLight,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Playback volume smoothly attenuates over the final 30 seconds before auto-stop.",
                            style = MaterialTheme.typography.labelSmall,
                            color = SleekTextMuted
                        )
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Close", color = SleekPurpleLight, fontWeight = FontWeight.Bold)
            }
        }
    )
}

@Composable
fun ResumePromptCard(
    positionMs: Long,
    onResume: () -> Unit,
    onStartOver: () -> Unit,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    val formattedTime = remember(positionMs) { formatTimeMs(positionMs) }

    LaunchedEffect(positionMs) {
        delay(6000)
        onDismiss()
    }

    Surface(
        shape = RoundedCornerShape(20.dp),
        color = Color(0xEE1A1B26),
        border = BorderStroke(1.dp, SleekPurpleLight.copy(alpha = 0.5f)),
        shadowElevation = 16.dp,
        modifier = modifier
            .padding(16.dp)
            .testTag("resume_prompt_card")
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .background(SleekPurpleDark, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.PlayArrow,
                    contentDescription = null,
                    tint = SleekPurpleLight,
                    modifier = Modifier.size(20.dp)
                )
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "Resume from $formattedTime?",
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                    color = Color.White
                )
                Text(
                    text = "Pick up where you left off",
                    style = MaterialTheme.typography.labelSmall,
                    color = SleekTextMuted
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Button(
                    onClick = onStartOver,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color.White.copy(alpha = 0.1f),
                        contentColor = Color.White
                    ),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.height(34.dp)
                ) {
                    Text("Start Over", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                }
                Button(
                    onClick = onResume,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = SleekPurpleDark,
                        contentColor = Color.White
                    ),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.height(34.dp)
                ) {
                    Text("Resume", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun AddMarkerDialog(
    positionMs: Long,
    onSaveMarker: (String) -> Unit,
    onDismiss: () -> Unit
) {
    var noteText by remember { mutableStateOf("Marker at ${formatTimeMs(positionMs)}") }

    androidx.compose.material3.AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF1C1B20),
        shape = RoundedCornerShape(24.dp),
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .background(SleekPurpleDark, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.BookmarkAdd,
                        contentDescription = null,
                        tint = SleekPurpleLight,
                        modifier = Modifier.size(20.dp)
                    )
                }
                Column {
                    Text(
                        text = "Add Timestamp Marker",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = Color.White
                    )
                    Text(
                        text = "Timestamp: ${formatTimeMs(positionMs)}",
                        style = MaterialTheme.typography.bodySmall,
                        color = SleekPurpleLight
                    )
                }
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = noteText,
                    onValueChange = { noteText = it },
                    label = { Text("Note / Bookmark Title") },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = SleekPurpleLight,
                        unfocusedBorderColor = Color.White.copy(alpha = 0.2f),
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    ),
                    modifier = Modifier.fillMaxWidth().testTag("marker_note_input")
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onSaveMarker(noteText.trim())
                    onDismiss()
                },
                colors = ButtonDefaults.buttonColors(containerColor = SleekPurpleDark)
            ) {
                Text("Save Marker", color = Color.White, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = SleekTextMuted)
            }
        }
    )
}

@Composable
fun MarkerListDialog(
    markers: List<com.example.data.MediaMarkerEntity>,
    onSelectMarker: (Long) -> Unit,
    onEditMarker: (com.example.data.MediaMarkerEntity, String) -> Unit,
    onDeleteMarker: (Long) -> Unit,
    onDismiss: () -> Unit
) {
    var editingMarker by remember { mutableStateOf<com.example.data.MediaMarkerEntity?>(null) }
    var editNoteText by remember { mutableStateOf("") }

    androidx.compose.material3.AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF1C1B20),
        shape = RoundedCornerShape(24.dp),
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .background(SleekPurpleDark, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Bookmarks,
                        contentDescription = null,
                        tint = SleekPurpleLight,
                        modifier = Modifier.size(20.dp)
                    )
                }
                Column {
                    Text(
                        text = "Timestamp Markers (${markers.size})",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = Color.White
                    )
                    Text(
                        text = "Tap any marker to jump to timestamp",
                        style = MaterialTheme.typography.bodySmall,
                        color = SleekTextMuted
                    )
                }
            }
        },
        text = {
            if (markers.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxWidth().padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("No markers added yet", color = SleekTextMuted, style = MaterialTheme.typography.bodyMedium)
                }
            } else {
                Column(
                    modifier = Modifier.verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    markers.forEach { marker ->
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = Color(0xFF282730),
                            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.08f)),
                            onClick = {
                                onSelectMarker(marker.positionMs)
                                onDismiss()
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Surface(
                                            shape = RoundedCornerShape(6.dp),
                                            color = SleekPurpleDark
                                        ) {
                                            Text(
                                                text = formatTimeMs(marker.positionMs),
                                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                                color = SleekPurpleLight,
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                            )
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = marker.note,
                                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                                        color = Color.White
                                    )
                                }
                                Row {
                                    IconButton(
                                        onClick = {
                                            editingMarker = marker
                                            editNoteText = marker.note
                                        },
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Icon(Icons.Default.Edit, contentDescription = "Edit Marker", tint = SleekTextMuted, modifier = Modifier.size(16.dp))
                                    }
                                    IconButton(
                                        onClick = { onDeleteMarker(marker.id) },
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Icon(Icons.Default.Delete, contentDescription = "Delete Marker", tint = Color(0xFFFF5A5F), modifier = Modifier.size(16.dp))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Close", color = SleekPurpleLight, fontWeight = FontWeight.Bold)
            }
        }
    )

    if (editingMarker != null) {
        val m = editingMarker!!
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { editingMarker = null },
            containerColor = Color(0xFF1C1B20),
            title = { Text("Edit Marker Note", color = Color.White) },
            text = {
                OutlinedTextField(
                    value = editNoteText,
                    onValueChange = { editNoteText = it },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = SleekPurpleLight,
                        unfocusedBorderColor = Color.White.copy(alpha = 0.2f),
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        onEditMarker(m, editNoteText.trim())
                        editingMarker = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = SleekPurpleDark)
                ) {
                    Text("Save", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { editingMarker = null }) {
                    Text("Cancel", color = SleekTextMuted)
                }
            }
        )
    }
}

@Composable
fun ExoPlayerAudioFxEngine(
    exoPlayer: androidx.media3.exoplayer.ExoPlayer,
    viewModel: VideoDownloaderViewModel
) {
    val volumeBoost by viewModel.volumeBoost.collectAsStateWithLifecycle()
    val virtualizerStr by viewModel.eqVirtualizer.collectAsStateWithLifecycle()
    val bassBoostStr by viewModel.eqBassBoost.collectAsStateWithLifecycle()
    val b60 by viewModel.eqBand60Hz.collectAsStateWithLifecycle()
    val b230 by viewModel.eqBand230Hz.collectAsStateWithLifecycle()
    val b910 by viewModel.eqBand910Hz.collectAsStateWithLifecycle()
    val b3k by viewModel.eqBand3kHz.collectAsStateWithLifecycle()
    val b14k by viewModel.eqBand14kHz.collectAsStateWithLifecycle()
    val audioEffectConfig by viewModel.audioEffectConfig.collectAsStateWithLifecycle()

    var audioSessionId by remember { mutableStateOf(exoPlayer.audioSessionId) }

    DisposableEffect(exoPlayer) {
        val listener = object : androidx.media3.exoplayer.analytics.AnalyticsListener {
            override fun onAudioSessionIdChanged(
                eventTime: androidx.media3.exoplayer.analytics.AnalyticsListener.EventTime,
                audioSessionIdNew: Int
            ) {
                audioSessionId = audioSessionIdNew
            }
        }
        exoPlayer.addAnalyticsListener(listener)
        onDispose {
            exoPlayer.removeAnalyticsListener(listener)
        }
    }

    var loudnessEnhancer by remember { mutableStateOf<android.media.audiofx.LoudnessEnhancer?>(null) }
    var virtualizer by remember { mutableStateOf<android.media.audiofx.Virtualizer?>(null) }
    var bassBoost by remember { mutableStateOf<android.media.audiofx.BassBoost?>(null) }
    var equalizer by remember { mutableStateOf<android.media.audiofx.Equalizer?>(null) }
    var environmentalReverb by remember { mutableStateOf<android.media.audiofx.EnvironmentalReverb?>(null) }
    var presetReverb by remember { mutableStateOf<android.media.audiofx.PresetReverb?>(null) }

    LaunchedEffect(audioSessionId) {
        if (audioSessionId != 0) {
            val le = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                runCatching { android.media.audiofx.LoudnessEnhancer(audioSessionId).apply { enabled = true } }.getOrNull()
            }
            val virt = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                runCatching { android.media.audiofx.Virtualizer(0, audioSessionId).apply { enabled = true } }.getOrNull()
            }
            val bb = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                runCatching { android.media.audiofx.BassBoost(0, audioSessionId).apply { enabled = true } }.getOrNull()
            }
            val eq = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                runCatching { android.media.audiofx.Equalizer(0, audioSessionId).apply { enabled = true } }.getOrNull()
            }
            val envRev = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                runCatching { android.media.audiofx.EnvironmentalReverb(0, audioSessionId).apply { enabled = true } }.getOrNull()
            }
            val presRev = if (envRev == null) {
                kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                    runCatching { android.media.audiofx.PresetReverb(0, audioSessionId).apply { enabled = true } }.getOrNull()
                }
            } else null

            loudnessEnhancer = le
            virtualizer = virt
            bassBoost = bb
            equalizer = eq
            environmentalReverb = envRev
            presetReverb = presRev
        }
    }

    DisposableEffect(audioSessionId) {
        onDispose {
            loudnessEnhancer?.release()
            virtualizer?.release()
            bassBoost?.release()
            equalizer?.release()
            environmentalReverb?.release()
            presetReverb?.release()
            loudnessEnhancer = null
            virtualizer = null
            bassBoost = null
            equalizer = null
            environmentalReverb = null
            presetReverb = null
        }
    }

    LaunchedEffect(environmentalReverb, presetReverb, audioEffectConfig) {
        kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            try {
                if (environmentalReverb != null) {
                    val rev = environmentalReverb ?: return@withContext
                    if (!audioEffectConfig.isEnabled) {
                        rev.enabled = false
                    } else {
                        rev.enabled = true
                        val intensity = audioEffectConfig.intensity.coerceIn(0.0f, 1.0f)
                        
                        when (audioEffectConfig.preset) {
                            AudioEffectPreset.OFF -> {
                                rev.enabled = false
                            }
                            AudioEffectPreset.SMALL_ROOM -> {
                                // Short decay, subtle early reflections, intimate sound
                                val decayMs = (350 + (300 * intensity)).toInt() // 350ms to 650ms
                                val roomLvl = (-1800 + (1200 * intensity)).toInt().toShort() // -1800 to -600 mB
                                val reflectionsLvl = (-2000 + (1000 * intensity)).toInt().toShort() // -2000 to -1000 mB
                                val reverbLvl = (-1500 + (1200 * intensity)).toInt().toShort()
                                rev.decayTime = decayMs
                                rev.decayHFRatio = 830.toShort()
                                rev.roomLevel = roomLvl
                                rev.roomHFLevel = (-600).toShort()
                                rev.reflectionsLevel = reflectionsLvl
                                rev.reflectionsDelay = 12
                                rev.reverbLevel = reverbLvl
                                rev.reverbDelay = 10
                                rev.diffusion = (600 + (300 * intensity)).toInt().toShort()
                                rev.density = (600 + (300 * intensity)).toInt().toShort()
                            }
                            AudioEffectPreset.STUDIO -> {
                                // Very subtle reflections, clean and controlled, minimal coloration
                                val decayMs = (200 + (250 * intensity)).toInt() // 200ms to 450ms
                                val roomLvl = (-2400 + (1400 * intensity)).toInt().toShort() // -2400 to -1000 mB
                                val reflectionsLvl = (-2800 + (1200 * intensity)).toInt().toShort()
                                val reverbLvl = (-2200 + (1200 * intensity)).toInt().toShort()
                                rev.decayTime = decayMs
                                rev.decayHFRatio = 900.toShort()
                                rev.roomLevel = roomLvl
                                rev.roomHFLevel = (-400).toShort()
                                rev.reflectionsLevel = reflectionsLvl
                                rev.reflectionsDelay = 8
                                rev.reverbLevel = reverbLvl
                                rev.reverbDelay = 6
                                rev.diffusion = 500.toShort()
                                rev.density = 500.toShort()
                            }
                            AudioEffectPreset.CONCERT_HALL -> {
                                // Longer decay, wider stereo impression, stronger reflections
                                val decayMs = (1500 + (1800 * intensity)).toInt() // 1500ms to 3300ms
                                val roomLvl = (-1200 + (1000 * intensity)).toInt().toShort() // -1200 to -200 mB
                                val reflectionsLvl = (-1400 + (900 * intensity)).toInt().toShort()
                                val reverbLvl = (-800 + (800 * intensity)).toInt().toShort()
                                rev.decayTime = decayMs
                                rev.decayHFRatio = 700.toShort()
                                rev.roomLevel = roomLvl
                                rev.roomHFLevel = (-500).toShort()
                                rev.reflectionsLevel = reflectionsLvl
                                rev.reflectionsDelay = 30
                                rev.reverbLevel = reverbLvl
                                rev.reverbDelay = 25
                                rev.diffusion = (800 + (200 * intensity)).toInt().toShort()
                                rev.density = (800 + (200 * intensity)).toInt().toShort()
                            }
                            AudioEffectPreset.CATHEDRAL -> {
                                // Very long decay, spacious ambience, strongest reverberation
                                val decayMs = (3500 + (4500 * intensity)).toInt() // 3500ms to 8000ms
                                val roomLvl = (-800 + (800 * intensity)).toInt().toShort() // -800 to 0 mB
                                val reflectionsLvl = (-900 + (800 * intensity)).toInt().toShort()
                                val reverbLvl = (-400 + (600 * intensity)).toInt().toShort()
                                rev.decayTime = decayMs
                                rev.decayHFRatio = 600.toShort()
                                rev.roomLevel = roomLvl
                                rev.roomHFLevel = (-200).toShort()
                                rev.reflectionsLevel = reflectionsLvl
                                rev.reflectionsDelay = 60
                                rev.reverbLevel = reverbLvl
                                rev.reverbDelay = 40
                                rev.diffusion = 1000.toShort()
                                rev.density = 1000.toShort()
                            }
                        }
                    }
                } else if (presetReverb != null) {
                    val pRev = presetReverb ?: return@withContext
                    if (!audioEffectConfig.isEnabled || audioEffectConfig.preset == AudioEffectPreset.OFF) {
                        pRev.enabled = false
                        pRev.preset = android.media.audiofx.PresetReverb.PRESET_NONE
                    } else {
                        pRev.enabled = true
                        when (audioEffectConfig.preset) {
                            AudioEffectPreset.OFF -> {
                                pRev.enabled = false
                                pRev.preset = android.media.audiofx.PresetReverb.PRESET_NONE
                            }
                            AudioEffectPreset.SMALL_ROOM -> {
                                pRev.preset = android.media.audiofx.PresetReverb.PRESET_SMALLROOM
                            }
                            AudioEffectPreset.STUDIO -> {
                                pRev.preset = android.media.audiofx.PresetReverb.PRESET_MEDIUMROOM
                            }
                            AudioEffectPreset.CONCERT_HALL -> {
                                pRev.preset = android.media.audiofx.PresetReverb.PRESET_LARGEHALL
                            }
                            AudioEffectPreset.CATHEDRAL -> {
                                pRev.preset = android.media.audiofx.PresetReverb.PRESET_LARGEROOM
                            }
                        }
                    }
                }
            } catch (_: Exception) {
                // Safeguard: gracefully bypass effect without interrupting playback
            }
        }
    }

    LaunchedEffect(loudnessEnhancer, volumeBoost) {
        try {
            loudnessEnhancer?.setTargetGain((volumeBoost * 40).toInt())
        } catch (e: Exception) {}
    }

    LaunchedEffect(virtualizer, virtualizerStr) {
        try {
            if (virtualizer?.properties != null) {
                virtualizer?.setStrength((virtualizerStr * 10).toInt().toShort())
            }
        } catch (e: Exception) {}
    }

    LaunchedEffect(bassBoost, bassBoostStr) {
        try {
            if (bassBoost?.properties != null) {
                bassBoost?.setStrength((bassBoostStr * 10).toInt().toShort())
            }
        } catch (e: Exception) {}
    }

    LaunchedEffect(equalizer, b60, b230, b910, b3k, b14k) {
        try {
            equalizer?.let { eq ->
                val bands = eq.numberOfBands
                if (bands > 0) eq.setBandLevel(0, (b60 * 100).toInt().toShort())
                if (bands > 1) eq.setBandLevel(1, (b230 * 100).toInt().toShort())
                if (bands > 2) eq.setBandLevel(2, (b910 * 100).toInt().toShort())
                if (bands > 3) eq.setBandLevel(3, (b3k * 100).toInt().toShort())
                if (bands > 4) eq.setBandLevel(4, (b14k * 100).toInt().toShort())
            }
        } catch (e: Exception) {}
    }
}


@Composable
fun LiquidGlassGestureIndicator(
    type: Int,
    isActive: Boolean,
    currentValue: Float,
    displayValue: String,
    modifier: Modifier = Modifier
) {
    var showIndicator by remember { mutableStateOf(false) }
    
    LaunchedEffect(isActive) {
        if (isActive) {
            showIndicator = true
        } else {
            delay(1500)
            showIndicator = false
        }
    }
    
    val alpha by animateFloatAsState(
        targetValue = if (showIndicator) 1f else 0f,
        animationSpec = if (showIndicator) spring(dampingRatio = Spring.DampingRatioNoBouncy, stiffness = Spring.StiffnessMedium) 
                        else tween(220, easing = FastOutSlowInEasing),
        label = "indicatorAlpha"
    )
    val scale by animateFloatAsState(
        targetValue = if (showIndicator) 1f else 0.96f,
        animationSpec = if (showIndicator) spring(dampingRatio = Spring.DampingRatioNoBouncy, stiffness = Spring.StiffnessMedium)
                        else tween(220, easing = FastOutSlowInEasing),
        label = "indicatorScale"
    )
    
    val visualTarget = if (type == 1) {
        val clamped = currentValue.coerceIn(0f, 1f)
        if (clamped <= 0.5f) {
            clamped * (4f / 3f)
        } else {
            (2f / 3f) + (clamped - 0.5f) * (2f / 3f)
        }
    } else {
        currentValue.coerceIn(0f, 1f)
    }
    
    val animatedFill by animateFloatAsState(
        targetValue = visualTarget,
        animationSpec = spring(dampingRatio = Spring.DampingRatioNoBouncy, stiffness = Spring.StiffnessLow),
        label = "indicatorFill"
    )

    if (alpha > 0f) {
        Column(
            modifier = modifier
                .graphicsLayer {
                    this.alpha = alpha
                    this.scaleX = scale
                    this.scaleY = scale
                },
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = displayValue,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                modifier = Modifier.padding(bottom = 12.dp)
            )
            
            val fillColors = if (type == 0) {
                // Brightness gradient: Dark night to bright sun
                listOf(Color.White, Color(0xFFFFCC00), Color(0xFFFF4500), Color(0xFF1A1A24))
            } else {
                // Volume: 0-100% Green->Yellow->Red, 100-200% -> Color(255, 50, 200) Pink/Magenta or Color(25, 50, 200) Blue
                // We'll use Color(255, 50, 200) for the over-boosted segment (often typo'd as 25,50,200)
                listOf(Color(255, 50, 200), Color(0xFFFF3B30), Color(0xFFFFCC00), Color(0xFF34C759))
            }

            Box(
                modifier = Modifier
                    .width(28.dp)
                    .height(200.dp)
                    .graphicsLayer {
                        shadowElevation = 24.dp.toPx()
                        ambientShadowColor = Color.Black
                        spotShadowColor = Color.Black
                        shape = CircleShape
                        clip = true
                    }
                    .background(Color(12, 13, 18, (255 * 0.45f).toInt()))
                    .border(
                        width = 1.dp,
                        color = Color.White.copy(alpha = 0.12f),
                        shape = CircleShape
                    ),
                contentAlignment = Alignment.BottomCenter
            ) {
                // Filled Track with animated height and safe color mapping
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .clip(object : androidx.compose.ui.graphics.Shape {
                            override fun createOutline(size: androidx.compose.ui.geometry.Size, layoutDirection: androidx.compose.ui.unit.LayoutDirection, density: androidx.compose.ui.unit.Density): androidx.compose.ui.graphics.Outline {
                                val fillHeight = size.height * animatedFill
                                return androidx.compose.ui.graphics.Outline.Rectangle(
                                    androidx.compose.ui.geometry.Rect(0f, size.height - fillHeight, size.width, size.height)
                                )
                            }
                        })
                        .background(Brush.verticalGradient(fillColors))
                )
                
                // Icon (static at bottom)
                Icon(
                    imageVector = if (type == 0) Icons.Default.WbSunny else Icons.Default.VolumeUp,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier
                        .padding(bottom = 12.dp)
                        .size(16.dp)
                )
            }
        }
    }
}

@Composable
fun TermsAndConditionsDialog(
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        shape = RoundedCornerShape(24.dp),
        containerColor = SleekCard,
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .background(SleekPurpleContainer.copy(alpha = 0.4f), CircleShape)
                        .border(1.dp, SleekPurpleLight.copy(alpha = 0.2f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Security,
                        contentDescription = null,
                        tint = SleekPurpleLight,
                        modifier = Modifier.size(22.dp)
                    )
                }
                Column {
                    Text(
                        text = "Terms & Conditions",
                        color = SleekTextPrimary,
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    Text(
                        text = "Last Updated: August 2026",
                        color = SleekTextMuted,
                        style = MaterialTheme.typography.labelSmall
                    )
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text(
                    text = "Please read these Terms & Conditions carefully prior to utilizing Downly. By downloading, installing, or using this application, you agree to be bound by the terms outlined below.",
                    color = SleekTextSecondary,
                    style = MaterialTheme.typography.bodyMedium,
                    lineHeight = 20.sp
                )

                HorizontalDivider(color = SleekBorderColor.copy(alpha = 0.4f))

                // Section 1
                LegalSectionItem(
                    number = "1",
                    title = "Personal & Fair Use Only",
                    body = "Downly is provided solely as a personal offline media cache and playback manager. You agree to use Downly exclusively for personal, non-commercial media storage and playback in compliance with relevant local intellectual property statutes."
                )

                // Section 2
                LegalSectionItem(
                    number = "2",
                    title = "Intellectual Property & Copyright",
                    body = "Downly does not host, upload, scrape, store on cloud infrastructure, or distribute any copyrighted streams or media files. All media parsing and extraction are executed on-device using open-source yt-dlp binary wrappers. You are solely responsible for ensuring you have the legal right or copyright holder's authorization to save content for personal offline viewing."
                )

                // Section 3
                LegalSectionItem(
                    number = "3",
                    title = "Third-Party Platform Compliance",
                    body = "You acknowledge that accessing external services is subject to the respective terms and policies of those service providers. Downly is an independent client tool and is not affiliated, endorsed, or partnered with any video streaming platform or social media network."
                )

                // Section 4
                LegalSectionItem(
                    number = "4",
                    title = "Prohibited Actions",
                    body = "You shall not use Downly to circumvent digital rights management (DRM) protections, engage in automated mass scraping for commercial exploitation, or redistribute downloaded copyrighted media without appropriate licenses."
                )

                // Section 5
                LegalSectionItem(
                    number = "5",
                    title = "Disclaimer of Warranties",
                    body = "Downly is provided on an \"AS IS\" and \"AS AVAILABLE\" basis without warranties of any kind, whether express or implied. Extraction availability is dependent on upstream web endpoints and may change without notice."
                )

                // Section 6
                LegalSectionItem(
                    number = "6",
                    title = "Limitation of Liability",
                    body = "To the maximum extent permissible by law, the authors and contributors of Downly shall not be liable for any direct, indirect, incidental, or consequential damages resulting from the use or misuse of the software."
                )

                Text(
                    text = "Questions regarding these terms? Contact officialmp4go@gmail.com",
                    color = SleekTextMuted,
                    style = MaterialTheme.typography.labelSmall,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth().padding(top = 4.dp)
                )
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color.White,
                    contentColor = Color.Black
                ),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Default.Check, contentDescription = "Accept", modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("I Understand & Accept", fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }
        }
    )
}

@Composable
fun PrivacyPolicyDialog(
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        shape = RoundedCornerShape(24.dp),
        containerColor = SleekCard,
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .background(SleekPurpleContainer.copy(alpha = 0.4f), CircleShape)
                        .border(1.dp, SleekPurpleLight.copy(alpha = 0.2f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = null,
                        tint = SleekPurpleLight,
                        modifier = Modifier.size(22.dp)
                    )
                }
                Column {
                    Text(
                        text = "Privacy Policy",
                        color = SleekTextPrimary,
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    Text(
                        text = "Zero Telemetry • 100% On-Device",
                        color = EmeraldSuccess,
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold)
                    )
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text(
                    text = "Your privacy is our utmost priority. Downly is built strictly as an offline-first client application. We believe your media consumption and downloads should remain strictly confidential to you.",
                    color = SleekTextSecondary,
                    style = MaterialTheme.typography.bodyMedium,
                    lineHeight = 20.sp
                )

                HorizontalDivider(color = SleekBorderColor.copy(alpha = 0.4f))

                // Policy 1
                LegalSectionItem(
                    number = "1",
                    title = "Zero Personal Data Collection",
                    body = "We do NOT collect, transmit, store, sell, or analyze any personal data, device identifiers (IMEI/MAC), IP logs, search queries, or media consumption patterns. There are no tracking SDKs or ad analytics embedded in this application."
                )

                // Policy 2
                LegalSectionItem(
                    number = "2",
                    title = "100% Local On-Device Storage",
                    body = "All download records, audio wave caches, custom playlists, tags, bookmarks, and app preferences are stored exclusively on your device's private local SQLite database (Android Room) or your chosen public directory. Nothing is synchronized to remote databases."
                )

                // Policy 3
                LegalSectionItem(
                    number = "3",
                    title = "Direct Content Network Requests",
                    body = "When analyzing a video or downloading chunks, network communication occurs strictly between your Android device and the target media host. Downly operates with no intermediary telemetry server, middleman proxy, or link capture server."
                )

                // Policy 4
                LegalSectionItem(
                    number = "4",
                    title = "Android Permissions Transparency",
                    body = "• Storage / Media: Used exclusively to write downloaded video and audio files to your device storage.\n• Internet Access: Used exclusively to retrieve video stream metadata and download user-requested media chunks.\n• Foreground Service & Notifications: Used to maintain persistent progress indicators and prevent OS task termination during active downloads.\n• Wake Lock: Used optionally while downloading to prevent premature sleep."
                )

                // Policy 5
                LegalSectionItem(
                    number = "5",
                    title = "User Data Control & Permanent Deletion",
                    body = "You retain absolute ownership of all stored items. You may wipe individual media files, clear download logs, or reset all database records at any time with a single tap in the Library and Settings tabs."
                )

                // Policy 6
                LegalSectionItem(
                    number = "6",
                    title = "Contact & Privacy Inquiries",
                    body = "If you have any questions or security concerns regarding this Privacy Policy, you may contact the development team at officialmp4go@gmail.com."
                )

                Text(
                    text = "© 2026 Downly Media Tech. Offline-first privacy verified.",
                    color = SleekTextMuted,
                    style = MaterialTheme.typography.labelSmall,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth().padding(top = 4.dp)
                )
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color.White,
                    contentColor = Color.Black
                ),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Default.Check, contentDescription = "Got it", modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Got It", fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }
        }
    )
}

@Composable
fun LegalSectionItem(
    number: String,
    title: String,
    body: String
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color.Black.copy(alpha = 0.25f), RoundedCornerShape(12.dp))
            .border(1.dp, SleekBorderColor.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Surface(
                shape = CircleShape,
                color = SleekPurpleContainer.copy(alpha = 0.6f),
                border = BorderStroke(0.5.dp, SleekPurpleLight.copy(alpha = 0.4f)),
                modifier = Modifier.size(20.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Text(
                        text = number,
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.ExtraBold),
                        color = SleekPurpleLight,
                        fontSize = 11.sp
                    )
                }
            }
            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                color = SleekTextPrimary
            )
        }
        Text(
            text = body,
            style = MaterialTheme.typography.bodySmall,
            color = SleekTextSecondary,
            lineHeight = 18.sp
        )
    }
}

/**
 * Custom vector Instagram camera glyph.
 */
@Composable
fun InstagramIcon(
    modifier: Modifier = Modifier,
    useGradient: Boolean = true,
    tint: Color = Color.White
) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        val strokeWidth = w * 0.10f
        val cornerRadius = CornerRadius(w * 0.28f, h * 0.28f)

        val brush = if (useGradient) {
            Brush.linearGradient(
                colors = listOf(
                    Color(0xFF833AB4), // Purple
                    Color(0xFFFD1D1D), // Crimson/Red
                    Color(0xFFFCB045)  // Orange/Yellow
                ),
                start = Offset(0f, h),
                end = Offset(w, 0f)
            )
        } else {
            androidx.compose.ui.graphics.SolidColor(tint)
        }

        // Outer rounded rect
        val inset = strokeWidth / 2f
        drawRoundRect(
            brush = brush,
            topLeft = Offset(inset, inset),
            size = Size(w - strokeWidth, h - strokeWidth),
            cornerRadius = cornerRadius,
            style = Stroke(width = strokeWidth)
        )

        // Center lens circle
        drawCircle(
            brush = brush,
            radius = w * 0.24f,
            center = center,
            style = Stroke(width = strokeWidth)
        )

        // Flash dot
        drawCircle(
            brush = brush,
            radius = w * 0.055f,
            center = Offset(w * 0.74f, h * 0.26f),
            style = Fill
        )
    }
}

/**
 * Directly opens the developer's Instagram profile via native app or browser fallback.
 */
fun openInstagramProfile(context: Context, username: String) {
    val cleanUsername = username.removePrefix("@")
    val appUri = Uri.parse("http://instagram.com/_u/$cleanUsername")
    val appIntent = android.content.Intent(android.content.Intent.ACTION_VIEW, appUri).apply {
        setPackage("com.instagram.android")
        addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
    }
    try {
        context.startActivity(appIntent)
    } catch (e: Exception) {
        val webUri = Uri.parse("https://instagram.com/$cleanUsername")
        val webIntent = android.content.Intent(android.content.Intent.ACTION_VIEW, webUri).apply {
            addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            context.startActivity(webIntent)
        } catch (e2: Exception) {
            android.widget.Toast.makeText(context, "Cannot open Instagram profile", android.widget.Toast.LENGTH_SHORT).show()
        }
    }
}

// --- PHASE 2C: REAL-TIME VIDEO COLOR CONTROLS UTILITIES & PANEL ---

fun calculateVideoColorMatrix(
    brightness: Float, // -1.0 to +1.0 (neutral: 0.0)
    contrast: Float,   // 0.5 to 2.0 (neutral: 1.0)
    saturation: Float, // 0.0 to 2.0 (neutral: 1.0)
    gamma: Float,      // 0.5 to 2.0 (neutral: 1.0)
    sharpness: Float = 0.0f,   // 0.0 to 2.0 (neutral: 0.0)
    temperature: Float = 0.0f, // -1.0 (Cool) to +1.0 (Warm)
    highlights: Float = 0.0f,  // -1.0 to +1.0 (neutral: 0.0)
    shadows: Float = 0.0f,     // -1.0 to +1.0 (neutral: 0.0)
    vibrance: Float = 1.0f,    // 0.0 to 2.0 (neutral: 1.0)
    tint: Float = 0.0f         // -1.0 (Magenta) to +1.0 (Green)
): android.graphics.ColorMatrix {
    val gInv = if (gamma > 0.05f) 1.0f / gamma else 1.0f
    val effectiveContrast = contrast * (1f + sharpness * 0.25f)
    val cScale = effectiveContrast * gInv
    
    val highlightOffset = highlights * 20f
    val shadowOffset = shadows * 25f
    val bcOffset = (255f * brightness * effectiveContrast + 128f * (1f - effectiveContrast)) * gInv + 128f * (1f - gInv) + highlightOffset + shadowOffset

    // Temperature (Red/Blue warmth balance) & Tint (Green/Magenta balance)
    val tempRed = if (temperature > 0) 1.0f + temperature * 0.25f else 1.0f + temperature * 0.10f
    val tempBlue = if (temperature < 0) 1.0f - temperature * 0.25f else 1.0f - temperature * 0.12f
    val tintGreen = if (tint > 0) 1.0f + tint * 0.20f else 1.0f + tint * 0.10f
    val tintRedGreen = if (tint < 0) 1.0f - tint * 0.15f else 1.0f

    val bcArray = floatArrayOf(
        (cScale + sharpness * 0.15f) * tempRed * tintRedGreen, -sharpness * 0.075f, -sharpness * 0.075f, 0f, bcOffset,
        -sharpness * 0.075f, (cScale + sharpness * 0.15f) * tintGreen, -sharpness * 0.075f, 0f, bcOffset,
        -sharpness * 0.075f, -sharpness * 0.075f, (cScale + sharpness * 0.15f) * tempBlue, 0f, bcOffset,
        0f, 0f, 0f, 1f, 0f
    )
    val bcMatrix = android.graphics.ColorMatrix(bcArray)

    val effectiveSat = saturation * vibrance
    val satMatrix = android.graphics.ColorMatrix()
    satMatrix.setSaturation(effectiveSat)

    val finalMatrix = android.graphics.ColorMatrix()
    finalMatrix.setConcat(satMatrix, bcMatrix)

    return finalMatrix
}

@Composable
fun VideoAdjustmentsPanel(
    adjustments: VideoColorAdjustments,
    compareRatio: Float = 1.0f,
    onUpdateBrightness: (Float) -> Unit,
    onUpdateContrast: (Float) -> Unit,
    onUpdateSaturation: (Float) -> Unit,
    onUpdateGamma: (Float) -> Unit,
    onUpdateSharpness: (Float) -> Unit,
    onUpdateTemperature: (Float) -> Unit = {},
    onUpdateHighlights: (Float) -> Unit = {},
    onUpdateShadows: (Float) -> Unit = {},
    onUpdateVibrance: (Float) -> Unit = {},
    onUpdateTint: (Float) -> Unit = {},
    onSelectPreset: (String) -> Unit = {},
    onUpdateCompareRatio: (Float) -> Unit = {},
    isHoldOriginalActive: Boolean = false,
    onHoldOriginalChange: (Boolean) -> Unit = {},
    onReset: () -> Unit,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(20.dp),
        color = Color(0xEC14151F),
        border = BorderStroke(1.dp, SleekPurpleDark.copy(alpha = 0.8f)),
        shadowElevation = 16.dp,
        modifier = modifier
            .widthIn(max = 380.dp)
            .fillMaxWidth(0.92f)
            .padding(12.dp)
            .testTag("video_adjustments_panel")
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Tune,
                        contentDescription = null,
                        tint = SleekPurpleLight,
                        modifier = Modifier.size(20.dp)
                    )
                    Text(
                        text = "Video Adjustments",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = Color.White
                    )
                }

                Row(
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(
                        onClick = onReset,
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                        enabled = !adjustments.isDefault,
                        modifier = Modifier.testTag("video_adjustments_reset_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Reset",
                            tint = if (!adjustments.isDefault) SleekPurpleLight else SleekTextMuted,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Reset",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (!adjustments.isDefault) SleekPurpleLight else SleekTextMuted
                        )
                    }

                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .size(28.dp)
                            .testTag("video_adjustments_close_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = SleekTextSecondary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }

            // Quick Color Grading Presets Scroll Row
            val presets = listOf("DEFAULT", "CINEMATIC", "VIVID", "HDR BOOST", "WARM FILM", "COOL TEAL", "NOIR")
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                presets.forEach { preset ->
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = Color.White.copy(alpha = 0.08f),
                        border = BorderStroke(1.dp, SleekPurpleLight.copy(alpha = 0.3f)),
                        modifier = Modifier.clickable { onSelectPreset(preset) }
                    ) {
                        Text(
                            text = preset,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                        )
                    }
                }
            }

            HorizontalDivider(color = Color.White.copy(alpha = 0.12f))

            val scrollState = rememberScrollState()
            val coroutineScope = rememberCoroutineScope()

            // Scrollable Controls Body with Visual Scroll Indicator & Gradient Fade
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 300.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(scrollState)
                        .padding(bottom = if (scrollState.canScrollForward) 28.dp else 4.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Section 1: Tone & Contrast Controls
                    Text(
                        text = "TONE & CONTRAST",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = SleekPurpleLight,
                        letterSpacing = 1.sp
                    )

                    // 1. Brightness (-1.0 to +1.0, neutral 0.0)
                    val brightnessVal = adjustments.brightness
                    val brightnessStr = if (brightnessVal > 0f) String.format(java.util.Locale.US, "+%.2f", brightnessVal) else String.format(java.util.Locale.US, "%.2f", brightnessVal)
                    ColorAdjustSliderRow(
                        label = "Brightness",
                        valueStr = brightnessStr,
                        value = brightnessVal,
                        valueRange = -1.0f..1.0f,
                        onValueChange = onUpdateBrightness,
                        testTag = "slider_brightness"
                    )

                    // 2. Contrast (0.5 to 2.0, neutral 1.0)
                    val contrastVal = adjustments.contrast
                    val contrastStr = String.format(java.util.Locale.US, "%.2f", contrastVal)
                    ColorAdjustSliderRow(
                        label = "Contrast",
                        valueStr = contrastStr,
                        value = contrastVal,
                        valueRange = 0.5f..2.0f,
                        onValueChange = onUpdateContrast,
                        testTag = "slider_contrast"
                    )

                    // 3. Saturation (0.0 to 2.0, neutral 1.0)
                    val saturationVal = adjustments.saturation
                    val saturationStr = String.format(java.util.Locale.US, "%.2f", saturationVal)
                    ColorAdjustSliderRow(
                        label = "Saturation",
                        valueStr = saturationStr,
                        value = saturationVal,
                        valueRange = 0.0f..2.0f,
                        onValueChange = onUpdateSaturation,
                        testTag = "slider_saturation"
                    )

                    // 4. Gamma (0.5 to 2.0, neutral 1.0)
                    val gammaVal = adjustments.gamma
                    val gammaStr = String.format(java.util.Locale.US, "%.2f", gammaVal)
                    ColorAdjustSliderRow(
                        label = "Gamma",
                        valueStr = gammaStr,
                        value = gammaVal,
                        valueRange = 0.5f..2.0f,
                        onValueChange = onUpdateGamma,
                        testTag = "slider_gamma"
                    )

                    // 5. Sharpness (0.0 to 2.0, neutral 0.0)
                    val sharpnessVal = adjustments.sharpness
                    val sharpnessStr = String.format(java.util.Locale.US, "%.2f", sharpnessVal)
                    ColorAdjustSliderRow(
                        label = "Sharpness",
                        valueStr = sharpnessStr,
                        value = sharpnessVal,
                        valueRange = 0.0f..2.0f,
                        onValueChange = onUpdateSharpness,
                        testTag = "slider_sharpness"
                    )

                    HorizontalDivider(color = Color.White.copy(alpha = 0.08f), modifier = Modifier.padding(vertical = 2.dp))

                    // Section 2: Pro Color & Light Balance
                    Text(
                        text = "COLOR BALANCE & LIGHTING",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color(0xFFFFAB40),
                        letterSpacing = 1.sp
                    )

                    // 6. Temperature (-1.0 Cool to +1.0 Warm)
                    val tempVal = adjustments.temperature
                    val tempStr = if (tempVal > 0f) String.format(java.util.Locale.US, "+%.2f Warm", tempVal) else if (tempVal < 0f) String.format(java.util.Locale.US, "%.2f Cool", tempVal) else "0.00 Neutral"
                    ColorAdjustSliderRow(
                        label = "Temperature",
                        valueStr = tempStr,
                        value = tempVal,
                        valueRange = -1.0f..1.0f,
                        onValueChange = onUpdateTemperature,
                        testTag = "slider_temperature"
                    )

                    // 7. Highlights (-1.0 to +1.0)
                    val hlVal = adjustments.highlights
                    val hlStr = if (hlVal > 0f) String.format(java.util.Locale.US, "+%.2f", hlVal) else String.format(java.util.Locale.US, "%.2f", hlVal)
                    ColorAdjustSliderRow(
                        label = "Highlights",
                        valueStr = hlStr,
                        value = hlVal,
                        valueRange = -1.0f..1.0f,
                        onValueChange = onUpdateHighlights,
                        testTag = "slider_highlights"
                    )

                    // 8. Shadows (-1.0 to +1.0)
                    val shVal = adjustments.shadows
                    val shStr = if (shVal > 0f) String.format(java.util.Locale.US, "+%.2f", shVal) else String.format(java.util.Locale.US, "%.2f", shVal)
                    ColorAdjustSliderRow(
                        label = "Shadows",
                        valueStr = shStr,
                        value = shVal,
                        valueRange = -1.0f..1.0f,
                        onValueChange = onUpdateShadows,
                        testTag = "slider_shadows"
                    )

                    // 9. Vibrance (0.0 to 2.0)
                    val vibVal = adjustments.vibrance
                    val vibStr = String.format(java.util.Locale.US, "%.2f", vibVal)
                    ColorAdjustSliderRow(
                        label = "Vibrance",
                        valueStr = vibStr,
                        value = vibVal,
                        valueRange = 0.0f..2.0f,
                        onValueChange = onUpdateVibrance,
                        testTag = "slider_vibrance"
                    )

                    // 10. Tint (-1.0 Magenta to +1.0 Green)
                    val tintVal = adjustments.tint
                    val tintStr = if (tintVal > 0f) String.format(java.util.Locale.US, "+%.2f Green", tintVal) else if (tintVal < 0f) String.format(java.util.Locale.US, "%.2f Magenta", tintVal) else "0.00 Neutral"
                    ColorAdjustSliderRow(
                        label = "Tint",
                        valueStr = tintStr,
                        value = tintVal,
                        valueRange = -1.0f..1.0f,
                        onValueChange = onUpdateTint,
                        testTag = "slider_tint"
                    )

                    HorizontalDivider(color = Color.White.copy(alpha = 0.12f), modifier = Modifier.padding(vertical = 2.dp))

                    // 11. Before / After Comparison Wipe Slider
                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Compare,
                                    contentDescription = null,
                                    tint = Color(0xFFFFAB40),
                                    modifier = Modifier.size(15.dp)
                                )
                                Text(
                                    text = "Before / After Split",
                                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                    color = Color.White
                                )
                            }
                            Text(
                                text = if (compareRatio == 0.0f) "Before (Original)" else if (compareRatio == 1.0f) "After (100%)" else "${(compareRatio * 100).toInt()}% Wipe",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFFFAB40)
                            )
                        }

                        Slider(
                            value = compareRatio,
                            onValueChange = onUpdateCompareRatio,
                            valueRange = 0.0f..1.0f,
                            colors = SliderDefaults.colors(
                                thumbColor = Color(0xFFFFAB40),
                                activeTrackColor = Color(0xFFFFAB40),
                                inactiveTrackColor = Color.White.copy(alpha = 0.2f)
                            ),
                            modifier = Modifier.height(28.dp)
                        )

                        Spacer(modifier = Modifier.height(4.dp))

                        // Hold to view original video
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (isHoldOriginalActive) Color(0xFFFF5A5F).copy(alpha = 0.25f) else Color.White.copy(alpha = 0.08f),
                            border = BorderStroke(1.dp, if (isHoldOriginalActive) Color(0xFFFF5A5F) else Color.White.copy(alpha = 0.15f)),
                            modifier = Modifier
                                .fillMaxWidth()
                                .pointerInput(Unit) {
                                    detectTapGestures(
                                        onPress = {
                                            onHoldOriginalChange(true)
                                            tryAwaitRelease()
                                            onHoldOriginalChange(false)
                                        }
                                    )
                                }
                        ) {
                            Row(
                                modifier = Modifier.padding(vertical = 6.dp, horizontal = 10.dp),
                                horizontalArrangement = Arrangement.Center,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Visibility,
                                    contentDescription = null,
                                    tint = if (isHoldOriginalActive) Color(0xFFFF5A5F) else SleekTextSecondary,
                                    modifier = Modifier.size(15.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = if (isHoldOriginalActive) "Showing Original Video" else "Press & Hold for Original Video",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isHoldOriginalActive) Color(0xFFFF5A5F) else Color.White
                                )
                            }
                        }
                    }
                }

                // Subtle Bottom Gradient Fade & Scroll Indicator Badge Overlay
                androidx.compose.animation.AnimatedVisibility(
                    visible = scrollState.canScrollForward,
                    enter = androidx.compose.animation.fadeIn(),
                    exit = androidx.compose.animation.fadeOut(),
                    modifier = Modifier.align(Alignment.BottomCenter)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(44.dp)
                            .background(
                                androidx.compose.ui.graphics.Brush.verticalGradient(
                                    colors = listOf(
                                        Color.Transparent,
                                        Color(0xF014151F)
                                    )
                                )
                            ),
                        contentAlignment = Alignment.BottomCenter
                    ) {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = Color(0xF21C1D2A),
                            border = BorderStroke(1.dp, Color(0xFFFFAB40).copy(alpha = 0.7f)),
                            shadowElevation = 6.dp,
                            modifier = Modifier
                                .padding(bottom = 3.dp)
                                .clickable {
                                    coroutineScope.launch {
                                        scrollState.animateScrollTo(scrollState.value + 300)
                                    }
                                }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                horizontalArrangement = Arrangement.spacedBy(4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Scroll for more options",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFFFFAB40)
                                )
                                Icon(
                                    imageVector = Icons.Default.KeyboardArrowDown,
                                    contentDescription = "Scroll down",
                                    tint = Color(0xFFFFAB40),
                                    modifier = Modifier.size(14.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ColorAdjustSliderRow(
    label: String,
    valueStr: String,
    value: Float,
    valueRange: ClosedFloatingPointRange<Float>,
    onValueChange: (Float) -> Unit,
    testTag: String = ""
) {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold),
                color = SleekTextPrimary
            )
            Text(
                text = valueStr,
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                color = SleekPurpleLight
            )
        }
        Slider(
            value = value,
            onValueChange = onValueChange,
            valueRange = valueRange,
            colors = SliderDefaults.colors(
                thumbColor = SleekPurpleLight,
                activeTrackColor = SleekPurpleLight,
                inactiveTrackColor = Color.White.copy(alpha = 0.15f)
            ),
            modifier = Modifier
                .fillMaxWidth()
                .height(32.dp)
                .testTag(testTag)
        )
    }
}

// --- PHASE 2D & 2E: REAL-TIME AUDIO EFFECTS & VOCAL REDUCTION PANEL ---

@Composable
fun AudioEffectsPanel(
    config: AudioEffectConfig,
    vocalConfig: VocalReductionConfig,
    isStereoCompatible: Boolean,
    onSelectPreset: (AudioEffectPreset) -> Unit,
    onUpdateIntensity: (Float) -> Unit,
    onSelectVocalMode: (VocalReductionMode) -> Unit,
    onUpdateVocalStrength: (Float) -> Unit,
    onReset: () -> Unit,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    val hasActiveEffects = config.preset != AudioEffectPreset.OFF ||
            config.intensity > 0.001f ||
            vocalConfig.mode != VocalReductionMode.OFF ||
            vocalConfig.strength > 0.001f

    Surface(
        shape = RoundedCornerShape(20.dp),
        color = Color(0xEC14151F),
        border = BorderStroke(1.dp, SleekPurpleDark.copy(alpha = 0.8f)),
        shadowElevation = 16.dp,
        modifier = modifier
            .widthIn(max = 380.dp)
            .fillMaxWidth(0.92f)
            .padding(12.dp)
            .testTag("audio_effects_panel")
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.SurroundSound,
                        contentDescription = null,
                        tint = SleekPurpleLight,
                        modifier = Modifier.size(20.dp)
                    )
                    Text(
                        text = "Audio Effects",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = Color.White
                    )
                }

                Row(
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(
                        onClick = onReset,
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                        enabled = hasActiveEffects,
                        modifier = Modifier.testTag("audio_effects_reset_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Reset",
                            tint = if (hasActiveEffects) SleekPurpleLight else SleekTextMuted,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Reset",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (hasActiveEffects) SleekPurpleLight else SleekTextMuted
                        )
                    }

                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .size(28.dp)
                            .testTag("audio_effects_close_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = SleekTextSecondary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }

            HorizontalDivider(color = Color.White.copy(alpha = 0.12f))

            // Presets Selection Grid
            Text(
                text = "Preset Room Profile",
                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold),
                color = SleekTextSecondary
            )

            // Preset Buttons: [Off], [Small Room], [Studio], [Concert Hall], [Cathedral]
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf(AudioEffectPreset.OFF, AudioEffectPreset.SMALL_ROOM, AudioEffectPreset.STUDIO).forEach { p ->
                        val isSelected = config.preset == p
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = if (isSelected) SleekPurpleLight.copy(alpha = 0.25f) else Color.White.copy(alpha = 0.06f),
                            border = BorderStroke(
                                1.dp,
                                if (isSelected) SleekPurpleLight else Color.White.copy(alpha = 0.1f)
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .clickable { onSelectPreset(p) }
                                .testTag("audio_preset_${p.name.lowercase()}")
                        ) {
                            Box(
                                modifier = Modifier.padding(vertical = 8.dp, horizontal = 4.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = p.displayName,
                                    fontSize = 11.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                    color = if (isSelected) SleekPurpleLight else Color.White,
                                    maxLines = 1
                                )
                            }
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf(AudioEffectPreset.CONCERT_HALL, AudioEffectPreset.CATHEDRAL).forEach { p ->
                        val isSelected = config.preset == p
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = if (isSelected) SleekPurpleLight.copy(alpha = 0.25f) else Color.White.copy(alpha = 0.06f),
                            border = BorderStroke(
                                1.dp,
                                if (isSelected) SleekPurpleLight else Color.White.copy(alpha = 0.1f)
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .clickable { onSelectPreset(p) }
                                .testTag("audio_preset_${p.name.lowercase()}")
                        ) {
                            Box(
                                modifier = Modifier.padding(vertical = 8.dp, horizontal = 4.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = p.displayName,
                                    fontSize = 11.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                    color = if (isSelected) SleekPurpleLight else Color.White,
                                    maxLines = 1
                                )
                            }
                        }
                    }
                }
            }

            // Room Intensity Control
            val intensityPercent = (config.intensity * 100).roundToInt()
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Room Intensity",
                        style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold),
                        color = if (config.preset != AudioEffectPreset.OFF) SleekTextPrimary else SleekTextMuted
                    )
                    Text(
                        text = "${intensityPercent}%",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = if (config.preset != AudioEffectPreset.OFF) SleekPurpleLight else SleekTextMuted
                    )
                }

                Slider(
                    value = config.intensity,
                    onValueChange = onUpdateIntensity,
                    valueRange = 0.0f..1.0f,
                    enabled = config.preset != AudioEffectPreset.OFF,
                    colors = SliderDefaults.colors(
                        thumbColor = SleekPurpleLight,
                        activeTrackColor = SleekPurpleLight,
                        inactiveTrackColor = Color.White.copy(alpha = 0.15f),
                        disabledThumbColor = SleekTextMuted,
                        disabledActiveTrackColor = SleekTextMuted.copy(alpha = 0.3f),
                        disabledInactiveTrackColor = Color.White.copy(alpha = 0.05f)
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(30.dp)
                        .testTag("audio_effect_intensity_slider")
                )
            }

            HorizontalDivider(color = Color.White.copy(alpha = 0.12f))

            // --- PHASE 2E: VOCAL REDUCTION / KARAOKE MODE ---
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.MicOff,
                        contentDescription = null,
                        tint = SleekPurpleLight,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = "Vocal Reduction (Karaoke)",
                        style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold),
                        color = SleekTextSecondary
                    )
                }

                if (vocalConfig.isEnabled) {
                    Text(
                        text = "ACTIVE",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, fontSize = 9.sp),
                        color = EmeraldSuccess
                    )
                }
            }

            // Modes: [Off], [Low], [Medium], [Strong]
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                listOf(
                    VocalReductionMode.OFF,
                    VocalReductionMode.LOW,
                    VocalReductionMode.MEDIUM,
                    VocalReductionMode.STRONG
                ).forEach { mode ->
                    val isSelected = vocalConfig.mode == mode
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = if (isSelected) SleekPurpleLight.copy(alpha = 0.25f) else Color.White.copy(alpha = 0.06f),
                        border = BorderStroke(
                            1.dp,
                            if (isSelected) SleekPurpleLight else Color.White.copy(alpha = 0.1f)
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .clickable { onSelectVocalMode(mode) }
                            .testTag("vocal_mode_${mode.name.lowercase()}")
                    ) {
                        Box(
                            modifier = Modifier.padding(vertical = 8.dp, horizontal = 2.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = mode.displayName,
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSelected) SleekPurpleLight else Color.White,
                                maxLines = 1
                            )
                        }
                    }
                }
            }

            // Vocal Reduction Strength Slider
            val vocalPercent = (vocalConfig.strength * 100).roundToInt()
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Vocal Reduction",
                        style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold),
                        color = if (vocalConfig.isEnabled) SleekTextPrimary else SleekTextMuted
                    )
                    Text(
                        text = "${vocalPercent}%",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = if (vocalConfig.isEnabled) SleekPurpleLight else SleekTextMuted
                    )
                }

                Slider(
                    value = vocalConfig.strength,
                    onValueChange = onUpdateVocalStrength,
                    valueRange = 0.0f..1.0f,
                    colors = SliderDefaults.colors(
                        thumbColor = SleekPurpleLight,
                        activeTrackColor = SleekPurpleLight,
                        inactiveTrackColor = Color.White.copy(alpha = 0.15f)
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(30.dp)
                        .testTag("vocal_reduction_slider")
                )
            }

            // Mono / Incompatible notice
            if (!isStereoCompatible && vocalConfig.strength > 0f) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color(0x33FFB300),
                    border = BorderStroke(1.dp, Color(0x66FFB300)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = null,
                            tint = AmberAccent,
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            text = "Vocal reduction requires a compatible stereo source.",
                            fontSize = 10.sp,
                            color = Color(0xFFFFE082),
                            lineHeight = 13.sp
                        )
                    }
                }
            }
        }
    }
}


