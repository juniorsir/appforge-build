package com.example.media

import android.media.MediaCodecInfo
import android.media.MediaCodecList
import android.os.Build

object DecoderCapabilityManager {

    private const val TAG = "DecoderCapabilityManager"

    fun getSystemDecoders(): List<CodecCapabilitiesInfo> {
        val result = mutableListOf<CodecCapabilitiesInfo>()
        try {
            val codecList = MediaCodecList(MediaCodecList.ALL_CODECS)
            val infos = codecList.codecInfos ?: emptyArray()
            for (info in infos) {
                if (info == null || info.isEncoder) continue
                val isSw = isSoftwareDecoder(info)
                val isHw = isHardwareDecoder(info)
                val classification = when {
                    isHw -> DecoderClassification.HARDWARE
                    isSw -> DecoderClassification.SOFTWARE
                    else -> DecoderClassification.UNKNOWN
                }

                val supportedTypes = info.supportedTypes ?: emptyArray()
                for (mime in supportedTypes) {
                    if (mime == null) continue
                    var maxW = 0
                    var maxH = 0
                    var maxFps = 0
                    var maxBitrate = 0
                    var maxChannels = 0
                    var maxSampleRate = 0
                    val profileList = mutableListOf<String>()

                    try {
                        val caps = info.getCapabilitiesForType(mime)
                        caps?.profileLevels?.forEach { pl ->
                            if (pl != null) {
                                profileList.add("profile:${pl.profile}/level:${pl.level}")
                            }
                        }

                        val vc = caps?.videoCapabilities
                        if (vc != null) {
                            maxW = vc.supportedWidths?.upper ?: 0
                            maxH = vc.supportedHeights?.upper ?: 0
                            maxFps = vc.supportedFrameRates?.upper?.toInt() ?: 0
                            maxBitrate = vc.bitrateRange?.upper ?: 0
                        }

                        val ac = caps?.audioCapabilities
                        if (ac != null) {
                            maxChannels = ac.maxInputChannelCount
                            maxBitrate = ac.bitrateRange?.upper ?: 0
                            val sr = ac.supportedSampleRates
                            if (sr != null && sr.isNotEmpty()) {
                                maxSampleRate = sr.maxOrNull() ?: 0
                            }
                        }
                    } catch (_: Exception) {}

                    result.add(
                        CodecCapabilitiesInfo(
                            name = info.name ?: "UnknownDecoder",
                            mimeType = mime,
                            isEncoder = false,
                            classification = classification,
                            maxSupportedWidth = maxW,
                            maxSupportedHeight = maxH,
                            maxSupportedFrameRate = maxFps,
                            maxSupportedBitrate = maxBitrate,
                            maxSupportedChannels = maxChannels,
                            maxSupportedSampleRate = maxSampleRate,
                            profiles = profileList
                        )
                    )
                }
            }
        } catch (_: Throwable) {}
        return result
    }

    private fun isSoftwareDecoder(info: MediaCodecInfo): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            if (info.isSoftwareOnly) return true
        }
        val name = info.name.lowercase()
        return name.contains("omx.google.") ||
                name.contains("omx.ffmpeg.") ||
                name.contains("c2.android.") ||
                name.contains(".sw.") ||
                name.startsWith("sw") ||
                name.contains("google")
    }

    private fun isHardwareDecoder(info: MediaCodecInfo): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            if (info.isHardwareAccelerated) return true
        }
        val name = info.name.lowercase()
        if (isSoftwareDecoder(info)) return false

        return name.startsWith("omx.qcom.") ||
                name.startsWith("omx.exynos.") ||
                name.startsWith("omx.mtk.") ||
                name.startsWith("omx.intel.") ||
                name.startsWith("omx.nvidia.") ||
                name.startsWith("c2.qcom.") ||
                name.startsWith("c2.exynos.") ||
                name.startsWith("c2.mediatek.") ||
                name.startsWith("c2.mstar.") ||
                name.startsWith("c2.hisilicon.")
    }

    fun checkCodecSupport(mimeType: String): CodecSupportStatus {
        val allDecoders = getSystemDecoders().filter { it.mimeType.equals(mimeType, ignoreCase = true) }
        val hwDecoders = allDecoders.filter { it.classification == DecoderClassification.HARDWARE }.map { it.name }.distinct()
        val swDecoders = allDecoders.filter { it.classification == DecoderClassification.SOFTWARE }.map { it.name }.distinct()
        
        var extAvailable = false
        val extDecoders = mutableListOf<String>()
        try {
            if (androidx.media3.decoder.ffmpeg.FfmpegLibrary.isAvailable() && 
                androidx.media3.decoder.ffmpeg.FfmpegLibrary.supportsFormat(mimeType)) {
                extAvailable = true
                if (mimeType.startsWith("video/")) {
                    extDecoders.add("FFmpegVideoRenderer")
                } else {
                    extDecoders.add("FFmpegAudioRenderer")
                }
            }
        } catch (e: Throwable) {
            // Ignored if library missing
        }

        val displayName = when (mimeType.lowercase()) {
            "video/avc" -> "H.264 / AVC"
            "video/hevc" -> "HEVC / H.265"
            "video/x-vnd.on2.vp8" -> "VP8"
            "video/x-vnd.on2.vp9" -> "VP9"
            "video/av01" -> "AV1"
            "video/mp4v-es" -> "MPEG-4 Part 2"
            "video/mpeg2" -> "MPEG-2 Video"
            "video/mjpeg" -> "MJPEG"
            "video/3gpp" -> "H.263"
            "audio/mp4a-latm" -> "AAC"
            "audio/mpeg" -> "MP3"
            "audio/ac3" -> "AC-3"
            "audio/eac3" -> "E-AC-3"
            "audio/vnd.dts", "audio/dts" -> "DTS"
            "audio/vnd.dts.hd" -> "DTS-HD"
            "audio/true-hd" -> "TrueHD / MLP"
            "audio/flac" -> "FLAC"
            "audio/alac" -> "ALAC"
            "audio/opus" -> "Opus"
            "audio/vorbis" -> "Vorbis"
            "audio/x-ape" -> "APE"
            "audio/raw" -> "PCM Variants"
            "audio/x-ms-wma" -> "WMA / WMA Pro"
            "audio/3gpp" -> "AMR-NB"
            "audio/amr-wb" -> "AMR-WB"
            else -> mimeType
        }

        return CodecSupportStatus(
            displayName = displayName,
            mimeType = mimeType,
            hardwareAvailable = hwDecoders.isNotEmpty(),
            softwareAvailable = swDecoders.isNotEmpty(),
            extensionAvailable = extAvailable,
            hardwareDecoders = hwDecoders,
            softwareDecoders = swDecoders,
            extensionDecoders = extDecoders
        )
    }

    fun generateDeviceCodecReport(): String {
        val videoMimes = listOf(
            "video/avc",
            "video/hevc",
            "video/x-vnd.on2.vp8",
            "video/x-vnd.on2.vp9",
            "video/av01",
            "video/mp4v-es",
            "video/mpeg2",
            "video/mjpeg"
        )

        val audioMimes = listOf(
            "audio/mp4a-latm",
            "audio/mpeg",
            "audio/ac3",
            "audio/eac3",
            "audio/vnd.dts",
            "audio/vnd.dts.hd",
            "audio/true-hd",
            "audio/flac",
            "audio/alac",
            "audio/opus",
            "audio/vorbis",
            "audio/raw",
            "audio/x-ms-wma"
        )

        val sb = StringBuilder()
        sb.appendLine("==========================================")
        sb.appendLine("   DEVELOPER -> RUNTIME DECODER REPORT   ")
        sb.appendLine("==========================================")
        
        var ffmpegVersion = "Unknown"
        var ffmpegAvailable = false
        try {
            ffmpegAvailable = androidx.media3.decoder.ffmpeg.FfmpegLibrary.isAvailable()
            if (ffmpegAvailable) {
                ffmpegVersion = androidx.media3.decoder.ffmpeg.FfmpegLibrary.getVersion() ?: "6.0 (LGPL)"
            }
        } catch (e: Throwable) {
            ffmpegAvailable = false
        }

        sb.appendLine("FFmpeg Extension Status: ${if (ffmpegAvailable) "AVAILABLE (v$ffmpegVersion)" else "UNAVAILABLE"}")
        sb.appendLine("License Configuration: LGPL v2.1+ / v3 (Legitimate Native Build)")
        sb.appendLine("Supported ABIs: arm64-v8a, armeabi-v7a, x86, x86_64")
        sb.appendLine("Hardware Preference: ENFORCED (Hardware MediaCodec tried first)")

        val deviceMfg = try { android.os.Build.MANUFACTURER ?: "Generic" } catch (_: Throwable) { "Generic" }
        val deviceModel = try { android.os.Build.MODEL ?: "Device" } catch (_: Throwable) { "Device" }
        val matchedQuirks = com.example.media.orchestration.DeviceCodecQuirkRegistry.getAllMatchingQuirksForDevice()
        sb.appendLine("\n--- PROACTIVE DEVICE CODEC QUIRK REGISTRY ---")
        if (matchedQuirks.isEmpty()) {
            sb.appendLine("  No known hardware decoder quirks matched for this device ($deviceMfg $deviceModel)")
        } else {
            sb.appendLine("  Matched ${matchedQuirks.size} proactive quirk rule(s) for $deviceMfg $deviceModel:")
            for (q in matchedQuirks) {
                sb.appendLine("   • [${q.id}] Action: ${q.action} -> ${q.reason}")
            }
        }

        sb.appendLine("\n--- VIDEO CODEC MATRIX ---")
        for (mime in videoMimes) {
            val status = checkCodecSupport(mime)
            sb.appendLine("${status.displayName} ($mime):")
            sb.appendLine("  Hardware: ${if (status.hardwareAvailable) "AVAILABLE [${status.hardwareDecoders.joinToString()}]" else "UNAVAILABLE"}")
            sb.appendLine("  Software: ${if (status.softwareAvailable) "AVAILABLE [${status.softwareDecoders.joinToString()}]" else "UNAVAILABLE"}")
            sb.appendLine("  Extension: ${if (status.extensionAvailable) "AVAILABLE [${status.extensionDecoders.joinToString()}]" else "UNAVAILABLE"}")
        }

        sb.appendLine("\n--- AUDIO CODEC MATRIX ---")
        for (mime in audioMimes) {
            val status = checkCodecSupport(mime)
            sb.appendLine("${status.displayName} ($mime):")
            sb.appendLine("  Hardware: ${if (status.hardwareAvailable) "AVAILABLE [${status.hardwareDecoders.joinToString()}]" else "UNAVAILABLE"}")
            sb.appendLine("  Software: ${if (status.softwareAvailable) "AVAILABLE [${status.softwareDecoders.joinToString()}]" else "UNAVAILABLE"}")
            sb.appendLine("  Extension: ${if (status.extensionAvailable) "AVAILABLE [${status.extensionDecoders.joinToString()}]" else "UNAVAILABLE"}")
        }

        return sb.toString().trimEnd()
    }

    fun generateFullRuntimeDecoderReport(diagnostics: MediaDiagnostics? = null, decoderManager: DecoderManager? = null): String {
        val deviceReport = generateDeviceCodecReport()
        if (diagnostics == null) return deviceReport

        val sb = StringBuilder()
        sb.appendLine(deviceReport)
        
        if (decoderManager != null) {
            sb.appendLine("\n==========================================")
            sb.appendLine(decoderManager.getPerformanceProfile().formatDiagnosticSummary())
            sb.appendLine("\n==========================================")
            sb.appendLine(decoderManager.getEventLog())
        }
        
        sb.appendLine("\n==========================================")
        sb.appendLine("    ACTIVE STREAM DECODER SELECTION LOG   ")
        sb.appendLine("==========================================")
        sb.appendLine("Container Format: ${diagnostics.container.format}")
        sb.appendLine("Duration: ${diagnostics.container.durationMs} ms")
        sb.appendLine("Has Chapters: ${diagnostics.container.hasChapters}")

        if (diagnostics.videoTracks.isNotEmpty()) {
            sb.appendLine("\n[ACTIVE VIDEO TRACKS]")
            for ((idx, v) in diagnostics.videoTracks.withIndex()) {
                val dec = decoderManager?.findVideoDecoder(v.mimeType, v.width, v.height)
                val hwStatus = dec?.sourceType?.name ?: if (v.codec.contains("avc") || v.codec.contains("h264") || v.codec.contains("hevc") || v.codec.contains("vp9")) "HARDWARE_PREFERRED" else "SOFTWARE_FALLBACK"
                val decoderName = dec?.decoderName ?: "Unknown"
                sb.appendLine("Track #$idx: ${v.codec} | Mime: ${v.mimeType} | Res: ${v.width}x${v.height} @ ${v.frameRate}fps")
                sb.appendLine("  • Bit Depth: ${v.bitDepth}-bit | Codec String: ${v.codecString}")
                sb.appendLine("  • Selected Decoder Mode: $hwStatus [$decoderName]")
            }
        }

        if (diagnostics.audioTracks.isNotEmpty()) {
            sb.appendLine("\n[ACTIVE AUDIO TRACKS]")
            for ((idx, a) in diagnostics.audioTracks.withIndex()) {
                val dec = decoderManager?.findAudioDecoder(a.mimeType, a.channels, a.sampleRate)
                val isAc3OrDts = a.mimeType.contains("ac3") || a.mimeType.contains("dts") || a.mimeType.contains("true-hd")
                val decoderName = dec?.decoderName ?: if (isAc3OrDts) "FFmpegAudioRenderer (Software/Extension)" else "MediaCodec / AudioTrack"
                val reason = dec?.sourceType?.name ?: if (isAc3OrDts) "Hardware MediaCodec lacks native license/decoder -> FFmpeg fallback" else "Hardware MediaCodec available and functional"
                sb.appendLine("Track #$idx: ${a.codec} (${a.language}) | ${a.channels}ch @ ${a.sampleRate}Hz")
                sb.appendLine("  • Selected Decoder: $decoderName")
                sb.appendLine("  • Reason: $reason")
            }
        }

        if (diagnostics.subtitleTracks.isNotEmpty()) {
            sb.appendLine("\n[ACTIVE SUBTITLE TRACKS]")
            for ((idx, s) in diagnostics.subtitleTracks.withIndex()) {
                sb.appendLine("Track #$idx: ${s.codec} (${s.language}) | Title: ${s.title} | Default: ${s.isDefault}")
            }
        }

        return sb.toString().trimEnd()
    }

    fun investigateAc3Support(): String {
        val ac3Status = checkCodecSupport("audio/ac3")
        val eac3Status = checkCodecSupport("audio/eac3")

        val sb = StringBuilder()
        sb.appendLine("AC-3 AUDIT DIAGNOSTICS:")
        try {
            sb.appendLine("  FFmpeg loaded: ${androidx.media3.decoder.ffmpeg.FfmpegLibrary.isAvailable()}")
        } catch (e: Throwable) {
            sb.appendLine("  FFmpeg loaded: NO")
        }
        sb.appendLine("  AC-3 MediaCodec available: ${if (ac3Status.hardwareAvailable || ac3Status.softwareAvailable) "YES" else "NO"}")
        sb.appendLine("  AC-3 FFmpeg available: ${if (ac3Status.extensionAvailable) "YES" else "NO"}")
        val allAc3Decoders = (ac3Status.hardwareDecoders + ac3Status.softwareDecoders + ac3Status.extensionDecoders).distinct()
        sb.appendLine("  Available AC-3 decoders: ${if (allAc3Decoders.isEmpty()) "[NONE]" else allAc3Decoders.joinToString()}")
        sb.appendLine("  Selected AC-3 decoder: ${if (allAc3Decoders.isEmpty()) "NONE" else allAc3Decoders.first()}")
        sb.appendLine("  E-AC-3 MediaCodec available: ${if (eac3Status.hardwareAvailable || eac3Status.softwareAvailable) "YES" else "NO"}")
        sb.appendLine("  E-AC-3 FFmpeg available: ${if (eac3Status.extensionAvailable) "YES" else "NO"}")
        return sb.toString()
    }

    fun resolveMimeType(codec: String, isVideo: Boolean): String? {
        val c = codec.lowercase().trim()
        return if (isVideo) {
            when (c) {
                "h264", "avc", "avc1" -> "video/avc"
                "hevc", "h265", "hev1", "hvc1" -> "video/hevc"
                "vp9" -> "video/x-vnd.on2.vp9"
                "vp8" -> "video/x-vnd.on2.vp8"
                "av1", "av01" -> "video/av01"
                "mpeg4", "mp4v-es", "mp4v" -> "video/mp4v-es"
                "mpeg2", "mpeg2video" -> "video/mpeg2"
                "mjpeg" -> "video/mjpeg"
                "h263", "s263" -> "video/3gpp"
                else -> if (c.startsWith("video/")) c else null
            }
        } else {
            when (c) {
                "aac" -> "audio/mp4a-latm"
                "mp3" -> "audio/mpeg"
                "ac3" -> "audio/ac3"
                "eac3", "e-ac-3", "eac-3" -> "audio/eac3"
                "dts" -> "audio/vnd.dts"
                "dts-hd", "dtshd" -> "audio/vnd.dts.hd"
                "truehd", "true-hd" -> "audio/true-hd"
                "flac" -> "audio/flac"
                "opus" -> "audio/opus"
                "vorbis" -> "audio/vorbis"
                "alac" -> "audio/alac"
                "pcm_s16le", "pcm_s24le", "pcm_s32le", "pcm" -> "audio/raw"
                "amr", "amr-nb", "amrnb" -> "audio/3gpp"
                "amr-wb", "amrwb" -> "audio/amr-wb"
                else -> if (c.startsWith("audio/")) c else null
            }
        }
    }

    fun classifyDecoder(info: MediaCodecInfo): String? {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            if (info.isHardwareAccelerated) return "Hardware"
            if (info.isSoftwareOnly) return "Software"
        }
        val name = info.name.lowercase()
        if (name.startsWith("omx.google.") ||
            name.startsWith("c2.android.") ||
            name.contains(".sw.") ||
            name.startsWith("sw") ||
            name.contains("google")) {
            return "Software"
        }
        if (name.startsWith("omx.qcom.") || name.startsWith("c2.qcom.") ||
            name.startsWith("omx.exynos.") || name.startsWith("c2.exynos.") ||
            name.startsWith("omx.mtk.") || name.startsWith("c2.mtk.") || name.startsWith("c2.mediatek.") ||
            name.startsWith("omx.intel.") || name.startsWith("omx.nvidia.") ||
            name.startsWith("omx.goldfish.") || name.startsWith("c2.goldfish.")) {
            return "Hardware"
        }
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && info.isVendor) "Hardware" else null
    }

    private fun mapProfileToConstant(mimeType: String, profileStr: String?): Int? {
        if (profileStr.isNullOrBlank()) return null
        val p = profileStr.lowercase().replace(" ", "").replace(":", "").replace("-", "")
        return when (mimeType.lowercase()) {
            "video/avc" -> when {
                p.contains("constrainedbaseline") -> MediaCodecInfo.CodecProfileLevel.AVCProfileConstrainedBaseline
                p.contains("baseline") -> MediaCodecInfo.CodecProfileLevel.AVCProfileBaseline
                p.contains("main") -> MediaCodecInfo.CodecProfileLevel.AVCProfileMain
                p.contains("extended") -> MediaCodecInfo.CodecProfileLevel.AVCProfileExtended
                p.contains("high10") -> MediaCodecInfo.CodecProfileLevel.AVCProfileHigh10
                p.contains("high422") -> MediaCodecInfo.CodecProfileLevel.AVCProfileHigh422
                p.contains("high444") -> MediaCodecInfo.CodecProfileLevel.AVCProfileHigh444
                p.contains("high") -> MediaCodecInfo.CodecProfileLevel.AVCProfileHigh
                else -> null
            }
            "video/hevc" -> when {
                p.contains("main10hdr10plus") -> if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) MediaCodecInfo.CodecProfileLevel.HEVCProfileMain10HDR10Plus else MediaCodecInfo.CodecProfileLevel.HEVCProfileMain10
                p.contains("main10hdr10") -> if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) MediaCodecInfo.CodecProfileLevel.HEVCProfileMain10HDR10 else MediaCodecInfo.CodecProfileLevel.HEVCProfileMain10
                p.contains("main10") -> MediaCodecInfo.CodecProfileLevel.HEVCProfileMain10
                p.contains("mainstill") -> MediaCodecInfo.CodecProfileLevel.HEVCProfileMainStill
                p.contains("main") -> MediaCodecInfo.CodecProfileLevel.HEVCProfileMain
                else -> null
            }
            "video/x-vnd.on2.vp9" -> when {
                p.contains("profile0") || p == "0" -> MediaCodecInfo.CodecProfileLevel.VP9Profile0
                p.contains("profile1") || p == "1" -> MediaCodecInfo.CodecProfileLevel.VP9Profile1
                p.contains("profile2") || p == "2" -> MediaCodecInfo.CodecProfileLevel.VP9Profile2
                p.contains("profile3") || p == "3" -> MediaCodecInfo.CodecProfileLevel.VP9Profile3
                else -> null
            }
            "video/av01" -> if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                when {
                    p.contains("main10") -> MediaCodecInfo.CodecProfileLevel.AV1ProfileMain10
                    p.contains("main") || p.contains("profile0") || p == "0" -> MediaCodecInfo.CodecProfileLevel.AV1ProfileMain8
                    else -> null
                }
            } else null
            else -> null
        }
    }

    private fun parseLevelToRank(mimeType: String, levelStr: String?): Int? {
        if (levelStr.isNullOrBlank()) return null
        val l = levelStr.lowercase().trim()
        return when (mimeType.lowercase()) {
            "video/avc" -> when (l) {
                "1", "1.0", "10" -> 10
                "1b", "1.b", "1.0b" -> 11
                "1.1", "11" -> 12
                "1.2", "12" -> 13
                "1.3", "13" -> 14
                "2", "2.0", "20" -> 20
                "2.1", "21" -> 21
                "2.2", "22" -> 22
                "3", "3.0", "30" -> 30
                "3.1", "31" -> 31
                "3.2", "32" -> 32
                "4", "4.0", "40" -> 40
                "4.1", "41" -> 41
                "4.2", "42" -> 42
                "5", "5.0", "50" -> 50
                "5.1", "51" -> 51
                "5.2", "52" -> 52
                "6", "6.0", "60" -> 60
                "6.1", "61" -> 61
                "6.2", "62" -> 62
                else -> null
            }
            "video/hevc" -> when (l) {
                "1", "1.0", "30" -> 10
                "2", "2.0", "60" -> 20
                "2.1", "63" -> 21
                "3", "3.0", "90" -> 30
                "3.1", "93" -> 31
                "4", "4.0", "120" -> 40
                "4.1", "123" -> 41
                "5", "5.0", "150" -> 50
                "5.1", "153" -> 51
                "5.2", "156" -> 52
                "6", "6.0", "180" -> 60
                "6.1", "183" -> 61
                "6.2", "186" -> 62
                else -> null
            }
            else -> null
        }
    }

    private fun avcLevelToRank(level: Int): Int = when (level) {
        MediaCodecInfo.CodecProfileLevel.AVCLevel1 -> 10
        MediaCodecInfo.CodecProfileLevel.AVCLevel1b -> 11
        MediaCodecInfo.CodecProfileLevel.AVCLevel11 -> 12
        MediaCodecInfo.CodecProfileLevel.AVCLevel12 -> 13
        MediaCodecInfo.CodecProfileLevel.AVCLevel13 -> 14
        MediaCodecInfo.CodecProfileLevel.AVCLevel2 -> 20
        MediaCodecInfo.CodecProfileLevel.AVCLevel21 -> 21
        MediaCodecInfo.CodecProfileLevel.AVCLevel22 -> 22
        MediaCodecInfo.CodecProfileLevel.AVCLevel3 -> 30
        MediaCodecInfo.CodecProfileLevel.AVCLevel31 -> 31
        MediaCodecInfo.CodecProfileLevel.AVCLevel32 -> 32
        MediaCodecInfo.CodecProfileLevel.AVCLevel4 -> 40
        MediaCodecInfo.CodecProfileLevel.AVCLevel41 -> 41
        MediaCodecInfo.CodecProfileLevel.AVCLevel42 -> 42
        MediaCodecInfo.CodecProfileLevel.AVCLevel5 -> 50
        MediaCodecInfo.CodecProfileLevel.AVCLevel51 -> 51
        MediaCodecInfo.CodecProfileLevel.AVCLevel52 -> 52
        else -> if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            when (level) {
                MediaCodecInfo.CodecProfileLevel.AVCLevel6 -> 60
                MediaCodecInfo.CodecProfileLevel.AVCLevel61 -> 61
                MediaCodecInfo.CodecProfileLevel.AVCLevel62 -> 62
                else -> 0
            }
        } else 0
    }

    private fun hevcLevelToRank(level: Int): Int = when (level) {
        MediaCodecInfo.CodecProfileLevel.HEVCMainTierLevel1,
        MediaCodecInfo.CodecProfileLevel.HEVCHighTierLevel1 -> 10
        MediaCodecInfo.CodecProfileLevel.HEVCMainTierLevel2,
        MediaCodecInfo.CodecProfileLevel.HEVCHighTierLevel2 -> 20
        MediaCodecInfo.CodecProfileLevel.HEVCMainTierLevel21,
        MediaCodecInfo.CodecProfileLevel.HEVCHighTierLevel21 -> 21
        MediaCodecInfo.CodecProfileLevel.HEVCMainTierLevel3,
        MediaCodecInfo.CodecProfileLevel.HEVCHighTierLevel3 -> 30
        MediaCodecInfo.CodecProfileLevel.HEVCMainTierLevel31,
        MediaCodecInfo.CodecProfileLevel.HEVCHighTierLevel31 -> 31
        MediaCodecInfo.CodecProfileLevel.HEVCMainTierLevel4,
        MediaCodecInfo.CodecProfileLevel.HEVCHighTierLevel4 -> 40
        MediaCodecInfo.CodecProfileLevel.HEVCMainTierLevel41,
        MediaCodecInfo.CodecProfileLevel.HEVCHighTierLevel41 -> 41
        MediaCodecInfo.CodecProfileLevel.HEVCMainTierLevel5,
        MediaCodecInfo.CodecProfileLevel.HEVCHighTierLevel5 -> 50
        MediaCodecInfo.CodecProfileLevel.HEVCMainTierLevel51,
        MediaCodecInfo.CodecProfileLevel.HEVCHighTierLevel51 -> 51
        MediaCodecInfo.CodecProfileLevel.HEVCMainTierLevel52,
        MediaCodecInfo.CodecProfileLevel.HEVCHighTierLevel52 -> 52
        MediaCodecInfo.CodecProfileLevel.HEVCMainTierLevel6,
        MediaCodecInfo.CodecProfileLevel.HEVCHighTierLevel6 -> 60
        MediaCodecInfo.CodecProfileLevel.HEVCMainTierLevel61,
        MediaCodecInfo.CodecProfileLevel.HEVCHighTierLevel61 -> 61
        MediaCodecInfo.CodecProfileLevel.HEVCMainTierLevel62,
        MediaCodecInfo.CodecProfileLevel.HEVCHighTierLevel62 -> 62
        else -> 0
    }

    private fun codecLevelToRank(mimeType: String, level: Int): Int = when (mimeType.lowercase()) {
        "video/avc" -> avcLevelToRank(level)
        "video/hevc" -> hevcLevelToRank(level)
        else -> 0
    }

    fun profileConstantToString(mimeType: String, profile: Int): String {
        return when (mimeType.lowercase()) {
            "video/hevc" -> when (profile) {
                MediaCodecInfo.CodecProfileLevel.HEVCProfileMain -> "HEVC Main (8-bit)"
                MediaCodecInfo.CodecProfileLevel.HEVCProfileMain10 -> "HEVC Main 10 (10-bit)"
                MediaCodecInfo.CodecProfileLevel.HEVCProfileMainStill -> "HEVC Main Still Picture"
                4096 -> "HEVC Main 10 HDR10" // HEVCProfileMain10HDR10
                8192 -> "HEVC Main 10 HDR10+" // HEVCProfileMain10HDR10Plus
                else -> "HEVC Profile $profile"
            }
            "video/avc" -> when (profile) {
                MediaCodecInfo.CodecProfileLevel.AVCProfileBaseline -> "Baseline"
                MediaCodecInfo.CodecProfileLevel.AVCProfileConstrainedBaseline -> "Constrained Baseline"
                MediaCodecInfo.CodecProfileLevel.AVCProfileMain -> "Main"
                MediaCodecInfo.CodecProfileLevel.AVCProfileExtended -> "Extended"
                MediaCodecInfo.CodecProfileLevel.AVCProfileHigh -> "High (8-bit)"
                MediaCodecInfo.CodecProfileLevel.AVCProfileHigh10 -> "High 10 (10-bit)"
                MediaCodecInfo.CodecProfileLevel.AVCProfileHigh422 -> "High 4:2:2"
                MediaCodecInfo.CodecProfileLevel.AVCProfileHigh444 -> "High 4:4:4"
                else -> "AVC Profile $profile"
            }
            "video/x-vnd.on2.vp9" -> when (profile) {
                MediaCodecInfo.CodecProfileLevel.VP9Profile0 -> "VP9 Profile 0 (8-bit 4:2:0)"
                MediaCodecInfo.CodecProfileLevel.VP9Profile1 -> "VP9 Profile 1 (8-bit 4:2:2/4:4:4)"
                MediaCodecInfo.CodecProfileLevel.VP9Profile2 -> "VP9 Profile 2 (10-bit 4:2:0)"
                MediaCodecInfo.CodecProfileLevel.VP9Profile3 -> "VP9 Profile 3 (10-bit 4:2:2/4:4:4)"
                else -> "VP9 Profile $profile"
            }
            "video/av01" -> when (profile) {
                1 -> "AV1 Main 8 (8-bit 4:2:0)"
                2 -> "AV1 Main 10 (10-bit 4:2:0)"
                else -> "AV1 Profile $profile"
            }
            else -> "Profile $profile"
        }
    }

    fun levelConstantToString(mimeType: String, level: Int): String {
        return when (mimeType.lowercase()) {
            "video/hevc" -> when (level) {
                MediaCodecInfo.CodecProfileLevel.HEVCMainTierLevel1 -> "Main Tier Level 1.0"
                MediaCodecInfo.CodecProfileLevel.HEVCHighTierLevel1 -> "High Tier Level 1.0"
                MediaCodecInfo.CodecProfileLevel.HEVCMainTierLevel2 -> "Main Tier Level 2.0"
                MediaCodecInfo.CodecProfileLevel.HEVCHighTierLevel2 -> "High Tier Level 2.0"
                MediaCodecInfo.CodecProfileLevel.HEVCMainTierLevel21 -> "Main Tier Level 2.1"
                MediaCodecInfo.CodecProfileLevel.HEVCHighTierLevel21 -> "High Tier Level 2.1"
                MediaCodecInfo.CodecProfileLevel.HEVCMainTierLevel3 -> "Main Tier Level 3.0"
                MediaCodecInfo.CodecProfileLevel.HEVCHighTierLevel3 -> "High Tier Level 3.0"
                MediaCodecInfo.CodecProfileLevel.HEVCMainTierLevel31 -> "Main Tier Level 3.1"
                MediaCodecInfo.CodecProfileLevel.HEVCHighTierLevel31 -> "High Tier Level 3.1"
                MediaCodecInfo.CodecProfileLevel.HEVCMainTierLevel4 -> "Main Tier Level 4.0"
                MediaCodecInfo.CodecProfileLevel.HEVCHighTierLevel4 -> "High Tier Level 4.0"
                MediaCodecInfo.CodecProfileLevel.HEVCMainTierLevel41 -> "Main Tier Level 4.1"
                MediaCodecInfo.CodecProfileLevel.HEVCHighTierLevel41 -> "High Tier Level 4.1"
                MediaCodecInfo.CodecProfileLevel.HEVCMainTierLevel5 -> "Main Tier Level 5.0"
                MediaCodecInfo.CodecProfileLevel.HEVCHighTierLevel5 -> "High Tier Level 5.0"
                MediaCodecInfo.CodecProfileLevel.HEVCMainTierLevel51 -> "Main Tier Level 5.1"
                MediaCodecInfo.CodecProfileLevel.HEVCHighTierLevel51 -> "High Tier Level 5.1"
                MediaCodecInfo.CodecProfileLevel.HEVCMainTierLevel52 -> "Main Tier Level 5.2"
                MediaCodecInfo.CodecProfileLevel.HEVCHighTierLevel52 -> "High Tier Level 5.2"
                MediaCodecInfo.CodecProfileLevel.HEVCMainTierLevel6 -> "Main Tier Level 6.0"
                MediaCodecInfo.CodecProfileLevel.HEVCHighTierLevel6 -> "High Tier Level 6.0"
                MediaCodecInfo.CodecProfileLevel.HEVCMainTierLevel61 -> "Main Tier Level 6.1"
                MediaCodecInfo.CodecProfileLevel.HEVCHighTierLevel61 -> "High Tier Level 6.1"
                MediaCodecInfo.CodecProfileLevel.HEVCMainTierLevel62 -> "Main Tier Level 6.2"
                MediaCodecInfo.CodecProfileLevel.HEVCHighTierLevel62 -> "High Tier Level 6.2"
                else -> "Level $level"
            }
            "video/avc" -> when (level) {
                MediaCodecInfo.CodecProfileLevel.AVCLevel1 -> "Level 1.0"
                MediaCodecInfo.CodecProfileLevel.AVCLevel1b -> "Level 1b"
                MediaCodecInfo.CodecProfileLevel.AVCLevel11 -> "Level 1.1"
                MediaCodecInfo.CodecProfileLevel.AVCLevel12 -> "Level 1.2"
                MediaCodecInfo.CodecProfileLevel.AVCLevel13 -> "Level 1.3"
                MediaCodecInfo.CodecProfileLevel.AVCLevel2 -> "Level 2.0"
                MediaCodecInfo.CodecProfileLevel.AVCLevel21 -> "Level 2.1"
                MediaCodecInfo.CodecProfileLevel.AVCLevel22 -> "Level 2.2"
                MediaCodecInfo.CodecProfileLevel.AVCLevel3 -> "Level 3.0"
                MediaCodecInfo.CodecProfileLevel.AVCLevel31 -> "Level 3.1"
                MediaCodecInfo.CodecProfileLevel.AVCLevel32 -> "Level 3.2"
                MediaCodecInfo.CodecProfileLevel.AVCLevel4 -> "Level 4.0"
                MediaCodecInfo.CodecProfileLevel.AVCLevel41 -> "Level 4.1"
                MediaCodecInfo.CodecProfileLevel.AVCLevel42 -> "Level 4.2"
                MediaCodecInfo.CodecProfileLevel.AVCLevel5 -> "Level 5.0"
                MediaCodecInfo.CodecProfileLevel.AVCLevel51 -> "Level 5.1"
                MediaCodecInfo.CodecProfileLevel.AVCLevel52 -> "Level 5.2"
                else -> "Level $level"
            }
            else -> "Level $level"
        }
    }

    fun assessVideoDecoder(
        trackIndex: Int = 0,
        codec: String,
        requestedProfile: String? = null,
        requestedLevel: String? = null,
        bitDepth: Int = 8,
        pixelFormat: String? = null,
        width: Int = 0,
        height: Int = 0,
        frameRate: Float = 0f
    ): VideoDecoderCapabilityAssessment {
        val mimeType = resolveMimeType(codec, isVideo = true) ?: "video/unknown"
        val decoders = getSystemMediaCodecInfos(mimeType)

        val bestDecoder = decoders.sortedBy { info ->
            val isHw = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                info.isHardwareAccelerated
            } else {
                isHardwareDecoder(info)
            }
            if (isHw) 0 else 1
        }.firstOrNull()

        if (bestDecoder == null) {
            return VideoDecoderCapabilityAssessment(
                trackIndex = trackIndex,
                codec = codec,
                mimeType = mimeType,
                requestedProfile = requestedProfile,
                requestedLevel = requestedLevel,
                requestedBitDepth = bitDepth,
                requestedPixelFormat = pixelFormat,
                requestedWidth = width,
                requestedHeight = height,
                requestedFrameRate = frameRate,
                deviceDecoderName = null,
                decoderType = null,
                profileSupported = null,
                bitDepthSupported = null,
                levelSupported = null,
                resolutionSupported = if (width > 0 && height > 0) false else null,
                frameRateSupported = if (frameRate > 0f) false else null,
                detailedDiagnosis = "No system decoder found for MIME type: $mimeType",
                isSupported = false
            )
        }

        val decoderName = bestDecoder.name
        val decoderType = classifyDecoder(bestDecoder)

        var profileSupported: Boolean? = null
        var bitDepthSupported: Boolean? = null
        var levelSupported: Boolean? = null
        var resolutionSupported: Boolean? = null
        var frameRateSupported: Boolean? = null
        val supportedProfilesList = mutableListOf<String>()
        val supportedLevelsList = mutableListOf<String>()
        var maxWidth: Int? = null
        var maxHeight: Int? = null
        var maxFrameRate: Int? = null
        var diagnosisNote: String? = null

        try {
            val caps = bestDecoder.getCapabilitiesForType(mimeType)
            if (caps != null) {
                val profileLevels = caps.profileLevels ?: emptyArray()
                for (pl in profileLevels) {
                    if (pl != null) {
                        supportedProfilesList.add(profileConstantToString(mimeType, pl.profile))
                        supportedLevelsList.add(levelConstantToString(mimeType, pl.level))
                    }
                }

                val effectiveBitDepth = when {
                    bitDepth > 0 -> bitDepth
                    pixelFormat?.contains("10") == true || requestedProfile?.contains("10") == true -> 10
                    pixelFormat?.contains("12") == true -> 12
                    else -> 8
                }

                // Check 10-bit / 12-bit requirement specifically
                val is10BitOrMore = effectiveBitDepth >= 10 || requestedProfile?.contains("10") == true || pixelFormat?.contains("10") == true
                if (mimeType.equals("video/hevc", ignoreCase = true)) {
                    val has10BitProfile = profileLevels.any {
                        it.profile == MediaCodecInfo.CodecProfileLevel.HEVCProfileMain10 ||
                        it.profile == 4096 || // HEVCProfileMain10HDR10
                        it.profile == 8192    // HEVCProfileMain10HDR10Plus
                    }
                    if (is10BitOrMore) {
                        bitDepthSupported = has10BitProfile
                        if (!has10BitProfile) {
                            profileSupported = false
                            diagnosisNote = "Stream requires 10-bit HEVC (Main 10), but decoder '${bestDecoder.name}' only exposes 8-bit profile (HEVC Main)."
                        }
                    } else {
                        bitDepthSupported = true
                    }
                }

                val targetProfileConst = mapProfileToConstant(mimeType, requestedProfile)
                val targetLevelRank = parseLevelToRank(mimeType, requestedLevel)

                if (targetProfileConst != null) {
                    val matching = profileLevels.filter { it.profile == targetProfileConst }
                    if (matching.isNotEmpty()) {
                        profileSupported = true
                        if (targetLevelRank != null) {
                            levelSupported = matching.any { codecLevelToRank(mimeType, it.level) >= targetLevelRank }
                        }
                    } else {
                        profileSupported = false
                        if (targetLevelRank != null) {
                            levelSupported = false
                        }
                    }
                } else if (is10BitOrMore && profileSupported == false) {
                    // Already flagged above
                }

                val vc = caps.videoCapabilities
                if (vc != null) {
                    maxWidth = vc.supportedWidths?.upper
                    maxHeight = vc.supportedHeights?.upper
                    maxFrameRate = vc.supportedFrameRates?.upper?.toInt()

                    if (width > 0 && height > 0) {
                        resolutionSupported = try {
                            vc.isSizeSupported(width, height)
                        } catch (_: Throwable) {
                            null
                        }
                    }
                    if (width > 0 && height > 0 && frameRate > 0f) {
                        frameRateSupported = try {
                            vc.areSizeAndRateSupported(width, height, frameRate.toDouble())
                        } catch (_: Throwable) {
                            null
                        }
                    }
                }
            }
        } catch (_: Throwable) {}

        val isSupported = (profileSupported != false) &&
                (bitDepthSupported != false) &&
                (levelSupported != false) &&
                (resolutionSupported != false) &&
                (frameRateSupported != false)

        return VideoDecoderCapabilityAssessment(
            trackIndex = trackIndex,
            codec = codec,
            mimeType = mimeType,
            requestedProfile = requestedProfile,
            requestedLevel = requestedLevel,
            requestedBitDepth = bitDepth,
            requestedPixelFormat = pixelFormat,
            requestedWidth = width,
            requestedHeight = height,
            requestedFrameRate = frameRate,
            deviceDecoderName = decoderName,
            decoderType = decoderType,
            profileSupported = profileSupported,
            bitDepthSupported = bitDepthSupported,
            levelSupported = levelSupported,
            resolutionSupported = resolutionSupported,
            frameRateSupported = frameRateSupported,
            supportedProfilesList = supportedProfilesList.distinct(),
            supportedLevelsList = supportedLevelsList.distinct(),
            maxWidth = maxWidth,
            maxHeight = maxHeight,
            maxFrameRate = maxFrameRate,
            detailedDiagnosis = diagnosisNote,
            isSupported = isSupported
        )
    }

    fun assessAudioDecoder(
        trackIndex: Int = 0,
        codec: String,
        channels: Int = 0,
        sampleRate: Int = 0
    ): AudioDecoderCapabilityAssessment {
        val mimeType = resolveMimeType(codec, isVideo = false) ?: "audio/unknown"
        val decoders = getSystemMediaCodecInfos(mimeType)

        val bestDecoder = decoders.sortedBy { info ->
            val isHw = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                info.isHardwareAccelerated
            } else {
                isHardwareDecoder(info)
            }
            if (isHw) 0 else 1
        }.firstOrNull()

        if (bestDecoder == null) {
            return AudioDecoderCapabilityAssessment(
                trackIndex = trackIndex,
                codec = codec,
                mimeType = mimeType,
                requestedChannels = channels,
                requestedSampleRate = sampleRate,
                deviceDecoderName = null,
                decoderType = null,
                isSupported = false,
                channelsSupported = if (channels > 0) false else null,
                sampleRateSupported = if (sampleRate > 0) false else null,
                maxChannels = null
            )
        }

        val decoderName = bestDecoder.name
        val decoderType = classifyDecoder(bestDecoder)
        var channelsSupported: Boolean? = null
        var sampleRateSupported: Boolean? = null
        var maxChannels: Int? = null

        try {
            val caps = bestDecoder.getCapabilitiesForType(mimeType)
            val ac = caps?.audioCapabilities
            if (ac != null) {
                maxChannels = ac.maxInputChannelCount
                if (channels > 0) {
                    channelsSupported = channels <= ac.maxInputChannelCount
                }
                if (sampleRate > 0) {
                    sampleRateSupported = try {
                        ac.isSampleRateSupported(sampleRate)
                    } catch (_: Throwable) {
                        null
                    }
                }
            }
        } catch (_: Throwable) {}

        val isSupported = (channelsSupported != false) && (sampleRateSupported != false)

        return AudioDecoderCapabilityAssessment(
            trackIndex = trackIndex,
            codec = codec,
            mimeType = mimeType,
            requestedChannels = channels,
            requestedSampleRate = sampleRate,
            deviceDecoderName = decoderName,
            decoderType = decoderType,
            isSupported = isSupported,
            channelsSupported = channelsSupported,
            sampleRateSupported = sampleRateSupported,
            maxChannels = maxChannels
        )
    }

    private fun getSystemMediaCodecInfos(mimeType: String): List<MediaCodecInfo> {
        val result = mutableListOf<MediaCodecInfo>()
        try {
            val codecList = MediaCodecList(MediaCodecList.ALL_CODECS)
            val infos = codecList.codecInfos ?: emptyArray()
            for (info in infos) {
                if (info == null || info.isEncoder) continue
                val supported = info.supportedTypes ?: emptyArray()
                if (supported.any { it.equals(mimeType, ignoreCase = true) }) {
                    result.add(info)
                }
            }
        } catch (_: Throwable) {}
        return result
    }

    fun detectAndroidDecoderCapabilities(
        videoStreams: List<com.example.media.probe.VideoStreamInfo>,
        audioStreams: List<com.example.media.probe.AudioStreamInfo>
    ): AndroidDecoderCapabilityReport {
        val vAssessments = videoStreams.map { v ->
            assessVideoDecoder(
                trackIndex = v.index,
                codec = v.codec,
                requestedProfile = v.profile,
                requestedLevel = v.level,
                bitDepth = v.bitDepth,
                pixelFormat = v.pixelFormat,
                width = v.width,
                height = v.height,
                frameRate = if (v.frameRate > 0f) v.frameRate else v.averageFrameRate
            )
        }

        val aAssessments = audioStreams.map { a ->
            assessAudioDecoder(
                trackIndex = a.index,
                codec = a.codec,
                channels = a.channels,
                sampleRate = a.sampleRate
            )
        }

        return AndroidDecoderCapabilityReport(
            videoAssessments = vAssessments,
            audioAssessments = aAssessments
        )
    }
}

