package com.example

import android.content.Context
import android.net.Uri
import androidx.test.core.app.ApplicationProvider
import com.example.media.probe.AudioStreamInfo
import com.example.media.probe.MediaProbeInfo
import com.example.media.probe.VideoStreamInfo
import kotlinx.coroutines.test.runTest
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  private val context: Context get() = ApplicationProvider.getApplicationContext()

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Downly", appName)
  }

  @Test
  fun testCloudBackupManifestSerializationAndValidation() {
      val playlists = listOf(
          com.example.ui.Playlist(
              id = "pl_1",
              name = "My Study List",
              description = "Lecture clips",
              createdAt = 1700000000000L,
              mediaIds = listOf("media_1", "media_2")
          )
      )

      val downloads = listOf(
          com.example.data.DownloadEntity(
              id = "media_1",
              title = "Kotlin Flow Deep Dive",
              author = "Android Team",
              durationText = "12:30",
              thumbnailUrl = "https://example.com/thumb.jpg",
              localPath = "/storage/emulated/0/media_1.mp4",
              fileSize = 52428800L,
              downloadedAt = 1700000000000L,
              isFavorite = true,
              isKept = true,
              isProtected = false
          )
      )

      val progress = listOf(
          com.example.data.PlaybackProgressEntity(
              mediaId = "media_1",
              mediaPath = "/storage/emulated/0/media_1.mp4",
              durationMs = 750000L,
              lastPositionMs = 300000L,
              lastPlayedTimestamp = 1700000100000L,
              isCompleted = false,
              completedTimestamp = 0L
          )
      )

      val markers = listOf(
          com.example.data.MediaMarkerEntity(
              id = 1L,
              mediaId = "media_1",
              positionMs = 120000L,
              note = "StateFlow vs SharedFlow - Key architectural difference",
              createdAt = 1700000050000L
          )
      )

      val preferences = com.example.backup.cloud.PreferencesBackupItem(
          autoCleanPeriod = "DAYS_30",
          keepFavorites = true,
          keepPlaylistItems = true,
          keepMarkedItems = true,
          onlyCleanWhenStorageLow = false
      )

      val manifest = com.example.backup.cloud.CloudBackupManifest.create(
          backupType = com.example.backup.cloud.BackupType.LIBRARY_ONLY,
          playlists = playlists,
          downloads = downloads,
          playbackProgress = progress,
          markers = markers,
          preferences = preferences
      )

      val json = manifest.toJsonString()
      assertNotNull(json)
      assertTrue(json.contains("Kotlin Flow Deep Dive"))
      assertTrue(json.contains("StateFlow vs SharedFlow"))

      val restoredManifest = com.example.backup.cloud.CloudBackupManifest.parseAndValidate(json)
      assertEquals(1, restoredManifest.version)
      assertEquals(com.example.backup.cloud.BackupType.LIBRARY_ONLY, restoredManifest.backupType)
      assertEquals(1, restoredManifest.playlists.size)
      assertEquals("My Study List", restoredManifest.playlists[0].name)
      assertEquals(listOf("media_1", "media_2"), restoredManifest.playlists[0].mediaIds)

      assertEquals(1, restoredManifest.media.size)
      assertEquals("media_1", restoredManifest.media[0].id)
      assertTrue(restoredManifest.media[0].isFavorite)
      assertTrue(restoredManifest.media[0].isKept)

      assertEquals(1, restoredManifest.playbackPositions.size)
      assertEquals(300000L, restoredManifest.playbackPositions[0].lastPositionMs)

      assertEquals(1, restoredManifest.markers.size)
      assertEquals("StateFlow vs SharedFlow - Key architectural difference", restoredManifest.markers[0].note)

      assertNotNull(restoredManifest.preferences)
      assertEquals("DAYS_30", restoredManifest.preferences?.autoCleanPeriod)
      assertTrue(restoredManifest.preferences?.keepFavorites == true)
  }

  @Test
  fun testThemePersistenceAndRestoration() {
      val context = ApplicationProvider.getApplicationContext<Context>()

      val customSettings = com.example.ui.theme.AppThemeSettings(
          themeMode = com.example.ui.theme.AppThemeMode.MIDNIGHT,
          accentPalette = com.example.ui.theme.AccentPalette.CYAN,
          customAccentColor = 0xFF00E5FF,
          gradientConfig = com.example.ui.theme.CustomGradientConfig(
              isEnabled = true,
              colorA = 0xFF00E5FF,
              colorB = 0xFF7C4DFF,
              intensity = 0.85f
          )
      )

      // Save
      com.example.ui.theme.ThemePreferencesManager.saveThemeSettings(context, customSettings)

      // Load
      val loaded = com.example.ui.theme.ThemePreferencesManager.loadThemeSettings(context)
      assertEquals(com.example.ui.theme.AppThemeMode.MIDNIGHT, loaded.themeMode)
      assertEquals(com.example.ui.theme.AccentPalette.CYAN, loaded.accentPalette)
      assertEquals(0xFF00E5FFL, loaded.customAccentColor)
      assertTrue(loaded.gradientConfig.isEnabled)
      assertEquals(0xFF00E5FFL, loaded.gradientConfig.colorA)
      assertEquals(0xFF7C4DFFL, loaded.gradientConfig.colorB)
      assertEquals(0.85f, loaded.gradientConfig.intensity, 0.01f)
  }

  @Test
  fun testPlayerGesturePersistenceAndRestoration() {
      val context = ApplicationProvider.getApplicationContext<Context>()

      var customSettings = com.example.player.gestures.PlayerGestureSettings()
      customSettings = customSettings.withAction(
          com.example.player.gestures.PlayerGesture.THREE_FINGER_TAP,
          com.example.player.gestures.PlayerGestureAction.MUTE_UNMUTE
      )
      customSettings = customSettings.withAction(
          com.example.player.gestures.PlayerGesture.TWO_FINGER_SWIPE_UP,
          com.example.player.gestures.PlayerGestureAction.SPEED_TOGGLE
      )
      customSettings = customSettings.withAction(
          com.example.player.gestures.PlayerGesture.LONG_PRESS,
          com.example.player.gestures.PlayerGestureAction.SCREENSHOT
      )
      customSettings = customSettings.withAction(
          com.example.player.gestures.PlayerGesture.LEFT_EDGE_SWIPE,
          com.example.player.gestures.PlayerGestureAction.SEEK_BACKWARD_10
      )

      // Save
      com.example.player.gestures.PlayerGesturePreferencesManager.saveSettings(context, customSettings)

      // Load and verify
      val loaded = com.example.player.gestures.PlayerGesturePreferencesManager.loadSettings(context)
      assertEquals(
          com.example.player.gestures.PlayerGestureAction.PLAY_PAUSE,
          loaded.getActionFor(com.example.player.gestures.PlayerGesture.TWO_FINGER_DOUBLE_TAP)
      )
      assertEquals(
          com.example.player.gestures.PlayerGestureAction.MUTE_UNMUTE,
          loaded.getActionFor(com.example.player.gestures.PlayerGesture.THREE_FINGER_TAP)
      )
      assertEquals(
          com.example.player.gestures.PlayerGestureAction.SPEED_TOGGLE,
          loaded.getActionFor(com.example.player.gestures.PlayerGesture.TWO_FINGER_SWIPE_UP)
      )
      assertEquals(
          com.example.player.gestures.PlayerGestureAction.SCREENSHOT,
          loaded.getActionFor(com.example.player.gestures.PlayerGesture.LONG_PRESS)
      )
      assertEquals(
          com.example.player.gestures.PlayerGestureAction.SEEK_BACKWARD_10,
          loaded.getActionFor(com.example.player.gestures.PlayerGesture.LEFT_EDGE_SWIPE)
      )
      assertEquals(
          com.example.player.gestures.PlayerGestureAction.NONE,
          loaded.getActionFor(com.example.player.gestures.PlayerGesture.RIGHT_EDGE_SWIPE)
      )
  }

  @Test
  fun testMediaConversionRequestValidation() {
      val validRequest = com.example.media.operations.MediaConversionRequest(
          inputUri = android.net.Uri.parse("file:///data/local/tmp/test.mkv"),
          outputFile = java.io.File("/data/local/tmp/test.mp4"),
          videoCodec = "libx264",
          audioCodec = "aac",
          targetWidth = 1920,
          targetHeight = 1080,
          crf = 23,
          preset = "fast"
      )
      assertTrue(validRequest.validate().isSuccess)

      val invalidCodecRequest = validRequest.copy(videoCodec = "invalid_codec_name")
      assertTrue(invalidCodecRequest.validate().isFailure)

      val invalidCrfRequest = validRequest.copy(crf = 99)
      assertTrue(invalidCrfRequest.validate().isFailure)

      val invalidDimensionsRequest = validRequest.copy(targetWidth = -100)
      assertTrue(invalidDimensionsRequest.validate().isFailure)
  }

  @Test
  fun testPlaybackFallbackEvaluationLogic() {
      val directCompat = com.example.media.playback.PlaybackCompatibilityResult(
          strategy = com.example.media.playback.PlaybackStrategy.DIRECT_HARDWARE,
          reason = "Hardware acceleration available",
          containerFormat = "mp4",
          videoCodec = "h264",
          audioCodec = "aac"
      )
      assertEquals(com.example.media.playback.PlaybackStrategy.DIRECT_HARDWARE, directCompat.strategy)
      assertFalse(directCompat.requiresRemux)
      assertFalse(directCompat.requiresTranscode)

      val remuxCompat = com.example.media.playback.PlaybackCompatibilityResult(
          strategy = com.example.media.playback.PlaybackStrategy.REMUX_REQUIRED,
          reason = "Codecs compatible; remuxing to MP4",
          containerFormat = "avi",
          videoCodec = "h264",
          audioCodec = "mp3",
          requiresRemux = true
      )
      assertEquals(com.example.media.playback.PlaybackStrategy.REMUX_REQUIRED, remuxCompat.strategy)
      assertTrue(remuxCompat.requiresRemux)
  }

  @Test
  fun testFrpPreviewEngineStateAndCache() {
      com.example.media.preview.FrpPreviewEngine.clearCache()
      val sampleUri = android.net.Uri.parse("file:///data/local/tmp/test_preview.mp4")
      com.example.media.preview.FrpPreviewEngine.setActivePlaybackSource(sampleUri, "/data/local/tmp/test_preview.mp4")

      assertEquals(sampleUri, com.example.media.preview.FrpPreviewEngine.activePlaybackUri)
      assertEquals("/data/local/tmp/test_preview.mp4", com.example.media.preview.FrpPreviewEngine.activePlaybackPath)

      com.example.media.preview.FrpPreviewEngine.clearCache()
  }

  @Test
  fun testTemporaryMediaManagerLifecycle() {
      val context = ApplicationProvider.getApplicationContext<Context>()
      val tempFile = com.example.media.storage.TemporaryMediaManager.createTempFile(context, "test_", "mp4")
      assertTrue(tempFile.name.startsWith("test_"))
      assertTrue(tempFile.name.endsWith(".mp4"))

      tempFile.writeText("sample-media-test")
      assertTrue(tempFile.exists())

      val deleted = com.example.media.storage.TemporaryMediaManager.deleteSilently(tempFile)
      assertTrue(deleted)
      assertFalse(tempFile.exists())
  }

  @Test
  fun testFFmpegDiagnosticsReportFormatting() {
      val diag = com.example.media.ffmpeg.FFmpegDiagnostics(
          isAvailable = true,
          ffmpegVersion = "7.1",
          ffmpegKitVersion = "8.1.7",
          abi = "arm64-v8a",
          buildConfiguration = "enable-gpl",
          nativeLibraryLoaded = true,
          selfTestPassed = true,
          probeSelfTestPassed = true,
          registeredPackages = listOf("ffmpeg-kit-full")
      )
      val report = diag.toFormattedReport()
      assertTrue(report.contains("=== FFmpegKit Diagnostics Report ==="))
      assertTrue(report.contains("FFmpegKit Version: 8.1.7"))
      assertTrue(report.contains("Target ABI: arm64-v8a"))
      assertTrue(report.contains("FFmpeg Execution Self-Test: PASS"))
      assertTrue(report.contains("FFprobe Self-Test: PASS"))
  }

  @Test
  fun testFFmpegKitRuntimeClassLoading() {
      // 1. Verify FFmpegKitConfig class is present on runtime classpath without running native JNI clinit
      val configClass = Class.forName("com.arthenica.ffmpegkit.FFmpegKitConfig", false, javaClass.classLoader)
      assertNotNull(configClass)
      assertEquals("com.arthenica.ffmpegkit.FFmpegKitConfig", configClass.name)

      // 2. Verify SmartException dependency is present on runtime classpath
      val smartExceptionClass = Class.forName("com.arthenica.smartexception.java.Exceptions", true, javaClass.classLoader)
      assertNotNull(smartExceptionClass)
      assertEquals("com.arthenica.smartexception.java.Exceptions", smartExceptionClass.name)

      // 3. Verify that on device/host, initializing clinit handles native linkage gracefully
      try {
          Class.forName("com.arthenica.ffmpegkit.FFmpegKitConfig", true, javaClass.classLoader)
      } catch (t: Throwable) {
          // In host JVM Robolectric environments, native Android ARM64 ELF libraries (.so) are not linked into host JVM
          assertTrue(t is Error || t is Exception || t is UnsatisfiedLinkError)
      }
  }

  @Test
  fun testRobolectricDecoderCapabilityDetection() {
      val testProbe = com.example.media.probe.MediaProbeInfo(
          pathOrUri = "file:///sample.mkv",
          videoStreams = listOf(
              com.example.media.probe.VideoStreamInfo(
                  index = 0,
                  codec = "hevc",
                  profile = "Main 10",
                  level = "5.1",
                  width = 3840,
                  height = 2160,
                  frameRate = 60f
              )
          ),
          audioStreams = listOf(
              com.example.media.probe.AudioStreamInfo(
                  index = 1,
                  codec = "eac3",
                  sampleRate = 48000,
                  channels = 6
              )
          )
      )

      val report = com.example.media.DecoderCapabilityManager.detectAndroidDecoderCapabilities(
          testProbe.videoStreams,
          testProbe.audioStreams
      )
      assertNotNull(report)
      assertEquals(1, report.videoAssessments.size)
      assertEquals(1, report.audioAssessments.size)
      println("Robolectric decoder capability report:\n${report.toFormattedReport()}")
  }

  @Test
  fun testPhase5CompleteCodecReportSuccess() {
      val context = ApplicationProvider.getApplicationContext<Context>()
      val probe = com.example.media.probe.MediaProbeInfo(
          pathOrUri = "content://media/external/video/media/101",
          format = "mov,mp4,m4a,3gp,3g2,mj2",
          durationMs = 125000L,
          sizeBytes = 45000000L,
          streamCount = 2,
          videoStreams = listOf(
              com.example.media.probe.VideoStreamInfo(
                  index = 0,
                  codec = "h264",
                  profile = "High",
                  level = "4.1",
                  width = 1920,
                  height = 1080,
                  frameRate = 30f,
                  pixelFormat = "yuv420p",
                  bitDepth = 8
              )
          ),
          audioStreams = listOf(
              com.example.media.probe.AudioStreamInfo(
                  index = 1,
                  codec = "aac",
                  sampleRate = 48000,
                  channels = 2,
                  bitrate = 192000L,
                  language = "eng"
              )
          )
      )

      val playbackReport = com.example.media.playback.PlaybackAnalysisReport(
          result = com.example.media.playback.PlaybackAnalysisResult.SUCCESS,
          player = "Media3 / ExoPlayer",
          containerFormat = "MP4",
          video = com.example.media.playback.VideoAnalysisInfo(
              codec = "h264",
              profile = "High",
              level = "4.1",
              pixelFormat = "yuv420p",
              bitDepth = 8,
              width = 1920,
              height = 1080,
              frameRate = 30f
          ),
          audio = com.example.media.playback.AudioAnalysisInfo(
              codec = "aac",
              profile = "LC",
              channels = 2,
              sampleRate = 48000,
              bitrate = 192000L
          ),
          analysis = "Video and audio streams are natively supported by Android MediaCodec hardware decoders.",
          recommendedAction = "Direct hardware playback operational. No compatibility remediation required."
      )

      val reportText = com.example.media.playback.CodecReportGenerator.generateCompleteCodecReport(
          context = context,
          report = playbackReport,
          probeInfo = probe,
          fileName = "test_video_1080p.mp4",
          fileSizeBytes = 45000000L,
          durationMs = 125000L,
          mediaUriString = "content://media/external/video/media/101",
          hardwareAccelerationMode = "Auto (Hardware Preferred)"
      )

      println("\n=== PHASE 5: SUCCESSFUL PLAYBACK CODEC REPORT ===")
      println(reportText)

      assertTrue(reportText.contains("============================================================"))
      assertTrue(reportText.contains("COMPREHENSIVE CODEC & PLAYBACK REPORT"))
      assertTrue(reportText.contains("[APPLICATION & PLAYER]"))
      assertTrue(reportText.contains("Application: Downly"))
      assertTrue(reportText.contains("FFmpegKit Distribution: dev.ffmpegkit-maintained:ffmpeg-kit-full"))
      assertTrue(reportText.contains("[DEVICE DIAGNOSTIC CONTEXT]"))
      assertTrue(reportText.contains("[FILE & STORAGE INFORMATION]"))
      assertTrue(reportText.contains("File: test_video_1080p.mp4"))
      assertTrue(reportText.contains("[CONTAINER & STREAM METADATA]"))
      assertTrue(reportText.contains("Container: MP4"))
      assertTrue(reportText.contains("Codec: H.264 (AVC)"))
      assertTrue(reportText.contains("Codec: AAC"))
      assertTrue(reportText.contains("[ANDROID DECODER CAPABILITIES]"))
      assertTrue(reportText.contains("[PLAYER COMPATIBILITY]"))
      assertTrue(reportText.contains("Direct Playback Compatibility: Supported (Direct hardware playback operational)"))
      assertTrue(reportText.contains("[RECOMMENDATION]"))

      // Test clipboard copying
      val copied = com.example.media.playback.CodecReportGenerator.copyReportToClipboard(context, reportText)
      assertTrue(copied)
      val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
      val clipData = clipboard.primaryClip
      assertNotNull(clipData)
      assertEquals("Codec Report", clipData?.description?.label)
      val copiedText = clipData?.getItemAt(0)?.text?.toString()
      assertEquals(reportText, copiedText)
  }

  @Test
  fun testPhase5CompleteCodecReportPlaybackFailureAndRedaction() {
      val context = ApplicationProvider.getApplicationContext<Context>()
      val failingProbe = com.example.media.probe.MediaProbeInfo(
          pathOrUri = "https://example.com/stream?token=SECRET_AUTH_TOKEN_12345&sig=ABCDEF",
          format = "matroska,webm",
          durationMs = 3600000L,
          sizeBytes = 850000000L,
          streamCount = 3,
          videoStreams = listOf(
              com.example.media.probe.VideoStreamInfo(
                  index = 0,
                  codec = "hevc",
                  profile = "Main 10",
                  level = "5.1",
                  width = 3840,
                  height = 2160,
                  frameRate = 60f,
                  pixelFormat = "yuv420p10le",
                  bitDepth = 10
              )
          ),
          audioStreams = listOf(
              com.example.media.probe.AudioStreamInfo(
                  index = 1,
                  codec = "eac3",
                  sampleRate = 48000,
                  channels = 6,
                  bitrate = 640000L,
                  language = "eng"
              )
          ),
          subtitleStreams = listOf(
              com.example.media.probe.SubtitleStreamInfo(
                  index = 2,
                  codec = "subrip",
                  language = "eng",
                  title = "English Full"
              )
          )
      )

      val failureReport = com.example.media.playback.PlaybackAnalysisReport(
          result = com.example.media.playback.PlaybackAnalysisResult.FAILED,
          player = "Media3 / ExoPlayer",
          failure = com.example.media.playback.PlaybackFailureDetails(
              exceptionClass = "MediaCodecAudioRendererException",
              errorCode = 4003,
              errorCodeName = "ERROR_CODE_DECODER_INIT_FAILED",
              rootCauseClass = "MediaCodec.CodecException",
              rootCauseMessage = "Error 0xfffffc0e: Failed to initialize decoder c2.android.eac3.decoder",
              rendererName = "AudioRenderer",
              isDecoderInit = true,
              isMediaCodecException = true
          ),
          containerFormat = "Matroska / WebM",
          video = com.example.media.playback.VideoAnalysisInfo(
              codec = "hevc",
              profile = "Main 10",
              level = "5.1",
              pixelFormat = "yuv420p10le",
              bitDepth = 10,
              width = 3840,
              height = 2160,
              frameRate = 60f
          ),
          audio = com.example.media.playback.AudioAnalysisInfo(
              codec = "eac3",
              profile = "Enhanced AC-3",
              channels = 6,
              sampleRate = 48000,
              bitrate = 640000L
          ),
          analysis = "Playback failed during audio decoder initialization (c2.android.eac3.decoder).",
          recommendedAction = "Audio extraction/transcoding to AAC or FFmpegAudioRenderer fallback recommended."
      )

      val sensitiveUrl = "https://example.com/video.mkv?token=SECRET_AUTH_TOKEN_12345&sig=ABCDEF&session_id=987654"
      val reportText = com.example.media.playback.CodecReportGenerator.generateCompleteCodecReport(
          context = context,
          report = failureReport,
          probeInfo = failingProbe,
          fileName = "/data/user/0/com.example/files/downloads/secret_movie.mkv",
          fileSizeBytes = 850000000L,
          durationMs = 3600000L,
          mediaUriString = sensitiveUrl,
          hardwareAccelerationMode = "Auto (Hardware Preferred)"
      )

      println("\n=== PHASE 5: PLAYBACK FAILURE & SENSITIVE DATA REDACTION CODEC REPORT ===")
      println(reportText)

      // Verification of Redaction: no tokens, query params, private app paths
      assertFalse(reportText.contains("SECRET_AUTH_TOKEN_12345"))
      assertFalse(reportText.contains("session_id=987654"))
      assertFalse(reportText.contains("/data/user/0/com.example/files/downloads/"))
      assertTrue(reportText.contains("[Local Storage]/secret_movie.mkv"))
      assertTrue(reportText.contains("secret_movie.mkv"))

      // Verification of Failure Details
      assertTrue(reportText.contains("[PLAYBACK FAILURE & ROOT-CAUSE ANALYSIS]"))
      assertTrue(reportText.contains("Playback State: FAILED"))
      assertTrue(reportText.contains("Playback Failure: MediaCodecAudioRendererException"))
      assertTrue(reportText.contains("Error Code: ERROR_CODE_DECODER_INIT_FAILED (4003)"))
      assertTrue(reportText.contains("Root Cause: Error 0xfffffc0e: Failed to initialize decoder c2.android.eac3.decoder"))
      assertTrue(reportText.contains("Direct Playback Compatibility: Incompatible"))
      assertTrue(reportText.contains("Audio extraction/transcoding to AAC or FFmpegAudioRenderer fallback recommended."))

      // Subtitle streams check
      assertTrue(reportText.contains("Subtitle Streams:"))
      assertTrue(reportText.contains("SUBRIP (eng) | Title: English Full"))
  }

  @Test
  fun testPhase6_H264_AAC_MKV_DirectPlay() = runTest {
      val probe = MediaProbeInfo(
          pathOrUri = "/dummy/video.mkv",
          format = "matroska,webm",
          durationMs = 120000L,
          overallBitrate = 2500000L,
          videoStreams = listOf(
              VideoStreamInfo(index = 0, codec = "h264", width = 1920, height = 1080, frameRate = 30f, profile = "High", level = "41", bitDepth = 8)
          ),
          audioStreams = listOf(
              AudioStreamInfo(index = 1, codec = "aac", channels = 2, sampleRate = 48000, bitrate = 192000L)
          )
      )

      val result = com.example.media.playback.PlaybackFallbackEngine.evaluatePlaybackStrategy(
          context = context,
          uri = Uri.parse("file:///dummy/video.mkv"),
          probeInfoOverride = probe
      )

      println("\n[PHASE 6 TEST: H.264 + AAC MKV]")
      println("Input: video.mkv (H.264 High@L4.1 8-bit + AAC Stereo)")
      println("Diagnosis: Container and codecs fully supported by Android MediaCodec")
      println("Action: Strategy=${result.strategy}, VideoAction=${result.videoAction}, AudioAction=${result.audioAction}")
      println("Output: Direct Hardware Playback")
      println("Playback: DIRECT_HARDWARE (ExoPlayer MediaCodec)")
      println("Quality impact: ${result.qualityImpact}")
      println("Time taken: ${result.estimatedSpeed}")

      assertEquals(com.example.media.playback.PlaybackStrategy.DIRECT_HARDWARE, result.strategy)
      assertEquals("direct", result.videoAction)
      assertEquals("direct", result.audioAction)
      assertFalse(result.requiresRemux)
      assertFalse(result.requiresTranscode)
  }

  @Test
  fun testPhase6_H264_EAC3_MKV_TargetedAudioTranscode() = runTest {
      val probe = MediaProbeInfo(
          pathOrUri = "/dummy/movie_eac3.mkv",
          format = "matroska,webm",
          durationMs = 150000L,
          overallBitrate = 4500000L,
          videoStreams = listOf(
              VideoStreamInfo(index = 0, codec = "h264", width = 1920, height = 1080, frameRate = 24f, profile = "High", level = "41", bitDepth = 8)
          ),
          audioStreams = listOf(
              AudioStreamInfo(index = 1, codec = "eac3", channels = 6, sampleRate = 48000, bitrate = 640000L)
          )
      )

      // Audio decoder fails / is unsupported without Dolby hardware license
      val playbackError = androidx.media3.common.PlaybackException(
          "Audio track init failed for eac3",
          IllegalStateException("Failed to initialize decoder c2.android.eac3.decoder"),
          androidx.media3.common.PlaybackException.ERROR_CODE_DECODER_INIT_FAILED
      )

      val result = com.example.media.playback.PlaybackFallbackEngine.evaluatePlaybackStrategy(
          context = context,
          uri = Uri.parse("file:///dummy/movie_eac3.mkv"),
          playbackError = playbackError,
          probeInfoOverride = probe
      )

      println("\n[PHASE 6 TEST: H.264 + E-AC-3 MKV]")
      println("Input: movie_eac3.mkv (H.264 High + E-AC-3 5.1 Surround)")
      println("Diagnosis: Video is hardware compatible; E-AC-3 audio codec lacks decoder")
      println("Action: Strategy=${result.strategy}, VideoAction=${result.videoAction}, AudioAction=${result.audioAction}")
      println("Output: video.mp4 (H.264 bitstream copy + AAC 192k audio)")
      println("Playback: TARGETED_AUDIO_TRANSCODE (Video copy, Audio AAC)")
      println("Quality impact: ${result.qualityImpact}")
      println("Time taken: ${result.estimatedSpeed}")

      assertEquals(com.example.media.playback.PlaybackStrategy.TARGETED_AUDIO_TRANSCODE, result.strategy)
      assertEquals("copy", result.videoAction)
      assertEquals("transcode", result.audioAction)
      assertTrue(result.requiresTranscode)
      assertFalse(result.requiresRemux)
  }

  @Test
  fun testPhase6_HEVC_8bit_MKV_DirectPlay() = runTest {
      val probe = MediaProbeInfo(
          pathOrUri = "/dummy/hevc_8bit.mkv",
          format = "matroska,webm",
          durationMs = 90000L,
          overallBitrate = 3000000L,
          videoStreams = listOf(
              VideoStreamInfo(index = 0, codec = "hevc", width = 1920, height = 1080, frameRate = 60f, profile = "Main", level = "120", bitDepth = 8)
          ),
          audioStreams = listOf(
              AudioStreamInfo(index = 1, codec = "opus", channels = 2, sampleRate = 48000, bitrate = 128000L)
          )
      )

      val result = com.example.media.playback.PlaybackFallbackEngine.evaluatePlaybackStrategy(
          context = context,
          uri = Uri.parse("file:///dummy/hevc_8bit.mkv"),
          probeInfoOverride = probe
      )

      println("\n[PHASE 6 TEST: HEVC 8-bit + Opus MKV]")
      println("Input: hevc_8bit.mkv (HEVC Main 8-bit + Opus Stereo)")
      println("Diagnosis: Hardware HEVC & Opus decoder supported")
      println("Action: Strategy=${result.strategy}, VideoAction=${result.videoAction}, AudioAction=${result.audioAction}")
      println("Output: Direct Hardware Playback")
      println("Playback: DIRECT_HARDWARE")
      println("Quality impact: ${result.qualityImpact}")
      println("Time taken: ${result.estimatedSpeed}")

      assertEquals(com.example.media.playback.PlaybackStrategy.DIRECT_HARDWARE, result.strategy)
      assertEquals("direct", result.videoAction)
      assertEquals("direct", result.audioAction)
  }

  @Test
  fun testPhase6_HEVC_Main10_MKV_TargetedVideoTranscode() = runTest {
      val probe = MediaProbeInfo(
          pathOrUri = "/dummy/hevc_10bit_4k.mkv",
          format = "matroska,webm",
          durationMs = 180000L,
          overallBitrate = 8000000L,
          videoStreams = listOf(
              VideoStreamInfo(index = 0, codec = "hevc", width = 3840, height = 2160, frameRate = 60f, profile = "High 10", level = "150", bitDepth = 10)
          ),
          audioStreams = listOf(
              AudioStreamInfo(index = 1, codec = "aac", channels = 2, sampleRate = 48000, bitrate = 256000L)
          )
      )

      val playbackError = androidx.media3.common.PlaybackException(
          "Decoder init failed for 10-bit HEVC profile",
          IllegalStateException("c2.android.hevc.decoder cannot handle 10-bit profile"),
          androidx.media3.common.PlaybackException.ERROR_CODE_DECODER_INIT_FAILED
      )

      val result = com.example.media.playback.PlaybackFallbackEngine.evaluatePlaybackStrategy(
          context = context,
          uri = Uri.parse("file:///dummy/hevc_10bit_4k.mkv"),
          playbackError = playbackError,
          probeInfoOverride = probe
      )

      println("\n[PHASE 6 TEST: HEVC Main10 10-bit + AAC MKV]")
      println("Input: hevc_10bit_4k.mkv (HEVC 10-bit High 10 + AAC)")
      println("Diagnosis: 10-bit video exceeds hardware decoder; AAC audio is supported")
      println("Action: Strategy=${result.strategy}, VideoAction=${result.videoAction}, AudioAction=${result.audioAction}")
      println("Output: fixed.mp4 (H.264 8-bit transcoded video + untouched AAC bitstream copy)")
      println("Playback: TARGETED_VIDEO_TRANSCODE")
      println("Quality impact: ${result.qualityImpact}")
      println("Time taken: ${result.estimatedSpeed}")

      assertEquals(com.example.media.playback.PlaybackStrategy.TARGETED_VIDEO_TRANSCODE, result.strategy)
      assertEquals("transcode", result.videoAction)
      assertEquals("copy", result.audioAction)
      assertTrue(result.requiresTranscode)
  }

  @Test
  fun testPhase6_VP9_MKV_DirectPlay() = runTest {
      val probe = MediaProbeInfo(
          pathOrUri = "/dummy/vp9_video.mkv",
          format = "matroska,webm",
          durationMs = 60000L,
          overallBitrate = 2000000L,
          videoStreams = listOf(
              VideoStreamInfo(index = 0, codec = "vp9", width = 1920, height = 1080, frameRate = 30f, profile = "Profile 0", level = "40", bitDepth = 8)
          ),
          audioStreams = listOf(
              AudioStreamInfo(index = 1, codec = "opus", channels = 2, sampleRate = 48000, bitrate = 128000L)
          )
      )

      val result = com.example.media.playback.PlaybackFallbackEngine.evaluatePlaybackStrategy(
          context = context,
          uri = Uri.parse("file:///dummy/vp9_video.mkv"),
          probeInfoOverride = probe
      )

      println("\n[PHASE 6 TEST: VP9 + Opus MKV]")
      println("Input: vp9_video.mkv (VP9 Profile 0 8-bit + Opus)")
      println("Diagnosis: Hardware VP9 and Opus playback fully supported")
      println("Action: Strategy=${result.strategy}, VideoAction=${result.videoAction}, AudioAction=${result.audioAction}")
      println("Output: Direct Hardware Playback")
      println("Playback: DIRECT_HARDWARE")
      println("Quality impact: ${result.qualityImpact}")
      println("Time taken: ${result.estimatedSpeed}")

      assertEquals(com.example.media.playback.PlaybackStrategy.DIRECT_HARDWARE, result.strategy)
      assertEquals("direct", result.videoAction)
      assertEquals("direct", result.audioAction)
  }

  @Test
  fun testPhase6_RealWorldFailingMKV_ContainerRemux() = runTest {
      val probe = MediaProbeInfo(
          pathOrUri = "/dummy/corrupted_header.mkv",
          format = "matroska,webm",
          durationMs = 300000L,
          overallBitrate = 4000000L,
          videoStreams = listOf(
              VideoStreamInfo(index = 0, codec = "h264", width = 1920, height = 1080, frameRate = 24f, profile = "High", level = "41", bitDepth = 8)
          ),
          audioStreams = listOf(
              AudioStreamInfo(index = 1, codec = "aac", channels = 2, sampleRate = 48000, bitrate = 192000L)
          )
      )

      // Simulates real-world MKV container parser failure (e.g. malformed EBML header / clusters)
      val containerError = androidx.media3.common.PlaybackException(
          "None of the available extractors (MatroskaExtractor) could read the stream.",
          androidx.media3.exoplayer.source.UnrecognizedInputFormatException(
              "None of the available extractors (MatroskaExtractor) could read the stream.",
              Uri.parse("file:///dummy/corrupted_header.mkv")
          ),
          androidx.media3.common.PlaybackException.ERROR_CODE_PARSING_CONTAINER_UNSUPPORTED
      )

      val result = com.example.media.playback.PlaybackFallbackEngine.evaluatePlaybackStrategy(
          context = context,
          uri = Uri.parse("file:///dummy/corrupted_header.mkv"),
          playbackError = containerError,
          probeInfoOverride = probe
      )

      println("\n[PHASE 6 TEST: Real-World Failing MKV (Container Demux Issue)]")
      println("Input: corrupted_header.mkv (H.264 + AAC in problematic Matroska container)")
      println("Diagnosis: Both codecs are hardware supported, but MatroskaExtractor threw UnrecognizedInputFormatException")
      println("Action: Strategy=${result.strategy}, VideoAction=${result.videoAction}, AudioAction=${result.audioAction}")
      println("Output: remuxed.mp4 (Standard MP4 container with 100% lossless bitstream copy)")
      println("Playback: REMUX_REQUIRED (Stream Copy to MP4)")
      println("Quality impact: ${result.qualityImpact}")
      println("Time taken: ${result.estimatedSpeed}")

      assertEquals(com.example.media.playback.PlaybackStrategy.REMUX_REQUIRED, result.strategy)
      assertEquals("copy", result.videoAction)
      assertEquals("copy", result.audioAction)
      assertTrue(result.requiresRemux)
      assertFalse(result.requiresTranscode)
  }

  @Test
  fun testPhase6_AudioExtractionRegression() {
      val m4aFormat = com.example.media.operations.AudioOutputFormat.M4A
      val mp3Format = com.example.media.operations.AudioOutputFormat.MP3
      val flacFormat = com.example.media.operations.AudioOutputFormat.FLAC
      val opusFormat = com.example.media.operations.AudioOutputFormat.OPUS

      assertEquals("m4a", m4aFormat.extension)
      assertEquals("aac", m4aFormat.defaultCodec)
      assertEquals("mp3", mp3Format.extension)
      assertEquals("libmp3lame", mp3Format.defaultCodec)
      assertEquals("flac", flacFormat.extension)
      assertEquals("flac", flacFormat.defaultCodec)
      assertEquals("opus", opusFormat.extension)
      assertEquals("libopus", opusFormat.defaultCodec)

      println("\n[PHASE 6 TEST: Audio Extraction Regression]")
      println("Audio extraction formats and default codecs verified: 0 regressions.")
  }

  @Test
  fun testPhase7_BitDepthDetectionAndVideoStreamInfo() {
      val vStream = VideoStreamInfo(
          index = 0,
          codec = "hevc",
          profile = "Main 10",
          level = "150",
          profileId = 2,
          levelId = 150,
          bitDepth = 10,
          chromaSubsampling = "4:2:0",
          hdrFormat = "BT.2020 (Wide Color Gamut)",
          width = 1920,
          height = 1080,
          frameRate = 23.98f,
          pixelFormat = "yuv420p10le"
      )

      assertEquals(10, vStream.bitDepth)
      assertEquals("4:2:0", vStream.chromaSubsampling)
      assertEquals("yuv420p10le", vStream.pixelFormat)
      assertEquals("Main 10", vStream.profile)
      assertEquals("150", vStream.level)

      val probe = MediaProbeInfo(
          pathOrUri = "/dummy/solo_leveling_s01e01_1080p_10bit.mkv",
          format = "matroska,webm",
          durationMs = 1420000L,
          overallBitrate = 4500000L,
          videoStreams = listOf(vStream),
          audioStreams = listOf(
              AudioStreamInfo(index = 1, codec = "eac3", channels = 6, sampleRate = 48000, bitrate = 640000L)
          )
      )

      val formattedProbe = probe.toFormattedReport()
      assertTrue(formattedProbe.contains("Bit Depth: 10-bit"))
      assertTrue(formattedProbe.contains("Pixel Format: yuv420p10le"))
      assertTrue(formattedProbe.contains("Chroma Subsampling: 4:2:0"))
  }

  @Test
  fun testPhase7_ProfileAndLevelTranslations() {
      val mimeHevc = "video/hevc"
      val mainProfile = com.example.media.DecoderCapabilityManager.profileConstantToString(mimeHevc, android.media.MediaCodecInfo.CodecProfileLevel.HEVCProfileMain)
      val main10Profile = com.example.media.DecoderCapabilityManager.profileConstantToString(mimeHevc, android.media.MediaCodecInfo.CodecProfileLevel.HEVCProfileMain10)
      val level5 = com.example.media.DecoderCapabilityManager.levelConstantToString(mimeHevc, android.media.MediaCodecInfo.CodecProfileLevel.HEVCMainTierLevel5)

      assertEquals("HEVC Main (8-bit)", mainProfile)
      assertEquals("HEVC Main 10 (10-bit)", main10Profile)
      assertEquals("Main Tier Level 5.0", level5)

      val mimeAvc = "video/avc"
      val highProfile = com.example.media.DecoderCapabilityManager.profileConstantToString(mimeAvc, android.media.MediaCodecInfo.CodecProfileLevel.AVCProfileHigh)
      val high10Profile = com.example.media.DecoderCapabilityManager.profileConstantToString(mimeAvc, android.media.MediaCodecInfo.CodecProfileLevel.AVCProfileHigh10)
      val level41 = com.example.media.DecoderCapabilityManager.levelConstantToString(mimeAvc, android.media.MediaCodecInfo.CodecProfileLevel.AVCLevel41)

      assertEquals("High (8-bit)", highProfile)
      assertEquals("High 10 (10-bit)", high10Profile)
      assertEquals("Level 4.1", level41)
  }

  @Test
  fun testPhase7_ComprehensiveCodecReportAccuracy() {
      val probe = MediaProbeInfo(
          pathOrUri = "/dummy/solo_leveling_10bit.mkv",
          format = "matroska,webm",
          durationMs = 1420000L,
          overallBitrate = 4500000L,
          videoStreams = listOf(
              VideoStreamInfo(
                  index = 0,
                  codec = "hevc",
                  profile = "Main 10",
                  level = "150",
                  bitDepth = 10,
                  chromaSubsampling = "4:2:0",
                  width = 1920,
                  height = 1080,
                  frameRate = 23.98f,
                  pixelFormat = "yuv420p10le"
              )
          ),
          audioStreams = listOf(
              AudioStreamInfo(index = 1, codec = "eac3", channels = 6, sampleRate = 48000, bitrate = 640000L)
          )
      )

      val report = com.example.media.playback.PlaybackAnalysisReport(
          result = com.example.media.playback.PlaybackAnalysisResult.FAILED,
          player = "Media3 / ExoPlayer",
          failure = com.example.media.playback.PlaybackFailureDetails(
              exceptionClass = "DecoderInitializationException",
              errorCode = androidx.media3.common.PlaybackException.ERROR_CODE_DECODER_INIT_FAILED,
              errorCodeName = "ERROR_CODE_DECODER_INIT_FAILED",
              rootCauseClass = "MediaCodecRenderer.DecoderInitializationException",
              rootCauseMessage = "Decoder init failed: OMX.sprd.hevc.decoder, Format(1, null, null, video/hevc, null, -1, null, [1920, 1080, 23.976], [-1, -1])",
              diagnosticInfo = "NO_EXCEEDS_CAPABILITIES"
          ),
          containerFormat = "matroska,webm",
          video = com.example.media.playback.VideoAnalysisInfo(
              codec = "hevc",
              profile = "Main 10",
              level = "150",
              pixelFormat = "yuv420p10le",
              bitDepth = 10,
              width = 1920,
              height = 1080,
              frameRate = 23.98f
          ),
          audio = com.example.media.playback.AudioAnalysisInfo(
              codec = "eac3",
              channels = 6,
              sampleRate = 48000
          ),
          deviceDecoder = com.example.media.playback.DeviceDecoderAnalysis(
              decoderName = "OMX.sprd.hevc.decoder",
              decoderType = "Hardware",
              supportedProfiles = listOf("HEVC Main (8-bit)"),
              maxResolution = "1920x1080",
              isSupported = false,
              profileSupported = false,
              bitDepthSupported = false,
              resolutionSupported = true,
              levelSupported = true,
              detailedDiagnosis = "Stream requires 10-bit HEVC (Main 10), but decoder 'OMX.sprd.hevc.decoder' only exposes 8-bit profile (HEVC Main)."
          ),
          analysis = "The requested video profile is not supported by\nthe available decoder.",
          recommendedAction = "Remux will NOT fix codec incompatibility.\nTranscoding may be required."
      )

      val fullReport = com.example.media.playback.CodecReportGenerator.generateCompleteCodecReport(
          report = report,
          probeInfo = probe,
          fileName = "Solo Leveling S01E01 1080p BluRay 10bit HEVC.mkv"
      )

      println("\n[PHASE 7 TEST: Comprehensive Codec Report Output]")
      println(fullReport)

      assertTrue(fullReport.contains("Bit Depth: 10-bit"))
      assertTrue(fullReport.contains("Pixel Format: yuv420p10le"))
      assertTrue(fullReport.contains("Profile: Main 10"))
      assertTrue(fullReport.contains("Bit Depth Support: FAIL"))
      assertTrue(fullReport.contains("OMX.sprd.hevc.decoder (Hardware)"))
      assertTrue(fullReport.contains("HEVC Main (8-bit)"))
      assertTrue(fullReport.contains("Diagnostic Note: Stream requires 10-bit HEVC (Main 10)"))
      assertFalse(fullReport.contains("Bit Depth: 8-bit"))
  }
}

