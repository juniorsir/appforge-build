package com.kavach.presentation.dashboard

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.kavach.BaseApplication
import com.kavach.accessibility.AccessibilityRepository
import com.kavach.accessibility.models.AccessibilityServiceStatus
import com.kavach.audio.AudioCaptureEngine
import com.kavach.domain.model.AudioCaptureState
import com.kavach.domain.model.ChatMessage
import com.kavach.domain.model.CompanionConfig
import com.kavach.domain.model.SessionState
import com.kavach.domain.repository.WebSocketRepository
import com.kavach.domain.usecase.GetCompanionConfigUseCase
import com.kavach.domain.usecase.GetSessionHistoryUseCase
import com.kavach.domain.usecase.GetSessionStateUseCase
import com.kavach.domain.usecase.SaveCompanionConfigUseCase
import com.kavach.domain.usecase.SendMessageUseCase
import com.kavach.domain.usecase.ToggleStreamConnectionUseCase
import com.kavach.hardware.DeviceBridgeManager
import com.kavach.security.AuraSecurityShield
import com.kavach.services.RealtimeConnectionService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject

/**
 * Unified UI State for the Dashboard screen.
 */
data class DashboardUiState(
    val config: CompanionConfig = CompanionConfig(),
    val sessionState: SessionState = SessionState(sessionId = ""),
    val history: List<ChatMessage> = emptyList(),
    val isMicMuted: Boolean = false,
    val isCameraEnabled: Boolean = false,
    val textInput: String = ""
)

/**
 * MVVM ViewModel for the Clean Utilitarian Command Console.
 * Manages WebSocket/HTTP bridge state, system hardware toggles, shell command execution,
 * accessibility UI automation, and live telemetry logs.
 */
class DashboardViewModel(
    private val getCompanionConfigUseCase: GetCompanionConfigUseCase,
    private val saveCompanionConfigUseCase: SaveCompanionConfigUseCase,
    private val getSessionHistoryUseCase: GetSessionHistoryUseCase,
    private val sendMessageUseCase: SendMessageUseCase,
    private val getSessionStateUseCase: GetSessionStateUseCase,
    private val toggleStreamConnectionUseCase: ToggleStreamConnectionUseCase,
    private val audioCaptureEngine: AudioCaptureEngine,
    val permissionEventBus: com.kavach.capabilities.permissions.PermissionEventBus,
    private val webSocketRepository: WebSocketRepository,
    private val deviceBridgeManager: DeviceBridgeManager,
    private val accessibilityRepository: AccessibilityRepository,
    val securityShield: AuraSecurityShield,
    private val appGuardManager: com.kavach.hardware.AppGuardManager? = com.kavach.hardware.AppGuardManager.activeInstance,
    private val deviceOpsExpansionManager: com.kavach.hardware.DeviceOpsExpansionManager? = com.kavach.hardware.DeviceOpsExpansionManager.activeInstance,
    private val appVisibilityManager: com.kavach.util.AppVisibilityManager? = null,
    private val aeroShareManager: com.kavach.aeroshare.AeroShareManager? = null,
    private val telemetryVaultManager: com.kavach.telemetry.OfflineTelemetryVaultManager? = com.kavach.telemetry.OfflineTelemetryVaultManager.activeInstance
) : ViewModel() {

    val permissionAlerts = permissionEventBus.permissionAlerts
    val isAppHidden: StateFlow<Boolean> = appVisibilityManager?.isAppHidden ?: MutableStateFlow(false).asStateFlow()
    val isSyntheticIconForced: StateFlow<Boolean> =
        appVisibilityManager?.isSyntheticIconForced ?: MutableStateFlow(false).asStateFlow()

    val pairedDevices: StateFlow<List<com.kavach.security.PairedClient>> = securityShield.pairedDevicesFlow
    val pendingPairRequests: StateFlow<List<com.kavach.security.PendingPairRequest>> = securityShield.pendingPairRequestsFlow
    val authMode: StateFlow<String> = securityShield.authModeFlow
    val isPanicLockdown: StateFlow<Boolean> = securityShield.isPanicLockdownFlow
    val discoveredPeers: StateFlow<List<com.kavach.aeroshare.models.AeroDevice>> =
        aeroShareManager?.discoveredDevices ?: MutableStateFlow(emptyList<com.kavach.aeroshare.models.AeroDevice>()).asStateFlow()
    private val _pairingCode = MutableStateFlow(securityShield.getActivePairingCode().first)
    val pairingCode: StateFlow<String> = _pairingCode.asStateFlow()
    val localIpAddress: String
        get() = aeroShareManager?.getLocalIpAddress() ?: "127.0.0.1"

    private val _textInput = MutableStateFlow("")
    val audioState: StateFlow<AudioCaptureState> = audioCaptureEngine.state
    val realtimeAudioStatus: StateFlow<com.kavach.hardware.RealtimeAudioStatus> = deviceBridgeManager.realtimeAudioState

    // Live WebSocket & Bridge Telemetry Flows
    val wsConnectionState: StateFlow<SessionState.ConnectionState> = webSocketRepository.connectionState
    val activeUrl: StateFlow<String> = webSocketRepository.activeUrlFlow
    val connectionLogs: StateFlow<List<String>> = webSocketRepository.connectionLogs
    val lastFailureReason: StateFlow<String?> = webSocketRepository.lastFailureReason
    val latencyMs: StateFlow<Long> = webSocketRepository.latencyMs
    val vaultUiSummary: StateFlow<com.kavach.telemetry.VaultUiSummary> =
        telemetryVaultManager?.vaultUiSummaryFlow?.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000L),
            initialValue = com.kavach.telemetry.VaultUiSummary()
        ) ?: MutableStateFlow(com.kavach.telemetry.VaultUiSummary()).asStateFlow()

    // Live System Hardware & Clipboard Flows
    val isTorchOn: StateFlow<Boolean> = deviceBridgeManager.isTorchOn
    val isDndActive: StateFlow<Boolean> = deviceBridgeManager.isDndActive
    val isAutoRotateOn: StateFlow<Boolean> = deviceBridgeManager.isAutoRotateOn
    val ringerMode: StateFlow<String> = deviceBridgeManager.ringerMode
    val brightnessLevel: StateFlow<Int> = deviceBridgeManager.brightnessLevel
    val isLocationEnabled: StateFlow<Boolean> = deviceBridgeManager.isLocationEnabled
    val locationSnapshot = deviceBridgeManager.locationSnapshot
    val isLiveLocationTracking = deviceBridgeManager.isLiveLocationTracking
    val clipboardPreview: StateFlow<String> = deviceBridgeManager.clipboardPreview
    val accessibilityStatus: StateFlow<AccessibilityServiceStatus> = accessibilityRepository.serviceStatus

    // Expanded Controls Flows
    val volumeStreams = deviceBridgeManager.volumeStreams
    val systemTelemetry = deviceBridgeManager.systemTelemetry
    val isRecordingAudio: StateFlow<Boolean> = deviceBridgeManager.isRecordingAudio
    val isSpeakingTts: StateFlow<Boolean> = deviceBridgeManager.isSpeakingTts
    val activeNotifications = com.kavach.services.AeroNotificationListenerService.notificationsFlow
    val isNotificationListenerConnected = com.kavach.services.AeroNotificationListenerService.isConnected

    // App Guard & Package Monitoring Flows
    val blockedPackages: StateFlow<Set<String>> =
        appGuardManager?.blockedPackages ?: MutableStateFlow(emptySet())
    val alertOnInstall: StateFlow<Boolean> =
        appGuardManager?.alertOnInstall ?: MutableStateFlow(true)
    val alertOnUninstall: StateFlow<Boolean> =
        appGuardManager?.alertOnUninstall ?: MutableStateFlow(true)
    val autoBlockNewInstalls: StateFlow<Boolean> =
        appGuardManager?.autoBlockNewInstalls ?: MutableStateFlow(false)
    val appGuardEvents: StateFlow<List<com.kavach.hardware.AppLifecycleEvent>> =
        appGuardManager?.recentEvents ?: MutableStateFlow(emptyList())

    // Device Ops Expansion (Screen-Time Quotas, Unlock Monitor, History/Keyword Watch, Automation Rules)
    val usageQuotasFlow: StateFlow<List<com.kavach.hardware.AppUsageQuotaItem>> =
        deviceOpsExpansionManager?.usageQuotasFlow ?: MutableStateFlow(emptyList())
    val unlockEventsFlow: StateFlow<List<com.kavach.hardware.UnlockSecurityEvent>> =
        deviceOpsExpansionManager?.unlockEventsFlow ?: MutableStateFlow(emptyList())
    val unlockMonitorEnabled: StateFlow<Boolean> =
        deviceOpsExpansionManager?.unlockMonitorEnabled ?: MutableStateFlow(true)
    val capturePhotoOnUnlock: StateFlow<Boolean> =
        deviceOpsExpansionManager?.capturePhotoOnUnlock ?: MutableStateFlow(false)
    val watchedKeywordsFlow: StateFlow<Set<String>> =
        deviceOpsExpansionManager?.watchedKeywordsFlow ?: MutableStateFlow(emptySet())
    val automationRulesFlow: StateFlow<List<com.kavach.hardware.AutomationRuleItem>> =
        deviceOpsExpansionManager?.automationRulesFlow ?: MutableStateFlow(emptyList())

    private var lastAppSearchQuery: String = ""
    private var includeSystemAppsInSearch: Boolean = true

    private val _installedApps = MutableStateFlow<List<com.kavach.hardware.AppItemUi>>(emptyList())
    val installedApps: StateFlow<List<com.kavach.hardware.AppItemUi>> = _installedApps.asStateFlow()

    init {
        appGuardManager?.onAppsChangedCallback = {
            loadInstalledApps(lastAppSearchQuery, includeSystemAppsInSearch)
        }
    }

    override fun onCleared() {
        appGuardManager?.onAppsChangedCallback = null
        _installedApps.value = emptyList()
        _contactsList.value = emptyList()
        super.onCleared()
    }

    private val _contactsList = MutableStateFlow<List<com.kavach.hardware.ContactItemUi>>(emptyList())
    val contactsList: StateFlow<List<com.kavach.hardware.ContactItemUi>> = _contactsList.asStateFlow()

    private val _lastCommandOutput = MutableStateFlow<String?>(null)
    val lastCommandOutput: StateFlow<String?> = _lastCommandOutput.asStateFlow()

    val uiState: StateFlow<DashboardUiState> = combine(
        getCompanionConfigUseCase(),
        getSessionStateUseCase(),
        getSessionHistoryUseCase(),
        _textInput
    ) { config, sessionState, history, textInput ->
        DashboardUiState(
            config = config,
            sessionState = sessionState,
            history = history,
            isMicMuted = config.isMicMuted,
            isCameraEnabled = config.isCameraEnabled,
            textInput = textInput
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = DashboardUiState()
    )

    fun refreshStates() {
        deviceBridgeManager.refreshSystemStates()
    }

    fun onTextInputChange(text: String) {
        _textInput.value = text
    }

    fun connectToServer(context: Context, url: String) {
        val cleanUrl = url.trim().ifEmpty { RealtimeConnectionService.DEFAULT_SERVER_URL }
        RealtimeConnectionService.reconnect(context, cleanUrl)
    }

    fun disconnectServer(context: Context) {
        RealtimeConnectionService.disconnect(context)
    }

    fun toggleTorch() {
        viewModelScope.launch(Dispatchers.IO) {
            val res = deviceBridgeManager.handleSystemToggle(JSONObject().put("target", "torch"))
            val stateStr = if (res.optBoolean("enabled")) "ON" else "OFF"
            webSocketRepository.addLog("SYSTEM: Torch toggled -> $stateStr")
        }
    }

    fun toggleDnd() {
        viewModelScope.launch(Dispatchers.IO) {
            val res = deviceBridgeManager.handleSystemToggle(JSONObject().put("target", "dnd"))
            if (res.optBoolean("requiresPermission")) {
                webSocketRepository.addLog("SYSTEM: DND policy permission requested on device")
            } else {
                val stateStr = if (res.optBoolean("enabled")) "ACTIVE" else "NORMAL"
                webSocketRepository.addLog("SYSTEM: Do Not Disturb -> $stateStr")
            }
        }
    }

    fun toggleAutoRotate() {
        viewModelScope.launch(Dispatchers.IO) {
            val res = deviceBridgeManager.handleSystemToggle(JSONObject().put("target", "rotate"))
            if (res.optBoolean("requiresPermission")) {
                webSocketRepository.addLog("SYSTEM: Write Settings permission requested for Auto-Rotate")
            } else {
                val stateStr = if (res.optBoolean("enabled")) "ON" else "LOCKED"
                webSocketRepository.addLog("SYSTEM: Auto-Rotate -> $stateStr")
            }
        }
    }

    fun cycleRingerAndVibrate() {
        viewModelScope.launch(Dispatchers.IO) {
            val res = deviceBridgeManager.handleSystemToggle(
                JSONObject().put("target", "ringer_cycle").put("action", "cycle")
            )
            webSocketRepository.addLog("SYSTEM: Ringer & Haptics -> ${res.optString("ringerMode", "VIBRATE")}")
        }
    }

    fun captureScreenshot() {
        viewModelScope.launch(Dispatchers.IO) {
            val res = deviceBridgeManager.handleSystemToggle(JSONObject().put("target", "screenshot"))
            if (res.optBoolean("success")) {
                val path = res.optString("path")
                _lastCommandOutput.value = "Screenshot saved to $path"
                webSocketRepository.addLog("SCREENSHOT: Saved to $path")
            } else {
                val err = res.optString("error", "Enable Accessibility Service")
                _lastCommandOutput.value = err
                webSocketRepository.addLog("SCREENSHOT ERR: $err")
            }
        }
    }

    fun openHotspotPanel() {
        viewModelScope.launch(Dispatchers.IO) {
            deviceBridgeManager.handleSystemToggle(JSONObject().put("target", "hotspot"))
            webSocketRepository.addLog("SYSTEM: Opened Hotspot & Tethering panel")
        }
    }

    fun openLocationSettings() {
        viewModelScope.launch(Dispatchers.IO) {
            val res = deviceBridgeManager.handleSystemToggle(JSONObject().put("target", "location"))
            webSocketRepository.addLog("SYSTEM: Opened Location settings (GPS=${res.optBoolean("locationEnabled")})")
        }
    }

    fun refreshLocationDetails() {
        viewModelScope.launch(Dispatchers.IO) {
            val res = deviceBridgeManager.getCurrentLocationDetails()
            if (res.optBoolean("success")) {
                val lat = res.optDouble("latitude", 0.0)
                val lon = res.optDouble("longitude", 0.0)
                val acc = res.optDouble("accuracy", 0.0)
                val prov = res.optString("provider", "GPS")
                val mapsUrl = res.optString("mapsUrl", "")
                val summary = String.format(java.util.Locale.US, "GPS [%s]: %.6f, %.6f (±%.1fm) %s", prov, lat, lon, acc, mapsUrl)
                _lastCommandOutput.value = summary
                webSocketRepository.addLog("LOCATION: $summary")
            } else {
                val err = res.optString("error", "Location unavailable")
                _lastCommandOutput.value = err
                webSocketRepository.addLog("LOCATION ERR: $err")
            }
        }
    }

    fun startLiveLocationTracking(intervalMs: Long = 1000L) {
        viewModelScope.launch(Dispatchers.IO) {
            val res = deviceBridgeManager.startLiveLocationTracking(intervalMs)
            webSocketRepository.addLog("LOCATION: Started Realtime GPS Tracking (${intervalMs}ms) -> ok=${res.optBoolean("success")}")
        }
    }

    fun stopLiveLocationTracking() {
        viewModelScope.launch(Dispatchers.IO) {
            deviceBridgeManager.stopLiveLocationTracking()
            webSocketRepository.addLog("LOCATION: Stopped Realtime GPS Tracking")
        }
    }

    fun toggleLiveLocationTracking() {
        viewModelScope.launch(Dispatchers.IO) {
            val res = deviceBridgeManager.toggleLiveLocationTracking()
            val isLive = res.optBoolean("isLiveTracking")
            webSocketRepository.addLog("LOCATION: Live Tracking -> ${if (isLive) "ACTIVE (Realtime 1s)" else "PAUSED"}")
        }
    }

    fun lockDeviceScreen() {
        viewModelScope.launch(Dispatchers.IO) {
            val res = deviceBridgeManager.handleSystemToggle(JSONObject().put("target", "lock"))
            if (res.optBoolean("success")) {
                webSocketRepository.addLog("SYSTEM: Screen locked")
            } else {
                webSocketRepository.addLog("SYSTEM: Lock screen requires Accessibility Service")
            }
        }
    }

    fun triggerGlobalUiAction(globalKey: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val res = if (globalKey in listOf("NOTIFICATIONS", "QUICK_SETTINGS")) {
                deviceBridgeManager.handleSystemToggle(JSONObject().put("target", globalKey.lowercase()))
            } else {
                deviceBridgeManager.handleUiAction(JSONObject().put("action", globalKey))
            }
            webSocketRepository.addLog("UI_GLOBAL: $globalKey -> ok=${res.optBoolean("success")}")
        }
    }

    fun setBrightnessLevel(level: Int) {
        viewModelScope.launch(Dispatchers.IO) {
            val res = deviceBridgeManager.handleSystemToggle(
                JSONObject().put("target", "brightness").put("level", level.coerceIn(10, 255))
            )
            webSocketRepository.addLog("SYSTEM: Brightness -> ${res.optInt("brightness")}/255")
        }
    }

    fun openWifiPanel() {
        viewModelScope.launch(Dispatchers.IO) {
            deviceBridgeManager.handleSystemToggle(JSONObject().put("target", "wifi"))
            webSocketRepository.addLog("SYSTEM: Opened Wi-Fi settings panel")
        }
    }

    fun openBluetoothPanel() {
        viewModelScope.launch(Dispatchers.IO) {
            deviceBridgeManager.handleSystemToggle(JSONObject().put("target", "bluetooth"))
            webSocketRepository.addLog("SYSTEM: Opened Bluetooth settings panel")
        }
    }

    fun adjustVolume(action: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val res = deviceBridgeManager.handleSystemToggle(
                JSONObject().put("target", "volume").put("action", action)
            )
            webSocketRepository.addLog("SYSTEM: Volume [$action] -> ${res.optInt("mediaVolume")}/${res.optInt("mediaMax")}")
        }
    }

    fun triggerMediaControl(command: String) {
        viewModelScope.launch(Dispatchers.IO) {
            deviceBridgeManager.handleSystemToggle(
                JSONObject().put("target", "media").put("command", command)
            )
            webSocketRepository.addLog("SYSTEM: Media control [$command] dispatched")
        }
    }

    fun refreshClipboard() {
        viewModelScope.launch(Dispatchers.IO) {
            val text = deviceBridgeManager.getClipboardText()
            webSocketRepository.addLog("CLIPBOARD: Synced (${text.length} chars)")
        }
    }

    fun updateClipboard(text: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val ok = deviceBridgeManager.setClipboardText(text)
            webSocketRepository.addLog("CLIPBOARD: Set (${text.length} chars) -> ok=$ok")
        }
    }

    fun inspectUiHierarchy() {
        viewModelScope.launch(Dispatchers.IO) {
            val nodes = accessibilityRepository.getFullNodeTree()
            if (nodes.isEmpty()) {
                webSocketRepository.addLog("UI_TREE: No nodes returned (verify Accessibility Service is enabled)")
                _lastCommandOutput.value = "Accessibility Service is not active. Tap 'Permissions' to enable."
            } else {
                var totalNodes = 0
                var clickableCount = 0
                fun countRecursive(n: com.kavach.accessibility.models.AccessibilityNodeModel) {
                    totalNodes++
                    if (n.isClickable) clickableCount++
                    n.children.forEach { countRecursive(it) }
                }
                nodes.forEach { countRecursive(it) }
                val summary = "UI Tree Snapshot: $totalNodes nodes ($clickableCount clickable)"
                webSocketRepository.addLog("UI_TREE: $summary")
                _lastCommandOutput.value = summary
            }
        }
    }

    fun executeConsoleCommand(rawInput: String) {
        val cmd = rawInput.trim()
        if (cmd.isEmpty()) return
        viewModelScope.launch(Dispatchers.IO) {
            webSocketRepository.addLog("SHELL $ $cmd")
            val res = deviceBridgeManager.executeShellCommand(cmd, timeoutMs = 15000L)
            val exitCode = res.optInt("exit_code", -1)
            val dur = res.optLong("duration_ms", 0L)
            val stdout = res.optString("stdout", "").trim()
            val stderr = res.optString("stderr", "").trim()
            val combined = buildString {
                if (stdout.isNotEmpty()) append(stdout)
                if (stderr.isNotEmpty()) {
                    if (isNotEmpty()) append("\n")
                    append("[stderr] ").append(stderr)
                }
                if (isEmpty()) append("(exit $exitCode in ${dur}ms)")
            }
            _lastCommandOutput.value = "$ $cmd  [exit=$exitCode, ${dur}ms]\n$combined"
            val logPreview = combined.replace("\n", " | ").take(140)
            webSocketRepository.addLog("SHELL [exit=$exitCode, ${dur}ms]: $logPreview")
        }
    }

    fun clearCommandOutput() {
        _lastCommandOutput.value = null
    }

    fun clearLogs() {
        webSocketRepository.clearLogs()
        _lastCommandOutput.value = null
    }

    fun startAudioCapture(context: Context) {
        RealtimeConnectionService.start(context)
    }

    fun stopAudioCapture(context: Context) {
        RealtimeConnectionService.stop(context)
    }

    fun toggleAudioPause(context: Context) {
        val current = audioState.value
        if (current.isRecording) {
            if (current.isPaused) {
                RealtimeConnectionService.resume(context)
            } else {
                RealtimeConnectionService.pause(context)
            }
        }
    }

    fun restartAudioCapture(context: Context) {
        viewModelScope.launch {
            RealtimeConnectionService.stop(context)
            kotlinx.coroutines.delay(400)
            RealtimeConnectionService.start(context)
        }
    }

    fun toggleConnection() {
        viewModelScope.launch {
            val isConnected = uiState.value.sessionState.connectionState == SessionState.ConnectionState.CONNECTED
            toggleStreamConnectionUseCase(!isConnected)
        }
    }

    fun toggleMicrophone() {
        viewModelScope.launch {
            val currentConfig = uiState.value.config
            saveCompanionConfigUseCase(currentConfig.copy(isMicMuted = !currentConfig.isMicMuted))
        }
    }

    fun toggleCamera() {
        viewModelScope.launch {
            val currentConfig = uiState.value.config
            saveCompanionConfigUseCase(currentConfig.copy(isCameraEnabled = !currentConfig.isCameraEnabled))
        }
    }

    fun sendMessage() {
        val text = _textInput.value.trim()
        if (text.isEmpty()) return

        viewModelScope.launch {
            _textInput.value = ""
            sendMessageUseCase(text)
        }
    }

    fun exportServerScripts() {
        viewModelScope.launch(Dispatchers.IO) {
            val res = deviceBridgeManager.exportServerScriptsToStorage()
            val dir = res.optString("directory", "/sdcard/Download/AeroShare")
            val count = res.optInt("count", 0)
            _lastCommandOutput.value = "Exported $count server files to $dir"
            webSocketRepository.addLog("SYSTEM: Exported $count server files to $dir")
        }
    }

    // -------------------------------------------------------------------------
    // Expanded Controls Actions (Audio/TTS, Gesture Pad, Apps/System, Media, Comms)
    // -------------------------------------------------------------------------

    fun speakText(text: String, rate: Float = 1.0f, pitch: Float = 1.0f) {
        if (text.isBlank()) return
        viewModelScope.launch(Dispatchers.IO) {
            deviceBridgeManager.speakText(text, rate, pitch)
            webSocketRepository.addLog("AUDIO_TTS: Speaking '${text.take(40)}'")
        }
    }

    fun stopTts() {
        viewModelScope.launch(Dispatchers.IO) {
            deviceBridgeManager.stopTts()
            webSocketRepository.addLog("AUDIO_TTS: Stopped")
        }
    }

    fun setStreamVolumePercent(streamType: String, percent: Int) {
        viewModelScope.launch(Dispatchers.IO) {
            val res = deviceBridgeManager.setStreamVolumePercent(streamType, percent)
            webSocketRepository.addLog("AUDIO_VOL: $streamType -> ${res.optInt("percent")}%")
        }
    }

    fun recordAudioClip(durationSec: Int = 5) {
        viewModelScope.launch(Dispatchers.IO) {
            webSocketRepository.addLog("AUDIO_MIC: Recording ${durationSec}s audio clip...")
            val res = deviceBridgeManager.recordAudioClip(durationSec)
            if (res.optBoolean("success")) {
                val path = res.optString("path")
                _lastCommandOutput.value = "Saved ${durationSec}s mic clip: $path"
                webSocketRepository.addLog("AUDIO_MIC: Saved to $path")
            } else {
                val err = res.optString("error", "Mic recording failed")
                _lastCommandOutput.value = err
                webSocketRepository.addLog("AUDIO_MIC ERR: $err")
            }
        }
    }

    fun performCoordinateTap(x: Float, y: Float, isLongPress: Boolean = false) {
        viewModelScope.launch(Dispatchers.IO) {
            val res = deviceBridgeManager.performCoordinateTap(x, y, isLongPress)
            val label = if (isLongPress) "LONG_PRESS" else "TAP"
            webSocketRepository.addLog("UI_PAD: $label (${x.toInt()}, ${y.toInt()}) -> ok=${res.optBoolean("success")}")
        }
    }

    fun performDirectionalSwipe(direction: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val res = deviceBridgeManager.performDirectionalSwipe(direction)
            webSocketRepository.addLog("UI_PAD: SWIPE_$direction -> ok=${res.optBoolean("success")}")
        }
    }

    fun performScroll(direction: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val res = deviceBridgeManager.handleUiAction(
                JSONObject().put("action", "SCROLL").put("direction", direction)
            )
            webSocketRepository.addLog("UI_PAD: SCROLL_$direction -> ok=${res.optBoolean("success")}")
        }
    }

    fun injectInputText(text: String) {
        if (text.isBlank()) return
        viewModelScope.launch(Dispatchers.IO) {
            val res = deviceBridgeManager.injectInputText(text)
            webSocketRepository.addLog("UI_INPUT: Injected '${text.take(30)}' -> ok=${res.optBoolean("success")}")
        }
    }

    fun sendHardwareKey(keyName: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val res = deviceBridgeManager.sendHardwareKey(keyName)
            webSocketRepository.addLog("UI_KEY: $keyName -> ok=${res.optBoolean("success")}")
        }
    }

    fun loadInstalledApps(query: String = lastAppSearchQuery, includeSystem: Boolean = includeSystemAppsInSearch) {
        lastAppSearchQuery = query
        includeSystemAppsInSearch = includeSystem
        viewModelScope.launch(Dispatchers.IO) {
            _installedApps.value = deviceBridgeManager.getInstalledApps(query, includeSystem = includeSystem)
        }
    }

    fun launchApp(packageName: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val res = deviceBridgeManager.launchApp(packageName)
            if (!res.optBoolean("success")) {
                val err = res.optString("error", "Launch blocked or failed")
                _lastCommandOutput.value = err
                webSocketRepository.addLog("APP_LAUNCH ERR: $packageName -> $err")
            } else {
                webSocketRepository.addLog("APP_LAUNCH: $packageName -> ok=true")
            }
        }
    }

    fun toggleBlockApp(packageName: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val mgr = appGuardManager ?: com.kavach.hardware.AppGuardManager.activeInstance ?: return@launch
            val isCurrentlyBlocked = mgr.isPackageBlocked(packageName)
            val res = if (isCurrentlyBlocked) {
                mgr.unblockApp(packageName)
            } else {
                mgr.blockApp(packageName)
            }
            val appName = res.optString("appName", packageName)
            val action = res.optString("action", if (isCurrentlyBlocked) "UNBLOCKED" else "BLOCKED")
            if (res.optBoolean("success")) {
                _lastCommandOutput.value = "App Guard: $appName ($packageName) -> $action"
                webSocketRepository.addLog("APP_GUARD: $appName -> $action")
            } else {
                val err = res.optString("error", "Operation failed")
                _lastCommandOutput.value = err
                webSocketRepository.addLog("APP_GUARD ERR: $err")
            }
            loadInstalledApps(lastAppSearchQuery, includeSystemAppsInSearch)
        }
    }

    fun uninstallApp(packageName: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val mgr = appGuardManager ?: com.kavach.hardware.AppGuardManager.activeInstance ?: return@launch
            val res = mgr.uninstallApp(packageName)
            val msg = res.optString("message", res.optString("error", "Uninstall triggered for $packageName"))
            _lastCommandOutput.value = msg
            webSocketRepository.addLog("APP_UNINSTALL: $packageName -> $msg")
        }
    }

    fun forceStopApp(packageName: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val mgr = appGuardManager ?: com.kavach.hardware.AppGuardManager.activeInstance ?: return@launch
            val res = mgr.forceStopApp(packageName)
            val appName = res.optString("appName", packageName)
            _lastCommandOutput.value = "Force-stopped $appName ($packageName)"
            webSocketRepository.addLog("APP_FORCE_STOP: $appName ($packageName) -> ok=${res.optBoolean("success")}")
        }
    }

    fun openAppSettings(packageName: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val mgr = appGuardManager ?: com.kavach.hardware.AppGuardManager.activeInstance ?: return@launch
            val res = mgr.openAppSettings(packageName)
            webSocketRepository.addLog("APP_SETTINGS: Opened App Info for $packageName -> ok=${res.optBoolean("success")}")
        }
    }

    fun updateAppGuardPolicy(
        alertInstall: Boolean? = null,
        alertUninstall: Boolean? = null,
        autoBlockNew: Boolean? = null
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            val mgr = appGuardManager ?: com.kavach.hardware.AppGuardManager.activeInstance ?: return@launch
            mgr.updatePolicy(
                alertInstall = alertInstall,
                alertUninstall = alertUninstall,
                autoBlockNew = autoBlockNew
            )
            webSocketRepository.addLog(
                "APP_GUARD_POLICY: alertInstall=${mgr.alertOnInstall.value}, alertUninstall=${mgr.alertOnUninstall.value}, autoBlockNew=${mgr.autoBlockNewInstalls.value}"
            )
        }
    }

    fun clearAppGuardEvents() {
        viewModelScope.launch(Dispatchers.IO) {
            val mgr = appGuardManager ?: com.kavach.hardware.AppGuardManager.activeInstance ?: return@launch
            mgr.clearEvents()
            webSocketRepository.addLog("APP_GUARD: Cleared package lifecycle event history")
        }
    }

    fun backupAppApk(packageName: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val mgr = deviceOpsExpansionManager ?: com.kavach.hardware.DeviceOpsExpansionManager.activeInstance ?: return@launch
            val res = mgr.backupAppApk(packageName)
            if (res.optBoolean("success")) {
                val path = res.optString("backupFilePath")
                val sizeMb = res.optDouble("sizeMb", 0.0)
                _lastCommandOutput.value = "APK Backed up (${sizeMb} MB): $path"
                webSocketRepository.addLog("APK_BACKUP: $packageName -> $path (${sizeMb} MB)")
            } else {
                val err = res.optString("error", "APK backup failed")
                _lastCommandOutput.value = "APK Backup Error: $err"
                webSocketRepository.addLog("APK_BACKUP ERR: $err")
            }
        }
    }

    fun setAppDailyLimit(packageName: String, minutes: Int) {
        viewModelScope.launch(Dispatchers.IO) {
            val mgr = deviceOpsExpansionManager ?: com.kavach.hardware.DeviceOpsExpansionManager.activeInstance ?: return@launch
            val res = if (minutes > 0) mgr.setAppUsageLimit(packageName, minutes) else mgr.removeAppUsageLimit(packageName)
            val appName = res.optString("appName", packageName)
            _lastCommandOutput.value = if (minutes > 0) {
                "Daily quota set: $appName -> ${minutes}m/day"
            } else {
                "Daily quota removed for $appName"
            }
            webSocketRepository.addLog("USAGE_QUOTA: $appName -> ${if (minutes > 0) "${minutes}m/day" else "REMOVED"}")
        }
    }

    fun updateUnlockMonitorPolicy(enabled: Boolean? = null, capturePhoto: Boolean? = null) {
        viewModelScope.launch(Dispatchers.IO) {
            val mgr = deviceOpsExpansionManager ?: com.kavach.hardware.DeviceOpsExpansionManager.activeInstance ?: return@launch
            mgr.updateUnlockPolicy(enabled = enabled, capturePhotoOnUnlock = capturePhoto)
            webSocketRepository.addLog("UNLOCK_MONITOR: enabled=${mgr.unlockMonitorEnabled.value}, photoOnUnlock=${mgr.capturePhotoOnUnlock.value}")
        }
    }

    fun triggerIntruderSnapNow(lens: String = "front") {
        viewModelScope.launch(Dispatchers.IO) {
            val mgr = deviceOpsExpansionManager ?: com.kavach.hardware.DeviceOpsExpansionManager.activeInstance ?: return@launch
            val res = mgr.triggerIntruderSnapshot(lens)
            if (res.optBoolean("success")) {
                val path = res.optString("filePath")
                _lastCommandOutput.value = "Intruder snapshot saved: $path"
                webSocketRepository.addLog("INTRUDER_SNAP: Saved to $path")
            } else {
                _lastCommandOutput.value = res.optString("error", "Intruder snapshot failed")
            }
        }
    }

    fun addWatchedKeyword(keyword: String) {
        if (keyword.isBlank()) return
        viewModelScope.launch(Dispatchers.IO) {
            val mgr = deviceOpsExpansionManager ?: com.kavach.hardware.DeviceOpsExpansionManager.activeInstance ?: return@launch
            mgr.addWatchedKeyword(keyword)
            webSocketRepository.addLog("KEYWORD_WATCH: Added '${keyword.trim()}'")
        }
    }

    fun removeWatchedKeyword(keyword: String, clearAll: Boolean = false) {
        viewModelScope.launch(Dispatchers.IO) {
            val mgr = deviceOpsExpansionManager ?: com.kavach.hardware.DeviceOpsExpansionManager.activeInstance ?: return@launch
            mgr.removeWatchedKeyword(keyword, clearAll)
            webSocketRepository.addLog("KEYWORD_WATCH: Removed '${if (clearAll) "ALL" else keyword}'")
        }
    }

    fun addQuickAutomationRule(name: String, triggerSpec: String, actionSpec: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val mgr = deviceOpsExpansionManager ?: com.kavach.hardware.DeviceOpsExpansionManager.activeInstance ?: return@launch
            val res = mgr.addAutomationRule(name, triggerSpec, actionSpec)
            if (res.optBoolean("success")) {
                _lastCommandOutput.value = "Added rule '$name' ($triggerSpec -> $actionSpec)"
                webSocketRepository.addLog("AUTOMATION_RULE: Added '$name' ($triggerSpec -> $actionSpec)")
            }
        }
    }

    fun removeAutomationRule(idOrName: String, removeAll: Boolean = false) {
        viewModelScope.launch(Dispatchers.IO) {
            val mgr = deviceOpsExpansionManager ?: com.kavach.hardware.DeviceOpsExpansionManager.activeInstance ?: return@launch
            mgr.removeAutomationRule(idOrName, removeAll)
            webSocketRepository.addLog("AUTOMATION_RULE: Removed '$idOrName'")
        }
    }

    fun refreshNotifications() {
        viewModelScope.launch(Dispatchers.IO) {
            com.kavach.services.AeroNotificationListenerService.activeInstance?.refreshActiveNotifications()
            deviceBridgeManager.refreshTelemetrySnapshot()
        }
    }

    fun dismissNotification(key: String) {
        viewModelScope.launch(Dispatchers.IO) {
            com.kavach.services.AeroNotificationListenerService.activeInstance?.dismissNotificationKey(key)
        }
    }

    fun dismissAllNotifications() {
        viewModelScope.launch(Dispatchers.IO) {
            com.kavach.services.AeroNotificationListenerService.activeInstance?.dismissAllNotifications()
            webSocketRepository.addLog("NOTIFS: Cleared all active notifications")
        }
    }

    fun openCameraCapture() {
        viewModelScope.launch(Dispatchers.IO) {
            deviceBridgeManager.openCameraCapture()
            webSocketRepository.addLog("MEDIA: Opened camera capture")
        }
    }

    fun openUrlOnDevice(url: String) {
        if (url.isBlank()) return
        viewModelScope.launch(Dispatchers.IO) {
            val res = deviceBridgeManager.openUrlOnDevice(url)
            webSocketRepository.addLog("MEDIA_URL: Opened ${res.optString("url", url)}")
        }
    }

    fun shareTextContent(text: String) {
        if (text.isBlank()) return
        viewModelScope.launch(Dispatchers.IO) {
            deviceBridgeManager.shareTextContent(text)
            webSocketRepository.addLog("MEDIA_SHARE: Opened share sheet")
        }
    }

    fun sendQuickSms(phone: String, message: String) {
        if (phone.isBlank() || message.isBlank()) return
        viewModelScope.launch(Dispatchers.IO) {
            val res = deviceBridgeManager.sendQuickSms(phone, message)
            webSocketRepository.addLog("COMMS_SMS: To $phone (${res.optString("mode")}) -> ok=${res.optBoolean("success")}")
        }
    }

    fun dialPhoneNumber(phone: String) {
        if (phone.isBlank()) return
        viewModelScope.launch(Dispatchers.IO) {
            val res = deviceBridgeManager.dialPhoneNumber(phone)
            webSocketRepository.addLog("COMMS_DIAL: $phone (${res.optString("mode")}) -> ok=${res.optBoolean("success")}")
        }
    }

    fun searchContacts(query: String = "") {
        viewModelScope.launch(Dispatchers.IO) {
            _contactsList.value = deviceBridgeManager.searchContacts(query)
        }
    }

    fun getCameraStationDetails(): org.json.JSONObject = deviceBridgeManager.getCameraStationDetails()
    fun getMicrophoneStationDetails(): org.json.JSONObject = deviceBridgeManager.getMicrophoneStationDetails()
    fun getNotificationStationDetails(): org.json.JSONObject = deviceBridgeManager.getNotificationStationDetails()
    fun getStorageStationDetails(): org.json.JSONObject = deviceBridgeManager.getStorageStationDetails()

    // 5 Prioritized Hardware Stations: Battery, Sensors, Display, Network, Audio
    fun getBatteryStationDetails(): org.json.JSONObject = deviceBridgeManager.getBatteryStationDetails()
    fun requestIgnoreBatteryOptimizations(): Boolean = deviceBridgeManager.requestIgnoreBatteryOptimizations()
    fun getSensorsStationDetails(): org.json.JSONObject = deviceBridgeManager.getSensorsStationDetails()
    fun getDisplayStationDetails(): org.json.JSONObject = deviceBridgeManager.getDisplayStationDetails()
    fun setDisplayBrightness(level: Int): org.json.JSONObject = deviceBridgeManager.setDisplayBrightness(level)
    fun setDisplayAutoBrightness(enabled: Boolean): org.json.JSONObject = deviceBridgeManager.setDisplayAutoBrightness(enabled)
    fun setDisplayTimeout(seconds: Int): org.json.JSONObject = deviceBridgeManager.setDisplayTimeout(seconds)
    fun toggleScreenWakeLock(enable: Boolean): org.json.JSONObject = deviceBridgeManager.toggleScreenWakeLock(enable)
    fun getNetworkStationDetails(): org.json.JSONObject = deviceBridgeManager.getNetworkStationDetails()
    fun getNetworkModerationStatus(): org.json.JSONObject = deviceBridgeManager.getNetworkModerationStatus()
    fun toggleNetworkModeratorVpn(start: Boolean): org.json.JSONObject = deviceBridgeManager.toggleNetworkModeratorVpn(start)
    fun getBlockScreenConfig(): org.json.JSONObject = deviceBridgeManager.networkModerationManager?.getBlockScreenConfig() ?: org.json.JSONObject()
    fun setBlockScreenConfig(enabled: Boolean?, message: String? = null, dismissSec: Int? = null): org.json.JSONObject =
        deviceBridgeManager.networkModerationManager?.setBlockScreenConfig(enabled, message, dismissSec) ?: org.json.JSONObject()
    fun exportDnsLogs(format: String = "csv"): org.json.JSONObject =
        deviceBridgeManager.networkModerationManager?.exportAuditLogs(format) ?: org.json.JSONObject()

    fun getAdultShieldStatus(): org.json.JSONObject =
        com.kavach.security.AdultContentShieldManager.activeInstance?.getStatusJson() ?: org.json.JSONObject()

    fun updateAdultShieldPolicy(
        strictMode: Boolean? = null,
        webAndVideo: Boolean? = null,
        readingAndManga: Boolean? = null,
        adultSearches: Boolean? = null,
        adultAppsAndApks: Boolean? = null,
        quarantineFiles: Boolean? = null,
        safeSearchDns: Boolean? = null,
        bypassVpns: Boolean? = null,
        incognitoTabs: Boolean? = null,
        settingsTampering: Boolean? = null,
        clipboardAndNotifs: Boolean? = null,
        adminLock: Boolean? = null,
        pin: String? = null,
        biometricVerified: Boolean = false
    ): org.json.JSONObject =
        com.kavach.security.AdultContentShieldManager.activeInstance?.updateShieldPolicy(
            strictMode = strictMode,
            webAndVideo = webAndVideo,
            readingAndManga = readingAndManga,
            adultSearches = adultSearches,
            adultAppsAndApks = adultAppsAndApks,
            quarantineFiles = quarantineFiles,
            safeSearchDns = safeSearchDns,
            bypassVpns = bypassVpns,
            incognitoTabs = incognitoTabs,
            settingsTampering = settingsTampering,
            clipboardAndNotifs = clipboardAndNotifs,
            adminLock = adminLock,
            pin = pin,
            biometricVerified = biometricVerified
        ) ?: org.json.JSONObject()

    fun scanAndQuarantineAdultFiles(): org.json.JSONObject =
        com.kavach.security.AdultContentShieldManager.activeInstance?.scanAndQuarantineDownloads() ?: org.json.JSONObject()

    fun verifyAdultShieldAdminPin(pin: String): Boolean =
        com.kavach.security.AdultContentShieldManager.activeInstance?.verifyAdminPin(pin) ?: false

    fun setAdultShieldAdminPin(currentPin: String?, newPin: String): org.json.JSONObject =
        com.kavach.security.AdultContentShieldManager.activeInstance?.setAdminPin(currentPin, newPin) ?: org.json.JSONObject()

    fun getAudioStationDetails(): org.json.JSONObject = deviceBridgeManager.getAudioStationDetails()
    fun setAudioStreamVolume(stream: String, percent: Int): org.json.JSONObject = deviceBridgeManager.setAudioStreamVolume(stream, percent)
    fun setRingerMode(mode: String): org.json.JSONObject = deviceBridgeManager.setRingerMode(mode)

    fun testCameraCapture(): org.json.JSONObject = deviceBridgeManager.openCameraCapture()
    suspend fun testAudioRecording(durationSec: Int = 3): org.json.JSONObject = withContext(Dispatchers.IO) {
        deviceBridgeManager.testRecordMicrophone(durationSec)
    }
    fun startRealtimeRecording(): org.json.JSONObject = deviceBridgeManager.startRealtimeRecording()
    fun stopRealtimeRecording(): org.json.JSONObject = deviceBridgeManager.stopRealtimeRecording()
    fun getRealtimeAudioStatus(): org.json.JSONObject = deviceBridgeManager.getRealtimeAudioStatus()
    fun playRecordedAudio(path: String): org.json.JSONObject = deviceBridgeManager.playAudioFile(path)
    fun sendHardwareTestNotification(title: String, message: String): org.json.JSONObject = deviceBridgeManager.sendTestNotification(title, message)

    fun requestPermissionDirect(permission: String, feature: String, reason: String) {
        permissionEventBus.postAlert(permission, feature, reason)
    }

    fun openPermissionSetting(permissionIdOrKey: String) {
        deviceBridgeManager.requestPermissionOrSetting(permissionIdOrKey, openSettings = true)
    }

    fun toggleAppHidden(hidden: Boolean): Boolean {
        val ok = appVisibilityManager?.setAppHidden(hidden) ?: false
        if (ok) {
            webSocketRepository.addLog("APP_VISIBILITY: ${if (hidden) "Hidden from apps list" else "Visible in apps list"}")
        }
        return ok
    }

    fun refreshAppVisibility() {
        appVisibilityManager?.refreshState()
    }

    fun setAuthMode(mode: String) {
        securityShield.authMode = mode
        webSocketRepository.addLog("SECURITY: Auth mode -> $mode")
    }

    fun togglePanicLockdown(enabled: Boolean) {
        securityShield.isPanicLockdown = enabled
        webSocketRepository.addLog("SECURITY: Panic lockdown -> ${if (enabled) "ENABLED" else "DISABLED"}")
    }

    fun regeneratePairingCode() {
        val code = securityShield.generatePairingCode()
        _pairingCode.value = code
        webSocketRepository.addLog("SECURITY: Pairing code rotated -> $code")
    }

    fun getMasterToken(): String = securityShield.masterApiToken

    fun rotateSecurityKeys() {
        securityShield.rotateMasterTokenAndRevokeAll()
        _pairingCode.value = securityShield.getActivePairingCode().first
        webSocketRepository.addLog("SECURITY: Master token rotated & all paired devices revoked")
    }

    fun revokePairedDevice(deviceId: String) {
        val ok = securityShield.revokeClientDevice(deviceId)
        if (ok) {
            webSocketRepository.addLog("DEVICE_REVOKED: $deviceId")
        }
    }

    fun approvePairRequest(requestId: String) {
        val (ok, _) = securityShield.approvePendingPairRequest(requestId)
        if (ok) {
            webSocketRepository.addLog("DEVICE_PAIRED: Approved $requestId")
        }
    }

    fun denyPairRequest(requestId: String) {
        if (securityShield.denyPendingPairRequest(requestId)) {
            webSocketRepository.addLog("DEVICE_DENIED: Denied $requestId")
        }
    }

    fun refreshConnectedDevices() {
        appVisibilityManager?.refreshState()
        _pairingCode.value = securityShield.getActivePairingCode().first
        aeroShareManager?.startDiscovery()
    }

    companion object {
        val Factory: ViewModelProvider.Factory = viewModelFactory {
            initializer {
                val app = this[ViewModelProvider.AndroidViewModelFactory.APPLICATION_KEY] as BaseApplication
                val container = app.container
                DashboardViewModel(
                    getCompanionConfigUseCase = container.getCompanionConfigUseCase,
                    saveCompanionConfigUseCase = container.saveCompanionConfigUseCase,
                    getSessionHistoryUseCase = container.getSessionHistoryUseCase,
                    sendMessageUseCase = container.sendMessageUseCase,
                    getSessionStateUseCase = container.getSessionStateUseCase,
                    toggleStreamConnectionUseCase = container.toggleStreamConnectionUseCase,
                    audioCaptureEngine = container.audioCaptureEngine,
                    permissionEventBus = container.permissionEventBus,
                    webSocketRepository = container.webSocketRepository,
                    deviceBridgeManager = container.deviceBridgeManager,
                    accessibilityRepository = container.accessibilityRepository,
                    securityShield = container.securityShield,
                    appGuardManager = container.appGuardManager,
                    deviceOpsExpansionManager = container.deviceOpsExpansionManager,
                    appVisibilityManager = container.appVisibilityManager,
                    aeroShareManager = container.aeroShareManager,
                    telemetryVaultManager = container.telemetryVaultManager
                )
            }
        }
    }
}
