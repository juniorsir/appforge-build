package com.kavach.ui.theme

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * AURA ASSISTANT — Centralized Liquid Glass Specifications & Reusable Components
 * Dark Obsidian Glass with Cyan (#38BDF8) and Electric Violet (#A855F7) Specular Glow,
 * 28.dp Super-Rounded Cards, 20.dp Inner Capsules, and Instagram-Style 50% Full-Pill Inputs.
 */
@Immutable
enum class AuraGlassLevel(
    val bgAlpha: Float,
    val borderAlpha: Float,
    val highlightAlpha: Float
) {
    LEVEL_1(bgAlpha = 0.04f, borderAlpha = 0.10f, highlightAlpha = 0.05f),
    LEVEL_2(bgAlpha = 0.06f, borderAlpha = 0.12f, highlightAlpha = 0.07f),
    LEVEL_3(bgAlpha = 0.08f, borderAlpha = 0.16f, highlightAlpha = 0.09f),
    ELEVATED(bgAlpha = 0.11f, borderAlpha = 0.22f, highlightAlpha = 0.12f),
    ACTIVE(bgAlpha = 0.14f, borderAlpha = 0.35f, highlightAlpha = 0.15f);

    fun backgroundColor(): Color = AuraColors.White.copy(alpha = bgAlpha)
    fun borderColor(): Color = AuraColors.White.copy(alpha = borderAlpha)

    fun createHighlightBrush(): Brush = Brush.verticalGradient(
        0.0f to AuraColors.White.copy(alpha = highlightAlpha),
        0.5f to AuraColors.White.copy(alpha = highlightAlpha * 0.3f),
        1.0f to AuraColors.Transparent
    )
}

object LiquidGlassTokens {
    val ObsidianVoid = Color(0xFF04060B)
    val GlassCardFill = Color(0xFF0B111E).copy(alpha = 0.84f)
    val GlassModalFill = Color(0xFF0A101C).copy(alpha = 0.94f)
    val GlassCapsuleFill = Color(0xFF070B14).copy(alpha = 0.88f)
    val GlassPillInputFill = Color(0xFF060A12).copy(alpha = 0.92f)
    val CyanGlow = Color(0xFF38BDF8)
    val VioletGlow = Color(0xFFA855F7)
    val EmeraldGlow = Color(0xFF10B981)
    val AmberGlow = Color(0xFFF59E0B)
    val CoralGlow = Color(0xFFF43F5E)

    val OuterCardShape = RoundedCornerShape(28.dp)
    val InnerCapsuleShape = RoundedCornerShape(20.dp)
    val FullPillShape = RoundedCornerShape(50)

    fun specularBorder(
        primaryTint: Color = CyanGlow,
        secondaryTint: Color = VioletGlow,
        width: Dp = 1.dp,
        intensity: Float = 1f
    ): BorderStroke = BorderStroke(
        width = width,
        brush = Brush.linearGradient(
            colors = listOf(
                Color.White.copy(alpha = (0.22f * intensity).coerceAtMost(0.6f)),
                primaryTint.copy(alpha = (0.34f * intensity).coerceAtMost(0.8f)),
                secondaryTint.copy(alpha = (0.22f * intensity).coerceAtMost(0.7f)),
                Color.White.copy(alpha = (0.06f * intensity).coerceAtMost(0.3f))
            ),
            start = Offset(0f, 0f),
            end = Offset(900f, 900f)
        )
    )

    val TopRefractionSheen = Brush.verticalGradient(
        0.0f to Color.White.copy(alpha = 0.08f),
        0.35f to Color(0xFF38BDF8).copy(alpha = 0.025f),
        1.0f to Color.Transparent
    )
}

/**
 * Draws the signature Dark Obsidian ambient Cyan + Electric Violet liquid aura behind a screen.
 */
fun Modifier.liquidObsidianBackground(
    primaryAura: Color = LiquidGlassTokens.CyanGlow,
    secondaryAura: Color = LiquidGlassTokens.VioletGlow
): Modifier = this
    .background(LiquidGlassTokens.ObsidianVoid)
    .drawBehind {
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(
                    primaryAura.copy(alpha = 0.12f),
                    primaryAura.copy(alpha = 0.03f),
                    Color.Transparent
                ),
                center = Offset(size.width * 0.14f, size.height * 0.06f),
                radius = size.width * 0.9f
            ),
            radius = size.width * 0.9f,
            center = Offset(size.width * 0.14f, size.height * 0.06f)
        )
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(
                    secondaryAura.copy(alpha = 0.10f),
                    secondaryAura.copy(alpha = 0.025f),
                    Color.Transparent
                ),
                center = Offset(size.width * 0.88f, size.height * 0.28f),
                radius = size.width * 0.78f
            ),
            radius = size.width * 0.78f,
            center = Offset(size.width * 0.88f, size.height * 0.28f)
        )
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(
                    primaryAura.copy(alpha = 0.06f),
                    Color.Transparent
                ),
                center = Offset(size.width * 0.25f, size.height * 0.82f),
                radius = size.width * 0.7f
            ),
            radius = size.width * 0.7f,
            center = Offset(size.width * 0.25f, size.height * 0.82f)
        )
    }

/**
 * 28.dp Super-Rounded Liquid Glass Card with diagonal specular refraction border and top sheen.
 */
@Composable
fun LiquidGlassCard(
    modifier: Modifier = Modifier,
    accentTint: Color = LiquidGlassTokens.CyanGlow,
    secondaryTint: Color = LiquidGlassTokens.VioletGlow,
    shape: Shape = LiquidGlassTokens.OuterCardShape,
    containerColor: Color = LiquidGlassTokens.GlassCardFill,
    content: @Composable BoxScope.() -> Unit
) {
    Surface(
        color = containerColor,
        shape = shape,
        border = LiquidGlassTokens.specularBorder(
            primaryTint = accentTint,
            secondaryTint = secondaryTint
        ),
        modifier = modifier.fillMaxWidth()
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(LiquidGlassTokens.TopRefractionSheen),
            content = content
        )
    }
}

/**
 * Premium glowing squircle/circle icon orb with radial halo and specular glass border.
 */
@Composable
fun LiquidIconOrb(
    icon: ImageVector,
    tint: Color,
    contentDescription: String? = null,
    size: Dp = 36.dp,
    iconSize: Dp = 18.dp,
    isCircle: Boolean = false,
    modifier: Modifier = Modifier
) {
    val shape = if (isCircle) CircleShape else RoundedCornerShape((size.value * 0.36f).dp)
    Box(
        modifier = modifier
            .size(size)
            .clip(shape)
            .background(
                Brush.radialGradient(
                    colors = listOf(
                        tint.copy(alpha = 0.26f),
                        tint.copy(alpha = 0.08f)
                    )
                )
            )
            .border(
                width = 0.9.dp,
                brush = Brush.linearGradient(
                    colors = listOf(
                        Color.White.copy(alpha = 0.28f),
                        tint.copy(alpha = 0.45f),
                        tint.copy(alpha = 0.12f)
                    )
                ),
                shape = shape
            ),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = contentDescription,
            tint = tint,
            modifier = Modifier.size(iconSize)
        )
    }
}
