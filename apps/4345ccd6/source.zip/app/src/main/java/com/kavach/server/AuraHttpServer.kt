package com.kavach.server

import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.OutputStream
import java.net.ServerSocket
import java.net.Socket

class AuraHttpServer(
    private val scope: CoroutineScope,
    private val port: Int = 8080,
    private val securityShield: com.kavach.security.AuraSecurityShield? = null,
    private val onScriptRequest: ((scriptName: String) -> ByteArray?)? = null,
    private val onApiRequest: ((endpoint: String, jsonPayload: JSONObject) -> JSONObject)? = null,
    private val onWsMessage: ((rawText: String, sendReply: (String) -> Unit) -> Unit)? = null
) {
    private val TAG = "AuraHttpServer"
    private var serverSocket: ServerSocket? = null
    private var serverJob: Job? = null
    private val connectedWsClients = java.util.concurrent.ConcurrentHashMap.newKeySet<OutputStream>()
    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    private val clientDispatcher = Dispatchers.IO.limitedParallelism(16)

    companion object {
        private const val MAX_HEADER_BYTES = 16 * 1024
        private const val MAX_HEADER_LINES = 64
    }

    fun start() {
        if (serverJob?.isActive == true) return
        serverJob = scope.launch(Dispatchers.IO) {
            while (isActive) {
                try {
                    val sock = ServerSocket()
                    sock.reuseAddress = true
                    sock.bind(java.net.InetSocketAddress("0.0.0.0", port))
                    serverSocket = sock
                    Log.i(TAG, "Aura Documentation & REST API HTTP Server listening on http://127.0.0.1:$port")

                    while (isActive && serverSocket?.isClosed == false) {
                        try {
                            val clientSocket = serverSocket?.accept() ?: break
                            launch(clientDispatcher) {
                                handleClient(clientSocket)
                            }
                        } catch (e: Exception) {
                            if (isActive) {
                                Log.w(TAG, "Exception accepting connection: ${e.message}")
                            }
                        }
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "Failed to bind AuraHttpServer to port $port: ${e.message}. Retrying in 2s...")
                    try {
                        serverSocket?.close()
                    } catch (_: Exception) {}
                    kotlinx.coroutines.delay(2000)
                }
            }
        }
    }

    private val cachedHelpBytes by lazy {
        AuraManifestProvider.generateManifestJson().toByteArray(Charsets.UTF_8)
    }

    private val cachedCapabilitiesBytes by lazy {
        val manifest = JSONObject(AuraManifestProvider.generateManifestJson())
        val caps = manifest.optJSONArray("capabilities") ?: org.json.JSONArray()
        val responseObj = JSONObject().apply {
            put("totalCapabilities", manifest.optInt("totalCapabilitiesCount", 42))
            put("categories", manifest.optJSONArray("categories"))
            put("capabilities", caps)
        }
        responseObj.toString(2).toByteArray(Charsets.UTF_8)
    }

    private val cachedCommandsBytes by lazy {
        val manifest = JSONObject(AuraManifestProvider.generateManifestJson())
        val cmds = manifest.optJSONArray("commands") ?: org.json.JSONArray()
        val responseObj = JSONObject().apply {
            put("totalCommands", manifest.optInt("totalCommandsCount", 24))
            put("commands", cmds)
        }
        responseObj.toString(2).toByteArray(Charsets.UTF_8)
    }

    private val cachedHealthBytes by lazy {
        val statusObj = JSONObject().apply {
            put("status", "UP")
            put("server", "Aura Local Media & Device Engine")
            put("totalCapabilities", 52)
            put("totalCommands", 33)
            put("websocketPort", 8000)
            put("httpDocsPort", port)
            put("securityShield", securityShield?.authMode ?: "DISABLED")
        }
        statusObj.toString(2).toByteArray(Charsets.UTF_8)
    }

    private fun handleClient(socket: Socket) {
        socket.use { client ->
            try {
                client.soTimeout = 4000
                val clientIp = client.inetAddress?.hostAddress ?: "127.0.0.1"
                val rawInput = BufferedInputStream(client.getInputStream(), 4096)
                val out: OutputStream = client.getOutputStream()
                var totalHeaderBytes = 0

                fun readHeaderLine(): String? {
                    val sb = StringBuilder(128)
                    while (true) {
                        val b = rawInput.read()
                        if (b == -1) break
                        totalHeaderBytes++
                        if (totalHeaderBytes > MAX_HEADER_BYTES || sb.length > 4096) return null
                        if (b == '\n'.code) {
                            if (sb.endsWith("\r")) sb.setLength(sb.length - 1)
                            break
                        }
                        sb.append(b.toChar())
                    }
                    return sb.toString()
                }

                val requestLine = readHeaderLine()
                if (requestLine.isNullOrBlank()) return
                val parts = requestLine.split(" ")
                if (parts.size < 2) return

                val method = parts[0].uppercase()
                val rawUri = parts[1]
                val path = rawUri.substringBefore("?")
                val queryString = if (rawUri.contains("?")) rawUri.substringAfter("?") else ""

                // Strict URL & Path Sanitization: Reject path traversal or malformed characters
                if (path.contains("..") || path.contains("\\") || path.contains("\u0000") || path.contains("%2e%2e", ignoreCase = true)) {
                    val badUrlObj = JSONObject().apply {
                        put("success", false)
                        put("error", "400 Bad Request: Malformed or unauthorized URL path detected.")
                    }
                    val badBytes = badUrlObj.toString(2).toByteArray(Charsets.UTF_8)
                    val header = "HTTP/1.1 400 Bad Request\r\nContent-Type: application/json\r\nContent-Length: ${badBytes.size}\r\nConnection: close\r\n\r\n"
                    out.write(header.toByteArray(Charsets.UTF_8))
                    out.write(badBytes)
                    out.flush()
                    return
                }

                // Read headers & capture Origin / Proxy / Auth / WebSocket Upgrade
                var contentLength = 0
                var authHeader: String? = null
                var originHeader: String? = null
                var upgradeHeader: String? = null
                var secWebSocketKey: String? = null
                var hasProxyHeaders = false
                var headerLineCount = 0
                while (headerLineCount < MAX_HEADER_LINES) {
                    val line = readHeaderLine() ?: return
                    headerLineCount++
                    if (line.isEmpty()) break
                    val headerLower = line.lowercase()
                    if (headerLower.startsWith("content-length:")) {
                        contentLength = headerLower.substringAfter(":").trim().toIntOrNull() ?: 0
                    } else if (headerLower.startsWith("authorization:")) {
                        authHeader = line.substringAfter(":").trim()
                    } else if (headerLower.startsWith("x-api-key:")) {
                        authHeader = line.substringAfter(":").trim()
                    } else if (headerLower.startsWith("origin:")) {
                        originHeader = line.substringAfter(":").trim()
                    } else if (headerLower.startsWith("upgrade:")) {
                        upgradeHeader = line.substringAfter(":").trim()
                    } else if (headerLower.startsWith("sec-websocket-key:")) {
                        secWebSocketKey = line.substringAfter(":").trim()
                    } else if (
                        headerLower.startsWith("x-forwarded-for:") ||
                        headerLower.startsWith("cf-connecting-ip:") ||
                        headerLower.startsWith("x-real-ip:") ||
                        headerLower.startsWith("forwarded:")
                    ) {
                        hasProxyHeaders = true
                    }
                }

                // Extract query string early so queryToken can be checked for WS & HTTP auth
                var queryToken: String? = null
                val queryParams = mutableListOf<Pair<String, String>>()
                if (queryString.isNotBlank()) {
                    queryString.split("&").forEach { param ->
                        val kv = param.split("=", limit = 2)
                        if (kv.isNotEmpty()) {
                            val k = java.net.URLDecoder.decode(kv[0], "UTF-8")
                            val v = if (kv.size > 1) java.net.URLDecoder.decode(kv[1], "UTF-8") else "true"
                            if (k.equals("token", ignoreCase = true) || k.equals("apiKey", ignoreCase = true) || k.equals("api_key", ignoreCase = true)) {
                                queryToken = v
                            }
                            queryParams.add(k to v)
                        }
                    }
                }

                // Strict Origin Check: only allow exact localhost/loopback browser origins (native CLI sends no Origin header)
                val verifiedAllowedOrigin: String? = if (!originHeader.isNullOrBlank()) {
                    val parsedHost = try {
                        java.net.URI(originHeader).host?.lowercase()
                    } catch (_: Exception) {
                        null
                    }
                    val isLocalOrigin = parsedHost == "127.0.0.1" || parsedHost == "localhost" || parsedHost == "::1"
                    if (!isLocalOrigin) {
                        val unauthOriginObj = JSONObject().apply {
                            put("success", false)
                            put("error", "403 Forbidden: Cross-Origin requests from untrusted domains are rejected.")
                        }
                        val unauthOriginBytes = unauthOriginObj.toString(2).toByteArray(Charsets.UTF_8)
                        val header = "HTTP/1.1 403 Forbidden\r\nContent-Type: application/json\r\nContent-Length: ${unauthOriginBytes.size}\r\nConnection: close\r\n\r\n"
                        out.write(header.toByteArray(Charsets.UTF_8))
                        out.write(unauthOriginBytes)
                        out.flush()
                        return
                    }
                    originHeader
                } else {
                    null
                }

                // Handle CORS preflight (never wildcard *)
                if (method == "OPTIONS") {
                    val corsLine = if (verifiedAllowedOrigin != null) {
                        "Access-Control-Allow-Origin: $verifiedAllowedOrigin\r\nVary: Origin\r\n"
                    } else {
                        ""
                    }
                    val header = "HTTP/1.1 204 No Content\r\n" +
                            corsLine +
                            "Access-Control-Allow-Methods: GET, POST, OPTIONS\r\n" +
                            "Access-Control-Allow-Headers: Content-Type, Authorization, X-API-Key\r\n" +
                            "Connection: close\r\n\r\n"
                    out.write(header.toByteArray(Charsets.UTF_8))
                    out.flush()
                    return
                }

                // Rate limiting and Lockout check (applied BEFORE WebSocket upgrade & REST execution)
                if (securityShield != null) {
                    if (securityShield.isIpLockedOut(clientIp)) {
                        val lockObj = JSONObject().apply {
                            put("success", false)
                            put("error", if (securityShield.isPanicLockdown) {
                                "403 Forbidden: Device is in Panic Lockdown. Unlock inside the app."
                            } else {
                                "403 Forbidden: Client IP temporarily locked out due to excessive failed auth attempts. Try again in 60s."
                            })
                        }
                        val lockBytes = lockObj.toString(2).toByteArray(Charsets.UTF_8)
                        val header = buildString {
                            append("HTTP/1.1 403 Forbidden\r\n")
                            append("Content-Type: application/json; charset=utf-8\r\n")
                            append("Content-Length: ${lockBytes.size}\r\n")
                            append("Connection: close\r\n\r\n")
                        }
                        out.write(header.toByteArray(Charsets.UTF_8))
                        out.write(lockBytes)
                        out.flush()
                        return
                    }

                    if (!securityShield.checkRateLimit(clientIp)) {
                        val rateObj = JSONObject().apply {
                            put("success", false)
                            put("error", "429 Too Many Requests: Rate limit exceeded. Maximum 150 requests per minute.")
                        }
                        val rateBytes = rateObj.toString(2).toByteArray(Charsets.UTF_8)
                        val header = buildString {
                            append("HTTP/1.1 429 Too Many Requests\r\n")
                            append("Content-Type: application/json; charset=utf-8\r\n")
                            append("Content-Length: ${rateBytes.size}\r\n")
                            append("Retry-After: 60\r\n")
                            append("Connection: close\r\n\r\n")
                        }
                        out.write(header.toByteArray(Charsets.UTF_8))
                        out.write(rateBytes)
                        out.flush()
                        return
                    }
                }

                // Native RFC 6455 WebSocket Upgrade Support (MUST pass authentication BEFORE upgrading)
                if (upgradeHeader.equals("websocket", ignoreCase = true) && !secWebSocketKey.isNullOrBlank()) {
                    if (securityShield != null) {
                        val wsAuthorized = securityShield.verifyRequest(
                            clientIp = clientIp,
                            providedAuthHeader = authHeader,
                            providedQueryToken = queryToken,
                            hasProxyHeaders = hasProxyHeaders
                        )
                        if (!wsAuthorized) {
                            val unauthBytes = JSONObject().apply {
                                put("success", false)
                                put("error", "401 Unauthorized: WebSocket upgrade requires authentication.")
                            }.toString(2).toByteArray(Charsets.UTF_8)
                            val hdr = "HTTP/1.1 401 Unauthorized\r\nContent-Type: application/json\r\nContent-Length: ${unauthBytes.size}\r\nConnection: close\r\n\r\n"
                            out.write(hdr.toByteArray(Charsets.UTF_8))
                            out.write(unauthBytes)
                            out.flush()
                            return
                        }
                    }
                    handleWebSocketUpgrade(client, rawInput, out, secWebSocketKey)
                    return
                }

                // Read body if POST/PUT (max 10MB payload protect)
                var bodyJson = JSONObject()
                val safeContentLength = contentLength.coerceAtMost(10 * 1024 * 1024)
                if (safeContentLength > 0) {
                    val bodyBytes = ByteArray(safeContentLength)
                    var readCount = 0
                    while (readCount < safeContentLength) {
                        val read = rawInput.read(bodyBytes, readCount, safeContentLength - readCount)
                        if (read <= 0) break
                        readCount += read
                    }
                    val bodyString = String(bodyBytes, 0, readCount, Charsets.UTF_8)
                    if (bodyString.isNotBlank()) {
                        try {
                            bodyJson = JSONObject(bodyString)
                        } catch (e: Exception) {
                            bodyJson.put("raw", bodyString)
                        }
                    }
                }

                // Populate query string parameters if not already in JSON body
                for ((k, v) in queryParams) {
                    if (!bodyJson.has(k)) {
                        if (v.equals("true", ignoreCase = true)) bodyJson.put(k, true)
                        else if (v.equals("false", ignoreCase = true)) bodyJson.put(k, false)
                        else bodyJson.put(k, v)
                    }
                }

                // Inject verified socket metadata so endpoints never trust spoofed clientIp or token flags in body JSON
                bodyJson.put("_socketClientIp", if (hasProxyHeaders) "proxied:$clientIp" else clientIp)
                bodyJson.put("_isMasterTokenAuth", securityShield?.isMasterToken(authHeader, queryToken) == true)

                // Authentication verification on ALL routes except minimal health & login/pairing handshakes
                val isAuthExemptPath = path == "/health" ||
                        path == "/api/auth/login" ||
                        path == "/api/auth/poll" ||
                        path == "/api/pair/request" ||
                        path == "/api/pair/poll" ||
                        path == "/api/pair/register" ||
                        path == "/api/security/pair/request" ||
                        path == "/api/security/pair/poll" ||
                        path == "/api/security/pair/register"

                if (!isAuthExemptPath && securityShield != null) {
                    val isAuthorized = securityShield.verifyRequest(
                        clientIp = clientIp,
                        providedAuthHeader = authHeader,
                        providedQueryToken = queryToken,
                        hasProxyHeaders = hasProxyHeaders
                    )
                    if (!isAuthorized) {
                        val unauthObj = JSONObject().apply {
                            put("success", false)
                            put("error", "UNAUTHORIZED_DEVICE")
                            put("action", "AUTHENTICATION_REQUIRED")
                            put("message", "401 Unauthorized: This device or bridge is not authenticated.")
                            put("loginCommand", "python server/send_cmd.py login")
                            put("instructions", "Run 'python send_cmd.py login' in Termux. Verify on phone with Face, Fingerprint, or PIN to authorize access.")
                            put("authMode", securityShield.authMode)
                        }
                        val unauthBytes = unauthObj.toString(2).toByteArray(Charsets.UTF_8)
                        val header = buildString {
                            append("HTTP/1.1 401 Unauthorized\r\n")
                            append("Content-Type: application/json; charset=utf-8\r\n")
                            append("Content-Length: ${unauthBytes.size}\r\n")
                            append("WWW-Authenticate: Bearer realm=\"AuraSecureAPI\"\r\n")
                            append("Connection: close\r\n\r\n")
                        }
                        out.write(header.toByteArray(Charsets.UTF_8))
                        out.write(unauthBytes)
                        out.flush()
                        return
                    }
                }

                // Direct CLI Script Download Route (/send_cmd.py, /scripts/send_cmd.py, /mock_server.py, /ws_relay.py)
                if ((path == "/send_cmd.py" || path == "/mock_server.py" || path == "/ws_relay.py" || path.startsWith("/scripts/")) && onScriptRequest != null) {
                    val scriptBytes = onScriptRequest.invoke(path.substringAfterLast("/"))
                    if (scriptBytes != null) {
                        val hdr = buildString {
                            append("HTTP/1.1 200 OK\r\n")
                            append("Content-Type: text/x-python; charset=utf-8\r\n")
                            append("Content-Length: ${scriptBytes.size}\r\n")
                            append("Cache-Control: no-store\r\n")
                            if (verifiedAllowedOrigin != null) {
                                append("Access-Control-Allow-Origin: $verifiedAllowedOrigin\r\n")
                                append("Vary: Origin\r\n")
                            }
                            append("Connection: close\r\n\r\n")
                        }
                        out.write(hdr.toByteArray(Charsets.UTF_8))
                        out.write(scriptBytes)
                        out.flush()
                        return
                    }
                }

                val (statusCode, bodyBytes) = when {
                    path == "/" || path == "/help" || path == "/docs" || path == "/manifest" -> {
                        Pair("200 OK", cachedHelpBytes)
                    }
                    path == "/capabilities" -> {
                        Pair("200 OK", cachedCapabilitiesBytes)
                    }
                    path == "/commands" -> {
                        Pair("200 OK", cachedCommandsBytes)
                    }
                    path == "/health" || path == "/status" || path == "/ws" -> {
                        Pair("200 OK", cachedHealthBytes)
                    }
                    path.startsWith("/api/") && onApiRequest != null -> {
                        try {
                            val apiResult = onApiRequest.invoke(path, bodyJson)
                            Pair("200 OK", apiResult.toString(2).toByteArray(Charsets.UTF_8))
                        } catch (e: Exception) {
                            val errObj = JSONObject().apply {
                                put("success", false)
                                put("error", e.message ?: "API Error")
                            }
                            Pair("500 Internal Server Error", errObj.toString(2).toByteArray(Charsets.UTF_8))
                        }
                    }
                    else -> {
                        val notFoundObj = JSONObject().apply {
                            put("error", "Not Found")
                            put("availableEndpoints", listOf("/health", "/api/*"))
                        }
                        Pair("404 Not Found", notFoundObj.toString(2).toByteArray(Charsets.UTF_8))
                    }
                }

                val header = buildString {
                    append("HTTP/1.1 $statusCode\r\n")
                    append("Content-Type: application/json; charset=utf-8\r\n")
                    append("Content-Length: ${bodyBytes.size}\r\n")
                    if (verifiedAllowedOrigin != null) {
                        append("Access-Control-Allow-Origin: $verifiedAllowedOrigin\r\n")
                        append("Access-Control-Allow-Methods: GET, POST, OPTIONS\r\n")
                        append("Access-Control-Allow-Headers: Content-Type, Authorization, X-API-Key\r\n")
                        append("Vary: Origin\r\n")
                    }
                    // OWASP Hardened Security Headers
                    securityShield?.getSecurityHeaders()?.forEach { (k, v) ->
                        append("$k: $v\r\n")
                    }
                    append("Connection: close\r\n")
                    append("\r\n")
                }
                out.write(header.toByteArray(Charsets.UTF_8))
                out.write(bodyBytes)
                out.flush()
            } catch (e: Exception) {
                Log.e(TAG, "Error handling HTTP client request: ${e.message}")
            }
        }
    }

    private fun handleWebSocketUpgrade(
        client: Socket,
        rawInput: java.io.InputStream,
        out: OutputStream,
        secWebSocketKey: String
    ) {
        try {
            client.soTimeout = 0
            val magic = secWebSocketKey.trim() + "258EAFA5-E914-47DA-95CA-C5AB0DC85B11"
            val sha1 = java.security.MessageDigest.getInstance("SHA-1").digest(magic.toByteArray(Charsets.UTF_8))
            val acceptKey = android.util.Base64.encodeToString(sha1, android.util.Base64.NO_WRAP)

            val handshake = buildString {
                append("HTTP/1.1 101 Switching Protocols\r\n")
                append("Upgrade: websocket\r\n")
                append("Connection: Upgrade\r\n")
                append("Sec-WebSocket-Accept: $acceptKey\r\n\r\n")
            }
            synchronized(out) {
                out.write(handshake.toByteArray(Charsets.UTF_8))
                out.flush()
            }

            connectedWsClients.add(out)

            // Send initial PONG greeting so client transitions to CONNECTED immediately
            val initPong = JSONObject().apply {
                put("type", "PONG")
                put("timestamp", System.currentTimeMillis())
                put("sessionId", "aura-ws-" + System.currentTimeMillis())
                put("pingId", "init")
                put("requestTimestamp", System.currentTimeMillis())
                put("clientName", "AuraEmbeddedWsServer")
                put("deviceId", "android-embedded-bridge")
                put("protocolVersion", "1.0")
            }.toString()
            sendWsTextFrame(out, initPong)

            while (!client.isClosed) {
                val b0 = rawInput.read()
                if (b0 == -1) break
                val b1 = rawInput.read()
                if (b1 == -1) break

                val opcode = b0 and 0x0F
                val isMasked = (b1 and 0x80) != 0
                var payloadLen = (b1 and 0x7F).toLong()

                if (payloadLen == 126L) {
                    val hi = rawInput.read()
                    val lo = rawInput.read()
                    if (hi == -1 || lo == -1) break
                    payloadLen = ((hi and 0xFF).toLong() shl 8) or (lo and 0xFF).toLong()
                } else if (payloadLen == 127L) {
                    var len64 = 0L
                    for (i in 0 until 8) {
                        val b = rawInput.read()
                        if (b == -1) return
                        len64 = (len64 shl 8) or (b and 0xFF).toLong()
                    }
                    payloadLen = len64
                }

                if (payloadLen > 16 * 1024 * 1024) break // Cap frame at 16MB

                val maskKey = ByteArray(4)
                if (isMasked) {
                    var mRead = 0
                    while (mRead < 4) {
                        val r = rawInput.read(maskKey, mRead, 4 - mRead)
                        if (r <= 0) return
                        mRead += r
                    }
                }

                val payload = ByteArray(payloadLen.toInt())
                var pRead = 0
                while (pRead < payload.size) {
                    val r = rawInput.read(payload, pRead, payload.size - pRead)
                    if (r <= 0) return
                    pRead += r
                }

                if (isMasked) {
                    for (i in payload.indices) {
                        payload[i] = (payload[i].toInt() xor maskKey[i % 4].toInt()).toByte()
                    }
                }

                when (opcode) {
                    0x8 -> break // Close frame
                    0x9 -> {
                        // Ping -> send Pong (0xA)
                        sendWsControlFrame(out, 0xA, payload)
                    }
                    0x1 -> {
                        val text = String(payload, Charsets.UTF_8)
                        val json = try { JSONObject(text) } catch (_: Exception) { null }
                        val msgType = json?.optString("type", "") ?: ""

                        if (msgType == "PING") {
                            val pong = JSONObject().apply {
                                put("type", "PONG")
                                put("timestamp", System.currentTimeMillis())
                                put("sessionId", json?.optString("sessionId", "aura-ws") ?: "aura-ws")
                                put("pingId", json?.optString("pingId", "1") ?: "1")
                                put("requestTimestamp", json?.optLong("timestamp", System.currentTimeMillis()) ?: System.currentTimeMillis())
                            }.toString()
                            sendWsTextFrame(out, pong)
                        } else if (msgType != "PONG" && msgType != "HELLO" && msgType != "ACCESSIBILITY_SCREEN_UPDATE") {
                            onWsMessage?.invoke(text) { replyText ->
                                try {
                                    sendWsTextFrame(out, replyText)
                                } catch (_: Exception) {}
                            }
                            // Relay frame to all other connected WS clients on port 8080
                            for (other in connectedWsClients) {
                                if (other !== out) {
                                    try {
                                        sendWsTextFrame(other, text)
                                    } catch (_: Exception) {
                                        connectedWsClients.remove(other)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Log.d(TAG, "WebSocket client closed: ${e.message}")
        } finally {
            connectedWsClients.remove(out)
        }
    }

    private fun sendWsTextFrame(out: OutputStream, text: String) {
        val bytes = text.toByteArray(Charsets.UTF_8)
        sendWsControlFrame(out, 0x1, bytes)
    }

    private fun sendWsControlFrame(out: OutputStream, opcode: Int, payload: ByteArray) {
        synchronized(out) {
            out.write(0x80 or (opcode and 0x0F))
            val len = payload.size
            when {
                len <= 125 -> out.write(len)
                len <= 65535 -> {
                    out.write(126)
                    out.write((len shr 8) and 0xFF)
                    out.write(len and 0xFF)
                }
                else -> {
                    out.write(127)
                    val l = len.toLong()
                    for (shift in 56 downTo 0 step 8) {
                        out.write(((l shr shift) and 0xFF).toInt())
                    }
                }
            }
            out.write(payload)
            out.flush()
        }
    }

    fun stop() {
        try {
            serverSocket?.close()
        } catch (e: Exception) {
            // Ignore
        }
        connectedWsClients.clear()
        serverJob?.cancel()
    }
}
