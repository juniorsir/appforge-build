package com.kavach

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import com.kavach.di.AppContainer
import com.kavach.services.RealtimeConnectionService
import com.kavach.workers.TelemetrySyncWorker
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * Base Application entry point.
 * Initializes dependency injection scopes, background bridge auto-connect,
 * and periodic WorkManager synchronization workers.
 */
class BaseApplication : Application() {

    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()

        container = AppContainer(this)

        try {
            container.appVisibilityManager.syncPersistedState(allowBridgeStart = false)
        } catch (e: Throwable) {
            android.util.Log.w("BaseApplication", "Failed syncing app visibility state", e)
        }

        // Start local :8080 bridge & auto-connect to available tunnel (authenticated tunnel or local)
        // even when app is hidden from launcher and MainActivity is never opened.
        ensureBackgroundBridgeConnected(startForegroundIfPossible = false)

        try {
            TelemetrySyncWorker.enqueuePeriodicSync(this)
        } catch (e: Throwable) {
            android.util.Log.w("BaseApplication", "Failed to enqueue periodic telemetry sync worker", e)
        }
    }

    fun ensureBackgroundBridgeConnected(startForegroundIfPossible: Boolean = false) {
        container.applicationScope.launch(Dispatchers.IO) {
            try {
                container.httpServer.start()
            } catch (t: Throwable) {
                android.util.Log.w("BaseApplication", "HTTP bridge start failed: ${t.message}")
            }

            try {
                val isHidden = container.appVisibilityManager.refreshState()
                val prefs = getSharedPreferences("termux_bridge_prefs", Context.MODE_PRIVATE)
                val autoConnect = prefs.getBoolean("key_auto_connect", true)
                if (autoConnect || isHidden) {
                    val candidates = RealtimeConnectionService.getCandidateUrls(this@BaseApplication)
                    container.webSocketRepository.connectBestAvailable(candidates, forceSwitch = false)
                }

                if (startForegroundIfPossible) {
                    RealtimeConnectionService.ensureBridge(this@BaseApplication)
                } else if (isHidden && !RealtimeConnectionService.serviceState.value.isServiceRunning) {
                    postHiddenReopenNotification()
                }
            } catch (t: Throwable) {
                android.util.Log.w("BaseApplication", "Background bridge auto-connect error: ${t.message}")
            }
        }
    }

    private fun postHiddenReopenNotification() {
        try {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager ?: return
            val channelId = "termux_aios_bridge_foreground_channel"
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val chan = NotificationChannel(
                    channelId,
                    "Termux AIOS Bridge Service",
                    NotificationManager.IMPORTANCE_LOW
                ).apply {
                    setShowBadge(false)
                }
                nm.createNotificationChannel(chan)
            }
            val openIntent = Intent(this, MainActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            }
            val pi = PendingIntent.getActivity(
                this,
                4002,
                openIntent,
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val notif = NotificationCompat.Builder(this, channelId)
                .setSmallIcon(android.R.drawable.stat_notify_sync)
                .setContentTitle("AeroShare Bridge Active (Hidden)")
                .setContentText("Auto-connecting tunnel/local - Tap to open console")
                .setOngoing(true)
                .setContentIntent(pi)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .build()
            nm.notify(4001, notif)
        } catch (_: Throwable) {}
    }

    @Suppress("DEPRECATION")
    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        if (!::container.isInitialized) return
        val aggressive = level >= android.content.ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW ||
            level == android.content.ComponentCallbacks2.TRIM_MEMORY_UI_HIDDEN
        container.trimMemory(aggressive = aggressive)
    }

    override fun onLowMemory() {
        super.onLowMemory()
        if (::container.isInitialized) {
            container.trimMemory(aggressive = true)
        }
    }
}
