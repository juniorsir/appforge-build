package com.kavach.telemetry

import android.Manifest
import android.annotation.SuppressLint
import android.app.ActivityManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Looper
import android.os.PowerManager
import android.util.Log
import androidx.core.content.ContextCompat
import com.kavach.data.local.DeviceSnapshotEntity
import com.kavach.data.local.LocationPointEntity
import com.kavach.data.local.SyncWatermarkEntity
import com.kavach.data.local.TelemetryVaultDao
import com.kavach.data.local.TimelineEventEntity
import com.kavach.data.local.VaultCategory
import com.kavach.data.local.VaultCountSummary
import com.kavach.data.local.VaultSyncStatus
import com.kavach.domain.model.SessionState
import com.kavach.domain.repository.WebSocketRepository
import com.kavach.hardware.NetworkTelemetryManager
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

data class VaultUiSummary(
    val isMonitoringActive: Boolean = false,
    val isSyncing: Boolean = false,
    val isOnline: Boolean = false,
    val isBridgeConnected: Boolean = false,
    val pendingCount: Int = 0,
    val totalEvents: Int = 0,
    val totalLocations: Int = 0,
    val lastSyncAt: Long = 0L,
    val lastSyncMessage: String = ""
)

/**
 * Always-on offline-first store-and-forward telemetry recorder.
 * Captures GPS location paths, app launches/guard events, unlocks, notifications,
 * DNS queries/blocks, and battery/Wi-Fi/network transitions into Room SQLite.
 *
 * Unsynced records stay queued offline indefinitely regardless of outage length.
 * Upon bridge reconnect, pending records auto-push in acknowledged batches and
 * begin their 20-day post-sync local retention countdown (`expiresAt = syncedAt + 20 days`).
 */
class OfflineTelemetryVaultManager(
    private val context: Context,
    private val dao: TelemetryVaultDao,
    private val webSocketRepository: WebSocketRepository,
    private val networkTelemetryManager: NetworkTelemetryManager,
    private val scope: CoroutineScope = CoroutineScope(
        SupervisorJob() + Dispatchers.IO + CoroutineExceptionHandler { _, throwable ->
            Log.w(TAG, "Vault background coroutine warning: ${throwable.message}")
        }
    )
) {
    companion object {
        private const val TAG = "OfflineTelemetryVault"
        const val RETENTION_AFTER_SYNC_DAYS = 20L
        const val RETENTION_AFTER_SYNC_MS = RETENTION_AFTER_SYNC_DAYS * 24L * 60L * 60L * 1000L

        private const val GPS_MIN_TIME_MS = 30_000L
        private const val GPS_MIN_DISTANCE_M = 15f
        private const val HEARTBEAT_SNAPSHOT_MS = 5 * 60_000L

        @Volatile
        var activeInstance: OfflineTelemetryVaultManager? = null
            private set

        fun haversineMeters(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Float {
            val r = 6371000.0
            val dLat = Math.toRadians(lat2 - lat1)
            val dLon = Math.toRadians(lon2 - lon1)
            val a = sin(dLat / 2).pow(2) +
                cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) * sin(dLon / 2).pow(2)
            val c = 2 * atan2(sqrt(a), sqrt(1 - a))
            return (r * c).toFloat()
        }
    }

    init {
        activeInstance = this
    }

    private val isStarted = AtomicBoolean(false)
    private val syncMutex = Mutex()

    private val _isMonitoringActive = MutableStateFlow(false)
    val isMonitoringActive: StateFlow<Boolean> = _isMonitoringActive.asStateFlow()

    private val _isSyncing = MutableStateFlow(false)
    val isSyncing: StateFlow<Boolean> = _isSyncing.asStateFlow()

    private val _lastSyncMessage = MutableStateFlow("")
    val lastSyncMessage: StateFlow<String> = _lastSyncMessage.asStateFlow()

    private val _lastSyncedAt = MutableStateFlow(0L)
    val lastSyncedAt: StateFlow<Long> = _lastSyncedAt.asStateFlow()

    private val _isNetworkOnline = MutableStateFlow(true)
    val isNetworkOnline: StateFlow<Boolean> = _isNetworkOnline.asStateFlow()

    val recentEventsFlow: Flow<List<TimelineEventEntity>> = dao.observeRecentEvents(180)
    val recentLocationsFlow: Flow<List<LocationPointEntity>> = dao.observeRecentLocations(320)
    val recentSnapshotsFlow: Flow<List<DeviceSnapshotEntity>> = dao.observeRecentSnapshots(80)

    val pendingTotalCountFlow: Flow<Int> = combine(
        dao.observePendingEventsCount(),
        dao.observePendingLocationsCount(),
        dao.observePendingSnapshotsCount()
    ) { e, l, s -> e + l + s }

    val vaultUiSummaryFlow: Flow<VaultUiSummary> = combine(
        _isMonitoringActive,
        _isSyncing,
        _isNetworkOnline,
        webSocketRepository.connectionState,
        pendingTotalCountFlow,
        dao.observeTotalEventsCount(),
        dao.observeTotalLocationsCount(),
        _lastSyncedAt,
        _lastSyncMessage
    ) { values ->
        VaultUiSummary(
            isMonitoringActive = values[0] as Boolean,
            isSyncing = values[1] as Boolean,
            isOnline = values[2] as Boolean,
            isBridgeConnected = (values[3] as SessionState.ConnectionState) == SessionState.ConnectionState.CONNECTED,
            pendingCount = values[4] as Int,
            totalEvents = values[5] as Int,
            totalLocations = values[6] as Int,
            lastSyncAt = values[7] as Long,
            lastSyncMessage = values[8] as String
        )
    }

    // Deduplication & change detection state
    @Volatile private var lastBatteryPct: Int = -1
    @Volatile private var lastChargingState: Boolean? = null
    @Volatile private var lastNetworkConnected: Boolean? = null
    @Volatile private var lastNetworkTransport: String = ""
    @Volatile private var lastWifiSsid: String = ""
    @Volatile private var lastPowerSaveMode: Boolean? = null
    @Volatile private var lastRecordedLocation: LocationPointEntity? = null
    @Volatile private var lastAppLaunchPkg: String = ""
    @Volatile private var lastAppLaunchMs: Long = 0L

    private val dnsDedupMap = ConcurrentHashMap<String, Long>()
    private var locationListener: LocationListener? = null
    private var fusedCallback: com.google.android.gms.location.LocationCallback? = null
    private var networkCallback: ConnectivityManager.NetworkCallback? = null
    private var powerReceiver: BroadcastReceiver? = null
    private var heartbeatJob: Job? = null
    private var wsReconnectObserverJob: Job? = null

    fun startAlwaysOnMonitoring() {
        if (!isStarted.compareAndSet(false, true)) return
        _isMonitoringActive.value = true

        scope.launch(Dispatchers.IO) {
            try {
                lastRecordedLocation = dao.getLatestLocationPoint()
                val wm = dao.getWatermark()
                if (wm != null) {
                    _lastSyncedAt.value = wm.lastSuccessfulSyncAt
                }
                // Run initial 20-day expiry prune safely
                pruneExpiredSyncedInternal()
            } catch (t: Throwable) {
                Log.w(TAG, "Vault init DB preload failed: ${t.message}")
            }

            runCatching { capturePowerAndNetworkSnapshot(reason = "BRIDGE_ACTIVE", forceEvent = true) }
            runCatching { startPassiveAndAdaptiveLocationCollector() }
            runCatching { registerPowerAndBatteryReceiver() }
            runCatching { registerConnectivityObserver() }
            runCatching { startHeartbeatLoop() }
            runCatching { startReconnectSyncObserver() }
        }
    }

    private fun startReconnectSyncObserver() {
        wsReconnectObserverJob?.cancel()
        wsReconnectObserverJob = scope.launch(Dispatchers.IO) {
            var previousState: SessionState.ConnectionState? = null
            webSocketRepository.connectionState.collect { state ->
                val becameConnected =
                    state == SessionState.ConnectionState.CONNECTED &&
                        previousState != SessionState.ConnectionState.CONNECTED
                previousState = state
                if (becameConnected) {
                    delay(1400L)
                    if (webSocketRepository.connectionState.value == SessionState.ConnectionState.CONNECTED) {
                        syncPendingBatchesInternal(manual = false)
                    }
                }
            }
        }
    }

    private fun startHeartbeatLoop() {
        heartbeatJob?.cancel()
        heartbeatJob = scope.launch(Dispatchers.IO) {
            while (isActive) {
                delay(HEARTBEAT_SNAPSHOT_MS)
                try {
                    capturePowerAndNetworkSnapshot(reason = "HEARTBEAT_5M", forceEvent = false)
                    pollRecentForegroundAppFallback()
                } catch (t: Throwable) {
                    Log.w(TAG, "Heartbeat capture error: ${t.message}")
                }
            }
        }
    }

    private fun registerPowerAndBatteryReceiver() {
        if (powerReceiver != null) return
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(ctx: Context?, intent: Intent?) {
                val action = intent?.action ?: return
                scope.launch(Dispatchers.IO) {
                    when (action) {
                        Intent.ACTION_POWER_CONNECTED ->
                            capturePowerAndNetworkSnapshot("POWER_CONNECTED", forceEvent = true)
                        Intent.ACTION_POWER_DISCONNECTED ->
                            capturePowerAndNetworkSnapshot("POWER_DISCONNECTED", forceEvent = true)
                        PowerManager.ACTION_POWER_SAVE_MODE_CHANGED ->
                            capturePowerAndNetworkSnapshot("POWER_SAVE_CHANGED", forceEvent = true)
                        Intent.ACTION_BATTERY_CHANGED -> {
                            val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
                            val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, 100).coerceAtLeast(1)
                            val pct = if (level >= 0) (level * 100) / scale else -1
                            val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
                            val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                                status == BatteryManager.BATTERY_STATUS_FULL
                            val pctDelta = if (lastBatteryPct < 0 || pct < 0) 99 else kotlin.math.abs(pct - lastBatteryPct)
                            val chargeChanged = lastChargingState != null && lastChargingState != charging
                            if (pctDelta >= 3 || chargeChanged) {
                                capturePowerAndNetworkSnapshot(
                                    reason = if (chargeChanged) "CHARGING_STATE" else "BATTERY_STEP",
                                    forceEvent = true
                                )
                            }
                        }
                    }
                }
            }
        }
        powerReceiver = receiver
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_BATTERY_CHANGED)
            addAction(Intent.ACTION_POWER_CONNECTED)
            addAction(Intent.ACTION_POWER_DISCONNECTED)
            addAction(PowerManager.ACTION_POWER_SAVE_MODE_CHANGED)
        }
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                context.registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
            } else {
                context.registerReceiver(receiver, filter)
            }
        } catch (t: Throwable) {
            Log.w(TAG, "Failed registering battery receiver: ${t.message}")
        }
    }

    private fun registerConnectivityObserver() {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return
        if (networkCallback != null) return

        val callback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                _isNetworkOnline.value = true
                scope.launch(Dispatchers.IO) {
                    delay(350L)
                    capturePowerAndNetworkSnapshot("NETWORK_ONLINE", forceEvent = true)
                }
            }

            override fun onLost(network: Network) {
                scope.launch(Dispatchers.IO) {
                    delay(450L)
                    val stillConnected = isAnyInternetNetworkActive(cm)
                    _isNetworkOnline.value = stillConnected
                    capturePowerAndNetworkSnapshot(
                        reason = if (stillConnected) "NETWORK_HANDOFF" else "NETWORK_OFFLINE",
                        forceEvent = true
                    )
                }
            }

            override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) {
                val online = caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                _isNetworkOnline.value = online
                val transport = when {
                    caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "WIFI"
                    caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "CELLULAR"
                    caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "ETHERNET"
                    else -> "OTHER"
                }
                if (transport != lastNetworkTransport) {
                    scope.launch(Dispatchers.IO) {
                        capturePowerAndNetworkSnapshot("TRANSPORT_$transport", forceEvent = true)
                    }
                }
            }
        }
        networkCallback = callback
        try {
            val req = NetworkRequest.Builder()
                .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                .build()
            cm.registerNetworkCallback(req, callback)
            _isNetworkOnline.value = isAnyInternetNetworkActive(cm)
        } catch (t: Throwable) {
            Log.w(TAG, "Failed registering ConnectivityManager callback: ${t.message}")
        }
    }

    private fun isAnyInternetNetworkActive(cm: ConnectivityManager): Boolean {
        val net = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(net) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    @SuppressLint("MissingPermission")
    private fun startPassiveAndAdaptiveLocationCollector() {
        val hasFine = runCatching {
            ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        }.getOrDefault(false)
        val hasCoarse = runCatching {
            ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        }.getOrDefault(false)
        if (!hasFine && !hasCoarse) {
            Log.i(TAG, "Location permission not granted yet; passive vault GPS collector deferred until granted.")
            return
        }

        // Seed from last known fix immediately so we have an origin
        try {
            val lm = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager
            if (lm != null) {
                val seedLoc = listOf(
                    LocationManager.GPS_PROVIDER,
                    LocationManager.NETWORK_PROVIDER,
                    LocationManager.PASSIVE_PROVIDER
                ).mapNotNull { prov ->
                    try { lm.getLastKnownLocation(prov) } catch (_: Throwable) { null }
                }.maxByOrNull { it.time }
                if (seedLoc != null) {
                    scope.launch(Dispatchers.IO) {
                        recordAndroidLocation(seedLoc, source = "CACHED_SEED")
                    }
                }

                val listener = object : LocationListener {
                    override fun onLocationChanged(location: Location) {
                        scope.launch(Dispatchers.IO) {
                            recordAndroidLocation(location, source = location.provider ?: "gps")
                        }
                    }
                    @Deprecated("Deprecated in Java")
                    override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
                    override fun onProviderEnabled(provider: String) {}
                    override fun onProviderDisabled(provider: String) {}
                }
                locationListener = listener

                android.os.Handler(Looper.getMainLooper()).post {
                    try {
                        if (lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                            lm.requestLocationUpdates(
                                LocationManager.GPS_PROVIDER,
                                GPS_MIN_TIME_MS,
                                GPS_MIN_DISTANCE_M,
                                listener,
                                Looper.getMainLooper()
                            )
                        }
                        if (lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                            lm.requestLocationUpdates(
                                LocationManager.NETWORK_PROVIDER,
                                GPS_MIN_TIME_MS,
                                GPS_MIN_DISTANCE_M,
                                listener,
                                Looper.getMainLooper()
                            )
                        }
                        if (lm.allProviders.contains(LocationManager.PASSIVE_PROVIDER)) {
                            lm.requestLocationUpdates(
                                LocationManager.PASSIVE_PROVIDER,
                                GPS_MIN_TIME_MS,
                                GPS_MIN_DISTANCE_M,
                                listener,
                                Looper.getMainLooper()
                            )
                        }
                    } catch (t: Throwable) {
                        Log.w(TAG, "LocationManager updates skipped: ${t.message}")
                    }
                }
            }
        } catch (t: Throwable) {
            Log.w(TAG, "LocationManager setup error: ${t.message}")
        }

        // Also subscribe via FusedLocationProviderClient (Balanced Power)
        try {
            val fused = com.google.android.gms.location.LocationServices.getFusedLocationProviderClient(context)
            val req = com.google.android.gms.location.LocationRequest.Builder(
                com.google.android.gms.location.Priority.PRIORITY_BALANCED_POWER_ACCURACY,
                45_000L
            )
                .setMinUpdateIntervalMillis(20_000L)
                .setMinUpdateDistanceMeters(GPS_MIN_DISTANCE_M)
                .build()
            val cb = object : com.google.android.gms.location.LocationCallback() {
                override fun onLocationResult(res: com.google.android.gms.location.LocationResult) {
                    val last = res.lastLocation ?: return
                    scope.launch(Dispatchers.IO) {
                        recordAndroidLocation(last, source = "fused")
                    }
                }
            }
            fusedCallback = cb
            android.os.Handler(Looper.getMainLooper()).post {
                try {
                    fused.requestLocationUpdates(req, cb, Looper.getMainLooper())
                } catch (_: Throwable) {}
            }
        } catch (_: Throwable) {}
    }

    /**
     * Called when location updates arrive from the live GPS tracker or background listener.
     */
    fun recordCoordinatesFromBridge(
        latitude: Double,
        longitude: Double,
        altitude: Double = 0.0,
        accuracyMeters: Float = 0f,
        speedMps: Float = 0f,
        bearingDegrees: Float = 0f,
        provider: String = "bridge",
        timestampMs: Long = System.currentTimeMillis()
    ) {
        scope.launch(Dispatchers.IO) {
            persistLocationPoint(
                latitude = latitude,
                longitude = longitude,
                altitude = altitude,
                accuracyMeters = accuracyMeters,
                speedMps = speedMps,
                bearingDegrees = bearingDegrees,
                provider = provider,
                timestampMs = timestampMs
            )
        }
    }

    private suspend fun recordAndroidLocation(location: Location, source: String) {
        persistLocationPoint(
            latitude = location.latitude,
            longitude = location.longitude,
            altitude = if (location.hasAltitude()) location.altitude else 0.0,
            accuracyMeters = if (location.hasAccuracy()) location.accuracy else 0f,
            speedMps = if (location.hasSpeed()) location.speed else 0f,
            bearingDegrees = if (location.hasBearing()) location.bearing else 0f,
            provider = location.provider ?: source,
            timestampMs = if (location.time > 0L) location.time else System.currentTimeMillis()
        )
    }

    private suspend fun persistLocationPoint(
        latitude: Double,
        longitude: Double,
        altitude: Double,
        accuracyMeters: Float,
        speedMps: Float,
        bearingDegrees: Float,
        provider: String,
        timestampMs: Long
    ) {
        if (latitude == 0.0 && longitude == 0.0) return
        val prev = lastRecordedLocation
        val now = if (timestampMs > 0L) timestampMs else System.currentTimeMillis()
        val distMeters = if (prev != null) {
            haversineMeters(prev.latitude, prev.longitude, latitude, longitude)
        } else 0f

        // Filter noisy stationary jitter (<8m within 20s and low speed)
        if (prev != null && distMeters < 8f && (now - prev.timestamp) < 20_000L && speedMps < 1.2f) {
            return
        }
        // Avoid identical timestamp duplicates from multiple providers
        if (prev != null && kotlin.math.abs(now - prev.timestamp) < 3_000L && distMeters < 5f) {
            return
        }

        val batteryPct = readBatteryPercent()
        val transport = lastNetworkTransport.ifBlank { if (_isNetworkOnline.value) "ONLINE" else "OFFLINE" }
        val point = LocationPointEntity(
            id = "loc_${now}_${UUID.randomUUID().toString().take(6)}",
            timestamp = now,
            latitude = latitude,
            longitude = longitude,
            altitude = altitude,
            accuracyMeters = accuracyMeters,
            speedMps = speedMps,
            bearingDegrees = bearingDegrees,
            provider = provider,
            batteryPercent = batteryPct,
            networkTransport = transport,
            distanceFromPrevMeters = distMeters,
            syncStatus = VaultSyncStatus.PENDING
        )
        dao.insertLocationPoint(point)
        lastRecordedLocation = point

        // Add timeline breadcrumb when first fix, movement >= 35m, or > 5 minutes since previous point
        val isSignificantMove = prev == null || distMeters >= 35f || (now - prev.timestamp) >= 5 * 60_000L
        if (isSignificantMove) {
            val speedKmh = speedMps * 3.6f
            val moveStr = if (prev == null) "Initial location fix" else String.format(java.util.Locale.US, "Moved +%.0fm", distMeters)
            val meta = JSONObject().apply {
                put("latitude", latitude)
                put("longitude", longitude)
                put("accuracyMeters", accuracyMeters.toDouble())
                put("speedKmh", speedKmh.toDouble())
                put("provider", provider)
                put("distanceMeters", distMeters.toDouble())
                put("online", _isNetworkOnline.value)
            }
            dao.insertEvent(
                TimelineEventEntity(
                    id = "evt_loc_${now}_${UUID.randomUUID().toString().take(5)}",
                    timestamp = now,
                    category = VaultCategory.LOCATION,
                    subType = if (prev == null) "GPS_ORIGIN" else "GPS_MOVEMENT",
                    title = String.format(java.util.Locale.US, "GPS: %.5f, %.5f", latitude, longitude),
                    detail = "$moveStr • ±${accuracyMeters.toInt()}m (${provider.uppercase()}) • ${String.format(java.util.Locale.US, "%.1f km/h", speedKmh)}",
                    severity = "INFO",
                    metadataJson = meta.toString(),
                    syncStatus = VaultSyncStatus.PENDING
                )
            )
        }
    }

    private fun readBatteryPercent(): Int {
        return try {
            val bm = context.getSystemService(Context.BATTERY_SERVICE) as? BatteryManager
            bm?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)?.coerceIn(0, 100) ?: -1
        } catch (_: Throwable) {
            -1
        }
    }

    private suspend fun capturePowerAndNetworkSnapshot(reason: String, forceEvent: Boolean) {
        try {
            val now = System.currentTimeMillis()
            val net = try {
                networkTelemetryManager.getTelemetry()
            } catch (_: Throwable) {
                null
            }
            val bm = context.getSystemService(Context.BATTERY_SERVICE) as? BatteryManager
            val batteryIntent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val rawLevel = batteryIntent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scale = (batteryIntent?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100).coerceAtLeast(1)
            val battPct = if (rawLevel >= 0) (rawLevel * 100) / scale else (bm?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) ?: -1)
            val tempTenths = batteryIntent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0
            val battTempC = tempTenths / 10f
            val status = batteryIntent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
            val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL || (bm?.isCharging == true)

            val pm = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
            val isInteractive = pm?.isInteractive ?: true
            val isPowerSave = pm?.isPowerSaveMode ?: false

            val netConnected = net?.isConnected ?: _isNetworkOnline.value
            val transport = net?.activeTransport ?: if (netConnected) "ONLINE" else "OFFLINE"
            val wifiSsid = net?.wifi?.ssid?.takeIf { it.isNotBlank() && it != "<unknown ssid>" } ?: ""
            val wifiRssi = net?.wifi?.rssiDbm ?: 0
            val cellularType = net?.cellular?.networkType ?: ""
            val fgPkg = queryForegroundPackageQuick()

            _isNetworkOnline.value = netConnected

            val snap = DeviceSnapshotEntity(
                id = "snap_${now}_${UUID.randomUUID().toString().take(5)}",
                timestamp = now,
                batteryPercent = battPct,
                isCharging = isCharging,
                batteryTempC = battTempC,
                networkConnected = netConnected,
                networkTransport = transport,
                wifiSsid = wifiSsid,
                wifiRssiDbm = wifiRssi,
                cellularType = cellularType,
                foregroundPackage = fgPkg,
                isInteractive = isInteractive,
                syncStatus = VaultSyncStatus.PENDING
            )
            dao.insertDeviceSnapshot(snap)

            val networkChanged =
                (lastNetworkConnected != null && lastNetworkConnected != netConnected) ||
                    (lastNetworkTransport.isNotEmpty() && lastNetworkTransport != transport) ||
                    (wifiSsid.isNotEmpty() && lastWifiSsid != wifiSsid)
            val powerChanged =
                (lastBatteryPct >= 0 && kotlin.math.abs(battPct - lastBatteryPct) >= 5) ||
                    (lastChargingState != null && lastChargingState != isCharging) ||
                    (lastPowerSaveMode != null && lastPowerSaveMode != isPowerSave)

            if (forceEvent || networkChanged) {
                if (lastNetworkConnected != netConnected || reason == "NETWORK_OFFLINE" || reason == "NETWORK_ONLINE" || reason.startsWith("TRANSPORT_") || networkChanged) {
                    val netSubType = if (!netConnected) "NETWORK_OFFLINE" else if (lastNetworkConnected == false) "NETWORK_ONLINE" else "NETWORK_CHANGE"
                    val title = when (netSubType) {
                        "NETWORK_OFFLINE" -> "Internet Offline (Recording Locally)"
                        "NETWORK_ONLINE" -> "Internet Restored ($transport)"
                        else -> "Network State: $transport"
                    }
                    val detailParts = buildList {
                        if (wifiSsid.isNotEmpty()) add("Wi-Fi: $wifiSsid (${wifiRssi} dBm)")
                        if (cellularType.isNotEmpty()) add("Cell: $cellularType")
                        add("Battery: $battPct%${if (isCharging) " ⚡" else ""}")
                    }
                    dao.insertEvent(
                        TimelineEventEntity(
                            id = "evt_net_${now}_${UUID.randomUUID().toString().take(5)}",
                            timestamp = now,
                            category = VaultCategory.NETWORK,
                            subType = netSubType,
                            title = title,
                            detail = detailParts.joinToString(" • "),
                            severity = if (!netConnected) "WARN" else "INFO",
                            metadataJson = JSONObject().apply {
                                put("connected", netConnected)
                                put("transport", transport)
                                put("wifiSsid", wifiSsid)
                                put("wifiRssiDbm", wifiRssi)
                                put("cellularType", cellularType)
                                put("reason", reason)
                            }.toString(),
                            syncStatus = VaultSyncStatus.PENDING
                        )
                    )
                }
            }

            if (forceEvent || powerChanged) {
                if (reason == "POWER_CONNECTED" || reason == "POWER_DISCONNECTED" || reason == "POWER_SAVE_CHANGED" || powerChanged || reason == "BRIDGE_ACTIVE") {
                    val pwrSub = if (reason == "POWER_CONNECTED" || reason == "POWER_DISCONNECTED") reason else "BATTERY_POWER"
                    val title = when {
                        reason == "POWER_CONNECTED" -> "Charger Connected ($battPct%)"
                        reason == "POWER_DISCONNECTED" -> "Charger Unplugged ($battPct%)"
                        isPowerSave -> "Battery Saver ON ($battPct%)"
                        else -> "Battery ${battPct}%${if (isCharging) " (Charging)" else ""}"
                    }
                    dao.insertEvent(
                        TimelineEventEntity(
                            id = "evt_pwr_${now}_${UUID.randomUUID().toString().take(5)}",
                            timestamp = now,
                            category = VaultCategory.POWER,
                            subType = pwrSub,
                            title = title,
                            detail = String.format(java.util.Locale.US, "Temp %.1f°C • Net: %s • Reason: %s", battTempC, transport, reason),
                            severity = if (battPct in 1..15 && !isCharging) "WARN" else "INFO",
                            metadataJson = JSONObject().apply {
                                put("batteryPercent", battPct)
                                put("isCharging", isCharging)
                                put("batteryTempC", battTempC.toDouble())
                                put("powerSave", isPowerSave)
                                put("reason", reason)
                            }.toString(),
                            syncStatus = VaultSyncStatus.PENDING
                        )
                    )
                }
            }

            lastBatteryPct = battPct
            lastChargingState = isCharging
            lastNetworkConnected = netConnected
            lastNetworkTransport = transport
            lastWifiSsid = wifiSsid
            lastPowerSaveMode = isPowerSave
        } catch (t: Throwable) {
            Log.w(TAG, "capturePowerAndNetworkSnapshot error: ${t.message}")
        }
    }

    private fun queryForegroundPackageQuick(): String {
        return try {
            val usm = context.getSystemService(Context.USAGE_STATS_SERVICE) as? UsageStatsManager ?: return ""
            val end = System.currentTimeMillis()
            val events = usm.queryEvents(end - 30_000L, end)
            val evt = UsageEvents.Event()
            var lastPkg = ""
            while (events.hasNextEvent()) {
                events.getNextEvent(evt)
                @Suppress("DEPRECATION")
                if (evt.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND || evt.eventType == 1) {
                    lastPkg = evt.packageName ?: lastPkg
                }
            }
            lastPkg
        } catch (_: Throwable) {
            ""
        }
    }

    private suspend fun pollRecentForegroundAppFallback() {
        val pkg = queryForegroundPackageQuick()
        if (pkg.isNotBlank() && pkg != context.packageName && pkg != lastAppLaunchPkg) {
            val label = resolveAppLabel(pkg)
            recordAppLaunch(pkg, label, source = "USAGE_POLL")
        }
    }

    private fun resolveAppLabel(packageName: String): String {
        return try {
            val pm = context.packageManager
            val ai = pm.getApplicationInfo(packageName, 0)
            pm.getApplicationLabel(ai).toString()
        } catch (_: Throwable) {
            packageName.substringAfterLast('.')
        }
    }

    // =========================================================================
    // Public Collector Hooks (App Launches, Unlocks, Notifications, DNS/Blocks)
    // =========================================================================

    fun recordAppLaunch(packageName: String, appName: String = "", source: String = "ACCESSIBILITY") {
        val pkg = packageName.trim()
        if (pkg.isEmpty() || pkg == context.packageName || pkg == "com.android.systemui") return
        val now = System.currentTimeMillis()
        if (pkg == lastAppLaunchPkg && (now - lastAppLaunchMs) < 5_000L) return
        lastAppLaunchPkg = pkg
        lastAppLaunchMs = now

        scope.launch(Dispatchers.IO) {
            val label = appName.ifBlank { resolveAppLabel(pkg) }
            dao.insertEvent(
                TimelineEventEntity(
                    id = "evt_app_${now}_${UUID.randomUUID().toString().take(5)}",
                    timestamp = now,
                    category = VaultCategory.APP,
                    subType = "APP_LAUNCH",
                    title = "Opened $label",
                    detail = "$pkg • via $source",
                    packageName = pkg,
                    severity = "INFO",
                    metadataJson = JSONObject().apply {
                        put("appName", label)
                        put("packageName", pkg)
                        put("source", source)
                    }.toString(),
                    syncStatus = VaultSyncStatus.PENDING
                )
            )
        }
    }

    fun recordAppGuardEvent(eventType: String, packageName: String, appName: String, details: String) {
        val now = System.currentTimeMillis()
        scope.launch(Dispatchers.IO) {
            val sev = if (eventType == "BLOCKED_LAUNCH" || eventType == "UNINSTALLED") "BLOCKED" else "INFO"
            dao.insertEvent(
                TimelineEventEntity(
                    id = "evt_guard_${now}_${UUID.randomUUID().toString().take(5)}",
                    timestamp = now,
                    category = VaultCategory.APP,
                    subType = eventType,
                    title = "$eventType: $appName",
                    detail = "$packageName • $details",
                    packageName = packageName,
                    severity = sev,
                    metadataJson = JSONObject().apply {
                        put("eventType", eventType)
                        put("appName", appName)
                        put("packageName", packageName)
                    }.toString(),
                    syncStatus = VaultSyncStatus.PENDING
                )
            )
        }
    }

    fun recordUnlockEvent(
        eventType: String,
        fgPackage: String,
        fgAppName: String,
        batteryPercent: Int,
        details: String
    ) {
        val now = System.currentTimeMillis()
        scope.launch(Dispatchers.IO) {
            val title = when (eventType) {
                "DEVICE_UNLOCKED" -> "Device Unlocked"
                "SCREEN_ON" -> "Screen Powered On"
                "SCREEN_OFF" -> "Screen Locked / Off"
                "INTRUDER_SNAP" -> "Security Intruder Snap"
                else -> eventType
            }
            dao.insertEvent(
                TimelineEventEntity(
                    id = "evt_ul_${now}_${UUID.randomUUID().toString().take(5)}",
                    timestamp = now,
                    category = VaultCategory.UNLOCK,
                    subType = eventType,
                    title = title,
                    detail = "$details • App: $fgAppName • Battery: $batteryPercent%",
                    packageName = fgPackage,
                    severity = if (eventType == "INTRUDER_SNAP") "ALERT" else "INFO",
                    metadataJson = JSONObject().apply {
                        put("eventType", eventType)
                        put("foregroundApp", fgAppName)
                        put("batteryPercent", batteryPercent)
                    }.toString(),
                    syncStatus = VaultSyncStatus.PENDING
                )
            )
        }
    }

    fun recordNotificationEvent(
        packageName: String,
        appName: String,
        title: String,
        text: String,
        postTime: Long,
        matchedKeywords: List<String> = emptyList()
    ) {
        val ts = if (postTime > 0L) postTime else System.currentTimeMillis()
        scope.launch(Dispatchers.IO) {
            val cleanTitle = title.ifBlank { appName }
            val detail = buildString {
                if (text.isNotBlank()) append(text.take(240))
                if (matchedKeywords.isNotEmpty()) {
                    if (isNotEmpty()) append(" • ")
                    append("Keywords: ${matchedKeywords.joinToString(", ")}")
                }
            }.ifBlank { packageName }

            dao.insertEvent(
                TimelineEventEntity(
                    id = "evt_nf_${ts}_${UUID.randomUUID().toString().take(5)}",
                    timestamp = ts,
                    category = VaultCategory.NOTIFICATION,
                    subType = if (matchedKeywords.isNotEmpty()) "NOTIFICATION_KEYWORD_MATCH" else "NOTIFICATION",
                    title = "$appName: $cleanTitle".take(140),
                    detail = detail,
                    packageName = packageName,
                    severity = if (matchedKeywords.isNotEmpty()) "ALERT" else "INFO",
                    metadataJson = JSONObject().apply {
                        put("appName", appName)
                        put("title", title)
                        put("matchedKeywords", JSONArray(matchedKeywords))
                    }.toString(),
                    syncStatus = VaultSyncStatus.PENDING
                )
            )
        }
    }

    fun recordDnsEvent(
        domain: String,
        action: String, // "BLOCKED" or "ALLOWED"
        reason: String,
        packageName: String = "",
        queryType: String = "DNS_QUERY"
    ) {
        val cleanDomain = domain.trim().lowercase()
        if (cleanDomain.isEmpty()) return
        val now = System.currentTimeMillis()
        val isBlocked = action.equals("BLOCKED", ignoreCase = true)
        val dedupKey = "$action|$cleanDomain|$packageName"
        val dedupWindow = if (isBlocked) 1_000L else 8_000L
        val lastMs = dnsDedupMap[dedupKey] ?: 0L
        if (now - lastMs < dedupWindow) return
        dnsDedupMap[dedupKey] = now
        if (dnsDedupMap.size > 200) {
            dnsDedupMap.entries.removeIf { (now - it.value) > 45_000L }
            if (dnsDedupMap.size > 220) {
                val it = dnsDedupMap.keys.iterator()
                var drop = dnsDedupMap.size - 160
                while (it.hasNext() && drop > 0) {
                    it.next(); it.remove(); drop--
                }
            }
        }

        scope.launch(Dispatchers.IO) {
            val appLabel = if (packageName.isNotBlank()) resolveAppLabel(packageName) else "System"
            dao.insertEvent(
                TimelineEventEntity(
                    id = "evt_dns_${now}_${UUID.randomUUID().toString().take(5)}",
                    timestamp = now,
                    category = VaultCategory.DNS,
                    subType = if (isBlocked) "DNS_BLOCKED" else "DNS_QUERY",
                    title = if (isBlocked) "Blocked: $cleanDomain" else "DNS Query: $cleanDomain",
                    detail = "$reason • App: $appLabel ($queryType)",
                    packageName = packageName,
                    domain = cleanDomain,
                    severity = if (isBlocked) "BLOCKED" else "INFO",
                    metadataJson = JSONObject().apply {
                        put("domain", cleanDomain)
                        put("action", if (isBlocked) "BLOCKED" else "ALLOWED")
                        put("reason", reason)
                        put("queryType", queryType)
                        put("packageName", packageName)
                    }.toString(),
                    syncStatus = VaultSyncStatus.PENDING
                )
            )
        }
    }

    fun recordAdultShieldEvent(
        channel: String,
        target: String,
        reason: String,
        packageName: String = "",
        actionTaken: String = "KICK_BACK_AND_BLOCK_SCREEN"
    ) {
        val cleanTarget = target.trim()
        if (cleanTarget.isEmpty()) return
        val now = System.currentTimeMillis()
        val dedupKey = "ADULT_SHIELD|$channel|$cleanTarget|$packageName"
        val lastMs = dnsDedupMap[dedupKey] ?: 0L
        if (now - lastMs < 1_200L) return
        dnsDedupMap[dedupKey] = now

        scope.launch(Dispatchers.IO) {
            val appLabel = if (packageName.isNotBlank()) resolveAppLabel(packageName) else "System"
            val vaultCategory = if (channel == "APP_APK" || channel == "BYPASS_ATTEMPT" || channel == "QUARANTINE") {
                VaultCategory.APP
            } else {
                VaultCategory.DNS
            }
            dao.insertEvent(
                TimelineEventEntity(
                    id = "evt_as_${now}_${UUID.randomUUID().toString().take(5)}",
                    timestamp = now,
                    category = vaultCategory,
                    subType = "ADULT_SHIELD_$channel",
                    title = "Adult Shield ($channel): ${cleanTarget.take(90)}",
                    detail = "$reason • Action: $actionTaken • App: $appLabel",
                    packageName = packageName,
                    domain = if (vaultCategory == VaultCategory.DNS) cleanTarget.take(120) else "",
                    severity = "BLOCKED",
                    metadataJson = JSONObject().apply {
                        put("channel", channel)
                        put("target", cleanTarget)
                        put("reason", reason)
                        put("actionTaken", actionTaken)
                        put("packageName", packageName)
                    }.toString(),
                    syncStatus = VaultSyncStatus.PENDING
                )
            )
        }
    }

    // =========================================================================
    // Reconnect Auto-Push Batcher & 20-Day Post-Sync Retention Engine
    // =========================================================================

    fun triggerManualSyncAsync() {
        scope.launch(Dispatchers.IO) {
            syncPendingBatchesInternal(manual = true)
        }
    }

    suspend fun syncPendingBatchesInternal(manual: Boolean = false): JSONObject = syncMutex.withLock {
        val nowAttempt = System.currentTimeMillis()
        val isWsConnected = webSocketRepository.connectionState.value == SessionState.ConnectionState.CONNECTED
        if (!isWsConnected) {
            val pending = dao.countPendingEvents() + dao.countPendingLocations() + dao.countPendingSnapshots()
            _lastSyncMessage.value = "Bridge offline ($pending queued locally)"
            return JSONObject().apply {
                put("success", false)
                put("connected", false)
                put("pendingCount", pending)
                put("message", "Relay/WebSocket bridge is not connected; $pending items remain queued locally.")
            }
        }

        _isSyncing.value = true
        var syncedEvents = 0
        var syncedLocations = 0
        var syncedSnapshots = 0
        var batchesPushed = 0

        try {
            while (true) {
                val evtBatch = dao.getPendingEventsBatch(50)
                val locBatch = dao.getPendingLocationsBatch(50)
                val snapBatch = dao.getPendingSnapshotsBatch(25)
                if (evtBatch.isEmpty() && locBatch.isEmpty() && snapBatch.isEmpty()) {
                    break
                }

                val syncedAt = System.currentTimeMillis()
                val expiresAt = syncedAt + RETENTION_AFTER_SYNC_MS
                val batchId = "batch_${syncedAt}_${batchesPushed + 1}"

                val payload = JSONObject().apply {
                    put("type", "TELEMETRY_BATCH_SYNC")
                    put("batchId", batchId)
                    put("timestamp", syncedAt)
                    put("manual", manual)
                    put("retentionDaysAfterSync", RETENTION_AFTER_SYNC_DAYS)
                    put("expiresAt", expiresAt)
                    put("counts", JSONObject().apply {
                        put("events", evtBatch.size)
                        put("locations", locBatch.size)
                        put("snapshots", snapBatch.size)
                    })
                    put("events", JSONArray().apply {
                        evtBatch.forEach { put(TelemetryVaultExporter.eventToJson(it)) }
                    })
                    put("locations", JSONArray().apply {
                        locBatch.forEach { put(TelemetryVaultExporter.locationToJson(it)) }
                    })
                    put("snapshots", JSONArray().apply {
                        snapBatch.forEach { put(TelemetryVaultExporter.snapshotToJson(it)) }
                    })
                }

                val sent = webSocketRepository.sendRaw(payload.toString())
                if (!sent) {
                    _lastSyncMessage.value = "Paused sync (link dropped)"
                    return JSONObject().apply {
                        put("success", false)
                        put("error", "WebSocket disconnected mid-sync after $batchesPushed batches")
                        put("syncedEvents", syncedEvents)
                        put("syncedLocations", syncedLocations)
                        put("syncedSnapshots", syncedSnapshots)
                    }
                }

                if (evtBatch.isNotEmpty()) {
                    dao.markEventsSynced(evtBatch.map { it.id }, syncedAt, expiresAt)
                    syncedEvents += evtBatch.size
                }
                if (locBatch.isNotEmpty()) {
                    dao.markLocationsSynced(locBatch.map { it.id }, syncedAt, expiresAt)
                    syncedLocations += locBatch.size
                }
                if (snapBatch.isNotEmpty()) {
                    dao.markSnapshotsSynced(snapBatch.map { it.id }, syncedAt, expiresAt)
                    syncedSnapshots += snapBatch.size
                }

                batchesPushed++
                delay(120L)
            }

            val totalBatchItems = syncedEvents + syncedLocations + syncedSnapshots
            val existingWm = dao.getWatermark() ?: SyncWatermarkEntity()
            val finalSyncedAt = System.currentTimeMillis()
            val summary = if (totalBatchItems > 0) {
                "Synced $syncedEvents events, $syncedLocations GPS pts, $syncedSnapshots snapshots (kept 20d)"
            } else {
                "All records already synced"
            }

            dao.upsertWatermark(
                existingWm.copy(
                    lastSyncAttemptAt = nowAttempt,
                    lastSuccessfulSyncAt = if (totalBatchItems > 0) finalSyncedAt else existingWm.lastSuccessfulSyncAt,
                    totalSyncedEvents = existingWm.totalSyncedEvents + syncedEvents,
                    totalSyncedLocations = existingWm.totalSyncedLocations + syncedLocations,
                    totalSyncedSnapshots = existingWm.totalSyncedSnapshots + syncedSnapshots,
                    lastSyncBatchSummary = summary
                )
            )
            if (totalBatchItems > 0) {
                _lastSyncedAt.value = finalSyncedAt
                webSocketRepository.addLog("VAULT_SYNC: $summary")
            }
            _lastSyncMessage.value = summary

            val pruned = pruneExpiredSyncedInternal()

            return JSONObject().apply {
                put("success", true)
                put("connected", true)
                put("batchesPushed", batchesPushed)
                put("syncedEvents", syncedEvents)
                put("syncedLocations", syncedLocations)
                put("syncedSnapshots", syncedSnapshots)
                put("totalSyncedInRun", totalBatchItems)
                put("prunedExpiredCount", pruned)
                put("retentionDays", RETENTION_AFTER_SYNC_DAYS)
                put("message", summary)
            }
        } finally {
            _isSyncing.value = false
        }
    }

    suspend fun pruneExpiredSyncedInternal(nowMs: Long = System.currentTimeMillis()): Int {
        val deleted = dao.pruneAllExpiredSynced(nowMs)
        val existingWm = dao.getWatermark() ?: SyncWatermarkEntity()
        dao.upsertWatermark(
            existingWm.copy(
                lastPrunedAt = nowMs,
                totalPrunedCount = existingWm.totalPrunedCount + deleted
            )
        )
        if (deleted > 0) {
            Log.i(TAG, "Pruned $deleted expired synced telemetry records (>20d post-sync).")
        }
        return deleted
    }

    suspend fun clearAllSyncedHistory(): Int {
        val deleted = dao.clearAllSynced()
        val existingWm = dao.getWatermark() ?: SyncWatermarkEntity()
        val nowMs = System.currentTimeMillis()
        dao.upsertWatermark(
            existingWm.copy(
                lastPrunedAt = nowMs,
                totalPrunedCount = existingWm.totalPrunedCount + deleted
            )
        )
        return deleted
    }

    suspend fun getSummary(): VaultCountSummary = dao.getVaultCountSummary()

    fun getStatusJson(): JSONObject = kotlinx.coroutines.runBlocking(Dispatchers.IO) {
        val s = dao.getVaultCountSummary()
        val pendingTotal = s.pendingEvents + s.pendingLocations + s.pendingSnapshots
        val syncedTotal = s.syncedEvents + s.syncedLocations + s.syncedSnapshots
        JSONObject().apply {
            put("success", true)
            put("isMonitoringActive", _isMonitoringActive.value)
            put("isNetworkOnline", _isNetworkOnline.value)
            put("isBridgeConnected", webSocketRepository.connectionState.value == SessionState.ConnectionState.CONNECTED)
            put("isSyncing", _isSyncing.value)
            put("retentionDaysAfterSync", RETENTION_AFTER_SYNC_DAYS)
            put("totalEvents", s.totalEvents)
            put("pendingEvents", s.pendingEvents)
            put("syncedEvents", s.syncedEvents)
            put("totalLocations", s.totalLocations)
            put("pendingLocations", s.pendingLocations)
            put("syncedLocations", s.syncedLocations)
            put("totalSnapshots", s.totalSnapshots)
            put("pendingSnapshots", s.pendingSnapshots)
            put("syncedSnapshots", s.syncedSnapshots)
            put("totalPendingCount", pendingTotal)
            put("totalSyncedCount", syncedTotal)
            put("oldestPendingTimestamp", s.oldestPendingTimestamp ?: 0L)
            put("earliestExpirationTimestamp", s.earliestExpiresAt ?: 0L)
            put("lastSuccessfulSyncAt", s.lastSuccessfulSyncAt)
            put("lastPrunedAt", s.lastPrunedAt)
            put("totalPrunedCount", s.totalPrunedCount)
            put("lastSyncMessage", _lastSyncMessage.value)
        }
    }

    fun queryTimelineJson(
        category: String = "",
        sinceMs: Long = 0L,
        untilMs: Long = Long.MAX_VALUE,
        searchQuery: String = "",
        pendingOnly: Boolean = false,
        limit: Int = 150,
        offset: Int = 0
    ): JSONObject = kotlinx.coroutines.runBlocking(Dispatchers.IO) {
        val cleanCat = normalizeCategory(category)
        val rows = dao.queryEvents(
            sinceMs = sinceMs,
            untilMs = untilMs,
            category = cleanCat,
            pendingOnly = pendingOnly,
            searchQuery = searchQuery.trim(),
            limit = limit.coerceIn(1, 1000),
            offset = offset.coerceAtLeast(0)
        )
        val arr = JSONArray()
        rows.forEach { arr.put(TelemetryVaultExporter.eventToJson(it)) }
        JSONObject().apply {
            put("success", true)
            put("categoryFilter", cleanCat.ifBlank { "ALL" })
            put("pendingOnly", pendingOnly)
            put("returnedCount", rows.size)
            put("events", arr)
        }
    }

    fun queryLocationPathJson(
        sinceMs: Long = 0L,
        untilMs: Long = Long.MAX_VALUE,
        pendingOnly: Boolean = false,
        limit: Int = 500
    ): JSONObject = kotlinx.coroutines.runBlocking(Dispatchers.IO) {
        val points = dao.queryLocationPathAsc(
            sinceMs = sinceMs,
            untilMs = untilMs,
            pendingOnly = pendingOnly,
            limit = limit.coerceIn(1, 2000)
        )
        TelemetryVaultExporter.buildLocationPathReportJson(points)
    }

    fun querySnapshotsJson(
        sinceMs: Long = 0L,
        untilMs: Long = Long.MAX_VALUE,
        pendingOnly: Boolean = false,
        limit: Int = 100
    ): JSONObject = kotlinx.coroutines.runBlocking(Dispatchers.IO) {
        val rows = dao.querySnapshots(
            sinceMs = sinceMs,
            untilMs = untilMs,
            pendingOnly = pendingOnly,
            limit = limit.coerceIn(1, 500)
        )
        val arr = JSONArray()
        rows.forEach { arr.put(TelemetryVaultExporter.snapshotToJson(it)) }
        JSONObject().apply {
            put("success", true)
            put("returnedCount", rows.size)
            put("snapshots", arr)
        }
    }

    fun exportVaultJson(
        format: String = "json",
        category: String = "",
        sinceMs: Long = 0L,
        untilMs: Long = Long.MAX_VALUE,
        limit: Int = 1500
    ): JSONObject = kotlinx.coroutines.runBlocking(Dispatchers.IO) {
        val cleanCat = normalizeCategory(category)
        val events = dao.queryEvents(
            sinceMs = sinceMs,
            untilMs = untilMs,
            category = cleanCat,
            pendingOnly = false,
            searchQuery = "",
            limit = limit.coerceIn(1, 3000),
            offset = 0
        )
        val points = dao.queryLocationPathAsc(
            sinceMs = sinceMs,
            untilMs = untilMs,
            pendingOnly = false,
            limit = limit.coerceIn(1, 3000)
        )
        val snapshots = dao.querySnapshots(
            sinceMs = sinceMs,
            untilMs = untilMs,
            pendingOnly = false,
            limit = 300
        )
        TelemetryVaultExporter.exportToDownloadsAndPayload(
            format = format,
            category = cleanCat,
            events = events,
            locations = points,
            snapshots = snapshots
        )
    }

    private fun normalizeCategory(raw: String): String {
        val up = raw.trim().uppercase()
        return when (up) {
            "", "ALL" -> ""
            "GPS", "LOC", "LOCATION", "PATH", "PATHS", "GPS_PATHS" -> VaultCategory.LOCATION
            "APP", "APPS", "LAUNCH", "LAUNCHES", "GUARD" -> VaultCategory.APP
            "UNLOCK", "UNLOCKS", "SCREEN", "SECURITY" -> VaultCategory.UNLOCK
            "NOTIF", "NOTIFS", "NOTIFICATION", "NOTIFICATIONS" -> VaultCategory.NOTIFICATION
            "DNS", "BLOCK", "BLOCKS", "BLOCKED", "SITES", "WEB" -> VaultCategory.DNS
            "POWER", "BATTERY", "BATT" -> VaultCategory.POWER
            "NET", "NETWORK", "WIFI", "CELL" -> VaultCategory.NETWORK
            else -> up
        }
    }

    fun stop() {
        isStarted.set(false)
        _isMonitoringActive.value = false
        heartbeatJob?.cancel()
        wsReconnectObserverJob?.cancel()
        try { powerReceiver?.let { context.unregisterReceiver(it) } } catch (_: Throwable) {}
        powerReceiver = null
        try {
            val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
            networkCallback?.let { cm?.unregisterNetworkCallback(it) }
        } catch (_: Throwable) {}
        networkCallback = null
        try {
            val lm = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager
            locationListener?.let { lm?.removeUpdates(it) }
        } catch (_: Throwable) {}
        locationListener = null
        try {
            fusedCallback?.let {
                com.google.android.gms.location.LocationServices.getFusedLocationProviderClient(context).removeLocationUpdates(it)
            }
        } catch (_: Throwable) {}
        fusedCallback = null
    }

    fun trimCaches(aggressive: Boolean = false) {
        if (aggressive) {
            dnsDedupMap.clear()
        } else {
            val now = System.currentTimeMillis()
            dnsDedupMap.entries.removeIf { (now - it.value) > 30_000L }
        }
    }
}
