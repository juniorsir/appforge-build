# Full-Screen Tablet Drag & Expandable Full-Screen HUD Mode

Fix floating HUD drag clipping on tablets, foldables, and landscape displays so the overlay moves smoothly to every screen edge, refine horizontal dragging so only short flicks trigger prompt history, and add an in-place Full-Screen Liquid Glass overlay mode.

## User Review & Critical Decisions

> [!IMPORTANT]
> The decisions below reflect your answers from our setup questions and will guide implementation once you approve.

- **Confirmed Decision 1 — Full-Display Drag Range**: Fix early drag clipping by measuring true physical display bounds, disabling restrictive overlay system-bar inset clamping (`fitInsetsTypes = 0`), and reacting live to tablet rotation or foldable screen resize events.
- **Confirmed Decision 2 — Free Drag vs. Prompt History**: Allow uninterrupted 2D dragging anywhere across the screen, reserving prompt-history recall strictly for a short, fast horizontal flick on the header (snapping the card back in place when a flick is recognized).
- **Confirmed Decision 3 — Full-Screen Overlay Mode**: Extend the single HUD window to morph seamlessly across three states — **Docked Pill**, **Floating Card**, and **Full-Screen Overlay** — while preserving Termux-safe focus, `agy_hud_` accessibility exclusion, and your live Liquid Glass theme.
- **Recommended Default — Full-Screen Controls**: Place a clean glass expand/restore toggle in the expanded HUD header (plus a Dashboard toggle button and expanded-header double-tap gesture) so full-screen mode is one tap away without crowding the collapsed pill.

---

## 1. Overview & Core Concept

- **What It Does**: Eliminates the invisible drag walls that trap the floating HUD inside a subset of tablet, foldable, or landscape screens, and introduces an optional edge-to-edge Full-Screen Liquid Glass workspace inside the same single overlay window.
- **Target Audience / Persona**: Tablet, foldable, and large-screen Android power users multitasking with Termux, browsers, chess boards, or media alongside the floating Agy HUD.
- **Key Value**: Effortless positioning of the HUD anywhere on any screen size, zero accidental gesture hijacking during long drags, and generous full-screen breathing room whenever you want to inspect snipped screenshots, read long responses, play chess autopilot, or browse media.

---

## 2. User Experience & Visual Design

### Key User Flows

1. **Full-Display Free Dragging (Tablet & Landscape)**
   - Touch and drag the HUD header (or empty card margin) smoothly from corner to corner across the full physical width and height of a tablet, foldable, or rotated screen.
   - Rotating the device or unfolding a foldable automatically recalculates screen bounds and smoothly clamps the HUD inside the new viewport so it never disappears off-screen.
   - When collapsed into a pill with Magnetic Edge Dock enabled, releasing the pill snaps it cleanly to the true far-left or far-right physical edge of the tablet display.

2. **Uninterrupted Drag vs. Short-Flick Prompt History**
   - Moving the HUD horizontally across a wide tablet screen moves the window fluidly without locking up.
   - Performing a brief, crisp horizontal flick (`< 220ms`, short travel distance) on the expanded header recalls the previous or next prompt into the input bar, displays the transient `"Prompt X/Y"` cue, and smoothly returns the card to its anchor point.

3. **Three-State In-Place Morph: Pill ↔ Floating Card ↔ Full-Screen Overlay**
   - **Floating Card → Full-Screen**: Tap the expand icon (`⤢`) in the expanded header (or double-tap the expanded header, or tap **Full Screen** on the Dashboard HUD card). The single window smoothly expands edge-to-edge with spring transition physics, remembering your previous `(x, y)` coordinates.
   - **Inside Full-Screen Mode**:
     - Safe-area padding protects the top status bar / camera cutout and bottom navigation bar / tablet taskbar.
     - Content centers neatly within a comfortable `680dp` max-width reading column so text, chess boards, approval cards, and media carousels stay well-proportioned on wide tablets.
     - The adaptive middle stage lifts its `210dp` compact height cap and expands to fill available vertical space (`weight = 1f`), anchoring the frosted input pill cleanly along the bottom safe area (lifting naturally above the keyboard when focused).
   - **Full-Screen → Floating Card**: Tap the restore icon (`⧉` PiP-return) in the header, double-tap the header, or swipe down from the top header to morph smoothly back to your saved floating position.

### Visual Identity & Theme

- **Aesthetic Direction**: Continues the existing **Apple Liquid Glass** design system across all three window states, adapting automatically to your chosen Accent Tint (`Sky Blue`, `Violet Mist`, `Mint Jade`, `Sunset Coral`), Glass Surface (`White`, `Auto`, `Smoked`), and Frost Opacity slider.
- **Surface & Geometry**:
  - *Docked Pill*: `28dp` capsule radius, compact width, magnetic edge snap.
  - *Floating Card*: `24dp` rounded glass card (`344dp` width on phones, subtly adaptive up to `380dp` on wide tablets for comfortable touch ergonomics).
  - *Full-Screen Overlay*: Edge-to-edge luminous frosted glass veil (`0dp` outer corners) with a subtle specular top refraction highlight and a centered glass content container so underlying apps softly glow through without visual clutter.
- **Interactive Feedback & Motion**: Spring lift on drag start (`1.02x`), overshoot settle on release, haptic tick on edge-dock and full-screen morph, and full respect for system Reduced Motion settings.

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1: True Display Metrics + Zero Overlay Inset Clipping**
  - *Chosen Approach*: Query live physical display dimensions from the system display service (`DisplayManager` + `maximumWindowMetrics` with safe fallback) and clear `fitInsetsTypes = 0` on the overlay window while applying our own inset-aware safe clamping.
  - *Why*: Application-scoped `currentWindowMetrics` on tablets and multi-window hosts often returns constrained or stale app bounds, causing the HUD to stop midway across the screen. Using real display metrics + live display change listening guarantees full-screen reach in portrait, landscape, split-screen, and unfolded modes.
  - *Alternatives Considered*: Relying on `resources.displayMetrics` (fails on rotation, multi-window, and unfolded foldables).

- **Decision 2: Post-Release Short-Flick Detection for Prompt History**
  - *Chosen Approach*: Let every movement past touch slop drag smoothly in real time; only classify a gesture as a prompt-history flick on finger release if total duration is short (`< 220ms`), travel is compact (`42dp..125dp`), and horizontal velocity clearly dominates vertical movement, smoothly springing the card back to its start position.
  - *Why*: Eliminates the frustrating mid-drag freeze when dragging sideways across wide tablets while preserving the hidden prompt-history gesture.
  - *Alternatives Considered*: Disabling horizontal history swipe completely (loses a useful power gesture).

- **Decision 3: Single-Window Three-State Morph for Full-Screen Mode**
  - *Chosen Approach*: Morph the existing single overlay window between Pill, Floating Card, and Full-Screen (`MATCH_PARENT × MATCH_PARENT`) instead of spawning a second Activity or dialog window.
  - *Why*: Preserves single-window architecture, keeps `agy_hud_` accessibility self-exclusion intact, avoids disrupting the active foreground app (like Termux or Chess), and maintains uninterrupted media/chess/approval state.
  - *Alternatives Considered*: Launching a transparent Activity (steals focus from Termux and interrupts background app state).

---

## 4. Technical Architecture & Data Strategy *(Technical Reference)*

### Architecture & Component Diagram

```text
┌─────────────────────────────────────────────────────────────────────────┐
│                    System Display & Window Metrics                      │
│  DisplayManager (DisplayListener) + maximumWindowMetrics + Cutout/Bars  │
└───────────────────────────────────┬─────────────────────────────────────┘
                                    │ Live Display Bounds & Safe Insets
                                    ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                       HudDragBoundsMath (Pure Logic)                    │
│  • Full-display clamp (x, y)   • Short-flick vs. Free-drag classifier   │
│  • Adaptive tablet card width  • Magnetic edge snap for wide screens    │
└───────────────────────────────────┬─────────────────────────────────────┘
                                    │
                                    ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                        Single-Window HUD Host                           │
│  HudStore (StateFlow<HudUiState>: collapsed | floating | fullScreen)    │
│                                                                         │
│  ┌──────────────────────┐  ┌──────────────────────┐  ┌───────────────┐  │
│  │  Top Header (44dp+)  │  │ Adaptive Middle Stage│  │ Bottom Input  │  │
│  │  • Free 2D drag      │  │ • Compact: <= 210dp  │  │ • Mic / Snip  │  │
│  │  • Short flick hist. │  │ • Full-Screen: flex  │  │ • Termux-safe │  │
│  │  • Full-Screen btn   │  │   centered <= 680dp  │  │   IME focus   │  │
│  │  • Collapse / Stop   │  │ • Snip/Media/Chess   │  │               │  │
│  └──────────────────────┘  └──────────────────────┘  └───────────────┘  │
└───────────────────────────────────┬─────────────────────────────────────┘
                                    │ Observed Live State
                                    ▼
┌─────────────────────────────────────────────────────────────────────────┐
│             Dashboard Hero Card & Quick Settings Tile                   │
│  • Show / Full Screen / Collapse / Hide controls synced with HudStore   │
│  • QS Tile reflects Expanded / Full / Docked / Off states               │
└─────────────────────────────────────────────────────────────────────────┘
```

### Data Model & State

- **Window Mode State (`HudUiState`)**: Add `fullScreen: Boolean = false` alongside `visible` and `collapsed` (mutually exclusive: entering `fullScreen` sets `collapsed = false`; collapsing clears `fullScreen = false`). Also support optional `fullScreen` flag in `/api/hud/state` and `/api/hud/patch` payloads for remote bridge control.
- **Saved Floating Anchor**: Remember the user's last floating `(x, y)` coordinates before entering Full-Screen mode and restore them (re-clamped to current display bounds) when returning to floating mode.
- **Pure Geometry Helpers**: Extract display clamping, adaptive tablet card width, and short-flick vs. free-drag classification into pure, unit-testable math functions so tablet/landscape/foldable edge cases are verified deterministically in JVM unit tests.

### Interactive Component & State Mapping

- **Display Change Listener**: Registers when the HUD attaches and unregisters on detach; on any screen resize, rotation, or fold/unfold, recomputes bounds, updates full-screen or floating layout dimensions, and smoothly re-clamps `(x, y)`.
- **Header & Card Margin Drag Touch Handler**: Tracks full-screen raw pointer deltas against current display bounds without blocking horizontal drags; evaluates short horizontal flicks, vertical collapse/restore flings, and double-tap expand/restore cleanly on pointer up.
- **Full-Screen Header Toggle & Dashboard Action**: Toggles `HudStore.toggleFullScreen()`, updating `WindowManager.LayoutParams` (`MATCH_PARENT` vs. floating card width, zero outer corner radius vs. `24dp` card radius, safe system-bar padding, and unconstrained middle-stage height) in one smooth transition.
- **Termux-Safe Focus Preservation**: Even in Full-Screen Overlay mode, `FLAG_NOT_FOCUSABLE` remains active at rest until the user taps the input field or approval editor, and is released immediately on Send, Restore, Collapse, or Hide.
