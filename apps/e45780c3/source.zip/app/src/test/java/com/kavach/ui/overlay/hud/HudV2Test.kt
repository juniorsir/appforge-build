package com.kavach.ui.overlay.hud

import com.kavach.accessibility.AccessibilityRepositoryImpl
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicReference

/**
 * Unit tests for Single-Window HUD v2 (HudModels, HudStore, Termux-safe focus invariant,
 * Media Carousel state, Chess Board state, Approval Gate blocking latch, Region Snip preview/attach,
 * backward-compatible payload aliases, and Accessibility self-exclusion).
 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class HudV2Test {

    private lateinit var store: HudStore
    private val broadcastEvents = mutableListOf<JSONObject>()

    @Before
    fun setUp() {
        broadcastEvents.clear()
        store = HudStore(onCommandBroadcast = { broadcastEvents.add(it) })
    }

    @Test
    fun `applyFullState sets core fields and backward-compatible aliases`() {
        val payload = JSONObject().apply {
            put("state", "WORKING")
            put("title", "Chess Co-Pilot")
            put("currentAction", "Calculating e2e4 reply...")
            put("detailedOutput", "Center control favored by +0.45")
            put("appPackage", "com.chess")
            put("progress", 65)
            put("autoHideSeconds", 10)
            put(
                "taskMap",
                JSONObject().apply {
                    put(
                        "chess",
                        JSONObject().apply {
                            put("fen", "rnbqkbnr/pppppppp/8/8/4P3/8/PPPP1PPP/RNBQKBNR b KQkq - 0 1")
                            put("playerColor", "black")
                            put("evalCp", -45)
                            put("lastMove", JSONObject().put("from", "e2").put("to", "e4"))
                            put("bestMove", "c7c5")
                            put("turnLabel", "Black to move")
                            put("autopilotState", "RUNNING")
                        }
                    )
                    put(
                        "results",
                        JSONObject().apply {
                            put(
                                "items",
                                JSONArray().apply {
                                    put(
                                        JSONObject()
                                            .put("id", "img_1")
                                            .put("kind", "image")
                                            .put("title", "Opening Book")
                                            .put("uri", "https://example.org/sicilian.png")
                                    )
                                    put(
                                        JSONObject()
                                            .put("id", "vid_1")
                                            .put("kind", "video")
                                            .put("title", "Sicilian Theory")
                                            .put("uri", "https://example.org/sicilian.mp4")
                                    )
                                }
                            )
                        }
                    )
                }
            )
            put(
                "quickActions",
                JSONArray().apply {
                    put(JSONObject().put("id", "q1").put("label", "Explain position").put("prompt", "Explain this position"))
                    put(JSONObject().put("id", "q2").put("label", "Hint"))
                    put(JSONObject().put("id", "q3").put("label", "Analyze"))
                    put(JSONObject().put("id", "q4").put("label", "Overflow Ignored"))
                }
            )
        }

        val resp = store.applyFullState(payload)
        assertTrue(resp.optBoolean("success"))
        assertEquals("WORKING", resp.optString("state"))
        assertTrue(resp.optBoolean("hasChess"))
        assertEquals(2, resp.optInt("mediaCount"))

        val st = store.currentState()
        assertTrue(st.visible)
        assertEquals(HudStatus.WORKING, st.status)
        assertEquals("Chess Co-Pilot", st.title)
        assertEquals("Calculating e2e4 reply...", st.thinkingText)
        assertEquals("Center control favored by +0.45", st.summaryText)
        assertEquals(0.65f, st.progress ?: 0f, 0.001f)
        assertTrue(st.isStopVisible)
        assertTrue(st.hasMiddleContent)

        val chess = st.chess
        assertNotNull(chess)
        assertTrue(chess!!.isBlackPerspective)
        assertEquals(-45, chess.evalCp)
        assertEquals("e2e4", chess.lastMove)
        assertEquals("c7c5", chess.bestMove)
        assertEquals("RUNNING", chess.normalizedAutopilotState)

        assertEquals(2, st.mediaItems.size)
        assertTrue(st.mediaItems[0].isImage)
        assertFalse(st.mediaItems[0].hasPlayableTransport)
        assertTrue(st.mediaItems[1].isVideo)
        assertTrue(st.mediaItems[1].hasPlayableTransport)

        // Capped at 3 screen-aware quick action chips
        assertEquals(3, st.quickActions.size)
    }

    @Test
    fun `applyPatch updates surgically without wiping untouched fields`() {
        store.applyFullState(
            JSONObject()
                .put("state", "WORKING")
                .put("title", "Media Session")
                .put("thinkingText", "Loading track...")
                .put("detailedOutput", "Playing Synthwave Mix")
                .put(
                    "mediaItems",
                    JSONArray().put(
                        JSONObject()
                            .put("id", "a1")
                            .put("kind", "audio")
                            .put("title", "Synthwave")
                            .put("uri", "https://example.org/mix.mp3")
                    )
                )
        )

        val patchRes = store.applyPatch(
            JSONObject()
                .put("appendLog", "Buffering 80%")
                .put("progress", 0.8)
                .put("mediaPlaying", true)
                .put("mediaMuted", true)
        )
        assertTrue(patchRes.optBoolean("patched"))

        val st = store.currentState()
        assertEquals("Media Session", st.title)
        assertEquals("Playing Synthwave Mix", st.summaryText)
        assertEquals("Buffering 80%", st.thinkingText)
        assertEquals(listOf("Buffering 80%"), st.logs)
        assertEquals(0.8f, st.progress ?: 0f, 0.001f)
        assertEquals(1, st.mediaItems.size)
        assertTrue(st.mediaPlaying)
        assertTrue(st.mediaMuted)
    }

    @Test
    fun `media carousel toggles only play-pause and mute-unmute plus index clamping`() {
        store.applyFullState(
            JSONObject()
                .put("state", "DONE")
                .put(
                    "mediaItems",
                    JSONArray()
                        .put(JSONObject().put("kind", "image").put("title", "Photo").put("uri", "https://example.org/1.jpg"))
                        .put(JSONObject().put("kind", "audio").put("title", "Now Playing Track").put("isNowPlaying", true))
                )
        )

        assertEquals(0, store.currentState().mediaActiveIndex)
        store.setMediaActiveIndex(5)
        assertEquals(1, store.currentState().mediaActiveIndex)
        assertTrue(store.currentState().activeMediaItem!!.isNowPlaying)
        assertTrue(store.currentState().activeMediaItem!!.hasPlayableTransport)

        assertTrue(store.toggleMediaPlayPause())
        assertTrue(store.currentState().mediaPlaying)
        assertFalse(store.toggleMediaPlayPause())
        assertFalse(store.currentState().mediaPlaying)

        assertTrue(store.toggleMediaMute())
        assertTrue(store.currentState().mediaMuted)
        assertFalse(store.toggleMediaMute())
        assertFalse(store.currentState().mediaMuted)
    }

    @Test
    fun `approval gate sets NEEDS_INPUT unblocks waiting thread and queues APPROVAL_RESPONSE`() {
        val resp = store.setApproval(
            JSONObject()
                .put("id", "apr_42")
                .put("title", "Run Shell Command")
                .put("description", "Clean temporary cache folder")
                .put("commandPreview", "rm -rf /tmp/cache")
                .put("riskLevel", "HIGH")
                .put("allowEdit", true)
        )
        assertTrue(resp.optBoolean("approvalActive"))
        assertEquals("apr_42", resp.optString("approvalId"))
        assertEquals(HudStatus.NEEDS_INPUT, store.currentState().status)
        assertFalse(store.currentState().collapsed)

        val resolvedRef = AtomicReference<HudStore.ApprovalResolution?>()
        val doneLatch = CountDownLatch(1)
        val waiter = Thread {
            resolvedRef.set(store.awaitApprovalResult("apr_42", 2000L))
            doneLatch.countDown()
        }
        waiter.start()

        val decisionRes = store.respondToApproval("EDIT", "ls -la /tmp/cache")
        assertTrue(decisionRes.optBoolean("approved"))
        assertEquals("EDIT", decisionRes.optString("decision"))
        assertTrue(doneLatch.await(1500L, TimeUnit.MILLISECONDS))

        val resolution = resolvedRef.get()
        assertNotNull(resolution)
        assertEquals("EDIT", resolution!!.decision)
        assertTrue(resolution.approved)
        assertEquals("ls -la /tmp/cache", resolution.editedCommand)
        assertNull(store.currentState().approval)
        assertFalse(store.currentState().inputFocused)

        val polled = store.pollCommands()
        assertEquals(1, polled.optInt("count"))
        val cmd = polled.getJSONArray("commands").getJSONObject(0)
        assertEquals("APPROVAL_RESPONSE", cmd.optString("action"))
        assertEquals("apr_42", cmd.optString("buttonId"))
        assertEquals("ls -la /tmp/cache", cmd.getJSONObject("payload").optString("editedCommand"))
        assertEquals("ls -la /tmp/cache", cmd.getJSONObject("payload").optString("editedText"))
    }

    @Test
    fun `Termux-safe focus invariant prevents focus when hidden collapsed or after submit and stop`() {
        // Hidden at rest -> cannot acquire focus
        store.setInputFocused(true)
        assertFalse(store.currentState().inputFocused)

        // Expanded & visible -> focus allowed on explicit tap
        store.show(collapsed = false)
        store.setInputFocused(true)
        assertTrue(store.currentState().inputFocused)

        // Collapsing in-place immediately releases focus back to Termux
        store.setCollapsed(true)
        assertFalse(store.currentState().inputFocused)
        store.setInputFocused(true)
        assertFalse(store.currentState().inputFocused)

        // Expand, focus, then submit prompt -> releases focus immediately
        store.setCollapsed(false)
        store.setInputFocused(true)
        assertTrue(store.currentState().inputFocused)

        val cmd = store.submitPrompt("check battery")
        assertNotNull(cmd)
        assertFalse(store.currentState().inputFocused)
        assertEquals(HudStatus.WORKING, store.currentState().status)
        assertEquals(1, broadcastEvents.size)

        // STOP immediately stops working state and clears focus
        store.setInputFocused(true)
        store.enqueueCommand("STOP")
        assertEquals(HudStatus.STOPPED, store.currentState().status)
        assertFalse(store.currentState().inputFocused)

        // Hide clears visibility & focus
        store.hide()
        assertFalse(store.currentState().visible)
        assertFalse(store.currentState().inputFocused)
    }

    @Test
    fun `region snip attaches thumbnail toggles inline expansion and embeds snip payload on submit`() {
        store.show(collapsed = true)
        val snip = SnippedRegionContext(
            x1 = 100,
            y1 = 220,
            x2 = 540,
            y2 = 620,
            screenWidth = 1080,
            screenHeight = 2400,
            packageName = "com.android.settings",
            nodes = listOf(
                SnippedUiNode(text = "Wi-Fi", centerX = 320, centerY = 420, clickable = true)
            ),
            screenshotBase64 = "ZmFrZV9qcGVnX2J5dGVz",
            screenshotWidth = 440,
            screenshotHeight = 400
        )

        store.attachSnip(snip)
        assertTrue(store.currentState().visible)
        assertFalse(store.currentState().collapsed)
        assertNotNull(store.currentState().attachedSnip)
        assertFalse(store.currentState().snipPreviewExpanded)
        assertTrue(store.currentState().hasMiddleContent)

        // Tap thumbnail to expand inline preview, tap again to collapse
        assertTrue(store.toggleSnipPreviewExpanded())
        assertTrue(store.currentState().snipPreviewExpanded)
        assertFalse(store.toggleSnipPreviewExpanded())
        assertFalse(store.currentState().snipPreviewExpanded)

        // Submitting with empty text still submits snip with default prompt and clears attachment
        val cmd = store.submitPrompt("")
        assertNotNull(cmd)
        assertEquals("PROMPT", cmd!!.action)
        assertTrue(cmd.text.isNotBlank())
        assertTrue(cmd.payload!!.optBoolean("hasSnip"))
        assertEquals(440, cmd.payload!!.getJSONObject("snip").optInt("screenshotWidth"))
        assertNull(store.currentState().attachedSnip)
        assertFalse(store.currentState().snipPreviewExpanded)
    }

    @Test
    fun `casual placeholders rotate without repeating previous hint`() {
        assertTrue(HudModels.CASUAL_PLACEHOLDERS.size >= 5)
        for (hint in HudModels.CASUAL_PLACEHOLDERS) {
            val next = HudModels.randomPlaceholder(previous = hint)
            assertTrue(next in HudModels.CASUAL_PLACEHOLDERS)
            assertTrue(next != hint)
        }
    }

    @Test
    fun `accessibility repository excludes all agy_hud_ prefixed overlay identifiers`() {
        val repo = AccessibilityRepositoryImpl()
        assertTrue(repo.isAgyHudIdentifier(viewId = null, contentDescription = HudModels.HUD_WINDOW_TAG))
        assertTrue(repo.isAgyHudIdentifier(viewId = "com.kavach:id/agy_hud_input", contentDescription = null))
        assertTrue(repo.isAgyHudIdentifier(viewId = null, contentDescription = "agy_hud_snip_thumbnail"))
        assertTrue(repo.isAgyHudIdentifier(viewId = null, contentDescription = "agy_hud_pointer"))
        assertFalse(repo.isAgyHudIdentifier(viewId = "com.termux:id/terminal_view", contentDescription = "Termux"))
        assertFalse(repo.isAgyHudIdentifier(viewId = "com.chess:id/board", contentDescription = "Chess Board"))
    }

    @Test
    fun `resolved hud palette adapts across accents glass modes and clamped frost`() {
        for (preset in HudAccentPreset.entries) {
            val light = ResolvedHudPalette.resolve(
                HudAppearanceConfig(accent = preset, surfaceMode = HudGlassMode.WHITE, frostStrength = 0.50f),
                isSystemDark = true
            )
            assertFalse(light.isDark)
            assertEquals(HudAppearanceConfig.MIN_FROST, light.frostStrength, 0.001f)
            assertEquals(preset, light.accentPreset)

            val smoked = ResolvedHudPalette.resolve(
                HudAppearanceConfig(accent = preset, surfaceMode = HudGlassMode.SMOKED, frostStrength = 1.25f),
                isSystemDark = false
            )
            assertTrue(smoked.isDark)
            assertEquals(HudAppearanceConfig.MAX_FROST, smoked.frostStrength, 0.001f)
            assertTrue(light.signature != smoked.signature)
        }

        val autoDark = ResolvedHudPalette.resolve(
            HudAppearanceConfig(surfaceMode = HudGlassMode.AUTO),
            isSystemDark = true
        )
        val autoLight = ResolvedHudPalette.resolve(
            HudAppearanceConfig(surfaceMode = HudGlassMode.AUTO),
            isSystemDark = false
        )
        assertTrue(autoDark.isDark)
        assertFalse(autoLight.isDark)
    }

    @Test
    fun `prompt history ring buffer deduplicates caps at 12 and steps bidirectionally`() {
        assertNull(store.stepPromptHistory(delta = 1))

        for (i in 1..15) {
            store.submitPrompt("prompt $i")
        }
        // Re-submitting an older prompt moves it to front without duplicating
        store.submitPrompt("prompt 10")

        val history = store.getRecentPrompts()
        assertEquals(12, history.size)
        assertEquals("prompt 10", history[0])
        assertEquals("prompt 15", history[1])

        val step1 = store.stepPromptHistory(delta = 1)
        assertNotNull(step1)
        assertEquals("prompt 10", step1!!.text)
        assertEquals(1, step1.index)
        assertEquals(12, step1.total)

        val step2 = store.stepPromptHistory(delta = 1)
        assertEquals("prompt 15", step2!!.text)
        assertEquals(2, step2.index)

        // Stepping backwards returns to index 1
        val backStep = store.stepPromptHistory(delta = -1)
        assertEquals("prompt 10", backStep!!.text)
        assertEquals(1, backStep.index)
    }

    @Test
    fun `magnetic edge dock math snaps to nearest edge and respects fling velocity`() {
        val leftSnap = HudEdgeDockMath.computeSnapTarget(
            currentX = 120,
            viewWidth = 280,
            screenWidth = 1080,
            marginPx = 24,
            velocityX = 0f
        )
        assertFalse(leftSnap.dockedRight)
        assertEquals(24, leftSnap.targetX)

        val rightSnap = HudEdgeDockMath.computeSnapTarget(
            currentX = 620,
            viewWidth = 280,
            screenWidth = 1080,
            marginPx = 24,
            velocityX = 0f
        )
        assertTrue(rightSnap.dockedRight)
        assertEquals(1080 - 280 - 24, rightSnap.targetX)

        // Strong rightward fling overrides left position
        val flingRight = HudEdgeDockMath.computeSnapTarget(
            currentX = 80,
            viewWidth = 280,
            screenWidth = 1080,
            marginPx = 24,
            velocityX = 650f
        )
        assertTrue(flingRight.dockedRight)

        // Strong leftward fling overrides right position
        val flingLeft = HudEdgeDockMath.computeSnapTarget(
            currentX = 720,
            viewWidth = 280,
            screenWidth = 1080,
            marginPx = 24,
            velocityX = -650f
        )
        assertFalse(flingLeft.dockedRight)
    }

    @Test
    fun `double shake detector ignores single jolt triggers on valid double peak and enforces cooldown`() {
        val detector = DoubleShakeDetector(
            thresholdG = 2.3f,
            minGapMs = 160L,
            maxGapMs = 680L,
            cooldownMs = 1400L
        )
        val strongAccel = 26f // ~2.65g

        // Resting gravity does not trigger
        assertFalse(detector.onAcceleration(0f, 9.81f, 0f, 1000L))
        // First strong jolt only arms detector
        assertFalse(detector.onAcceleration(strongAccel, 0f, 0f, 1100L))
        // Sample inside same spike (< minGapMs) is ignored
        assertFalse(detector.onAcceleration(strongAccel, 0f, 0f, 1150L))
        // Second valid peak within [160ms, 680ms] triggers
        assertTrue(detector.onAcceleration(strongAccel, 0f, 0f, 1360L))
        // Immediate follow-up peaks during cooldown are blocked
        assertFalse(detector.onAcceleration(strongAccel, 0f, 0f, 1600L))
        assertFalse(detector.onAcceleration(strongAccel, 0f, 0f, 1900L))
        // After cooldown expires, a fresh double-shake triggers again
        assertFalse(detector.onAcceleration(strongAccel, 0f, 0f, 3000L))
        assertTrue(detector.onAcceleration(strongAccel, 0f, 0f, 3260L))
    }

    @Test
    fun `drag bounds clamp reaches all four corners on tablet portrait landscape and unfolded foldable`() {
        val margin = 16
        val cardW = 760
        val cardH = 320

        val displays = listOf(
            1600 to 2560, // Tablet portrait
            2560 to 1600, // Tablet landscape
            1840 to 2208  // Unfolded foldable
        )

        for ((displayW, displayH) in displays) {
            val topLeft = HudDragBoundsMath.clampToFullDisplay(
                x = -500,
                y = -300,
                viewWidth = cardW,
                viewHeight = cardH,
                displayWidth = displayW,
                displayHeight = displayH,
                edgeMarginPx = margin,
                topInsetPx = margin,
                bottomInsetPx = margin
            )
            assertEquals(margin, topLeft.x)
            assertEquals(margin, topLeft.y)

            val bottomRight = HudDragBoundsMath.clampToFullDisplay(
                x = displayW + 500,
                y = displayH + 500,
                viewWidth = cardW,
                viewHeight = cardH,
                displayWidth = displayW,
                displayHeight = displayH,
                edgeMarginPx = margin,
                topInsetPx = margin,
                bottomInsetPx = margin
            )
            assertEquals(displayW - cardW - margin, bottomRight.x)
            assertEquals(displayH - cardH - margin, bottomRight.y)
        }
    }

    @Test
    fun `adaptive widths distinguish phone vs tablet card and cap full screen content at 680dp`() {
        // Phone 1080px @ 3.0x (360dp wide) -> capped to 344dp or screen - 24dp
        val phoneCard = HudDragBoundsMath.computeFloatingCardWidth(screenWidthPx = 1080, density = 3.0f)
        assertEquals((1080 - 24 * 3.0f).toInt(), phoneCard)

        // Tablet 2560px @ 2.0x (1280dp wide) -> uses 380dp tablet card width
        val tabletCard = HudDragBoundsMath.computeFloatingCardWidth(screenWidthPx = 2560, density = 2.0f)
        assertEquals((380f * 2.0f).toInt(), tabletCard)

        // Full-screen content width capped at 680dp on wide tablets
        val tabletFullW = HudDragBoundsMath.computeFullScreenContentWidth(screenWidthPx = 2560, density = 2.0f)
        assertEquals((680f * 2.0f).toInt(), tabletFullW)

        // Full-screen content width fills available width minus 32dp padding on phones
        val phoneFullW = HudDragBoundsMath.computeFullScreenContentWidth(screenWidthPx = 1080, density = 3.0f)
        assertEquals((1080 - 32 * 3.0f).toInt(), phoneFullW)
    }

    @Test
    fun `short horizontal flick detector distinguishes crisp prompt flick from long or slow tablet drags`() {
        val density = 2.0f // 1dp = 2px

        // Short crisp 75dp horizontal flick in 120ms -> true
        assertTrue(
            HudDragBoundsMath.isShortHorizontalPromptFlick(
                dxPx = -150f,
                dyPx = 12f,
                durationMs = 120L,
                density = density
            )
        )
        assertTrue(
            HudDragBoundsMath.isShortHorizontalPromptFlick(
                dxPx = 180f,
                dyPx = -10f,
                durationMs = 140L,
                density = density
            )
        )

        // Long horizontal drag across a tablet (320dp in 180ms) -> false (must stay free-dragged!)
        assertFalse(
            HudDragBoundsMath.isShortHorizontalPromptFlick(
                dxPx = 640f,
                dyPx = 8f,
                durationMs = 180L,
                density = density
            )
        )

        // Slow horizontal drag (80dp in 420ms) -> false
        assertFalse(
            HudDragBoundsMath.isShortHorizontalPromptFlick(
                dxPx = 160f,
                dyPx = 4f,
                durationMs = 420L,
                density = density
            )
        )

        // Diagonal or vertical drag -> false
        assertFalse(
            HudDragBoundsMath.isShortHorizontalPromptFlick(
                dxPx = 140f,
                dyPx = 120f,
                durationMs = 130L,
                density = density
            )
        )

        // Too short jitter (20dp) -> false
        assertFalse(
            HudDragBoundsMath.isShortHorizontalPromptFlick(
                dxPx = 40f,
                dyPx = 2f,
                durationMs = 80L,
                density = density
            )
        )
    }

    @Test
    fun `three-state full screen overlay transitions preserve Termux-safe focus invariant`() {
        // Show directly in full-screen overlay mode
        store.show(collapsed = false, fullScreen = true)
        assertTrue(store.currentState().visible)
        assertFalse(store.currentState().collapsed)
        assertTrue(store.currentState().fullScreen)
        assertFalse(store.currentState().inputFocused)

        // Focus can be acquired while in full-screen mode
        store.setInputFocused(true)
        assertTrue(store.currentState().inputFocused)

        // Exiting full-screen back to floating card releases focus cleanly
        assertFalse(store.toggleFullScreen())
        assertFalse(store.currentState().fullScreen)
        assertFalse(store.currentState().collapsed)
        assertFalse(store.currentState().inputFocused)

        // Re-entering full-screen via toggleFullScreen
        assertTrue(store.toggleFullScreen())
        assertTrue(store.currentState().fullScreen)

        // Collapsing while in full-screen exits full-screen and releases focus
        store.setInputFocused(true)
        store.setCollapsed(true)
        assertTrue(store.currentState().collapsed)
        assertFalse(store.currentState().fullScreen)
        assertFalse(store.currentState().inputFocused)

        // Full-screen patch / full state JSON support
        val patchResp = store.applyPatch(JSONObject().put("fullScreen", true))
        assertTrue(store.currentState().fullScreen)
        assertFalse(store.currentState().collapsed)
        assertTrue(patchResp.optBoolean("fullScreen"))
        assertTrue(store.pollCommands().optBoolean("fullScreen"))

        // Hiding resets fullScreen and inputFocused
        store.hide()
        assertFalse(store.currentState().visible)
        assertFalse(store.currentState().fullScreen)
        assertFalse(store.currentState().inputFocused)
    }
}
