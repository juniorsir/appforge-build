package com.kavach.ui.overlay.hud

import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/**
 * Immutable data models and constants for Single-Window HUD v2.
 */
object HudModels {
    const val HUD_NODE_TAG_PREFIX = "agy_hud_"
    const val HUD_WINDOW_TAG = "${HUD_NODE_TAG_PREFIX}window"

    val CASUAL_PLACEHOLDERS: List<String> = listOf(
        "whatsup bro...",
        "tell me...",
        "ask anything...",
        "what's next?",
        "snip or say something..."
    )

    fun randomPlaceholder(previous: String = ""): String {
        val candidates = CASUAL_PLACEHOLDERS.filter { it != previous }
        return (candidates.ifEmpty { CASUAL_PLACEHOLDERS }).random()
    }
}

enum class HudStatus {
    IDLE,
    WORKING,
    PAUSED,
    NEEDS_INPUT,
    STOPPED,
    DONE,
    ERROR;

    companion object {
        fun fromRaw(raw: String?, fallback: HudStatus = IDLE): HudStatus {
            val clean = raw?.trim()?.uppercase().orEmpty()
            if (clean.isEmpty()) return fallback
            return when (clean) {
                "IDLE", "READY", "STANDBY" -> IDLE
                "WORKING", "RUNNING", "ACTIVE", "THINKING", "LOADING", "EXECUTING", "IN_PROGRESS" -> WORKING
                "PAUSED", "HOLD", "WAITING" -> PAUSED
                "NEEDS_INPUT", "APPROVAL", "AWAITING_APPROVAL", "CONFIRM", "INPUT_REQUIRED" -> NEEDS_INPUT
                "STOPPED", "ABORTED", "CANCELLED", "CANCELED" -> STOPPED
                "DONE", "COMPLETED", "COMPLETE", "SUCCESS", "FINISHED" -> DONE
                "ERROR", "FAILED", "FAIL" -> ERROR
                else -> entries.firstOrNull { it.name == clean } ?: fallback
            }
        }
    }
}

data class MediaCarouselItem(
    val id: String = UUID.randomUUID().toString().take(8),
    val kind: String = "image", // image | video | audio
    val title: String = "",
    val subtitle: String = "",
    val uri: String = "",
    val thumbnailUri: String = "",
    val isNowPlaying: Boolean = false,
    val durationMs: Long = 0L
) {
    val normalizedKind: String
        get() = when (kind.trim().lowercase()) {
            "video", "mp4", "webm", "stream" -> "video"
            "audio", "song", "music", "track", "now_playing" -> "audio"
            else -> "image"
        }

    val isVideo: Boolean get() = normalizedKind == "video"
    val isAudio: Boolean get() = normalizedKind == "audio"
    val isImage: Boolean get() = normalizedKind == "image"
    val hasPlayableTransport: Boolean get() = isVideo || isAudio || isNowPlaying
}

data class ChessBoardState(
    val fen: String = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1",
    val playerColor: String = "white", // white | black
    val evalCp: Int = 0,
    val lastMove: String = "",
    val bestMove: String = "",
    val turnLabel: String = "White to move",
    val autopilotState: String = "IDLE", // IDLE | RUNNING | PAUSED
    val statusText: String = ""
) {
    val isBlackPerspective: Boolean
        get() = playerColor.trim().lowercase().startsWith("b")

    val normalizedAutopilotState: String
        get() = when (autopilotState.trim().uppercase()) {
            "RUNNING", "ACTIVE", "ON" -> "RUNNING"
            "PAUSED", "HOLD" -> "PAUSED"
            else -> "IDLE"
        }
}

data class ApprovalPrompt(
    val id: String = UUID.randomUUID().toString().take(8),
    val title: String = "Approval Required",
    val description: String = "",
    val commandPreview: String = "",
    val riskLevel: String = "MEDIUM", // LOW | MEDIUM | HIGH
    val allowEdit: Boolean = true,
    val timeoutSeconds: Int = 60
) {
    val normalizedRisk: String
        get() = when (riskLevel.trim().uppercase()) {
            "LOW", "SAFE" -> "LOW"
            "HIGH", "CRITICAL", "DANGER" -> "HIGH"
            else -> "MEDIUM"
        }
}

data class QuickAction(
    val id: String,
    val label: String,
    val prompt: String = "",
    val action: String = "PROMPT",
    val iconHint: String = "",
    val appPackage: String = ""
)

data class HardwareChip(
    val label: String,
    val detail: String = "",
    val kind: String = "info" // battery | media | network | info
)

data class HudTaskItem(
    val id: String,
    val title: String,
    val status: String = "PENDING", // PENDING | RUNNING | DONE | FAILED
    val detail: String = ""
)

data class SnippedUiNode(
    val text: String = "",
    val contentDescription: String = "",
    val viewId: String = "",
    val className: String = "",
    val bounds: String = "",
    val centerX: Int = 0,
    val centerY: Int = 0,
    val clickable: Boolean = false
) {
    fun toJson(): JSONObject = JSONObject().apply {
        if (text.isNotBlank()) put("text", text)
        if (contentDescription.isNotBlank()) put("contentDescription", contentDescription)
        if (viewId.isNotBlank()) put("viewId", viewId)
        if (className.isNotBlank()) put("className", className)
        if (bounds.isNotBlank()) put("bounds", bounds)
        put("centerX", centerX)
        put("centerY", centerY)
        put("clickable", clickable)
    }

    companion object {
        fun fromJson(obj: JSONObject?): SnippedUiNode? {
            if (obj == null) return null
            return SnippedUiNode(
                text = obj.optString("text", ""),
                contentDescription = obj.optString("contentDescription", ""),
                viewId = obj.optString("viewId", ""),
                className = obj.optString("className", ""),
                bounds = obj.optString("bounds", ""),
                centerX = obj.optInt("centerX", 0),
                centerY = obj.optInt("centerY", 0),
                clickable = obj.optBoolean("clickable", false)
            )
        }
    }
}

data class SnippedRegionContext(
    val x1: Int,
    val y1: Int,
    val x2: Int,
    val y2: Int,
    val screenWidth: Int = 1080,
    val screenHeight: Int = 2400,
    val packageName: String = "",
    val nodes: List<SnippedUiNode> = emptyList(),
    val screenshotBase64: String = "",
    val screenshotWidth: Int = 0,
    val screenshotHeight: Int = 0,
    val screenshotMimeType: String = "image/jpeg",
    val capturedAtMs: Long = System.currentTimeMillis()
) {
    val widthPx: Int get() = (x2 - x1).coerceAtLeast(0)
    val heightPx: Int get() = (y2 - y1).coerceAtLeast(0)
    val hasScreenshot: Boolean get() = screenshotBase64.isNotBlank()

    val summaryLabel: String
        get() = when {
            hasScreenshot -> "Snip ${widthPx}×${heightPx}"
            nodes.isNotEmpty() -> "Snip (${nodes.size} items)"
            else -> "Snip ${widthPx}×${heightPx}"
        }

    fun toJson(): JSONObject = JSONObject().apply {
        put("x1", x1)
        put("y1", y1)
        put("x2", x2)
        put("y2", y2)
        put("screenWidth", screenWidth)
        put("screenHeight", screenHeight)
        if (packageName.isNotBlank()) put("packageName", packageName)
        put("capturedAtMs", capturedAtMs)
        put("nodeCount", nodes.size)
        val arr = JSONArray()
        nodes.forEach { arr.put(it.toJson()) }
        put("nodes", arr)
        if (screenshotBase64.isNotBlank()) {
            put("screenshotBase64", screenshotBase64)
            put("screenshotWidth", screenshotWidth)
            put("screenshotHeight", screenshotHeight)
            put("screenshotMimeType", screenshotMimeType)
        }
    }

    companion object {
        fun fromJson(obj: JSONObject?): SnippedRegionContext? {
            if (obj == null) return null
            val nodesArr = obj.optJSONArray("nodes")
            val parsedNodes = buildList {
                if (nodesArr != null) {
                    for (i in 0 until nodesArr.length()) {
                        SnippedUiNode.fromJson(nodesArr.optJSONObject(i))?.let { add(it) }
                    }
                }
            }
            return SnippedRegionContext(
                x1 = obj.optInt("x1", 0),
                y1 = obj.optInt("y1", 0),
                x2 = obj.optInt("x2", 0),
                y2 = obj.optInt("y2", 0),
                screenWidth = obj.optInt("screenWidth", 1080).coerceAtLeast(1),
                screenHeight = obj.optInt("screenHeight", 2400).coerceAtLeast(1),
                packageName = obj.optString("packageName", ""),
                nodes = parsedNodes,
                screenshotBase64 = obj.optString("screenshotBase64", ""),
                screenshotWidth = obj.optInt("screenshotWidth", 0),
                screenshotHeight = obj.optInt("screenshotHeight", 0),
                screenshotMimeType = obj.optString("screenshotMimeType", "image/jpeg").ifBlank { "image/jpeg" },
                capturedAtMs = obj.optLong("capturedAtMs", System.currentTimeMillis())
            )
        }
    }
}

data class HudCommand(
    val id: String = UUID.randomUUID().toString().take(10),
    val type: String = "HUD_COMMAND",
    val action: String,
    val text: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val buttonId: String = "",
    val payload: JSONObject? = null
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("type", type)
        put("action", action)
        put("text", text)
        put("timestamp", timestamp)
        if (buttonId.isNotBlank()) put("buttonId", buttonId)
        if (payload != null) put("payload", payload)
    }
}

data class HudUiState(
    val visible: Boolean = false,
    val collapsed: Boolean = false,
    val fullScreen: Boolean = false,
    val inputFocused: Boolean = false,
    val status: HudStatus = HudStatus.IDLE,
    val title: String = "Agy",
    val thinkingText: String = "Ready",
    val summaryText: String = "",
    val appPackage: String = "",
    val iconHint: String = "",
    val actionKind: String = "",
    val progress: Float? = null,
    val tasks: List<HudTaskItem> = emptyList(),
    val mediaItems: List<MediaCarouselItem> = emptyList(),
    val mediaActiveIndex: Int = 0,
    val mediaPlaying: Boolean = false,
    val mediaMuted: Boolean = false,
    val chess: ChessBoardState? = null,
    val approval: ApprovalPrompt? = null,
    val hardwareChip: HardwareChip? = null,
    val quickActions: List<QuickAction> = emptyList(),
    val attachedSnip: SnippedRegionContext? = null,
    val snipPreviewExpanded: Boolean = false,
    val autoHideSeconds: Int = 0,
    val logs: List<String> = emptyList()
) {
    val isStopVisible: Boolean
        get() = status == HudStatus.WORKING || chess?.normalizedAutopilotState == "RUNNING"

    val hasMiddleContent: Boolean
        get() = attachedSnip != null ||
            approval != null ||
            chess != null ||
            mediaItems.isNotEmpty() ||
            summaryText.isNotBlank() ||
            hardwareChip != null ||
            quickActions.isNotEmpty() ||
            tasks.isNotEmpty()

    val activeMediaItem: MediaCarouselItem?
        get() = mediaItems.getOrNull(mediaActiveIndex.coerceIn(0, (mediaItems.size - 1).coerceAtLeast(0)))
}
