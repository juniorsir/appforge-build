package com.kavach.ui.overlay.hud

import android.animation.ValueAnimator
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Point
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.TextUtils
import android.transition.AutoTransition
import android.transition.TransitionManager
import android.util.Log
import android.view.Display
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.view.animation.LinearInterpolator
import android.view.animation.OvershootInterpolator
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import com.kavach.accessibility.models.AccessibilityNodeModel
import com.kavach.ui.overlay.AgyAppIconResolver
import com.kavach.ui.overlay.AgyAppleVectorIconView
import com.kavach.ui.overlay.AgyMediaPlaybackController
import com.kavach.ui.overlay.AgyRegionSnipOverlayManager
import com.kavach.ui.overlay.AgySmartSuggestionsResolver
import com.kavach.ui.overlay.AgyVoiceInputController
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import org.json.JSONObject
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Single-Window HUD v2 Host (`agy_hud_window`) — White Apple Liquid Glass Edition.
 *
 * - Exactly ONE draggable WindowManager overlay window with layered frosted translucent white
 *   glass rendering, top specular refraction highlight, Sky Blue live sheen, and cool-tinted shadow.
 * - Morphs smoothly in-place with spring physics between Expanded Card and Compact Draggable Pill
 *   (`[Logo] [Title / Thinking...] [⤢ Expand]`).
 * - Termux-safe keyboard focus: `FLAG_NOT_FOCUSABLE` at rest; focus acquired ONLY when user taps
 *   the input box and immediately released back to Termux on Send, Enter, Collapse, Hide, or outside touch.
 */
class HudWindowController(
    private val context: Context,
    val store: HudStore,
    private val appearanceFlow: StateFlow<HudAppearanceConfig>? = null
) {
    companion object {
        private const val TAG = "HudWindowController"
        private const val ACCENT_ROSE = "#E11D48"
        private const val ACCENT_EMERALD = "#15803D"
        private const val ACCENT_AMBER = "#D97706"
        private const val MAX_WIDTH_DP = 344
        private const val DOUBLE_TAP_WINDOW_MS = 260L
    }

    val stateFlow: StateFlow<HudUiState> = store.state

    var regionSnipOverlayManager: AgyRegionSnipOverlayManager? = null
    var foregroundPackageProvider: (() -> String?)? = null
    var nodeTreeProvider: (() -> List<AccessibilityNodeModel>)? = null
    var regionScreenshotProvider: ((x1: Int, y1: Int, x2: Int, y2: Int, screenWidth: Int, screenHeight: Int) -> AgyRegionSnipOverlayManager.CapturedRegionBitmap?)? = null

    private val mainHandler = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val windowManager: WindowManager? by lazy {
        context.getSystemService(Context.WINDOW_SERVICE) as? WindowManager
    }
    private val displayManager: DisplayManager? by lazy {
        context.getSystemService(Context.DISPLAY_SERVICE) as? DisplayManager
    }
    private val inputMethodManager: InputMethodManager? by lazy {
        context.getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
    }
    private val mediaController = AgyMediaPlaybackController(context).apply {
        onPlaybackStateChanged = { playing, muted ->
            store.setMediaPlaying(playing)
            store.setMediaMuted(muted)
        }
    }

    private data class DisplayBounds(
        val width: Int,
        val height: Int,
        val topInset: Int,
        val bottomInset: Int
    )

    private var rootCard: LiquidGlassHudSurface? = null
    private var innerContainer: LinearLayout? = null
    private var fullScreenSpacer: View? = null
    private var windowParams: WindowManager.LayoutParams? = null
    private var headerRow: LinearLayout? = null
    private var logoView: HudLogoBadgeView? = null
    private var titleTv: TextView? = null
    private var subtitleTv: TextView? = null
    private var stopBtn: AgyAppleVectorIconView? = null
    private var fullScreenBtn: AgyAppleVectorIconView? = null
    private var collapseExpandBtn: AgyAppleVectorIconView? = null
    private var middleStageView: HudMiddleStageViews? = null
    private var bottomBarContainer: LinearLayout? = null
    private var micBtn: AgyAppleVectorIconView? = null
    private var inputEditText: EditText? = null
    private var snipBadgeView: TextView? = null
    private var snipBtn: AgyAppleVectorIconView? = null
    private var sendBtn: AgyAppleVectorIconView? = null

    private var voiceController: AgyVoiceInputController? = null
    private var isVoiceListening: Boolean = false
    private var currentPlaceholder: String = HudModels.randomPlaceholder()
    private var isWindowAttached: Boolean = false
    private var isDisplayListenerRegistered: Boolean = false
    private var isAnimatingOut: Boolean = false
    private var isPassThroughActive: Boolean = false
    private var hasUserDragged: Boolean = false
    private var lastCollapsedState: Boolean? = null
    private var lastFullScreenState: Boolean? = null
    private var savedFloatingX: Int? = null
    private var savedFloatingY: Int? = null
    private var savedYBeforeIme: Int? = null
    private var currentAppearance: HudAppearanceConfig = appearanceFlow?.value ?: HudAppearanceConfig()
    private var activePalette: ResolvedHudPalette = ResolvedHudPalette.resolve(currentAppearance, isSystemDark = false)
    private var edgeSnapAnimator: ValueAnimator? = null
    private var lastPillTapMs: Long = 0L
    private var lastHeaderTapMs: Long = 0L
    private var transientSubtitleHint: String? = null

    private val displayListener = object : DisplayManager.DisplayListener {
        override fun onDisplayAdded(displayId: Int) = Unit
        override fun onDisplayRemoved(displayId: Int) = Unit
        override fun onDisplayChanged(displayId: Int) {
            if (displayId == Display.DEFAULT_DISPLAY) {
                mainHandler.post {
                    if (isWindowAttached && store.currentState().visible) {
                        applyStateToWindow(store.currentState())
                    }
                }
            }
        }
    }

    private val autoHideRunnable = Runnable {
        store.hide()
    }
    private val passThroughRestoreRunnable = Runnable {
        restoreFromPassThrough()
    }
    private val pendingSinglePillTapRunnable = Runnable {
        if (store.currentState().collapsed) {
            store.setCollapsed(false)
        }
    }
    private val clearTransientSubtitleRunnable = Runnable {
        transientSubtitleHint = null
        if (isWindowAttached && store.currentState().visible) {
            applyStateToWindow(store.currentState())
        }
    }

    init {
        activePalette = resolveCurrentPalette()
        scope.launch {
            store.state.collect { uiState ->
                applyStateToWindow(uiState)
            }
        }
        appearanceFlow?.let { flow ->
            scope.launch {
                flow.collect { cfg ->
                    currentAppearance = cfg
                    activePalette = resolveCurrentPalette()
                    if (isWindowAttached && store.currentState().visible) {
                        applyStateToWindow(store.currentState())
                    }
                }
            }
        }
    }

    // -------------------------------------------------------------------------
    // Public API (Dashboard, HTTP/WS Bridge, Automation)
    // -------------------------------------------------------------------------

    fun hasOverlayPermission(): Boolean {
        return Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(context)
    }

    fun getOverlayPermissionIntent(): Intent? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return null
        return Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:${context.packageName}")
        ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }

    /**
     * Shows the single-window Liquid Glass HUD as an expanded floating card (or full-screen / docked pill).
     */
    fun show(collapsed: Boolean = false, fullScreen: Boolean = false): Boolean {
        if (!hasOverlayPermission()) return false
        currentPlaceholder = HudModels.randomPlaceholder(currentPlaceholder)
        refreshScreenAwareSuggestions()
        store.show(collapsed = collapsed, fullScreen = fullScreen)
        return true
    }

    fun collapse() {
        releaseFocusToUnderlyingApp()
        store.setCollapsed(true)
    }

    fun expand() {
        store.setCollapsed(false)
    }

    fun setFullScreen(enabled: Boolean) {
        if (enabled && !hasOverlayPermission()) return
        if (!enabled) {
            releaseFocusToUnderlyingApp()
        }
        store.setFullScreen(enabled)
    }

    fun toggleFullScreen(): Boolean {
        if (!hasOverlayPermission()) return false
        val next = !store.currentState().fullScreen
        setFullScreen(next)
        return next
    }

    fun hide(): JSONObject {
        releaseFocusToUnderlyingApp()
        regionSnipOverlayManager?.hide()
        return store.hide()
    }

    fun resetToIdle(): JSONObject {
        currentPlaceholder = HudModels.randomPlaceholder(currentPlaceholder)
        releaseFocusToUnderlyingApp()
        return store.resetToIdle()
    }

    /**
     * Hands-free toggle used by double-shake summon:
     * - Hidden -> show expanded card
     * - Collapsed pill -> expand in place
     * - Expanded card -> collapse to magnetic edge pill
     */
    fun toggleFromShakeSummon() {
        runOnMain {
            if (!hasOverlayPermission()) return@runOnMain
            val cur = store.currentState()
            when {
                !cur.visible -> show(collapsed = false)
                cur.collapsed -> expand()
                else -> collapse()
            }
        }
    }

    /**
     * Temporarily makes the single HUD window touch-transparent if an automated tap/swipe
     * collides with its screen bounds, so DeviceBridgeManager gestures pass straight through.
     */
    fun temporarilyPassThroughIfColliding(
        x1: Float,
        y1: Float,
        x2: Float = x1,
        y2: Float = y1,
        durationMs: Long = 900L
    ): Boolean {
        val view = rootCard ?: return false
        val lp = windowParams ?: return false
        if (!isWindowAttached) return false

        val rect = Rect(
            lp.x,
            lp.y,
            lp.x + view.width.coerceAtLeast(1),
            lp.y + view.height.coerceAtLeast(1)
        )
        val gestureRect = Rect(
            min(x1, x2).toInt() - 12,
            min(y1, y2).toInt() - 12,
            max(x1, x2).toInt() + 12,
            max(y1, y2).toInt() + 12
        )
        if (!Rect.intersects(rect, gestureRect)) return false

        runOnMain {
            val v = rootCard ?: return@runOnMain
            val p = windowParams ?: return@runOnMain
            isPassThroughActive = true
            p.flags = p.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
            v.animate().alpha(0.28f).setDuration(140L).start()
            try {
                windowManager?.updateViewLayout(v, p)
            } catch (_: Throwable) {}
            mainHandler.removeCallbacks(passThroughRestoreRunnable)
            mainHandler.postDelayed(passThroughRestoreRunnable, durationMs.coerceIn(250L, 4000L))
        }
        return true
    }

    private fun restoreFromPassThrough() {
        if (!isPassThroughActive) return
        isPassThroughActive = false
        val v = rootCard ?: return
        val p = windowParams ?: return
        p.flags = p.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
        v.animate().alpha(1f).setDuration(180L).start()
        try {
            windowManager?.updateViewLayout(v, p)
        } catch (_: Throwable) {}
    }

    // -------------------------------------------------------------------------
    // Window Rendering & Spring Morph Lifecycle
    // -------------------------------------------------------------------------

    private fun applyStateToWindow(state: HudUiState) {
        mainHandler.removeCallbacks(autoHideRunnable)
        if (!state.visible) {
            animateHideAndDetach()
            return
        }
        if (!hasOverlayPermission()) return

        val wasAttached = isWindowAttached && !isAnimatingOut
        if (isAnimatingOut) {
            rootCard?.animate()?.cancel()
            isAnimatingOut = false
        }
        ensureWindowAttached()
        val card = rootCard ?: return
        val contentHost = innerContainer ?: return
        val lp = windowParams ?: return
        val d = context.resources.displayMetrics.density.coerceAtLeast(1f)
        val bounds = resolveDisplayMetrics()
        val screenW = bounds.width
        val screenH = bounds.height
        val floatingCardW = HudDragBoundsMath.computeFloatingCardWidth(screenW, d)
        val fullScreenContentW = HudDragBoundsMath.computeFullScreenContentWidth(screenW, d)
        val palette = resolveCurrentPalette()
        activePalette = palette

        // Trigger smooth in-place morph animation when toggling collapsed / floating / full-screen
        val collapseChanged = lastCollapsedState != null && lastCollapsedState != state.collapsed
        val fullScreenChanged = lastFullScreenState != null && lastFullScreenState != state.fullScreen
        if (fullScreenChanged) {
            if (state.fullScreen) {
                savedFloatingX = lp.x
                savedFloatingY = lp.y
            }
        }
        lastCollapsedState = state.collapsed
        lastFullScreenState = state.fullScreen
        if (wasAttached && (collapseChanged || fullScreenChanged) && !isReducedMotionEnabled()) {
            try {
                val morph = AutoTransition().apply {
                    duration = 250L
                    interpolator = OvershootInterpolator(0.45f)
                }
                TransitionManager.beginDelayedTransition(card, morph)
            } catch (_: Throwable) {}
        }

        // Update glass corner geometry, dynamic White/Smoked palette, & active sheen
        val isActivePulse = state.status == HudStatus.WORKING || state.status == HudStatus.NEEDS_INPUT
        card.setGlassState(
            pillMode = state.collapsed,
            fullScreenMode = state.fullScreen && !state.collapsed,
            shimmerActive = isActivePulse && !isReducedMotionEnabled(),
            accentActive = isActivePulse,
            palette = palette
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            card.outlineAmbientShadowColor = palette.shadowAmbient
            card.outlineSpotShadowColor = palette.shadowSpot
        }

        // Update 3-state window geometry in-place: Docked Pill <-> Floating Card <-> Full-Screen Overlay
        val isFull = state.fullScreen && !state.collapsed
        if (isFull) {
            edgeSnapAnimator?.cancel()
            lp.width = WindowManager.LayoutParams.MATCH_PARENT
            lp.height = WindowManager.LayoutParams.MATCH_PARENT
            lp.x = 0
            lp.y = 0
            card.gravity = Gravity.CENTER_HORIZONTAL
            val hPad = (16 * d).toInt()
            val topPad = bounds.topInset + (12 * d).toInt()
            val botPad = bounds.bottomInset + (16 * d).toInt()
            card.setPadding(hPad, topPad, hPad, botPad)
            contentHost.layoutParams = LinearLayout.LayoutParams(
                fullScreenContentW,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        } else {
            val targetW = if (state.collapsed) {
                ViewGroup.LayoutParams.WRAP_CONTENT
            } else {
                floatingCardW
            }
            val wasFullScreen = lp.height == WindowManager.LayoutParams.MATCH_PARENT
            lp.width = targetW
            lp.height = WindowManager.LayoutParams.WRAP_CONTENT
            card.gravity = Gravity.NO_GRAVITY
            contentHost.layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            if (wasFullScreen) {
                savedFloatingX?.let { lp.x = it }
                savedFloatingY?.let { lp.y = it }
                savedFloatingX = null
                savedFloatingY = null
            } else if (!state.collapsed && !hasUserDragged) {
                lp.x = ((screenW - floatingCardW) / 2).coerceAtLeast((10 * d).toInt())
            }
        }

        // Apply Termux-safe focus flag synced with store
        val shouldBeFocusable = state.inputFocused && !state.collapsed && !isPassThroughActive
        val hasNotFocusable = (lp.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE) != 0
        if (shouldBeFocusable && hasNotFocusable) {
            lp.flags = (lp.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE.inv()) or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH
        } else if (!shouldBeFocusable && !hasNotFocusable) {
            lp.flags = lp.flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        }

        // Update Top Header with dynamic palette
        val resolvedIcon = AgyAppIconResolver.resolve(
            context = context,
            explicitIcon = state.iconHint,
            explicitPackage = state.appPackage,
            fallbackText = "${state.title} ${state.thinkingText}",
            actionKindHint = state.actionKind
        )
        logoView?.updateIcon(
            icon = resolvedIcon,
            pulsing = isActivePulse && !isReducedMotionEnabled(),
            palette = palette
        )

        titleTv?.setTextColor(palette.textPrimary)
        fullScreenBtn?.apply {
            visibility = if (state.collapsed) View.GONE else View.VISIBLE
            glassFillColor = palette.iconSurfaceFill
            glassBorderColor = palette.iconSurfaceBorder
            iconTint = if (isFull) palette.accentDeep else palette.textPrimary
            iconType = if (isFull) {
                AgyAppleVectorIconView.IconType.PIP_ENTER
            } else {
                AgyAppleVectorIconView.IconType.ARROW_EXPAND
            }
            contentDescription = if (isFull) {
                "${HudModels.HUD_NODE_TAG_PREFIX}exit_fullscreen_btn"
            } else {
                "${HudModels.HUD_NODE_TAG_PREFIX}fullscreen_btn"
            }
        }
        collapseExpandBtn?.apply {
            glassFillColor = palette.iconSurfaceFill
            glassBorderColor = palette.iconSurfaceBorder
            iconTint = palette.textPrimary
        }

        if (state.collapsed) {
            titleTv?.text = buildString {
                append(state.title.ifBlank { "Agy" })
                if (state.thinkingText.isNotBlank() && state.thinkingText != "Ready") {
                    append(" • ").append(state.thinkingText)
                }
            }
            titleTv?.maxWidth = (182 * d).toInt()
            subtitleTv?.visibility = View.GONE
            collapseExpandBtn?.iconType = AgyAppleVectorIconView.IconType.ARROW_EXPAND
            collapseExpandBtn?.contentDescription = "${HudModels.HUD_NODE_TAG_PREFIX}expand_btn"
            card.setPadding((10 * d).toInt(), (6 * d).toInt(), (10 * d).toInt(), (6 * d).toInt())
        } else {
            titleTv?.text = state.title.ifBlank { "Agy" }
            titleTv?.maxWidth = Int.MAX_VALUE
            subtitleTv?.visibility = View.VISIBLE
            val shownSub = transientSubtitleHint ?: state.thinkingText.ifBlank { "Ready" }
            subtitleTv?.text = shownSub
            subtitleTv?.setTextColor(
                if (transientSubtitleHint != null) {
                    palette.accentDeep
                } else {
                    when (state.status) {
                        HudStatus.WORKING -> palette.accentDeep
                        HudStatus.NEEDS_INPUT -> Color.parseColor(ACCENT_AMBER)
                        HudStatus.ERROR -> Color.parseColor(ACCENT_ROSE)
                        HudStatus.DONE -> Color.parseColor(ACCENT_EMERALD)
                        else -> palette.textSecondary
                    }
                }
            )
            collapseExpandBtn?.iconType = AgyAppleVectorIconView.IconType.MINUS
            collapseExpandBtn?.contentDescription = "${HudModels.HUD_NODE_TAG_PREFIX}collapse_btn"
            if (!isFull) {
                card.setPadding((14 * d).toInt(), (10 * d).toInt(), (14 * d).toInt(), (12 * d).toInt())
            }
        }

        stopBtn?.visibility = if (state.isStopVisible) View.VISIBLE else View.GONE

        // Update Middle Stage with dynamic palette & compact vs. full-screen layout weight
        val stageInnerWidthPx = if (isFull) {
            fullScreenContentW.coerceAtLeast((240 * d).toInt())
        } else {
            (floatingCardW - (28 * d).toInt()).coerceAtLeast((220 * d).toInt())
        }
        middleStageView?.apply {
            val midLp = (layoutParams as? LinearLayout.LayoutParams) ?: LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            if (isFull && state.hasMiddleContent) {
                midLp.height = 0
                midLp.weight = 1f
            } else {
                midLp.height = ViewGroup.LayoutParams.WRAP_CONTENT
                midLp.weight = 0f
            }
            midLp.topMargin = (6 * d).toInt()
            layoutParams = midLp
            render(state, stageInnerWidthPx, palette, fullScreen = isFull)
        }
        fullScreenSpacer?.visibility = if (isFull && !state.hasMiddleContent) View.VISIBLE else View.GONE

        // Update Bottom Floating Input Bar & controls with dynamic palette
        bottomBarContainer?.apply {
            visibility = if (state.collapsed) View.GONE else View.VISIBLE
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = 999f * d
                setColor(palette.inputPillBg)
                setStroke((1f * d).toInt().coerceAtLeast(1), palette.inputPillBorder)
            }
        }
        inputEditText?.apply {
            hint = currentPlaceholder
            setTextColor(palette.textPrimary)
            setHintTextColor(palette.textPlaceholder)
        }
        micBtn?.apply {
            if (!isVoiceListening) {
                glassFillColor = palette.iconSurfaceFill
                glassBorderColor = palette.iconSurfaceBorder
                iconTint = palette.textPrimary
            }
        }
        snipBtn?.apply {
            glassFillColor = palette.accentPillBg
            glassBorderColor = palette.accentPillBorder
            iconTint = palette.accentDeep
        }
        sendBtn?.accentColor = palette.accentPrimary

        val snip = state.attachedSnip
        if (snip != null) {
            snipBadgeView?.visibility = View.VISIBLE
            snipBadgeView?.text = "Snip ✕"
            snipBadgeView?.setTextColor(palette.accentDeep)
            snipBadgeView?.background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = 999f * d
                setColor(palette.accentPillBg)
                setStroke((1f * d).toInt().coerceAtLeast(1), palette.accentPillBorder)
            }
        } else {
            snipBadgeView?.visibility = View.GONE
        }

        // Clamp safely on full display when floating/pill
        if (!isFull) {
            if (!hasUserDragged && !state.collapsed) {
                lp.x = ((screenW - floatingCardW) / 2).coerceAtLeast((10 * d).toInt())
            }
            clampPosition(lp, bounds, if (state.collapsed) card.width.takeIf { it > 0 } ?: (210 * d).toInt() else floatingCardW)
        }
        try {
            windowManager?.updateViewLayout(card, lp)
        } catch (t: Throwable) {
            Log.w(TAG, "updateViewLayout skipped: ${t.message}")
        }

        // Magnetic Edge Dock when morphing into compact pill
        if (wasAttached && collapseChanged && state.collapsed && currentAppearance.magneticEdgeDock) {
            card.post { snapCollapsedPillToEdge(velocityX = 0f, haptic = true) }
        }

        // Play spring pop-in animation on first attach
        if (!wasAttached) {
            playEntranceSpring(card)
        }

        // Optional auto-hide timer when not actively working / awaiting approval
        if (state.autoHideSeconds > 0 && state.status != HudStatus.WORKING && state.status != HudStatus.NEEDS_INPUT) {
            mainHandler.postDelayed(autoHideRunnable, state.autoHideSeconds * 1000L)
        }
    }

    private fun ensureWindowAttached() {
        if (isWindowAttached && rootCard != null) return
        val wm = windowManager ?: return
        val d = context.resources.displayMetrics.density.coerceAtLeast(1f)
        val bounds = resolveDisplayMetrics()
        val floatingCardW = HudDragBoundsMath.computeFloatingCardWidth(bounds.width, d)

        hasUserDragged = false
        lastCollapsedState = null
        lastFullScreenState = null
        savedFloatingX = null
        savedFloatingY = null

        val palette = resolveCurrentPalette()
        activePalette = palette

        val card = LiquidGlassHudSurface(context, palette).apply {
            orientation = LinearLayout.VERTICAL
            elevation = 16f * d
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                outlineAmbientShadowColor = palette.shadowAmbient
                outlineSpotShadowColor = palette.shadowSpot
            }
            setPadding((14 * d).toInt(), (10 * d).toInt(), (14 * d).toInt(), (12 * d).toInt())
            contentDescription = HudModels.HUD_WINDOW_TAG
        }

        val contentHost = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
        }

        // 1. Top Header (44dp, draggable + hidden gestures)
        val header = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            minimumHeight = (44 * d).toInt()
            contentDescription = "${HudModels.HUD_NODE_TAG_PREFIX}header"
        }

        val logo = HudLogoBadgeView(context, palette).apply {
            contentDescription = "${HudModels.HUD_NODE_TAG_PREFIX}logo"
        }
        header.addView(logo, LinearLayout.LayoutParams((34 * d).toInt(), (34 * d).toInt()))

        val titleCol = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                marginStart = (10 * d).toInt()
                marginEnd = (6 * d).toInt()
            }
        }
        val tTv = TextView(context).apply {
            text = "Agy"
            textSize = 13.5f
            setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
            setTextColor(palette.textPrimary)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            contentDescription = "${HudModels.HUD_NODE_TAG_PREFIX}title"
        }
        val sTv = TextView(context).apply {
            text = "Ready"
            textSize = 11.5f
            setTextColor(palette.textSecondary)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            contentDescription = "${HudModels.HUD_NODE_TAG_PREFIX}subtitle"
        }
        titleCol.addView(tTv)
        titleCol.addView(sTv)
        header.addView(titleCol)

        val stopButton = AgyAppleVectorIconView(context, AgyAppleVectorIconView.IconType.STOP_SQUARE).apply {
            glassStyle = AgyAppleVectorIconView.GlassStyle.ACCENT_CIRCLE
            accentColor = Color.parseColor(ACCENT_ROSE)
            iconTint = Color.WHITE
            iconSizeDp = 11f
            minTouchSizeDp = 34f
            visibility = View.GONE
            contentDescription = "${HudModels.HUD_NODE_TAG_PREFIX}stop_btn"
            setOnClickListener {
                store.enqueueCommand(action = "STOP", text = "Stopped by user")
            }
            attachSpringPress(this)
        }
        header.addView(
            stopButton,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                marginEnd = (6 * d).toInt()
            }
        )

        val fullScreenButton = AgyAppleVectorIconView(context, AgyAppleVectorIconView.IconType.ARROW_EXPAND).apply {
            glassStyle = AgyAppleVectorIconView.GlassStyle.GLASS_CIRCLE
            glassFillColor = palette.iconSurfaceFill
            glassBorderColor = palette.iconSurfaceBorder
            iconTint = palette.textPrimary
            iconSizeDp = 13f
            minTouchSizeDp = 34f
            contentDescription = "${HudModels.HUD_NODE_TAG_PREFIX}fullscreen_btn"
            setOnClickListener {
                toggleFullScreen()
            }
            attachSpringPress(this)
        }
        header.addView(
            fullScreenButton,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                marginEnd = (6 * d).toInt()
            }
        )

        val collapseButton = AgyAppleVectorIconView(context, AgyAppleVectorIconView.IconType.MINUS).apply {
            glassStyle = AgyAppleVectorIconView.GlassStyle.GLASS_CIRCLE
            glassFillColor = palette.iconSurfaceFill
            glassBorderColor = palette.iconSurfaceBorder
            iconTint = palette.textPrimary
            iconSizeDp = 13f
            minTouchSizeDp = 34f
            contentDescription = "${HudModels.HUD_NODE_TAG_PREFIX}collapse_btn"
            setOnClickListener {
                mainHandler.removeCallbacks(pendingSinglePillTapRunnable)
                val nowCollapsed = store.toggleCollapsed()
                if (nowCollapsed) {
                    releaseFocusToUnderlyingApp()
                }
            }
            attachSpringPress(this)
        }
        header.addView(collapseButton)

        attachDragBehavior(header, isHeaderHandle = true, allowOutsideRelease = false)
        attachDragBehavior(card, isHeaderHandle = false, allowOutsideRelease = true)
        contentHost.addView(header)

        // 2. Adaptive Middle Stage (maxHeight <= 210dp, hides when empty/idle)
        val middle = HudMiddleStageViews(
            context = context,
            mediaController = mediaController,
            callbacks = object : HudMiddleStageViews.Callbacks {
                override fun onToggleSnipExpand() {
                    store.toggleSnipPreviewExpanded()
                }

                override fun onClearSnip() {
                    store.attachSnip(null)
                }

                override fun onMediaPageSelected(index: Int) {
                    store.setMediaActiveIndex(index)
                }

                override fun onMediaPlayPause() {
                    mediaController.togglePlayPause()
                }

                override fun onMediaMuteToggle() {
                    mediaController.toggleMute()
                }

                override fun onChessAction(action: String, text: String, buttonId: String) {
                    if (action == "APPROVAL_EDIT_OPEN") {
                        applyStateToWindow(store.currentState())
                        return
                    }
                    store.enqueueCommand(action = action, text = text, buttonId = buttonId)
                }

                override fun onApprovalDecision(decision: String, editedCommand: String?) {
                    releaseFocusToUnderlyingApp()
                    store.respondToApproval(decision, editedCommand)
                }

                override fun onQuickActionClick(action: QuickAction) {
                    releaseFocusToUnderlyingApp()
                    store.submitPrompt(
                        rawText = action.prompt.ifBlank { action.label },
                        action = action.action,
                        buttonId = action.id
                    )
                }

                override fun onRequestInputFocus(editText: EditText) {
                    acquireFocusForInput(editText)
                }
            }
        )
        contentHost.addView(
            middle,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                topMargin = (6 * d).toInt()
            }
        )

        val spacer = View(context).apply {
            visibility = View.GONE
        }
        contentHost.addView(
            spacer,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        )

        // 3. Bottom Bar (48dp Integrated Frosted Liquid Glass Input Pill)
        val bottomBar = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            minimumHeight = (48 * d).toInt()
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = 999f * d
                setColor(palette.inputPillBg)
                setStroke((1f * d).toInt().coerceAtLeast(1), palette.inputPillBorder)
            }
            setPadding((6 * d).toInt(), (4 * d).toInt(), (6 * d).toInt(), (4 * d).toInt())
            contentDescription = "${HudModels.HUD_NODE_TAG_PREFIX}bottom_bar"
        }

        val micButton = AgyAppleVectorIconView(context, AgyAppleVectorIconView.IconType.WAVEFORM).apply {
            glassStyle = AgyAppleVectorIconView.GlassStyle.GLASS_CIRCLE
            glassFillColor = palette.iconSurfaceFill
            glassBorderColor = palette.iconSurfaceBorder
            iconTint = palette.textPrimary
            iconSizeDp = 14f
            minTouchSizeDp = 36f
            contentDescription = "${HudModels.HUD_NODE_TAG_PREFIX}mic_btn"
            setOnClickListener { toggleVoiceInput() }
            attachSpringPress(this)
        }
        bottomBar.addView(micButton)

        val editBox = EditText(context).apply {
            hint = currentPlaceholder
            setHintTextColor(palette.textPlaceholder)
            setTextColor(palette.textPrimary)
            textSize = 13f
            background = null
            maxLines = 2
            isSingleLine = true
            imeOptions = EditorInfo.IME_ACTION_SEND or EditorInfo.IME_FLAG_NO_EXTRACT_UI
            setPadding((9 * d).toInt(), (6 * d).toInt(), (6 * d).toInt(), (6 * d).toInt())
            contentDescription = "${HudModels.HUD_NODE_TAG_PREFIX}prompt_input"
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            setOnClickListener { acquireFocusForInput(this) }
            setOnEditorActionListener { _, actionId, event ->
                if (actionId == EditorInfo.IME_ACTION_SEND ||
                    actionId == EditorInfo.IME_ACTION_DONE ||
                    (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER && event.action == KeyEvent.ACTION_DOWN)
                ) {
                    submitCurrentInput()
                    true
                } else {
                    false
                }
            }
        }
        bottomBar.addView(editBox)

        val snipBadge = TextView(context).apply {
            text = "Snip ✕"
            textSize = 10f
            setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
            setTextColor(palette.accentDeep)
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = 999f * d
                setColor(palette.accentPillBg)
                setStroke((1f * d).toInt().coerceAtLeast(1), palette.accentPillBorder)
            }
            setPadding((8 * d).toInt(), (4 * d).toInt(), (8 * d).toInt(), (4 * d).toInt())
            visibility = View.GONE
            contentDescription = "${HudModels.HUD_NODE_TAG_PREFIX}snip_badge"
            setOnClickListener { store.attachSnip(null) }
            attachSpringPress(this)
        }
        bottomBar.addView(
            snipBadge,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                marginEnd = (4 * d).toInt()
            }
        )

        val snipButton = AgyAppleVectorIconView(context, AgyAppleVectorIconView.IconType.SCISSORS).apply {
            glassStyle = AgyAppleVectorIconView.GlassStyle.GLASS_CIRCLE
            glassFillColor = palette.accentPillBg
            glassBorderColor = palette.accentPillBorder
            iconTint = palette.accentDeep
            iconSizeDp = 14f
            minTouchSizeDp = 36f
            contentDescription = "${HudModels.HUD_NODE_TAG_PREFIX}snip_btn"
            setOnClickListener { launchOnDemandSnip() }
            attachSpringPress(this)
        }
        bottomBar.addView(
            snipButton,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                marginEnd = (5 * d).toInt()
            }
        )

        val sendButton = AgyAppleVectorIconView(context, AgyAppleVectorIconView.IconType.CHEVRON_UP).apply {
            glassStyle = AgyAppleVectorIconView.GlassStyle.ACCENT_CIRCLE
            accentColor = palette.accentPrimary
            iconTint = Color.WHITE
            iconSizeDp = 15f
            minTouchSizeDp = 36f
            contentDescription = "${HudModels.HUD_NODE_TAG_PREFIX}send_btn"
            setOnClickListener { submitCurrentInput() }
            attachSpringPress(this)
        }
        bottomBar.addView(sendButton)

        contentHost.addView(
            bottomBar,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                topMargin = (8 * d).toInt()
            }
        )
        card.addView(
            contentHost,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        )

        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val initialX = ((bounds.width - floatingCardW) / 2).coerceAtLeast((10 * d).toInt())
        val initialY = (bounds.height - bounds.bottomInset - (220 * d).toInt())
            .coerceAtLeast(bounds.topInset + (40 * d).toInt())

        val lp = WindowManager.LayoutParams(
            floatingCardW,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = initialX
            y = initialY
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
            title = HudModels.HUD_WINDOW_TAG
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                // Critical for tablets/large screens: prevent taskbar & system bars from clipping drag bounds
                fitInsetsTypes = 0
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }

        try {
            wm.addView(card, lp)
            rootCard = card
            innerContainer = contentHost
            fullScreenSpacer = spacer
            windowParams = lp
            headerRow = header
            logoView = logo
            titleTv = tTv
            subtitleTv = sTv
            stopBtn = stopButton
            fullScreenBtn = fullScreenButton
            collapseExpandBtn = collapseButton
            middleStageView = middle
            bottomBarContainer = bottomBar
            micBtn = micButton
            inputEditText = editBox
            snipBadgeView = snipBadge
            snipBtn = snipButton
            sendBtn = sendButton
            isWindowAttached = true
            if (!isDisplayListenerRegistered) {
                try {
                    displayManager?.registerDisplayListener(displayListener, mainHandler)
                    isDisplayListenerRegistered = true
                } catch (_: Throwable) {}
            }
        } catch (t: Throwable) {
            Log.e(TAG, "Failed attaching HUD v2 window: ${t.message}")
        }
    }

    private fun playEntranceSpring(card: View) {
        if (isReducedMotionEnabled()) {
            card.alpha = 1f
            card.scaleX = 1f
            card.scaleY = 1f
            card.translationY = 0f
            return
        }
        val d = context.resources.displayMetrics.density.coerceAtLeast(1f)
        card.alpha = 0f
        card.scaleX = 0.91f
        card.scaleY = 0.91f
        card.translationY = 24f * d
        card.animate()
            .alpha(1f)
            .scaleX(1f)
            .scaleY(1f)
            .translationY(0f)
            .setDuration(290L)
            .setInterpolator(OvershootInterpolator(1.02f))
            .start()
    }

    private fun animateHideAndDetach() {
        val card = rootCard
        if (!isWindowAttached || card == null) {
            detachWindow()
            return
        }
        if (isReducedMotionEnabled() || isAnimatingOut) {
            detachWindow()
            return
        }
        isAnimatingOut = true
        val d = context.resources.displayMetrics.density.coerceAtLeast(1f)
        card.animate()
            .alpha(0f)
            .scaleX(0.92f)
            .scaleY(0.92f)
            .translationY(18f * d)
            .setDuration(165L)
            .setInterpolator(DecelerateInterpolator())
            .withEndAction {
                isAnimatingOut = false
                if (!store.currentState().visible) {
                    detachWindow()
                }
            }
            .start()
    }

    private fun detachWindow() {
        isAnimatingOut = false
        isVoiceListening = false
        edgeSnapAnimator?.cancel()
        edgeSnapAnimator = null
        voiceController?.release()
        voiceController = null
        middleStageView?.release()
        if (isDisplayListenerRegistered) {
            try {
                displayManager?.unregisterDisplayListener(displayListener)
            } catch (_: Throwable) {}
            isDisplayListenerRegistered = false
        }
        mainHandler.removeCallbacks(autoHideRunnable)
        mainHandler.removeCallbacks(passThroughRestoreRunnable)
        mainHandler.removeCallbacks(pendingSinglePillTapRunnable)
        mainHandler.removeCallbacks(clearTransientSubtitleRunnable)
        transientSubtitleHint = null
        isPassThroughActive = false
        hasUserDragged = false
        lastCollapsedState = null
        lastFullScreenState = null
        savedFloatingX = null
        savedFloatingY = null
        savedYBeforeIme = null

        rootCard?.let { v ->
            v.animate().cancel()
            v.stopAnimations()
            try {
                windowManager?.removeView(v)
            } catch (_: Throwable) {}
        }
        rootCard = null
        innerContainer = null
        fullScreenSpacer = null
        windowParams = null
        headerRow = null
        logoView = null
        titleTv = null
        subtitleTv = null
        stopBtn = null
        fullScreenBtn = null
        collapseExpandBtn = null
        middleStageView = null
        bottomBarContainer = null
        micBtn = null
        inputEditText = null
        snipBadgeView = null
        snipBtn = null
        sendBtn = null
        isWindowAttached = false
    }

    // -------------------------------------------------------------------------
    // Termux-Safe Focus, Input Submission, Voice & On-Demand Snip
    // -------------------------------------------------------------------------

    private fun acquireFocusForInput(target: EditText) {
        val card = rootCard ?: return
        val lp = windowParams ?: return
        if (!isWindowAttached) return

        store.setInputFocused(true)
        lp.flags = (lp.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE.inv()) or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH

        if (!store.currentState().fullScreen) {
            val (_, screenH) = resolveScreenSize()
            val imeSafeMaxY = (screenH * 0.44f).toInt()
            if (lp.y > imeSafeMaxY) {
                if (savedYBeforeIme == null) savedYBeforeIme = lp.y
                lp.y = imeSafeMaxY
            }
        }

        try {
            windowManager?.updateViewLayout(card, lp)
        } catch (_: Throwable) {}

        target.post {
            target.requestFocus()
            target.setSelection(target.text?.length ?: 0)
            try {
                inputMethodManager?.showSoftInput(target, InputMethodManager.SHOW_IMPLICIT)
            } catch (_: Throwable) {}
        }
    }

    private fun releaseFocusToUnderlyingApp() {
        val card = rootCard
        val lp = windowParams
        inputEditText?.let { et ->
            try {
                inputMethodManager?.hideSoftInputFromWindow(et.windowToken, 0)
            } catch (_: Throwable) {}
            et.clearFocus()
        }
        store.setInputFocused(false)
        if (card != null && lp != null && isWindowAttached) {
            lp.flags = lp.flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
            savedYBeforeIme?.let { prevY ->
                lp.y = prevY
                savedYBeforeIme = null
            }
            try {
                windowManager?.updateViewLayout(card, lp)
            } catch (_: Throwable) {}
        }
    }

    private fun submitCurrentInput() {
        val et = inputEditText ?: return
        val text = et.text?.toString()?.trim().orEmpty()
        val submitted = store.submitPrompt(text)
        if (submitted != null) {
            et.setText("")
            currentPlaceholder = HudModels.randomPlaceholder(currentPlaceholder)
            et.hint = currentPlaceholder
        }
        releaseFocusToUnderlyingApp()
    }

    private fun toggleVoiceInput() {
        val controller = voiceController ?: AgyVoiceInputController(
            context = context,
            onListeningChanged = { listening ->
                runOnMain {
                    isVoiceListening = listening
                    micBtn?.glassStyle = if (listening) {
                        AgyAppleVectorIconView.GlassStyle.ACCENT_CIRCLE
                    } else {
                        AgyAppleVectorIconView.GlassStyle.GLASS_CIRCLE
                    }
                    micBtn?.accentColor = Color.parseColor(ACCENT_ROSE)
                    micBtn?.glassFillColor = activePalette.iconSurfaceFill
                    micBtn?.glassBorderColor = activePalette.iconSurfaceBorder
                    micBtn?.iconTint = if (listening) Color.WHITE else activePalette.textPrimary
                    if (listening) {
                        store.applyPatch(JSONObject().put("thinkingText", "Listening..."))
                    }
                }
            },
            onPartialText = { partial ->
                runOnMain {
                    inputEditText?.setText(partial)
                    inputEditText?.setSelection(partial.length)
                }
            },
            onFinalText = { finalText ->
                runOnMain {
                    inputEditText?.setText(finalText)
                    inputEditText?.setSelection(finalText.length)
                    store.applyPatch(JSONObject().put("thinkingText", "Voice ready — tap Send"))
                }
            },
            onErrorMessage = { msg ->
                runOnMain {
                    Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                }
            }
        ).also { voiceController = it }

        controller.toggleListening()
    }

    private fun launchOnDemandSnip() {
        val snipMgr = regionSnipOverlayManager
        if (snipMgr == null) {
            Toast.makeText(context, "Snip overlay unavailable", Toast.LENGTH_SHORT).show()
            return
        }
        releaseFocusToUnderlyingApp()
        rootCard?.visibility = View.INVISIBLE

        val started = snipMgr.startSnip(
            nodeTreeProvider = nodeTreeProvider,
            foregroundPackageProvider = foregroundPackageProvider,
            screenshotProvider = regionScreenshotProvider,
            onComplete = { captured ->
                runOnMain {
                    rootCard?.visibility = View.VISIBLE
                    store.attachSnip(captured)
                }
            },
            onCancel = {
                runOnMain {
                    rootCard?.visibility = View.VISIBLE
                }
            }
        )
        if (!started) {
            rootCard?.visibility = View.VISIBLE
            Toast.makeText(context, "Enable overlay permission to snip", Toast.LENGTH_SHORT).show()
        }
    }

    private fun refreshScreenAwareSuggestions() {
        val fgPkg = try { foregroundPackageProvider?.invoke() } catch (_: Throwable) { null }
        val resolved = AgySmartSuggestionsResolver.resolve(fgPkg, maxItems = 3)
        store.updateForegroundQuickActions(fgPkg, resolved)
    }

    // -------------------------------------------------------------------------
    // Draggable Top Header + Spring Lift Physics + Safe Screen Clamping
    // -------------------------------------------------------------------------

    private fun attachDragBehavior(
        handle: View,
        isHeaderHandle: Boolean,
        allowOutsideRelease: Boolean
    ) {
        val d = context.resources.displayMetrics.density.coerceAtLeast(1f)
        val touchSlop = ViewConfiguration.get(context).scaledTouchSlop
        val swipeDownThreshold = 38f * d
        val swipeUpThreshold = 34f * d
        val fullScreenExitThreshold = 44f * d
        var downRawX = 0f
        var downRawY = 0f
        var downTimeMs = 0L
        var startWinX = 0
        var startWinY = 0
        var dragging = false

        handle.setOnTouchListener { v, event ->
            if (allowOutsideRelease && event.actionMasked == MotionEvent.ACTION_OUTSIDE) {
                if (store.currentState().inputFocused) {
                    releaseFocusToUnderlyingApp()
                }
                return@setOnTouchListener false
            }
            val card = rootCard ?: return@setOnTouchListener false
            val lp = windowParams ?: return@setOnTouchListener false
            val currentState = store.currentState()
            val isFull = currentState.fullScreen && !currentState.collapsed

            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    edgeSnapAnimator?.cancel()
                    downRawX = event.rawX
                    downRawY = event.rawY
                    downTimeMs = event.eventTime
                    startWinX = lp.x
                    startWinY = lp.y
                    dragging = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - downRawX
                    val dy = event.rawY - downRawY

                    if (!dragging && (abs(dx) > touchSlop || abs(dy) > touchSlop)) {
                        dragging = true
                        if (!isFull) {
                            hasUserDragged = true
                            savedYBeforeIme = null
                            if (!isReducedMotionEnabled()) {
                                card.animate()
                                    .scaleX(1.02f)
                                    .scaleY(1.02f)
                                    .setDuration(140L)
                                    .setInterpolator(DecelerateInterpolator())
                                    .start()
                            }
                        }
                    }
                    if (dragging && !isFull) {
                        val bounds = resolveDisplayMetrics()
                        lp.x = (startWinX + dx).toInt()
                        lp.y = (startWinY + dy).toInt()
                        clampPosition(lp, bounds, card.width.coerceAtLeast(1))
                        try {
                            windowManager?.updateViewLayout(card, lp)
                        } catch (_: Throwable) {}
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    val dx = event.rawX - downRawX
                    val dy = event.rawY - downRawY
                    val elapsedMs = (event.eventTime - downTimeMs).coerceAtLeast(1L)
                    val elapsedSec = elapsedMs.coerceAtLeast(16L) / 1000f
                    val velocityX = dx / elapsedSec
                    val velocityY = dy / elapsedSec
                    val isCollapsed = currentState.collapsed

                    if (dragging && !isFull && !isReducedMotionEnabled()) {
                        card.animate()
                            .scaleX(1f)
                            .scaleY(1f)
                            .setDuration(220L)
                            .setInterpolator(OvershootInterpolator(1.2f))
                            .start()
                    }

                    if (isFull) {
                        if (dragging && isHeaderHandle &&
                            dy > fullScreenExitThreshold &&
                            abs(dy) > abs(dx) * 1.25f &&
                            velocityY > 300f
                        ) {
                            v.performHapticFeedback(android.view.HapticFeedbackConstants.CLOCK_TICK)
                            setFullScreen(false)
                        } else if (!dragging && isHeaderHandle) {
                            val now = System.currentTimeMillis()
                            if (now - lastHeaderTapMs <= DOUBLE_TAP_WINDOW_MS) {
                                lastHeaderTapMs = 0L
                                v.performHapticFeedback(android.view.HapticFeedbackConstants.CLOCK_TICK)
                                toggleFullScreen()
                            } else {
                                lastHeaderTapMs = now
                            }
                        }
                        return@setOnTouchListener true
                    }

                    if (dragging) {
                        // Free 2D drag everywhere; prompt history only on a short crisp horizontal flick on the header
                        val isShortPromptFlick = !isCollapsed &&
                            isHeaderHandle &&
                            HudDragBoundsMath.isShortHorizontalPromptFlick(
                                dxPx = dx,
                                dyPx = dy,
                                durationMs = elapsedMs,
                                density = d
                            )
                        val isDownwardCollapseFling = !isCollapsed &&
                            isHeaderHandle &&
                            dy > swipeDownThreshold &&
                            abs(dy) > abs(dx) * 1.25f &&
                            velocityY > 360f
                        val isUpwardExpandFling = isCollapsed &&
                            dy < -swipeUpThreshold &&
                            abs(dy) > abs(dx) * 1.25f &&
                            velocityY < -340f

                        when {
                            isShortPromptFlick -> {
                                // Swipe left -> older prompt; swipe right -> newer prompt; spring back to drag anchor
                                val delta = if (dx < 0f) +1 else -1
                                cyclePromptHistoryGesture(delta, v)
                                animateWindowBackToAnchor(card, lp, startWinX, startWinY)
                            }
                            isDownwardCollapseFling -> {
                                v.performHapticFeedback(android.view.HapticFeedbackConstants.CLOCK_TICK)
                                collapse()
                            }
                            isUpwardExpandFling -> {
                                v.performHapticFeedback(android.view.HapticFeedbackConstants.CLOCK_TICK)
                                expand()
                            }
                            isCollapsed && currentAppearance.magneticEdgeDock -> {
                                snapCollapsedPillToEdge(velocityX = velocityX, haptic = true)
                            }
                        }
                    } else if (isCollapsed) {
                        // Double-tap collapsed pill -> expand + instant voice input; single tap -> expand
                        val now = System.currentTimeMillis()
                        if (now - lastPillTapMs <= DOUBLE_TAP_WINDOW_MS) {
                            lastPillTapMs = 0L
                            mainHandler.removeCallbacks(pendingSinglePillTapRunnable)
                            v.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS)
                            store.setCollapsed(false)
                            mainHandler.postDelayed({
                                if (isWindowAttached && store.currentState().visible && !store.currentState().collapsed) {
                                    toggleVoiceInput()
                                }
                            }, 160L)
                        } else {
                            lastPillTapMs = now
                            mainHandler.removeCallbacks(pendingSinglePillTapRunnable)
                            mainHandler.postDelayed(pendingSinglePillTapRunnable, DOUBLE_TAP_WINDOW_MS)
                        }
                    } else if (isHeaderHandle) {
                        // Double-tap expanded header -> toggle Full-Screen Overlay mode
                        val now = System.currentTimeMillis()
                        if (now - lastHeaderTapMs <= DOUBLE_TAP_WINDOW_MS) {
                            lastHeaderTapMs = 0L
                            v.performHapticFeedback(android.view.HapticFeedbackConstants.CLOCK_TICK)
                            toggleFullScreen()
                        } else {
                            lastHeaderTapMs = now
                        }
                    }
                    true
                }
                else -> false
            }
        }
    }

    private fun animateWindowBackToAnchor(
        card: View,
        lp: WindowManager.LayoutParams,
        targetX: Int,
        targetY: Int
    ) {
        val startX = lp.x
        val startY = lp.y
        if (startX == targetX && startY == targetY) return
        edgeSnapAnimator?.cancel()
        if (isReducedMotionEnabled()) {
            lp.x = targetX
            lp.y = targetY
            try {
                windowManager?.updateViewLayout(card, lp)
            } catch (_: Throwable) {}
            return
        }
        edgeSnapAnimator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 200L
            interpolator = OvershootInterpolator(0.75f)
            addUpdateListener { anim ->
                if (!isWindowAttached || rootCard !== card) return@addUpdateListener
                val f = anim.animatedValue as Float
                lp.x = (startX + (targetX - startX) * f).toInt()
                lp.y = (startY + (targetY - startY) * f).toInt()
                try {
                    windowManager?.updateViewLayout(card, lp)
                } catch (_: Throwable) {}
            }
            start()
        }
    }

    private fun cyclePromptHistoryGesture(delta: Int, hapticAnchor: View) {
        val step = store.stepPromptHistory(delta)
        if (step == null) {
            showTransientSubtitle("No recent prompts yet")
            return
        }
        hapticAnchor.performHapticFeedback(android.view.HapticFeedbackConstants.CLOCK_TICK)
        inputEditText?.apply {
            setText(step.text)
            setSelection(step.text.length)
        }
        showTransientSubtitle("Prompt ${step.index}/${step.total}")
    }

    private fun showTransientSubtitle(message: String) {
        transientSubtitleHint = message
        mainHandler.removeCallbacks(clearTransientSubtitleRunnable)
        if (isWindowAttached && store.currentState().visible) {
            subtitleTv?.text = message
            subtitleTv?.setTextColor(activePalette.accentDeep)
        }
        mainHandler.postDelayed(clearTransientSubtitleRunnable, 1800L)
    }

    private fun snapCollapsedPillToEdge(velocityX: Float = 0f, haptic: Boolean = false) {
        val card = rootCard ?: return
        val lp = windowParams ?: return
        if (!isWindowAttached || !store.currentState().collapsed) return

        val d = context.resources.displayMetrics.density.coerceAtLeast(1f)
        val (screenW, _) = resolveScreenSize()
        val marginPx = (10 * d).toInt()
        val pillW = card.width.takeIf { it > 0 } ?: (216 * d).toInt()
        val snap = HudEdgeDockMath.computeSnapTarget(
            currentX = lp.x,
            viewWidth = pillW,
            screenWidth = screenW,
            marginPx = marginPx,
            velocityX = velocityX
        )
        val startX = lp.x
        val targetX = snap.targetX
        if (startX == targetX) return

        edgeSnapAnimator?.cancel()
        if (isReducedMotionEnabled()) {
            lp.x = targetX
            try {
                windowManager?.updateViewLayout(card, lp)
            } catch (_: Throwable) {}
            if (haptic) card.performHapticFeedback(android.view.HapticFeedbackConstants.CLOCK_TICK)
            return
        }

        edgeSnapAnimator = ValueAnimator.ofInt(startX, targetX).apply {
            duration = 250L
            interpolator = OvershootInterpolator(0.85f)
            addUpdateListener { anim ->
                if (!isWindowAttached || rootCard !== card) return@addUpdateListener
                lp.x = anim.animatedValue as Int
                try {
                    windowManager?.updateViewLayout(card, lp)
                } catch (_: Throwable) {}
            }
            start()
        }
        if (haptic) {
            card.performHapticFeedback(android.view.HapticFeedbackConstants.CLOCK_TICK)
        }
    }

    private fun attachSpringPress(view: View) {
        view.setOnTouchListener { v, event ->
            if (!isReducedMotionEnabled()) {
                when (event.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        v.animate()
                            .scaleX(0.90f)
                            .scaleY(0.90f)
                            .setDuration(95L)
                            .setInterpolator(DecelerateInterpolator())
                            .start()
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        v.animate()
                            .scaleX(1f)
                            .scaleY(1f)
                            .setDuration(200L)
                            .setInterpolator(OvershootInterpolator(1.4f))
                            .start()
                    }
                }
            }
            false
        }
    }

    private fun clampPosition(
        lp: WindowManager.LayoutParams,
        bounds: DisplayBounds,
        cardW: Int
    ) {
        val d = context.resources.displayMetrics.density.coerceAtLeast(1f)
        val margin = (8 * d).toInt()
        val effectiveW = if (lp.width > 0) lp.width else cardW.coerceAtLeast((180 * d).toInt())
        val effectiveH = rootCard?.height?.takeIf { it > 0 } ?: (110 * d).toInt()
        val clamped = HudDragBoundsMath.clampToFullDisplay(
            x = lp.x,
            y = lp.y,
            viewWidth = effectiveW,
            viewHeight = effectiveH,
            displayWidth = bounds.width,
            displayHeight = bounds.height,
            edgeMarginPx = margin,
            topInsetPx = margin,
            bottomInsetPx = margin
        )
        lp.x = clamped.x
        lp.y = clamped.y
    }

    private fun resolveDisplayMetrics(): DisplayBounds {
        val d = context.resources.displayMetrics.density.coerceAtLeast(1f)
        var width = 0
        var height = 0
        var topInset = 0
        var bottomInset = 0

        val wm = windowManager
        if (wm != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            try {
                // Always prefer maximumWindowMetrics (full physical display) over app-scoped currentWindowMetrics
                val maxMetrics = wm.maximumWindowMetrics
                val b = maxMetrics.bounds
                if (b.width() > 0 && b.height() > 0) {
                    width = b.width()
                    height = b.height()
                }
                val sysInsets = maxMetrics.windowInsets.getInsetsIgnoringVisibility(
                    WindowInsets.Type.statusBars() or WindowInsets.Type.displayCutout()
                )
                val navInsets = maxMetrics.windowInsets.getInsetsIgnoringVisibility(
                    WindowInsets.Type.navigationBars()
                )
                topInset = sysInsets.top
                bottomInset = navInsets.bottom
            } catch (_: Throwable) {}
        }

        // Cross-check with physical default Display.getRealSize for multi-window / tablet compat safety
        try {
            val defaultDisplay = displayManager?.getDisplay(Display.DEFAULT_DISPLAY)
            if (defaultDisplay != null) {
                val pt = Point()
                @Suppress("DEPRECATION")
                defaultDisplay.getRealSize(pt)
                if (pt.x > 0 && pt.y > 0) {
                    if (width <= 0 || height <= 0 || pt.x > width || pt.y > height) {
                        width = max(width, pt.x)
                        height = max(height, pt.y)
                    }
                }
            }
        } catch (_: Throwable) {}

        if (width <= 0 || height <= 0) {
            val dm = context.resources.displayMetrics
            width = dm.widthPixels.coerceAtLeast(360)
            height = dm.heightPixels.coerceAtLeast(640)
        }

        if (topInset <= 0) {
            val resId = context.resources.getIdentifier("status_bar_height", "dimen", "android")
            topInset = if (resId > 0) {
                context.resources.getDimensionPixelSize(resId)
            } else {
                (28 * d).toInt()
            }
        }
        if (bottomInset <= 0) {
            bottomInset = (18 * d).toInt()
        }

        return DisplayBounds(
            width = width,
            height = height,
            topInset = topInset,
            bottomInset = bottomInset
        )
    }

    private fun resolveScreenSize(): Pair<Int, Int> {
        val b = resolveDisplayMetrics()
        return b.width to b.height
    }

    private fun isReducedMotionEnabled(): Boolean {
        return try {
            Settings.Global.getFloat(
                context.contentResolver,
                Settings.Global.ANIMATOR_DURATION_SCALE,
                1.0f
            ) == 0f
        } catch (_: Throwable) {
            false
        }
    }

    private fun resolveCurrentPalette(): ResolvedHudPalette {
        val uiMode = context.resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK
        val isSystemDark = uiMode == android.content.res.Configuration.UI_MODE_NIGHT_YES
        return ResolvedHudPalette.resolve(currentAppearance, isSystemDark = isSystemDark)
    }

    private fun runOnMain(block: () -> Unit) {
        if (Looper.myLooper() == Looper.getMainLooper()) block() else mainHandler.post(block)
    }

    // -------------------------------------------------------------------------
    // Layered Apple Liquid Glass Backdrop Surface (White / Smoked / Auto + Accents)
    // -------------------------------------------------------------------------

    private class LiquidGlassHudSurface(
        context: Context,
        initialPalette: ResolvedHudPalette
    ) : LinearLayout(context) {
        private val d = context.resources.displayMetrics.density.coerceAtLeast(1f)
        private val bodyRect = RectF()
        private val sheenRect = RectF()
        private val borderRect = RectF()

        private val basePaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val topSheenPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val activeSweepPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val rimPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 1.25f * d
        }

        private var palette: ResolvedHudPalette = initialPalette
        private var pillMode: Boolean = false
        private var fullScreenMode: Boolean = false
        private var accentActive: Boolean = false
        private var shimmerPhase: Float = 0f
        private var shimmerRunning: Boolean = false

        private val shimmerAnimator = ValueAnimator.ofFloat(-0.35f, 1.35f).apply {
            duration = 2600L
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.RESTART
            interpolator = LinearInterpolator()
            addUpdateListener {
                shimmerPhase = it.animatedValue as Float
                invalidate()
            }
        }

        init {
            setWillNotDraw(false)
            clipToOutline = true
        }

        fun setGlassState(
            pillMode: Boolean,
            fullScreenMode: Boolean = false,
            shimmerActive: Boolean,
            accentActive: Boolean,
            palette: ResolvedHudPalette
        ) {
            var dirty = false
            if (this.palette.signature != palette.signature) {
                this.palette = palette
                dirty = true
            }
            if (this.pillMode != pillMode || this.fullScreenMode != fullScreenMode) {
                this.pillMode = pillMode
                this.fullScreenMode = fullScreenMode
                updateOutlineProvider()
                dirty = true
            }
            if (this.accentActive != accentActive) {
                this.accentActive = accentActive
                dirty = true
            }
            if (shimmerRunning != shimmerActive) {
                shimmerRunning = shimmerActive
                if (shimmerActive) {
                    if (!shimmerAnimator.isStarted) shimmerAnimator.start()
                } else {
                    shimmerAnimator.cancel()
                    shimmerPhase = -0.35f
                    dirty = true
                }
            }
            if (dirty) invalidate()
        }

        fun stopAnimations() {
            shimmerAnimator.cancel()
            shimmerRunning = false
        }

        private fun updateOutlineProvider() {
            val radius = when {
                fullScreenMode -> 0f
                pillMode -> 28f * d
                else -> 24f * d
            }
            outlineProvider = object : android.view.ViewOutlineProvider() {
                override fun getOutline(view: View, outline: android.graphics.Outline) {
                    if (radius <= 0f) {
                        outline.setRect(0, 0, view.width, view.height)
                    } else {
                        outline.setRoundRect(0, 0, view.width, view.height, min(radius, view.height / 2f))
                    }
                }
            }
            invalidateOutline()
        }

        override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
            super.onSizeChanged(w, h, oldw, oldh)
            updateOutlineProvider()
        }

        override fun onDetachedFromWindow() {
            shimmerAnimator.cancel()
            super.onDetachedFromWindow()
        }

        override fun onDraw(canvas: Canvas) {
            val w = width.toFloat()
            val h = height.toFloat()
            if (w <= 0f || h <= 0f) {
                super.onDraw(canvas)
                return
            }

            val p = palette
            val radius = when {
                fullScreenMode -> 0f
                pillMode -> min(28f * d, h / 2f)
                else -> min(24f * d, h / 2f)
            }
            bodyRect.set(0f, 0f, w, h)

            // 1. Frosted Liquid Glass gradient base (White or Smoked with live frost alpha)
            basePaint.shader = LinearGradient(
                0f, 0f, 0f, h,
                intArrayOf(p.surfaceTop, p.surfaceMid, p.surfaceBottom),
                floatArrayOf(0f, 0.52f, 1f),
                Shader.TileMode.CLAMP
            )
            canvas.drawRoundRect(bodyRect, radius, radius, basePaint)

            // 2. Top specular refraction glass sheen
            val sheenH = (h * 0.36f).coerceAtLeast(28f * d)
            sheenRect.set(0f, 0f, w, sheenH)
            topSheenPaint.shader = LinearGradient(
                0f, 0f, 0f, sheenH,
                p.sheenTop,
                Color.TRANSPARENT,
                Shader.TileMode.CLAMP
            )
            canvas.drawRoundRect(bodyRect, radius, radius, topSheenPaint)

            // 3. Subtle moving accent liquid shimmer when actively working / awaiting approval
            if (shimmerRunning) {
                val centerX = w * shimmerPhase
                val band = w * 0.34f
                activeSweepPaint.shader = LinearGradient(
                    centerX - band, 0f, centerX + band, h * 0.6f,
                    intArrayOf(
                        Color.TRANSPARENT,
                        p.shimmerBand,
                        p.shimmerCore,
                        Color.TRANSPARENT
                    ),
                    floatArrayOf(0f, 0.42f, 0.58f, 1f),
                    Shader.TileMode.CLAMP
                )
                canvas.drawRoundRect(bodyRect, radius, radius, activeSweepPaint)
            }

            // 4. Dual-tone luminous glass rim border (omitted in edge-to-edge full-screen mode)
            if (!fullScreenMode) {
                val halfStroke = rimPaint.strokeWidth / 2f
                borderRect.set(halfStroke, halfStroke, w - halfStroke, h - halfStroke)
                val edgeBottomColor = if (accentActive) p.rimBottomActive else p.rimBottomIdle
                rimPaint.shader = LinearGradient(
                    0f, 0f, w, h,
                    intArrayOf(p.rimTop, p.rimMid, edgeBottomColor),
                    floatArrayOf(0f, 0.45f, 1f),
                    Shader.TileMode.CLAMP
                )
                canvas.drawRoundRect(borderRect, radius, radius, rimPaint)
            }

            super.onDraw(canvas)
        }
    }

    /**
     * Compact 34dp App/Task Icon Badge with dual-ring accent breathing halo when WORKING / NEEDS_INPUT.
     */
    private class HudLogoBadgeView(
        context: Context,
        initialPalette: ResolvedHudPalette
    ) : View(context) {
        private val d = context.resources.displayMetrics.density.coerceAtLeast(1f)
        private var resolvedIcon: AgyAppIconResolver.ResolvedIcon = AgyAppIconResolver.resolve(context)
        private var palette: ResolvedHudPalette = initialPalette
        private var pulsePhase: Float = 0f
        private var pulsing: Boolean = false
        private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 2.0f * d
            color = initialPalette.accentPrimary
        }
        private val outerHaloPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 1.2f * d
            color = initialPalette.accentSoft
        }
        private val animator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 1350L
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.REVERSE
            interpolator = DecelerateInterpolator()
            addUpdateListener {
                pulsePhase = it.animatedValue as Float
                invalidate()
            }
        }

        fun updateIcon(
            icon: AgyAppIconResolver.ResolvedIcon,
            pulsing: Boolean,
            palette: ResolvedHudPalette
        ) {
            resolvedIcon = icon
            this.palette = palette
            ringPaint.color = palette.accentPrimary
            outerHaloPaint.color = palette.accentSoft
            if (this.pulsing != pulsing) {
                this.pulsing = pulsing
                if (pulsing) {
                    if (!animator.isStarted) animator.start()
                } else {
                    animator.cancel()
                    pulsePhase = 0f
                }
            }
            invalidate()
        }

        override fun onDetachedFromWindow() {
            animator.cancel()
            super.onDetachedFromWindow()
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val pad = 3.5f * d
            canvas.save()
            canvas.translate(pad, pad)
            val innerW = (width - pad * 2f).coerceAtLeast(1f)
            val innerH = (height - pad * 2f).coerceAtLeast(1f)
            AgyAppIconResolver.drawBadgeOnCanvas(canvas, innerW, innerH, resolvedIcon)
            AgyAppIconResolver.drawActionSubBadge(
                canvas,
                innerW,
                innerH,
                resolvedIcon.actionKind,
                surfaceRingColor = palette.actionRingColor
            )
            canvas.restore()

            if (pulsing) {
                val cx = width / 2f
                val cy = height / 2f
                val baseR = (min(width, height) / 2f) - 2.2f * d
                ringPaint.alpha = (110 + (125 * pulsePhase)).toInt().coerceIn(80, 235)
                canvas.drawCircle(cx, cy, baseR, ringPaint)

                outerHaloPaint.alpha = ((1f - pulsePhase) * 140f).toInt().coerceIn(0, 140)
                canvas.drawCircle(cx, cy, baseR + (1.6f * d * pulsePhase), outerHaloPaint)
            }
        }
    }
}
