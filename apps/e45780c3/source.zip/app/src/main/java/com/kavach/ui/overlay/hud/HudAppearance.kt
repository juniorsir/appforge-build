package com.kavach.ui.overlay.hud

import android.content.Context
import android.graphics.Color
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

private val Context.hudAppearanceDataStore: DataStore<Preferences> by preferencesDataStore(
    name = "agy_hud_appearance_prefs"
)

enum class HudAccentPreset(
    val id: String,
    val label: String,
    val primaryHex: String,
    val deepHex: String,
    val softHex: String,
    val orbSecondaryHex: String
) {
    SKY_BLUE(
        id = "sky_blue",
        label = "Sky Blue",
        primaryHex = "#0EA5E9",
        deepHex = "#0284C7",
        softHex = "#38BDF8",
        orbSecondaryHex = "#93C5FD"
    ),
    VIOLET_MIST(
        id = "violet_mist",
        label = "Violet Mist",
        primaryHex = "#8B5CF6",
        deepHex = "#6D28D9",
        softHex = "#A78BFA",
        orbSecondaryHex = "#C4B5FD"
    ),
    MINT_JADE(
        id = "mint_jade",
        label = "Mint Jade",
        primaryHex = "#10B981",
        deepHex = "#047857",
        softHex = "#34D399",
        orbSecondaryHex = "#6EE7B7"
    ),
    SUNSET_CORAL(
        id = "sunset_coral",
        label = "Sunset Coral",
        primaryHex = "#F43F5E",
        deepHex = "#BE123C",
        softHex = "#FB7185",
        orbSecondaryHex = "#FDA4AF"
    );

    companion object {
        fun fromId(raw: String?): HudAccentPreset {
            val clean = raw?.trim()?.lowercase().orEmpty()
            return entries.firstOrNull { it.id == clean || it.name.equals(clean, ignoreCase = true) }
                ?: SKY_BLUE
        }
    }
}

enum class HudGlassMode(
    val id: String,
    val label: String
) {
    WHITE("white", "White"),
    AUTO("auto", "Auto"),
    SMOKED("smoked", "Smoked");

    companion object {
        fun fromId(raw: String?): HudGlassMode {
            val clean = raw?.trim()?.lowercase().orEmpty()
            return entries.firstOrNull { it.id == clean || it.name.equals(clean, ignoreCase = true) }
                ?: WHITE
        }
    }
}

data class HudAppearanceConfig(
    val accent: HudAccentPreset = HudAccentPreset.SKY_BLUE,
    val surfaceMode: HudGlassMode = HudGlassMode.WHITE,
    val frostStrength: Float = 0.86f,
    val magneticEdgeDock: Boolean = true,
    val shakeToSummon: Boolean = false
) {
    val clampedFrost: Float
        get() = frostStrength.coerceIn(MIN_FROST, MAX_FROST)

    companion object {
        const val MIN_FROST = 0.72f
        const val MAX_FROST = 0.95f
    }
}

/**
 * Pure resolved color tokens for both the native WindowManager HUD Canvas/Views and
 * the Jetpack Compose AeroShare Dashboard, ensuring identical Liquid Glass aesthetics.
 */
data class ResolvedHudPalette(
    val isDark: Boolean,
    val frostStrength: Float,
    val accentPreset: HudAccentPreset,
    val surfaceTop: Int,
    val surfaceMid: Int,
    val surfaceBottom: Int,
    val sheenTop: Int,
    val rimTop: Int,
    val rimMid: Int,
    val rimBottomIdle: Int,
    val rimBottomActive: Int,
    val shimmerBand: Int,
    val shimmerCore: Int,
    val cardBgTop: Int,
    val cardBgBottom: Int,
    val innerBg: Int,
    val inputPillBg: Int,
    val inputPillBorder: Int,
    val borderNeutral: Int,
    val borderAccent: Int,
    val textPrimary: Int,
    val textSecondary: Int,
    val textPlaceholder: Int,
    val accentPrimary: Int,
    val accentDeep: Int,
    val accentSoft: Int,
    val accentPillBg: Int,
    val accentPillBorder: Int,
    val iconSurfaceFill: Int,
    val iconSurfaceBorder: Int,
    val actionRingColor: Int,
    val shadowAmbient: Int,
    val shadowSpot: Int,
    val orbPrimary: Int,
    val orbSecondary: Int
) {
    val signature: String
        get() = "${accentPreset.id}|$isDark|${(frostStrength * 100).roundToInt()}"

    companion object {
        fun resolve(config: HudAppearanceConfig, isSystemDark: Boolean): ResolvedHudPalette {
            val dark = when (config.surfaceMode) {
                HudGlassMode.WHITE -> false
                HudGlassMode.SMOKED -> true
                HudGlassMode.AUTO -> isSystemDark
            }
            val frost = config.clampedFrost
            val accentPrimary = Color.parseColor(config.accent.primaryHex)
            val accentDeep = Color.parseColor(config.accent.deepHex)
            val accentSoft = Color.parseColor(config.accent.softHex)
            val orbSecondary = Color.parseColor(config.accent.orbSecondaryHex)

            return if (!dark) {
                val topAlpha = ((frost + 0.07f).coerceAtMost(0.97f) * 255f).roundToInt()
                val midAlpha = (frost * 255f).roundToInt()
                val botAlpha = ((frost - 0.04f).coerceAtLeast(0.68f) * 255f).roundToInt()
                val cardTopA = ((frost + 0.04f).coerceAtMost(0.95f) * 255f).roundToInt()
                val cardBotA = ((frost - 0.05f).coerceAtLeast(0.66f) * 255f).roundToInt()

                ResolvedHudPalette(
                    isDark = false,
                    frostStrength = frost,
                    accentPreset = config.accent,
                    surfaceTop = Color.argb(topAlpha, 255, 255, 255),
                    surfaceMid = Color.argb(midAlpha, 247, 251, 255),
                    surfaceBottom = Color.argb(botAlpha, 234, 244, 255),
                    sheenTop = Color.argb(242, 255, 255, 255),
                    rimTop = Color.argb(252, 255, 255, 255),
                    rimMid = withAlpha(accentSoft, 0.34f),
                    rimBottomIdle = Color.argb(42, 15, 23, 42),
                    rimBottomActive = withAlpha(accentPrimary, 0.44f),
                    shimmerBand = withAlpha(accentSoft, 0.16f),
                    shimmerCore = Color.argb(56, 255, 255, 255),
                    cardBgTop = Color.argb(cardTopA, 255, 255, 255),
                    cardBgBottom = Color.argb(cardBotA, 248, 251, 255),
                    innerBg = Color.argb(208, 241, 246, 253),
                    inputPillBg = Color.argb(((frost + 0.02f).coerceAtMost(0.94f) * 255f).roundToInt(), 255, 255, 255),
                    inputPillBorder = withAlpha(accentPrimary, 0.24f),
                    borderNeutral = Color.argb(34, 15, 23, 42),
                    borderAccent = withAlpha(accentPrimary, 0.28f),
                    textPrimary = Color.parseColor("#0F172A"),
                    textSecondary = Color.parseColor("#475569"),
                    textPlaceholder = Color.parseColor("#64748B"),
                    accentPrimary = accentPrimary,
                    accentDeep = accentDeep,
                    accentSoft = accentSoft,
                    accentPillBg = withAlpha(accentPrimary, 0.13f),
                    accentPillBorder = withAlpha(accentPrimary, 0.30f),
                    iconSurfaceFill = Color.argb(226, 241, 245, 249),
                    iconSurfaceBorder = Color.argb(34, 15, 23, 42),
                    actionRingColor = Color.argb(245, 255, 255, 255),
                    shadowAmbient = withAlpha(accentDeep, 0.18f),
                    shadowSpot = Color.argb(56, 15, 23, 42),
                    orbPrimary = accentSoft,
                    orbSecondary = orbSecondary
                )
            } else {
                val topAlpha = ((frost + 0.05f).coerceAtMost(0.96f) * 255f).roundToInt()
                val midAlpha = (frost * 255f).roundToInt()
                val botAlpha = ((frost - 0.03f).coerceAtLeast(0.70f) * 255f).roundToInt()
                val cardTopA = ((frost - 0.06f).coerceAtLeast(0.62f) * 255f).roundToInt()
                val cardBotA = ((frost - 0.10f).coerceAtLeast(0.58f) * 255f).roundToInt()

                ResolvedHudPalette(
                    isDark = true,
                    frostStrength = frost,
                    accentPreset = config.accent,
                    surfaceTop = Color.argb(topAlpha, 22, 31, 48),
                    surfaceMid = Color.argb(midAlpha, 15, 23, 38),
                    surfaceBottom = Color.argb(botAlpha, 11, 18, 32),
                    sheenTop = Color.argb(54, 255, 255, 255),
                    rimTop = Color.argb(92, 255, 255, 255),
                    rimMid = withAlpha(accentSoft, 0.36f),
                    rimBottomIdle = Color.argb(46, 255, 255, 255),
                    rimBottomActive = withAlpha(accentPrimary, 0.56f),
                    shimmerBand = withAlpha(accentSoft, 0.22f),
                    shimmerCore = Color.argb(42, 255, 255, 255),
                    cardBgTop = Color.argb(cardTopA, 30, 41, 59),
                    cardBgBottom = Color.argb(cardBotA, 19, 28, 44),
                    innerBg = Color.argb(185, 15, 23, 42),
                    inputPillBg = Color.argb(((frost - 0.04f).coerceAtLeast(0.66f) * 255f).roundToInt(), 30, 41, 59),
                    inputPillBorder = withAlpha(accentSoft, 0.34f),
                    borderNeutral = Color.argb(48, 255, 255, 255),
                    borderAccent = withAlpha(accentSoft, 0.42f),
                    textPrimary = Color.parseColor("#F8FAFC"),
                    textSecondary = Color.parseColor("#CBD5E1"),
                    textPlaceholder = Color.parseColor("#94A3B8"),
                    accentPrimary = accentPrimary,
                    accentDeep = accentSoft,
                    accentSoft = accentSoft,
                    accentPillBg = withAlpha(accentPrimary, 0.22f),
                    accentPillBorder = withAlpha(accentSoft, 0.42f),
                    iconSurfaceFill = Color.argb(170, 51, 65, 85),
                    iconSurfaceBorder = Color.argb(56, 255, 255, 255),
                    actionRingColor = Color.argb(240, 15, 23, 42),
                    shadowAmbient = withAlpha(accentPrimary, 0.24f),
                    shadowSpot = Color.argb(120, 2, 6, 23),
                    orbPrimary = accentPrimary,
                    orbSecondary = orbSecondary
                )
            }
        }

        fun withAlpha(color: Int, alphaFraction: Float): Int {
            val a = (alphaFraction.coerceIn(0f, 1f) * 255f).roundToInt()
            return Color.argb(a, Color.red(color), Color.green(color), Color.blue(color))
        }
    }
}

/**
 * Pure geometry helper for magnetic left/right edge docking of the collapsed HUD pill.
 */
object HudEdgeDockMath {
    data class DockSnapResult(
        val targetX: Int,
        val dockedRight: Boolean
    )

    fun computeSnapTarget(
        currentX: Int,
        viewWidth: Int,
        screenWidth: Int,
        marginPx: Int,
        velocityX: Float = 0f
    ): DockSnapResult {
        val safeViewW = viewWidth.coerceAtLeast(1)
        val minX = marginPx.coerceAtLeast(0)
        val maxX = (screenWidth - safeViewW - minX).coerceAtLeast(minX)
        val center = currentX + safeViewW / 2f
        val screenMid = screenWidth / 2f
        val flingRight = velocityX > 380f
        val flingLeft = velocityX < -380f
        val dockRight = when {
            flingRight -> true
            flingLeft -> false
            else -> center >= screenMid
        }
        return DockSnapResult(
            targetX = if (dockRight) maxX else minX,
            dockedRight = dockRight
        )
    }
}

/**
 * Pure display geometry & gesture classification helpers for tablet, foldable,
 * and large-screen full-display HUD dragging and Full-Screen Overlay sizing.
 */
object HudDragBoundsMath {
    const val PHONE_MAX_CARD_DP = 344f
    const val TABLET_MAX_CARD_DP = 380f
    const val TABLET_BREAKPOINT_DP = 600f
    const val FULLSCREEN_CONTENT_MAX_DP = 680f

    data class ClampedPoint(
        val x: Int,
        val y: Int
    )

    fun computeFloatingCardWidth(screenWidthPx: Int, density: Float): Int {
        val d = density.coerceAtLeast(1f)
        val screenWidthDp = screenWidthPx / d
        val targetMaxDp = if (screenWidthDp >= TABLET_BREAKPOINT_DP) TABLET_MAX_CARD_DP else PHONE_MAX_CARD_DP
        val minW = (248f * d).roundToInt()
        val availW = (screenWidthPx - (24f * d).roundToInt()).coerceAtLeast(minW)
        return minOf((targetMaxDp * d).roundToInt(), availW)
    }

    fun computeFullScreenContentWidth(screenWidthPx: Int, density: Float): Int {
        val d = density.coerceAtLeast(1f)
        val minW = (260f * d).roundToInt()
        val availW = (screenWidthPx - (32f * d).roundToInt()).coerceAtLeast(minW)
        return minOf((FULLSCREEN_CONTENT_MAX_DP * d).roundToInt(), availW)
    }

    /**
     * Clamps a floating overlay coordinate to the true full physical display bounds,
     * allowing edge-to-edge reach across tablets, foldables, and landscape screens.
     */
    fun clampToFullDisplay(
        x: Int,
        y: Int,
        viewWidth: Int,
        viewHeight: Int,
        displayWidth: Int,
        displayHeight: Int,
        edgeMarginPx: Int,
        topInsetPx: Int = 0,
        bottomInsetPx: Int = 0
    ): ClampedPoint {
        val margin = edgeMarginPx.coerceAtLeast(0)
        val safeW = viewWidth.coerceAtLeast(1)
        val safeH = viewHeight.coerceAtLeast(1)
        val minX = margin
        val maxX = (displayWidth - safeW - margin).coerceAtLeast(minX)
        val minY = maxOf(margin, topInsetPx.coerceAtLeast(0))
        val maxY = (displayHeight - safeH - maxOf(margin, bottomInsetPx.coerceAtLeast(0))).coerceAtLeast(minY)
        return ClampedPoint(
            x = x.coerceIn(minX, maxX),
            y = y.coerceIn(minY, maxY)
        )
    }

    /**
     * Distinguishes a short, crisp horizontal flick (for recalling prompt history) from a
     * free positional drag across a phone or wide tablet display.
     */
    fun isShortHorizontalPromptFlick(
        dxPx: Float,
        dyPx: Float,
        durationMs: Long,
        density: Float
    ): Boolean {
        if (durationMs !in 1L..220L) return false
        val d = density.coerceAtLeast(1f)
        val absDx = kotlin.math.abs(dxPx)
        val absDy = kotlin.math.abs(dyPx)
        val minFlickPx = 42f * d
        val maxFlickPx = 128f * d
        if (absDx < minFlickPx || absDx > maxFlickPx) return false
        if (absDx <= absDy * 1.75f) return false
        val velocityDpPerSec = (absDx / d) / (durationMs.coerceAtLeast(16L) / 1000f)
        return velocityDpPerSec >= 260f
    }
}

/**
 * Local Jetpack DataStore repository for HUD Liquid Glass appearance & gesture preferences.
 */
class HudAppearanceRepository(
    private val context: Context,
    private val scope: CoroutineScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
) {
    private object Keys {
        val ACCENT = stringPreferencesKey("hud_accent_preset")
        val GLASS_MODE = stringPreferencesKey("hud_glass_mode")
        val FROST = floatPreferencesKey("hud_frost_strength")
        val MAGNETIC_DOCK = booleanPreferencesKey("hud_magnetic_edge_dock")
        val SHAKE_SUMMON = booleanPreferencesKey("hud_shake_to_summon")
    }

    private val _config = MutableStateFlow(HudAppearanceConfig())
    val config: StateFlow<HudAppearanceConfig> = _config.asStateFlow()

    init {
        scope.launch {
            context.hudAppearanceDataStore.data
                .catch { /* keep defaults on read error */ }
                .map { prefs ->
                    HudAppearanceConfig(
                        accent = HudAccentPreset.fromId(prefs[Keys.ACCENT]),
                        surfaceMode = HudGlassMode.fromId(prefs[Keys.GLASS_MODE]),
                        frostStrength = (prefs[Keys.FROST] ?: 0.86f)
                            .coerceIn(HudAppearanceConfig.MIN_FROST, HudAppearanceConfig.MAX_FROST),
                        magneticEdgeDock = prefs[Keys.MAGNETIC_DOCK] ?: true,
                        shakeToSummon = prefs[Keys.SHAKE_SUMMON] ?: false
                    )
                }
                .collect { loaded ->
                    _config.value = loaded
                }
        }
    }

    fun setAccent(accent: HudAccentPreset) {
        _config.value = _config.value.copy(accent = accent)
        scope.launch {
            runCatching {
                context.hudAppearanceDataStore.edit { it[Keys.ACCENT] = accent.id }
            }
        }
    }

    fun setSurfaceMode(mode: HudGlassMode) {
        _config.value = _config.value.copy(surfaceMode = mode)
        scope.launch {
            runCatching {
                context.hudAppearanceDataStore.edit { it[Keys.GLASS_MODE] = mode.id }
            }
        }
    }

    fun setFrostStrength(frost: Float) {
        val clamped = frost.coerceIn(HudAppearanceConfig.MIN_FROST, HudAppearanceConfig.MAX_FROST)
        _config.value = _config.value.copy(frostStrength = clamped)
        scope.launch {
            runCatching {
                context.hudAppearanceDataStore.edit { it[Keys.FROST] = clamped }
            }
        }
    }

    fun setMagneticEdgeDock(enabled: Boolean) {
        _config.value = _config.value.copy(magneticEdgeDock = enabled)
        scope.launch {
            runCatching {
                context.hudAppearanceDataStore.edit { it[Keys.MAGNETIC_DOCK] = enabled }
            }
        }
    }

    fun setShakeToSummon(enabled: Boolean) {
        _config.value = _config.value.copy(shakeToSummon = enabled)
        scope.launch {
            runCatching {
                context.hudAppearanceDataStore.edit { it[Keys.SHAKE_SUMMON] = enabled }
            }
        }
    }
}
