package com.example.ui.theme

import android.app.Activity
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

@Composable
fun SystemBarsThemeSync(isWhiteTheme: Boolean = false) {
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window ?: return@SideEffect
            val controller = WindowCompat.getInsetsController(window, view)
            controller.isAppearanceLightStatusBars = false
            controller.isAppearanceLightNavigationBars = false
        }
    }
}

private val NexoraDarkColorScheme = darkColorScheme(
    primary = NexoraColors.ElectricIndigo,
    onPrimary = Color.White,
    primaryContainer = NexoraColors.Sky100,
    onPrimaryContainer = Color(0xFFF5F5F5),
    secondary = NexoraColors.Lavender500,
    onSecondary = Color.White,
    secondaryContainer = NexoraColors.Lavender200,
    onSecondaryContainer = Color(0xFFF5F5F5),
    tertiary = NexoraColors.InstagramSunsetAmber,
    background = Color(0xFF1E1E1E),
    onBackground = Color(0xFFF5F5F5),
    surface = Color(0xFF2A2A2E),
    onSurface = Color(0xFFF5F5F5),
    surfaceVariant = Color(0xFF343439),
    onSurfaceVariant = Color(0xFFB4B4B4),
    outline = Color(0xFF38383D),
    outlineVariant = Color(0xFF45454B),
    error = NexoraColors.LiveRose,
    onError = Color.White
)

@Composable
fun NexoraTheme(
    isWhiteTheme: Boolean = false,
    content: @Composable () -> Unit
) {
    SystemBarsThemeSync(isWhiteTheme = false)

    MaterialTheme(
        colorScheme = NexoraDarkColorScheme,
        typography = NexoraTypography.MaterialTypography,
        content = content
    )
}
