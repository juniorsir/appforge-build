package com.example.ui.theme

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * 1. Floating Header & Navigation Bars:
 *    - Deep Instagram Dark Charcoal (#121212) frosted glass with subtle top sheen and #262626 rim
 */
fun Modifier.liquidGlassNav(cornerRadius: Dp = 999.dp): Modifier {
    val shape = RoundedCornerShape(cornerRadius)
    return this
        .shadow(
            elevation = 12.dp,
            shape = shape,
            ambientColor = Color(0x80000000),
            spotColor = Color(0x99000000)
        )
        .clip(shape)
        .background(
            brush = Brush.verticalGradient(
                colors = listOf(
                    Color(0xF52A2A2D),
                    Color(0xF8242426)
                )
            ),
            shape = shape
        )
        .drawWithCache {
            val radiusPx = cornerRadius.toPx()
            val topGlossBrush = Brush.verticalGradient(
                colors = listOf(Color(0x14FFFFFF), Color.Transparent),
                startY = 0f,
                endY = size.height * 0.48f
            )
            onDrawWithContent {
                drawRoundRect(
                    brush = topGlossBrush,
                    cornerRadius = CornerRadius(radiusPx, radiusPx),
                    size = Size(size.width, size.height * 0.48f)
                )
                drawContent()
            }
        }
        .border(width = 1.dp, color = NexoraColors.SpecularBorderNav, shape = shape)
}

/**
 * 2. Video Cards, Bento Panels, Hero Containers:
 *    - Premium Dark Charcoal spatial container with subtle specular hairline
 */
fun Modifier.liquidGlassCard(cornerRadius: Dp = 24.dp): Modifier {
    val shape = RoundedCornerShape(cornerRadius)
    return this
        .shadow(
            elevation = 16.dp,
            shape = shape,
            ambientColor = NexoraColors.AmbientShadowTint,
            spotColor = NexoraColors.AmbientShadowTint
        )
        .clip(shape)
        .background(
            brush = Brush.verticalGradient(
                colors = listOf(
                    Color(0xFF28282B),
                    Color(0xFF232325)
                )
            ),
            shape = shape
        )
        .drawWithCache {
            val strokePx = 1.dp.toPx()
            val radiusPx = cornerRadius.toPx()
            val innerHighlightBrush = Brush.verticalGradient(
                colors = listOf(Color(0x18FFFFFF), Color.Transparent),
                startY = 0f,
                endY = size.height * 0.35f
            )
            onDrawWithContent {
                drawContent()
                drawRoundRect(
                    brush = innerHighlightBrush,
                    cornerRadius = CornerRadius(radiusPx, radiusPx),
                    style = Stroke(width = strokePx)
                )
            }
        }
        .border(width = 1.dp, color = NexoraColors.SpecularBorderStrong, shape = shape)
}

/**
 * 3. Primary CTA Buttons, Active Filter Pills, Verified Studio Badges:
 *    - Deep Instagram Blue (#0095F6) & Sunset tinted surface with luminous Instagram Blue border
 */
fun Modifier.liquidGlassAccent(cornerRadius: Dp = 999.dp): Modifier {
    val shape = RoundedCornerShape(cornerRadius)
    return this
        .shadow(
            elevation = 8.dp,
            shape = shape,
            ambientColor = Color(0x400095F6),
            spotColor = Color(0x458134AF)
        )
        .clip(shape)
        .background(
            brush = Brush.linearGradient(
                colors = listOf(
                    Color(0x330095F6),
                    Color(0x268134AF),
                    Color(0x380095F6)
                ),
                start = Offset.Zero,
                end = Offset.Infinite
            ),
            shape = shape
        )
        .border(width = 1.dp, color = Color(0x880095F6), shape = shape)
}

/**
 * 4. Secondary Action Pills, Active Navbar Pills, Stat Pills:
 *    - Dark Charcoal Spatial Pill
 */
fun Modifier.liquidGlassWhitePill(cornerRadius: Dp = 999.dp): Modifier {
    val shape = RoundedCornerShape(cornerRadius)
    return this
        .shadow(
            elevation = 4.dp,
            shape = shape,
            ambientColor = Color(0x66000000),
            spotColor = Color(0x80000000)
        )
        .clip(shape)
        .background(
            brush = Brush.verticalGradient(
                colors = listOf(Color(0xFF323235), Color(0xFF2A2A2D))
            ),
            shape = shape
        )
        .drawWithCache {
            val radiusPx = cornerRadius.toPx()
            val topSheen = Brush.verticalGradient(
                colors = listOf(Color(0x14FFFFFF), Color.Transparent),
                startY = 0f,
                endY = size.height * 0.50f
            )
            onDrawWithContent {
                drawRoundRect(
                    brush = topSheen,
                    cornerRadius = CornerRadius(radiusPx, radiusPx)
                )
                drawContent()
            }
        }
        .border(width = 1.dp, color = NexoraColors.SpecularBorderSubtle, shape = shape)
}

/**
 * 5. Elevated Dragged Glass Capsule (Dark Refractive Droplet with Instagram Sunset + Blue Rim):
 */
fun Modifier.liquidGlassElevatedCapsule(cornerRadius: Dp = 999.dp): Modifier {
    val shape = RoundedCornerShape(cornerRadius)
    return this
        .clip(shape)
        .background(
            brush = Brush.linearGradient(
                colors = listOf(
                    Color(0xCC262626),
                    Color(0xB3121212),
                    Color(0x4D0095F6)
                ),
                start = Offset.Zero,
                end = Offset.Infinite
            ),
            shape = shape
        )
        .drawWithCache {
            val radiusPx = cornerRadius.toPx()
            val strokePx = 1.2.dp.toPx()
            val topSpecularCrescent = Brush.verticalGradient(
                colors = listOf(
                    Color(0x2EFFFFFF),
                    Color(0x12FFFFFF),
                    Color.Transparent
                ),
                startY = 0f,
                endY = size.height * 0.46f
            )
            val diagonalRefractionBand = Brush.linearGradient(
                colors = listOf(
                    Color.Transparent,
                    Color(0x240095F6),
                    Color(0x24DD2A7B),
                    Color.Transparent
                ),
                start = Offset(0f, 0f),
                end = Offset(size.width, size.height)
            )
            val innerCausticStroke = Brush.verticalGradient(
                colors = listOf(
                    Color(0x880095F6),
                    Color(0x66DD2A7B),
                    Color(0x66F58529)
                )
            )
            onDrawWithContent {
                drawRoundRect(
                    brush = diagonalRefractionBand,
                    cornerRadius = CornerRadius(radiusPx, radiusPx)
                )
                drawRoundRect(
                    brush = topSpecularCrescent,
                    cornerRadius = CornerRadius(radiusPx, radiusPx),
                    size = Size(size.width, size.height * 0.46f)
                )
                drawContent()
                drawRoundRect(
                    brush = innerCausticStroke,
                    cornerRadius = CornerRadius(radiusPx, radiusPx),
                    style = Stroke(width = strokePx)
                )
            }
        }
        .border(
            width = 1.2.dp,
            brush = Brush.linearGradient(
                colors = listOf(
                    NexoraColors.InstagramSunsetAmber,
                    NexoraColors.InstagramSunsetPink,
                    NexoraColors.InstagramSunsetPurple,
                    NexoraColors.ElectricIndigo
                ),
                start = Offset.Zero,
                end = Offset.Infinite
            ),
            shape = shape
        )
}

/**
 * 6. Badges over Video Thumbnails & Hero Banners:
 */
fun Modifier.liquidGlassDarkOverlay(cornerRadius: Dp = 999.dp): Modifier {
    val shape = RoundedCornerShape(cornerRadius)
    return this
        .clip(shape)
        .background(color = Color(0xB3000000), shape = shape)
        .border(width = 1.dp, color = Color(0x33FFFFFF), shape = shape)
}
