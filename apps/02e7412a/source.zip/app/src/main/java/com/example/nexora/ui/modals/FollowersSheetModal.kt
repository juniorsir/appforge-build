package com.example.nexora.ui.modals

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.nexora.animation.BubbleModalPanel
import com.example.nexora.animation.ClickOrigin
import com.example.nexora.data.CreatorProfile
import com.example.nexora.ui.components.CreatorAvatarBadge
import com.example.ui.theme.NexoraColors
import com.example.ui.theme.NexoraTypography
import com.example.ui.theme.liquidGlassAccent
import com.example.ui.theme.liquidGlassCard
import com.example.ui.theme.liquidGlassWhitePill

enum class SocialListType {
    FOLLOWERS,
    FOLLOWING
}

@Composable
fun FollowersSheetModal(
    visible: Boolean,
    listType: SocialListType,
    creators: List<CreatorProfile>,
    subscribedCreatorIds: Set<String>,
    origin: ClickOrigin,
    viewportSize: IntSize,
    onDismiss: () -> Unit,
    onToggleSubscribe: (String) -> Unit,
    onSelectCreator: (String) -> Unit
) {
    BubbleModalPanel(
        visible = visible,
        origin = origin,
        viewportSize = viewportSize,
        onDismiss = onDismiss,
        modifier = Modifier
            .padding(16.dp)
            .widthIn(max = 520.dp)
            .fillMaxWidth()
    ) {
        var searchQuery by remember { mutableStateOf("") }
        var activeMode by remember(listType) { mutableStateOf(listType) }
        var isFullScreen by remember { mutableStateOf(false) }
        val followersListState = rememberLazyListState()

        val listMaxHeight by animateDpAsState(
            targetValue = if (isFullScreen) 580.dp else 340.dp,
            animationSpec = spring(
                dampingRatio = Spring.DampingRatioLowBouncy,
                stiffness = Spring.StiffnessMediumLow
            ),
            label = "followers_list_height"
        )

        val scrollExpandConnection = rememberSheetScrollExpandConnection(
            isFullScreen = isFullScreen,
            onExpand = { isFullScreen = true },
            onCollapse = { isFullScreen = false }
        )

        LaunchedEffect(followersListState.isScrollInProgress) {
            if (followersListState.isScrollInProgress && !isFullScreen) {
                isFullScreen = true
            }
        }

        val filteredCreators = remember(creators, searchQuery) {
            if (searchQuery.isBlank()) {
                creators
            } else {
                creators.filter {
                    it.name.contains(searchQuery, ignoreCase = true) ||
                            it.handle.contains(searchQuery, ignoreCase = true)
                }
            }
        }

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .liquidGlassCard(cornerRadius = 28.dp)
                .sheetPinchGesture(
                    isFullScreen = isFullScreen,
                    onFullScreenChange = { isFullScreen = it }
                )
                .nestedScroll(scrollExpandConnection)
                .padding(18.dp)
                .testTag("followers_sheet_modal"),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Interactive Drag Handle Pill (Tap or Drag toggles full size)
            SheetInteractiveDragHandle(
                isFullScreen = isFullScreen,
                onToggleFullScreen = { isFullScreen = !isFullScreen }
            )

            // Header Row with Title, Fullscreen Toggle, & Close Button
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = "Followers",
                        style = NexoraTypography.SectionTitle.copy(
                            color = if (activeMode == SocialListType.FOLLOWERS) NexoraColors.InkPrimary else NexoraColors.InkSecondary,
                            fontWeight = if (activeMode == SocialListType.FOLLOWERS) FontWeight.ExtraBold else FontWeight.Medium
                        ),
                        modifier = Modifier
                            .clickable { activeMode = SocialListType.FOLLOWERS }
                            .testTag("followers_tab_btn")
                    )

                    Text(
                        text = "Following",
                        style = NexoraTypography.SectionTitle.copy(
                            color = if (activeMode == SocialListType.FOLLOWING) NexoraColors.InkPrimary else NexoraColors.InkSecondary,
                            fontWeight = if (activeMode == SocialListType.FOLLOWING) FontWeight.ExtraBold else FontWeight.Medium
                        ),
                        modifier = Modifier
                            .clickable { activeMode = SocialListType.FOLLOWING }
                            .testTag("following_tab_btn")
                    )
                }

                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .liquidGlassWhitePill(999.dp)
                        .clickable { onDismiss() }
                        .testTag("followers_modal_close_btn"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Filled.Close,
                        contentDescription = "Close",
                        tint = NexoraColors.InkSecondary,
                        modifier = Modifier.size(15.dp)
                    )
                }
            }

            // Search Filter
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Search users...") },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Filled.Search,
                        contentDescription = "Search",
                        tint = NexoraColors.InkSecondary,
                        modifier = Modifier.size(18.dp)
                    )
                },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("followers_search_input")
            )

            // User List (Auto-expands on scroll)
            LazyColumn(
                state = followersListState,
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = listMaxHeight),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(filteredCreators, key = { it.id }) { creator ->
                    val isSubscribed = creator.id in subscribedCreatorIds

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .liquidGlassWhitePill(16.dp)
                            .clickable {
                                onSelectCreator(creator.id)
                                onDismiss()
                            }
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            CreatorAvatarBadge(
                                name = creator.name,
                                seed = creator.avatarSeed,
                                size = 42.dp,
                                isSquircle = false,
                                showOnlineDot = creator.isOnline
                            )

                            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                Text(
                                    text = creator.name,
                                    style = NexoraTypography.CardTitle.copy(fontSize = 14.sp),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = creator.handle,
                                    style = NexoraTypography.MetaCaption,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }

                        Box(
                            modifier = Modifier
                                .height(32.dp)
                                .then(
                                    if (isSubscribed) {
                                        Modifier.liquidGlassAccent(999.dp)
                                    } else {
                                        Modifier
                                            .clip(CircleShape)
                                            .liquidGlassWhitePill(999.dp)
                                    }
                                )
                                .clickable { onToggleSubscribe(creator.id) }
                                .padding(horizontal = 12.dp)
                                .testTag("user_follow_btn_${creator.id}"),
                            contentAlignment = Alignment.Center
                        ) {
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = if (isSubscribed) Icons.Filled.Check else Icons.Filled.PersonAdd,
                                    contentDescription = if (isSubscribed) "Following" else "Follow",
                                    tint = if (isSubscribed) NexoraColors.InkAccent else NexoraColors.InkPrimary,
                                    modifier = Modifier.size(14.dp)
                                )
                                Text(
                                    text = if (isSubscribed) "Following" else "Follow",
                                    style = NexoraTypography.BadgeMicro.copy(
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = if (isSubscribed) NexoraColors.InkAccent else NexoraColors.InkPrimary
                                    )
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
