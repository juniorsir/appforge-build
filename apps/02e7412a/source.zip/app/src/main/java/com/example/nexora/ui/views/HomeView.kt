package com.example.nexora.ui.views

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.nexora.data.SpatialPulseStory
import com.example.nexora.data.VideoItem
import com.example.nexora.ui.components.NexoraVideoCard
import com.example.nexora.ui.modals.SpatialClipsRail
import com.example.nexora.ui.modals.SpatialPulseRingBar
import com.example.ui.theme.NexoraColors
import com.example.ui.theme.NexoraTypography
import com.example.ui.theme.liquidGlassCard

import androidx.compose.foundation.layout.height
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.example.nexora.ui.components.InstagramDarkShimmerBox
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeView(
    videos: List<VideoItem>,
    shortVideos: List<VideoItem> = emptyList(),
    spatialPulses: List<SpatialPulseStory> = emptyList(),
    selectedCategory: String,
    searchQuery: String,
    savedVideoIds: Set<String>,
    watchHistoryProgress: Map<String, Float>,
    isCatalogLoading: Boolean = false,
    catalogError: String? = null,
    onRetryCatalog: () -> Unit = {},
    onSelectCategory: (String) -> Unit,
    onVideoClick: (VideoItem) -> Unit,
    onCreatorClick: (String) -> Unit,
    onToggleSave: (String) -> Unit,
    onToggleLike: (String) -> Unit = {},
    onDoubleTapLike: (String) -> Unit = onToggleLike,
    onToggleRepost: (String) -> Unit = {},
    onAddComment: (String, String) -> Unit = { _, _ -> },
    onToggleCommentLike: (String, String) -> Unit = { _, _ -> },
    onActionFeedback: (String) -> Unit = {},
    onOpenPulse: (SpatialPulseStory) -> Unit = {},
    onCreatePulseClick: () -> Unit = {},
    onOpenSpatialClip: (String) -> Unit = {},
    onShareVideo: (VideoItem) -> Unit,
    isRefreshing: Boolean = false,
    onRefresh: () -> Unit = {},
    refreshTrigger: Long = 0L,
    isGlobalAudioMuted: Boolean = false,
    onToggleMute: () -> Unit = {},
    isFeedVisible: Boolean = true,
    modifier: Modifier = Modifier
) {
    val nonLiveVideos = remember(videos) { videos.filter { !it.isLiveStream } }
    val filteredVideos = remember(nonLiveVideos, searchQuery) {
        val q = searchQuery.trim()
        if (q.isEmpty()) {
            nonLiveVideos
        } else {
            nonLiveVideos.filter { video ->
                video.title.contains(q, ignoreCase = true) ||
                    video.creatorName.contains(q, ignoreCase = true) ||
                    video.creatorHandle.contains(q, ignoreCase = true) ||
                    video.description.contains(q, ignoreCase = true) ||
                    video.category.contains(q, ignoreCase = true) ||
                    video.hashtags.any { it.contains(q, ignoreCase = true) }
            }
        }
    }
    val filteredShortVideos = remember(shortVideos, searchQuery) {
        val q = searchQuery.trim()
        if (q.isEmpty()) {
            shortVideos
        } else {
            shortVideos.filter { clip ->
                clip.title.contains(q, ignoreCase = true) ||
                    clip.creatorName.contains(q, ignoreCase = true) ||
                    clip.creatorHandle.contains(q, ignoreCase = true) ||
                    clip.description.contains(q, ignoreCase = true) ||
                    clip.category.contains(q, ignoreCase = true) ||
                    clip.hashtags.any { it.contains(q, ignoreCase = true) }
            }
        }
    }

    val listState = rememberLazyListState()

    LaunchedEffect(refreshTrigger) {
        if (refreshTrigger > 0L) {
            listState.animateScrollToItem(0)
        }
    }

    // Detect which regular feed post is in the middle of the screen
    val candidateAutoplayVideoId by remember(listState) {
        derivedStateOf {
            val layoutInfo = listState.layoutInfo
            val visibleItems = layoutInfo.visibleItemsInfo
            if (visibleItems.isEmpty()) return@derivedStateOf null

            val viewportCenter = (layoutInfo.viewportStartOffset + layoutInfo.viewportEndOffset) / 2

            val postItems = visibleItems.filter { itemInfo ->
                itemInfo.key.toString().startsWith("post_row_")
            }
            if (postItems.isEmpty()) return@derivedStateOf null

            val closestRow = postItems.minByOrNull { item ->
                val itemCenter = item.offset + (item.size / 2)
                kotlin.math.abs(itemCenter - viewportCenter)
            } ?: return@derivedStateOf null

            val rawKey = closestRow.key.toString().removePrefix("post_row_")
            rawKey.split("|").firstOrNull()
        }
    }

    // Debounce inline ExoPlayer activation while scrolling so flinging the feed stays 60fps butter-smooth
    var activeAutoplayVideoId by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(candidateAutoplayVideoId, listState.isScrollInProgress) {
        if (listState.isScrollInProgress) {
            delay(160L)
        } else {
            delay(60L)
        }
        activeAutoplayVideoId = candidateAutoplayVideoId
    }

    PullToRefreshBox(
        isRefreshing = isRefreshing,
        onRefresh = onRefresh,
        modifier = modifier.fillMaxSize()
    ) {
        BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
            val screenWidth = maxWidth
            val columns = when {
                screenWidth > 1024.dp -> 3
                screenWidth >= 600.dp -> 2
                else -> 1
            }
            val isDesktop = screenWidth >= 768.dp
            val chunkedVideos = remember(filteredVideos, columns) {
                filteredVideos.chunked(columns)
            }

            LazyColumn(
                state = listState,
                modifier = Modifier
                    .fillMaxSize()
                    .testTag("home_view_list"),
                contentPadding = PaddingValues(
                    start = if (isDesktop) 24.dp else 0.dp,
                    end = if (isDesktop) 24.dp else 0.dp,
                    top = 0.dp,
                    bottom = 64.dp
                ),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
            if (isCatalogLoading && filteredVideos.isEmpty()) {
                item(key = "catalog_loading_banner") {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("catalog_loading_indicator"),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        InstagramDarkShimmerBox(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(340.dp)
                                .clip(RoundedCornerShape(24.dp))
                        )
                    }
                }
            }

            if (catalogError != null) {
                item(key = "catalog_error_banner") {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .liquidGlassCard(cornerRadius = 18.dp)
                            .padding(horizontal = 16.dp, vertical = 12.dp)
                            .testTag("catalog_error_banner"),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(
                            modifier = Modifier.weight(1f),
                            verticalArrangement = Arrangement.spacedBy(2.dp)
                        ) {
                            Text(
                                text = "Catalog Network Error",
                                style = NexoraTypography.CardTitle.copy(
                                    fontSize = 13.5.sp,
                                    color = NexoraColors.LiveRose
                                )
                            )
                            Text(
                                text = catalogError,
                                style = NexoraTypography.MetaCaption
                            )
                        }

                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(999.dp))
                                .background(NexoraColors.ElectricIndigo)
                                .clickable { onRetryCatalog() }
                                .padding(horizontal = 14.dp, vertical = 7.dp)
                                .testTag("catalog_retry_btn"),
                            contentAlignment = Alignment.Center
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Refresh,
                                    contentDescription = "Retry catalog",
                                    tint = Color.White,
                                    modifier = Modifier.size(14.dp)
                                )
                                Text(
                                    text = "Retry",
                                    style = NexoraTypography.BadgeMicro.copy(
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold
                                    )
                                )
                            }
                        }
                    }
                }
            }

            // 0. Ephemeral Spatial Pulses (Stories) Orbital Ring Strip
            if (spatialPulses.isNotEmpty() && searchQuery.isBlank()) {
                item(key = "spatial_pulse_stories_ring") {
                    SpatialPulseRingBar(
                        pulses = spatialPulses,
                        onOpenPulse = onOpenPulse,
                        onCreatePulseClick = onCreatePulseClick
                    )
                }
            }

            // 1. Spatial Clips (9:16 Vertical Short Videos Rail from dedicated /_/s7a1 API)
            if (filteredShortVideos.isNotEmpty()) {
                item(key = "home_spatial_clips_rail") {
                    SpatialClipsRail(
                        clips = filteredShortVideos,
                        onOpenClip = onOpenSpatialClip,
                        onCreatorClick = onCreatorClick
                    )
                }
            }

            // 2. Unified Aspect-Ratio Post / Video Cards Feed
            if (chunkedVideos.isNotEmpty()) {
                items(
                    items = chunkedVideos,
                    key = { row -> "post_row_" + row.joinToString("|") { it.id } }
                ) { rowItems ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(20.dp)
                    ) {
                        rowItems.forEach { video ->
                            Box(modifier = Modifier.weight(1f)) {
                                NexoraVideoCard(
                                    video = video,
                                    isSaved = video.id in savedVideoIds,
                                    onVideoClick = onVideoClick,
                                    onCreatorClick = onCreatorClick,
                                    onToggleSave = onToggleSave,
                                    onShareClick = onShareVideo,
                                    resumeProgress = watchHistoryProgress[video.id],
                                    onToggleLike = onToggleLike,
                                    onDoubleTapLike = onDoubleTapLike,
                                    onToggleRepost = onToggleRepost,
                                    onAddComment = onAddComment,
                                    onToggleCommentLike = onToggleCommentLike,
                                    onActionFeedback = onActionFeedback,
                                    isAutoplayActive = isFeedVisible && (video.id == activeAutoplayVideoId),
                                    isMuted = isGlobalAudioMuted,
                                    onToggleMute = onToggleMute
                                )
                            }
                        }
                        repeat(columns - rowItems.size) {
                            Spacer(modifier = Modifier.weight(1f))
                        }
                    }
                }
            } else if (!isCatalogLoading && filteredShortVideos.isEmpty() && searchQuery.isNotBlank()) {
                item(key = "home_empty_search_state") {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .liquidGlassCard(cornerRadius = 22.dp)
                            .padding(horizontal = 20.dp, vertical = 32.dp)
                            .testTag("home_empty_search_state"),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = "No results found for \"${searchQuery.trim()}\"",
                            style = NexoraTypography.CardTitle.copy(
                                fontSize = 15.sp,
                                color = NexoraColors.InkPrimary
                            )
                        )
                        Text(
                            text = "Try searching for another video title, creator, or hashtag.",
                            style = NexoraTypography.MetaCaption.copy(
                                color = NexoraColors.InkSecondary
                            )
                        )
                    }
                }
            }
        }
    }
}
}
