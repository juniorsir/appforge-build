package com.example.nexora.ui.modals

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import kotlin.math.sqrt

/**
 * Detects two-finger pinch gesture on modal sheets to smoothly expand or collapse them.
 * - Pinch outward (zoom > 1.04f): expands to full screen.
 * - Pinch inward (zoom < 0.96f): collapses back to compact size.
 * Leaves single-finger gestures, list scrolling, clicks, and inputs completely unimpeded.
 */
fun Modifier.sheetPinchGesture(
    isFullScreen: Boolean,
    onFullScreenChange: (Boolean) -> Unit
): Modifier = this.pointerInput(isFullScreen) {
    awaitEachGesture {
        do {
            val event = awaitPointerEvent()
            if (event.changes.size >= 2) {
                val p1 = event.changes[0].position
                val p2 = event.changes[1].position
                val prevP1 = event.changes[0].previousPosition
                val prevP2 = event.changes[1].previousPosition
                val dx = p1.x - p2.x
                val dy = p1.y - p2.y
                val prevDx = prevP1.x - prevP2.x
                val prevDy = prevP1.y - prevP2.y
                val currentDist = sqrt(dx * dx + dy * dy)
                val prevDist = sqrt(prevDx * prevDx + prevDy * prevDy)

                if (prevDist > 16f && currentDist > 16f) {
                    val ratio = currentDist / prevDist
                    if (ratio > 1.04f && !isFullScreen) {
                        onFullScreenChange(true)
                        event.changes.forEach { it.consume() }
                    } else if (ratio < 0.96f && isFullScreen) {
                        onFullScreenChange(false)
                        event.changes.forEach { it.consume() }
                    }
                }
            }
        } while (event.changes.any { it.pressed })
    }
}

/**
 * Creates a [NestedScrollConnection] that automatically expands the bottom sheet to full size
 * whenever the user scrolls or drags upward within its content, and allows collapsing
 * when pulling down from the top.
 */
@Composable
fun rememberSheetScrollExpandConnection(
    isFullScreen: Boolean,
    onExpand: () -> Unit,
    onCollapse: (() -> Unit)? = null
): NestedScrollConnection {
    return remember(isFullScreen) {
        object : NestedScrollConnection {
            override fun onPreScroll(available: Offset, source: NestedScrollSource): Offset {
                if (source == NestedScrollSource.UserInput) {
                    // Scrolling up/down: If moving content up (dragging upwards), available.y is negative
                    if (available.y < -3f && !isFullScreen) {
                        onExpand()
                    } else if (available.y > 22f && isFullScreen && onCollapse != null) {
                        onCollapse()
                    }
                }
                return Offset.Zero
            }
        }
    }
}

/**
 * Native Instagram-style horizontal drag pill handle at the top of modal bottom sheets.
 * Minimal 36.dp x 4.dp translucent rounded pill without arrow or button clutter.
 * Tapping or dragging upward/downward smoothly transitions between compact and full-screen modes.
 */
@Composable
fun SheetInteractiveDragHandle(
    isFullScreen: Boolean,
    onToggleFullScreen: () -> Unit,
    modifier: Modifier = Modifier,
    pillColor: Color = Color.White
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .pointerInput(isFullScreen) {
                detectVerticalDragGestures { change, dragAmount ->
                    change.consume()
                    if (dragAmount < -10f && !isFullScreen) {
                        onToggleFullScreen()
                    } else if (dragAmount > 10f && isFullScreen) {
                        onToggleFullScreen()
                    }
                }
            }
            .clickable { onToggleFullScreen() }
            .padding(top = 10.dp, bottom = 8.dp)
            .testTag("sheet_interactive_drag_handle"),
        contentAlignment = Alignment.Center
    ) {
        Box(
            modifier = Modifier
                .width(36.dp)
                .height(4.dp)
                .clip(RoundedCornerShape(999.dp))
                .background(pillColor.copy(alpha = 0.35f))
        )
    }
}
