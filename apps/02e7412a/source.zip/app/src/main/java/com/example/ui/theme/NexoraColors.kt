package com.example.ui.theme

import android.content.Context
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.graphics.Color

object NexoraColors {
    var isWhiteThemeState = mutableStateOf(false)

    var isWhiteTheme: Boolean
        get() = false
        set(_) {
            isWhiteThemeState.value = false
        }

    fun initTheme(context: Context) {
        isWhiteThemeState.value = false
        context.getSharedPreferences("nexora_theme_prefs", Context.MODE_PRIVATE)
            .edit()
            .putBoolean("is_white_theme", false)
            .apply()
    }

    fun toggleTheme(context: Context? = null) {
        // White UI removed completely - app is permanently in dark spatial mode
    }

    fun setWhiteTheme(white: Boolean, context: Context? = null) {
        // White UI removed completely - app is permanently in dark spatial mode
    }

    // Base Canvas: True Instagram AMOLED Pure Black (#000000)
    val CanvasBase: Color = Color(0xFF000000)
    val Pearl50: Color = Color(0xFF000000)
    val Pearl100: Color = Color(0xFF121212)
    val Pearl200: Color = Color(0xFF1C1C1E)
    val Pearl300: Color = Color(0xFF262626)

    // Ambient Radial Mesh Orb Colors
    val MeshOrbTopLeftLav      = Color.Transparent
    val MeshOrbTopRightSky     = Color.Transparent
    val MeshOrbBottomCenterInd = Color.Transparent

    // Instagram Sunset Gradient Scale (Amber -> Magenta-Red -> Purple -> Indigo)
    val InstagramSunsetAmber  = Color(0xFFF58529)
    val InstagramSunsetPink   = Color(0xFFDD2A7B)
    val InstagramSunsetPurple = Color(0xFF8134AF)
    val InstagramSunsetIndigo = Color(0xFF515BD4)

    val Lavender100: Color = Color(0xFF121212)
    val Lavender200: Color = Color(0xFF1C1C1E)
    val Lavender300 = Color(0xFF8134AF)
    val Lavender400 = Color(0xFFDD2A7B)
    val Lavender500 = Color(0xFFE1306C)

    // Instagram Blue Scale (#0095F6)
    val Sky100: Color = Color(0xFF121212)
    val Sky200: Color = Color(0xFF1C1C1E)
    val Sky300 = Color(0xFF3897F0)
    val Sky400 = Color(0xFF0095F6)

    // High-Contrast Dark Mode Typography Hierarchy (WCAG AA Compliant)
    val InkPrimary: Color = Color(0xFFF5F5F5)
    val InkAccent = Color(0xFF0095F6) // Active pill labels & interactive accents
    val InkSecondary: Color = Color(0xFFA8A8A8)
    val InkBody: Color = Color(0xFFE8E8ED)
    val InkMuted: Color = Color(0xFF737373)

    // Semantic Status Accents
    val LiveRose       = Color(0xFFFF3040) // Crimson Red - Likes & Live indicator
    val EmeraldLive    = Color(0xFF10B981) // Verified / Online status dot
    val AmberStar      = Color(0xFFFCAF45) // Warm Amber - Featured / Rating accent
    val ElectricIndigo = Color(0xFF0095F6) // Primary accent

    // High-Contrast Clean Hairline Borders & Strokes (WCAG AA)
    val SpecularBorderStrong: Color = Color(0xFF262626)
    val SpecularBorderNav: Color = Color(0xFF262626)
    val SpecularBorderSubtle: Color = Color(0xFF262626)
    val AmbientShadowTint: Color = Color(0x80000000)
}
