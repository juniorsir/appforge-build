package com.example.nexora.ui.modals

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.awaitLongPressOrCancellation
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.offset
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.unit.IntOffset
import kotlin.math.roundToInt
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.automirrored.filled.VolumeOff
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.AddCircleOutline
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.IosShare
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.Velocity
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.nexora.animation.BubbleModalPanel
import com.example.nexora.animation.ClickOrigin
import com.example.nexora.data.VideoComment
import com.example.nexora.data.VideoItem
import com.example.nexora.data.VisualThemePreset
import androidx.activity.compose.BackHandler
import androidx.compose.ui.platform.LocalContext
import com.example.nexora.ui.components.CreatorAvatarBadge
import com.example.nexora.ui.components.PremiumShortVideoIcon
import com.example.nexora.ui.components.SpatialVisualCanvas
import com.example.nexora.ui.components.NexoraShortsCard
import com.example.nexora.ui.components.VerifiedBadge
import com.example.nexora.ui.player.AkashInlineClipExoPlayer
import com.example.nexora.ui.player.AkashQualityController
import com.example.nexora.ui.player.ReelsLookaheadCacheManager
import com.example.ui.theme.NexoraColors
import com.example.ui.theme.NexoraTypography
import com.example.ui.theme.liquidGlassAccent
import com.example.ui.theme.liquidGlassCard
import com.example.ui.theme.liquidGlassDarkOverlay
import com.example.ui.theme.liquidGlassElevatedCapsule
import com.example.ui.theme.liquidGlassWhitePill
import kotlin.math.sin
import kotlinx.coroutines.launch

/**
 * Horizontal 9:16 Short-Form Video Rail ("Spatial Clips") for Home & Explore Feeds:
 * Displays vertical frosted-glass clip cards that expand into the full-screen VerticalPager viewer.
 */
@Composable
fun SpatialClipsRail(
    clips: List<VideoItem>,
    onOpenClip: (String) -> Unit,
    modifier: Modifier = Modifier,
    onCreatorClick: (String) -> Unit = {}
) {
    val context = LocalContext.current
    val shortOnlyClips = remember(clips) {
        clips.filter { !it.isLiveStream && !it.isPhotoPost && it.isShortVideo && it.rawDurationSeconds <= 120.0 }
    }
    if (shortOnlyClips.isEmpty()) return

    LaunchedEffect(shortOnlyClips.firstOrNull()?.id) {
        ReelsLookaheadCacheManager.preWarmInitialClips(context, shortOnlyClips)
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(bottom = 6.dp)
            .testTag("spatial_clips_rail_section"),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Section Header Pill Bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(28.dp)
                        .liquidGlassAccent(999.dp),
                    contentAlignment = Alignment.Center
                ) {
                    PremiumShortVideoIcon(
                        isSelected = true,
                        size = 16.dp
                    )
                }
                Text(
                    text = "Spatial Clips",
                    style = NexoraTypography.CardTitle.copy(fontSize = 15.sp)
                )
            }

            Box(
                modifier = Modifier
                    .liquidGlassWhitePill(999.dp)
                    .clickable { shortOnlyClips.firstOrNull()?.let { onOpenClip(it.id) } }
                    .padding(horizontal = 10.dp, vertical = 4.dp)
                    .testTag("spatial_clips_swipe_all_btn")
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.PlayArrow,
                        contentDescription = null,
                        tint = NexoraColors.InkAccent,
                        modifier = Modifier.size(13.dp)
                    )
                    Text(
                        text = "SWIPE 9:16",
                        style = NexoraTypography.BadgeMicro.copy(
                            fontSize = 9.5.sp,
                            color = NexoraColors.InkAccent,
                            fontWeight = FontWeight.Bold
                        )
                    )
                }
            }
        }

        // 9:16 Portrait Glass Cards Row
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(vertical = 2.dp),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("spatial_clips_lazy_row")
        ) {
            itemsIndexed(
                items = shortOnlyClips,
                key = { _, clip -> "clip_${clip.id}" },
                contentType = { _, _ -> "spatial_clip_card" }
            ) { _, clip ->
                Box(
                    modifier = Modifier
                        .width(148.dp)
                        .testTag("spatial_clip_card_${clip.id}")
                ) {
                    NexoraShortsCard(
                        video = clip,
                        isSaved = false,
                        onVideoClick = { onOpenClip(clip.id) },
                        onCreatorClick = onCreatorClick,
                        onToggleSave = { },
                        onShareClick = { },
                        onToggleLike = { }
                    )
                }
            }
        }
    }
}

/**
 * Full-Screen Vertical Swipe Short-Video Viewer (`VerticalPager`):
 * - Swipe vertically across all Spatial Clips (like Instagram Reels, styled in Frosted Liquid Glass)
 * - Double-tap anywhere for Refractive Glass Heart Burst + persisted Like
 * - Floating Liquid Glass right-side action column (Like, Comment Drawer, Repost, Save, Share)
 * - Bottom Creator Follow capsule + animated Spatial Audio Waveform pill
 */
@Composable
fun SpatialClipsVerticalViewerModal(
    activeClipId: String?,
    clips: List<VideoItem>,
    savedVideoIds: Set<String>,
    subscribedCreatorIds: Set<String>,
    origin: ClickOrigin,
    viewportSize: IntSize,
    onDismiss: () -> Unit,
    onToggleLike: (String) -> Unit,
    onDoubleTapLike: (String) -> Unit,
    onToggleRepost: (String) -> Unit,
    onToggleSave: (String) -> Unit,
    onToggleSubscribe: (String) -> Unit,
    onCreatorClick: (String) -> Unit,
    onAddComment: (String, String) -> Unit,
    onToggleCommentLike: (String, String) -> Unit,
    onShareClip: (VideoItem) -> Unit,
    onCheckClipStatus: (String) -> Unit = {},
    onDeleteComment: (String, String) -> Unit = { _, _ -> },
    isGlobalAudioMuted: Boolean = false,
    onToggleMute: () -> Unit = {}
) {
    val context = LocalContext.current
    val nonLiveClips = remember(clips) {
        clips.filter { !it.isLiveStream && !it.isPhotoPost && it.isShortVideo && it.rawDurationSeconds <= 120.0 }
    }
    val initialIndex = remember(activeClipId, nonLiveClips.size) {
        nonLiveClips.indexOfFirst { it.id == activeClipId }.coerceAtLeast(0)
    }

    BubbleModalPanel(
        visible = activeClipId != null && nonLiveClips.isNotEmpty(),
        origin = origin,
        viewportSize = viewportSize,
        onDismiss = onDismiss,
        modifier = Modifier.fillMaxSize(),
        targetCornerRadius = 0.dp
    ) {
        val pagerState = rememberPagerState(
            initialPage = initialIndex,
            pageCount = { nonLiveClips.size }
        )
        var isOverlaySheetOpen by remember { mutableStateOf(false) }
        var isTopHeaderVisible by remember { mutableStateOf(true) }

        LaunchedEffect(activeClipId) {
            val targetIdx = nonLiveClips.indexOfFirst { it.id == activeClipId }
            if (targetIdx >= 0 && targetIdx != pagerState.currentPage) {
                pagerState.scrollToPage(targetIdx)
            }
        }

        // Instagram Reels Lookahead Pre-Buffering + Sovereign Interaction Status Check:
        // When Reel [i] is playing:
        // - Hydrate is_liked, is_saved, likes_count from GET /_/u/status/{file_code}
        // - Pre-load thumbnails for Reel [i + 1], [i + 2], [i + 3]
        // - Pre-cache first 3MB of Reel [i + 1] and [i + 2] via ExoPlayer CacheDataSource
        LaunchedEffect(pagerState.currentPage, nonLiveClips.size) {
            val currentIdx = pagerState.currentPage
            nonLiveClips.getOrNull(currentIdx)?.let { activeClip ->
                onCheckClipStatus(activeClip.id)
            }
            for (offset in 1..3) {
                nonLiveClips.getOrNull(currentIdx + offset)?.let { futureClip ->
                    ReelsLookaheadCacheManager.preloadReelThumbnail(context, futureClip)
                }
            }
            nonLiveClips.getOrNull(currentIdx + 1)?.let { nextClip ->
                ReelsLookaheadCacheManager.preCacheReelFirst2MB(context, nextClip)
            }
            nonLiveClips.getOrNull(currentIdx + 2)?.let { secondNextClip ->
                ReelsLookaheadCacheManager.preCacheReelFirst2MB(context, secondNextClip)
            }
        }

        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(NexoraColors.CanvasBase)
                .testTag("spatial_clips_vertical_viewer_modal")
        ) {
            VerticalPager(
                state = pagerState,
                userScrollEnabled = !isOverlaySheetOpen,
                key = { pageIndex -> nonLiveClips[pageIndex].id },
                modifier = Modifier
                    .fillMaxSize()
                    .testTag("spatial_clips_vertical_pager"),
                beyondViewportPageCount = 1
            ) { pageIndex ->
                val clip = nonLiveClips[pageIndex]
                val isCurrentPage = activeClipId != null &&
                    pagerState.currentPage == pageIndex &&
                    pagerState.settledPage == pageIndex
                val isNextPage = activeClipId != null && pageIndex == pagerState.currentPage + 1
                val isPreviousPage = activeClipId != null && pageIndex == pagerState.currentPage - 1

                SpatialClipVerticalPage(
                    clip = clip,
                    pageIndex = pageIndex,
                    totalClips = nonLiveClips.size,
                    isCurrentPage = isCurrentPage,
                    isNextPage = isNextPage,
                    isPreviousPage = isPreviousPage,
                    isSaved = clip.id in savedVideoIds,
                    isSubscribed = clip.creatorId in subscribedCreatorIds,
                    onDismiss = onDismiss,
                    onToggleLike = { onToggleLike(clip.id) },
                    onDoubleTapLike = { onDoubleTapLike(clip.id) },
                    onToggleRepost = { onToggleRepost(clip.id) },
                    onToggleSave = { onToggleSave(clip.id) },
                    onToggleSubscribe = { onToggleSubscribe(clip.creatorId) },
                    onCreatorClick = {
                        onDismiss()
                        onCreatorClick(clip.creatorId)
                    },
                    onAddComment = { text -> onAddComment(clip.id, text) },
                    onToggleCommentLike = { commentId -> onToggleCommentLike(clip.id, commentId) },
                    onShareClip = { onShareClip(clip) },
                    onDeleteComment = { commentId -> onDeleteComment(clip.id, commentId) },
                    onSheetOpenChange = { open ->
                        if (isCurrentPage) {
                            isOverlaySheetOpen = open
                        }
                    },
                    onControlsVisibleChange = { visible ->
                        if (isCurrentPage) {
                            isTopHeaderVisible = visible
                        }
                    },
                    isGlobalAudioMuted = isGlobalAudioMuted,
                    onToggleMute = onToggleMute,
                    allClips = clips
                )
            }

            // Stable Top Header Bar (Stays fixed at top over VerticalPager during scrolling)
            StableShortsTopHeader(
                isVisible = isTopHeaderVisible,
                onDismiss = onDismiss,
                onCameraClick = {
                    val currentClip = nonLiveClips.getOrNull(pagerState.currentPage)
                    if (currentClip != null) onShareClip(currentClip)
                },
                isMuted = isGlobalAudioMuted,
                onToggleMute = onToggleMute
            )
        }
    }
}

@Composable
private fun SpatialClipVerticalPage(
    clip: VideoItem,
    pageIndex: Int,
    totalClips: Int,
    isCurrentPage: Boolean,
    isSaved: Boolean,
    isSubscribed: Boolean,
    onDismiss: () -> Unit,
    onToggleLike: () -> Unit,
    onDoubleTapLike: () -> Unit,
    onToggleRepost: () -> Unit,
    onToggleSave: () -> Unit,
    onToggleSubscribe: () -> Unit,
    onCreatorClick: () -> Unit,
    onAddComment: (String) -> Unit,
    onToggleCommentLike: (String) -> Unit,
    onShareClip: () -> Unit,
    isNextPage: Boolean = false,
    isPreviousPage: Boolean = false,
    onSheetOpenChange: (Boolean) -> Unit = {},
    onControlsVisibleChange: (Boolean) -> Unit = {},
    onDeleteComment: (String) -> Unit = {},
    isGlobalAudioMuted: Boolean = false,
    onToggleMute: () -> Unit = {},
    allClips: List<VideoItem> = emptyList()
) {
    val coroutineScope = rememberCoroutineScope()
    var isControlsVisible by remember { mutableStateOf(true) }
    var isPaused by remember { mutableStateOf(false) }
    var showAudioPill by remember(clip.id) { mutableStateOf(false) }

    LaunchedEffect(isGlobalAudioMuted) {
        if (isCurrentPage) {
            showAudioPill = true
            kotlinx.coroutines.delay(1200L)
            showAudioPill = false
        }
    }
    var isCommentDrawerOpen by remember { mutableStateOf(false) }
    var isShareSheetOpen by remember { mutableStateOf(false) }
    var isMoreOptionsSheetOpen by remember { mutableStateOf(false) }
    var isAudioSheetOpen by remember { mutableStateOf(false) }
    var feedbackMessage by remember(clip.id) { mutableStateOf<String?>(null) }
    var isGifPickerOpen by remember { mutableStateOf(false) }
    var gifSearchQuery by remember { mutableStateOf("") }
    var commentSortMode by remember { mutableStateOf("Top") }
    var commentDraft by remember { mutableStateOf("") }
    var replyingToAuthor by remember { mutableStateOf<String?>(null) }
    var shareSearchQuery by remember { mutableStateOf("") }
    var shareMessageDraft by remember { mutableStateOf("") }
    var selectedShareRecipients by remember { mutableStateOf(setOf<String>()) }

    val infiniteTransition = rememberInfiniteTransition(label = "audio_disc_rotation")
    val audioDiscRotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 4000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "audio_disc_deg"
    )

    LaunchedEffect(isCommentDrawerOpen, isShareSheetOpen, isMoreOptionsSheetOpen, isAudioSheetOpen, isCurrentPage, isControlsVisible) {
        if (!isCurrentPage) {
            isCommentDrawerOpen = false
            isShareSheetOpen = false
            isMoreOptionsSheetOpen = false
            isAudioSheetOpen = false
            isGifPickerOpen = false
        } else {
            onSheetOpenChange(isCommentDrawerOpen || isShareSheetOpen || isMoreOptionsSheetOpen || isAudioSheetOpen)
            onControlsVisibleChange(isControlsVisible)
        }
    }


    val slides = clip.carouselSlides.ifEmpty { listOf(clip.visualPreset) }
    var activeSlideIndex by remember(clip.id) { mutableIntStateOf(0) }
    val currentPreset = slides[activeSlideIndex.coerceIn(0, slides.lastIndex)]
    var isCaptionExpanded by remember(clip.id) { mutableStateOf(false) }

    val haptic = LocalHapticFeedback.current
    var isScrubbing by remember { mutableStateOf(false) }
    var scrubDragStartProgress by remember { mutableFloatStateOf(0f) }
    var scrubDragAccumulatorPx by remember { mutableFloatStateOf(0f) }
    var scrubProgress by remember { mutableFloatStateOf(0f) }
    var playbackProgress by remember(clip.id) { mutableFloatStateOf(0f) }
    var reportedDurationSec by remember(clip.id) {
        mutableIntStateOf(clip.durationSeconds.takeIf { it > 0 } ?: 30)
    }
    var seekTrigger by remember(clip.id) { mutableIntStateOf(0) }
    var seekFraction by remember(clip.id) { mutableFloatStateOf(0f) }

    // Reset pause & progress state when swiping away from a page
    LaunchedEffect(isCurrentPage) {
        if (!isCurrentPage) {
            isPaused = false
            playbackProgress = 0f
        }
    }

    // For synthetic fallback clips without an ExoPlayer stream, advance progress only when actively playing
    LaunchedEffect(clip.id, clip.fileCode, isCurrentPage, isPaused, isScrubbing) {
        if (clip.fileCode.isNullOrBlank() && isCurrentPage && !isPaused && !isScrubbing) {
            val durationMs = (reportedDurationSec.coerceAtLeast(1)) * 1000f
            var lastFrameNanos = withFrameNanos { it }
            while (true) {
                val frameNanos = withFrameNanos { it }
                val deltaMs = ((frameNanos - lastFrameNanos) / 1_000_000f).coerceAtLeast(0f)
                lastFrameNanos = frameNanos
                playbackProgress = (playbackProgress + (deltaMs / durationMs)) % 1f
            }
        }
    }

    val effectiveProgress = if (isScrubbing) scrubProgress else playbackProgress
    val currentEffectiveProgress by rememberUpdatedState(effectiveProgress)
    var longPressConsumedTap by remember { mutableStateOf(false) }

    val totalDurationSec = reportedDurationSec.takeIf { it > 0 } ?: 30
    val currentSec = (effectiveProgress * totalDurationSec).roundToInt()
    val currentSecStr = "%d:%02d".format(currentSec / 60, currentSec % 60)
    val totalSecStr = "%d:%02d".format(totalDurationSec / 60, totalDurationSec % 60)

    val vignetteAlpha by animateFloatAsState(
        targetValue = if (isControlsVisible) 1f else 0f,
        animationSpec = tween(220, easing = FastOutSlowInEasing),
        label = "vignette_alpha"
    )

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .background(NexoraColors.CanvasBase)
            .pointerInput(clip.id, isCommentDrawerOpen, isShareSheetOpen, isMoreOptionsSheetOpen, isControlsVisible, isPaused, isCaptionExpanded) {
                detectTapGestures(
                    onPress = {
                        longPressConsumedTap = false
                        tryAwaitRelease()
                    },
                    onDoubleTap = { _ ->
                        if (isCaptionExpanded) isCaptionExpanded = false
                        onDoubleTapLike()
                    },
                    onTap = {
                        if (longPressConsumedTap || isScrubbing) {
                            longPressConsumedTap = false
                            return@detectTapGestures
                        }
                        if (isCommentDrawerOpen) {
                            isCommentDrawerOpen = false
                        } else if (isShareSheetOpen) {
                            isShareSheetOpen = false
                        } else if (isMoreOptionsSheetOpen) {
                            isMoreOptionsSheetOpen = false
                        } else if (isAudioSheetOpen) {
                            isAudioSheetOpen = false
                        } else if (isCaptionExpanded) {
                            // If caption is opened, clicking anywhere collapses it
                            isCaptionExpanded = false
                        } else if (!isControlsVisible) {
                            // Single tap while in distraction-free view restores controls
                            isControlsVisible = true
                            feedbackMessage = "Standard view restored"
                            coroutineScope.launch {
                                kotlinx.coroutines.delay(1800L)
                                if (feedbackMessage == "Standard view restored") {
                                    feedbackMessage = null
                                }
                            }
                        } else {
                            // Standard single tap toggles video play/pause
                            isPaused = !isPaused
                        }
                    }
                )
            }
            .pointerInput(clip.id) {
                detectDragGesturesAfterLongPress(
                    onDragStart = {
                        longPressConsumedTap = true
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        val startProg = currentEffectiveProgress
                        isScrubbing = true
                        scrubDragStartProgress = startProg
                        scrubDragAccumulatorPx = 0f
                        scrubProgress = startProg
                        seekFraction = startProg
                        seekTrigger += 1
                    },
                    onDrag = { change, dragAmount ->
                        change.consume()
                        scrubDragAccumulatorPx += dragAmount.x
                        val widthPx = (size.width.toFloat() * 0.72f).coerceAtLeast(260f)
                        val delta = scrubDragAccumulatorPx / widthPx
                        val nextProg = (scrubDragStartProgress + delta).coerceIn(0f, 1f)
                        scrubProgress = nextProg
                        if (kotlin.math.abs(nextProg - seekFraction) >= 0.015f) {
                            seekFraction = nextProg
                            seekTrigger += 1
                        }
                    },
                    onDragEnd = {
                        playbackProgress = scrubProgress
                        seekFraction = scrubProgress
                        seekTrigger += 1
                        isScrubbing = false
                    },
                    onDragCancel = {
                        isScrubbing = false
                    }
                )
            }
    ) {
        val screenWidthPx = with(LocalDensity.current) { maxWidth.toPx() }
        val currentScreenWidthPx by rememberUpdatedState(screenWidthPx)

        // 1. Live Full-Bleed Vertical Native ExoPlayer Stream (or Spatial Canvas fallback)
        if (!clip.fileCode.isNullOrBlank() || !clip.streamUrl.isNullOrBlank()) {
            AkashInlineClipExoPlayer(
                clip = clip,
                isActivePage = isCurrentPage,
                isPaused = isPaused || isScrubbing,
                isNextPage = isNextPage,
                isPreviousPage = isPreviousPage,
                isMuted = isGlobalAudioMuted,
                modifier = Modifier.fillMaxSize(),
                seekTrigger = seekTrigger,
                seekFraction = seekFraction,
                onProgressUpdate = { fraction, durSec ->
                    if (!isScrubbing && !isPaused) {
                        playbackProgress = fraction
                        if (durSec > 0) {
                            reportedDurationSec = durSec
                        }
                    }
                }
            )
        } else {
            SpatialVisualCanvas(
                preset = currentPreset,
                isAnimated = isCurrentPage && !isPaused && !isScrubbing,
                playbackPhase = effectiveProgress
            )
        }

        // 2. Subtle Asymmetric Optical Vignette (Fades away completely in Full Distraction-Free mode)
        Box(
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer { alpha = vignetteAlpha }
                .background(
                    Brush.verticalGradient(
                        0.0f to Color(0x66090D16),
                        0.18f to Color.Transparent,
                        0.62f to Color.Transparent,
                        1.0f to Color(0xCC090D16)
                    )
                )
        )

        // 3. Center Play Icon when paused (tap animation removed)
        if (isPaused) {
            Box(
                modifier = Modifier
                    .size(72.dp)
                    .clip(CircleShape)
                    .background(Color(0x66090D16))
                    .align(Alignment.Center)
                    .clickable {
                        isPaused = false
                    }
                    .testTag("clip_tap_play_pause_overlay_${clip.id}"),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Filled.PlayArrow,
                    contentDescription = "Play",
                    tint = Color.White,
                    modifier = Modifier.size(38.dp)
                )
            }
        }

        // 4b. Center Audio Status Pill (like Instagram speaker HUD)
        AnimatedVisibility(
            visible = showAudioPill && isCurrentPage,
            enter = fadeIn(animationSpec = tween(150)) + scaleIn(initialScale = 0.82f),
            exit = fadeOut(animationSpec = tween(220)) + scaleOut(targetScale = 0.88f),
            modifier = Modifier.align(Alignment.Center)
        ) {
            Box(
                modifier = Modifier
                    .size(72.dp)
                    .clip(CircleShape)
                    .background(Color(0x77090D16))
                    .clickable { onToggleMute() }
                    .testTag("clip_audio_pill_${clip.id}"),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (isGlobalAudioMuted) Icons.AutoMirrored.Filled.VolumeOff else Icons.AutoMirrored.Filled.VolumeUp,
                    contentDescription = if (isGlobalAudioMuted) "Muted" else "Unmuted",
                    tint = Color.White,
                    modifier = Modifier.size(36.dp)
                )
            }
        }

        // Top HUD shadow styling for captions
        val hudTextShadow = remember {
            Shadow(
                color = Color(0xB3090D16),
                offset = Offset(0f, 2f),
                blurRadius = 8f
            )
        }

        // 6. Right-Side Frameless Sculpted Vector Action HUD (Official Instagram Reels Order)
        AnimatedVisibility(
            visible = isControlsVisible,
            enter = fadeIn(animationSpec = tween(220)) + slideInHorizontally(
                animationSpec = spring(
                    dampingRatio = Spring.DampingRatioLowBouncy,
                    stiffness = Spring.StiffnessMediumLow
                )
            ) { it / 2 },
            exit = fadeOut(animationSpec = tween(180)) + slideOutHorizontally(
                animationSpec = tween(180)
            ) { it / 2 },
            modifier = Modifier.align(Alignment.BottomEnd)
        ) {
            Column(
                modifier = Modifier
                    .windowInsetsPadding(WindowInsets.navigationBars)
                    .padding(end = 12.dp, bottom = 24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // 1. Like Button with Count
                FramelessSculptedActionItem(
                    glyph = ClipActionGlyph.HEART,
                    activeColor = NexoraColors.LiveRose,
                    label = formatShortCount(clip.likesCount),
                    isActive = clip.isLiked,
                    testTag = "clip_like_btn_${clip.id}",
                    onClick = onToggleLike
                )

                // 2. Comment Drawer Button
                FramelessSculptedActionItem(
                    glyph = ClipActionGlyph.COMMENT,
                    activeColor = Color.White,
                    label = "${clip.comments.size}",
                    isActive = isCommentDrawerOpen,
                    testTag = "clip_comment_btn_${clip.id}",
                    onClick = {
                        isShareSheetOpen = false
                        isMoreOptionsSheetOpen = false
                        isAudioSheetOpen = false
                        isCommentDrawerOpen = !isCommentDrawerOpen
                    }
                )

                // 3. Save / Bookmark Button
                FramelessSculptedActionItem(
                    glyph = ClipActionGlyph.BOOKMARK,
                    activeColor = Color.White,
                    label = if (isSaved) "Saved" else "Save",
                    isActive = isSaved,
                    testTag = "clip_save_btn_${clip.id}",
                    onClick = onToggleSave
                )

                // 4. Share Button
                FramelessSculptedActionItem(
                    glyph = ClipActionGlyph.SHARE,
                    activeColor = Color.White,
                    label = "Share",
                    isActive = isShareSheetOpen,
                    testTag = "clip_share_btn_${clip.id}",
                    onClick = {
                        isCommentDrawerOpen = false
                        isMoreOptionsSheetOpen = false
                        isAudioSheetOpen = false
                        isShareSheetOpen = !isShareSheetOpen
                    }
                )

                // 5. More Options (Three Dots)
                FramelessSculptedActionItem(
                    glyph = ClipActionGlyph.MORE,
                    activeColor = Color.White,
                    label = "",
                    isActive = isMoreOptionsSheetOpen,
                    testTag = "clip_more_btn_${clip.id}",
                    onClick = {
                        isCommentDrawerOpen = false
                        isShareSheetOpen = false
                        isAudioSheetOpen = false
                        isMoreOptionsSheetOpen = !isMoreOptionsSheetOpen
                    }
                )

                // 6. Spinning Instagram Audio Disc (Mini Music Player Launcher)
                InstagramAudioDisc(
                    preset = currentPreset,
                    rotation = audioDiscRotation,
                    isPlaying = !isPaused && isCurrentPage,
                    modifier = Modifier
                        .padding(top = 4.dp)
                        .clickable {
                            isCommentDrawerOpen = false
                            isShareSheetOpen = false
                            isMoreOptionsSheetOpen = false
                            isAudioSheetOpen = true
                        }
                        .testTag("clip_audio_disc_${clip.id}")
                )
            }
        }

        // 7. Bottom-Left Creator Info & Expandable Caption & Audio Row (Official Instagram Reels Format)
        AnimatedVisibility(
            visible = isControlsVisible || isScrubbing,
            enter = fadeIn(animationSpec = tween(220)) + slideInVertically(
                animationSpec = spring(
                    dampingRatio = Spring.DampingRatioLowBouncy,
                    stiffness = Spring.StiffnessMediumLow
                )
            ) { it / 2 },
            exit = fadeOut(animationSpec = tween(180)) + slideOutVertically(
                animationSpec = tween(180)
            ) { it / 2 },
            modifier = Modifier.align(Alignment.BottomStart)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth(0.72f)
                    .windowInsetsPadding(WindowInsets.navigationBars)
                    .padding(start = 16.dp, bottom = 22.dp),
                verticalArrangement = Arrangement.spacedBy(7.dp)
            ) {
                // Creator Row: Circular User Profile Photo + @handle • relative_time + Minimal text Follow Link
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    CreatorAvatarBadge(
                        name = clip.creatorName,
                        seed = clip.creatorAvatarSeed,
                        size = 36.dp,
                        isSquircle = false,
                        borderWidth = 1.4.dp,
                        showOnlineDot = false,
                        avatarUrl = clip.effectiveCreatorAvatarUrl,
                        modifier = Modifier.clickable { onCreatorClick() }
                    )

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        modifier = Modifier.clickable { onCreatorClick() }
                    ) {
                        Text(
                            text = clip.formattedCreatorHandle,
                            style = NexoraTypography.NavPillLabel.copy(
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                shadow = hudTextShadow
                            )
                        )
                        VerifiedBadge(size = 13.dp)
                    }

                    Text(
                        text = "• ${clip.relativeTime}",
                        style = NexoraTypography.BadgeMicro.copy(
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color.White.copy(alpha = 0.85f),
                            shadow = hudTextShadow
                        ),
                        modifier = Modifier.testTag("clip_creator_relative_time_${clip.id}")
                    )

                    Text(
                        text = "•",
                        style = NexoraTypography.BadgeMicro.copy(
                            fontSize = 12.sp,
                            color = Color.White.copy(alpha = 0.7f),
                            shadow = hudTextShadow
                        )
                    )

                    // Minimal Text Link without Border
                    Text(
                        text = if (isSubscribed) "Following" else "Follow",
                        style = NexoraTypography.BadgeMicro.copy(
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            shadow = hudTextShadow
                        ),
                        modifier = Modifier
                            .clickable { onToggleSubscribe() }
                            .padding(horizontal = 2.dp, vertical = 2.dp)
                            .testTag("clip_follow_btn_${clip.id}")
                    )
                }

                // Caption Area Below User Handle (Supports Tap to expand/collapse + Long Press & Swipe Left/Right to Scrub)
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .pointerInput(clip.id) {
                            awaitEachGesture {
                                val down = awaitFirstDown(requireUnconsumed = false)
                                down.consume()
                                val longPress = awaitLongPressOrCancellation(down.id)
                                if (longPress != null) {
                                    longPress.consume()
                                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                    val startProg = currentEffectiveProgress
                                    isScrubbing = true
                                    scrubDragStartProgress = startProg
                                    scrubDragAccumulatorPx = 0f
                                    scrubProgress = startProg
                                    seekFraction = startProg
                                    seekTrigger += 1

                                    while (true) {
                                        val event = awaitPointerEvent()
                                        val change = event.changes.firstOrNull { it.id == down.id }
                                            ?: event.changes.firstOrNull()
                                            ?: break
                                        if (!change.pressed) {
                                            change.consume()
                                            break
                                        }
                                        val dx = change.positionChange().x
                                        change.consume()
                                        if (dx != 0f) {
                                            scrubDragAccumulatorPx += dx
                                            val widthPx = (currentScreenWidthPx * 0.72f).coerceAtLeast(260f)
                                            val delta = scrubDragAccumulatorPx / widthPx
                                            val nextProg = (scrubDragStartProgress + delta).coerceIn(0f, 1f)
                                            scrubProgress = nextProg
                                            if (kotlin.math.abs(nextProg - seekFraction) >= 0.015f) {
                                                seekFraction = nextProg
                                                seekTrigger += 1
                                            }
                                        }
                                    }

                                    playbackProgress = scrubProgress
                                    seekFraction = scrubProgress
                                    seekTrigger += 1
                                    isScrubbing = false
                                } else {
                                    val upChange = currentEvent.changes.firstOrNull { it.id == down.id }
                                    if (upChange != null && !upChange.pressed && !upChange.isConsumed) {
                                        upChange.consume()
                                        isCaptionExpanded = !isCaptionExpanded
                                    }
                                }
                            }
                        },
                    verticalArrangement = Arrangement.spacedBy(7.dp)
                ) {
                    if (isCaptionExpanded) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("clip_expanded_caption_${clip.id}"),
                            verticalArrangement = Arrangement.spacedBy(5.dp)
                        ) {
                            Text(
                                text = clip.cleanTitle,
                                style = NexoraTypography.CardTitle.copy(
                                    fontSize = 13.5.sp,
                                    fontWeight = FontWeight.Normal,
                                    color = Color.White,
                                    shadow = hudTextShadow,
                                    lineHeight = 18.sp
                                )
                            )
                            if (clip.hashtags.isNotEmpty()) {
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    clip.hashtags.forEach { tag ->
                                        Text(
                                            text = tag,
                                            style = NexoraTypography.BadgeMicro.copy(
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.Medium,
                                                color = NexoraColors.Sky400,
                                                shadow = hudTextShadow
                                            )
                                        )
                                    }
                                }
                            }
                            Row(
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = "${clip.formattedViews} • ${clip.relativeTime}",
                                    style = NexoraTypography.BadgeMicro.copy(
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = Color.White.copy(alpha = 0.82f),
                                        shadow = hudTextShadow
                                    ),
                                    modifier = Modifier
                                        .padding(top = 2.dp)
                                        .testTag("clip_expanded_views_time_${clip.id}")
                                )
                                Text(
                                    text = "less",
                                    style = NexoraTypography.BadgeMicro.copy(
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = Color.White.copy(alpha = 0.70f),
                                        shadow = hudTextShadow
                                    )
                                )
                            }
                        }
                    } else {
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(3.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.Bottom,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = clip.cleanTitle,
                                    style = NexoraTypography.CardTitle.copy(
                                        fontSize = 13.5.sp,
                                        fontWeight = FontWeight.Normal,
                                        color = Color.White,
                                        shadow = hudTextShadow,
                                        lineHeight = 18.sp
                                    ),
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.weight(1f, fill = false)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "... more",
                                    style = NexoraTypography.BadgeMicro.copy(
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = Color.White.copy(alpha = 0.72f),
                                        shadow = hudTextShadow
                                    ),
                                    modifier = Modifier.testTag("clip_caption_more_toggle_${clip.id}")
                                )
                            }

                            // Views Count directly beneath the title
                            Text(
                                text = clip.formattedViews,
                                style = NexoraTypography.BadgeMicro.copy(
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = Color.White.copy(alpha = 0.84f),
                                    shadow = hudTextShadow
                                ),
                                modifier = Modifier.testTag("clip_views_beneath_title_${clip.id}")
                            )
                        }
                    }

                    // Instagram Audio Line: Music Note Icon + Scrolling Track Marquee (Tap opens Music Mini Player)
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier
                            .padding(top = 1.dp)
                            .clickable {
                                isCommentDrawerOpen = false
                                isShareSheetOpen = false
                                isMoreOptionsSheetOpen = false
                                isAudioSheetOpen = true
                            }
                            .testTag("clip_audio_row_${clip.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.GraphicEq,
                            contentDescription = "Audio track details",
                            tint = Color.White.copy(alpha = 0.95f),
                            modifier = Modifier.size(13.dp)
                        )

                        Text(
                            text = "${clip.cleanCreatorName} • Original audio • ${clip.cleanTitle}",
                            style = NexoraTypography.BadgeMicro.copy(
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.Medium,
                                color = Color.White.copy(alpha = 0.95f),
                                shadow = hudTextShadow
                            ),
                            maxLines = 1,
                            modifier = Modifier
                                .weight(1f, fill = false)
                                .basicMarquee()
                                .testTag("clip_audio_marquee_${clip.id}")
                        )
                    }
                }
            }
        }

        // 8. Scrubbing Time Bubble & Current Frame Indicator (Follows Drag Position)
        AnimatedVisibility(
            visible = isScrubbing,
            enter = fadeIn(animationSpec = tween(160)) + scaleIn(initialScale = 0.85f),
            exit = fadeOut(animationSpec = tween(140)) + scaleOut(targetScale = 0.85f),
            modifier = Modifier
                .align(Alignment.BottomStart)
                .offset {
                    val cardWidthPx = 76.dp.toPx()
                    val targetX = (effectiveProgress * screenWidthPx) - (cardWidthPx / 2f)
                    val clampedX = targetX.coerceIn(16.dp.toPx(), screenWidthPx - cardWidthPx - 16.dp.toPx())
                    IntOffset(clampedX.roundToInt(), -44.dp.toPx().roundToInt())
                }
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                // Live Current Frame Indicator (Mini 9:16 Video Canvas Frame)
                Box(
                    modifier = Modifier
                        .size(width = 76.dp, height = 114.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(NexoraColors.CanvasBase)
                        .border(1.8.dp, Color.White, RoundedCornerShape(12.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    SpatialVisualCanvas(
                        preset = currentPreset,
                        modifier = Modifier.fillMaxSize(),
                        isAnimated = false,
                        playbackPhase = effectiveProgress
                    )
                    // Frame Percentage Overlay Pill
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(4.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(Color.Black.copy(alpha = 0.70f))
                            .padding(horizontal = 4.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "#${(effectiveProgress * 100).toInt()}%",
                            style = NexoraTypography.BadgeMicro.copy(
                                fontSize = 9.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = NexoraColors.Sky400
                            )
                        )
                    }
                }

                // Time Bubble
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(999.dp))
                        .background(Color.Black.copy(alpha = 0.88f))
                        .border(1.dp, Color.White.copy(alpha = 0.25f), RoundedCornerShape(999.dp))
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(5.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(CircleShape)
                                .background(NexoraColors.Sky400)
                        )
                        Text(
                            text = "$currentSecStr / $totalSecStr",
                            style = NexoraTypography.BadgeMicro.copy(
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        )
                    }
                }
            }
        }

        // 9. Instagram Seekbar (Direct Drag on Seekbar + Long Press Drag on Caption)
        val seekbarHeight by animateDpAsState(
            targetValue = if (isScrubbing) 6.dp else 2.5.dp,
            animationSpec = spring(dampingRatio = Spring.DampingRatioLowBouncy),
            label = "seekbar_height"
        )

        AnimatedVisibility(
            visible = isControlsVisible || isScrubbing,
            enter = fadeIn(animationSpec = tween(200)),
            exit = fadeOut(animationSpec = tween(180)),
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .padding(bottom = if (isScrubbing) 6.dp else 0.dp)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(if (isScrubbing) 32.dp else 22.dp)
                    .pointerInput(clip.id) {
                        awaitEachGesture {
                            val down = awaitFirstDown(requireUnconsumed = false)
                            down.consume()
                            val widthPx = currentScreenWidthPx.coerceAtLeast(300f)
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            isScrubbing = true
                            val fraction = (down.position.x / widthPx).coerceIn(0f, 1f)
                            scrubDragStartProgress = fraction
                            scrubDragAccumulatorPx = 0f
                            scrubProgress = fraction
                            seekFraction = fraction
                            seekTrigger += 1

                            while (true) {
                                val event = awaitPointerEvent()
                                val change = event.changes.firstOrNull { it.id == down.id }
                                    ?: event.changes.firstOrNull()
                                    ?: break
                                if (!change.pressed) {
                                    change.consume()
                                    break
                                }
                                val dx = change.positionChange().x
                                change.consume()
                                if (dx != 0f) {
                                    scrubDragAccumulatorPx += dx
                                    val delta = scrubDragAccumulatorPx / widthPx
                                    val nextProg = (scrubDragStartProgress + delta).coerceIn(0f, 1f)
                                    scrubProgress = nextProg
                                    if (kotlin.math.abs(nextProg - seekFraction) >= 0.015f) {
                                        seekFraction = nextProg
                                        seekTrigger += 1
                                    }
                                }
                            }

                            playbackProgress = scrubProgress
                            seekFraction = scrubProgress
                            seekTrigger += 1
                            isScrubbing = false
                        }
                    },
                contentAlignment = Alignment.BottomCenter
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(seekbarHeight),
                    contentAlignment = Alignment.CenterStart
                ) {
                    // Background Track
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(seekbarHeight)
                            .background(if (isScrubbing) Color.White.copy(alpha = 0.35f) else Color.White.copy(alpha = 0.22f))
                    )
                    // Filled Progress
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(effectiveProgress)
                            .height(seekbarHeight)
                            .background(Color.White)
                    )
                    // Frame Indicator Orb along Seekbar
                    if (isScrubbing) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth(effectiveProgress)
                                .align(Alignment.CenterStart)
                        ) {
                            Box(
                                modifier = Modifier
                                    .align(Alignment.CenterEnd)
                                    .size(14.dp)
                                    .clip(CircleShape)
                                    .background(Color.White)
                                    .border(2.dp, NexoraColors.Sky400, CircleShape)
                            )
                        }
                    }
                }
            }
        }

        // NestedScroll blocker so scrolling inside the Comment or Share sheet NEVER leaks to VerticalPager
        val sheetNestedScrollBlocker = remember {
            object : NestedScrollConnection {
                override fun onPostScroll(
                    consumed: Offset,
                    available: Offset,
                    source: NestedScrollSource
                ): Offset = available

                override suspend fun onPostFling(
                    consumed: Velocity,
                    available: Velocity
                ): Velocity = available
            }
        }

        // 9. Scrim Overlay when Instagram Comment, Share Sheet, More Options, or Music Player Sheet is open
        AnimatedVisibility(
            visible = isCommentDrawerOpen || isShareSheetOpen || isMoreOptionsSheetOpen || isAudioSheetOpen,
            enter = fadeIn(animationSpec = tween(200)),
            exit = fadeOut(animationSpec = tween(180)),
            modifier = Modifier.fillMaxSize()
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0x78000000))
                    .pointerInput(Unit) {
                        detectVerticalDragGestures { change, _ ->
                            change.consume()
                        }
                    }
                    .clickable {
                        isCommentDrawerOpen = false
                        isShareSheetOpen = false
                        isMoreOptionsSheetOpen = false
                        isAudioSheetOpen = false
                        isGifPickerOpen = false
                    }
            )
        }

        // 10. Upgraded Instagram-Style Comments Bottom Sheet
        AnimatedVisibility(
            visible = isCommentDrawerOpen,
            enter = slideInVertically(
                initialOffsetY = { it },
                animationSpec = spring(
                    dampingRatio = Spring.DampingRatioNoBouncy,
                    stiffness = Spring.StiffnessMediumLow
                )
            ) + fadeIn(),
            exit = slideOutVertically(
                targetOffsetY = { it },
                animationSpec = tween(220, easing = FastOutSlowInEasing)
            ) + fadeOut(),
            modifier = Modifier.align(Alignment.BottomCenter)
        ) {
            SpatialClipCommentsBottomSheet(
                clip = clip,
                commentSortMode = commentSortMode,
                onSortModeChange = { commentSortMode = it },
                commentDraft = commentDraft,
                onCommentDraftChange = { commentDraft = it },
                replyingToAuthor = replyingToAuthor,
                onReplyingToAuthorChange = { replyingToAuthor = it },
                isGifPickerOpen = isGifPickerOpen,
                onGifPickerOpenChange = { isGifPickerOpen = it },
                gifSearchQuery = gifSearchQuery,
                onGifSearchQueryChange = { gifSearchQuery = it },
                onOpenShareSheet = {
                    isCommentDrawerOpen = false
                    isGifPickerOpen = false
                    isShareSheetOpen = true
                },
                onAddComment = onAddComment,
                onToggleCommentLike = onToggleCommentLike,
                sheetNestedScrollBlocker = sheetNestedScrollBlocker,
                onDeleteComment = onDeleteComment
            )
        }

        // 11. Instagram-Style Share Bottom Sheet (Search + 4-Col Friend Grid + Quick Share Dock)
        AnimatedVisibility(
            visible = isShareSheetOpen,
            enter = slideInVertically(
                initialOffsetY = { it },
                animationSpec = spring(
                    dampingRatio = Spring.DampingRatioNoBouncy,
                    stiffness = Spring.StiffnessMediumLow
                )
            ) + fadeIn(),
            exit = slideOutVertically(
                targetOffsetY = { it },
                animationSpec = tween(220, easing = FastOutSlowInEasing)
            ) + fadeOut(),
            modifier = Modifier.align(Alignment.BottomCenter)
        ) {
            val shareContacts = remember {
                listOf(
                    Triple("Lyra Vance", "@lyra.spatial", 2),
                    Triple("Kaelen Voss", "@kaelen.voss", 3),
                    Triple("Sora Takahashi", "@sora.optics", 4),
                    Triple("Nova Synth", "@nova.synth", 5),
                    Triple("Orion Pulse", "@orion.lab", 6),
                    Triple("Vespera", "@vespera.ai", 7),
                    Triple("Solis Studio", "@solis.vision", 8),
                    Triple("Aether Crew", "@aether.official", 1),
                    Triple("Zephyr Ward", "@zephyr.ward", 9),
                    Triple("Astrid Bloom", "@astrid.bloom", 10),
                    Triple("Cosmos Media", "@cosmos.media", 11),
                    Triple("Zenith Lab", "@zenith.lab", 12),
                    Triple("Hyperion Wave", "@hyperion.wave", 13),
                    Triple("Nebula Prime", "@nebula.prime", 14),
                    Triple("Cygnus Studio", "@cygnus.studio", 15),
                    Triple("Pulse Collective", "@pulse.collective", 16)
                )
            }
            val filteredContacts = remember(shareSearchQuery) {
                if (shareSearchQuery.isBlank()) shareContacts
                else shareContacts.filter {
                    it.first.contains(shareSearchQuery, ignoreCase = true) ||
                        it.second.contains(shareSearchQuery, ignoreCase = true)
                }
            }

            var isShareFullScreen by remember { mutableStateOf(false) }
            val shareListState = rememberLazyListState()

            val shareSheetFraction by animateFloatAsState(
                targetValue = if (isShareFullScreen) 0.94f else 0.58f,
                animationSpec = spring(
                    dampingRatio = Spring.DampingRatioLowBouncy,
                    stiffness = Spring.StiffnessMediumLow
                ),
                label = "share_sheet_height"
            )

            val shareScrollExpandConnection = rememberSheetScrollExpandConnection(
                isFullScreen = isShareFullScreen,
                onExpand = { isShareFullScreen = true },
                onCollapse = { isShareFullScreen = false }
            )

            LaunchedEffect(shareListState.isScrollInProgress) {
                if (shareListState.isScrollInProgress && !isShareFullScreen) {
                    isShareFullScreen = true
                }
            }

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .fillMaxHeight(shareSheetFraction)
                    .clip(RoundedCornerShape(topStart = 26.dp, topEnd = 26.dp))
                    .background(NexoraColors.CanvasBase)
                    .border(
                        width = 1.dp,
                        color = NexoraColors.SpecularBorderStrong,
                        shape = RoundedCornerShape(topStart = 26.dp, topEnd = 26.dp)
                    )
                    .sheetPinchGesture(
                        isFullScreen = isShareFullScreen,
                        onFullScreenChange = { isShareFullScreen = it }
                    )
                    .nestedScroll(shareScrollExpandConnection)
                    .nestedScroll(sheetNestedScrollBlocker)
                    .clickable(enabled = false) {}
                    .windowInsetsPadding(WindowInsets.navigationBars)
                    .padding(bottom = 14.dp)
                    .testTag("clip_share_bottom_sheet")
            ) {
                // Top Interactive Drag Handle Pill (Tap or Drag toggles full size)
                SheetInteractiveDragHandle(
                    isFullScreen = isShareFullScreen,
                    onToggleFullScreen = { isShareFullScreen = !isShareFullScreen }
                )

                // Theme-Matched Frosted Search Bar inside Share Sheet
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp)
                        .height(40.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(NexoraColors.Pearl50.copy(alpha = 0.88f))
                        .border(
                            width = 1.dp,
                            color = NexoraColors.SpecularBorderStrong,
                            shape = RoundedCornerShape(14.dp)
                        )
                        .padding(horizontal = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.Search,
                        contentDescription = "Search recipients",
                        tint = NexoraColors.ElectricIndigo,
                        modifier = Modifier.size(18.dp)
                    )
                    BasicTextField(
                        value = shareSearchQuery,
                        onValueChange = { shareSearchQuery = it },
                        singleLine = true,
                        textStyle = NexoraTypography.NavPillLabel.copy(
                            fontSize = 13.5.sp,
                            color = NexoraColors.InkPrimary
                        ),
                        cursorBrush = SolidColor(NexoraColors.ElectricIndigo),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("clip_share_search_input"),
                        decorationBox = { inner ->
                            if (shareSearchQuery.isEmpty()) {
                                Text(
                                    text = "Search friends...",
                                    style = NexoraTypography.NavPillLabel.copy(
                                        fontSize = 13.5.sp,
                                        color = NexoraColors.InkMuted
                                    )
                                )
                            }
                            inner()
                        }
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Scrollable 4-Column Contact Avatar Grid (Auto-expands to full screen on scroll or pinch)
                val rows = filteredContacts.chunked(4)
                LazyColumn(
                    state = shareListState,
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .padding(horizontal = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    items(rows) { rowContacts ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceEvenly
                        ) {
                            rowContacts.forEach { (name, handle, seed) ->
                                val isSelected = handle in selectedShareRecipients
                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy(6.dp),
                                    modifier = Modifier
                                        .width(76.dp)
                                        .clickable {
                                            selectedShareRecipients = if (isSelected) {
                                                selectedShareRecipients - handle
                                            } else {
                                                selectedShareRecipients + handle
                                            }
                                        }
                                ) {
                                    Box(contentAlignment = Alignment.BottomEnd) {
                                        CreatorAvatarBadge(
                                            name = name,
                                            seed = seed,
                                            size = 58.dp,
                                            isSquircle = false,
                                            borderWidth = if (isSelected) 2.dp else 1.dp,
                                            showOnlineDot = !isSelected
                                        )
                                        if (isSelected) {
                                            Box(
                                                modifier = Modifier
                                                    .size(20.dp)
                                                    .clip(CircleShape)
                                                    .background(
                                                        Brush.linearGradient(
                                                            colors = listOf(
                                                                NexoraColors.ElectricIndigo,
                                                                NexoraColors.Sky400
                                                            )
                                                        )
                                                    )
                                                    .border(1.5.dp, NexoraColors.Pearl50, CircleShape),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Filled.Check,
                                                    contentDescription = "Selected",
                                                    tint = Color.White,
                                                    modifier = Modifier.size(12.dp)
                                                )
                                            }
                                        }
                                    }
                                    Text(
                                        text = name.substringBefore(" "),
                                        style = NexoraTypography.BadgeMicro.copy(
                                            fontSize = 11.5.sp,
                                            color = if (isSelected) NexoraColors.ElectricIndigo else NexoraColors.InkPrimary,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.SemiBold
                                        ),
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))
                HorizontalDivider(
                    color = NexoraColors.Pearl300.copy(alpha = 0.75f),
                    thickness = 0.8.dp
                )
                Spacer(modifier = Modifier.height(12.dp))

                if (selectedShareRecipients.isNotEmpty()) {
                    // "Write a message..." + Theme Gradient "Send" Button when friends are selected
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        BasicTextField(
                            value = shareMessageDraft,
                            onValueChange = { shareMessageDraft = it },
                            singleLine = true,
                            textStyle = NexoraTypography.NavPillLabel.copy(
                                fontSize = 13.sp,
                                color = NexoraColors.InkPrimary
                            ),
                            cursorBrush = SolidColor(NexoraColors.ElectricIndigo),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(NexoraColors.Pearl50.copy(alpha = 0.82f))
                                .border(
                                    width = 1.dp,
                                    color = NexoraColors.SpecularBorderStrong,
                                    shape = RoundedCornerShape(12.dp)
                                )
                                .padding(horizontal = 12.dp, vertical = 10.dp),
                            decorationBox = { inner ->
                                if (shareMessageDraft.isEmpty()) {
                                    Text(
                                        text = "Write a message...",
                                        style = NexoraTypography.NavPillLabel.copy(
                                            fontSize = 13.sp,
                                            color = NexoraColors.InkMuted
                                        )
                                    )
                                }
                                inner()
                            }
                        )

                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(42.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(
                                    Brush.horizontalGradient(
                                        colors = listOf(
                                            NexoraColors.ElectricIndigo,
                                            NexoraColors.Sky400
                                        )
                                    )
                                )
                                .clickable {
                                    onShareClip()
                                    selectedShareRecipients = emptySet()
                                    shareMessageDraft = ""
                                    isShareSheetOpen = false
                                }
                                .testTag("clip_share_send_btn"),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = if (selectedShareRecipients.size == 1) "Send" else "Send separately (${selectedShareRecipients.size})",
                                style = NexoraTypography.NavPillLabel.copy(
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            )
                        }
                    }
                } else {
                    // Bottom Quick-Share Action Strip (Add to story, Share, Copy link, Repost, Messages)
                    LazyRow(
                        modifier = Modifier.fillMaxWidth(),
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(20.dp)
                    ) {
                        item {
                            InstagramQuickShareAction(
                                icon = Icons.Filled.AddCircleOutline,
                                label = "Add to story",
                                onClick = {
                                    onShareClip()
                                    isShareSheetOpen = false
                                }
                            )
                        }
                        item {
                            InstagramQuickShareAction(
                                icon = Icons.Filled.IosShare,
                                label = "Share",
                                onClick = {
                                    onShareClip()
                                    isShareSheetOpen = false
                                }
                            )
                        }
                        item {
                            InstagramQuickShareAction(
                                icon = Icons.Filled.Link,
                                label = "Copy link",
                                onClick = {
                                    onShareClip()
                                    isShareSheetOpen = false
                                }
                            )
                        }
                        item {
                            InstagramQuickShareAction(
                                icon = Icons.Filled.Repeat,
                                label = if (clip.isReposted) "Reposted" else "Repost",
                                onClick = {
                                    onToggleRepost()
                                    isShareSheetOpen = false
                                }
                            )
                        }
                        item {
                            InstagramQuickShareAction(
                                icon = Icons.AutoMirrored.Filled.Send,
                                label = "Messages",
                                onClick = {
                                    onShareClip()
                                    isShareSheetOpen = false
                                }
                            )
                        }
                    }
                }
            }
        }

        // 12. Top Floating Feedback Toast Banner (Matched with Pastel Glass Theme)
        AnimatedVisibility(
            visible = feedbackMessage != null,
            enter = fadeIn(animationSpec = tween(180)) + slideInVertically(
                animationSpec = spring(
                    dampingRatio = Spring.DampingRatioLowBouncy,
                    stiffness = Spring.StiffnessMediumLow
                )
            ) { -it },
            exit = fadeOut(animationSpec = tween(220)) + slideOutVertically(
                animationSpec = tween(220)
            ) { -it },
            modifier = Modifier
                .align(Alignment.TopCenter)
                .windowInsetsPadding(WindowInsets.statusBars)
                .padding(top = 56.dp)
        ) {
            feedbackMessage?.let { msg ->
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(999.dp))
                        .background(
                            Brush.horizontalGradient(
                                colors = listOf(
                                    NexoraColors.Pearl50.copy(alpha = 0.96f),
                                    NexoraColors.Sky100.copy(alpha = 0.94f),
                                    NexoraColors.Lavender100.copy(alpha = 0.94f)
                                )
                            )
                        )
                        .border(
                            width = 1.dp,
                            color = NexoraColors.ElectricIndigo.copy(alpha = 0.35f),
                            shape = RoundedCornerShape(999.dp)
                        )
                        .padding(horizontal = 16.dp, vertical = 9.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Check,
                            contentDescription = null,
                            tint = NexoraColors.ElectricIndigo,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = msg,
                            style = NexoraTypography.BadgeMicro.copy(
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = NexoraColors.InkPrimary
                            )
                        )
                    }
                }
            }
        }

        // 13. Clean Theme-Matched More Options Bottom Sheet (Pastel Glass + Unicolor Icons + Zero Extra Boxes)
        AnimatedVisibility(
            visible = isMoreOptionsSheetOpen,
            enter = slideInVertically(
                initialOffsetY = { it },
                animationSpec = spring(
                    dampingRatio = Spring.DampingRatioNoBouncy,
                    stiffness = Spring.StiffnessMediumLow
                )
            ) + fadeIn(),
            exit = slideOutVertically(
                targetOffsetY = { it },
                animationSpec = tween(220, easing = FastOutSlowInEasing)
            ) + fadeOut(),
            modifier = Modifier.align(Alignment.BottomCenter)
        ) {
            SpatialClipMoreOptionsBottomSheet(
                clip = clip,
                isSaved = isSaved,
                onToggleSave = {
                    val nextSaved = !isSaved
                    onToggleSave()
                    isMoreOptionsSheetOpen = false
                    feedbackMessage = if (nextSaved) "Saved" else "Removed from Saved"
                    coroutineScope.launch {
                        kotlinx.coroutines.delay(2200L)
                        feedbackMessage = null
                    }
                },
                onRemix = {
                    isMoreOptionsSheetOpen = false
                    feedbackMessage = "Remix camera ready"
                    coroutineScope.launch {
                        kotlinx.coroutines.delay(2200L)
                        feedbackMessage = null
                    }
                },
                onAudio = {
                    isMoreOptionsSheetOpen = false
                    isAudioSheetOpen = true
                },
                onCopyLink = {
                    onShareClip()
                    isMoreOptionsSheetOpen = false
                    feedbackMessage = "Link copied"
                    coroutineScope.launch {
                        kotlinx.coroutines.delay(2200L)
                        feedbackMessage = null
                    }
                },
                onInterested = {
                    isMoreOptionsSheetOpen = false
                    feedbackMessage = "Interested • Showing more like this"
                    coroutineScope.launch {
                        kotlinx.coroutines.delay(2400L)
                        if (feedbackMessage?.startsWith("Interested") == true) {
                            feedbackMessage = null
                        }
                    }
                },
                onNotInterested = {
                    isMoreOptionsSheetOpen = false
                    feedbackMessage = "Not Interested • Hidden"
                    coroutineScope.launch {
                        kotlinx.coroutines.delay(2400L)
                        if (feedbackMessage?.startsWith("Not Interested") == true) {
                            feedbackMessage = null
                        }
                    }
                },
                onReport = {
                    isMoreOptionsSheetOpen = false
                    feedbackMessage = "Report submitted"
                    coroutineScope.launch {
                        kotlinx.coroutines.delay(2400L)
                        if (feedbackMessage?.startsWith("Report") == true) {
                            feedbackMessage = null
                        }
                    }
                },
                onClaim = {
                    isMoreOptionsSheetOpen = false
                    feedbackMessage = "Claim submitted"
                    coroutineScope.launch {
                        kotlinx.coroutines.delay(2400L)
                        if (feedbackMessage?.startsWith("Claim") == true) {
                            feedbackMessage = null
                        }
                    }
                },
                onQualityChanged = { label ->
                    feedbackMessage = "Playback quality: $label"
                    coroutineScope.launch {
                        kotlinx.coroutines.delay(2200L)
                        if (feedbackMessage?.startsWith("Playback quality") == true) {
                            feedbackMessage = null
                        }
                    }
                },
                onDismiss = { isMoreOptionsSheetOpen = false },
                nestedScrollBlocker = sheetNestedScrollBlocker
            )
        }

        // 13. Instagram Music Mini Player & Audio Details Sheet
        AnimatedVisibility(
            visible = isAudioSheetOpen,
            enter = slideInVertically(
                initialOffsetY = { it },
                animationSpec = spring(
                    dampingRatio = Spring.DampingRatioNoBouncy,
                    stiffness = Spring.StiffnessMediumLow
                )
            ) + fadeIn(),
            exit = slideOutVertically(
                targetOffsetY = { it },
                animationSpec = tween(220, easing = FastOutSlowInEasing)
            ) + fadeOut(),
            modifier = Modifier.align(Alignment.BottomCenter)
        ) {
            InstagramMusicMiniPlayerSheet(
                clip = clip,
                allClips = allClips,
                isGlobalAudioMuted = isGlobalAudioMuted,
                onToggleMute = onToggleMute,
                onUseAudio = {
                    onShareClip()
                },
                onCreatorClick = { creatorId ->
                    isAudioSheetOpen = false
                    onCreatorClick()
                },
                onShareAudio = {
                    onShareClip()
                },
                onDismiss = {
                    isAudioSheetOpen = false
                },
                sheetNestedScrollBlocker = sheetNestedScrollBlocker
            )
        }
    }
}

@Composable
private fun InstagramQuickShareAction(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(6.dp),
        modifier = Modifier.clickable { onClick() }
    ) {
        Box(
            modifier = Modifier
                .size(50.dp)
                .clip(CircleShape)
                .background(NexoraColors.Pearl200)
                .border(1.dp, Color.White.copy(alpha = 0.14f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = Color.White,
                modifier = Modifier.size(22.dp)
            )
        }
        Text(
            text = label,
            style = NexoraTypography.BadgeMicro.copy(
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                color = NexoraColors.InkSecondary
            )
        )
    }
}

private enum class MoreOptionGlyph {
    SAVE,
    REMIX,
    AUDIO,
    LINK,
    QUALITY,
    INTERESTED,
    NOT_INTERESTED,
    REPORT,
    CLAIM
}

@Composable
private fun InstagramMusicMiniPlayerSheet(
    clip: VideoItem,
    allClips: List<VideoItem>,
    isGlobalAudioMuted: Boolean,
    onToggleMute: () -> Unit,
    onUseAudio: () -> Unit,
    onCreatorClick: (String) -> Unit,
    onShareAudio: () -> Unit,
    onDismiss: () -> Unit,
    sheetNestedScrollBlocker: NestedScrollConnection,
    modifier: Modifier = Modifier
) {
    var isAudioSaved by remember { mutableStateOf(false) }
    var isPreviewPlaying by remember { mutableStateOf(true) }
    var previewProgress by remember { mutableFloatStateOf(0.35f) }
    var toastFeedback by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(isPreviewPlaying) {
        if (isPreviewPlaying) {
            var lastFrame = withFrameNanos { it }
            while (true) {
                val frame = withFrameNanos { it }
                val delta = ((frame - lastFrame) / 1_000_000f) / 15000f
                lastFrame = frame
                previewProgress = (previewProgress + delta) % 1f
            }
        }
    }

    val relatedClips = remember(clip.id, allClips) {
        allClips.filter { it.id != clip.id }.take(6)
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp))
            .background(NexoraColors.CanvasBase)
            .border(
                width = 1.dp,
                color = NexoraColors.SpecularBorderStrong,
                shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
            )
            .nestedScroll(sheetNestedScrollBlocker)
            .pointerInput(Unit) {
                detectVerticalDragGestures { change, _ -> change.consume() }
            }
            .clickable(enabled = false) {}
            .windowInsetsPadding(WindowInsets.navigationBars)
            .padding(bottom = 16.dp)
            .testTag("instagram_music_mini_player_sheet")
    ) {
        // Drag Handle
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 10.dp, bottom = 8.dp),
            contentAlignment = Alignment.Center
        ) {
            Box(
                modifier = Modifier
                    .width(42.dp)
                    .height(4.dp)
                    .clip(RoundedCornerShape(999.dp))
                    .background(NexoraColors.Pearl300)
            )
        }

        // Top Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Filled.GraphicEq,
                    contentDescription = "Audio track",
                    tint = NexoraColors.ElectricIndigo,
                    modifier = Modifier.size(20.dp)
                )
                Text(
                    text = "Audio Details",
                    style = NexoraTypography.SectionTitle.copy(
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = NexoraColors.InkPrimary
                    )
                )
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Save Audio Bookmark
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(NexoraColors.Pearl50.copy(alpha = 0.90f))
                        .clickable {
                            isAudioSaved = !isAudioSaved
                            toastFeedback = if (isAudioSaved) "Audio saved to collection" else "Audio removed"
                        }
                        .testTag("save_audio_track_btn"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (isAudioSaved) Icons.Filled.Bookmark else Icons.Outlined.BookmarkBorder,
                        contentDescription = "Save audio",
                        tint = if (isAudioSaved) NexoraColors.ElectricIndigo else NexoraColors.InkPrimary,
                        modifier = Modifier.size(18.dp)
                    )
                }

                // Share Audio
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(NexoraColors.Pearl50.copy(alpha = 0.90f))
                        .clickable { onShareAudio() }
                        .testTag("share_audio_track_btn"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Filled.IosShare,
                        contentDescription = "Share audio",
                        tint = NexoraColors.InkPrimary,
                        modifier = Modifier.size(18.dp)
                    )
                }

                // Close Button
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(NexoraColors.Pearl50.copy(alpha = 0.90f))
                        .clickable { onDismiss() }
                        .testTag("close_audio_sheet_btn"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Filled.Close,
                        contentDescription = "Close",
                        tint = NexoraColors.InkPrimary,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Toast Feedback if any
        toastFeedback?.let { msg ->
            Text(
                text = msg,
                style = NexoraTypography.BadgeMicro.copy(
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = NexoraColors.ElectricIndigo
                ),
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 2.dp)
            )
        }

        // Hero Audio Card Section
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .clip(RoundedCornerShape(20.dp))
                .background(NexoraColors.Pearl50.copy(alpha = 0.92f))
                .border(1.dp, NexoraColors.SpecularBorderStrong, RoundedCornerShape(20.dp))
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Album Artwork Box with Spinning Record Overlay
            Box(
                modifier = Modifier
                    .size(76.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color(0xFF1E1B4B)),
                contentAlignment = Alignment.Center
            ) {
                SpatialVisualCanvas(
                    preset = clip.visualPreset,
                    modifier = Modifier.fillMaxSize(),
                    isAnimated = isPreviewPlaying,
                    playbackPhase = previewProgress
                )
                // Overlaid Disc Badge
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(4.dp)
                        .size(26.dp)
                        .clip(CircleShape)
                        .background(NexoraColors.CanvasBase.copy(alpha = 0.85f))
                        .border(1.dp, Color.White, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Filled.GraphicEq,
                        contentDescription = null,
                        tint = NexoraColors.Sky400,
                        modifier = Modifier.size(14.dp)
                    )
                }
            }

            // Audio Metadata
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "${clip.cleanCreatorName} • Original audio",
                        style = NexoraTypography.CardTitle.copy(
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = NexoraColors.InkPrimary
                        ),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Text(
                    text = clip.formattedCreatorHandle,
                    style = NexoraTypography.NavPillLabel.copy(
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = NexoraColors.ElectricIndigo
                    ),
                    modifier = Modifier.clickable {
                        onCreatorClick(clip.creatorId)
                    }
                )

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.padding(top = 2.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(NexoraColors.ElectricIndigo.copy(alpha = 0.12f))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "Trending #1",
                            style = NexoraTypography.BadgeMicro.copy(
                                fontSize = 10.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = NexoraColors.ElectricIndigo
                            )
                        )
                    }

                    Text(
                        text = "12.8K Reels",
                        style = NexoraTypography.BadgeMicro.copy(
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            color = NexoraColors.InkMuted
                        )
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Music Scrubber & Player Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .height(48.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(NexoraColors.Pearl100)
                .padding(horizontal = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Play / Pause Button
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .clip(CircleShape)
                    .background(NexoraColors.ElectricIndigo)
                    .clickable { isPreviewPlaying = !isPreviewPlaying }
                    .testTag("audio_preview_play_pause_btn"),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (isPreviewPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                    contentDescription = if (isPreviewPlaying) "Pause preview" else "Play preview",
                    tint = Color.White,
                    modifier = Modifier.size(18.dp)
                )
            }

            // Waveform scrubber bar
            Box(
                modifier = Modifier
                    .weight(1f)
                    .height(24.dp)
                    .clickable {
                        previewProgress = (previewProgress + 0.25f) % 1f
                    },
                contentAlignment = Alignment.Center
            ) {
                SpatialAudioWaveformMini(
                    phase = previewProgress,
                    isPlaying = isPreviewPlaying
                )
            }

            // Time indicator
            Text(
                text = "${(previewProgress * 30).toInt()}s / 30s",
                style = NexoraTypography.BadgeMicro.copy(
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color.White.copy(alpha = 0.85f)
                )
            )

            // Mute / Unmute
            Box(
                modifier = Modifier
                    .size(30.dp)
                    .clip(CircleShape)
                    .clickable { onToggleMute() }
                    .testTag("audio_preview_mute_btn"),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (isGlobalAudioMuted) Icons.AutoMirrored.Filled.VolumeOff else Icons.AutoMirrored.Filled.VolumeUp,
                    contentDescription = "Mute",
                    tint = Color.White,
                    modifier = Modifier.size(16.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // "Use Audio" Primary Instagram Action Button
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .height(48.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(
                    Brush.horizontalGradient(
                        colors = listOf(
                            NexoraColors.ElectricIndigo,
                            NexoraColors.Sky400
                        )
                    )
                )
                .clickable {
                    onUseAudio()
                    onDismiss()
                }
                .testTag("use_audio_in_reel_btn"),
            contentAlignment = Alignment.Center
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Filled.AutoAwesome,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(18.dp)
                )
                Text(
                    text = "Use Audio in Reel",
                    style = NexoraTypography.NavPillLabel.copy(
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                )
            }
        }

        if (relatedClips.isNotEmpty()) {
            Spacer(modifier = Modifier.height(16.dp))

            // Section Header: Reels using this audio
            Text(
                text = "Reels using this audio",
                style = NexoraTypography.SectionTitle.copy(
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = NexoraColors.InkPrimary
                ),
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp)
            )

            Spacer(modifier = Modifier.height(6.dp))

            // Horizontal Reel Thumbnail Row
            LazyRow(
                contentPadding = PaddingValues(horizontal = 20.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(relatedClips, key = { it.id }) { relClip ->
                    Box(
                        modifier = Modifier
                            .size(width = 86.dp, height = 124.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(NexoraColors.Pearl100)
                            .clickable {
                                onDismiss()
                            }
                            .testTag("related_audio_reel_${relClip.id}"),
                        contentAlignment = Alignment.BottomStart
                    ) {
                        SpatialVisualCanvas(
                            preset = relClip.visualPreset,
                            modifier = Modifier.fillMaxSize(),
                            isAnimated = false,
                            playbackPhase = 0.5f
                        )
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(
                                    Brush.verticalGradient(
                                        0.5f to Color.Transparent,
                                        1.0f to Color.Black.copy(alpha = 0.75f)
                                    )
                                )
                        )
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(3.dp),
                            modifier = Modifier.padding(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.PlayArrow,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(10.dp)
                            )
                            Text(
                                text = relClip.viewsText,
                                style = NexoraTypography.BadgeMicro.copy(
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SpatialClipMoreOptionsBottomSheet(
    clip: VideoItem,
    isSaved: Boolean,
    onToggleSave: () -> Unit,
    onRemix: () -> Unit,
    onAudio: () -> Unit,
    onCopyLink: () -> Unit,
    onInterested: () -> Unit,
    onNotInterested: () -> Unit,
    onReport: () -> Unit,
    onClaim: () -> Unit,
    onQualityChanged: (String) -> Unit = {},
    onDismiss: () -> Unit,
    nestedScrollBlocker: NestedScrollConnection,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val forceHighestQuality = AkashQualityController.forceHighestQuality
    var isMoreFullScreen by remember { mutableStateOf(false) }
    val moreScrollState = rememberScrollState()

    val moreSheetFraction by animateFloatAsState(
        targetValue = if (isMoreFullScreen) 0.88f else 0.52f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioLowBouncy,
            stiffness = Spring.StiffnessMediumLow
        ),
        label = "more_sheet_height"
    )

    val moreScrollExpandConnection = rememberSheetScrollExpandConnection(
        isFullScreen = isMoreFullScreen,
        onExpand = { isMoreFullScreen = true },
        onCollapse = { isMoreFullScreen = false }
    )

    LaunchedEffect(moreScrollState.isScrollInProgress) {
        if (moreScrollState.isScrollInProgress && !isMoreFullScreen) {
            isMoreFullScreen = true
        }
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .fillMaxHeight(moreSheetFraction)
            .clip(RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp))
            .background(NexoraColors.CanvasBase)
            .border(
                width = 1.dp,
                color = NexoraColors.SpecularBorderStrong,
                shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
            )
            .sheetPinchGesture(
                isFullScreen = isMoreFullScreen,
                onFullScreenChange = { isMoreFullScreen = it }
            )
            .nestedScroll(moreScrollExpandConnection)
            .nestedScroll(nestedScrollBlocker)
            .clickable(enabled = false) {}
            .windowInsetsPadding(WindowInsets.navigationBars)
            .padding(bottom = 16.dp)
            .testTag("clip_more_options_sheet")
    ) {
        // Interactive Drag Handle Pill (Tap or Drag toggles full size)
        SheetInteractiveDragHandle(
            isFullScreen = isMoreFullScreen,
            onToggleFullScreen = { isMoreFullScreen = !isMoreFullScreen }
        )

        // Top Row: 4 Quick-Action Circular Orbs (Save, Remix, Audio, Copy link)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            InstagramColoredQuickOrb(
                label = if (isSaved) "Saved" else "Save",
                glyphType = MoreOptionGlyph.SAVE,
                gradientColors = listOf(Color.White, Color.White),
                isHighlighted = isSaved,
                testTag = "clip_option_save",
                onClick = onToggleSave
            )

            InstagramColoredQuickOrb(
                label = "Remix",
                glyphType = MoreOptionGlyph.REMIX,
                gradientColors = listOf(Color.White, Color.White),
                testTag = "clip_option_remix",
                onClick = onRemix
            )

            InstagramColoredQuickOrb(
                label = "Audio",
                glyphType = MoreOptionGlyph.AUDIO,
                gradientColors = listOf(Color.White, Color.White),
                testTag = "clip_option_audio",
                onClick = onAudio
            )

            InstagramColoredQuickOrb(
                label = "Copy link",
                glyphType = MoreOptionGlyph.LINK,
                gradientColors = listOf(Color.White, Color.White),
                testTag = "clip_option_copy_link",
                onClick = onCopyLink
            )
        }

        Spacer(modifier = Modifier.height(14.dp))

        HorizontalDivider(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp),
            thickness = 0.7.dp,
            color = NexoraColors.SpecularBorderSubtle
        )

        Spacer(modifier = Modifier.height(4.dp))

        // Clean Boxless Vertical List with Subtle Hairline Dividers
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .verticalScroll(moreScrollState)
                .padding(horizontal = 20.dp)
        ) {
            // Single Toggle Switch: "Highest Quality" [ON/OFF] (No multi-resolution dropdown/sub-menu)
            SleekMoreOptionRow(
                title = "Highest Quality",
                accentColors = listOf(Color.White, Color.White),
                iconTint = Color.White,
                titleColor = Color.White,
                badgeText = if (forceHighestQuality) "ON" else "OFF",
                glyphType = MoreOptionGlyph.QUALITY,
                testTag = "force_highest_quality_toggle",
                onClick = {
                    val nextState = AkashQualityController.toggleHighestQuality()
                    onQualityChanged(
                        if (nextState) "Highest Quality: ON" else "Highest Quality: OFF (Adaptive HLS)"
                    )
                    onDismiss()
                }
            )

            HorizontalDivider(
                modifier = Modifier.fillMaxWidth(),
                thickness = 0.6.dp,
                color = Color.White.copy(alpha = 0.10f)
            )

            SleekMoreOptionRow(
                title = "Interested",
                accentColors = listOf(NexoraColors.InkPrimary, NexoraColors.InkPrimary),
                iconTint = NexoraColors.InkPrimary,
                titleColor = NexoraColors.InkPrimary,
                badgeText = "Boost",
                glyphType = MoreOptionGlyph.INTERESTED,
                testTag = "clip_option_interested",
                onClick = onInterested
            )

            HorizontalDivider(
                modifier = Modifier.fillMaxWidth(),
                thickness = 0.6.dp,
                color = NexoraColors.SpecularBorderSubtle
            )

            SleekMoreOptionRow(
                title = "Not interested",
                accentColors = listOf(NexoraColors.InkPrimary, NexoraColors.InkPrimary),
                iconTint = NexoraColors.InkPrimary,
                titleColor = NexoraColors.InkPrimary,
                glyphType = MoreOptionGlyph.NOT_INTERESTED,
                testTag = "clip_option_not_interested",
                onClick = onNotInterested
            )

            HorizontalDivider(
                modifier = Modifier.fillMaxWidth(),
                thickness = 0.6.dp,
                color = NexoraColors.SpecularBorderSubtle
            )

            SleekMoreOptionRow(
                title = "Claim this video",
                accentColors = listOf(NexoraColors.InkPrimary, NexoraColors.InkPrimary),
                iconTint = NexoraColors.InkPrimary,
                titleColor = NexoraColors.InkPrimary,
                badgeText = "Creator",
                glyphType = MoreOptionGlyph.CLAIM,
                testTag = "clip_option_claim",
                onClick = onClaim
            )

            HorizontalDivider(
                modifier = Modifier.fillMaxWidth(),
                thickness = 0.6.dp,
                color = NexoraColors.SpecularBorderSubtle
            )

            SleekMoreOptionRow(
                title = "Report",
                accentColors = listOf(NexoraColors.LiveRose, NexoraColors.LiveRose),
                iconTint = NexoraColors.LiveRose,
                titleColor = NexoraColors.LiveRose,
                glyphType = MoreOptionGlyph.REPORT,
                testTag = "clip_option_report",
                onClick = onReport
            )
        }
    }
}

@Composable
private fun InstagramColoredQuickOrb(
    label: String,
    glyphType: MoreOptionGlyph,
    gradientColors: List<Color>,
    testTag: String,
    isHighlighted: Boolean = false,
    onClick: () -> Unit
) {
    val unicolorTint = NexoraColors.InkPrimary
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(7.dp),
        modifier = Modifier
            .clip(RoundedCornerShape(16.dp))
            .clickable { onClick() }
            .padding(horizontal = 8.dp, vertical = 4.dp)
            .testTag(testTag)
    ) {
        Box(
            modifier = Modifier
                .size(54.dp)
                .clip(CircleShape)
                .background(
                    if (isHighlighted) {
                        NexoraColors.ElectricIndigo.copy(alpha = 0.15f)
                    } else {
                        NexoraColors.Pearl200
                    }
                )
                .border(
                    width = 1.dp,
                    color = if (isHighlighted) {
                        NexoraColors.ElectricIndigo.copy(alpha = 0.65f)
                    } else {
                        NexoraColors.SpecularBorderSubtle
                    },
                    shape = CircleShape
                ),
            contentAlignment = Alignment.Center
        ) {
            MoreOptionVectorGlyph(
                glyphType = glyphType,
                tint = if (isHighlighted) NexoraColors.ElectricIndigo else unicolorTint,
                modifier = Modifier.size(22.dp)
            )
        }

        Text(
            text = label,
            style = NexoraTypography.BadgeMicro.copy(
                fontSize = 11.5.sp,
                fontWeight = if (isHighlighted) FontWeight.Bold else FontWeight.SemiBold,
                color = if (isHighlighted) NexoraColors.ElectricIndigo else NexoraColors.InkPrimary
            )
        )
    }
}

@Composable
private fun SleekMoreOptionRow(
    title: String,
    accentColors: List<Color>,
    glyphType: MoreOptionGlyph,
    testTag: String,
    iconTint: Color = NexoraColors.InkPrimary,
    titleColor: Color = NexoraColors.InkPrimary,
    badgeText: String? = null,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(horizontal = 6.dp, vertical = 14.dp)
            .testTag(testTag),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Direct Unboxed Unicolor Vector Icon (No extra icon box)
        MoreOptionVectorGlyph(
            glyphType = glyphType,
            tint = iconTint,
            modifier = Modifier.size(20.dp)
        )

        // Title in crisp primary text (or LiveRose for Report)
        Text(
            text = title,
            style = NexoraTypography.NavPillLabel.copy(
                fontSize = 14.5.sp,
                fontWeight = FontWeight.SemiBold,
                color = titleColor
            ),
            modifier = Modifier.weight(1f)
        )

        // Optional Subtle Dark/Light Pill Badge
        badgeText?.let { badge ->
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(999.dp))
                    .background(NexoraColors.Pearl200)
                    .border(
                        width = 0.8.dp,
                        color = NexoraColors.SpecularBorderSubtle,
                        shape = RoundedCornerShape(999.dp)
                    )
                    .padding(horizontal = 9.dp, vertical = 3.dp)
            ) {
                Text(
                    text = badge,
                    style = NexoraTypography.BadgeMicro.copy(
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = NexoraColors.InkPrimary
                    )
                )
            }
        }
    }
}

@Composable
private fun MoreOptionVectorGlyph(
    glyphType: MoreOptionGlyph,
    tint: Color,
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        when (glyphType) {
            MoreOptionGlyph.SAVE -> {
                // Distinct Bookmark / Save vector
                val path = Path().apply {
                    moveTo(w * 0.25f, h * 0.15f)
                    lineTo(w * 0.75f, h * 0.15f)
                    lineTo(w * 0.75f, h * 0.85f)
                    lineTo(w * 0.50f, h * 0.65f)
                    lineTo(w * 0.25f, h * 0.85f)
                    close()
                }
                drawPath(path = path, color = tint, style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
            }
            MoreOptionGlyph.REMIX -> {
                // Distinct Video Clapper / Remix vector
                drawRect(
                    color = tint,
                    topLeft = Offset(w * 0.15f, h * 0.30f),
                    size = Size(w * 0.70f, h * 0.50f),
                    style = Stroke(width = 2.dp.toPx())
                )
                drawLine(
                    color = tint,
                    start = Offset(w * 0.15f, h * 0.48f),
                    end = Offset(w * 0.85f, h * 0.48f),
                    strokeWidth = 1.8.dp.toPx()
                )
                drawLine(
                    color = tint,
                    start = Offset(w * 0.35f, h * 0.18f),
                    end = Offset(w * 0.55f, h * 0.30f),
                    strokeWidth = 2.dp.toPx(),
                    cap = StrokeCap.Round
                )
                drawLine(
                    color = tint,
                    start = Offset(w * 0.65f, h * 0.18f),
                    end = Offset(w * 0.85f, h * 0.30f),
                    strokeWidth = 2.dp.toPx(),
                    cap = StrokeCap.Round
                )
            }
            MoreOptionGlyph.AUDIO -> {
                // Distinct Sound Wave / Music Note vector
                drawCircle(color = tint, radius = 2.5.dp.toPx(), center = Offset(w * 0.35f, h * 0.72f))
                drawCircle(color = tint, radius = 2.5.dp.toPx(), center = Offset(w * 0.75f, h * 0.62f))
                drawLine(color = tint, start = Offset(w * 0.47f, h * 0.72f), end = Offset(w * 0.47f, h * 0.22f), strokeWidth = 2.dp.toPx())
                drawLine(color = tint, start = Offset(w * 0.47f, h * 0.22f), end = Offset(w * 0.87f, h * 0.15f), strokeWidth = 2.dp.toPx(), cap = StrokeCap.Round)
                drawLine(color = tint, start = Offset(w * 0.87f, h * 0.15f), end = Offset(w * 0.87f, h * 0.62f), strokeWidth = 2.dp.toPx())
            }
            MoreOptionGlyph.LINK -> {
                // Distinct Share/Link Arrow vector
                val arrowPath = Path().apply {
                    moveTo(w * 0.4f, h * 0.2f)
                    lineTo(w * 0.8f, h * 0.2f)
                    lineTo(w * 0.8f, h * 0.6f)
                }
                drawPath(path = arrowPath, color = tint, style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
                drawLine(color = tint, start = Offset(w * 0.8f, h * 0.2f), end = Offset(w * 0.25f, h * 0.75f), strokeWidth = 2.dp.toPx(), cap = StrokeCap.Round)
            }
            MoreOptionGlyph.QUALITY -> {
                // HD / Video Quality Sliders vector
                drawRoundRect(
                    color = tint,
                    topLeft = Offset(w * 0.14f, h * 0.20f),
                    size = Size(w * 0.72f, h * 0.60f),
                    cornerRadius = CornerRadius(4.dp.toPx()),
                    style = Stroke(width = 1.9.dp.toPx())
                )
                drawLine(
                    color = tint,
                    start = Offset(w * 0.28f, h * 0.40f),
                    end = Offset(w * 0.72f, h * 0.40f),
                    strokeWidth = 1.7.dp.toPx(),
                    cap = StrokeCap.Round
                )
                drawCircle(
                    color = tint,
                    radius = 2.4.dp.toPx(),
                    center = Offset(w * 0.58f, h * 0.40f)
                )
                drawLine(
                    color = tint,
                    start = Offset(w * 0.28f, h * 0.60f),
                    end = Offset(w * 0.72f, h * 0.60f),
                    strokeWidth = 1.7.dp.toPx(),
                    cap = StrokeCap.Round
                )
                drawCircle(
                    color = tint,
                    radius = 2.4.dp.toPx(),
                    center = Offset(w * 0.40f, h * 0.60f)
                )
            }
            MoreOptionGlyph.INTERESTED -> {
                // Distinct Star / Thumbs Up vector
                val starPath = Path().apply {
                    moveTo(w * 0.5f, h * 0.12f)
                    lineTo(w * 0.62f, h * 0.38f)
                    lineTo(w * 0.90f, h * 0.42f)
                    lineTo(w * 0.70f, h * 0.62f)
                    lineTo(w * 0.75f, h * 0.88f)
                    lineTo(w * 0.5f, h * 0.74f)
                    lineTo(w * 0.25f, h * 0.88f)
                    lineTo(w * 0.30f, h * 0.62f)
                    lineTo(w * 0.10f, h * 0.42f)
                    lineTo(w * 0.38f, h * 0.38f)
                    close()
                }
                drawPath(path = starPath, color = tint, style = Stroke(width = 1.8.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
            }
            MoreOptionGlyph.NOT_INTERESTED -> {
                // Distinct Eye / Hide vector
                drawCircle(color = tint, radius = w * 0.35f, style = Stroke(width = 2.dp.toPx()))
                drawCircle(color = tint, radius = w * 0.12f)
                drawLine(color = tint, start = Offset(w * 0.18f, h * 0.82f), end = Offset(w * 0.82f, h * 0.18f), strokeWidth = 2.2.dp.toPx(), cap = StrokeCap.Round)
            }
            MoreOptionGlyph.REPORT -> {
                // Distinct Flag vector
                val flagPath = Path().apply {
                    moveTo(w * 0.3f, h * 0.18f)
                    lineTo(w * 0.8f, h * 0.35f)
                    lineTo(w * 0.3f, h * 0.52f)
                    close()
                }
                drawPath(path = flagPath, color = tint)
                drawLine(color = tint, start = Offset(w * 0.3f, h * 0.18f), end = Offset(w * 0.3f, h * 0.85f), strokeWidth = 2.2.dp.toPx(), cap = StrokeCap.Round)
            }
            MoreOptionGlyph.CLAIM -> {
                // Distinct Verified Badge / Claim vector
                val badgePath = Path().apply {
                    moveTo(w * 0.5f, h * 0.15f)
                    lineTo(w * 0.70f, h * 0.25f)
                    lineTo(w * 0.78f, h * 0.48f)
                    lineTo(w * 0.68f, h * 0.72f)
                    lineTo(w * 0.5f, h * 0.85f)
                    lineTo(w * 0.32f, h * 0.72f)
                    lineTo(w * 0.22f, h * 0.48f)
                    lineTo(w * 0.30f, h * 0.25f)
                    close()
                }
                drawPath(path = badgePath, color = tint, style = Stroke(width = 1.8.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
                val checkPath = Path().apply {
                    moveTo(w * 0.36f, h * 0.50f)
                    lineTo(w * 0.46f, h * 0.60f)
                    lineTo(w * 0.64f, h * 0.38f)
                }
                drawPath(path = checkPath, color = tint, style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
            }
        }
    }
}

private enum class ClipActionGlyph {
    HEART,
    COMMENT,
    REPOST,
    BOOKMARK,
    SHARE,
    VIEWS,
    MORE
}

@Composable
private fun SculptedCameraIcon(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        val shadowColor = Color(0x99090D16)
        val cornerRad = CornerRadius(4.5.dp.toPx())
        val bumpPath = Path().apply {
            moveTo(w * 0.32f, h * 0.30f)
            lineTo(w * 0.38f, h * 0.18f)
            lineTo(w * 0.62f, h * 0.18f)
            lineTo(w * 0.68f, h * 0.30f)
            close()
        }
        translate(left = 0f, top = 1.5.dp.toPx()) {
            drawRoundRect(
                color = shadowColor,
                topLeft = Offset(w * 0.12f, h * 0.30f),
                size = Size(w * 0.76f, h * 0.54f),
                cornerRadius = cornerRad,
                style = Stroke(width = 2.4.dp.toPx())
            )
            drawPath(path = bumpPath, color = shadowColor, style = Stroke(width = 2.2.dp.toPx()))
            drawCircle(
                color = shadowColor,
                radius = w * 0.16f,
                center = Offset(w * 0.5f, h * 0.57f),
                style = Stroke(width = 2.4.dp.toPx())
            )
        }
        drawRoundRect(
            color = Color.White,
            topLeft = Offset(w * 0.12f, h * 0.30f),
            size = Size(w * 0.76f, h * 0.54f),
            cornerRadius = cornerRad,
            style = Stroke(width = 2.0.dp.toPx())
        )
        drawPath(path = bumpPath, color = Color.White, style = Stroke(width = 1.8.dp.toPx()))
        drawCircle(
            color = Color.White,
            radius = w * 0.16f,
            center = Offset(w * 0.5f, h * 0.57f),
            style = Stroke(width = 2.0.dp.toPx())
        )
        drawCircle(color = Color.White, radius = 1.5.dp.toPx(), center = Offset(w * 0.74f, h * 0.40f))
    }
}

@Composable
private fun InstagramAudioDisc(
    preset: VisualThemePreset,
    rotation: Float,
    isPlaying: Boolean,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .size(34.dp)
            .graphicsLayer { rotationZ = if (isPlaying) rotation else 0f }
            .clip(RoundedCornerShape(8.dp))
            .background(NexoraColors.CanvasBase)
            .border(1.6.dp, Color.White.copy(alpha = 0.90f), RoundedCornerShape(8.dp)),
        contentAlignment = Alignment.Center
    ) {
        SpatialVisualCanvas(
            preset = preset,
            modifier = Modifier.fillMaxSize(),
            isAnimated = false,
            playbackPhase = 0.5f
        )
        Box(
            modifier = Modifier
                .size(14.dp)
                .clip(CircleShape)
                .background(Color.Black.copy(alpha = 0.78f)),
            contentAlignment = Alignment.Center
        ) {
            Canvas(modifier = Modifier.size(7.dp)) {
                drawCircle(color = Color.White, radius = 1.8.dp.toPx())
            }
        }
    }
}

@Composable
private fun SculptedBackChevronIcon(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        val chevronPath = Path().apply {
            moveTo(w * 0.62f, h * 0.18f)
            lineTo(w * 0.26f, h * 0.50f)
            lineTo(w * 0.62f, h * 0.82f)
        }
        // Soft optical drop shadow pass
        translate(left = 0f, top = 1.5.dp.toPx()) {
            drawPath(
                path = chevronPath,
                color = Color(0x99090D16),
                style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
            )
        }
        // Crisp foreground stroke
        drawPath(
            path = chevronPath,
            color = Color.White,
            style = Stroke(width = 2.2.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
        )
    }
}

@Composable
private fun FramelessSculptedActionItem(
    glyph: ClipActionGlyph,
    activeColor: Color,
    label: String,
    isActive: Boolean,
    testTag: String,
    onClick: () -> Unit
) {
    val scale by animateFloatAsState(
        targetValue = if (isActive) 1.20f else 1f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioLowBouncy,
            stiffness = Spring.StiffnessMedium
        ),
        label = "frameless_icon_scale"
    )

    val labelShadow = remember {
        Shadow(
            color = Color(0xCC090D16),
            offset = Offset(0f, 1.5f),
            blurRadius = 6f
        )
    }

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(4.dp),
        modifier = Modifier
            .size(width = 48.dp, height = 52.dp)
            .clickable { onClick() }
            .testTag(testTag)
    ) {
        Box(
            modifier = Modifier
                .size(30.dp)
                .graphicsLayer {
                    scaleX = scale
                    scaleY = scale
                },
            contentAlignment = Alignment.Center
        ) {
            Canvas(modifier = Modifier.size(26.dp)) {
                val shadowColor = Color(0x99090D16)
                val mainColor = if (isActive) activeColor else Color.White

                // Enhanced luminous halo (no box or border)
                if (isActive) {
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(
                                activeColor.copy(alpha = 0.45f),
                                activeColor.copy(alpha = 0.15f),
                                Color.Transparent
                            )
                        ),
                        radius = size.minDimension * 0.82f
                    )
                }

                when (glyph) {
                    ClipActionGlyph.HEART -> {
                        drawSculptedHeartGlyph(
                            isFilled = isActive,
                            tint = mainColor,
                            shadowColor = shadowColor
                        )
                    }

                    ClipActionGlyph.COMMENT -> {
                        // Instagram-style clean circular speech bubble with bottom-right tail
                        val w = size.width
                        val h = size.height
                        val bubblePath = Path().apply {
                            moveTo(w * 0.76f, h * 0.72f)
                            lineTo(w * 0.88f, h * 0.88f)
                            lineTo(w * 0.64f, h * 0.82f)
                            cubicTo(w * 0.36f, h * 0.90f, w * 0.12f, h * 0.72f, w * 0.12f, h * 0.48f)
                            cubicTo(w * 0.12f, h * 0.24f, w * 0.30f, h * 0.12f, w * 0.50f, h * 0.12f)
                            cubicTo(w * 0.72f, h * 0.12f, w * 0.88f, h * 0.26f, w * 0.88f, h * 0.48f)
                            cubicTo(w * 0.88f, h * 0.58f, w * 0.83f, h * 0.66f, w * 0.76f, h * 0.72f)
                            close()
                        }
                        translate(left = 0f, top = 1.5.dp.toPx()) {
                            drawPath(
                                path = bubblePath,
                                color = shadowColor,
                                style = Stroke(width = 2.6.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
                            )
                        }
                        drawPath(
                            path = bubblePath,
                            color = mainColor,
                            style = Stroke(width = 2.1.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
                        )
                    }

                    ClipActionGlyph.REPOST -> {
                        val w = size.width
                        val h = size.height
                        val loopPath = Path().apply {
                            // Upper arc + arrow
                            moveTo(w * 0.20f, h * 0.42f)
                            cubicTo(w * 0.20f, h * 0.22f, w * 0.40f, h * 0.18f, w * 0.76f, h * 0.24f)
                            moveTo(w * 0.64f, h * 0.13f)
                            lineTo(w * 0.80f, h * 0.25f)
                            lineTo(w * 0.65f, h * 0.37f)
                            // Lower arc + arrow
                            moveTo(w * 0.80f, h * 0.58f)
                            cubicTo(w * 0.80f, h * 0.78f, w * 0.60f, h * 0.82f, w * 0.24f, h * 0.76f)
                            moveTo(w * 0.36f, h * 0.63f)
                            lineTo(w * 0.20f, h * 0.75f)
                            lineTo(w * 0.35f, h * 0.87f)
                        }
                        translate(left = 0f, top = 1.5.dp.toPx()) {
                            drawPath(
                                path = loopPath,
                                color = shadowColor,
                                style = Stroke(width = 2.6.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
                            )
                        }
                        drawPath(
                            path = loopPath,
                            color = mainColor,
                            style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
                        )
                    }

                    ClipActionGlyph.BOOKMARK -> {
                        val w = size.width
                        val h = size.height
                        val bookmarkPath = Path().apply {
                            moveTo(w * 0.24f, h * 0.14f)
                            lineTo(w * 0.76f, h * 0.14f)
                            lineTo(w * 0.76f, h * 0.86f)
                            lineTo(w * 0.50f, h * 0.66f)
                            lineTo(w * 0.24f, h * 0.86f)
                            close()
                        }
                        translate(left = 0f, top = 1.5.dp.toPx()) {
                            drawPath(
                                path = bookmarkPath,
                                color = shadowColor,
                                style = Stroke(width = 2.6.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
                            )
                        }
                        if (isActive) {
                            drawPath(path = bookmarkPath, color = mainColor)
                        } else {
                            drawPath(
                                path = bookmarkPath,
                                color = mainColor,
                                style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
                            )
                        }
                    }

                    ClipActionGlyph.SHARE -> {
                        // Instagram Direct Paper Plane with inner diagonal crease line
                        val w = size.width
                        val h = size.height
                        val sharePath = Path().apply {
                            moveTo(w * 0.12f, h * 0.42f)
                            lineTo(w * 0.88f, h * 0.14f)
                            lineTo(w * 0.58f, h * 0.88f)
                            lineTo(w * 0.44f, h * 0.54f)
                            close()
                        }
                        translate(left = 0f, top = 1.5.dp.toPx()) {
                            drawPath(
                                path = sharePath,
                                color = shadowColor,
                                style = Stroke(width = 2.5.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
                            )
                            drawLine(
                                color = shadowColor,
                                start = Offset(w * 0.44f, h * 0.54f),
                                end = Offset(w * 0.88f, h * 0.14f),
                                strokeWidth = 2.2.dp.toPx(),
                                cap = StrokeCap.Round
                            )
                        }
                        drawPath(
                            path = sharePath,
                            color = mainColor,
                            style = Stroke(width = 2.0.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
                        )
                        drawLine(
                            color = mainColor,
                            start = Offset(w * 0.44f, h * 0.54f),
                            end = Offset(w * 0.88f, h * 0.14f),
                            strokeWidth = 1.8.dp.toPx(),
                            cap = StrokeCap.Round
                        )
                    }

                    ClipActionGlyph.VIEWS -> {
                        // Sculpted eye / views counter icon with drop shadow
                        val w = size.width
                        val h = size.height
                        val eyePath = Path().apply {
                            moveTo(w * 0.10f, h * 0.50f)
                            cubicTo(w * 0.28f, h * 0.22f, w * 0.72f, h * 0.22f, w * 0.90f, h * 0.50f)
                            cubicTo(w * 0.72f, h * 0.78f, w * 0.28f, h * 0.78f, w * 0.10f, h * 0.50f)
                            close()
                        }
                        translate(left = 0f, top = 1.5.dp.toPx()) {
                            drawPath(
                                path = eyePath,
                                color = shadowColor,
                                style = Stroke(width = 2.4.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
                            )
                            drawCircle(
                                color = shadowColor,
                                radius = w * 0.13f,
                                center = Offset(w * 0.50f, h * 0.50f)
                            )
                        }
                        drawPath(
                            path = eyePath,
                            color = mainColor,
                            style = Stroke(width = 2.0.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
                        )
                        drawCircle(
                            color = mainColor,
                            radius = w * 0.12f,
                            center = Offset(w * 0.50f, h * 0.50f)
                        )
                    }

                    ClipActionGlyph.MORE -> {
                        // Sleek sculpted three horizontal dots with drop shadow
                        val w = size.width
                        val h = size.height
                        val dotRadius = 2.4.dp.toPx()
                        val spacing = 6.8.dp.toPx()
                        translate(left = 0f, top = 1.5.dp.toPx()) {
                            for (i in -1..1) {
                                drawCircle(
                                    color = shadowColor,
                                    radius = dotRadius + 0.3.dp.toPx(),
                                    center = Offset(w * 0.5f + i * spacing, h * 0.5f)
                                )
                            }
                        }
                        for (i in -1..1) {
                            drawCircle(
                                color = mainColor,
                                radius = dotRadius,
                                center = Offset(w * 0.5f + i * spacing, h * 0.5f)
                            )
                        }
                    }
                }
            }
        }
        Text(
            text = label,
            style = NexoraTypography.BadgeMicro.copy(
                fontSize = 10.5.sp,
                color = Color.White,
                fontWeight = FontWeight.SemiBold,
                shadow = labelShadow
            )
        )
    }
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawSculptedHeartGlyph(
    isFilled: Boolean,
    tint: Color,
    shadowColor: Color
) {
    val w = size.width
    val h = size.height
    val heartPath = Path().apply {
        moveTo(w * 0.50f, h * 0.84f)
        cubicTo(w * 0.16f, h * 0.62f, w * 0.08f, h * 0.34f, w * 0.24f, h * 0.20f)
        cubicTo(w * 0.36f, h * 0.10f, w * 0.50f, h * 0.20f, w * 0.50f, h * 0.30f)
        cubicTo(w * 0.50f, h * 0.20f, w * 0.64f, h * 0.10f, w * 0.76f, h * 0.20f)
        cubicTo(w * 0.92f, h * 0.34f, w * 0.84f, h * 0.62f, w * 0.50f, h * 0.84f)
        close()
    }
    translate(left = 0f, top = 1.5.dp.toPx()) {
        drawPath(
            path = heartPath,
            color = shadowColor,
            style = Stroke(width = 2.6.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
        )
    }
    if (isFilled) {
        drawPath(path = heartPath, color = tint)
    } else {
        drawPath(
            path = heartPath,
            color = tint,
            style = Stroke(width = 2.1.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
        )
    }
}

@Composable
private fun SpatialAudioWaveformMini(
    phase: Float,
    isPlaying: Boolean
) {
    Canvas(modifier = Modifier.size(width = 22.dp, height = 13.dp)) {
        val barCount = 5
        val spacing = size.width / barCount
        for (i in 0 until barCount) {
            val wave = if (isPlaying) {
                0.30f + 0.70f * kotlin.math.abs(sin((phase * 18f) + i * 0.95f))
            } else {
                0.28f
            }
            val barHeight = (size.height * wave).coerceAtLeast(3.dp.toPx())
            val x = i * spacing + spacing * 0.5f
            // Subtle shadow line
            drawLine(
                color = Color(0x88090D16),
                start = Offset(x, (size.height - barHeight) * 0.5f + 1.dp.toPx()),
                end = Offset(x, (size.height + barHeight) * 0.5f + 1.dp.toPx()),
                strokeWidth = 2.2.dp.toPx(),
                cap = StrokeCap.Round
            )
            drawLine(
                color = if (i % 2 == 0) NexoraColors.Sky400 else Color.White,
                start = Offset(x, (size.height - barHeight) * 0.5f),
                end = Offset(x, (size.height + barHeight) * 0.5f),
                strokeWidth = 1.8.dp.toPx(),
                cap = StrokeCap.Round
            )
        }
    }
}

private fun formatShortCount(count: Int): String = when {
    count >= 1_000_000 -> String.format("%.1fM", count / 1_000_000f)
    count >= 1_000 -> String.format("%.1fK", count / 1_000f)
    else -> count.toString()
}

/**
 * Full-Stage Vertical Swipe Short-Video View (`SpatialClipsStageView`) for Navbar Slot 3:
 * Renders the VerticalPager short-video feed directly inside the primary stage with
 * floating Liquid Glass side actions, double-tap refractive heart burst, comment drawer,
 * creator follow capsule, and animated spatial audio waveform pill.
 */
@Composable
fun SpatialClipsStageView(
    clips: List<VideoItem>,
    savedVideoIds: Set<String>,
    subscribedCreatorIds: Set<String>,
    onToggleLike: (String) -> Unit,
    onDoubleTapLike: (String) -> Unit,
    onToggleRepost: (String) -> Unit,
    onToggleSave: (String) -> Unit,
    onToggleSubscribe: (String) -> Unit,
    onCreatorClick: (String) -> Unit,
    onAddComment: (String, String) -> Unit,
    onToggleCommentLike: (String, String) -> Unit,
    onShareClip: (VideoItem) -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier,
    isLoading: Boolean = false,
    errorMessage: String? = null,
    onRetry: () -> Unit = {},
    onCheckClipStatus: (String) -> Unit = {},
    isGlobalAudioMuted: Boolean = false,
    onToggleMute: () -> Unit = {}
) {
    BackHandler { onBack() }

    val context = LocalContext.current
    val nonLiveClips = remember(clips) {
        clips.filter { !it.isLiveStream && !it.isPhotoPost && it.isShortVideo && it.rawDurationSeconds <= 120.0 }
    }
    if (nonLiveClips.isEmpty()) {
        Box(
            modifier = modifier
                .fillMaxSize()
                .background(NexoraColors.CanvasBase)
                .testTag("spatial_clips_stage_view"),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.padding(24.dp)
            ) {
                Text(
                    text = if (isLoading) "Loading Shorts Feed..." else (errorMessage ?: "Syncing Shorts Feed..."),
                    style = NexoraTypography.CardTitle.copy(color = Color.White, fontSize = 15.sp)
                )
                if (!isLoading) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(999.dp))
                            .background(NexoraColors.ElectricIndigo)
                            .clickable { onRetry() }
                            .padding(horizontal = 18.dp, vertical = 9.dp)
                            .testTag("shorts_stage_retry_btn"),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "Retry Shorts API",
                            style = NexoraTypography.BadgeMicro.copy(
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                        )
                    }
                }
            }
            StableShortsTopHeader(
                isVisible = true,
                onDismiss = onBack,
                onCameraClick = {},
                isMuted = isGlobalAudioMuted,
                onToggleMute = onToggleMute
            )
        }
        return
    }

    val pagerState = rememberPagerState(
        initialPage = 0,
        pageCount = { nonLiveClips.size }
    )
    var isOverlaySheetOpen by remember { mutableStateOf(false) }
    var isTopHeaderVisible by remember { mutableStateOf(true) }

    // Instagram Reels Lookahead Pre-Buffering + Sovereign Interaction Status Check:
    // When Reel [i] is playing:
    // - Hydrate is_liked, is_saved, likes_count from GET /_/u/status/{file_code}
    // - Pre-cache first 2MB of Reel [i + 1] via ExoPlayer CacheDataSource
    // - Pre-load thumbnail for Reel [i + 2]
    LaunchedEffect(pagerState.currentPage, nonLiveClips.size) {
        val currentIdx = pagerState.currentPage
        nonLiveClips.getOrNull(currentIdx)?.let { activeClip ->
            onCheckClipStatus(activeClip.id)
        }
        nonLiveClips.getOrNull(currentIdx + 2)?.let { futureClip ->
            ReelsLookaheadCacheManager.preloadReelThumbnail(context, futureClip)
        }
        nonLiveClips.getOrNull(currentIdx + 1)?.let { nextClip ->
            ReelsLookaheadCacheManager.preCacheReelFirst2MB(context, nextClip)
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(NexoraColors.CanvasBase)
            .testTag("spatial_clips_stage_view")
    ) {
        VerticalPager(
            state = pagerState,
            userScrollEnabled = !isOverlaySheetOpen,
            modifier = Modifier
                .fillMaxSize()
                .testTag("spatial_clips_stage_vertical_pager"),
            beyondViewportPageCount = 1
        ) { pageIndex ->
            val clip = nonLiveClips[pageIndex]
            val isCurrentPage = pagerState.currentPage == pageIndex && pagerState.settledPage == pageIndex
            val isNextPage = pageIndex == pagerState.currentPage + 1

            SpatialClipVerticalPage(
                clip = clip,
                pageIndex = pageIndex,
                totalClips = nonLiveClips.size,
                isCurrentPage = isCurrentPage,
                isNextPage = isNextPage,
                isSaved = clip.id in savedVideoIds,
                isSubscribed = clip.creatorId in subscribedCreatorIds,
                onDismiss = onBack,
                onToggleLike = { onToggleLike(clip.id) },
                onDoubleTapLike = { onDoubleTapLike(clip.id) },
                onToggleRepost = { onToggleRepost(clip.id) },
                onToggleSave = { onToggleSave(clip.id) },
                onToggleSubscribe = { onToggleSubscribe(clip.creatorId) },
                onCreatorClick = { onCreatorClick(clip.creatorId) },
                onAddComment = { text -> onAddComment(clip.id, text) },
                onToggleCommentLike = { commentId -> onToggleCommentLike(clip.id, commentId) },
                onShareClip = { onShareClip(clip) },
                onSheetOpenChange = { open ->
                    if (isCurrentPage) {
                        isOverlaySheetOpen = open
                    }
                },
                onControlsVisibleChange = { visible ->
                    if (isCurrentPage) {
                        isTopHeaderVisible = visible
                    }
                },
                isGlobalAudioMuted = isGlobalAudioMuted,
                onToggleMute = onToggleMute,
                allClips = clips
            )
        }

        // Stable Top Header Bar (Stays fixed at top over VerticalPager during scrolling)
        StableShortsTopHeader(
            isVisible = isTopHeaderVisible,
            onDismiss = onBack,
            onCameraClick = {
                val currentClip = nonLiveClips.getOrNull(pagerState.currentPage)
                if (currentClip != null) onShareClip(currentClip)
            },
            isMuted = isGlobalAudioMuted,
            onToggleMute = onToggleMute
        )
    }
}

data class DraggableCardData(
    val id: String,
    val title: String,
    val category: String,
    val preset: VisualThemePreset,
    val tag: String? = null
)

@Composable
fun InteractiveDraggableCardDeck(
    clip: VideoItem,
    onCardClick: (DraggableCardData) -> Unit,
    modifier: Modifier = Modifier
) {
    // Generate multi-card deck per clip
    val cards = remember(clip.id) {
        listOf(
            DraggableCardData(
                id = "${clip.id}_card_1",
                title = "${clip.category} Gear",
                category = "Pick",
                preset = clip.visualPreset,
                tag = "4K"
            ),
            DraggableCardData(
                id = "${clip.id}_card_2",
                title = "Stem Audio",
                category = "Track",
                preset = VisualThemePreset.FJORD_AURORA,
                tag = "Mix"
            ),
            DraggableCardData(
                id = "${clip.id}_card_3",
                title = "Camera Preset",
                category = "LUT",
                preset = VisualThemePreset.CYBER_LIGHTFIELD,
                tag = "Pro"
            )
        )
    }

    var topCardIndex by remember(clip.id) { mutableIntStateOf(0) }
    val coroutineScope = rememberCoroutineScope()

    val dragOffsetX = remember { Animatable(0f) }
    val dragOffsetY = remember { Animatable(0f) }
    var isDragging by remember { mutableStateOf(false) }

    Box(
        modifier = modifier
            .size(58.dp)
            .testTag("interactive_draggable_card_deck_${clip.id}"),
        contentAlignment = Alignment.Center
    ) {
        // Render non-top cards first (tilted square deck underneath so user sees there are more)
        cards.indices.reversed().forEach { index ->
            if (index != topCardIndex) {
                val relativeIndex = (index - topCardIndex + cards.size) % cards.size
                if (relativeIndex in 1..2) {
                    val tiltAngle = if (relativeIndex == 1) -5.5f else 4.5f
                    val offsetXDp = if (relativeIndex == 1) (-3).dp else 2.5.dp
                    val offsetYDp = if (relativeIndex == 1) 2.dp else 4.dp
                    val scaleFactor = if (relativeIndex == 1) 0.92f else 0.85f
                    val alphaVal = if (relativeIndex == 1) 0.88f else 0.65f

                    SingleDraggableCardView(
                        card = cards[index],
                        isTopCard = false,
                        modifier = Modifier
                            .graphicsLayer {
                                rotationZ = tiltAngle
                                scaleX = scaleFactor
                                scaleY = scaleFactor
                                translationX = offsetXDp.toPx()
                                translationY = offsetYDp.toPx()
                                alpha = alphaVal
                            }
                    )
                }
            }
        }

        // Render Active Top Card (Draggable square card with physics spring return/dismiss)
        val topCard = cards[topCardIndex]
        val dragRotation = dragOffsetX.value * 0.12f
        val dragScale = if (isDragging) 1.06f else 1.0f

        SingleDraggableCardView(
            card = topCard,
            isTopCard = true,
            modifier = Modifier
                .graphicsLayer {
                    translationX = dragOffsetX.value
                    translationY = dragOffsetY.value
                    rotationZ = dragRotation
                    scaleX = dragScale
                    scaleY = dragScale
                }
                .pointerInput(clip.id, topCardIndex) {
                    detectDragGestures(
                        onDragStart = {
                            isDragging = true
                        },
                        onDragEnd = {
                            isDragging = false
                            val totalDrag = kotlin.math.hypot(dragOffsetX.value, dragOffsetY.value)
                            val threshold = 40.dp.toPx()

                            if (totalDrag > threshold) {
                                coroutineScope.launch {
                                    val targetX = if (dragOffsetX.value >= 0) 200.dp.toPx() else -200.dp.toPx()
                                    dragOffsetX.animateTo(
                                        targetValue = targetX,
                                        animationSpec = spring(
                                            dampingRatio = Spring.DampingRatioLowBouncy,
                                            stiffness = Spring.StiffnessMedium
                                        )
                                    )
                                    topCardIndex = (topCardIndex + 1) % cards.size
                                    dragOffsetX.snapTo(0f)
                                    dragOffsetY.snapTo(0f)
                                }
                            } else {
                                coroutineScope.launch {
                                    launch {
                                        dragOffsetX.animateTo(
                                            0f,
                                            spring(
                                                dampingRatio = Spring.DampingRatioMediumBouncy,
                                                stiffness = Spring.StiffnessLow
                                            )
                                        )
                                    }
                                    launch {
                                        dragOffsetY.animateTo(
                                            0f,
                                            spring(
                                                dampingRatio = Spring.DampingRatioMediumBouncy,
                                                stiffness = Spring.StiffnessLow
                                            )
                                        )
                                    }
                                }
                            }
                        },
                        onDragCancel = {
                            isDragging = false
                            coroutineScope.launch {
                                dragOffsetX.snapTo(0f)
                                dragOffsetY.snapTo(0f)
                            }
                        },
                        onDrag = { change, dragAmount ->
                            change.consume()
                            coroutineScope.launch {
                                dragOffsetX.snapTo(dragOffsetX.value + dragAmount.x)
                                dragOffsetY.snapTo(dragOffsetY.value + dragAmount.y)
                            }
                        }
                    )
                }
                .clickable {
                    onCardClick(topCard)
                }
        )
    }
}

@Composable
private fun SingleDraggableCardView(
    card: DraggableCardData,
    isTopCard: Boolean,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .size(58.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(Color.Black.copy(alpha = 0.55f))
            .border(
                width = 1.dp,
                brush = Brush.verticalGradient(
                    listOf(
                        Color.White.copy(alpha = 0.35f),
                        Color.White.copy(alpha = 0.08f)
                    )
                ),
                shape = RoundedCornerShape(12.dp)
            )
            .testTag("draggable_card_${card.id}")
    ) {
        // Compact Square Short-Video Canvas
        SpatialVisualCanvas(
            preset = card.preset,
            modifier = Modifier.fillMaxSize(),
            isAnimated = isTopCard,
            playbackPhase = 0.5f
        )

        // Gradient Scrim Overlay for Legibility
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            Color.Black.copy(alpha = 0.35f),
                            Color.Transparent,
                            Color.Black.copy(alpha = 0.85f)
                        )
                    )
                )
        )

        // Category Pill Overlay (Top Start)
        Row(
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(4.dp)
                .background(
                    color = Color.Black.copy(alpha = 0.65f),
                    shape = CircleShape
                )
                .padding(horizontal = 4.dp, vertical = 2.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            Icon(
                imageVector = Icons.Filled.AutoAwesome,
                contentDescription = null,
                tint = NexoraColors.Sky400,
                modifier = Modifier.size(8.dp)
            )
            Text(
                text = card.category,
                style = NexoraTypography.BadgeMicro.copy(
                    fontSize = 7.5.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                ),
                maxLines = 1
            )
        }

        // Title & Grip Icon Row (Bottom Overlay)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.BottomStart)
                .padding(horizontal = 4.dp, vertical = 3.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = card.title,
                style = NexoraTypography.NavPillLabel.copy(
                    fontSize = 7.5.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                ),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f)
            )

            GripVerticalIcon(
                modifier = Modifier.size(width = 6.dp, height = 9.dp),
                tint = Color.White.copy(alpha = 0.85f)
            )
        }
    }
}

@Composable
fun GripVerticalIcon(
    modifier: Modifier = Modifier,
    tint: Color = Color.White.copy(alpha = 0.6f)
) {
    Canvas(modifier = modifier) {
        val radius = 1.2.dp.toPx()
        val spacingY = 4.dp.toPx()
        val spacingX = 3.2.dp.toPx()
        val startX = (size.width - spacingX) / 2f
        val startY = (size.height - spacingY * 2) / 2f

        for (col in 0..1) {
            for (row in 0..2) {
                drawCircle(
                    color = tint,
                    radius = radius,
                    center = Offset(
                        x = startX + col * spacingX,
                        y = startY + row * spacingY
                    )
                )
            }
        }
    }
}

@Composable
private fun StableShortsTopHeader(
    isVisible: Boolean,
    onDismiss: () -> Unit,
    onCameraClick: () -> Unit,
    isMuted: Boolean = false,
    onToggleMute: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val hudTextShadow = remember {
        Shadow(
            color = Color(0xB3090D16),
            offset = Offset(0f, 2f),
            blurRadius = 8f
        )
    }

    AnimatedVisibility(
        visible = isVisible,
        enter = fadeIn(animationSpec = tween(220)) + slideInVertically(
            animationSpec = spring(
                dampingRatio = Spring.DampingRatioLowBouncy,
                stiffness = Spring.StiffnessMediumLow
            )
        ) { -it },
        exit = fadeOut(animationSpec = tween(180)) + slideOutVertically(
            animationSpec = tween(180)
        ) { -it },
        modifier = modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .windowInsetsPadding(WindowInsets.statusBars)
                .padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clickable { onDismiss() }
                        .testTag("spatial_clips_back_btn"),
                    contentAlignment = Alignment.CenterStart
                ) {
                    SculptedBackChevronIcon(modifier = Modifier.size(24.dp))
                }
                Text(
                    text = "Reels",
                    style = NexoraTypography.SectionTitle.copy(
                        fontSize = 21.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        shadow = hudTextShadow
                    )
                )
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                val forceHighestQuality = AkashQualityController.forceHighestQuality

                // Single Top-Right Toggle Switch: [HQ] / Highest Quality [ON/OFF]
                Row(
                    modifier = Modifier
                        .height(34.dp)
                        .clip(RoundedCornerShape(999.dp))
                        .background(
                            if (forceHighestQuality) Color.White else Color(0x66000000)
                        )
                        .border(
                            width = 1.dp,
                            color = if (forceHighestQuality) Color.White else Color.White.copy(alpha = 0.32f),
                            shape = RoundedCornerShape(999.dp)
                        )
                        .clickable {
                            AkashQualityController.toggleHighestQuality()
                        }
                        .padding(horizontal = 11.dp)
                        .testTag("shorts_hq_toggle_btn"),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(5.dp)
                ) {
                    Text(
                        text = "HQ",
                        style = NexoraTypography.BadgeMicro.copy(
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = if (forceHighestQuality) NexoraColors.CanvasBase else Color.White
                        )
                    )
                    Text(
                        text = if (forceHighestQuality) "ON" else "OFF",
                        style = NexoraTypography.BadgeMicro.copy(
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (forceHighestQuality) {
                                NexoraColors.CanvasBase.copy(alpha = 0.85f)
                            } else {
                                Color.White.copy(alpha = 0.72f)
                            }
                        )
                    )
                }

                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(Color(0x55000000))
                        .clickable { onToggleMute() }
                        .testTag("reels_mute_toggle_btn"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (isMuted) Icons.AutoMirrored.Filled.VolumeOff else Icons.AutoMirrored.Filled.VolumeUp,
                        contentDescription = if (isMuted) "Unmute Audio" else "Mute Audio",
                        tint = Color.White,
                        modifier = Modifier.size(20.dp)
                    )
                }

                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clickable { onCameraClick() }
                        .testTag("instagram_reels_camera_btn"),
                    contentAlignment = Alignment.Center
                ) {
                    SculptedCameraIcon(modifier = Modifier.size(24.dp))
                }
            }
        }
    }
}


