package com.example.nexora.network

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import kotlinx.coroutines.tasks.await

import okio.BufferedSink
import okio.ForwardingSink
import okio.buffer

data class AkashPlaybackInfo(
    val thumbnailUrl: String
)

data class AkashCatalogItem(
    val fileCode: String,
    val mediaType: String, // "short", "long_video", or "photo"
    val title: String,
    val author: String,
    val creatorHandle: String,
    val displayName: String,
    val duration: Double,
    val streamUrl: String,
    val directStreamUrl: String,
    val adaptiveStreamUrl: String = streamUrl,
    val highestQualityStreamUrl: String = directStreamUrl,
    val thumbnailUrl: String,
    val views: Long,
    val simulatedViews: Long = views,
    val formattedViews: String = "",
    val uploadedAt: String = "",
    val relativeTime: String = "Just now",
    val qualityMode: String = "single_toggle",
    val hasHighestQualityToggle: Boolean = true,
    val playback: AkashPlaybackInfo,
    val authorAvatarUrl: String? = null,
    val availableQualities: List<String> = emptyList(),
    val qualityStreams: Map<String, String> = emptyMap()
) {
    val fullThumbnailUrl: String
        get() = thumbnailUrl.ifBlank { AkashMediaService.thumbnailUrl(fileCode) }

    val directTokenStreamUrl: String
        get() = highestQualityStreamUrl.ifBlank {
            directStreamUrl.ifBlank {
                streamUrl.ifBlank { AkashMediaService.continuousStreamUrl(fileCode) }
            }
        }
}

data class AkashLikeStatusResponse(
    val status: String,
    val fileCode: String,
    val isLiked: Boolean,
    val likesCount: Int,
    val liked: Boolean = isLiked,
    val totalLikes: Int = likesCount
)

data class AkashSaveStatusResponse(
    val status: String,
    val fileCode: String,
    val isSaved: Boolean
)

data class AkashVideoStatusResponse(
    val fileCode: String,
    val isLiked: Boolean,
    val isSaved: Boolean,
    val likesCount: Int,
    val totalLikes: Int = likesCount,
    val totalComments: Int = 0
)

data class AkashSavedReelsResult(
    val items: List<AkashCatalogItem>,
    val fileCodes: Set<String>
)

data class AkashSyncProfileResult(
    val status: String,
    val handle: String?,
    val displayName: String?,
    val avatarUrl: String?
)

data class AkashHandleCheckResult(
    val status: String,
    val handle: String,
    val available: Boolean,
    val message: String? = null
)

data class AkashProfileUpdateResult(
    val success: Boolean,
    val isConflict: Boolean = false,
    val handle: String? = null,
    val message: String? = null
)

data class AkashCommentItem(
    val id: String,
    val fileCode: String,
    val authorName: String,
    val authorHandle: String,
    val avatarUrl: String?,
    val commentText: String,
    val createdAt: String,
    val likes: Int,
    val isLiked: Boolean = false
)

data class AkashCreatorProfileResponse(
    val status: String,
    val displayName: String,
    val handle: String,
    val avatarUrl: String?,
    val totalViews: Long,
    val totalLikes: Long,
    val shorts: List<AkashCatalogItem>
)

data class AkashPreUploadCheckResult(
    val success: Boolean,
    val mediaType: String,
    val message: String? = null
)

data class AkashUploadResult(
    val success: Boolean,
    val fileCode: String? = null,
    val message: String? = null
)

data class AkashStep1VideoUploadResult(
    val status: String,
    val videoToken: String,
    val duration: Double,
    val width: Int,
    val height: Int
)

data class AkashStep2ThumbnailUploadResult(
    val status: String,
    val thumbnailToken: String,
    val width: Int,
    val height: Int
)

data class AkashStep3CreateMediaResult(
    val status: String,
    val fileCode: String,
    val directStreamUrl: String,
    val adaptiveStreamUrl: String = directStreamUrl,
    val highestQualityStreamUrl: String = directStreamUrl,
    val thumbnailUrl: String,
    val qualityStreams: Map<String, String> = emptyMap(),
    val availableQualities: List<String> = emptyList()
)

private class ProgressRequestBody(
    private val delegate: okhttp3.RequestBody,
    private val onProgress: (Float) -> Unit
) : okhttp3.RequestBody() {
    override fun contentType(): okhttp3.MediaType? = delegate.contentType()
    override fun contentLength(): Long = delegate.contentLength()

    override fun writeTo(sink: BufferedSink) {
        val totalBytes = contentLength().coerceAtLeast(1L)
        var bytesWritten = 0L
        val countingSink = object : ForwardingSink(sink) {
            override fun write(source: okio.Buffer, byteCount: Long) {
                super.write(source, byteCount)
                bytesWritten += byteCount
                val fraction = (bytesWritten.toFloat() / totalBytes.toFloat()).coerceIn(0f, 1f)
                onProgress(fraction)
            }
        }
        val bufferedSink = countingSink.buffer()
        delegate.writeTo(bufferedSink)
        bufferedSink.flush()
    }
}

/**
 * Sovereign Media & User Vault Service Layer for Akash Shorts (`https://akashbox.duckdns.org`).
 *
 * Dedicated App A Security Token: `akash_sec_shorts_app_a_9e4b11f8c32d4a7b91e0a29487c56d10e82f1a3c7489b012`
 * Headers required on all requests:
 *   - `X-App-Token: akash_sec_shorts_app_a_9e4b11f8c32d4a7b91e0a29487c56d10e82f1a3c7489b012`
 *   - `Authorization: Bearer <FIREBASE_ID_TOKEN>` (for authenticated user actions)
 *
 * Zero-Emoji Policy:
 * All usernames, display names, titles, captions, and comments are sanitized free of emojis.
 */
object AkashMediaService {
    const val BASE_URL = "https://akashbox.duckdns.org"
    const val SHORTS_FEED_ENDPOINT = "$BASE_URL/_/s7a1"
    const val SHORTS_FALLBACK_ENDPOINT = "$BASE_URL/_/s/feed?limit=20"
    const val SHORTS_ENDPOINT = SHORTS_FEED_ENDPOINT
    const val UPLOAD_VIDEO_STEP1_ENDPOINT = "$BASE_URL/_/upload/video"
    const val UPLOAD_THUMBNAIL_STEP2_ENDPOINT = "$BASE_URL/_/upload/thumbnail"
    const val CREATE_MEDIA_STEP3_ENDPOINT = "$BASE_URL/_/media/create"
    const val USER_SYNC_ENDPOINT = "$BASE_URL/_/u/sync"
    const val CHECK_HANDLE_ENDPOINT = "$BASE_URL/_/u/check-handle"
    const val USER_PROFILE_ENDPOINT = "$BASE_URL/_/u/profile"
    const val USER_LIKE_ENDPOINT = "$BASE_URL/_/u/like"
    const val USER_SAVED_ENDPOINT = "$BASE_URL/_/u/saved"
    const val USER_STATUS_ENDPOINT = "$BASE_URL/_/u/status"
    const val COMMENTS_ENDPOINT = "$BASE_URL/_/u/comments"
    const val COMMENT_POST_ENDPOINT = "$BASE_URL/_/u/comment"
    const val CREATOR_PROFILE_ENDPOINT = "$BASE_URL/_/u/creator"
    const val PRE_UPLOAD_VERIFY_ENDPOINT = "$BASE_URL/_/v8f3"
    const val EXECUTE_UPLOAD_ENDPOINT = "$BASE_URL/_/9a4f2b"

    const val APP_TOKEN = "akash_sec_shorts_app_a_9e4b11f8c32d4a7b91e0a29487c56d10e82f1a3c7489b012"
    const val HEADER_APP_TOKEN = "x-app-token"
    const val HEADER_APP_TOKEN_UPPER = "X-App-Token"

    private val JSON_MEDIA_TYPE = "application/json; charset=utf-8".toMediaType()

    /**
     * Zero Emoji Enforcement Regex:
     * Matches standard and extended emoji planes, pictographs, transport/map symbols,
     * dingbats, and variation selectors.
     */
    private val zeroEmojiRegex = Regex(
        "[\\x{1F600}-\\x{1F64F}\\x{1F300}-\\x{1F5FF}\\x{1F680}-\\x{1F6FF}\\x{2600}-\\x{26FF}\\x{2700}-\\x{27BF}\\x{1F900}-\\x{1F9FF}\\x{1FA70}-\\x{1FAFF}\\x{FE00}-\\x{FE0F}\\p{So}\\p{Cn}]"
    )

    private val httpClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(10, TimeUnit.SECONDS)
            .readTimeout(14, TimeUnit.SECONDS)
            .writeTimeout(25, TimeUnit.SECONDS)
            .connectionPool(okhttp3.ConnectionPool(8, 5, TimeUnit.MINUTES))
            .followRedirects(true)
            .followSslRedirects(true)
            .build()
    }

    @Volatile
    private var cachedShortsItems: List<AkashCatalogItem> = emptyList()

    @Volatile
    private var lastShortsCacheTimeMs: Long = 0L

    fun getCachedShortsSnapshot(): List<AkashCatalogItem> = cachedShortsItems

    /**
     * Strips all emojis and non-printable symbols while preserving clean text.
     */
    fun cleanEmojis(raw: String): String {
        if (raw.isEmpty()) return ""
        return raw.replace(zeroEmojiRegex, "").replace(Regex("\\s+"), " ").trim()
    }

    /**
     * Handle format requirements: Alphanumeric and underscores only (^[a-z0-9_]{3,24}$). Zero emojis.
     */
    fun validateHandleFormat(rawHandle: String): Boolean {
        val clean = cleanEmojis(rawHandle).removePrefix("@").lowercase().trim()
        return Regex("^[a-z0-9_]{3,24}$").matches(clean)
    }

    /**
     * Returns the direct JPEG frame thumbnail URL for a given `file_code`.
     */
    fun thumbnailUrl(fileCode: String): String {
        val cleanCode = fileCode.trim()
        return "$BASE_URL/_/t9b2c4/$cleanCode"
    }

    /**
     * Returns the continuous pristine raw source streaming URL (`/_/8b0d4f/{file_code}`) with token.
     */
    fun continuousStreamUrl(fileCode: String): String {
        val cleanCode = fileCode.trim()
        return "$BASE_URL/_/8b0d4f/$cleanCode?token=$APP_TOKEN"
    }

    /**
     * Returns the HLS adaptive bitrate master playlist URL (`/_/h8a2/{file_code}/master.m3u8`) with token.
     */
    fun adaptiveHlsStreamUrl(fileCode: String): String {
        val cleanCode = fileCode.trim()
        return "$BASE_URL/_/h8a2/$cleanCode/master.m3u8?token=$APP_TOKEN"
    }

    /**
     * Returns the highest quality pristine raw source URL (`/_/8b0d4f/{file_code}`) with token.
     */
    fun highestQualityStreamUrl(fileCode: String): String {
        return continuousStreamUrl(fileCode)
    }

    /**
     * Seeds realistic simulated baseline views between 2,500 and 37,500+ using the Part 1 SQL formula:
     * `2500 + ((id * 3749) % 35000) + (views_count * 15)`
     */
    fun computeSimulatedViews(fileCode: String, rawViewsCount: Long = 0L, recordIdSeed: Int = 1): Long {
        val positiveHash = (fileCode.hashCode().toLong() and 0x7FFFFFFFL)
        val idVal = if (positiveHash > 0L) positiveHash else recordIdSeed.toLong().coerceAtLeast(1L)
        val safeViewsCount = rawViewsCount.coerceAtLeast(0L)
        return 2500L + ((idVal * 3749L) % 35000L) + (safeViewsCount * 15L)
    }

    /**
     * Formats view counts into human-readable strings (e.g. "18.4K views", "1.2M views").
     * Never outputs "0 views".
     */
    fun formatViewsCount(views: Long, fallbackSeedCode: String = "sh_default"): String {
        val effective = if (views > 0L) views else computeSimulatedViews(fallbackSeedCode, 0L, 1)
        return when {
            effective >= 1_000_000L -> String.format(java.util.Locale.US, "%.1fM views", effective / 1_000_000.0)
            effective >= 1_000L -> String.format(java.util.Locale.US, "%.1fK views", effective / 1_000.0)
            else -> "$effective views"
        }
    }

    /**
     * Dynamically computes relative time from an ISO-8601 or SQLite timestamp:
     * <60s -> "Just now", <1h -> "Xm ago", <24h -> "Xh ago", <7d -> "Xd ago", <30d -> "Xw ago", else "Xmo ago".
     */
    fun computeRelativeTime(uploadedAtRaw: String?, fallbackIndex: Int = 0): String {
        val trimmed = uploadedAtRaw?.trim().orEmpty()
        if (trimmed.isNotEmpty()) {
            // If already formatted as relative time from API (e.g. "2h ago", "1d ago", "Just now")
            if (trimmed.equals("Just now", ignoreCase = true) || trimmed.endsWith("ago", ignoreCase = true)) {
                return trimmed
            }
            val parsedEpochMs = parseTimestampToEpochMs(trimmed)
            if (parsedEpochMs != null && parsedEpochMs > 0L) {
                val nowMs = System.currentTimeMillis()
                val diffSeconds = ((nowMs - parsedEpochMs) / 1000L).coerceAtLeast(0L)
                return formatElapsedSecondsToRelativeTime(diffSeconds)
            }
        }
        // Deterministic fallback offset so every item has a realistic relative upload timestamp
        val fallbackOffsetsSec = longArrayOf(
            2L * 3600L,        // 2h ago
            5L * 3600L,        // 5h ago
            14L * 3600L,       // 14h ago
            1L * 86_400L,      // 1d ago
            2L * 86_400L,      // 2d ago
            3L * 86_400L,      // 3d ago
            5L * 86_400L,      // 5d ago
            9L * 86_400L,      // 1w ago
            16L * 86_400L      // 2w ago
        )
        val chosenSec = fallbackOffsetsSec[(fallbackIndex.coerceAtLeast(0)) % fallbackOffsetsSec.size]
        return formatElapsedSecondsToRelativeTime(chosenSec)
    }

    fun formatElapsedSecondsToRelativeTime(diffSeconds: Long): String {
        val sec = diffSeconds.coerceAtLeast(0L)
        return when {
            sec < 60L -> "Just now"
            sec < 3600L -> "${(sec / 60L).coerceAtLeast(1L)}m ago"
            sec < 86_400L -> "${(sec / 3600L).coerceAtLeast(1L)}h ago"
            sec < 7L * 86_400L -> "${(sec / 86_400L).coerceAtLeast(1L)}d ago"
            sec < 30L * 86_400L -> "${(sec / (7L * 86_400L)).coerceAtLeast(1L)}w ago"
            else -> "${(sec / (30L * 86_400L)).coerceAtLeast(1L)}mo ago"
        }
    }

    fun defaultIsoTimestampForIndex(index: Int): String {
        val fallbackOffsetsSec = longArrayOf(
            2L * 3600L,
            5L * 3600L,
            14L * 3600L,
            1L * 86_400L,
            2L * 86_400L,
            3L * 86_400L,
            5L * 86_400L,
            9L * 86_400L,
            16L * 86_400L
        )
        val offsetMs = fallbackOffsetsSec[(index.coerceAtLeast(0)) % fallbackOffsetsSec.size] * 1000L
        val fmt = java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", java.util.Locale.US).apply {
            timeZone = java.util.TimeZone.getTimeZone("UTC")
        }
        return fmt.format(java.util.Date(System.currentTimeMillis() - offsetMs))
    }

    private fun parseTimestampToEpochMs(raw: String): Long? {
        raw.toLongOrNull()?.let { numeric ->
            return if (numeric < 10_000_000_000L) numeric * 1000L else numeric
        }
        val patterns = listOf(
            "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'",
            "yyyy-MM-dd'T'HH:mm:ss'Z'",
            "yyyy-MM-dd'T'HH:mm:ssX",
            "yyyy-MM-dd HH:mm:ss"
        )
        for (pattern in patterns) {
            val parsed = runCatching {
                val sdf = java.text.SimpleDateFormat(pattern, java.util.Locale.US).apply {
                    timeZone = java.util.TimeZone.getTimeZone("UTC")
                }
                sdf.parse(raw)?.time
            }.getOrNull()
            if (parsed != null) return parsed
        }
        return null
    }

    /**
     * Normalizes a potentially relative URL from the Akash Media API into a full HTTPS URL.
     */
    fun normalizeUrl(rawUrl: String): String {
        val trimmed = rawUrl.trim()
        return when {
            trimmed.startsWith("http://") || trimmed.startsWith("https://") -> trimmed
            trimmed.startsWith("/") -> "$BASE_URL$trimmed"
            else -> "$BASE_URL/$trimmed"
        }
    }

    /**
     * Ensures the stream URL is normalized and includes the `?token=...` authentication fallback parameter.
     */
    fun ensureStreamToken(rawUrl: String): String {
        val normalized = normalizeUrl(rawUrl)
        if (normalized.contains("token=")) {
            return normalized
        }
        val separator = if (normalized.contains("?")) "&" else "?"
        return "${normalized}${separator}token=$APP_TOKEN"
    }

    private fun Request.Builder.applySovereignHeaders(firebaseIdToken: String? = null): Request.Builder {
        addHeader(HEADER_APP_TOKEN, APP_TOKEN)
        addHeader(HEADER_APP_TOKEN_UPPER, APP_TOKEN)
        addHeader("Accept", "application/json")
        if (!firebaseIdToken.isNullOrBlank()) {
            addHeader("Authorization", "Bearer ${firebaseIdToken.trim()}")
        }
        return this
    }

    /**
     * Calls Shorts Feed: `GET /_/s/feed?limit=20` with fallback to `GET /_/s7a1`.
     * Uses an in-memory fast cache for repeated calls within 15 seconds and updates cache on success.
     */
    suspend fun fetchShortsFeed(
        firebaseIdToken: String? = null,
        forceRefresh: Boolean = false
    ): Result<List<AkashCatalogItem>> = withContext(Dispatchers.IO) {
        val now = System.currentTimeMillis()
        if (!forceRefresh && cachedShortsItems.isNotEmpty() && (now - lastShortsCacheTimeMs) < 15_000L) {
            return@withContext Result.success(cachedShortsItems)
        }

        runCatching {
            // 1. Try primary endpoint GET /_/s/feed?limit=20
            val primaryRequest = Request.Builder()
                .url(SHORTS_FEED_ENDPOINT)
                .get()
                .applySovereignHeaders(firebaseIdToken)
                .build()

            val primaryItems = runCatching {
                httpClient.newCall(primaryRequest).execute().use { response ->
                    if (response.isSuccessful) {
                        val body = response.body?.string().orEmpty()
                        parseCatalogItems(body)
                            .filter { it.mediaType == "short" && (it.duration <= 0.0 || it.duration <= 120.0) }
                    } else null
                }
            }.getOrNull()

            if (!primaryItems.isNullOrEmpty()) {
                cachedShortsItems = primaryItems
                lastShortsCacheTimeMs = System.currentTimeMillis()
                return@runCatching primaryItems
            }

            // 2. Fallback to GET /_/s7a1
            val fallbackRequest = Request.Builder()
                .url(SHORTS_FALLBACK_ENDPOINT)
                .get()
                .applySovereignHeaders(firebaseIdToken)
                .build()

            httpClient.newCall(fallbackRequest).execute().use { response ->
                if (!response.isSuccessful) {
                    if (cachedShortsItems.isNotEmpty()) {
                        return@runCatching cachedShortsItems
                    }
                    throw IOException("Shorts API failed with HTTP ${response.code}")
                }
                val body = response.body?.string() ?: throw IOException("Empty body")
                val parsed = parseCatalogItems(body)
                    .filter { it.mediaType == "short" && (it.duration <= 0.0 || it.duration <= 120.0) }
                if (parsed.isNotEmpty()) {
                    cachedShortsItems = parsed
                    lastShortsCacheTimeMs = System.currentTimeMillis()
                }
                parsed
            }
        }
    }

    /**
     * Calls catalog and filters strictly by `media_type === "short"`.
     */
    suspend fun fetchCatalog(
        type: String = "short",
        limit: Int = 50,
        firebaseIdToken: String? = null
    ): Result<List<AkashCatalogItem>> = fetchShortsFeed(firebaseIdToken).map { items ->
        items.take(limit)
    }

    /**
     * Step 1: Firebase Login & Account Synchronization
     * `POST /_/u/sync`
     * Headers: `X-App-Token`, `Authorization: Bearer <FIREBASE_ID_TOKEN>`
     * Body: `{ "display_name": "Alex Vance", "email": "alex@example.com", "avatar_url": "https://..." }`
     * Returns the user's permanent, unique @handle.
     */
    suspend fun syncUserProfile(
        firebaseIdToken: String,
        displayName: String,
        email: String,
        avatarUrl: String?
    ): Result<AkashSyncProfileResult> = withContext(Dispatchers.IO) {
        runCatching {
            val cleanName = cleanEmojis(displayName).ifBlank { "Akash Creator" }
            val cleanEmail = cleanEmojis(email).trim().lowercase()
            val payload = JSONObject().apply {
                put("display_name", cleanName)
                put("email", cleanEmail)
                put("avatar_url", avatarUrl ?: JSONObject.NULL)
            }
            val request = Request.Builder()
                .url(USER_SYNC_ENDPOINT)
                .post(payload.toString().toRequestBody(JSON_MEDIA_TYPE))
                .applySovereignHeaders(firebaseIdToken)
                .build()

            httpClient.newCall(request).execute().use { response ->
                val bodyStr = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    throw IOException("User sync failed with HTTP ${response.code}: $bodyStr")
                }
                val json = if (bodyStr.isNotBlank()) JSONObject(bodyStr) else JSONObject()
                val userObj = json.optJSONObject("user")
                val rawHandle = json.optString("handle", "")
                    .ifEmpty { userObj?.optString("handle", "") }
                    .orEmpty()
                val assignedHandle = if (rawHandle.isNotBlank()) {
                    val cleaned = cleanEmojis(rawHandle).removePrefix("@")
                    "@$cleaned"
                } else null

                val returnedName = json.optString("display_name", cleanName)
                    .ifEmpty { userObj?.optString("display_name", cleanName) }
                val returnedAvatar = json.optString("avatar_url", avatarUrl.orEmpty())
                    .ifEmpty { userObj?.optString("avatar_url", avatarUrl.orEmpty()) }

                AkashSyncProfileResult(
                    status = json.optString("status", "success"),
                    handle = assignedHandle,
                    displayName = returnedName,
                    avatarUrl = returnedAvatar
                )
            }
        }
    }

    /**
     * Step 2: Check Username Availability
     * `GET /_/u/check-handle/{handle}`
     * Headers: `X-App-Token`
     * Response: `{"status": "success", "handle": "@alex", "available": true}`
     */
    suspend fun checkHandleAvailability(handle: String): Result<AkashHandleCheckResult> = withContext(Dispatchers.IO) {
        runCatching {
            val cleanHandle = cleanEmojis(handle).removePrefix("@").lowercase().trim()
            if (!validateHandleFormat(cleanHandle)) {
                return@runCatching AkashHandleCheckResult(
                    status = "error",
                    handle = "@$cleanHandle",
                    available = false,
                    message = "Handle must be 3-24 characters (lowercase letters, numbers, underscores only)"
                )
            }

            val request = Request.Builder()
                .url("$CHECK_HANDLE_ENDPOINT/$cleanHandle")
                .get()
                .applySovereignHeaders(null)
                .build()

            httpClient.newCall(request).execute().use { response ->
                val bodyStr = response.body?.string().orEmpty()
                val json = if (bodyStr.isNotBlank()) JSONObject(bodyStr) else JSONObject()
                val isAvail = json.optBoolean("available", response.isSuccessful)
                val returnedHandle = json.optString("handle", "@$cleanHandle")
                AkashHandleCheckResult(
                    status = json.optString("status", if (response.isSuccessful) "success" else "error"),
                    handle = if (returnedHandle.startsWith("@")) returnedHandle else "@$returnedHandle",
                    available = isAvail,
                    message = json.optString("message", null)
                )
            }
        }
    }

    /**
     * Dispatches a clickable verification URL to the user's email address
     * via the Akash Sovereign Vault email relay (`POST /_/u/email-verify-url`) and optional
     * custom domain transactional email API (e.g., Resend API if configured in BuildConfig).
     */
    /**
     * Dispatches a verification email containing the verification link directly to the recipient's inbox.
     * Uses Firebase Auth Identity Toolkit and optional custom Resend API.
     * Throws an exception or returns Result.failure if the email could not be sent,
     * ensuring that failures are immediately communicated to the user.
     */
    suspend fun sendEmailVerificationUrl(
        recipientEmail: String,
        verificationUrl: String
    ): Result<String?> = withContext(Dispatchers.IO) {
        val cleanEmail = cleanEmojis(recipientEmail).trim().lowercase()
        val cleanUrl = verificationUrl.trim()

        if (cleanEmail.isBlank() || !cleanEmail.contains("@") || !cleanEmail.substringAfter("@").contains(".")) {
            return@withContext Result.failure(IllegalArgumentException("Please enter a valid email address."))
        }

        // 1. Transactional Email via Resend API if configured in BuildConfig
        val resendApiKey = runCatching {
            com.example.BuildConfig::class.java.getDeclaredField("RESEND_API_KEY").get(null) as? String
        }.getOrNull()?.trim().orEmpty()

        val customSenderEmail = runCatching {
            com.example.BuildConfig::class.java.getDeclaredField("VERIFICATION_SENDER_EMAIL").get(null) as? String
        }.getOrNull()?.trim().orEmpty().ifBlank { "Akash Verification <noreply@auth.akash.jo3.org>" }

        if (resendApiKey.isNotBlank() && !resendApiKey.startsWith("MY_")) {
            val resendPayload = JSONObject().apply {
                put("from", customSenderEmail)
                put("to", JSONArray().put(cleanEmail))
                put("subject", "Verify your email to create your Akash Shorts account")
                put(
                    "html",
                    """
                    <div style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; max-width: 460px; margin: 0 auto; padding: 32px 24px; color: #0F172A;">
                      <h2 style="margin: 0 0 8px 0; font-size: 22px; font-weight: 800; color: #0F172A;">Verify your email address</h2>
                      <p style="margin: 0 0 24px 0; font-size: 14px; color: #64748B;">Click the verification URL below to verify <strong>$cleanEmail</strong> and set your password and username on Akash Shorts:</p>
                      <div style="margin: 20px 0;">
                        <a href="$cleanUrl" style="display: inline-block; background: linear-gradient(90deg, #5B5FEF, #8B5CF6); color: #FFFFFF; text-decoration: none; font-weight: 700; font-size: 14px; padding: 12px 24px; border-radius: 10px;">Verify Email URL</a>
                      </div>
                      <p style="margin: 24px 0 0 0; font-size: 12px; color: #94A3B8;">If you did not request this email, you can safely ignore it.</p>
                    </div>
                    """.trimIndent()
                )
            }
            val resendReq = Request.Builder()
                .url("https://api.resend.com/emails")
                .post(resendPayload.toString().toRequestBody(JSON_MEDIA_TYPE))
                .addHeader("Authorization", "Bearer $resendApiKey")
                .addHeader("Content-Type", "application/json")
                .build()

            try {
                httpClient.newCall(resendReq).execute().use { resp ->
                    val respBody = resp.body?.string().orEmpty()
                    if (resp.isSuccessful) {
                        return@withContext Result.success(null)
                    } else {
                        val errorDetail = runCatching {
                            JSONObject(respBody).optString("message", resp.message)
                        }.getOrDefault(resp.message)
                        return@withContext Result.failure(
                            IOException("Transactional email delivery failed: $errorDetail")
                        )
                    }
                }
            } catch (e: Exception) {
                return@withContext Result.failure(
                    IOException("Network error while delivering email: ${e.localizedMessage}")
                )
            }
        }

        // 2. Firebase Authentication Real Email Dispatch using custom domain (noreply@auth.akash.jo3.org)
        val firebaseApiKey = "AIzaSyDoWPeIWX_cZGA9GfuORkV6R3ea8_Xteck"
        val sendOobUrl = "https://identitytoolkit.googleapis.com/v1/accounts:sendOobCode?key=$firebaseApiKey"

        try {
            val oobPayload = JSONObject().apply {
                put("requestType", "PASSWORD_RESET")
                put("email", cleanEmail)
                put("continueUrl", "https://auth.akash.jo3.org/__/auth/action")
                put("canHandleCodeInApp", true)
            }

            val oobReq = Request.Builder()
                .url(sendOobUrl)
                .post(oobPayload.toString().toRequestBody(JSON_MEDIA_TYPE))
                .build()

            httpClient.newCall(oobReq).execute().use { oobResp ->
                val body = oobResp.body?.string().orEmpty()
                if (oobResp.isSuccessful) {
                    return@withContext Result.success(null)
                } else {
                    val errorObj = runCatching { JSONObject(body).optJSONObject("error") }.getOrNull()
                    val exactMessage = errorObj?.optString("message", body) ?: body
                    val code = errorObj?.optInt("code", oobResp.code) ?: oobResp.code
                    return@withContext Result.failure(
                        IOException("Firebase error [$code]: $exactMessage")
                    )
                }
            }
        } catch (e: Exception) {
            return@withContext Result.failure(
                IOException("Network error: ${e.localizedMessage ?: e.message}")
            )
        }
    }

    /**
     * Checks if a user's email has been verified on Firebase Authentication.
     */
    suspend fun checkFirebaseEmailVerified(
        email: String,
        password: String
    ): Result<Boolean> = withContext(Dispatchers.IO) {
        val cleanEmail = cleanEmojis(email).trim().lowercase()
        val firebaseApiKey = "AIzaSyDoWPeIWX_cZGA9GfuORkV6R3ea8_Xteck"
        val signInUrl = "https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=$firebaseApiKey"

        try {
            val payload = JSONObject().apply {
                put("email", cleanEmail)
                put("password", password)
                put("returnSecureToken", true)
            }
            val req = Request.Builder()
                .url(signInUrl)
                .post(payload.toString().toRequestBody(JSON_MEDIA_TYPE))
                .build()

            httpClient.newCall(req).execute().use { resp ->
                val body = resp.body?.string().orEmpty()
                if (resp.isSuccessful) {
                    val json = JSONObject(body)
                    val idToken = json.optString("idToken", "")
                    if (idToken.isNotBlank()) {
                        val parts = idToken.split(".")
                        if (parts.size >= 2) {
                            val decoded = String(android.util.Base64.decode(parts[1], android.util.Base64.URL_SAFE), Charsets.UTF_8)
                            val claims = JSONObject(decoded)
                            val isVerified = claims.optBoolean("email_verified", false)
                            return@withContext Result.success(isVerified)
                        }
                    }
                    val isVerifiedDirect = json.optBoolean("emailVerified", false)
                    Result.success(isVerifiedDirect)
                } else {
                    val errorObj = runCatching { JSONObject(body).optJSONObject("error") }.getOrNull()
                    val exactMessage = errorObj?.optString("message", body) ?: body
                    val code = errorObj?.optInt("code", resp.code) ?: resp.code
                    Result.failure(IOException("Firebase error [$code]: $exactMessage"))
                }
            }
        } catch (e: Exception) {
            Result.failure(IOException("Network error: ${e.localizedMessage ?: e.message}"))
        }
    }

    /**
     * Applies an Out-Of-Band verification code (or extracted code from email URL) to confirm email verification.
     */
    suspend fun applyVerificationOobCode(
        rawCodeOrUrl: String
    ): Result<Boolean> = withContext(Dispatchers.IO) {
        val cleanInput = rawCodeOrUrl.trim()
        val oobCode = when {
            cleanInput.contains("oobCode=") -> cleanInput.substringAfter("oobCode=").substringBefore("&")
            cleanInput.contains("code=") -> cleanInput.substringAfter("code=").substringBefore("&")
            else -> cleanInput
        }.trim()

        if (oobCode.isBlank()) {
            return@withContext Result.failure(IllegalArgumentException("Please enter or paste a valid verification link or code."))
        }

        val firebaseApiKey = "AIzaSyDoWPeIWX_cZGA9GfuORkV6R3ea8_Xteck"
        val updateUrl = "https://identitytoolkit.googleapis.com/v1/accounts:update?key=$firebaseApiKey"

        try {
            val payload = JSONObject().apply {
                put("oobCode", oobCode)
            }
            val req = Request.Builder()
                .url(updateUrl)
                .post(payload.toString().toRequestBody(JSON_MEDIA_TYPE))
                .build()

            httpClient.newCall(req).execute().use { resp ->
                val body = resp.body?.string().orEmpty()
                if (resp.isSuccessful) {
                    Result.success(true)
                } else {
                    val errorObj = runCatching { JSONObject(body).optJSONObject("error") }.getOrNull()
                    val exactMessage = errorObj?.optString("message", body) ?: body
                    val code = errorObj?.optInt("code", resp.code) ?: resp.code
                    Result.failure(IOException("Firebase error [$code]: $exactMessage"))
                }
            }
        } catch (e: Exception) {
            Result.failure(IOException("Network error: ${e.localizedMessage ?: e.message}"))
        }
    }

    /**
     * Dispatches a 6-digit registration verification code to the user's email address
     * via the Akash Sovereign Vault email relay (`POST /_/u/email-otp`) and optional
     * custom domain transactional email API (e.g., Resend API if configured in BuildConfig).
     */
    suspend fun sendEmailVerificationCode(
        recipientEmail: String,
        verificationCode: String,
        displayName: String
    ): Result<Boolean> = withContext(Dispatchers.IO) {
        runCatching {
            val cleanEmail = cleanEmojis(recipientEmail).trim().lowercase()
            val cleanName = cleanEmojis(displayName).ifBlank { "Akash Creator" }
            val cleanCode = verificationCode.filter { it.isDigit() }.take(6)

            // 1. Optional Custom Domain Transactional Email via Resend API if configured in BuildConfig
            val resendApiKey = runCatching {
                com.example.BuildConfig::class.java.getDeclaredField("RESEND_API_KEY").get(null) as? String
            }.getOrNull()?.trim().orEmpty()

            val customSenderEmail = runCatching {
                com.example.BuildConfig::class.java.getDeclaredField("VERIFICATION_SENDER_EMAIL").get(null) as? String
            }.getOrNull()?.trim().orEmpty().ifBlank { "Akash Verification <noreply@auth.akash.jo3.org>" }

            if (resendApiKey.isNotBlank() && !resendApiKey.startsWith("MY_")) {
                val resendPayload = JSONObject().apply {
                    put("from", customSenderEmail)
                    put("to", JSONArray().put(cleanEmail))
                    put("subject", "$cleanCode is your Akash verification code")
                    put(
                        "html",
                        """
                        <div style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; max-width: 460px; margin: 0 auto; padding: 32px 24px; color: #0F172A;">
                          <h2 style="margin: 0 0 8px 0; font-size: 22px; font-weight: 800; color: #0F172A;">Verify your email</h2>
                          <p style="margin: 0 0 24px 0; font-size: 14px; color: #64748B;">Hi $cleanName, enter the 6-digit verification code below to complete creating your Akash account:</p>
                          <div style="font-size: 32px; font-weight: 800; letter-spacing: 8px; color: #5B5FEF; padding: 16px 0; border-bottom: 2px solid #5B5FEF; text-align: center;">$cleanCode</div>
                          <p style="margin: 24px 0 0 0; font-size: 12px; color: #94A3B8;">This verification code expires in 10 minutes. If you didn't request this email, you can safely ignore it.</p>
                        </div>
                        """.trimIndent()
                    )
                }
                val resendReq = Request.Builder()
                    .url("https://api.resend.com/emails")
                    .post(resendPayload.toString().toRequestBody(JSON_MEDIA_TYPE))
                    .addHeader("Authorization", "Bearer $resendApiKey")
                    .addHeader("Content-Type", "application/json")
                    .build()
                runCatching {
                    httpClient.newCall(resendReq).execute().use { resp ->
                        if (resp.isSuccessful) return@runCatching true
                    }
                }
            }

            // 2. Dispatch via Akash Sovereign Backend email relay endpoint
            val akashPayload = JSONObject().apply {
                put("email", cleanEmail)
                put("code", cleanCode)
                put("display_name", cleanName)
                put("purpose", "account_registration")
            }
            val akashReq = Request.Builder()
                .url("$BASE_URL/_/u/email-otp")
                .post(akashPayload.toString().toRequestBody(JSON_MEDIA_TYPE))
                .applySovereignHeaders(null)
                .build()

            httpClient.newCall(akashReq).execute().use { response ->
                response.isSuccessful
            }
        }
    }

    /**
     * Step 3: Update Profile / Username
     * `PUT /_/u/profile`
     * Headers: `Authorization: Bearer <FIREBASE_ID_TOKEN>`, `X-App-Token`
     * Body: `{ "display_name": "...", "handle": "alex_vance", "avatar_url": "..." }`
     * Returns HTTP 409 Conflict if the handle is already taken by another user.
     */
    suspend fun updateUserProfile(
        firebaseIdToken: String,
        displayName: String,
        handle: String,
        avatarUrl: String?
    ): Result<AkashProfileUpdateResult> = withContext(Dispatchers.IO) {
        runCatching {
            val cleanName = cleanEmojis(displayName).ifBlank { "Akash Creator" }
            val cleanHandle = cleanEmojis(handle).removePrefix("@").lowercase().trim()
            if (!validateHandleFormat(cleanHandle)) {
                return@runCatching AkashProfileUpdateResult(
                    success = false,
                    isConflict = false,
                    message = "Handle must be 3-24 characters (lowercase letters, numbers, underscores only)"
                )
            }

            val payload = JSONObject().apply {
                put("display_name", cleanName)
                put("handle", cleanHandle)
                put("avatar_url", avatarUrl ?: JSONObject.NULL)
            }

            val request = Request.Builder()
                .url(USER_PROFILE_ENDPOINT)
                .put(payload.toString().toRequestBody(JSON_MEDIA_TYPE))
                .applySovereignHeaders(firebaseIdToken)
                .build()

            httpClient.newCall(request).execute().use { response ->
                if (response.code == 409) {
                    return@use AkashProfileUpdateResult(
                        success = false,
                        isConflict = true,
                        message = "Username @$cleanHandle is already taken by another user."
                    )
                }
                val bodyStr = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    return@use AkashProfileUpdateResult(
                        success = false,
                        isConflict = false,
                        message = "Profile update failed (HTTP ${response.code})"
                    )
                }
                AkashProfileUpdateResult(
                    success = true,
                    isConflict = false,
                    handle = "@$cleanHandle"
                )
            }
        }
    }

    /**
     * Like / Unlike Post
     * `POST /_/u/like`
     * Body: `{ "file_code": "s_1489976d", "media_type": "short" }`
     * Response: `{"status": "success", "liked": true, "total_likes": 43}`
     */
    suspend fun toggleLikeReel(
        firebaseIdToken: String?,
        fileCode: String
    ): Result<AkashLikeStatusResponse> = withContext(Dispatchers.IO) {
        runCatching {
            val cleanCode = fileCode.trim()
            val payload = JSONObject().apply {
                put("file_code", cleanCode)
                put("media_type", "short")
            }
            val request = Request.Builder()
                .url(USER_LIKE_ENDPOINT)
                .post(payload.toString().toRequestBody(JSON_MEDIA_TYPE))
                .applySovereignHeaders(firebaseIdToken)
                .build()

            httpClient.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    throw IOException("Like API failed with HTTP ${response.code}")
                }
                val bodyStr = response.body?.string().orEmpty()
                val json = JSONObject(bodyStr)
                val isLiked = json.optBoolean("liked", json.optBoolean("is_liked", true))
                val likes = json.optInt("total_likes", json.optInt("likes_count", -1))
                AkashLikeStatusResponse(
                    status = json.optString("status", "success"),
                    fileCode = json.optString("file_code", cleanCode),
                    isLiked = isLiked,
                    likesCount = likes,
                    liked = isLiked,
                    totalLikes = likes
                )
            }
        }
    }

    /**
     * Bookmark / Save Post
     * `POST /_/u/saved` with `{"file_code": "...", "media_type": "short"}`
     */
    suspend fun toggleSaveReel(
        firebaseIdToken: String?,
        fileCode: String
    ): Result<AkashSaveStatusResponse> = withContext(Dispatchers.IO) {
        runCatching {
            val cleanCode = fileCode.trim()
            val payload = JSONObject().apply {
                put("file_code", cleanCode)
                put("media_type", "short")
            }
            val request = Request.Builder()
                .url(USER_SAVED_ENDPOINT)
                .post(payload.toString().toRequestBody(JSON_MEDIA_TYPE))
                .applySovereignHeaders(firebaseIdToken)
                .build()

            httpClient.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    throw IOException("Save API failed with HTTP ${response.code}")
                }
                val bodyStr = response.body?.string().orEmpty()
                val json = JSONObject(bodyStr)
                AkashSaveStatusResponse(
                    status = json.optString("status", "success"),
                    fileCode = json.optString("file_code", cleanCode),
                    isSaved = json.optBoolean("is_saved", true)
                )
            }
        }
    }

    /**
     * List saved shorts
     * `GET /_/u/saved?media_type=short`
     */
    suspend fun fetchSavedReels(
        firebaseIdToken: String?
    ): Result<AkashSavedReelsResult> = withContext(Dispatchers.IO) {
        runCatching {
            val request = Request.Builder()
                .url("$USER_SAVED_ENDPOINT?media_type=short")
                .get()
                .applySovereignHeaders(firebaseIdToken)
                .build()

            httpClient.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    throw IOException("Get Saved Reels failed with HTTP ${response.code}")
                }
                val bodyStr = response.body?.string().orEmpty().trim()
                if (bodyStr.isEmpty()) {
                    return@use AkashSavedReelsResult(emptyList(), emptySet())
                }
                val parsedItems = parseCatalogItems(bodyStr)
                    .filter { it.mediaType == "short" && (it.duration <= 0.0 || it.duration <= 120.0) }

                val codes = mutableSetOf<String>()
                parsedItems.forEach { codes.add(it.fileCode) }

                runCatching {
                    val arr = if (bodyStr.startsWith("[")) {
                        JSONArray(bodyStr)
                    } else {
                        val root = JSONObject(bodyStr)
                        root.optJSONArray("items")
                            ?: root.optJSONArray("saved")
                            ?: root.optJSONArray("data")
                            ?: JSONArray()
                    }
                    for (i in 0 until arr.length()) {
                        val obj = arr.optJSONObject(i)
                        if (obj != null) {
                            val code = obj.optString("file_code", "").trim()
                            if (code.isNotEmpty()) codes.add(code)
                        } else {
                            val str = arr.optString(i, "").trim()
                            if (str.isNotEmpty()) codes.add(str)
                        }
                    }
                }

                AkashSavedReelsResult(items = parsedItems, fileCodes = codes)
            }
        }
    }

    /**
     * Video Interaction Status
     * `GET /_/u/status/{file_code}`
     * Response: `{"status": "success", "file_code": "s_1489976d", "is_liked": true, "is_saved": false, "total_likes": 42, "total_comments": 5}`
     */
    suspend fun fetchVideoInteractionStatus(
        firebaseIdToken: String?,
        fileCode: String
    ): Result<AkashVideoStatusResponse> = withContext(Dispatchers.IO) {
        runCatching {
            val cleanCode = fileCode.trim()
            val request = Request.Builder()
                .url("$USER_STATUS_ENDPOINT/$cleanCode")
                .get()
                .applySovereignHeaders(firebaseIdToken)
                .build()

            httpClient.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    throw IOException("Status API failed with HTTP ${response.code}")
                }
                val bodyStr = response.body?.string().orEmpty()
                val json = JSONObject(bodyStr)
                val totalLikes = json.optInt("total_likes", json.optInt("likes_count", -1))
                val totalComments = json.optInt("total_comments", 0)
                AkashVideoStatusResponse(
                    fileCode = json.optString("file_code", cleanCode),
                    isLiked = json.optBoolean("is_liked", false),
                    isSaved = json.optBoolean("is_saved", false),
                    likesCount = totalLikes,
                    totalLikes = totalLikes,
                    totalComments = totalComments
                )
            }
        }
    }

    /**
     * List comments for a video
     * `GET /_/u/comments/{file_code}`
     * Zero-Emoji Policy: strips emojis from comment texts and author names.
     */
    suspend fun fetchComments(
        fileCode: String,
        firebaseIdToken: String? = null
    ): Result<List<AkashCommentItem>> = withContext(Dispatchers.IO) {
        runCatching {
            val cleanCode = fileCode.trim()
            val request = Request.Builder()
                .url("$COMMENTS_ENDPOINT/$cleanCode")
                .get()
                .applySovereignHeaders(firebaseIdToken)
                .build()

            httpClient.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    throw IOException("Comments API failed with HTTP ${response.code}")
                }
                val bodyStr = response.body?.string().orEmpty().trim()
                if (bodyStr.isEmpty()) return@use emptyList()

                val arr: JSONArray = if (bodyStr.startsWith("[")) {
                    JSONArray(bodyStr)
                } else {
                    val root = JSONObject(bodyStr)
                    root.optJSONArray("comments")
                        ?: root.optJSONArray("items")
                        ?: root.optJSONArray("data")
                        ?: JSONArray()
                }

                val result = mutableListOf<AkashCommentItem>()
                for (i in 0 until arr.length()) {
                    val obj = arr.optJSONObject(i) ?: continue
                    val id = obj.optString("id", obj.optString("comment_id", "c_$i"))
                    val rawAuthor = obj.optString("author_name", obj.optString("author", "Creator"))
                    val rawHandle = obj.optString("creator_handle", obj.optString("author_handle", obj.optString("handle", "")))
                    val authorName = cleanEmojis(rawAuthor).ifBlank { "Creator" }
                    val authorHandle = cleanEmojis(rawHandle).let { h ->
                        val unPrefixed = h.removePrefix("@")
                        if (unPrefixed.isNotBlank()) "@$unPrefixed" else "@${authorName.lowercase().replace(" ", "_")}"
                    }
                    val commentText = cleanEmojis(obj.optString("comment_text", obj.optString("text", "")))
                    val avatarUrl = obj.optString("avatar_url", "").takeIf { it.isNotBlank() }?.let { normalizeUrl(it) }
                    val createdAt = obj.optString("timestamp", obj.optString("created_at", "Recently"))
                    val likes = obj.optInt("likes", obj.optInt("total_likes", 0))
                    val isLiked = obj.optBoolean("is_liked", false)

                    if (commentText.isNotBlank()) {
                        result.add(
                            AkashCommentItem(
                                id = id,
                                fileCode = cleanCode,
                                authorName = authorName,
                                authorHandle = authorHandle,
                                avatarUrl = avatarUrl,
                                commentText = commentText,
                                createdAt = createdAt,
                                likes = likes,
                                isLiked = isLiked
                            )
                        )
                    }
                }
                result
            }
        }
    }

    /**
     * Post a new comment
     * `POST /_/u/comment`
     * Headers: `Authorization: Bearer <FIREBASE_ID_TOKEN>`, `X-App-Token`
     * Body: `{"file_code": "s_1489976d", "media_type": "short", "comment_text": "Incredible edit!"}`
     * Zero-Emoji Policy: strips emojis from commentText automatically.
     */
    suspend fun postComment(
        firebaseIdToken: String,
        fileCode: String,
        commentText: String
    ): Result<AkashCommentItem> = withContext(Dispatchers.IO) {
        runCatching {
            val cleanCode = fileCode.trim()
            val sanitizedText = cleanEmojis(commentText).trim()
            if (sanitizedText.isEmpty()) {
                throw IllegalArgumentException("Comment text cannot be empty or solely emojis")
            }

            val payload = JSONObject().apply {
                put("file_code", cleanCode)
                put("media_type", "short")
                put("comment_text", sanitizedText)
            }

            val request = Request.Builder()
                .url(COMMENT_POST_ENDPOINT)
                .post(payload.toString().toRequestBody(JSON_MEDIA_TYPE))
                .applySovereignHeaders(firebaseIdToken)
                .build()

            httpClient.newCall(request).execute().use { response ->
                val bodyStr = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    throw IOException("Post comment failed with HTTP ${response.code}: $bodyStr")
                }
                val json = if (bodyStr.isNotBlank()) JSONObject(bodyStr) else JSONObject()
                val commentObj = json.optJSONObject("comment") ?: json
                val id = commentObj.optString("id", commentObj.optString("comment_id", "c_${System.currentTimeMillis()}"))
                val author = cleanEmojis(commentObj.optString("author_name", commentObj.optString("author", "You"))).ifBlank { "You" }
                val handle = cleanEmojis(commentObj.optString("creator_handle", commentObj.optString("author_handle", "")))
                val formattedHandle = if (handle.isNotBlank()) {
                    if (handle.startsWith("@")) handle else "@$handle"
                } else "@creator"

                AkashCommentItem(
                    id = id,
                    fileCode = cleanCode,
                    authorName = author,
                    authorHandle = formattedHandle,
                    avatarUrl = commentObj.optString("avatar_url", null),
                    commentText = sanitizedText,
                    createdAt = "Just now",
                    likes = 1,
                    isLiked = true
                )
            }
        }
    }

    /**
     * Delete Comment
     * `DELETE /_/u/comment/{comment_id}`
     * Headers: `Authorization: Bearer <FIREBASE_ID_TOKEN>`, `X-App-Token`
     */
    suspend fun deleteComment(
        firebaseIdToken: String,
        commentId: String
    ): Result<Boolean> = withContext(Dispatchers.IO) {
        runCatching {
            val cleanId = commentId.trim()
            val request = Request.Builder()
                .url("$COMMENT_POST_ENDPOINT/$cleanId")
                .delete()
                .applySovereignHeaders(firebaseIdToken)
                .build()

            httpClient.newCall(request).execute().use { response ->
                response.isSuccessful
            }
        }
    }

    /**
     * Creator Channel Profile:
     * `GET /_/u/creator/{handle}`
     * Headers: `X-App-Token`
     * Response: display name, @handle, avatar, total views, total likes, and shorts array.
     */
    suspend fun fetchCreatorProfile(
        handle: String,
        firebaseIdToken: String? = null
    ): Result<AkashCreatorProfileResponse> = withContext(Dispatchers.IO) {
        runCatching {
            val cleanHandle = cleanEmojis(handle).removePrefix("@").lowercase().trim()
            val request = Request.Builder()
                .url("$CREATOR_PROFILE_ENDPOINT/$cleanHandle")
                .get()
                .applySovereignHeaders(firebaseIdToken)
                .build()

            httpClient.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    throw IOException("Creator profile API failed with HTTP ${response.code}")
                }
                val bodyStr = response.body?.string().orEmpty()
                val json = JSONObject(bodyStr)
                val rawName = cleanEmojis(json.optString("display_name", json.optString("name", cleanHandle)))
                val rawAvatar = json.optString("avatar_url", null)
                val totalViews = json.optLong("total_views", json.optLong("views", 0L))
                val totalLikes = json.optLong("total_likes", json.optLong("likes", 0L))
                val shortsArr = json.optJSONArray("shorts")?.toString() ?: "[]"
                val shortsList = parseCatalogItems(shortsArr)
                    .filter { it.mediaType == "short" && (it.duration <= 0.0 || it.duration <= 120.0) }

                AkashCreatorProfileResponse(
                    status = json.optString("status", "success"),
                    displayName = rawName.ifBlank { cleanHandle },
                    handle = "@$cleanHandle",
                    avatarUrl = rawAvatar?.let { normalizeUrl(it) },
                    totalViews = totalViews,
                    totalLikes = totalLikes,
                    shorts = shortsList
                )
            }
        }
    }

    /**
     * Tier 1 & Tier 2 Pre-Upload Check:
     * `POST /_/v8f3`
     * Headers: `X-App-Token`
     * Multipart: `file=@my_short.mp4`
     * Ensure response is `{"status": "success", "media_type": "video"}`.
     */
    suspend fun verifyPreUpload(
        fileBytes: ByteArray,
        fileName: String = "my_short.mp4"
    ): Result<AkashPreUploadCheckResult> = withContext(Dispatchers.IO) {
        runCatching {
            val filePart = fileBytes.toRequestBody("video/mp4".toMediaType())
            val multipartBody = MultipartBody.Builder()
                .setType(MultipartBody.FORM)
                .addFormDataPart("file", fileName, filePart)
                .build()

            val request = Request.Builder()
                .url(PRE_UPLOAD_VERIFY_ENDPOINT)
                .post(multipartBody)
                .applySovereignHeaders(null)
                .build()

            httpClient.newCall(request).execute().use { response ->
                val bodyStr = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    return@use AkashPreUploadCheckResult(
                        success = false,
                        mediaType = "unknown",
                        message = "Pre-upload verification rejected with HTTP ${response.code}: $bodyStr"
                    )
                }
                val json = if (bodyStr.isNotBlank()) JSONObject(bodyStr) else JSONObject()
                val status = json.optString("status", "")
                val mediaType = json.optString("media_type", "")
                val isSuccess = status.equals("success", ignoreCase = true) && mediaType.equals("video", ignoreCase = true)

                AkashPreUploadCheckResult(
                    success = isSuccess,
                    mediaType = mediaType,
                    message = if (!isSuccess) "Verification failed: $bodyStr" else null
                )
            }
        }
    }

    /**
     * Execute Upload:
     * `POST /_/9a4f2b`
     * Headers: `Authorization: Bearer <FIREBASE_ID_TOKEN>`, `X-App-Token`
     * Multipart:
     *   `file=@my_short.mp4`
     *   `title="My Cool Short"`
     *   `author="<USER_GLOBAL_HANDLE>"`
     *   `media_type="short"`
     */
    suspend fun executeShortUpload(
        firebaseIdToken: String,
        fileBytes: ByteArray,
        fileName: String = "my_short.mp4",
        title: String,
        authorHandle: String
    ): Result<AkashUploadResult> = withContext(Dispatchers.IO) {
        runCatching {
            val cleanTitle = cleanEmojis(title).ifBlank { "Short Video" }
            val cleanAuthor = cleanEmojis(authorHandle).let { if (it.startsWith("@")) it else "@$it" }
            val filePart = fileBytes.toRequestBody("video/mp4".toMediaType())

            val multipartBody = MultipartBody.Builder()
                .setType(MultipartBody.FORM)
                .addFormDataPart("file", fileName, filePart)
                .addFormDataPart("title", cleanTitle)
                .addFormDataPart("author", cleanAuthor)
                .addFormDataPart("media_type", "short")
                .build()

            val request = Request.Builder()
                .url(EXECUTE_UPLOAD_ENDPOINT)
                .post(multipartBody)
                .applySovereignHeaders(firebaseIdToken)
                .build()

            httpClient.newCall(request).execute().use { response ->
                val bodyStr = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    throw IOException("Upload failed with HTTP ${response.code}: $bodyStr")
                }
                val json = if (bodyStr.isNotBlank()) JSONObject(bodyStr) else JSONObject()
                val fileCode = json.optString("file_code", json.optString("code", ""))
                AkashUploadResult(
                    success = true,
                    fileCode = fileCode.ifBlank { null },
                    message = json.optString("message", "Upload successful")
                )
            }
        }
    }

    /**
     * Modular 3-Step Upload Workflow — Step 1: Upload Video Independently
     * Endpoint: `POST https://akashbox.duckdns.org/_/upload/video`
     * Header: `X-App-Token: akash_sec_shorts_app_a_9e4b11f8c32d4a7b91e0a29487c56d10e82f1a3c7489b012`
     * Body: `multipart/form-data` with key `"file"` (MP4, WebM, MOV)
     * Response: `{ "status": "success", "video_token": "vtok_...", "duration": 15.0, "width": 1080, "height": 1920 }`
     */
    suspend fun uploadVideoStep1(
        videoBytes: ByteArray,
        fileName: String = "akash_short.mp4",
        mimeType: String = "video/mp4",
        firebaseIdToken: String? = null,
        onProgress: (Float) -> Unit = {}
    ): Result<AkashStep1VideoUploadResult> = withContext(Dispatchers.IO) {
        runCatching {
            val rawBody = videoBytes.toRequestBody(mimeType.toMediaType())
            val progressBody = ProgressRequestBody(rawBody, onProgress)
            val multipartBody = MultipartBody.Builder()
                .setType(MultipartBody.FORM)
                .addFormDataPart("file", fileName, progressBody)
                .build()

            val request = Request.Builder()
                .url(UPLOAD_VIDEO_STEP1_ENDPOINT)
                .post(multipartBody)
                .applySovereignHeaders(firebaseIdToken)
                .build()

            httpClient.newCall(request).execute().use { response ->
                val bodyStr = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    throw IOException("Step 1 video upload failed with HTTP ${response.code}: $bodyStr")
                }
                val json = if (bodyStr.isNotBlank()) JSONObject(bodyStr) else JSONObject()
                val videoToken = json.optString("video_token", "").trim()
                    .ifEmpty { "vtok_${System.currentTimeMillis()}" }
                AkashStep1VideoUploadResult(
                    status = json.optString("status", "success"),
                    videoToken = videoToken,
                    duration = json.optDouble("duration", 15.0).let { if (it.isNaN() || it <= 0.0) 15.0 else it },
                    width = json.optInt("width", 1080),
                    height = json.optInt("height", 1920)
                )
            }
        }
    }

    /**
     * Modular 3-Step Upload Workflow — Step 2: Upload Thumbnail Separately (Optional / Custom Cover)
     * Endpoint: `POST https://akashbox.duckdns.org/_/upload/thumbnail`
     * Header: `X-App-Token: akash_sec_shorts_app_a_9e4b11f8c32d4a7b91e0a29487c56d10e82f1a3c7489b012`
     * Body: `multipart/form-data` with key `"file"` (JPEG, PNG, WebP)
     * Response: `{ "status": "success", "thumbnail_token": "ttok_...", "width": 1080, "height": 1920 }`
     */
    suspend fun uploadThumbnailStep2(
        thumbnailBytes: ByteArray,
        fileName: String = "akash_cover.jpg",
        mimeType: String = "image/jpeg",
        firebaseIdToken: String? = null,
        onProgress: (Float) -> Unit = {}
    ): Result<AkashStep2ThumbnailUploadResult> = withContext(Dispatchers.IO) {
        runCatching {
            val rawBody = thumbnailBytes.toRequestBody(mimeType.toMediaType())
            val progressBody = ProgressRequestBody(rawBody, onProgress)
            val multipartBody = MultipartBody.Builder()
                .setType(MultipartBody.FORM)
                .addFormDataPart("file", fileName, progressBody)
                .build()

            val request = Request.Builder()
                .url(UPLOAD_THUMBNAIL_STEP2_ENDPOINT)
                .post(multipartBody)
                .applySovereignHeaders(firebaseIdToken)
                .build()

            httpClient.newCall(request).execute().use { response ->
                val bodyStr = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    throw IOException("Step 2 thumbnail upload failed with HTTP ${response.code}: $bodyStr")
                }
                val json = if (bodyStr.isNotBlank()) JSONObject(bodyStr) else JSONObject()
                val thumbnailToken = json.optString("thumbnail_token", "").trim()
                    .ifEmpty { "ttok_${System.currentTimeMillis()}" }
                AkashStep2ThumbnailUploadResult(
                    status = json.optString("status", "success"),
                    thumbnailToken = thumbnailToken,
                    width = json.optInt("width", 1080),
                    height = json.optInt("height", 1920)
                )
            }
        }
    }

    /**
     * Modular 3-Step Upload Workflow — Step 3: Create Metadata & Finalize Short
     * Endpoint: `POST https://akashbox.duckdns.org/_/media/create`
     * Headers:
     *   - `X-App-Token: akash_sec_shorts_app_a_9e4b11f8c32d4a7b91e0a29487c56d10e82f1a3c7489b012`
     *   - `Content-Type: application/json`
     * JSON Body:
     *   `{ "video_token": "vtok_...", "thumbnail_token": "ttok_...", "title": "...", "caption": "...", "author": "...", "media_type": "short" }`
     */
    suspend fun createMediaStep3(
        videoToken: String,
        thumbnailToken: String?,
        title: String,
        caption: String,
        author: String,
        firebaseIdToken: String? = null
    ): Result<AkashStep3CreateMediaResult> = withContext(Dispatchers.IO) {
        runCatching {
            val cleanTitle = cleanEmojis(title).ifBlank { "Akash Short" }
            val cleanCaption = cleanEmojis(caption)
            val cleanAuthor = cleanEmojis(author).ifBlank { "Akash Creator" }

            val payload = JSONObject().apply {
                put("video_token", videoToken.trim())
                if (!thumbnailToken.isNullOrBlank()) {
                    put("thumbnail_token", thumbnailToken.trim())
                }
                put("title", cleanTitle)
                put("caption", cleanCaption)
                put("author", cleanAuthor)
                put("media_type", "short")
            }

            val request = Request.Builder()
                .url(CREATE_MEDIA_STEP3_ENDPOINT)
                .post(payload.toString().toRequestBody(JSON_MEDIA_TYPE))
                .applySovereignHeaders(firebaseIdToken)
                .addHeader("Content-Type", "application/json")
                .build()

            httpClient.newCall(request).execute().use { response ->
                val bodyStr = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    throw IOException("Step 3 finalize short failed with HTTP ${response.code}: $bodyStr")
                }
                val json = if (bodyStr.isNotBlank()) JSONObject(bodyStr) else JSONObject()
                val fileCode = json.optString("file_code", "").trim()
                    .ifEmpty { "s_${System.currentTimeMillis().toString(16)}" }
                val rawDirect = json.optString("highest_quality_stream_url", "")
                    .ifBlank { json.optString("direct_stream_url", "") }
                    .trim()
                val directUrl = if (rawDirect.isNotEmpty()) ensureStreamToken(rawDirect) else highestQualityStreamUrl(fileCode)
                val rawAdaptive = json.optString("adaptive_stream_url", "")
                    .ifBlank { json.optString("stream_url", "") }
                    .trim()
                val adaptiveUrl = if (rawAdaptive.isNotEmpty()) ensureStreamToken(rawAdaptive) else adaptiveHlsStreamUrl(fileCode)
                val rawThumb = json.optString("thumbnail_url", "").trim()
                val thumbUrl = if (rawThumb.isNotEmpty()) normalizeUrl(rawThumb) else thumbnailUrl(fileCode)

                AkashStep3CreateMediaResult(
                    status = json.optString("status", "success"),
                    fileCode = fileCode,
                    directStreamUrl = directUrl,
                    adaptiveStreamUrl = adaptiveUrl,
                    highestQualityStreamUrl = directUrl,
                    thumbnailUrl = thumbUrl,
                    qualityStreams = emptyMap(),
                    availableQualities = emptyList()
                )
            }
        }
    }

    /**
     * Single-use instant playback stream URL OTT resolution
     */
    suspend fun resolveStreamUrl(fileCode: String): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            val cleanCode = fileCode.trim()
            val url = "$BASE_URL/_/3c7e1a/$cleanCode?ott=true"
            val request = Request.Builder()
                .url(url)
                .get()
                .applySovereignHeaders(null)
                .build()

            httpClient.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    throw IOException("OTT stream resolution failed with HTTP ${response.code}")
                }
                val bodyString = response.body?.string()
                    ?: throw IOException("Empty response body from OTT stream endpoint")

                val json = JSONObject(bodyString)
                val resolved = json.optString("stream_url", "").trim()
                if (resolved.isEmpty()) {
                    throw IOException("Missing stream_url in OTT response")
                }
                ensureStreamToken(resolved)
            }
        }
    }

    internal fun parseCatalogItems(
        jsonString: String
    ): List<AkashCatalogItem> {
        val trimmed = jsonString.trim()
        val itemsArray: JSONArray = if (trimmed.startsWith("[")) {
            JSONArray(trimmed)
        } else {
            val root = JSONObject(trimmed)
            root.optJSONArray("items")
                ?: root.optJSONArray("saved")
                ?: root.optJSONArray("data")
                ?: JSONArray()
        }

        val result = ArrayList<AkashCatalogItem>(itemsArray.length())
        for (i in 0 until itemsArray.length()) {
            val obj = itemsArray.optJSONObject(i) ?: continue
            val fileCode = obj.optString("file_code", "").trim()
            if (fileCode.isEmpty()) continue

            val rawMediaType = obj.optString("media_type", "").trim()
            val mediaType = when {
                rawMediaType.equals("short", ignoreCase = true) -> "short"
                rawMediaType.equals("photo", ignoreCase = true) ||
                    rawMediaType.equals("image", ignoreCase = true) -> "photo"
                rawMediaType.equals("long_video", ignoreCase = true) -> "long_video"
                rawMediaType.isNotEmpty() -> rawMediaType.lowercase()
                fileCode.startsWith("s_", ignoreCase = true) ||
                    fileCode.startsWith("sh_", ignoreCase = true) -> "short"
                fileCode.startsWith("p_", ignoreCase = true) ||
                    fileCode.startsWith("img_", ignoreCase = true) -> "photo"
                else -> "short"
            }

            val title = cleanEmojis(obj.optString("title", "")).ifEmpty { "Video by creator" }
            val rawAuthor = cleanEmojis(obj.optString("author", "")).ifEmpty { "creator" }
            val rawCreatorHandle = cleanEmojis(obj.optString("creator_handle", ""))
            val creatorHandle = when {
                rawCreatorHandle.isNotEmpty() -> {
                    if (rawCreatorHandle.startsWith("@")) rawCreatorHandle else "@$rawCreatorHandle"
                }
                rawAuthor.startsWith("@") -> rawAuthor
                else -> "@${rawAuthor.lowercase().replace(" ", "_")}"
            }

            val rawDisplayName = cleanEmojis(obj.optString("display_name", ""))
            val displayName = rawDisplayName.ifEmpty { rawAuthor.removePrefix("@") }

            val rawDurationVal = obj.optDouble("duration", Double.NaN)
            val duration = if (!rawDurationVal.isNaN() && rawDurationVal >= 0.0) {
                rawDurationVal
            } else {
                val durationStr = obj.optString("duration", "")
                    .trim()
                    .lowercase()
                    .removeSuffix("s")
                    .trim()
                durationStr.toDoubleOrNull()?.takeIf { it >= 0.0 } ?: 26.0
            }

            // Highest quality raw source stream URL (`/_/8b0d4f/{file_code}`)
            val rawHighestQualityUrl = obj.optString("highest_quality_stream_url", "")
                .ifBlank { obj.optString("direct_stream_url", "") }
                .trim()
            val highestQualityStreamUrl = if (rawHighestQualityUrl.isNotEmpty()) {
                ensureStreamToken(rawHighestQualityUrl)
            } else {
                highestQualityStreamUrl(fileCode)
            }

            // Adaptive stream URL (`/_/h8a2/{file_code}/master.m3u8` or API `adaptive_stream_url` / `stream_url`)
            val rawAdaptiveUrl = obj.optString("adaptive_stream_url", "").trim()
            val rawStreamUrl = obj.optString("stream_url", "").trim()
            val adaptiveStreamUrl = when {
                rawAdaptiveUrl.isNotEmpty() -> ensureStreamToken(rawAdaptiveUrl)
                rawStreamUrl.isNotEmpty() -> ensureStreamToken(rawStreamUrl)
                else -> adaptiveHlsStreamUrl(fileCode)
            }
            val streamUrl = if (rawStreamUrl.isNotEmpty()) {
                ensureStreamToken(rawStreamUrl)
            } else {
                adaptiveStreamUrl
            }

            val topLevelThumb = obj.optString("thumbnail_url", "").trim()
            val playbackObj = obj.optJSONObject("playback")
            val nestedThumb = playbackObj?.optString("thumbnail_url", "")?.trim().orEmpty()
            val chosenThumb = topLevelThumb.ifEmpty { nestedThumb }
            val thumbUrl = if (chosenThumb.isNotEmpty()) {
                normalizeUrl(chosenThumb)
            } else {
                thumbnailUrl(fileCode)
            }

            val rawViewsCount = obj.optLong("views_count", obj.optLong("views", 0L)).coerceAtLeast(0L)
            val rawSimulatedViews = obj.optLong("simulated_views", 0L)
            val simulatedViews = when {
                rawSimulatedViews > 0L -> rawSimulatedViews
                rawViewsCount >= 1200L -> rawViewsCount
                else -> computeSimulatedViews(fileCode, rawViewsCount, i + 1)
            }
            val views = simulatedViews
            val apiFormattedViews = obj.optString("formatted_views", "").trim()
            val formattedViews = if (apiFormattedViews.isNotEmpty() && !apiFormattedViews.startsWith("0 ")) {
                apiFormattedViews
            } else {
                formatViewsCount(simulatedViews, fileCode)
            }

            val rawUploadedAt = obj.optString("uploaded_at", "")
                .ifBlank { obj.optString("created_at", "") }
                .trim()
            val uploadedAt = rawUploadedAt.ifEmpty { defaultIsoTimestampForIndex(i) }
            val apiRelativeTime = obj.optString("relative_time", "").trim()
            val relativeTime = if (apiRelativeTime.isNotEmpty()) {
                apiRelativeTime
            } else {
                computeRelativeTime(rawUploadedAt, i)
            }

            val qualityMode = obj.optString("quality_mode", "single_toggle").ifBlank { "single_toggle" }
            val hasHighestQualityToggle = obj.optBoolean("has_highest_quality_toggle", true)

            val userObj = obj.optJSONObject("user") ?: obj.optJSONObject("creator")
            val rawAvatar = listOf(
                obj.optString("avatar_url", ""),
                obj.optString("author_avatar", ""),
                obj.optString("profile_photo", ""),
                obj.optString("profile_pic", ""),
                obj.optString("avatar", ""),
                userObj?.optString("avatar_url", "").orEmpty(),
                userObj?.optString("profile_photo", "").orEmpty(),
                userObj?.optString("avatar", "").orEmpty()
            ).map { it.trim() }.firstOrNull { it.isNotEmpty() }
            val resolvedAvatarUrl = rawAvatar?.let { normalizeUrl(it) }

            // Rules for backend handlers:
            // available_qualities MUST be an empty array [] for shorts so the frontend does not render resolution picker sheets.
            val availableQualities = emptyList<String>()

            result.add(
                AkashCatalogItem(
                    fileCode = fileCode,
                    mediaType = mediaType,
                    title = title,
                    author = rawAuthor,
                    creatorHandle = creatorHandle,
                    displayName = displayName,
                    duration = duration,
                    streamUrl = streamUrl,
                    directStreamUrl = highestQualityStreamUrl,
                    adaptiveStreamUrl = adaptiveStreamUrl,
                    highestQualityStreamUrl = highestQualityStreamUrl,
                    thumbnailUrl = thumbUrl,
                    views = views,
                    simulatedViews = simulatedViews,
                    formattedViews = formattedViews,
                    uploadedAt = uploadedAt,
                    relativeTime = relativeTime,
                    qualityMode = qualityMode,
                    hasHighestQualityToggle = hasHighestQualityToggle,
                    playback = AkashPlaybackInfo(thumbnailUrl = thumbUrl),
                    authorAvatarUrl = resolvedAvatarUrl,
                    availableQualities = availableQualities,
                    qualityStreams = emptyMap()
                )
            )
        }
        return result
    }
}
