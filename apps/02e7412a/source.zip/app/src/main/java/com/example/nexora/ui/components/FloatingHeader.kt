package com.example.nexora.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandHorizontally
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkHorizontally
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.ManageAccounts
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.RadioButtonChecked
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.Explore
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.RadioButtonChecked
import androidx.compose.material.icons.outlined.Shield
import androidx.compose.material.icons.outlined.VideoLibrary
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.BiasAlignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import com.example.nexora.data.CreatorProfile
import com.example.nexora.data.NavTab
import com.example.nexora.data.NotificationItem
import com.example.nexora.ui.modals.LocalSpatialCallController
import com.example.ui.theme.NexoraColors
import com.example.ui.theme.NexoraTypography
import com.example.ui.theme.liquidGlassAccent
import com.example.ui.theme.liquidGlassCard
import com.example.ui.theme.liquidGlassElevatedCapsule
import com.example.ui.theme.liquidGlassNav
import com.example.ui.theme.liquidGlassWhitePill
import kotlin.math.roundToInt

private val CANONICAL_NAV_TABS = listOf(
    NavTab.HOME,
    NavTab.EXPLORE,
    NavTab.LIVE,
    NavTab.MESSAGES,
    NavTab.PROFILE
)

/**
 * Icon-first Top Floating Pill Header:
 * - Left: Nexora prism icon
 * - Center (on wide screens): Fixed-order Icon Navigation Bar where long-press + drag slides the
 *   elevated transparent glass droplet across tabs to switch the active view
 * - Action Cluster: Compact Search icon/field, circular + Create icon button, Notifications Bell icon button.
 *   When the user enters the Profile tab (`activeTab == NavTab.PROFILE`), the action items smoothly
 *   shift to the left side and the Account Centre button slides in from the right (leftward slide animation).
 *   When the user leaves the Profile tab, the Account Centre button hides with the reverse animation
 *   and the header items smoothly return to the right side.
 */
@Composable
fun FloatingHeader(
    activeTab: NavTab,
    searchQuery: String,
    unreadNotificationCount: Int,
    unreadDmCount: Int = 0,
    ownStudioProfile: CreatorProfile,
    isOwnProfile: Boolean = true,
    isWideScreen: Boolean,
    onSelectTab: (NavTab) -> Unit,
    onSearchQueryChange: (String) -> Unit,
    onOpenUploadModal: () -> Unit,
    onOpenDmModal: () -> Unit = {},
    onToggleNotifications: () -> Unit,
    onOpenAdminModal: () -> Unit,
    onOpenAccountCentre: () -> Unit = onOpenAdminModal,
    onOpenOwnProfile: () -> Unit,
    onCaptureSlotOrigin: (Offset) -> Unit = {},
    modifier: Modifier = Modifier
) {
    var isSearchOpen by remember { mutableStateOf(false) }
    val showSearchField = isSearchOpen || searchQuery.isNotEmpty()
    val isProfileTab = activeTab == NavTab.PROFILE && isOwnProfile

    // Smoothly animates 0f (items at right edge) -> 1f (items shifted left by 46.dp) on own Profile tab,
    // and reverses 1f -> 0f when leaving own Profile tab or viewing another creator's profile.
    val profileShiftProgress by animateFloatAsState(
        targetValue = if (isProfileTab) 1f else 0f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioNoBouncy,
            stiffness = Spring.StiffnessMediumLow
        ),
        label = "header_profile_shift_progress"
    )

    val callController = LocalSpatialCallController.current
    val isCallMiniBarVisible = callController.activeCallThread != null && callController.isCallMinimized

    Box(
        modifier = modifier
            .fillMaxWidth()
            .then(
                if (isCallMiniBarVisible) Modifier
                else Modifier.windowInsetsPadding(WindowInsets.statusBars)
            )
            .padding(
                top = if (isWideScreen) (if (isCallMiniBarVisible) 2.dp else 10.dp) else 0.dp,
                bottom = if (isWideScreen) 6.dp else 0.dp,
                start = if (isWideScreen) 24.dp else 0.dp,
                end = if (isWideScreen) 24.dp else 0.dp
            ),
        contentAlignment = Alignment.Center
    ) {
        if (!isWideScreen) {
            // Authentic Instagram Mobile Top Bar: Pure Black (#000000), 1dp bottom border (#262626)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .background(Color(0xFF000000))
                    .drawBehind {
                        drawLine(
                            color = Color(0xFF262626),
                            start = Offset(0f, size.height),
                            end = Offset(size.width, size.height),
                            strokeWidth = 1.dp.toPx()
                        )
                    }
                    .padding(horizontal = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Left: Instagram script wordmark
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    modifier = Modifier
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null
                        ) { onSelectTab(NavTab.HOME) }
                        .testTag("header_brand_logo")
                ) {
                    Text(
                        text = "Instagram",
                        style = androidx.compose.ui.text.TextStyle(
                            fontFamily = androidx.compose.ui.text.font.FontFamily.Cursive,
                            fontWeight = FontWeight.Bold,
                            fontSize = 28.sp,
                            letterSpacing = (-0.5).sp,
                            color = Color.White
                        )
                    )
                    Icon(
                        imageVector = Icons.Filled.KeyboardArrowDown,
                        contentDescription = "Switch accounts or feeds",
                        tint = Color.White,
                        modifier = Modifier.size(16.dp)
                    )
                }

                // Right Action Cluster: Notifications (Heart) & DMs (Paper Airplane)
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    // Notifications Heart
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clickable(
                                interactionSource = remember { MutableInteractionSource() },
                                indication = null
                            ) { onToggleNotifications() }
                            .testTag("header_notifications_btn"),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (unreadNotificationCount > 0) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                            contentDescription = "Notifications",
                            tint = Color.White,
                            modifier = Modifier.size(24.dp)
                        )
                        if (unreadNotificationCount > 0) {
                            Box(
                                modifier = Modifier
                                    .align(Alignment.TopEnd)
                                    .padding(top = 4.dp, end = 4.dp)
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(NexoraColors.LiveRose)
                            )
                        }
                    }

                    // Direct Messages Paper Airplane
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clickable(
                                interactionSource = remember { MutableInteractionSource() },
                                indication = null
                            ) { onOpenDmModal() }
                            .testTag("header_dm_btn"),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Send,
                            contentDescription = "Direct Messages",
                            tint = Color.White,
                            modifier = Modifier.size(22.dp)
                        )
                        if (unreadDmCount > 0) {
                            Box(
                                modifier = Modifier
                                    .align(Alignment.TopEnd)
                                    .offset(x = 4.dp, y = (-2).dp)
                                    .clip(RoundedCornerShape(999.dp))
                                    .background(NexoraColors.LiveRose)
                                    .padding(horizontal = 4.dp, vertical = 1.dp)
                            ) {
                                Text(
                                    text = if (unreadDmCount > 99) "99+" else unreadDmCount.toString(),
                                    style = NexoraTypography.BadgeMicro.copy(
                                        color = Color.White,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                )
                            }
                        }
                    }
                }
            }
        } else {
            Row(
                modifier = Modifier
                    .widthIn(max = 1440.dp)
                    .fillMaxWidth()
                    .height(54.dp)
                    .liquidGlassNav(999.dp)
                    .padding(horizontal = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Left Brand Prism Icon (Icon-only)
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(999.dp))
                        .clickable { onSelectTab(NavTab.HOME) }
                        .padding(2.dp)
                        .testTag("header_brand_logo"),
                    contentAlignment = Alignment.Center
                ) {
                    NexoraPrismLogo(size = 36.dp)
                }

                // Center Icon-Only Navigation Pill Tabs (Desktop/Tablet >= 768.dp)
                SlideToSwitchHeaderNav(
                    activeTab = activeTab,
                    unreadDmCount = unreadDmCount,
                    ownStudioProfile = ownStudioProfile,
                    onSelectTab = onSelectTab,
                    onOpenOwnProfile = onOpenOwnProfile,
                    onCaptureSlotOrigin = onCaptureSlotOrigin
                )

                // Wide-Screen Action Cluster + Account Centre Button
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    HeaderActionClusterItems(
                        showSearchField = showSearchField,
                        searchQuery = searchQuery,
                        unreadNotificationCount = unreadNotificationCount,
                        isWideScreen = true,
                        isProfileTab = isProfileTab,
                        onOpenSearch = { isSearchOpen = true },
                        onCloseSearch = {
                            onSearchQueryChange("")
                            isSearchOpen = false
                        },
                        onSearchFocusLost = {
                            if (searchQuery.isEmpty()) isSearchOpen = false
                        },
                        onSearchQueryChange = onSearchQueryChange,
                        onOpenUploadModal = onOpenUploadModal,
                        onToggleNotifications = onToggleNotifications
                    )

                    AnimatedVisibility(
                        visible = isProfileTab,
                        enter = slideInHorizontally(
                            animationSpec = spring(
                                dampingRatio = Spring.DampingRatioNoBouncy,
                                stiffness = Spring.StiffnessMediumLow
                            ),
                            initialOffsetX = { fullWidth -> fullWidth + 48 }
                        ) + expandHorizontally(
                            expandFrom = Alignment.Start,
                            animationSpec = spring(
                                dampingRatio = Spring.DampingRatioNoBouncy,
                                stiffness = Spring.StiffnessMediumLow
                            )
                        ) + fadeIn(animationSpec = tween(220)),
                        exit = slideOutHorizontally(
                            animationSpec = spring(
                                dampingRatio = Spring.DampingRatioNoBouncy,
                                stiffness = Spring.StiffnessMediumLow
                            ),
                            targetOffsetX = { fullWidth -> fullWidth + 48 }
                        ) + shrinkHorizontally(
                            shrinkTowards = Alignment.Start,
                            animationSpec = spring(
                                dampingRatio = Spring.DampingRatioNoBouncy,
                                stiffness = Spring.StiffnessMediumLow
                            )
                        ) + fadeOut(animationSpec = tween(180))
                    ) {
                        AccountCentreHeaderButton(
                            compactIconOnly = false,
                            onClick = onOpenAccountCentre
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun HeaderActionClusterItems(
    showSearchField: Boolean,
    searchQuery: String,
    unreadNotificationCount: Int,
    isWideScreen: Boolean,
    isProfileTab: Boolean,
    onOpenSearch: () -> Unit,
    onCloseSearch: () -> Unit,
    onSearchFocusLost: () -> Unit,
    onSearchQueryChange: (String) -> Unit,
    onOpenUploadModal: () -> Unit,
    onToggleNotifications: () -> Unit
) {
    val searchFocusRequester = remember { FocusRequester() }
    val focusManager = LocalFocusManager.current
    val keyboardController = LocalSoftwareKeyboardController.current
    var hasGainedFocus by remember { mutableStateOf(false) }

    LaunchedEffect(showSearchField) {
        if (showSearchField) {
            hasGainedFocus = false
            runCatching {
                searchFocusRequester.requestFocus()
                keyboardController?.show()
            }
        } else {
            hasGainedFocus = false
        }
    }

    if (showSearchField) {
        val searchFieldWidth = when {
            isWideScreen -> 220.dp
            isProfileTab -> 136.dp
            else -> 176.dp
        }
        Row(
            modifier = Modifier
                .width(searchFieldWidth)
                .height(38.dp)
                .liquidGlassWhitePill(999.dp)
                .clickable {
                    runCatching {
                        searchFocusRequester.requestFocus()
                        keyboardController?.show()
                    }
                }
                .padding(horizontal = 12.dp)
                .testTag("header_search_pill"),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Filled.Search,
                contentDescription = "Search",
                tint = NexoraColors.InkMuted,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            BasicTextField(
                value = searchQuery,
                onValueChange = onSearchQueryChange,
                singleLine = true,
                textStyle = NexoraTypography.NavPillLabel.copy(color = NexoraColors.InkPrimary),
                cursorBrush = SolidColor(NexoraColors.InkAccent),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(
                    onSearch = {
                        keyboardController?.hide()
                        focusManager.clearFocus()
                    }
                ),
                modifier = Modifier
                    .weight(1f)
                    .focusRequester(searchFocusRequester)
                    .onFocusChanged { focusState ->
                        if (focusState.isFocused) {
                            hasGainedFocus = true
                        } else if (hasGainedFocus) {
                            onSearchFocusLost()
                        }
                    }
                    .testTag("search_input_field"),
                decorationBox = { innerTextField ->
                    Box(contentAlignment = Alignment.CenterStart) {
                        if (searchQuery.isEmpty()) {
                            Text(
                                text = "Search...",
                                style = NexoraTypography.NavPillLabel.copy(
                                    color = NexoraColors.InkMuted
                                ),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        innerTextField()
                    }
                }
            )
            Spacer(modifier = Modifier.width(4.dp))
            Box(
                modifier = Modifier
                    .size(22.dp)
                    .clip(CircleShape)
                    .clickable {
                        onCloseSearch()
                        keyboardController?.hide()
                        focusManager.clearFocus()
                    }
                    .testTag("clear_search_button"),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Filled.Close,
                    contentDescription = "Clear search",
                    tint = NexoraColors.InkSecondary,
                    modifier = Modifier.size(15.dp)
                )
            }
        }
    } else {
        Box(
            modifier = Modifier
                .size(38.dp)
                .liquidGlassWhitePill(999.dp)
                .clickable { onOpenSearch() }
                .testTag("header_search_pill"),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Filled.Search,
                contentDescription = "Search",
                tint = NexoraColors.InkPrimary,
                modifier = Modifier.size(18.dp)
            )
        }
    }

    // Create / Upload Icon Button (38.dp circular accent button)
    Box(
        modifier = Modifier
            .size(38.dp)
            .liquidGlassAccent(999.dp)
            .clickable { onOpenUploadModal() }
            .testTag("header_create_button"),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = Icons.Filled.Add,
            contentDescription = "Create",
            tint = NexoraColors.InkAccent,
            modifier = Modifier.size(19.dp)
        )
    }

    // Notifications Bell Icon Button
    Box(
        modifier = Modifier
            .size(38.dp)
            .liquidGlassWhitePill(999.dp)
            .clickable { onToggleNotifications() }
            .testTag("header_notifications_button"),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = if (unreadNotificationCount > 0) Icons.Filled.Notifications else Icons.Outlined.Notifications,
            contentDescription = "Notifications",
            tint = NexoraColors.InkPrimary,
            modifier = Modifier.size(18.dp)
        )
        if (unreadNotificationCount > 0) {
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(top = 7.dp, end = 7.dp)
                    .size(8.dp)
                    .clip(CircleShape)
                    .background(NexoraColors.LiveRose)
            )
        }
    }
}

@Composable
private fun AccountCentreHeaderButton(
    compactIconOnly: Boolean = true,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .size(38.dp)
            .liquidGlassAccent(999.dp)
            .border(
                width = 1.2.dp,
                brush = Brush.linearGradient(
                    colors = listOf(
                        NexoraColors.Lavender500.copy(alpha = 0.85f),
                        NexoraColors.Sky400.copy(alpha = 0.85f)
                    )
                ),
                shape = RoundedCornerShape(999.dp)
            )
            .clickable { onClick() }
            .testTag("header_account_centre_button"),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = Icons.Filled.ManageAccounts,
            contentDescription = "Account Centre",
            tint = NexoraColors.InkAccent,
            modifier = Modifier.size(18.dp)
        )
    }
}

/**
 * Wide-screen Center Navigation Pill Row:
 * Fixed tab positions (Home, Explore, Live, Library, Profile).
 * Single-tap switches tab immediately.
 * Long-press lifts the active glass pill into an elevated transparent liquid-glass lens that the
 * user drags across slots and drops to switch the active tab!
 */
@Composable
private fun SlideToSwitchHeaderNav(
    activeTab: NavTab,
    unreadDmCount: Int,
    ownStudioProfile: CreatorProfile,
    onSelectTab: (NavTab) -> Unit,
    onOpenOwnProfile: () -> Unit,
    onCaptureSlotOrigin: (Offset) -> Unit
) {
    val density = LocalDensity.current
    val haptic = LocalHapticFeedback.current
    val slotWidthDp = 48.dp
    val spacingDp = 6.dp
    val slotWidthPx = with(density) { slotWidthDp.toPx() }
    val slotStepPx = with(density) { (slotWidthDp + spacingDp).toPx() }

    val activeIndex = CANONICAL_NAV_TABS.indexOf(activeTab).coerceAtLeast(0)
    var isDraggingLens by remember { mutableStateOf(false) }
    var dragLensCenterPx by remember { mutableFloatStateOf(0f) }
    var hoveredTab by remember { mutableStateOf<NavTab?>(null) }
    var rowRootOffset by remember { mutableStateOf(Offset.Zero) }
    var rowHeightPx by remember { mutableFloatStateOf(0f) }

    val currentOnSelectTab by rememberUpdatedState(onSelectTab)
    val currentOnOpenOwnProfile by rememberUpdatedState(onOpenOwnProfile)
    val currentOnCaptureSlotOrigin by rememberUpdatedState(onCaptureSlotOrigin)
    val currentActiveTab by rememberUpdatedState(activeTab)

    // Target X offset for the sliding glass indicator pill
    val maxLensX = (CANONICAL_NAV_TABS.size - 1) * slotStepPx
    val targetIndicatorX = if (isDraggingLens) {
        (dragLensCenterPx - slotWidthPx * 0.5f).coerceIn(0f, maxLensX)
    } else {
        activeIndex * slotStepPx
    }

    val animatedIndicatorX by animateFloatAsState(
        targetValue = targetIndicatorX,
        animationSpec = if (isDraggingLens) {
            spring(dampingRatio = 0.82f, stiffness = 900f)
        } else {
            spring(dampingRatio = 0.68f, stiffness = 420f)
        },
        label = "header_lens_x"
    )

    val lensScaleX by animateFloatAsState(
        targetValue = if (isDraggingLens) 1.22f else 1.0f,
        animationSpec = spring(dampingRatio = 0.60f, stiffness = 440f),
        label = "header_lens_scale_x"
    )
    val lensScaleY by animateFloatAsState(
        targetValue = if (isDraggingLens) 1.26f else 1.0f,
        animationSpec = spring(dampingRatio = 0.60f, stiffness = 440f),
        label = "header_lens_scale_y"
    )
    val lensLiftY by animateFloatAsState(
        targetValue = if (isDraggingLens) with(density) { -4.dp.toPx() } else 0f,
        animationSpec = spring(dampingRatio = 0.65f, stiffness = 440f),
        label = "header_lens_lift"
    )
    val lensHaloAlpha by animateFloatAsState(
        targetValue = if (isDraggingLens) 1f else 0f,
        animationSpec = spring(stiffness = Spring.StiffnessMedium),
        label = "header_lens_halo"
    )

    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(999.dp))
            .background(NexoraColors.Pearl200)
            .padding(4.dp)
            .onGloballyPositioned { coords ->
                rowRootOffset = coords.positionInRoot()
                rowHeightPx = coords.size.height.toFloat()
            }
            .pointerInput(Unit) {
                detectDragGesturesAfterLongPress(
                    onDragStart = { startOffset ->
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        isDraggingLens = true
                        dragLensCenterPx = startOffset.x
                        val idx = ((startOffset.x - slotWidthPx * 0.5f) / slotStepPx)
                            .roundToInt()
                            .coerceIn(0, CANONICAL_NAV_TABS.lastIndex)
                        hoveredTab = CANONICAL_NAV_TABS[idx]
                    },
                    onDrag = { change, dragAmount ->
                        change.consume()
                        dragLensCenterPx += dragAmount.x
                        val idx = ((dragLensCenterPx - slotWidthPx * 0.5f) / slotStepPx)
                            .roundToInt()
                            .coerceIn(0, CANONICAL_NAV_TABS.lastIndex)
                        val candidate = CANONICAL_NAV_TABS[idx]
                        if (candidate != hoveredTab) {
                            hoveredTab = candidate
                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            // Update pointer origin to the hovered slot center & switch tab live!
                            val slotCenterRoot = Offset(
                                x = rowRootOffset.x + idx * slotStepPx + slotWidthPx * 0.5f,
                                y = rowRootOffset.y + rowHeightPx * 0.5f
                            )
                            currentOnCaptureSlotOrigin(slotCenterRoot)
                            if (candidate == NavTab.PROFILE) {
                                currentOnOpenOwnProfile()
                            } else if (candidate != currentActiveTab) {
                                currentOnSelectTab(candidate)
                            }
                        }
                    },
                    onDragEnd = {
                        val finalTab = hoveredTab
                        if (finalTab != null) {
                            val idx = CANONICAL_NAV_TABS.indexOf(finalTab).coerceAtLeast(0)
                            val slotCenterRoot = Offset(
                                x = rowRootOffset.x + idx * slotStepPx + slotWidthPx * 0.5f,
                                y = rowRootOffset.y + rowHeightPx * 0.5f
                            )
                            currentOnCaptureSlotOrigin(slotCenterRoot)
                            if (finalTab == NavTab.PROFILE) {
                                currentOnOpenOwnProfile()
                            } else if (finalTab != currentActiveTab) {
                                currentOnSelectTab(finalTab)
                            }
                        }
                        isDraggingLens = false
                        hoveredTab = null
                    },
                    onDragCancel = {
                        isDraggingLens = false
                        hoveredTab = null
                    }
                )
            }
    ) {
        // 1. Fixed Tab Icons Row
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(spacingDp)
        ) {
            CANONICAL_NAV_TABS.forEach { tab ->
                val isHighlighted = if (isDraggingLens) hoveredTab == tab else activeTab == tab
                FixedNavbarTabItem(
                    tab = tab,
                    isSelected = isHighlighted,
                    isLensHovering = isDraggingLens && hoveredTab == tab,
                    unreadDmCount = unreadDmCount,
                    ownStudioProfile = ownStudioProfile,
                    iconSize = 19.dp,
                    avatarSize = 28.dp,
                    testTag = if (tab == NavTab.PROFILE) "header_profile_avatar" else "nav_tab_${tab.name.lowercase()}",
                    onClick = {
                        if (tab == NavTab.PROFILE) onOpenOwnProfile() else onSelectTab(tab)
                    },
                    modifier = Modifier.size(width = slotWidthDp, height = 38.dp)
                )
            }
        }

        // 2. Sliding Transparent Glass Indicator Droplet (rests behind active tab, elevates into transparent lens on long-press drag)
        Box(
            modifier = Modifier
                .offset { IntOffset(animatedIndicatorX.roundToInt(), 0) }
                .size(width = slotWidthDp, height = 38.dp)
                .zIndex(if (isDraggingLens) 10f else 0f)
                .graphicsLayer {
                    translationY = lensLiftY
                    scaleX = lensScaleX
                    scaleY = lensScaleY
                }
                .drawBehind {
                    if (lensHaloAlpha > 0.01f) {
                        drawCircle(
                            brush = Brush.radialGradient(
                                colors = listOf(
                                    Color.White.copy(alpha = 0.34f * lensHaloAlpha),
                                    NexoraColors.Sky400.copy(alpha = 0.24f * lensHaloAlpha),
                                    NexoraColors.Lavender500.copy(alpha = 0.16f * lensHaloAlpha),
                                    Color.Transparent
                                ),
                                center = center,
                                radius = size.maxDimension * 0.78f
                            ),
                            radius = size.maxDimension * 0.78f,
                            center = center
                        )
                    }
                }
                .then(
                    if (isDraggingLens) {
                        Modifier.liquidGlassElevatedCapsule(999.dp)
                    } else {
                        Modifier.liquidGlassWhitePill(999.dp)
                    }
                )
        )
    }
}

/**
 * Mobile Floating Bottom Navigation Bar (< 768.dp):
 * Fixed icon order (Home, Explore, Live, Library, Profile).
 * Single-tap switches tab immediately.
 * Long-pressing lifts the active indicator into an ultra-transparent elevated glass droplet
 * that slides across tabs to switch views with spring physics!
 */
@Composable
fun MobileFloatingBottomNav(
    activeTab: NavTab,
    unreadDmCount: Int = 0,
    ownStudioProfile: CreatorProfile,
    onSelectTab: (NavTab) -> Unit,
    onOpenOwnProfile: () -> Unit,
    onCaptureSlotOrigin: (Offset) -> Unit = {},
    onOpenUploadModal: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val haptic = LocalHapticFeedback.current

    Box(
        modifier = modifier
            .fillMaxWidth()
            .background(Color(0xFF000000))
            .drawBehind {
                drawLine(
                    color = Color(0xFF262626),
                    start = Offset(0f, 0f),
                    end = Offset(size.width, 0f),
                    strokeWidth = 1.dp.toPx()
                )
            }
            .height(50.dp)
            .testTag("mobile_bottom_nav"),
        contentAlignment = Alignment.Center
    ) {
        Row(
            modifier = Modifier.fillMaxSize(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceAround
        ) {
            // 1. Home
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null
                    ) {
                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        onSelectTab(NavTab.HOME)
                    }
                    .testTag("bottom_nav_home"),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (activeTab == NavTab.HOME) Icons.Filled.Home else Icons.Outlined.Home,
                    contentDescription = "Home",
                    tint = Color.White,
                    modifier = Modifier.size(26.dp)
                )
            }

            // 2. Search / Explore
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null
                    ) {
                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        onSelectTab(NavTab.EXPLORE)
                    }
                    .testTag("bottom_nav_explore"),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Filled.Search,
                    contentDescription = "Search",
                    tint = if (activeTab == NavTab.EXPLORE) Color.White else Color(0xFFA8A8A8),
                    modifier = Modifier.size(26.dp)
                )
            }

            // 3. Create (+) - Square with plus inside
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null
                    ) {
                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        onOpenUploadModal()
                    }
                    .testTag("bottom_nav_create"),
                contentAlignment = Alignment.Center
            ) {
                Box(
                    modifier = Modifier
                        .size(26.dp)
                        .border(
                            width = 2.dp,
                            color = Color.White,
                            shape = RoundedCornerShape(8.dp)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Filled.Add,
                        contentDescription = "Create",
                        tint = Color.White,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            // 4. Reels / Live
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null
                    ) {
                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        onSelectTab(NavTab.LIVE)
                    }
                    .testTag("bottom_nav_live"),
                contentAlignment = Alignment.Center
            ) {
                PremiumShortVideoIcon(
                    isSelected = activeTab == NavTab.LIVE,
                    size = 24.dp
                )
            }

            // 5. Profile
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null
                    ) {
                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        onOpenOwnProfile()
                    }
                    .testTag("bottom_nav_profile"),
                contentAlignment = Alignment.Center
            ) {
                Box(
                    modifier = Modifier
                        .size(28.dp)
                        .clip(CircleShape)
                        .then(
                            if (activeTab == NavTab.PROFILE) {
                                Modifier.border(width = 2.dp, color = Color.White, shape = CircleShape)
                            } else Modifier
                        )
                        .padding(if (activeTab == NavTab.PROFILE) 2.dp else 0.dp),
                    contentAlignment = Alignment.Center
                ) {
                    CreatorAvatarBadge(
                        name = ownStudioProfile.name,
                        seed = ownStudioProfile.avatarSeed,
                        size = 24.dp,
                        borderWidth = 0.dp,
                        avatarUrl = ownStudioProfile.avatarUrl
                    )
                }
            }
        }
    }
}

/**
 * Individual fixed-position Navbar Tab Icon with subtle spring magnification when the
 * elevated transparent glass lens glides over it.
 */
@Composable
private fun FixedNavbarTabItem(
    tab: NavTab,
    isSelected: Boolean,
    isLensHovering: Boolean,
    unreadDmCount: Int = 0,
    ownStudioProfile: CreatorProfile,
    iconSize: Dp,
    avatarSize: Dp,
    testTag: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val iconScale by animateFloatAsState(
        targetValue = when {
            isLensHovering -> 1.18f
            isSelected -> 1.05f
            else -> 1.0f
        },
        animationSpec = spring(
            dampingRatio = 0.62f,
            stiffness = 460f
        ),
        label = "fixed_tab_icon_scale"
    )

    val infiniteTransition = rememberInfiniteTransition(label = "live_dot")
    val livePulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.45f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(850),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    val icon = when (tab) {
        NavTab.HOME -> if (isSelected) Icons.Filled.Home else Icons.Outlined.Home
        NavTab.EXPLORE -> if (isSelected) Icons.Filled.Explore else Icons.Outlined.Explore
        NavTab.LIVE -> if (isSelected) Icons.Filled.RadioButtonChecked else Icons.Outlined.RadioButtonChecked
        NavTab.MESSAGES -> if (isSelected) Icons.Filled.ChatBubble else Icons.Outlined.ChatBubbleOutline
        NavTab.LIBRARY -> if (isSelected) Icons.Filled.VideoLibrary else Icons.Outlined.VideoLibrary
        NavTab.PROFILE -> if (isSelected) Icons.Filled.Person else Icons.Outlined.Person
    }

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(999.dp))
            .clickable { onClick() }
            .graphicsLayer {
                scaleX = iconScale
                scaleY = iconScale
            }
            .testTag(testTag),
        contentAlignment = Alignment.Center
    ) {
        when (tab) {
            NavTab.LIVE -> {
                PremiumShortVideoIcon(
                    isSelected = isSelected,
                    size = iconSize + 3.dp
                )
            }
            NavTab.MESSAGES -> {
                PremiumChatIcon(
                    isSelected = isSelected,
                    unreadCount = unreadDmCount,
                    pulseAlpha = livePulseAlpha,
                    size = iconSize + 2.dp
                )
            }
            NavTab.PROFILE -> {
                CreatorAvatarBadge(
                    name = ownStudioProfile.name,
                    seed = ownStudioProfile.avatarSeed,
                    size = avatarSize,
                    borderWidth = if (isSelected) 2.dp else 1.2.dp,
                    showOnlineDot = true
                )
            }
            else -> {
                Icon(
                    imageVector = icon,
                    contentDescription = tab.label,
                    tint = if (isSelected) Color.White else NexoraColors.InkMuted,
                    modifier = Modifier.size(iconSize)
                )
            }
        }
    }
}

/**
 * Bespoke Multi-Layer Refractive Vector Short-Video (Spatial Clips / Reels) Icon:
 * Renders a tilted rear 9:16 glass card, a sculpted front rounded reel squircle with diagonal
 * cinema prism cuts, a top specular highlight arc, and a central play prism.
 */
@Composable
fun PremiumShortVideoIcon(
    isSelected: Boolean,
    size: Dp = 22.dp,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier.size(size),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = this.size.width
            val h = this.size.height
            val strokePx = w * 0.082f

            val activeWhiteBrush = Brush.linearGradient(
                colors = listOf(
                    Color.White,
                    Color(0xFFE5E5EA)
                ),
                start = Offset(0f, 0f),
                end = Offset(w, h)
            )
            val idleStrokeBrush = Brush.linearGradient(
                colors = listOf(
                    NexoraColors.InkSecondary,
                    NexoraColors.InkMuted
                ),
                start = Offset.Zero,
                end = Offset(w, h)
            )

            // 1. Rear Tilted 9:16 Portrait Glass Frame (creates layered spatial reel depth)
            val rearLeft = w * 0.28f
            val rearTop = h * 0.06f
            val rearW = w * 0.60f
            val rearH = h * 0.72f
            val rearCorner = rearW * 0.30f

            drawRoundRect(
                brush = if (isSelected) {
                    Brush.linearGradient(
                        colors = listOf(
                            Color.White.copy(alpha = 0.38f),
                            Color.White.copy(alpha = 0.22f)
                        )
                    )
                } else {
                    Brush.linearGradient(
                        colors = listOf(
                            NexoraColors.InkMuted.copy(alpha = 0.16f),
                            NexoraColors.InkMuted.copy(alpha = 0.08f)
                        )
                    )
                },
                topLeft = Offset(rearLeft, rearTop),
                size = Size(rearW, rearH),
                cornerRadius = CornerRadius(rearCorner, rearCorner)
            )
            drawRoundRect(
                color = if (isSelected) Color.White.copy(alpha = 0.65f) else NexoraColors.InkMuted.copy(alpha = 0.48f),
                topLeft = Offset(rearLeft, rearTop),
                size = Size(rearW, rearH),
                cornerRadius = CornerRadius(rearCorner, rearCorner),
                style = Stroke(width = strokePx * 0.80f)
            )

            // 2. Front Primary Sculpted Reel Squircle
            val frontLeft = w * 0.10f
            val frontTop = h * 0.16f
            val frontW = w * 0.70f
            val frontH = h * 0.76f
            val frontCorner = frontW * 0.30f

            if (isSelected) {
                drawRoundRect(
                    brush = activeWhiteBrush,
                    topLeft = Offset(frontLeft, frontTop),
                    size = Size(frontW, frontH),
                    cornerRadius = CornerRadius(frontCorner, frontCorner)
                )
            } else {
                drawRoundRect(
                    color = NexoraColors.Pearl200,
                    topLeft = Offset(frontLeft, frontTop),
                    size = Size(frontW, frontH),
                    cornerRadius = CornerRadius(frontCorner, frontCorner)
                )
                drawRoundRect(
                    brush = idleStrokeBrush,
                    topLeft = Offset(frontLeft, frontTop),
                    size = Size(frontW, frontH),
                    cornerRadius = CornerRadius(frontCorner, frontCorner),
                    style = Stroke(width = strokePx)
                )
            }

            // 3. Top Clapper Header Band & Diagonal Refractive Cuts
            val clapperBottomY = frontTop + frontH * 0.28f
            val detailColor = if (isSelected) NexoraColors.CanvasBase else NexoraColors.InkSecondary

            drawLine(
                color = detailColor.copy(alpha = if (isSelected) 0.85f else 0.65f),
                start = Offset(frontLeft + strokePx * 0.5f, clapperBottomY),
                end = Offset(frontLeft + frontW - strokePx * 0.5f, clapperBottomY),
                strokeWidth = strokePx * 0.78f,
                cap = StrokeCap.Round
            )

            // Two angled clapper slashes
            drawLine(
                color = detailColor,
                start = Offset(frontLeft + frontW * 0.34f, frontTop + strokePx * 0.6f),
                end = Offset(frontLeft + frontW * 0.24f, clapperBottomY - strokePx * 0.3f),
                strokeWidth = strokePx * 0.78f,
                cap = StrokeCap.Round
            )
            drawLine(
                color = detailColor,
                start = Offset(frontLeft + frontW * 0.68f, frontTop + strokePx * 0.6f),
                end = Offset(frontLeft + frontW * 0.58f, clapperBottomY - strokePx * 0.3f),
                strokeWidth = strokePx * 0.78f,
                cap = StrokeCap.Round
            )

            // 4. Central Play Prism Triangle in Lower Reel Stage
            val centerX = frontLeft + frontW * 0.52f
            val centerY = frontTop + frontH * 0.63f
            val triHalfH = frontH * 0.17f
            val triW = frontW * 0.28f

            val playPath = Path().apply {
                moveTo(centerX - triW * 0.45f, centerY - triHalfH)
                lineTo(centerX + triW * 0.58f, centerY)
                lineTo(centerX - triW * 0.45f, centerY + triHalfH)
                close()
            }
            drawPath(
                path = playPath,
                color = if (isSelected) NexoraColors.CanvasBase else NexoraColors.InkSecondary
            )
        }
    }
}

/**
 * Bespoke Multi-Layer Refractive Vector Chat Icon:
 * Renders overlapping sculpted glassmorphic chat bubbles with a crisp white fill when
 * active, a top specular highlight crescent, internal conversation wave lines, and a
 * luminous unread rose aura orb.
 */
@Composable
fun PremiumChatIcon(
    isSelected: Boolean,
    unreadCount: Int = 0,
    pulseAlpha: Float = 1f,
    size: Dp = 22.dp,
    modifier: Modifier = Modifier
) {
    val hasUnread = unreadCount > 0
    Box(
        modifier = modifier.size(size),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = this.size.width
            val h = this.size.height
            val strokePx = w * 0.082f

            val activeWhiteGradient = Brush.linearGradient(
                colors = listOf(
                    Color.White,
                    Color(0xFFE5E5EA)
                ),
                start = Offset(0f, 0f),
                end = Offset(w, h)
            )
            val mutedStrokeBrush = Brush.linearGradient(
                colors = listOf(
                    NexoraColors.InkSecondary,
                    NexoraColors.InkMuted
                ),
                start = Offset.Zero,
                end = Offset(w, h)
            )

            // 1. Rear Secondary Glass Bubble (top-right offset for spatial depth)
            drawRoundRect(
                brush = if (isSelected || hasUnread) {
                    Brush.linearGradient(
                        colors = listOf(
                            Color.White.copy(alpha = if (isSelected) 0.36f else 0.20f),
                            Color.White.copy(alpha = if (isSelected) 0.22f else 0.12f)
                        )
                    )
                } else {
                    Brush.linearGradient(
                        colors = listOf(
                            NexoraColors.InkMuted.copy(alpha = 0.16f),
                            NexoraColors.InkMuted.copy(alpha = 0.08f)
                        )
                    )
                },
                topLeft = Offset(w * 0.26f, h * 0.08f),
                size = Size(w * 0.66f, h * 0.50f),
                cornerRadius = CornerRadius(w * 0.22f, w * 0.22f)
            )
            drawRoundRect(
                color = if (isSelected) Color.White.copy(alpha = 0.65f) else NexoraColors.InkMuted.copy(alpha = 0.52f),
                topLeft = Offset(w * 0.26f, h * 0.08f),
                size = Size(w * 0.66f, h * 0.50f),
                cornerRadius = CornerRadius(w * 0.22f, w * 0.22f),
                style = Stroke(width = strokePx * 0.85f)
            )

            // 2. Front Primary Sculpted Chat Capsule + Tail Path
            val frontLeft = w * 0.07f
            val frontTop = h * 0.24f
            val frontRight = w * 0.78f
            val frontBottom = h * 0.78f
            val frontWidth = frontRight - frontLeft
            val frontHeight = frontBottom - frontTop
            val cornerR = frontHeight * 0.46f

            if (isSelected) {
                drawRoundRect(
                    brush = activeWhiteGradient,
                    topLeft = Offset(frontLeft, frontTop),
                    size = Size(frontWidth, frontHeight),
                    cornerRadius = CornerRadius(cornerR, cornerR)
                )
            } else {
                drawRoundRect(
                    color = NexoraColors.Pearl200,
                    topLeft = Offset(frontLeft, frontTop),
                    size = Size(frontWidth, frontHeight),
                    cornerRadius = CornerRadius(cornerR, cornerR)
                )
                drawRoundRect(
                    brush = if (hasUnread) activeWhiteGradient else mutedStrokeBrush,
                    topLeft = Offset(frontLeft, frontTop),
                    size = Size(frontWidth, frontHeight),
                    cornerRadius = CornerRadius(cornerR, cornerR),
                    style = Stroke(width = strokePx)
                )
            }

            // Sculpted bottom-left speech tail
            val tailPath = Path().apply {
                moveTo(frontLeft + frontWidth * 0.16f, frontBottom - strokePx * 0.3f)
                lineTo(frontLeft + frontWidth * 0.04f, h * 0.91f)
                lineTo(frontLeft + frontWidth * 0.36f, frontBottom - strokePx * 0.2f)
                close()
            }
            drawPath(
                path = tailPath,
                brush = if (isSelected || hasUnread) activeWhiteGradient else mutedStrokeBrush
            )

            // 3. Top Specular Highlight Arc inside Front Bubble
            drawLine(
                color = if (isSelected) NexoraColors.CanvasBase.copy(alpha = 0.25f) else Color.White.copy(alpha = 0.90f),
                start = Offset(frontLeft + frontWidth * 0.24f, frontTop + frontHeight * 0.22f),
                end = Offset(frontLeft + frontWidth * 0.62f, frontTop + frontHeight * 0.22f),
                strokeWidth = strokePx * 0.75f,
                cap = StrokeCap.Round
            )

            // 4. Dual Precision Conversation Wave Bars inside Front Bubble
            val lineColor = if (isSelected) NexoraColors.CanvasBase else if (hasUnread) Color.White else NexoraColors.InkSecondary
            drawLine(
                color = lineColor,
                start = Offset(frontLeft + frontWidth * 0.24f, frontTop + frontHeight * 0.46f),
                end = Offset(frontLeft + frontWidth * 0.76f, frontTop + frontHeight * 0.46f),
                strokeWidth = strokePx * 0.88f,
                cap = StrokeCap.Round
            )
            drawLine(
                color = lineColor.copy(alpha = 0.82f),
                start = Offset(frontLeft + frontWidth * 0.24f, frontTop + frontHeight * 0.68f),
                end = Offset(frontLeft + frontWidth * 0.56f, frontTop + frontHeight * 0.68f),
                strokeWidth = strokePx * 0.88f,
                cap = StrokeCap.Round
            )

            // 5. Luminous Unread Aura Orb (Top-Right)
            if (hasUnread) {
                val badgeCenter = Offset(w * 0.84f, h * 0.18f)
                drawCircle(
                    color = NexoraColors.LiveRose.copy(alpha = 0.38f * pulseAlpha),
                    radius = w * 0.21f,
                    center = badgeCenter
                )
                drawCircle(
                    color = NexoraColors.CanvasBase,
                    radius = w * 0.145f,
                    center = badgeCenter
                )
                drawCircle(
                    color = NexoraColors.LiveRose,
                    radius = w * 0.105f,
                    center = badgeCenter
                )
            }
        }
    }
}

@Composable
fun NexoraPrismLogo(
    size: Dp = 36.dp,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .size(size)
            .clip(RoundedCornerShape(11.dp))
            .background(
                Brush.linearGradient(
                    colors = listOf(
                        NexoraColors.InstagramSunsetAmber,
                        NexoraColors.InstagramSunsetPink,
                        NexoraColors.InstagramSunsetPurple,
                        NexoraColors.InstagramSunsetIndigo
                    ),
                    start = Offset.Zero,
                    end = Offset.Infinite
                )
            )
            .border(1.dp, NexoraColors.SpecularBorderSubtle, RoundedCornerShape(11.dp)),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(size * 0.52f)) {
            val w = this.size.width
            val h = this.size.height
            val playPath = Path().apply {
                moveTo(w * 0.18f, h * 0.12f)
                lineTo(w * 0.88f, h * 0.50f)
                lineTo(w * 0.18f, h * 0.88f)
                close()
            }
            drawPath(path = playPath, color = Color.White)
        }
    }
}

@Composable
fun NotificationsDropdownPanel(
    notifications: List<NotificationItem>,
    onMarkAllRead: () -> Unit,
    onNotificationClick: (NotificationItem) -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .widthIn(max = 320.dp)
            .fillMaxWidth()
            .liquidGlassCard(cornerRadius = 24.dp)
            .padding(12.dp)
            .testTag("notifications_dropdown_panel"),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Filled.Notifications,
                contentDescription = "Notifications",
                tint = NexoraColors.InkPrimary,
                modifier = Modifier.size(18.dp)
            )
            Row(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(28.dp)
                        .liquidGlassAccent(999.dp)
                        .clickable { onMarkAllRead() }
                        .testTag("mark_all_read_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Filled.DoneAll,
                        contentDescription = "Mark all read",
                        tint = NexoraColors.InkAccent,
                        modifier = Modifier.size(14.dp)
                    )
                }
                Box(
                    modifier = Modifier
                        .size(28.dp)
                        .liquidGlassWhitePill(999.dp)
                        .clickable { onClose() },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Filled.Close,
                        contentDescription = "Close",
                        tint = NexoraColors.InkSecondary,
                        modifier = Modifier.size(14.dp)
                    )
                }
            }
        }

        notifications.forEach { item ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(if (item.isUnread) NexoraColors.Pearl300 else NexoraColors.Pearl100)
                    .clickable { onNotificationClick(item) }
                    .padding(10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(7.dp)
                        .clip(CircleShape)
                        .background(
                            if (item.isUnread) NexoraColors.LiveRose else NexoraColors.InkMuted.copy(alpha = 0.3f)
                        )
                )
                Text(
                    text = item.subtitle,
                    style = NexoraTypography.NavPillLabel.copy(
                        fontWeight = if (item.isUnread) FontWeight.Bold else FontWeight.Medium,
                        color = NexoraColors.InkPrimary
                    ),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}
