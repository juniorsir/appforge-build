package com.example.nexora.ui.modals

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.nexora.animation.BubbleModalPanel
import com.example.nexora.animation.ClickOrigin
import com.example.nexora.data.DirectChatMessage
import com.example.nexora.data.DirectMessageThread
import com.example.nexora.data.SpatialPulseStory
import com.example.nexora.data.VisualThemePreset
import com.example.nexora.ui.components.CreatorAvatarBadge
import com.example.nexora.ui.components.PremiumChatIcon
import com.example.nexora.ui.components.SpatialVisualCanvas
import com.example.nexora.ui.components.VerifiedBadge
import com.example.ui.theme.NexoraColors
import com.example.ui.theme.NexoraTypography
import com.example.ui.theme.liquidGlassAccent
import com.example.ui.theme.liquidGlassCard
import com.example.ui.theme.liquidGlassDarkOverlay
import com.example.ui.theme.liquidGlassElevatedCapsule
import com.example.ui.theme.liquidGlassWhitePill

/**
 * Ephemeral Spatial Pulses (Stories) Orbital Ring Strip on the Home Feed:
 * Renders 100% circular (`CircleShape`) double-ring Liquid Glass creator portals with a
 * continuously rotating iridescent gradient halo, a live spatial canvas preview inside each
 * circular story ring, and a floating creator mini-avatar / "+" creation badge.
 */
@Composable
fun SpatialPulseRingBar(
    pulses: List<SpatialPulseStory>,
    onOpenPulse: (SpatialPulseStory) -> Unit,
    onCreatePulseClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse_halo_rotation")
    val haloRotationDeg by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 6400, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "halo_deg"
    )
    val haloGlowAlpha by infiniteTransition.animateFloat(
        initialValue = 0.52f,
        targetValue = 0.95f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1900, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "halo_glow"
    )

    LazyRow(
        modifier = modifier
            .fillMaxWidth()
            .testTag("spatial_pulse_ring_row"),
        horizontalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(vertical = 4.dp, horizontal = 2.dp)
    ) {
        items(pulses, key = { it.id }) { pulse ->
            val isOwnStudio = pulse.creatorId == "creator_aether"
            val previewPreset = pulse.slides.firstOrNull()?.preset ?: VisualThemePreset.NORDIC_PAVILION

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier
                    .width(78.dp)
                    .clickable { onOpenPulse(pulse) }
                    .testTag("pulse_capsule_${pulse.creatorId}")
            ) {
                Box(
                    modifier = Modifier.size(74.dp),
                    contentAlignment = Alignment.Center
                ) {
                    // 1. Circular Double-Ring Glass Portal with Animated Iridescent Gradient Halo
                    Box(
                        modifier = Modifier
                            .size(72.dp)
                            .drawBehind {
                                val r = size.minDimension / 2f
                                if (!pulse.isViewed) {
                                    // Soft outer ambient Instagram Sunset bloom
                                    drawCircle(
                                        brush = Brush.radialGradient(
                                            colors = listOf(
                                                NexoraColors.InstagramSunsetPink.copy(alpha = 0.28f * haloGlowAlpha),
                                                NexoraColors.InstagramSunsetAmber.copy(alpha = 0.18f * haloGlowAlpha),
                                                Color.Transparent
                                            ),
                                            center = center,
                                            radius = r * 1.16f
                                        ),
                                        radius = r * 1.16f,
                                        center = center
                                    )
                                    // Rotating sweep Instagram Sunset Gradient outer ring
                                    rotate(degrees = haloRotationDeg) {
                                        drawCircle(
                                            brush = Brush.sweepGradient(
                                                colors = listOf(
                                                    NexoraColors.InstagramSunsetAmber,
                                                    NexoraColors.InstagramSunsetPink,
                                                    NexoraColors.InstagramSunsetPurple,
                                                    NexoraColors.InstagramSunsetIndigo,
                                                    NexoraColors.InstagramSunsetAmber
                                                ),
                                                center = center
                                            ),
                                            radius = r - 1.5.dp.toPx(),
                                            center = center,
                                            style = Stroke(width = 2.8.dp.toPx())
                                        )
                                    }
                                } else {
                                    // Viewed dark charcoal ring (#363636 -> #262626)
                                    drawCircle(
                                        brush = Brush.linearGradient(
                                            colors = listOf(
                                                Color(0xFF363636),
                                                NexoraColors.Pearl300,
                                                Color(0xFF363636)
                                            )
                                        ),
                                        radius = r - 1.2.dp.toPx(),
                                        center = center,
                                        style = Stroke(width = 1.6.dp.toPx())
                                    )
                                }
                            }
                            .padding(3.5.dp)
                            .clip(CircleShape)
                            .background(NexoraColors.CanvasBase)
                            .border(1.2.dp, NexoraColors.SpecularBorderStrong, CircleShape)
                            .padding(2.5.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        // 2. Live Spatial Canvas Preview Inside Circular Story Ring
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .clip(CircleShape)
                                .drawWithContent {
                                    drawContent()
                                    // Glass sphere specular highlight crescent at top-left
                                    drawCircle(
                                        brush = Brush.linearGradient(
                                            colors = listOf(
                                                Color.White.copy(alpha = 0.52f),
                                                Color.White.copy(alpha = 0.10f),
                                                Color.Transparent
                                            ),
                                            start = Offset(0f, 0f),
                                            end = Offset(size.width * 0.65f, size.height * 0.65f)
                                        )
                                    )
                                }
                                .border(1.dp, Color.White.copy(alpha = 0.72f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            SpatialVisualCanvas(
                                preset = previewPreset,
                                isAnimated = true,
                                playbackPhase = (pulse.avatarSeed * 0.19f) % 1f
                            )
                        }
                    }

                    // 3. Top-Start Slide Count Micro Glass Pill (when multiple slides exist)
                    if (!pulse.isViewed && pulse.slides.size > 1) {
                        Box(
                            modifier = Modifier
                                .align(Alignment.TopStart)
                                .clip(CircleShape)
                                .background(
                                    Brush.linearGradient(
                                        colors = listOf(
                                            NexoraColors.ElectricIndigo,
                                            NexoraColors.Lavender500
                                        )
                                    )
                                )
                                .border(1.2.dp, Color.White, CircleShape)
                                .padding(horizontal = 5.5.dp, vertical = 1.dp)
                        ) {
                            Text(
                                text = "${pulse.slides.size}",
                                style = NexoraTypography.BadgeMicro.copy(
                                    fontSize = 8.5.sp,
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold
                                )
                            )
                        }
                    }

                    // 4. Bottom-End Floating Badge: "+" Add Pulse on Own Studio OR Creator Circular Mini-Avatar
                    if (isOwnStudio) {
                        Box(
                            modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .size(24.dp)
                                .liquidGlassAccent(999.dp)
                                .border(1.5.dp, Color.White, CircleShape)
                                .clickable { onCreatePulseClick() }
                                .testTag("add_pulse_button"),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Add,
                                contentDescription = "Add Spatial Pulse",
                                tint = NexoraColors.InkAccent,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                    } else {
                        Box(
                            modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .clip(CircleShape)
                                .background(Color.White)
                                .padding(1.2.dp)
                        ) {
                            CreatorAvatarBadge(
                                name = pulse.creatorName,
                                seed = pulse.avatarSeed,
                                size = 23.dp,
                                isSquircle = false,
                                borderWidth = 1.2.dp,
                                showOnlineDot = false
                            )
                        }
                    }
                }

                Text(
                    text = if (isOwnStudio) "Your Pulse" else pulse.creatorName.substringBefore(" "),
                    style = NexoraTypography.BadgeMicro.copy(
                        fontSize = 11.sp,
                        fontWeight = if (!pulse.isViewed) FontWeight.Bold else FontWeight.Medium,
                        color = if (!pulse.isViewed) NexoraColors.InkPrimary else NexoraColors.InkMuted
                    ),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

/**
 * Full-Screen Ephemeral Spatial Pulse (Story) Viewer Modal:
 * - Segmented auto-advancing liquid-glass progress bars
 * - Left/Right tap navigation across slides
 * - Quick emoji reaction pills & Direct Message reply input bar
 */
@Composable
fun SpatialPulseViewerModal(
    pulse: SpatialPulseStory?,
    origin: ClickOrigin,
    viewportSize: IntSize,
    onDismiss: () -> Unit,
    onCreatorClick: (String) -> Unit,
    onSendReply: (SpatialPulseStory, String) -> Unit
) {
    BubbleModalPanel(
        visible = pulse != null,
        origin = origin,
        viewportSize = viewportSize,
        onDismiss = onDismiss,
        modifier = Modifier
            .padding(14.dp)
            .widthIn(max = 500.dp)
            .fillMaxWidth()
    ) {
        val activePulse = pulse ?: return@BubbleModalPanel
        val slides = activePulse.slides
        var currentSlideIdx by remember(activePulse.id) { mutableIntStateOf(0) }
        val safeIdx = currentSlideIdx.coerceIn(0, (slides.size - 1).coerceAtLeast(0))
        val activeSlide = slides.getOrNull(safeIdx) ?: return@BubbleModalPanel

        var replyText by remember(activePulse.id) { mutableStateOf("") }
        val slideProgress = remember(activePulse.id, safeIdx) { Animatable(0f) }

        LaunchedEffect(activePulse.id, safeIdx) {
            slideProgress.snapTo(0f)
            slideProgress.animateTo(
                targetValue = 1f,
                animationSpec = tween(durationMillis = 5200, easing = LinearEasing)
            )
            if (safeIdx < slides.lastIndex) {
                currentSlideIdx = safeIdx + 1
            } else {
                onDismiss()
            }
        }

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(600.dp)
                .liquidGlassCard(cornerRadius = 30.dp)
                .padding(8.dp)
                .testTag("spatial_pulse_viewer_modal")
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .clip(RoundedCornerShape(24.dp))
                    .pointerInput(activePulse.id, safeIdx) {
                        detectTapGestures { offset ->
                            if (offset.x < size.width * 0.36f) {
                                if (safeIdx > 0) {
                                    currentSlideIdx = safeIdx - 1
                                }
                            } else {
                                if (safeIdx < slides.lastIndex) {
                                    currentSlideIdx = safeIdx + 1
                                } else {
                                    onDismiss()
                                }
                            }
                        }
                    }
            ) {
                SpatialVisualCanvas(
                    preset = activeSlide.preset,
                    isAnimated = true,
                    playbackPhase = 0.35f + safeIdx * 0.25f
                )

                // Top & Bottom Cinematic Legibility Gradient
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(
                                    Color(0xAA0F172A),
                                    Color.Transparent,
                                    Color.Transparent,
                                    Color(0xCC0F172A)
                                )
                            )
                        )
                )

                // Top Bar: Segmented Liquid-Glass Progress Bars + Creator Header + Close Button
                Column(
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        slides.forEachIndexed { idx, _ ->
                            val fillFrac = when {
                                idx < safeIdx -> 1f
                                idx == safeIdx -> slideProgress.value
                                else -> 0f
                            }
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(3.5.dp)
                                    .clip(RoundedCornerShape(999.dp))
                                    .background(Color.White.copy(alpha = 0.32f))
                            ) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth(fillFrac)
                                        .fillMaxHeight()
                                        .background(Color.White)
                                )
                            }
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.clickable {
                                onDismiss()
                                onCreatorClick(activePulse.creatorId)
                            }
                        ) {
                            CreatorAvatarBadge(
                                name = activePulse.creatorName,
                                seed = activePulse.avatarSeed,
                                size = 34.dp
                            )
                            Column {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Text(
                                        text = activePulse.creatorName,
                                        style = NexoraTypography.NavPillLabel.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = Color.White
                                        )
                                    )
                                    VerifiedBadge(size = 13.dp)
                                }
                                Text(
                                    text = activeSlide.timestamp,
                                    style = NexoraTypography.BadgeMicro.copy(
                                        fontSize = 10.sp,
                                        color = Color.White.copy(alpha = 0.78f)
                                    )
                                )
                            }
                        }

                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .liquidGlassDarkOverlay(999.dp)
                                .clickable { onDismiss() }
                                .testTag("pulse_viewer_close_btn"),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Close,
                                contentDescription = "Close Pulse",
                                tint = Color.White,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }

                // Bottom Overlay: Slide Caption + Quick Glass Reactions + Direct Reply Bar
                Column(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .liquidGlassDarkOverlay(16.dp)
                            .padding(horizontal = 12.dp, vertical = 8.dp)
                    ) {
                        Text(
                            text = activeSlide.caption,
                            style = NexoraTypography.NavPillLabel.copy(color = Color.White),
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Reply Input Pill
                        Row(
                            modifier = Modifier
                                .weight(1f)
                                .height(40.dp)
                                .liquidGlassElevatedCapsule(999.dp)
                                .padding(horizontal = 14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            BasicTextField(
                                value = replyText,
                                onValueChange = { replyText = it },
                                singleLine = true,
                                textStyle = NexoraTypography.NavPillLabel.copy(color = Color.White),
                                cursorBrush = SolidColor(Color.White),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("pulse_reply_input"),
                                decorationBox = { innerTextField ->
                                    if (replyText.isEmpty()) {
                                        Text(
                                            text = "Reply...",
                                            style = NexoraTypography.NavPillLabel.copy(
                                                color = Color.White.copy(alpha = 0.72f)
                                            )
                                        )
                                    }
                                    innerTextField()
                                }
                            )
                            if (replyText.isNotBlank()) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.Send,
                                    contentDescription = "Send Reply",
                                    tint = Color.White,
                                    modifier = Modifier
                                        .size(17.dp)
                                        .clickable {
                                            onSendReply(activePulse, replyText)
                                            replyText = ""
                                        }
                                )
                            }
                        }

                        // Quick Emoji Reaction Capsules
                        listOf("🔥", "👏", "❤️", "🚀", "✨").forEach { reactionEmoji ->
                            Box(
                                modifier = Modifier
                                    .size(38.dp)
                                    .liquidGlassElevatedCapsule(999.dp)
                                    .clickable {
                                        onSendReply(activePulse, reactionEmoji)
                                    }
                                    .testTag("pulse_reaction_$reactionEmoji"),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(text = reactionEmoji, fontSize = 17.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * Direct Messages ("Spatial Direct") Glass Modal Drawer:
 * Opens from the header chat icon with two-stage Spatial Inbox & Dedicated Conversation View,
 * Status Orbs, Smart Filter Pills, Quick-Switch Creator Dock, Voice Waves, Spatial Scenes, and Infinite GIF Studio.
 */
@Composable
fun DirectMessagesModal(
    visible: Boolean,
    threads: List<DirectMessageThread>,
    activeCreatorId: String,
    origin: ClickOrigin,
    viewportSize: IntSize,
    onDismiss: () -> Unit,
    onSelectThread: (String) -> Unit,
    onSendMessage: (creatorId: String, text: String, sharedPreset: VisualThemePreset?) -> Unit,
    onOpenCreatorProfile: (String) -> Unit,
    isConversationOpen: Boolean = false,
    onConversationStateChange: ((Boolean) -> Unit)? = null
) {
    BubbleModalPanel(
        visible = visible,
        origin = origin,
        viewportSize = viewportSize,
        onDismiss = onDismiss,
        modifier = Modifier
            .padding(16.dp)
            .widthIn(max = 620.dp)
            .fillMaxWidth()
    ) {
        SpatialDirectMessagesExperience(
            threads = threads,
            activeCreatorId = activeCreatorId,
            isModalCompact = true,
            onSelectThread = onSelectThread,
            onSendMessage = onSendMessage,
            onOpenCreatorProfile = { creatorId ->
                onDismiss()
                onOpenCreatorProfile(creatorId)
            },
            onCloseModal = onDismiss,
            isConversationOpen = isConversationOpen,
            onConversationStateChange = onConversationStateChange,
            modifier = Modifier.testTag("direct_messages_modal")
        )
    }
}

/**
 * Full-Stage Direct Messages ("Spatial Direct") View for Navbar Slot 4 (`NavTab.MESSAGES`):
 * Delivers an Instagram-fast yet Nexora-original two-stage Spatial Inbox & Conversation View
 * with Quick-Switch Creator Dock while smoothly hiding the floating top header and bottom nav
 * when a conversation is opened.
 */
@Composable
fun DirectMessagesStageView(
    threads: List<DirectMessageThread>,
    activeCreatorId: String,
    isConversationOpen: Boolean = false,
    onConversationStateChange: (Boolean) -> Unit = {},
    onSelectThread: (String) -> Unit,
    onSendMessage: (creatorId: String, text: String, sharedPreset: VisualThemePreset?) -> Unit,
    onOpenCreatorProfile: (String) -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler {
        if (isConversationOpen) {
            onConversationStateChange(false)
        } else {
            onBack()
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .testTag("direct_messages_stage_view"),
        contentAlignment = Alignment.TopCenter
    ) {
        SpatialDirectMessagesExperience(
            threads = threads,
            activeCreatorId = activeCreatorId,
            isModalCompact = false,
            onSelectThread = onSelectThread,
            onSendMessage = onSendMessage,
            onOpenCreatorProfile = onOpenCreatorProfile,
            onCloseModal = null,
            isConversationOpen = isConversationOpen,
            onConversationStateChange = onConversationStateChange,
            modifier = Modifier.fillMaxSize()
        )
    }
}



