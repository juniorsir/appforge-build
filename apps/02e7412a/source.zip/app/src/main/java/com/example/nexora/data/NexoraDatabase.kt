package com.example.nexora.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "saved_videos")
data class SavedVideoEntity(
    @PrimaryKey val videoId: String,
    val savedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "watch_history")
data class WatchHistoryEntity(
    @PrimaryKey val videoId: String,
    val progressFraction: Float,
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "playlists")
data class PlaylistEntity(
    @PrimaryKey val id: String,
    val title: String,
    val description: String,
    val isPublic: Boolean,
    val videoIdsCsv: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "uploaded_videos")
data class UploadedVideoEntity(
    @PrimaryKey val id: String,
    val title: String,
    val description: String,
    val category: String,
    val duration: String,
    val is4kHdr: Boolean,
    val visualPresetName: String,
    val carouselPresetsCsv: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "studio_profile")
data class StudioProfileEntity(
    @PrimaryKey val id: String = "creator_aether",
    val name: String,
    val handle: String,
    val category: String,
    val bio: String,
    val location: String,
    val website: String,
    val bannerPresetName: String
)

@Entity(tableName = "subscribed_studios")
data class SubscribedStudioEntity(
    @PrimaryKey val creatorId: String,
    val subscribedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "navbar_order")
data class NavbarOrderEntity(
    @PrimaryKey val id: String = "primary_nav",
    val tabOrderCsv: String,
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "liked_posts")
data class LikedPostEntity(
    @PrimaryKey val videoId: String,
    val likedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "reposted_posts")
data class RepostedPostEntity(
    @PrimaryKey val videoId: String,
    val repostedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "viewed_pulses")
data class ViewedPulseEntity(
    @PrimaryKey val pulseId: String,
    val viewedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "direct_messages")
data class DirectMessageEntity(
    @PrimaryKey val id: String,
    val creatorId: String,
    val senderName: String,
    val text: String,
    val timestamp: String,
    val isFromMe: Boolean,
    val sharedPresetName: String? = null,
    val createdAt: Long = System.currentTimeMillis()
)

@Dao
interface NexoraDao {
    @Query("SELECT * FROM saved_videos ORDER BY savedAt DESC")
    fun observeSavedVideos(): Flow<List<SavedVideoEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSavedVideo(entity: SavedVideoEntity)

    @Query("DELETE FROM saved_videos WHERE videoId = :videoId")
    suspend fun deleteSavedVideo(videoId: String)

    @Query("SELECT * FROM watch_history ORDER BY updatedAt DESC")
    fun observeWatchHistory(): Flow<List<WatchHistoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertWatchHistory(entity: WatchHistoryEntity)

    @Query("DELETE FROM watch_history")
    suspend fun clearWatchHistory()

    @Query("SELECT * FROM playlists ORDER BY createdAt DESC")
    fun observePlaylists(): Flow<List<PlaylistEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPlaylist(entity: PlaylistEntity)

    @Query("DELETE FROM playlists WHERE id = :playlistId")
    suspend fun deletePlaylist(playlistId: String)

    @Query("SELECT * FROM uploaded_videos ORDER BY createdAt DESC")
    fun observeUploadedVideos(): Flow<List<UploadedVideoEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUploadedVideo(entity: UploadedVideoEntity)

    @Query("SELECT * FROM studio_profile WHERE id = 'creator_aether' LIMIT 1")
    fun observeOwnStudioProfile(): Flow<StudioProfileEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertOwnStudioProfile(entity: StudioProfileEntity)

    @Query("SELECT * FROM subscribed_studios ORDER BY subscribedAt DESC")
    fun observeSubscribedStudios(): Flow<List<SubscribedStudioEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSubscribedStudio(entity: SubscribedStudioEntity)

    @Query("DELETE FROM subscribed_studios WHERE creatorId = :creatorId")
    suspend fun deleteSubscribedStudio(creatorId: String)

    @Query("SELECT * FROM navbar_order WHERE id = 'primary_nav' LIMIT 1")
    fun observeNavbarOrder(): Flow<NavbarOrderEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertNavbarOrder(entity: NavbarOrderEntity)

    @Query("SELECT * FROM liked_posts ORDER BY likedAt DESC")
    fun observeLikedPosts(): Flow<List<LikedPostEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLikedPost(entity: LikedPostEntity)

    @Query("DELETE FROM liked_posts WHERE videoId = :videoId")
    suspend fun deleteLikedPost(videoId: String)

    @Query("SELECT * FROM reposted_posts ORDER BY repostedAt DESC")
    fun observeRepostedPosts(): Flow<List<RepostedPostEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRepostedPost(entity: RepostedPostEntity)

    @Query("DELETE FROM reposted_posts WHERE videoId = :videoId")
    suspend fun deleteRepostedPost(videoId: String)

    @Query("SELECT * FROM viewed_pulses")
    fun observeViewedPulses(): Flow<List<ViewedPulseEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertViewedPulse(entity: ViewedPulseEntity)

    @Query("SELECT * FROM direct_messages ORDER BY createdAt ASC")
    fun observeDirectMessages(): Flow<List<DirectMessageEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDirectMessage(entity: DirectMessageEntity)
}

@Database(
    entities = [
        SavedVideoEntity::class,
        WatchHistoryEntity::class,
        PlaylistEntity::class,
        UploadedVideoEntity::class,
        StudioProfileEntity::class,
        SubscribedStudioEntity::class,
        NavbarOrderEntity::class,
        LikedPostEntity::class,
        RepostedPostEntity::class,
        ViewedPulseEntity::class,
        DirectMessageEntity::class
    ],
    version = 3,
    exportSchema = false
)
abstract class NexoraDatabase : RoomDatabase() {
    abstract fun nexoraDao(): NexoraDao

    companion object {
        @Volatile
        private var INSTANCE: NexoraDatabase? = null

        fun getInstance(context: Context): NexoraDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    NexoraDatabase::class.java,
                    "nexora_spatial_vault.db"
                )
                    .fallbackToDestructiveMigration(dropAllTables = true)
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}

class NexoraRepository(private val dao: NexoraDao) {
    val savedVideos: Flow<List<SavedVideoEntity>> = dao.observeSavedVideos()
    val watchHistory: Flow<List<WatchHistoryEntity>> = dao.observeWatchHistory()
    val playlists: Flow<List<PlaylistEntity>> = dao.observePlaylists()
    val uploadedVideos: Flow<List<UploadedVideoEntity>> = dao.observeUploadedVideos()
    val ownStudioProfile: Flow<StudioProfileEntity?> = dao.observeOwnStudioProfile()
    val subscribedStudios: Flow<List<SubscribedStudioEntity>> = dao.observeSubscribedStudios()
    val navbarOrder: Flow<NavbarOrderEntity?> = dao.observeNavbarOrder()
    val likedPosts: Flow<List<LikedPostEntity>> = dao.observeLikedPosts()
    val repostedPosts: Flow<List<RepostedPostEntity>> = dao.observeRepostedPosts()
    val viewedPulses: Flow<List<ViewedPulseEntity>> = dao.observeViewedPulses()
    val directMessages: Flow<List<DirectMessageEntity>> = dao.observeDirectMessages()

    suspend fun toggleSavedVideo(videoId: String, currentlySaved: Boolean) {
        if (currentlySaved) {
            dao.deleteSavedVideo(videoId)
        } else {
            dao.insertSavedVideo(SavedVideoEntity(videoId = videoId))
        }
    }

    suspend fun recordWatchProgress(
        videoId: String,
        progressFraction: Float,
        mediaType: String = "long_video"
    ): Boolean {
        val normalizedType = mediaType.trim().lowercase()
        if (normalizedType == "short" || normalizedType == "shorts" || videoId.startsWith("akash_")) {
            return false
        }
        dao.upsertWatchHistory(
            WatchHistoryEntity(
                videoId = videoId,
                progressFraction = progressFraction.coerceIn(0.05f, 1f)
            )
        )
        return true
    }

    suspend fun clearHistory() {
        dao.clearWatchHistory()
    }

    suspend fun savePlaylist(playlist: Playlist) {
        dao.insertPlaylist(
            PlaylistEntity(
                id = playlist.id,
                title = playlist.title,
                description = playlist.description,
                isPublic = playlist.isPublic,
                videoIdsCsv = playlist.videoIds.joinToString(","),
                createdAt = playlist.createdAt
            )
        )
    }

    suspend fun deletePlaylist(playlistId: String) {
        dao.deletePlaylist(playlistId)
    }

    suspend fun addVideoToPlaylist(playlist: Playlist, videoId: String) {
        if (videoId !in playlist.videoIds) {
            val updated = playlist.copy(videoIds = playlist.videoIds + videoId)
            savePlaylist(updated)
        }
    }

    suspend fun insertUploadedVideo(entity: UploadedVideoEntity) {
        dao.insertUploadedVideo(entity)
    }

    suspend fun updateOwnStudioProfile(profile: CreatorProfile) {
        dao.upsertOwnStudioProfile(
            StudioProfileEntity(
                id = "creator_aether",
                name = profile.name,
                handle = profile.handle,
                category = profile.category,
                bio = profile.bio,
                location = profile.location,
                website = profile.website,
                bannerPresetName = profile.bannerPreset.name
            )
        )
    }

    suspend fun toggleSubscription(creatorId: String, currentlySubscribed: Boolean) {
        if (currentlySubscribed) {
            dao.deleteSubscribedStudio(creatorId)
        } else {
            dao.insertSubscribedStudio(SubscribedStudioEntity(creatorId = creatorId))
        }
    }

    suspend fun saveNavbarOrder(tabs: List<NavTab>) {
        dao.upsertNavbarOrder(
            NavbarOrderEntity(
                id = "primary_nav",
                tabOrderCsv = tabs.joinToString(",") { it.name }
            )
        )
    }

    suspend fun setPostLiked(videoId: String, liked: Boolean) {
        if (liked) {
            dao.insertLikedPost(LikedPostEntity(videoId = videoId))
        } else {
            dao.deleteLikedPost(videoId)
        }
    }

    suspend fun setPostReposted(videoId: String, reposted: Boolean) {
        if (reposted) {
            dao.insertRepostedPost(RepostedPostEntity(videoId = videoId))
        } else {
            dao.deleteRepostedPost(videoId)
        }
    }

    suspend fun markPulseViewed(pulseId: String) {
        dao.insertViewedPulse(ViewedPulseEntity(pulseId = pulseId))
    }

    suspend fun insertDirectMessage(entity: DirectMessageEntity) {
        dao.insertDirectMessage(entity)
    }
}

data class ShortDbRecord(
    val id: Long,
    val fileCode: String,
    val viewsCount: Long,
    val simulatedViews: Long,
    val likesCount: Long = 0,
    val sharesCount: Long = 0,
    val soundTitle: String = "Original Audio",
    val soundAuthor: String = "",
    val createdAt: String,
    val uploadedAt: String,
    val hlsMasterPath: String,
    val availableQualitiesJson: String
)

data class WatchProgressResult(
    val savedHistory: Boolean,
    val reason: String? = null
)

/**
 * Sovereign User Vault Interaction Storage (`user_vault.db`)
 * - Enforces WAL mode, NORMAL synchronous level, foreign keys, and 5000ms busy_timeout.
 * - Strictly disables watch history for `media_type in ('short', 'shorts')`.
 */
class UserVaultSqLiteDatabase private constructor(context: Context) :
    android.database.sqlite.SQLiteOpenHelper(context.applicationContext, DATABASE_NAME, null, DATABASE_VERSION) {

    override fun onConfigure(db: android.database.sqlite.SQLiteDatabase) {
        super.onConfigure(db)
        db.enableWriteAheadLogging()
        db.setForeignKeyConstraintsEnabled(true)
        runCatching {
            db.rawQuery("PRAGMA synchronous=NORMAL;", null).close()
            db.rawQuery("PRAGMA busy_timeout=5000;", null).close()
        }
    }

    override fun onCreate(db: android.database.sqlite.SQLiteDatabase) {
        ensureSchema(db)
    }

    override fun onUpgrade(
        db: android.database.sqlite.SQLiteDatabase,
        oldVersion: Int,
        newVersion: Int
    ) {
        ensureSchema(db)
    }

    private fun ensureSchema(db: android.database.sqlite.SQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS user_likes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                uid TEXT NOT NULL,
                file_code TEXT NOT NULL,
                media_type TEXT NOT NULL DEFAULT 'short' CHECK(media_type IN ('short', 'long_video', 'photo')),
                liked_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(uid, file_code)
            );
            """.trimIndent()
        )
        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS user_saved (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                uid TEXT NOT NULL,
                file_code TEXT NOT NULL,
                media_type TEXT NOT NULL DEFAULT 'short' CHECK(media_type IN ('short', 'long_video', 'photo')),
                saved_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(uid, file_code)
            );
            """.trimIndent()
        )
        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS user_comments (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                uid TEXT NOT NULL,
                file_code TEXT NOT NULL,
                media_type TEXT NOT NULL DEFAULT 'short' CHECK(media_type IN ('short', 'long_video', 'photo')),
                comment_text TEXT NOT NULL CHECK(length(trim(comment_text)) BETWEEN 1 AND 500),
                created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
            );
            """.trimIndent()
        )
        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS user_watch_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                uid TEXT NOT NULL,
                file_code TEXT NOT NULL,
                media_type TEXT NOT NULL CHECK(media_type NOT IN ('short', 'shorts')),
                progress_seconds REAL NOT NULL DEFAULT 0.0,
                duration_seconds REAL NOT NULL DEFAULT 0.0,
                updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(uid, file_code)
            );
            """.trimIndent()
        )
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_user_likes_file_code ON user_likes(file_code);")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_user_saved_uid_saved_at ON user_saved(uid, saved_at DESC);")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_user_comments_file_created ON user_comments(file_code, created_at DESC);")
    }

    fun recordProgress(
        uid: String,
        fileCode: String,
        mediaType: String,
        progressSeconds: Double,
        durationSeconds: Double
    ): WatchProgressResult {
        val normalizedType = mediaType.trim().lowercase()
        if (normalizedType == "short" || normalizedType == "shorts") {
            return WatchProgressResult(savedHistory = false, reason = "watch_history_disabled_for_shorts")
        }
        val db = writableDatabase
        db.execSQL(
            """
            INSERT INTO user_watch_history (uid, file_code, media_type, progress_seconds, duration_seconds, updated_at)
            VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
            ON CONFLICT(uid, file_code) DO UPDATE SET
                progress_seconds = excluded.progress_seconds,
                duration_seconds = excluded.duration_seconds,
                updated_at = CURRENT_TIMESTAMP;
            """.trimIndent(),
            arrayOf<Any>(uid, fileCode, normalizedType, progressSeconds.coerceAtLeast(0.0), durationSeconds.coerceAtLeast(0.0))
        )
        return WatchProgressResult(savedHistory = true)
    }

    companion object {
        const val DATABASE_NAME = "user_vault.db"
        private const val DATABASE_VERSION = 1

        @Volatile
        private var INSTANCE: UserVaultSqLiteDatabase? = null

        fun getInstance(context: Context): UserVaultSqLiteDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: UserVaultSqLiteDatabase(context).also { INSTANCE = it }
            }
        }
    }
}

/**
 * Connected SQLite database (`shorts.db`) executing the presentation schema, WAL configuration & migration:
 * - Engine: SQLite with Write-Ahead Logging (`PRAGMA journal_mode=WAL`), `synchronous=NORMAL`,
 *   `foreign_keys=ON`, and `busy_timeout=5000`.
 * - Ensures `creators`, `shorts`, and `tracked_creators` tables and optimal feed/lookup indexes exist.
 * - Ensures presentation columns exist on `creators` (followers_count, following_count, total_likes_count, is_verified, bio).
 * - Ensures presentation columns exist on `shorts` (shares_count, sound_title, sound_author, simulated_views, uploaded_at, hls_master_path, available_qualities).
 * - Implements deterministic social metrics and SQLite triggers for automatic metric synchronization.
 */
class ShortsSqLiteDatabase private constructor(context: Context) :
    android.database.sqlite.SQLiteOpenHelper(context.applicationContext, DATABASE_NAME, null, DATABASE_VERSION) {

    override fun onConfigure(db: android.database.sqlite.SQLiteDatabase) {
        super.onConfigure(db)
        db.enableWriteAheadLogging()
        db.setForeignKeyConstraintsEnabled(true)
        runCatching {
            db.rawQuery("PRAGMA synchronous=NORMAL;", null).close()
            db.rawQuery("PRAGMA busy_timeout=5000;", null).close()
        }
    }

    override fun onCreate(db: android.database.sqlite.SQLiteDatabase) {
        runShortsMigration(db)
    }

    override fun onUpgrade(
        db: android.database.sqlite.SQLiteDatabase,
        oldVersion: Int,
        newVersion: Int
    ) {
        runShortsMigration(db)
    }

    override fun onOpen(db: android.database.sqlite.SQLiteDatabase) {
        super.onOpen(db)
        if (!db.isReadOnly) {
            runShortsMigration(db)
        }
    }

    fun runShortsMigration(db: android.database.sqlite.SQLiteDatabase = writableDatabase) {
        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS creators (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL COLLATE NOCASE,
                platform TEXT NOT NULL DEFAULT 'nexora',
                display_name TEXT,
                avatar_url TEXT,
                bio TEXT DEFAULT '',
                followers_count INTEGER NOT NULL DEFAULT 0 CHECK(followers_count >= 0),
                following_count INTEGER NOT NULL DEFAULT 0 CHECK(following_count >= 0),
                total_likes_count INTEGER NOT NULL DEFAULT 0 CHECK(total_likes_count >= 0),
                is_verified INTEGER NOT NULL DEFAULT 0 CHECK(is_verified IN (0, 1)),
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
            """.trimIndent()
        )
        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS tracked_creators (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL COLLATE NOCASE,
                platform TEXT DEFAULT 'instagram',
                is_active INTEGER DEFAULT 1 CHECK(is_active IN (0, 1)),
                last_checked_at TIMESTAMP
            );
            """.trimIndent()
        )
        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS shorts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                file_code TEXT UNIQUE NOT NULL,
                creator_id INTEGER NOT NULL DEFAULT 1 REFERENCES creators(id) ON DELETE CASCADE,
                media_type TEXT DEFAULT 'short',
                title TEXT,
                caption TEXT,
                author TEXT,
                creator_handle TEXT,
                duration REAL DEFAULT 0.0 CHECK(duration >= 0),
                video_path TEXT NOT NULL DEFAULT '',
                thumbnail_path TEXT,
                source_url TEXT,
                likes_count INTEGER DEFAULT 0 CHECK(likes_count >= 0),
                views_count INTEGER DEFAULT 0 CHECK(views_count >= 0),
                shares_count INTEGER DEFAULT 0 CHECK(shares_count >= 0),
                sound_title TEXT DEFAULT 'Original Audio',
                sound_author TEXT DEFAULT '',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                hls_master_path TEXT,
                available_qualities TEXT DEFAULT '[]',
                simulated_views INTEGER DEFAULT 0 CHECK(simulated_views >= 0),
                uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
            """.trimIndent()
        )

        // 1. Safe ALTER TABLE migrations for creators presentation columns
        val existingCreatorColumns = mutableSetOf<String>()
        db.rawQuery("PRAGMA table_info(creators)", null).use { cursor ->
            val nameIdx = cursor.getColumnIndex("name")
            while (cursor.moveToNext()) {
                if (nameIdx >= 0) {
                    existingCreatorColumns.add(cursor.getString(nameIdx).lowercase())
                }
            }
        }
        if ("followers_count" !in existingCreatorColumns) {
            runCatching {
                db.execSQL("ALTER TABLE creators ADD COLUMN followers_count INTEGER NOT NULL DEFAULT 0;")
            }
        }
        if ("following_count" !in existingCreatorColumns) {
            runCatching {
                db.execSQL("ALTER TABLE creators ADD COLUMN following_count INTEGER NOT NULL DEFAULT 0;")
            }
        }
        if ("total_likes_count" !in existingCreatorColumns) {
            runCatching {
                db.execSQL("ALTER TABLE creators ADD COLUMN total_likes_count INTEGER NOT NULL DEFAULT 0;")
            }
        }
        if ("is_verified" !in existingCreatorColumns) {
            runCatching {
                db.execSQL("ALTER TABLE creators ADD COLUMN is_verified INTEGER NOT NULL DEFAULT 0;")
            }
        }
        if ("bio" !in existingCreatorColumns) {
            runCatching {
                db.execSQL("ALTER TABLE creators ADD COLUMN bio TEXT DEFAULT '';")
            }
        }

        // 2. Safe ALTER TABLE migrations for shorts columns
        val existingColumns = mutableSetOf<String>()
        db.rawQuery("PRAGMA table_info(shorts)", null).use { cursor ->
            val nameIdx = cursor.getColumnIndex("name")
            while (cursor.moveToNext()) {
                if (nameIdx >= 0) {
                    existingColumns.add(cursor.getString(nameIdx).lowercase())
                }
            }
        }

        if ("creator_id" !in existingColumns) {
            runCatching {
                db.execSQL("ALTER TABLE shorts ADD COLUMN creator_id INTEGER NOT NULL DEFAULT 1 REFERENCES creators(id) ON DELETE CASCADE;")
            }
        }
        if ("caption" !in existingColumns) {
            runCatching {
                db.execSQL("ALTER TABLE shorts ADD COLUMN caption TEXT;")
            }
        }
        if ("video_path" !in existingColumns) {
            runCatching {
                db.execSQL("ALTER TABLE shorts ADD COLUMN video_path TEXT NOT NULL DEFAULT '';")
            }
        }
        if ("thumbnail_path" !in existingColumns) {
            runCatching {
                db.execSQL("ALTER TABLE shorts ADD COLUMN thumbnail_path TEXT;")
            }
        }
        if ("source_url" !in existingColumns) {
            runCatching {
                db.execSQL("ALTER TABLE shorts ADD COLUMN source_url TEXT;")
            }
        }
        if ("likes_count" !in existingColumns) {
            runCatching {
                db.execSQL("ALTER TABLE shorts ADD COLUMN likes_count INTEGER DEFAULT 0;")
            }
        }
        if ("shares_count" !in existingColumns) {
            runCatching {
                db.execSQL("ALTER TABLE shorts ADD COLUMN shares_count INTEGER NOT NULL DEFAULT 0;")
            }
        }
        if ("sound_title" !in existingColumns) {
            runCatching {
                db.execSQL("ALTER TABLE shorts ADD COLUMN sound_title TEXT DEFAULT 'Original Audio';")
            }
        }
        if ("sound_author" !in existingColumns) {
            runCatching {
                db.execSQL("ALTER TABLE shorts ADD COLUMN sound_author TEXT DEFAULT '';")
            }
        }
        if ("simulated_views" !in existingColumns) {
            runCatching {
                db.execSQL("ALTER TABLE shorts ADD COLUMN simulated_views INTEGER DEFAULT 0;")
            }
        }
        if ("uploaded_at" !in existingColumns) {
            runCatching {
                db.execSQL("ALTER TABLE shorts ADD COLUMN uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP;")
            }
        }
        if ("hls_master_path" !in existingColumns) {
            runCatching {
                db.execSQL("ALTER TABLE shorts ADD COLUMN hls_master_path TEXT;")
            }
        }
        if ("available_qualities" !in existingColumns) {
            runCatching {
                db.execSQL("ALTER TABLE shorts ADD COLUMN available_qualities TEXT DEFAULT '[]';")
            }
        }

        // Ensure indexes for creator lookup, file_code lookup, and keyset feed pagination
        runCatching {
            db.execSQL("CREATE INDEX IF NOT EXISTS idx_shorts_creator ON shorts(creator_id, id DESC);")
            db.execSQL("CREATE INDEX IF NOT EXISTS idx_shorts_code ON shorts(file_code);")
            db.execSQL("CREATE INDEX IF NOT EXISTS idx_shorts_feed_order ON shorts(created_at DESC, id DESC);")
            db.execSQL("CREATE INDEX IF NOT EXISTS idx_creators_user ON creators(username);")
        }

        // 3. Backfill existing records with realistic simulated baseline views and shares
        runCatching {
            db.execSQL(
                """
                UPDATE shorts
                SET simulated_views = 2500 + ((id * 3749) % 35000) + (views_count * 15)
                WHERE simulated_views IS NULL OR simulated_views = 0;
                """.trimIndent()
            )
            db.execSQL(
                """
                UPDATE shorts
                SET shares_count = MAX(12, CAST(((id * 179) % 450) + (likes_count * 0.04) AS INTEGER))
                WHERE shares_count IS NULL OR shares_count = 0;
                """.trimIndent()
            )
            db.execSQL(
                """
                UPDATE shorts
                SET sound_author = author
                WHERE sound_author IS NULL OR sound_author = '';
                """.trimIndent()
            )
        }

        // 4. Backfill creator presentation metrics (followers, following, verified, total likes)
        runCatching {
            db.execSQL(
                """
                UPDATE creators
                SET followers_count = 15000 + ((id * 8363) % 240000),
                    following_count = 45 + ((id * 31) % 400),
                    is_verified = CASE WHEN ((id * 7) % 5) = 0 THEN 1 ELSE 0 END
                WHERE followers_count IS NULL OR followers_count = 0;
                """.trimIndent()
            )
            // Sync total_likes_count as sum of likes plus baseline formula
            db.execSQL(
                """
                UPDATE creators
                SET total_likes_count = (
                    SELECT COALESCE(SUM(s.likes_count), 0) + CAST(creators.followers_count * 4.2 AS INTEGER)
                    FROM shorts s WHERE s.creator_id = creators.id
                )
                WHERE total_likes_count IS NULL OR total_likes_count = 0;
                """.trimIndent()
            )
        }

        // 5. Sync uploaded_at with created_at if null
        runCatching {
            db.execSQL(
                """
                UPDATE shorts
                SET uploaded_at = created_at
                WHERE uploaded_at IS NULL AND created_at IS NOT NULL;
                """.trimIndent()
            )
        }

        // 6. Triggers for automatic metric synchronization
        runCatching {
            db.execSQL(
                """
                CREATE TRIGGER IF NOT EXISTS trg_shorts_sync_creator_likes_insert
                AFTER INSERT ON shorts
                FOR EACH ROW
                BEGIN
                    UPDATE creators
                    SET total_likes_count = total_likes_count + NEW.likes_count
                    WHERE id = NEW.creator_id;
                END;
                """.trimIndent()
            )
            db.execSQL(
                """
                CREATE TRIGGER IF NOT EXISTS trg_shorts_sync_creator_likes_update
                AFTER UPDATE OF likes_count ON shorts
                FOR EACH ROW
                BEGIN
                    UPDATE creators
                    SET total_likes_count = MAX(0, total_likes_count + (NEW.likes_count - OLD.likes_count))
                    WHERE id = NEW.creator_id;
                END;
                """.trimIndent()
            )
        }
    }

    fun upsertAndGetShortRecord(
        fileCode: String,
        title: String,
        author: String,
        creatorHandle: String,
        duration: Double,
        rawViewsCount: Long,
        fallbackCreatedAtIso: String,
        hlsMasterPath: String
    ): ShortDbRecord {
        val db = writableDatabase
        val safeViewsCount = rawViewsCount.coerceAtLeast(0L)
        val cleanUsername = creatorHandle.removePrefix("@").trim().ifBlank { "nexora_creator" }

        db.beginTransactionNonExclusive()
        try {
            db.execSQL(
                """
                INSERT OR IGNORE INTO creators (username, platform, display_name)
                VALUES (?, 'nexora', ?);
                """.trimIndent(),
                arrayOf<Any>(cleanUsername, author)
            )

            var creatorId = 1L
            db.rawQuery(
                "SELECT id FROM creators WHERE username = ? LIMIT 1",
                arrayOf(cleanUsername)
            ).use { c ->
                if (c.moveToFirst()) {
                    creatorId = c.getLong(0)
                }
            }

            db.execSQL(
                """
                INSERT OR IGNORE INTO shorts (
                    file_code, creator_id, media_type, title, author, creator_handle, duration,
                    video_path, views_count, simulated_views, shares_count, sound_title, sound_author,
                    created_at, uploaded_at, hls_master_path, available_qualities
                ) VALUES (?, ?, 'short', ?, ?, ?, ?, ?, ?, 0, 0, 'Original Audio', ?, ?, ?, ?, '[]');
                """.trimIndent(),
                arrayOf<Any>(
                    fileCode,
                    creatorId,
                    title,
                    author,
                    creatorHandle,
                    duration.coerceAtLeast(0.0),
                    hlsMasterPath,
                    safeViewsCount,
                    author,
                    fallbackCreatedAtIso,
                    fallbackCreatedAtIso,
                    hlsMasterPath
                )
            )

            // Execute targeted backfill formula only if simulated_views is still 0
            db.execSQL(
                """
                UPDATE shorts
                SET simulated_views = 2500 + ((id * 3749) % 35000) + (views_count * 15),
                    shares_count = CASE WHEN shares_count = 0 THEN MAX(12, CAST(((id * 179) % 450) + (likes_count * 0.04) AS INTEGER)) ELSE shares_count END,
                    uploaded_at = COALESCE(uploaded_at, created_at),
                    available_qualities = '[]'
                WHERE file_code = ? AND (simulated_views IS NULL OR simulated_views = 0 OR available_qualities != '[]');
                """.trimIndent(),
                arrayOf<Any>(fileCode)
            )
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }

        db.rawQuery(
            """
            SELECT id, file_code, views_count, simulated_views, likes_count, shares_count, sound_title, sound_author, created_at, uploaded_at, hls_master_path, available_qualities
            FROM shorts WHERE file_code = ? LIMIT 1
            """.trimIndent(),
            arrayOf(fileCode)
        ).use { cursor ->
            if (cursor.moveToFirst()) {
                val id = cursor.getLong(0)
                val viewsCount = cursor.getLong(2)
                val simViews = cursor.getLong(3).takeIf { it > 0L }
                    ?: (2500L + ((id * 3749L) % 35000L) + (viewsCount * 15L))
                val likes = cursor.getLong(4)
                val shares = cursor.getLong(5)
                val soundTitle = cursor.getString(6) ?: "Original Audio"
                val soundAuthor = cursor.getString(7) ?: author
                val createdAt = cursor.getString(8) ?: fallbackCreatedAtIso
                val uploadedAt = cursor.getString(9) ?: createdAt
                val hlsPath = cursor.getString(10) ?: hlsMasterPath
                val availQual = cursor.getString(11) ?: "[]"
                return ShortDbRecord(
                    id = id,
                    fileCode = fileCode,
                    viewsCount = viewsCount,
                    simulatedViews = simViews,
                    likesCount = likes,
                    sharesCount = shares,
                    soundTitle = soundTitle,
                    soundAuthor = soundAuthor,
                    createdAt = createdAt,
                    uploadedAt = uploadedAt,
                    hlsMasterPath = hlsPath,
                    availableQualitiesJson = availQual
                )
            }
        }

        val fallbackId = (fileCode.hashCode().toLong() and 0x7FFFFFFFL).coerceAtLeast(1L)
        val fallbackSimViews = 2500L + ((fallbackId * 3749L) % 35000L) + (safeViewsCount * 15L)
        return ShortDbRecord(
            id = fallbackId,
            fileCode = fileCode,
            viewsCount = safeViewsCount,
            simulatedViews = fallbackSimViews,
            likesCount = 0L,
            sharesCount = 18L,
            soundTitle = "Original Audio",
            soundAuthor = author,
            createdAt = fallbackCreatedAtIso,
            uploadedAt = fallbackCreatedAtIso,
            hlsMasterPath = hlsMasterPath,
            availableQualitiesJson = "[]"
        )
    }

    companion object {
        const val DATABASE_NAME = "shorts.db"
        private const val DATABASE_VERSION = 4

        @Volatile
        private var INSTANCE: ShortsSqLiteDatabase? = null

        fun getInstance(context: Context): ShortsSqLiteDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: ShortsSqLiteDatabase(context).also { dbHelper ->
                    runCatching { dbHelper.runShortsMigration() }
                    INSTANCE = dbHelper
                }
            }
        }
    }
}


