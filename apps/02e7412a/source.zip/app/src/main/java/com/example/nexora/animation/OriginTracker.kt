package com.example.nexora.animation

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import com.example.ui.theme.NexoraColors

/**
 * Root wrapper that intercepts pointer down coordinates in the Initial pass
 * (before button onClick handlers run) and draws the 440ms tactile specular
 * bubble ring whenever a transition trigger occurs.
 */
@Composable
fun OriginTrackerBox(
    activeOrigin: ClickOrigin,
    onPointerDownCapture: (ClickOrigin) -> Unit,
    modifier: Modifier = Modifier,
    content: @Composable (viewportSize: IntSize) -> Unit
) {
    var viewportSize by remember { mutableStateOf(IntSize(1080, 2400)) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .onSizeChanged { size ->
                if (size.width > 0 && size.height > 0) {
                    viewportSize = size
                }
            }
            .pointerInput(Unit) {
                awaitPointerEventScope {
                    while (true) {
                        val event = awaitPointerEvent(PointerEventPass.Initial)
                        val firstDown = event.changes.firstOrNull { it.pressed && !it.previousPressed }
                        if (firstDown != null) {
                            val pos = firstDown.position
                            val captured = ClickOrigin.fromRootCoordinates(
                                x = pos.x,
                                y = pos.y,
                                viewportWidth = size.width.toFloat(),
                                viewportHeight = size.height.toFloat(),
                                timestamp = System.currentTimeMillis()
                            )
                            onPointerDownCapture(captured)
                        }
                    }
                }
            }
    ) {
        content(viewportSize)
        // Tap animation removed per user request
    }
}

/**
 * Tactile Specular Bubble Ring on Click:
 * Tap animation removed per user request.
 */
@Composable
fun BubbleClickRippleOverlay(
    origin: ClickOrigin,
    modifier: Modifier = Modifier
) {
    // Tap animation removed per user request
}
