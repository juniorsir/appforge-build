# Implementation Plan: Instagram-Style Clean Chat UI & Sleek GIF Studio

Transform the chat interface and GIF Studio to match Instagram's signature clean, minimal, and modern aesthetic—removing cluttered container borders, card wrappers, and nested outlines around GIFs and media, while refining message bubbles and the GIF picker into a seamless experience.

---

## 1. Proposed Changes

### A. Borderless Instagram-Style GIF & Media Rendering in Chat
- **File**: `app/src/main/java/com/example/nexora/ui/modals/SpatialDirectChatView.kt`
- **Current Behavior**: GIF messages are wrapped in a colored chat bubble Column with 13dp horizontal padding, 10dp vertical padding, a background color, an outer stroke border (`SpecularBorderStrong`), and a nested container with an explicit "Full Screen" badge overlay.
- **Proposed Instagram Style**:
  - Standalone GIF messages render directly as **borderless rounded media** (`16.dp`–`18.dp` corner radius) without any surrounding bubble card, outer border, or background box.
  - Tapping the GIF seamlessly opens the **Full-Screen GIF Viewer** with the quick emoji reaction bar.
  - Remove intrusive "Full Screen" badge overlays on top of the GIF in the chat stream, letting the media breathe cleanly just like Instagram DMs.
  - Shared spatial scene cards and voice wave notes also receive matching clean, borderless or fine-edge styling without heavy container borders.

### B. Clean Message Bubbles & Overall Opened Chat Screen
- **File**: `app/src/main/java/com/example/nexora/ui/modals/SpatialDirectChatView.kt`
- **Current Behavior**: Heavy borders (`SpecularBorderStrong`), thick dividing lines, and multi-layered boxes.
- **Proposed Instagram Style**:
  - **Outgoing Messages**: Sleek rounded pill (`RoundedCornerShape(20.dp, 20.dp, 20.dp, 6.dp)`) with clean Electric Indigo or subtle modern purple-blue gradient, free of heavy double borders.
  - **Incoming Messages**: Sleek dark neutral pill (`#242424` / `NexoraColors.Pearl100`) with smooth rounded corners (`20.dp, 20.dp, 6.dp, 20.dp`), crisp white typography, and no outer card border.
  - **Chat Header**: Clean top bar with back navigation, user avatar, username and active status, and minimalist action icons (call/close) without clunky container boxes.
  - **Composer Bar**: Instagram capsule pill layout with seamless dark background (`#262626`), clean text input ("Message..."), and sleek circular action icons (voice note, GIF picker, media attach, send).

### C. Redesigned Instagram-Style GIF Studio
- **File**: `app/src/main/java/com/example/nexora/ui/modals/SpatialDirectChatView.kt`
- **Current Behavior**: Cluttered full-screen dialog window with chunky category borders, count badges, and heavy outer borders around each GIF item.
- **Proposed Instagram Style**:
  - Convert into an **Instagram-style Bottom Sheet Modal**:
    - Smooth top grab handle indicator (`36.dp` x `4.dp`, rounded pill).
    - Header with clean "Search GIPHY" or "GIFs" label and minimalist close icon.
    - Seamless search pill (`#262626` background, subtle magnifying glass, borderless).
    - Horizontal category chips (Trending, Reactions, Love, Happy, Sad, Cheers, Dance, Wow) with active state as sleek solid white pill with dark text, and inactive as soft dark pills.
    - 2-column borderless GIF grid (`GridCells.Fixed(2)`) with clean rounded corners (`14.dp`), removing all outer card strokes, shadows, and secondary badges.
    - Tapping a GIF instantly sends it into the chat; long-press or tap-to-expand preview opens the full-screen viewer.

### D. Full-Screen GIF Viewer with Reactions Bar
- **File**: `app/src/main/java/com/example/nexora/ui/modals/SpatialDirectChatView.kt`
- **Current Behavior**: Has thick borders and glow shadows.
- **Proposed Instagram Style**:
  - Deep black translucent immersive backdrop (`Color.Black.copy(alpha = 0.94f)`).
  - Centered high-resolution GIF with smooth rounded corners (`18.dp`).
  - Sleek emoji reaction bar (`❤️`, `🔥`, `😮`, `😂`, `💯`, `👏`) floating below the GIF to quickly react with emojis directly into the thread.
  - Clean "Send in Chat" action button and top-right close affordance.

---

## 2. Verification Plan

1. **Compilation Verification**:
   - Run `compile_applet` to confirm all Jetpack Compose UI updates, layouts, imports, and modifiers compile with zero errors.
2. **Visual & Behavioral Verification**:
   - Verify that sent and received GIFs display borderless in the chat stream with no outer card wrappers or boxes.
   - Verify that regular chat bubbles display clean Instagram-style pills without heavy strokes.
   - Verify that opening the GIF Studio shows a clean bottom sheet with seamless search, category chips, and a 2-column grid.
   - Verify that tapping a GIF in chat or previewing from the studio opens the full-screen viewer with the emoji reaction bar.
