#!/usr/bin/env python3
"""
CLI Controller for Termux AIOS & Android Automation Bridge
Sends commands over localhost WebSocket or HTTP REST to the Android device.

Features:
- List installed applications (with search filter & system app toggle)
- Open / Launch applications by name, package name, or URL
- Inspect on-screen UI hierarchy (Accessibility tree)
- Tap elements by label or coordinates
- Dispatch gestures (swipe, click, scroll next)
- Trigger system actions (Back, Home, Recents, Notifications)
- Display live toast messages
- Seamless auto-fallback to HTTP REST (Port 8080) if WebSocket server (Port 8000) is offline

Usage:
    python send_cmd.py apps [filter] [--system] [--json]
    python send_cmd.py open <appName | packageName | url>
    python send_cmd.py inspect [delay_sec]
    python send_cmd.py click <x> <y>
    python send_cmd.py tap <label>
    python send_cmd.py swipe <x1> <y1> <x2> <y2> [duration_ms]
    python send_cmd.py next
    python send_cmd.py back | home | recents | notifications
    python send_cmd.py toast <text>
"""

import asyncio
import json
import os
import re
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid

WS_SERVER_URL = os.environ.get("AURA_WS_URL", "ws://127.0.0.1:8000/ws")
HTTP_SERVER_URL = os.environ.get("AURA_HTTP_URL", "http://127.0.0.1:8080")

try:
    import websockets
    HAS_WEBSOCKETS = True
except ImportError:
    HAS_WEBSOCKETS = False


def parse_center(bounds_str):
    try:
        nums = [int(n) for n in re.findall(r'\d+', bounds_str)]
        if len(nums) == 4:
            return (nums[0] + nums[2]) // 2, (nums[1] + nums[3]) // 2
    except Exception:
        pass
    return None


def print_tree(nodes, depth=0, find_text=None, matched_targets=None):
    if not isinstance(nodes, list):
        nodes = [nodes]

    for node in nodes:
        indent = "  " * depth
        class_name = node.get("className", "").split(".")[-1]
        text = node.get("text", "") or ""
        desc = node.get("contentDescription", "") or ""
        clickable = node.get("isClickable", False)
        bounds = node.get("boundsInScreen", "")

        center = parse_center(bounds)
        cx, cy = center if center else (0, 0)
        coord_str = f" -> click {cx} {cy}" if (clickable and center) else ""

        if find_text and matched_targets is not None:
            clean_search = find_text.strip().lower()
            if (clean_search in text.lower() or clean_search in desc.lower()) and center:
                matched_targets.append((text or desc or class_name, cx, cy))

        info = []
        if text:
            info.append(f'"{text}"')
        if desc and desc != text:
            info.append(f'desc="{desc}"')
        if not info and clickable:
            info.append("(clickable area)")

        label = " ".join(info) if info else ""
        marker = "•" if (clickable or text or desc) else "·"
        print(f"{indent}{marker} [{class_name}] {label}{coord_str}")

        children = node.get("children", [])
        if children:
            print_tree(children, depth + 1, find_text, matched_targets)


# ---------------------------------------------------------------------------
# HTTP REST Fallback Helpers & Security Shield (Zero external dependencies)
# ---------------------------------------------------------------------------

TOKEN_FILE = os.path.expanduser("~/.aura_token")
LOCAL_TOKEN_FILE = os.path.join(os.path.dirname(__file__), ".aura_token")

def load_stored_token():
    if os.environ.get("AURA_API_TOKEN"):
        return os.environ.get("AURA_API_TOKEN")
    if os.environ.get("AERO_TOKEN"):
        return os.environ.get("AERO_TOKEN")
    if os.path.exists(TOKEN_FILE):
        try:
            with open(TOKEN_FILE, "r") as f:
                return f.read().strip()
        except Exception:
            pass
    if os.path.exists(LOCAL_TOKEN_FILE):
        try:
            with open(LOCAL_TOKEN_FILE, "r") as f:
                return f.read().strip()
        except Exception:
            pass
    return ""

def save_stored_token(token):
    try:
        with open(TOKEN_FILE, "w") as f:
            f.write(token.strip())
    except Exception:
        pass
    try:
        with open(LOCAL_TOKEN_FILE, "w") as f:
            f.write(token.strip())
    except Exception:
        pass

AUTH_TOKEN = load_stored_token()

def get_http_headers():
    headers = {
        "User-Agent": "AuraTermuxCLI/3.0",
        "Accept": "application/json"
    }
    if AUTH_TOKEN:
        headers["Authorization"] = f"Bearer {AUTH_TOKEN}"
        headers["X-API-Key"] = AUTH_TOKEN
    return headers


def http_get(path_and_query):
    url = f"{HTTP_SERVER_URL}{path_and_query}"
    req = urllib.request.Request(url, headers=get_http_headers())
    try:
        with urllib.request.urlopen(req, timeout=4.0) as resp:
            data = resp.read().decode("utf-8")
            return json.loads(data)
    except urllib.error.HTTPError as e:
        try:
            err_data = e.read().decode("utf-8")
            return json.loads(err_data)
        except Exception:
            return {"success": False, "error": f"HTTP {e.code}: {e.reason}"}
    except Exception as e:
        return {"success": False, "error": str(e)}


def http_post(endpoint, payload):
    url = f"{HTTP_SERVER_URL}{endpoint}"
    data_bytes = json.dumps(payload).encode("utf-8")
    headers = get_http_headers()
    headers["Content-Type"] = "application/json"
    req = urllib.request.Request(
        url,
        data=data_bytes,
        headers=headers
    )
    try:
        with urllib.request.urlopen(req, timeout=4.0) as resp:
            data = resp.read().decode("utf-8")
            return json.loads(data)
    except urllib.error.HTTPError as e:
        try:
            err_data = e.read().decode("utf-8")
            return json.loads(err_data)
        except Exception:
            return {"success": False, "error": f"HTTP {e.code}: {e.reason}"}
    except Exception as e:
        return {"success": False, "error": str(e)}


def execute_login(client_name="Termux Bridge", as_json=False):
    global AUTH_TOKEN
    sec_dev_id = f"SEC-DEV-{uuid.uuid4().hex[:8].upper()}"

    payload = {
        "clientName": client_name,
        "securityDeviceId": sec_dev_id,
        "deviceId": sec_dev_id
    }

    res = http_post("/api/auth/login", payload)
    if not res.get("success", False):
        if as_json:
            print(json.dumps(res, indent=2))
        else:
            print(f"\n[ERROR] Login request failed: {res.get('error', 'Unknown error')}")
            print(f"Hint: Ensure AeroShare is running on your phone at {HTTP_SERVER_URL}\n")
        return

    req_id = res.get("requestId", "")
    if as_json and not sys.stdout.isatty():
        pass

    print("\n" + "=" * 68)
    print(" 🔐 AUTHENTICATION REQUIRED: PENDING ON-DEVICE FACE VERIFICATION")
    print("=" * 68)
    print(f" Security Device ID : {sec_dev_id}")
    print(f" Client Name        : {client_name}")
    print(f" Notification       : Sent to Android phone notification drawer!")
    print(f" Status             : Waiting for Face match on phone...")
    print("-" * 68)
    print(" 📱 Action Required On Phone:")
    print(" 1. Look at your Android phone screen (or tap the incoming notification).")
    print(" 2. Verify your FACE when prompted by AeroShare.")
    print(" ⚠️  Note: Screen lock (PIN / Pattern) is strictly disabled.")
    print("=" * 68)
    print(" Polling for Face confirmation (press Ctrl+C to cancel)", end="", flush=True)

    start_time = time.time()
    poll_payload = {
        "requestId": req_id,
        "securityDeviceId": sec_dev_id
    }

    while time.time() - start_time < 90:
        time.sleep(1.5)
        print(".", end="", flush=True)
        poll_res = http_post("/api/auth/poll", poll_payload)
        if poll_res.get("success", False):
            status = poll_res.get("status", "")
            if status == "APPROVED":
                token = poll_res.get("clientToken", "")
                save_stored_token(token)
                AUTH_TOKEN = token
                print("\n\n" + "=" * 68)
                print(" ✅ FACE VERIFIED! ACCESS GRANTED TO TERMUX")
                print("=" * 68)
                print(f" Security Device ID : {sec_dev_id}")
                print(f" Authorized Token   : {token[:16]}... (Saved to ~/.aura_token)")
                print(f" Status             : FULLY AUTHORIZED")
                print("-" * 68)
                print(" You can now execute commands from Termux freely!")
                print(" Example: python send_cmd.py apps")
                print("=" * 68 + "\n")
                return
            elif status == "DENIED":
                print("\n\n" + "=" * 68)
                print(" ❌ ACCESS DENIED: Face authentication was rejected on phone.")
                print("=" * 68 + "\n")
                return

    print("\n\n[TIMEOUT] Face verification timed out after 90 seconds. Try running 'python send_cmd.py login' again.\n")


def execute_pair(code_or_subcmd=None, client_name="Termux-Client", as_json=False):
    global AUTH_TOKEN
    if not code_or_subcmd:
        res = http_get("/api/security/pair/code")
        if as_json:
            print(json.dumps(res, indent=2))
        else:
            code = res.get("pairingCode", "")
            valid = res.get("validitySeconds", 300)
            print("\n" + "=" * 55)
            print(" 🔐 ON-DEVICE 6-DIGIT PAIRING CODE")
            print("=" * 55)
            print(f" Active Code:  {code}")
            print(f" Remaining:    {valid} seconds")
            print("-" * 55)
            print(f" Pair on another device: python send_cmd.py pair {code}")
            print("=" * 55 + "\n")
        return

    if code_or_subcmd in ["devices", "list", "peers"]:
        res = http_get("/api/security/devices")
        if as_json:
            print(json.dumps(res, indent=2))
            return
        devices = res.get("pairedDevices", [])
        print("\n" + "=" * 75)
        print(f" 🛡️  PAIRED CLIENT DEVICES ({len(devices)} registered)")
        print("=" * 75)
        if not devices:
            print(" No remote devices currently paired.")
        else:
            print(f" {'#':<4} {'DEVICE ID':<20} {'NAME':<24} {'IP ADDRESS':<16} {'REVOKED'}")
            print("-" * 75)
            for idx, d in enumerate(devices, start=1):
                did = d.get("deviceId", "")[:18]
                name = d.get("clientName", "")[:22]
                ip = d.get("clientIp", "")[:15]
                rev = "Yes ❌" if d.get("isRevoked", False) else "No ✅"
                print(f" {idx:<4} {did:<20} {name:<24} {ip:<16} {rev}")
        print("=" * 75 + "\n")
        return

    if code_or_subcmd in ["revoke", "delete", "remove"]:
        target_id = client_name
        res = http_post("/api/security/revoke", {"deviceId": target_id})
        if as_json:
            print(json.dumps(res, indent=2))
        else:
            if res.get("success", False):
                print(f"✓ Revoked client device: {target_id}")
            else:
                print(f"[ERROR] Failed to revoke client: {target_id}")
        return

    # Pair with 6-digit numeric code or master token
    code = code_or_subcmd
    res = http_post("/api/security/pair/register", {"code": code, "clientName": client_name})
    if as_json:
        print(json.dumps(res, indent=2))
    else:
        if res.get("success", False):
            token = res.get("clientToken", "")
            save_stored_token(token)
            AUTH_TOKEN = token
            print("\n" + "=" * 60)
            print(" ✅ DEVICE PAIRING SUCCESSFUL!")
            print("=" * 60)
            print(f" Client Name: {res.get('clientName', client_name)}")
            print(f" Device ID:   {res.get('deviceId', '')}")
            print(f" Token:       {token[:16]}... (Saved to ~/.aura_token)")
            print("=" * 60 + "\n")
        else:
            print(f"\n[ERROR] Pairing Failed: {res.get('error', 'Invalid code')}")
            print(f"Hint: {res.get('hint', 'Verify code on phone screen')}\n")


def execute_security(subcmd=None, val=None, as_json=False):
    if subcmd == "mode" and val:
        res = http_post("/api/security/mode", {"mode": val.upper()})
        if as_json:
            print(json.dumps(res, indent=2))
        else:
            if res.get("success", False):
                print(f"✓ Security Auth Mode set to: {val.upper()}")
            else:
                print(f"[ERROR] {res.get('error', 'Failed to update auth mode')}")
    elif subcmd == "biometrics" or subcmd == "bio":
        res = http_get("/api/security/biometrics")
        if as_json:
            print(json.dumps(res, indent=2))
            return
        print("\n" + "=" * 65)
        print(" 👤 ON-DEVICE BIOMETRIC SECURITY STATUS")
        print("=" * 65)
        print(f" Device Secure:      {'Yes ✅' if res.get('isDeviceSecure', False) else 'No ⚠️'}")
        print(f" Face Prioritized:   {'Yes 🎯 (Android BiometricPrompt)' if res.get('facePrioritized', True) else 'No'}")
        print(f" Face Hardware:      {'Detected ✅' if res.get('hasFaceHardware', False) else 'Standard Camera/Sensor'}")
        print(f" Screen Lock Bypass: {'Disabled 🚫 (PIN / Pattern Forbidden)' if not res.get('pinPatternAllowed', False) else 'Enabled'}")
        print(f" Keyguard Locked:    {res.get('isKeyguardLocked', False)}")
        print(f" Require for Pair:   {res.get('requireBiometricForPairing', True)}")
        print(f" Biometric Types:    {', '.join(res.get('supportedTypes', ['FACE_AUTHENTICATION', 'BIOMETRIC_STRONG']))}")
        print("=" * 65 + "\n")
    elif subcmd == "token":
        res = http_get("/api/security/token")
        if as_json:
            print(json.dumps(res, indent=2))
        else:
            tok = res.get("token", "")
            print(f"🔑 Master Secure API Token: {tok}")
            print(f"   Export in Termux: export AURA_API_TOKEN=\"{tok}\"")
    else:
        res = http_get("/api/security/status")
        if as_json:
            print(json.dumps(res, indent=2))
            return
        print("\n" + "=" * 60)
        print(" 🛡️  AURA ENDPOINT SECURITY SHIELD STATUS")
        print("=" * 60)
        print(f" Auth Mode:          {res.get('authMode', 'LOCAL_TRUST')}")
        print(f" Strict Auth:        {res.get('isStrictAuth', False)}")
        print(f" Local Trust:        {res.get('localTrustEnabled', True)}")
        print(f" Active Code:        {res.get('activePairingCode', 'N/A')} ({res.get('pairingCodeRemainingSec', 0)}s left)")
        print(f" Paired Devices:     {res.get('pairedDevicesCount', 0)}")
        print(f" Biometrics Active:  {'Yes ✅' if res.get('isBiometricsAvailable', False) else 'No'}")
        print(f" Rate Limiter:       ACTIVE (150 req/min + IP Lockout)")
        print(f" OWASP Headers:      ACTIVE (CSP, HSTS, X-Frame-Options)")
        print("=" * 60 + "\n")


# ---------------------------------------------------------------------------
# App Listing & Formatting
# ---------------------------------------------------------------------------

def display_apps(apps_list, filter_query="", as_json=False):
    if as_json:
        print(json.dumps(apps_list, indent=2))
        return

    if not apps_list:
        if filter_query:
            print(f"\n[!] No installed applications found matching '{filter_query}'.")
            print("    Try running without a filter: python send_cmd.py apps")
        else:
            print("\n[!] No installed applications found.")
        return

    print("\n" + "=" * 80)
    title = f" INSTALLED APPLICATIONS ({len(apps_list)} found)"
    if filter_query:
        title += f" [Filter: '{filter_query}']"
    print(title)
    print("=" * 80)
    print(f" {'#':<4} {'APP NAME':<28} {'PACKAGE NAME':<34} {'TYPE':<8}")
    print("-" * 80)

    for idx, app in enumerate(apps_list, start=1):
        name = app.get("appName", "Unknown")[:26]
        pkg = app.get("packageName", "")[:33]
        is_sys = app.get("isSystemApp", False)
        app_type = "[System]" if is_sys else "[User]"
        print(f" {idx:<4} {name:<28} {pkg:<34} {app_type:<8}")

    print("=" * 80)
    print("💡 Tip: To launch an app, run:")
    print("   python send_cmd.py open <appName | packageName | url>")
    print("   Example: python send_cmd.py open Termux\n")


# ---------------------------------------------------------------------------
# App List & Launch Execution (with automatic WebSocket -> HTTP fallback)
# ---------------------------------------------------------------------------

async def execute_list_apps(include_system=False, filter_query="", as_json=False, force_http=False):
    # If force HTTP or no websockets library, use HTTP directly
    if force_http or not HAS_WEBSOCKETS:
        return run_http_list_apps(include_system, filter_query, as_json)

    # Try WebSocket first
    now_ms = int(time.time() * 1000)
    req_id = "apps-" + str(now_ms)
    packet = {
        "type": "APP_LIST",
        "timestamp": now_ms,
        "sessionId": "cli-" + str(now_ms),
        "requestId": req_id,
        "includeSystem": include_system
    }

    try:
        async with websockets.connect(WS_SERVER_URL, open_timeout=2.0) as ws:
            # Drain server hello
            try:
                await asyncio.wait_for(ws.recv(), timeout=0.8)
            except Exception:
                pass

            await ws.send(json.dumps(packet))

            # Wait for APP_LIST_RESULT
            while True:
                msg = await asyncio.wait_for(ws.recv(), timeout=6.0)
                data = json.loads(msg)
                if data.get("type") == "APP_LIST_RESULT" or data.get("requestId") == req_id:
                    apps = data.get("apps", [])
                    if filter_query:
                        q = filter_query.lower()
                        apps = [a for a in apps if q in a.get("appName", "").lower() or q in a.get("packageName", "").lower()]
                    display_apps(apps, filter_query, as_json)
                    return True

    except (ConnectionRefusedError, OSError, asyncio.TimeoutError):
        # Fall back gracefully to HTTP REST server on port 8080
        return run_http_list_apps(include_system, filter_query, as_json)
    except Exception as e:
        print(f"[!] WebSocket error: {e}. Falling back to HTTP REST...")
        return run_http_list_apps(include_system, filter_query, as_json)


def run_http_list_apps(include_system=False, filter_query="", as_json=False):
    params = []
    if include_system:
        params.append("includeSystem=true")
    if filter_query:
        params.append(f"filter={urllib.parse.quote(filter_query)}")
    q_str = "?" + "&".join(params) if params else ""

    res = http_get(f"/api/app/list{q_str}")
    if res.get("success", False):
        apps = res.get("apps", [])
        if filter_query and not q_str:
            q = filter_query.lower()
            apps = [a for a in apps if q in a.get("appName", "").lower() or q in a.get("packageName", "").lower()]
        display_apps(apps, filter_query, as_json)
        return True
    else:
        err = res.get("error", "Unknown error")
        print(f"[ERROR] Could not fetch apps via HTTP: {err}")
        print("Ensure Aura is running on the device (HTTP REST active on port 8080).")
        return False


async def execute_launch_app(target, force_http=False):
    clean_target = target.strip()
    is_url = clean_target.startswith(("http://", "https://", "www."))

    # If force HTTP or no websockets library, use HTTP directly
    if force_http or not HAS_WEBSOCKETS:
        return run_http_launch_app(clean_target, is_url)

    # Try WebSocket first
    now_ms = int(time.time() * 1000)
    req_id = "launch-" + str(now_ms)
    packet = {
        "type": "APP_LAUNCH",
        "timestamp": now_ms,
        "sessionId": "cli-" + str(now_ms),
        "requestId": req_id,
        "packageName": clean_target if not is_url else None,
        "url": clean_target if is_url else None
    }

    try:
        async with websockets.connect(WS_SERVER_URL, open_timeout=2.0) as ws:
            # Drain server hello
            try:
                await asyncio.wait_for(ws.recv(), timeout=0.8)
            except Exception:
                pass

            await ws.send(json.dumps(packet))

            # Wait for APP_LAUNCH_RESULT
            while True:
                msg = await asyncio.wait_for(ws.recv(), timeout=5.0)
                data = json.loads(msg)
                if data.get("type") == "APP_LAUNCH_RESULT" or data.get("requestId") == req_id:
                    success = data.get("success", False)
                    launched = data.get("launchedTarget") or clean_target
                    if success:
                        print(f"✓ Successfully launched: '{launched}'")
                    else:
                        err = data.get("errorMessage", "Target not found or launch failed")
                        print(f"✗ Failed to launch '{clean_target}': {err}")
                        print("  💡 Run 'python send_cmd.py apps' to view installed applications.")
                    return success

    except (ConnectionRefusedError, OSError, asyncio.TimeoutError):
        # Fall back gracefully to HTTP REST server on port 8080
        return run_http_launch_app(clean_target, is_url)
    except Exception as e:
        print(f"[!] WebSocket error: {e}. Falling back to HTTP REST...")
        return run_http_launch_app(clean_target, is_url)


def run_http_launch_app(clean_target, is_url):
    payload = {
        "packageName": clean_target if not is_url else None,
        "url": clean_target if is_url else None
    }
    res = http_post("/api/app/launch", payload)
    if res.get("success", False):
        target_name = res.get("target") or clean_target
        print(f"✓ Successfully launched: '{target_name}'")
        return True
    else:
        err = res.get("error", "Target not found or launch failed")
        print(f"✗ Failed to launch '{clean_target}': {err}")
        print("  💡 Run 'python send_cmd.py apps' to view installed applications.")
        return False


# ---------------------------------------------------------------------------
# AeroShare Peer-to-Peer File Transfer & Local Device Discovery
# ---------------------------------------------------------------------------

def execute_devices(as_json=False):
    res = http_get("/api/share/devices")
    if as_json:
        print(json.dumps(res, indent=2))
        return
    if not res.get("success", False):
        print(f"[ERROR] Could not fetch devices: {res.get('error', 'Unknown')}")
        return

    local_name = res.get("localDeviceName", "Android Device")
    local_ip = res.get("localIp", "Unknown")
    is_radar = res.get("isRadarActive", True)
    devices = res.get("devices", [])

    print("\n" + "=" * 80)
    print(f" AEROSHARE LOCAL RADAR & PEER DISCOVERY")
    print(f" Local Device: {local_name} ({local_ip}) | Radar: {'[ON - Scanning]' if is_radar else '[OFF]'}")
    print("=" * 80)
    if not devices:
        print(" [!] No nearby AeroShare peers discovered yet.")
        print("     • Ensure devices are connected to the same Wi-Fi or Hotspot.")
        print("     • You can manually beam to any device IP via: python send_cmd.py share <file> <IP>")
    else:
        print(f" {'#':<4} {'DEVICE NAME':<28} {'IP ADDRESS':<18} {'PORT':<8} {'TYPE':<10} {'SIGNAL':<8}")
        print("-" * 80)
        for idx, dev in enumerate(devices, start=1):
            name = dev.get("name", "Peer")[:26]
            ip = dev.get("ip", "")[:16]
            port = dev.get("port", 8080)
            dtype = dev.get("deviceType", "PHONE")[:8]
            rssi = f"{dev.get('rssi', -50)}dBm"
            print(f" {idx:<4} {name:<28} {ip:<18} {port:<8} {dtype:<10} {rssi:<8}")
    print("=" * 80 + "\n")


def execute_share(target_input, peer_ip="", as_json=False):
    if not target_input:
        print("[ERROR] Please specify a file path or text snippet to share.")
        print("Usage: python send_cmd.py share <filePath | text> [targetDeviceIp]")
        return

    is_file = os.path.exists(target_input) and os.path.isfile(target_input)
    payload = {}
    if is_file:
        payload["filePath"] = os.path.abspath(target_input)
    else:
        payload["text"] = target_input

    if peer_ip:
        payload["ip"] = peer_ip

    res = http_post("/api/share/send", payload)
    if as_json:
        print(json.dumps(res, indent=2))
        return

    if res.get("success", False):
        if is_file:
            print(f"✓ Started AeroShare transfer of '{res.get('fileName')}' ({res.get('sizeBytes', 0)} bytes)")
            print(f"  Transfer ID : {res.get('transferId')}")
            print(f"  Target Peer : {res.get('targetIp')}")
            print("  Run 'python send_cmd.py transfers' to inspect live progress.")
        else:
            print(f"✓ Sent text snippet to {res.get('targetIp')}: \"{res.get('text')}\"")
    else:
        print(f"✗ Failed to initiate transfer: {res.get('error', 'Unknown error')}")


def execute_transfers(as_json=False):
    res = http_get("/api/share/transfers")
    if as_json:
        print(json.dumps(res, indent=2))
        return
    transfers = res.get("transfers", [])
    print("\n" + "=" * 80)
    print(f" AEROSHARE ACTIVE TRANSFERS ({len(transfers)} active)")
    print("=" * 80)
    if not transfers:
        print(" No active transfers currently running.")
    else:
        for tx in transfers:
            fn = tx.get("fileName", "file")
            pct = tx.get("progressPct", 0)
            status = tx.get("status", "TRANSFERRING")
            speed = tx.get("speedBytesPerSec", 0) / (1024 * 1024)
            eta = tx.get("etaSeconds", 0)
            direction = tx.get("direction", "SEND")
            peer = tx.get("peerName", tx.get("peerIp", "Peer"))
            tx_id = tx.get("id", "")
            bar_len = 20
            filled = int(bar_len * pct / 100)
            bar = "█" * filled + "░" * (bar_len - filled)
            print(f" [{direction}] {fn} -> {peer}")
            print(f"   [{bar}] {pct}% | {speed:.2f} MB/s | ETA: {eta}s | Status: {status} | ID: {tx_id}")
    print("=" * 80 + "\n")


def execute_history(as_json=False):
    res = http_get("/api/share/history")
    if as_json:
        print(json.dumps(res, indent=2))
        return
    history = res.get("history", [])
    print("\n" + "=" * 80)
    print(f" AEROSHARE TRANSFER HISTORY ({len(history)} items)")
    print("=" * 80)
    if not history:
        print(" No completed transfers recorded.")
    else:
        print(f" {'FILE NAME':<30} {'STATUS':<12} {'DIR':<8} {'PEER':<20}")
        print("-" * 80)
        for item in history[:20]:
            fn = item.get("fileName", "file")[:28]
            status = item.get("status", "DONE")[:10]
            direction = item.get("direction", "SEND")[:6]
            peer = item.get("peerName", "Peer")[:18]
            print(f" {fn:<30} {status:<12} {direction:<8} {peer:<20}")
    print("=" * 80 + "\n")


def execute_cancel(transfer_id):
    if not transfer_id:
        print("[ERROR] Missing transfer ID to cancel.")
        return
    res = http_post("/api/share/cancel", {"id": transfer_id})
    if res.get("success", False):
        print(f"✓ Cancelled transfer: {transfer_id}")
    else:
        print(f"✗ Could not cancel transfer: {transfer_id}")


def execute_clip(text=None, as_json=False):
    if text:
        res = http_post("/api/share/clip", {"text": text})
        if as_json:
            print(json.dumps(res, indent=2))
        else:
            print(f"✓ Beamed clipboard snippet: \"{text}\"")
    else:
        res = http_get("/api/share/clip")
        if as_json:
            print(json.dumps(res, indent=2))
        else:
            clip_text = res.get("clipboardText", "")
            print(f"Clipboard Content: {clip_text}")


def execute_radar(enable=None, as_json=False):
    payload = {}
    if enable is not None:
        payload["enabled"] = enable
    res = http_post("/api/share/radar", payload)
    if as_json:
        print(json.dumps(res, indent=2))
    else:
        status_str = "ACTIVE (Scanning)" if res.get("isRadarActive", True) else "PAUSED"
        print(f"✓ AeroShare Radar is now: {status_str}")


def execute_battery(as_json=False):
    res = http_get("/api/battery")
    if as_json:
        print(json.dumps(res, indent=2))
        return
    pct = res.get("batteryPct", 0)
    charging = "⚡ Charging" if res.get("isCharging", False) else "Discharging"
    temp = res.get("batteryTempC", 0.0)
    uptime_sec = res.get("uptimeSeconds", 0)
    uptime_str = f"{uptime_sec // 3600}h {(uptime_sec % 3600) // 60}m"
    is_opt = res.get("isIgnoringBatteryOptimizations", False)
    print("\n" + "=" * 55)
    print(" 🔋 DEVICE BATTERY & POWER STATUS")
    print("=" * 55)
    print(f" Level:           {pct}% [{charging}]")
    print(f" Temperature:     {temp}°C")
    print(f" Throttling:      {'Yes ⚠️' if res.get('isThermalThrottling', False) else 'Normal'}")
    print(f" Background Mode: {'✓ UNRESTRICTED (Exempt from Doze)' if is_opt else '⚠️ OPTIMIZED (Restricted in Doze)'}")
    print(f" Uptime:          {uptime_str}")
    print("=" * 55 + "\n")


def execute_battery_opt(action="STATUS", as_json=False):
    res = http_post("/api/battery/optimization", {"action": action.upper()})
    if as_json:
        print(json.dumps(res, indent=2))
        return
    status = res.get("status", "OPTIMIZED")
    print("\n" + "=" * 60)
    print(f" ⚡ BATTERY OPTIMIZATION & BACKGROUND EXECUTION: [{status}]")
    print("=" * 60)
    if status == "UNRESTRICTED":
        print(" ✓ App is UNRESTRICTED. Background transfers & radar run uninterrupted.")
    else:
        print(" ⚠️ App is OPTIMIZED. Android Doze may pause background transfers.")
        print(f" 💡 {res.get('hint', '')}")
    if res.get("actionRequested", False):
        print(" ✓ System authorization intent dispatched to phone screen.")
    print("=" * 60 + "\n")


def execute_sensors(as_json=False):
    res = http_get("/api/sensors")
    if as_json:
        print(json.dumps(res, indent=2))
        return
    print("\n" + "=" * 60)
    print(" 📡 LIVE HARDWARE SENSORS SNAPSHOT")
    print("=" * 60)
    if "ambientLightLux" in res:
        print(f" Ambient Light:    {res['ambientLightLux']:.1f} lux")
    if "proximityCm" in res:
        is_near = " (NEAR)" if res.get("isNear", False) else " (FAR)"
        print(f" Proximity:        {res['proximityCm']:.1f} cm{is_near}")
    if "compassHeadingDegrees" in res:
        cardinal = res.get("compassCardinal", "")
        print(f" Compass:          {res['compassHeadingDegrees']:.1f}° ({cardinal})")
    if "pressureHpa" in res:
        print(f" Barometer:        {res['pressureHpa']:.1f} hPa")
    if "stepCount" in res:
        print(f" Step Counter:     {int(res['stepCount'])} steps")
    if "accelerometer" in res:
        acc = res["accelerometer"]
        print(f" Accelerometer:    X={acc.get('x', 0):.2f}, Y={acc.get('y', 0):.2f}, Z={acc.get('z', 0):.2f} m/s²")
    if "gyroscope" in res:
        gyro = res["gyroscope"]
        print(f" Gyroscope:        X={gyro.get('x', 0):.2f}, Y={gyro.get('y', 0):.2f}, Z={gyro.get('z', 0):.2f} rad/s")
    print("=" * 60 + "\n")


def execute_torch(enable=True, as_json=False):
    res = http_post("/api/torch", {"enabled": enable})
    if as_json:
        print(json.dumps(res, indent=2))
    else:
        state_str = "ON 🔦" if enable else "OFF"
        print(f"✓ Camera Torch set to: {state_str}")


def execute_vibrate(duration_ms=200, preset=None, as_json=False):
    payload = {"durationMs": duration_ms}
    if preset:
        payload["preset"] = preset
    res = http_post("/api/vibrate", payload)
    if as_json:
        print(json.dumps(res, indent=2))
    else:
        print(f"✓ Triggered haptic vibration ({duration_ms}ms)")


def execute_tts(text, pitch=1.0, rate=1.0, as_json=False):
    if not text:
        print("[ERROR] Missing text to speak.")
        return
    res = http_post("/api/tts", {"text": text, "pitch": pitch, "rate": rate})
    if as_json:
        print(json.dumps(res, indent=2))
    else:
        print(f"✓ Spoke aloud: \"{text}\"")


def execute_volume(level=None, stream="MEDIA", as_json=False):
    if level is not None:
        try:
            vol_int = int(level)
            res = http_post("/api/volume", {"stream": stream.upper(), "volume": vol_int})
            if as_json:
                print(json.dumps(res, indent=2))
            else:
                print(f"✓ Set {stream.upper()} volume to: {vol_int}")
        except ValueError:
            print(f"[ERROR] Invalid volume level: {level}")
    else:
        res = http_get("/api/volume")
        if as_json:
            print(json.dumps(res, indent=2))
            return
        print("\n" + "=" * 50)
        print(" 🔊 AUDIO STREAMS & VOLUME STATUS")
        print("=" * 50)
        print(f" Ringer Mode: {res.get('ringerMode', 'NORMAL')}")
        print("-" * 50)
        for s in res.get("streams", []):
            st = s.get("stream", "STREAM")
            cur = s.get("volume", 0)
            max_v = s.get("max", 15)
            pct = s.get("percentage", 0)
            print(f" {st:<16} {cur:>2}/{max_v:<2} ({pct}%)")
        print("=" * 50 + "\n")


def execute_tone(freq_hz=440, duration_ms=500, as_json=False):
    res = http_post("/api/audio/tone", {"frequency": freq_hz, "durationMs": duration_ms})
    if as_json:
        print(json.dumps(res, indent=2))
    else:
        print(f"✓ Played audio tone ({freq_hz} Hz for {duration_ms}ms)")


def execute_hud(text, title="⚡ Termux HUD", as_json=False):
    res = http_post("/api/floating", {"title": title, "text": text, "type": "HUD", "isDraggable": True})
    if as_json:
        print(json.dumps(res, indent=2))
    else:
        if res.get("displayedAsToast", False):
            print(f"✓ HUD displayed as Toast (overlay permission pending): \"{text}\"")
        else:
            print(f"✓ Floating HUD displayed: \"{text}\"")


def execute_notify(title, message, as_json=False):
    res = http_post("/api/notification", {"title": title, "message": message})
    if as_json:
        print(json.dumps(res, indent=2))
    else:
        print(f"✓ System notification posted: [{title}] {message}")


def execute_media(action="PLAY_PAUSE", as_json=False):
    res = http_post("/api/media/control", {"command": action})
    if as_json:
        print(json.dumps(res, indent=2))
    else:
        print(f"✓ Media action '{action.upper()}' dispatched")


def execute_storage(folder="DOWNLOADS", limit=30, as_json=False):
    res = http_post("/api/storage/files", {"folder": folder, "limit": limit})
    if as_json:
        print(json.dumps(res, indent=2))
        return
    files = res.get("files", [])
    directory = res.get("directory", folder)
    print("\n" + "=" * 80)
    print(f" 📁 STORAGE FILE EXPLORER: {directory} ({len(files)} files)")
    print("=" * 80)
    print(f" {'#':<4} {'NAME':<38} {'SIZE':<12} {'TYPE':<8}")
    print("-" * 80)
    for idx, f in enumerate(files, start=1):
        name = f.get("name", "")[:36]
        sz_bytes = f.get("sizeBytes", 0)
        is_dir = f.get("isDirectory", False)
        if is_dir:
            sz_str = "<DIR>"
            ftype = "[DIR]"
        else:
            if sz_bytes > 1024 * 1024:
                sz_str = f"{sz_bytes / (1024 * 1024):.1f} MB"
            elif sz_bytes > 1024:
                sz_str = f"{sz_bytes / 1024:.1f} KB"
            else:
                sz_str = f"{sz_bytes} B"
            ftype = "[FILE]"
        print(f" {idx:<4} {name:<38} {sz_str:<12} {ftype:<8}")
    print("=" * 80)
    print("💡 Tip: Share any file instantly:")
    print("   python send_cmd.py share <filePath>\n")


def execute_sms(phone, message="", as_json=False):
    if not phone:
        print("[ERROR] Missing phone number.")
        return
    res = http_post("/api/sms/compose", {"phone": phone, "message": message})
    if as_json:
        print(json.dumps(res, indent=2))
    else:
        print(f"✓ SMS Composer opened for: {phone}")


# ---------------------------------------------------------------------------
# Main CLI Router
# ---------------------------------------------------------------------------

def print_help():
    print("""
================================================================================
  Aura Android & Termux Automation CLI (send_cmd.py)
================================================================================

AEROSHARE P2P FILE TRANSFER & RADAR:
  python send_cmd.py devices                   # Discover nearby AeroShare peers
  python send_cmd.py share <file|text> [ip]    # Send file or text to device
  python send_cmd.py transfers                 # View live transfer progress & speeds
  python send_cmd.py history                   # View completed transfer history
  python send_cmd.py cancel <transfer_id>      # Cancel an active file transfer
  python send_cmd.py clip [text]               # Read or beam shared clipboard
  python send_cmd.py radar [on|off]            # Toggle background discovery radar

DEVICE PAIRING & SECURITY SHIELD:
  python send_cmd.py login [client_name]       # Authenticate Termux via Face scan on phone
  python send_cmd.py pair                      # View active 6-digit pairing code & validity
  python send_cmd.py pair <code> [client_name] # Pair this terminal using 6-digit code
  python send_cmd.py pair devices              # List all paired client devices
  python send_cmd.py pair revoke <device_id>   # Revoke a remote client's access
  python send_cmd.py security                  # Check security shield status & mode
  python send_cmd.py security biometrics       # View Face / Biometric security capabilities
  python send_cmd.py security mode STRICT      # Enforce strict token auth for all requests
  python send_cmd.py security mode LOCAL_TRUST # Trust loopback 127.0.0.1, protect external LAN
  python send_cmd.py security token            # View master secure token

HARDWARE, POWER & SENSORS:
  python send_cmd.py battery                   # Battery %, charging status, temp, uptime
  python send_cmd.py sensors                   # Live light lux, compass, proximity, acc
  python send_cmd.py torch [on|off]            # Turn flashlight on or off
  python send_cmd.py vibrate [ms]              # Haptic vibration (default 200ms)
  python send_cmd.py tts <text>                # Speak text aloud via Text-to-Speech
  python send_cmd.py tone [freq_hz] [dur_ms]   # Play pure audio tone (e.g. 440 Hz)
  python send_cmd.py volume [0-15] [stream]    # View or set audio stream volumes
  python send_cmd.py media <play|next|prev>    # Control system media player
  python send_cmd.py files [folder]            # Browse device storage (Downloads, DCIM)
  python send_cmd.py sms <phone> [message]     # Open SMS composer with pre-filled text
  python send_cmd.py hud <text> [title]        # Display floating HUD overlay widget
  python send_cmd.py notify <title> <message>  # Post an Android system notification

APPLICATION CONTROLS:
  python send_cmd.py apps [filter] [--system] [--json]
      List installed applications.
      Examples:
        python send_cmd.py apps                     # List user apps
        python send_cmd.py apps --system            # Include system apps
        python send_cmd.py apps termux              # Search for 'termux'
        python send_cmd.py apps --json              # Output as JSON

  python send_cmd.py open <app_name | packageName | url>
      Launch an app by friendly name, package name, or open a web URL.
      Aliases: launch, run, start
      Examples:
        python send_cmd.py open Termux              # Launch by name
        python send_cmd.py open YouTube             # Case-insensitive
        python send_cmd.py open com.android.chrome  # Launch by package ID
        python send_cmd.py open https://github.com  # Open in browser

SCREEN INSPECTION & GESTURES:
  python send_cmd.py inspect [delay_sec]
      Scan foreground UI hierarchy and print interactive elements with click bounds.
      Example: python send_cmd.py inspect 3

  python send_cmd.py tap <text>
      Find a UI element matching visible text or content description and tap it.
      Example: python send_cmd.py tap Settings

  python send_cmd.py click <x> <y>
      Tap exact screen coordinates.
      Example: python send_cmd.py click 540 1200

  python send_cmd.py swipe <x1> <y1> <x2> <y2> [duration_ms]
      Perform drag or swipe gesture.
      Example: python send_cmd.py swipe 500 1500 500 300 200

  python send_cmd.py next
      Scroll upward to the next post, video, or reel.

SYSTEM HARDWARE NAVIGATION:
  python send_cmd.py back            # Trigger Android Back key
  python send_cmd.py home            # Trigger Android Home key
  python send_cmd.py recents         # Open Recent Apps switcher
  python send_cmd.py notifications   # Pull down notification drawer

MESSAGING & TOASTS:
  python send_cmd.py toast <text>    # Display custom toast message on device
  python send_cmd.py <prompt text>   # Stream text / AI prompt to phone

FLAGS:
  --http     Force direct HTTP REST execution (port 8080) instead of WebSocket.
  --system   Include system apps in listing.
  --json     Output raw JSON format.
================================================================================
""")


async def main():
    global AUTH_TOKEN
    raw_args = sys.argv[1:]
    if not raw_args or raw_args[0] in ["-h", "--help", "help"]:
        print_help()
        return

    # Extract global flags
    force_http = "--http" in raw_args
    include_system = "--system" in raw_args or "-s" in raw_args
    as_json = "--json" in raw_args

    # Check for --token <val> or --key <val>
    cleaned_args = []
    skip_next = False
    for i, a in enumerate(raw_args):
        if skip_next:
            skip_next = False
            continue
        if a in ["--token", "--key", "-k"] and i + 1 < len(raw_args):
            AUTH_TOKEN = raw_args[i + 1]
            skip_next = True
            continue
        if a.startswith("--token="):
            AUTH_TOKEN = a.split("=", 1)[1]
            continue
        if a.startswith("--key="):
            AUTH_TOKEN = a.split("=", 1)[1]
            continue
        if a not in ["--http", "--system", "-s", "--json"]:
            cleaned_args.append(a)

    args = cleaned_args
    if not args:
        print_help()
        return

    cmd = args[0].lower()

    # Security & Authentication Controls
    if cmd in ["login", "authenticate", "auth-login"]:
        cname = args[1] if len(args) > 1 else "Termux-Workstation"
        execute_login(cname, as_json=as_json)
        return

    if cmd in ["pair", "register", "pairing"]:
        code_or_sub = args[1] if len(args) > 1 else None
        cname = args[2] if len(args) > 2 else "Termux-Workstation"
        execute_pair(code_or_sub, cname, as_json=as_json)
        return

    if cmd in ["security", "auth", "shield"]:
        subcmd = args[1].lower() if len(args) > 1 else None
        val = args[2] if len(args) > 2 else None
        execute_security(subcmd, val, as_json=as_json)
        return

    # AeroShare P2P & File Sharing Controls
    if cmd in ["devices", "peers", "nearby"]:
        execute_devices(as_json=as_json)
        return

    if cmd in ["share", "send"]:
        if len(args) < 2:
            print("[ERROR] Missing file path or text to share.")
            print("Usage: python send_cmd.py share <filePath | text> [targetDeviceIp]")
            return
        target_input = args[1]
        peer_ip = args[2] if len(args) > 2 else ""
        execute_share(target_input, peer_ip, as_json=as_json)
        return

    if cmd in ["transfers", "tx"]:
        execute_transfers(as_json=as_json)
        return

    if cmd in ["history", "transfers-history"]:
        execute_history(as_json=as_json)
        return

    if cmd in ["cancel", "abort"]:
        if len(args) < 2:
            print("[ERROR] Missing transfer ID to cancel.")
            print("Usage: python send_cmd.py cancel <transferId>")
            return
        execute_cancel(args[1])
        return

    if cmd in ["clip", "clipboard"]:
        text_arg = " ".join(args[1:]) if len(args) > 1 else None
        execute_clip(text_arg, as_json=as_json)
        return

    if cmd in ["radar"]:
        enable_arg = None
        if len(args) > 1:
            enable_arg = args[1].lower() in ["on", "true", "start", "enable"]
        execute_radar(enable_arg, as_json=as_json)
        return

    # Hardware & Diagnostics
    if cmd in ["battery", "batt", "power"]:
        execute_battery(as_json=as_json)
        return

    if cmd in ["battery-opt", "battery-optimization", "doze", "unrestricted"]:
        action_arg = args[1] if len(args) > 1 else "STATUS"
        execute_battery_opt(action_arg, as_json=as_json)
        return

    if cmd in ["sensors", "sensor"]:
        execute_sensors(as_json=as_json)
        return

    if cmd in ["torch", "flash", "flashlight"]:
        enable = True
        if len(args) > 1 and args[1].lower() in ["off", "false", "0", "disable"]:
            enable = False
        execute_torch(enable, as_json=as_json)
        return

    if cmd in ["vibrate", "vib", "haptic"]:
        duration = int(args[1]) if len(args) > 1 and args[1].isdigit() else 200
        execute_vibrate(duration, as_json=as_json)
        return

    if cmd in ["tts", "speak", "voice"]:
        if len(args) < 2:
            print("[ERROR] Missing text to speak.")
            print("Usage: python send_cmd.py tts <text>")
            return
        execute_tts(" ".join(args[1:]), as_json=as_json)
        return

    if cmd in ["tone", "beep"]:
        freq = int(args[1]) if len(args) > 1 and args[1].isdigit() else 440
        dur = int(args[2]) if len(args) > 2 and args[2].isdigit() else 500
        execute_tone(freq, dur, as_json=as_json)
        return

    if cmd in ["volume", "vol"]:
        level = args[1] if len(args) > 1 else None
        stream = args[2] if len(args) > 2 else "MEDIA"
        execute_volume(level, stream, as_json=as_json)
        return

    if cmd in ["hud", "floating"]:
        if len(args) < 2:
            print("[ERROR] Missing text for HUD overlay.")
            print("Usage: python send_cmd.py hud <text> [title]")
            return
        title = args[2] if len(args) > 2 else "⚡ Termux HUD"
        execute_hud(args[1], title, as_json=as_json)
        return

    if cmd in ["notify", "notification"]:
        if len(args) < 2:
            print("[ERROR] Missing message for notification.")
            print("Usage: python send_cmd.py notify <title> <message>")
            return
        title = args[1] if len(args) > 2 else "Aura Alert"
        msg = " ".join(args[2:]) if len(args) > 2 else args[1]
        execute_notify(title, msg, as_json=as_json)
        return

    if cmd in ["media", "player", "music"]:
        action = args[1].upper() if len(args) > 1 else "PLAY_PAUSE"
        execute_media(action, as_json=as_json)
        return

    if cmd in ["files", "storage", "ls-files", "dir"]:
        folder = args[1] if len(args) > 1 else "DOWNLOADS"
        limit = int(args[2]) if len(args) > 2 and args[2].isdigit() else 30
        execute_storage(folder, limit, as_json=as_json)
        return

    if cmd in ["sms", "text"]:
        if len(args) < 2:
            print("[ERROR] Missing phone number.")
            print("Usage: python send_cmd.py sms <phone_number> [message_text]")
            return
        phone = args[1]
        msg = " ".join(args[2:]) if len(args) > 2 else ""
        execute_sms(phone, msg, as_json=as_json)
        return

    # 1. LIST APPS: apps, list-apps, list_apps, list, ls
    if cmd in ["apps", "list-apps", "list_apps", "list", "ls"]:
        filter_query = " ".join(args[1:]) if len(args) > 1 else ""
        await execute_list_apps(include_system=include_system, filter_query=filter_query, as_json=as_json, force_http=force_http)
        return

    # 2. OPEN / LAUNCH APPS: open, launch, run, start
    if cmd in ["open", "launch", "run", "start"]:
        if len(args) < 2:
            print("[ERROR] Missing app name, package name, or URL.")
            print("Usage: python send_cmd.py open <appName | packageName | url>")
            return
        target = " ".join(args[1:])
        await execute_launch_app(target, force_http=force_http)
        return

    # Check for websockets for gesture/inspect operations
    if not HAS_WEBSOCKETS:
        print("[ERROR] The 'websockets' library is required for real-time gestures & inspection.")
        print("Install via: pip install websockets")
        print("\nNote: 'apps' and 'open' commands work without websockets via HTTP REST!")
        return

    now_ms = int(time.time() * 1000)

    try:
        async with websockets.connect(WS_SERVER_URL) as ws:
            # Drain initial server HELLO
            try:
                await asyncio.wait_for(ws.recv(), timeout=1.0)
            except asyncio.TimeoutError:
                pass

            # 3. SYSTEM HARDWARE GESTURES (Back, Home, Recents, Notifications)
            if cmd in ["back", "home", "recents", "notifications"]:
                packet = {
                    "type": "ACCESSIBILITY_GESTURE",
                    "timestamp": now_ms,
                    "sessionId": "cli-" + str(now_ms),
                    "gestureId": f"{cmd}-{now_ms}",
                    "gestureType": cmd.upper(),
                    "startX": 0.0,
                    "startY": 0.0,
                    "durationMs": 50
                }
                await ws.send(json.dumps(packet))
                print(f"Dispatched system action: {cmd.upper()}")

            # 4. INSPECT SCREEN UI
            elif cmd == "inspect":
                delay = int(args[1]) if len(args) > 1 and args[1].isdigit() else 0
                if delay > 0:
                    print(f"Switch to target app! Inspecting in {delay}s...")
                    for i in range(delay, 0, -1):
                        print(f" {i}...", end="", flush=True)
                        await asyncio.sleep(1)
                    print(" Inspecting!")

                packet = {
                    "type": "ACCESSIBILITY_INSPECT",
                    "timestamp": now_ms,
                    "sessionId": "cli-" + str(now_ms),
                    "target": "active_window"
                }
                print("Sent ACCESSIBILITY_INSPECT -> Waiting for screen nodes...")
                await ws.send(json.dumps(packet))

                while True:
                    msg = await asyncio.wait_for(ws.recv(), timeout=8.0)
                    data = json.loads(msg)
                    if data.get("type") == "ACCESSIBILITY_INSPECT_RESULT":
                        nodes = data.get("nodes", [])
                        print("\n" + "=" * 60)
                        print(f" PHONE SCREEN UI MAP ({len(nodes)} root node(s)):")
                        print("=" * 60)
                        print_tree(nodes)
                        print("=" * 60 + "\n")
                        break

            # 5. TAP BY LABEL
            elif cmd == "tap" and len(args) >= 2:
                target_label = " ".join(args[1:])
                packet = {
                    "type": "ACCESSIBILITY_INSPECT",
                    "timestamp": now_ms,
                    "sessionId": "cli-" + str(now_ms),
                    "target": "active_window"
                }
                print(f"Searching screen for '{target_label}'...")
                await ws.send(json.dumps(packet))

                matched_targets = []
                while True:
                    msg = await asyncio.wait_for(ws.recv(), timeout=8.0)
                    data = json.loads(msg)
                    if data.get("type") == "ACCESSIBILITY_INSPECT_RESULT":
                        nodes = data.get("nodes", [])
                        print_tree(nodes, depth=0, find_text=target_label, matched_targets=matched_targets)
                        break

                if matched_targets:
                    found_name, tx, ty = matched_targets[0]
                    click_packet = {
                        "type": "ACCESSIBILITY_GESTURE",
                        "timestamp": now_ms,
                        "sessionId": "cli-" + str(now_ms),
                        "gestureId": f"click-{now_ms}",
                        "gestureType": "CLICK",
                        "action": "CLICK",
                        "startX": float(tx),
                        "startY": float(ty),
                        "x": int(tx),
                        "y": int(ty),
                        "durationMs": 100
                    }
                    await ws.send(json.dumps(click_packet))
                    print(f"✓ Tapped '{found_name}' at ({tx}, {ty})")
                else:
                    print(f"✗ Could not find element matching '{target_label}' on screen.")
                    print("  Try running 'python send_cmd.py inspect' to see full UI structure.")

            # 6. CLICK COORDINATES
            elif cmd == "click" and len(args) >= 3:
                x, y = int(args[1]), int(args[2])
                packet = {
                    "type": "ACCESSIBILITY_GESTURE",
                    "timestamp": now_ms,
                    "sessionId": "cli-" + str(now_ms),
                    "gestureId": f"click-{now_ms}",
                    "gestureType": "CLICK",
                    "action": "CLICK",
                    "startX": float(x),
                    "startY": float(y),
                    "x": x,
                    "y": y,
                    "durationMs": 100
                }
                await ws.send(json.dumps(packet))
                print(f"Dispatched CLICK at ({x}, {y})")

            # 7. SWIPE
            elif cmd == "swipe" and len(args) >= 5:
                x1, y1 = int(args[1]), int(args[2])
                x2, y2 = int(args[3]), int(args[4])
                dur = int(args[5]) if len(args) > 5 else 300
                packet = {
                    "type": "ACCESSIBILITY_GESTURE",
                    "timestamp": now_ms,
                    "sessionId": "cli-" + str(now_ms),
                    "gestureId": f"swipe-{now_ms}",
                    "gestureType": "SWIPE",
                    "action": "SWIPE",
                    "startX": float(x1),
                    "startY": float(y1),
                    "endX": float(x2),
                    "endY": float(y2),
                    "x": x1,
                    "y": y1,
                    "durationMs": dur
                }
                await ws.send(json.dumps(packet))
                print(f"Dispatched SWIPE from ({x1}, {y1}) to ({x2}, {y2}) [{dur}ms]")

            # 8. NEXT (REELS / SCROLL)
            elif cmd == "next":
                packet = {
                    "type": "ACCESSIBILITY_GESTURE",
                    "timestamp": now_ms,
                    "sessionId": "cli-" + str(now_ms),
                    "gestureId": f"next-{now_ms}",
                    "gestureType": "SWIPE",
                    "action": "SWIPE",
                    "startX": 500.0,
                    "startY": 1400.0,
                    "endX": 500.0,
                    "endY": 300.0,
                    "durationMs": 250
                }
                await ws.send(json.dumps(packet))
                print("Dispatched scroll to next item")

            # 9. TOAST
            elif cmd == "toast" and len(args) >= 2:
                msg = " ".join(args[1:])
                packet = {
                    "type": "AI_STREAM",
                    "timestamp": now_ms,
                    "sessionId": "cli-" + str(now_ms),
                    "textChunk": msg,
                    "isFinal": True
                }
                await ws.send(json.dumps(packet))
                print(f"Dispatched toast: '{msg}'")

            # 10. ARBITRARY TEXT / AI PROMPT
            else:
                prompt_text = " ".join(args)
                packet = {
                    "type": "AI_STREAM",
                    "timestamp": now_ms,
                    "sessionId": "cli-" + str(now_ms),
                    "textChunk": prompt_text,
                    "isFinal": True
                }
                await ws.send(json.dumps(packet))
                print(f"Dispatched message: '{prompt_text}'")

    except ConnectionRefusedError:
        print(f"[!] Could not connect to WebSocket at {WS_SERVER_URL}.")
        print("    If Termux relay is offline, start it with: python mock_server.py")
        print("    Or for app controls, they work automatically with: python send_cmd.py apps")
    except Exception as e:
        print(f"[ERROR] {type(e).__name__}: {e}")


if __name__ == "__main__":
    asyncio.run(main())
