package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.security.FaceDeviceAuthDialog
import com.example.presentation.dashboard.DashboardScreen
import com.example.presentation.dashboard.DashboardViewModel
import com.example.presentation.navigation.DashboardRoute
import com.example.presentation.navigation.SettingsRoute
import com.example.presentation.navigation.SpeechDiagnosticsRoute
import com.example.presentation.navigation.ConversationEngineRoute
import com.example.presentation.navigation.AccessibilityDashboardRoute
import com.example.presentation.accessibility.AccessibilityDashboardScreen
import com.example.presentation.accessibility.AccessibilityViewModel
import com.example.presentation.settings.SettingsScreen
import com.example.presentation.settings.SettingsViewModel
import com.example.presentation.speech.SpeechDiagnosticsScreen
import com.example.presentation.speech.SpeechDiagnosticsViewModel
import com.example.presentation.brain.ConversationEngineScreen
import com.example.presentation.brain.ConversationEngineViewModel
import com.example.ui.theme.MyApplicationTheme
// import dagger.hilt.android.AndroidEntryPoint

/**
 * Main Activity of the real-time AI companion app.
 * Configures the type-safe Navigation Compose graph and obtains base ViewModels.
 */
// @AndroidEntryPoint
class MainActivity : ComponentActivity() {
    private val requestMultiplePermissionsLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        permissions.entries.forEach {
            android.util.Log.d("MainActivity", "Permission ${it.key} granted: ${it.value}")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        handleAuthIntent(intent)
        
        val permissionsToRequest = mutableListOf(
            android.Manifest.permission.CAMERA,
            android.Manifest.permission.RECORD_AUDIO,
            android.Manifest.permission.ACCESS_FINE_LOCATION,
            android.Manifest.permission.ACCESS_COARSE_LOCATION
        )
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
            permissionsToRequest.add(android.Manifest.permission.POST_NOTIFICATIONS)
        }
        requestMultiplePermissionsLauncher.launch(permissionsToRequest.toTypedArray())
        
        // Enable edge-to-edge full-bleed drawing supporting modern safeDrawing insets
        enableEdgeToEdge()
        
        setContent {
            MyApplicationTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    val appContainer = (applicationContext as? BaseApplication)?.container
                    val pendingPairRequest = appContainer?.securityShield?.latestPendingPairRequest?.collectAsStateWithLifecycle()?.value

                    val navController = rememberNavController()

                    // Global Face / Biometric Authorization Popup for New Device Connections
                    if (pendingPairRequest != null && appContainer != null) {
                        FaceDeviceAuthDialog(
                            request = pendingPairRequest,
                            onAuthorize = { reqId ->
                                appContainer.securityShield.approvePendingPairRequest(reqId)
                            },
                            onDeny = { reqId ->
                                appContainer.securityShield.denyPendingPairRequest(reqId)
                            },
                            onDismiss = {
                                appContainer.securityShield.dismissPendingPairRequest()
                            }
                        )
                    }
                    
                    NavHost(
                        navController = navController,
                        startDestination = DashboardRoute
                    ) {
                        composable<DashboardRoute> {
                            val dashboardViewModel: DashboardViewModel = viewModel(
                                factory = DashboardViewModel.Factory
                            )
                            DashboardScreen(
                                onNavigateToSettings = { navController.navigate(SettingsRoute) },
                                onNavigateToDeveloper = { navController.navigate(com.example.presentation.navigation.DeveloperRoute) },
                                onNavigateToSpeechDiagnostics = { navController.navigate(SpeechDiagnosticsRoute) },
                                onNavigateToConversationEngine = { navController.navigate(ConversationEngineRoute) },
                                viewModel = dashboardViewModel
                            )
                        }
                        
                        composable<SettingsRoute> {
                            val settingsViewModel: SettingsViewModel = viewModel(
                                factory = SettingsViewModel.Factory
                            )
                            SettingsScreen(
                                onNavigateBack = { navController.popBackStack() },
                                viewModel = settingsViewModel
                            )
                        }

                        composable<com.example.presentation.navigation.DeveloperRoute> {
                            val developerViewModel: com.example.presentation.developer.DeveloperViewModel = viewModel(
                                factory = com.example.presentation.developer.DeveloperViewModel.Factory
                            )
                            com.example.presentation.developer.DeveloperScreen(
                                onNavigateBack = { navController.popBackStack() },
                                viewModel = developerViewModel,
                                onNavigateToCapabilities = {
                                    navController.navigate(com.example.presentation.navigation.CapabilityDashboardRoute)
                                },
                                onNavigateToToolsFramework = {
                                    navController.navigate(com.example.presentation.navigation.ToolsFrameworkRoute)
                                },
                                onNavigateToAccessibility = {
                                    navController.navigate(com.example.presentation.navigation.AccessibilityDashboardRoute)
                                }
                            )
                        }

                        composable<com.example.presentation.navigation.CapabilityDashboardRoute> {
                            com.example.presentation.developer.CapabilityDashboardScreen(
                                onNavigateBack = { navController.popBackStack() }
                            )
                        }

                        composable<com.example.presentation.navigation.ToolsFrameworkRoute> {
                            com.example.presentation.developer.ToolsDashboardScreen(
                                onNavigateBack = { navController.popBackStack() }
                            )
                        }

                        composable<SpeechDiagnosticsRoute> {
                            val speechViewModel: SpeechDiagnosticsViewModel = viewModel(
                                factory = SpeechDiagnosticsViewModel.Factory
                            )
                            SpeechDiagnosticsScreen(
                                onNavigateBack = { navController.popBackStack() },
                                viewModel = speechViewModel
                            )
                        }

                        composable<ConversationEngineRoute> {
                            val brainViewModel: ConversationEngineViewModel = viewModel(
                                factory = ConversationEngineViewModel.Factory
                            )
                            ConversationEngineScreen(
                                onNavigateBack = { navController.popBackStack() },
                                viewModel = brainViewModel
                            )
                        }

                        composable<AccessibilityDashboardRoute> {
                            val accessibilityViewModel: AccessibilityViewModel = viewModel(
                                factory = AccessibilityViewModel.Factory
                            )
                            AccessibilityDashboardScreen(
                                onNavigateBack = { navController.popBackStack() },
                                viewModel = accessibilityViewModel
                            )
                        }
                    }
                }
            }
        }
    }

    override fun onNewIntent(intent: android.content.Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleAuthIntent(intent)
    }

    private fun handleAuthIntent(intent: android.content.Intent?) {
        val reqId = intent?.getStringExtra("AUTH_REQUEST_ID") ?: return
        val appContainer = (applicationContext as? BaseApplication)?.container ?: return
        val req = appContainer.securityShield.getPendingPairRequest(reqId)
        if (req != null) {
            appContainer.securityShield.showPendingPairRequest(req)
        }
    }
}
