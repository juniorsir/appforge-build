package com.example.ui.overlay

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.util.Log
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.util.concurrent.ConcurrentHashMap

class FloatingOverlayManager(private val context: Context) {

    private val TAG = "FloatingOverlayManager"
    private val mainHandler = Handler(Looper.getMainLooper())
    private val windowManager by lazy {
        context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    }

    data class FloatingOptions(
        val floatingId: String = "default_floating",
        val title: String? = null,
        val text: String,
        val subText: String? = null,
        val type: String = "HUD", // "BADGE", "HUD", "STICKY_NOTE", "STATUS_PILL", "CARD", "TERMINAL_MINI"
        val backgroundColor: String? = null, // e.g., "#E61E1E2E"
        val textColor: String? = null, // e.g., "#FFFFFF"
        val accentColor: String? = null, // e.g., "#00E5FF"
        val textSize: Float = 13f,
        val cornerRadius: Int = 16, // dp
        val alpha: Float = 0.95f,
        val gravity: String = "TOP_RIGHT", // "TOP_LEFT", "TOP_RIGHT", "TOP_CENTER", "BOTTOM_LEFT", "BOTTOM_RIGHT", "BOTTOM_CENTER", "CENTER"
        val x: Int = 24, // dp
        val y: Int = 100, // dp
        val widthDp: Int = -2, // -2 is WRAP_CONTENT, or fixed dp
        val heightDp: Int = -2,
        val isDraggable: Boolean = true,
        val showCloseButton: Boolean = true,
        val autoDismissSeconds: Int = 0 // 0 = permanent until dismissed
    )

    private data class ActiveOverlay(
        val view: View,
        val params: WindowManager.LayoutParams,
        val titleView: TextView?,
        val bodyView: TextView?,
        val subTextView: TextView?,
        var autoDismissRunnable: Runnable? = null
    )

    private val activeOverlays = ConcurrentHashMap<String, ActiveOverlay>()

    fun hasPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Settings.canDrawOverlays(context)
        } else {
            true
        }
    }

    fun getPermissionIntent(): Intent? {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(context)) {
            Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:${context.packageName}")
            ).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
        } else null
    }

    fun showFloating(options: FloatingOptions): Boolean {
        if (!hasPermission()) {
            Log.w(TAG, "SYSTEM_ALERT_WINDOW permission not granted")
            return false
        }

        mainHandler.post {
            try {
                // If this ID is already active, remove it or update it
                activeOverlays[options.floatingId]?.let { existing ->
                    try {
                        existing.autoDismissRunnable?.let { mainHandler.removeCallbacks(it) }
                        windowManager.removeView(existing.view)
                    } catch (e: Exception) {
                        Log.w(TAG, "Error removing old overlay view: ${e.message}")
                    }
                    activeOverlays.remove(options.floatingId)
                }

                val density = context.resources.displayMetrics.density

                val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                } else {
                    @Suppress("DEPRECATION")
                    WindowManager.LayoutParams.TYPE_PHONE
                }

                val displayMetrics = context.resources.displayMetrics
                val screenWidth = displayMetrics.widthPixels
                val screenHeight = displayMetrics.heightPixels

                val w = if (options.widthDp > 0) (options.widthDp * density).toInt() else WindowManager.LayoutParams.WRAP_CONTENT
                val h = if (options.heightDp > 0) (options.heightDp * density).toInt() else WindowManager.LayoutParams.WRAP_CONTENT

                // Calculate initial (x, y) relative to TOP | START so dragging direction is always 100% natural (1:1 with finger move)
                val estimatedWidth = if (w > 0) w else (220 * density).toInt()
                val estimatedHeight = if (h > 0) h else (60 * density).toInt()
                val marginX = (options.x * density).toInt()
                val marginY = (options.y * density).toInt()

                val (initCalcX, initCalcY) = when (options.gravity.uppercase()) {
                    "TOP_LEFT" -> Pair(marginX, marginY + (48 * density).toInt())
                    "TOP_RIGHT" -> Pair((screenWidth - estimatedWidth - marginX - (16 * density).toInt()).coerceAtLeast(0), marginY + (48 * density).toInt())
                    "TOP_CENTER" -> Pair((screenWidth / 2 - estimatedWidth / 2 + marginX).coerceAtLeast(0), marginY + (48 * density).toInt())
                    "BOTTOM_LEFT" -> Pair(marginX, (screenHeight - estimatedHeight - marginY - (48 * density).toInt()).coerceAtLeast(0))
                    "BOTTOM_RIGHT" -> Pair((screenWidth - estimatedWidth - marginX - (16 * density).toInt()).coerceAtLeast(0), (screenHeight - estimatedHeight - marginY - (48 * density).toInt()).coerceAtLeast(0))
                    "BOTTOM_CENTER" -> Pair((screenWidth / 2 - estimatedWidth / 2 + marginX).coerceAtLeast(0), (screenHeight - estimatedHeight - marginY - (48 * density).toInt()).coerceAtLeast(0))
                    "CENTER" -> Pair((screenWidth / 2 - estimatedWidth / 2 + marginX).coerceAtLeast(0), (screenHeight / 2 - estimatedHeight / 2 + marginY).coerceAtLeast(0))
                    else -> Pair((screenWidth - estimatedWidth - marginX - (16 * density).toInt()).coerceAtLeast(0), marginY + (48 * density).toInt())
                }

                val params = WindowManager.LayoutParams(
                    w,
                    h,
                    overlayType,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                    PixelFormat.TRANSLUCENT
                ).apply {
                    gravity = Gravity.TOP or Gravity.START
                    x = initCalcX
                    y = initCalcY
                }

                // Create custom Root Container
                val rootLayout = LinearLayout(context).apply {
                    orientation = LinearLayout.VERTICAL
                    val pad = (12 * density).toInt()
                    setPadding(pad, pad, pad, pad)
                    this.alpha = options.alpha.coerceIn(0.1f, 1.0f)
                    elevation = 16 * density

                    val bg = GradientDrawable().apply {
                        shape = GradientDrawable.RECTANGLE
                        cornerRadius = options.cornerRadius * density
                        val bgHex = options.backgroundColor ?: when (options.type.uppercase()) {
                            "STATUS_PILL" -> "#E6000000"
                            "STICKY_NOTE" -> "#E6FFF9C4"
                            "TERMINAL_MINI" -> "#F2121212"
                            "BADGE" -> "#E61A73E8"
                            else -> "#E61E1E2E"
                        }
                        val colorInt = try { Color.parseColor(bgHex) } catch (e: Exception) { Color.DKGRAY }
                        setColor(colorInt)
                        val strokeColor = try {
                            Color.parseColor(options.accentColor ?: "#44FFFFFF")
                        } catch (e: Exception) { Color.parseColor("#44FFFFFF") }
                        setStroke((1.5f * density).toInt(), strokeColor)
                    }
                    background = bg
                }

                var titleTv: TextView? = null
                var bodyTv: TextView? = null
                var subTv: TextView? = null

                // Header Bar (Title + Close Button)
                val headerRow = LinearLayout(context).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    layoutParams = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    )
                }

                if (!options.title.isNullOrBlank()) {
                    titleTv = TextView(context).apply {
                        text = options.title
                        textSize = options.textSize + 1
                        typeface = Typeface.DEFAULT_BOLD
                        val tColor = try {
                            Color.parseColor(options.accentColor ?: options.textColor ?: "#00E5FF")
                        } catch (e: Exception) { Color.CYAN }
                        setTextColor(tColor)
                        layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                    }
                    headerRow.addView(titleTv)
                } else {
                    val spacer = View(context).apply {
                        layoutParams = LinearLayout.LayoutParams(0, 0, 1f)
                    }
                    headerRow.addView(spacer)
                }

                if (options.showCloseButton) {
                    val closeBtn = TextView(context).apply {
                        text = "✕"
                        textSize = 14f
                        typeface = Typeface.DEFAULT_BOLD
                        val cColor = try {
                            Color.parseColor(options.textColor ?: "#B0BEC5")
                        } catch (e: Exception) { Color.LTGRAY }
                        setTextColor(cColor)
                        val padClose = (4 * density).toInt()
                        setPadding(padClose, 0, padClose, 0)
                        setOnClickListener {
                            hideFloating(options.floatingId)
                        }
                    }
                    headerRow.addView(closeBtn)
                }

                if (!options.title.isNullOrBlank() || options.showCloseButton) {
                    rootLayout.addView(headerRow)
                }

                // Main Body Text
                bodyTv = TextView(context).apply {
                    text = options.text
                    textSize = options.textSize
                    val defaultTextHex = if (options.type.equals("STICKY_NOTE", ignoreCase = true)) "#212121" else "#FFFFFF"
                    val bColor = try {
                        Color.parseColor(options.textColor ?: defaultTextHex)
                    } catch (e: Exception) { Color.WHITE }
                    setTextColor(bColor)
                    if (options.type.equals("TERMINAL_MINI", ignoreCase = true)) {
                        typeface = Typeface.MONOSPACE
                    }
                    val topMargin = if (!options.title.isNullOrBlank() || options.showCloseButton) (4 * density).toInt() else 0
                    layoutParams = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    ).apply {
                        setMargins(0, topMargin, 0, 0)
                    }
                }
                rootLayout.addView(bodyTv)

                // SubText / Timestamp / Metrics (optional)
                if (!options.subText.isNullOrBlank()) {
                    subTv = TextView(context).apply {
                        text = options.subText
                        textSize = (options.textSize - 2).coerceAtLeast(10f)
                        val sColor = try {
                            Color.parseColor(options.accentColor ?: "#90A4AE")
                        } catch (e: Exception) { Color.LTGRAY }
                        setTextColor(sColor)
                        layoutParams = LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.WRAP_CONTENT,
                            LinearLayout.LayoutParams.WRAP_CONTENT
                        ).apply {
                            setMargins(0, (3 * density).toInt(), 0, 0)
                        }
                    }
                    rootLayout.addView(subTv)
                }

                // Drag and Drop touch listener
                if (options.isDraggable) {
                    rootLayout.setOnTouchListener(object : View.OnTouchListener {
                        private var initialX = 0
                        private var initialY = 0
                        private var initialTouchX = 0f
                        private var initialTouchY = 0f
                        private var isMoving = false

                        override fun onTouch(v: View?, event: MotionEvent?): Boolean {
                            if (event == null) return false
                            when (event.action) {
                                MotionEvent.ACTION_DOWN -> {
                                    initialX = params.x
                                    initialY = params.y
                                    initialTouchX = event.rawX
                                    initialTouchY = event.rawY
                                    isMoving = false
                                    return false // allow children clicks if not dragging
                                }
                                MotionEvent.ACTION_MOVE -> {
                                    val dx = (event.rawX - initialTouchX).toInt()
                                    val dy = (event.rawY - initialTouchY).toInt()
                                    if (Math.abs(dx) > 10 || Math.abs(dy) > 10 || isMoving) {
                                        isMoving = true
                                        params.x = initialX + dx
                                        params.y = initialY + dy
                                        try {
                                            windowManager.updateViewLayout(rootLayout, params)
                                        } catch (e: Exception) {
                                            Log.w(TAG, "Error updating dragged overlay: ${e.message}")
                                        }
                                        return true
                                    }
                                }
                                MotionEvent.ACTION_UP -> {
                                    return isMoving
                                }
                            }
                            return false
                        }
                    })
                }

                windowManager.addView(rootLayout, params)

                var autoDismissRunnable: Runnable? = null
                if (options.autoDismissSeconds > 0) {
                    autoDismissRunnable = Runnable {
                        hideFloating(options.floatingId)
                    }
                    mainHandler.postDelayed(autoDismissRunnable, options.autoDismissSeconds * 1000L)
                }

                activeOverlays[options.floatingId] = ActiveOverlay(
                    view = rootLayout,
                    params = params,
                    titleView = titleTv,
                    bodyView = bodyTv,
                    subTextView = subTv,
                    autoDismissRunnable = autoDismissRunnable
                )

                Log.i(TAG, "Displayed floating overlay '${options.floatingId}' (type: ${options.type})")
            } catch (e: Exception) {
                Log.e(TAG, "Failed to display floating overlay: ${e.message}", e)
            }
        }
        return true
    }

    fun updateFloating(
        floatingId: String,
        text: String? = null,
        title: String? = null,
        subText: String? = null,
        backgroundColor: String? = null,
        textColor: String? = null
    ): Boolean {
        val overlay = activeOverlays[floatingId] ?: return false
        mainHandler.post {
            try {
                text?.let { overlay.bodyView?.text = it }
                title?.let { overlay.titleView?.text = it }
                subText?.let { overlay.subTextView?.text = it }
                
                textColor?.let {
                    val colorInt = Color.parseColor(it)
                    overlay.bodyView?.setTextColor(colorInt)
                }

                backgroundColor?.let {
                    val bg = overlay.view.background as? GradientDrawable
                    bg?.setColor(Color.parseColor(it))
                }

                windowManager.updateViewLayout(overlay.view, overlay.params)
                Log.d(TAG, "Updated floating overlay '$floatingId'")
            } catch (e: Exception) {
                Log.w(TAG, "Failed to update floating overlay '$floatingId': ${e.message}")
            }
        }
        return true
    }

    fun hideFloating(floatingId: String): Boolean {
        val overlay = activeOverlays.remove(floatingId) ?: return false
        mainHandler.post {
            try {
                overlay.autoDismissRunnable?.let { mainHandler.removeCallbacks(it) }
                overlay.view.animate()
                    .alpha(0f)
                    .scaleX(0.8f)
                    .scaleY(0.8f)
                    .setDuration(250)
                    .withEndAction {
                        try {
                            windowManager.removeView(overlay.view)
                        } catch (ignored: Exception) {}
                    }
                    .start()
                Log.i(TAG, "Dismissed floating overlay '$floatingId'")
            } catch (e: Exception) {
                try {
                    windowManager.removeView(overlay.view)
                } catch (ignored: Exception) {}
            }
        }
        return true
    }

    fun hideAllFloating() {
        val ids = activeOverlays.keys.toList()
        for (id in ids) {
            hideFloating(id)
        }
    }

    private fun parseGravity(gravityStr: String): Int {
        return when (gravityStr.uppercase()) {
            "TOP_LEFT" -> Gravity.TOP or Gravity.START
            "TOP_RIGHT" -> Gravity.TOP or Gravity.END
            "TOP_CENTER" -> Gravity.TOP or Gravity.CENTER_HORIZONTAL
            "BOTTOM_LEFT" -> Gravity.BOTTOM or Gravity.START
            "BOTTOM_RIGHT" -> Gravity.BOTTOM or Gravity.END
            "BOTTOM_CENTER" -> Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            "CENTER" -> Gravity.CENTER
            else -> Gravity.TOP or Gravity.END
        }
    }
}
