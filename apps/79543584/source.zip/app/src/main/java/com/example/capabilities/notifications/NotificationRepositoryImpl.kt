package com.example.capabilities.notifications

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import com.example.capabilities.CapabilityResult
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class NotificationRepositoryImpl @Inject constructor(
    @ApplicationContext private val context: Context
) : NotificationRepository {

    private val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    private val channelId = "aura_remote_notifications"
    private val authChannelId = "aura_security_auth_channel"

    init {
        createNotificationChannel()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "Aura System Notifications",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "Notifications received from Aura & Termux Assistant"
            }
            notificationManager.createNotificationChannel(channel)

            val authChannel = NotificationChannel(
                authChannelId,
                "AeroShare Security Authentication",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "High-priority security prompts for device pairing and face authentication"
                enableVibration(true)
                enableLights(true)
            }
            notificationManager.createNotificationChannel(authChannel)
        }
    }

    override fun showNotification(title: String, message: String): CapabilityResult<Unit> {
        return try {
            val notification = NotificationCompat.Builder(context, channelId)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle(title)
                .setContentText(message)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setAutoCancel(true)
                .build()

            val notificationId = (System.currentTimeMillis() % 10000).toInt()
            notificationManager.notify(notificationId, notification)
            CapabilityResult.Success(Unit)
        } catch (e: Exception) {
            CapabilityResult.Error("Failed to show notification: ${e.message}", e)
        }
    }

    override fun showProgressNotification(title: String, progress: Int, max: Int): CapabilityResult<Unit> {
        return try {
            val notification = NotificationCompat.Builder(context, channelId)
                .setSmallIcon(android.R.drawable.stat_sys_download)
                .setContentTitle(title)
                .setProgress(max, progress, false)
                .setOngoing(progress < max)
                .setAutoCancel(progress >= max)
                .build()

            notificationManager.notify(9999, notification)
            CapabilityResult.Success(Unit)
        } catch (e: Exception) {
            CapabilityResult.Error("Failed to show progress notification: ${e.message}", e)
        }
    }

    override fun showAuthNotification(
        title: String,
        message: String,
        securityDeviceId: String,
        requestId: String
    ): CapabilityResult<Unit> {
        return try {
            val intent = android.content.Intent(context, com.example.MainActivity::class.java).apply {
                flags = android.content.Intent.FLAG_ACTIVITY_NEW_TASK or
                        android.content.Intent.FLAG_ACTIVITY_CLEAR_TOP or
                        android.content.Intent.FLAG_ACTIVITY_SINGLE_TOP
                putExtra("AUTH_REQUEST_ID", requestId)
                putExtra("SECURITY_DEVICE_ID", securityDeviceId)
            }
            val pendingIntent = android.app.PendingIntent.getActivity(
                context,
                2026,
                intent,
                android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE
            )

            val notification = NotificationCompat.Builder(context, authChannelId)
                .setSmallIcon(android.R.drawable.ic_lock_lock)
                .setContentTitle(title)
                .setContentText(message)
                .setStyle(NotificationCompat.BigTextStyle().bigText(message))
                .setPriority(NotificationCompat.PRIORITY_MAX)
                .setCategory(NotificationCompat.CATEGORY_REMINDER)
                .setContentIntent(pendingIntent)
                .setAutoCancel(true)
                .setDefaults(NotificationCompat.DEFAULT_ALL)
                .build()

            val notificationId = 10099
            notificationManager.notify(notificationId, notification)
            CapabilityResult.Success(Unit)
        } catch (e: Exception) {
            CapabilityResult.Error("Failed to show auth notification: ${e.message}", e)
        }
    }
}

