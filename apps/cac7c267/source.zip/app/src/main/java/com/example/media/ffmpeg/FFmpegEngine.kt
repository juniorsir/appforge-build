package com.example.media.ffmpeg

import android.util.Log
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.FFmpegKitConfig
import com.arthenica.ffmpegkit.FFprobeKit
import com.arthenica.ffmpegkit.Packages
import com.arthenica.ffmpegkit.ReturnCode
import com.arthenica.ffmpegkit.SessionState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class FFmpegResult(
    val sessionId: Long,
    val isSuccess: Boolean,
    val returnCode: Int,
    val output: String,
    val failStackTrace: String? = null,
    val executionDurationMs: Long = 0L
)

object FFmpegEngine {
    private const val TAG = "FFmpegEngine"
    private var cachedDiagnostics: FFmpegDiagnostics? = null

    @Volatile
    private var isInitialized = false

    fun initialize() {
        if (isInitialized) return
        synchronized(this) {
            if (isInitialized) return
            try {
                // Ensure native libraries load cleanly and configure log levels
                FFmpegKitConfig.enableLogCallback { log ->
                    if (log.level.value >= com.arthenica.ffmpegkit.Level.AV_LOG_WARNING.value) {
                        Log.d(TAG, "[FFmpeg #${log.sessionId}] ${log.message.trimEnd()}")
                    }
                }
                isInitialized = true
                Log.i(TAG, "FFmpegEngine initialized successfully. Version: ${FFmpegKitConfig.getFFmpegVersion()}")
            } catch (t: Throwable) {
                Log.e(TAG, "Failed to initialize FFmpegKit: ${t.message}", t)
            }
        }
    }

    suspend fun getDiagnostics(forceRefresh: Boolean = false): FFmpegDiagnostics = withContext(Dispatchers.IO) {
        if (cachedDiagnostics != null && !forceRefresh) {
            return@withContext cachedDiagnostics!!
        }

        val startTime = System.currentTimeMillis()
        var classLoadingStatus = "UNKNOWN"
        var isAvailable = false
        var ffmpegVer = "N/A"
        var buildConfig = "N/A"
        var nativeLoaded = false
        var selfTestPassed = false
        var probeSelfTestPassed = false
        var packagesList = emptyList<String>()
        var errorMsg: String? = null

        try {
            // Explicit Runtime Class Detection
            try {
                Class.forName("com.arthenica.ffmpegkit.FFmpegKitConfig")
                Class.forName("com.arthenica.smartexception.java.Exceptions")
                classLoadingStatus = "CLASS FOUND"
            } catch (cnfe: ClassNotFoundException) {
                classLoadingStatus = "CLASS NOT FOUND: ${cnfe.message}"
                throw cnfe
            } catch (nde: NoClassDefFoundError) {
                classLoadingStatus = "CLASS NOT FOUND: ${nde.message}"
                throw nde
            }

            initialize()
            ffmpegVer = FFmpegKitConfig.getFFmpegVersion() ?: "Unknown"
            buildConfig = FFmpegKitConfig.getBuildDate() ?: "N/A"
            nativeLoaded = true
            isAvailable = true

            // Test harmless execution: -version
            val testSession = FFmpegKit.execute("-version")
            selfTestPassed = ReturnCode.isSuccess(testSession.returnCode)

            // Test harmless probe execution: -version
            val probeSession = FFprobeKit.execute("-version")
            probeSelfTestPassed = ReturnCode.isSuccess(probeSession.returnCode)

            // Determine registered packages
            val pkgs = mutableListOf<String>()
            try {
                if (Packages.getPackageName() != null) {
                    pkgs.add(Packages.getPackageName())
                }
            } catch (_: Throwable) {}
            packagesList = pkgs

        } catch (t: Throwable) {
            errorMsg = "${t.javaClass.simpleName}: ${t.message}"
            Log.e(TAG, "FFmpeg self-diagnostic failed", t)
        }

        val diag = FFmpegDiagnostics(
            isAvailable = isAvailable && selfTestPassed,
            ffmpegVersion = ffmpegVer,
            ffmpegKitVersion = "8.1.7",
            abi = "arm64-v8a",
            buildConfiguration = buildConfig,
            classLoadingStatus = classLoadingStatus,
            nativeLibraryLoaded = nativeLoaded,
            selfTestPassed = selfTestPassed,
            probeSelfTestPassed = probeSelfTestPassed,
            registeredPackages = packagesList,
            errorMessage = errorMsg,
            executionTimeMs = System.currentTimeMillis() - startTime
        )

        cachedDiagnostics = diag
        diag
    }

    suspend fun execute(command: String): FFmpegResult = withContext(Dispatchers.IO) {
        val start = System.currentTimeMillis()
        try {
            initialize()
            val session = FFmpegKit.execute(command)
            val duration = System.currentTimeMillis() - start
            val success = ReturnCode.isSuccess(session.returnCode)

            FFmpegResult(
                sessionId = session.sessionId,
                isSuccess = success,
                returnCode = session.returnCode?.value ?: -1,
                output = session.allLogsAsString ?: "",
                failStackTrace = session.failStackTrace,
                executionDurationMs = duration
            )
        } catch (t: Throwable) {
            Log.e(TAG, "FFmpeg execute failed", t)
            val duration = System.currentTimeMillis() - start
            FFmpegResult(
                sessionId = -1L,
                isSuccess = false,
                returnCode = -1,
                output = "FFmpeg Execution Error: ${t.javaClass.simpleName}: ${t.message}",
                failStackTrace = t.stackTraceToString(),
                executionDurationMs = duration
            )
        }
    }

    suspend fun executeWithArguments(arguments: Array<String>): FFmpegResult = withContext(Dispatchers.IO) {
        val start = System.currentTimeMillis()
        try {
            initialize()
            val session = FFmpegKit.executeWithArguments(arguments)
            val duration = System.currentTimeMillis() - start
            val success = ReturnCode.isSuccess(session.returnCode)

            FFmpegResult(
                sessionId = session.sessionId,
                isSuccess = success,
                returnCode = session.returnCode?.value ?: -1,
                output = session.allLogsAsString ?: "",
                failStackTrace = session.failStackTrace,
                executionDurationMs = duration
            )
        } catch (t: Throwable) {
            Log.e(TAG, "FFmpeg executeWithArguments failed", t)
            val duration = System.currentTimeMillis() - start
            FFmpegResult(
                sessionId = -1L,
                isSuccess = false,
                returnCode = -1,
                output = "FFmpeg Execution Error: ${t.javaClass.simpleName}: ${t.message}",
                failStackTrace = t.stackTraceToString(),
                executionDurationMs = duration
            )
        }
    }

    fun executeAsyncWithArguments(
        arguments: Array<String>,
        totalDurationMs: Long = 0L,
        onProgress: (FFmpegProgress) -> Unit,
        onComplete: (FFmpegResult) -> Unit
    ): Long {
        initialize()
        var sessionStartTime = System.currentTimeMillis()

        val session = FFmpegKit.executeWithArgumentsAsync(
            arguments,
            { completedSession ->
                FFmpegSessionManager.unregisterSession(completedSession.sessionId)
                val duration = System.currentTimeMillis() - sessionStartTime
                val success = ReturnCode.isSuccess(completedSession.returnCode)
                val isCancelled = ReturnCode.isCancel(completedSession.returnCode)

                if (isCancelled) {
                    onProgress(
                        FFmpegProgress(
                            sessionId = completedSession.sessionId,
                            state = FFmpegState.CANCELLED,
                            totalDurationMs = totalDurationMs
                        )
                    )
                } else if (success) {
                    onProgress(
                        FFmpegProgress(
                            sessionId = completedSession.sessionId,
                            state = FFmpegState.COMPLETED,
                            progressPercentage = 100f,
                            totalDurationMs = totalDurationMs
                        )
                    )
                } else {
                    onProgress(
                        FFmpegProgress(
                            sessionId = completedSession.sessionId,
                            state = FFmpegState.FAILED,
                            totalDurationMs = totalDurationMs,
                            logOutput = completedSession.allLogsAsString
                        )
                    )
                }

                onComplete(
                    FFmpegResult(
                        sessionId = completedSession.sessionId,
                        isSuccess = success,
                        returnCode = completedSession.returnCode?.value ?: -1,
                        output = completedSession.allLogsAsString ?: "",
                        failStackTrace = completedSession.failStackTrace,
                        executionDurationMs = duration
                    )
                )
            },
            { log ->
                // Optional log listener
            },
            { statistics ->
                val timeMs = statistics.time.toLong()
                val percentage = if (totalDurationMs > 0) {
                    (timeMs.toFloat() / totalDurationMs.toFloat() * 100f).coerceIn(0f, 99.9f)
                } else 0f

                val speed = statistics.speed
                val bitrate = statistics.bitrate
                val remainingMs = if (speed > 0 && totalDurationMs > timeMs) {
                    ((totalDurationMs - timeMs) / speed).toLong()
                } else 0L

                onProgress(
                    FFmpegProgress(
                        sessionId = statistics.sessionId,
                        state = FFmpegState.RUNNING,
                        progressPercentage = percentage,
                        currentTimestampMs = timeMs,
                        totalDurationMs = totalDurationMs,
                        speed = speed,
                        bitrateKbps = bitrate,
                        estimatedRemainingTimeMs = remainingMs
                    )
                )
            }
        )

        FFmpegSessionManager.registerSession(session)
        onProgress(
            FFmpegProgress(
                sessionId = session.sessionId,
                state = FFmpegState.STARTING,
                totalDurationMs = totalDurationMs
            )
        )
        return session.sessionId
    }

    fun cancel(sessionId: Long): Boolean {
        return FFmpegSessionManager.cancel(sessionId)
    }

    fun cancelAll() {
        FFmpegSessionManager.cancelAll()
    }
}
