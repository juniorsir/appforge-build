package com.example.ui.settings

import android.content.Context
import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.media.ffmpeg.FFmpegDiagnostics
import com.example.media.ffmpeg.FFmpegEngine
import com.example.media.ffmpeg.FFmpegResult
import com.example.media.storage.TemporaryMediaManager
import com.example.ui.*
import com.example.ui.theme.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Interactive FFmpeg Engine Verification, Diagnostics & Command Console Component.
 * Provides live native initialization checking, self-test verification, quick command presets,
 * real-time session execution with latency timing, and an interactive terminal console.
 */
@Composable
fun FFmpegConsoleCard(
    modifier: Modifier = Modifier,
    initialCommand: String = "-version"
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val clipboardManager = LocalClipboardManager.current

    var commandInput by remember { mutableStateOf(initialCommand) }
    var isExecuting by remember { mutableStateOf(false) }
    var activeSessionId by remember { mutableStateOf<Long?>(null) }
    var executionLatencyMs by remember { mutableLongStateOf(0L) }
    var returnCode by remember { mutableStateOf<Int?>(null) }
    var diagnostics by remember { mutableStateOf<FFmpegDiagnostics?>(null) }
    var isInitializing by remember { mutableStateOf(false) }

    // Console output text buffer
    var consoleOutput by remember {
        mutableStateOf(
            buildString {
                appendLine("╔══════════════════════════════════════════════════════════════╗")
                appendLine("║      FFmpegKit Native Engine Interactive Terminal Console    ║")
                appendLine("║   Distribution: dev.ffmpegkit-maintained:ffmpeg-kit-full:8.1.7║")
                appendLine("║   Architecture: arm64-v8a • 16 KB Page-Size Compliant        ║")
                appendLine("╚══════════════════════════════════════════════════════════════╝")
                appendLine("Tap 'Install / Verify Engine' or run a command preset below.")
            }
        )
    }

    // Auto-fetch initial diagnostics on first composition
    LaunchedEffect(Unit) {
        scope.launch(Dispatchers.IO) {
            val diag = FFmpegEngine.getDiagnostics(forceRefresh = false)
            diagnostics = diag
        }
    }

    val presetCommands = remember {
        listOf(
            "Quick -version" to "-version",
            "Build Config" to "-buildconf",
            "Supported Codecs" to "-codecs",
            "Demuxers & Muxers" to "-formats",
            "I/O Protocols" to "-protocols",
            "Audio/Video Filters" to "-filters",
            "FFprobe Version" to "ffprobe -version",
            "Synthetic Encoding Test" to "TEST_SYNTHETIC"
        )
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("ffmpeg_console_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = SleekCardDark),
        border = BorderStroke(1.dp, SleekBorderColor)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Header: Engine Info & Status Badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .background(
                                Brush.linearGradient(
                                    listOf(Color(0xFF00C853), Color(0xFF009688))
                                ),
                                RoundedCornerShape(10.dp)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Terminal,
                            contentDescription = "FFmpeg Console",
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    Column {
                        Text(
                            text = "FFmpeg Engine & Console",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = SleekTextPrimary
                            )
                        )
                        Text(
                            text = "Native v8.1.7 · arm64-v8a · 16KB Page-Size",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = SleekTextSecondary,
                                fontSize = 11.sp
                            )
                        )
                    }
                }

                // Active Engine Status Chip
                val isEngineReady = diagnostics?.isAvailable == true
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = if (isEngineReady) EmeraldSuccess.copy(alpha = 0.15f) else SleekPurpleLight.copy(alpha = 0.15f),
                    border = BorderStroke(
                        1.dp,
                        if (isEngineReady) EmeraldSuccess.copy(alpha = 0.4f) else SleekPurpleLight.copy(alpha = 0.4f)
                    )
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(CircleShape)
                                .background(if (isEngineReady) EmeraldSuccess else SleekPurpleLight)
                        )
                        Text(
                            text = if (isEngineReady) "ACTIVE" else "READY",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = if (isEngineReady) EmeraldSuccess else SleekPurpleLight,
                                fontSize = 10.sp
                            )
                        )
                    }
                }
            }

            // Engine Verification & Install Action Card
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = Color.Black.copy(alpha = 0.35f),
                border = BorderStroke(1.dp, SleekBorderColor.copy(alpha = 0.4f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
                        Text(
                            text = "Engine Installation & Native Verification",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                fontWeight = FontWeight.SemiBold,
                                color = SleekTextPrimary
                            )
                        )
                        Text(
                            text = if (diagnostics != null) {
                                "FFmpeg ${diagnostics?.ffmpegVersion} • Self-Test: ${if (diagnostics?.selfTestPassed == true) "PASS" else "PENDING"}"
                            } else {
                                "Check native JNI/AAR binaries and run diagnostic suite"
                            },
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = SleekTextSecondary,
                                fontSize = 11.sp
                            )
                        )
                    }

                    Button(
                        onClick = {
                            if (isInitializing) return@Button
                            isInitializing = true
                            scope.launch(Dispatchers.IO) {
                                try {
                                    FFmpegEngine.initialize()
                                    val diag = FFmpegEngine.getDiagnostics(forceRefresh = true)
                                    diagnostics = diag
                                    withContext(Dispatchers.Main) {
                                        val report = diag.toFormattedReport()
                                        consoleOutput = "$consoleOutput\n\n$report"
                                        Toast.makeText(
                                            context,
                                            if (diag.selfTestPassed) "FFmpeg Engine Verified Successfully!" else "Diagnostic completed with issues",
                                            Toast.LENGTH_SHORT
                                        ).show()
                                    }
                                } catch (t: Throwable) {
                                    withContext(Dispatchers.Main) {
                                        consoleOutput = "$consoleOutput\n\n[INIT ERROR] ${t.javaClass.simpleName}: ${t.message}"
                                    }
                                } finally {
                                    isInitializing = false
                                }
                            }
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = SleekPurpleLight,
                            contentColor = Color.Black
                        ),
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                        enabled = !isInitializing && !isExecuting,
                        modifier = Modifier.testTag("install_verify_ffmpeg_btn")
                    ) {
                        if (isInitializing) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(14.dp),
                                color = Color.Black,
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                        } else {
                            Icon(
                                imageVector = Icons.Default.Verified,
                                contentDescription = null,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                        }
                        Text(
                            text = if (isInitializing) "Verifying..." else "Verify Engine",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold)
                        )
                    }
                }
            }

            // Preset Command Chips
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    text = "COMMAND PRESETS & TEST SUITE",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = SleekTextSecondary,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.5.sp
                    )
                )

                val scrollState = rememberScrollState()
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(scrollState),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    presetCommands.forEach { (label, cmd) ->
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (commandInput == cmd) SleekPurpleLight.copy(alpha = 0.25f) else Color.White.copy(alpha = 0.05f),
                            border = BorderStroke(
                                1.dp,
                                if (commandInput == cmd) SleekPurpleLight else Color.White.copy(alpha = 0.1f)
                            ),
                            modifier = Modifier.clickable {
                                commandInput = cmd
                            }
                        ) {
                            Text(
                                text = label,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontSize = 11.sp,
                                    fontWeight = if (commandInput == cmd) FontWeight.Bold else FontWeight.Medium,
                                    color = if (commandInput == cmd) SleekPurpleLight else SleekTextPrimary
                                ),
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                            )
                        }
                    }
                }
            }

            // Command Input Field
            OutlinedTextField(
                value = commandInput,
                onValueChange = { commandInput = it },
                placeholder = {
                    Text(
                        "-version or ffprobe -version",
                        color = SleekTextSecondary.copy(alpha = 0.5f),
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace
                    )
                },
                leadingIcon = {
                    Text(
                        "$ ",
                        color = SleekPurpleLight,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        modifier = Modifier.padding(start = 12.dp)
                    )
                },
                textStyle = LocalTextStyle.current.copy(
                    fontFamily = FontFamily.Monospace,
                    fontSize = 12.sp,
                    color = SleekTextPrimary
                ),
                shape = RoundedCornerShape(12.dp),
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("ffmpeg_command_input"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = SleekTextPrimary,
                    unfocusedTextColor = SleekTextPrimary,
                    focusedBorderColor = SleekPurpleLight,
                    unfocusedBorderColor = SleekBorderColor,
                    focusedContainerColor = Color.Black.copy(alpha = 0.4f),
                    unfocusedContainerColor = Color.Black.copy(alpha = 0.4f)
                )
            )

            // Execution Action Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Execute Button
                Button(
                    onClick = {
                        val trimmed = commandInput.trim()
                        if (trimmed.isEmpty() || isExecuting) return@Button
                        isExecuting = true
                        returnCode = null
                        val startTime = System.currentTimeMillis()

                        scope.launch(Dispatchers.IO) {
                            try {
                                if (trimmed == "TEST_SYNTHETIC") {
                                    withContext(Dispatchers.Main) {
                                        consoleOutput = "$consoleOutput\n\n▶ Generating synthetic test card & audio sine wave (2s h264/aac mp4)..."
                                    }
                                    val tempOut = TemporaryMediaManager.createTempFile(context, "test_synth_", "mp4")
                                    val synthCmd = "-f lavfi -i testsrc=duration=2:size=320x240:rate=30 -f lavfi -i sine=frequency=1000:duration=2 -c:v libx264 -c:a aac -pix_fmt yuv420p -y ${tempOut.absolutePath}"
                                    val res = FFmpegEngine.execute(synthCmd)
                                    val duration = System.currentTimeMillis() - startTime
                                    executionLatencyMs = duration
                                    returnCode = res.returnCode
                                    val fileSize = if (tempOut.exists()) tempOut.length() else 0L
                                    tempOut.delete()

                                    withContext(Dispatchers.Main) {
                                        consoleOutput = buildString {
                                            append(consoleOutput)
                                            appendLine()
                                            appendLine("══════════════════════════════════════════════════════")
                                            appendLine("🧪 SYNTHETIC ENCODING TEST RESULTS")
                                            appendLine("══════════════════════════════════════════════════════")
                                            appendLine("Return Code: ${res.returnCode} (${if (res.isSuccess) "SUCCESS" else "FAILED"})")
                                            appendLine("Latency: ${duration}ms")
                                            appendLine("Generated Sample Size: $fileSize bytes")
                                            appendLine("─── ENGINE LOGS ───")
                                            appendLine(if (res.output.isNotBlank()) res.output.takeLast(2000) else "[No stdout]")
                                            if (res.failStackTrace != null) {
                                                appendLine("StackTrace: ${res.failStackTrace}")
                                            }
                                        }
                                    }
                                } else {
                                    withContext(Dispatchers.Main) {
                                        consoleOutput = "$consoleOutput\n\n▶ Executing: $trimmed"
                                    }

                                    // Run command through FFmpeg or FFprobe
                                    val res = if (trimmed.startsWith("ffprobe ", ignoreCase = true)) {
                                        val probeArgs = trimmed.removePrefix("ffprobe ").removePrefix("FFPROBE ").trim()
                                        val probeSession = com.arthenica.ffmpegkit.FFprobeKit.execute(probeArgs)
                                        FFmpegResult(
                                            sessionId = probeSession.sessionId,
                                            isSuccess = com.arthenica.ffmpegkit.ReturnCode.isSuccess(probeSession.returnCode),
                                            returnCode = probeSession.returnCode?.value ?: -1,
                                            output = probeSession.allLogsAsString ?: "",
                                            failStackTrace = probeSession.failStackTrace,
                                            executionDurationMs = System.currentTimeMillis() - startTime
                                        )
                                    } else {
                                        val ffmpegArgs = trimmed.removePrefix("ffmpeg ").removePrefix("FFMPEG ").trim()
                                        FFmpegEngine.execute(ffmpegArgs)
                                    }

                                    val duration = System.currentTimeMillis() - startTime
                                    executionLatencyMs = duration
                                    returnCode = res.returnCode

                                    withContext(Dispatchers.Main) {
                                        consoleOutput = buildString {
                                            append(consoleOutput)
                                            appendLine()
                                            appendLine("══════════════════════════════════════════════════════")
                                            appendLine("SESSION #${res.sessionId} FINISHED • Return Code: ${res.returnCode} (${if (res.isSuccess) "SUCCESS" else "FAILED"})")
                                            appendLine("Duration: ${duration}ms")
                                            appendLine("─── CONSOLE OUTPUT ───")
                                            appendLine(if (res.output.isNotBlank()) res.output else "[Empty stdout]")
                                            if (res.failStackTrace != null) {
                                                appendLine("Exception Trace:\n${res.failStackTrace}")
                                            }
                                        }
                                    }
                                }
                            } catch (t: Throwable) {
                                withContext(Dispatchers.Main) {
                                    consoleOutput = "$consoleOutput\n\n[EXECUTION ERROR] ${t.javaClass.simpleName}: ${t.message}"
                                }
                            } finally {
                                isExecuting = false
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color.White,
                        contentColor = Color.Black
                    ),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(44.dp)
                        .testTag("run_ffmpeg_command_btn"),
                    enabled = !isExecuting
                ) {
                    if (isExecuting) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(16.dp),
                            color = Color.Black,
                            strokeWidth = 2.dp
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Running...", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold))
                    } else {
                        Icon(Icons.Default.PlayArrow, contentDescription = "Run", modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Run Command", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold))
                    }
                }

                // Cancel Session Button (when running)
                if (isExecuting) {
                    Button(
                        onClick = {
                            activeSessionId?.let { FFmpegEngine.cancel(it) } ?: FFmpegEngine.cancelAll()
                            Toast.makeText(context, "Cancelling FFmpeg session...", Toast.LENGTH_SHORT).show()
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = CrimsonFailure,
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.height(44.dp).testTag("cancel_ffmpeg_session_btn")
                    ) {
                        Icon(Icons.Default.Cancel, contentDescription = "Cancel", modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Cancel", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold))
                    }
                }
            }

            // Terminal Output Console Box
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFF0D0D15))
                    .border(1.dp, SleekBorderColor.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
            ) {
                // Terminal Titlebar
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF141420))
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(Color(0xFFFF5F56)))
                        Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(Color(0xFFFFBD2E)))
                        Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(Color(0xFF27C93F)))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "terminal://ffmpeg",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontFamily = FontFamily.Monospace,
                                color = SleekTextSecondary,
                                fontSize = 11.sp
                            )
                        )
                    }

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (executionLatencyMs > 0) {
                            Text(
                                text = "${executionLatencyMs}ms",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontFamily = FontFamily.Monospace,
                                    color = SleekPurpleLight,
                                    fontSize = 10.sp
                                )
                            )
                        }

                        // Copy Button
                        IconButton(
                            onClick = {
                                clipboardManager.setText(AnnotatedString(consoleOutput))
                                Toast.makeText(context, "Console output copied to clipboard", Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.ContentCopy,
                                contentDescription = "Copy Output",
                                tint = SleekTextSecondary,
                                modifier = Modifier.size(14.dp)
                            )
                        }

                        // Clear Button
                        IconButton(
                            onClick = {
                                consoleOutput = "Console cleared.\n"
                                returnCode = null
                                executionLatencyMs = 0L
                            },
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.DeleteOutline,
                                contentDescription = "Clear Console",
                                tint = SleekTextSecondary,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                    }
                }

                // Scrollable Console Text Output Area
                val terminalScrollState = rememberScrollState()
                LaunchedEffect(consoleOutput) {
                    terminalScrollState.animateScrollTo(terminalScrollState.maxValue)
                }

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 160.dp, max = 280.dp)
                        .verticalScroll(terminalScrollState)
                        .padding(12.dp)
                ) {
                    SelectionContainer {
                        Text(
                            text = consoleOutput,
                            style = MaterialTheme.typography.bodySmall.copy(
                                fontFamily = FontFamily.Monospace,
                                fontSize = 11.sp,
                                lineHeight = 16.sp,
                                color = when {
                                    returnCode == 0 -> EmeraldSuccess
                                    returnCode != null && returnCode != 0 -> CrimsonFailure
                                    else -> Color(0xFFE2E8F0)
                                }
                            )
                        )
                    }
                }
            }
        }
    }
}
