import re

with open('app/src/main/java/com/example/ui/settings/SettingsCategoryPages.kt', 'r') as f:
    content = f.read()

# Delete lines 964 to 1012 which are leftover Cloud Dialog code with syntax errors
lines = content.split('\n')
new_lines = []
skip = False
for i, line in enumerate(lines):
    if i == 963: # index 963 is line 964
        skip = True
    
    if i == 1012: # index 1012 is line 1013 -> "Column("
        skip = False
        
    if not skip:
        new_lines.append(line)

with open('app/src/main/java/com/example/ui/settings/SettingsCategoryPages.kt', 'w') as f:
    f.write('\n'.join(new_lines))

