// just thinking out loud
