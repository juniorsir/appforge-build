package com.example

import org.junit.Assert.*
import org.junit.Test
import com.yausername.youtubedl_android.mapper.VideoInfo

class ExampleUnitTest {
  @Test
  fun addition_isCorrect() {
    assertEquals(4, 2 + 2)
  }

  @Test
  fun testFFmpegExtension() {
      println("--- FFMPEG EXTENSION AUDIT ---")
      try {
          val isAvailable = androidx.media3.decoder.ffmpeg.FfmpegLibrary.isAvailable()
          println("FfmpegLibrary.isAvailable(): $isAvailable")
          if (isAvailable) {
              val version = androidx.media3.decoder.ffmpeg.FfmpegLibrary.getVersion()
              println("FfmpegLibrary.getVersion(): $version")
          }
      } catch (e: Throwable) {
          println("FfmpegLibrary error: ${e.message}")
      }

      val mimesToTest = listOf(
          "audio/ac3", "audio/eac3", "audio/dts", "audio/flac", "audio/opus",
          "audio/vorbis", "audio/true-hd", "audio/alac", "audio/mp4a-latm", "audio/mpeg"
      )
      for (mime in mimesToTest) {
          val supported = try {
              androidx.media3.decoder.ffmpeg.FfmpegLibrary.supportsFormat(mime)
          } catch (e: Throwable) {
              false
          }
          println("Supports $mime: $supported")
      }
  }

  @Test
  fun testDeviceCodecReport() {
      try {
          val report = com.example.media.DecoderCapabilityManager.generateDeviceCodecReport()
          println("\n--- DEVICE CODEC REPORT ---")
          println(report)
      } catch (t: Throwable) {
          println("Device codec report handled gracefully on host JVM: ${t.message}")
      }
  }

  @Test
  fun testAudioEffectConfig() {
      val defaultCfg = com.example.ui.AudioEffectConfig()
      assertEquals(com.example.ui.AudioEffectPreset.OFF, defaultCfg.preset)
      assertEquals(0.0f, defaultCfg.intensity, 0.001f)
      assertFalse(defaultCfg.isEnabled)

      val smallRoomCfg = com.example.ui.AudioEffectConfig(
          preset = com.example.ui.AudioEffectPreset.SMALL_ROOM,
          intensity = 0.5f
      )
      assertTrue(smallRoomCfg.isEnabled)
      assertEquals("Small Room", smallRoomCfg.preset.displayName)
      assertEquals(0.5f, smallRoomCfg.intensity, 0.001f)

      val cathedralCfg = com.example.ui.AudioEffectConfig(
          preset = com.example.ui.AudioEffectPreset.CATHEDRAL,
          intensity = 1.0f
      )
      assertTrue(cathedralCfg.isEnabled)
      assertEquals("Cathedral", cathedralCfg.preset.displayName)
  }

  @Test
  fun testVideoColorAdjustments() {
      val defaultAdjustments = com.example.ui.VideoColorAdjustments()
      assertTrue(defaultAdjustments.isDefault)
      assertEquals(0.0f, defaultAdjustments.brightness, 0.001f)
      assertEquals(1.0f, defaultAdjustments.contrast, 0.001f)
      assertEquals(1.0f, defaultAdjustments.saturation, 0.001f)
      assertEquals(1.0f, defaultAdjustments.gamma, 0.001f)
      assertEquals(0.0f, defaultAdjustments.sharpness, 0.001f)
      assertEquals(0.0f, defaultAdjustments.temperature, 0.001f)
      assertEquals(0.0f, defaultAdjustments.highlights, 0.001f)
      assertEquals(0.0f, defaultAdjustments.shadows, 0.001f)
      assertEquals(1.0f, defaultAdjustments.vibrance, 0.001f)
      assertEquals(0.0f, defaultAdjustments.tint, 0.001f)

      val custom = defaultAdjustments.copy(brightness = 0.2f)
      assertFalse(custom.isDefault)
  }

  @Test
  fun testVocalReductionConfig() {
      val defaultCfg = com.example.ui.VocalReductionConfig()
      assertEquals(com.example.ui.VocalReductionMode.OFF, defaultCfg.mode)
      assertEquals(0.0f, defaultCfg.strength, 0.001f)
      assertFalse(defaultCfg.isEnabled)

      val lowCfg = com.example.ui.VocalReductionConfig(
          mode = com.example.ui.VocalReductionMode.LOW,
          strength = 0.25f
      )
      assertTrue(lowCfg.isEnabled)
      assertEquals("Low", lowCfg.mode.displayName)
      assertEquals(0.25f, lowCfg.strength, 0.001f)

      val strongCfg = com.example.ui.VocalReductionConfig(
          mode = com.example.ui.VocalReductionMode.STRONG,
          strength = 0.85f
      )
      assertTrue(strongCfg.isEnabled)
      assertEquals("Strong", strongCfg.mode.displayName)
  }

  @Test
  fun testVocalReductionAudioProcessorMath() {
      val processor = com.example.media.audiofx.VocalReductionAudioProcessor()
      processor.strength = 0.5f
      assertEquals(0.5f, processor.strength, 0.001f)

      // Test configuration with Stereo 16-bit PCM
      val stereoFormat = androidx.media3.common.audio.AudioProcessor.AudioFormat(
          44100,
          2,
          androidx.media3.common.C.ENCODING_PCM_16BIT
      )
      val outputFormat = processor.configure(stereoFormat)
      assertTrue(processor.isStereoCompatible)
      assertEquals(stereoFormat.sampleRate, outputFormat.sampleRate)
      assertEquals(2, outputFormat.channelCount)

      // Test configuration with Mono (should gracefully mark incompatible)
      val monoFormat = androidx.media3.common.audio.AudioProcessor.AudioFormat(
          44100,
          1,
          androidx.media3.common.C.ENCODING_PCM_16BIT
      )
      processor.configure(monoFormat)
      assertFalse(processor.isStereoCompatible)
  }

  @Test
  fun test0ByteFileDetection() {
      val tempFile = java.io.File.createTempFile("test_zero_byte", ".mp4")
      try {
          val result = com.example.download.recovery.DownloadValidator.validateFile(tempFile, expectedSize = 1000L)
          assertTrue(result is com.example.download.recovery.DownloadValidator.ValidationResult.ZeroByte)
      } finally {
          tempFile.delete()
      }
  }

  @Test
  fun testMissingFileDetection() {
      val nonExistent = java.io.File("/tmp/non_existent_file_${System.currentTimeMillis()}.mp4")
      val result = com.example.download.recovery.DownloadValidator.validateFile(nonExistent, expectedSize = 5000L)
      assertTrue(result is com.example.download.recovery.DownloadValidator.ValidationResult.MissingFile)
  }

  @Test
  fun testTruncatedIncompleteFileDetection() {
      val tempFile = java.io.File.createTempFile("test_partial", ".mp4")
      try {
          tempFile.writeBytes(ByteArray(500))
          val result = com.example.download.recovery.DownloadValidator.validateFile(tempFile, expectedSize = 10000L)
          assertTrue(result is com.example.download.recovery.DownloadValidator.ValidationResult.Incomplete)
          val incomplete = result as com.example.download.recovery.DownloadValidator.ValidationResult.Incomplete
          assertEquals(500L, incomplete.bytesDownloaded)
          assertEquals(10000L, incomplete.expectedBytes)
          assertTrue(incomplete.isResumable)
      } finally {
          tempFile.delete()
      }
  }

  @Test
  fun testMp4ContainerMagicBytesValidation() {
      val tempFile = java.io.File.createTempFile("test_mp4_magic", ".mp4")
      try {
          // Construct minimal MP4 header: 4 bytes length + 'ftyp' + 4 bytes brand
          val mp4Header = byteArrayOf(
              0x00, 0x00, 0x00, 0x18,
              'f'.code.toByte(), 't'.code.toByte(), 'y'.code.toByte(), 'p'.code.toByte(),
              'i'.code.toByte(), 's'.code.toByte(), 'o'.code.toByte(), 'm'.code.toByte()
          ) + ByteArray(10000)
          tempFile.writeBytes(mp4Header)
          val isValidMagic = com.example.download.recovery.DownloadValidator.checkHeaderMagic(tempFile)
          assertTrue(isValidMagic)
      } finally {
          tempFile.delete()
      }
  }

  @Test
  fun testWebmEbmlMagicBytesValidation() {
      val tempFile = java.io.File.createTempFile("test_webm_magic", ".webm")
      try {
          // EBML header: 0x1A 0x45 0xDF 0xA3
          val ebmlHeader = byteArrayOf(
              0x1A.toByte(), 0x45.toByte(), 0xDF.toByte(), 0xA3.toByte()
          ) + ByteArray(10000)
          tempFile.writeBytes(ebmlHeader)
          val isValidMagic = com.example.download.recovery.DownloadValidator.checkHeaderMagic(tempFile)
          assertTrue(isValidMagic)
      } finally {
          tempFile.delete()
      }
  }

  @Test
  fun testDownloadStatusEnumValues() {
      val statuses = com.example.ui.DownloadStatus.values().map { it.name }
      assertTrue(statuses.contains("QUEUED"))
      assertTrue(statuses.contains("DOWNLOADING"))
      assertTrue(statuses.contains("PAUSED"))
      assertTrue(statuses.contains("COMPLETED"))
      assertTrue(statuses.contains("FAILED"))
      assertTrue(statuses.contains("INCOMPLETE"))
      assertTrue(statuses.contains("CORRUPTED"))
      assertTrue(statuses.contains("RECOVERABLE"))
  }

  @Test
  fun testRecoveryPreservesOriginalMetadata() {
      val entity = com.example.data.DownloadEntity(
          id = "test_vid_1080",
          title = "Sample Presentation",
          author = "Creator",
          durationText = "03:45",
          thumbnailUrl = "https://example.com/thumb.jpg",
          localPath = "/data/sample.mp4",
          fileSize = 1024L,
          expectedSize = 50000L,
          originalUrl = "https://example.com/watch?v=12345",
          formatId = "137+140",
          formatQuality = "1080p",
          formatExt = "mp4",
          downloadStatus = "RECOVERABLE",
          statusMessage = "Interrupted (1024 bytes)"
      )
      assertEquals("https://example.com/watch?v=12345", entity.originalUrl)
      assertEquals("137+140", entity.formatId)
      assertEquals("1080p", entity.formatQuality)
      assertEquals("RECOVERABLE", entity.downloadStatus)
      assertEquals(50000L, entity.expectedSize)
  }

  @Test
  fun testAutoCleanDefaultSettings() {
      val defaultSettings = com.example.storage.cleanup.AutoCleanSettings()
      assertEquals(com.example.storage.cleanup.AutoCleanPeriod.OFF, defaultSettings.period)
      assertTrue(defaultSettings.keepFavorites)
      assertTrue(defaultSettings.keepPlaylistItems)
      assertTrue(defaultSettings.keepMarkedItems)
      assertFalse(defaultSettings.onlyCleanWhenStorageLow)
  }

  @Test
  fun testAutoCleanPeriodDurations() {
      assertEquals(0L, com.example.storage.cleanup.AutoCleanPeriod.OFF.durationMs)
      assertEquals(1 * 86400000L, com.example.storage.cleanup.AutoCleanPeriod.ONE_DAY.durationMs)
      assertEquals(3 * 86400000L, com.example.storage.cleanup.AutoCleanPeriod.THREE_DAYS.durationMs)
      assertEquals(7 * 86400000L, com.example.storage.cleanup.AutoCleanPeriod.SEVEN_DAYS.durationMs)
      assertEquals(14 * 86400000L, com.example.storage.cleanup.AutoCleanPeriod.FOURTEEN_DAYS.durationMs)
      assertEquals(30 * 86400000L, com.example.storage.cleanup.AutoCleanPeriod.THIRTY_DAYS.durationMs)
  }

  @Test
  fun testCompletionEligibilityRules() {
      val now = System.currentTimeMillis()
      val completedAgo10Days = now - (10 * 86400000L)
      val completedAgo2Days = now - (2 * 86400000L)

      // 7-day policy
      val period7Days = com.example.storage.cleanup.AutoCleanPeriod.SEVEN_DAYS

      // Item watched 10 days ago (more than 7 days) -> should be eligible
      val scheduled10Days = completedAgo10Days + period7Days.durationMs
      assertTrue(now >= scheduled10Days)

      // Item watched 2 days ago (less than 7 days) -> should NOT be eligible yet
      val scheduled2Days = completedAgo2Days + period7Days.durationMs
      assertFalse(now >= scheduled2Days)
  }

  @Test
  fun testCompletionThresholdEvaluation() {
      // Test media completion conditions (last 2-5% or <=5 seconds remaining)
      val durationMs = 100_000L // 100 seconds

      // 90 seconds (90%) -> NOT complete
      val pos90 = 90_000L
      val isComplete90 = (pos90.toDouble() / durationMs.toDouble() >= 0.95) || (durationMs - pos90 <= 5000L)
      assertFalse(isComplete90)

      // 96 seconds (96%) -> Complete
      val pos96 = 96_000L
      val isComplete96 = (pos96.toDouble() / durationMs.toDouble() >= 0.95) || (durationMs - pos96 <= 5000L)
      assertTrue(isComplete96)

      // 98 seconds (2s left) -> Complete
      val pos98 = 98_000L
      val isComplete98 = (pos98.toDouble() / durationMs.toDouble() >= 0.95) || (durationMs - pos98 <= 5000L)
      assertTrue(isComplete98)
  }

  @Test
  fun testProtectedMediaNeverEligible() {
      val downloadKept = com.example.data.DownloadEntity(
          id = "vid_keep_1",
          title = "Special Concert",
          author = "Artist",
          durationText = "1:00:00",
          thumbnailUrl = "",
          localPath = "/data/concert.mp4",
          fileSize = 1024L,
          isKept = true
      )
      assertTrue(downloadKept.isKept)

      val downloadFav = com.example.data.DownloadEntity(
          id = "vid_fav_1",
          title = "Favorite Documentary",
          author = "Director",
          durationText = "45:00",
          thumbnailUrl = "",
          localPath = "/data/doc.mp4",
          fileSize = 2048L,
          isFavorite = true
      )
      assertTrue(downloadFav.isFavorite)

      val downloadExplicitlyProtected = com.example.data.DownloadEntity(
          id = "vid_prot_1",
          title = "Protected Lecture",
          author = "Prof",
          durationText = "50:00",
          thumbnailUrl = "",
          localPath = "/data/lecture.mp4",
          fileSize = 4096L,
          isProtected = true
      )
      assertTrue(downloadExplicitlyProtected.isProtected)
  }

  @Test
  fun testCloudBackupSettingsAndConstraints() {
      val defaultSettings = com.example.backup.cloud.CloudBackupSettings()
      assertFalse(defaultSettings.includeDownloadedMedia)
      assertTrue(defaultSettings.wifiOnly)
      assertFalse(defaultSettings.chargingOnly)
      assertEquals(com.example.backup.cloud.AutoBackupFrequency.OFF, defaultSettings.autoBackupFrequency)
      assertEquals("Never", defaultSettings.lastBackupTime)

      val customSettings = defaultSettings.copy(
          includeDownloadedMedia = true,
          wifiOnly = false,
          autoBackupFrequency = com.example.backup.cloud.AutoBackupFrequency.DAILY
      )
      assertTrue(customSettings.includeDownloadedMedia)
      assertFalse(customSettings.wifiOnly)
      assertEquals(com.example.backup.cloud.AutoBackupFrequency.DAILY, customSettings.autoBackupFrequency)
  }

  @Test
  fun testBuiltInThemesResolution() {
      // AMOLED Black must resolve to true black #000000
      val amoledSettings = com.example.ui.theme.AppThemeSettings(
          themeMode = com.example.ui.theme.AppThemeMode.AMOLED_BLACK
      )
      assertTrue(amoledSettings.isAmoled)
      val amoledColors = com.example.ui.theme.resolveSleekColorsFromSettings(amoledSettings)
      assertEquals(androidx.compose.ui.graphics.Color(0xFF000000), amoledColors.bg)

      // Obsidian Dark Theme
      val obsidianSettings = com.example.ui.theme.AppThemeSettings(
          themeMode = com.example.ui.theme.AppThemeMode.OBSIDIAN
      )
      val obsidianColors = com.example.ui.theme.resolveSleekColorsFromSettings(obsidianSettings)
      assertEquals(androidx.compose.ui.graphics.Color(0xFF09090C), obsidianColors.bg)

      // Midnight Dark Theme
      val midnightSettings = com.example.ui.theme.AppThemeSettings(
          themeMode = com.example.ui.theme.AppThemeMode.MIDNIGHT
      )
      val midnightColors = com.example.ui.theme.resolveSleekColorsFromSettings(midnightSettings)
      assertEquals(androidx.compose.ui.graphics.Color(0xFF070B14), midnightColors.bg)

      // Graphite Dark Theme
      val graphiteSettings = com.example.ui.theme.AppThemeSettings(
          themeMode = com.example.ui.theme.AppThemeMode.GRAPHITE
      )
      val graphiteColors = com.example.ui.theme.resolveSleekColorsFromSettings(graphiteSettings)
      assertEquals(androidx.compose.ui.graphics.Color(0xFF121316), graphiteColors.bg)
  }

  @Test
  fun testAccentPaletteAndCustomColors() {
      // Test Purple (Default)
      val purpleSettings = com.example.ui.theme.AppThemeSettings(
          accentPalette = com.example.ui.theme.AccentPalette.PURPLE
      )
      val purpleColors = com.example.ui.theme.resolveSleekColorsFromSettings(purpleSettings)
      assertEquals(androidx.compose.ui.graphics.Color(0xFF8B5CF6), purpleColors.primary)

      // Test Orange
      val orangeSettings = com.example.ui.theme.AppThemeSettings(
          accentPalette = com.example.ui.theme.AccentPalette.ORANGE
      )
      val orangeColors = com.example.ui.theme.resolveSleekColorsFromSettings(orangeSettings)
      assertEquals(androidx.compose.ui.graphics.Color(0xFFFF6D00), orangeColors.primary)

      // Test Cyan
      val cyanSettings = com.example.ui.theme.AppThemeSettings(
          accentPalette = com.example.ui.theme.AccentPalette.CYAN
      )
      val cyanColors = com.example.ui.theme.resolveSleekColorsFromSettings(cyanSettings)
      assertEquals(androidx.compose.ui.graphics.Color(0xFF06B6D4), cyanColors.primary)

      // Test Custom Accent
      val customColorHex = 0xFFFF0055L
      val customSettings = com.example.ui.theme.AppThemeSettings(
          accentPalette = com.example.ui.theme.AccentPalette.CUSTOM,
          customAccentColor = customColorHex
      )
      val customColors = com.example.ui.theme.resolveSleekColorsFromSettings(customSettings)
      assertEquals(androidx.compose.ui.graphics.Color(customColorHex), customColors.primary)
  }

  @Test
  fun testThemeSafeFallback() {
      assertEquals(com.example.ui.theme.AppThemeMode.OBSIDIAN, com.example.ui.theme.AppThemeMode.fromId("INVALID_MODE_XYZ"))
      assertEquals(com.example.ui.theme.AppThemeMode.AMOLED_BLACK, com.example.ui.theme.AppThemeMode.fromId("AMOLED Black"))
      assertEquals(com.example.ui.theme.AppThemeMode.MIDNIGHT, com.example.ui.theme.AppThemeMode.fromId("Midnight"))
      assertEquals(com.example.ui.theme.AccentPalette.PURPLE, com.example.ui.theme.AccentPalette.fromId("UNKNOWN_COLOR"))
  }

  @Test
  fun testColorUtilsAndAccessibilityContrast() {
      // White background requires dark text
      val textOnWhite = com.example.ui.theme.ThemeColorUtils.getReadableTextColorForBackground(androidx.compose.ui.graphics.Color.White)
      assertEquals(androidx.compose.ui.graphics.Color(0xFF1A1A1A), textOnWhite)

      // Black background requires light text
      val textOnBlack = com.example.ui.theme.ThemeColorUtils.getReadableTextColorForBackground(androidx.compose.ui.graphics.Color.Black)
      assertEquals(androidx.compose.ui.graphics.Color.White, textOnBlack)

      // Color lighten / darken
      val baseColor = androidx.compose.ui.graphics.Color(0xFF8B5CF6)
      val lightened = com.example.ui.theme.ThemeColorUtils.lightenColor(baseColor, 0.3f)
      assertTrue(com.example.ui.theme.ThemeColorUtils.calculateLuminance(lightened) > com.example.ui.theme.ThemeColorUtils.calculateLuminance(baseColor))
  }

  @Test
  fun testPlayerGestureDefaultsAndFallback() {
      val settings = com.example.player.gestures.PlayerGestureSettings()
      
      // Default for TWO_FINGER_DOUBLE_TAP should be PLAY_PAUSE
      assertEquals(
          com.example.player.gestures.PlayerGestureAction.PLAY_PAUSE,
          settings.getActionFor(com.example.player.gestures.PlayerGesture.TWO_FINGER_DOUBLE_TAP)
      )

      // Other gestures should default to NONE
      assertEquals(
          com.example.player.gestures.PlayerGestureAction.NONE,
          settings.getActionFor(com.example.player.gestures.PlayerGesture.THREE_FINGER_TAP)
      )
      assertEquals(
          com.example.player.gestures.PlayerGestureAction.NONE,
          settings.getActionFor(com.example.player.gestures.PlayerGesture.TWO_FINGER_SWIPE_UP)
      )
      assertEquals(
          com.example.player.gestures.PlayerGestureAction.NONE,
          settings.getActionFor(com.example.player.gestures.PlayerGesture.TWO_FINGER_SWIPE_DOWN)
      )
      assertEquals(
          com.example.player.gestures.PlayerGestureAction.NONE,
          settings.getActionFor(com.example.player.gestures.PlayerGesture.LEFT_EDGE_SWIPE)
      )
      assertEquals(
          com.example.player.gestures.PlayerGestureAction.NONE,
          settings.getActionFor(com.example.player.gestures.PlayerGesture.RIGHT_EDGE_SWIPE)
      )
      assertEquals(
          com.example.player.gestures.PlayerGestureAction.NONE,
          settings.getActionFor(com.example.player.gestures.PlayerGesture.LONG_PRESS)
      )
  }

  @Test
  fun testPlayerGestureActionMapping() {
      var settings = com.example.player.gestures.PlayerGestureSettings()
      
      // Assign custom actions
      settings = settings.withAction(
          com.example.player.gestures.PlayerGesture.THREE_FINGER_TAP,
          com.example.player.gestures.PlayerGestureAction.MUTE_UNMUTE
      )
      settings = settings.withAction(
          com.example.player.gestures.PlayerGesture.TWO_FINGER_SWIPE_UP,
          com.example.player.gestures.PlayerGestureAction.NEXT_MEDIA
      )
      settings = settings.withAction(
          com.example.player.gestures.PlayerGesture.LONG_PRESS,
          com.example.player.gestures.PlayerGestureAction.SCREENSHOT
      )

      assertEquals(
          com.example.player.gestures.PlayerGestureAction.MUTE_UNMUTE,
          settings.getActionFor(com.example.player.gestures.PlayerGesture.THREE_FINGER_TAP)
      )
      assertEquals(
          com.example.player.gestures.PlayerGestureAction.NEXT_MEDIA,
          settings.getActionFor(com.example.player.gestures.PlayerGesture.TWO_FINGER_SWIPE_UP)
      )
      assertEquals(
          com.example.player.gestures.PlayerGestureAction.SCREENSHOT,
          settings.getActionFor(com.example.player.gestures.PlayerGesture.LONG_PRESS)
      )
  }

  @Test
  fun testPlayerGestureEnumLookup() {
      assertEquals(
          com.example.player.gestures.PlayerGesture.TWO_FINGER_DOUBLE_TAP,
          com.example.player.gestures.PlayerGesture.fromId("two_finger_double_tap")
      )
      assertEquals(
          com.example.player.gestures.PlayerGesture.LONG_PRESS,
          com.example.player.gestures.PlayerGesture.fromId("long_press")
      )
      assertNull(com.example.player.gestures.PlayerGesture.fromId("non_existent_gesture"))

      assertEquals(
          com.example.player.gestures.PlayerGestureAction.PLAY_PAUSE,
          com.example.player.gestures.PlayerGestureAction.fromId("play_pause")
      )
      assertEquals(
          com.example.player.gestures.PlayerGestureAction.SCREENSHOT,
          com.example.player.gestures.PlayerGestureAction.fromId("screenshot")
      )
      assertEquals(
          com.example.player.gestures.PlayerGestureAction.NONE,
          com.example.player.gestures.PlayerGestureAction.fromId("invalid_action_id")
      )
  }

  @Test
  fun testExtractValidUrl_ValidHttpAndHttps() {
      val httpsUrl = "https://www.youtube.com/watch?v=dQw4w9WgXcQ"
      assertEquals(httpsUrl, MainActivity.extractValidUrl(httpsUrl))

      val httpUrl = "http://example.com/media/sample.mp4"
      assertEquals(httpUrl, MainActivity.extractValidUrl(httpUrl))
  }

  @Test
  fun testExtractValidUrl_WithPunctuationAndQuotes() {
      val quotedUrl = "\"https://instagram.com/reel/C12345/\""
      assertEquals("https://instagram.com/reel/C12345/", MainActivity.extractValidUrl(quotedUrl))

      val trailingPeriod = "Check out https://tiktok.com/@user/video/987654321."
      assertEquals("https://tiktok.com/@user/video/987654321", MainActivity.extractValidUrl(trailingPeriod))

      val bracketed = "<https://twitter.com/i/status/123456789>"
      assertEquals("https://twitter.com/i/status/123456789", MainActivity.extractValidUrl(bracketed))
  }

  @Test
  fun testExtractValidUrl_FromShareText() {
      val shareText = "Look at this video https://vimeo.com/123456 shared via App"
      assertEquals("https://vimeo.com/123456", MainActivity.extractValidUrl(shareText))
  }

  @Test
  fun testExtractValidUrl_RejectsContentAndFileSchemes() {
      assertNull(MainActivity.extractValidUrl("content://media/external/images/media/123"))
      assertNull(MainActivity.extractValidUrl("file:///sdcard/Download/video.mp4"))
      assertNull(MainActivity.extractValidUrl("javascript:alert(1)"))
      assertNull(MainActivity.extractValidUrl("data:text/plain;base64,SGVsbG8="))
  }

  @Test
  fun testExtractValidUrl_RejectsMalformedAndEmpty() {
      assertNull(MainActivity.extractValidUrl(null))
      assertNull(MainActivity.extractValidUrl(""))
      assertNull(MainActivity.extractValidUrl("   "))
      assertNull(MainActivity.extractValidUrl("http://"))
      assertNull(MainActivity.extractValidUrl("https://"))
      assertNull(MainActivity.extractValidUrl("Just ordinary plain text without links"))
  }
}
