package com.example.data

import android.content.Context
import android.os.Environment
import android.util.Log
import com.example.DownloadManager
import com.example.ui.ActiveDownloadTask
import com.example.ui.DownloadStatus
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object DownloadBackupManager {
    private const val TAG = "DownloadBackupManager"
    private const val BACKUP_FILENAME = "downloads_backup.json"

    // Retrieve target backup file locations surviving uninstalls
    fun getBackupFiles(context: Context): List<File> {
        val files = mutableListOf<File>()
        
        // 1. App-specific external storage (Guaranteed safe and permission-free on Android 11+)
        try {
            context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)?.let {
                files.add(File(it, BACKUP_FILENAME))
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error getting external files dir: ${e.message}")
        }

        // 2. Public Downloads directory if accessible
        try {
            val safeDir = com.example.util.DeviceCompatHelper.getSafeDownloadDirectory(context, preferPublic = true)
            files.add(File(safeDir, BACKUP_FILENAME))
        } catch (e: Exception) {
            Log.e(TAG, "Error getting safe downloads dir: ${e.message}")
        }

        // 3. App internal files directory fallback
        try {
            files.add(File(context.filesDir, BACKUP_FILENAME))
        } catch (e: Exception) {
            Log.e(TAG, "Error getting internal files dir: ${e.message}")
        }

        return files.distinctBy { it.absolutePath }
    }

    // Return backup file information (last modified time and size stats)
    fun getBackupStatus(context: Context): Pair<String, String> {
        val files = getBackupFiles(context)
        for (file in files) {
            if (file.exists() && file.length() > 0) {
                try {
                    val date = Date(file.lastModified())
                    val sdf = SimpleDateFormat("MMM dd, yyyy HH:mm:ss", Locale.getDefault())
                    val content = file.readText()
                    val root = JSONObject(content)
                    val completedCount = root.optJSONArray("completed")?.length() ?: 0
                    val failedCount = root.optJSONArray("failed")?.length() ?: 0
                    return Pair(
                        sdf.format(date),
                        "$completedCount completed, $failedCount failed"
                    )
                } catch (e: Exception) {
                    Log.e(TAG, "Failed to read stats from backup file: ${e.message}")
                }
            }
        }
        return Pair("Never", "No backup found")
    }

    // Backup completed downloads and failed downloads to file
    fun backup(context: Context, completedList: List<DownloadEntity>, failedList: List<ActiveDownloadTask> = emptyList()) {
        try {
            val root = JSONObject()
            
            val completedArray = JSONArray()
            completedList.forEach { entity ->
                val obj = JSONObject().apply {
                    put("id", entity.id)
                    put("title", entity.title)
                    put("author", entity.author)
                    put("durationText", entity.durationText)
                    put("thumbnailUrl", entity.thumbnailUrl)
                    put("localPath", entity.localPath)
                    put("fileSize", entity.fileSize)
                    put("downloadedAt", entity.downloadedAt)
                }
                completedArray.put(obj)
            }
            root.put("completed", completedArray)

            // Keep track of previously backed up failed downloads so we don't clear them
            val currentFailedMap = failedList.associateBy { it.id }.toMutableMap()
            
            // Read existing backup first to load previous failures
            val existingBackup = readBackupData(context)
            existingBackup?.optJSONArray("failed")?.let { failedArray ->
                for (i in 0 until failedArray.length()) {
                    val obj = failedArray.getJSONObject(i)
                    val id = obj.optString("id")
                    if (id.isNotEmpty() && !currentFailedMap.containsKey(id)) {
                        val task = ActiveDownloadTask(
                            id = id,
                            title = obj.optString("title"),
                            progress = 0f,
                            speedText = "Failed",
                            downloadedBytes = 0,
                            totalBytes = obj.optLong("totalBytes"),
                            status = DownloadStatus.FAILED,
                            ext = obj.optString("ext"),
                            error = obj.optString("error")
                        )
                        currentFailedMap[id] = task
                    }
                }
            }

            val failedArray = JSONArray()
            currentFailedMap.values.forEach { task ->
                val obj = JSONObject().apply {
                    put("id", task.id)
                    put("title", task.title)
                    put("totalBytes", task.totalBytes)
                    put("ext", task.ext)
                    put("error", task.error ?: "Download failed.")
                }
                failedArray.put(obj)
            }
            root.put("failed", failedArray)

            val jsonStr = root.toString(2)
            
            // Write to all target files (Public Downloads & direct fallback)
            val targetFiles = getBackupFiles(context)
            for (file in targetFiles) {
                try {
                    val parent = file.parentFile
                    if (parent != null && !parent.exists()) {
                        parent.mkdirs()
                    }
                    file.writeText(jsonStr)
                    Log.d(TAG, "Successfully wrote backup file: ${file.absolutePath}")
                } catch (e: Exception) {
                    Log.e(TAG, "Failed writing backup to ${file.absolutePath}: ${e.message}")
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error in backup process: ${e.message}", e)
        }
    }

    private fun readBackupData(context: Context): JSONObject? {
        val targetFiles = getBackupFiles(context)
        for (file in targetFiles) {
            if (file.exists()) {
                try {
                    val content = file.readText()
                    if (content.isNotBlank()) {
                        return JSONObject(content)
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "Failed reading backup from ${file.absolutePath}: ${e.message}")
                }
            }
        }
        return null
    }

    // Restore download records and failed downloads from backup file
    suspend fun restore(context: Context, database: AppDatabase): Boolean {
        var restoredAny = false
        try {
            val root = readBackupData(context) ?: return false
            Log.d(TAG, "Found backup data! Restoring metadata into Room and DownloadManager...")

            val completedArray = root.optJSONArray("completed")
            if (completedArray != null && completedArray.length() > 0) {
                val dao = database.downloadDao()
                for (i in 0 until completedArray.length()) {
                    val obj = completedArray.getJSONObject(i)
                    val id = obj.getString("id")
                    
                    val existing = dao.getDownloadById(id)
                    if (existing == null) {
                        val entity = DownloadEntity(
                            id = id,
                            title = obj.getString("title"),
                            author = obj.getString("author"),
                            durationText = obj.getString("durationText"),
                            thumbnailUrl = obj.getString("thumbnailUrl"),
                            localPath = obj.getString("localPath"),
                            fileSize = obj.getLong("fileSize"),
                            downloadedAt = obj.getLong("downloadedAt")
                        )
                        dao.insertDownload(entity)
                        restoredAny = true
                        Log.d(TAG, "Restored completed item in database: ${entity.title}")
                    }
                }
            }

            val failedArray = root.optJSONArray("failed")
            if (failedArray != null && failedArray.length() > 0) {
                val currentActive = DownloadManager.activeDownloads.value.toMutableMap()
                var updated = false
                for (i in 0 until failedArray.length()) {
                    val obj = failedArray.getJSONObject(i)
                    val id = obj.getString("id")
                    
                    if (!currentActive.containsKey(id)) {
                        val task = ActiveDownloadTask(
                            id = id,
                            title = obj.getString("title"),
                            progress = 0f,
                            speedText = "Failed",
                            downloadedBytes = 0,
                            totalBytes = obj.optLong("totalBytes"),
                            status = DownloadStatus.FAILED,
                            ext = obj.optString("ext"),
                            error = obj.optString("error", "Download failed.")
                        )
                        currentActive[id] = task
                        updated = true
                        restoredAny = true
                        Log.d(TAG, "Restored failed item in DownloadManager: ${task.title}")
                    }
                }
                if (updated) {
                    DownloadManager.updateActiveDownloads(currentActive)
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error in restore process: ${e.message}", e)
        }
        return restoredAny
    }
}
