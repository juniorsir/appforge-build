package com.example.media.orchestration

enum class PlaybackErrorCategory {
    NETWORK_ERROR,
    DEMUX_ERROR,
    DECODER_UNSUPPORTED,
    DECODER_INITIALIZATION_FAILURE,
    DECODER_RUNTIME_FAILURE,
    AUDIO_OUTPUT_FAILURE,
    SURFACE_FAILURE,
    DRM_ERROR,
    CORRUPTED_MEDIA,
    UNKNOWN_ERROR
}

class DefaultDecoderFailureManager : DecoderFailureManager {
    
    private val failures = mutableMapOf<String, MutableList<String>>() // mimeType -> list of failed decoder names
    val eventLog = BoundedDecoderEventLog(maxEntries = 100)

    override fun classifyFailure(cause: Throwable): DecoderFailureType {
        val msg = cause.message?.lowercase() ?: ""
        val typeName = cause.javaClass.simpleName
        
        return when {
            typeName.contains("DecoderInitializationException") -> DecoderFailureType.DECODER_INITIALIZATION_FAILED
            msg.contains("format not supported") -> DecoderFailureType.UNSUPPORTED_CODEC
            msg.contains("profile") -> DecoderFailureType.UNSUPPORTED_PROFILE
            msg.contains("level") -> DecoderFailureType.UNSUPPORTED_LEVEL
            msg.contains("resolution") -> DecoderFailureType.UNSUPPORTED_RESOLUTION
            msg.contains("audiotrack") -> DecoderFailureType.AUDIO_OUTPUT_FAILED
            msg.contains("surface") -> DecoderFailureType.SURFACE_INITIALIZATION_FAILED
            msg.contains("corrupt") -> DecoderFailureType.CORRUPTED_STREAM
            else -> DecoderFailureType.DECODER_RUNTIME_FAILED
        }
    }

    fun classifyErrorCategory(cause: Throwable): PlaybackErrorCategory {
        val msg = cause.message?.lowercase() ?: ""
        val typeName = cause.javaClass.simpleName

        return when {
            typeName.contains("Http") || typeName.contains("Network") || msg.contains("network") || msg.contains("connection") || msg.contains("timeout") -> PlaybackErrorCategory.NETWORK_ERROR
            typeName.contains("Extractor") || typeName.contains("Parser") || msg.contains("demux") || msg.contains("container") -> PlaybackErrorCategory.DEMUX_ERROR
            typeName.contains("DecoderInitializationException") -> PlaybackErrorCategory.DECODER_INITIALIZATION_FAILURE
            typeName.contains("MediaCodec") || msg.contains("codec") -> PlaybackErrorCategory.DECODER_RUNTIME_FAILURE
            msg.contains("audiotrack") || msg.contains("audio_output") -> PlaybackErrorCategory.AUDIO_OUTPUT_FAILURE
            msg.contains("surface") || msg.contains("display") -> PlaybackErrorCategory.SURFACE_FAILURE
            typeName.contains("Drm") || msg.contains("drm") -> PlaybackErrorCategory.DRM_ERROR
            msg.contains("corrupt") || msg.contains("invalid data") -> PlaybackErrorCategory.CORRUPTED_MEDIA
            msg.contains("unsupported") -> PlaybackErrorCategory.DECODER_UNSUPPORTED
            else -> PlaybackErrorCategory.UNKNOWN_ERROR
        }
    }

    override fun recordFailure(decoderName: String?, mimeType: String, failureType: DecoderFailureType, cause: Throwable) {
        if (decoderName != null) {
            val list = failures.getOrPut(mimeType) { mutableListOf() }
            if (!list.contains(decoderName)) {
                list.add(decoderName)
            }
        }
        val cat = classifyErrorCategory(cause)
        eventLog.logEvent(
            category = cat.name,
            message = "Failure recorded: ${cause.message ?: cause.javaClass.simpleName}",
            decoderName = decoderName,
            mimeType = mimeType
        )
    }

    override fun getFailedDecoders(mimeType: String): List<String> {
        return failures[mimeType] ?: emptyList()
    }

    fun isBlacklisted(decoderName: String, mimeType: String): Boolean {
        return failures[mimeType]?.contains(decoderName) == true
    }

    override fun clearFailures() {
        failures.clear()
        eventLog.clear()
    }
}

