package com.example

import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.VideoView
import android.media.MediaPlayer
import kotlinx.coroutines.*
import com.example.data.YoutubeRepository
import com.example.ui.YtdlpPipelineManager
import com.example.ui.VideoFormatUi
import com.example.ui.AnalyzedVideo
import com.example.ui.ThreeDClockRollerView
import coil.load

class FloatingBubbleService : Service() {
    private lateinit var windowManager: WindowManager
    private var bubbleView: ImageView? = null
    private var expandedView: LinearLayout? = null
    private var resultCard: LinearLayout? = null
    private var titleView: TextView? = null
    private var durationView: TextView? = null
    private var thumbnailView: ImageView? = null
    
    private var mediaContainer: FrameLayout? = null
    private var videoView: VideoView? = null
    
    private var clockRollerView: ThreeDClockRollerView? = null
    
    private var currentFormats = listOf<VideoFormatUi>()
    private var selectedFormat: VideoFormatUi? = null
    private var currentAnalyzedVideo: AnalyzedVideo? = null
    
    private lateinit var bubbleParams: WindowManager.LayoutParams
    private lateinit var expandedParams: WindowManager.LayoutParams

    private var isExpanded = false
    private val serviceScope = CoroutineScope(Dispatchers.Main + Job())

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        if (!canDrawOverlaysSafe(this)) {
            isRunning = false
            stopSelf()
            return
        }

        isRunning = true
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        initUI()
    }

    private fun initUI() {
        createBubbleView()
        createExpandedView()
    }

    private fun createBubbleView() {
        val size = dpToPx(60)
        bubbleView = ImageView(this).apply {
            setImageResource(android.R.drawable.ic_menu_search)
            val bg = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#8B1E2D"))
                setStroke(dpToPx(2), Color.parseColor("#333333"))
            }
            background = bg
            setPadding(dpToPx(12), dpToPx(12), dpToPx(12), dpToPx(12))
            setColorFilter(Color.WHITE)
            elevation = dpToPx(8).toFloat()
        }

        val layoutFlag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        bubbleParams = WindowManager.LayoutParams(
            size,
            size,
            layoutFlag,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dpToPx(16)
            y = dpToPx(100)
        }

        bubbleView?.let { setupDragListener(it, false) }

        try {
            windowManager.addView(bubbleView, bubbleParams)
        } catch (e: Exception) {
            e.printStackTrace()
            isRunning = false
            stopSelf()
        }
    }

    private fun createExpandedView() {
        val layoutFlag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        expandedParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutFlag,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dpToPx(16)
            y = dpToPx(100)
            width = dpToPx(340)
        }

        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val bg = GradientDrawable().apply {
                setColor(Color.parseColor("#141414")) // Dark space gray
                cornerRadius = dpToPx(16).toFloat()
                setStroke(dpToPx(1), Color.parseColor("#2C2C2C")) // Clean, subtle border
            }
            background = bg
            setPadding(dpToPx(12), dpToPx(12), dpToPx(12), dpToPx(12))
            elevation = dpToPx(16).toFloat()
        }

        // --- TOP BAR ---
        val topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = dpToPx(4)
            }
        }

        val dragHandle = ImageView(this).apply {
            setImageResource(R.drawable.ic_drag_modern)
            setColorFilter(Color.parseColor("#888888"))
            setPadding(dpToPx(10), dpToPx(10), dpToPx(10), dpToPx(10))
        }
        setupDragListener(dragHandle, true)
        topBar.addView(dragHandle, LinearLayout.LayoutParams(dpToPx(40), dpToPx(40)))

        // Modern Rounded Pill container for text input
        val inputContainer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            val pillBg = GradientDrawable().apply {
                setColor(Color.parseColor("#1E1E1E"))
                cornerRadius = dpToPx(12).toFloat()
                setStroke(dpToPx(1), Color.parseColor("#333333"))
            }
            background = pillBg
            setPadding(dpToPx(10), dpToPx(6), dpToPx(10), dpToPx(6))
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                marginEnd = dpToPx(6)
                marginStart = dpToPx(4)
            }
        }

        val inputField = EditText(this).apply {
            hint = "URL or search..."
            setHintTextColor(Color.parseColor("#666666"))
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            background = null
            setPadding(dpToPx(4), dpToPx(2), dpToPx(4), dpToPx(2))
            maxLines = 1
            inputType = android.text.InputType.TYPE_TEXT_VARIATION_URI
        }
        inputContainer.addView(inputField, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        topBar.addView(inputContainer)

        val goButton = ImageView(this).apply {
            setImageResource(R.drawable.ic_search_modern)
            setColorFilter(Color.WHITE)
            val btnBg = GradientDrawable().apply {
                setColor(Color.parseColor("#E53935")) // Vibrant crimson red
                cornerRadius = dpToPx(12).toFloat()
            }
            background = btnBg
            setPadding(dpToPx(10), dpToPx(10), dpToPx(10), dpToPx(10))
            setOnClickListener {
                val query = inputField.text.toString().trim()
                if (query.isNotEmpty()) {
                    performSearch(query)
                }
            }
        }
        topBar.addView(goButton, LinearLayout.LayoutParams(dpToPx(40), dpToPx(40)))

        val closeButton = ImageView(this).apply {
            setImageResource(R.drawable.ic_close_modern)
            setColorFilter(Color.parseColor("#888888"))
            setPadding(dpToPx(10), dpToPx(10), dpToPx(10), dpToPx(10))
            setOnClickListener { collapse() }
        }
        topBar.addView(closeButton, LinearLayout.LayoutParams(dpToPx(40), dpToPx(40)))

        container.addView(topBar)

        // --- RESULT CARD ---
        resultCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            val cardBg = GradientDrawable().apply {
                setColor(Color.parseColor("#1A1A1A")) // Modern dark card color
                cornerRadius = dpToPx(14).toFloat()
                setStroke(dpToPx(1), Color.parseColor("#2D2D2D"))
            }
            background = cardBg
            setPadding(dpToPx(10), dpToPx(10), dpToPx(10), dpToPx(10))
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                topMargin = dpToPx(8)
            }
        }

        mediaContainer = FrameLayout(this).apply {
            val params = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dpToPx(150))
            params.bottomMargin = dpToPx(10)
            layoutParams = params
            val containerBg = GradientDrawable().apply {
                setColor(Color.BLACK)
                cornerRadius = dpToPx(10).toFloat()
            }
            background = containerBg
            clipToOutline = true
        }
        
        thumbnailView = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            val bg = GradientDrawable().apply { cornerRadius = dpToPx(12).toFloat() }
            clipToOutline = true
        }
        mediaContainer?.addView(thumbnailView, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        
        videoView = VideoView(this).apply {
            visibility = View.GONE
        }
        mediaContainer?.addView(videoView, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT, Gravity.CENTER))

        resultCard?.addView(mediaContainer)

        titleView = TextView(this).apply {
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            maxLines = 2
            ellipsize = android.text.TextUtils.TruncateAt.END
        }
        resultCard?.addView(titleView)
        
        durationView = TextView(this).apply {
            setTextColor(Color.parseColor("#A8A8A8"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            setPadding(0, dpToPx(4), 0, dpToPx(12))
        }
        resultCard?.addView(durationView)

        // Lower row for Format Selection (Left) and Actions (Right)
        val lowerRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                topMargin = dpToPx(8)
            }
        }

        // 1. Beautiful Framed Roller Container
        val rollerContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.2f)
        }

        val rollerLabel = TextView(this).apply {
            text = "SELECT QUALITY"
            setTextColor(Color.parseColor("#777777"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 9f)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(dpToPx(2), 0, 0, dpToPx(4))
        }
        rollerContainer.addView(rollerLabel)

        val rollerCard = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            val bg = GradientDrawable().apply {
                setColor(Color.parseColor("#151515"))
                cornerRadius = dpToPx(12).toFloat()
                setStroke(dpToPx(1), Color.parseColor("#2D2D2D"))
            }
            background = bg
            setPadding(dpToPx(4), dpToPx(4), dpToPx(4), dpToPx(4))
        }

        val roller = ThreeDClockRollerView(this).apply {
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dpToPx(76))
        }
        clockRollerView = roller
        rollerCard.addView(roller)
        rollerContainer.addView(rollerCard)
        lowerRow.addView(rollerContainer)

        // 2. Beautiful Framed Actions Container
        val actionsContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 0.8f).apply {
                marginStart = dpToPx(12)
            }
        }

        val actionsLabel = TextView(this).apply {
            text = "ACTIONS"
            setTextColor(Color.parseColor("#777777"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 9f)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, 0, 0, dpToPx(8))
        }
        actionsContainer.addView(actionsLabel)

        val buttonsRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }

        val playBtn = ImageView(this).apply {
            setImageResource(R.drawable.ic_play_modern)
            setColorFilter(Color.WHITE)
            val bg = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#10B981")) // Vibrant emerald green
            }
            background = bg
            setPadding(dpToPx(10), dpToPx(10), dpToPx(10), dpToPx(10))
            layoutParams = LinearLayout.LayoutParams(dpToPx(40), dpToPx(40)).apply {
                marginEnd = dpToPx(8)
            }
            setOnClickListener { playMedia() }
        }
        buttonsRow.addView(playBtn)

        val downloadBtn = ImageView(this).apply {
            setImageResource(R.drawable.ic_download_modern)
            setColorFilter(Color.WHITE)
            val bg = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#F59E0B")) // Vibrant amber yellow
            }
            background = bg
            setPadding(dpToPx(10), dpToPx(10), dpToPx(10), dpToPx(10))
            layoutParams = LinearLayout.LayoutParams(dpToPx(40), dpToPx(40))
            setOnClickListener { triggerDownload() }
        }
        buttonsRow.addView(downloadBtn)

        actionsContainer.addView(buttonsRow)
        lowerRow.addView(actionsContainer)

        resultCard?.addView(lowerRow)

        container.addView(resultCard)

        expandedView = container
        expandedView?.visibility = View.GONE
        try {
            windowManager.addView(expandedView, expandedParams)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun updateFormatsUI() {
        val roller = clockRollerView ?: return
        val items = currentFormats.map { it.quality }
        val currentIndex = currentFormats.indexOfFirst { it.formatId == selectedFormat?.formatId }
            .coerceAtLeast(0)
        
        roller.setItems(items, currentIndex)
        roller.setOnItemSelectedListener { index ->
            if (index in currentFormats.indices) {
                selectedFormat = currentFormats[index]
                if (videoView?.isPlaying == true || videoView?.visibility == View.VISIBLE) {
                    playMedia()
                }
            }
        }
    }

    private fun playMedia() {
        val format = selectedFormat ?: return
        val finalFormat = if (format.type == "video_only") {
            currentFormats.firstOrNull { it.type == "adaptive" }
                ?: currentFormats.firstOrNull { it.type == "combined" }
                ?: format
        } else {
            format
        }
        val urlToPlay = finalFormat.downloadUrl
        if (urlToPlay.isNullOrEmpty()) return

        videoView?.visibility = View.VISIBLE
        val headers = mutableMapOf<String, String>()
        finalFormat.userAgent?.takeIf { it.isNotEmpty() }?.let { headers["User-Agent"] = it }
        videoView?.setVideoURI(android.net.Uri.parse(urlToPlay), headers)
        videoView?.setOnPreparedListener { mp ->
            mp.isLooping = true
            videoView?.start()
            if (finalFormat.type == "audio") {
                thumbnailView?.visibility = View.VISIBLE
            } else {
                thumbnailView?.visibility = View.GONE
            }
        }
        videoView?.setOnErrorListener { _, _, _ -> true }
    }

    private fun triggerDownload() {
        val format = selectedFormat
        val video = currentAnalyzedVideo
        if (format != null && video != null) {
            val prefs = getSharedPreferences("꒯ꄲꅐꋊ꒒ꌦPrefs", Context.MODE_PRIVATE)
            val customFolder = prefs.getString("customDownloadFolder", "") ?: ""
            val isIncognito = prefs.getBoolean("isIncognitoMode", false)
            val usePublicDownloads = if (isIncognito) false else prefs.getBoolean("usePublicDownloads", true)
            DownloadManager.startDownload(this, video, format, usePublicDownloads = usePublicDownloads, customFolder = customFolder)
            // Show a small toast or visual feedback inside the bubble
            titleView?.text = "Download Started: ${video.title}"
        }
    }

    private fun performSearch(query: String) {
        collapse()
        
        videoView?.stopPlayback()
        videoView?.visibility = View.GONE
        thumbnailView?.visibility = View.VISIBLE
        
        bubbleView?.animate()?.rotationBy(360f)?.setDuration(1000)?.withEndAction {
            if (isRunning && !isExpanded) {
                bubbleView?.animate()?.rotationBy(360f)?.setDuration(1000)?.start()
            }
        }?.start()
        
        serviceScope.launch {
            try {
                val isUrl = query.startsWith("http://", ignoreCase = true) || 
                            query.startsWith("https://", ignoreCase = true) || 
                            query.contains("youtube.com", ignoreCase = true) || 
                            query.contains("youtu.be", ignoreCase = true)

                if (isUrl) {
                    withContext(Dispatchers.Main) {
                        titleView?.text = "Analyzing pasted link..."
                        durationView?.text = "Fetching formats directly from video..."
                        clockRollerView?.setItems(emptyList())
                        resultCard?.visibility = View.VISIBLE
                        expand()
                    }

                    val extraction = YtdlpPipelineManager.analyzeUrl(this@FloatingBubbleService, query) { _ -> }
                    if (extraction.success) {
                        // Group and process formats to show all clean resolutions
                        val rawVideos = extraction.formats.filter {
                            val ext = it.ext.lowercase()
                            val url = it.downloadUrl.lowercase()
                            val q = it.quality.lowercase()
                            (it.type == "combined" || it.type == "video_only") &&
                            !ext.contains("m3u8") &&
                            !ext.contains("mpd") &&
                            !ext.contains("mhtml") &&
                            !url.contains(".m3u8") &&
                            !url.contains(".mpd") &&
                            !q.contains("direct stream") &&
                            !q.contains("mhtml") &&
                            !q.contains("adaptive") &&
                            it.formatId != 9999 &&
                            it.formatId != 9911
                        }

                        val groupedByHeight = rawVideos.groupBy { fmt ->
                            if (fmt.height != null) fmt.height else {
                                val match = java.util.regex.Pattern.compile("""(\d+)p""").matcher(fmt.quality)
                                if (match.find()) match.group(1).toIntOrNull() else null
                            }
                        }.filterKeys { it != null } as Map<Int, List<VideoFormatUi>>

                        val bestVideos = groupedByHeight.mapNotNull { (height, formatsAtRes) ->
                            formatsAtRes.maxByOrNull { fmt ->
                                val extIsMp4 = fmt.ext.equals("mp4", ignoreCase = true)
                                val extIsWebm = fmt.ext.equals("webm", ignoreCase = true)
                                val hasAudio = fmt.type == "combined" || fmt.hasAudio
                                val baseScore = when {
                                    extIsMp4 && hasAudio -> 4000
                                    extIsMp4 && !hasAudio -> 3000
                                    extIsWebm && hasAudio -> 2000
                                    extIsWebm && !hasAudio -> 1000
                                    else -> 0
                                }
                                val detailScore = (fmt.tbr ?: 0.0).toInt() * 10 + (fmt.sizeBytes / 100000).toInt()
                                baseScore * 100000000L + detailScore
                            }
                        }

                        val sortedVideos = bestVideos.sortedByDescending { fmt ->
                            if (fmt.height != null) fmt.height else {
                                val match = java.util.regex.Pattern.compile("""(\d+)p""").matcher(fmt.quality)
                                if (match.find()) match.group(1).toIntOrNull() else 0
                            }
                        }

                        val cleanVideoFormats = sortedVideos.map { fmt ->
                            val h = if (fmt.height != null) fmt.height else {
                                val match = java.util.regex.Pattern.compile("""(\d+)p""").matcher(fmt.quality)
                                if (match.find()) match.group(1).toIntOrNull() ?: 360 else 360
                            }
                            fmt.copy(quality = "${h}p")
                        }

                        val adaptiveFormat = extraction.formats.firstOrNull { it.formatId == 9999 }
                        val finalFormatsList = mutableListOf<VideoFormatUi>()
                        if (adaptiveFormat != null) {
                            finalFormatsList.add(adaptiveFormat)
                        }
                        finalFormatsList.addAll(cleanVideoFormats)

                        if (finalFormatsList.isEmpty()) {
                            finalFormatsList.addAll(extraction.formats.filter { it.downloadUrl.isNotEmpty() })
                        }

                        currentFormats = finalFormatsList

                        selectedFormat = currentFormats.firstOrNull { it.type == "adaptive" }
                            ?: currentFormats.firstOrNull { it.quality.contains("720p") }
                            ?: currentFormats.firstOrNull()

                        val videoId = if (query.contains("youtube.com") || query.contains("youtu.be")) {
                            java.util.regex.Pattern.compile("""(?:v=|\/)([a-zA-Z0-9_-]{11})""").matcher(query).let {
                                if (it.find()) it.group(1) else "video_${query.hashCode()}"
                            }
                        } else {
                            "video_${query.hashCode()}"
                        }

                        currentAnalyzedVideo = AnalyzedVideo(
                            id = videoId,
                            title = extraction.title,
                            author = extraction.uploader,
                            durationText = "Adaptive Stream",
                            thumbnailUrl = extraction.thumbnailUrl,
                            formats = currentFormats,
                            originalUrl = query
                        )

                        withContext(Dispatchers.Main) {
                            titleView?.text = extraction.title
                            durationView?.text = extraction.uploader
                            thumbnailView?.load(extraction.thumbnailUrl) { crossfade(true) }
                            updateFormatsUI()
                            bubbleView?.clearAnimation()
                        }
                    } else {
                        withContext(Dispatchers.Main) {
                            titleView?.text = "Failed to extract formats."
                            bubbleView?.clearAnimation()
                        }
                    }
                } else {
                    // First get basic metadata
                    val results = YoutubeRepository.fetchSearchVideos(this@FloatingBubbleService, query)
                    val firstResult = results.firstOrNull()
                    
                    if (firstResult != null) {
                        withContext(Dispatchers.Main) {
                            titleView?.text = "Analyzing formats... ${firstResult.title}"
                            thumbnailView?.load(firstResult.thumbnailUrl) { crossfade(true) }
                            durationView?.text = "${firstResult.author} • ${firstResult.durationText}"
                            clockRollerView?.setItems(emptyList())
                            resultCard?.visibility = View.VISIBLE
                            expand()
                        }
                        
                        // Now deeply analyze to get stream formats
                        val extraction = YtdlpPipelineManager.analyzeUrl(this@FloatingBubbleService, firstResult.originalUrl) { _ -> }
                        if (extraction.success) {
                            // Group and process formats to show all clean resolutions
                            val rawVideos = extraction.formats.filter {
                                val ext = it.ext.lowercase()
                                val url = it.downloadUrl.lowercase()
                                val q = it.quality.lowercase()
                                (it.type == "combined" || it.type == "video_only") &&
                                !ext.contains("m3u8") &&
                                !ext.contains("mpd") &&
                                !ext.contains("mhtml") &&
                                !url.contains(".m3u8") &&
                                !url.contains(".mpd") &&
                                !q.contains("direct stream") &&
                                !q.contains("mhtml") &&
                                !q.contains("adaptive") &&
                                it.formatId != 9999 &&
                                it.formatId != 9911
                            }

                            val groupedByHeight = rawVideos.groupBy { fmt ->
                                if (fmt.height != null) fmt.height else {
                                    val match = java.util.regex.Pattern.compile("""(\d+)p""").matcher(fmt.quality)
                                    if (match.find()) match.group(1).toIntOrNull() else null
                                }
                            }.filterKeys { it != null } as Map<Int, List<VideoFormatUi>>

                            val bestVideos = groupedByHeight.mapNotNull { (height, formatsAtRes) ->
                                formatsAtRes.maxByOrNull { fmt ->
                                    val extIsMp4 = fmt.ext.equals("mp4", ignoreCase = true)
                                    val extIsWebm = fmt.ext.equals("webm", ignoreCase = true)
                                    val hasAudio = fmt.type == "combined" || fmt.hasAudio
                                    val baseScore = when {
                                        extIsMp4 && hasAudio -> 4000
                                        extIsMp4 && !hasAudio -> 3000
                                        extIsWebm && hasAudio -> 2000
                                        extIsWebm && !hasAudio -> 1000
                                        else -> 0
                                    }
                                    val detailScore = (fmt.tbr ?: 0.0).toInt() * 10 + (fmt.sizeBytes / 100000).toInt()
                                    baseScore * 100000000L + detailScore
                                }
                            }

                            val sortedVideos = bestVideos.sortedByDescending { fmt ->
                                if (fmt.height != null) fmt.height else {
                                    val match = java.util.regex.Pattern.compile("""(\d+)p""").matcher(fmt.quality)
                                    if (match.find()) match.group(1).toIntOrNull() else 0
                                }
                            }

                            val cleanVideoFormats = sortedVideos.map { fmt ->
                                val h = if (fmt.height != null) fmt.height else {
                                    val match = java.util.regex.Pattern.compile("""(\d+)p""").matcher(fmt.quality)
                                    if (match.find()) match.group(1).toIntOrNull() ?: 360 else 360
                                }
                                fmt.copy(quality = "${h}p")
                            }

                            val adaptiveFormat = extraction.formats.firstOrNull { it.formatId == 9999 }
                            val finalFormatsList = mutableListOf<VideoFormatUi>()
                            if (adaptiveFormat != null) {
                                finalFormatsList.add(adaptiveFormat)
                            }
                            finalFormatsList.addAll(cleanVideoFormats)

                            if (finalFormatsList.isEmpty()) {
                                finalFormatsList.addAll(extraction.formats.filter { it.downloadUrl.isNotEmpty() })
                            }

                            currentFormats = finalFormatsList

                            selectedFormat = currentFormats.firstOrNull { it.type == "adaptive" }
                                ?: currentFormats.firstOrNull { it.quality.contains("720p") }
                                ?: currentFormats.firstOrNull()
                            
                            currentAnalyzedVideo = AnalyzedVideo(
                                id = firstResult.id,
                                title = extraction.title,
                                author = extraction.uploader,
                                durationText = firstResult.durationText,
                                thumbnailUrl = extraction.thumbnailUrl,
                                formats = currentFormats,
                                originalUrl = firstResult.originalUrl
                            )
                            
                            withContext(Dispatchers.Main) {
                                titleView?.text = extraction.title
                                updateFormatsUI()
                                bubbleView?.clearAnimation()
                            }
                        } else {
                            withContext(Dispatchers.Main) {
                                titleView?.text = "Failed to extract formats."
                                bubbleView?.clearAnimation()
                            }
                        }
                    } else {
                        withContext(Dispatchers.Main) {
                            bubbleView?.clearAnimation()
                            titleView?.text = "No results found"
                            durationView?.text = ""
                            thumbnailView?.setImageDrawable(null)
                            clockRollerView?.setItems(emptyList())
                            resultCard?.visibility = View.VISIBLE
                            expand()
                        }
                    }
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    bubbleView?.clearAnimation()
                    titleView?.text = "Error: ${e.localizedMessage}"
                    durationView?.text = ""
                    thumbnailView?.setImageDrawable(null)
                    clockRollerView?.setItems(emptyList())
                    resultCard?.visibility = View.VISIBLE
                    expand()
                }
            }
        }
    }

    private fun setupDragListener(view: View, isExpandedView: Boolean) {
        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f
        var startClickTime = 0L

        view.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = if (isExpandedView) expandedParams.x else bubbleParams.x
                    initialY = if (isExpandedView) expandedParams.y else bubbleParams.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    startClickTime = System.currentTimeMillis()
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val newX = initialX + (event.rawX - initialTouchX).toInt()
                    val newY = initialY + (event.rawY - initialTouchY).toInt()
                    
                    if (isExpandedView) {
                        expandedParams.x = newX
                        expandedParams.y = newY
                        bubbleParams.x = newX
                        bubbleParams.y = newY
                        try {
                            windowManager.updateViewLayout(expandedView, expandedParams)
                        } catch (e: Exception) {
                            e.printStackTrace()
                        }
                    } else {
                        bubbleParams.x = newX
                        bubbleParams.y = newY
                        expandedParams.x = newX
                        expandedParams.y = newY
                        try {
                            windowManager.updateViewLayout(bubbleView, bubbleParams)
                        } catch (e: Exception) {
                            e.printStackTrace()
                        }
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    val clickDuration = System.currentTimeMillis() - startClickTime
                    if (clickDuration < 200 && !isExpandedView) {
                        toggleExpandCollapse()
                    }
                    true
                }
                else -> false
            }
        }
    }

    private fun toggleExpandCollapse() {
        if (isExpanded) {
            collapse()
        } else {
            expand()
        }
    }

    private fun expand() {
        if (!isExpanded) {
            try {
                isExpanded = true
                
                expandedParams.x = bubbleParams.x
                expandedParams.y = bubbleParams.y
                
                expandedView?.apply {
                    alpha = 0f
                    scaleX = 0.8f
                    scaleY = 0.8f
                    visibility = View.VISIBLE
                }
                
                try {
                    windowManager.updateViewLayout(expandedView, expandedParams)
                } catch (e: Exception) {
                    e.printStackTrace()
                }
                
                expandedView?.animate()
                    ?.alpha(1f)
                    ?.scaleX(1f)
                    ?.scaleY(1f)
                    ?.setDuration(300)
                    ?.setInterpolator(android.view.animation.OvershootInterpolator(1.1f))
                    ?.start()
                
                bubbleView?.animate()
                    ?.alpha(0f)
                    ?.scaleX(0.4f)
                    ?.scaleY(0.4f)
                    ?.setDuration(250)
                    ?.setInterpolator(android.view.animation.AccelerateInterpolator())
                    ?.withEndAction {
                        bubbleView?.visibility = View.GONE
                    }
                    ?.start()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    private fun collapse() {
        if (isExpanded) {
            try {
                isExpanded = false
                
                videoView?.stopPlayback()
                
                bubbleParams.x = expandedParams.x
                bubbleParams.y = expandedParams.y
                try {
                    windowManager.updateViewLayout(bubbleView, bubbleParams)
                } catch (e: Exception) {
                    e.printStackTrace()
                }
                
                bubbleView?.apply { visibility = View.VISIBLE }
                
                bubbleView?.animate()
                    ?.alpha(1f)
                    ?.scaleX(1f)
                    ?.scaleY(1f)
                    ?.setDuration(280)
                    ?.setInterpolator(android.view.animation.OvershootInterpolator(1.1f))
                    ?.start()
                
                expandedView?.animate()
                    ?.alpha(0f)
                    ?.scaleX(0.6f)
                    ?.scaleY(0.6f)
                    ?.setDuration(250)
                    ?.setInterpolator(android.view.animation.AccelerateInterpolator())
                    ?.withEndAction {
                        expandedView?.visibility = View.GONE
                    }
                    ?.start()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        isRunning = false
        serviceScope.cancel()
        expandedView?.let {
            try { windowManager.removeView(it) } catch (e: Exception) { e.printStackTrace() }
        }
        bubbleView?.let {
            try { windowManager.removeView(it) } catch (e: Exception) { e.printStackTrace() }
        }
    }

    private fun dpToPx(dp: Int): Int {
        return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp.toFloat(), resources.displayMetrics).toInt()
    }

    companion object {
        var isRunning = false
        fun canDrawOverlaysSafe(context: android.content.Context): Boolean {
            if (android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.M) {
                return true
            }
            return android.provider.Settings.canDrawOverlays(context)
        }
    }
}
