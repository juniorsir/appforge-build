package com.example.extraction

import android.util.LruCache
import com.example.ui.YtdlpPipelineManager.ExtractionResult
import java.security.MessageDigest
import java.util.concurrent.ConcurrentHashMap

/**
 * Advanced SHA-256 thread-safe extraction LRU cache with 3-hour expiration.
 */
object ExtractionCache {
    private const val MAX_CACHE_ENTRIES = 100
    private const val EXPIRATION_MS = 3 * 3600 * 1000L // 3 Hours

    private val cache = object : LruCache<String, ExtractionResult>(MAX_CACHE_ENTRIES) {
        override fun entryRemoved(evicted: Boolean, key: String?, oldValue: ExtractionResult?, newValue: ExtractionResult?) {
            super.entryRemoved(evicted, key, oldValue, newValue)
        }
    }

    private val activeExtractions = ConcurrentHashMap<String, kotlinx.coroutines.Deferred<ExtractionResult>>()

    /**
     * Compute SHA-256 hash of cleaned URL as cache key.
     */
    fun hashUrl(url: String): String {
        val clean = url.trim()
        return try {
            val digest = MessageDigest.getInstance("SHA-256")
            val hashBytes = digest.digest(clean.toByteArray(Charsets.UTF_8))
            hashBytes.joinToString("") { "%02x".format(it) }
        } catch (e: Exception) {
            clean.hashCode().toString()
        }
    }

    /**
     * Get cached result if valid and not expired.
     */
    fun get(url: String): ExtractionResult? {
        val key = hashUrl(url)
        synchronized(cache) {
            val entry = cache.get(key) ?: return null
            val age = System.currentTimeMillis() - entry.timestamp
            if (age > EXPIRATION_MS) {
                cache.remove(key)
                return null
            }
            return entry
        }
    }

    /**
     * Store successful extraction result in cache.
     */
    fun put(url: String, result: ExtractionResult) {
        if (!result.success) return
        val key = hashUrl(url)
        synchronized(cache) {
            cache.put(key, result)
        }
    }

    /**
     * Remove specific URL from cache.
     */
    fun remove(url: String) {
        val key = hashUrl(url)
        synchronized(cache) {
            cache.remove(key)
        }
    }

    /**
     * Clear entire extraction cache.
     */
    fun clear() {
        synchronized(cache) {
            cache.evictAll()
        }
    }

    fun getActiveExtractionsMap() = activeExtractions
}
