package com.example.media.operations

import android.net.Uri
import java.io.File

data class MediaConversionRequest(
    val inputUri: Uri,
    val outputFile: File,
    val videoCodec: String? = "libx264",
    val audioCodec: String? = "aac",
    val targetWidth: Int? = null,
    val targetHeight: Int? = null,
    val videoBitrateKbps: Int? = null,
    val audioBitrateKbps: Int? = 192,
    val frameRate: Float? = null,
    val crf: Int? = 23,
    val preset: String? = "fast",
    val fastStart: Boolean = true
) {
    fun validate(): Result<Unit> {
        val allowedVideoCodecs = setOf("libx264", "libx265", "libvpx-vp9", "libaom-av1", "copy", null)
        val allowedAudioCodecs = setOf("aac", "libmp3lame", "libopus", "flac", "pcm_s16le", "copy", null)
        val allowedPresets = setOf("ultrafast", "superfast", "veryfast", "faster", "fast", "medium", "slow", null)

        if (videoCodec !in allowedVideoCodecs) {
            return Result.failure(IllegalArgumentException("Unsupported or invalid video codec: $videoCodec"))
        }
        if (audioCodec !in allowedAudioCodecs) {
            return Result.failure(IllegalArgumentException("Unsupported or invalid audio codec: $audioCodec"))
        }
        if (preset !in allowedPresets) {
            return Result.failure(IllegalArgumentException("Invalid preset: $preset"))
        }
        if (targetWidth != null && targetWidth <= 0) {
            return Result.failure(IllegalArgumentException("targetWidth must be positive"))
        }
        if (targetHeight != null && targetHeight <= 0) {
            return Result.failure(IllegalArgumentException("targetHeight must be positive"))
        }
        if (crf != null && (crf < 0 || crf > 51)) {
            return Result.failure(IllegalArgumentException("CRF must be between 0 and 51"))
        }
        return Result.success(Unit)
    }
}
