package com.example.extraction

import android.content.Context
import android.util.Log
import com.example.ui.VideoFormatUi
import com.example.ui.YtdlpPipelineManager
import com.example.ui.YtdlpPipelineManager.BackendType
import com.example.ui.YtdlpPipelineManager.ExtractionResult
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import com.yausername.youtubedl_android.mapper.VideoInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

/**
 * Main Orchestrator for yt-dlp Extraction & Presentation Pipeline.
 * Coordinates all extraction stages, retry logic, caching, and structured logging.
 */
object YtdlpExtractorPipeline {
    private const val TAG = "YtdlpExtractorPipeline"
    private const val MAX_RETRIES = 3

    /**
     * Executes the pipeline over a clean URL.
     */
    suspend fun executePipeline(
        context: Context,
        url: String,
        onLog: (String) -> Unit
    ): ExtractionResult = withContext(Dispatchers.IO) {
        val overallStartTime = System.currentTimeMillis()
        val logBuffer = StringBuilder()

        fun emitLog(tag: String, msg: String, elapsedMs: Long = System.currentTimeMillis() - overallStartTime) {
            val formatted = "[$tag] [${elapsedMs}ms] $msg"
            logBuffer.append(formatted).append("\n")
            onLog(formatted)
            Log.d(TAG, formatted)
        }

        val cleanUrl = url.trim()
        emitLog("Extractor", "Initiating extraction pipeline for: $cleanUrl")

        // 1. Check Cache
        val cached = ExtractionCache.get(cleanUrl)
        if (cached != null && cached.success) {
            emitLog("Cache", "Cache HIT for SHA-256 key")
            return@withContext cached
        }
        emitLog("Cache", "Cache MISS - Dispatching fresh extraction")

        // 2. Retry Loop with Exponential Backoff
        var attempt = 0
        var lastException: Throwable? = null

        while (attempt < MAX_RETRIES) {
            attempt++
            val attemptStart = System.currentTimeMillis()
            if (attempt > 1) {
                val backoffMs = (1000L * Math.pow(2.0, (attempt - 2).toDouble())).toLong()
                emitLog("Retry", "Attempt #$attempt after ${backoffMs}ms backoff delay...")
                delay(backoffMs)
            }

            try {
                // Ensure JNI Core initialized
                val jniStart = System.currentTimeMillis()
                YtdlpPipelineManager.init(context) { emitLog("JNI", it) }
                emitLog("JNI", "JNI Core ready check passed", System.currentTimeMillis() - jniStart)

                val request = YoutubeDLRequest(cleanUrl).apply {
                    addOption("--dump-json")
                    addOption("--no-playlist")
                    addOption("--flat-playlist")
                    addOption("--no-check-formats")
                    addOption("--no-warnings")
                    addOption("--no-check-certificate")
                    addOption("--no-cache-dir")
                    addOption("--socket-timeout", "12")
                    addOption("--retries", "3")
                    addOption("--geo-bypass")
                    addOption("--skip-download")
                    addOption("--force-ipv4")

                    if (cleanUrl.contains("youtube.com", ignoreCase = true) || cleanUrl.contains("youtu.be", ignoreCase = true)) {
                        // Removed to fix 360p format restriction
                                // AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Mobile Safari/537.36")
                        // 
                    }
                }

                emitLog("Extractor", "Executing JNI YoutubeDL.getInfo request...")
                val videoInfo: VideoInfo? = YoutubeDL.getInstance().getInfo(request)

                if (videoInfo != null) {
                    val parseStart = System.currentTimeMillis()
                    val result = processVideoInfo(videoInfo, cleanUrl, { tag, msg, elapsed -> emitLog(tag, msg, elapsed) }, parseStart)
                    if (result.success) {
                        ExtractionCache.put(cleanUrl, result)
                        emitLog("Extractor", "Pipeline execution completed successfully with ${result.formats.size} formats")
                        return@withContext result
                    }
                }
            } catch (e: Throwable) {
                lastException = e
                val errorMsg = e.localizedMessage ?: "Unknown JNI error"
                emitLog("Retry", "Attempt #$attempt failed: $errorMsg")

                // Non-retryable errors
                if (isNonRetryableError(errorMsg)) {
                    emitLog("Retry", "Non-retryable error detected. Halting retries.")
                    break
                }
            }
        }

        // Return structured failure
        val failureReason = lastException?.localizedMessage ?: "Extraction returned null or empty result"
        val errorReport = StructuredExtractionError(
            reason = failureReason,
            retryCount = attempt,
            failedStage = "JNI_GETINFO"
        )

        val ytId = extractYoutubeId(cleanUrl)
        val fallbackThumb = if (ytId != null) "https://img.youtube.com/vi/$ytId/hqdefault.jpg" else ""

        return@withContext ExtractionResult(
            success = false,
            title = "Extraction Failed",
            uploader = "Unknown Provider",
            thumbnailUrl = fallbackThumb,
            formats = emptyList(),
            usedBackend = BackendType.NATIVE_SEAL,
            logOutput = logBuffer.toString(),
            errorCode = "EXTRACTION_PIPELINE_ERROR",
            structuredError = errorReport
        )
    }

    private fun processVideoInfo(
        videoInfo: VideoInfo,
        url: String,
        emitLog: (String, String, Long) -> Unit,
        startTime: Long
    ): ExtractionResult {
        val title = videoInfo.title ?: "Untitled Stream"
        val uploader = videoInfo.uploader ?: "Unknown Provider"
        val durationSeconds = videoInfo.duration.toLong()
        val isLive = try {
            val field = videoInfo.javaClass.getDeclaredField("isLive")
            field.isAccessible = true
            field.getBoolean(videoInfo)
        } catch (e: Exception) {
            false
        }

        // 1. Raw Format Collection (Stage 1)
        val rawCollectStart = System.currentTimeMillis()
        val rawFormats = RawFormatCollector.collectRawFormats(videoInfo)
        emitLog("Parser", "RawFormatCollector found ${rawFormats.size} raw formats", System.currentTimeMillis() - rawCollectStart)

        // 2. Format Validation & Filtering (Stage 2)
        val validStart = System.currentTimeMillis()
        val validRawFormats = rawFormats.filter { FormatValidator.isValidFormat(it) }
        emitLog("Parser", "FormatValidator accepted ${validRawFormats.size}/${rawFormats.size} formats", System.currentTimeMillis() - validStart)

        // 3. Manifest Intelligence & Normalization (Stage 3 & 4)
        val normStart = System.currentTimeMillis()
        val normalizedFormats = validRawFormats.map { raw ->
            val streamType = ManifestResolver.resolveStreamType(raw, isLive)
            FormatNormalizerAndEstimator.normalize(raw, streamType, durationSeconds, isLive)
        }
        emitLog("Manifest", "ManifestResolver normalized ${normalizedFormats.size} stream specifications", System.currentTimeMillis() - normStart)

        // 4. Duplicate Removal & Quality Ranking (Stage 5)
        val rankStart = System.currentTimeMillis()
        val deduplicatedFormats = DuplicateAndRankEngine.process(normalizedFormats)
        emitLog("Sorter", "DuplicateAndRankEngine produced ${deduplicatedFormats.size} deduplicated & ranked formats", System.currentTimeMillis() - rankStart)

        // 5. UI Mapping (Stage 6)
        val mapStart = System.currentTimeMillis()
        val uiFormats = UIFormatMapper.mapToUiFormats(deduplicatedFormats)
        emitLog("Mapper", "UIFormatMapper produced ${uiFormats.size} VideoFormatUi models", System.currentTimeMillis() - mapStart)

        val thumbnail = videoInfo.thumbnail
            ?: extractYoutubeId(url)?.let { "https://img.youtube.com/vi/$it/hqdefault.jpg" }
            ?: ""

        return ExtractionResult(
            success = uiFormats.isNotEmpty(),
            title = title,
            uploader = uploader,
            thumbnailUrl = thumbnail,
            formats = uiFormats,
            usedBackend = BackendType.NATIVE_SEAL,
            logOutput = "Modular pipeline extraction completed cleanly",
            durationSeconds = durationSeconds,
            extractorName = videoInfo.extractor ?: "generic"
        )
    }

    private fun isNonRetryableError(msg: String): Boolean {
        val lower = msg.lowercase()
        return lower.contains("404") ||
                lower.contains("private video") ||
                lower.contains("removed by the user") ||
                lower.contains("copyright claim") ||
                lower.contains("drm") ||
                lower.contains("geo-blocked") ||
                lower.contains("confirm your age")
    }

    private fun extractYoutubeId(url: String): String? {
        val pattern = "(?i)(?:https?:\\/\\/)?(?:www\\.|m\\.)?(?:youtube\\.com\\/(?:watch\\?(?:.*&)?v=|embed\\/|shorts\\/)|youtu\\.be\\/)([a-zA-Z0-9_-]{11})"
        val matchResult = Regex(pattern).find(url)
        return matchResult?.groupValues?.get(1)
    }
}
