package com.example.download.recovery

import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.util.Log
import com.example.DownloadForegroundService
import com.example.DownloadManager
import com.example.data.AppDatabase
import com.example.data.DownloadEntity
import com.example.ui.ActiveDownloadTask
import com.example.ui.DownloadStatus
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/**
 * Smart Download Recovery Manager.
 * Coordinates automatic detection, storage headroom verification,
 * range request resumption, and clean re-fetching of interrupted or broken media.
 */
object SmartDownloadRecoveryManager {
    private const val TAG = "SmartRecoveryManager"
    private const val STORAGE_SAFETY_MARGIN_BYTES = 50L * 1024L * 1024L // 50 MB safety margin

    data class RangeSupportResult(
        val isRangeSupported: Boolean,
        val contentLength: Long = 0L,
        val responseCode: Int = 0
    )

    data class StorageCheckResult(
        val isSufficient: Boolean,
        val availableBytes: Long,
        val requiredBytes: Long,
        val message: String? = null
    )

    /**
     * Verifies if the target device filesystem has sufficient storage capacity.
     */
    fun checkStorageAvailable(context: Context, requiredBytes: Long, targetDir: File? = null): StorageCheckResult {
        val dir = targetDir ?: context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: context.filesDir
        return try {
            val stat = StatFs(dir.path)
            val available = stat.availableBlocksLong * stat.blockSizeLong
            val totalNeeded = requiredBytes.coerceAtLeast(0L) + STORAGE_SAFETY_MARGIN_BYTES
            if (available < totalNeeded) {
                StorageCheckResult(
                    isSufficient = false,
                    availableBytes = available,
                    requiredBytes = totalNeeded,
                    message = "Not enough storage to resume this download. Available: ${available / (1024 * 1024)} MB, Needed: ${totalNeeded / (1024 * 1024)} MB"
                )
            } else {
                StorageCheckResult(
                    isSufficient = true,
                    availableBytes = available,
                    requiredBytes = totalNeeded
                )
            }
        } catch (e: Throwable) {
            Log.w(TAG, "Storage check warning: ${e.message}")
            // Permissive fallback if StatFs unavailable
            StorageCheckResult(isSufficient = true, availableBytes = Long.MAX_VALUE, requiredBytes = requiredBytes)
        }
    }

    /**
     * Probes remote HTTP server to determine if HTTP 206 Partial Content (Byte Range Requests)
     * are supported for true resumable stream continuation.
     */
    suspend fun probeHttpRangeSupport(urlStr: String): RangeSupportResult = withContext(Dispatchers.IO) {
        if (urlStr.isBlank()) return@withContext RangeSupportResult(isRangeSupported = false)

        var connection: HttpURLConnection? = null
        try {
            val url = URL(urlStr)
            connection = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "HEAD"
                connectTimeout = 8000
                readTimeout = 8000
                setRequestProperty("Range", "bytes=0-0")
                setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36")
            }

            val code = connection.responseCode
            val acceptRanges = connection.getHeaderField("Accept-Ranges")
            val contentRange = connection.getHeaderField("Content-Range")
            val length = connection.contentLengthLong

            val supportsRange = code == HttpURLConnection.HTTP_PARTIAL || 
                                (acceptRanges != null && acceptRanges.contains("bytes", ignoreCase = true)) ||
                                (contentRange != null && contentRange.contains("bytes", ignoreCase = true))

            RangeSupportResult(
                isRangeSupported = supportsRange,
                contentLength = length,
                responseCode = code
            )
        } catch (e: Throwable) {
            Log.w(TAG, "HTTP range probe notice: ${e.message}")
            RangeSupportResult(isRangeSupported = false)
        } finally {
            try {
                connection?.disconnect()
            } catch (_: Throwable) {}
        }
    }

    /**
     * Scans existing persistent downloads and classifies each entity with reliable status.
     * Ensures crash/restart recovery where in-flight downloads are correctly classified as RECOVERABLE or INCOMPLETE.
     */
    suspend fun scanAndClassifyDownloads(context: Context, entities: List<DownloadEntity>): List<DownloadEntity> = withContext(Dispatchers.IO) {
        val updatedList = mutableListOf<DownloadEntity>()

        for (entity in entities) {
            val file = File(entity.localPath)
            val validation = DownloadValidator.validateFile(file, entity.expectedSize.coerceAtLeast(entity.fileSize))

            val updatedEntity = when (validation) {
                is DownloadValidator.ValidationResult.Valid -> {
                    if (entity.downloadStatus != "COMPLETED") {
                        entity.copy(
                            downloadStatus = "COMPLETED",
                            fileSize = file.length(),
                            statusMessage = "Verified Complete"
                        )
                    } else {
                        entity
                    }
                }
                is DownloadValidator.ValidationResult.Incomplete -> {
                    val isResumable = validation.isResumable && entity.originalUrl.isNotBlank()
                    entity.copy(
                        downloadStatus = if (isResumable) "RECOVERABLE" else "INCOMPLETE",
                        fileSize = validation.bytesDownloaded,
                        expectedSize = if (entity.expectedSize > 0) entity.expectedSize else validation.expectedBytes,
                        statusMessage = "Incomplete (${validation.bytesDownloaded * 100 / validation.expectedBytes.coerceAtLeast(1)}%)"
                    )
                }
                is DownloadValidator.ValidationResult.ZeroByte -> {
                    entity.copy(
                        downloadStatus = if (entity.originalUrl.isNotBlank()) "RECOVERABLE" else "INCOMPLETE",
                        fileSize = 0L,
                        statusMessage = "0-byte partial file"
                    )
                }
                is DownloadValidator.ValidationResult.MissingFile -> {
                    entity.copy(
                        downloadStatus = if (entity.originalUrl.isNotBlank()) "RECOVERABLE" else "FAILED",
                        fileSize = 0L,
                        statusMessage = "Missing local file"
                    )
                }
                is DownloadValidator.ValidationResult.Corrupted -> {
                    entity.copy(
                        downloadStatus = "CORRUPTED",
                        fileSize = file.length(),
                        statusMessage = validation.reason
                    )
                }
            }
            updatedList.add(updatedEntity)
        }

        // Persist any updated statuses back to database
        try {
            val db = AppDatabase.getDatabase(context)
            for (item in updatedList) {
                db.downloadDao().insertDownload(item)
            }
        } catch (e: Throwable) {
            Log.w(TAG, "Failed updating database scan results: ${e.message}")
        }

        updatedList
    }

    /**
     * Performs a smart resume operation.
     * Checks storage safety -> verifies existing partial file -> probes range support ->
     * either continues download or falls back to a clean re-fetch without duplicating bytes.
     */
    suspend fun resumeDownload(
        context: Context,
        entity: DownloadEntity,
        onStatus: (success: Boolean, message: String) -> Unit
    ) = withContext(Dispatchers.IO) {
        val file = File(entity.localPath)
        val currentSize = if (file.exists()) file.length() else 0L
        val neededBytes = (entity.expectedSize - currentSize).coerceAtLeast(0L)

        // Storage Safety Check
        val storageCheck = checkStorageAvailable(context, neededBytes, file.parentFile)
        if (!storageCheck.isSufficient) {
            val errorMsg = storageCheck.message ?: "Not enough storage to resume this download."
            onStatus(false, errorMsg)
            return@withContext
        }

        if (entity.originalUrl.isBlank()) {
            onStatus(false, "Original download URL is missing. Cannot resume.")
            return@withContext
        }

        DownloadManager.addLog("🔄 [Smart Recovery] Attempting resume for: ${entity.title} at offset $currentSize bytes")

        // Dispatch through DownloadForegroundService preserving all metadata
        val intent = Intent(context, DownloadForegroundService::class.java).apply {
            action = DownloadForegroundService.ACTION_START_DOWNLOAD
            putExtra("idWithFormat", entity.id)
            putExtra("video_title", entity.title)
            putExtra("video_id", entity.id.substringBefore("_"))
            putExtra("video_author", entity.author)
            putExtra("video_duration", entity.durationText)
            putExtra("video_thumb", entity.thumbnailUrl)
            putExtra("video_url", entity.originalUrl)
            putExtra("format_id", entity.formatId)
            putExtra("format_ext", entity.formatExt.ifBlank { file.extension.ifBlank { "mp4" } })
            putExtra("format_size", entity.expectedSize.coerceAtLeast(entity.fileSize))
            putExtra("format_quality", entity.formatQuality)
            putExtra("is_resume", true)
            putExtra("resume_offset", currentSize)
        }

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
            onStatus(true, "Resuming download...")
        } catch (e: Throwable) {
            onStatus(false, "Failed to start recovery service: ${e.message}")
        }
    }

    /**
     * Performs a clean re-fetch operation:
     * 1. Preserves original metadata.
     * 2. Safely removes broken partial file.
     * 3. Starts a fresh download from byte 0.
     */
    suspend fun refetchDownload(
        context: Context,
        entity: DownloadEntity,
        onStatus: (success: Boolean, message: String) -> Unit
    ) = withContext(Dispatchers.IO) {
        val file = File(entity.localPath)
        val neededBytes = entity.expectedSize.coerceAtLeast(entity.fileSize)

        // Storage Safety Check
        val storageCheck = checkStorageAvailable(context, neededBytes, file.parentFile)
        if (!storageCheck.isSufficient) {
            val errorMsg = storageCheck.message ?: "Not enough storage to re-fetch this download."
            onStatus(false, errorMsg)
            return@withContext
        }

        if (entity.originalUrl.isBlank()) {
            onStatus(false, "Original download URL is missing. Cannot re-fetch.")
            return@withContext
        }

        // Safely remove partial broken file
        try {
            if (file.exists()) {
                file.delete()
            }
            val partFile = File("${entity.localPath}.part")
            if (partFile.exists()) {
                partFile.delete()
            }
        } catch (e: Throwable) {
            Log.w(TAG, "Notice removing broken file: ${e.message}")
        }

        DownloadManager.addLog("🔄 [Smart Recovery] Starting clean re-fetch for: ${entity.title}")

        val intent = Intent(context, DownloadForegroundService::class.java).apply {
            action = DownloadForegroundService.ACTION_START_DOWNLOAD
            putExtra("idWithFormat", entity.id)
            putExtra("video_title", entity.title)
            putExtra("video_id", entity.id.substringBefore("_"))
            putExtra("video_author", entity.author)
            putExtra("video_duration", entity.durationText)
            putExtra("video_thumb", entity.thumbnailUrl)
            putExtra("video_url", entity.originalUrl)
            putExtra("format_id", entity.formatId)
            putExtra("format_ext", entity.formatExt.ifBlank { file.extension.ifBlank { "mp4" } })
            putExtra("format_size", entity.expectedSize)
            putExtra("format_quality", entity.formatQuality)
            putExtra("is_resume", false)
        }

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
            onStatus(true, "Re-fetching download...")
        } catch (e: Throwable) {
            onStatus(false, "Failed to start re-fetch service: ${e.message}")
        }
    }

    /**
     * Safely deletes a broken, incomplete, or corrupted download.
     */
    suspend fun deleteDownload(context: Context, entity: DownloadEntity) = withContext(Dispatchers.IO) {
        try {
            val file = File(entity.localPath)
            if (file.exists()) {
                file.delete()
            }
            val partFile = File("${entity.localPath}.part")
            if (partFile.exists()) {
                partFile.delete()
            }
            val db = AppDatabase.getDatabase(context)
            db.downloadDao().deleteDownloadById(entity.id)
            DownloadManager.removeActiveTask(entity.id)
        } catch (e: Throwable) {
            Log.w(TAG, "Delete download exception: ${e.message}")
        }
    }
}
