package com.example.media.ffmpeg

import android.util.Log
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.FFmpegSession
import com.arthenica.ffmpegkit.Session
import java.util.concurrent.ConcurrentHashMap

object FFmpegSessionManager {
    private const val TAG = "FFmpegSessionManager"
    private val activeSessions = ConcurrentHashMap<Long, Session>()

    fun registerSession(session: Session) {
        activeSessions[session.sessionId] = session
        Log.d(TAG, "Registered active FFmpeg session #${session.sessionId}")
    }

    fun unregisterSession(sessionId: Long) {
        activeSessions.remove(sessionId)
        Log.d(TAG, "Unregistered FFmpeg session #$sessionId")
    }

    fun getSession(sessionId: Long): Session? {
        return activeSessions[sessionId]
    }

    fun cancel(sessionId: Long): Boolean {
        val session = activeSessions[sessionId]
        return if (session != null) {
            Log.i(TAG, "Cancelling FFmpeg session #$sessionId...")
            FFmpegKit.cancel(sessionId)
            activeSessions.remove(sessionId)
            true
        } else {
            Log.w(TAG, "Attempted to cancel unknown/inactive session #$sessionId")
            FFmpegKit.cancel(sessionId)
            false
        }
    }

    fun cancelAll() {
        Log.i(TAG, "Cancelling all active FFmpeg sessions (${activeSessions.size} active)...")
        for ((id, _) in activeSessions) {
            FFmpegKit.cancel(id)
        }
        activeSessions.clear()
    }

    fun getActiveSessionCount(): Int = activeSessions.size
}
