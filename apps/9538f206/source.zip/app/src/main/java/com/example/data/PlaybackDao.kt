package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface PlaybackDao {
    @Query("SELECT * FROM playback_progress WHERE mediaId = :mediaId")
    suspend fun getProgress(mediaId: String): PlaybackProgressEntity?

    @Query("SELECT * FROM playback_progress WHERE mediaId = :mediaId")
    fun getProgressFlow(mediaId: String): Flow<PlaybackProgressEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveProgress(progress: PlaybackProgressEntity)

    @Query("DELETE FROM playback_progress WHERE mediaId = :mediaId")
    suspend fun clearProgress(mediaId: String)

    @Query("SELECT * FROM playback_progress")
    suspend fun getAllProgressSync(): List<PlaybackProgressEntity>

    @Query("SELECT * FROM media_markers WHERE mediaId = :mediaId ORDER BY positionMs ASC")
    fun getMarkersFlow(mediaId: String): Flow<List<MediaMarkerEntity>>

    @Query("SELECT * FROM media_markers WHERE mediaId = :mediaId ORDER BY positionMs ASC")
    suspend fun getMarkers(mediaId: String): List<MediaMarkerEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMarker(marker: MediaMarkerEntity)

    @Update
    suspend fun updateMarker(marker: MediaMarkerEntity)

    @Query("DELETE FROM media_markers WHERE id = :markerId")
    suspend fun deleteMarker(markerId: Long)

    @Query("SELECT * FROM media_markers")
    suspend fun getAllMarkersSync(): List<MediaMarkerEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllMarkers(markers: List<MediaMarkerEntity>)
}
