package com.example.media.ffmpeg

data class FFmpegDiagnostics(
    val isAvailable: Boolean = false,
    val ffmpegVersion: String = "N/A",
    val ffmpegKitVersion: String = "8.1.7",
    val abi: String = "arm64-v8a",
    val buildConfiguration: String = "N/A",
    val nativeLibraryLoaded: Boolean = false,
    val selfTestPassed: Boolean = false,
    val probeSelfTestPassed: Boolean = false,
    val registeredPackages: List<String> = emptyList(),
    val errorMessage: String? = null,
    val executionTimeMs: Long = 0L
) {
    fun toFormattedReport(): String {
        val sb = StringBuilder()
        sb.appendLine("=== FFmpegKit Diagnostics Report ===")
        sb.appendLine("FFmpegKit Available: $isAvailable")
        sb.appendLine("FFmpegKit Version: $ffmpegKitVersion")
        sb.appendLine("FFmpeg Version: $ffmpegVersion")
        sb.appendLine("Target ABI: $abi")
        sb.appendLine("Native Libraries Loaded: $nativeLibraryLoaded")
        sb.appendLine("FFmpeg Execution Self-Test: ${if (selfTestPassed) "PASS" else "FAIL"}")
        sb.appendLine("FFprobe Self-Test: ${if (probeSelfTestPassed) "PASS" else "FAIL"}")
        if (registeredPackages.isNotEmpty()) {
            sb.appendLine("Packages: ${registeredPackages.joinToString(", ")}")
        }
        if (!errorMessage.isNullOrBlank()) {
            sb.appendLine("Diagnostic Error: $errorMessage")
        }
        sb.appendLine("Diagnostic Latency: ${executionTimeMs}ms")
        sb.appendLine("====================================")
        return sb.toString()
    }
}
