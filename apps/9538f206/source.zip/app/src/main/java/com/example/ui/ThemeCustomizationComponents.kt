package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.ui.theme.AccentPalette
import com.example.ui.theme.AppThemeMode
import com.example.ui.theme.AppThemeSettings
import com.example.ui.theme.CustomGradientConfig
import com.example.ui.theme.ThemeColorUtils

/**
 * Full Theme Personalization UI Component
 */
@Composable
fun ThemePersonalizationSection(
    themeSettings: AppThemeSettings,
    onUpdateThemeSettings: (AppThemeSettings) -> Unit,
    modifier: Modifier = Modifier
) {
    var showCustomColorDialog by remember { mutableStateOf(false) }
    var customColorTarget by remember { mutableStateOf("ACCENT") } // "ACCENT", "GRADIENT_A", "GRADIENT_B"

    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. Theme Mode Selector
        Text(
            text = "THEME MODE",
            color = SleekPurpleLight,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val modes = listOf(
                AppThemeMode.AMOLED_BLACK,
                AppThemeMode.OBSIDIAN,
                AppThemeMode.MIDNIGHT,
                AppThemeMode.GRAPHITE
            )

            modes.forEach { mode ->
                val isSelected = themeSettings.themeMode == mode
                val bgSample = when (mode) {
                    AppThemeMode.AMOLED_BLACK -> Color(0xFF000000)
                    AppThemeMode.OBSIDIAN -> Color(0xFF09090C)
                    AppThemeMode.MIDNIGHT -> Color(0xFF070B14)
                    AppThemeMode.GRAPHITE -> Color(0xFF121316)
                    AppThemeMode.LIGHT_MODE -> Color(0xFFFAFAFA)
                }

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (isSelected) SleekPurpleContainer else SleekCard)
                        .border(
                            width = if (isSelected) 2.dp else 1.dp,
                            color = if (isSelected) SleekPurpleLight else SleekBorderColor,
                            shape = RoundedCornerShape(12.dp)
                        )
                        .clickable {
                            onUpdateThemeSettings(themeSettings.copy(themeMode = mode))
                        }
                        .padding(vertical = 10.dp, horizontal = 4.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        // Preview circle
                        Box(
                            modifier = Modifier
                                .size(24.dp)
                                .clip(CircleShape)
                                .background(bgSample)
                                .border(1.dp, Color.White.copy(alpha = 0.3f), CircleShape)
                        ) {
                            if (isSelected) {
                                Icon(
                                    imageVector = Icons.Default.Check,
                                    contentDescription = null,
                                    tint = SleekPurpleLight,
                                    modifier = Modifier
                                        .size(14.dp)
                                        .align(Alignment.Center)
                                )
                            }
                        }

                        Text(
                            text = mode.displayName.replace(" ", "\n"),
                            color = if (isSelected) SleekPurpleLight else SleekTextPrimary,
                            fontSize = 11.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            textAlign = TextAlign.Center,
                            lineHeight = 13.sp
                        )
                    }
                }
            }
        }

        // AMOLED Note if active
        if (themeSettings.themeMode == AppThemeMode.AMOLED_BLACK) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color.White.copy(alpha = 0.04f))
                    .border(1.dp, Color.White.copy(alpha = 0.1f), RoundedCornerShape(8.dp))
                    .padding(horizontal = 12.dp, vertical = 8.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Bolt,
                        contentDescription = null,
                        tint = SleekPurpleLight,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = "True #000000 AMOLED black active. Maximizes battery life on OLED displays.",
                        color = SleekTextSecondary,
                        fontSize = 11.sp,
                        lineHeight = 14.sp
                    )
                }
            }
        }

        Divider(color = SleekBorderColor, thickness = 0.5.dp)

        // 2. Accent Color Palette
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "ACCENT COLOR",
                color = SleekPurpleLight,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )

            if (themeSettings.accentPalette == AccentPalette.CUSTOM) {
                Text(
                    text = "Custom: #${themeSettings.customAccentColor.toString(16).takeLast(6).uppercase()}",
                    color = SleekTextSecondary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }

        // Accent swatches row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            val palettes = listOf(
                AccentPalette.PURPLE,
                AccentPalette.ORANGE,
                AccentPalette.PINK,
                AccentPalette.BLUE,
                AccentPalette.CYAN,
                AccentPalette.GREEN,
                AccentPalette.RED,
                AccentPalette.CUSTOM
            )

            palettes.forEach { palette ->
                val isSelected = themeSettings.accentPalette == palette
                val swatchColor = if (palette == AccentPalette.CUSTOM) {
                    Color(themeSettings.customAccentColor)
                } else {
                    palette.primaryColor
                }

                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(swatchColor)
                            .border(
                                width = if (isSelected) 3.dp else 1.dp,
                                color = if (isSelected) Color.White else Color.White.copy(alpha = 0.2f),
                                shape = CircleShape
                            )
                            .clickable {
                                if (palette == AccentPalette.CUSTOM) {
                                    customColorTarget = "ACCENT"
                                    showCustomColorDialog = true
                                }
                                onUpdateThemeSettings(themeSettings.copy(accentPalette = palette))
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        if (isSelected) {
                            Icon(
                                imageVector = Icons.Default.Check,
                                contentDescription = null,
                                tint = ThemeColorUtils.getReadableTextColorForBackground(swatchColor),
                                modifier = Modifier.size(18.dp)
                            )
                        } else if (palette == AccentPalette.CUSTOM) {
                            Icon(
                                imageVector = Icons.Default.Palette,
                                contentDescription = null,
                                tint = ThemeColorUtils.getReadableTextColorForBackground(swatchColor),
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }

                    Text(
                        text = if (palette == AccentPalette.CUSTOM) "Custom" else palette.displayName,
                        color = if (isSelected) SleekPurpleLight else SleekTextMuted,
                        fontSize = 9.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                    )
                }
            }
        }

        Divider(color = SleekBorderColor, thickness = 0.5.dp)

        // 3. Custom Gradient Section
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "DECORATIVE GRADIENT",
                    color = SleekPurpleLight,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "Apply custom gradient to hero banners and accent surfaces",
                    color = SleekTextMuted,
                    fontSize = 11.sp
                )
            }

            Switch(
                checked = themeSettings.gradientConfig.isEnabled,
                onCheckedChange = { isEnabled ->
                    onUpdateThemeSettings(
                        themeSettings.copy(
                            gradientConfig = themeSettings.gradientConfig.copy(isEnabled = isEnabled)
                        )
                    )
                },
                colors = SwitchDefaults.colors(
                    checkedThumbColor = Color.White,
                    checkedTrackColor = SleekPurpleLight,
                    uncheckedThumbColor = SleekTextMuted,
                    uncheckedTrackColor = SleekCard
                )
            )
        }

        AnimatedVisibility(visible = themeSettings.gradientConfig.isEnabled) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(SleekCard)
                    .border(1.dp, SleekBorderColor, RoundedCornerShape(12.dp))
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Color A & Color B Swatches
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Color A
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(SleekCardDark)
                            .clickable {
                                customColorTarget = "GRADIENT_A"
                                showCustomColorDialog = true
                            }
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(20.dp)
                                .clip(CircleShape)
                                .background(Color(themeSettings.gradientConfig.colorA))
                                .border(1.dp, Color.White.copy(alpha = 0.3f), CircleShape)
                        )
                        Text(
                            text = "Color A",
                            color = SleekTextPrimary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Icon(
                            imageVector = Icons.Default.Edit,
                            contentDescription = null,
                            tint = SleekTextSecondary,
                            modifier = Modifier.size(14.dp)
                        )
                    }

                    Icon(
                        imageVector = Icons.Default.ArrowForward,
                        contentDescription = null,
                        tint = SleekTextMuted,
                        modifier = Modifier.size(16.dp)
                    )

                    // Color B
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(SleekCardDark)
                            .clickable {
                                customColorTarget = "GRADIENT_B"
                                showCustomColorDialog = true
                            }
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(20.dp)
                                .clip(CircleShape)
                                .background(Color(themeSettings.gradientConfig.colorB))
                                .border(1.dp, Color.White.copy(alpha = 0.3f), CircleShape)
                        )
                        Text(
                            text = "Color B",
                            color = SleekTextPrimary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Icon(
                            imageVector = Icons.Default.Edit,
                            contentDescription = null,
                            tint = SleekTextSecondary,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }

                // Gradient Intensity Slider
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Gradient Intensity",
                            color = SleekTextSecondary,
                            fontSize = 11.sp
                        )
                        Text(
                            text = "${(themeSettings.gradientConfig.intensity * 100).toInt()}%",
                            color = SleekPurpleLight,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Slider(
                        value = themeSettings.gradientConfig.intensity,
                        onValueChange = { newIntensity ->
                            onUpdateThemeSettings(
                                themeSettings.copy(
                                    gradientConfig = themeSettings.gradientConfig.copy(intensity = newIntensity)
                                )
                            )
                        },
                        valueRange = 0.1f..1.0f,
                        colors = SliderDefaults.colors(
                            thumbColor = SleekPurpleLight,
                            activeTrackColor = SleekPurpleLight,
                            inactiveTrackColor = SleekCardDark
                        )
                    )
                }
            }
        }

        Divider(color = SleekBorderColor, thickness = 0.5.dp)

        // 4. Live Preview Card
        Text(
            text = "LIVE THEME PREVIEW",
            color = SleekPurpleLight,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp
        )

        ThemeLivePreviewCard(themeSettings = themeSettings)
    }

    // Custom Color Dialog
    if (showCustomColorDialog) {
        val initialColor = when (customColorTarget) {
            "GRADIENT_A" -> Color(themeSettings.gradientConfig.colorA)
            "GRADIENT_B" -> Color(themeSettings.gradientConfig.colorB)
            else -> Color(themeSettings.customAccentColor)
        }

        CustomColorPickerDialog(
            title = when (customColorTarget) {
                "GRADIENT_A" -> "Choose Gradient Color A"
                "GRADIENT_B" -> "Choose Gradient Color B"
                else -> "Choose Custom Accent Color"
            },
            initialColor = initialColor,
            onDismiss = { showCustomColorDialog = false },
            onColorSelected = { selectedColor ->
                val colorHex = (selectedColor.toArgb().toLong() and 0xFFFFFFFFL)
                when (customColorTarget) {
                    "GRADIENT_A" -> {
                        onUpdateThemeSettings(
                            themeSettings.copy(
                                gradientConfig = themeSettings.gradientConfig.copy(colorA = colorHex)
                            )
                        )
                    }
                    "GRADIENT_B" -> {
                        onUpdateThemeSettings(
                            themeSettings.copy(
                                gradientConfig = themeSettings.gradientConfig.copy(colorB = colorHex)
                            )
                        )
                    }
                    else -> {
                        onUpdateThemeSettings(
                            themeSettings.copy(
                                accentPalette = AccentPalette.CUSTOM,
                                customAccentColor = colorHex
                            )
                        )
                    }
                }
                showCustomColorDialog = false
            }
        )
    }
}

/**
 * Live Theme Preview showcase component
 */
@Composable
fun ThemeLivePreviewCard(
    themeSettings: AppThemeSettings,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(SleekCard)
            .border(1.dp, SleekBorderColor, RoundedCornerShape(16.dp))
            .padding(16.dp)
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            // Header bar with theme badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(SleekPurpleLight)
                    )
                    Text(
                        text = "${themeSettings.themeMode.displayName} • ${if (themeSettings.accentPalette == AccentPalette.CUSTOM) "Custom" else themeSettings.accentPalette.displayName}",
                        color = SleekTextPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(SleekPurpleLight.copy(alpha = 0.15f))
                        .padding(horizontal = 8.dp, vertical = 3.dp)
                ) {
                    Text(
                        text = "ACTIVE",
                        color = SleekPurpleLight,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // Decorative Gradient Banner Preview
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(38.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(HeroGradient)
                    .padding(horizontal = 12.dp),
                contentAlignment = Alignment.CenterStart
            ) {
                Text(
                    text = "DOWNLY Decorative Surface Preview",
                    color = Color.White,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }

            // Interactive Mock Row: Button, Glow Icon, Slider
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Button
                Button(
                    onClick = {},
                    colors = ButtonDefaults.buttonColors(
                        containerColor = SleekPurpleLight,
                        contentColor = ThemeColorUtils.getReadableTextColorForBackground(SleekPurpleLight)
                    ),
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                    modifier = Modifier.height(36.dp)
                ) {
                    Text("Action", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }

                // Player Glow Play Icon Sample
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(SleekPurpleLight.copy(alpha = 0.2f))
                        .border(1.dp, SleekPurpleLight.copy(alpha = 0.5f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = null,
                        tint = SleekPurpleLight,
                        modifier = Modifier.size(20.dp)
                    )
                }

                // Progress Bar preview
                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(2.dp)
                ) {
                    Text(
                        text = "Accent Progress Indicator",
                        color = SleekTextMuted,
                        fontSize = 10.sp
                    )
                    LinearProgressIndicator(
                        progress = { 0.72f },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(3.dp)),
                        color = SleekPurpleLight,
                        trackColor = SleekCardDark
                    )
                }
            }
        }
    }
}

/**
 * Custom RGB & Hex Color Picker Dialog
 */
@Composable
fun CustomColorPickerDialog(
    title: String,
    initialColor: Color,
    onDismiss: () -> Unit,
    onColorSelected: (Color) -> Unit
) {
    var red by remember { mutableFloatStateOf(initialColor.red) }
    var green by remember { mutableFloatStateOf(initialColor.green) }
    var blue by remember { mutableFloatStateOf(initialColor.blue) }

    val currentColor = Color(red, green, blue, 1f)

    // Preset quick colors
    val quickPresets = listOf(
        Color(0xFF8B5CF6), // Purple
        Color(0xFF3B82F6), // Blue
        Color(0xFF06B6D4), // Cyan
        Color(0xFF10B981), // Emerald
        Color(0xFFFF6D00), // Orange
        Color(0xFFF43F5E), // Rose
        Color(0xFFEC4899), // Pink
        Color(0xFFEAB308), // Amber
        Color(0xFF6366F1), // Indigo
        Color(0xFF14B8A6)  // Teal
    )

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = SleekCard,
            border = androidx.compose.foundation.BorderStroke(1.dp, SleekBorderColor),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Header
                Text(
                    text = title,
                    color = SleekTextPrimary,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )

                // Live Color Swatch & Hex Display
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(56.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(currentColor)
                            .border(2.dp, Color.White.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
                    )

                    Column {
                        val hexStr = String.format("#%02X%02X%02X", (red * 255).toInt(), (green * 255).toInt(), (blue * 255).toInt())
                        Text(
                            text = hexStr,
                            color = SleekTextPrimary,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "R: ${(red * 255).toInt()}  G: ${(green * 255).toInt()}  B: ${(blue * 255).toInt()}",
                            color = SleekTextSecondary,
                            fontSize = 12.sp
                        )
                    }
                }

                // Preset Swatches
                Text(
                    text = "Quick Presets",
                    color = SleekTextSecondary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    quickPresets.take(5).forEach { color ->
                        Box(
                            modifier = Modifier
                                .size(28.dp)
                                .clip(CircleShape)
                                .background(color)
                                .border(1.dp, Color.White.copy(alpha = 0.3f), CircleShape)
                                .clickable {
                                    red = color.red
                                    green = color.green
                                    blue = color.blue
                                }
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    quickPresets.drop(5).take(5).forEach { color ->
                        Box(
                            modifier = Modifier
                                .size(28.dp)
                                .clip(CircleShape)
                                .background(color)
                                .border(1.dp, Color.White.copy(alpha = 0.3f), CircleShape)
                                .clickable {
                                    red = color.red
                                    green = color.green
                                    blue = color.blue
                                }
                        )
                    }
                }

                Divider(color = SleekBorderColor, thickness = 0.5.dp)

                // Sliders: Red, Green, Blue
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    // Red Slider
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("R", color = Color(0xFFEF4444), fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.width(20.dp))
                        Slider(
                            value = red,
                            onValueChange = { red = it },
                            modifier = Modifier.weight(1f),
                            colors = SliderDefaults.colors(
                                thumbColor = Color(0xFFEF4444),
                                activeTrackColor = Color(0xFFEF4444),
                                inactiveTrackColor = SleekCardDark
                            )
                        )
                    }

                    // Green Slider
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("G", color = Color(0xFF10B981), fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.width(20.dp))
                        Slider(
                            value = green,
                            onValueChange = { green = it },
                            modifier = Modifier.weight(1f),
                            colors = SliderDefaults.colors(
                                thumbColor = Color(0xFF10B981),
                                activeTrackColor = Color(0xFF10B981),
                                inactiveTrackColor = SleekCardDark
                            )
                        )
                    }

                    // Blue Slider
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("B", color = Color(0xFF3B82F6), fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.width(20.dp))
                        Slider(
                            value = blue,
                            onValueChange = { blue = it },
                            modifier = Modifier.weight(1f),
                            colors = SliderDefaults.colors(
                                thumbColor = Color(0xFF3B82F6),
                                activeTrackColor = Color(0xFF3B82F6),
                                inactiveTrackColor = SleekCardDark
                            )
                        )
                    }
                }

                // Action Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("Cancel", color = SleekTextSecondary)
                    }

                    Button(
                        onClick = { onColorSelected(currentColor) },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = SleekPurpleLight,
                            contentColor = ThemeColorUtils.getReadableTextColorForBackground(SleekPurpleLight)
                        ),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("Apply", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
