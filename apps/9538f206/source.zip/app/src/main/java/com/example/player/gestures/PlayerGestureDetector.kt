package com.example.player.gestures

import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.PointerInputChange
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.coroutineScope
import kotlin.math.abs

/**
 * Custom Multi-Touch & Edge Gesture detector for Downly Player.
 * Respects gesture priority:
 * 1. Single pointer normal drags & taps are preserved for existing Volume / Brightness / Seek gestures.
 * 2. Multi-touch (2-finger, 3-finger) and Edge swipes trigger custom mapped actions.
 */
fun Modifier.playerCustomGestures(
    enabled: Boolean = true,
    settings: PlayerGestureSettings,
    onTriggerGesture: (PlayerGesture) -> Unit
): Modifier {
    if (!enabled) return this

    return this.pointerInput(settings, enabled) {
        val density = Density(density, fontScale)
        val edgeThresholdPx = with(density) { 56.dp.toPx() }
        val minSwipeDistancePx = with(density) { 60.dp.toPx() }
        val maxPerpendicularDeviationPx = with(density) { 50.dp.toPx() }

        var lastTwoFingerTapTime = 0L

        awaitEachGesture {
            val down = awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
            val startTime = System.currentTimeMillis()
            val startPos = down.position
            val width = size.width.toFloat()
            val height = size.height.toFloat()

            val isNearLeftEdge = startPos.x <= edgeThresholdPx
            val isNearRightEdge = startPos.x >= (width - edgeThresholdPx)

            var maxPointersSeen = 1
            var multiTouchTriggered = false
            var edgeTriggered = false
            var initialTwoFingerCenter: Offset? = null
            var totalTwoFingerDeltaY = 0f

            while (true) {
                val event = awaitPointerEvent(pass = PointerEventPass.Initial)
                val activePointers = event.changes.filter { it.pressed }
                val pointerCount = activePointers.size

                if (pointerCount > maxPointersSeen) {
                    maxPointersSeen = pointerCount
                }

                if (pointerCount == 2) {
                    val p1 = activePointers[0].position
                    val p2 = activePointers[1].position
                    val center = Offset((p1.x + p2.x) / 2f, (p1.y + p2.y) / 2f)

                    if (initialTwoFingerCenter == null) {
                        initialTwoFingerCenter = center
                    } else {
                        val dy = center.y - initialTwoFingerCenter.y
                        val dx = center.x - initialTwoFingerCenter.x
                        totalTwoFingerDeltaY = dy

                        if (!multiTouchTriggered && abs(dy) >= minSwipeDistancePx && abs(dx) < abs(dy) * 0.8f) {
                            multiTouchTriggered = true
                            if (dy < 0) {
                                // Swiped up
                                if (settings.getActionFor(PlayerGesture.TWO_FINGER_SWIPE_UP) != PlayerGestureAction.NONE) {
                                    activePointers.forEach { it.consume() }
                                    onTriggerGesture(PlayerGesture.TWO_FINGER_SWIPE_UP)
                                }
                            } else {
                                // Swiped down
                                if (settings.getActionFor(PlayerGesture.TWO_FINGER_SWIPE_DOWN) != PlayerGestureAction.NONE) {
                                    activePointers.forEach { it.consume() }
                                    onTriggerGesture(PlayerGesture.TWO_FINGER_SWIPE_DOWN)
                                }
                            }
                        }
                    }
                }

                // Check for single pointer edge inward swipe
                if (pointerCount == 1 && (isNearLeftEdge || isNearRightEdge) && !edgeTriggered && !multiTouchTriggered) {
                    val currentPos = activePointers[0].position
                    val dx = currentPos.x - startPos.x
                    val dy = currentPos.y - startPos.y

                    if (abs(dy) <= maxPerpendicularDeviationPx) {
                        if (isNearLeftEdge && dx >= minSwipeDistancePx) {
                            if (settings.getActionFor(PlayerGesture.LEFT_EDGE_SWIPE) != PlayerGestureAction.NONE) {
                                edgeTriggered = true
                                activePointers[0].consume()
                                onTriggerGesture(PlayerGesture.LEFT_EDGE_SWIPE)
                            }
                        } else if (isNearRightEdge && dx <= -minSwipeDistancePx) {
                            if (settings.getActionFor(PlayerGesture.RIGHT_EDGE_SWIPE) != PlayerGestureAction.NONE) {
                                edgeTriggered = true
                                activePointers[0].consume()
                                onTriggerGesture(PlayerGesture.RIGHT_EDGE_SWIPE)
                            }
                        }
                    }
                }

                if (activePointers.isEmpty()) {
                    // All fingers lifted
                    val duration = System.currentTimeMillis() - startTime

                    // Multi-finger Tap handling
                    if (!multiTouchTriggered && !edgeTriggered && duration < 400) {
                        if (maxPointersSeen == 3) {
                            if (settings.getActionFor(PlayerGesture.THREE_FINGER_TAP) != PlayerGestureAction.NONE) {
                                onTriggerGesture(PlayerGesture.THREE_FINGER_TAP)
                            }
                        } else if (maxPointersSeen == 2) {
                            val now = System.currentTimeMillis()
                            if (now - lastTwoFingerTapTime < 450) {
                                // Two-finger double tap detected!
                                lastTwoFingerTapTime = 0L
                                if (settings.getActionFor(PlayerGesture.TWO_FINGER_DOUBLE_TAP) != PlayerGestureAction.NONE) {
                                    onTriggerGesture(PlayerGesture.TWO_FINGER_DOUBLE_TAP)
                                }
                            } else {
                                lastTwoFingerTapTime = now
                            }
                        }
                    }
                    break
                }
            }
        }
    }
}
