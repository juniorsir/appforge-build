package com.example.search

import java.util.Locale
import java.util.regex.Pattern

data class SearchCandidate(
    val id: String,
    val title: String,
    val author: String,
    val description: String,
    val durationText: String,
    val thumbnailUrl: String,
    val originalUrl: String,
    val publishedAtText: String,
    val viewCount: Long,
    val likeCount: Long,
    val commentCount: Long
)

object IntelligentSearchRanker {

    // 1. QUERY UNDERSTANDING
    fun normalizeQuery(query: String): String {
        return query.trim()
            .replace(Regex("\\s+"), " ")
            .lowercase(Locale.ROOT)
    }

    private fun extractIntent(query: String): Set<String> {
        val intents = mutableSetOf<String>()
        val lower = query.lowercase(Locale.ROOT)
        if (lower.contains("video")) intents.add("video")
        if (lower.contains("music") || lower.contains("song")) intents.add("music")
        if (lower.contains("trailer")) intents.add("trailer")
        if (lower.contains("podcast")) intents.add("podcast")
        if (lower.contains("tutorial")) intents.add("tutorial")
        if (lower.contains("news")) intents.add("news")
        if (lower.contains("movie")) intents.add("movie")
        if (lower.contains("artist")) intents.add("artist")
        return intents
    }

    private fun isExplicitQuery(query: String): Boolean {
        val lower = query.lowercase(Locale.ROOT)
        val blocked = listOf("porn", "sex", "nsfw", "xxx", "nude", "naked", "erotic", "xvideos", "pornhub", "onlyfans")
        val blockedRegex = Regex("\\b(${blocked.joinToString("|")})\\b")
        return blockedRegex.containsMatchIn(lower)
    }

    // 9. INAPPROPRIATE CONTENT FILTER
    private fun isSafe(candidate: SearchCandidate): Boolean {
        val textToInspect = "${candidate.title} ${candidate.description} ${candidate.author}".lowercase(Locale.ROOT)
        
        // 10. False-Positive protection
        val educationalTerms = listOf(
            "documentary", "history", "science", "medical", "anatomy", "education", 
            "news", "war", "biology", "research", "tutorial", "informative"
        )
        val isEducational = educationalTerms.any { textToInspect.contains(it) }

        val blocked = listOf(
            "porn", "nsfw", "xxx", "nude", "naked", "erotic", 
            "gore", "murder", "rape", "beheading", "onlyfans"
        )
        val blockedRegex = Regex("\\b(${blocked.joinToString("|")})\\b")
        
        if (blockedRegex.containsMatchIn(textToInspect)) {
            // Allow if educational, else block
            if (!isEducational) {
                return false
            }
        }
        
        // Additional check for spam/scam clickbait patterns
        val scamRegex = Regex("\\b(free robux|free vbucks|hack|cheat tool|generator)\\b")
        if (scamRegex.containsMatchIn(textToInspect)) {
            return false
        }
        
        return true
    }

    // Pipeline
    fun rankAndFilter(query: String, candidates: List<SearchCandidate>): List<SearchCandidate> {
        if (candidates.isEmpty()) return emptyList()

        val normalizedQuery = normalizeQuery(query)

        // 11. QUERY SAFETY
        if (isExplicitQuery(normalizedQuery)) {
            return emptyList()
        }

        val intents = extractIntent(normalizedQuery)

        // 8. DUPLICATE REMOVAL
        val uniqueCandidates = candidates
            .distinctBy { it.id }
            .distinctBy { it.title.lowercase(Locale.ROOT).replace(Regex("[^a-z0-9]"), "") + it.author.lowercase(Locale.ROOT) }

        // Safety filter
        val safeCandidates = uniqueCandidates.filter { isSafe(it) }

        if (safeCandidates.isEmpty()) return emptyList()

        // Normalize metrics for scoring
        val maxViews = safeCandidates.maxOfOrNull { it.viewCount }?.coerceAtLeast(1L) ?: 1L
        val maxLikes = safeCandidates.maxOfOrNull { it.likeCount }?.coerceAtLeast(1L) ?: 1L
        val maxComments = safeCandidates.maxOfOrNull { it.commentCount }?.coerceAtLeast(1L) ?: 1L

        val isFreshnessImportant = listOf("latest", "new", "today", "recent", "2026", "this week").any { normalizedQuery.contains(it) }

        // Rank
        val ranked = safeCandidates.map { candidate ->
            // 4. Relevance Score
            var relevance = 0.0
            val titleLower = candidate.title.lowercase(Locale.ROOT)
            val descLower = candidate.description.lowercase(Locale.ROOT)
            val authorLower = candidate.author.lowercase(Locale.ROOT)

            val queryWords = normalizedQuery.split(" ").filter { it.length > 2 }
            var matches = 0.0
            for (word in queryWords) {
                if (titleLower.contains(word)) matches += 2.0
                else if (descLower.contains(word)) matches += 1.0
                if (authorLower.contains(word)) matches += 1.5
            }
            if (queryWords.isNotEmpty()) {
                relevance = (matches / (queryWords.size * 2.0)).coerceIn(0.0, 1.0)
            } else {
                // If query is short words only, check raw contains
                if (titleLower.contains(normalizedQuery)) relevance = 1.0
            }
            
            // Exact phrase match bonus
            if (titleLower.contains(normalizedQuery)) {
                relevance = (relevance + 0.4).coerceAtMost(1.0)
            }
            
            // Intent bonus
            for (intent in intents) {
                if (titleLower.contains(intent)) {
                    relevance = (relevance + 0.1).coerceAtMost(1.0)
                }
            }

            // 5. Popularity
            val popularity = (candidate.viewCount.toDouble() / maxViews).coerceIn(0.0, 1.0)

            // Engagement
            val likeScore = (candidate.likeCount.toDouble() / maxLikes).coerceIn(0.0, 1.0)
            val commentScore = (candidate.commentCount.toDouble() / maxComments).coerceIn(0.0, 1.0)
            val engagement = ((likeScore * 0.7) + (commentScore * 0.3)).coerceIn(0.0, 1.0)

            // 7. Freshness
            var freshness = 0.5 // Default average freshness for evergreen content
            val pubLower = candidate.publishedAtText.lowercase(Locale.ROOT)
            if (pubLower.contains("minute") || pubLower.contains("hour") || pubLower.contains("today")) freshness = 1.0
            else if (pubLower.contains("day")) freshness = 0.9
            else if (pubLower.contains("week")) freshness = 0.8
            else if (pubLower.contains("month")) freshness = 0.6
            else if (pubLower.contains("year")) freshness = 0.3

            if (!isFreshnessImportant) {
                freshness = (freshness + 0.5) / 2.0 // Soften freshness impact if not explicitly requested
            } else {
                if (freshness < 0.5) freshness *= 0.5 // Penalize old content more if new is requested
            }

            // 6. Trending (simulated via freshness + popularity + engagement)
            val trendingBoost = if (freshness > 0.7 && popularity > 0.6 && engagement > 0.6) 0.1 else 0.0

            // 3. FinalScore Weights
            var finalScore = (0.55 * relevance) + (0.20 * popularity) + (0.15 * engagement) + (0.10 * freshness)
            
            if (trendingBoost > 0 && relevance > 0.4) {
                 finalScore = (finalScore + trendingBoost).coerceAtMost(1.0) // Controlled trending boost
            }
            
            Pair(candidate, Pair(finalScore, relevance))
        }

        // 15. Result Quality Threshold
        val threshold = if (normalizedQuery.split(" ").size > 3) 0.20 else 0.15

        val filteredAndSorted = ranked
            .filter { it.second.second >= threshold }
            .sortedByDescending { it.second.first }
            .map { it.first }
            
        return filteredAndSorted
    }
}
