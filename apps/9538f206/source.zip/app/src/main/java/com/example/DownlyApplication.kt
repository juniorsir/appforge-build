package com.example

import android.app.Application
import android.util.Log

class DownlyApplication : Application() {

    override fun onCreate() {
        super.onCreate()
        setupUncaughtExceptionHandler()
        com.example.media.ffmpeg.FFmpegEngine.initialize()
        com.example.media.storage.TemporaryMediaManager.cleanupAll(this)
    }

    private fun setupUncaughtExceptionHandler() {
        val defaultHandler = Thread.getDefaultUncaughtExceptionHandler()

        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            try {
                val isRecoverableCrash = isIntentOrDataParsingCrash(throwable) || isRecoverableUiOrParserCrash(throwable)
                val errorMessage = throwable.message ?: throwable.javaClass.simpleName
                val stackTraceString = Log.getStackTraceString(throwable)

                val logReport = buildString {
                    append("🚨 UNCAUGHT EXCEPTION on thread [${thread.name}]\n")
                    append("Type: ${throwable.javaClass.name}\n")
                    append("Message: $errorMessage\n")
                    append("Recoverable Crash: $isRecoverableCrash\n")
                    append("Stacktrace:\n$stackTraceString")
                }

                Log.e(TAG, logReport)
                DownloadManager.addLog("⚠️ Exception Intercepted: $errorMessage")

                if (isRecoverableCrash) {
                    Log.w(TAG, "Safely caught recoverable exception on thread [${thread.name}]. Suppressing fatal crash.")
                    DownloadManager.addLog("🛡️ Safe Guard: Suppressed runtime crash: $errorMessage")
                    return@setDefaultUncaughtExceptionHandler
                }
            } catch (loggingEx: Throwable) {
                Log.e(TAG, "Error inside uncaughtExceptionHandler: ${loggingEx.message}", loggingEx)
            }

            // For critical fatal crashes, delegate to the default system handler
            defaultHandler?.uncaughtException(thread, throwable)
        }
    }

    private fun isRecoverableUiOrParserCrash(throwable: Throwable?): Boolean {
        var current: Throwable? = throwable
        while (current != null) {
            val className = current.javaClass.name
            val msg = current.message.orEmpty()
            val stack = Log.getStackTraceString(current)

            if (className.contains("IllegalStateException", ignoreCase = true) && stack.contains("animateItem", ignoreCase = true) ||
                stack.contains("ModalBottomSheet", ignoreCase = true) ||
                stack.contains("FormatRowItem", ignoreCase = true) ||
                stack.contains("VideoSelectionPreview", ignoreCase = true) ||
                stack.contains("ThumbnailPreviewData", ignoreCase = true) ||
                stack.contains("YtdlpPipelineManager", ignoreCase = true) ||
                stack.contains("AnalyzedVideo", ignoreCase = true) ||
                msg.contains("Item with given key does not exist", ignoreCase = true) ||
                msg.contains("LazyLayout", ignoreCase = true)
            ) {
                return true
            }
            current = current.cause
        }
        return false
    }

    private fun isIntentOrDataParsingCrash(throwable: Throwable?): Boolean {
        var current: Throwable? = throwable
        while (current != null) {
            val className = current.javaClass.name
            val msg = current.message.orEmpty()
            val stack = Log.getStackTraceString(current)

            if (className.contains("BadParcelableException", ignoreCase = true) ||
                className.contains("ActivityNotFoundException", ignoreCase = true) ||
                className.contains("TransactionTooLargeException", ignoreCase = true) ||
                className.contains("MalformedURLException", ignoreCase = true) ||
                className.contains("URISyntaxException", ignoreCase = true) ||
                className.contains("NullPointerException", ignoreCase = true) && stack.contains("handleExternalIntent", ignoreCase = true) ||
                stack.contains("handleExternalIntent", ignoreCase = true) ||
                stack.contains("processExternalIntent", ignoreCase = true) ||
                stack.contains("extractExternalUrl", ignoreCase = true) ||
                stack.contains("processIntent", ignoreCase = true) ||
                stack.contains("handleIntent", ignoreCase = true) ||
                stack.contains("extractUrlFromIntent", ignoreCase = true) ||
                stack.contains("android.content.Intent", ignoreCase = true) ||
                msg.contains("ClassNotFoundException when unmarshalling", ignoreCase = true) ||
                msg.contains("Key android.intent.extra", ignoreCase = true)
            ) {
                return true
            }
            current = current.cause
        }
        return false
    }

    companion object {
        private const val TAG = "DownlyApplication"
    }
}
