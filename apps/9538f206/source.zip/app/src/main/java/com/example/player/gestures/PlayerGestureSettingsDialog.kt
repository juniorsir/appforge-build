package com.example.player.gestures

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FastForward
import androidx.compose.material.icons.filled.FastRewind
import androidx.compose.material.icons.filled.Gesture
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.ui.LocalSleekColors

@Composable
fun PlayerGestureSettingsDialog(
    currentSettings: PlayerGestureSettings,
    onSaveSettings: (PlayerGestureSettings) -> Unit,
    onDismiss: () -> Unit
) {
    var workingSettings by remember(currentSettings) { mutableStateOf(currentSettings) }
    val sleekColors = LocalSleekColors.current

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .fillMaxHeight(0.90f)
                .border(1.dp, sleekColors.border, RoundedCornerShape(24.dp)),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = sleekColors.bg)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp)
            ) {
                // Header Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(sleekColors.primary.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Gesture,
                                contentDescription = null,
                                tint = sleekColors.primary,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Column {
                            Text(
                                text = "Player Gestures",
                                color = sleekColors.textPrimary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp
                            )
                            Text(
                                text = "Configure multi-touch & edge shortcuts",
                                color = sleekColors.textSecondary,
                                fontSize = 12.sp
                            )
                        }
                    }

                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(Color.White.copy(alpha = 0.06f))
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = sleekColors.textSecondary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Info banner explaining priority and built-in gestures
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    color = sleekColors.card.copy(alpha = 0.6f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.1f))
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = null,
                            tint = sleekColors.accent,
                            modifier = Modifier.size(18.dp)
                        )
                        Text(
                            text = "Standard volume (right drag) & brightness (left drag) remain active. Custom shortcuts trigger alongside without conflict.",
                            color = sleekColors.textSecondary,
                            fontSize = 11.5.sp,
                            lineHeight = 16.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Gesture list
                LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(bottom = 12.dp)
                ) {
                    items(PlayerGesture.entries) { gesture ->
                        val currentAction = workingSettings.getActionFor(gesture)
                        GestureConfigRow(
                            gesture = gesture,
                            currentAction = currentAction,
                            onActionSelected = { newAction ->
                                workingSettings = workingSettings.withAction(gesture, newAction)
                                onSaveSettings(workingSettings)
                            }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Action buttons: Reset to Defaults & Done
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Reset to Defaults Button
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color.White.copy(alpha = 0.05f))
                            .border(1.dp, Color.White.copy(alpha = 0.15f), RoundedCornerShape(12.dp))
                            .clickable {
                                workingSettings = PlayerGestureSettings()
                                onSaveSettings(workingSettings)
                            }
                            .padding(horizontal = 14.dp, vertical = 10.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = null,
                                tint = sleekColors.textSecondary,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = "Reset Defaults",
                                color = sleekColors.textSecondary,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }

                    // Done / Close button
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(sleekColors.primary)
                            .clickable {
                                onSaveSettings(workingSettings)
                                onDismiss()
                            }
                            .padding(horizontal = 24.dp, vertical = 10.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Check,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = "Done",
                                color = Color.White,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun GestureConfigRow(
    gesture: PlayerGesture,
    currentAction: PlayerGestureAction,
    onActionSelected: (PlayerGestureAction) -> Unit
) {
    val sleekColors = LocalSleekColors.current
    var menuExpanded by remember { mutableStateOf(false) }

    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        color = sleekColors.card,
        border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.08f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Gesture Info
            Row(
                modifier = Modifier.weight(1f),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(34.dp)
                        .clip(CircleShape)
                        .background(
                            if (currentAction != PlayerGestureAction.NONE)
                                sleekColors.primary.copy(alpha = 0.15f)
                            else
                                Color.White.copy(alpha = 0.05f)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = getGestureIcon(gesture),
                        contentDescription = null,
                        tint = if (currentAction != PlayerGestureAction.NONE) sleekColors.primary else sleekColors.textSecondary,
                        modifier = Modifier.size(18.dp)
                    )
                }

                Column {
                    Text(
                        text = gesture.displayName,
                        color = sleekColors.textPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = gesture.description,
                        color = sleekColors.textSecondary,
                        fontSize = 10.5.sp,
                        lineHeight = 14.sp
                    )
                }
            }

            Spacer(modifier = Modifier.width(8.dp))

            // Action Selection Dropdown Button
            Box {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(
                            if (currentAction != PlayerGestureAction.NONE)
                                sleekColors.primary.copy(alpha = 0.12f)
                            else
                                Color.White.copy(alpha = 0.04f)
                        )
                        .border(
                            1.dp,
                            if (currentAction != PlayerGestureAction.NONE)
                                sleekColors.primary.copy(alpha = 0.4f)
                            else
                                Color.White.copy(alpha = 0.1f),
                            RoundedCornerShape(10.dp)
                        )
                        .clickable { menuExpanded = true }
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = getActionIcon(currentAction),
                            contentDescription = null,
                            tint = if (currentAction != PlayerGestureAction.NONE) sleekColors.primary else sleekColors.textSecondary,
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            text = currentAction.displayName,
                            color = if (currentAction != PlayerGestureAction.NONE) sleekColors.primary else sleekColors.textSecondary,
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Icon(
                            imageVector = Icons.Default.ArrowDropDown,
                            contentDescription = null,
                            tint = if (currentAction != PlayerGestureAction.NONE) sleekColors.primary else sleekColors.textSecondary,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }

                DropdownMenu(
                    expanded = menuExpanded,
                    onDismissRequest = { menuExpanded = false },
                    modifier = Modifier
                        .background(sleekColors.card)
                        .border(1.dp, Color.White.copy(alpha = 0.15f), RoundedCornerShape(12.dp))
                ) {
                    PlayerGestureAction.entries.forEach { action ->
                        val isSelected = action == currentAction
                        DropdownMenuItem(
                            leadingIcon = {
                                Icon(
                                    imageVector = getActionIcon(action),
                                    contentDescription = null,
                                    tint = if (isSelected) sleekColors.primary else sleekColors.textSecondary,
                                    modifier = Modifier.size(16.dp)
                                )
                            },
                            text = {
                                Column {
                                    Text(
                                        text = action.displayName,
                                        color = if (isSelected) sleekColors.primary else sleekColors.textPrimary,
                                        fontSize = 12.5.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                    )
                                    Text(
                                        text = action.description,
                                        color = sleekColors.textSecondary,
                                        fontSize = 10.sp
                                    )
                                }
                            },
                            onClick = {
                                onActionSelected(action)
                                menuExpanded = false
                            }
                        )
                    }
                }
            }
        }
    }
}

fun getGestureIcon(gesture: PlayerGesture): ImageVector {
    return when (gesture) {
        PlayerGesture.TWO_FINGER_DOUBLE_TAP -> Icons.Default.TouchApp
        PlayerGesture.THREE_FINGER_TAP -> Icons.Default.Gesture
        PlayerGesture.TWO_FINGER_SWIPE_UP -> Icons.Default.Speed
        PlayerGesture.TWO_FINGER_SWIPE_DOWN -> Icons.Default.Tune
        PlayerGesture.LEFT_EDGE_SWIPE -> Icons.Default.FastRewind
        PlayerGesture.RIGHT_EDGE_SWIPE -> Icons.Default.FastForward
        PlayerGesture.LONG_PRESS -> Icons.Default.TouchApp
    }
}

fun getActionIcon(action: PlayerGestureAction): ImageVector {
    return when (action) {
        PlayerGestureAction.NONE -> Icons.Default.Block
        PlayerGestureAction.PLAY_PAUSE -> Icons.Default.PlayCircle
        PlayerGestureAction.MUTE_UNMUTE -> Icons.Default.VolumeOff
        PlayerGestureAction.NEXT_MEDIA -> Icons.Default.SkipNext
        PlayerGestureAction.PREVIOUS_MEDIA -> Icons.Default.SkipPrevious
        PlayerGestureAction.SEEK_FORWARD_10 -> Icons.Default.FastForward
        PlayerGestureAction.SEEK_BACKWARD_10 -> Icons.Default.FastRewind
        PlayerGestureAction.SPEED_TOGGLE -> Icons.Default.Speed
        PlayerGestureAction.OPEN_CONTROLS -> Icons.Default.Tune
        PlayerGestureAction.LOCK_PLAYER -> Icons.Default.Lock
        PlayerGestureAction.SCREENSHOT -> Icons.Default.CameraAlt
    }
}
