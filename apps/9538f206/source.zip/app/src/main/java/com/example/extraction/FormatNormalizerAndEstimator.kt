package com.example.extraction

import java.util.Locale
import java.util.regex.Pattern

/**
 * Stage 4: FormatNormalizerAndEstimator
 * Normalizes metadata, detects codec families, HDR, FPS, bitrates, and estimates file size using bitrate * duration.
 */
object FormatNormalizerAndEstimator {

    private val RESOLUTION_REGEX = Pattern.compile("""\b(\d{3,4})p?\b""", Pattern.CASE_INSENSITIVE)

    /**
     * Normalizes a validated RawFormat into a NormalizedFormat.
     */
    fun normalize(
        raw: RawFormat,
        streamType: StreamType,
        durationSeconds: Long,
        isVideoLive: Boolean
    ): NormalizedFormat {
        // 1. Resolution
        var height = raw.height
        if (height <= 0) {
            val matcher = RESOLUTION_REGEX.matcher(raw.formatNote)
            if (matcher.find()) {
                height = matcher.group(1)?.toIntOrNull() ?: 0
            } else {
                val matcher2 = RESOLUTION_REGEX.matcher(raw.formatIdStr)
                if (matcher2.find()) {
                    height = matcher2.group(1)?.toIntOrNull() ?: 0
                }
            }
        }
        val width = raw.width

        // 2. Codec Detection
        val vcodecRaw = raw.vcodec
        val acodecRaw = raw.acodec
        val videoCodecFamily = detectVideoCodecFamily(vcodecRaw, raw.formatNote)
        val audioCodecFamily = detectAudioCodecFamily(acodecRaw, raw.formatNote)
        val codecEfficiency = mapCodecEfficiency(videoCodecFamily)

        val isVideoExt = raw.ext.lowercase() in listOf("mp4", "mkv", "webm", "mov", "avi", "3gp", "flv", "ts")
        val isVideoNote = raw.formatNote.contains("p", ignoreCase = true) || raw.formatIdStr.contains("video", ignoreCase = true)
        val hasVideo = streamType != StreamType.AUDIO_ONLY &&
                ((vcodecRaw.isNotBlank() && !vcodecRaw.equals("none", ignoreCase = true)) ||
                        raw.height > 0 || raw.width > 0 || isVideoExt || isVideoNote)

        val isAudioExt = raw.ext.lowercase() in listOf("mp3", "m4a", "aac", "wav", "flac", "opus", "ogg", "wma")
        val isAudioNote = raw.formatNote.contains("audio", ignoreCase = true) || raw.formatIdStr.contains("audio", ignoreCase = true)
        val hasAudio = streamType != StreamType.VIDEO_ONLY &&
                ((acodecRaw.isNotBlank() && !acodecRaw.equals("none", ignoreCase = true)) ||
                        isAudioExt || isAudioNote || (!hasVideo && !isAudioExt))

        // 3. HDR & Dynamic Range
        val dynamicRange = raw.dynamicRange
        val isHdr = dynamicRange.contains("HDR", ignoreCase = true) ||
                dynamicRange.contains("HLG", ignoreCase = true) ||
                dynamicRange.contains("DV", ignoreCase = true) ||
                raw.formatNote.contains("HDR", ignoreCase = true)

        // 4. Bitrate Calculations
        val tbrKbps = raw.tbr.toInt().let { if (it > 0) it else (raw.vbr + raw.abr).toInt() }
        val audioBitrateKbps = raw.abr.toInt().let { if (it > 0) it else 0 }

        // 5. Size Estimation (Phase 9)
        var sizeBytes = raw.filesize
        var isEstimated = false
        var sizeText = ""

        if (sizeBytes > 0) {
            sizeText = String.format(Locale.US, "%.1f MB", sizeBytes.toFloat() / (1024 * 1024))
        } else if (raw.filesizeApprox > 0) {
            sizeBytes = raw.filesizeApprox
            isEstimated = true
            sizeText = String.format(Locale.US, "Est. ~%.1f MB", sizeBytes.toFloat() / (1024 * 1024))
        } else if (tbrKbps > 0 && durationSeconds > 0) {
            val estBytes = (tbrKbps.toDouble() * 1000.0 / 8.0 * durationSeconds.toDouble()).toLong()
            if (estBytes > 0) {
                sizeBytes = estBytes
                isEstimated = true
                sizeText = String.format(Locale.US, "Est. ~%.1f MB", estBytes.toFloat() / (1024 * 1024))
            }
        }

        if (sizeText.isBlank()) {
            sizeText = when (streamType) {
                StreamType.ADAPTIVE_HLS, StreamType.ADAPTIVE_DASH -> "Adaptive Stream"
                StreamType.LIVE_STREAM -> "Live Stream"
                else -> "Direct Stream"
            }
        }

        // Display quality text
        val displayQuality = when {
            streamType == StreamType.AUDIO_ONLY -> "${if (audioBitrateKbps > 0) audioBitrateKbps else 128}kbps Audio"
            height > 0 -> if (isHdr) "${height}p HDR" else "${height}p"
            else -> raw.formatNote.ifBlank { "Adaptive Connection" }
        }

        return NormalizedFormat(
            rawFormatId = raw.formatIdStr,
            streamType = streamType,
            ext = raw.ext.ifBlank { "mp4" },
            downloadUrl = raw.url,
            resolutionHeight = height,
            resolutionWidth = width,
            displayQuality = displayQuality,
            fps = raw.fps,
            isHdr = isHdr,
            dynamicRange = dynamicRange,
            videoCodec = vcodecRaw,
            videoCodecFamily = videoCodecFamily,
            audioCodec = acodecRaw,
            audioCodecFamily = audioCodecFamily,
            codecEfficiency = codecEfficiency,
            hasVideo = hasVideo,
            hasAudio = hasAudio,
            sizeBytes = sizeBytes,
            isEstimatedSize = isEstimated,
            formattedSizeText = sizeText,
            bitrateKbps = tbrKbps,
            audioBitrateKbps = audioBitrateKbps,
            sampleRateHz = raw.asr,
            language = raw.language,
            protocol = raw.protocol,
            qualityScore = 0, // Will be computed in DuplicateAndRankEngine
            isLive = isVideoLive || streamType == StreamType.LIVE_STREAM,
            isAdaptive = streamType == StreamType.ADAPTIVE_HLS || streamType == StreamType.ADAPTIVE_DASH
        )
    }

    private fun detectVideoCodecFamily(vcodec: String, note: String): String {
        val vc = vcodec.lowercase()
        val n = note.lowercase()
        return when {
            vc.startsWith("av01") || vc.contains("av1") || n.contains("av1") -> "AV1"
            vc.startsWith("vp09") || vc.contains("vp9") || n.contains("vp9") -> "VP9"
            vc.startsWith("hev1") || vc.startsWith("hvc1") || vc.contains("hevc") || vc.contains("h.265") || n.contains("hevc") -> "HEVC"
            vc.startsWith("avc1") || vc.contains("h.264") || vc.contains("avc") || n.contains("avc") -> "AVC"
            vc.contains("vp8") -> "VP8"
            vc.isNotBlank() && !vc.equals("none") -> vc.uppercase(Locale.US)
            else -> "None"
        }
    }

    private fun detectAudioCodecFamily(acodec: String, note: String): String {
        val ac = acodec.lowercase()
        val n = note.lowercase()
        return when {
            ac.contains("opus") || n.contains("opus") -> "Opus"
            ac.contains("mp4a") || ac.contains("aac") || n.contains("aac") -> "AAC"
            ac.contains("mp3") || n.contains("mp3") -> "MP3"
            ac.contains("vorbis") || n.contains("vorbis") -> "Vorbis"
            ac.contains("flac") -> "FLAC"
            ac.contains("ac-3") || ac.contains("eac-3") -> "AC3"
            ac.isNotBlank() && !ac.equals("none") -> ac.uppercase(Locale.US)
            else -> "None"
        }
    }

    private fun mapCodecEfficiency(family: String): CodecEfficiency {
        return when (family) {
            "AV1" -> CodecEfficiency.AV1
            "HEVC" -> CodecEfficiency.HEVC
            "VP9" -> CodecEfficiency.VP9
            "AVC" -> CodecEfficiency.AVC
            "VP8" -> CodecEfficiency.VP8
            else -> CodecEfficiency.OTHER
        }
    }
}
