package com.example.ui.theme

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import com.example.ui.SleekColors

/**
 * Built-in Theme Modes for DOWNLY
 */
enum class AppThemeMode(val id: String, val displayName: String, val description: String) {
    AMOLED_BLACK("AMOLED_BLACK", "AMOLED Black", "True #000000 black background for maximum OLED contrast and battery savings"),
    OBSIDIAN("OBSIDIAN", "Obsidian", "Deep dark canvas with subtle violet undertones (Default DOWNLY)"),
    MIDNIGHT("MIDNIGHT", "Midnight", "Deep navy blue-black palette with cool slate undertones"),
    GRAPHITE("GRAPHITE", "Graphite", "Modern sleek neutral charcoal & graphite slate"),
    LIGHT_MODE("LIGHT_MODE", "Light Mode", "High-contrast clean light theme");

    companion object {
        fun fromId(id: String?): AppThemeMode {
            return entries.firstOrNull { it.id.equals(id, ignoreCase = true) || it.displayName.equals(id, ignoreCase = true) }
                ?: when (id?.trim()) {
                    "Dark Mode" -> OBSIDIAN
                    "Light Mode" -> LIGHT_MODE
                    "AMOLED", "AMOLED Black", "#000000" -> AMOLED_BLACK
                    "Obsidian" -> OBSIDIAN
                    "Midnight" -> MIDNIGHT
                    "Graphite" -> GRAPHITE
                    else -> OBSIDIAN
                }
        }
    }
}

/**
 * Accent Colors for DOWNLY
 */
enum class AccentPalette(val id: String, val displayName: String, val primaryColor: Color, val accentColor: Color) {
    PURPLE("PURPLE", "Purple", Color(0xFF8B5CF6), Color(0xFFA78BFA)),
    ORANGE("ORANGE", "Orange", Color(0xFFFF6D00), Color(0xFFFF9D33)),
    PINK("PINK", "Pink", Color(0xFFEC4899), Color(0xFFF472B6)),
    BLUE("BLUE", "Blue", Color(0xFF3B82F6), Color(0xFF60A5FA)),
    CYAN("CYAN", "Cyan", Color(0xFF06B6D4), Color(0xFF22D3EE)),
    GREEN("GREEN", "Green", Color(0xFF10B981), Color(0xFF34D399)),
    RED("RED", "Red", Color(0xFFEF4444), Color(0xFFF87171)),
    CUSTOM("CUSTOM", "Custom", Color(0xFF8B5CF6), Color(0xFFA78BFA));

    companion object {
        fun fromId(id: String?): AccentPalette {
            return entries.firstOrNull { it.id.equals(id, ignoreCase = true) || it.displayName.equals(id, ignoreCase = true) }
                ?: PURPLE
        }
    }
}

/**
 * Custom decorative gradient configuration
 */
data class CustomGradientConfig(
    val isEnabled: Boolean = false,
    val colorA: Long = 0xFF8B5CF6,
    val colorB: Long = 0xFFEC4899,
    val intensity: Float = 0.6f
)

/**
 * Full Theme Settings Data Model
 */
data class AppThemeSettings(
    val themeMode: AppThemeMode = AppThemeMode.OBSIDIAN,
    val accentPalette: AccentPalette = AccentPalette.PURPLE,
    val customAccentColor: Long = 0xFF8B5CF6,
    val gradientConfig: CustomGradientConfig = CustomGradientConfig()
) {
    val isAmoled: Boolean
        get() = themeMode == AppThemeMode.AMOLED_BLACK
}

/**
 * Contrast and color utility functions for accessibility
 */
object ThemeColorUtils {

    fun calculateLuminance(color: Color): Float {
        val r = color.red
        val g = color.green
        val b = color.blue
        return 0.2126f * r + 0.7152f * g + 0.0722f * b
    }

    fun getReadableTextColorForBackground(bg: Color, defaultLight: Color = Color.White, defaultDark: Color = Color(0xFF1A1A1A)): Color {
        val lum = calculateLuminance(bg)
        return if (lum > 0.5f) defaultDark else defaultLight
    }

    fun lightenColor(color: Color, factor: Float = 0.25f): Color {
        val r = (color.red + (1f - color.red) * factor).coerceIn(0f, 1f)
        val g = (color.green + (1f - color.green) * factor).coerceIn(0f, 1f)
        val b = (color.blue + (1f - color.blue) * factor).coerceIn(0f, 1f)
        return Color(r, g, b, color.alpha)
    }

    fun darkenColor(color: Color, factor: Float = 0.25f): Color {
        val r = (color.red * (1f - factor)).coerceIn(0f, 1f)
        val g = (color.green * (1f - factor)).coerceIn(0f, 1f)
        val b = (color.blue * (1f - factor)).coerceIn(0f, 1f)
        return Color(r, g, b, color.alpha)
    }
}

/**
 * Resolve SleekColors from AppThemeSettings
 */
fun resolveSleekColorsFromSettings(settings: AppThemeSettings, isSystemDark: Boolean = true): SleekColors {
    val isDark = when (settings.themeMode) {
        AppThemeMode.LIGHT_MODE -> false
        else -> true
    }

    // Resolve primary and accent colors
    val (primaryColor, accentColor) = if (settings.accentPalette == AccentPalette.CUSTOM) {
        val customColor = Color(settings.customAccentColor)
        val lightAccent = ThemeColorUtils.lightenColor(customColor, 0.25f)
        Pair(customColor, lightAccent)
    } else {
        Pair(settings.accentPalette.primaryColor, settings.accentPalette.accentColor)
    }

    // Resolve gradient
    val heroBrush = if (settings.gradientConfig.isEnabled) {
        val colA = Color(settings.gradientConfig.colorA).copy(alpha = settings.gradientConfig.intensity.coerceIn(0.1f, 1.0f))
        val colB = Color(settings.gradientConfig.colorB).copy(alpha = settings.gradientConfig.intensity.coerceIn(0.1f, 1.0f))
        Brush.linearGradient(colors = listOf(colA, colB))
    } else {
        Brush.linearGradient(
            colors = listOf(
                primaryColor.copy(alpha = 0.85f),
                accentColor.copy(alpha = 0.85f)
            )
        )
    }

    if (!isDark) {
        // Light Mode
        return SleekColors(
            bg = Color(0xFFFAFAFA),
            card = Color(0xFFFFFFFF),
            surface = Color(0xFFFFFFFF),
            primary = primaryColor,
            accent = accentColor,
            container = Color(0xFFF1F3F5),
            textPrimary = Color(0xFF1E293B),
            textSecondary = Color(0xFF64748B),
            textMuted = Color(0xFF94A3B8),
            border = Color(0xFFE2E8F0),
            failure = Color(0xFFEF4444),
            success = Color(0xFF10B981),
            gradient = heroBrush
        )
    }

    return when (settings.themeMode) {
        AppThemeMode.AMOLED_BLACK -> {
            // True #000000 Black for AMOLED screens
            SleekColors(
                bg = Color(0xFF000000),
                card = Color(0xFF080808),
                surface = Color(0xFF101012),
                primary = primaryColor,
                accent = accentColor,
                container = Color(0xFF050505),
                textPrimary = Color(0xFFFFFFFF),
                textSecondary = Color(0xFFA1A1AA),
                textMuted = Color(0xFF71717A),
                border = Color(0x26FFFFFF), // Subtle high-contrast border for AMOLED separation
                failure = Color(0xFFFF4D5A),
                success = Color(0xFF22C55E),
                gradient = heroBrush
            )
        }
        AppThemeMode.OBSIDIAN -> {
            // Deep Obsidian canvas
            SleekColors(
                bg = Color(0xFF09090C),
                card = Color(0xFF111216),
                surface = Color(0xFF17191E),
                primary = primaryColor,
                accent = accentColor,
                container = Color(0xFF111216),
                textPrimary = Color(0xFFFFFFFF),
                textSecondary = Color(0xFFA5A5B2),
                textMuted = Color(0xFF757B88),
                border = Color(0x14FFFFFF),
                failure = Color(0xFFFF4D5A),
                success = Color(0xFF22C55E),
                gradient = heroBrush
            )
        }
        AppThemeMode.MIDNIGHT -> {
            // Deep Navy Midnight palette
            SleekColors(
                bg = Color(0xFF070B14),
                card = Color(0xFF0E1626),
                surface = Color(0xFF142036),
                primary = primaryColor,
                accent = accentColor,
                container = Color(0xFF0C1322),
                textPrimary = Color(0xFFF1F5F9),
                textSecondary = Color(0xFF94A3B8),
                textMuted = Color(0xFF64748B),
                border = Color(0x1E38BDF8),
                failure = Color(0xFFF87171),
                success = Color(0xFF34D399),
                gradient = heroBrush
            )
        }
        AppThemeMode.GRAPHITE -> {
            // Modern neutral Charcoal & Graphite
            SleekColors(
                bg = Color(0xFF121316),
                card = Color(0xFF1A1B20),
                surface = Color(0xFF24262D),
                primary = primaryColor,
                accent = accentColor,
                container = Color(0xFF18191E),
                textPrimary = Color(0xFFF3F4F6),
                textSecondary = Color(0xFF9CA3AF),
                textMuted = Color(0xFF6B7280),
                border = Color(0x1FFFFFFF),
                failure = Color(0xFFF87171),
                success = Color(0xFF34D399),
                gradient = heroBrush
            )
        }
        AppThemeMode.LIGHT_MODE -> {
            // Handled above
            SleekColors(
                bg = Color(0xFFFAFAFA),
                card = Color(0xFFFFFFFF),
                surface = Color(0xFFFFFFFF),
                primary = primaryColor,
                accent = accentColor,
                container = Color(0xFFF1F3F5),
                textPrimary = Color(0xFF1E293B),
                textSecondary = Color(0xFF64748B),
                textMuted = Color(0xFF94A3B8),
                border = Color(0xFFE2E8F0),
                failure = Color(0xFFEF4444),
                success = Color(0xFF10B981),
                gradient = heroBrush
            )
        }
    }
}

/**
 * Persistent storage manager for Theme settings
 */
object ThemePreferencesManager {
    private const val PREFS_NAME = "downly_theme_prefs"
    private const val KEY_THEME_MODE = "theme_mode_v2"
    private const val KEY_ACCENT_PALETTE = "accent_palette"
    private const val KEY_CUSTOM_ACCENT_COLOR = "custom_accent_color"
    private const val KEY_GRADIENT_ENABLED = "gradient_enabled"
    private const val KEY_GRADIENT_COLOR_A = "gradient_color_a"
    private const val KEY_GRADIENT_COLOR_B = "gradient_color_b"
    private const val KEY_GRADIENT_INTENSITY = "gradient_intensity"

    fun loadThemeSettings(context: Context): AppThemeSettings {
        return try {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val themeModeStr = prefs.getString(KEY_THEME_MODE, AppThemeMode.OBSIDIAN.id)
            val accentPaletteStr = prefs.getString(KEY_ACCENT_PALETTE, AccentPalette.PURPLE.id)
            val customAccent = prefs.getLong(KEY_CUSTOM_ACCENT_COLOR, 0xFF8B5CF6)
            val gradEnabled = prefs.getBoolean(KEY_GRADIENT_ENABLED, false)
            val gradColA = prefs.getLong(KEY_GRADIENT_COLOR_A, 0xFF8B5CF6)
            val gradColB = prefs.getLong(KEY_GRADIENT_COLOR_B, 0xFFEC4899)
            val gradIntensity = prefs.getFloat(KEY_GRADIENT_INTENSITY, 0.6f)

            val mode = AppThemeMode.fromId(themeModeStr)
            val palette = AccentPalette.fromId(accentPaletteStr)

            AppThemeSettings(
                themeMode = mode,
                accentPalette = palette,
                customAccentColor = customAccent,
                gradientConfig = CustomGradientConfig(
                    isEnabled = gradEnabled,
                    colorA = gradColA,
                    colorB = gradColB,
                    intensity = gradIntensity
                )
            )
        } catch (e: Exception) {
            // Fall back safely to default theme on any read error
            AppThemeSettings(
                themeMode = AppThemeMode.OBSIDIAN,
                accentPalette = AccentPalette.PURPLE
            )
        }
    }

    fun saveThemeSettings(context: Context, settings: AppThemeSettings) {
        try {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            prefs.edit()
                .putString(KEY_THEME_MODE, settings.themeMode.id)
                .putString(KEY_ACCENT_PALETTE, settings.accentPalette.id)
                .putLong(KEY_CUSTOM_ACCENT_COLOR, settings.customAccentColor)
                .putBoolean(KEY_GRADIENT_ENABLED, settings.gradientConfig.isEnabled)
                .putLong(KEY_GRADIENT_COLOR_A, settings.gradientConfig.colorA)
                .putLong(KEY_GRADIENT_COLOR_B, settings.gradientConfig.colorB)
                .putFloat(KEY_GRADIENT_INTENSITY, settings.gradientConfig.intensity)
                .apply()
        } catch (e: Exception) {
            // Ignored
        }
    }
}
