package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "playback_progress")
data class PlaybackProgressEntity(
    @PrimaryKey val mediaId: String,
    val mediaPath: String,
    val durationMs: Long,
    val lastPositionMs: Long,
    val lastPlayedTimestamp: Long = System.currentTimeMillis(),
    val isCompleted: Boolean = false,
    val completedTimestamp: Long = 0L
)
