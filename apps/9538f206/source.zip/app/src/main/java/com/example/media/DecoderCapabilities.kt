package com.example.media

enum class DecoderClassification {
    HARDWARE,
    SOFTWARE,
    EXTENSION,
    UNKNOWN
}

data class CodecCapabilitiesInfo(
    val name: String,
    val mimeType: String,
    val isEncoder: Boolean,
    val classification: DecoderClassification,
    val maxSupportedWidth: Int = 0,
    val maxSupportedHeight: Int = 0,
    val maxSupportedFrameRate: Int = 0,
    val maxSupportedBitrate: Int = 0,
    val maxSupportedChannels: Int = 0,
    val maxSupportedSampleRate: Int = 0,
    val profiles: List<String> = emptyList()
)

data class CodecSupportStatus(
    val displayName: String,
    val mimeType: String,
    val hardwareAvailable: Boolean,
    val softwareAvailable: Boolean,
    val extensionAvailable: Boolean = false,
    val hardwareDecoders: List<String> = emptyList(),
    val softwareDecoders: List<String> = emptyList(),
    val extensionDecoders: List<String> = emptyList()
)
