package com.example.media

enum class TrackType {
    VIDEO,
    AUDIO,
    TEXT,
    UNKNOWN
}

data class MediaTrackInfo(
    val id: String,
    val type: TrackType,
    val mimeType: String?,
    val codec: String?,
    val language: String? = null,
    val title: String? = null,
    val bitrate: Int = 0,
    val width: Int = 0,
    val height: Int = 0,
    val frameRate: Float = 0f,
    val sampleRate: Int = 0,
    val channelCount: Int = 0,
    val channelLayout: String? = null,
    val isDefault: Boolean = false,
    val isForced: Boolean = false,
    val isSupported: Boolean = true
)
