package com.example.ui.settings

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.ui.graphics.vector.ImageVector

/**
 * High-level settings categories for DOWNLY hierarchical settings architecture.
 */
enum class SettingsCategory(
    val id: String,
    val title: String,
    val description: String,
    val icon: ImageVector
) {
    APPEARANCE(
        id = "appearance",
        title = "Appearance",
        description = "Theme, accent colors, AMOLED & custom gradients",
        icon = Icons.Default.Palette
    ),
    PLAYER(
        id = "player",
        title = "Player",
        description = "Playback, gestures, audio effects, PiP & decoders",
        icon = Icons.Default.PlayCircle
    ),
    DOWNLOADS(
        id = "downloads",
        title = "Downloads",
        description = "Download behavior, codecs, subtitles & battery saving",
        icon = Icons.Default.CloudDownload
    ),
    LIBRARY(
        id = "library",
        title = "Library",
        description = "Playlists, history, content controls & cloud backup",
        icon = Icons.Default.VideoLibrary
    ),
    NETWORK(
        id = "network",
        title = "Network & Transfer",
        description = "Wi-Fi rules, floating search bubble & CLI terminal runner",
        icon = Icons.Default.Wifi
    ),
    NOTIFICATIONS(
        id = "notifications",
        title = "Notifications & Controls",
        description = "Background playback, media controls, foreground alerts & haptics",
        icon = Icons.Default.NotificationsActive
    ),
    STORAGE(
        id = "storage",
        title = "Storage",
        description = "Storage analyzer, auto-clean watched media & cache cleanup",
        icon = Icons.Default.Storage
    ),
    ABOUT(
        id = "about",
        title = "About",
        description = "App information, lead developer credits, legal & privacy policy",
        icon = Icons.Default.Info
    )
}

/**
 * Searchable item for quick navigation across settings.
 */
data class SettingsSearchItem(
    val title: String,
    val description: String,
    val category: SettingsCategory,
    val breadcrumb: String,
    val icon: ImageVector,
    val keywords: List<String> = emptyList()
)

object SettingsSearchIndex {
    val items = listOf(
        // Appearance
        SettingsSearchItem(
            title = "Theme Mode",
            description = "Select system, dark, light, or AMOLED pitch black theme",
            category = SettingsCategory.APPEARANCE,
            breadcrumb = "Appearance → Theme",
            icon = Icons.Default.DarkMode,
            keywords = listOf("dark", "light", "amoled", "pitch black", "system", "theme", "mode", "oled")
        ),
        SettingsSearchItem(
            title = "Accent Color & Palette",
            description = "Choose dynamic accent colors or custom hex palette",
            category = SettingsCategory.APPEARANCE,
            breadcrumb = "Appearance → Accent Color",
            icon = Icons.Default.ColorLens,
            keywords = listOf("accent", "palette", "color", "tint", "purple", "neon", "cyan", "gold")
        ),
        SettingsSearchItem(
            title = "Custom Gradient",
            description = "Configure custom dual-tone gradient background",
            category = SettingsCategory.APPEARANCE,
            breadcrumb = "Appearance → Custom Gradient",
            icon = Icons.Default.Gradient,
            keywords = listOf("gradient", "custom color", "background", "hero", "two-tone")
        ),
        SettingsSearchItem(
            title = "AMOLED Pitch Black",
            description = "True #000000 black surfaces for OLED battery conservation",
            category = SettingsCategory.APPEARANCE,
            breadcrumb = "Appearance → AMOLED Mode",
            icon = Icons.Default.Brightness2,
            keywords = listOf("amoled", "pitch black", "oled", "battery", "black")
        ),

        // Player
        SettingsSearchItem(
            title = "Player Gestures",
            description = "Configure multi-touch shortcuts and edge swipe actions",
            category = SettingsCategory.PLAYER,
            breadcrumb = "Player → Gestures",
            icon = Icons.Default.Gesture,
            keywords = listOf("gesture", "shortcuts", "double tap", "multi touch", "swipe", "edge", "three finger")
        ),
        SettingsSearchItem(
            title = "Decoder Preference",
            description = "Codec engine priority (Hardware MediaCodec vs FFmpeg Software)",
            category = SettingsCategory.PLAYER,
            breadcrumb = "Player → Playback & Decoder",
            icon = Icons.Default.Memory,
            keywords = listOf("decoder", "hardware", "software", "ffmpeg", "mediacodec", "playback")
        ),
        SettingsSearchItem(
            title = "Hardware Acceleration",
            description = "Enable GPU decoding for smooth playback and battery saving",
            category = SettingsCategory.PLAYER,
            breadcrumb = "Player → Playback & Decoder",
            icon = Icons.Default.Speed,
            keywords = listOf("gpu", "hardware acceleration", "codec", "decode", "smooth")
        ),
        SettingsSearchItem(
            title = "Audio Output Mode",
            description = "PCM downmix or direct surround passthrough (AC3/DTS)",
            category = SettingsCategory.PLAYER,
            breadcrumb = "Player → Audio Output",
            icon = Icons.Default.SurroundSound,
            keywords = listOf("audio output", "pcm", "passthrough", "surround", "dts", "ac3", "dolby")
        ),
        SettingsSearchItem(
            title = "Auto-Dim Inactivity (Battery Saver)",
            description = "Automatically dim player screen after inactivity",
            category = SettingsCategory.PLAYER,
            breadcrumb = "Player → Battery Saver",
            icon = Icons.Default.BatterySaver,
            keywords = listOf("dim", "auto dim", "inactivity", "screen timeout", "battery saver")
        ),
        SettingsSearchItem(
            title = "Picture-in-Picture (PiP) Mode",
            description = "In-app floating glass player and system OS PiP window",
            category = SettingsCategory.PLAYER,
            breadcrumb = "Player → Picture-in-Picture",
            icon = Icons.Default.PictureInPictureAlt,
            keywords = listOf("pip", "picture in picture", "floating", "mini player", "window")
        ),
        SettingsSearchItem(
            title = "Auto-Enter System PiP on Leave",
            description = "Seamlessly enter OS PiP when pressing Home or switching apps",
            category = SettingsCategory.PLAYER,
            breadcrumb = "Player → Picture-in-Picture",
            icon = Icons.Default.OpenInNew,
            keywords = listOf("pip", "home", "minimize", "background", "leave")
        ),

        // Downloads
        SettingsSearchItem(
            title = "Download over Wi-Fi Only",
            description = "Prevent downloads on cellular mobile data networks",
            category = SettingsCategory.DOWNLOADS,
            breadcrumb = "Downloads → Network Rules",
            icon = Icons.Default.Wifi,
            keywords = listOf("wifi", "cellular", "mobile data", "data saver", "network")
        ),
        SettingsSearchItem(
            title = "Background Downloads",
            description = "Keep downloading streams even when app is closed or in background",
            category = SettingsCategory.DOWNLOADS,
            breadcrumb = "Downloads → Preferences",
            icon = Icons.Default.Download,
            keywords = listOf("background", "service", "foreground service", "closed", "downloads")
        ),
        SettingsSearchItem(
            title = "Default Download Quality",
            description = "Preferred resolution preset (1080p, 720p, 4K, Best)",
            category = SettingsCategory.DOWNLOADS,
            breadcrumb = "Downloads → Preferences",
            icon = Icons.Default.HighQuality,
            keywords = listOf("quality", "resolution", "1080p", "720p", "4k", "preset")
        ),
        SettingsSearchItem(
            title = "Battery & Power Throttling",
            description = "Auto-pause downloads when battery is low or not charging",
            category = SettingsCategory.DOWNLOADS,
            breadcrumb = "Downloads → Battery & Power",
            icon = Icons.Default.BatteryChargingFull,
            keywords = listOf("battery", "charging", "auto pause", "power", "throttle", "saver")
        ),
        SettingsSearchItem(
            title = "Embed Subtitles into Video",
            description = "Mux soft subtitles directly into MKV/MP4 containers",
            category = SettingsCategory.DOWNLOADS,
            breadcrumb = "Downloads → Subtitles & Captions",
            icon = Icons.Default.Subtitles,
            keywords = listOf("subtitles", "captions", "embed", "mux", "mkv", "mp4", "srt", "vtt")
        ),
        SettingsSearchItem(
            title = "Include Auto-Generated Captions",
            description = "Download machine-generated subtitles if manual subs aren't found",
            category = SettingsCategory.DOWNLOADS,
            breadcrumb = "Downloads → Subtitles & Captions",
            icon = Icons.Default.ClosedCaption,
            keywords = listOf("auto captions", "automatic", "captions", "subtitles", "machine")
        ),
        SettingsSearchItem(
            title = "Preferred Subtitle Languages",
            description = "Filter subtitle streams by language codes",
            category = SettingsCategory.DOWNLOADS,
            breadcrumb = "Downloads → Subtitles & Captions",
            icon = Icons.Default.Translate,
            keywords = listOf("language", "english", "spanish", "subtitles", "translation")
        ),
        SettingsSearchItem(
            title = "Embed ID3 Cover & Metadata",
            description = "Attach thumbnail artwork and artist/title tags to audio files",
            category = SettingsCategory.DOWNLOADS,
            breadcrumb = "Downloads → Audio & Metadata",
            icon = Icons.Default.GraphicEq,
            keywords = listOf("id3", "metadata", "album art", "cover", "tags", "artist")
        ),
        SettingsSearchItem(
            title = "Preferred Audio Format & Quality",
            description = "Default codec (MP3, M4A, FLAC, OPUS) and bitrate for extractions",
            category = SettingsCategory.DOWNLOADS,
            breadcrumb = "Downloads → Audio & Metadata",
            icon = Icons.Default.MusicNote,
            keywords = listOf("audio format", "mp3", "m4a", "flac", "opus", "bitrate", "320kbps", "quality")
        ),
        SettingsSearchItem(
            title = "Custom Download Folder",
            description = "Select custom internal storage or SD card directory for files",
            category = SettingsCategory.DOWNLOADS,
            breadcrumb = "Downloads → Storage Path",
            icon = Icons.Default.Folder,
            keywords = listOf("folder", "directory", "storage path", "sd card", "save location")
        ),

        // Library
        SettingsSearchItem(
            title = "Student Mode (Safe Search)",
            description = "Filter restricted and sensitive content from search",
            category = SettingsCategory.LIBRARY,
            breadcrumb = "Library → Content Controls",
            icon = Icons.Default.School,
            keywords = listOf("student mode", "safe search", "filter", "restricted", "content", "family")
        ),
        SettingsSearchItem(
            title = "Show Recommendations",
            description = "Display related videos on home and player screens",
            category = SettingsCategory.LIBRARY,
            breadcrumb = "Library → Content Controls",
            icon = Icons.Default.AutoAwesome,
            keywords = listOf("recommendations", "suggestions", "related videos", "home")
        ),
        SettingsSearchItem(
            title = "Save Search History",
            description = "Remember past queries and browsing activity",
            category = SettingsCategory.LIBRARY,
            breadcrumb = "Library → History & Privacy",
            icon = Icons.Default.History,
            keywords = listOf("history", "search history", "queries", "recent searches")
        ),
        SettingsSearchItem(
            title = "Incognito Mode",
            description = "Do not save search/browsing histories and save downloads privately",
            category = SettingsCategory.LIBRARY,
            breadcrumb = "Library → History & Privacy",
            icon = Icons.Default.VisibilityOff,
            keywords = listOf("incognito", "private", "stealth", "anonymous", "no history")
        ),
        SettingsSearchItem(
            title = "Cloud Backup & Restore",
            description = "Back up playlists, markers, notes, positions and downloaded media",
            category = SettingsCategory.LIBRARY,
            breadcrumb = "Library → Cloud Backup",
            icon = Icons.Default.CloudUpload,
            keywords = listOf("cloud backup", "google drive", "restore", "sync", "backup", "cloud")
        ),

        // Network & Transfer
        SettingsSearchItem(
            title = "Floating Search Bubble",
            description = "Display overlay search bubble above other Android applications",
            category = SettingsCategory.NETWORK,
            breadcrumb = "Network & Transfer → Overlay",
            icon = Icons.Default.Layers,
            keywords = listOf("floating", "bubble", "overlay", "draw over other apps", "quick search")
        ),
        SettingsSearchItem(
            title = "Custom CLI Terminal Runner",
            description = "Execute custom command arguments directly on the extraction engine",
            category = SettingsCategory.NETWORK,
            breadcrumb = "Network & Transfer → CLI Runner",
            icon = Icons.Default.Terminal,
            keywords = listOf("cli", "terminal", "command", "engine", "ytdlp", "verify")
        ),
        SettingsSearchItem(
            title = "Live Console Logs",
            description = "Real-time stream extraction and download process logs",
            category = SettingsCategory.NETWORK,
            breadcrumb = "Network & Transfer → Live Console",
            icon = Icons.Default.Dns,
            keywords = listOf("logs", "console", "terminal", "live", "debugging", "output")
        ),

        // Notifications & Controls
        SettingsSearchItem(
            title = "YouTube Background Audio Playback",
            description = "Keep listening to audio when screen is locked or app is minimized",
            category = SettingsCategory.NOTIFICATIONS,
            breadcrumb = "Notifications → Background Audio",
            icon = Icons.Default.Headphones,
            keywords = listOf("youtube", "background audio", "screen off", "locked", "listen")
        ),
        SettingsSearchItem(
            title = "Media Notification Controls",
            description = "Dedicated media bar with Play/Pause, Rewind, Forward & lockscreen controls",
            category = SettingsCategory.NOTIFICATIONS,
            breadcrumb = "Notifications → Media Controls",
            icon = Icons.Default.NotificationsActive,
            keywords = listOf("notification", "lockscreen", "media controls", "seek", "play", "pause")
        ),
        SettingsSearchItem(
            title = "Persistent Foreground Notifications",
            description = "Show ongoing download status bar alert",
            category = SettingsCategory.NOTIFICATIONS,
            breadcrumb = "Notifications → Alerts",
            icon = Icons.Default.NotificationImportant,
            keywords = listOf("persistent", "foreground", "download notification", "progress")
        ),
        SettingsSearchItem(
            title = "Haptic Tactile Feedback",
            description = "Vibration response on taps, toggles, and gesture triggers",
            category = SettingsCategory.NOTIFICATIONS,
            breadcrumb = "Notifications → Feedback",
            icon = Icons.Default.Vibration,
            keywords = listOf("haptic", "vibration", "tactile", "feedback", "touch")
        ),

        // Storage
        SettingsSearchItem(
            title = "Storage Analyzer",
            description = "Visual space breakdown and storage consumption by downloaded media",
            category = SettingsCategory.STORAGE,
            breadcrumb = "Storage → Storage Analyzer",
            icon = Icons.Default.Storage,
            keywords = listOf("storage", "space", "analyzer", "gb", "mb", "usage", "bar")
        ),
        SettingsSearchItem(
            title = "Auto-Clean Watched Downloads",
            description = "Automatically delete media files after playback completion",
            category = SettingsCategory.STORAGE,
            breadcrumb = "Storage → Auto-Clean",
            icon = Icons.Default.AutoDelete,
            keywords = listOf("auto clean", "delete watched", "cleanup", "storage low", "favorites")
        ),
        SettingsSearchItem(
            title = "Clear Library Offline Cache",
            description = "Delete all offline cached downloads and temporary files",
            category = SettingsCategory.STORAGE,
            breadcrumb = "Storage → Cache Cleanup",
            icon = Icons.Default.Delete,
            keywords = listOf("clear all", "delete all", "cache", "purge", "reset")
        ),

        // About
        SettingsSearchItem(
            title = "About DOWNLY",
            description = "App version, high-speed multi-threaded media extraction details",
            category = SettingsCategory.ABOUT,
            breadcrumb = "About → Information",
            icon = Icons.Default.Info,
            keywords = listOf("about", "version", "downly", "info", "engine")
        ),
        SettingsSearchItem(
            title = "Lead Developer & Credits",
            description = "Crafted by JuniorSir (Instagram: @_junior_sir_)",
            category = SettingsCategory.ABOUT,
            breadcrumb = "About → Developer",
            icon = Icons.Default.Person,
            keywords = listOf("juniorsir", "developer", "author", "instagram", "credits")
        ),
        SettingsSearchItem(
            title = "Terms & Conditions",
            description = "Terms of service, fair use policy, copyright compliance and licensing",
            category = SettingsCategory.ABOUT,
            breadcrumb = "About → Legal",
            icon = Icons.Default.Security,
            keywords = listOf("terms", "conditions", "license", "legal", "copyright", "fair use")
        ),
        SettingsSearchItem(
            title = "Privacy Policy",
            description = "Zero telemetry tracking, 100% on-device local storage",
            category = SettingsCategory.ABOUT,
            breadcrumb = "About → Privacy",
            icon = Icons.Default.Lock,
            keywords = listOf("privacy", "policy", "telemetry", "tracking", "local storage")
        )
    )

    fun search(query: String): List<SettingsSearchItem> {
        val q = query.trim().lowercase()
        if (q.isEmpty()) return emptyList()
        return items.filter { item ->
            item.title.lowercase().contains(q) ||
            item.description.lowercase().contains(q) ||
            item.breadcrumb.lowercase().contains(q) ||
            item.keywords.any { it.contains(q) }
        }
    }
}
