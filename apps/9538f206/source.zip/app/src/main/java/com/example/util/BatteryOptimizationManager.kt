package com.example.util

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.PowerManager
import android.util.Log
import com.example.DownloadManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class BatteryInfo(
    val batteryPercentage: Int = 100,
    val isCharging: Boolean = false,
    val isPowerSaveMode: Boolean = false,
    val isLowBattery: Boolean = false, // battery <= threshold (e.g., 20%)
    val isBatterySaverTriggered: Boolean = false // (battery <= 20% || !isCharging) when auto-pause is enabled
)

object BatteryOptimizationManager {
    private const val TAG = "BatteryOptManager"
    private const val PREFS_NAME = "꒯ꄲꅐꋊ꒒ꌦPrefs"
    private const val KEY_AUTO_PAUSE_BATTERY = "autoPauseOnLowBatteryOrDischarging"
    private const val KEY_BATTERY_THRESHOLD = "batterySaverThreshold"
    private const val KEY_PAUSE_NOT_CHARGING = "pauseIfNotCharging"
    private const val KEY_LARGE_FILE_THRESHOLD_MB = "largeFileThresholdMb"
    private const val KEY_AUTO_RESUME_CHARGING = "autoResumeOnPowerConnected"

    private val _batteryInfo = MutableStateFlow(BatteryInfo())
    val batteryInfo: StateFlow<BatteryInfo> = _batteryInfo.asStateFlow()

    private val _autoPauseEnabled = MutableStateFlow(true)
    val autoPauseEnabled: StateFlow<Boolean> = _autoPauseEnabled.asStateFlow()

    private val _batteryThreshold = MutableStateFlow(20)
    val batteryThreshold: StateFlow<Int> = _batteryThreshold.asStateFlow()

    private val _pauseIfNotCharging = MutableStateFlow(true)
    val pauseIfNotCharging: StateFlow<Boolean> = _pauseIfNotCharging.asStateFlow()

    private val _largeFileThresholdMb = MutableStateFlow(50)
    val largeFileThresholdMb: StateFlow<Int> = _largeFileThresholdMb.asStateFlow()

    private val _autoResumeOnCharging = MutableStateFlow(true)
    val autoResumeOnCharging: StateFlow<Boolean> = _autoResumeOnCharging.asStateFlow()

    private var isRegistered = false
    private var appContext: Context? = null
    private val scope = CoroutineScope(Dispatchers.Default)

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (context == null || intent == null) return
            updateBatteryStatus(context, intent)
        }
    }

    fun init(context: Context) {
        if (isRegistered) return
        val app = context.applicationContext
        appContext = app

        val prefs = app.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        _autoPauseEnabled.value = prefs.getBoolean(KEY_AUTO_PAUSE_BATTERY, true)
        _batteryThreshold.value = prefs.getInt(KEY_BATTERY_THRESHOLD, 20)
        _pauseIfNotCharging.value = prefs.getBoolean(KEY_PAUSE_NOT_CHARGING, true)
        _largeFileThresholdMb.value = prefs.getInt(KEY_LARGE_FILE_THRESHOLD_MB, 50)
        _autoResumeOnCharging.value = prefs.getBoolean(KEY_AUTO_RESUME_CHARGING, true)

        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_BATTERY_CHANGED)
            addAction(Intent.ACTION_POWER_CONNECTED)
            addAction(Intent.ACTION_POWER_DISCONNECTED)
            addAction(PowerManager.ACTION_POWER_SAVE_MODE_CHANGED)
        }

        try {
            val stickyIntent = app.registerReceiver(batteryReceiver, filter)
            if (stickyIntent != null) {
                updateBatteryStatus(app, stickyIntent)
            } else {
                checkCurrentBattery(app)
            }
            isRegistered = true
            DownloadManager.addLog("🔋 [Battery Optimizer] Initialized (Threshold: ${_batteryThreshold.value}%, Large file: ${_largeFileThresholdMb.value}MB, PauseIfNotCharging: ${_pauseIfNotCharging.value})")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to register battery receiver", e)
            checkCurrentBattery(app)
        }
    }

    fun checkCurrentBattery(context: Context) {
        try {
            val bm = context.getSystemService(Context.BATTERY_SERVICE) as? BatteryManager
            val capacity = bm?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) ?: 100
            val isCharging = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
                bm?.isCharging ?: false
            } else {
                false
            }
            val pm = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
            val isPowerSave = pm?.isPowerSaveMode ?: false

            val isLow = capacity <= _batteryThreshold.value
            val shouldTrigger = _autoPauseEnabled.value && (isLow || (_pauseIfNotCharging.value && !isCharging))

            _batteryInfo.value = BatteryInfo(
                batteryPercentage = capacity,
                isCharging = isCharging,
                isPowerSaveMode = isPowerSave,
                isLowBattery = isLow,
                isBatterySaverTriggered = shouldTrigger
            )
        } catch (e: Exception) {
            Log.e(TAG, "Error checking battery", e)
        }
    }

    fun updateBatteryStatus(context: Context, intent: Intent) {
        val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
        val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val plugged = intent.getIntExtra(BatteryManager.EXTRA_PLUGGED, -1)

        val currentLevel = if (level >= 0 && scale > 0) {
            (level * 100) / scale
        } else {
            val bm = context.getSystemService(Context.BATTERY_SERVICE) as? BatteryManager
            bm?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) ?: _batteryInfo.value.batteryPercentage
        }

        val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                status == BatteryManager.BATTERY_STATUS_FULL ||
                plugged == BatteryManager.BATTERY_PLUGGED_AC ||
                plugged == BatteryManager.BATTERY_PLUGGED_USB ||
                plugged == BatteryManager.BATTERY_PLUGGED_WIRELESS

        val powerManager = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
        val isPowerSave = powerManager?.isPowerSaveMode ?: false

        val isLow = currentLevel <= _batteryThreshold.value
        val shouldTriggerSaver = _autoPauseEnabled.value && (isLow || (_pauseIfNotCharging.value && !isCharging))

        val previousInfo = _batteryInfo.value
        val newInfo = BatteryInfo(
            batteryPercentage = currentLevel,
            isCharging = isCharging,
            isPowerSaveMode = isPowerSave,
            isLowBattery = isLow,
            isBatterySaverTriggered = shouldTriggerSaver
        )
        _batteryInfo.value = newInfo

        // Event detection
        if (!previousInfo.isCharging && isCharging) {
            DownloadManager.addLog("⚡ [Battery Optimizer] Power connected (Battery: $currentLevel%).")
            if (_autoResumeOnCharging.value) {
                DownloadManager.addLog("▶️ [Battery Optimizer] Auto-resuming paused downloads on power connection.")
                DownloadManager.resumeAllDownloads()
            }
        } else if (previousInfo.isCharging && !isCharging) {
            DownloadManager.addLog("🔋 [Battery Optimizer] Disconnected from power (Battery: $currentLevel%).")
            if (shouldTriggerSaver) {
                triggerAutoPauseLargeDownloads(currentLevel, isCharging)
            }
        } else if (shouldTriggerSaver && !previousInfo.isBatterySaverTriggered) {
            triggerAutoPauseLargeDownloads(currentLevel, isCharging)
        }
    }

    private fun triggerAutoPauseLargeDownloads(level: Int, isCharging: Boolean) {
        val thresholdBytes = _largeFileThresholdMb.value * 1024L * 1024L
        val reason = if (level <= _batteryThreshold.value) {
            "Paused (Battery Low: $level% <= ${_batteryThreshold.value}%)"
        } else {
            "Paused (Not Charging - Resource Saver)"
        }
        scope.launch {
            DownloadManager.pauseLargeDownloads(thresholdBytes, reason)
        }
    }

    fun isLargeDownload(totalBytes: Long): Boolean {
        val thresholdBytes = _largeFileThresholdMb.value * 1024L * 1024L
        return totalBytes >= thresholdBytes || totalBytes <= 0
    }

    fun shouldPauseNewDownload(totalBytes: Long): Boolean {
        if (!_autoPauseEnabled.value) return false
        val info = _batteryInfo.value
        if (!isLargeDownload(totalBytes)) return false
        return info.isLowBattery || (_pauseIfNotCharging.value && !info.isCharging)
    }

    fun setAutoPauseEnabled(context: Context, enabled: Boolean) {
        _autoPauseEnabled.value = enabled
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit().putBoolean(KEY_AUTO_PAUSE_BATTERY, enabled).apply()
        DownloadManager.addLog("⚙️ [Battery Optimizer] Low Battery Auto-Pause set to: $enabled")
        checkCurrentBattery(context)
        if (enabled && _batteryInfo.value.isBatterySaverTriggered) {
            triggerAutoPauseLargeDownloads(_batteryInfo.value.batteryPercentage, _batteryInfo.value.isCharging)
        }
    }

    fun setBatteryThreshold(context: Context, threshold: Int) {
        _batteryThreshold.value = threshold
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit().putInt(KEY_BATTERY_THRESHOLD, threshold).apply()
        DownloadManager.addLog("⚙️ [Battery Optimizer] Battery Threshold set to: $threshold%")
        checkCurrentBattery(context)
        if (_autoPauseEnabled.value && _batteryInfo.value.isBatterySaverTriggered) {
            triggerAutoPauseLargeDownloads(_batteryInfo.value.batteryPercentage, _batteryInfo.value.isCharging)
        }
    }

    fun setPauseIfNotCharging(context: Context, enabled: Boolean) {
        _pauseIfNotCharging.value = enabled
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit().putBoolean(KEY_PAUSE_NOT_CHARGING, enabled).apply()
        DownloadManager.addLog("⚙️ [Battery Optimizer] Pause If Not Charging set to: $enabled")
        checkCurrentBattery(context)
        if (_autoPauseEnabled.value && enabled && !_batteryInfo.value.isCharging) {
            triggerAutoPauseLargeDownloads(_batteryInfo.value.batteryPercentage, false)
        }
    }

    fun setLargeFileThresholdMb(context: Context, thresholdMb: Int) {
        _largeFileThresholdMb.value = thresholdMb
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit().putInt(KEY_LARGE_FILE_THRESHOLD_MB, thresholdMb).apply()
        DownloadManager.addLog("⚙️ [Battery Optimizer] Large File Threshold set to: ${thresholdMb}MB")
        if (_autoPauseEnabled.value && _batteryInfo.value.isBatterySaverTriggered) {
            triggerAutoPauseLargeDownloads(_batteryInfo.value.batteryPercentage, _batteryInfo.value.isCharging)
        }
    }

    fun setAutoResumeOnCharging(context: Context, enabled: Boolean) {
        _autoResumeOnCharging.value = enabled
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit().putBoolean(KEY_AUTO_RESUME_CHARGING, enabled).apply()
        DownloadManager.addLog("⚙️ [Battery Optimizer] Auto-Resume on Charging set to: $enabled")
    }
}
