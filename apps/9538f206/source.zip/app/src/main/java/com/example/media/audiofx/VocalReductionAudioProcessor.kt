package com.example.media.audiofx

import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Phase 2E: Real-Time Vocal Reduction / Karaoke AudioProcessor.
 *
 * Center-channel cancellation algorithm for stereo sources:
 * C ≈ (L + R) / 2
 * L' = L - k * C = (1 - k/2) * L - (k/2) * R
 * R' = R - k * C = (1 - k/2) * R - (k/2) * L
 *
 * Mathematical properties:
 * - k = 0.0 (Off): L' = L, R' = R (original unchanged stereo)
 * - k = 0.25 (Low): L' = 0.875 L - 0.125 R (subtle vocal reduction)
 * - k = 0.50 (Medium): L' = 0.75 L - 0.25 R (moderate reduction)
 * - k = 0.85 / 1.0 (Strong): maximum center-channel reduction
 *
 * Safety & Quality:
 * - Off-main-thread processing in ExoPlayer audio pipeline
 * - Prevents clipping with bounds clamping
 * - Graceful fallback & stereo compatibility checks: if non-stereo (mono/multichannel)
 *   or format mismatch, processing is bypassed safely without crashes or distortion.
 * - Deterministic processing order: Input -> Vocal Reduction -> Room Effects -> Output.
 */
class VocalReductionAudioProcessor : BaseAudioProcessor() {

    @Volatile
    var strength: Float = 0.0f
        set(value) {
            field = value.coerceIn(0.0f, 1.0f)
        }

    @Volatile
    var isStereoCompatible: Boolean = true
        private set

    var onCompatibilityChanged: ((Boolean) -> Unit)? = null

    override fun onConfigure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        if (inputAudioFormat.encoding != C.ENCODING_PCM_16BIT && inputAudioFormat.encoding != C.ENCODING_PCM_FLOAT) {
            isStereoCompatible = false
            onCompatibilityChanged?.invoke(false)
            return AudioProcessor.AudioFormat.NOT_SET
        }
        if (inputAudioFormat.channelCount != 2) {
            // Non-stereo source (mono or 5.1/7.1) cannot be processed via stereo center-channel cancellation
            isStereoCompatible = false
            onCompatibilityChanged?.invoke(false)
            return AudioProcessor.AudioFormat.NOT_SET
        }

        isStereoCompatible = true
        onCompatibilityChanged?.invoke(true)
        return inputAudioFormat
    }

    override fun queueInput(inputBuffer: ByteBuffer) {
        val remaining = inputBuffer.remaining()
        if (remaining == 0) return

        val k = strength
        val compatible = isStereoCompatible

        // If vocal reduction is off (0.0f) or incompatible, pass through unchanged
        if (k <= 0.001f || !compatible) {
            val outputBuffer = replaceOutputBuffer(remaining)
            outputBuffer.put(inputBuffer)
            outputBuffer.flip()
            return
        }

        val encoding = inputAudioFormat.encoding
        val outputBuffer = replaceOutputBuffer(remaining)

        if (encoding == C.ENCODING_PCM_16BIT) {
            val inputShortBuffer = inputBuffer.order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
            val outputShortBuffer = outputBuffer.order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
            val frames = remaining / 4 // 2 channels * 2 bytes per sample

            val halfK = k * 0.5f
            val oneMinusHalfK = 1.0f - halfK

            for (i in 0 until frames) {
                val left = inputShortBuffer.get().toFloat()
                val right = inputShortBuffer.get().toFloat()

                // Center-channel vocal reduction formula:
                // L' = L - k * (L + R) / 2 = (1 - k/2) * L - (k/2) * R
                // R' = R - k * (L + R) / 2 = (1 - k/2) * R - (k/2) * L
                val newL = (oneMinusHalfK * left - halfK * right).toInt().coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt())
                val newR = (oneMinusHalfK * right - halfK * left).toInt().coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt())

                outputShortBuffer.put(newL.toShort())
                outputShortBuffer.put(newR.toShort())
            }

            inputBuffer.position(inputBuffer.position() + remaining)
            outputBuffer.position(outputBuffer.position() + frames * 4)
        } else if (encoding == C.ENCODING_PCM_FLOAT) {
            val inputFloatBuffer = inputBuffer.order(ByteOrder.LITTLE_ENDIAN).asFloatBuffer()
            val outputFloatBuffer = outputBuffer.order(ByteOrder.LITTLE_ENDIAN).asFloatBuffer()
            val frames = remaining / 8 // 2 channels * 4 bytes per sample

            val halfK = k * 0.5f
            val oneMinusHalfK = 1.0f - halfK

            for (i in 0 until frames) {
                val left = inputFloatBuffer.get()
                val right = inputFloatBuffer.get()

                val newL = (oneMinusHalfK * left - halfK * right).coerceIn(-1.0f, 1.0f)
                val newR = (oneMinusHalfK * right - halfK * left).coerceIn(-1.0f, 1.0f)

                outputFloatBuffer.put(newL)
                outputFloatBuffer.put(newR)
            }

            inputBuffer.position(inputBuffer.position() + remaining)
            outputBuffer.position(outputBuffer.position() + frames * 8)
        } else {
            outputBuffer.put(inputBuffer)
        }

        outputBuffer.flip()
    }
}
