package com.example

import android.content.Context
import android.content.Intent
import android.util.Log
import com.example.data.DownloadEntity
import com.example.ui.ActiveDownloadTask
import com.example.ui.AnalyzedVideo
import com.example.ui.DownloadStatus
import com.example.ui.VideoFormatUi
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.*

object DownloadManager {
    private const val TAG = "DownloadManager"

    private val _activeDownloads = MutableStateFlow<Map<String, ActiveDownloadTask>>(emptyMap())
    val activeDownloads = _activeDownloads.asStateFlow()

    private val _logs = MutableStateFlow<List<String>>(emptyList())
    val logs = _logs.asStateFlow()

    private val activeJobs = java.util.concurrent.ConcurrentHashMap<String, Job>()

    private val sdf = SimpleDateFormat("HH:mm:ss", Locale.getDefault())

    fun updateActiveDownloads(map: Map<String, ActiveDownloadTask>) {
        _activeDownloads.value = map
    }

    fun removeActiveTask(id: String) {
        _activeDownloads.value = _activeDownloads.value - id
        activeJobs.remove(id)?.cancel()
    }

    fun cancelDownload(id: String) {
        addLog("⚠️ Cancelling download task: $id")
        removeActiveTask(id)
    }

    fun pauseAllDownloads() {
        addLog("⏸️ Pausing all active queue downloads...")
        _activeDownloads.value = _activeDownloads.value.mapValues { (id, task) ->
            if (task.status == DownloadStatus.DOWNLOADING || task.status == DownloadStatus.PENDING) {
                activeJobs[id]?.cancel()
                task.copy(status = DownloadStatus.PAUSED, speedText = "Paused")
            } else {
                task
            }
        }
    }

    fun pauseLargeDownloads(thresholdBytes: Long, reason: String = "Paused (Battery Saver)") {
        var count = 0
        _activeDownloads.value = _activeDownloads.value.mapValues { (id, task) ->
            val isLarge = task.totalBytes >= thresholdBytes || task.totalBytes <= 0
            if (isLarge && (task.status == DownloadStatus.DOWNLOADING || task.status == DownloadStatus.PENDING)) {
                activeJobs[id]?.cancel()
                count++
                task.copy(status = DownloadStatus.PAUSED, speedText = reason)
            } else {
                task
            }
        }
        if (count > 0) {
            addLog("🔋 [Battery Optimizer] Auto-paused $count large download(s) to optimize system resources: $reason")
        }
    }

    fun pauseDownload(id: String, reason: String = "Paused") {
        addLog("⏸️ Pausing download task: $id ($reason)")
        _activeDownloads.value = _activeDownloads.value.mapValues { (taskId, task) ->
            if (taskId == id && (task.status == DownloadStatus.DOWNLOADING || task.status == DownloadStatus.PENDING)) {
                activeJobs[id]?.cancel()
                task.copy(status = DownloadStatus.PAUSED, speedText = reason)
            } else {
                task
            }
        }
    }

    fun resumeDownload(id: String) {
        addLog("▶️ Resuming download task: $id")
        _activeDownloads.value = _activeDownloads.value.mapValues { (taskId, task) ->
            if (taskId == id && task.status == DownloadStatus.PAUSED) {
                task.copy(status = DownloadStatus.PENDING, speedText = "Waiting in queue...")
            } else {
                task
            }
        }
    }

    fun resumeAllDownloads() {
        addLog("▶️ Resuming all queued/paused downloads...")
        _activeDownloads.value = _activeDownloads.value.mapValues { (_, task) ->
            if (task.status == DownloadStatus.PAUSED) {
                task.copy(status = DownloadStatus.PENDING, speedText = "Waiting in queue...")
            } else {
                task
            }
        }
    }

    fun clearFinishedOrFailedTasks() {
        addLog("🧹 Clearing completed and failed tasks from queue...")
        _activeDownloads.value = _activeDownloads.value.filterValues { task ->
            task.status != DownloadStatus.COMPLETED && task.status != DownloadStatus.FAILED
        }
    }

    fun addLog(msg: String) {
        val time = sdf.format(Date())
        val formatted = "[$time] $msg"
        Log.d(TAG, formatted)
        val current = _logs.value.takeLast(299) // Keep last 300 logs
        _logs.value = current + formatted
    }

    fun clearLogs() {
        _logs.value = emptyList()
    }

    fun startDownload(context: Context, video: AnalyzedVideo, format: VideoFormatUi, usePublicDownloads: Boolean, customFolder: String = "") {
        val videoId = video.id
        val idWithFormat = "${videoId}_${format.formatId}"

        addLog("--------------------------------------------------")
        addLog("📥 INITIATING VIDEO DOWNLOAD STAGE")
        addLog("Title: \"${video.title}\"")
        addLog("Codec Format: ${format.ext} - ${format.quality}")

        // Create initial pending state
        val initialTask = ActiveDownloadTask(
            id = idWithFormat,
            title = video.title,
            progress = 0f,
            speedText = "Connecting...",
            downloadedBytes = 0,
            totalBytes = format.sizeBytes,
            status = DownloadStatus.QUEUED,
            ext = format.ext,
            originalUrl = video.originalUrl,
            formatId = if (format.rawFormatIdStr.isNotBlank()) format.rawFormatIdStr else format.formatId.toString(),
            formatQuality = format.quality,
            author = video.author,
            durationText = video.durationText,
            thumbnailUrl = video.thumbnailUrl
        )

        _activeDownloads.value = _activeDownloads.value + (idWithFormat to initialTask)

        // Delegate execution via Foreground Service
        val intent = Intent(context, DownloadForegroundService::class.java).apply {
            action = DownloadForegroundService.ACTION_START_DOWNLOAD
            putExtra("idWithFormat", idWithFormat)
            putExtra("video_title", video.title)
            putExtra("video_id", videoId)
            putExtra("video_author", video.author)
            putExtra("video_duration", video.durationText)
            putExtra("video_thumb", video.thumbnailUrl)
            putExtra("video_url", video.originalUrl)
            val rawFmtId = if (format.rawFormatIdStr.isNotBlank()) format.rawFormatIdStr else format.formatId.toString()
            putExtra("format_id", rawFmtId)
            putExtra("format_ext", format.ext)
            putExtra("format_size", format.sizeBytes)
            putExtra("format_quality", format.quality)
            putExtra("format_type", format.type)
            putExtra("format_has_audio", format.hasAudio || format.type == "combined")
            putExtra("use_public_downloads", usePublicDownloads)
            putExtra("custom_folder", customFolder)
            
            // Collect metadata for combining logic
            val combinedFormats = video.formats.filter { 
                it.type == "audio" || (it.vcodec == "none" || it.vcodec.isBlank()) && (it.acodec != "none" && it.acodec.isNotBlank()) 
            }
            val bestAudioFormat = combinedFormats.sortedWith(compareByDescending<com.example.ui.VideoFormatUi> { fmt ->
                val kbps = fmt.quality.replace("kbps", "", ignoreCase = true).trim().toIntOrNull() ?: 0
                kbps
            }.thenByDescending { it.tbr ?: 0.0 }.thenByDescending { it.sizeBytes }).firstOrNull()
            
            val audioFormatId = bestAudioFormat?.let {
                if (it.rawFormatIdStr.isNotBlank()) it.rawFormatIdStr else it.formatId.toString()
            } ?: "bestaudio"
            putExtra("audio_format_id", audioFormatId)
        }

        val started = com.example.util.DeviceCompatHelper.startForegroundServiceCompat(context, intent)
        if (!started) {
            addLog("⚠️ Failed to dispatch background service.")
        }
    }

    fun convertAudio(context: Context, item: DownloadEntity, targetExt: String = "mp3") {
        addLog("🎵 Queueing audio conversion to ${targetExt.uppercase()} for: ${item.title}")
        
        val intent = Intent(context, DownloadForegroundService::class.java).apply {
            action = DownloadForegroundService.ACTION_CONVERT_MP3
            putExtra("item_id", item.id)
            putExtra("item_title", item.title)
            putExtra("item_author", item.author)
            putExtra("item_duration", item.durationText)
            putExtra("item_thumb", item.thumbnailUrl)
            putExtra("item_path", item.localPath)
            putExtra("target_ext", targetExt)
        }

        val started = com.example.util.DeviceCompatHelper.startForegroundServiceCompat(context, intent)
        if (!started) {
            addLog("⚠️ Unable to start audio conversion service.")
        }
    }

    // Helper method called by internal download thread inside service to track the active job
    fun registerJob(id: String, job: Job) {
        activeJobs[id]?.cancel()
        activeJobs[id] = job
    }
}
