package com.example.media

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.media.MediaMetadataRetriever
import android.util.Log
import android.util.LruCache
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.min
import kotlin.random.Random

object DownlyMediaArtworkManager {

    private const val TAG = "DownlyArtworkManager"
    const val TARGET_SIZE = 512

    // Memory cache for processed 512x512 artwork bitmaps (up to 15 items)
    private val artworkCache = object : LruCache<String, Bitmap>(15) {
        override fun sizeOf(key: String, bitmap: Bitmap): Int {
            return 1 // count by items
        }
    }

    /**
     * Primary entry point to retrieve cached or newly processed 512x512 artwork.
     * Always runs safely on IO thread and returns a non-null 512x512 Bitmap.
     */
    suspend fun getArtwork(
        context: Context,
        mediaId: String,
        title: String,
        artist: String,
        mediaPath: String,
        thumbUrl: String
    ): Bitmap = withContext(Dispatchers.IO) {
        val cacheKey = buildCacheKey(mediaId, mediaPath, title)

        // 1. Check Cache
        artworkCache.get(cacheKey)?.let { cachedBmp ->
            if (!cachedBmp.isRecycled && cachedBmp.width == TARGET_SIZE && cachedBmp.height == TARGET_SIZE) {
                return@withContext cachedBmp
            }
        }

        // 2. Try Priority 1: Embedded artwork or thumbUrl
        var embeddedBitmap: Bitmap? = null
        try {
            embeddedBitmap = extractEmbeddedArtwork(mediaPath)
        } catch (e: Exception) {
            Log.d(TAG, "Embedded metadata extraction failed: ${e.message}")
        }

        if (embeddedBitmap == null && thumbUrl.isNotBlank()) {
            try {
                embeddedBitmap = fetchNetworkThumbnail(context, thumbUrl)
            } catch (e: Exception) {
                Log.d(TAG, "Network thumbnail load failed: ${e.message}")
            }
        }

        if (embeddedBitmap != null) {
            try {
                val processedSquare = processToSquare512(embeddedBitmap)
                if (processedSquare != null) {
                    artworkCache.put(cacheKey, processedSquare)
                    return@withContext processedSquare
                }
            } catch (e: Exception) {
                Log.w(TAG, "Failed processing embedded artwork: ${e.message}")
            }
        }

        // 3. Try Priority 2: Generated Fallback Artwork
        try {
            val generatedBmp = generateSquareArtwork(title, artist)
            artworkCache.put(cacheKey, generatedBmp)
            return@withContext generatedBmp
        } catch (e: Throwable) {
            Log.e(TAG, "Artwork generation failed: ${e.message}")
        }

        // 4. Priority 3: Static Hardcoded DOWNLY Default Artwork
        val defaultBmp = createDefaultDownlyArtwork()
        artworkCache.put(cacheKey, defaultBmp)
        return@withContext defaultBmp
    }

    private fun buildCacheKey(mediaId: String, mediaPath: String, title: String): String {
        val primary = mediaId.ifBlank { mediaPath.ifBlank { title } }
        return "${primary}_${title.hashCode()}"
    }

    /**
     * Extracts embedded picture bytes from local audio/video media file using MediaMetadataRetriever.
     */
    private fun extractEmbeddedArtwork(path: String): Bitmap? {
        if (path.isBlank() || path.startsWith("http://") || path.startsWith("https://")) {
            return null
        }
        val actualPath = if (path.contains("|STREAM_AUDIO_URL|")) {
            path.substringBefore("|STREAM_AUDIO_URL|")
        } else path

        val file = java.io.File(actualPath)
        if (!file.exists() || !file.canRead()) return null

        var retriever: MediaMetadataRetriever? = null
        return try {
            retriever = MediaMetadataRetriever()
            retriever.setDataSource(actualPath)
            val pictureBytes = retriever.embeddedPicture
            if (pictureBytes != null && pictureBytes.isNotEmpty()) {
                BitmapFactory.decodeByteArray(pictureBytes, 0, pictureBytes.size)
            } else null
        } catch (e: Exception) {
            null
        } finally {
            try {
                retriever?.release()
            } catch (_: Exception) {}
        }
    }

    /**
     * Fetches thumbnail image from URL or local file URI via Coil or HttpURLConnection.
     */
    private suspend fun fetchNetworkThumbnail(context: Context, urlStr: String): Bitmap? {
        if (urlStr.isBlank()) return null
        return try {
            val loader = coil.ImageLoader(context)
            val request = coil.request.ImageRequest.Builder(context)
                .data(urlStr)
                .allowHardware(false)
                .build()
            val result = loader.execute(request)
            if (result is coil.request.SuccessResult) {
                val drawable = result.drawable
                if (drawable is android.graphics.drawable.BitmapDrawable) {
                    drawable.bitmap
                } else {
                    val bmp = Bitmap.createBitmap(
                        drawable.intrinsicWidth.coerceAtLeast(100),
                        drawable.intrinsicHeight.coerceAtLeast(100),
                        Bitmap.Config.ARGB_8888
                    )
                    val canvas = Canvas(bmp)
                    drawable.setBounds(0, 0, canvas.width, canvas.height)
                    drawable.draw(canvas)
                    bmp
                }
            } else null
        } catch (e: Exception) {
            fetchBitmapDirectHttp(urlStr)
        }
    }

    private fun fetchBitmapDirectHttp(urlString: String): Bitmap? {
        if (!urlString.startsWith("http://") && !urlString.startsWith("https://")) return null
        var conn: HttpURLConnection? = null
        return try {
            val url = URL(urlString)
            conn = url.openConnection() as HttpURLConnection
            conn.connectTimeout = 8000
            conn.readTimeout = 8000
            conn.doInput = true
            conn.connect()
            if (conn.responseCode == HttpURLConnection.HTTP_OK) {
                BitmapFactory.decodeStream(conn.inputStream)
            } else null
        } catch (e: Exception) {
            null
        } finally {
            conn?.disconnect()
        }
    }

    /**
     * Converts any input Bitmap to a perfect 512x512 square by center-cropping and scaling without stretching.
     */
    fun processToSquare512(src: Bitmap): Bitmap? {
        if (src.isRecycled) return null

        val w = src.width
        val h = src.height
        if (w <= 0 || h <= 0) return null

        val squareSize = min(w, h)
        val left = (w - squareSize) / 2
        val top = (h - squareSize) / 2

        val cropped = if (w == h) src else Bitmap.createBitmap(src, left, top, squareSize, squareSize)

        val result = if (cropped.width == TARGET_SIZE && cropped.height == TARGET_SIZE) {
            cropped
        } else {
            Bitmap.createScaledBitmap(cropped, TARGET_SIZE, TARGET_SIZE, true)
        }

        assert(result.width == result.height) { "Artwork width must equal height" }
        assert(result.width == TARGET_SIZE && result.height == TARGET_SIZE) {
            "Artwork dimensions must be 512x512, but were ${result.width}x${result.height}"
        }

        return result
    }

    /**
     * Generates a deterministic 512x512 DOWNLY artwork from media title and artist.
     * Features 2-3 complementary colors, smooth radial/linear gradients, subtle 3D lighting,
     * soft glow, dark cinematic background, slight glass depth, and centered DOWNLY branding.
     */
    fun generateSquareArtwork(title: String, artist: String): Bitmap {
        val seed = (title.trim().lowercase() + "|" + artist.trim().lowercase()).hashCode().toLong()
        val random = Random(seed)

        // Preset 3-color cinematic dark palette combinations
        val palettes = arrayOf(
            intArrayOf(0xFF8B5CF6.toInt(), 0xFFEC4899.toInt(), 0xFF3B82F6.toInt()), // Violet / Magenta / Blue
            intArrayOf(0xFF10B981.toInt(), 0xFF06B6D4.toInt(), 0xFF6366F1.toInt()), // Emerald / Cyan / Indigo
            intArrayOf(0xFFF59E0B.toInt(), 0xFFEF4444.toInt(), 0xFF8B5CF6.toInt()), // Amber / Crimson / Purple
            intArrayOf(0xFF0EA5E9.toInt(), 0xFF6366F1.toInt(), 0xFFA855F7.toInt()), // Sky / Indigo / Purple
            intArrayOf(0xFFF43F5E.toInt(), 0xFFD946EF.toInt(), 0xFF8B5CF6.toInt()), // Rose / Fuchsia / Violet
            intArrayOf(0xFF14B8A6.toInt(), 0xFF3B82F6.toInt(), 0xFF1E1B4B.toInt())  // Teal / Blue / Deep Obsidian
        )

        val selectedPalette = palettes[Math.abs(random.nextInt()) % palettes.size]
        val c1 = selectedPalette[0]
        val c2 = selectedPalette[1]
        val c3 = selectedPalette[2]

        val size = TARGET_SIZE
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)

        // 1. Dark Obsidian Canvas Base
        val basePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0xFF0D0E15.toInt()
        }
        canvas.drawRect(0f, 0f, size.toFloat(), size.toFloat(), basePaint)

        // 2. Smooth Linear Directional Gradient Overlay
        val angleChoice = Math.abs(random.nextInt()) % 4
        val (x0, y0, x1, y1) = when (angleChoice) {
            0 -> arrayOf(0f, 0f, size.toFloat(), size.toFloat())
            1 -> arrayOf(size.toFloat(), 0f, 0f, size.toFloat())
            2 -> arrayOf(0f, size.toFloat(), size.toFloat(), 0f)
            else -> arrayOf(size.toFloat() / 2, 0f, size.toFloat() / 2, size.toFloat())
        }

        val linearPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = LinearGradient(
                x0, y0, x1, y1,
                intArrayOf(c1, c2, c3),
                floatArrayOf(0f, 0.55f, 1f),
                Shader.TileMode.CLAMP
            )
            alpha = 210 // semi-transparent over obsidian base
        }
        canvas.drawRect(0f, 0f, size.toFloat(), size.toFloat(), linearPaint)

        // 3. Central Radial Glow for 3D Cinematic Lighting Depth
        val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = RadialGradient(
                size / 2f, size / 2f, size * 0.65f,
                intArrayOf(0x99FFFFFF.toInt(), c1, 0x00000000),
                floatArrayOf(0f, 0.45f, 1f),
                Shader.TileMode.CLAMP
            )
        }
        canvas.drawRect(0f, 0f, size.toFloat(), size.toFloat(), glowPaint)

        // 4. Subtle Liquid Glass Specular Arc Overlays
        val specPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = LinearGradient(
                0f, 0f, size.toFloat(), size / 2f,
                intArrayOf(0x40FFFFFF.toInt(), 0x00FFFFFF.toInt()),
                null,
                Shader.TileMode.CLAMP
            )
        }
        val specPath = Path().apply {
            moveTo(0f, 0f)
            lineTo(size.toFloat(), 0f)
            lineTo(size.toFloat(), size * 0.35f)
            cubicTo(
                size * 0.7f, size * 0.45f,
                size * 0.3f, size * 0.25f,
                0f, size * 0.35f
            )
            close()
        }
        canvas.drawPath(specPath, specPaint)

        // 5. Centered DOWNLY Clean Display Typography Branding
        val cx = size / 2f
        val cy = size / 2f

        val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0xFFFFFFFF.toInt()
            textSize = 38f
            letterSpacing = 0.28f
            textAlign = Paint.Align.CENTER
            isFakeBoldText = true
            setShadowLayer(10f, 0f, 3f, 0x80000000.toInt())
        }
        val yPos = cy - ((textPaint.descent() + textPaint.ascent()) / 2)
        canvas.drawText("DOWNLY", cx, yPos, textPaint)

        // Strict Geometry Assertions
        assert(bmp.width == bmp.height) { "Generated artwork must be square" }
        assert(bmp.width == TARGET_SIZE && bmp.height == TARGET_SIZE) {
            "Generated artwork dimensions must be 512x512, but were ${bmp.width}x${bmp.height}"
        }

        return bmp
    }

    /**
     * Fallback static DOWNLY default artwork in case generation fails.
     */
    fun createDefaultDownlyArtwork(): Bitmap {
        val size = TARGET_SIZE
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)

        val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = LinearGradient(
                0f, 0f, size.toFloat(), size.toFloat(),
                intArrayOf(0xFF7E22CE.toInt(), 0xFF1E1B4B.toInt(), 0xFF0F172A.toInt()),
                floatArrayOf(0f, 0.5f, 1f),
                Shader.TileMode.CLAMP
            )
        }
        canvas.drawRect(0f, 0f, size.toFloat(), size.toFloat(), bgPaint)

        val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = 36f
            letterSpacing = 0.25f
            textAlign = Paint.Align.CENTER
            isFakeBoldText = true
        }
        canvas.drawText("DOWNLY", size / 2f, size / 2f + 12f, textPaint)

        assert(bmp.width == bmp.height)
        assert(bmp.width == TARGET_SIZE && bmp.height == TARGET_SIZE)

        return bmp
    }

    fun ByteArrayToBitmap(data: ByteArray): Bitmap? {
        return try {
            BitmapFactory.decodeByteArray(data, 0, data.size)
        } catch (e: Exception) {
            null
        }
    }

    fun bitmapToByteArray(bitmap: Bitmap): ByteArray {
        val stream = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.PNG, 95, stream)
        return stream.toByteArray()
    }
}
