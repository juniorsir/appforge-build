package com.example.media.preview

import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.util.Log
import android.util.LruCache
import com.example.media.operations.ThumbnailEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/**
 * FRP (Frame Realtime Preview) Engine
 * High-performance, low-latency video frame extraction and memory-cached preview subsystem
 * for video player scrubbing, timeline seekbar thumbnails, and media previews.
 */
object FrpPreviewEngine {
    private const val TAG = "FrpPreviewEngine"

    // Active playback source tracked globally for ambient FRP seekbar preview
    @Volatile
    var activePlaybackUri: Uri? = null

    @Volatile
    var activePlaybackPath: String? = null

    // Max 30MB in-memory LRU cache for extracted FRP preview frames
    private val maxMemoryBytes = (Runtime.getRuntime().maxMemory() / 8).toInt().coerceAtMost(30 * 1024 * 1024)
    private val frameCache = object : LruCache<String, Bitmap>(maxMemoryBytes) {
        override fun sizeOf(key: String, bitmap: Bitmap): Int {
            return bitmap.byteCount
        }
    }

    /**
     * Sets the active playback source for global FRP frame retrieval.
     */
    fun setActivePlaybackSource(uri: Uri?, path: String?) {
        activePlaybackUri = uri
        activePlaybackPath = path
    }

    /**
     * Retrieves or asynchronously extracts a video frame for the given timestamp in milliseconds.
     * Uses 500ms time-quantization to maximize cache hits during smooth seekbar scrubbing.
     */
    suspend fun getFrameAtTime(
        context: Context,
        uri: Uri?,
        path: String?,
        timeMs: Long,
        targetWidth: Int = 240,
        targetHeight: Int = 135
    ): Bitmap? = withContext(Dispatchers.IO) {
        val effectiveUri = uri ?: activePlaybackUri
        val effectivePath = path ?: activePlaybackPath
        val safeTimeMs = timeMs.coerceAtLeast(0L)
        val quantizedBucket = safeTimeMs / 500L
        val sourceKey = (effectiveUri?.toString() ?: effectivePath ?: return@withContext null)
        val cacheKey = "${sourceKey}_q$quantizedBucket"

        // 1. Check in-memory LRU cache first
        val cached = frameCache.get(cacheKey)
        if (cached != null && !cached.isRecycled) {
            return@withContext cached
        }

        // 2. Hardware / Native extraction via MediaMetadataRetriever
        var extracted: Bitmap? = null
        try {
            val retriever = MediaMetadataRetriever()
            if (effectiveUri != null && effectiveUri.scheme != null && effectiveUri.scheme != "file") {
                retriever.setDataSource(context, effectiveUri)
            } else {
                val filePath = effectiveUri?.path ?: effectivePath
                if (filePath != null && File(filePath).exists()) {
                    retriever.setDataSource(filePath)
                }
            }

            val timeUs = safeTimeMs * 1000L
            extracted = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
                try {
                    retriever.getScaledFrameAtTime(
                        timeUs,
                        MediaMetadataRetriever.OPTION_CLOSEST,
                        targetWidth,
                        targetHeight
                    )
                } catch (_: Throwable) {
                    retriever.getFrameAtTime(timeUs, MediaMetadataRetriever.OPTION_CLOSEST)
                }
            } else {
                retriever.getFrameAtTime(timeUs, MediaMetadataRetriever.OPTION_CLOSEST)
            }

            try {
                retriever.release()
            } catch (_: Throwable) {}
        } catch (e: Throwable) {
            Log.d(TAG, "MediaMetadataRetriever frame extraction fallback to FFmpeg: ${e.message}")
        }

        // 3. Fallback to FFmpeg ThumbnailEngine if MediaMetadataRetriever couldn't extract (e.g. MKV/AVI/unsupported codecs)
        if (extracted == null && (effectiveUri != null || effectivePath != null)) {
            val targetUri = effectiveUri ?: Uri.fromFile(File(effectivePath!!))
            try {
                val ffmpegResult = ThumbnailEngine.generateThumbnail(
                    context = context,
                    uri = targetUri,
                    timestampMs = safeTimeMs,
                    maxWidth = targetWidth,
                    maxHeight = targetHeight
                )
                extracted = ffmpegResult.getOrNull()
            } catch (e: Throwable) {
                Log.w(TAG, "FFmpeg FRP extraction failed: ${e.message}")
            }
        }

        // 4. Cache and return if successfully extracted
        if (extracted != null) {
            frameCache.put(cacheKey, extracted)
        }

        return@withContext extracted
    }

    /**
     * Clear all cached FRP frames
     */
    fun clearCache() {
        frameCache.evictAll()
    }
}
