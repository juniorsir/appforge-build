package com.example.player.gestures

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.Immutable
import org.json.JSONObject

@Immutable
enum class PlayerGesture(
    val id: String,
    val displayName: String,
    val description: String
) {
    TWO_FINGER_DOUBLE_TAP(
        id = "two_finger_double_tap",
        displayName = "Two-Finger Double Tap",
        description = "Quickly double tap the video screen with two fingers"
    ),
    THREE_FINGER_TAP(
        id = "three_finger_tap",
        displayName = "Three-Finger Tap",
        description = "Single tap the screen with three fingers simultaneously"
    ),
    TWO_FINGER_SWIPE_UP(
        id = "two_finger_swipe_up",
        displayName = "Two-Finger Swipe Up",
        description = "Swipe upward vertically using two fingers"
    ),
    TWO_FINGER_SWIPE_DOWN(
        id = "two_finger_swipe_down",
        displayName = "Two-Finger Swipe Down",
        description = "Swipe downward vertically using two fingers"
    ),
    LEFT_EDGE_SWIPE(
        id = "left_edge_swipe",
        displayName = "Left-Edge Inward Swipe",
        description = "Swipe inward horizontally from the left edge of the screen"
    ),
    RIGHT_EDGE_SWIPE(
        id = "right_edge_swipe",
        displayName = "Right-Edge Inward Swipe",
        description = "Swipe inward horizontally from the right edge of the screen"
    ),
    LONG_PRESS(
        id = "long_press",
        displayName = "Long Press",
        description = "Press and hold the player screen for 500ms"
    );

    companion object {
        fun fromId(id: String): PlayerGesture? {
            return entries.firstOrNull { it.id.equals(id, ignoreCase = true) || it.name.equals(id, ignoreCase = true) }
        }
    }
}

@Immutable
enum class PlayerGestureAction(
    val id: String,
    val displayName: String,
    val description: String
) {
    NONE(
        id = "none",
        displayName = "Off / Disabled",
        description = "No action performed"
    ),
    PLAY_PAUSE(
        id = "play_pause",
        displayName = "Play / Pause",
        description = "Toggle video playback and pause"
    ),
    MUTE_UNMUTE(
        id = "mute_unmute",
        displayName = "Mute / Unmute",
        description = "Toggle audio mute state"
    ),
    NEXT_MEDIA(
        id = "next_media",
        displayName = "Next",
        description = "Play next media in playlist or queue"
    ),
    PREVIOUS_MEDIA(
        id = "previous_media",
        displayName = "Previous",
        description = "Play previous media in playlist or queue"
    ),
    SEEK_FORWARD_10(
        id = "seek_fwd_10",
        displayName = "Seek +10 seconds",
        description = "Fast-forward playback position by 10s"
    ),
    SEEK_BACKWARD_10(
        id = "seek_bwd_10",
        displayName = "Seek −10 seconds",
        description = "Rewind playback position by 10s"
    ),
    SPEED_TOGGLE(
        id = "speed_toggle",
        displayName = "Speed Toggle",
        description = "Cycle speed (1x → 1.25x → 1.5x → 2x)"
    ),
    OPEN_CONTROLS(
        id = "open_controls",
        displayName = "Open Player Controls",
        description = "Toggle visibility of playback controls"
    ),
    LOCK_PLAYER(
        id = "lock_player",
        displayName = "Lock Player",
        description = "Toggle touch lock to prevent accidental touches"
    ),
    SCREENSHOT(
        id = "screenshot",
        displayName = "Screenshot",
        description = "Capture and save current video frame"
    );

    companion object {
        fun fromId(id: String): PlayerGestureAction {
            return entries.firstOrNull { it.id.equals(id, ignoreCase = true) || it.name.equals(id, ignoreCase = true) }
                ?: NONE
        }
    }
}

@Immutable
data class PlayerGestureSettings(
    val mappings: Map<PlayerGesture, PlayerGestureAction> = defaultMappings()
) {
    fun getActionFor(gesture: PlayerGesture): PlayerGestureAction {
        return mappings[gesture] ?: defaultFor(gesture)
    }

    fun withAction(gesture: PlayerGesture, action: PlayerGestureAction): PlayerGestureSettings {
        val updated = mappings.toMutableMap()
        updated[gesture] = action
        return copy(mappings = updated)
    }

    companion object {
        fun defaultFor(gesture: PlayerGesture): PlayerGestureAction {
            return when (gesture) {
                PlayerGesture.TWO_FINGER_DOUBLE_TAP -> PlayerGestureAction.PLAY_PAUSE
                else -> PlayerGestureAction.NONE
            }
        }

        fun defaultMappings(): Map<PlayerGesture, PlayerGestureAction> {
            return PlayerGesture.entries.associateWith { defaultFor(it) }
        }
    }
}

object PlayerGesturePreferencesManager {
    private const val PREFS_NAME = "downly_player_gestures_prefs"
    private const val KEY_MAPPINGS_JSON = "custom_gesture_mappings_json"

    fun loadSettings(context: Context): PlayerGestureSettings {
        val prefs: SharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val jsonStr = prefs.getString(KEY_MAPPINGS_JSON, null) ?: return PlayerGestureSettings()
        return try {
            val json = JSONObject(jsonStr)
            val map = mutableMapOf<PlayerGesture, PlayerGestureAction>()
            PlayerGesture.entries.forEach { gesture ->
                if (json.has(gesture.id)) {
                    val actionId = json.getString(gesture.id)
                    map[gesture] = PlayerGestureAction.fromId(actionId)
                } else {
                    map[gesture] = PlayerGestureSettings.defaultFor(gesture)
                }
            }
            PlayerGestureSettings(mappings = map)
        } catch (e: Exception) {
            PlayerGestureSettings()
        }
    }

    fun saveSettings(context: Context, settings: PlayerGestureSettings) {
        val prefs: SharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        try {
            val json = JSONObject()
            settings.mappings.forEach { (gesture, action) ->
                json.put(gesture.id, action.id)
            }
            prefs.edit().putString(KEY_MAPPINGS_JSON, json.toString()).apply()
        } catch (_: Exception) {
        }
    }
}
