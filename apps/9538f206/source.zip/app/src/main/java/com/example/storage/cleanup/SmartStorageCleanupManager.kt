package com.example.storage.cleanup

import android.content.Context
import android.os.Environment
import android.os.StatFs
import android.util.Log
import com.example.data.AppDatabase
import com.example.data.DownloadEntity
import com.example.data.PlaybackProgressEntity
import java.io.File

/**
 * Period options for automatic watched media cleanup.
 */
enum class AutoCleanPeriod(val days: Int, val displayName: String, val durationMs: Long) {
    OFF(0, "OFF", 0L),
    ONE_DAY(1, "After 1 day", 1L * 24 * 60 * 60 * 1000L),
    THREE_DAYS(3, "After 3 days", 3L * 24 * 60 * 60 * 1000L),
    SEVEN_DAYS(7, "After 7 days", 7L * 24 * 60 * 60 * 1000L),
    FOURTEEN_DAYS(14, "After 14 days", 14L * 24 * 60 * 60 * 1000L),
    THIRTY_DAYS(30, "After 30 days", 30L * 24 * 60 * 60 * 1000L);

    companion object {
        fun fromDays(days: Int): AutoCleanPeriod = entries.firstOrNull { it.days == days } ?: OFF
    }
}

/**
 * Configuration settings for watched download cleanup and safety protections.
 */
data class AutoCleanSettings(
    val period: AutoCleanPeriod = AutoCleanPeriod.OFF,
    val keepFavorites: Boolean = true,
    val keepPlaylistItems: Boolean = true,
    val keepMarkedItems: Boolean = true,
    val onlyCleanWhenStorageLow: Boolean = false,
    val lowStorageThresholdPercent: Int = 15
)

/**
 * Encapsulates an item inspected for potential cleanup or review.
 */
data class WatchedMediaCleanupItem(
    val mediaId: String,
    val title: String,
    val filePath: String,
    val fileSize: Long,
    val completedTimestamp: Long,
    val scheduledDeletionTimestamp: Long,
    val isEligibleNow: Boolean,
    val isProtected: Boolean,
    val isKept: Boolean,
    val isFavorite: Boolean,
    val isInPlaylist: Boolean,
    val isCurrentlyPlaying: Boolean,
    val isCurrentlyDownloading: Boolean,
    val protectionReason: String? = null
)

/**
 * Execution summary after running a cleanup pass.
 */
data class CleanupExecutionResult(
    val deletedCount: Int,
    val freedBytes: Long,
    val skippedProtectedCount: Int,
    val skippedNotDueCount: Int,
    val errorCount: Int
)

object SmartStorageCleanupManager {
    private const val TAG = "SmartStorageCleanup"
    private const val PREFS_NAME = "storage_cleanup_prefs"
    private const val KEY_CLEAN_PERIOD_DAYS = "auto_clean_period_days"
    private const val KEY_KEEP_FAVORITES = "keep_favorites"
    private const val KEY_KEEP_PLAYLISTS = "keep_playlists"
    private const val KEY_KEEP_MARKED = "keep_marked"
    private const val KEY_LOW_STORAGE_ONLY = "only_clean_when_storage_low"

    /**
     * Load settings from SharedPreferences.
     */
    fun loadSettings(context: Context): AutoCleanSettings {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val periodDays = prefs.getInt(KEY_CLEAN_PERIOD_DAYS, 0)
        return AutoCleanSettings(
            period = AutoCleanPeriod.fromDays(periodDays),
            keepFavorites = prefs.getBoolean(KEY_KEEP_FAVORITES, true),
            keepPlaylistItems = prefs.getBoolean(KEY_KEEP_PLAYLISTS, true),
            keepMarkedItems = prefs.getBoolean(KEY_KEEP_MARKED, true),
            onlyCleanWhenStorageLow = prefs.getBoolean(KEY_LOW_STORAGE_ONLY, false)
        )
    }

    /**
     * Save settings to SharedPreferences.
     */
    fun saveSettings(context: Context, settings: AutoCleanSettings) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit()
            .putInt(KEY_CLEAN_PERIOD_DAYS, settings.period.days)
            .putBoolean(KEY_KEEP_FAVORITES, settings.keepFavorites)
            .putBoolean(KEY_KEEP_PLAYLISTS, settings.keepPlaylistItems)
            .putBoolean(KEY_KEEP_MARKED, settings.keepMarkedItems)
            .putBoolean(KEY_LOW_STORAGE_ONLY, settings.onlyCleanWhenStorageLow)
            .apply()
    }

    /**
     * Check if device free storage is below safety threshold.
     */
    fun isStorageLow(context: Context, thresholdPercent: Int = 15): Boolean {
        return try {
            val path = context.getExternalFilesDir(null) ?: context.filesDir
            val statFs = StatFs(path.absolutePath)
            val availableBytes = statFs.availableBlocksLong * statFs.blockSizeLong
            val totalBytes = statFs.blockCountLong * statFs.blockSizeLong
            if (totalBytes <= 0L) return false
            val freePercent = (availableBytes.toDouble() / totalBytes.toDouble()) * 100.0
            freePercent < thresholdPercent.toDouble() || availableBytes < 1024L * 1024L * 1024L // <15% or <1GB free
        } catch (e: Exception) {
            Log.e(TAG, "Failed to inspect storage stats: ${e.message}")
            false
        }
    }

    /**
     * Inspect all downloaded files and playback records to generate items for review.
     */
    suspend fun getWatchedCleanupReviewList(
        database: AppDatabase,
        settings: AutoCleanSettings,
        playlistMediaIds: Set<String>,
        favoriteMediaIds: Set<String>,
        currentlyPlayingMediaId: String?,
        activeDownloadIds: Set<String>,
        currentTimeMs: Long = System.currentTimeMillis()
    ): List<WatchedMediaCleanupItem> {
        return try {
            val allDownloads = database.downloadDao().getAllDownloadsSync()
            val allProgress = database.playbackDao().getAllProgressSync().associateBy { it.mediaId }

            val reviewItems = mutableListOf<WatchedMediaCleanupItem>()

            for (download in allDownloads) {
                val progress = allProgress[download.id]
                // Only consider items that have genuinely reached playback completion
                if (progress == null || !progress.isCompleted) {
                    continue
                }

                val completedTime = if (progress.completedTimestamp > 0L) {
                    progress.completedTimestamp
                } else {
                    progress.lastPlayedTimestamp
                }

                val scheduledTime = if (settings.period != AutoCleanPeriod.OFF) {
                    completedTime + settings.period.durationMs
                } else {
                    0L
                }

                val isFavorite = download.isFavorite || favoriteMediaIds.contains(download.id)
                val isKept = download.isKept
                val isProtected = download.isProtected
                val inPlaylist = playlistMediaIds.contains(download.id)
                val isPlaying = currentlyPlayingMediaId == download.id
                val isDownloading = activeDownloadIds.contains(download.id)

                // Determine protection reason if any
                val protectionReason = when {
                    isPlaying -> "Currently playing"
                    isDownloading -> "Active download/recovery"
                    isProtected -> "Protected from deletion"
                    isKept && settings.keepMarkedItems -> "Marked as Keep"
                    isFavorite && settings.keepFavorites -> "Favorite media"
                    inPlaylist && settings.keepPlaylistItems -> "In saved playlist"
                    else -> null
                }

                val isEligibleNow = protectionReason == null &&
                        settings.period != AutoCleanPeriod.OFF &&
                        currentTimeMs >= scheduledTime

                reviewItems.add(
                    WatchedMediaCleanupItem(
                        mediaId = download.id,
                        title = download.title,
                        filePath = download.localPath,
                        fileSize = download.fileSize,
                        completedTimestamp = completedTime,
                        scheduledDeletionTimestamp = scheduledTime,
                        isEligibleNow = isEligibleNow,
                        isProtected = isProtected,
                        isKept = isKept,
                        isFavorite = isFavorite,
                        isInPlaylist = inPlaylist,
                        isCurrentlyPlaying = isPlaying,
                        isCurrentlyDownloading = isDownloading,
                        protectionReason = protectionReason
                    )
                )
            }

            reviewItems.sortedByDescending { it.completedTimestamp }
        } catch (e: Exception) {
            Log.e(TAG, "Error calculating watched cleanup review list: ${e.message}")
            emptyList()
        }
    }

    /**
     * Safely executes cleanup of eligible watched files.
     */
    suspend fun performSafeCleanup(
        context: Context,
        database: AppDatabase,
        settings: AutoCleanSettings,
        playlistMediaIds: Set<String>,
        favoriteMediaIds: Set<String>,
        currentlyPlayingMediaId: String?,
        activeDownloadIds: Set<String>,
        forceClean: Boolean = false,
        specificMediaIdsToClean: Set<String>? = null,
        currentTimeMs: Long = System.currentTimeMillis()
    ): CleanupExecutionResult {
        var deletedCount = 0
        var freedBytes = 0L
        var skippedProtectedCount = 0
        var skippedNotDueCount = 0
        var errorCount = 0

        // If auto-clean is OFF and this isn't a manual force action, exit safely
        if (settings.period == AutoCleanPeriod.OFF && !forceClean && specificMediaIdsToClean == null) {
            return CleanupExecutionResult(0, 0, 0, 0, 0)
        }

        // If low-storage only mode is active, ensure storage is indeed low
        if (settings.onlyCleanWhenStorageLow && !forceClean && specificMediaIdsToClean == null) {
            if (!isStorageLow(context, settings.lowStorageThresholdPercent)) {
                Log.d(TAG, "Storage is healthy; skipping scheduled cleanup pass in Low-Storage Mode.")
                return CleanupExecutionResult(0, 0, 0, 0, 0)
            }
        }

        try {
            val allDownloads = database.downloadDao().getAllDownloadsSync()
            val allProgress = database.playbackDao().getAllProgressSync().associateBy { it.mediaId }

            for (download in allDownloads) {
                // If specific targets requested, filter
                if (specificMediaIdsToClean != null && !specificMediaIdsToClean.contains(download.id)) {
                    continue
                }

                val progress = allProgress[download.id]
                // Only consider watched/completed items
                if (progress == null || !progress.isCompleted) {
                    continue
                }

                val completedTime = if (progress.completedTimestamp > 0L) {
                    progress.completedTimestamp
                } else {
                    progress.lastPlayedTimestamp
                }

                val scheduledTime = if (settings.period != AutoCleanPeriod.OFF) {
                    completedTime + settings.period.durationMs
                } else {
                    0L
                }

                // ==========================================
                // 9. LAST-MINUTE SAFETY RE-CHECKS
                // ==========================================
                val isPlaying = currentlyPlayingMediaId == download.id
                val isDownloading = activeDownloadIds.contains(download.id)
                val isFavorite = download.isFavorite || favoriteMediaIds.contains(download.id)
                val inPlaylist = playlistMediaIds.contains(download.id)

                if (isPlaying || isDownloading) {
                    skippedProtectedCount++
                    continue
                }

                if (download.isProtected) {
                    skippedProtectedCount++
                    continue
                }

                if (download.isKept && settings.keepMarkedItems) {
                    skippedProtectedCount++
                    continue
                }

                if (isFavorite && settings.keepFavorites) {
                    skippedProtectedCount++
                    continue
                }

                if (inPlaylist && settings.keepPlaylistItems) {
                    skippedProtectedCount++
                    continue
                }

                // Check due timestamp unless forced or specific IDs requested
                if (specificMediaIdsToClean == null && !forceClean) {
                    if (settings.period == AutoCleanPeriod.OFF || currentTimeMs < scheduledTime) {
                        skippedNotDueCount++
                        continue
                    }
                }

                // Verify file path exists and is valid before deletion
                if (download.localPath.isBlank()) {
                    errorCount++
                    continue
                }

                val file = File(download.localPath)
                val fileSize = if (file.exists()) file.length() else download.fileSize

                var fileDeletedSuccessfully = false
                if (file.exists()) {
                    try {
                        // Safe deletion: Attempt moving to trash cache if supported, or cleanly deleting
                        val trashDir = File(context.cacheDir, ".trash")
                        if (!trashDir.exists()) trashDir.mkdirs()

                        val trashedFile = File(trashDir, "${System.currentTimeMillis()}_${file.name}")
                        val movedToTrash = file.renameTo(trashedFile)

                        if (movedToTrash) {
                            trashedFile.delete() // purge from trash cache
                            fileDeletedSuccessfully = true
                        } else {
                            fileDeletedSuccessfully = file.delete()
                        }
                    } catch (e: Exception) {
                        Log.e(TAG, "Failed to delete file for media ${download.id}: ${e.message}")
                        errorCount++
                    }
                } else {
                    // File already missing from disk, clean up database record
                    fileDeletedSuccessfully = true
                }

                if (fileDeletedSuccessfully) {
                    try {
                        database.downloadDao().deleteDownloadById(download.id)
                        database.playbackDao().clearProgress(download.id)
                        deletedCount++
                        freedBytes += fileSize
                        Log.d(TAG, "Successfully auto-cleaned watched download: ${download.title} ($fileSize bytes)")
                    } catch (e: Exception) {
                        Log.e(TAG, "Failed to delete database record for media ${download.id}: ${e.message}")
                        errorCount++
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error executing safe storage cleanup: ${e.message}")
            errorCount++
        }

        return CleanupExecutionResult(
            deletedCount = deletedCount,
            freedBytes = freedBytes,
            skippedProtectedCount = skippedProtectedCount,
            skippedNotDueCount = skippedNotDueCount,
            errorCount = errorCount
        )
    }
}
