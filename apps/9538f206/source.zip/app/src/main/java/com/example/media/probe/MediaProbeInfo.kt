package com.example.media.probe

data class VideoStreamInfo(
    val index: Int = 0,
    val codec: String = "unknown",
    val codecLongName: String? = null,
    val profile: String? = null,
    val width: Int = 0,
    val height: Int = 0,
    val frameRate: Float = 0f,
    val bitrate: Long = 0L,
    val pixelFormat: String? = null,
    val colorSpace: String? = null,
    val bitDepth: Int = 8,
    val isDefault: Boolean = false,
    val rotation: Int = 0
)

data class AudioStreamInfo(
    val index: Int = 0,
    val codec: String = "unknown",
    val codecLongName: String? = null,
    val sampleRate: Int = 0,
    val channels: Int = 0,
    val channelLayout: String? = null,
    val bitrate: Long = 0L,
    val language: String = "und",
    val title: String? = null,
    val isDefault: Boolean = false,
    val isForced: Boolean = false
)

data class SubtitleStreamInfo(
    val index: Int = 0,
    val codec: String = "unknown",
    val language: String = "und",
    val title: String? = null,
    val isDefault: Boolean = false,
    val isForced: Boolean = false
)

data class MediaProbeInfo(
    val pathOrUri: String,
    val format: String = "unknown",
    val formatLongName: String? = null,
    val durationMs: Long = 0L,
    val sizeBytes: Long = 0L,
    val overallBitrate: Long = 0L,
    val videoStreams: List<VideoStreamInfo> = emptyList(),
    val audioStreams: List<AudioStreamInfo> = emptyList(),
    val subtitleStreams: List<SubtitleStreamInfo> = emptyList(),
    val metadataTags: Map<String, String> = emptyMap(),
    val rawProperties: String? = null
) {
    val primaryVideo: VideoStreamInfo?
        get() = videoStreams.firstOrNull { it.isDefault } ?: videoStreams.firstOrNull()

    val primaryAudio: AudioStreamInfo?
        get() = audioStreams.firstOrNull { it.isDefault } ?: audioStreams.firstOrNull()

    val isVideo: Boolean
        get() = videoStreams.isNotEmpty()

    val isAudioOnly: Boolean
        get() = videoStreams.isEmpty() && audioStreams.isNotEmpty()

    fun toFormattedReport(): String {
        val sb = StringBuilder()
        sb.appendLine("=== Media Probe Information ===")
        sb.appendLine("Source: $pathOrUri")
        sb.appendLine("Container: $format ($formatLongName)")
        sb.appendLine("Duration: ${durationMs / 1000.0}s ($durationMs ms)")
        sb.appendLine("Size: ${sizeBytes / 1024 / 1024.0} MB ($sizeBytes bytes)")
        sb.appendLine("Bitrate: ${overallBitrate / 1000} kbps")

        if (videoStreams.isNotEmpty()) {
            sb.appendLine("\n[Video Streams: ${videoStreams.size}]")
            for (v in videoStreams) {
                sb.appendLine("  #${v.index}: ${v.codec.uppercase()} | ${v.width}x${v.height} | ${v.frameRate} fps | ${v.bitrate / 1000} kbps | pix_fmt=${v.pixelFormat} | rot=${v.rotation}°")
            }
        }

        if (audioStreams.isNotEmpty()) {
            sb.appendLine("\n[Audio Streams: ${audioStreams.size}]")
            for (a in audioStreams) {
                sb.appendLine("  #${a.index}: ${a.codec.uppercase()} | ${a.language} | ${a.channels}ch (${a.channelLayout}) | ${a.sampleRate} Hz | ${a.bitrate / 1000} kbps | title=${a.title}")
            }
        }

        if (subtitleStreams.isNotEmpty()) {
            sb.appendLine("\n[Subtitle Streams: ${subtitleStreams.size}]")
            for (s in subtitleStreams) {
                sb.appendLine("  #${s.index}: ${s.codec} | lang=${s.language} | title=${s.title} | def=${s.isDefault}")
            }
        }

        if (metadataTags.isNotEmpty()) {
            sb.appendLine("\n[Metadata Tags]")
            metadataTags.forEach { (k, v) ->
                sb.appendLine("  $k = $v")
            }
        }
        sb.appendLine("===============================")
        return sb.toString()
    }
}
