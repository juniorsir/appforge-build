package com.example.extraction

/**
 * Stage 3: ManifestResolver
 * Performs manifest intelligence to accurately categorize stream types (HLS, DASH, Progressive, Live, etc.).
 */
object ManifestResolver {

    /**
     * Resolves stream type for a raw format based on protocol, URL, formatNote, and codecs.
     */
    fun resolveStreamType(raw: RawFormat, isVideoLive: Boolean): StreamType {
        if (isVideoLive) {
            return StreamType.LIVE_STREAM
        }

        val url = raw.url.lowercase()
        val protocol = raw.protocol.lowercase()
        val note = raw.formatNote.lowercase()
        val formatId = raw.formatIdStr.lowercase()
        val manifestUrl = raw.manifestUrl.lowercase()

        // 1. Live stream detection
        if (protocol.contains("live") || note.contains("live") || formatId.contains("live")) {
            return StreamType.LIVE_STREAM
        }

        // 2. HLS Manifest
        if (url.contains(".m3u8") || manifestUrl.contains(".m3u8") ||
            protocol.contains("hls") || formatId.contains("hls") || note.contains("hls")) {
            return StreamType.ADAPTIVE_HLS
        }

        // 3. DASH Manifest
        if (url.contains(".mpd") || manifestUrl.contains(".mpd") ||
            protocol.contains("dash") || formatId.contains("dash") || note.contains("dash")) {
            return StreamType.ADAPTIVE_DASH
        }

        // Codec & Format checks
        val isVideoExt = raw.ext.lowercase() in listOf("mp4", "mkv", "webm", "mov", "avi", "3gp", "flv", "ts")
        val isVideoNote = note.contains("p") || formatId.contains("video") || note.contains("video")
        val hasVideo = (raw.vcodec.isNotBlank() && !raw.vcodec.equals("none", ignoreCase = true)) ||
                raw.height > 0 || raw.width > 0 || isVideoExt || isVideoNote

        val isAudioExt = raw.ext.lowercase() in listOf("mp3", "m4a", "aac", "wav", "flac", "opus", "ogg", "wma")
        val isAudioNote = note.contains("audio") || formatId.contains("audio")
        val hasAudio = (raw.acodec.isNotBlank() && !raw.acodec.equals("none", ignoreCase = true)) ||
                isAudioExt || isAudioNote

        return when {
            hasVideo && hasAudio -> StreamType.MERGED
            hasVideo -> StreamType.VIDEO_ONLY
            hasAudio && !hasVideo -> StreamType.AUDIO_ONLY
            else -> StreamType.PROGRESSIVE
        }
    }
}
