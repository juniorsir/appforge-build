package com.example.extraction

/**
 * Stage 5: DuplicateAndRankEngine
 * Intelligently merges duplicates and scores/ranks formats using multi-attribute metrics (Phase 6, 7, 8).
 */
object DuplicateAndRankEngine {

    private data class DeduplicationKey(
        val streamType: StreamType,
        val height: Int,
        val ext: String,
        val videoCodecFamily: String,
        val audioCodecFamily: String,
        val fps: Int,
        val isHdr: Boolean,
        val roundedBitrateKbps: Int
    )

    /**
     * Deduplicates and ranks normalized formats.
     */
    fun process(formats: List<NormalizedFormat>): List<NormalizedFormat> {
        if (formats.isEmpty()) return emptyList()

        // 1. Compute quality scores for each format
        val scoredFormats = formats.map { computeScore(it) }

        // 2. Filter out audio streams with extremely low bitrates (< 24 kbps) if higher quality audio exists (Phase 8)
        val hasGoodAudio = scoredFormats.any { it.streamType == StreamType.AUDIO_ONLY && it.audioBitrateKbps >= 48 }
        val filteredAudio = scoredFormats.filterNot {
            hasGoodAudio && it.streamType == StreamType.AUDIO_ONLY && it.audioBitrateKbps in 1..23
        }

        // 3. Deduplicate (Phase 6)
        val deduplicatedMap = LinkedHashMap<DeduplicationKey, NormalizedFormat>()

        filteredAudio.forEach { format ->
            val roundedBitrate = (format.bitrateKbps / 250) * 250 // Group within ~250kbps band
            val key = DeduplicationKey(
                streamType = format.streamType,
                height = format.resolutionHeight,
                ext = format.ext.lowercase(),
                videoCodecFamily = format.videoCodecFamily,
                audioCodecFamily = format.audioCodecFamily,
                fps = if (format.fps >= 50) 60 else 30,
                isHdr = format.isHdr,
                roundedBitrateKbps = roundedBitrate
            )

            val existing = deduplicatedMap[key]
            if (existing == null || format.qualityScore > existing.qualityScore) {
                deduplicatedMap[key] = format
            }
        }

        // 4. Sort formats descending by quality score
        return deduplicatedMap.values.sortedByDescending { it.qualityScore }
    }

    private fun computeScore(fmt: NormalizedFormat): NormalizedFormat {
        var score = 0

        // 1. Resolution Base Score
        score += fmt.resolutionHeight

        // 2. HDR Bonus
        if (fmt.isHdr) {
            score += 300
        }

        // 3. FPS Bonus
        if (fmt.fps >= 50) {
            score += 100
        } else if (fmt.fps > 30) {
            score += 50
        }

        // 4. Codec Efficiency Bonus (Phase 7)
        score += fmt.codecEfficiency.scoreBonus

        // 5. Audio Availability (Combined stream bonus)
        if (fmt.hasVideo && fmt.hasAudio) {
            score += 500
        }

        // 6. Protocol Stability
        when (fmt.streamType) {
            StreamType.PROGRESSIVE, StreamType.MERGED -> score += 150
            StreamType.ADAPTIVE_HLS -> score += 100
            StreamType.ADAPTIVE_DASH -> score += 80
            StreamType.LIVE_STREAM -> score += 50
            else -> {}
        }

        // 7. Audio Quality Ranking (Phase 8)
        if (fmt.streamType == StreamType.AUDIO_ONLY) {
            score += when (fmt.audioCodecFamily) {
                "Opus" -> 150
                "AAC" -> 120
                "MP3" -> 90
                "Vorbis" -> 70
                else -> 50
            }
            score += (fmt.audioBitrateKbps.coerceAtMost(320))
        } else {
            score += (fmt.bitrateKbps / 10).coerceAtMost(200)
        }

        return fmt.copy(qualityScore = score)
    }
}
