package com.example.data

import kotlinx.coroutines.flow.Flow

class DownloadRepository(private val downloadDao: DownloadDao) {
    val allDownloads: Flow<List<DownloadEntity>> = downloadDao.getAllDownloads()

    suspend fun insertDownload(download: DownloadEntity) {
        downloadDao.insertDownload(download)
    }

    suspend fun deleteDownload(download: DownloadEntity) {
        downloadDao.deleteDownload(download)
    }

    suspend fun deleteDownloadById(id: String) {
        downloadDao.deleteDownloadById(id)
    }

    suspend fun getDownloadById(id: String): DownloadEntity? {
        return downloadDao.getDownloadById(id)
    }

    suspend fun getAllDownloadsSync(): List<DownloadEntity> {
        return downloadDao.getAllDownloadsSync()
    }

    suspend fun updateDownloadStatus(id: String, status: String, message: String) {
        downloadDao.updateDownloadStatus(id, status, message)
    }

    suspend fun deleteAllDownloads() {
        downloadDao.deleteAllDownloads()
    }
}
