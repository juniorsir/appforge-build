package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

@Composable
fun MyApplicationTheme(
    themeSettings: AppThemeSettings? = null,
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit,
) {
    val settings = themeSettings ?: AppThemeSettings(
        themeMode = if (darkTheme) AppThemeMode.OBSIDIAN else AppThemeMode.LIGHT_MODE
    )
    val sleekColors = resolveSleekColorsFromSettings(settings, darkTheme)

    val isDark = settings.themeMode != AppThemeMode.LIGHT_MODE

    val colorScheme = if (isDark) {
        darkColorScheme(
            primary = sleekColors.primary,
            secondary = sleekColors.accent,
            tertiary = sleekColors.accent,
            background = sleekColors.bg,
            surface = sleekColors.card,
            surfaceVariant = sleekColors.surface,
            onPrimary = Color.White,
            onSecondary = Color.White,
            onBackground = sleekColors.textPrimary,
            onSurface = sleekColors.textPrimary,
            onSurfaceVariant = sleekColors.textSecondary
        )
    } else {
        lightColorScheme(
            primary = sleekColors.primary,
            secondary = sleekColors.accent,
            tertiary = sleekColors.accent,
            background = sleekColors.bg,
            surface = sleekColors.card,
            surfaceVariant = sleekColors.surface,
            onPrimary = Color.White,
            onSecondary = Color.White,
            onBackground = sleekColors.textPrimary,
            onSurface = sleekColors.textPrimary,
            onSurfaceVariant = sleekColors.textSecondary
        )
    }

    MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
