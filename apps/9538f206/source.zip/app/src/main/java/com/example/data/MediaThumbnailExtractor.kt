package com.example.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import android.media.MediaMetadataRetriever
import android.os.Build
import android.util.Log
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.abs

object MediaThumbnailExtractor {
    private const val TAG = "MediaThumbnailExtractor"

    fun getOrExtractThumbnail(
        context: Context,
        localPath: String,
        mediaId: String,
        fallbackUrl: String? = null
    ): String {
        val safeId = if (mediaId.isNotBlank()) mediaId else localPath.hashCode().toString()
        val thumbsDir = File(context.cacheDir, "media_thumbnails").apply {
            if (!exists()) mkdirs()
        }
        val thumbFile = File(thumbsDir, "${safeId.hashCode()}_thumb.jpg")

        if (thumbFile.exists() && thumbFile.length() > 0) {
            return thumbFile.absolutePath
        }

        // 1. Try the original/source thumbnail from extractor metadata.
        if (!fallbackUrl.isNullOrBlank()) {
            if (fallbackUrl.startsWith("http://") || fallbackUrl.startsWith("https://")) {
                try {
                    val connection = URL(fallbackUrl).openConnection() as HttpURLConnection
                    connection.connectTimeout = 3000
                    connection.readTimeout = 3000
                    connection.doInput = true
                    connection.connect()
                    if (connection.responseCode == HttpURLConnection.HTTP_OK) {
                        connection.inputStream.use { input ->
                            val bitmap = BitmapFactory.decodeStream(input)
                            if (bitmap != null) {
                                saveBitmap(bitmap, thumbFile)
                                Log.d(TAG, "THUMBNAIL: source")
                                return thumbFile.absolutePath
                            }
                        }
                    }
                } catch (e: Exception) {
                    Log.w(TAG, "Failed downloading source thumbnail from $fallbackUrl: ${e.message}")
                }
            } else {
                val srcFile = File(fallbackUrl)
                if (srcFile.exists() && srcFile.length() > 0) {
                    try {
                        val bitmap = BitmapFactory.decodeFile(srcFile.absolutePath)
                        if (bitmap != null) {
                            saveBitmap(bitmap, thumbFile)
                            Log.d(TAG, "THUMBNAIL: source")
                            return thumbFile.absolutePath
                        }
                    } catch (e: Exception) {
                        Log.w(TAG, "Failed decoding local source thumbnail: ${e.message}")
                    }
                }
            }
        }

        // 2 & 3: Try embedded artwork, then video frame
        if (localPath.isNotBlank()) {
            val mediaFile = File(localPath)
            if (mediaFile.exists() && mediaFile.isFile) {
                var retriever: MediaMetadataRetriever? = null
                try {
                    retriever = MediaMetadataRetriever()
                    retriever.setDataSource(localPath)

                    // 2. Embedded artwork
                    val embeddedArt = retriever.embeddedPicture
                    if (embeddedArt != null && embeddedArt.isNotEmpty()) {
                        val bitmap = BitmapFactory.decodeByteArray(embeddedArt, 0, embeddedArt.size)
                        if (bitmap != null) {
                            saveBitmap(bitmap, thumbFile)
                            Log.d(TAG, "THUMBNAIL: embedded artwork")
                            return thumbFile.absolutePath
                        }
                    }

                    // 3. Generate a thumbnail locally from the actual video
                    val hasVideo = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_HAS_VIDEO)
                    if (hasVideo != null && hasVideo.equals("yes", ignoreCase = true)) {
                        val bitmap = try {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
                                retriever.getScaledFrameAtTime(
                                    1000000L, // 1 second in microseconds
                                    MediaMetadataRetriever.OPTION_CLOSEST_SYNC,
                                    640,
                                    360
                                ) ?: retriever.frameAtTime
                            } else {
                                retriever.frameAtTime
                            }
                        } catch (e: Exception) {
                            retriever.frameAtTime
                        }
                        if (bitmap != null) {
                            saveBitmap(bitmap, thumbFile)
                            Log.d(TAG, "THUMBNAIL: video frame")
                            return thumbFile.absolutePath
                        }
                    }
                } catch (e: Exception) {
                    Log.w(TAG, "MediaMetadataRetriever extraction failed for $localPath: ${e.message}")
                } finally {
                    try {
                        retriever?.release()
                    } catch (ignored: Exception) {}
                }
            }
        }

        // 4. Generate fallback gradient image
        val fallbackBitmap = createGradientFallback(safeId)
        saveBitmap(fallbackBitmap, thumbFile)
        Log.d(TAG, "THUMBNAIL: generated fallback")
        return thumbFile.absolutePath
    }

    private fun saveBitmap(bitmap: Bitmap, file: File) {
        FileOutputStream(file).use { out ->
            bitmap.compress(Bitmap.CompressFormat.JPEG, 85, out)
        }
        bitmap.recycle()
    }

    private fun createGradientFallback(seed: String): Bitmap {
        val width = 640
        val height = 360
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        val hash = abs(seed.hashCode())
        val hue1 = (hash % 360).toFloat()
        val hue2 = ((hash + 120) % 360).toFloat()

        val color1 = Color.HSVToColor(floatArrayOf(hue1, 0.7f, 0.6f))
        val color2 = Color.HSVToColor(floatArrayOf(hue2, 0.8f, 0.4f))

        val paint = Paint()
        paint.shader = LinearGradient(
            0f, 0f, width.toFloat(), height.toFloat(),
            color1, color2,
            Shader.TileMode.CLAMP
        )
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paint)

        return bitmap
    }

    /**
     * Extracts representative frames from a local video file at given percentage intervals.
     * Uses disk caching and small resolution (360x202) for smooth asynchronous loading.
     */
    fun extractFramesAtPercentages(
        context: Context,
        localPath: String,
        mediaId: String,
        percentages: List<Float>
    ): List<ExtractedFrame> {
        val safeId = if (mediaId.isNotBlank()) mediaId else localPath.hashCode().toString()
        val framesDir = File(context.cacheDir, "video_frame_thumbnails").apply {
            if (!exists()) mkdirs()
        }

        val resultList = mutableListOf<ExtractedFrame>()
        val missingPercentages = mutableListOf<Float>()

        for (pct in percentages) {
            val pctInt = (pct * 100).toInt()
            val frameFile = File(framesDir, "${safeId.hashCode()}_frame_${pctInt}.jpg")
            if (frameFile.exists() && frameFile.length() > 0) {
                resultList.add(ExtractedFrame(pct, 0L, frameFile.absolutePath))
            } else {
                missingPercentages.add(pct)
            }
        }

        if (missingPercentages.isEmpty()) {
            return resultList.sortedBy { it.percentage }
        }

        val mediaFile = File(localPath)
        if (!mediaFile.exists() || !mediaFile.isFile) {
            return resultList.sortedBy { it.percentage }
        }

        var retriever: MediaMetadataRetriever? = null
        try {
            retriever = MediaMetadataRetriever()
            retriever.setDataSource(localPath)

            val durationStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
            val durationMs = durationStr?.toLongOrNull() ?: 10000L

            for (pct in missingPercentages) {
                val pctInt = (pct * 100).toInt()
                val frameFile = File(framesDir, "${safeId.hashCode()}_frame_${pctInt}.jpg")
                val targetTimeUs = ((durationMs * 1000L * pct).toLong()).coerceAtLeast(0L)

                var bitmap: Bitmap? = null
                try {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
                        bitmap = retriever.getScaledFrameAtTime(
                            targetTimeUs,
                            MediaMetadataRetriever.OPTION_CLOSEST_SYNC,
                            360,
                            202
                        )
                    }
                    if (bitmap == null) {
                        bitmap = retriever.getFrameAtTime(targetTimeUs, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                    }
                    if (bitmap == null) {
                        bitmap = retriever.frameAtTime
                    }
                } catch (e: Exception) {
                    try {
                        // Offset retry for robustness
                        val offsetTimeUs = (targetTimeUs + 500000L).coerceAtLeast(0L)
                        bitmap = retriever.getFrameAtTime(offsetTimeUs, MediaMetadataRetriever.OPTION_CLOSEST)
                    } catch (ignored: Exception) {}
                }

                if (bitmap != null) {
                    saveBitmap(bitmap, frameFile)
                    resultList.add(ExtractedFrame(pct, targetTimeUs / 1000L, frameFile.absolutePath))
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "extractFramesAtPercentages failed for $localPath: ${e.message}")
        } finally {
            try {
                retriever?.release()
            } catch (ignored: Exception) {}
        }

        return resultList.sortedBy { it.percentage }
    }

    /**
     * Persistently saves a user-selected frame as the primary thumbnail for a media item.
     */
    fun saveCustomThumbnail(
        context: Context,
        mediaId: String,
        sourceImagePath: String
    ): String {
        val safeId = if (mediaId.isNotBlank()) mediaId else sourceImagePath.hashCode().toString()
        val thumbsDir = File(context.cacheDir, "media_thumbnails").apply {
            if (!exists()) mkdirs()
        }
        try {
            val prefix = "${safeId.hashCode()}_"
            thumbsDir.listFiles()?.forEach { file ->
                if (file.name.startsWith(prefix) && file.name.endsWith("_thumb.jpg")) {
                    file.delete()
                }
            }
        } catch (_: Exception) {}

        val thumbFile = File(thumbsDir, "${safeId.hashCode()}_${System.currentTimeMillis()}_thumb.jpg")
        val srcFile = File(sourceImagePath)
        if (srcFile.exists() && srcFile.length() > 0) {
            try {
                srcFile.copyTo(thumbFile, overwrite = true)
                return thumbFile.absolutePath
            } catch (e: Exception) {
                Log.w(TAG, "Failed copying custom thumbnail: ${e.message}")
            }
        }
        return sourceImagePath
    }
}

data class ExtractedFrame(
    val percentage: Float,
    val timestampMs: Long,
    val filePath: String
)
