package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface DownloadDao {
    @Query("SELECT * FROM downloads ORDER BY downloadedAt DESC")
    fun getAllDownloads(): Flow<List<DownloadEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDownload(download: DownloadEntity)

    @Delete
    suspend fun deleteDownload(download: DownloadEntity)

    @Query("DELETE FROM downloads WHERE id = :id")
    suspend fun deleteDownloadById(id: String)

    @Query("SELECT * FROM downloads WHERE id = :id LIMIT 1")
    suspend fun getDownloadById(id: String): DownloadEntity?

    @Query("UPDATE downloads SET title = :title, author = :author, thumbnailUrl = :thumbnailUrl WHERE id = :id")
    suspend fun updateDownloadMetadata(id: String, title: String, author: String, thumbnailUrl: String)

    @Query("UPDATE downloads SET thumbnailUrl = :thumbnailUrl WHERE id = :id")
    suspend fun updateThumbnail(id: String, thumbnailUrl: String)

    @Query("UPDATE downloads SET downloadStatus = :status, statusMessage = :message WHERE id = :id")
    suspend fun updateDownloadStatus(id: String, status: String, message: String)

    @Query("SELECT * FROM downloads")
    suspend fun getAllDownloadsSync(): List<DownloadEntity>

    @Query("UPDATE downloads SET isKept = :isKept WHERE id = :id")
    suspend fun updateKeepState(id: String, isKept: Boolean)

    @Query("UPDATE downloads SET isFavorite = :isFavorite WHERE id = :id")
    suspend fun updateFavoriteState(id: String, isFavorite: Boolean)

    @Query("UPDATE downloads SET isProtected = :isProtected WHERE id = :id")
    suspend fun updateProtectedState(id: String, isProtected: Boolean)

    @Query("DELETE FROM downloads")
    suspend fun deleteAllDownloads()
}
