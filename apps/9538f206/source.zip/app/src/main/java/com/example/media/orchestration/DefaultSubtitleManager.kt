package com.example.media.orchestration

import com.example.media.DecoderSourceType
import com.example.media.DecoderStatus
import com.example.media.DecoderSelection

class DefaultSubtitleManager : SubtitleManager {

    private val supportedTextMimes = listOf(
        androidx.media3.common.MimeTypes.APPLICATION_SUBRIP,
        androidx.media3.common.MimeTypes.TEXT_SSA,
        androidx.media3.common.MimeTypes.TEXT_VTT,
        androidx.media3.common.MimeTypes.APPLICATION_TTML,
        androidx.media3.common.MimeTypes.APPLICATION_TX3G,
        androidx.media3.common.MimeTypes.APPLICATION_CEA608,
        androidx.media3.common.MimeTypes.APPLICATION_CEA708
    )

    private val supportedBitmapMimes = listOf(
        androidx.media3.common.MimeTypes.APPLICATION_PGS,
        androidx.media3.common.MimeTypes.APPLICATION_VOBSUB,
        androidx.media3.common.MimeTypes.APPLICATION_DVBSUBS
    )

    override fun getRendererCandidates(mimeType: String): List<DecoderCandidate> {
        val candidates = mutableListOf<DecoderCandidate>()
        
        if (supportedTextMimes.contains(mimeType) || supportedBitmapMimes.contains(mimeType)) {
            candidates.add(
                DecoderCandidate(
                    name = "Media3SubtitleDecoder",
                    sourceType = DecoderSourceType.SOFTWARE,
                    mimeType = mimeType,
                    isAudio = false
                )
            )
        }
        
        return candidates
    }

    override fun selectBestRenderer(candidates: List<DecoderCandidate>): DecoderSelection {
        val available = candidates.filter { it.isAvailable }
        if (available.isEmpty()) {
            return DecoderSelection(
                mimeType = candidates.firstOrNull()?.mimeType ?: "unknown",
                decoderName = null,
                sourceType = DecoderSourceType.UNAVAILABLE,
                status = DecoderStatus.UNAVAILABLE,
                reason = "No available subtitle renderer",
                candidates = candidates
            )
        }
        val best = available.first()
        return DecoderSelection(
            mimeType = best.mimeType,
            decoderName = best.name,
            sourceType = best.sourceType,
            status = DecoderStatus.AVAILABLE,
            candidates = candidates
        )
    }
}
