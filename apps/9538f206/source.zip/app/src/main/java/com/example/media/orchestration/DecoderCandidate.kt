package com.example.media.orchestration

import com.example.media.DecoderSourceType

enum class DecoderFailureType {
    NONE,
    UNSUPPORTED_CODEC,
    UNSUPPORTED_PROFILE,
    UNSUPPORTED_LEVEL,
    UNSUPPORTED_RESOLUTION,
    UNSUPPORTED_BIT_DEPTH,
    UNSUPPORTED_CHANNEL_LAYOUT,
    DECODER_INITIALIZATION_FAILED,
    DECODER_RUNTIME_FAILED,
    SURFACE_INITIALIZATION_FAILED,
    AUDIO_OUTPUT_FAILED,
    CORRUPTED_STREAM,
    INVALID_FORMAT,
    UNKNOWN_FAILURE
}

data class DecoderCandidate(
    val name: String,
    val sourceType: DecoderSourceType,
    val mimeType: String,
    val isAudio: Boolean,
    var isAvailable: Boolean = true,
    var failureType: DecoderFailureType = DecoderFailureType.NONE,
    var failureReason: String? = null
)
