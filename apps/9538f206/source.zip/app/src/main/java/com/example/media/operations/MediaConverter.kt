package com.example.media.operations

import android.content.Context
import android.util.Log
import com.example.media.ffmpeg.FFmpegEngine
import com.example.media.ffmpeg.FFmpegProgress
import com.example.media.ffmpeg.FFmpegState
import com.example.media.probe.MediaProbeEngine
import com.example.media.storage.MediaUriResolver
import com.example.media.storage.TemporaryMediaManager
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow

object MediaConverter {
    private const val TAG = "MediaConverter"

    fun convertMedia(
        context: Context,
        request: MediaConversionRequest
    ): Flow<FFmpegProgress> = callbackFlow {
        val validation = request.validate()
        if (validation.isFailure) {
            val err = validation.exceptionOrNull() ?: IllegalArgumentException("Invalid conversion request")
            trySend(FFmpegProgress(state = FFmpegState.FAILED, error = err))
            close(err)
            return@callbackFlow
        }

        var resolvedSource: com.example.media.storage.ResolvedMediaSource? = null
        var activeSessionId: Long = 0L

        try {
            val probeResult = MediaProbeEngine.probeMedia(context, request.inputUri)
            val probeInfo = probeResult.getOrNull()
            val totalDurationMs = probeInfo?.durationMs ?: 0L

            resolvedSource = MediaUriResolver.resolveUriForFFmpeg(context, request.inputUri, preferDirectSaf = true)
            val inputPath = resolvedSource.pathOrSaf

            val argsList = mutableListOf("-i", inputPath)

            // Video encoding options
            if (request.videoCodec == "copy") {
                argsList.addAll(listOf("-c:v", "copy"))
            } else if (request.videoCodec != null) {
                argsList.addAll(listOf("-c:v", request.videoCodec))
                if (request.crf != null) {
                    argsList.addAll(listOf("-crf", request.crf.toString()))
                }
                if (request.preset != null) {
                    argsList.addAll(listOf("-preset", request.preset))
                }
                if (request.videoBitrateKbps != null) {
                    argsList.addAll(listOf("-b:v", "${request.videoBitrateKbps}k"))
                }
                if (request.frameRate != null && request.frameRate > 0) {
                    argsList.addAll(listOf("-r", request.frameRate.toString()))
                }
                if (request.targetWidth != null && request.targetHeight != null) {
                    argsList.addAll(listOf("-vf", "scale=${request.targetWidth}:${request.targetHeight}:force_original_aspect_ratio=decrease,pad=${request.targetWidth}:${request.targetHeight}:(ow-iw)/2:(oh-ih)/2"))
                } else if (request.targetWidth != null) {
                    argsList.addAll(listOf("-vf", "scale=${request.targetWidth}:-2"))
                } else if (request.targetHeight != null) {
                    argsList.addAll(listOf("-vf", "scale=-2:${request.targetHeight}"))
                }
                argsList.addAll(listOf("-pix_fmt", "yuv420p"))
            } else {
                argsList.add("-vn")
            }

            // Audio encoding options
            if (request.audioCodec == "copy") {
                argsList.addAll(listOf("-c:a", "copy"))
            } else if (request.audioCodec != null) {
                argsList.addAll(listOf("-c:a", request.audioCodec))
                if (request.audioBitrateKbps != null) {
                    argsList.addAll(listOf("-b:a", "${request.audioBitrateKbps}k"))
                }
            } else {
                argsList.add("-an")
            }

            if (request.fastStart && request.outputFile.name.endsWith(".mp4", ignoreCase = true)) {
                argsList.addAll(listOf("-movflags", "+faststart"))
            }

            argsList.addAll(listOf("-y", request.outputFile.absolutePath))

            Log.i(TAG, "Starting media conversion: ${argsList.joinToString(" ")}")

            activeSessionId = FFmpegEngine.executeAsyncWithArguments(
                arguments = argsList.toTypedArray(),
                totalDurationMs = totalDurationMs,
                onProgress = { progress ->
                    trySend(progress)
                },
                onComplete = { result ->
                    if (!result.isSuccess) {
                        trySend(
                            FFmpegProgress(
                                sessionId = result.sessionId,
                                state = FFmpegState.FAILED,
                                error = IllegalStateException(result.failStackTrace ?: result.output),
                                logOutput = result.output
                            )
                        )
                    }
                    close()
                }
            )

        } catch (e: Exception) {
            Log.e(TAG, "Conversion error: ${e.message}", e)
            trySend(
                FFmpegProgress(
                    state = FFmpegState.FAILED,
                    error = e
                )
            )
            close(e)
        }

        awaitClose {
            if (activeSessionId > 0L) {
                FFmpegEngine.cancel(activeSessionId)
            }
            if (resolvedSource?.isTemporaryFile == true) {
                TemporaryMediaManager.deleteSilently(resolvedSource?.temporaryFile)
            }
        }
    }
}
