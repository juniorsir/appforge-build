package com.example.extraction

import com.yausername.youtubedl_android.mapper.VideoFormat
import com.yausername.youtubedl_android.mapper.VideoInfo
import java.lang.reflect.Field
import java.util.concurrent.ConcurrentHashMap

/**
 * Stage 1: RawFormatCollector
 * Safely extracts raw format fields from VideoInfo format instances without throwing or aborting.
 */
object RawFormatCollector {

    private val fieldCache = ConcurrentHashMap<Pair<Class<*>, String>, Field?>()

    private fun getCachedField(clazz: Class<*>, fieldName: String): Field? {
        val key = Pair(clazz, fieldName)
        return fieldCache.getOrPut(key) {
            try {
                clazz.getDeclaredField(fieldName).apply { isAccessible = true }
            } catch (e: Exception) {
                null
            }
        }
    }

    private fun getStringProperty(obj: Any, fieldName: String): String {
        return try {
            val field = getCachedField(obj.javaClass, fieldName)
            field?.get(obj) as? String ?: ""
        } catch (e: Exception) {
            ""
        }
    }

    private fun getLongProperty(obj: Any, fieldName: String): Long {
        return try {
            val field = getCachedField(obj.javaClass, fieldName)
            when (val value = field?.get(obj)) {
                is Number -> value.toLong()
                is String -> value.toLongOrNull() ?: 0L
                else -> 0L
            }
        } catch (e: Exception) {
            0L
        }
    }

    private fun getDoubleProperty(obj: Any, fieldName: String): Double {
        return try {
            val field = getCachedField(obj.javaClass, fieldName)
            when (val value = field?.get(obj)) {
                is Number -> value.toDouble()
                is String -> value.toDoubleOrNull() ?: 0.0
                else -> 0.0
            }
        } catch (e: Exception) {
            0.0
        }
    }

    private fun getIntProperty(obj: Any, fieldName: String): Int {
        return try {
            val field = getCachedField(obj.javaClass, fieldName)
            when (val value = field?.get(obj)) {
                is Number -> value.toInt()
                is String -> value.toIntOrNull() ?: 0
                else -> 0
            }
        } catch (e: Exception) {
            0
        }
    }

    /**
     * Collects raw formats safely from VideoInfo.
     */
    fun collectRawFormats(videoInfo: VideoInfo): List<RawFormat> {
        val formats = videoInfo.formats ?: return emptyList()
        val rawList = mutableListOf<RawFormat>()

        // Also check if videoInfo has a top-level manifestUrl
        val topManifestUrl = getStringProperty(videoInfo, "manifestUrl")
            .ifBlank { getStringProperty(videoInfo, "manifest_url") }

        formats.forEachIndexed { index, format ->
            try {
                val rawFormat = extractSingleFormat(format, index, topManifestUrl)
                if (rawFormat != null) {
                    rawList.add(rawFormat)
                }
            } catch (e: Exception) {
                // Continue parsing remaining formats safely (Phase 2)
            }
        }
        return rawList
    }

    private fun extractSingleFormat(
        format: VideoFormat,
        index: Int,
        topManifestUrl: String
    ): RawFormat? {
        val url = format.url ?: getStringProperty(format, "url")
        if (url.isBlank()) return null

        val formatIdStr = format.formatId ?: getStringProperty(format, "format_id").ifBlank { "fmt_$index" }
        val ext = format.ext ?: getStringProperty(format, "ext").ifBlank { "mp4" }
        val formatNote = format.formatNote ?: getStringProperty(format, "format_note")
        
        val vcodec = format.vcodec ?: getStringProperty(format, "vcodec")
        val acodec = format.acodec ?: getStringProperty(format, "acodec")
        
        val height = if (format.height > 0) format.height else getIntProperty(format, "height")
        val width = if (format.width > 0) format.width else getIntProperty(format, "width")
        val fps = if (format.fps > 0) format.fps else getIntProperty(format, "fps")

        var filesize = getLongProperty(format, "fileSize")
        if (filesize <= 0L) {
            filesize = getLongProperty(format, "filesize")
        }
        var filesizeApprox = getLongProperty(format, "filesizeApprox")
        if (filesizeApprox <= 0L) {
            filesizeApprox = getLongProperty(format, "filesize_approx")
        }

        val vbr = getDoubleProperty(format, "vbr")
        val abr = if (format.abr > 0) format.abr.toDouble() else getDoubleProperty(format, "abr")
        val tbr = getDoubleProperty(format, "tbr").let { if (it > 0) it else (vbr + abr) }
        val asr = if (format.asr > 0) format.asr else getIntProperty(format, "asr")

        val dynamicRange = getStringProperty(format, "dynamicRange")
            .ifBlank { getStringProperty(format, "dynamic_range") }
        val language = getStringProperty(format, "language")
            .ifBlank { getStringProperty(format, "lang") }
        val protocol = getStringProperty(format, "protocol")
        
        val fmtManifestUrl = getStringProperty(format, "manifestUrl")
            .ifBlank { getStringProperty(format, "manifest_url") }
            .ifBlank { topManifestUrl }

        val sourcePreference = getIntProperty(format, "sourcePreference")
            .let { if (it != 0) it else getIntProperty(format, "source_preference") }

        return RawFormat(
            formatIdStr = formatIdStr,
            ext = ext,
            formatNote = formatNote,
            url = url,
            vcodec = vcodec,
            acodec = acodec,
            height = height,
            width = width,
            fps = fps,
            filesize = filesize,
            filesizeApprox = filesizeApprox,
            tbr = tbr,
            vbr = vbr,
            abr = abr,
            asr = asr,
            dynamicRange = dynamicRange,
            language = language,
            protocol = protocol,
            manifestUrl = fmtManifestUrl,
            sourcePreference = sourcePreference,
            rawIndex = index
        )
    }
}
