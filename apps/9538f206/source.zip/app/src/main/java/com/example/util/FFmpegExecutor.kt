package com.example.util

import android.content.Context
import android.util.Log
import com.example.DownloadManager
import com.yausername.ffmpeg.FFmpeg
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader

/**
 * Production-grade FFmpeg Execution Utility.
 * Resolves native ABI-packaged FFmpeg executables extracted by YoutubeDL/FFmpeg JNI initializer
 * and executes command arguments via ProcessBuilder with full diagnostic logs.
 */
object FFmpegExecutor {
    private const val TAG = "FFmpegExecutor"

    /**
     * Resolves the location of the extracted native FFmpeg binary executable file.
     */
    fun getFFmpegExecutable(context: Context): File? {
        val appContext = context.applicationContext
        try {
            FFmpeg.getInstance().init(appContext)
        } catch (e: Exception) {
            Log.w(TAG, "FFmpeg init warning: ${e.localizedMessage}")
        }

        val possibleLocations = listOf(
            File(appContext.noBackupFilesDir, "youtubedl-android/ffmpeg"),
            File(appContext.filesDir, "youtubedl-android/ffmpeg"),
            File(appContext.noBackupFilesDir, "ffmpeg"),
            File(appContext.filesDir, "ffmpeg"),
            File(appContext.codeCacheDir, "ffmpeg"),
            File(appContext.cacheDir, "ffmpeg")
        )

        for (loc in possibleLocations) {
            if (loc.exists()) {
                if (loc.isFile && (loc.canExecute() || loc.setExecutable(true))) {
                    return loc
                } else if (loc.isDirectory) {
                    val binary = loc.listFiles()?.firstOrNull { 
                        it.isFile && it.name.contains("ffmpeg", ignoreCase = true) 
                    }
                    if (binary != null && (binary.canExecute() || binary.setExecutable(true))) {
                        return binary
                    }
                }
            }
        }
        return null
    }

    /**
     * Executes an FFmpeg command using the native binary executable or reflection/process fallback,
     * with real-time stdout time parsing for progress callbacks and process cancellation handle.
     */
    fun executeWithProgress(
        context: Context,
        args: Array<String>,
        onProgress: ((currentMs: Long) -> Unit)? = null,
        onProcessStarted: ((Process) -> Unit)? = null
    ): Boolean {
        val appContext = context.applicationContext
        val ffmpegClass = try { Class.forName("com.yausername.ffmpeg.FFmpeg") } catch (_: Exception) { null }
        val ffmpegExecutable = getFFmpegExecutable(appContext)

        val logMsg = StringBuilder().apply {
            appendLine("🔍 [FFmpeg Diagnostic Log]")
            appendLine("  • Detected Class: ${ffmpegClass?.name ?: "Unknown"}")
            appendLine("  • Generated Command: ${args.joinToString(" ")}")
            appendLine("  • Executable: ${ffmpegExecutable?.absolutePath ?: "Not Found"}")
        }.toString()

        Log.d(TAG, logMsg)
        DownloadManager.addLog("🔍 [FFmpeg Diagnostic] Executable: ${ffmpegExecutable?.name ?: "None"}, Command: ${args.joinToString(" ")}")

        if (ffmpegExecutable != null && ffmpegExecutable.exists()) {
            try {
                ffmpegExecutable.setExecutable(true)
                val fullCmd = ArrayList<String>().apply {
                    add(ffmpegExecutable.absolutePath)
                    addAll(args)
                }

                val pb = ProcessBuilder(fullCmd)
                pb.directory(ffmpegExecutable.parentFile)
                pb.redirectErrorStream(true)

                val process = pb.start()
                onProcessStarted?.invoke(process)

                val reader = BufferedReader(InputStreamReader(process.inputStream))
                var line: String?
                val timeRegex = Regex("""time=(\d+):(\d+):(\d+(?:\.\d+)?)""")

                while (reader.readLine().also { line = it } != null) {
                    val l = line ?: continue
                    Log.v(TAG, "FFmpeg stdout: $l")
                    if (onProgress != null) {
                        timeRegex.find(l)?.let { match ->
                            val (h, m, s) = match.destructured
                            val sec = s.toDoubleOrNull() ?: 0.0
                            val totalMs = (((h.toLongOrNull() ?: 0L) * 3600) + ((m.toLongOrNull() ?: 0L) * 60) + sec * 1000.0).toLong()
                            onProgress(totalMs)
                        }
                    }
                }
                reader.close()

                val exitCode = process.waitFor()
                DownloadManager.addLog("⚡ Native FFmpeg Process exited with code: $exitCode")
                if (exitCode == 0) return true
            } catch (procEx: Exception) {
                Log.e(TAG, "Native ProcessBuilder execution error: ${procEx.localizedMessage}", procEx)
                DownloadManager.addLog("⚠️ ProcessBuilder execution error: ${procEx.localizedMessage}")
            }
        }

        return execute(context, args)
    }

    /**
     * Executes an FFmpeg command using the native binary executable or reflection/process fallback.
     */
    fun execute(context: Context, args: Array<String>): Boolean {
        val appContext = context.applicationContext
        val ffmpegClass = try { Class.forName("com.yausername.ffmpeg.FFmpeg") } catch (_: Exception) { null }
        val ffmpegExecutable = getFFmpegExecutable(appContext)

        // Diagnostic logging required by task specs
        val logMsg = StringBuilder().apply {
            appendLine("🔍 [FFmpeg Diagnostic Log]")
            appendLine("  • Detected Class: ${ffmpegClass?.name ?: "Unknown"}")
            appendLine("  • Package Name: ${ffmpegClass?.`package`?.name ?: "com.yausername.ffmpeg"}")
            appendLine("  • Method Signature: N/A (Native Executable ProcessBuilder)")
            appendLine("  • Parameter Types: [Array<String>]")
            appendLine("  • Generated Command: ${args.joinToString(" ")}")
            appendLine("  • Command Length: ${args.size}")
            appendLine("  • Reflection Target: ${ffmpegClass?.name ?: "N/A"}")
            appendLine("  • Invocation Mode: Native ProcessBuilder Executable (${ffmpegExecutable?.absolutePath ?: "Not Found"})")
        }.toString()

        Log.d(TAG, logMsg)
        DownloadManager.addLog("🔍 [FFmpeg Diagnostic] Executable: ${ffmpegExecutable?.name ?: "None"}, Command: ${args.joinToString(" ")}")

        // Execution Method 1: Direct Executable via ProcessBuilder
        if (ffmpegExecutable != null && ffmpegExecutable.exists()) {
            try {
                ffmpegExecutable.setExecutable(true)
                val fullCmd = ArrayList<String>().apply {
                    add(ffmpegExecutable.absolutePath)
                    addAll(args)
                }

                val pb = ProcessBuilder(fullCmd)
                pb.directory(ffmpegExecutable.parentFile)
                pb.redirectErrorStream(true)

                val process = pb.start()
                val reader = BufferedReader(InputStreamReader(process.inputStream))
                var line: String?
                while (reader.readLine().also { line = it } != null) {
                    Log.v(TAG, "FFmpeg stdout: $line")
                }
                reader.close()

                val exitCode = process.waitFor()
                DownloadManager.addLog("⚡ Native FFmpeg Process exited with code: $exitCode")
                if (exitCode == 0) return true
            } catch (procEx: Exception) {
                Log.e(TAG, "Native ProcessBuilder execution error: ${procEx.localizedMessage}", procEx)
                DownloadManager.addLog("⚠️ ProcessBuilder execution error: ${procEx.localizedMessage}")
            }
        }

        // Execution Method 2: Reflection fallback for variants that define an execute method
        if (ffmpegClass != null) {
            try {
                val getInstanceMethod = ffmpegClass.getMethod("getInstance")
                val ffmpegInstance = getInstanceMethod.invoke(null)
                val executeMethod = ffmpegClass.methods.firstOrNull { m ->
                    m.name == "execute" && m.parameterTypes.size == 1 && m.parameterTypes[0] == Array<String>::class.java
                }
                if (executeMethod != null) {
                    executeMethod.isAccessible = true
                    executeMethod.invoke(ffmpegInstance, arrayOf<Any>(args))
                    DownloadManager.addLog("⚡ Reflection execute method invoked successfully.")
                    return true
                }
            } catch (reflEx: Exception) {
                Log.w(TAG, "Reflection invocation fallback failed: ${reflEx.localizedMessage}")
            }
        }

        return false
    }
}
