package com.example.extraction

/**
 * Stage 2: FormatValidator
 * Rejects invalid, non-playable, or unsupported formats according to Phase 3 criteria.
 */
object FormatValidator {

    private val REJECTED_EXTENSIONS = setOf(
        "mhtml", "jpg", "jpeg", "png", "webp", "gif", "vtt", "srt", "ass", "json", "xml"
    )

    private val REJECTED_PROTOCOLS = setOf(
        "rtsp", "rtmp", "ftp", "chrome", "data", "file"
    )

    /**
     * Returns true if raw format meets valid playback/download requirements.
     */
    fun isValidFormat(raw: RawFormat): Boolean {
        // 1. Verify URL is not blank
        val url = raw.url.trim()
        if (url.isBlank()) return false

        // 2. Reject unsupported protocols
        val protocol = raw.protocol.lowercase()
        if (REJECTED_PROTOCOLS.any { protocol.startsWith(it) }) return false

        // 3. Verify formatId exists
        if (raw.formatIdStr.isBlank()) return false

        // 4. Reject mhtml, storyboards, thumbnails, images, subtitles, metadata
        val ext = raw.ext.lowercase()
        if (REJECTED_EXTENSIONS.contains(ext)) return false

        val formatId = raw.formatIdStr.lowercase()
        if (formatId.startsWith("sb") || formatId.contains("storyboard") || formatId.contains("mhtml")) {
            return false
        }

        val note = raw.formatNote.lowercase()
        if (note.contains("storyboard") || note.contains("mhtml") || note.contains("image")) {
            return false
        }

        // 5. Verify vcodec and acodec aren't both "none" or null while having no video/audio indicators
        val vcodec = raw.vcodec.lowercase()
        val acodec = raw.acodec.lowercase()
        if (vcodec == "none" && acodec == "none") {
            return false
        }

        return true
    }
}
