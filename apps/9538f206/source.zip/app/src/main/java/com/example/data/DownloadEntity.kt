package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "downloads")
data class DownloadEntity(
    @PrimaryKey val id: String, // videoId
    val title: String,
    val author: String,
    val durationText: String,
    val thumbnailUrl: String,
    val localPath: String,
    val fileSize: Long,
    val downloadedAt: Long = System.currentTimeMillis(),
    val originalUrl: String = "",
    val formatId: String = "",
    val formatQuality: String = "",
    val formatExt: String = "",
    val expectedSize: Long = 0L,
    val downloadStatus: String = "COMPLETED", // COMPLETED, INCOMPLETE, CORRUPTED, RECOVERABLE, FAILED, QUEUED, DOWNLOADING, PAUSED
    val statusMessage: String = "",
    val isAudioOnly: Boolean = false,
    val isFavorite: Boolean = false,
    val isKept: Boolean = false,
    val isProtected: Boolean = false
)
