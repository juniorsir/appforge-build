package com.example.backup.cloud

import com.example.data.DownloadEntity
import com.example.data.MediaMarkerEntity
import com.example.data.PlaybackProgressEntity
import com.example.ui.Playlist
import org.json.JSONArray
import org.json.JSONObject

enum class BackupType {
    LIBRARY_ONLY,
    FULL,
    SETTINGS_ONLY
}

enum class AutoBackupFrequency {
    OFF,
    DAILY,
    WEEKLY,
    MONTHLY
}

data class CloudBackupSettings(
    val includeDownloadedMedia: Boolean = false,
    val wifiOnly: Boolean = true,
    val chargingOnly: Boolean = false,
    val autoBackupFrequency: AutoBackupFrequency = AutoBackupFrequency.OFF,
    val lastBackupTime: String = "Never"
)

data class PreferencesBackupItem(
    val autoCleanPeriod: String = "DAYS_30",
    val keepFavorites: Boolean = true,
    val keepPlaylistItems: Boolean = true,
    val keepMarkedItems: Boolean = true,
    val onlyCleanWhenStorageLow: Boolean = false
) {
    fun toJson(): JSONObject {
        return JSONObject().apply {
            put("autoCleanPeriod", autoCleanPeriod)
            put("keepFavorites", keepFavorites)
            put("keepPlaylistItems", keepPlaylistItems)
            put("keepMarkedItems", keepMarkedItems)
            put("onlyCleanWhenStorageLow", onlyCleanWhenStorageLow)
        }
    }

    companion object {
        fun fromJson(json: JSONObject): PreferencesBackupItem {
            return PreferencesBackupItem(
                autoCleanPeriod = json.optString("autoCleanPeriod", "DAYS_30"),
                keepFavorites = json.optBoolean("keepFavorites", true),
                keepPlaylistItems = json.optBoolean("keepPlaylistItems", true),
                keepMarkedItems = json.optBoolean("keepMarkedItems", true),
                onlyCleanWhenStorageLow = json.optBoolean("onlyCleanWhenStorageLow", false)
            )
        }
    }
}

data class PlaylistBackupItem(
    val id: String = "",
    val name: String = "",
    val mediaIds: List<String> = emptyList()
) {
    fun toJson(): JSONObject {
        return JSONObject().apply {
            put("id", id)
            put("name", name)
            put("mediaIds", JSONArray(mediaIds))
        }
    }

    companion object {
        fun fromJson(json: JSONObject): PlaylistBackupItem {
            val arr = json.optJSONArray("mediaIds") ?: JSONArray()
            val ids = mutableListOf<String>()
            for (i in 0 until arr.length()) {
                ids.add(arr.optString(i))
            }
            return PlaylistBackupItem(
                id = json.optString("id"),
                name = json.optString("name"),
                mediaIds = ids
            )
        }
    }
}

data class MediaBackupItem(
    val id: String = "",
    val title: String = "",
    val author: String = "",
    val durationText: String = "",
    val isFavorite: Boolean = false,
    val isKept: Boolean = false
) {
    fun toJson(): JSONObject {
        return JSONObject().apply {
            put("id", id)
            put("title", title)
            put("author", author)
            put("durationText", durationText)
            put("isFavorite", isFavorite)
            put("isKept", isKept)
        }
    }

    companion object {
        fun fromJson(json: JSONObject): MediaBackupItem {
            return MediaBackupItem(
                id = json.optString("id"),
                title = json.optString("title"),
                author = json.optString("author"),
                durationText = json.optString("durationText"),
                isFavorite = json.optBoolean("isFavorite", false),
                isKept = json.optBoolean("isKept", false)
            )
        }
    }
}

data class PlaybackPositionBackupItem(
    val mediaId: String = "",
    val lastPositionMs: Long = 0L
) {
    fun toJson(): JSONObject {
        return JSONObject().apply {
            put("mediaId", mediaId)
            put("lastPositionMs", lastPositionMs)
        }
    }

    companion object {
        fun fromJson(json: JSONObject): PlaybackPositionBackupItem {
            return PlaybackPositionBackupItem(
                mediaId = json.optString("mediaId"),
                lastPositionMs = json.optLong("lastPositionMs", 0L)
            )
        }
    }
}

data class MarkerBackupItem(
    val mediaId: String = "",
    val positionMs: Long = 0L,
    val note: String = ""
) {
    fun toJson(): JSONObject {
        return JSONObject().apply {
            put("mediaId", mediaId)
            put("positionMs", positionMs)
            put("note", note)
        }
    }

    companion object {
        fun fromJson(json: JSONObject): MarkerBackupItem {
            return MarkerBackupItem(
                mediaId = json.optString("mediaId"),
                positionMs = json.optLong("positionMs", 0L),
                note = json.optString("note")
            )
        }
    }
}

data class CloudBackupManifest(
    val version: Int = 1,
    val backupType: BackupType = BackupType.FULL,
    val playlists: List<PlaylistBackupItem> = emptyList(),
    val media: List<MediaBackupItem> = emptyList(),
    val playbackPositions: List<PlaybackPositionBackupItem> = emptyList(),
    val markers: List<MarkerBackupItem> = emptyList(),
    val preferences: PreferencesBackupItem? = null
) {
    fun toJsonString(): String {
        val root = JSONObject().apply {
            put("version", version)
            put("backupType", backupType.name)
            put("playlists", JSONArray().apply { playlists.forEach { put(it.toJson()) } })
            put("media", JSONArray().apply { media.forEach { put(it.toJson()) } })
            put("playbackPositions", JSONArray().apply { playbackPositions.forEach { put(it.toJson()) } })
            put("markers", JSONArray().apply { markers.forEach { put(it.toJson()) } })
            preferences?.let { put("preferences", it.toJson()) }
        }
        return root.toString(2)
    }

    companion object {
        fun create(
            backupType: BackupType = BackupType.FULL,
            playlists: List<Playlist> = emptyList(),
            downloads: List<DownloadEntity> = emptyList(),
            playbackProgress: List<PlaybackProgressEntity> = emptyList(),
            markers: List<MediaMarkerEntity> = emptyList(),
            preferences: PreferencesBackupItem? = null
        ): CloudBackupManifest {
            return CloudBackupManifest(
                version = 1,
                backupType = backupType,
                playlists = playlists.map {
                    PlaylistBackupItem(
                        id = it.id,
                        name = it.name,
                        mediaIds = it.mediaIds
                    )
                },
                media = downloads.map {
                    MediaBackupItem(
                        id = it.id,
                        title = it.title,
                        author = it.author,
                        durationText = it.durationText,
                        isFavorite = it.isFavorite,
                        isKept = it.isKept
                    )
                },
                playbackPositions = playbackProgress.map {
                    PlaybackPositionBackupItem(
                        mediaId = it.mediaId,
                        lastPositionMs = it.lastPositionMs
                    )
                },
                markers = markers.map {
                    MarkerBackupItem(
                        mediaId = it.mediaId,
                        positionMs = it.positionMs,
                        note = it.note
                    )
                },
                preferences = preferences
            )
        }

        fun parseAndValidate(json: String): CloudBackupManifest {
            val root = JSONObject(json)
            val ver = root.optInt("version", 1)
            val typeStr = root.optString("backupType", BackupType.FULL.name)
            val backupType = try {
                BackupType.valueOf(typeStr)
            } catch (_: Exception) {
                BackupType.FULL
            }

            val playlistsArr = root.optJSONArray("playlists") ?: JSONArray()
            val playlistsList = mutableListOf<PlaylistBackupItem>()
            for (i in 0 until playlistsArr.length()) {
                val obj = playlistsArr.optJSONObject(i) ?: continue
                playlistsList.add(PlaylistBackupItem.fromJson(obj))
            }

            val mediaArr = root.optJSONArray("media") ?: JSONArray()
            val mediaList = mutableListOf<MediaBackupItem>()
            for (i in 0 until mediaArr.length()) {
                val obj = mediaArr.optJSONObject(i) ?: continue
                mediaList.add(MediaBackupItem.fromJson(obj))
            }

            val posArr = root.optJSONArray("playbackPositions") ?: JSONArray()
            val posList = mutableListOf<PlaybackPositionBackupItem>()
            for (i in 0 until posArr.length()) {
                val obj = posArr.optJSONObject(i) ?: continue
                posList.add(PlaybackPositionBackupItem.fromJson(obj))
            }

            val markersArr = root.optJSONArray("markers") ?: JSONArray()
            val markersList = mutableListOf<MarkerBackupItem>()
            for (i in 0 until markersArr.length()) {
                val obj = markersArr.optJSONObject(i) ?: continue
                markersList.add(MarkerBackupItem.fromJson(obj))
            }

            val prefObj = root.optJSONObject("preferences")
            val pref = prefObj?.let { PreferencesBackupItem.fromJson(it) }

            return CloudBackupManifest(
                version = ver,
                backupType = backupType,
                playlists = playlistsList,
                media = mediaList,
                playbackPositions = posList,
                markers = markersList,
                preferences = pref
            )
        }
    }
}
