package com.example.media

import android.content.Context
import android.content.Intent
import android.os.Build
import com.example.data.DownloadEntity
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

object BackgroundPlaybackManager {
    private val _isBackgroundActive = MutableStateFlow(false)
    val isBackgroundActive = _isBackgroundActive.asStateFlow()

    private val _currentMedia = MutableStateFlow<DownloadEntity?>(null)
    val currentMedia = _currentMedia.asStateFlow()

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying = _isPlaying.asStateFlow()

    private val _currentPositionMs = MutableStateFlow(0L)
    val currentPositionMs = _currentPositionMs.asStateFlow()

    private val _durationMs = MutableStateFlow(0L)
    val durationMs = _durationMs.asStateFlow()

    private val _playbackSpeed = MutableStateFlow(1.0f)
    val playbackSpeed = _playbackSpeed.asStateFlow()

    private val _isBuffering = MutableStateFlow(false)
    val isBuffering = _isBuffering.asStateFlow()

    private val _sleepTimerMinutes = MutableStateFlow(0)
    val sleepTimerMinutes = _sleepTimerMinutes.asStateFlow()

    private val _sleepSecondsRemaining = MutableStateFlow(0)
    val sleepSecondsRemaining = _sleepSecondsRemaining.asStateFlow()

    // Internal listener reference to active service
    var serviceInterface: ServiceControls? = null

    interface ServiceControls {
        fun pause()
        fun resume()
        fun seekTo(positionMs: Long)
        fun setSpeed(speed: Float)
        fun stop()
    }

    fun updateState(
        isActive: Boolean,
        media: DownloadEntity?,
        isPlaying: Boolean,
        positionMs: Long,
        durationMs: Long,
        isBuffering: Boolean = false
    ) {
        _isBackgroundActive.value = isActive
        _currentMedia.value = media
        _isPlaying.value = isPlaying
        _currentPositionMs.value = positionMs
        _durationMs.value = durationMs
        _isBuffering.value = isBuffering
    }

    fun updatePosition(posMs: Long) {
        _currentPositionMs.value = posMs
    }

    fun updateDuration(duration: Long) {
        _durationMs.value = duration
    }

    fun updatePlayingState(playing: Boolean) {
        _isPlaying.value = playing
    }

    fun updateSleepTimerState(minutes: Int, remainingSecs: Int) {
        _sleepTimerMinutes.value = minutes
        _sleepSecondsRemaining.value = remainingSecs
    }

    fun setSleepTimer(context: Context, minutes: Int) {
        _sleepTimerMinutes.value = minutes
        _sleepSecondsRemaining.value = minutes * 60
        val intent = Intent(context, BackgroundAudioPlayerService::class.java).apply {
            action = BackgroundAudioPlayerService.ACTION_SET_SLEEP_TIMER
            putExtra(BackgroundAudioPlayerService.EXTRA_SLEEP_MINUTES, minutes)
        }
        try {
            context.startService(intent)
        } catch (e: Throwable) {
            android.util.Log.w("BackgroundPlayback", "Failed to send sleep timer to service: ${e.message}")
        }
    }

    fun startBackgroundPlayback(
        context: Context,
        media: DownloadEntity,
        startPositionMs: Long = 0L,
        speed: Float = 1.0f
    ) {
        _currentMedia.value = media
        _currentPositionMs.value = startPositionMs
        _playbackSpeed.value = speed
        _isBackgroundActive.value = true
        _isPlaying.value = true

        val intent = Intent(context, BackgroundAudioPlayerService::class.java).apply {
            action = BackgroundAudioPlayerService.ACTION_START
            putExtra(BackgroundAudioPlayerService.EXTRA_MEDIA_ID, media.id)
            putExtra(BackgroundAudioPlayerService.EXTRA_MEDIA_TITLE, media.title)
            putExtra(BackgroundAudioPlayerService.EXTRA_MEDIA_AUTHOR, media.author)
            putExtra(BackgroundAudioPlayerService.EXTRA_MEDIA_PATH, media.localPath)
            putExtra(BackgroundAudioPlayerService.EXTRA_MEDIA_THUMB, media.thumbnailUrl)
            putExtra(BackgroundAudioPlayerService.EXTRA_MEDIA_DURATION, media.durationText)
            putExtra(BackgroundAudioPlayerService.EXTRA_START_POSITION, startPositionMs)
            putExtra(BackgroundAudioPlayerService.EXTRA_PLAYBACK_SPEED, speed)
        }

        com.example.util.DeviceCompatHelper.startForegroundServiceCompat(context, intent)
    }

    fun togglePlayPause() {
        if (_isPlaying.value) {
            pause()
        } else {
            resume()
        }
    }

    fun pause() {
        serviceInterface?.pause() ?: run {
            _isPlaying.value = false
        }
    }

    fun resume() {
        serviceInterface?.resume() ?: run {
            _isPlaying.value = true
        }
    }

    fun seekTo(positionMs: Long) {
        _currentPositionMs.value = positionMs
        serviceInterface?.seekTo(positionMs)
    }

    fun seekBy(deltaMs: Long) {
        val newPos = (_currentPositionMs.value + deltaMs).coerceIn(0L, _durationMs.value.coerceAtLeast(0L))
        seekTo(newPos)
    }

    fun setSpeed(speed: Float) {
        _playbackSpeed.value = speed
        serviceInterface?.setSpeed(speed)
    }

    fun stop(context: Context) {
        _isBackgroundActive.value = false
        _isPlaying.value = false
        _currentMedia.value = null
        _currentPositionMs.value = 0L
        _durationMs.value = 0L

        serviceInterface?.stop() ?: run {
            val intent = Intent(context, BackgroundAudioPlayerService::class.java).apply {
                action = BackgroundAudioPlayerService.ACTION_STOP
            }
            context.startService(intent)
        }
    }
}
