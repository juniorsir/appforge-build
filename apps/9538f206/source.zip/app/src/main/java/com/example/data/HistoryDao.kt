package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface HistoryDao {
    // Search history queries
    @Query("SELECT * FROM search_history ORDER BY searchedAt DESC LIMIT 30")
    fun getSearchHistory(): Flow<List<SearchHistoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSearch(search: SearchHistoryEntity)

    @Query("DELETE FROM search_history WHERE `query` = :query")
    suspend fun deleteSearchByQuery(query: String)

    @Query("DELETE FROM search_history")
    suspend fun clearSearchHistory()

    // Browsing/Watch history queries
    @Query("SELECT * FROM browsing_history ORDER BY browsedAt DESC LIMIT 30")
    fun getBrowsingHistory(): Flow<List<BrowsingHistoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBrowsingRecord(record: BrowsingHistoryEntity)

    @Query("DELETE FROM browsing_history WHERE id = :id")
    suspend fun deleteBrowsingRecordById(id: String)

    @Query("DELETE FROM browsing_history")
    suspend fun clearBrowsingHistory()
}
