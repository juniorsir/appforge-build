package com.example.media

import android.media.MediaCodecInfo
import android.media.MediaCodecList
import android.os.Build

object DecoderCapabilityManager {

    private const val TAG = "DecoderCapabilityManager"

    fun getSystemDecoders(): List<CodecCapabilitiesInfo> {
        val result = mutableListOf<CodecCapabilitiesInfo>()
        try {
            val codecList = MediaCodecList(MediaCodecList.ALL_CODECS)
            val infos = codecList.codecInfos ?: emptyArray()
            for (info in infos) {
                if (info == null || info.isEncoder) continue
                val isSw = isSoftwareDecoder(info)
                val isHw = isHardwareDecoder(info)
                val classification = when {
                    isHw -> DecoderClassification.HARDWARE
                    isSw -> DecoderClassification.SOFTWARE
                    else -> DecoderClassification.UNKNOWN
                }

                val supportedTypes = info.supportedTypes ?: emptyArray()
                for (mime in supportedTypes) {
                    if (mime == null) continue
                    var maxW = 0
                    var maxH = 0
                    var maxFps = 0
                    var maxBitrate = 0
                    var maxChannels = 0
                    var maxSampleRate = 0
                    val profileList = mutableListOf<String>()

                    try {
                        val caps = info.getCapabilitiesForType(mime)
                        caps?.profileLevels?.forEach { pl ->
                            if (pl != null) {
                                profileList.add("profile:${pl.profile}/level:${pl.level}")
                            }
                        }

                        val vc = caps?.videoCapabilities
                        if (vc != null) {
                            maxW = vc.supportedWidths?.upper ?: 0
                            maxH = vc.supportedHeights?.upper ?: 0
                            maxFps = vc.supportedFrameRates?.upper?.toInt() ?: 0
                            maxBitrate = vc.bitrateRange?.upper ?: 0
                        }

                        val ac = caps?.audioCapabilities
                        if (ac != null) {
                            maxChannels = ac.maxInputChannelCount
                            maxBitrate = ac.bitrateRange?.upper ?: 0
                            val sr = ac.supportedSampleRates
                            if (sr != null && sr.isNotEmpty()) {
                                maxSampleRate = sr.maxOrNull() ?: 0
                            }
                        }
                    } catch (_: Exception) {}

                    result.add(
                        CodecCapabilitiesInfo(
                            name = info.name ?: "UnknownDecoder",
                            mimeType = mime,
                            isEncoder = false,
                            classification = classification,
                            maxSupportedWidth = maxW,
                            maxSupportedHeight = maxH,
                            maxSupportedFrameRate = maxFps,
                            maxSupportedBitrate = maxBitrate,
                            maxSupportedChannels = maxChannels,
                            maxSupportedSampleRate = maxSampleRate,
                            profiles = profileList
                        )
                    )
                }
            }
        } catch (_: Throwable) {}
        return result
    }

    private fun isSoftwareDecoder(info: MediaCodecInfo): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            if (info.isSoftwareOnly) return true
        }
        val name = info.name.lowercase()
        return name.contains("omx.google.") ||
                name.contains("omx.ffmpeg.") ||
                name.contains("c2.android.") ||
                name.contains(".sw.") ||
                name.startsWith("sw") ||
                name.contains("google")
    }

    private fun isHardwareDecoder(info: MediaCodecInfo): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            if (info.isHardwareAccelerated) return true
        }
        val name = info.name.lowercase()
        if (isSoftwareDecoder(info)) return false

        return name.startsWith("omx.qcom.") ||
                name.startsWith("omx.exynos.") ||
                name.startsWith("omx.mtk.") ||
                name.startsWith("omx.intel.") ||
                name.startsWith("omx.nvidia.") ||
                name.startsWith("c2.qcom.") ||
                name.startsWith("c2.exynos.") ||
                name.startsWith("c2.mediatek.") ||
                name.startsWith("c2.mstar.") ||
                name.startsWith("c2.hisilicon.")
    }

    fun checkCodecSupport(mimeType: String): CodecSupportStatus {
        val allDecoders = getSystemDecoders().filter { it.mimeType.equals(mimeType, ignoreCase = true) }
        val hwDecoders = allDecoders.filter { it.classification == DecoderClassification.HARDWARE }.map { it.name }.distinct()
        val swDecoders = allDecoders.filter { it.classification == DecoderClassification.SOFTWARE }.map { it.name }.distinct()
        
        var extAvailable = false
        val extDecoders = mutableListOf<String>()
        try {
            if (androidx.media3.decoder.ffmpeg.FfmpegLibrary.isAvailable() && 
                androidx.media3.decoder.ffmpeg.FfmpegLibrary.supportsFormat(mimeType)) {
                extAvailable = true
                if (mimeType.startsWith("video/")) {
                    extDecoders.add("FFmpegVideoRenderer")
                } else {
                    extDecoders.add("FFmpegAudioRenderer")
                }
            }
        } catch (e: Throwable) {
            // Ignored if library missing
        }

        val displayName = when (mimeType.lowercase()) {
            "video/avc" -> "H.264 / AVC"
            "video/hevc" -> "HEVC / H.265"
            "video/x-vnd.on2.vp8" -> "VP8"
            "video/x-vnd.on2.vp9" -> "VP9"
            "video/av01" -> "AV1"
            "video/mp4v-es" -> "MPEG-4 Part 2"
            "video/mpeg2" -> "MPEG-2 Video"
            "video/mjpeg" -> "MJPEG"
            "video/3gpp" -> "H.263"
            "audio/mp4a-latm" -> "AAC"
            "audio/mpeg" -> "MP3"
            "audio/ac3" -> "AC-3"
            "audio/eac3" -> "E-AC-3"
            "audio/vnd.dts", "audio/dts" -> "DTS"
            "audio/vnd.dts.hd" -> "DTS-HD"
            "audio/true-hd" -> "TrueHD / MLP"
            "audio/flac" -> "FLAC"
            "audio/alac" -> "ALAC"
            "audio/opus" -> "Opus"
            "audio/vorbis" -> "Vorbis"
            "audio/x-ape" -> "APE"
            "audio/raw" -> "PCM Variants"
            "audio/x-ms-wma" -> "WMA / WMA Pro"
            "audio/3gpp" -> "AMR-NB"
            "audio/amr-wb" -> "AMR-WB"
            else -> mimeType
        }

        return CodecSupportStatus(
            displayName = displayName,
            mimeType = mimeType,
            hardwareAvailable = hwDecoders.isNotEmpty(),
            softwareAvailable = swDecoders.isNotEmpty(),
            extensionAvailable = extAvailable,
            hardwareDecoders = hwDecoders,
            softwareDecoders = swDecoders,
            extensionDecoders = extDecoders
        )
    }

    fun generateDeviceCodecReport(): String {
        val videoMimes = listOf(
            "video/avc",
            "video/hevc",
            "video/x-vnd.on2.vp8",
            "video/x-vnd.on2.vp9",
            "video/av01",
            "video/mp4v-es",
            "video/mpeg2",
            "video/mjpeg"
        )

        val audioMimes = listOf(
            "audio/mp4a-latm",
            "audio/mpeg",
            "audio/ac3",
            "audio/eac3",
            "audio/vnd.dts",
            "audio/vnd.dts.hd",
            "audio/true-hd",
            "audio/flac",
            "audio/alac",
            "audio/opus",
            "audio/vorbis",
            "audio/raw",
            "audio/x-ms-wma"
        )

        val sb = StringBuilder()
        sb.appendLine("==========================================")
        sb.appendLine("   DEVELOPER -> RUNTIME DECODER REPORT   ")
        sb.appendLine("==========================================")
        
        var ffmpegVersion = "Unknown"
        var ffmpegAvailable = false
        try {
            ffmpegAvailable = androidx.media3.decoder.ffmpeg.FfmpegLibrary.isAvailable()
            if (ffmpegAvailable) {
                ffmpegVersion = androidx.media3.decoder.ffmpeg.FfmpegLibrary.getVersion() ?: "6.0 (LGPL)"
            }
        } catch (e: Throwable) {
            ffmpegAvailable = false
        }

        sb.appendLine("FFmpeg Extension Status: ${if (ffmpegAvailable) "AVAILABLE (v$ffmpegVersion)" else "UNAVAILABLE"}")
        sb.appendLine("License Configuration: LGPL v2.1+ / v3 (Legitimate Native Build)")
        sb.appendLine("Supported ABIs: arm64-v8a, armeabi-v7a, x86, x86_64")
        sb.appendLine("Hardware Preference: ENFORCED (Hardware MediaCodec tried first)")

        val deviceMfg = try { android.os.Build.MANUFACTURER ?: "Generic" } catch (_: Throwable) { "Generic" }
        val deviceModel = try { android.os.Build.MODEL ?: "Device" } catch (_: Throwable) { "Device" }
        val matchedQuirks = com.example.media.orchestration.DeviceCodecQuirkRegistry.getAllMatchingQuirksForDevice()
        sb.appendLine("\n--- PROACTIVE DEVICE CODEC QUIRK REGISTRY ---")
        if (matchedQuirks.isEmpty()) {
            sb.appendLine("  No known hardware decoder quirks matched for this device ($deviceMfg $deviceModel)")
        } else {
            sb.appendLine("  Matched ${matchedQuirks.size} proactive quirk rule(s) for $deviceMfg $deviceModel:")
            for (q in matchedQuirks) {
                sb.appendLine("   • [${q.id}] Action: ${q.action} -> ${q.reason}")
            }
        }

        sb.appendLine("\n--- VIDEO CODEC MATRIX ---")
        for (mime in videoMimes) {
            val status = checkCodecSupport(mime)
            sb.appendLine("${status.displayName} ($mime):")
            sb.appendLine("  Hardware: ${if (status.hardwareAvailable) "AVAILABLE [${status.hardwareDecoders.joinToString()}]" else "UNAVAILABLE"}")
            sb.appendLine("  Software: ${if (status.softwareAvailable) "AVAILABLE [${status.softwareDecoders.joinToString()}]" else "UNAVAILABLE"}")
            sb.appendLine("  Extension: ${if (status.extensionAvailable) "AVAILABLE [${status.extensionDecoders.joinToString()}]" else "UNAVAILABLE"}")
        }

        sb.appendLine("\n--- AUDIO CODEC MATRIX ---")
        for (mime in audioMimes) {
            val status = checkCodecSupport(mime)
            sb.appendLine("${status.displayName} ($mime):")
            sb.appendLine("  Hardware: ${if (status.hardwareAvailable) "AVAILABLE [${status.hardwareDecoders.joinToString()}]" else "UNAVAILABLE"}")
            sb.appendLine("  Software: ${if (status.softwareAvailable) "AVAILABLE [${status.softwareDecoders.joinToString()}]" else "UNAVAILABLE"}")
            sb.appendLine("  Extension: ${if (status.extensionAvailable) "AVAILABLE [${status.extensionDecoders.joinToString()}]" else "UNAVAILABLE"}")
        }

        return sb.toString().trimEnd()
    }

    fun generateFullRuntimeDecoderReport(diagnostics: MediaDiagnostics? = null, decoderManager: DecoderManager? = null): String {
        val deviceReport = generateDeviceCodecReport()
        if (diagnostics == null) return deviceReport

        val sb = StringBuilder()
        sb.appendLine(deviceReport)
        
        if (decoderManager != null) {
            sb.appendLine("\n==========================================")
            sb.appendLine(decoderManager.getPerformanceProfile().formatDiagnosticSummary())
            sb.appendLine("\n==========================================")
            sb.appendLine(decoderManager.getEventLog())
        }
        
        sb.appendLine("\n==========================================")
        sb.appendLine("    ACTIVE STREAM DECODER SELECTION LOG   ")
        sb.appendLine("==========================================")
        sb.appendLine("Container Format: ${diagnostics.container.format}")
        sb.appendLine("Duration: ${diagnostics.container.durationMs} ms")
        sb.appendLine("Has Chapters: ${diagnostics.container.hasChapters}")

        if (diagnostics.videoTracks.isNotEmpty()) {
            sb.appendLine("\n[ACTIVE VIDEO TRACKS]")
            for ((idx, v) in diagnostics.videoTracks.withIndex()) {
                val dec = decoderManager?.findVideoDecoder(v.mimeType, v.width, v.height)
                val hwStatus = dec?.sourceType?.name ?: if (v.codec.contains("avc") || v.codec.contains("h264") || v.codec.contains("hevc") || v.codec.contains("vp9")) "HARDWARE_PREFERRED" else "SOFTWARE_FALLBACK"
                val decoderName = dec?.decoderName ?: "Unknown"
                sb.appendLine("Track #$idx: ${v.codec} | Mime: ${v.mimeType} | Res: ${v.width}x${v.height} @ ${v.frameRate}fps")
                sb.appendLine("  • Bit Depth: ${v.bitDepth}-bit | Codec String: ${v.codecString}")
                sb.appendLine("  • Selected Decoder Mode: $hwStatus [$decoderName]")
            }
        }

        if (diagnostics.audioTracks.isNotEmpty()) {
            sb.appendLine("\n[ACTIVE AUDIO TRACKS]")
            for ((idx, a) in diagnostics.audioTracks.withIndex()) {
                val dec = decoderManager?.findAudioDecoder(a.mimeType, a.channels, a.sampleRate)
                val isAc3OrDts = a.mimeType.contains("ac3") || a.mimeType.contains("dts") || a.mimeType.contains("true-hd")
                val decoderName = dec?.decoderName ?: if (isAc3OrDts) "FFmpegAudioRenderer (Software/Extension)" else "MediaCodec / AudioTrack"
                val reason = dec?.sourceType?.name ?: if (isAc3OrDts) "Hardware MediaCodec lacks native license/decoder -> FFmpeg fallback" else "Hardware MediaCodec available and functional"
                sb.appendLine("Track #$idx: ${a.codec} (${a.language}) | ${a.channels}ch @ ${a.sampleRate}Hz")
                sb.appendLine("  • Selected Decoder: $decoderName")
                sb.appendLine("  • Reason: $reason")
            }
        }

        if (diagnostics.subtitleTracks.isNotEmpty()) {
            sb.appendLine("\n[ACTIVE SUBTITLE TRACKS]")
            for ((idx, s) in diagnostics.subtitleTracks.withIndex()) {
                sb.appendLine("Track #$idx: ${s.codec} (${s.language}) | Title: ${s.title} | Default: ${s.isDefault}")
            }
        }

        return sb.toString().trimEnd()
    }

    fun investigateAc3Support(): String {
        val ac3Status = checkCodecSupport("audio/ac3")
        val eac3Status = checkCodecSupport("audio/eac3")

        val sb = StringBuilder()
        sb.appendLine("AC-3 AUDIT DIAGNOSTICS:")
        try {
            sb.appendLine("  FFmpeg loaded: ${androidx.media3.decoder.ffmpeg.FfmpegLibrary.isAvailable()}")
        } catch (e: Throwable) {
            sb.appendLine("  FFmpeg loaded: NO")
        }
        sb.appendLine("  AC-3 MediaCodec available: ${if (ac3Status.hardwareAvailable || ac3Status.softwareAvailable) "YES" else "NO"}")
        sb.appendLine("  AC-3 FFmpeg available: ${if (ac3Status.extensionAvailable) "YES" else "NO"}")
        val allAc3Decoders = (ac3Status.hardwareDecoders + ac3Status.softwareDecoders + ac3Status.extensionDecoders).distinct()
        sb.appendLine("  Available AC-3 decoders: ${if (allAc3Decoders.isEmpty()) "[NONE]" else allAc3Decoders.joinToString()}")
        sb.appendLine("  Selected AC-3 decoder: ${if (allAc3Decoders.isEmpty()) "NONE" else allAc3Decoders.first()}")
        sb.appendLine("  E-AC-3 MediaCodec available: ${if (eac3Status.hardwareAvailable || eac3Status.softwareAvailable) "YES" else "NO"}")
        sb.appendLine("  E-AC-3 FFmpeg available: ${if (eac3Status.extensionAvailable) "YES" else "NO"}")
        return sb.toString()
    }
}
