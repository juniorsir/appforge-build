package com.example.media

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaStyleNotificationHelper
import com.example.MainActivity
import com.example.R
import com.example.data.DownloadEntity
import kotlinx.coroutines.*

class BackgroundAudioPlayerService : Service(), BackgroundPlaybackManager.ServiceControls {

    companion object {
        private const val TAG = "BgAudioService"
        const val CHANNEL_ID = "bg_media_playback_channel"
        const val NOTIFICATION_ID = 4040

        const val ACTION_START = "com.example.media.ACTION_START"
        const val ACTION_PAUSE = "com.example.media.ACTION_PAUSE"
        const val ACTION_RESUME = "com.example.media.ACTION_RESUME"
        const val ACTION_TOGGLE = "com.example.media.ACTION_TOGGLE"
        const val ACTION_SEEK_BACK = "com.example.media.ACTION_SEEK_BACK"
        const val ACTION_SEEK_FORWARD = "com.example.media.ACTION_SEEK_FORWARD"
        const val ACTION_SEEK_TO = "com.example.media.ACTION_SEEK_TO"
        const val ACTION_SET_SLEEP_TIMER = "com.example.media.ACTION_SET_SLEEP_TIMER"
        const val ACTION_STOP = "com.example.media.ACTION_STOP"

        const val EXTRA_MEDIA_ID = "extra_media_id"
        const val EXTRA_MEDIA_TITLE = "extra_media_title"
        const val EXTRA_MEDIA_AUTHOR = "extra_media_author"
        const val EXTRA_MEDIA_PATH = "extra_media_path"
        const val EXTRA_MEDIA_THUMB = "extra_media_thumb"
        const val EXTRA_MEDIA_DURATION = "extra_media_duration"
        const val EXTRA_START_POSITION = "extra_start_position"
        const val EXTRA_PLAYBACK_SPEED = "extra_playback_speed"
        const val EXTRA_SLEEP_MINUTES = "extra_sleep_minutes"
    }

    private var exoPlayer: ExoPlayer? = null
    private var mediaSession: MediaSession? = null

    private var currentEntity: DownloadEntity? = null
    private var currentTitle: String = "Playing Audio"
    private var currentAuthor: String = "Downly Media Player"
    private var currentArtBitmap: Bitmap? = null

    private val serviceJob = SupervisorJob()
    private val serviceScope = CoroutineScope(Dispatchers.Main + serviceJob)
    private var progressJob: Job? = null

    private val noisyReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == AudioManager.ACTION_AUDIO_BECOMING_NOISY) {
                pause()
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        BackgroundPlaybackManager.serviceInterface = this

        initExoPlayer()

        try {
            val filter = IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY)
            registerReceiver(noisyReceiver, filter)
        } catch (e: Exception) {
            Log.w(TAG, "Failed to register noisy receiver: ${e.message}")
        }

        try {
            val initialNotification = buildNotification(isPlaying = false)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(
                    NOTIFICATION_ID,
                    initialNotification,
                    android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK
                )
            } else {
                startForeground(NOTIFICATION_ID, initialNotification)
            }
        } catch (e: Throwable) {
            Log.w(TAG, "startForeground in onCreate warning: ${e.message}")
        }
    }

    private fun initExoPlayer() {
        val renderersFactory = DefaultRenderersFactory(this)
            .setEnableDecoderFallback(true)
            .setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_ON)
            .setEnableAudioTrackPlaybackParams(true)

        val httpDataSourceFactory = DefaultHttpDataSource.Factory()
            .setUserAgent("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36")
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(15000)
            .setReadTimeoutMs(15000)

        val dataSourceFactory = DefaultDataSource.Factory(this, httpDataSourceFactory)
        val extractorsFactory = androidx.media3.extractor.DefaultExtractorsFactory()
            .setConstantBitrateSeekingEnabled(true)
        val mediaSourceFactory = DefaultMediaSourceFactory(this, extractorsFactory)
            .setDataSourceFactory(dataSourceFactory)

        val player = ExoPlayer.Builder(this, renderersFactory)
            .setMediaSourceFactory(mediaSourceFactory)
            .setWakeMode(C.WAKE_MODE_LOCAL)
            .setHandleAudioBecomingNoisy(true)
            .setAudioAttributes(
                androidx.media3.common.AudioAttributes.Builder()
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .setUsage(C.USAGE_MEDIA)
                    .build(),
                true
            )
            .build()

        player.playWhenReady = true
        player.repeatMode = Player.REPEAT_MODE_ONE

        player.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                val isBuffering = playbackState == Player.STATE_BUFFERING
                BackgroundPlaybackManager.updateState(
                    isActive = true,
                    media = currentEntity,
                    isPlaying = player.isPlaying,
                    positionMs = player.currentPosition.coerceAtLeast(0L),
                    durationMs = player.duration.coerceAtLeast(0L),
                    isBuffering = isBuffering
                )
                updateNotification()

                if (playbackState == Player.STATE_READY) {
                    startProgressTracking()
                } else if (playbackState == Player.STATE_ENDED) {
                    stopProgressTracking()
                }
            }

            override fun onIsPlayingChanged(isPlaying: Boolean) {
                BackgroundPlaybackManager.updatePlayingState(isPlaying)
                updateNotification()
                if (isPlaying) {
                    startProgressTracking()
                } else {
                    stopProgressTracking()
                }
            }
        })

        exoPlayer = player

        try {
            mediaSession = MediaSession.Builder(this, player).build()
        } catch (e: Exception) {
            Log.w(TAG, "MediaSession init error: ${e.message}")
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null) return START_NOT_STICKY

        when (intent.action) {
            ACTION_START -> {
                val mediaId = intent.getStringExtra(EXTRA_MEDIA_ID) ?: ""
                val mediaTitle = intent.getStringExtra(EXTRA_MEDIA_TITLE) ?: "Audio Track"
                val mediaAuthor = intent.getStringExtra(EXTRA_MEDIA_AUTHOR) ?: "Downly"
                val mediaPath = intent.getStringExtra(EXTRA_MEDIA_PATH) ?: ""
                val mediaThumb = intent.getStringExtra(EXTRA_MEDIA_THUMB) ?: ""
                val mediaDuration = intent.getStringExtra(EXTRA_MEDIA_DURATION) ?: ""
                val startPos = intent.getLongExtra(EXTRA_START_POSITION, 0L)
                val speed = intent.getFloatExtra(EXTRA_PLAYBACK_SPEED, 1.0f)

                stopProgressTracking()
                currentArtBitmap = null

                currentTitle = mediaTitle
                currentAuthor = mediaAuthor

                currentEntity = DownloadEntity(
                    id = mediaId,
                    title = mediaTitle,
                    author = mediaAuthor,
                    durationText = mediaDuration,
                    thumbnailUrl = mediaThumb,
                    localPath = mediaPath,
                    fileSize = 0L,
                    downloadedAt = System.currentTimeMillis()
                )

                loadMediaArtwork(mediaId, mediaTitle, mediaAuthor, mediaPath, mediaThumb)
                prepareAndPlay(mediaPath, startPos, speed)

                try {
                    val notif = buildNotification(isPlaying = true)
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        startForeground(
                            NOTIFICATION_ID,
                            notif,
                            android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK
                        )
                    } else {
                        startForeground(NOTIFICATION_ID, notif)
                    }
                } catch (e: Exception) {
                    Log.w(TAG, "startForeground error: ${e.message}")
                }
            }
            ACTION_PAUSE -> pause()
            ACTION_RESUME -> resume()
            ACTION_TOGGLE -> {
                if (exoPlayer?.isPlaying == true) pause() else resume()
            }
            ACTION_SEEK_BACK -> seekBy(-10000L)
            ACTION_SEEK_FORWARD -> seekBy(10000L)
            ACTION_SEEK_TO -> {
                val pos = intent.getLongExtra("pos", 0L)
                seekTo(pos)
            }
            ACTION_SET_SLEEP_TIMER -> {
                val minutes = intent.getIntExtra(EXTRA_SLEEP_MINUTES, 0)
                handleSetSleepTimer(minutes)
            }
            ACTION_STOP -> stop()
        }

        return START_NOT_STICKY
    }

    private var sleepTimerJob: Job? = null

    private fun handleSetSleepTimer(minutes: Int) {
        sleepTimerJob?.cancel()
        if (minutes <= 0) {
            exoPlayer?.volume = 1.0f
            BackgroundPlaybackManager.updateSleepTimerState(0, 0)
            updateNotification()
            return
        }

        sleepTimerJob = serviceScope.launch {
            var remainingSecs = minutes * 60
            val fadeDurationSecs = 30
            while (remainingSecs > 0 && exoPlayer?.isPlaying == true) {
                BackgroundPlaybackManager.updateSleepTimerState(minutes, remainingSecs)
                delay(1000)
                remainingSecs--

                if (remainingSecs <= fadeDurationSecs) {
                    val fadeFactor = (remainingSecs.toFloat() / fadeDurationSecs).coerceIn(0f, 1f)
                    exoPlayer?.volume = fadeFactor
                } else {
                    exoPlayer?.volume = 1.0f
                }
            }

            if (remainingSecs <= 0) {
                pause()
                exoPlayer?.volume = 1.0f
                BackgroundPlaybackManager.updateSleepTimerState(0, 0)
                updateNotification()
            }
        }
    }

    private fun prepareAndPlay(path: String, startPos: Long, speed: Float) {
        val player = exoPlayer ?: return
        try {
            player.stop()
            player.clearMediaItems()

            // If combined path exists (videoPath|STREAM_AUDIO_URL|audioPath), extract best audio stream
            val actualUri = if (path.contains("|STREAM_AUDIO_URL|")) {
                path.substringAfter("|STREAM_AUDIO_URL|")
            } else {
                path.substringBefore("|STREAM_AUDIO_URL|")
            }

            val metadataBuilder = androidx.media3.common.MediaMetadata.Builder()
                .setTitle(currentTitle)
                .setArtist(currentAuthor)
                .setAlbumTitle("DOWNLY")

            currentArtBitmap?.let { bmp ->
                val artworkBytes = DownlyMediaArtworkManager.bitmapToByteArray(bmp)
                metadataBuilder.setArtworkData(artworkBytes, androidx.media3.common.MediaMetadata.PICTURE_TYPE_FRONT_COVER)
            }

            val mediaItem = MediaItem.Builder()
                .setUri(actualUri)
                .setMediaMetadata(metadataBuilder.build())
                .build()

            player.setMediaItem(mediaItem)
            player.playbackParameters = PlaybackParameters(speed)
            player.prepare()
            if (startPos > 0L) {
                player.seekTo(startPos)
            }
            player.playWhenReady = true
            player.play()

            BackgroundPlaybackManager.updateState(
                isActive = true,
                media = currentEntity,
                isPlaying = true,
                positionMs = startPos,
                durationMs = 0L
            )
            updateNotification()
            startProgressTracking()
        } catch (e: Exception) {
            Log.e(TAG, "Error starting playback: ${e.message}", e)
        }
    }

    private fun startProgressTracking() {
        progressJob?.cancel()
        progressJob = serviceScope.launch {
            while (isActive) {
                val player = exoPlayer
                if (player != null && player.isPlaying) {
                    val pos = player.currentPosition.coerceAtLeast(0L)
                    val dur = player.duration.coerceAtLeast(0L)
                    BackgroundPlaybackManager.updatePosition(pos)
                    if (dur > 0L) {
                        BackgroundPlaybackManager.updateDuration(dur)
                    }
                }
                delay(500L)
            }
        }
    }

    private fun stopProgressTracking() {
        progressJob?.cancel()
        progressJob = null
    }

    override fun pause() {
        exoPlayer?.pause()
        BackgroundPlaybackManager.updatePlayingState(false)
        updateNotification()
    }

    override fun resume() {
        val player = exoPlayer ?: return
        if (player.playbackState == Player.STATE_ENDED) {
            player.seekTo(0L)
        }
        player.playWhenReady = true
        player.play()
        BackgroundPlaybackManager.updatePlayingState(true)
        updateNotification()
    }

    override fun seekTo(positionMs: Long) {
        exoPlayer?.seekTo(positionMs)
        BackgroundPlaybackManager.updatePosition(positionMs)
    }

    fun seekBy(deltaMs: Long) {
        val player = exoPlayer ?: return
        val current = player.currentPosition
        val dur = player.duration.coerceAtLeast(0L)
        val target = (current + deltaMs).coerceIn(0L, if (dur > 0L) dur else Long.MAX_VALUE)
        seekTo(target)
    }

    override fun setSpeed(speed: Float) {
        exoPlayer?.playbackParameters = PlaybackParameters(speed)
    }

    override fun stop() {
        stopProgressTracking()
        try {
            exoPlayer?.stop()
            exoPlayer?.clearMediaItems()
        } catch (_: Exception) {}

        BackgroundPlaybackManager.updateState(
            isActive = false,
            media = null,
            isPlaying = false,
            positionMs = 0L,
            durationMs = 0L
        )

        try {
            stopForeground(STOP_FOREGROUND_REMOVE)
        } catch (_: Throwable) {}
        stopSelf()
    }

    private var artworkJob: Job? = null

    private fun loadMediaArtwork(
        mediaId: String,
        title: String,
        author: String,
        path: String,
        thumbUrl: String
    ) {
        artworkJob?.cancel()
        artworkJob = serviceScope.launch(Dispatchers.IO) {
            val artworkBmp = DownlyMediaArtworkManager.getArtwork(
                context = this@BackgroundAudioPlayerService,
                mediaId = mediaId,
                title = title,
                artist = author,
                mediaPath = path,
                thumbUrl = thumbUrl
            )
            if (currentEntity?.id == mediaId) {
                currentArtBitmap = artworkBmp
                withContext(Dispatchers.Main) {
                    if (currentEntity?.id == mediaId) {
                        updateMediaSessionMetadata(artworkBmp, title, author)
                        updateNotification()
                    }
                }
            }
        }
    }

    private fun updateMediaSessionMetadata(artworkBmp: Bitmap, title: String, author: String) {
        try {
            val player = exoPlayer ?: return
            val artworkBytes = DownlyMediaArtworkManager.bitmapToByteArray(artworkBmp)

            val mediaMetadata = androidx.media3.common.MediaMetadata.Builder()
                .setTitle(title)
                .setArtist(author)
                .setAlbumTitle("DOWNLY")
                .setArtworkData(artworkBytes, androidx.media3.common.MediaMetadata.PICTURE_TYPE_FRONT_COVER)
                .build()

            val currentItem = player.currentMediaItem
            if (currentItem != null) {
                val updatedItem = currentItem.buildUpon()
                    .setMediaMetadata(mediaMetadata)
                    .build()
                player.replaceMediaItem(player.currentMediaItemIndex, updatedItem)
            }
        } catch (e: Exception) {
            Log.w(TAG, "Failed updating MediaSession metadata: ${e.message}")
        }
    }

    private fun updateNotification() {
        try {
            val isPlaying = exoPlayer?.isPlaying == true
            val notification = buildNotification(isPlaying)
            val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
            notificationManager?.notify(NOTIFICATION_ID, notification)
        } catch (e: Exception) {
            Log.w(TAG, "Failed to update media notification: ${e.message}")
        }
    }

    private fun buildNotification(isPlaying: Boolean): Notification {
        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra("OPEN_BACKGROUND_PLAYER", true)
            currentEntity?.let {
                putExtra("PLAY_MEDIA_ID", it.id)
                putExtra("PLAY_MEDIA_PATH", it.localPath)
            }
        }
        val contentPendingIntent = PendingIntent.getActivity(
            this, 100, openAppIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        // Actions
        val rewindIntent = Intent(this, BackgroundAudioPlayerService::class.java).apply { action = ACTION_SEEK_BACK }
        val rewindPending = getPendingIntentService(101, rewindIntent)

        val toggleAction = if (isPlaying) ACTION_PAUSE else ACTION_RESUME
        val toggleIntent = Intent(this, BackgroundAudioPlayerService::class.java).apply { action = toggleAction }
        val togglePending = getPendingIntentService(102, toggleIntent)

        val forwardIntent = Intent(this, BackgroundAudioPlayerService::class.java).apply { action = ACTION_SEEK_FORWARD }
        val forwardPending = getPendingIntentService(103, forwardIntent)

        val stopIntent = Intent(this, BackgroundAudioPlayerService::class.java).apply { action = ACTION_STOP }
        val stopPending = getPendingIntentService(104, stopIntent)

        val playPauseIcon = if (isPlaying) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play
        val playPauseText = if (isPlaying) "Pause" else "Play"

        // Ensure artwork is strictly 512x512 1:1 square
        val artworkToUse = currentArtBitmap ?: DownlyMediaArtworkManager.createDefaultDownlyArtwork()
        assert(artworkToUse.width == artworkToUse.height) { "Artwork must be 1:1 square" }

        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(currentTitle)
            .setContentText(currentAuthor)
            .setSubText("DOWNLY")
            .setSmallIcon(R.drawable.ic_download_modern)
            .setLargeIcon(artworkToUse)
            .setContentIntent(contentPendingIntent)
            .setDeleteIntent(stopPending)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setOngoing(isPlaying)
            .addAction(android.R.drawable.ic_media_rew, "Rewind 10s", rewindPending)
            .addAction(playPauseIcon, playPauseText, togglePending)
            .addAction(android.R.drawable.ic_media_ff, "Forward 10s", forwardPending)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Close", stopPending)

        mediaSession?.let { session ->
            builder.setStyle(
                MediaStyleNotificationHelper.MediaStyle(session)
                    .setShowActionsInCompactView(0, 1, 2)
            )
        }

        return builder.build()
    }

    private fun getPendingIntentService(requestCode: Int, intent: Intent): PendingIntent {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            PendingIntent.getForegroundService(
                this,
                requestCode,
                intent,
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
        } else {
            PendingIntent.getService(
                this,
                requestCode,
                intent,
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Background Audio Playback",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Controls for background media & audio playback without PiP"
                setShowBadge(false)
                lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        stopProgressTracking()
        serviceJob.cancel()
        try {
            unregisterReceiver(noisyReceiver)
        } catch (_: Exception) {}

        BackgroundPlaybackManager.serviceInterface = null
        try {
            mediaSession?.release()
            exoPlayer?.release()
        } catch (_: Exception) {}
        exoPlayer = null
        mediaSession = null
    }
}
