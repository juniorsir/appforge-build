package com.example.ui

import android.content.Context
import android.os.Build
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import kotlinx.coroutines.async
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import java.io.File
import java.util.Locale

import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import com.yausername.youtubedl_android.YoutubeDLResponse
import com.yausername.youtubedl_android.mapper.VideoInfo
import com.yausername.ffmpeg.FFmpeg

/**
 * Clean, production-grade Downloader Pipeline Manager focused exclusively on the Native ABI-Packaged JNI architecture (Seal-Style).
 */
object YtdlpPipelineManager {
    private const val TAG = "YtdlpPipelineManager"

    // High performance JNI extraction LRU cache to make repetitive playback instant
    fun evictUrl(url: String) {
        val cleanUrl = url.trim()
        com.example.extraction.ExtractionCache.remove(cleanUrl)
        Log.d(TAG, "🧹 Evicted URL from extraction cache ($cleanUrl)")
    }

    fun clearCache() {
        com.example.extraction.ExtractionCache.clear()
        Log.d(TAG, "🧹 Cleared entire JNI streaming URL cache")
    }

    // Dedicated prefetch queue and scope for ultra-fast, background URL JNI warm queries
    private val prefetchQueue = java.util.Collections.synchronizedSet(mutableSetOf<String>())
    private val prefetchScope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private val prefetchSemaphore = Semaphore(permits = 2)

    fun prefetchVideoUrl(context: Context, url: String) {
        val cleanUrl = url.trim()
        if (cleanUrl.isBlank()) return
        
        // Already cached?
        val cached = com.example.extraction.ExtractionCache.get(cleanUrl)
        if (cached != null && cached.success) return

        // Already being prefetched?
        if (!prefetchQueue.add(cleanUrl)) return

        prefetchScope.launch {
            val currentCached = com.example.extraction.ExtractionCache.get(cleanUrl)
            if (currentCached != null && currentCached.success) {
                prefetchQueue.remove(cleanUrl)
                return@launch
            }

            prefetchSemaphore.withPermit {
                try {
                    Log.d(TAG, "🟢 [PREFETCH STARTED] Beginning background JNI extraction: $cleanUrl")
                    com.example.extraction.YtdlpExtractorPipeline.executePipeline(context, cleanUrl) {}
                    Log.d(TAG, "✅ [PREFETCH COMPLETED] Background extraction cached successfully: $cleanUrl")
                } catch (e: Exception) {
                    Log.e(TAG, "⚠️ [PREFETCH FAILED] Error prefetching $cleanUrl: ${e.localizedMessage}")
                } finally {
                    prefetchQueue.remove(cleanUrl)
                }
            }
        }
    }

    fun prefetchBatch(context: Context, urls: List<String>) {
        prefetchScope.launch {
            urls.take(3).forEach { url ->
                prefetchVideoUrl(context, url)
                delay(400) // Increase stagger delay to 400ms for extra breathing room
            }
        }
    }

    enum class BackendType(val displayName: String, val priority: Int) {
        NATIVE_SEAL("Primary: Native ABI-Packaged (Seal-Style)", 1)
    }

    data class DiagnosticReport(
        val sdkInt: Int,
        val releaseVersion: String,
        val systemArchitecture: String,
        val wExRestricted: Boolean,
        val selinuxEnforced: Boolean,
        val codeCacheWritable: Boolean,
        val activeBackend: BackendType,
        val diagnosticsLog: String
    )

    data class ExtractionResult(
        val success: Boolean,
        val title: String,
        val uploader: String,
        val thumbnailUrl: String,
        val formats: List<VideoFormatUi>,
        val usedBackend: BackendType,
        val logOutput: String,
        val errorCode: String? = null,
        val structuredError: com.example.extraction.StructuredExtractionError? = null,
        val durationSeconds: Long = 0L,
        val extractorName: String = "generic",
        val timestamp: Long = System.currentTimeMillis()
    )

    /**
     * Executes metadata extraction and analysis via modular YtdlpExtractorPipeline.
     */
    suspend fun analyzeUrl(
        context: Context,
        url: String,
        onLog: (String) -> Unit
    ): ExtractionResult {
        return com.example.extraction.YtdlpExtractorPipeline.executePipeline(context, url, onLog)
    }

    fun runDiagnostics(context: Context): DiagnosticReport {
        val sdkInt = Build.VERSION.SDK_INT
        val release = Build.VERSION.RELEASE
        val pAbi = Build.SUPPORTED_ABIS.firstOrNull() ?: Build.CPU_ABI
        val allAbis = Build.SUPPORTED_ABIS.joinToString(", ")
        
        val targetSdk = context.applicationInfo.targetSdkVersion
        val wExRestricted = sdkInt >= 29 && targetSdk >= 29
        
        val codeCacheDirWritable = context.codeCacheDir?.canWrite() == true

        val logs = StringBuilder()
        logs.append("==================================================\n")
        logs.append("🛡️ NATIVE JNI ONLY DIAGNOSTIC REPORT\n")
        logs.append("==================================================\n")
        logs.append("✔ OS API Level: $sdkInt (Android $release)\n")
        logs.append("✔ Target SDK Level: $targetSdk\n")
        logs.append("✔ Device System ABIs: $pAbi (Supported: $allAbis)\n")
        logs.append("✔ SELinux W^X Execution Block: ${if (wExRestricted) "ENFORCED (Kernel bans dynamic writable execve)" else "ALLOWABLE"}\n")
        logs.append("✔ Safe Sandboxed codeCacheDir Storage: ${if (codeCacheDirWritable) "WRITABLE" else "RESTRICTED"}\n")

        logs.append("\n💡 DIAGNOSTIC SELECTION RESULT:\n")
        logs.append("↳ Auto-selected pipeline: ${BackendType.NATIVE_SEAL.displayName}\n")
        logs.append("--------------------------------------------------\n")

        return DiagnosticReport(
            sdkInt = sdkInt,
            releaseVersion = release,
            systemArchitecture = pAbi,
            wExRestricted = wExRestricted,
            selinuxEnforced = true,
            codeCacheWritable = codeCacheDirWritable,
            activeBackend = BackendType.NATIVE_SEAL,
            diagnosticsLog = logs.toString()
        )
    }

    var isInitialized = false

    private fun resetYtdlpFiles(context: Context, log: (String) -> Unit) {
        try {
            log("   🧹 Cleaning up youtubedl-android update caches to prevent Python 3.8 deprecation errors...")
            val dirsToClean = listOf(
                File(context.filesDir, "youtubedl-android"),
                File(context.noBackupFilesDir, "youtubedl-android")
            )
            for (dir in dirsToClean) {
                if (dir.exists()) {
                    log("   🗑️ Deleting update cache directory: ${dir.absolutePath}")
                    deleteRecursive(dir)
                }
            }
        } catch (e: Throwable) {
            log("   ⚠️ Cleanup warning: ${e.localizedMessage}")
        }
    }

    private fun deleteRecursive(fileOrDirectory: File) {
        if (fileOrDirectory.isDirectory) {
            val children = fileOrDirectory.listFiles()
            if (children != null) {
                for (child in children) {
                    deleteRecursive(child)
                }
            }
        }
        fileOrDirectory.delete()
    }

    @Synchronized
    fun init(context: Context, log: (String) -> Unit = {}) {
        if (isInitialized) return
        try {
            log("   ⚡ Initializing youtubedl-android JNI core components in parallel (accelerated)...")
            val appContext = context.applicationContext
            val latch = java.util.concurrent.CountDownLatch(2)
            var youtubeDLException: Throwable? = null
            var ffmpegException: Throwable? = null

            val executor = java.util.concurrent.Executors.newFixedThreadPool(2)

            executor.execute {
                try {
                    val startTime = System.currentTimeMillis()
                    YoutubeDL.getInstance().init(appContext)
                    val duration = System.currentTimeMillis() - startTime
                    log("   ✅ JNI YoutubeDL core loaded in ${duration}ms")
                } catch (e: Throwable) {
                    youtubeDLException = e
                    log("   ⚠️ JNI YoutubeDL loading error: ${e.localizedMessage}")
                } finally {
                    latch.countDown()
                }
            }

            executor.execute {
                try {
                    val startTime = System.currentTimeMillis()
                    FFmpeg.getInstance().init(appContext)
                    val duration = System.currentTimeMillis() - startTime
                    log("   ✅ JNI FFmpeg core loaded in ${duration}ms")
                } catch (e: Throwable) {
                    ffmpegException = e
                    log("   ⚠️ JNI FFmpeg loading error: ${e.localizedMessage}")
                } finally {
                    latch.countDown()
                }
            }

            latch.await()
            executor.shutdown()

            if (youtubeDLException == null && ffmpegException == null) {
                isInitialized = true
                log("   🚀 Highly parallelized JNI initialization succeeded fastly!")
            } else {
                val errorMsg = listOfNotNull(youtubeDLException?.localizedMessage, ffmpegException?.localizedMessage).joinToString("; ")
                log("   ⚠️ Parallel load had issues: $errorMsg")
                // Sequential fallback to be robust
                if (youtubeDLException != null) {
                    YoutubeDL.getInstance().init(appContext)
                }
                if (ffmpegException != null) {
                    FFmpeg.getInstance().init(appContext)
                }
                isInitialized = true
                log("   ✅ Sequential fallback resolved and JNI loaded successfully.")
            }
        } catch (e: Throwable) {
            log("   ⚠️ Native JNI initialization failed: ${e.localizedMessage}")
            Log.e(TAG, "Failed to initialize youtubedl-android structures", e)
        }
    }

    private fun findFFmpegLocation(context: Context): String? {
        return try {
            val candidates = listOf(
                File(context.noBackupFilesDir, "youtubedl-android/ffmpeg"),
                File(context.filesDir, "youtubedl-android/ffmpeg"),
                File(context.noBackupFilesDir, "ffmpeg"),
                File(context.filesDir, "ffmpeg"),
                File(context.codeCacheDir, "ffmpeg")
            )
            for (file in candidates) {
                if (file.exists()) {
                    return if (file.isDirectory) file.absolutePath else file.parentFile?.absolutePath
                }
            }
            context.noBackupFilesDir?.let { dir ->
                dir.listFiles()?.firstOrNull { it.name.contains("ffmpeg", ignoreCase = true) }?.let {
                    return if (it.isDirectory) it.absolutePath else it.parentFile?.absolutePath
                }
            }
            null
        } catch (e: Throwable) {
            null
        }
    }

    fun downloadUrlWithNative(
        context: Context,
        url: String,
        formatId: String?,
        outputFile: File,
        onProgress: (progress: Float, etaInSeconds: Long, line: String) -> Unit
    ): YoutubeDLResponse {
        init(context) { Log.d("NativeDLInit", it) }
        if (!isInitialized) {
            throw IllegalStateException("youtubedl-android JNI core failed to initialize. Cannot download using native JNI on this device.")
        }
        val isYoutube = url.contains("youtube.com", ignoreCase = true) || url.contains("youtu.be", ignoreCase = true)
        val ffmpegLoc = findFFmpegLocation(context)

        // Embedded Subtitles and Audio preferences from app settings
        val prefs = context.getSharedPreferences("꒯ꄲꅐꋊ꒒ꌦPrefs", Context.MODE_PRIVATE)
        val embedSubtitles = prefs.getBoolean("embedSubtitles", true)
        val embedAutoSubtitles = prefs.getBoolean("embedAutoSubtitles", true)
        val rawSubLangs = prefs.getString("subtitleLanguages", "en,es,fr,de") ?: "en,es,fr,de"
        val cleanSubLangs = rawSubLangs.split(",")
            .map { it.trim().lowercase() }
            .filter { it.isNotBlank() }
            .let { list ->
                // Avoid requesting "all" along with specific languages as "all" requests dozens of tracks triggering HTTP 429
                if (list.contains("all") && list.size > 1) {
                    list.filter { it != "all" }
                } else {
                    list
                }
            }
            .joinToString(",")

        val embedAudioMetadata = prefs.getBoolean("embedAudioMetadata", true)
        val audioMultistreams = prefs.getBoolean("audioMultistreams", false)

        val request = YoutubeDLRequest(url).apply {
            addOption("-o", outputFile.absolutePath)
            
            if (isYoutube) {
                // Removed to fix 360p format restriction
                        // AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Mobile Safari/537.36")
                // 
            }

            if (formatId != null) {
                addOption("-f", formatId)
            } else if (isYoutube) {
                addOption("-f", "bestvideo[height>=1080]+bestaudio/bestvideo+bestaudio/best")
            }
            
            if (ffmpegLoc.isNullOrBlank()) {
                addOption("--merge-output-format", "mkv")
            } else {
                addOption("--ffmpeg-location", ffmpegLoc)
                addOption("--merge-output-format", "mkv")
            }

            if (embedSubtitles) {
                addOption("--write-subs")
                if (embedAutoSubtitles) {
                    addOption("--write-auto-subs")
                }
                if (cleanSubLangs.isNotBlank()) {
                    addOption("--sub-langs", cleanSubLangs)
                }
                addOption("--embed-subs")
                addOption("--sleep-subtitles", "1")
                addOption("--ignore-errors")
            }

            if (embedAudioMetadata) {
                addOption("--embed-thumbnail")
                addOption("--embed-metadata")
            }

            if (audioMultistreams) {
                addOption("--audio-multistreams")
            }

            // Rapid-processing speedup optimizations
            addOption("--concurrent-fragments", "4")
            addOption("--no-mtime")
            addOption("--buffer-size", "256K")
            addOption("--no-playlist")
            addOption("--no-warnings")
            addOption("--no-cache-dir")
            addOption("--socket-timeout", "15")
            addOption("--retries", "3")
        }

        return try {
            YoutubeDL.getInstance().execute(request, null) { progress, etaInSeconds, line ->
                onProgress(progress, etaInSeconds, line)
            }
        } catch (e: Throwable) {
            val errorMsg = e.localizedMessage ?: ""
            val isSubtitle429Error = errorMsg.contains("subtitles", ignoreCase = true) ||
                    errorMsg.contains("429", ignoreCase = true) ||
                    errorMsg.contains("Too Many Requests", ignoreCase = true)

            if (embedSubtitles && isSubtitle429Error) {
                Log.w("YtdlpPipelineManager", "Subtitle HTTP 429 rate limit hit. Retrying video download without embedded subtitles...")
                val ffmpegLoc = findFFmpegLocation(context)
                val fallbackRequest = YoutubeDLRequest(url).apply {
                    addOption("-o", outputFile.absolutePath)
                    if (isYoutube) {
                        // Removed to fix 360p format restriction
                                // AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Mobile Safari/537.36")
                        // 
                    }
                    if (formatId != null) {
                        addOption("-f", formatId)
                    } else if (isYoutube) {
                        addOption("-f", "bestvideo[height>=1080]+bestaudio/bestvideo+bestaudio/best")
                    }
                    if (ffmpegLoc.isNullOrBlank()) {
                        addOption("--merge-output-format", "mkv")
                    } else {
                        addOption("--ffmpeg-location", ffmpegLoc)
                        addOption("--merge-output-format", "mkv")
                    }
                    if (embedAudioMetadata) {
                        addOption("--embed-thumbnail")
                        addOption("--embed-metadata")
                    }
                    if (audioMultistreams) {
                        addOption("--audio-multistreams")
                    }
                    addOption("--concurrent-fragments", "4")
                    addOption("--no-mtime")
                    addOption("--buffer-size", "256K")
                    addOption("--no-playlist")
                    addOption("--no-warnings")
                    addOption("--no-cache-dir")
                    addOption("--socket-timeout", "15")
                    addOption("--retries", "3")
                }
                YoutubeDL.getInstance().execute(fallbackRequest, null) { progress, etaInSeconds, line ->
                    onProgress(progress, etaInSeconds, line)
                }
            } else {
                throw e
            }
        }
    }

    private fun isNativeLibraryPresent(): Boolean {
        return try {
            YoutubeDL.getInstance() != null
            true
        } catch (e: Throwable) {
            false
        }
    }

    data class SearchResult(
        val id: String,
        val title: String,
        val author: String,
        val duration: String,
        val thumbnailUrl: String,
        val originalUrl: String
    )

    fun getEntries(videoInfo: VideoInfo): List<VideoInfo>? {
        return try {
            val method = videoInfo.javaClass.getMethod("getEntries")
            @Suppress("UNCHECKED_CAST")
            method.invoke(videoInfo) as? List<VideoInfo>
        } catch (e: Exception) {
            try {
                val field = videoInfo.javaClass.getDeclaredField("entries")
                field.isAccessible = true
                @Suppress("UNCHECKED_CAST")
                field.get(videoInfo) as? List<VideoInfo>
            } catch (ex: Exception) {
                null
            }
        }
    }

    private fun extractJsonField(json: String, field: String): String? {
        val pattern = "\"$field\"\\s*:\\s*(?:\"([^\"]*)\"|([^,}\\s]+))"
        val regex = java.util.regex.Pattern.compile(pattern)
        val matcher = regex.matcher(json)
        if (matcher.find()) {
            val group1 = matcher.group(1)
            if (group1 != null) {
                return group1
            }
            val group2 = matcher.group(2)
            if (group2 != null) {
                val cleanG2 = group2.trim().removeSurrounding("\"")
                if (cleanG2 == "null") return null
                return cleanG2
            }
        }
        return null
    }

    private fun unescapeJson(input: String): String {
        return try {
            var temp = input
                .replace("\\\"", "\"")
                .replace("\\\\", "\\")
                .replace("\\/", "/")
                .replace("\\t", "\t")
                .replace("\\n", "\n")
                .replace("\\r", "\r")
            
            val regex = java.util.regex.Pattern.compile("\\\\u([0-9a-fA-F]{4})")
            val matcher = regex.matcher(temp)
            val sb = java.lang.StringBuffer()
            while (matcher.find()) {
                val hexVal = matcher.group(1).toInt(16)
                matcher.appendReplacement(sb, java.util.regex.Matcher.quoteReplacement(hexVal.toChar().toString()))
            }
            matcher.appendTail(sb)
            sb.toString().replace("\\\"", "\"").replace("\\'", "'")
        } catch (e: Exception) {
            input
        }
    }

    suspend fun searchKeywords(
        context: Context,
        query: String,
        onLog: (String) -> Unit = {}
    ): List<SearchResult> = withContext(Dispatchers.IO) {
        val results = mutableListOf<SearchResult>()
        val cleanQuery = query.trim()
        val searchQuery = if (cleanQuery.startsWith("ytsearch", ignoreCase = true) || cleanQuery.startsWith("http://") || cleanQuery.startsWith("https://")) {
            cleanQuery
        } else {
            "ytsearch30:$cleanQuery"
        }
        onLog("🔍 Performing JNI YouTube search for: \"$searchQuery\"")
        try {
            init(context, onLog)
            if (!isInitialized) return@withContext emptyList()

            val request = YoutubeDLRequest(searchQuery).apply {
                addOption("--dump-json")
                addOption("--flat-playlist")
                // Rapid-search metadata optimizations
                addOption("--no-check-formats")
                addOption("--no-warnings")
                addOption("--no-check-certificate")
                addOption("--no-cache-dir")
                addOption("--socket-timeout", "10")
                addOption("--retries", "2")
                addOption("--geo-bypass")
                addOption("--force-ipv4")
                // Removed to fix 360p format restriction
                        // AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Mobile Safari/537.36")
                // 
            }

            try {
                onLog("📡 Executing Native search command...")
                val response = YoutubeDL.getInstance().execute(request, null)
                val stdout = response.out ?: ""
                if (stdout.isNotBlank()) {
                    val lines = stdout.split("\n").filter { it.isNotBlank() }
                    onLog("🧬 Found ${lines.size} potential JNI raw outputs. Parsing lines...")
                    for (line in lines) {
                        try {
                            val id = extractJsonField(line, "id") ?: continue
                            val title = unescapeJson(extractJsonField(line, "title") ?: "Untitled stream")
                            val uploader = unescapeJson(extractJsonField(line, "uploader") ?: extractJsonField(line, "channel") ?: "Unknown Source")
                            val durationStr = extractJsonField(line, "duration")
                            val durationInSeconds = durationStr?.toDoubleOrNull()?.toInt() ?: 0
                            val isShort = line.contains("/shorts/", ignoreCase = true) || title.contains("#shorts", ignoreCase = true) || title.contains("#short", ignoreCase = true)
                            val durationText = if (durationInSeconds > 0) {
                                val min = durationInSeconds / 60
                                val sec = durationInSeconds % 60
                                String.format(Locale.US, "%02d:%02d", min, sec)
                            } else if (isShort) {
                                "00:45"
                            } else {
                                "04:15"
                            }
                            val thumbUrl = extractJsonField(line, "thumbnail") ?: "https://img.youtube.com/vi/$id/hqdefault.jpg"
                            val originalUrl = "https://www.youtube.com/watch?v=$id"
                            results.add(
                                SearchResult(
                                    id = id,
                                    title = title,
                                    author = uploader,
                                    duration = durationText,
                                    thumbnailUrl = thumbUrl,
                                    originalUrl = originalUrl
                                )
                            )
                        } catch (e: Exception) {
                            // Ignored single line issue
                        }
                    }
                }
            } catch (e: Exception) {
                onLog("⚠️ Direct line search execute threw exception, trying old method: ${e.localizedMessage}")
            }

            if (results.isEmpty()) {
                onLog("⚠️ Custom parser got 0 results. Falling back to default getInfo parser...")
                val playlistInfo = YoutubeDL.getInstance().getInfo(request)
                if (playlistInfo != null) {
                    val entries = getEntries(playlistInfo)
                    if (!entries.isNullOrEmpty()) {
                        onLog("✅ Search returned ${entries.size} results from Native dynamic linker!")
                        for (entry in entries) {
                            val id = entry.id ?: continue
                            val title = entry.title ?: "Untitled stream"
                            val uploader = entry.uploader ?: "Unknown Source"
                            val durationInSeconds = entry.duration
                            val durationText = if (durationInSeconds > 0) {
                                val min = durationInSeconds / 60
                                val sec = durationInSeconds % 60
                                String.format(Locale.US, "%02d:%02d", min, sec)
                            } else {
                                "Adaptive"
                            }
                            val thumbUrl = entry.thumbnail ?: "https://img.youtube.com/vi/$id/hqdefault.jpg"
                            val originalUrl = "https://www.youtube.com/watch?v=$id"
                            results.add(
                                SearchResult(
                                    id = id,
                                    title = title,
                                    author = uploader,
                                    duration = durationText,
                                    thumbnailUrl = thumbUrl,
                                    originalUrl = originalUrl
                                )
                            )
                        }
                    } else {
                        onLog("⚠️ Entries are null. Falling back to single video detection.")
                        val id = playlistInfo.id
                        if (id != null) {
                            val title = playlistInfo.title ?: "Untitled search video"
                            val uploader = playlistInfo.uploader ?: "Unknown Creator"
                            val durationInSeconds = playlistInfo.duration
                            val durationText = if (durationInSeconds > 0) {
                                val min = durationInSeconds / 60
                                val sec = durationInSeconds % 60
                                String.format(Locale.US, "%02d:%02d", min, sec)
                            } else {
                                "Adaptive"
                            }
                            val thumbUrl = playlistInfo.thumbnail ?: "https://img.youtube.com/vi/$id/hqdefault.jpg"
                            val originalUrl = "https://www.youtube.com/watch?v=$id"
                            results.add(
                                SearchResult(
                                    id = id,
                                    title = title,
                                    author = uploader,
                                    duration = durationText,
                                    thumbnailUrl = thumbUrl,
                                    originalUrl = originalUrl
                                )
                            )
                        }
                    }
                }
            }
        } catch (e: Exception) {
            onLog("⚠️ Native keyword search threw exception: ${e.localizedMessage}")
        }
        return@withContext results
    }

    private fun extractYoutubeId(url: String): String? {
        val pattern = "(?i)(?:https?:\\/\\/)?(?:www\\.|m\\.)?(?:youtube\\.com\\/(?:watch\\?(?:.*&)?v=|embed\\/|shorts\\/)|youtu\\.be\\/)([a-zA-Z0-9_-]{11})"
        val matchResult = Regex(pattern).find(url)
        return matchResult?.groupValues?.get(1)
    }
}
