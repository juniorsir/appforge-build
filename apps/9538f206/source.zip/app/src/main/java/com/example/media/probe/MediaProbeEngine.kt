package com.example.media.probe

import android.content.Context
import android.net.Uri
import android.util.Log
import com.arthenica.ffmpegkit.FFprobeKit
import com.arthenica.ffmpegkit.ReturnCode
import com.example.media.ffmpeg.FFmpegEngine
import com.example.media.storage.MediaUriResolver
import com.example.media.storage.TemporaryMediaManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject

object MediaProbeEngine {
    private const val TAG = "MediaProbeEngine"

    suspend fun probeMedia(context: Context, uri: Uri): Result<MediaProbeInfo> = withContext(Dispatchers.IO) {
        FFmpegEngine.initialize()
        var resolvedSource: com.example.media.storage.ResolvedMediaSource? = null

        try {
            resolvedSource = MediaUriResolver.resolveUriForFFmpeg(context, uri, preferDirectSaf = true)
            val pathOrSaf = resolvedSource.pathOrSaf
            Log.d(TAG, "Probing media at: $pathOrSaf")

            val session = FFprobeKit.getMediaInformation(pathOrSaf)
            val returnCode = session.returnCode
            val mediaInfo = session.mediaInformation

            if (!ReturnCode.isSuccess(returnCode) || mediaInfo == null) {
                val errorMsg = session.failStackTrace ?: session.allLogsAsString ?: "FFprobe returned error code: ${returnCode?.value}"
                Log.e(TAG, "FFprobe inspection failed: $errorMsg")
                return@withContext Result.failure(IllegalStateException("FFprobe failed to inspect media: $errorMsg"))
            }

            val format = mediaInfo.format ?: "unknown"
            val formatLongName = mediaInfo.longFormat
            val durationSec = mediaInfo.duration?.toDoubleOrNull() ?: 0.0
            val durationMs = (durationSec * 1000.0).toLong()
            val sizeBytes = mediaInfo.size?.toLongOrNull() ?: resolvedSource.sizeBytes
            val overallBitrate = mediaInfo.bitrate?.toLongOrNull() ?: 0L

            val videoStreams = mutableListOf<VideoStreamInfo>()
            val audioStreams = mutableListOf<AudioStreamInfo>()
            val subtitleStreams = mutableListOf<SubtitleStreamInfo>()

            val streams = mediaInfo.streams ?: emptyList()
            for (stream in streams) {
                val type = stream.type?.lowercase()
                val index = stream.index?.toInt() ?: 0
                val codec = stream.codec ?: "unknown"
                val allProps = stream.allProperties
                val codecLong = allProps?.optString("codec_long_name") ?: stream.codec

                when (type) {
                    "video" -> {
                        val width = stream.width?.toInt() ?: 0
                        val height = stream.height?.toInt() ?: 0
                        val rFrameRate = stream.realFrameRate ?: stream.averageFrameRate ?: "0/1"
                        val fps = parseFpsFraction(rFrameRate)
                        val bitrate = stream.bitrate?.toLongOrNull() ?: 0L
                        val pixelFormat = allProps?.optString("pix_fmt")
                        val profile = allProps?.optString("profile")
                        val rotation = parseRotation(allProps)

                        videoStreams.add(
                            VideoStreamInfo(
                                index = index,
                                codec = codec,
                                codecLongName = codecLong,
                                profile = profile,
                                width = width,
                                height = height,
                                frameRate = fps,
                                bitrate = bitrate,
                                pixelFormat = pixelFormat,
                                rotation = rotation,
                                isDefault = allProps?.optJSONObject("disposition")?.optInt("default") == 1
                            )
                        )
                    }
                    "audio" -> {
                        val sampleRate = stream.sampleRate?.toIntOrNull() ?: 0
                        val channels = stream.allProperties?.optInt("channels") ?: 2
                        val channelLayout = stream.allProperties?.optString("channel_layout")
                        val bitrate = stream.bitrate?.toLongOrNull() ?: 0L
                        val tags = stream.allProperties?.optJSONObject("tags")
                        val lang = tags?.optString("language", "und") ?: "und"
                        val title = tags?.optString("title")

                        val disposition = stream.allProperties?.optJSONObject("disposition")
                        val isDefault = disposition?.optInt("default") == 1
                        val isForced = disposition?.optInt("forced") == 1

                        audioStreams.add(
                            AudioStreamInfo(
                                index = index,
                                codec = codec,
                                codecLongName = codecLong,
                                sampleRate = sampleRate,
                                channels = channels,
                                channelLayout = channelLayout,
                                bitrate = bitrate,
                                language = lang,
                                title = title,
                                isDefault = isDefault,
                                isForced = isForced
                            )
                        )
                    }
                    "subtitle" -> {
                        val tags = stream.allProperties?.optJSONObject("tags")
                        val lang = tags?.optString("language", "und") ?: "und"
                        val title = tags?.optString("title")
                        val disposition = stream.allProperties?.optJSONObject("disposition")
                        val isDefault = disposition?.optInt("default") == 1
                        val isForced = disposition?.optInt("forced") == 1

                        subtitleStreams.add(
                            SubtitleStreamInfo(
                                index = index,
                                codec = codec,
                                language = lang,
                                title = title,
                                isDefault = isDefault,
                                isForced = isForced
                            )
                        )
                    }
                }
            }

            val metadataTags = mutableMapOf<String, String>()
            val tagsObj = mediaInfo.allProperties?.optJSONObject("format")?.optJSONObject("tags")
            if (tagsObj != null) {
                val keys = tagsObj.keys()
                while (keys.hasNext()) {
                    val key = keys.next()
                    metadataTags[key] = tagsObj.optString(key)
                }
            }

            val probeInfo = MediaProbeInfo(
                pathOrUri = uri.toString(),
                format = format,
                formatLongName = formatLongName,
                durationMs = durationMs,
                sizeBytes = sizeBytes,
                overallBitrate = overallBitrate,
                videoStreams = videoStreams,
                audioStreams = audioStreams,
                subtitleStreams = subtitleStreams,
                metadataTags = metadataTags,
                rawProperties = mediaInfo.allProperties?.toString()
            )

            Log.i(TAG, "Successfully probed media: ${probeInfo.format}, ${videoStreams.size} video, ${audioStreams.size} audio")
            Result.success(probeInfo)
        } catch (e: Exception) {
            Log.e(TAG, "Exception during media probe: ${e.message}", e)
            Result.failure(e)
        } finally {
            if (resolvedSource?.isTemporaryFile == true) {
                TemporaryMediaManager.deleteSilently(resolvedSource.temporaryFile)
            }
        }
    }

    private fun parseFpsFraction(fraction: String): Float {
        return try {
            if (fraction.contains("/")) {
                val parts = fraction.split("/")
                val num = parts[0].toFloat()
                val den = parts[1].toFloat()
                if (den > 0) num / den else 0f
            } else {
                fraction.toFloat()
            }
        } catch (e: Exception) {
            0f
        }
    }

    private fun parseRotation(properties: JSONObject?): Int {
        if (properties == null) return 0
        try {
            val tags = properties.optJSONObject("tags")
            val rotate = tags?.optString("rotate")
            if (!rotate.isNullOrBlank()) {
                return rotate.toIntOrNull() ?: 0
            }
            val sideData = properties.optJSONArray("side_data_list")
            if (sideData != null) {
                for (i in 0 until sideData.length()) {
                    val item = sideData.optJSONObject(i)
                    val rotation = item?.optInt("rotation")
                    if (rotation != null && rotation != 0) return rotation
                }
            }
        } catch (_: Exception) {}
        return 0
    }
}
