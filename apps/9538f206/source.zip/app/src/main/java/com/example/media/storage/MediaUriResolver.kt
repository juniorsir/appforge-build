package com.example.media.storage

import android.content.Context
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import android.util.Log
import com.arthenica.ffmpegkit.FFmpegKitConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

data class ResolvedMediaSource(
    val pathOrSaf: String,
    val isTemporaryFile: Boolean,
    val temporaryFile: File? = null,
    val displayName: String? = null,
    val sizeBytes: Long = 0L
)

object MediaUriResolver {
    private const val TAG = "MediaUriResolver"

    suspend fun resolveUriForFFmpeg(
        context: Context,
        uri: Uri,
        preferDirectSaf: Boolean = true
    ): ResolvedMediaSource = withContext(Dispatchers.IO) {
        val scheme = uri.scheme?.lowercase()
        Log.d(TAG, "Resolving Uri: $uri (scheme=$scheme)")

        // 1. Direct file:// or raw filesystem path
        if (scheme == "file" || scheme == null) {
            val path = uri.path ?: uri.toString()
            val file = File(path)
            if (file.exists()) {
                return@withContext ResolvedMediaSource(
                    pathOrSaf = file.absolutePath,
                    isTemporaryFile = false,
                    displayName = file.name,
                    sizeBytes = file.length()
                )
            }
        }

        // 2. Direct string check for absolute path
        val rawString = uri.toString()
        if (rawString.startsWith("/")) {
            val file = File(rawString)
            if (file.exists()) {
                return@withContext ResolvedMediaSource(
                    pathOrSaf = file.absolutePath,
                    isTemporaryFile = false,
                    displayName = file.name,
                    sizeBytes = file.length()
                )
            }
        }

        // 3. SAF Direct Pipe if requested and supported by FFmpegKit
        if (preferDirectSaf && scheme == "content") {
            try {
                val safPath = FFmpegKitConfig.getSafParameter(context, uri, "r")
                if (!safPath.isNullOrBlank()) {
                    var size = 0L
                    var name: String? = null
                    context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                        val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                        val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        if (cursor.moveToFirst()) {
                            if (sizeIndex != -1) size = cursor.getLong(sizeIndex)
                            if (nameIndex != -1) name = cursor.getString(nameIndex)
                        }
                    }
                    return@withContext ResolvedMediaSource(
                        pathOrSaf = safPath,
                        isTemporaryFile = false,
                        displayName = name,
                        sizeBytes = size
                    )
                }
            } catch (e: Exception) {
                Log.w(TAG, "FFmpegKit SAF direct path mapping failed, falling back to temp file copy: ${e.message}")
            }
        }

        // 4. ContentResolver fallback: stream content into a temporary cache file
        val extension = getFileExtensionFromUri(context, uri) ?: "mp4"
        val tempFile = TemporaryMediaManager.createTempFile(context, "input_", extension)
        var totalBytes = 0L
        var displayName: String? = null

        try {
            context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (cursor.moveToFirst() && nameIndex != -1) {
                    displayName = cursor.getString(nameIndex)
                }
            }

            context.contentResolver.openInputStream(uri)?.use { inputStream ->
                FileOutputStream(tempFile).use { outputStream ->
                    val buffer = ByteArray(64 * 1024)
                    var read: Int
                    while (inputStream.read(buffer).also { read = it } != -1) {
                        outputStream.write(buffer, 0, read)
                        totalBytes += read
                    }
                    outputStream.flush()
                }
            }

            Log.d(TAG, "Cached Content Uri into temp file: ${tempFile.absolutePath} ($totalBytes bytes)")
            ResolvedMediaSource(
                pathOrSaf = tempFile.absolutePath,
                isTemporaryFile = true,
                temporaryFile = tempFile,
                displayName = displayName ?: tempFile.name,
                sizeBytes = totalBytes
            )
        } catch (e: Exception) {
            TemporaryMediaManager.deleteSilently(tempFile)
            Log.e(TAG, "Failed to cache Uri content to temp file: ${e.message}", e)
            throw e
        }
    }

    private fun getFileExtensionFromUri(context: Context, uri: Uri): String? {
        val mimeType = context.contentResolver.getType(uri)
        if (mimeType != null) {
            val extension = android.webkit.MimeTypeMap.getSingleton().getExtensionFromMimeType(mimeType)
            if (!extension.isNullOrBlank()) return extension
        }
        val path = uri.path ?: return null
        return if (path.contains(".")) path.substringAfterLast('.') else null
    }
}
