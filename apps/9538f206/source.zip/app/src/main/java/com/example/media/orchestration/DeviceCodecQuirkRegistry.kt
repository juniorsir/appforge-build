package com.example.media.orchestration

import android.os.Build
import java.util.Locale

enum class QuirkAction {
    FORCE_SOFTWARE_FALLBACK,
    DISABLE_HARDWARE_DECODER,
    PREFER_EXTENSION_RENDERER,
    DISABLE_TUNNELING,
    REDUCE_MAX_RESOLUTION
}

data class DeviceCodecQuirkRule(
    val id: String,
    val manufacturer: String? = null,
    val modelPattern: String? = null,
    val devicePattern: String? = null,
    val hardwarePattern: String? = null,
    val minApi: Int = 0,
    val maxApi: Int = Int.MAX_VALUE,
    val codecNamePattern: String? = null,
    val mimeTypePattern: String? = null,
    val action: QuirkAction,
    val reason: String
) {
    fun matchesDevice(): Boolean {
        if (Build.VERSION.SDK_INT < minApi || Build.VERSION.SDK_INT > maxApi) {
            return false
        }
        if (manufacturer != null) {
            val currentMfg = (Build.MANUFACTURER ?: "").lowercase(Locale.US)
            if (!currentMfg.contains(manufacturer.lowercase(Locale.US))) return false
        }
        if (modelPattern != null) {
            val currentModel = (Build.MODEL ?: "").lowercase(Locale.US)
            if (!currentModel.contains(modelPattern.lowercase(Locale.US)) &&
                !Regex(modelPattern, RegexOption.IGNORE_CASE).containsMatchIn(currentModel)) {
                return false
            }
        }
        if (devicePattern != null) {
            val currentDevice = (Build.DEVICE ?: "").lowercase(Locale.US)
            if (!currentDevice.contains(devicePattern.lowercase(Locale.US)) &&
                !Regex(devicePattern, RegexOption.IGNORE_CASE).containsMatchIn(currentDevice)) {
                return false
            }
        }
        if (hardwarePattern != null) {
            val currentHw = (Build.HARDWARE ?: "").lowercase(Locale.US)
            if (!currentHw.contains(hardwarePattern.lowercase(Locale.US)) &&
                !Regex(hardwarePattern, RegexOption.IGNORE_CASE).containsMatchIn(currentHw)) {
                return false
            }
        }
        return true
    }

    fun matchesCodec(codecName: String, mimeType: String): Boolean {
        if (!matchesDevice()) return false

        if (codecNamePattern != null) {
            val lowerCodec = codecName.lowercase(Locale.US)
            val lowerPattern = codecNamePattern.lowercase(Locale.US)
            if (!lowerCodec.contains(lowerPattern) &&
                !Regex(codecNamePattern, RegexOption.IGNORE_CASE).containsMatchIn(codecName)) {
                return false
            }
        }

        if (mimeTypePattern != null) {
            val lowerMime = mimeType.lowercase(Locale.US)
            val lowerPattern = mimeTypePattern.lowercase(Locale.US)
            if (!lowerMime.contains(lowerPattern) &&
                !Regex(mimeTypePattern, RegexOption.IGNORE_CASE).containsMatchIn(mimeType)) {
                return false
            }
        }

        return true
    }
}

object DeviceCodecQuirkRegistry {

    private val rules = mutableListOf<DeviceCodecQuirkRule>(
        // 1. Samsung Exynos 7 Series (7870 / 7420) HW HEVC Green Screen / Crash
        DeviceCodecQuirkRule(
            id = "SAMSUNG_EXYNOS_7_HEVC_BUG",
            manufacturer = "samsung",
            hardwarePattern = "exynos7870|exynos7420|universal7870|universal7420",
            maxApi = 27,
            codecNamePattern = "OMX.Exynos.HEVC.Decoder",
            mimeTypePattern = "video/hevc",
            action = QuirkAction.FORCE_SOFTWARE_FALLBACK,
            reason = "Exynos 7 series HW HEVC decoder crashes / causes green screen on Android 8.0 and lower"
        ),
        // 2. Samsung Exynos 8890 Frame Drop & Stutter
        DeviceCodecQuirkRule(
            id = "SAMSUNG_EXYNOS_8890_AVC_STUTTER",
            manufacturer = "samsung",
            hardwarePattern = "exynos8890|universal8890",
            maxApi = 28,
            codecNamePattern = "OMX.Exynos.AVC.Decoder",
            mimeTypePattern = "video/avc",
            action = QuirkAction.PREFER_EXTENSION_RENDERER,
            reason = "Exynos 8890 HW AVC decoder causes severe stuttering on 1080p60 content"
        ),
        // 3. Qualcomm Snapdragon 810/801/615 HW HEVC Surface Detachment Crash
        DeviceCodecQuirkRule(
            id = "QUALCOMM_MSM8994_HEVC_CRASH",
            hardwarePattern = "msm8994|msm8974|msm8939|qcom",
            codecNamePattern = "OMX.qcom.video.decoder.hevc",
            mimeTypePattern = "video/hevc",
            action = QuirkAction.DISABLE_HARDWARE_DECODER,
            reason = "Legacy Snapdragon HW HEVC decoder surface allocation crashes"
        ),
        // 4. MediaTek Legacy 32-bit SoC HEVC Hardware Freeze
        DeviceCodecQuirkRule(
            id = "MEDIATEK_LEGACY_HEVC_FREEZE",
            hardwarePattern = "mt6735|mt6737|mt6753|mt6580",
            codecNamePattern = "OMX.MTK.VIDEO.DECODER.HEVC",
            mimeTypePattern = "video/hevc",
            action = QuirkAction.FORCE_SOFTWARE_FALLBACK,
            reason = "MediaTek 32-bit legacy SoC hardware decoder freezes on HEVC streams"
        ),
        // 5. HiSilicon Kirin 650/950 HW VP9 Visual Corruption
        DeviceCodecQuirkRule(
            id = "KIRIN_HW_VP9_CORRUPTION",
            hardwarePattern = "hi6250|hi3650|hi3660|kirin",
            codecNamePattern = "OMX.hisi.video.decoder.hw",
            mimeTypePattern = "video/x-vnd.on2.vp9",
            action = QuirkAction.FORCE_SOFTWARE_FALLBACK,
            reason = "HiSilicon Kirin HW VP9 decoder visual corruption and buffer timeout"
        ),
        // 6. Rockchip RK3128/3288/3399 Decoder Instability
        DeviceCodecQuirkRule(
            id = "ROCKCHIP_HW_DECODER_UNSTABLE",
            hardwarePattern = "rk3128|rk3288|rk3399|rockchip",
            codecNamePattern = "OMX.rk.video_decoder",
            action = QuirkAction.DISABLE_HARDWARE_DECODER,
            reason = "Rockchip hardware video decoder instability during surface re-creation"
        ),
        // 7. Amlogic Awesome Decoder Audio/Video Tunneling Desync
        DeviceCodecQuirkRule(
            id = "AMLOGIC_AWESOME_TUNNELING_BUG",
            hardwarePattern = "gxl|g12a|amlogic",
            codecNamePattern = "OMX.amlogic.avc.decoder.awesome|OMX.amlogic.hevc.decoder.awesome",
            action = QuirkAction.DISABLE_TUNNELING,
            reason = "Amlogic awesome decoder tunneling desync"
        ),
        // 8. Qualcomm C2 Low Latency Decoder Surface Detachment Crash (MIUI/HyperOS)
        DeviceCodecQuirkRule(
            id = "QUALCOMM_C2_LOW_LATENCY_CRASH",
            codecNamePattern = "c2.qti.avc.decoder.low_latency|c2.qti.hevc.decoder.low_latency",
            action = QuirkAction.DISABLE_HARDWARE_DECODER,
            reason = "Qualcomm low-latency C2 decoder surface detachment crash"
        ),
        // 9. Unisoc / Spreadtrum HW AV1 & HEVC Intermittent Init Failure
        DeviceCodecQuirkRule(
            id = "UNISOC_SPRD_HW_INIT_FAIL",
            hardwarePattern = "sprd|unisoc|sc9863a|sc9832e|ums512",
            codecNamePattern = "c2.sprd.|OMX.sprd.",
            action = QuirkAction.FORCE_SOFTWARE_FALLBACK,
            reason = "Unisoc hardware decoder initialization failure and surface state corruption"
        ),
        // 10. Broadcom BCM Hardware AVC/HEVC Decoder Quirk
        DeviceCodecQuirkRule(
            id = "BROADCOM_HW_DECODER_QUIRK",
            hardwarePattern = "bcm2835|bcm2836|bcm2837|bcm2711|broadcom",
            codecNamePattern = "OMX.bcm.video_decoder",
            action = QuirkAction.DISABLE_HARDWARE_DECODER,
            reason = "Broadcom hardware video decoder surface allocation failure"
        ),
        // 11. MediaTek C2 Hardware Decoder Intermittent Init/Flush Failure
        DeviceCodecQuirkRule(
            id = "MEDIATEK_C2_HW_INIT_FAIL",
            hardwarePattern = "mt6873|mt6885|mt6893|mt6877|mt6983|mt8788|mt8183",
            codecNamePattern = "c2.mtk.avc.decoder|c2.mtk.hevc.decoder|OMX.MTK.VIDEO.DECODER.AVC",
            action = QuirkAction.FORCE_SOFTWARE_FALLBACK,
            reason = "MediaTek C2 hardware decoder initialization timeout and frame freezing"
        ),
        // 12. Exynos 9 Series (9810/9820/990) C2 Hardware HEVC/AV1 Initialization Failure
        DeviceCodecQuirkRule(
            id = "EXYNOS_C2_HW_INIT_FAIL",
            manufacturer = "samsung",
            hardwarePattern = "exynos9810|exynos9820|exynos9825|exynos990|exynos2100",
            codecNamePattern = "c2.exynos.hevc.decoder|c2.exynos.av1.decoder",
            action = QuirkAction.FORCE_SOFTWARE_FALLBACK,
            reason = "Exynos C2 hardware HEVC/AV1 decoder initialization instability"
        )
    )

    fun getMatchingQuirks(codecName: String, mimeType: String): List<DeviceCodecQuirkRule> {
        return rules.filter { it.matchesCodec(codecName, mimeType) }
    }

    fun getAllMatchingQuirksForDevice(): List<DeviceCodecQuirkRule> {
        return rules.filter { it.matchesDevice() }
    }

    fun shouldProactivelyDisableHardware(codecName: String, mimeType: String): Boolean {
        val quirks = getMatchingQuirks(codecName, mimeType)
        return quirks.any { it.action == QuirkAction.DISABLE_HARDWARE_DECODER || it.action == QuirkAction.FORCE_SOFTWARE_FALLBACK }
    }

    fun shouldPreferExtension(codecName: String, mimeType: String): Boolean {
        val quirks = getMatchingQuirks(codecName, mimeType)
        return quirks.any { it.action == QuirkAction.PREFER_EXTENSION_RENDERER }
    }

    fun shouldDisableTunneling(codecName: String, mimeType: String): Boolean {
        val quirks = getMatchingQuirks(codecName, mimeType)
        return quirks.any { it.action == QuirkAction.DISABLE_TUNNELING }
    }

    fun addCustomRule(rule: DeviceCodecQuirkRule) {
        rules.add(rule)
    }
}
