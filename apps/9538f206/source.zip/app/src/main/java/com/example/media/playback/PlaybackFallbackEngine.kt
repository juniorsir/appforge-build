package com.example.media.playback

import android.content.Context
import android.net.Uri
import android.util.Log
import com.example.media.DecoderCapabilityManager
import com.example.media.probe.MediaProbeEngine
import com.example.media.probe.MediaProbeInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object PlaybackFallbackEngine {
    private const val TAG = "PlaybackFallbackEngine"

    suspend fun evaluatePlaybackStrategy(context: Context, uri: Uri): PlaybackCompatibilityResult = withContext(Dispatchers.IO) {
        com.example.media.preview.FrpPreviewEngine.setActivePlaybackSource(uri, uri.path)
        val probeResult = MediaProbeEngine.probeMedia(context, uri)
        if (probeResult.isFailure) {
            return@withContext PlaybackCompatibilityResult(
                strategy = PlaybackStrategy.DIRECT_HARDWARE,
                reason = "Probe skipped; attempting default ExoPlayer hardware playback",
                containerFormat = "unknown",
                videoCodec = "unknown",
                audioCodec = "unknown"
            )
        }

        val probeInfo = probeResult.getOrThrow()
        val format = probeInfo.format.lowercase()
        val video = probeInfo.primaryVideo
        val audio = probeInfo.primaryAudio

        val videoCodec = video?.codec?.lowercase() ?: "none"
        val audioCodec = audio?.codec?.lowercase() ?: "none"

        Log.d(TAG, "Evaluating playback: format=$format, video=$videoCodec, audio=$audioCodec")

        // 1. Check if container is natively friendly to ExoPlayer/Media3 (mp4, m4v, mov, mkv, webm, mp3, aac, ts)
        val isStandardContainer = format.contains("mp4") ||
                format.contains("matroska") ||
                format.contains("webm") ||
                format.contains("mov") ||
                format.contains("mp3") ||
                format.contains("aac") ||
                format.contains("ogg") ||
                format.contains("flac") ||
                format.contains("mpegts")

        // 2. Check if video codec is supported by Android MediaCodec hardware
        val isStandardVideoCodec = videoCodec in setOf("h264", "avc1", "hevc", "h265", "vp8", "vp9", "av01", "av1", "none")
        val isStandardAudioCodec = audioCodec in setOf("aac", "mp3", "opus", "vorbis", "flac", "pcm_s16le", "pcm_s24le", "alac", "none")

        if (isStandardContainer && isStandardVideoCodec && isStandardAudioCodec) {
            return@withContext PlaybackCompatibilityResult(
                strategy = PlaybackStrategy.DIRECT_HARDWARE,
                reason = "Hardware acceleration available for container and codecs",
                containerFormat = format,
                videoCodec = videoCodec,
                audioCodec = audioCodec
            )
        }

        // 3. If video & audio codecs are standard but container is problematic (e.g. AVI, WMV, FLV) -> Fast Remux!
        if (isStandardVideoCodec && isStandardAudioCodec) {
            return@withContext PlaybackCompatibilityResult(
                strategy = PlaybackStrategy.REMUX_REQUIRED,
                reason = "Codecs are hardware-compatible; remuxing to MP4 container for instant hardware playback",
                containerFormat = format,
                videoCodec = videoCodec,
                audioCodec = audioCodec,
                requiresRemux = true
            )
        }

        // 4. Otherwise, transcoding is needed
        return@withContext PlaybackCompatibilityResult(
            strategy = PlaybackStrategy.TRANSCODE_REQUIRED,
            reason = "Unsupported codec ($videoCodec / $audioCodec); transcoding to standard H.264/AAC for playback",
            containerFormat = format,
            videoCodec = videoCodec,
            audioCodec = audioCodec,
            requiresTranscode = true
        )
    }
}
