package com.example.ui

import android.app.Application
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlin.coroutines.CoroutineContext
import kotlin.coroutines.EmptyCoroutineContext

/**
 * Base ViewModel class that provides a global CoroutineExceptionHandler to catch
 * and log uncaught coroutine exceptions, preventing application crashes.
 */
abstract class BaseViewModel : ViewModel() {

    protected val tag: String = this::class.java.simpleName

    /**
     * Global CoroutineExceptionHandler catching any uncaught exceptions thrown in coroutine builders.
     */
    val coroutineExceptionHandler = CoroutineExceptionHandler { coroutineContext, throwable ->
        Log.e(tag, "Uncaught coroutine exception in $tag on context $coroutineContext", throwable)
        onCoroutineException(coroutineContext, throwable)
    }

    /**
     * Hook for subclasses to handle uncaught exceptions (e.g. log errors, update UI error states).
     */
    protected open fun onCoroutineException(context: CoroutineContext, throwable: Throwable) {
        // Base logging handled; subclasses can override for custom handling
    }

    /**
     * Safely launches a coroutine tied to [viewModelScope] with the default [coroutineExceptionHandler].
     */
    fun safeLaunch(
        context: CoroutineContext = EmptyCoroutineContext,
        block: suspend CoroutineScope.() -> Unit
    ): Job {
        return viewModelScope.launch(context + coroutineExceptionHandler) {
            block()
        }
    }

    /**
     * Safely launches an IO coroutine tied to [viewModelScope] with the default [coroutineExceptionHandler].
     */
    fun safeLaunchIo(
        block: suspend CoroutineScope.() -> Unit
    ): Job {
        return viewModelScope.launch(Dispatchers.IO + coroutineExceptionHandler) {
            block()
        }
    }
}

/**
 * Base AndroidViewModel class providing global CoroutineExceptionHandler capabilities.
 */
abstract class BaseAndroidViewModel(application: Application) : AndroidViewModel(application) {

    protected val tag: String = this::class.java.simpleName

    /**
     * Global CoroutineExceptionHandler catching any uncaught exceptions thrown in coroutine builders.
     */
    val coroutineExceptionHandler = CoroutineExceptionHandler { coroutineContext, throwable ->
        Log.e(tag, "Uncaught coroutine exception in $tag on context $coroutineContext", throwable)
        onCoroutineException(coroutineContext, throwable)
    }

    /**
     * Hook for subclasses to handle uncaught exceptions (e.g. log errors, update UI error states).
     */
    protected open fun onCoroutineException(context: CoroutineContext, throwable: Throwable) {
        // Base logging handled; subclasses can override for custom handling
    }

    /**
     * Safely launches a coroutine tied to [viewModelScope] with the default [coroutineExceptionHandler].
     */
    fun safeLaunch(
        context: CoroutineContext = EmptyCoroutineContext,
        block: suspend CoroutineScope.() -> Unit
    ): Job {
        return viewModelScope.launch(context + coroutineExceptionHandler) {
            block()
        }
    }

    /**
     * Safely launches an IO coroutine tied to [viewModelScope] with the default [coroutineExceptionHandler].
     */
    fun safeLaunchIo(
        block: suspend CoroutineScope.() -> Unit
    ): Job {
        return viewModelScope.launch(Dispatchers.IO + coroutineExceptionHandler) {
            block()
        }
    }
}
