package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "media_markers")
data class MediaMarkerEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val mediaId: String,
    val positionMs: Long,
    val note: String,
    val createdAt: Long = System.currentTimeMillis()
)
