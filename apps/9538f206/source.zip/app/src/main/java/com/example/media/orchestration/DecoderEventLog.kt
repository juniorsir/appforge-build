package com.example.media.orchestration

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class DecoderEvent(
    val timestampMs: Long = System.currentTimeMillis(),
    val category: String,
    val message: String,
    val decoderName: String? = null,
    val mimeType: String? = null
)

class BoundedDecoderEventLog(private val maxEntries: Int = 100) {
    private val events = mutableListOf<DecoderEvent>()
    private val dateFormat = SimpleDateFormat("HH:mm:ss.SSS", Locale.US)

    @Synchronized
    fun logEvent(category: String, message: String, decoderName: String? = null, mimeType: String? = null) {
        if (events.size >= maxEntries) {
            events.removeAt(0)
        }
        events.add(DecoderEvent(category = category, message = message, decoderName = decoderName, mimeType = mimeType))
    }

    @Synchronized
    fun getEvents(): List<DecoderEvent> {
        return events.toList()
    }

    @Synchronized
    fun clear() {
        events.clear()
    }

    @Synchronized
    fun formatFormattedLog(): String {
        if (events.isEmpty()) return "No decoder events recorded."
        val sb = StringBuilder()
        sb.appendLine("=== BOUNDED DECODER EVENT LOG (Max $maxEntries) ===")
        for (event in events) {
            val timeStr = dateFormat.format(Date(event.timestampMs))
            val decStr = if (event.decoderName != null) " [${event.decoderName}]" else ""
            val mimeStr = if (event.mimeType != null) " ($event.mimeType)" else ""
            sb.appendLine("$timeStr [${event.category}]$decStr$mimeStr: ${event.message}")
        }
        return sb.toString().trimEnd()
    }
}
