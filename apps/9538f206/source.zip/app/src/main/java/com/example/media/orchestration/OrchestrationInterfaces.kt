package com.example.media.orchestration

import com.example.media.DecoderSelection

interface AudioDecoderManager {
    fun getDecoderCandidates(mimeType: String, channels: Int, sampleRate: Int): List<DecoderCandidate>
    fun selectBestDecoder(candidates: List<DecoderCandidate>): DecoderSelection
}

interface VideoDecoderManager {
    fun getDecoderCandidates(mimeType: String, width: Int, height: Int, fps: Float = -1f, bitDepth: Int = 8): List<DecoderCandidate>
    fun selectBestDecoder(candidates: List<DecoderCandidate>): DecoderSelection
}

interface SubtitleManager {
    fun getRendererCandidates(mimeType: String): List<DecoderCandidate>
    fun selectBestRenderer(candidates: List<DecoderCandidate>): DecoderSelection
}

interface DecoderFailureManager {
    fun classifyFailure(cause: Throwable): DecoderFailureType
    fun recordFailure(decoderName: String?, mimeType: String, failureType: DecoderFailureType, cause: Throwable)
    fun getFailedDecoders(mimeType: String): List<String>
    fun clearFailures()
}
