package com.example.media

import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong

data class PlaybackPerformanceProfile(
    var videoDecoderMode: String = "AUTO",
    var audioDecoderMode: String = "AUTO",
    var activeVideoDecoder: String = "Unknown",
    var activeAudioDecoder: String = "Unknown",
    var startupTimeMs: Long = 0L,
    var decoderInitTimeMs: Long = 0L,
    var bufferDurationMs: Long = 0L,
    var avDriftMs: Float = 0f,
    val renderedFrames: AtomicInteger = AtomicInteger(0),
    val droppedFrames: AtomicInteger = AtomicInteger(0),
    val audioUnderruns: AtomicInteger = AtomicInteger(0),
    val fallbackCount: AtomicInteger = AtomicInteger(0)
) {
    fun formatDiagnosticSummary(): String {
        val rFrames = renderedFrames.get()
        val dFrames = droppedFrames.get()
        val underruns = audioUnderruns.get()
        val fallbacks = fallbackCount.get()
        val dropRatio = if (rFrames + dFrames > 0) (dFrames.toFloat() / (rFrames + dFrames) * 100) else 0f

        return """
            PLAYBACK PERFORMANCE PROFILE
            ------------------------------------------
            Video Decoder: $activeVideoDecoder (Mode: $videoDecoderMode)
            Audio Decoder: $activeAudioDecoder (Mode: $audioDecoderMode)
            Startup Latency: ${startupTimeMs}ms
            Decoder Init Latency: ${decoderInitTimeMs}ms
            Buffer Duration: ${bufferDurationMs / 1000f}s
            A/V Drift: ${String.format("%.1f", avDriftMs)}ms
            Rendered Frames: $rFrames
            Dropped Frames: $dFrames (${String.format("%.2f", dropRatio)}%)
            Audio Underruns: $underruns
            Decoder Fallback Events: $fallbacks
        """.trimIndent()
    }
}
