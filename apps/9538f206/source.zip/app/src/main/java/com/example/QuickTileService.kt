package com.example

import android.app.PendingIntent
import android.content.Intent
import android.service.quicksettings.TileService
import android.os.Build
import androidx.annotation.RequiresApi

@RequiresApi(Build.VERSION_CODES.N)
class QuickTileService : TileService() {

    override fun onStartListening() {
        super.onStartListening()
        val tile = qsTile ?: return
        tile.state = if (FloatingBubbleService.isRunning) {
            android.service.quicksettings.Tile.STATE_ACTIVE
        } else {
            android.service.quicksettings.Tile.STATE_INACTIVE
        }
        tile.updateTile()
    }

    override fun onClick() {
        super.onClick()
        
        val hasPermission = FloatingBubbleService.canDrawOverlaysSafe(this)

        if (hasPermission) {
            val serviceIntent = Intent(this, FloatingBubbleService::class.java)
            if (FloatingBubbleService.isRunning) {
                stopService(serviceIntent)
                qsTile.state = android.service.quicksettings.Tile.STATE_INACTIVE
            } else {
                startService(serviceIntent)
                qsTile.state = android.service.quicksettings.Tile.STATE_ACTIVE
            }
            qsTile.updateTile()
        } else {
            val intent = Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                putExtra("launch_floating_widget", true)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                val pendingIntent = PendingIntent.getActivity(
                    this,
                    0,
                    intent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                startActivityAndCollapse(pendingIntent)
            } else {
                @Suppress("DEPRECATION")
                startActivityAndCollapse(intent)
            }
        }
    }
}
