package com.example.ui

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.util.TypedValue
import android.view.MotionEvent
import android.view.VelocityTracker
import android.view.View
import android.view.ViewConfiguration
import android.view.animation.DecelerateInterpolator
import kotlin.math.cos
import kotlin.math.sin

class ThreeDClockRollerView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    private var items = emptyList<String>()
    private var selectedIndex = 0
    private var onItemSelected: ((Int) -> Unit)? = null

    private var itemHeight = dpToPx(36f)
    private var scrollYValue = 0f

    private var lastTouchY = 0f
    private var isDragging = false
    private val touchSlop = ViewConfiguration.get(context).scaledTouchSlop

    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
    }

    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#33FFD700") // Elegant semi-transparent gold
        strokeWidth = dpToPx(1f)
    }

    private var animator: ValueAnimator? = null
    private var velocityTracker: VelocityTracker? = null
    private val maxFlingVelocity = ViewConfiguration.get(context).scaledMaximumFlingVelocity
    private val minFlingVelocity = ViewConfiguration.get(context).scaledMinimumFlingVelocity

    init {
        isClickable = true
        isFocusable = true
    }

    fun setItems(newItems: List<String>, initialIndex: Int = 0) {
        items = newItems
        selectedIndex = initialIndex.coerceIn(0, maxOf(0, items.size - 1))
        scrollYValue = selectedIndex * itemHeight
        invalidate()
    }

    fun setOnItemSelectedListener(listener: (Int) -> Unit) {
        onItemSelected = listener
    }

    fun getSelectedIndex(): Int = selectedIndex

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val defaultHeight = dpToPx(100f).toInt()
        val defaultWidth = dpToPx(140f).toInt()

        val width = resolveSize(defaultWidth, widthMeasureSpec)
        val height = resolveSize(defaultHeight, heightMeasureSpec)
        setMeasuredDimension(width, height)
    }

    override fun onDraw(canvas: Canvas) {
        if (items.isEmpty()) return

        val centerY = height / 2f
        val centerX = width / 2f
        val maxOffset = height / 2f

        // Draw selector highlight lines
        canvas.drawLine(0f, centerY - itemHeight / 2f, width.toFloat(), centerY - itemHeight / 2f, linePaint)
        canvas.drawLine(0f, centerY + itemHeight / 2f, width.toFloat(), centerY + itemHeight / 2f, linePaint)

        val halfPI = Math.PI / 2.0

        for (i in items.indices) {
            val itemCenterY = i * itemHeight
            val offsetY = itemCenterY - scrollYValue

            // Skip items that are too far
            if (Math.abs(offsetY) > maxOffset * 1.5f) continue

            // Angle on the cylinder
            val angle = (offsetY / maxOffset) * halfPI

            if (angle < -halfPI || angle > halfPI) continue

            // Projected Y
            val projectedY = centerY + sin(angle).toFloat() * (height / 2f) * 0.85f
            val scale = cos(angle).toFloat()

            // Styling based on index
            val isCurrent = i == selectedIndex
            if (isCurrent) {
                textPaint.color = Color.parseColor("#FFD700") // Gold accent for selected
                textPaint.textSize = dpToPx(15f) * (0.85f + 0.25f * scale)
                textPaint.typeface = android.graphics.Typeface.create(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD)
                textPaint.alpha = 255
            } else {
                textPaint.color = Color.parseColor("#A8A8A8")
                textPaint.textSize = dpToPx(12f) * (0.85f + 0.15f * scale)
                textPaint.typeface = android.graphics.Typeface.DEFAULT
                textPaint.alpha = (160 * scale).toInt().coerceIn(0, 255)
            }

            val text = items[i]
            val baseline = projectedY - (textPaint.descent() + textPaint.ascent()) / 2f
            canvas.drawText(text, centerX, baseline, textPaint)
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (items.isEmpty()) return false

        if (velocityTracker == null) {
            velocityTracker = VelocityTracker.obtain()
        }
        velocityTracker?.addMovement(event)

        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                animator?.cancel()
                lastTouchY = event.y
                isDragging = false
            }
            MotionEvent.ACTION_MOVE -> {
                val deltaY = lastTouchY - event.y
                if (!isDragging && Math.abs(deltaY) > touchSlop) {
                    isDragging = true
                }
                if (isDragging) {
                    scrollYValue += deltaY
                    val maxScroll = (items.size - 1) * itemHeight
                    scrollYValue = scrollYValue.coerceIn(-itemHeight * 0.5f, maxScroll + itemHeight * 0.5f)
                    lastTouchY = event.y
                    
                    val rawIndex = Math.round(scrollYValue / itemHeight)
                    selectedIndex = rawIndex.coerceIn(0, items.size - 1)
                    
                    invalidate()
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (isDragging) {
                    velocityTracker?.computeCurrentVelocity(1000, maxFlingVelocity.toFloat())
                    val velocityY = velocityTracker?.yVelocity ?: 0f
                    
                    if (Math.abs(velocityY) > minFlingVelocity) {
                        val flingDistance = -velocityY * 0.15f
                        val targetScrollY = (scrollYValue + flingDistance).coerceIn(0f, ((items.size - 1) * itemHeight))
                        val targetIndex = Math.round(targetScrollY / itemHeight).coerceIn(0, items.size - 1)
                        animateToItem(targetIndex)
                    } else {
                        val targetIndex = Math.round(scrollYValue / itemHeight).coerceIn(0, items.size - 1)
                        animateToItem(targetIndex)
                    }
                } else {
                    val clickY = event.y
                    val centerY = height / 2f
                    val clickedRowOffset = Math.round((clickY - centerY) / itemHeight)
                    val targetIndex = (selectedIndex + clickedRowOffset).coerceIn(0, items.size - 1)
                    animateToItem(targetIndex)
                }
                velocityTracker?.recycle()
                velocityTracker = null
                isDragging = false
            }
        }
        return true
    }

    private fun animateToItem(index: Int) {
        animator?.cancel()
        val startScroll = scrollYValue
        val endScroll = index * itemHeight
        
        animator = ValueAnimator.ofFloat(startScroll, endScroll).apply {
            duration = 220
            interpolator = DecelerateInterpolator()
            addUpdateListener { animation ->
                scrollYValue = animation.animatedValue as Float
                val rawIndex = Math.round(scrollYValue / itemHeight)
                selectedIndex = rawIndex.coerceIn(0, items.size - 1)
                invalidate()
            }
            addListener(object : android.animation.AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: android.animation.Animator) {
                    selectedIndex = index
                    scrollYValue = index * itemHeight
                    invalidate()
                    onItemSelected?.invoke(selectedIndex)
                }
            })
            start()
        }
    }

    private fun dpToPx(dp: Float): Float {
        return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp, resources.displayMetrics)
    }
}
