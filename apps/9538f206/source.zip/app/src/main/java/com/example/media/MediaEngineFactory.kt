package com.example.media

import android.content.Context

object MediaEngineFactory {
    fun create(context: Context): MediaEngine {
        return DefaultMediaEngine(context.applicationContext)
    }
}
