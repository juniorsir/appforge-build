package com.example.media.orchestration

import com.example.media.DecoderCapabilityManager
import com.example.media.DecoderSourceType
import com.example.media.DecoderStatus
import com.example.media.DecoderSelection

class DefaultAudioDecoderManager(
    private val failureManager: DecoderFailureManager,
    var engineMode: String = "AUTO"
) : AudioDecoderManager {

    override fun getDecoderCandidates(mimeType: String, channels: Int, sampleRate: Int): List<DecoderCandidate> {
        val candidates = mutableListOf<DecoderCandidate>()
        val support = DecoderCapabilityManager.checkCodecSupport(mimeType)

        val hwList = support.hardwareDecoders.map { DecoderCandidate(it, DecoderSourceType.HARDWARE, mimeType, true) }
        val extList = support.extensionDecoders.map { DecoderCandidate(it, DecoderSourceType.EXTENSION, mimeType, true) }
        val swList = support.softwareDecoders.map { DecoderCandidate(it, DecoderSourceType.SOFTWARE, mimeType, true) }

        // Proactively evaluate known device codec quirks before crash occurs
        for (candidate in hwList) {
            val quirks = DeviceCodecQuirkRegistry.getMatchingQuirks(candidate.name, mimeType)
            if (quirks.isNotEmpty()) {
                val primaryQuirk = quirks.first()
                if (primaryQuirk.action == QuirkAction.DISABLE_HARDWARE_DECODER || primaryQuirk.action == QuirkAction.FORCE_SOFTWARE_FALLBACK) {
                    candidate.isAvailable = false
                    candidate.failureType = DecoderFailureType.DECODER_INITIALIZATION_FAILED
                    candidate.failureReason = "Proactively disabled via DeviceCodecQuirkRegistry: ${primaryQuirk.reason}"
                }
            }
        }

        val preferExtension = hwList.any { hw ->
            DeviceCodecQuirkRegistry.shouldPreferExtension(hw.name, mimeType)
        }

        when (engineMode.uppercase()) {
            "SOFTWARE" -> {
                candidates.addAll(extList)
                candidates.addAll(swList)
                candidates.addAll(hwList)
            }
            "HARDWARE" -> {
                candidates.addAll(hwList)
                candidates.addAll(extList)
                candidates.addAll(swList)
            }
            else -> { // AUTO
                if (preferExtension) {
                    candidates.addAll(extList)
                    candidates.addAll(swList)
                    candidates.addAll(hwList)
                } else {
                    candidates.addAll(hwList)
                    candidates.addAll(extList)
                    candidates.addAll(swList)
                }
            }
        }

        // Filter out previously failed decoders
        val failed = failureManager.getFailedDecoders(mimeType)
        for (candidate in candidates) {
            if (failed.contains(candidate.name)) {
                candidate.isAvailable = false
                candidate.failureType = DecoderFailureType.DECODER_RUNTIME_FAILED
                candidate.failureReason = "Blacklisted for current session due to failure"
            }
        }

        return candidates
    }

    override fun selectBestDecoder(candidates: List<DecoderCandidate>): DecoderSelection {
        val available = candidates.filter { it.isAvailable }
        if (available.isEmpty()) {
            return DecoderSelection(
                mimeType = candidates.firstOrNull()?.mimeType ?: "unknown",
                decoderName = null,
                sourceType = DecoderSourceType.UNAVAILABLE,
                status = DecoderStatus.UNAVAILABLE,
                reason = "No available audio decoders",
                candidates = candidates
            )
        }
        val best = available.first()
        return DecoderSelection(
            mimeType = best.mimeType,
            decoderName = best.name,
            sourceType = best.sourceType,
            status = DecoderStatus.AVAILABLE,
            candidates = candidates
        )
    }
}
