package com.example.media.operations

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Log
import com.example.media.ffmpeg.FFmpegEngine
import com.example.media.storage.MediaUriResolver
import com.example.media.storage.TemporaryMediaManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Locale

object ThumbnailEngine {
    private const val TAG = "ThumbnailEngine"

    suspend fun generateThumbnail(
        context: Context,
        uri: Uri,
        timestampMs: Long = 1000L,
        maxWidth: Int = 512,
        maxHeight: Int = 512
    ): Result<Bitmap> = withContext(Dispatchers.IO) {
        var resolvedSource: com.example.media.storage.ResolvedMediaSource? = null
        val tempThumbnailFile = TemporaryMediaManager.createTempFile(context, "thumb_", "jpg")

        try {
            resolvedSource = MediaUriResolver.resolveUriForFFmpeg(context, uri, preferDirectSaf = true)
            val pathOrSaf = resolvedSource.pathOrSaf

            val timestampSec = String.format(Locale.US, "%.3f", (timestampMs.coerceAtLeast(0L) / 1000.0))
            val scaleFilter = "scale='min($maxWidth,iw)':'min($maxHeight,ih)':force_original_aspect_ratio=decrease"

            val args = arrayOf(
                "-ss", timestampSec,
                "-noaccurate_seek",
                "-i", pathOrSaf,
                "-vframes", "1",
                "-vf", scaleFilter,
                "-q:v", "2",
                "-f", "image2",
                "-y",
                tempThumbnailFile.absolutePath
            )

            Log.d(TAG, "Extracting thumbnail at ${timestampSec}s from $pathOrSaf")
            val result = FFmpegEngine.executeWithArguments(args)

            if (!result.isSuccess || !tempThumbnailFile.exists() || tempThumbnailFile.length() == 0L) {
                // Try fallback without -ss if initial timestamp was past duration
                val fallbackArgs = arrayOf(
                    "-i", pathOrSaf,
                    "-vframes", "1",
                    "-vf", scaleFilter,
                    "-q:v", "2",
                    "-f", "image2",
                    "-y",
                    tempThumbnailFile.absolutePath
                )
                val fallbackResult = FFmpegEngine.executeWithArguments(fallbackArgs)
                if (!fallbackResult.isSuccess || !tempThumbnailFile.exists() || tempThumbnailFile.length() == 0L) {
                    val err = "Thumbnail generation failed: ${result.failStackTrace ?: result.output}"
                    Log.e(TAG, err)
                    return@withContext Result.failure(IllegalStateException(err))
                }
            }

            val options = BitmapFactory.Options().apply {
                inPreferredConfig = Bitmap.Config.ARGB_8888
            }
            val bitmap = BitmapFactory.decodeFile(tempThumbnailFile.absolutePath, options)

            if (bitmap != null) {
                Log.d(TAG, "Thumbnail generated successfully: ${bitmap.width}x${bitmap.height}")
                Result.success(bitmap)
            } else {
                Result.failure(IllegalStateException("Failed to decode extracted thumbnail image"))
            }
        } catch (e: Exception) {
            Log.e(TAG, "Exception generating thumbnail: ${e.message}", e)
            Result.failure(e)
        } finally {
            TemporaryMediaManager.deleteSilently(tempThumbnailFile)
            if (resolvedSource?.isTemporaryFile == true) {
                TemporaryMediaManager.deleteSilently(resolvedSource.temporaryFile)
            }
        }
    }
}
