package com.example.player.gestures

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object PlayerGestureActionsDispatcher {
    private const val TAG = "GestureDispatcher"

    suspend fun captureFrameScreenshot(
        context: Context,
        localPath: String,
        positionMs: Long
    ): Pair<Boolean, String> = withContext(Dispatchers.IO) {
        if (localPath.isBlank()) {
            return@withContext Pair(false, "Screenshot unavailable: No local video file")
        }

        var retriever: MediaMetadataRetriever? = null
        try {
            retriever = MediaMetadataRetriever()
            val file = File(localPath)
            if (file.exists()) {
                retriever.setDataSource(file.absolutePath)
            } else {
                retriever.setDataSource(context, android.net.Uri.parse(localPath))
            }

            val timeUs = (positionMs * 1000L).coerceAtLeast(0L)
            val bitmap = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
                retriever.getScaledFrameAtTime(
                    timeUs,
                    MediaMetadataRetriever.OPTION_CLOSEST,
                    1920,
                    1080
                ) ?: retriever.getFrameAtTime(timeUs, MediaMetadataRetriever.OPTION_CLOSEST)
            } else {
                retriever.getFrameAtTime(timeUs, MediaMetadataRetriever.OPTION_CLOSEST)
            }

            if (bitmap == null) {
                return@withContext Pair(false, "Could not extract video frame")
            }

            val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
            val filename = "Downly_Screenshot_$timestamp.png"

            val success = saveBitmapToGallery(context, bitmap, filename)
            if (success) {
                Pair(true, "Screenshot saved to Gallery ($filename)")
            } else {
                Pair(false, "Failed to save screenshot file")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Screenshot extraction failed: ${e.message}", e)
            Pair(false, "Screenshot failed: ${e.localizedMessage ?: "Unknown error"}")
        } finally {
            try {
                retriever?.release()
            } catch (_: Exception) {}
        }
    }

    private fun saveBitmapToGallery(context: Context, bitmap: Bitmap, filename: String): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val contentValues = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, filename)
                    put(MediaStore.MediaColumns.MIME_TYPE, "image/png")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, "${Environment.DIRECTORY_PICTURES}/Downly_Screenshots")
                    put(MediaStore.Images.Media.IS_PENDING, 1)
                }

                val resolver = context.contentResolver
                val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues)
                    ?: return false

                resolver.openOutputStream(uri)?.use { stream ->
                    bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream)
                }

                contentValues.clear()
                contentValues.put(MediaStore.Images.Media.IS_PENDING, 0)
                resolver.update(uri, contentValues, null, null)
                true
            } else {
                val picturesDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES)
                val downlyDir = File(picturesDir, "Downly_Screenshots").apply { mkdirs() }
                val destFile = File(downlyDir, filename)
                FileOutputStream(destFile).use { stream ->
                    bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream)
                }
                true
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error saving bitmap to gallery", e)
            false
        }
    }
}
