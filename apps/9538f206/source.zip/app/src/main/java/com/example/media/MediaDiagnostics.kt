package com.example.media

data class ContainerDiagnostics(
    val format: String = "Unknown",
    val mimeType: String = "unknown",
    val durationMs: Long = 0L,
    val fileSizeBytes: Long = 0L,
    val bitrate: Int = 0,
    val startTimeMs: Long = 0L,
    val hasChapters: Boolean = false,
    val metadata: Map<String, String> = emptyMap()
)

data class VideoDiagnostics(
    val id: String = "N/A",
    val codec: String = "N/A",
    val mimeType: String = "N/A",
    val codecString: String = "N/A",
    val profile: String = "N/A",
    val level: String = "N/A",
    val width: Int = 0,
    val height: Int = 0,
    val frameRate: Float = 0f,
    val pixelFormat: String = "N/A",
    val bitDepth: Int = 8,
    val colorInformation: String = "N/A",
    val isDefault: Boolean = false,
    val bitrate: Int = 0
)

data class AudioDiagnostics(
    val id: String = "N/A",
    val codec: String = "N/A",
    val mimeType: String = "N/A",
    val codecString: String = "N/A",
    val language: String = "und",
    val channels: Int = 0,
    val channelLayout: String = "N/A",
    val sampleRate: Int = 0,
    val bitrate: Int = 0,
    val isDefault: Boolean = false,
    val isForced: Boolean = false,
    val title: String = "N/A"
)

data class SubtitleDiagnostics(
    val id: String = "N/A",
    val codec: String = "N/A",
    val mimeType: String = "N/A",
    val language: String = "und",
    val isDefault: Boolean = false,
    val isForced: Boolean = false,
    val title: String = "N/A"
)

data class MediaDiagnostics(
    val container: ContainerDiagnostics = ContainerDiagnostics(),
    val videoTracks: List<VideoDiagnostics> = emptyList(),
    val audioTracks: List<AudioDiagnostics> = emptyList(),
    val subtitleTracks: List<SubtitleDiagnostics> = emptyList()
) {
    fun toFormattedLog(): String {
        val sb = StringBuilder()
        sb.appendLine("[MEDIA]")
        sb.appendLine("container=${container.format}")
        sb.appendLine("mime=${container.mimeType}")
        sb.appendLine("durationMs=${container.durationMs}")
        sb.appendLine("fileSizeBytes=${container.fileSizeBytes}")
        if (container.metadata.isNotEmpty()) {
            sb.appendLine("metadata=${container.metadata}")
        }

        sb.appendLine("\n[VIDEO TRACKS: ${videoTracks.size}]")
        for ((i, v) in videoTracks.withIndex()) {
            sb.appendLine("  #$i: ${v.codec} | ${v.width}x${v.height} | ${v.frameRate}fps | default=${v.isDefault}")
        }

        sb.appendLine("\n[AUDIO TRACKS: ${audioTracks.size}]")
        for ((i, a) in audioTracks.withIndex()) {
            sb.appendLine("  #$i: ${a.codec} | ${a.language} | ${a.channels}ch | ${a.sampleRate}Hz | default=${a.isDefault}")
        }

        sb.appendLine("\n[SUBTITLE TRACKS: ${subtitleTracks.size}]")
        for ((i, s) in subtitleTracks.withIndex()) {
            sb.appendLine("  #$i: ${s.codec} | ${s.language} | default=${s.isDefault} | forced=${s.isForced}")
        }

        return sb.toString()
    }
}
