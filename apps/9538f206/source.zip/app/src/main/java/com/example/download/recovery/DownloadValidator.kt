package com.example.download.recovery

import android.content.Context
import android.media.MediaExtractor
import android.media.MediaFormat
import android.util.Log
import java.io.File
import java.io.FileInputStream

/**
 * Lightweight, non-destructive media validation engine for smart download recovery.
 */
object DownloadValidator {
    private const val TAG = "DownloadValidator"

    sealed class ValidationResult {
        object Valid : ValidationResult()
        data class Incomplete(val bytesDownloaded: Long, val expectedBytes: Long, val isResumable: Boolean) : ValidationResult()
        data class Corrupted(val reason: String) : ValidationResult()
        object ZeroByte : ValidationResult()
        object MissingFile : ValidationResult()
    }

    /**
     * Performs lightweight, non-blocking integrity validation on a downloaded file.
     * Does not decode full video streams; inspects file existence, non-zero length,
     * header magic bytes, and basic container metadata.
     */
    fun validateFile(file: File, expectedSize: Long = 0L): ValidationResult {
        if (!file.exists()) {
            return ValidationResult.MissingFile
        }

        val length = file.length()
        if (length == 0L) {
            return ValidationResult.ZeroByte
        }

        if (!file.canRead()) {
            return ValidationResult.Corrupted("File exists but is unreadable (permission or I/O failure)")
        }

        // If an expected non-zero size is known, check if truncated
        if (expectedSize > 0L && length < (expectedSize * 0.90).toLong()) {
            return ValidationResult.Incomplete(
                bytesDownloaded = length,
                expectedBytes = expectedSize,
                isResumable = true
            )
        }

        // Header magic bytes check
        val magicValid = checkHeaderMagic(file)
        if (!magicValid) {
            // If file has content but invalid header, it is corrupted or incomplete
            return if (expectedSize > 0L && length < expectedSize) {
                ValidationResult.Incomplete(length, expectedSize, isResumable = true)
            } else {
                ValidationResult.Corrupted("Invalid or missing container magic header bytes")
            }
        }

        // Media container track inspection (lightweight)
        val containerValid = inspectMediaContainer(file)
        if (!containerValid) {
            // If container cannot be inspected but header is valid and length is significant,
            // we do not falsely mark as broken if file is simply a specialized stream format.
            // But if size is very small (< 1KB), it's incomplete.
            if (length < 1024L) {
                return ValidationResult.Incomplete(length, expectedSize, isResumable = true)
            }
        }

        return ValidationResult.Valid
    }

    /**
     * Inspects the first 16-32 bytes of the file for valid media container signatures.
     */
    fun checkHeaderMagic(file: File): Boolean {
        if (!file.exists() || file.length() < 4L) return false

        try {
            FileInputStream(file).use { fis ->
                val header = ByteArray(32)
                val read = fis.read(header)
                if (read < 4) return false

                val ext = file.extension.lowercase()

                // Check common formats
                when (ext) {
                    "mp4", "m4a", "mov" -> {
                        // Check for 'ftyp' at offset 4
                        if (read >= 8) {
                            val ftyp = String(header, 4, 4, Charsets.US_ASCII)
                            if (ftyp.equals("ftyp", ignoreCase = true) || ftyp.equals("moov", ignoreCase = true) || ftyp.equals("mdat", ignoreCase = true)) {
                                return true
                            }
                        }
                    }
                    "webm", "mkv" -> {
                        // EBML Header: 0x1A 0x45 0xDF 0xA3
                        if (header[0] == 0x1A.toByte() && header[1] == 0x45.toByte() && header[2] == 0xDF.toByte() && header[3] == 0xA3.toByte()) {
                            return true
                        }
                    }
                    "mp3" -> {
                        // ID3v2 tag ("ID3") or MPEG frame sync (0xFF 0xFB / 0xFA / 0xF3 / 0xF2)
                        val id3 = String(header, 0, 3, Charsets.US_ASCII)
                        if (id3 == "ID3") return true
                        if ((header[0].toInt() and 0xFF) == 0xFF && (header[1].toInt() and 0xE0) == 0xE0) return true
                    }
                    "ogg", "opus" -> {
                        // "OggS"
                        val ogg = String(header, 0, 4, Charsets.US_ASCII)
                        if (ogg == "OggS") return true
                    }
                    "flac" -> {
                        // "fLaC"
                        val flac = String(header, 0, 4, Charsets.US_ASCII)
                        if (flac == "fLaC") return true
                    }
                    "wav" -> {
                        // "RIFF"
                        val riff = String(header, 0, 4, Charsets.US_ASCII)
                        if (riff == "RIFF") return true
                    }
                }

                // General fallback: if file starts with common signatures
                val s4 = if (read >= 4) String(header, 0, 4, Charsets.US_ASCII) else ""
                val s8 = if (read >= 8) String(header, 4, 4, Charsets.US_ASCII) else ""
                if (s4 == "RIFF" || s4 == "fLaC" || s4 == "OggS" || s4 == "ID3" || s8 == "ftyp" || s8 == "moov") {
                    return true
                }
                if (header[0] == 0x1A.toByte() && header[1] == 0x45.toByte()) {
                    return true
                }
            }
        } catch (e: Throwable) {
            Log.w(TAG, "Header check exception: ${e.message}")
            return false
        }
        return true // permissive fallback if extension is generic
    }

    /**
     * Fast container inspection using Android MediaExtractor to verify tracks exist.
     */
    private fun inspectMediaContainer(file: File): Boolean {
        var extractor: MediaExtractor? = null
        try {
            extractor = MediaExtractor()
            extractor.setDataSource(file.absolutePath)
            val trackCount = extractor.trackCount
            if (trackCount > 0) {
                return true
            }
        } catch (e: Throwable) {
            // MediaExtractor might fail on non-standard stream containers or audio-only codecs
            // Do not fail immediately unless file size is trivial
        } finally {
            try {
                extractor?.release()
            } catch (_: Throwable) {}
        }
        return file.length() > 8192L // At least 8KB of data
    }
}
