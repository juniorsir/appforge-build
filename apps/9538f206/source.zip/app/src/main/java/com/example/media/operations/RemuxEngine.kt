package com.example.media.operations

import android.content.Context
import android.net.Uri
import android.util.Log
import com.example.media.ffmpeg.FFmpegEngine
import com.example.media.ffmpeg.FFmpegProgress
import com.example.media.ffmpeg.FFmpegResult
import com.example.media.ffmpeg.FFmpegState
import com.example.media.probe.MediaProbeEngine
import com.example.media.storage.MediaUriResolver
import com.example.media.storage.TemporaryMediaManager
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import java.io.File

object RemuxEngine {
    private const val TAG = "RemuxEngine"

    fun remuxToMp4(
        context: Context,
        inputUri: Uri,
        outputFile: File
    ): Flow<FFmpegProgress> = callbackFlow {
        var resolvedSource: com.example.media.storage.ResolvedMediaSource? = null
        var activeSessionId: Long = 0L

        try {
            val probeResult = MediaProbeEngine.probeMedia(context, inputUri)
            val probeInfo = probeResult.getOrNull()
            val totalDurationMs = probeInfo?.durationMs ?: 0L

            resolvedSource = MediaUriResolver.resolveUriForFFmpeg(context, inputUri, preferDirectSaf = true)
            val inputPath = resolvedSource.pathOrSaf

            Log.i(TAG, "Starting stream-copy remux of $inputPath to MP4 (${outputFile.absolutePath})")

            val args = arrayOf(
                "-i", inputPath,
                "-c", "copy",
                "-movflags", "+faststart",
                "-y",
                outputFile.absolutePath
            )

            activeSessionId = FFmpegEngine.executeAsyncWithArguments(
                arguments = args,
                totalDurationMs = totalDurationMs,
                onProgress = { progress ->
                    trySend(progress)
                },
                onComplete = { result ->
                    if (!result.isSuccess) {
                        trySend(
                            FFmpegProgress(
                                sessionId = result.sessionId,
                                state = FFmpegState.FAILED,
                                error = IllegalStateException(result.failStackTrace ?: result.output),
                                logOutput = result.output
                            )
                        )
                    }
                    close()
                }
            )

        } catch (e: Exception) {
            Log.e(TAG, "Remux error: ${e.message}", e)
            trySend(
                FFmpegProgress(
                    state = FFmpegState.FAILED,
                    error = e
                )
            )
            close(e)
        }

        awaitClose {
            if (activeSessionId > 0L) {
                FFmpegEngine.cancel(activeSessionId)
            }
            if (resolvedSource?.isTemporaryFile == true) {
                TemporaryMediaManager.deleteSilently(resolvedSource?.temporaryFile)
            }
        }
    }
}
