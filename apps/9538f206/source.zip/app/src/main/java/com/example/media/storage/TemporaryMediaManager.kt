package com.example.media.storage

import android.content.Context
import android.util.Log
import java.io.File
import java.util.UUID

object TemporaryMediaManager {
    private const val TAG = "TempMediaManager"
    private const val TEMP_DIR_NAME = "ffmpeg_media_cache"

    fun getTempDirectory(context: Context): File {
        val dir = File(context.cacheDir, TEMP_DIR_NAME)
        if (!dir.exists()) {
            dir.mkdirs()
        }
        return dir
    }

    fun createTempFile(context: Context, prefix: String = "media_", extension: String = "tmp"): File {
        val dir = getTempDirectory(context)
        val ext = if (extension.startsWith(".")) extension else ".$extension"
        val fileName = "${prefix}${System.currentTimeMillis()}_${UUID.randomUUID().toString().take(8)}$ext"
        return File(dir, fileName)
    }

    fun deleteSilently(file: File?): Boolean {
        if (file == null || !file.exists()) return false
        return try {
            file.delete()
        } catch (e: Exception) {
            Log.w(TAG, "Failed to delete temp file ${file.absolutePath}: ${e.message}")
            false
        }
    }

    fun cleanupAll(context: Context) {
        try {
            val dir = File(context.cacheDir, TEMP_DIR_NAME)
            if (dir.exists() && dir.isDirectory) {
                dir.listFiles()?.forEach { it.delete() }
                Log.d(TAG, "Cleaned up temp media files in ${dir.absolutePath}")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error cleaning temp media directory: ${e.message}")
        }
    }
}
