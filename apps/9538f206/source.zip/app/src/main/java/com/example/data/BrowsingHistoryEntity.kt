package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "browsing_history")
data class BrowsingHistoryEntity(
    @PrimaryKey val id: String, // videoId
    val title: String,
    val author: String,
    val durationText: String,
    val thumbnailUrl: String,
    val originalUrl: String,
    val browsedAt: Long = System.currentTimeMillis()
)
