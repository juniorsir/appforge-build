package com.example.extraction

import com.example.ui.VideoFormatUi

/**
 * Stage 6: UIFormatMapper
 * Maps NormalizedFormat models into VideoFormatUi objects for Compose UI presentation (Phase 10).
 */
object UIFormatMapper {

    fun mapToUiFormats(normalizedFormats: List<NormalizedFormat>): List<VideoFormatUi> {
        return normalizedFormats.mapIndexed { index, fmt ->
            val typeStr = when (fmt.streamType) {
                StreamType.AUDIO_ONLY -> "audio"
                StreamType.VIDEO_ONLY -> "video_only"
                StreamType.ADAPTIVE_HLS, StreamType.ADAPTIVE_DASH -> "adaptive"
                else -> "combined"
            }

            val formatIdInt = fmt.rawFormatId.toIntOrNull() ?: (1000 + index)

            VideoFormatUi(
                formatId = formatIdInt,
                type = typeStr,
                quality = fmt.displayQuality,
                ext = fmt.ext,
                sizeText = fmt.formattedSizeText,
                downloadUrl = fmt.downloadUrl,
                sizeBytes = fmt.sizeBytes,
                userAgent = "",
                height = if (fmt.resolutionHeight > 0) fmt.resolutionHeight else null,
                hasAudio = fmt.hasAudio,
                tbr = if (fmt.bitrateKbps > 0) fmt.bitrateKbps.toDouble() else null,
                vcodec = fmt.videoCodecFamily,
                acodec = fmt.audioCodecFamily,
                fps = if (fmt.fps > 0) fmt.fps else null,
                isHdr = fmt.isHdr,
                isLive = fmt.isLive,
                isAdaptive = fmt.isAdaptive,
                rawFormatIdStr = fmt.rawFormatId,
                estimatedSizeText = if (fmt.isEstimatedSize) fmt.formattedSizeText else "",
                bitrateKbps = if (fmt.bitrateKbps > 0) fmt.bitrateKbps else null,
                audioBitrateKbps = if (fmt.audioBitrateKbps > 0) fmt.audioBitrateKbps else null,
                dynamicRange = fmt.dynamicRange,
                language = fmt.language,
                isAgeRestricted = fmt.isAgeRestricted,
                isPremium = fmt.isPremium,
                qualityScore = fmt.qualityScore,
                protocol = fmt.protocol
            )
        }
    }
}
