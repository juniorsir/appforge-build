package com.example.util

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.Settings
import android.util.Log
import androidx.core.content.ContextCompat
import java.io.File
import java.util.regex.Pattern

/**
 * Centralized backward compatibility helper for Downly.
 * Handles API differences cleanly from Android 7.0 (API 24) through Android 11 (API 30) up to Android 16 (API 36).
 */
object DeviceCompatHelper {
    private const val TAG = "DeviceCompatHelper"

    // API Level checks
    val isAndroid11OrAbove: Boolean get() = Build.VERSION.SDK_INT >= Build.VERSION_CODES.R // API 30
    val isAndroid12OrAbove: Boolean get() = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S // API 31
    val isAndroid13OrAbove: Boolean get() = Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU // API 33
    val isAndroid14OrAbove: Boolean get() = Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE // API 34
    val isAndroid15OrAbove: Boolean get() = Build.VERSION.SDK_INT >= 35 // API 35 (Vanilla Ice Cream)
    val isOreoOrAbove: Boolean get() = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O // API 26
    val isQOrAbove: Boolean get() = Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q // API 29

    /**
     * Get required runtime permissions appropriate for the running Android version.
     * On Android 13+ (API 33+): READ_MEDIA_VIDEO, READ_MEDIA_AUDIO, POST_NOTIFICATIONS
     * On Android 11-12 (API 30-32): READ_EXTERNAL_STORAGE
     * On Android 10 and below: READ_EXTERNAL_STORAGE, WRITE_EXTERNAL_STORAGE
     */
    fun getRequiredPermissions(): List<String> {
        return buildList {
            if (isAndroid13OrAbove) {
                add(android.Manifest.permission.READ_MEDIA_VIDEO)
                add(android.Manifest.permission.READ_MEDIA_AUDIO)
                add(android.Manifest.permission.POST_NOTIFICATIONS)
            } else if (isAndroid11OrAbove) {
                add(android.Manifest.permission.READ_EXTERNAL_STORAGE)
            } else {
                add(android.Manifest.permission.READ_EXTERNAL_STORAGE)
                add(android.Manifest.permission.WRITE_EXTERNAL_STORAGE)
            }
        }
    }

    /**
     * Returns PendingIntent flags with mandatory FLAG_IMMUTABLE on Android 12+ (API 31+)
     * and safe compatibility flags on older versions.
     */
    fun getPendingIntentFlags(isMutable: Boolean = false): Int {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val base = PendingIntent.FLAG_UPDATE_CURRENT
            if (isAndroid12OrAbove) {
                if (isMutable && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    base or PendingIntent.FLAG_MUTABLE
                } else {
                    base or PendingIntent.FLAG_IMMUTABLE
                }
            } else {
                base or PendingIntent.FLAG_IMMUTABLE
            }
        } else {
            PendingIntent.FLAG_UPDATE_CURRENT
        }
    }

    /**
     * Safely determine and verify a writable download directory.
     * Respects Android 11 Scoped Storage policies and prevents access crashes.
     */
    fun getSafeDownloadDirectory(
        context: Context,
        customFolder: String? = null,
        preferPublic: Boolean = false
    ): File {
        // 1. If custom folder specified, test if writable
        if (!customFolder.isNullOrBlank()) {
            val customDir = File(customFolder)
            if (isDirWritable(customDir)) {
                return customDir
            }
        }

        // 2. If public storage requested, test if writable on current Android version
        if (preferPublic) {
            try {
                @Suppress("DEPRECATION")
                val publicDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                if (isDirWritable(publicDir)) {
                    return publicDir
                }
            } catch (_: Throwable) {}
        }

        // 3. App-specific external downloads directory (Always safe and accessible on Android 11+ without permissions)
        val extDownloads = context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)
        if (extDownloads != null && isDirWritable(extDownloads)) {
            return extDownloads
        }

        // 4. App-specific external movies directory
        val extMovies = context.getExternalFilesDir(Environment.DIRECTORY_MOVIES)
        if (extMovies != null && isDirWritable(extMovies)) {
            return extMovies
        }

        // 5. Internal files directory (100% guaranteed writable fallback)
        val internalDir = File(context.filesDir, "downloads")
        if (!internalDir.exists()) {
            internalDir.mkdirs()
        }
        return internalDir
    }

    private fun isDirWritable(dir: File): Boolean {
        return try {
            if (!dir.exists()) {
                dir.mkdirs()
            }
            if (dir.exists() && dir.isDirectory) {
                val testFile = File(dir, ".write_test_${System.currentTimeMillis()}")
                if (testFile.createNewFile()) {
                    testFile.delete()
                    true
                } else {
                    false
                }
            } else {
                false
            }
        } catch (_: Throwable) {
            false
        }
    }

    /**
     * Safely start foreground service across all Android versions.
     */
    fun startForegroundServiceCompat(context: Context, intent: Intent): Boolean {
        return try {
            if (isOreoOrAbove) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
            true
        } catch (e: Throwable) {
            Log.w(TAG, "Failed starting foreground service, attempting normal service fallback: ${e.message}")
            try {
                context.startService(intent)
                true
            } catch (fallbackEx: Throwable) {
                Log.e(TAG, "Service start completely failed: ${fallbackEx.message}", fallbackEx)
                false
            }
        }
    }

    /**
     * Check if Picture-in-Picture is supported on this device.
     */
    fun isPipSupported(context: Context): Boolean {
        return isOreoOrAbove && context.packageManager.hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE)
    }

    /**
     * Check if the app has permission to draw system overlays (Floating bubble).
     */
    fun canDrawOverlays(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Settings.canDrawOverlays(context)
        } else {
            true
        }
    }

    /**
     * Check if notification permission is currently granted.
     */
    fun isNotificationPermissionGranted(context: Context): Boolean {
        return if (isAndroid13OrAbove) {
            ContextCompat.checkSelfPermission(
                context,
                android.Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            // Notifications are automatically granted on Android 12 and below
            true
        }
    }
}
