package com.example.media.orchestration

import com.example.media.DecoderCapabilityManager
import com.example.media.DecoderManager
import com.example.media.DecoderSelection
import com.example.media.DecoderSourceType
import com.example.media.DecoderStatus

class DecoderOrchestrator : DecoderManager {
    
    val failureManager = DefaultDecoderFailureManager()
    val profile = com.example.media.PlaybackPerformanceProfile()
    private val audioManager = DefaultAudioDecoderManager(failureManager)
    private val videoManager = DefaultVideoDecoderManager(failureManager)
    private val subtitleManager = DefaultSubtitleManager()

    override fun inspectCapabilities(): String {
        return DecoderCapabilityManager.generateDeviceCodecReport()
    }

    override fun findVideoDecoder(mimeType: String, width: Int, height: Int): DecoderSelection {
        val candidates = videoManager.getDecoderCandidates(mimeType, width, height)
        val selection = videoManager.selectBestDecoder(candidates)
        profile.activeVideoDecoder = selection.decoderName ?: "Unknown"
        failureManager.eventLog.logEvent("VIDEO_DECODER_SELECTED", "Selected ${selection.decoderName} (${selection.sourceType}) for $mimeType", selection.decoderName, mimeType)
        return selection
    }

    override fun findAudioDecoder(mimeType: String, channels: Int, sampleRate: Int): DecoderSelection {
        val candidates = audioManager.getDecoderCandidates(mimeType, channels, sampleRate)
        val selection = audioManager.selectBestDecoder(candidates)
        profile.activeAudioDecoder = selection.decoderName ?: "Unknown"
        failureManager.eventLog.logEvent("AUDIO_DECODER_SELECTED", "Selected ${selection.decoderName} (${selection.sourceType}) for $mimeType", selection.decoderName, mimeType)
        return selection
    }

    override fun findSubtitleRenderer(mimeType: String): DecoderSelection {
        val candidates = subtitleManager.getRendererCandidates(mimeType)
        val selection = subtitleManager.selectBestRenderer(candidates)
        failureManager.eventLog.logEvent("SUBTITLE_RENDERER_SELECTED", "Selected ${selection.decoderName} for $mimeType", selection.decoderName, mimeType)
        return selection
    }

    override fun reportDecoderFailure(decoderName: String?, mimeType: String, cause: Throwable) {
        val type = failureManager.classifyFailure(cause)
        failureManager.recordFailure(decoderName, mimeType, type, cause)
        profile.fallbackCount.incrementAndGet()
    }

    override fun getEventLog(): String {
        return failureManager.eventLog.formatFormattedLog()
    }

    override fun getPerformanceProfile(): com.example.media.PlaybackPerformanceProfile {
        return profile
    }
}
