package com.example.media

enum class DecoderSourceType {
    HARDWARE,
    SOFTWARE,
    EXTENSION,
    UNAVAILABLE,
    UNKNOWN
}

enum class DecoderStatus {
    AVAILABLE,
    UNAVAILABLE,
    FAILED
}

data class DecoderSelection(
    val mimeType: String,
    val decoderName: String?,
    val sourceType: DecoderSourceType,
    val status: DecoderStatus,
    val reason: String? = null,
    val candidates: List<com.example.media.orchestration.DecoderCandidate> = emptyList()
)

interface DecoderManager {
    fun inspectCapabilities(): String
    fun findVideoDecoder(mimeType: String, width: Int, height: Int): DecoderSelection
    fun findAudioDecoder(mimeType: String, channels: Int, sampleRate: Int): DecoderSelection
    fun findSubtitleRenderer(mimeType: String): DecoderSelection
    fun reportDecoderFailure(decoderName: String?, mimeType: String, cause: Throwable)
    fun getEventLog(): String = "No event log available."
    fun getPerformanceProfile(): PlaybackPerformanceProfile = PlaybackPerformanceProfile()
}

class DefaultDecoderManager : DecoderManager {

    override fun inspectCapabilities(): String {
        return DecoderCapabilityManager.generateDeviceCodecReport()
    }

    override fun findVideoDecoder(mimeType: String, width: Int, height: Int): DecoderSelection {
        val support = DecoderCapabilityManager.checkCodecSupport(mimeType)
        return when {
            support.hardwareAvailable -> DecoderSelection(
                mimeType = mimeType,
                decoderName = support.hardwareDecoders.firstOrNull(),
                sourceType = DecoderSourceType.HARDWARE,
                status = DecoderStatus.AVAILABLE
            )
            support.extensionAvailable -> DecoderSelection(
                mimeType = mimeType,
                decoderName = support.extensionDecoders.firstOrNull(),
                sourceType = DecoderSourceType.EXTENSION,
                status = DecoderStatus.AVAILABLE
            )
            support.softwareAvailable -> DecoderSelection(
                mimeType = mimeType,
                decoderName = support.softwareDecoders.firstOrNull(),
                sourceType = DecoderSourceType.SOFTWARE,
                status = DecoderStatus.AVAILABLE
            )
            else -> DecoderSelection(
                mimeType = mimeType,
                decoderName = null,
                sourceType = DecoderSourceType.UNAVAILABLE,
                status = DecoderStatus.UNAVAILABLE,
                reason = "No video decoder available for $mimeType"
            )
        }
    }

    override fun findAudioDecoder(mimeType: String, channels: Int, sampleRate: Int): DecoderSelection {
        val support = DecoderCapabilityManager.checkCodecSupport(mimeType)
        return when {
            support.hardwareAvailable -> DecoderSelection(
                mimeType = mimeType,
                decoderName = support.hardwareDecoders.firstOrNull(),
                sourceType = DecoderSourceType.HARDWARE,
                status = DecoderStatus.AVAILABLE
            )
            support.extensionAvailable -> DecoderSelection(
                mimeType = mimeType,
                decoderName = support.extensionDecoders.firstOrNull(),
                sourceType = DecoderSourceType.EXTENSION,
                status = DecoderStatus.AVAILABLE
            )
            support.softwareAvailable -> DecoderSelection(
                mimeType = mimeType,
                decoderName = support.softwareDecoders.firstOrNull(),
                sourceType = DecoderSourceType.SOFTWARE,
                status = DecoderStatus.AVAILABLE
            )
            else -> DecoderSelection(
                mimeType = mimeType,
                decoderName = null,
                sourceType = DecoderSourceType.UNAVAILABLE,
                status = DecoderStatus.UNAVAILABLE,
                reason = "No audio decoder available for $mimeType"
            )
        }
    }

    override fun findSubtitleRenderer(mimeType: String): DecoderSelection {
        return DecoderSelection(
            mimeType = mimeType,
            decoderName = "Media3SubtitleDecoder",
            sourceType = DecoderSourceType.SOFTWARE,
            status = DecoderStatus.AVAILABLE
        )
    }

    override fun reportDecoderFailure(decoderName: String?, mimeType: String, cause: Throwable) {
        android.util.Log.e("DecoderManager", "Decoder failure reported for $mimeType ($decoderName): ${cause.message}", cause)
    }
}
