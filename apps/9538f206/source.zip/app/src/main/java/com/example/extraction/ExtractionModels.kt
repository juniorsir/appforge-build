package com.example.extraction

import com.example.ui.VideoFormatUi

/**
 * Stream type classification for manifest intelligence.
 */
enum class StreamType {
    PROGRESSIVE,
    ADAPTIVE_HLS,
    ADAPTIVE_DASH,
    VIDEO_ONLY,
    AUDIO_ONLY,
    MERGED,
    LIVE_STREAM,
    UNKNOWN
}

/**
 * Codec efficiency hierarchy for quality scoring.
 */
enum class CodecEfficiency(val scoreBonus: Int) {
    AV1(250),
    HEVC(200),
    VP9(150),
    AVC(100),
    VP8(50),
    OTHER(0)
}

/**
 * Raw format extracted safely from VideoInfo format items using reflection / safe getters.
 */
data class RawFormat(
    val formatIdStr: String,
    val ext: String,
    val formatNote: String,
    val url: String,
    val vcodec: String,
    val acodec: String,
    val height: Int,
    val width: Int,
    val fps: Int,
    val filesize: Long,
    val filesizeApprox: Long,
    val tbr: Double,
    val vbr: Double,
    val abr: Double,
    val asr: Int,
    val dynamicRange: String,
    val language: String,
    val protocol: String,
    val manifestUrl: String,
    val sourcePreference: Int,
    val rawIndex: Int
)

/**
 * Normalized format representation with parsed and sanitized metadata.
 */
data class NormalizedFormat(
    val rawFormatId: String,
    val streamType: StreamType,
    val ext: String,
    val downloadUrl: String,
    val resolutionHeight: Int,
    val resolutionWidth: Int,
    val displayQuality: String,
    val fps: Int,
    val isHdr: Boolean,
    val dynamicRange: String,
    val videoCodec: String,
    val videoCodecFamily: String,
    val audioCodec: String,
    val audioCodecFamily: String,
    val codecEfficiency: CodecEfficiency,
    val hasVideo: Boolean,
    val hasAudio: Boolean,
    val sizeBytes: Long,
    val isEstimatedSize: Boolean,
    val formattedSizeText: String,
    val bitrateKbps: Int,
    val audioBitrateKbps: Int,
    val sampleRateHz: Int,
    val language: String,
    val protocol: String,
    val qualityScore: Int,
    val isLive: Boolean = false,
    val isAdaptive: Boolean = false,
    val isAgeRestricted: Boolean = false,
    val isPremium: Boolean = false
)

/**
 * Detailed error diagnostic output for extraction pipeline failures.
 */
data class StructuredExtractionError(
    val reason: String,
    val backend: String = "NATIVE_SEAL",
    val extractor: String = "yt-dlp",
    val networkStatus: String = "OK",
    val httpStatus: Int? = null,
    val failedStage: String = "",
    val retryCount: Int = 0,
    val cacheStatus: String = "MISS",
    val jniStatus: String = "READY"
)
