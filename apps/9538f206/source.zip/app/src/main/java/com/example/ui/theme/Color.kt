package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val KeyboardBackground = Color(0xFF0B0B0F)
val KeyCaps = Color(0xFF181820)
val KeyText = Color(0xFFFFFFFF)
val AccentOrange = Color(0xFFD97706)

val SecondaryText = Color(0xFFB7BBC5)
val SubduedCaps = Color(0xFF777D88)
