package com.example.media.operations

import android.content.Context
import android.net.Uri
import android.util.Log
import com.example.media.ffmpeg.FFmpegEngine
import com.example.media.ffmpeg.FFmpegProgress
import com.example.media.ffmpeg.FFmpegResult
import com.example.media.ffmpeg.FFmpegState
import com.example.media.probe.MediaProbeEngine
import com.example.media.storage.MediaUriResolver
import com.example.media.storage.TemporaryMediaManager
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import java.io.File

enum class AudioOutputFormat(val extension: String, val defaultCodec: String) {
    M4A("m4a", "aac"),
    MP3("mp3", "libmp3lame"),
    AAC("aac", "aac"),
    OPUS("opus", "libopus"),
    FLAC("flac", "flac"),
    WAV("wav", "pcm_s16le")
}

object AudioExtractor {
    private const val TAG = "AudioExtractor"

    fun extractAudio(
        context: Context,
        inputUri: Uri,
        outputFile: File,
        targetFormat: AudioOutputFormat = AudioOutputFormat.M4A,
        audioBitrateKbps: Int = 192
    ): Flow<FFmpegProgress> = callbackFlow {
        var resolvedSource: com.example.media.storage.ResolvedMediaSource? = null
        var activeSessionId: Long = 0L

        try {
            val probeResult = MediaProbeEngine.probeMedia(context, inputUri)
            val probeInfo = probeResult.getOrNull()
            val totalDurationMs = probeInfo?.durationMs ?: 0L

            resolvedSource = MediaUriResolver.resolveUriForFFmpeg(context, inputUri, preferDirectSaf = true)
            val inputPath = resolvedSource.pathOrSaf

            val primaryAudio = probeInfo?.primaryAudio
            val sourceAudioCodec = primaryAudio?.codec?.lowercase() ?: "unknown"

            // Check if stream copy is possible
            val canStreamCopy = when (targetFormat) {
                AudioOutputFormat.M4A, AudioOutputFormat.AAC -> sourceAudioCodec == "aac"
                AudioOutputFormat.MP3 -> sourceAudioCodec == "mp3"
                AudioOutputFormat.OPUS -> sourceAudioCodec == "opus"
                AudioOutputFormat.FLAC -> sourceAudioCodec == "flac"
                AudioOutputFormat.WAV -> sourceAudioCodec.startsWith("pcm")
            }

            val args = if (canStreamCopy) {
                Log.i(TAG, "Source audio codec ($sourceAudioCodec) matches target format ($targetFormat). Using stream copy!")
                arrayOf(
                    "-i", inputPath,
                    "-vn",
                    "-c:a", "copy",
                    "-y",
                    outputFile.absolutePath
                )
            } else {
                Log.i(TAG, "Transcoding audio from $sourceAudioCodec to ${targetFormat.defaultCodec} at ${audioBitrateKbps}k")
                val codecArgs = when (targetFormat) {
                    AudioOutputFormat.MP3 -> arrayOf("-c:a", "libmp3lame", "-b:a", "${audioBitrateKbps}k")
                    AudioOutputFormat.M4A, AudioOutputFormat.AAC -> arrayOf("-c:a", "aac", "-b:a", "${audioBitrateKbps}k")
                    AudioOutputFormat.OPUS -> arrayOf("-c:a", "libopus", "-b:a", "${audioBitrateKbps}k")
                    AudioOutputFormat.FLAC -> arrayOf("-c:a", "flac")
                    AudioOutputFormat.WAV -> arrayOf("-c:a", "pcm_s16le")
                }
                arrayOf(
                    "-i", inputPath,
                    "-vn",
                    *codecArgs,
                    "-y",
                    outputFile.absolutePath
                )
            }

            activeSessionId = FFmpegEngine.executeAsyncWithArguments(
                arguments = args,
                totalDurationMs = totalDurationMs,
                onProgress = { progress ->
                    trySend(progress)
                },
                onComplete = { result ->
                    if (!result.isSuccess) {
                        trySend(
                            FFmpegProgress(
                                sessionId = result.sessionId,
                                state = FFmpegState.FAILED,
                                error = IllegalStateException(result.failStackTrace ?: result.output),
                                logOutput = result.output
                            )
                        )
                    }
                    close()
                }
            )

        } catch (e: Exception) {
            Log.e(TAG, "Audio extraction exception: ${e.message}", e)
            trySend(
                FFmpegProgress(
                    state = FFmpegState.FAILED,
                    error = e
                )
            )
            close(e)
        }

        awaitClose {
            if (activeSessionId > 0L) {
                FFmpegEngine.cancel(activeSessionId)
            }
            if (resolvedSource?.isTemporaryFile == true) {
                TemporaryMediaManager.deleteSilently(resolvedSource?.temporaryFile)
            }
        }
    }
}
