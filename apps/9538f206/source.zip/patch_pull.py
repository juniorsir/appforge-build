import sys

with open("app/src/main/java/com/example/ui/VideoDownloaderScreen.kt", "r") as f:
    lines = f.readlines()

out = []
for i, line in enumerate(lines):
    if "if (filteredItems.isEmpty()) {" in line and "Column(" in lines[i+1]:
        out.append('            var isRefreshing by remember { mutableStateOf(false) }\n')
        out.append('            val coroutineScope = rememberCoroutineScope()\n')
        out.append('            @OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)\n')
        out.append('            val pullRefreshState = androidx.compose.material3.pulltorefresh.rememberPullToRefreshState()\n')
        out.append('            \n')
        out.append('            @OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)\n')
        out.append('            androidx.compose.material3.pulltorefresh.PullToRefreshBox(\n')
        out.append('                isRefreshing = isRefreshing,\n')
        out.append('                onRefresh = {\n')
        out.append('                    isRefreshing = true\n')
        out.append('                    coroutineScope.launch {\n')
        out.append('                        viewModel?.forceRefreshDownloads()\n')
        out.append('                        kotlinx.coroutines.delay(800)\n')
        out.append('                        isRefreshing = false\n')
        out.append('                    }\n')
        out.append('                },\n')
        out.append('                state = pullRefreshState,\n')
        out.append('                modifier = Modifier.weight(1f).fillMaxWidth()\n')
        out.append('            ) {\n')
        out.append(line)
    elif "suspend fun checkThumbnailUsability" in line:
        # Before this line, we need to add the closing brace for PullToRefreshBox.
        # But wait, there are braces before this line.
        # Let's just insert one brace at the right level before it.
        # Wait, the closing braces are:
        #             }
        #         }
        #     }
        # }
        # Let's just add it!
        pass # We will do it properly
    else:
        out.append(line)

# Let's do it safer.
