package com.example

import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import android.widget.FrameLayout
import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.drag
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.DownloadStatus
import com.example.ui.VideoDownloaderViewModel
import kotlin.math.roundToInt

class FloatingWidgetService : Service(), LifecycleOwner, ViewModelStoreOwner, SavedStateRegistryOwner {

    private lateinit var windowManager: WindowManager
    private var overlayLayout: FrameLayout? = null
    
    private val lifecycleRegistry = LifecycleRegistry(this)
    private val store = ViewModelStore()
    private val savedRegistryController = SavedStateRegistryController.create(this)

    override val lifecycle: Lifecycle get() = lifecycleRegistry
    override val viewModelStore: ViewModelStore get() = store
    override val savedStateRegistry: SavedStateRegistry get() = savedRegistryController.savedStateRegistry

    override fun onCreate() {
        super.onCreate()
        savedRegistryController.performRestore(null)
        lifecycleRegistry.currentState = Lifecycle.State.CREATED
        lifecycleRegistry.currentState = Lifecycle.State.STARTED
        lifecycleRegistry.currentState = Lifecycle.State.RESUMED
        
        setupFloatingWidget()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun setupFloatingWidget() {
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        
        val context = this
        val layoutParams = WindowManager.LayoutParams().apply {
            type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            } else {
                @Suppress("DEPRECATION")
                WindowManager.LayoutParams.TYPE_PHONE
            }
            format = PixelFormat.TRANSLUCENT
            flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
            width = WindowManager.LayoutParams.WRAP_CONTENT
            height = WindowManager.LayoutParams.WRAP_CONTENT
            gravity = Gravity.TOP or Gravity.START
            x = 100
            y = 500
        }

        val overlay = FrameLayout(context)
        overlay.setViewTreeLifecycleOwner(this)
        overlay.setViewTreeViewModelStoreOwner(this)
        overlay.setViewTreeSavedStateRegistryOwner(this)

        val factory = ViewModelProvider.AndroidViewModelFactory.getInstance(application)
        val viewModel = ViewModelProvider(store, factory)[VideoDownloaderViewModel::class.java]

        val composeView = ComposeView(context).apply {
            setContent {
                MyApplicationTheme {
                    var isExpanded by remember { mutableStateOf(false) }
                    var searchText by remember { mutableStateOf("") }
                    
                    val isAnalyzing by viewModel.isAnalyzing.collectAsState()
                    val analyzedVideo by viewModel.analyzedVideo.collectAsState()
                    val activeDownloads by viewModel.activeDownloads.collectAsState()

                    val activeTask = activeDownloads.values.firstOrNull {
                        it.status == DownloadStatus.DOWNLOADING || it.status == DownloadStatus.PENDING
                    }
                    
                    Surface(
                        modifier = Modifier.wrapContentSize(),
                        color = Color.Transparent
                    ) {
                        AnimatedContent(
                            targetState = isExpanded,
                            transitionSpec = {
                                fadeIn(animationSpec = tween(300)) togetherWith fadeOut(animationSpec = tween(300))
                            }
                        ) { targetExpanded ->
                            if (!targetExpanded) {
                                Box(
                                    modifier = Modifier
                                        .size(56.dp)
                                        .clip(CircleShape)
                                        .background(MaterialTheme.colorScheme.primaryContainer)
                                        .border(1.5.dp, MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.5f), CircleShape)
                                        .pointerInput(Unit) {
                                            awaitEachGesture {
                                                val down = awaitFirstDown()
                                                var dragged = false
                                                drag(down.id) { change ->
                                                    val changeAmount = change.positionChange()
                                                    layoutParams.x += changeAmount.x.toInt()
                                                    layoutParams.y += changeAmount.y.toInt()
                                                    try {
                                                        windowManager.updateViewLayout(overlay, layoutParams)
                                                    } catch (e: Exception) {
                                                        // ignore
                                                    }
                                                    change.consume()
                                                    dragged = true
                                                }
                                                if (!dragged) {
                                                    isExpanded = true
                                                    updateWindowFocus(true)
                                                }
                                            }
                                        },
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (activeTask != null || isAnalyzing) {
                                         CircularProgressIndicator(
                                             color = MaterialTheme.colorScheme.onPrimaryContainer,
                                             strokeWidth = 2.dp,
                                             modifier = Modifier.size(32.dp)
                                         )
                                    } else {
                                         Icon(
                                             imageVector = Icons.Default.Search,
                                             contentDescription = "Search bubble",
                                             tint = MaterialTheme.colorScheme.onPrimaryContainer,
                                             modifier = Modifier.size(28.dp)
                                         )
                                    }
                                }
                            } else {
                                Column(
                                    modifier = Modifier
                                        .width(300.dp)
                                        .clip(RoundedCornerShape(24.dp))
                                        .background(MaterialTheme.colorScheme.surface)
                                        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(24.dp))
                                        .padding(bottom = if (analyzedVideo != null || isAnalyzing) 16.dp else 0.dp)
                                ) {
                                    // Search Row
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(60.dp)
                                            .pointerInput(Unit) {
                                                awaitEachGesture {
                                                    val down = awaitFirstDown()
                                                    drag(down.id) { change ->
                                                        val changeAmount = change.positionChange()
                                                        layoutParams.x += changeAmount.x.toInt()
                                                        layoutParams.y += changeAmount.y.toInt()
                                                        try {
                                                            windowManager.updateViewLayout(overlay, layoutParams)
                                                        } catch (e: Exception) {
                                                            // ignore
                                                        }
                                                        change.consume()
                                                    }
                                                }
                                            }
                                            .padding(horizontal = 16.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        BasicTextField(
                                            value = searchText,
                                            onValueChange = { searchText = it },
                                            singleLine = true,
                                            textStyle = MaterialTheme.typography.bodyMedium.copy(color = MaterialTheme.colorScheme.onSurface),
                                            decorationBox = { innerTextField ->
                                                if (searchText.isEmpty()) {
                                                    Text(
                                                        text = "Search or paste link...",
                                                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                                                        fontSize = 14.sp
                                                    )
                                                }
                                                innerTextField()
                                            },
                                            modifier = Modifier.weight(1f)
                                        )

                                        if (searchText.isNotEmpty()) {
                                            IconButton(
                                                onClick = { searchText = "" },
                                                modifier = Modifier.size(36.dp)
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.Close,
                                                    contentDescription = "Clear",
                                                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                            }
                                        }

                                        IconButton(
                                            onClick = {
                                                if (searchText.isNotBlank()) {
                                                    viewModel.updateUrlInput(searchText)
                                                    viewModel.analyzeVideo()
                                                }
                                            },
                                            modifier = Modifier
                                                .size(40.dp)
                                                .background(MaterialTheme.colorScheme.primary, CircleShape)
                                        ) {
                                            if (isAnalyzing) {
                                                CircularProgressIndicator(
                                                    color = MaterialTheme.colorScheme.onPrimary,
                                                    strokeWidth = 2.dp,
                                                    modifier = Modifier.size(20.dp)
                                                )
                                            } else {
                                                Icon(
                                                    imageVector = Icons.Default.Search,
                                                    contentDescription = "Submit search",
                                                    tint = MaterialTheme.colorScheme.onPrimary
                                                )
                                            }
                                        }

                                        IconButton(
                                            onClick = {
                                                isExpanded = false
                                                updateWindowFocus(false)
                                            },
                                            modifier = Modifier.size(36.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Close,
                                                contentDescription = "Collapse",
                                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }

                                    // Results Content
                                    if (analyzedVideo != null && !isAnalyzing) {
                                        val video = analyzedVideo!!
                                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                                        Column(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(top = 16.dp, start = 16.dp, end = 16.dp),
                                            verticalArrangement = Arrangement.spacedBy(12.dp)
                                        ) {
                                            Text(
                                                text = video.title,
                                                color = MaterialTheme.colorScheme.onSurface,
                                                style = MaterialTheme.typography.titleSmall,
                                                maxLines = 2
                                            )
                                            
                                            val commonFormats = video.formats.filter { it.quality in listOf("1080p", "720p", "360p", "audio") }
                                                .distinctBy { it.quality }
                                                
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                                            ) {
                                                commonFormats.take(3).forEach { format ->
                                                    Button(
                                                        onClick = { 
                                                            viewModel.startDownload(video, format)
                                                            isExpanded = false
                                                            updateWindowFocus(false)
                                                            searchText = ""
                                                        },
                                                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
                                                        shape = RoundedCornerShape(12.dp),
                                                        modifier = Modifier.height(40.dp).weight(1f)
                                                    ) {
                                                        Text(format.quality, color = MaterialTheme.colorScheme.onSecondaryContainer, style = MaterialTheme.typography.labelMedium)
                                                    }
                                                }
                                            }
                                        }
                                    } else if (activeTask != null) {
                                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                                        Column(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(top = 16.dp, start = 16.dp, end = 16.dp)
                                        ) {
                                            Text(
                                                text = activeTask.title,
                                                color = MaterialTheme.colorScheme.onSurface,
                                                style = MaterialTheme.typography.labelMedium,
                                                maxLines = 1
                                            )
                                            LinearProgressIndicator(
                                                progress = { activeTask.progress },
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .padding(vertical = 8.dp)
                                                    .height(8.dp)
                                                    .clip(RoundedCornerShape(4.dp)),
                                                color = MaterialTheme.colorScheme.primary,
                                                trackColor = MaterialTheme.colorScheme.surfaceVariant,
                                            )
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween
                                            ) {
                                                Text(activeTask.speedText, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelSmall)
                                                val mbDownloaded = activeTask.downloadedBytes / (1024L * 1024L)
                                                val mbTotal = activeTask.totalBytes / (1024L * 1024L)
                                                Text("${mbDownloaded}MB / ${mbTotal}MB", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelSmall)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }


        overlay.addView(composeView)

        windowManager.addView(overlay, layoutParams)
        overlayLayout = overlay
    }

    private fun updateWindowFocus(focusable: Boolean) {
        val overlay = overlayLayout ?: return
        val layoutParams = overlay.layoutParams as WindowManager.LayoutParams
        if (focusable) {
            layoutParams.flags = WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
        } else {
            layoutParams.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
        }
        windowManager.updateViewLayout(overlay, layoutParams)
    }

    override fun onDestroy() {
        super.onDestroy()
        lifecycleRegistry.currentState = Lifecycle.State.DESTROYED
        overlayLayout?.let {
            try {
                windowManager.removeView(it)
            } catch (e: Exception) {
                // Ignore
            }
        }
    }
}
