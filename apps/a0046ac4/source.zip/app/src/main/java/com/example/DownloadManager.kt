package com.example

import android.content.Context
import android.content.Intent
import android.util.Log
import com.example.data.DownloadEntity
import com.example.ui.ActiveDownloadTask
import com.example.ui.AnalyzedVideo
import com.example.ui.DownloadStatus
import com.example.ui.VideoFormatUi
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.*

object DownloadManager {
    private const val TAG = "DownloadManager"

    private val _activeDownloads = MutableStateFlow<Map<String, ActiveDownloadTask>>(emptyMap())
    val activeDownloads = _activeDownloads.asStateFlow()

    private val _logs = MutableStateFlow<List<String>>(emptyList())
    val logs = _logs.asStateFlow()

    private val activeJobs = java.util.concurrent.ConcurrentHashMap<String, Job>()

    private val sdf = SimpleDateFormat("HH:mm:ss", Locale.getDefault())

    fun updateActiveDownloads(map: Map<String, ActiveDownloadTask>) {
        _activeDownloads.value = map
    }

    fun removeActiveTask(id: String) {
        _activeDownloads.value = _activeDownloads.value - id
        activeJobs.remove(id)?.cancel()
    }

    fun cancelDownload(id: String) {
        addLog("⚠️ Cancelling download task: $id")
        removeActiveTask(id)
    }

    fun addLog(msg: String) {
        val time = sdf.format(Date())
        val formatted = "[$time] $msg"
        Log.d(TAG, formatted)
        val current = _logs.value.takeLast(299) // Keep last 300 logs
        _logs.value = current + formatted
    }

    fun clearLogs() {
        _logs.value = emptyList()
    }

    fun startDownload(context: Context, video: AnalyzedVideo, format: VideoFormatUi, usePublicDownloads: Boolean) {
        val videoId = video.id
        val idWithFormat = "${videoId}_${format.formatId}"

        addLog("--------------------------------------------------")
        addLog("📥 INITIATING VIDEO DOWNLOAD STAGE")
        addLog("Title: \"${video.title}\"")
        addLog("Codec Format: ${format.ext} - ${format.quality}")

        // Create initial pending state
        val initialTask = ActiveDownloadTask(
            id = idWithFormat,
            title = video.title,
            progress = 0f,
            speedText = "Connecting...",
            downloadedBytes = 0,
            totalBytes = format.sizeBytes,
            status = DownloadStatus.PENDING,
            ext = format.ext
        )

        _activeDownloads.value = _activeDownloads.value + (idWithFormat to initialTask)

        // Delegate execution via Foreground Service
        val intent = Intent(context, DownloadForegroundService::class.java).apply {
            action = DownloadForegroundService.ACTION_START_DOWNLOAD
            putExtra("idWithFormat", idWithFormat)
            putExtra("video_title", video.title)
            putExtra("video_id", videoId)
            putExtra("video_author", video.author)
            putExtra("video_duration", video.durationText)
            putExtra("video_thumb", video.thumbnailUrl)
            putExtra("video_url", video.originalUrl)
            putExtra("format_id", format.formatId.toString())
            putExtra("format_ext", format.ext)
            putExtra("format_size", format.sizeBytes)
            putExtra("format_quality", format.quality)
            putExtra("format_type", format.type)
            putExtra("use_public_downloads", usePublicDownloads)
            
            // Collect metadata for combining logic
            val combinedFormats = video.formats.filter { it.type == "audio" }
            val audioFormatId = combinedFormats.firstOrNull { it.ext == "m4a" || it.ext == "mp4" }?.formatId?.toString()
                ?: combinedFormats.firstOrNull()?.formatId?.toString() ?: ""
            putExtra("audio_format_id", audioFormatId)
        }

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            context.startForegroundService(intent)
        } else {
            context.startService(intent)
        }
    }

    fun convertAudio(context: Context, item: DownloadEntity) {
        addLog("🎵 Queueing audio conversion for: ${item.title}")
        
        val intent = Intent(context, DownloadForegroundService::class.java).apply {
            action = DownloadForegroundService.ACTION_CONVERT_MP3
            putExtra("item_id", item.id)
            putExtra("item_title", item.title)
            putExtra("item_author", item.author)
            putExtra("item_duration", item.durationText)
            putExtra("item_thumb", item.thumbnailUrl)
            putExtra("item_path", item.localPath)
        }

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            context.startForegroundService(intent)
        } else {
            context.startService(intent)
        }
    }

    // Helper method called by internal download thread inside service to track the active job
    fun registerJob(id: String, job: Job) {
        activeJobs[id]?.cancel()
        activeJobs[id] = job
    }
}
