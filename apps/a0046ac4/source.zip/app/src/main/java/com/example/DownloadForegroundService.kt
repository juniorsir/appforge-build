package com.example

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Environment
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.example.data.AppDatabase
import com.example.data.DownloadEntity
import com.example.ui.ActiveDownloadTask
import com.example.ui.DownloadStatus
import com.example.ui.YtdlpPipelineManager
import kotlinx.coroutines.*
import java.io.File
import java.util.Locale

class DownloadForegroundService : Service() {
    private val CHANNEL_ID = "DownloadChannel"
    private val NOTIFICATION_ID = 2026 // unique notification ID
    private val serviceJob = SupervisorJob()
    private val serviceScope = CoroutineScope(Dispatchers.IO + serviceJob)
    
    // Track active runs in service
    private var activeTaskCount = 0

    companion object {
        const val ACTION_START_DOWNLOAD = "ACTION_START_DOWNLOAD"
        const val ACTION_CONVERT_MP3 = "ACTION_CONVERT_MP3"
        const val ACTION_STOP = "ACTION_STOP"
        const val ACTION_START = "ACTION_START"
        
        fun stopService(context: Context) {
            val intent = Intent(context, DownloadForegroundService::class.java).apply {
                action = ACTION_STOP
            }
            context.startService(intent)
        }
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null) return START_NOT_STICKY
        
        when (intent.action) {
            ACTION_STOP -> {
                if (activeTaskCount == 0) {
                    stopForeground(STOP_FOREGROUND_REMOVE)
                    stopSelf()
                }
            }
            ACTION_START -> {
                val title = intent.getStringExtra("title") ?: "Downloading media..."
                updateForegroundNotification(title)
            }
            ACTION_START_DOWNLOAD -> {
                activeTaskCount++
                val idWithFormat = intent.getStringExtra("idWithFormat") ?: ""
                val videoTitle = intent.getStringExtra("video_title") ?: "Media Download"
                
                // Show notification immediately to meet foreground service criteria
                updateForegroundNotification("Downloading: $videoTitle")
                
                val db = AppDatabase.getDatabase(applicationContext)
                
                val job = serviceScope.launch(Dispatchers.IO) {
                    runDownloadTask(intent, db)
                }
                if (idWithFormat.isNotEmpty()) {
                    DownloadManager.registerJob(idWithFormat, job)
                }
            }
            ACTION_CONVERT_MP3 -> {
                activeTaskCount++
                val itemTitle = intent.getStringExtra("item_title") ?: "Converting audio..."
                updateForegroundNotification("Converting to MP3: $itemTitle")
                
                val db = AppDatabase.getDatabase(applicationContext)
                serviceScope.launch(Dispatchers.IO) {
                    runConversionTask(intent, db)
                }
            }
        }
        return START_NOT_STICKY
    }

    private fun updateForegroundNotification(text: String, progress: Float = -1f) {
        val notification = createNotification(text, progress)
        startForeground(NOTIFICATION_ID, notification)
    }

    private suspend fun runDownloadTask(intent: Intent, db: AppDatabase) {
        val idWithFormat = intent.getStringExtra("idWithFormat") ?: ""
        val videoTitle = intent.getStringExtra("video_title") ?: ""
        val videoId = intent.getStringExtra("video_id") ?: ""
        val videoAuthor = intent.getStringExtra("video_author") ?: ""
        val videoDuration = intent.getStringExtra("video_duration") ?: ""
        val videoThumb = intent.getStringExtra("video_thumb") ?: ""
        val originalUrl = intent.getStringExtra("video_url") ?: ""
        val formatId = intent.getStringExtra("format_id") ?: ""
        val formatExt = intent.getStringExtra("format_ext") ?: ""
        val formatSize = intent.getLongExtra("format_size", 0L)
        val formatQuality = intent.getStringExtra("format_quality") ?: ""
        val formatType = intent.getStringExtra("format_type") ?: ""
        val usePublicDownloads = intent.getBooleanExtra("use_public_downloads", false)
        val audioFormatId = intent.getStringExtra("audio_format_id") ?: ""

        val directory = if (usePublicDownloads) {
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
        } else {
            getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: filesDir
        }
        
        if (!directory.exists()) {
            directory.mkdirs()
        }

        // Sanitize filename
        val sanitizedTitle = videoTitle.replace(Regex("[\\\\/:*?\"<>|]"), "_")
        val isMuxNeeded = formatType == "video_only"
        val actualIsMuxNeeded = isMuxNeeded && audioFormatId.isNotEmpty()
        val finalExt = if (actualIsMuxNeeded) "mp4" else formatExt
        val fileName = "${sanitizedTitle}_$formatQuality.$finalExt"
        val file = File(directory, fileName)

        DownloadManager.addLog("📁 Target Output File: \"${file.absolutePath}\"")

        try {
            if (originalUrl.isNotEmpty()) {
                DownloadManager.addLog("🚀 [DownloadForegroundService] Submitting target request natively to JNI libraries...")
                val formatOption = if (actualIsMuxNeeded) {
                    "$formatId+$audioFormatId"
                } else {
                    formatId
                }
                
                try {
                    YtdlpPipelineManager.downloadUrlWithNative(
                        context = applicationContext,
                        url = originalUrl,
                        formatId = formatOption,
                        outputFile = file
                    ) { progress, etaInSeconds, line ->
                        val percent = progress / 100f
                        val task = DownloadManager.activeDownloads.value[idWithFormat]
                        if (task != null) {
                            val etaFormatted = if (etaInSeconds > 0) " (ETA ${etaInSeconds}s)" else ""
                            val speedText = String.format(Locale.getDefault(), "Downloading: %.1f%% %s", progress, etaFormatted)
                            
                            // Update shared state
                            val updatedMap = DownloadManager.activeDownloads.value + (idWithFormat to task.copy(
                                progress = percent,
                                speedText = speedText,
                                status = DownloadStatus.DOWNLOADING,
                                downloadedBytes = (formatSize * percent).toLong(),
                                totalBytes = formatSize
                            ))
                            DownloadManager.updateActiveDownloads(updatedMap)
                            
                            // Live update notification progress
                            updateForegroundNotification("Downloading: $videoTitle", progress)
                        }
                    }
                    DownloadManager.addLog("🟢 [DownloadForegroundService] Native JNI execute session finished successfully.")
                } catch (e: Throwable) {
                    DownloadManager.addLog("❌ [DownloadForegroundService] Native JNI execution failed or was interrupted: ${e.localizedMessage}")
                    if (file.exists()) {
                        file.delete()
                    }
                    throw e
                }
            }

            // Complete!
            val fileSizeFinal = file.length()
            DownloadManager.addLog("✔ Stream transfer complete: Successfully cached $fileSizeFinal bytes locally.")
            val completedTask = ActiveDownloadTask(
                id = idWithFormat,
                title = videoTitle,
                progress = 1f,
                speedText = "Finished",
                downloadedBytes = fileSizeFinal,
                totalBytes = fileSizeFinal,
                status = DownloadStatus.COMPLETED,
                ext = finalExt
            )
            DownloadManager.updateActiveDownloads(DownloadManager.activeDownloads.value + (idWithFormat to completedTask))

            // Add details to persistent Room History
            val downloadRecord = DownloadEntity(
                id = idWithFormat,
                title = videoTitle,
                author = videoAuthor,
                durationText = videoDuration,
                thumbnailUrl = videoThumb,
                localPath = file.absolutePath,
                fileSize = fileSizeFinal,
                downloadedAt = System.currentTimeMillis()
            )
            db.downloadDao().insertDownload(downloadRecord)
            DownloadManager.addLog("🎉 Record successfully written to SQLite Database history.")
            
            // Automatically clear active download card from list 2 seconds after completion
            serviceScope.launch {
                delay(2000)
                DownloadManager.removeActiveTask(idWithFormat)
            }

        } catch (ce: CancellationException) {
            DownloadManager.addLog("⚠️ Stream transfer was explicitly cancelled by user.")
            try {
                if (file.exists()) {
                    file.delete()
                }
            } catch (e: Exception) {
                DownloadManager.addLog("⚠️ Failed clean deletion of incomplete caching chunks: ${e.message}")
            }
            DownloadManager.removeActiveTask(idWithFormat)
        } catch (e: Throwable) {
            val errMsg = e.localizedMessage ?: e.javaClass.simpleName ?: "Failed to completely stream video chunk buffers."
            DownloadManager.addLog("❌ Download failed: $errMsg")
            DownloadManager.updateActiveDownloads(DownloadManager.activeDownloads.value + (idWithFormat to ActiveDownloadTask(
                id = idWithFormat,
                title = videoTitle,
                progress = 0f,
                speedText = "Failed",
                downloadedBytes = 0,
                totalBytes = formatSize,
                status = DownloadStatus.FAILED,
                ext = formatExt,
                error = errMsg
            )))
        } finally {
            decrementTaskCount()
        }
    }

    private suspend fun runConversionTask(intent: Intent, db: AppDatabase) {
        val itemId = intent.getStringExtra("item_id") ?: ""
        val itemTitle = intent.getStringExtra("item_title") ?: "Audio"
        val itemAuthor = intent.getStringExtra("item_author") ?: ""
        val itemDuration = intent.getStringExtra("item_duration") ?: ""
        val itemThumb = intent.getStringExtra("item_thumb") ?: ""
        val itemPath = intent.getStringExtra("item_path") ?: ""

        try {
            val inputFile = File(itemPath)
            if (!inputFile.exists()) {
                DownloadManager.addLog("❌ Source file not found for conversion: ${inputFile.name}")
                return
            }
            
            val downloadsDir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "TubeStream")
            if (!downloadsDir.exists()) downloadsDir.mkdirs()
            
            val titleEscaped = itemTitle.replace(Regex("[^a-zA-Z0-9.\\-]"), "_")
            val outputFile = File(downloadsDir, "${titleEscaped}_audio.mp3")

            DownloadManager.addLog("🎵 Starting MP3 extraction for: $itemTitle")
            
            val args = arrayOf(
                "-y",
                "-i", inputFile.absolutePath,
                "-vn", // No video
                "-acodec", "libmp3lame", // Explicitly use mp3 lame if present
                "-q:a", "2",
                outputFile.absolutePath
            )

            YtdlpPipelineManager.init(applicationContext)
            
            // Invoke FFmpeg via our secure and robust reflection wrapper
            try {
                DownloadManager.addLog("⚡ Executing Native FFmpeg JNI conversion...")
                executeFFmpeg(args)
                DownloadManager.addLog("⚡ Native FFmpeg execution command returned.")
            } catch (ffmpegEx: Exception) {
                DownloadManager.addLog("❌ Primary FFmpeg execution failed: ${ffmpegEx.localizedMessage}")
            }
            
            if (outputFile.exists() && outputFile.length() > 0) {
                DownloadManager.addLog("✅ MP3 extracted successfully: ${outputFile.name}")
                val newEntity = DownloadEntity(
                    id = "conv_${System.currentTimeMillis()}",
                    title = "$itemTitle (Audio MP3)",
                    author = itemAuthor,
                    durationText = itemDuration,
                    thumbnailUrl = itemThumb,
                    localPath = outputFile.absolutePath,
                    fileSize = outputFile.length(),
                    downloadedAt = System.currentTimeMillis()
                )
                db.downloadDao().insertDownload(newEntity)
            } else {
                DownloadManager.addLog("🔴 FFmpeg MP3 Extraction failed. Trying generic copy to file as last resort...")
                // In some cases if MP3 transcode fails due to lack of libmp3lame, let's copy with general AAC copy to .m4a as fallback!
                val fallbackFile = File(downloadsDir, "${titleEscaped}_audio.m4a")
                val fallbackArgs = arrayOf(
                    "-y",
                    "-i", inputFile.absolutePath,
                    "-vn",
                    "-c:a", "copy",
                    fallbackFile.absolutePath
                )
                try {
                    DownloadManager.addLog("⚡ Executing fallback AAC copy command...")
                    executeFFmpeg(fallbackArgs)
                } catch (e: Exception) {
                    DownloadManager.addLog("❌ Fallback conversion failed: ${e.localizedMessage}")
                }
                
                if (fallbackFile.exists() && fallbackFile.length() > 0) {
                    DownloadManager.addLog("✅ MP3 conversion fallback (M4A stream copy) succeeded.")
                    val newEntity = DownloadEntity(
                        id = "conv_${System.currentTimeMillis()}",
                        title = "$itemTitle (Audio m4a)",
                        author = itemAuthor,
                        durationText = itemDuration,
                        thumbnailUrl = itemThumb,
                        localPath = fallbackFile.absolutePath,
                        fileSize = fallbackFile.length(),
                        downloadedAt = System.currentTimeMillis()
                    )
                    db.downloadDao().insertDownload(newEntity)
                } else {
                    DownloadManager.addLog("🔴 MP3 Extraction fallback failed completely.")
                }
            }
        } catch (e: Exception) {
            DownloadManager.addLog("💀 Convert Audio Error: ${e.message}")
        } finally {
            decrementTaskCount()
        }
    }

    @Synchronized
    private fun decrementTaskCount() {
        activeTaskCount = maxOf(0, activeTaskCount - 1)
        if (activeTaskCount == 0) {
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        } else {
            val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.notify(NOTIFICATION_ID, createNotification("$activeTaskCount media tasks active background...", -1f))
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        serviceJob.cancel()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val serviceChannel = NotificationChannel(
                CHANNEL_ID,
                "Download Service Channel",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Keeps downloads running in the background securely"
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(serviceChannel)
        }
    }

    private fun createNotification(contentText: String, progress: Float): Notification {
        val notificationIntent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this, 0, notificationIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("TubeStream Background Engine")
            .setContentText(contentText)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setOngoing(true)
            .setContentIntent(pendingIntent)

        if (progress >= 0f) {
            builder.setProgress(100, progress.toInt(), false)
        } else {
            builder.setProgress(0, 0, true) // indeterminate state
        }

        return builder.build()
    }

    private fun executeFFmpeg(args: Array<String>) {
        try {
            val ffmpegClass = Class.forName("com.yausername.ffmpeg.FFmpeg")
            val getInstanceMethod = ffmpegClass.getMethod("getInstance")
            val ffmpegInstance = getInstanceMethod.invoke(null)
            val executionMethod = ffmpegClass.getMethod("execute", Array<String>::class.java)
            executionMethod.isAccessible = true
            executionMethod.invoke(ffmpegInstance, arrayOf<Any>(args))
        } catch (e: Exception) {
            DownloadManager.addLog("❌ FFmpeg execution failed: ${e.localizedMessage}")
            throw e
        }
    }
}
