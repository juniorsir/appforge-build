package com.example.ui

import android.content.Context
import android.util.Log
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.animation.core.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.example.data.DownloadEntity
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.IntOffset
import kotlin.math.roundToInt
import androidx.compose.ui.graphics.graphicsLayer

// Theme Palette
data class SleekColors(
    val bg: Color,
    val card: Color,
    val surface: Color,
    val primary: Color,
    val accent: Color,
    val container: Color,
    val textPrimary: Color,
    val textSecondary: Color,
    val textMuted: Color,
    val border: Color,
    val failure: Color,
    val success: Color,
    val gradient: Brush
)

val LocalSleekColors = staticCompositionLocalOf<SleekColors> { error("No SleekColors provided") }

@Composable
fun getSleekColors(themeMode: String): SleekColors {
    val systemDark = isSystemInDarkTheme()
    val isDark = when (themeMode) {
        "Dark Mode" -> true
        "Light Mode" -> false
        else -> systemDark
    }
    return if (isDark) {
        SleekColors(
            bg = Color(0xFF121212),
            card = Color(0xFF202020),
            surface = Color(0xFF1A1A1A),
            primary = Color(0xFF8B1E2D),
            accent = Color(0xFFD97706),
            container = Color(0xFF2A2A2A),
            textPrimary = Color(0xFFFFFFFF),
            textSecondary = Color(0xFFA8A8A8),
            textMuted = Color(0xFF707070),
            border = Color(0xFF2A2A2A),
            failure = Color(0xFFB3263A),
            success = Color(0xFFD97706),
            gradient = Brush.linearGradient(
                colors = listOf(
                    Color(0xFF6D120F),
                    Color(0xFF8B1E2D),
                    Color(0xFFB3263A),
                    Color(0xFFD97706)
                )
            )
        )
    } else {
        SleekColors(
            bg = Color(0xFFFAFAFA),
            card = Color(0xFFFFFFFF),
            surface = Color(0xFFFFFFFF),
            primary = Color(0xFF8B1E2D),
            accent = Color(0xFFD97708),
            container = Color(0xFFEAEAEA),
            textPrimary = Color(0xFF1A1A1A),
            textSecondary = Color(0xFF666666),
            textMuted = Color(0xFF999999),
            border = Color(0xFFEAEAEA),
            failure = Color(0xFFB3263A),
            success = Color(0xFFD97708),
            gradient = Brush.linearGradient(
                colors = listOf(
                    Color(0xFFFFD6DD),
                    Color(0xFFF0D9F5),
                    Color(0xFFD8E8FF)
                )
            )
        )
    }
}

// Global accessor shortcuts that bridge to the current theme
val SleekBg @Composable get() = LocalSleekColors.current.bg
val SleekCard @Composable get() = LocalSleekColors.current.card
val SleekCardDark @Composable get() = LocalSleekColors.current.surface
val SleekPurpleDark @Composable get() = LocalSleekColors.current.primary
val SleekPurpleLight @Composable get() = LocalSleekColors.current.accent
val SleekPurpleContainer @Composable get() = LocalSleekColors.current.container
val SleekTextPrimary @Composable get() = LocalSleekColors.current.textPrimary
val SleekTextSecondary @Composable get() = LocalSleekColors.current.textSecondary
val SleekTextMuted @Composable get() = LocalSleekColors.current.textMuted
val SleekBorderColor @Composable get() = LocalSleekColors.current.border
val CrimsonFailure @Composable get() = LocalSleekColors.current.failure
val EmeraldSuccess @Composable get() = LocalSleekColors.current.success
val HeroGradient @Composable get() = LocalSleekColors.current.gradient

// Backwards compatibility mappings for existing layouts
val SlateBg @Composable get() = SleekBg
val SlateCard @Composable get() = SleekCard
val SlateCardDark @Composable get() = SleekCardDark
val AmberAccent @Composable get() = SleekPurpleDark
val AmberAccentLight @Composable get() = SleekPurpleDark
val SilverText @Composable get() = SleekTextSecondary
val WhiteText @Composable get() = SleekTextPrimary

@OptIn(ExperimentalMaterial3Api::class, com.google.accompanist.permissions.ExperimentalPermissionsApi::class)
@Composable
fun VideoDownloaderScreen(
    viewModel: VideoDownloaderViewModel,
    modifier: Modifier = Modifier
) {
    val themeMode by viewModel.themeMode.collectAsStateWithLifecycle()
    val colors = getSleekColors(themeMode)
    CompositionLocalProvider(LocalSleekColors provides colors) {
        val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current

    val initialPermissions = buildList {
        if (android.os.Build.VERSION.SDK_INT >= 33) {
            add(android.Manifest.permission.READ_MEDIA_VIDEO)
            add(android.Manifest.permission.READ_MEDIA_AUDIO)
            add(android.Manifest.permission.POST_NOTIFICATIONS)
        } else {
            add(android.Manifest.permission.READ_EXTERNAL_STORAGE)
            add(android.Manifest.permission.WRITE_EXTERNAL_STORAGE)
        }
    }

    val permissionState = com.google.accompanist.permissions.rememberMultiplePermissionsState(initialPermissions)
    var showPermissionDialog by remember { mutableStateOf(!permissionState.allPermissionsGranted) }

    LaunchedEffect(Unit) {
        if (!permissionState.allPermissionsGranted) {
            permissionState.launchMultiplePermissionRequest()
        }
    }

    if (!permissionState.allPermissionsGranted && showPermissionDialog) {
        androidx.compose.ui.window.Dialog(
            onDismissRequest = { showPermissionDialog = false },
            properties = androidx.compose.ui.window.DialogProperties(
                dismissOnBackPress = true,
                dismissOnClickOutside = false
            )
        ) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
                    .border(1.dp, SleekBorderColor, RoundedCornerShape(24.dp)),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = SleekCardDark)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(64.dp)
                            .background(SleekPurpleLight.copy(alpha = 0.1f), CircleShape)
                            .border(1.dp, SleekPurpleLight.copy(alpha = 0.3f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Lock,
                            contentDescription = null,
                            tint = SleekPurpleLight,
                            modifier = Modifier.size(32.dp)
                        )
                    }

                    Text(
                        text = "Permissions Required",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = SleekTextPrimary
                        ),
                        textAlign = TextAlign.Center
                    )

                    Text(
                        text = "To download media files, save them locally, convert to MP3, and post active download alerts, TubeStream needs storage and notifications access.",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = SleekTextSecondary,
                            lineHeight = 20.sp
                        ),
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = {
                                permissionState.launchMultiplePermissionRequest()
                                if (!permissionState.allPermissionsGranted) {
                                    try {
                                        val intent = android.content.Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                                            data = android.net.Uri.fromParts("package", context.packageName, null)
                                        }
                                        context.startActivity(intent)
                                    } catch (e: Exception) {
                                        // fallback ignore
                                    }
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = SleekPurpleLight,
                                contentColor = SleekBg
                            ),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text(
                                text = "Grant Access",
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.labelLarge
                            )
                        }

                        TextButton(
                            onClick = { showPermissionDialog = false },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "Skip for Now",
                                color = SleekTextMuted,
                                style = MaterialTheme.typography.labelLarge
                            )
                        }
                    }
                }
            }
        }
    }

    val urlInput by viewModel.videoUrlInput.collectAsStateWithLifecycle()
    val isAnalyzing by viewModel.isAnalyzing.collectAsStateWithLifecycle()
    val analyzedVideo by viewModel.analyzedVideo.collectAsStateWithLifecycle()
    val analysisError by viewModel.analysisError.collectAsStateWithLifecycle()
    val activeDownloads by viewModel.activeDownloads.collectAsStateWithLifecycle()
    val downloadHistory by viewModel.downloadHistory.collectAsStateWithLifecycle()
    val deviceMedia by viewModel.deviceMedia.collectAsStateWithLifecycle()
    
    LaunchedEffect(permissionState.allPermissionsGranted) {
        if (permissionState.allPermissionsGranted) {
            viewModel.loadDeviceMedia(context)
        }
    }
    val executionLogs by viewModel.executionLogs.collectAsStateWithLifecycle()
    val isAudioOnly by viewModel.isAudioOnlyMode.collectAsStateWithLifecycle()
    val searchResults by viewModel.searchResults.collectAsStateWithLifecycle()
    val isSearching by viewModel.isSearching.collectAsStateWithLifecycle()

    var selectedTabIndex by remember { mutableStateOf(0) }
    var playingDownload by remember { mutableStateOf<DownloadEntity?>(null) }
    var isStreamLoading by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    val isMobile = androidx.compose.ui.platform.LocalConfiguration.current.screenWidthDp < 600
    var showSettingsBottomSheet by remember { mutableStateOf(false) }

    LaunchedEffect(isMobile) {
        if (isMobile && selectedTabIndex == 3) {
            selectedTabIndex = 0
            showSettingsBottomSheet = true
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(SleekBg)
    ) {
        val infiniteTransition = androidx.compose.animation.core.rememberInfiniteTransition()
        val colorOffset by infiniteTransition.animateFloat(
            initialValue = 0f,
            targetValue = 1000f,
            animationSpec = androidx.compose.animation.core.infiniteRepeatable(
                animation = androidx.compose.animation.core.tween(15000, easing = androidx.compose.animation.core.LinearEasing),
                repeatMode = androidx.compose.animation.core.RepeatMode.Reverse
            ), label = "background_offset"
        )
        
        val accentColor = SleekPurpleLight
        Canvas(modifier = Modifier.fillMaxSize()) {
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(accentColor.copy(alpha = 0.1f), Color.Transparent),
                    center = androidx.compose.ui.geometry.Offset(size.width / 4, colorOffset),
                    radius = size.width
                )
            )
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(accentColor.copy(alpha = 0.05f), Color.Transparent),
                    center = androidx.compose.ui.geometry.Offset(size.width * 0.8f, size.height - colorOffset),
                    radius = size.width * 0.8f
                )
            )
        }
        
        Scaffold(
            modifier = Modifier.fillMaxSize(),
            containerColor = Color.Transparent,
            topBar = {
            Column {
                CenterAlignedTopAppBar(
                    title = {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            // DL/TubeStream icon box
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .background(SleekPurpleLight, shape = RoundedCornerShape(10.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "DL",
                                    color = SleekPurpleDark,
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.Black,
                                        fontFamily = FontFamily.SansSerif
                                    )
                                )
                            }
                            Column {
                                Text(
                                    text = "TubeStream",
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.ExtraBold,
                                        color = SleekTextPrimary,
                                        letterSpacing = (-0.5).sp
                                    )
                                )
                                Text(
                                    text = "POWERED BY TUBESTREAM",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 8.sp,
                                        color = SleekTextSecondary.copy(alpha = 0.8f),
                                        letterSpacing = 1.2.sp
                                    )
                                )
                            }
                        }
                    },
                    actions = {
                        val isTestMode by viewModel.isTestModeActive.collectAsStateWithLifecycle()
                        IconButton(onClick = { viewModel.toggleTestMode() }) {
                            Icon(
                                imageVector = Icons.Default.Build,
                                contentDescription = "Test Mode Toggle",
                                tint = if (isTestMode) EmeraldSuccess else SleekTextSecondary
                            )
                        }
                    },
                    colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                        containerColor = SleekBg,
                        titleContentColor = SleekTextPrimary
                    )
                )
                Divider(color = SleekBorderColor.copy(alpha = 0.5f), thickness = 1.dp)
            }
        },
        bottomBar = {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(SleekBg)
            ) {
                Divider(color = SleekBorderColor.copy(alpha = 0.5f), thickness = 1.dp, modifier = Modifier.align(Alignment.TopCenter))
                NavigationBar(
                    containerColor = SleekBg,
                    contentColor = SleekPurpleDark,
                    tonalElevation = 8.dp,
                    modifier = Modifier.clip(RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp))
                ) {
                    NavigationBarItem(
                        selected = selectedTabIndex == 0,
                        onClick = { selectedTabIndex = 0 },
                        icon = { Icon(Icons.Default.Home, contentDescription = "Home Feed") },
                        label = { Text("Home", fontWeight = if (selectedTabIndex == 0) FontWeight.Bold else FontWeight.Medium, fontSize = 11.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color.White,
                            selectedTextColor = SleekPurpleLight,
                            indicatorColor = SleekPurpleDark,
                            unselectedIconColor = SleekTextSecondary,
                            unselectedTextColor = SleekTextSecondary
                        )
                    )
                    NavigationBarItem(
                        selected = selectedTabIndex == 1,
                        onClick = { selectedTabIndex = 1 },
                        icon = { Icon(Icons.Default.Add, contentDescription = null) },
                        label = { Text("Download", fontWeight = if (selectedTabIndex == 1) FontWeight.Bold else FontWeight.Medium, fontSize = 11.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color.White,
                            selectedTextColor = SleekPurpleLight,
                            indicatorColor = SleekPurpleDark,
                            unselectedIconColor = SleekTextSecondary,
                            unselectedTextColor = SleekTextSecondary
                        )
                    )
                    NavigationBarItem(
                        selected = selectedTabIndex == 2,
                        onClick = { selectedTabIndex = 2 },
                        icon = { Icon(Icons.Default.Info, contentDescription = null) },
                        label = { Text("Library", fontWeight = if (selectedTabIndex == 2) FontWeight.Bold else FontWeight.Medium, fontSize = 11.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color.White,
                            selectedTextColor = SleekPurpleLight,
                            indicatorColor = SleekPurpleDark,
                            unselectedIconColor = SleekTextSecondary,
                            unselectedTextColor = SleekTextSecondary
                        )
                    )
                    NavigationBarItem(
                        selected = if (isMobile) showSettingsBottomSheet else selectedTabIndex == 3,
                        onClick = {
                            if (isMobile) {
                                showSettingsBottomSheet = true
                            } else {
                                selectedTabIndex = 3
                            }
                        },
                        icon = { Icon(Icons.Default.Settings, contentDescription = null) },
                        label = { Text("Settings", fontWeight = if (selectedTabIndex == 3 || (isMobile && showSettingsBottomSheet)) FontWeight.Bold else FontWeight.Medium, fontSize = 11.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color.White,
                            selectedTextColor = SleekPurpleLight,
                            indicatorColor = SleekPurpleDark,
                            unselectedIconColor = SleekTextSecondary,
                            unselectedTextColor = SleekTextSecondary
                        )
                    )
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
        ) {
            AnimatedContent(
                targetState = selectedTabIndex,
                transitionSpec = {
                    if (targetState > initialState) {
                        slideInHorizontally { width -> width } + fadeIn() togetherWith
                                slideOutHorizontally { width -> -width } + fadeOut()
                    } else {
                        slideInHorizontally { width -> -width } + fadeIn() togetherWith
                                slideOutHorizontally { width -> width } + fadeOut()
                    }.using(SizeTransform(clip = false))
                },
                label = "TabTransition",
                modifier = Modifier.weight(1f)
            ) { targetTab ->
                when (targetTab) {
                    0 -> {
                        val homeVideos by viewModel.homeVideos.collectAsStateWithLifecycle()
                        val isHomeSearching by viewModel.isHomeSearching.collectAsStateWithLifecycle()
                        val homeSelectedCategory by viewModel.homeSelectedCategory.collectAsStateWithLifecycle()
                        val homeError by viewModel.homeError.collectAsStateWithLifecycle()
                        val searchHistory by viewModel.searchHistory.collectAsStateWithLifecycle()
                        val browsingHistory by viewModel.browsingHistory.collectAsStateWithLifecycle()
                        val personalizedVideos by viewModel.personalizedVideos.collectAsStateWithLifecycle()

                        HomeTab(
                            homeVideos = homeVideos,
                            isHomeSearching = isHomeSearching,
                            homeSelectedCategory = homeSelectedCategory,
                            homeError = homeError,
                            searchHistory = searchHistory,
                            browsingHistory = browsingHistory,
                            personalizedVideos = personalizedVideos,
                            onCategorySelected = { viewModel.selectHomeCategory(it) },
                            onSearchQuerySubmitted = { viewModel.fetchHomeVideos(it) },
                            onDeleteSearchHistory = { viewModel.deleteSearchQuery(it) },
                            onClearSearchHistory = { viewModel.clearAllSearchHistory() },
                            onDeleteBrowsingHistory = { viewModel.deleteBrowsingRecord(it) },
                            onClearBrowsingHistory = { viewModel.clearAllBrowsingHistory() },
                            onStreamVideo = { video ->
                                viewModel.recordBrowsingVideo(video)
                                playingDownload = DownloadEntity(
                                    id = video.id,
                                    title = "[Live Stream] " + video.title,
                                    author = video.author,
                                    durationText = video.duration,
                                    thumbnailUrl = video.thumbnailUrl,
                                    localPath = video.originalUrl,
                                    fileSize = 0,
                                    downloadedAt = System.currentTimeMillis()
                                )
                            },
                            onAnalyzeVideo = { video ->
                                viewModel.recordBrowsingVideo(video)
                                viewModel.updateUrlInput(video.originalUrl)
                                selectedTabIndex = 1
                                viewModel.analyzeVideo()
                            }
                        )
                    }

                    1 -> DownloadTab(
                        urlInput = urlInput,
                        urlHistory = viewModel.urlHistory.collectAsStateWithLifecycle().value,
                        isAnalyzing = isAnalyzing,
                        analyzedVideo = analyzedVideo,
                        analysisError = analysisError,
                        activeDownloads = activeDownloads,
                        executionLogs = executionLogs,
                        isAudioOnly = isAudioOnly,
                        searchResults = searchResults,
                        isSearching = isSearching,
                        onToggleAudioOnly = { viewModel.toggleAudioOnlyMode() },
                        onClearLogs = { viewModel.clearLogs() },
                        onUrlChange = { viewModel.updateUrlInput(it) },
                        onClearUrlHistory = { viewModel.clearUrlHistory() },
                        onPasteClick = {
                            clipboardManager.getText()?.text?.let { viewModel.updateUrlInput(it) }
                        },
                        onClearClick = { viewModel.updateUrlInput("") },
                        onAnalyzeClick = { viewModel.analyzeVideo() },
                        onDownloadFormat = { format ->
                            analyzedVideo?.let { video ->
                                viewModel.startDownload(video, format)
                            }
                        },
                        onStreamFormat = { format ->
                            analyzedVideo?.let { video ->
                                val isAudioFormat = format.type == "audio"
                                playingDownload = DownloadEntity(
                                    id = video.id,
                                    title = if (isAudioFormat) "[Streaming Audio] ${video.title}" else "[Streaming Video] ${video.title}",
                                    author = video.author,
                                    durationText = video.durationText,
                                    thumbnailUrl = video.thumbnailUrl,
                                    localPath = format.downloadUrl,
                                    fileSize = format.sizeBytes,
                                    downloadedAt = System.currentTimeMillis()
                                )
                            }
                        },
                        onCancelActiveTask = { taskId ->
                            viewModel.removeActiveTask(taskId)
                        },
                        onSearchResultClick = { result ->
                            viewModel.updateUrlInput(result.originalUrl)
                            viewModel.analyzeVideo()
                        }
                    )
                    2 -> LibraryTab(
                        downloads = (downloadHistory + deviceMedia).distinctBy { it.localPath }.sortedByDescending { it.downloadedAt },
                        onPlayClick = { playingDownload = it },
                        onShareClick = { viewModel.shareVideo(context, it) },
                        onDeleteClick = { viewModel.deleteDownload(it) },
                        onConvertAudio = { viewModel.convertAudio(it) }
                    )
                    3 -> SettingsTab(
                        downloads = downloadHistory,
                        onClearAllDownloads = { viewModel.clearAllDownloads() },
                        viewModel = viewModel
                    )
                }
            }
        }
    }

    if (showSettingsBottomSheet) {
        val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
        ModalBottomSheet(
            onDismissRequest = { showSettingsBottomSheet = false },
            sheetState = sheetState,
            containerColor = SleekBg,
            dragHandle = { BottomSheetDefaults.DragHandle(color = SleekPurpleLight) },
            modifier = Modifier.fillMaxHeight(0.9f)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(SleekBg)
            ) {
                SettingsTab(
                    downloads = downloadHistory,
                    onClearAllDownloads = { viewModel.clearAllDownloads() },
                    viewModel = viewModel
                )
            }
        }
    }

    if (playingDownload != null) {
        val path = playingDownload!!.localPath.lowercase()
        val isAudio = path.endsWith(".mp3") ||
                      path.endsWith(".m4a") ||
                      path.endsWith(".opus") ||
                      path.endsWith(".wav") ||
                      path.endsWith(".ogg") ||
                      path.endsWith(".aac") ||
                      path.endsWith(".flac") ||
                      path.contains("/audios/") ||
                      path.contains("audio") ||
                      playingDownload!!.title.contains("[streaming audio]", ignoreCase = true)
        
        if (isAudio) {
            AudioPlayerDialog(
                download = playingDownload!!,
                onDismiss = { playingDownload = null }
            )
        } else {
            VideoPlayerDialog(
                download = playingDownload!!,
                onDismiss = { playingDownload = null },
                viewModel = viewModel,
                onPlayRelated = { video ->
                    viewModel.recordBrowsingVideo(video)
                    playingDownload = DownloadEntity(
                        id = video.id,
                        title = "[Live Stream] " + video.title,
                        author = video.author,
                        durationText = video.durationText,
                        thumbnailUrl = video.thumbnailUrl,
                        localPath = video.originalUrl,
                        fileSize = 0,
                        downloadedAt = System.currentTimeMillis()
                    )
                }
            )
        }
    }

    val showFloatingWidget by viewModel.showFloatingWidget.collectAsStateWithLifecycle()
    if (showFloatingWidget) {
        FloatingSearchWidget(
            viewModel = viewModel,
            isPlayerOpen = playingDownload != null,
            selectedTabIndex = selectedTabIndex,
            onClose = { viewModel.triggerFloatingWidget(false) }
        )
    }

    // External loading dialog removed to allow responsive, instant inline playback dialog launching
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeTab(
    homeVideos: List<YtdlpPipelineManager.SearchResult>,
    isHomeSearching: Boolean,
    homeSelectedCategory: String,
    homeError: String?,
    searchHistory: List<com.example.data.SearchHistoryEntity>,
    browsingHistory: List<com.example.data.BrowsingHistoryEntity>,
    personalizedVideos: List<YtdlpPipelineManager.SearchResult>,
    onCategorySelected: (String) -> Unit,
    onSearchQuerySubmitted: (String) -> Unit,
    onDeleteSearchHistory: (String) -> Unit,
    onClearSearchHistory: () -> Unit,
    onDeleteBrowsingHistory: (String) -> Unit,
    onClearBrowsingHistory: () -> Unit,
    onStreamVideo: (YtdlpPipelineManager.SearchResult) -> Unit,
    onAnalyzeVideo: (YtdlpPipelineManager.SearchResult) -> Unit,
    modifier: Modifier = Modifier
) {
    var searchQuery by remember { mutableStateOf("") }
    val categories = listOf("Trending", "Music", "Gaming", "Tech & AI", "Nature & Space", "Lo-Fi Beats")

    val infiniteTransition = androidx.compose.animation.core.rememberInfiniteTransition(label = "home_skeleton")
    val alpha by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 0.8f,
        animationSpec = androidx.compose.animation.core.infiniteRepeatable(
            animation = androidx.compose.animation.core.tween(800, easing = androidx.compose.animation.core.LinearEasing),
            repeatMode = androidx.compose.animation.core.RepeatMode.Reverse
        ),
        label = "home_skeleton_alpha"
    )
    val animatedSkeletonColor = SleekPurpleContainer.copy(alpha = alpha)

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(Color.Transparent),
        contentPadding = PaddingValues(bottom = 16.dp)
    ) {
        // Core Header & Search Bar
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(HeroGradient)
                    .padding(bottom = 24.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 20.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Explore Streams",
                                style = MaterialTheme.typography.headlineSmall.copy(
                                    fontWeight = FontWeight.ExtraBold,
                                    color = SleekTextPrimary
                                )
                            )
                            Text(
                                text = "Premium curated content feed",
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    color = SleekTextSecondary
                                )
                            )
                        }
                        
                        Box(
                            modifier = Modifier
                                .background(SleekTextPrimary.copy(alpha = 0.1f), RoundedCornerShape(12.dp))
                                .border(1.dp, SleekTextPrimary.copy(alpha = 0.2f), RoundedCornerShape(12.dp))
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = "LIVE SCALER",
                                color = SleekTextPrimary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                letterSpacing = 1.sp
                            )
                        }
                    }

                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        color = SleekCard.copy(alpha = 0.5f),
                        border = BorderStroke(1.dp, SleekTextPrimary.copy(alpha = 0.1f))
                    ) {
                        TextField(
                            value = searchQuery,
                            onValueChange = { searchQuery = it },
                            placeholder = {
                                Text(
                                    text = "Search YouTube streams directly...",
                                    color = SleekTextSecondary.copy(alpha = 0.6f),
                                    fontSize = 14.sp
                                )
                            },
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Default.Search,
                                    contentDescription = "Search",
                                    tint = SleekTextSecondary.copy(alpha = 0.7f)
                                )
                            },
                            trailingIcon = {
                                if (searchQuery.isNotEmpty()) {
                                    IconButton(onClick = { searchQuery = "" }) {
                                        Icon(
                                            imageVector = Icons.Default.Clear,
                                            contentDescription = "Clear",
                                            tint = SleekTextPrimary
                                        )
                                    }
                                }
                            },
                            singleLine = true,
                            colors = TextFieldDefaults.colors(
                                focusedContainerColor = Color.Transparent,
                                unfocusedContainerColor = Color.Transparent,
                                focusedIndicatorColor = Color.Transparent,
                                unfocusedIndicatorColor = Color.Transparent,
                                cursorColor = SleekTextPrimary,
                                focusedTextColor = SleekTextPrimary,
                                unfocusedTextColor = SleekTextPrimary
                            ),
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                            keyboardActions = KeyboardActions(onSearch = {
                                if (searchQuery.isNotBlank()) {
                                    onSearchQuerySubmitted(searchQuery)
                                }
                            }),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }
        }

        // Recent queries history horizontal chips list
        if (searchHistory.isNotEmpty()) {
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "RECENT SEARCHES",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.ExtraBold,
                                color = SleekPurpleLight,
                                letterSpacing = 0.5.sp,
                                fontSize = 9.sp
                            )
                        )
                        Text(
                            text = "Clear All",
                            modifier = Modifier.clickable { onClearSearchHistory() },
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = SleekTextMuted,
                                fontSize = 10.sp
                            )
                        )
                    }

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        searchHistory.take(8).forEach { entry ->
                            Row(
                                modifier = Modifier
                                    .background(SleekCardDark, RoundedCornerShape(8.dp))
                                    .border(1.dp, SleekBorderColor.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                                    .clickable {
                                        searchQuery = entry.query
                                        onSearchQuerySubmitted(entry.query)
                                    }
                                    .padding(horizontal = 10.dp, vertical = 6.dp),
                                horizontalArrangement = Arrangement.spacedBy(4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Search,
                                    contentDescription = "Search history item",
                                    tint = SleekTextSecondary,
                                    modifier = Modifier.size(11.dp)
                                )
                                Text(
                                    text = entry.query,
                                    color = SleekTextPrimary,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium
                                )
                                Spacer(modifier = Modifier.width(2.dp))
                                Icon(
                                    imageVector = Icons.Default.Clear,
                                    contentDescription = "Delete search record",
                                    tint = SleekTextMuted,
                                    modifier = Modifier
                                        .size(13.dp)
                                        .clickable { onDeleteSearchHistory(entry.query) }
                                )
                            }
                        }
                    }
                }
            }
        }

        // Horizontal Category Row
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                categories.forEach { category ->
                    val isSelected = homeSelectedCategory == category
                    Box(
                        modifier = Modifier
                            .clickable { onCategorySelected(category) }
                            .background(
                                color = if (isSelected) SleekPurpleLight else SleekCard,
                                shape = RoundedCornerShape(50)
                            )
                            .border(
                                width = 1.dp,
                                color = if (isSelected) Color.Transparent else SleekBorderColor,
                                shape = RoundedCornerShape(50)
                            )
                            .padding(horizontal = 16.dp, vertical = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = category.uppercase(),
                            color = if (isSelected) SleekBg else SleekTextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp,
                            letterSpacing = 0.5.sp
                        )
                    }
                }
            }
        }

        // 1. "Recently Watched" Personalized Browsing History Row
        if (browsingHistory.isNotEmpty()) {
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Recently Watched",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = SleekTextPrimary
                                )
                            )
                            Text(
                                text = "Pick up where you left off",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = SleekTextMuted
                                )
                            )
                        }

                        IconButton(
                            onClick = { onClearBrowsingHistory() },
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Delete,
                                contentDescription = "Clear all watch history",
                                tint = SleekTextMuted,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState())
                            .padding(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        browsingHistory.take(12).forEach { record ->
                            Card(
                                modifier = Modifier
                                    .width(200.dp)
                                    .clickable {
                                        onStreamVideo(
                                            YtdlpPipelineManager.SearchResult(
                                                id = record.id,
                                                title = record.title,
                                                author = record.author,
                                                duration = record.durationText,
                                                thumbnailUrl = record.thumbnailUrl,
                                                originalUrl = record.originalUrl
                                            )
                                        )
                                    },
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = SleekCard)
                            ) {
                                Box(modifier = Modifier.fillMaxWidth()) {
                                    AsyncImage(
                                        model = record.thumbnailUrl,
                                        contentDescription = record.title,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(110.dp)
                                            .clip(RoundedCornerShape(topStart = 12.dp, topEnd = 12.dp)),
                                        contentScale = ContentScale.Crop
                                    )
                                    
                                    if (record.durationText.isNotBlank()) {
                                        Box(
                                            modifier = Modifier
                                                .align(Alignment.BottomEnd)
                                                .padding(6.dp)
                                                .background(Color.Black.copy(alpha = 0.8f), RoundedCornerShape(4.dp))
                                                .padding(horizontal = 6.dp, vertical = 2.dp)
                                        ) {
                                            Text(
                                                text = record.durationText,
                                                color = Color.White,
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }

                                    IconButton(
                                        onClick = { onDeleteBrowsingHistory(record.id) },
                                        modifier = Modifier
                                            .align(Alignment.TopEnd)
                                            .padding(6.dp)
                                            .size(24.dp)
                                            .background(Color.Black.copy(alpha = 0.6f), CircleShape)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Close,
                                            contentDescription = "Remove video from history",
                                            tint = Color.White,
                                            modifier = Modifier.size(12.dp)
                                        )
                                    }
                                }

                                Column(
                                    modifier = Modifier
                                        .padding(8.dp)
                                        .fillMaxWidth(),
                                    verticalArrangement = Arrangement.spacedBy(2.dp)
                                ) {
                                    Text(
                                        text = record.title,
                                        color = SleekTextPrimary,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = record.author,
                                        color = SleekTextMuted,
                                        fontSize = 10.sp,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // 2. "Because you searched for '[LastQuery]'" Personalized Recommendations Row
        if (personalizedVideos.isNotEmpty() && searchHistory.isNotEmpty()) {
            val lastQuery = searchHistory.first().query
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Inspired by Your Interest",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = SleekPurpleLight
                                )
                            )
                            Text(
                                text = "Because you searched for \"$lastQuery\"",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = SleekTextMuted
                                ),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState())
                            .padding(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        personalizedVideos.forEach { video ->
                            Card(
                                modifier = Modifier
                                    .width(180.dp)
                                    .clickable {
                                        onStreamVideo(video)
                                    },
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = SleekCard)
                            ) {
                                Box(modifier = Modifier.fillMaxWidth()) {
                                    AsyncImage(
                                        model = video.thumbnailUrl,
                                        contentDescription = video.title,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(100.dp)
                                            .clip(RoundedCornerShape(topStart = 12.dp, topEnd = 12.dp)),
                                        contentScale = ContentScale.Crop
                                    )
                                    
                                    if (video.duration.isNotBlank()) {
                                        Box(
                                            modifier = Modifier
                                                .align(Alignment.BottomEnd)
                                                .padding(6.dp)
                                                .background(Color.Black.copy(alpha = 0.8f), RoundedCornerShape(4.dp))
                                                .padding(horizontal = 4.dp, vertical = 2.dp)
                                        ) {
                                            Text(
                                                text = video.duration,
                                                color = Color.White,
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }
                                }

                                Column(
                                    modifier = Modifier
                                        .padding(8.dp)
                                        .fillMaxWidth(),
                                    verticalArrangement = Arrangement.spacedBy(2.dp)
                                ) {
                                    Text(
                                        text = video.title,
                                        color = SleekTextPrimary,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = video.author,
                                        color = SleekTextMuted,
                                        fontSize = 10.sp,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Subtitle header label indicating main Feed Category starts below
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 10.dp)
            ) {
                Text(
                    text = "${homeSelectedCategory.uppercase()} FEED",
                    fontWeight = FontWeight.ExtraBold,
                    color = SleekPurpleLight,
                    fontSize = 10.sp,
                    letterSpacing = 0.5.sp
                )
            }
        }

        // Status or Error messages if any
        if (homeError != null) {
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                        .border(1.dp, SleekBorderColor.copy(alpha = 0.5f), RoundedCornerShape(16.dp)),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = SleekCardDark)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(18.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "Connection Notice",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = SleekTextPrimary
                            )
                        )
                        Text(
                            text = homeError,
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = SleekTextSecondary
                            ),
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Button(
                            onClick = { onCategorySelected(homeSelectedCategory) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = SleekPurpleLight,
                                contentColor = SleekBg
                            ),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Retry Sync", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Shimmer Skeletal Loading states
        if (isHomeSearching) {
            items(4) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 10.dp)
                        .background(SleekCard, RoundedCornerShape(16.dp))
                        .border(1.dp, SleekBorderColor, RoundedCornerShape(16.dp))
                        .height(240.dp)
                ) {
                    Column(
                        modifier = Modifier.fillMaxSize().padding(12.dp),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(150.dp)
                                .background(animatedSkeletonColor, RoundedCornerShape(12.dp))
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .background(animatedSkeletonColor, CircleShape)
                            )
                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Box(
                                    modifier = Modifier
                                        .width(180.dp)
                                        .height(14.dp)
                                        .background(animatedSkeletonColor, RoundedCornerShape(4.dp))
                                )
                                Box(
                                    modifier = Modifier
                                        .width(100.dp)
                                        .height(10.dp)
                                        .background(animatedSkeletonColor, RoundedCornerShape(4.dp))
                                )
                            }
                        }
                    }
                }
            }
        } else {
            // Main dynamic home video grid item list
            items(homeVideos) { video ->
                HomeVideoCard(
                    video = video,
                    onPlayClick = { onStreamVideo(video) },
                    onAnalyzeClick = { onAnalyzeVideo(video) }
                )
            }
        }
    }
}

@Composable
fun HomeVideoCard(
    video: YtdlpPipelineManager.SearchResult,
    onPlayClick: () -> Unit,
    onAnalyzeClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 10.dp)
            .border(1.dp, SleekBorderColor, RoundedCornerShape(16.dp)),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = SleekCard)
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().clickable { onPlayClick() }
        ) {
            // Video Thumbnail & Duration Badge
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(16f / 9f)
                    .background(Color.Black)
            ) {
                AsyncImage(
                    model = video.thumbnailUrl,
                    contentDescription = video.title,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )

                // High Contrast Circular Play Button Overlay
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .background(Color.Black.copy(alpha = 0.65f), CircleShape)
                            .border(1.5.dp, Color.White.copy(alpha = 0.5f), CircleShape)
                            .clickable { onPlayClick() },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.PlayArrow,
                            contentDescription = "Stream Direct",
                            tint = Color.White,
                            modifier = Modifier.size(28.dp)
                        )
                    }
                }

                // Duration Banner Tag
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(8.dp)
                        .background(Color.Black.copy(alpha = 0.85f), RoundedCornerShape(4.dp))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = video.duration,
                        color = Color.White,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // Info Details & Action Rows
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.Top
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .background(
                            brush = Brush.linearGradient(
                                colors = listOf(SleekPurpleLight.copy(alpha = 0.2f), SleekBorderColor)
                            ),
                            shape = CircleShape
                        )
                        .border(1.dp, SleekBorderColor, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = video.author.take(1).uppercase(),
                        color = SleekTextPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                }

                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = video.title,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                        color = SleekTextPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        lineHeight = 18.sp
                    )
                    
                    Text(
                        text = "${video.author} • OctaStream verified",
                        color = SleekTextMuted,
                        fontSize = 12.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                IconButton(
                    onClick = onAnalyzeClick,
                    modifier = Modifier
                        .background(SleekPurpleLight.copy(alpha = 0.1f), CircleShape)
                        .size(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.ArrowDownward,
                        contentDescription = "Get Options",
                        tint = SleekTextPrimary,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DownloadTab(
    urlInput: String,
    urlHistory: List<String>,
    isAnalyzing: Boolean,
    analyzedVideo: AnalyzedVideo?,
    analysisError: String?,
    activeDownloads: Map<String, ActiveDownloadTask>,
    executionLogs: List<String>,
    isAudioOnly: Boolean,
    searchResults: List<YtdlpPipelineManager.SearchResult>,
    isSearching: Boolean,
    onToggleAudioOnly: () -> Unit,
    onClearLogs: () -> Unit,
    onUrlChange: (String) -> Unit,
    onClearUrlHistory: () -> Unit,
    onPasteClick: () -> Unit,
    onClearClick: () -> Unit,
    onAnalyzeClick: () -> Unit,
    onDownloadFormat: (VideoFormatUi) -> Unit,
    onStreamFormat: (VideoFormatUi) -> Unit,
    onCancelActiveTask: (String) -> Unit,
    onSearchResultClick: (YtdlpPipelineManager.SearchResult) -> Unit
) {
    var showDownloadSheet by remember { mutableStateOf(false) }

    Box(modifier = Modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
        // Welcome and link parsing card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.Transparent),
                shape = RoundedCornerShape(28.dp),
                border = BorderStroke(1.dp, SleekBorderColor.copy(alpha = 0.3f)),
                elevation = CardDefaults.cardElevation(defaultElevation = 12.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.linearGradient(
                                colors = listOf(SleekCard, SleekCardDark)
                            )
                        )
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Text(
                            text = "Universal Downloader",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.ExtraBold,
                                color = SleekPurpleDark,
                                letterSpacing = 0.5.sp
                            )
                        )
                        Text(
                            text = "Paste any streaming video, direct download link, or YouTube URL below to extract and download instantly.",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = SleekTextSecondary.copy(alpha = 0.9f),
                                lineHeight = 20.sp
                            )
                        )

                        // URL Input Field
                        var historyExpanded by remember { mutableStateOf(false) }
                        val focusManager = androidx.compose.ui.platform.LocalFocusManager.current

                        ExposedDropdownMenuBox(
                            expanded = historyExpanded,
                            onExpandedChange = { historyExpanded = false } // Don't Auto Expand on click without focus logic, we'll manage manually on click
                        ) {
                            OutlinedTextField(
                                value = urlInput,
                                onValueChange = { 
                                    onUrlChange(it) 
                                    historyExpanded = false 
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .menuAnchor()
                                    .onFocusChanged { state ->
                                        if (state.isFocused && urlHistory.isNotEmpty() && urlInput.isEmpty()) {
                                            historyExpanded = true
                                        }
                                    }
                                    .testTag("url_input_field"),
                                textStyle = MaterialTheme.typography.bodyLarge.copy(color = SleekTextPrimary),
                                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                                keyboardActions = KeyboardActions(onSearch = { 
                                    focusManager.clearFocus()
                                    historyExpanded = false
                                    onAnalyzeClick() 
                                }),
                                placeholder = { Text("Paste video URL here...", color = SleekTextMuted, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                                trailingIcon = {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.padding(end = 6.dp)
                                    ) {
                                        if (urlInput.isNotEmpty()) {
                                            IconButton(
                                                onClick = onClearClick,
                                                modifier = Modifier.size(36.dp)
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.Clear,
                                                    contentDescription = "Clear",
                                                    tint = SleekTextSecondary,
                                                    modifier = Modifier.size(18.dp)
                                                )
                                            }
                                        } else {
                                            TextButton(
                                                onClick = onPasteClick,
                                                colors = ButtonDefaults.textButtonColors(contentColor = SleekPurpleDark),
                                                modifier = Modifier.testTag("paste_button")
                                            ) {
                                                Text("PASTE", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                            }
                                        }

                                        Spacer(modifier = Modifier.width(4.dp))

                                        // Beautiful, rounded search/action button inside
                                        val buttonAlpha by animateFloatAsState(targetValue = if (urlInput.trim().isNotEmpty() && !isAnalyzing) 1f else 0.4f, label = "ButtonAlpha")
                                        Box(
                                            modifier = Modifier
                                                .size(44.dp)
                                                .clip(CircleShape)
                                                .background(SleekPurpleDark.copy(alpha = buttonAlpha))
                                                .clickable(
                                                    enabled = urlInput.trim().isNotEmpty() && !isAnalyzing,
                                                    onClick = {
                                                        focusManager.clearFocus()
                                                        historyExpanded = false
                                                        onAnalyzeClick()
                                                    }
                                                )
                                                .testTag("analyze_button"),
                                             contentAlignment = Alignment.Center
                                        ) {
                                            if (isAnalyzing) {
                                                CircularProgressIndicator(
                                                    modifier = Modifier.size(20.dp),
                                                    color = SleekBg,
                                                    strokeWidth = 2.dp
                                                )
                                            } else {
                                                Icon(
                                                    imageVector = Icons.Default.Search,
                                                    contentDescription = "Search & Analyze",
                                                    tint = SleekBg.copy(alpha = buttonAlpha),
                                                    modifier = Modifier.size(22.dp)
                                                )
                                            }
                                        }
                                    }
                                },
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedContainerColor = SleekCardDark.copy(alpha = 0.5f),
                                    unfocusedContainerColor = SleekCardDark.copy(alpha = 0.5f),
                                    focusedBorderColor = SleekPurpleDark,
                                    unfocusedBorderColor = SleekBorderColor,
                                    focusedTextColor = SleekTextPrimary,
                                    unfocusedTextColor = SleekTextPrimary,
                                    cursorColor = SleekPurpleDark
                                ),
                                shape = RoundedCornerShape(24.dp),
                                singleLine = true
                            )
                            
                            ExposedDropdownMenu(
                                expanded = historyExpanded,
                                onDismissRequest = { historyExpanded = false },
                                modifier = Modifier.background(SleekCardDark)
                            ) {
                                if (urlHistory.isNotEmpty()) {
                                    urlHistory.forEach { historyUrl ->
                                        DropdownMenuItem(
                                            text = { Text(historyUrl, color = SleekTextPrimary, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                                            onClick = {
                                                onUrlChange(historyUrl)
                                                historyExpanded = false
                                                focusManager.clearFocus()
                                            },
                                            leadingIcon = { Icon(Icons.Default.History, contentDescription = null, tint = SleekTextSecondary) }
                                        )
                                    }
                                    HorizontalDivider(color = SleekBorderColor)
                                    DropdownMenuItem(
                                        text = { Text("Clear History", color = CrimsonFailure) },
                                        onClick = {
                                            onClearUrlHistory()
                                            historyExpanded = false
                                        },
                                        leadingIcon = { Icon(Icons.Default.Delete, contentDescription = null, tint = CrimsonFailure) }
                                    )
                                }
                            }
                        }

                        // Quick Action Chips
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            FilterChip(
                                selected = isAudioOnly,
                                onClick = onToggleAudioOnly,
                                label = { Text("Audio Only (MP3)", fontWeight = FontWeight.Bold, fontSize = 12.sp) },
                                leadingIcon = {
                                    Icon(
                                        imageVector = if (isAudioOnly) Icons.Default.CheckCircle else Icons.Default.PlayArrow,
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp)
                                    )
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = EmeraldSuccess.copy(alpha = 0.2f),
                                    selectedLabelColor = EmeraldSuccess,
                                    selectedLeadingIconColor = EmeraldSuccess,
                                    containerColor = SleekCardDark.copy(alpha = 0.5f),
                                    labelColor = SleekTextSecondary,
                                    iconColor = SleekTextSecondary
                                ),
                                border = FilterChipDefaults.filterChipBorder(
                                    borderColor = if (isAudioOnly) EmeraldSuccess else SleekBorderColor,
                                    enabled = true,
                                    selected = isAudioOnly
                                )
                            )
                        }
                    }
                }
            }
        }

        // 🔍 Keyword Search Progress Indicator
        if (isSearching) {
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "Searching YouTube keywords via JNI...",
                        color = SleekTextSecondary,
                        style = MaterialTheme.typography.bodyMedium.copy(
                            fontWeight = FontWeight.Medium,
                            fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
                        ),
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                }
            }
            items(3) {
                SkeletonSearchResultItem()
            }
        }

        // 🔍 Keyword Search Results Display
        if (!isSearching && searchResults.isNotEmpty()) {
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 4.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "SEARCH RESULTS",
                        style = MaterialTheme.typography.titleSmall.copy(
                            color = SleekPurpleDark,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            letterSpacing = 1.sp
                        )
                    )
                    
                    Text(
                        text = "Found ${searchResults.size}",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = SleekTextMuted,
                            fontWeight = FontWeight.SemiBold
                        )
                    )
                }
            }

            items(searchResults) { result ->
                SearchResultItemRow(
                    result = result,
                    onClick = { onSearchResultClick(result) },
                    modifier = Modifier.animateItem()
                )
            }
        }

        // Active Diagnostics / Error Info
        if (analysisError != null) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = CrimsonFailure.copy(alpha = 0.15f)),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, CrimsonFailure.copy(alpha = 0.3f))
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Warning, contentDescription = "Error", tint = CrimsonFailure, modifier = Modifier.size(24.dp))
                        Text(
                            text = analysisError,
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = CrimsonFailure,
                                fontWeight = FontWeight.Medium
                            )
                        )
                    }
                }
            }
        }

        // Active Downloads section
        if (activeDownloads.isNotEmpty()) {
            item {
                Text(
                    text = "ACTIVE DOWNLOADS",
                    style = MaterialTheme.typography.titleSmall.copy(
                        color = AmberAccent,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    ),
                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                )
            }

            items(activeDownloads.values.toList(), key = { it.id }) { task ->
                ActiveDownloadCard(
                    task = task, 
                    onCancelClick = { onCancelActiveTask(task.id) },
                    modifier = Modifier.animateItem()
                )
            }
        }

        // Analyzed Video details card
        if (isAnalyzing) {
            item {
                SkeletonAnalyzedVideoCard()
            }
        } else if (analyzedVideo != null) {
            item {
                AnalyzedVideoCard(
                    video = analyzedVideo,
                    onOpenDownloadOptions = {
                        showDownloadSheet = true
                    },
                    onStreamBestClick = {
                        val bestFormat = analyzedVideo.formats.firstOrNull { it.type == "combined" }
                            ?: analyzedVideo.formats.firstOrNull { it.type == "video_only" }
                            ?: analyzedVideo.formats.firstOrNull()
                        bestFormat?.let { onStreamFormat(it) }
                    }
                )
            }
        }
    }

    if (showDownloadSheet && analyzedVideo != null) {
        val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = false)
        ModalBottomSheet(
            onDismissRequest = { showDownloadSheet = false },
            sheetState = sheetState,
            containerColor = SleekCardDark,
            dragHandle = { BottomSheetDefaults.DragHandle(color = SleekTextSecondary) }
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
                    .padding(bottom = 32.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    text = "DOWNLOAD OPTIONS",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = SleekPurpleDark,
                        letterSpacing = 1.sp
                    )
                )
                
                val videoFormats = analyzedVideo.formats.filter { it.type == "combined" || it.type == "video_only" }
                val audioFormats = analyzedVideo.formats.filter { it.type == "audio" }

                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    if (videoFormats.isNotEmpty()) {
                        item {
                            Text(
                                text = "VIDEO",
                                style = MaterialTheme.typography.labelSmall.copy(color = SleekTextSecondary),
                                modifier = Modifier.padding(bottom = 4.dp)
                            )
                        }
                        items(videoFormats) { format ->
                            FormatRowItem(
                                format = format, 
                                modifier = Modifier.animateItem(),
                                onDownloadClick = {
                                    onDownloadFormat(format)
                                    showDownloadSheet = false
                                },
                                onStreamClick = {
                                    onStreamFormat(format)
                                    showDownloadSheet = false
                                }
                            )
                        }
                    }

                    if (audioFormats.isNotEmpty()) {
                        item {
                            Spacer(Modifier.height(8.dp))
                            Text(
                                text = "AUDIO",
                                style = MaterialTheme.typography.labelSmall.copy(color = SleekTextSecondary),
                                modifier = Modifier.padding(bottom = 4.dp)
                            )
                        }
                        items(audioFormats) { format ->
                            FormatRowItem(
                                format = format,
                                modifier = Modifier.animateItem(),
                                onDownloadClick = {
                                    onDownloadFormat(format)
                                    showDownloadSheet = false
                                },
                                onStreamClick = {
                                    onStreamFormat(format)
                                    showDownloadSheet = false
                                }
                            )
                        }
                    }
                }
            }
        }
    }
  }
}

@Composable
fun ActiveDownloadCard(
    task: ActiveDownloadTask,
    onCancelClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = androidx.compose.animation.core.rememberInfiniteTransition()
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.5f,
        targetValue = 1f,
        animationSpec = androidx.compose.animation.core.infiniteRepeatable(
            animation = androidx.compose.animation.core.tween(1000, easing = androidx.compose.animation.core.FastOutSlowInEasing),
            repeatMode = androidx.compose.animation.core.RepeatMode.Reverse
        ), label = "PulseAlpha"
    )

    val borderColor = when (task.status) {
        DownloadStatus.FAILED -> CrimsonFailure.copy(alpha = 0.6f)
        DownloadStatus.DOWNLOADING -> SleekPurpleLight.copy(alpha = pulseAlpha)
        DownloadStatus.COMPLETED -> EmeraldSuccess.copy(alpha = 0.8f)
        DownloadStatus.PENDING -> SleekTextSecondary.copy(alpha = 0.5f)
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .animateContentSize(animationSpec = androidx.compose.animation.core.spring(dampingRatio = androidx.compose.animation.core.Spring.DampingRatioMediumBouncy, stiffness = androidx.compose.animation.core.Spring.StiffnessLow)),
        colors = CardDefaults.cardColors(containerColor = SleekCard),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, borderColor)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = task.title,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        color = SleekTextPrimary,
                        style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold)
                    )
                    Text(
                        text = "Format: .${task.ext.uppercase()}  |  ${task.speedText}",
                        color = SleekTextSecondary,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
                
                IconButton(onClick = onCancelClick) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Cancel",
                        tint = if (task.status == DownloadStatus.FAILED) CrimsonFailure else SleekTextSecondary
                    )
                }
            }

            if (task.status == DownloadStatus.FAILED) {
                Text(
                    text = task.error ?: "Download terminated unexpectedly.",
                    color = CrimsonFailure,
                    style = MaterialTheme.typography.bodySmall,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            } else {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    val progressPercent = (task.progress * 100).toInt()
                    
                    LinearProgressIndicator(
                        progress = { task.progress },
                        modifier = Modifier
                            .weight(1f)
                            .height(6.dp)
                            .clip(RoundedCornerShape(3.dp)),
                        color = if (task.status == DownloadStatus.COMPLETED) EmeraldSuccess else SleekPurpleDark,
                        trackColor = SleekCardDark
                    )

                    Text(
                        text = "$progressPercent%",
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = SleekPurpleDark,
                            fontFamily = FontFamily.Monospace
                        )
                    )
                }
            }
        }
    }
}

@Composable
fun SkeletonAnalyzedVideoCard() {
    val infiniteTransition = rememberInfiniteTransition(label = "skeleton")
    val alpha by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 0.8f,
        animationSpec = infiniteRepeatable(
            animation = tween(800, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "skeleton_alpha"
    )
    val skeletonColor = SleekCardDark.copy(alpha = alpha)

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(130.dp)
            .testTag("analyzed_video_card_skeleton"),
        colors = CardDefaults.cardColors(containerColor = SleekPurpleContainer.copy(alpha = 0.5f)),
        shape = RoundedCornerShape(20.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxSize().padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Thumbnail Skeleton
            Box(
                modifier = Modifier
                    .fillMaxHeight()
                    .aspectRatio(16f/9f)
                    .clip(RoundedCornerShape(12.dp))
                    .background(skeletonColor)
            )

            // Info Column
            Column(
                modifier = Modifier.weight(1f).fillMaxHeight(),
                verticalArrangement = Arrangement.Center
            ) {
                Box(modifier = Modifier.fillMaxWidth().height(18.dp).background(skeletonColor, RoundedCornerShape(4.dp)))
                Spacer(modifier = Modifier.height(8.dp))
                Box(modifier = Modifier.fillMaxWidth(0.7f).height(18.dp).background(skeletonColor, RoundedCornerShape(4.dp)))
                Spacer(modifier = Modifier.height(16.dp))
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Box(modifier = Modifier.size(16.dp).background(skeletonColor, CircleShape))
                    Box(modifier = Modifier.width(80.dp).height(12.dp).background(skeletonColor, RoundedCornerShape(4.dp)))
                }
            }

            // Button skeleton
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .background(skeletonColor, CircleShape)
            )
        }
    }
}

@Composable
fun AnalyzedVideoCard(
    video: AnalyzedVideo,
    onOpenDownloadOptions: () -> Unit,
    onStreamBestClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(130.dp)
            .animateContentSize(animationSpec = androidx.compose.animation.core.spring(dampingRatio = androidx.compose.animation.core.Spring.DampingRatioMediumBouncy, stiffness = androidx.compose.animation.core.Spring.StiffnessLow))
            .testTag("analyzed_video_card"),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        shape = RoundedCornerShape(20.dp),
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.2f))
    ) {
        Box(modifier = Modifier.fillMaxSize().background(
            brush = Brush.linearGradient(
                colors = listOf(SleekPurpleContainer.copy(alpha = 0.4f), Color.White.copy(alpha = 0.05f))
            )
        )) {
            Row(
                modifier = Modifier.fillMaxSize().padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
            // Thumbnail
            Box(
                modifier = Modifier
                    .fillMaxHeight()
                    .aspectRatio(16f/9f)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color.Black)
                    .clickable { onStreamBestClick() }
            ) {
                AsyncImage(
                    model = video.thumbnailUrl,
                    contentDescription = "Video Thumbnail",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop,
                    alpha = 0.9f
                )
                // Play Overlay
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.2f)),
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .background(Color.Black.copy(alpha = 0.6f), CircleShape)
                            .border(1.dp, Color.White.copy(alpha = 0.3f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.PlayArrow,
                            contentDescription = "Stream Best",
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
                // Duration Badge
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(6.dp)
                        .background(Color.Black.copy(alpha = 0.7f), shape = RoundedCornerShape(4.dp))
                        .padding(horizontal = 4.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = video.durationText,
                        color = Color.White,
                        style = MaterialTheme.typography.bodySmall.copy(
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 9.sp
                        )
                    )
                }
            }

            // Details
            Column(
                modifier = Modifier.weight(1f).fillMaxHeight(),
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    text = video.title,
                    color = SleekTextPrimary,
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(Icons.Default.Person, contentDescription = "Channel", tint = SleekTextSecondary, modifier = Modifier.size(14.dp))
                    Text(
                        text = video.author,
                        color = SleekTextSecondary,
                        style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            // Download Button
            IconButton(
                onClick = onOpenDownloadOptions,
                modifier = Modifier
                    .size(48.dp)
                    .background(SleekPurpleDark, CircleShape)
            ) {
                Icon(Icons.Default.KeyboardArrowDown, contentDescription = "Download Options", tint = SleekTextPrimary)
            }
        }
      }
    }
}

@Composable
fun FormatRowItem(
    format: VideoFormatUi,
    onDownloadClick: () -> Unit,
    onStreamClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(
                brush = Brush.linearGradient(
                    colors = listOf(Color.White.copy(alpha = 0.1f), Color.White.copy(alpha = 0.02f))
                )
            )
            .border(1.dp, Color.White.copy(alpha = 0.2f), shape = RoundedCornerShape(16.dp))
            .padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .background(SleekPurpleContainer, shape = RoundedCornerShape(10.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.PlayArrow,
                    contentDescription = null,
                    tint = SleekPurpleDark,
                    modifier = Modifier.size(18.dp)
                )
            }
            Column {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = format.quality,
                        color = SleekTextPrimary,
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Box(
                        modifier = Modifier
                            .background(SleekPurpleLight.copy(alpha = 0.3f), shape = RoundedCornerShape(6.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = format.ext.uppercase(),
                            color = SleekTextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                    if (format.type == "video_only") {
                        Box(
                            modifier = Modifier
                                .background(SleekPurpleLight, shape = RoundedCornerShape(6.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "⚡ MERGING",
                                color = SleekTextPrimary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
                Text(
                    text = format.sizeText,
                    color = SleekTextSecondary,
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }

        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onStreamClick,
                modifier = Modifier
                    .size(36.dp)
                    .background(Color.White.copy(alpha = 0.12f), CircleShape)
                    .border(1.dp, Color.White.copy(alpha = 0.25f), CircleShape)
            ) {
                Icon(
                    imageVector = Icons.Default.PlayArrow,
                    contentDescription = "Stream Direct",
                    tint = SleekTextPrimary,
                    modifier = Modifier.size(18.dp)
                )
            }

            Button(
                onClick = onDownloadClick,
                colors = ButtonDefaults.buttonColors(
                    containerColor = SleekPurpleDark,
                    contentColor = SleekBg
                ),
                shape = RoundedCornerShape(50),
                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                modifier = Modifier.height(36.dp)
            ) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("GET", fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
        }
    }
}

@Composable
fun SearchResultItemRow(
    result: YtdlpPipelineManager.SearchResult,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = SleekCard),
        border = BorderStroke(1.dp, SleekBorderColor.copy(alpha = 0.3f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(width = 110.dp, height = 70.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color.Black)
            ) {
                AsyncImage(
                    model = result.thumbnailUrl,
                    contentDescription = result.title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                
                if (result.duration.isNotBlank()) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .padding(4.dp)
                            .background(Color.Black.copy(alpha = 0.75f), RoundedCornerShape(4.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = result.duration,
                            color = Color.White,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 10.sp
                            )
                        )
                    }
                }
            }

            Column(
                modifier = Modifier
                    .weight(1f)
                    .align(Alignment.CenterVertically),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text = result.title,
                    color = SleekTextPrimary,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        fontWeight = FontWeight.Bold,
                        lineHeight = 18.sp
                    ),
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                
                Text(
                    text = result.author,
                    color = SleekTextSecondary,
                    style = MaterialTheme.typography.bodySmall.copy(
                        fontWeight = FontWeight.Medium
                    ),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            
            Box(
                modifier = Modifier
                    .align(Alignment.CenterVertically)
                    .size(36.dp)
                    .background(SleekPurpleDark.copy(alpha = 0.1f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.PlayArrow,
                    contentDescription = "Select & Analyze",
                    tint = SleekPurpleDark,
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}

@Composable
fun SkeletonSearchResultItem() {
    val infiniteTransition = androidx.compose.animation.core.rememberInfiniteTransition(label = "search_skeleton")
    val alpha by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 0.8f,
        animationSpec = androidx.compose.animation.core.infiniteRepeatable(
            animation = androidx.compose.animation.core.tween(800, easing = androidx.compose.animation.core.LinearEasing),
            repeatMode = androidx.compose.animation.core.RepeatMode.Reverse
        ),
        label = "search_skeleton_alpha"
    )
    val skeletonColor = SleekPurpleContainer.copy(alpha = alpha)

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = SleekCard),
        border = BorderStroke(1.dp, SleekBorderColor.copy(alpha = 0.3f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(width = 110.dp, height = 70.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(skeletonColor)
            )

            Column(
                modifier = Modifier
                    .weight(1f)
                    .align(Alignment.CenterVertically),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth(0.9f)
                        .height(16.dp)
                        .background(skeletonColor, RoundedCornerShape(4.dp))
                )
                Box(
                    modifier = Modifier
                        .fillMaxWidth(0.6f)
                        .height(12.dp)
                        .background(skeletonColor, RoundedCornerShape(4.dp))
                )
            }
            
            Box(
                modifier = Modifier
                    .align(Alignment.CenterVertically)
                    .size(36.dp)
                    .background(skeletonColor, CircleShape)
            )
        }
    }
}

@Composable
fun PremiumSeekBar(
    value: Float,
    onValueChange: (Float) -> Unit,
    valueRange: ClosedFloatingPointRange<Float>,
    modifier: Modifier = Modifier,
    activeColor: Color = Color.White,
    inactiveColor: Color = Color.White.copy(alpha = 0.24f)
) {
    val rangeMin = valueRange.start
    val rangeMax = valueRange.endInclusive
    val rangeLength = rangeMax - rangeMin

    val progressFraction = if (rangeLength > 0f) {
        ((value - rangeMin) / rangeLength).coerceIn(0f, 1f)
    } else {
        0f
    }

    var isDragging by remember { mutableStateOf(false) }

    // Modern progressive animation for track thick/thin and thumb size
    val thumbRadius by androidx.compose.animation.core.animateDpAsState(
        targetValue = if (isDragging) 8.dp else 4.dp,
        animationSpec = androidx.compose.animation.core.spring(
            dampingRatio = androidx.compose.animation.core.Spring.DampingRatioMediumBouncy,
            stiffness = androidx.compose.animation.core.Spring.StiffnessLow
        ),
        label = "thumb_radius"
    )

    val trackHeight by androidx.compose.animation.core.animateDpAsState(
        targetValue = if (isDragging) 6.dp else 3.dp,
        animationSpec = androidx.compose.animation.core.spring(
            stiffness = androidx.compose.animation.core.Spring.StiffnessMedium
        ),
        label = "track_height"
    )

    BoxWithConstraints(
        modifier = modifier
            .fillMaxWidth()
            .height(24.dp),
        contentAlignment = Alignment.CenterStart
    ) {
        val widthPx = constraints.maxWidth.toFloat()

        Box(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(rangeMin, rangeMax, widthPx) {
                    detectTapGestures(
                        onPress = { offset ->
                            val fraction = (offset.x / widthPx).coerceIn(0f, 1f)
                            val newValue = rangeMin + fraction * rangeLength
                            onValueChange(newValue)
                        }
                    )
                }
                .pointerInput(rangeMin, rangeMax, widthPx) {
                    detectHorizontalDragGestures(
                        onDragStart = { isDragging = true },
                        onDragEnd = { isDragging = false },
                        onDragCancel = { isDragging = false },
                        onHorizontalDrag = { change, _ ->
                            val fraction = (change.position.x / widthPx).coerceIn(0f, 1f)
                            val newValue = rangeMin + fraction * rangeLength
                            onValueChange(newValue)
                            change.consume()
                        }
                    )
                }
        ) {
            Canvas(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.Center)
                    .height(24.dp)
            ) {
                val canvasWidth = size.width
                val canvasHeight = size.height
                val centerY = canvasHeight / 2f

                val trackHeightPx = trackHeight.toPx()
                val activeEndX = canvasWidth * progressFraction

                // 1. Draw Inactive Track
                drawRoundRect(
                    color = inactiveColor,
                    topLeft = androidx.compose.ui.geometry.Offset(0f, centerY - trackHeightPx / 2f),
                    size = androidx.compose.ui.geometry.Size(canvasWidth, trackHeightPx),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(trackHeightPx / 2f)
                )

                // 2. Draw Active Seek progress status
                drawRoundRect(
                    brush = Brush.horizontalGradient(
                        colors = listOf(
                            activeColor.copy(alpha = 0.75f),
                            activeColor
                        )
                    ),
                    topLeft = androidx.compose.ui.geometry.Offset(0f, centerY - trackHeightPx / 2f),
                    size = androidx.compose.ui.geometry.Size(activeEndX, trackHeightPx),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(trackHeightPx / 2f)
                )

                // 3. Draw active focus glow halo
                if (isDragging) {
                    drawCircle(
                        color = activeColor.copy(alpha = 0.18f),
                        radius = thumbRadius.toPx() * 2.5f,
                        center = androidx.compose.ui.geometry.Offset(activeEndX, centerY)
                    )
                }

                // 4. Draw active thumb
                drawCircle(
                    color = Color.White,
                    radius = thumbRadius.toPx(),
                    center = androidx.compose.ui.geometry.Offset(activeEndX, centerY)
                )
            }
        }
    }
}

@OptIn(com.google.accompanist.permissions.ExperimentalPermissionsApi::class)
@Composable
fun LibraryTab(
    downloads: List<DownloadEntity>,
    onPlayClick: (DownloadEntity) -> Unit,
    onShareClick: (DownloadEntity) -> Unit,
    onDeleteClick: (DownloadEntity) -> Unit,
    onConvertAudio: (DownloadEntity) -> Unit
) {
    val context = LocalContext.current
    val permissionState = com.google.accompanist.permissions.rememberMultiplePermissionsState(
        buildList {
            if (android.os.Build.VERSION.SDK_INT >= 33) {
                add(android.Manifest.permission.READ_MEDIA_VIDEO)
                add(android.Manifest.permission.READ_MEDIA_AUDIO)
            } else {
                add(android.Manifest.permission.READ_EXTERNAL_STORAGE)
                add(android.Manifest.permission.WRITE_EXTERNAL_STORAGE)
            }
        }
    )

    // Force a secondary check or a simple flag if allPermissionsGranted seems unreliable
    val isStoragePermissionGranted = remember(permissionState.allPermissionsGranted) {
        permissionState.allPermissionsGranted
    }

    var selectedFilter by remember { mutableStateOf("All") }
    val filters = listOf("All", "Videos", "Audio")
    
    val filteredDownloads = downloads.filter {
        when (selectedFilter) {
            "Videos" -> it.localPath.endsWith(".mp4", true) || it.localPath.endsWith(".webm", true) || it.localPath.endsWith(".mkv", true)
            "Audio" -> it.localPath.endsWith(".mp3", true) || it.localPath.endsWith(".m4a", true) || it.localPath.endsWith(".opus", true) || it.localPath.endsWith(".wav", true)
            else -> true
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                filters.forEach { filter ->
                    FilterChip(
                        selected = selectedFilter == filter,
                        onClick = { selectedFilter = filter },
                        label = { Text(filter, fontWeight = FontWeight.Bold, fontSize = 12.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = SleekPurpleLight.copy(alpha = 0.2f),
                            selectedLabelColor = SleekPurpleDark,
                            containerColor = SleekBg,
                            labelColor = SleekTextSecondary
                        ),
                        border = FilterChipDefaults.filterChipBorder(
                            borderColor = SleekBorderColor,
                            enabled = true,
                            selected = selectedFilter == filter
                        )
                    )
                }
            }
            if (!isStoragePermissionGranted) {
                IconButton(onClick = { permissionState.launchMultiplePermissionRequest() }) {
                    Icon(Icons.Default.Folder, contentDescription = "Request Storage", tint = SleekPurpleDark)
                }
            }
        }

        if (filteredDownloads.isEmpty()) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(
                    imageVector = Icons.Default.Info,
                    contentDescription = "Empty",
                    tint = SleekTextMuted.copy(alpha = 0.5f),
                    modifier = Modifier.size(80.dp)
                )
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "NO COMPATIBLE MEDIA",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = SleekTextPrimary,
                        letterSpacing = 1.sp
                    )
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = if (!isStoragePermissionGranted) "Grant storage access to see your device media, or download content." else "No media matches the currently selected filter.",
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = SleekTextSecondary,
                        textAlign = TextAlign.Center
                    )
                )
                if (!isStoragePermissionGranted) {
                    Spacer(modifier = Modifier.height(16.dp))
                    Button(onClick = { permissionState.launchMultiplePermissionRequest() }) {
                        Text("Grant Permissions")
                    }
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Text(
                        text = "DOWNLOAD HISTORY (${filteredDownloads.size})",
                        style = MaterialTheme.typography.titleSmall.copy(
                            color = SleekPurpleDark,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            letterSpacing = 1.sp
                        ),
                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 4.dp)
                    )
                }

                items(filteredDownloads, key = { it.id }) { item ->
                    LibraryItemCard(
                        item = item,
                        onPlayClick = { onPlayClick(item) },
                        onShareClick = { onShareClick(item) },
                        onDeleteClick = { onDeleteClick(item) },
                        onConvertAudio = { onConvertAudio(item) },
                        modifier = Modifier.animateItem()
                    )
                }
            }
        }
    }
}

@Composable
fun LibraryItemCard(
    item: DownloadEntity,
    onPlayClick: () -> Unit,
    onShareClick: () -> Unit,
    onDeleteClick: () -> Unit,
    onConvertAudio: () -> Unit,
    modifier: Modifier = Modifier
) {
    var showDeleteConfirmDialog by remember { mutableStateOf(false) }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .animateContentSize(animationSpec = androidx.compose.animation.core.spring(dampingRatio = androidx.compose.animation.core.Spring.DampingRatioMediumBouncy, stiffness = androidx.compose.animation.core.Spring.StiffnessLow))
            .testTag("library_item_card"),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.2f))
    ) {
        Column(modifier = Modifier.background(
            brush = Brush.linearGradient(
                colors = listOf(Color.White.copy(alpha = 0.15f), Color.White.copy(alpha = 0.05f))
            )
        )) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Mini Thumbnail
                Box(
                    modifier = Modifier
                        .size(width = 110.dp, height = 75.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(SleekBg)
                ) {
                    if (item.thumbnailUrl.isNotEmpty()) {
                        AsyncImage(
                            model = item.thumbnailUrl,
                            contentDescription = "Cover",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                    } else {
                        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Icon(imageVector = Icons.Default.MusicNote, contentDescription = "Audio Icon", tint = SleekPurpleDark, modifier = Modifier.size(48.dp))
                        }
                    }
                    // Length badge
                    Box(
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .padding(4.dp)
                            .background(Color.Black.copy(alpha = 0.7f), shape = RoundedCornerShape(4.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = item.durationText,
                            color = Color.White,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }

                // Info details
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .height(75.dp),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(
                            text = item.title,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            color = SleekTextPrimary,
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Text(
                            text = item.author,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            color = SleekTextSecondary,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // File size formatted
                        val formattedSize = String.format(Locale.getDefault(), "%.1f MB", item.fileSize.toFloat() / (1024 * 1024))
                        val isAudio = item.localPath.endsWith(".mp3") || item.localPath.endsWith(".m4a")
                        
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.PlayArrow,
                                contentDescription = null,
                                tint = SleekTextMuted,
                                modifier = Modifier.size(14.dp)
                            )
                            Text(
                                text = "$formattedSize  •  ${SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(item.downloadedAt))}",
                                color = SleekTextSecondary,
                                style = MaterialTheme.typography.labelSmall
                            )
                        }
                    }
                }
            }

            // Quick actions line
            Divider(color = SleekBorderColor.copy(alpha = 0.4f))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    // Play action (Sleek dark purple pill button)
                    Button(
                        onClick = onPlayClick,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = SleekPurpleDark,
                            contentColor = SleekBg
                        ),
                        shape = RoundedCornerShape(50),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                        modifier = Modifier.height(32.dp)
                    ) {
                        Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("PLAY", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }

                    // Share action (Sleek outline border pill button)
                    OutlinedButton(
                        onClick = onShareClick,
                        border = BorderStroke(1.dp, SleekBorderColor),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = SleekTextSecondary),
                        shape = RoundedCornerShape(50),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                        modifier = Modifier.height(32.dp)
                    ) {
                        Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("SHARE", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }

                    // Convert action if it is a video
                    val isVideo = item.localPath.endsWith(".mp4", true) || item.localPath.endsWith(".mkv", true) || item.localPath.endsWith(".webm", true)
                    if (isVideo) {
                        OutlinedButton(
                            onClick = onConvertAudio,
                            border = BorderStroke(1.dp, SleekBorderColor),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = SleekPurpleLight),
                            shape = RoundedCornerShape(50),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                            modifier = Modifier.height(32.dp)
                        ) {
                            Icon(Icons.Default.MusicNote, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("TO MP3", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                }

                // Delete action
                IconButton(
                    onClick = { showDeleteConfirmDialog = true },
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = "Delete",
                        tint = CrimsonFailure,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }

    if (showDeleteConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirmDialog = false },
            title = { Text("Delete downloaded file?", color = SleekTextPrimary, fontWeight = FontWeight.Bold) },
            text = { Text("This will permanently delete this video from your device storage and library cache.", color = SleekTextSecondary) },
            confirmButton = {
                TextButton(
                    onClick = {
                        showDeleteConfirmDialog = false
                        onDeleteClick()
                    }
                ) {
                    Text("DELETE", color = CrimsonFailure, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirmDialog = false }) {
                    Text("CANCEL", color = SleekTextSecondary, fontWeight = FontWeight.Bold)
                }
            },
            containerColor = SleekCard,
            titleContentColor = SleekTextPrimary,
            textContentColor = SleekTextSecondary
        )
    }
}

@Composable
fun SmoothToggle(
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    val offset by animateFloatAsState(
        targetValue = if (checked) 24f else 4f,
        animationSpec = tween(durationMillis = 250),
        label = "toggle_offset"
    )
    
    val trackColor = if (checked) SleekPurpleDark else SleekCardDark.copy(alpha = 0.5f)
    val thumbColor = if (checked) SleekBg else SleekTextSecondary.copy(alpha = 0.7f)

    Box(
        modifier = modifier
            .size(width = 50.dp, height = 28.dp)
            .clip(RoundedCornerShape(50))
            .background(trackColor)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null
            ) {
                onCheckedChange(!checked)
            }
    ) {
        Box(
            modifier = Modifier
                .offset(x = offset.dp)
                .align(Alignment.CenterStart)
                .size(20.dp)
                .clip(CircleShape)
                .background(thumbColor)
        )
    }
}

@Composable
fun SettingRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    description: String,
    onClick: (() -> Unit)? = null,
    action: @Composable RowScope.() -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(SleekCard, RoundedCornerShape(16.dp))
            .border(1.dp, SleekBorderColor.copy(alpha = 0.4f), RoundedCornerShape(16.dp))
            .then(
                if (onClick != null) Modifier.clickable(onClick = onClick)
                else Modifier
            )
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(40.dp)
                .background(SleekPurpleContainer.copy(alpha = 0.4f), CircleShape)
                .border(1.dp, SleekBorderColor.copy(alpha = 0.5f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = SleekTextPrimary,
                modifier = Modifier.size(20.dp)
            )
        }
        
        Spacer(modifier = Modifier.width(16.dp))
        
        Column(
            modifier = Modifier
                .weight(1f)
                .padding(end = 12.dp)
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    letterSpacing = 0.2.sp
                ),
                color = SleekTextPrimary
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = description,
                style = MaterialTheme.typography.bodyMedium.copy(
                    fontSize = 11.sp,
                    lineHeight = 15.sp
                ),
                color = SleekTextSecondary
            )
        }
        
        Row(
            verticalAlignment = Alignment.CenterVertically,
            content = action
        )
    }
}

@Composable
fun SettingsTab(
    downloads: List<com.example.data.DownloadEntity>,
    onClearAllDownloads: () -> Unit,
    viewModel: VideoDownloaderViewModel
) {
    val context = LocalContext.current
    var showConfirmClear by remember { mutableStateOf(false) }
    var wifiOnly by remember { mutableStateOf(true) }
    var backgroundDownloads by remember { mutableStateOf(true) }
    var autoConvertAudio by remember { mutableStateOf(false) }

    val downloadCount = downloads.size
    val totalBytes = downloads.sumOf { it.fileSize }
    val totalMb = totalBytes / (1024.0 * 1024.0)
    val sizeFormatted = if (totalMb > 1024) String.format(java.util.Locale.US, "%.2f GB", totalMb / 1024.0) else String.format(java.util.Locale.US, "%.1f MB", totalMb)

    val customCommandInput by viewModel.customCommandInput.collectAsStateWithLifecycle()
    val ytdlpVerificationStatus by viewModel.ytdlpVerificationStatus.collectAsStateWithLifecycle()
    val isYtdlpLoading by viewModel.isYtdlpLoading.collectAsStateWithLifecycle()
    val usePublicDownloads by viewModel.usePublicDownloads.collectAsStateWithLifecycle()
    val defaultDownloadQuality by viewModel.defaultDownloadQuality.collectAsStateWithLifecycle()

    if (showConfirmClear) {
        AlertDialog(
            onDismissRequest = { showConfirmClear = false },
            title = { Text("Delete Library & Files?", fontWeight = FontWeight.Bold, color = SleekTextPrimary) },
            text = { Text("This will permanently delete all $downloadCount downloaded videos and media from your device memory. This action cannot be undone.", color = SleekTextSecondary) },
            confirmButton = {
                TextButton(
                    onClick = {
                        showConfirmClear = false
                        onClearAllDownloads()
                    }
                ) {
                    Text("DELETE ALL", color = CrimsonFailure, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showConfirmClear = false }) {
                    Text("CANCEL", color = SleekTextSecondary, fontWeight = FontWeight.Bold)
                }
            },
            containerColor = SleekCard,
            titleContentColor = SleekTextPrimary,
            textContentColor = SleekTextSecondary,
            shape = RoundedCornerShape(24.dp)
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 24.dp, vertical = 20.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(24.dp)
    ) {
        // Preferences Block
        Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Text("PREFERENCES", style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold, color = SleekPurpleDark))
            
            SettingRow(
                icon = Icons.Default.Wifi,
                title = "Download over Wi-Fi only",
                description = "Pause downloads on cellular data"
            ) {
                SmoothToggle(
                    checked = wifiOnly,
                    onCheckedChange = { wifiOnly = it }
                )
            }

            SettingRow(
                icon = Icons.Default.CloudDownload,
                title = "Background downloads",
                description = "Continue downloading when app is closed"
            ) {
                SmoothToggle(
                    checked = backgroundDownloads,
                    onCheckedChange = { backgroundDownloads = it }
                )
            }

            SettingRow(
                icon = Icons.Default.MusicNote,
                title = "Save as Audio by Default",
                description = "Always extract MP3 format if available"
            ) {
                SmoothToggle(
                    checked = autoConvertAudio,
                    onCheckedChange = { autoConvertAudio = it }
                )
            }
            SettingRow(
                icon = Icons.Default.Folder,
                title = "Save to Public Downloads",
                description = "Store files in main Downloads folder"
            ) {
                SmoothToggle(
                    checked = usePublicDownloads,
                    onCheckedChange = { viewModel.updateUsePublicDownloads(it) }
                )
            }

            var isOverlayActive by remember {
                mutableStateOf(
                    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
                        android.provider.Settings.canDrawOverlays(context)
                    } else {
                        true
                    }
                )
            }

            SettingRow(
                icon = Icons.Default.Layers,
                title = "Floating over other apps",
                description = "Show floating search bubble over other applications"
            ) {
                SmoothToggle(
                    checked = isOverlayActive,
                    onCheckedChange = { active ->
                        if (active) {
                            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M && !android.provider.Settings.canDrawOverlays(context)) {
                                val intent = android.content.Intent(
                                    android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                    android.net.Uri.parse("package:${context.packageName}")
                                )
                                context.startActivity(intent)
                            } else {
                                isOverlayActive = true
                                context.startService(android.content.Intent(context, com.example.FloatingWidgetService::class.java))
                            }
                        } else {
                            isOverlayActive = false
                            context.stopService(android.content.Intent(context, com.example.FloatingWidgetService::class.java))
                        }
                    }
                )
            }

            var qualityExpanded by remember { mutableStateOf(false) }
            val options = listOf("Ask Every Time", "Audio Only", "1080p", "720p", "480p", "360p", "144p")

            SettingRow(
                icon = Icons.Default.HighQuality,
                title = "Default Download Quality",
                description = "Automatically skip format selection if available",
                onClick = { qualityExpanded = true }
            ) {
                Box {
                    TextButton(
                        onClick = { qualityExpanded = true },
                        colors = ButtonDefaults.textButtonColors(contentColor = SleekPurpleLight)
                    ) {
                        Text(defaultDownloadQuality, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.width(4.dp))
                        Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                    }
                    DropdownMenu(
                        expanded = qualityExpanded,
                        onDismissRequest = { qualityExpanded = false },
                        modifier = Modifier.background(SleekCardDark)
                    ) {
                        options.forEach { selectionOption ->
                            DropdownMenuItem(
                                text = { Text(selectionOption, color = SleekTextPrimary) },
                                onClick = {
                                    viewModel.updateDefaultDownloadQuality(selectionOption)
                                    qualityExpanded = false
                                }
                            )
                        }
                    }
                }
            }

            var themeExpanded by remember { mutableStateOf(false) }
            val themeOptions = listOf("System Default", "Light Mode", "Dark Mode")
            val currentTheme by viewModel.themeMode.collectAsStateWithLifecycle()

            SettingRow(
                icon = Icons.Default.Contrast,
                title = "App Theme",
                description = "Choose between light, dark, or system default",
                onClick = { themeExpanded = true }
            ) {
                Box {
                    TextButton(
                        onClick = { themeExpanded = true },
                        colors = ButtonDefaults.textButtonColors(contentColor = SleekPurpleLight)
                    ) {
                        Text(currentTheme, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.width(4.dp))
                        Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                    }
                    DropdownMenu(
                        expanded = themeExpanded,
                        onDismissRequest = { themeExpanded = false },
                        modifier = Modifier.background(SleekCardDark)
                    ) {
                        themeOptions.forEach { themeOption ->
                            DropdownMenuItem(
                                text = { Text(themeOption, color = SleekTextPrimary) },
                                onClick = {
                                    viewModel.updateThemeMode(themeOption)
                                    themeExpanded = false
                                }
                            )
                        }
                    }
                }
            }
        }

        HorizontalDivider(color = SleekBorderColor.copy(alpha = 0.4f))

        // Storage location block
        Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            Text("STORAGE PATH", style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold, color = SleekPurpleDark))
            Text(
                if (usePublicDownloads) "Files are saved to your public folder:\nInternal Storage/Download/"
                else "Files are saved privately to guarantee playback security:\nInternal Storage/Android/data/\ncom.example/files/Movies/",
                style = MaterialTheme.typography.bodyMedium.copy(fontFamily = FontFamily.Monospace),
                color = SleekTextSecondary
            )
        }

        HorizontalDivider(color = SleekBorderColor.copy(alpha = 0.4f))

        // Storage Analyzer Block
        Card(
            colors = CardDefaults.cardColors(containerColor = SleekCard),
            shape = RoundedCornerShape(24.dp),
            border = BorderStroke(1.dp, SleekBorderColor.copy(alpha = 0.5f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    text = "STORAGE ANALYZER",
                    style = MaterialTheme.typography.labelMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = SleekPurpleDark,
                        letterSpacing = 1.sp
                    )
                )

                Row(verticalAlignment = Alignment.Bottom) {
                    Text(
                        text = sizeFormatted,
                        style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Black),
                        color = SleekTextPrimary
                    )
                    Text(
                        text = " used by downloaded media",
                        style = MaterialTheme.typography.bodyMedium,
                        color = SleekTextSecondary,
                        modifier = Modifier.padding(bottom = 5.dp, start = 8.dp)
                    )
                }

                // Visualizer Bar
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .clip(RoundedCornerShape(50))
                        .background(SleekPurpleLight.copy(alpha = 0.2f))
                ) {
                    val targetProgress = if (downloads.isNotEmpty()) 1f else 0.05f
                    val animatedProgress by androidx.compose.animation.core.animateFloatAsState(
                        targetValue = targetProgress,
                        animationSpec = androidx.compose.animation.core.tween(1500)
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(animatedProgress)
                            .height(8.dp)
                            .background(
                                brush = androidx.compose.ui.graphics.Brush.horizontalGradient(
                                    colors = listOf(SleekPurpleDark, EmeraldSuccess)
                                )
                            )
                    )
                }
            }
        }

        HorizontalDivider(color = SleekBorderColor.copy(alpha = 0.4f))

        // Diagnostics
        SettingRow(
            icon = Icons.Default.Delete,
            title = "LIBRARY ITEMS",
            description = "$downloadCount items cached offline",
            onClick = { if (downloadCount > 0) showConfirmClear = true }
        ) {
            if (downloadCount > 0) {
                Button(
                    onClick = { showConfirmClear = true },
                    colors = ButtonDefaults.buttonColors(containerColor = CrimsonFailure, contentColor = SleekBg),
                    shape = RoundedCornerShape(50),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                    modifier = Modifier.height(40.dp)
                ) {
                    Text("CLEAR ALL", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }
        }

        HorizontalDivider(color = SleekBorderColor.copy(alpha = 0.4f))

        // Custom CLI Runner Block
        Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            Text(
                "CUSTOM CLI TERMINAL RUNNER", 
                style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold, color = SleekPurpleDark)
            )
            OutlinedTextField(
                value = customCommandInput,
                onValueChange = { viewModel.updateCustomCommandInput(it) },
                placeholder = { Text("e.g. --version or --help", color = SleekTextSecondary.copy(alpha = 0.6f)) },
                leadingIcon = {
                    Text(
                        " ./engine ",
                        color = SleekPurpleDark,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(start = 12.dp)
                    )
                },
                textStyle = LocalTextStyle.current.copy(fontFamily = FontFamily.Monospace, fontSize = 13.sp),
                modifier = Modifier.fillMaxWidth().testTag("custom_command_input"),
                shape = RoundedCornerShape(12.dp),
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = SleekTextPrimary,
                    unfocusedTextColor = SleekTextPrimary,
                    focusedBorderColor = SleekPurpleDark,
                    unfocusedBorderColor = SleekBorderColor,
                    focusedContainerColor = SleekCardDark,
                    unfocusedContainerColor = SleekCardDark
                )
            )
            
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Button(
                    onClick = { viewModel.verifyYtdlp(context) },
                    colors = ButtonDefaults.buttonColors(containerColor = SleekCardDark, contentColor = SleekPurpleDark),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.weight(1f).testTag("verify_ytdlp_btn"),
                    enabled = !isYtdlpLoading,
                    border = BorderStroke(1.dp, SleekPurpleLight)
                ) {
                    Text("VERIFY", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
                
                Button(
                    onClick = { viewModel.executeCustomYtdlpCommand(context) },
                    colors = ButtonDefaults.buttonColors(containerColor = SleekPurpleDark, contentColor = SleekBg),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.weight(1f).testTag("run_custom_command_btn"),
                    enabled = !isYtdlpLoading
                ) {
                    Text("RUN", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }
            
            // Terminal Output
            if (ytdlpVerificationStatus.isNotEmpty()) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = SleekCardDark),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
                ) {
                    SelectionContainer {
                        Text(
                            text = ytdlpVerificationStatus,
                            color = EmeraldSuccess,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp,
                            modifier = Modifier.padding(12.dp).fillMaxWidth()
                        )
                    }
                }
            }
        }

        HorizontalDivider(color = SleekBorderColor.copy(alpha = 0.4f))

        // 🚀 LIVE CONSOLE LOGS TERMINAL
        Card(
            colors = CardDefaults.cardColors(containerColor = SleekCard),
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(1.dp, SleekPurpleDark.copy(alpha = 0.15f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            val executionLogs by viewModel.executionLogs.collectAsStateWithLifecycle()
            
            Column(
                modifier = Modifier.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .background(EmeraldSuccess, shape = CircleShape)
                        )
                        Text(
                            text = "LIVE CONSOLE LOGS",
                            color = SleekTextSecondary,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                letterSpacing = 0.5.sp
                            )
                        )
                    }
                    
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val clipboardManager = androidx.compose.ui.platform.LocalClipboardManager.current
                        val currentContext = androidx.compose.ui.platform.LocalContext.current
                        TextButton(
                            onClick = {
                                val logsText = executionLogs.joinToString("\n")
                                clipboardManager.setText(androidx.compose.ui.text.AnnotatedString(logsText))
                                android.widget.Toast.makeText(currentContext, "Logs copied!", android.widget.Toast.LENGTH_SHORT).show()
                            },
                            colors = ButtonDefaults.textButtonColors(contentColor = SleekPurpleDark),
                            modifier = Modifier.height(28.dp)
                        ) {
                            Text("COPY", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                        TextButton(
                            onClick = { viewModel.clearLogs() },
                            colors = ButtonDefaults.textButtonColors(contentColor = SleekPurpleDark),
                            modifier = Modifier.height(28.dp)
                        ) {
                            Text("CLEAR", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
                
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(220.dp)
                        .background(SleekCardDark, shape = RoundedCornerShape(8.dp))
                        .border(1.dp, SleekBorderColor, shape = RoundedCornerShape(8.dp))
                        .padding(10.dp)
                ) {
                    val scrollState = rememberLazyListState()
                    LaunchedEffect(executionLogs.size) {
                        if (executionLogs.isNotEmpty()) {
                            scrollState.animateScrollToItem(executionLogs.size - 1)
                        }
                    }
                    
                    LazyColumn(
                        state = scrollState,
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        items(executionLogs) { logLine ->
                            val logColor = when {
                                logLine.contains("❌") || logLine.contains("💀") -> CrimsonFailure
                                logLine.contains("✔") || logLine.contains("🎉") -> EmeraldSuccess
                                logLine.contains("⚠️") -> SleekPurpleLight
                                logLine.contains("📡") || logLine.contains("🎬") -> SleekPurpleLight
                                else -> SleekTextSecondary
                            }
                            Text(
                                text = logLine,
                                color = logColor,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 11.sp,
                                lineHeight = 15.sp
                            )
                        }
                    }
                }
            }
        }

        HorizontalDivider(color = SleekBorderColor.copy(alpha = 0.4f))

        // About block
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("ABOUT TUBESTREAM", style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold, color = SleekPurpleDark))
            Text(
                "TubeStream is a high-speed local downloader client powered by a robust media extraction engine. Segment extraction downloads stream parts simultaneously to maximize your bandwidth speed.",
                style = MaterialTheme.typography.bodyMedium,
                color = SleekTextSecondary
            )
        }
        
        Spacer(modifier = Modifier.height(32.dp))
    }
}

@OptIn(androidx.compose.ui.ExperimentalComposeUiApi::class, androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
fun VideoPlayerDialog(
    download: DownloadEntity,
    onDismiss: () -> Unit,
    viewModel: VideoDownloaderViewModel,
    onPlayRelated: (com.example.data.YtVideo) -> Unit
) {
    val context = LocalContext.current
    var isBoosted by remember { mutableStateOf(false) }
    var isHdrEnabled by remember { mutableStateOf(false) }
    var colorEnhancementPreset by remember { mutableStateOf("None") }

    // Qualities selection states for high performance streaming
    var streamFormats by remember { mutableStateOf<List<VideoFormatUi>>(emptyList()) }
    var currentFormat by remember { mutableStateOf<VideoFormatUi?>(null) }
    var isLoadingFormats by remember { mutableStateOf(false) }
    var isQualityMenuExpanded by remember { mutableStateOf(false) }
    var currentPlaySpeed by remember { mutableStateOf(1.0f) }
    var currentQualityMode by remember { mutableStateOf("Auto") }
    var isLoopEnabled by remember { mutableStateOf(true) }
    var playerResizeMode by remember { mutableStateOf(0) } // 0 fit, 3 fill, 4 zoom
    var sleepTimerMinutes by remember { mutableStateOf(0) }
    var showVideoDownloadSheet by remember { mutableStateOf(false) }
    var analyzedVideoResult by remember { mutableStateOf<com.example.ui.AnalyzedVideo?>(null) }

    // Identify if we need to resolve YouTube URLs before initializing the ExoPlayer
    val isRawYoutubeUrl = remember(download.localPath) {
        val path = download.localPath.lowercase()
        (path.startsWith("http://") || path.startsWith("https://")) && (path.contains("youtube.com") || path.contains("youtu.be"))
    }
    var isStreamResolving by remember { mutableStateOf(isRawYoutubeUrl) }

    val exoPlayer = remember {
        com.example.ui.PlayerHolder.initialize(context)
    }

    LaunchedEffect(currentQualityMode) {
        val trackSelector = com.example.ui.PlayerHolder.trackSelector ?: return@LaunchedEffect
        val builder = trackSelector.buildUponParameters()
        if (currentQualityMode == "Auto") {
            builder.setMaxVideoSize(Int.MAX_VALUE, Int.MAX_VALUE)
        } else {
            val height = currentQualityMode.replace("p", "").toIntOrNull() ?: 1080
            builder.setMaxVideoSize(Int.MAX_VALUE, height)
        }
        trackSelector.setParameters(builder)
    }

    LaunchedEffect(download.localPath) {
        if (!isRawYoutubeUrl) {
            val initialPath = download.localPath
            val mediaItem = if (initialPath.startsWith("http://") || initialPath.startsWith("https://")) {
                androidx.media3.common.MediaItem.fromUri(Uri.parse(initialPath))
            } else {
                androidx.media3.common.MediaItem.fromUri(Uri.fromFile(java.io.File(initialPath)))
            }
            exoPlayer.setMediaItem(mediaItem)
            exoPlayer.prepare()
            exoPlayer.playWhenReady = true
        }
        exoPlayer.repeatMode = androidx.media3.common.Player.REPEAT_MODE_ONE
    }

    val scope_ = rememberCoroutineScope()
    var isVisible by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        isVisible = true
    }

    val dismissWithAnimation = {
        scope_.launch {
            isVisible = false
            kotlinx.coroutines.delay(280)
            onDismiss()
        }
    }
    
    // Trigger YouTube Data API / fallback loading when videoId changes
    LaunchedEffect(download.id) {
        viewModel.loadVideoDetailsAndDecorations(
            videoId = download.id,
            defaultTitle = download.title.replace("[Live Stream] ", "").replace("[Streaming Video] ", "").replace("[Streaming Audio] ", ""),
            defaultAuthor = download.author,
            defaultThumb = download.thumbnailUrl,
            defaultDuration = download.durationText,
            defaultUrl = download.localPath
        )

        // Asynchronously load stream qualities and formats for this video
        if (download.id.isNotBlank()) {
            isLoadingFormats = true
            isStreamResolving = isRawYoutubeUrl
            try {
                if (isRawYoutubeUrl) {
                    val url = "https://www.youtube.com/watch?v=" + download.id
                    val analyzed = YtdlpPipelineManager.analyzeUrl(context, url) { _ -> }
                    if (analyzed != null) {
                        analyzedVideoResult = com.example.ui.AnalyzedVideo(
                            id = download.id,
                            title = analyzed.title,
                            author = analyzed.uploader,
                            durationText = download.durationText,
                            thumbnailUrl = analyzed.thumbnailUrl,
                            formats = analyzed.formats,
                            originalUrl = url
                        )
                        val formatsList = analyzed.formats.filter { it.type == "combined" || it.type == "video_only" }
                        streamFormats = formatsList
                        val firstBest = formatsList.firstOrNull()
                        currentFormat = firstBest
                        if (firstBest != null) {
                            val mediaItem = androidx.media3.common.MediaItem.fromUri(Uri.parse(firstBest.downloadUrl))
                            exoPlayer.setMediaItem(mediaItem)
                            exoPlayer.prepare()
                            exoPlayer.play()
                        }
                    }
                } else if (download.localPath.startsWith("http://") || download.localPath.startsWith("https://")) {
                    val url = "https://www.youtube.com/watch?v=" + download.id
                    val analyzed = YtdlpPipelineManager.analyzeUrl(context, url) { _ -> }
                    if (analyzed != null) {
                        analyzedVideoResult = com.example.ui.AnalyzedVideo(
                            id = download.id,
                            title = analyzed.title,
                            author = analyzed.uploader,
                            durationText = download.durationText,
                            thumbnailUrl = analyzed.thumbnailUrl,
                            formats = analyzed.formats,
                            originalUrl = url
                        )
                        val formatsList = analyzed.formats.filter { it.type == "combined" || it.type == "video_only" }
                        streamFormats = formatsList
                        currentFormat = formatsList.firstOrNull { it.downloadUrl == download.localPath }
                            ?: formatsList.firstOrNull()
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            } finally {
                isLoadingFormats = false
                isStreamResolving = false
            }
        }
    }

    // Collect states from ViewModel
    val videoDetails by viewModel.videoDetails.collectAsStateWithLifecycle()
    val videoComments by viewModel.videoComments.collectAsStateWithLifecycle()
    val relatedVideos by viewModel.relatedVideos.collectAsStateWithLifecycle()
    val isLoadingDetails by viewModel.isLoadingDetails.collectAsStateWithLifecycle()

    val infiniteTransition = androidx.compose.animation.core.rememberInfiniteTransition(label = "player_skeleton")
    val alpha by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 0.8f,
        animationSpec = androidx.compose.animation.core.infiniteRepeatable(
            animation = androidx.compose.animation.core.tween(800, easing = androidx.compose.animation.core.LinearEasing),
            repeatMode = androidx.compose.animation.core.RepeatMode.Reverse
        ),
        label = "player_skeleton_alpha"
    )
    val animatedSkeletonColor = SleekPurpleContainer.copy(alpha = alpha)

    // Interactive custom state variables for high-fidelity animations
    var isDescriptionExpanded by remember { mutableStateOf(false) }
    var isCommentsExpanded by remember { mutableStateOf(false) }
    var likedState by remember { mutableStateOf(0) } // 0 = none, 1 = liked, 2 = disliked
    var isSubscribed by remember { mutableStateOf(false) }


    val selectFormat = { format: VideoFormatUi ->
        val resumePosition = exoPlayer.currentPosition
        val wasPlaying = exoPlayer.isPlaying
        currentFormat = format
        
        val mediaItem = androidx.media3.common.MediaItem.fromUri(Uri.parse(format.downloadUrl))
        exoPlayer.setMediaItem(mediaItem)
        exoPlayer.prepare()
        exoPlayer.seekTo(resumePosition)
        if (wasPlaying) {
            exoPlayer.play()
        }
    }
    
    val loudnessEnhancer = com.example.ui.PlayerHolder.loudnessEnhancer!!

    DisposableEffect(Unit) {
        val sessionToken = androidx.media3.session.SessionToken(context, android.content.ComponentName(context, com.example.PlaybackService::class.java))
        val controllerFuture = androidx.media3.session.MediaController.Builder(context, sessionToken).buildAsync()
        
        onDispose {
            androidx.media3.session.MediaController.releaseFuture(controllerFuture)
            com.example.ui.PlayerHolder.player?.stop()
        }
    }

    var isPlaying by remember { mutableStateOf(exoPlayer.isPlaying) }
    var currentPosition by remember { mutableLongStateOf(0L) }
    var duration by remember { mutableLongStateOf(0L) }
    var showControls by remember { mutableStateOf(true) }

    DisposableEffect(exoPlayer) {
        val listener = object : androidx.media3.common.Player.Listener {
            override fun onIsPlayingChanged(isPlaying_: Boolean) {
                isPlaying = isPlaying_
            }
            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == androidx.media3.common.Player.STATE_READY) {
                    duration = exoPlayer.duration.coerceAtLeast(0L)
                }
            }
            override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                error.printStackTrace()
                android.widget.Toast.makeText(context, "Cannot stream this quality right now.", android.widget.Toast.LENGTH_SHORT).show()
            }
        }
        exoPlayer.addListener(listener)
        onDispose { exoPlayer.removeListener(listener) }
    }

    LaunchedEffect(isPlaying) {
        while (isPlaying) {
            currentPosition = exoPlayer.currentPosition.coerceAtLeast(0L)
            kotlinx.coroutines.delay(100)
        }
    }

    LaunchedEffect(currentPlaySpeed, exoPlayer) {
        try {
            exoPlayer.setPlaybackSpeed(currentPlaySpeed)
        } catch (e: Exception) {
            try {
                exoPlayer.playbackParameters = androidx.media3.common.PlaybackParameters(currentPlaySpeed)
            } catch (ex: Exception) {
                ex.printStackTrace()
            }
        }
    }

    LaunchedEffect(isLoopEnabled, exoPlayer) {
        exoPlayer.repeatMode = if (isLoopEnabled) {
            androidx.media3.common.Player.REPEAT_MODE_ONE
        } else {
            androidx.media3.common.Player.REPEAT_MODE_OFF
        }
    }

    LaunchedEffect(sleepTimerMinutes) {
        if (sleepTimerMinutes > 0) {
            val millis = sleepTimerMinutes * 60000L
            kotlinx.coroutines.delay(millis)
            if (exoPlayer.isPlaying) {
                exoPlayer.pause()
                android.widget.Toast.makeText(context, "Sleep timer finished. Playback paused.", android.widget.Toast.LENGTH_LONG).show()
            }
            sleepTimerMinutes = 0
        }
    }

    LaunchedEffect(showControls, isPlaying, isQualityMenuExpanded, showVideoDownloadSheet) {
        if (showControls && isPlaying && !isQualityMenuExpanded && !showVideoDownloadSheet) {
            kotlinx.coroutines.delay(3000)
            showControls = false
        }
    }

    var isMinimized by remember { mutableStateOf(false) }

    androidx.activity.compose.BackHandler(enabled = isVisible) {
        if (!isMinimized) {
            isMinimized = true
        } else {
            dismissWithAnimation()
        }
    }

    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.BottomEnd
    ) {
        androidx.compose.animation.AnimatedVisibility(
            visible = isVisible,
            enter = androidx.compose.animation.fadeIn() + androidx.compose.animation.slideInVertically(initialOffsetY = { it / 2 }),
            exit = androidx.compose.animation.fadeOut() + androidx.compose.animation.slideOutVertically(targetOffsetY = { it / 2 }),
            modifier = if (isMinimized) {
                Modifier
                    .padding(bottom = 90.dp, end = 16.dp)
                    .width(180.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .pointerInput(Unit) {
                        detectTapGestures(
                            onTap = { isMinimized = false }
                        )
                    }
            } else {
                Modifier.fillMaxSize()
            }
        ) {
            Surface(
                modifier = if (isMinimized) Modifier.aspectRatio(16f / 9f) else Modifier.fillMaxSize(),
                color = SleekBg
            ) {
                Column(modifier = Modifier.fillMaxSize()) {
                    var doubleTapIndicator by remember { mutableStateOf<String?>(null) }
                    var isScrubbing by remember { mutableStateOf(false) }
                    var scrubPosition by remember { mutableStateOf(0L) }

                    LaunchedEffect(doubleTapIndicator) {
                        if (doubleTapIndicator != null) {
                            kotlinx.coroutines.delay(600)
                            doubleTapIndicator = null
                        }
                    }

                    // 1. YouTube-style Video Player Area (STAYS STICKY ON TOP)
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .statusBarsPadding()
                            .aspectRatio(16f / 9f)
                            .background(Color.Black)
                            .pointerInput(Unit) {
                                detectTapGestures(
                                    onDoubleTap = { offset ->
                                        val width = size.width
                                        if (offset.x < width / 2) {
                                            val newPos = (exoPlayer.currentPosition - 10000).coerceAtLeast(0L)
                                            exoPlayer.seekTo(newPos)
                                            doubleTapIndicator = "rewind"
                                        } else {
                                            val newPos = (exoPlayer.currentPosition + 10000).coerceAtMost(exoPlayer.duration.coerceAtLeast(0L))
                                            exoPlayer.seekTo(newPos)
                                            doubleTapIndicator = "forward"
                                        }
                                    },
                                    onTap = { showControls = !showControls }
                                )
                            }
                            .pointerInput(Unit) {
                                detectHorizontalDragGestures(
                                    onDragStart = { _ ->
                                        isScrubbing = true
                                        scrubPosition = exoPlayer.currentPosition
                                        showControls = true
                                    },
                                    onDragEnd = {
                                        isScrubbing = false
                                        exoPlayer.seekTo(scrubPosition)
                                    },
                                    onDragCancel = {
                                        isScrubbing = false
                                    },
                                    onHorizontalDrag = { change, dragAmount ->
                                        change.consume()
                                        val dragFactor = 150L // 1 pixel drag = 150ms
                                        scrubPosition = (scrubPosition + (dragAmount * dragFactor.toFloat()).toLong()).coerceIn(0L, duration)
                                    }
                                )
                            }
                    ) {
                        // Video View Layer
                        androidx.compose.ui.viewinterop.AndroidView(
                            factory = { ctx ->
                                androidx.media3.ui.PlayerView(ctx).apply {
                                    player = exoPlayer
                                    useController = false
                                }
                            },
                            update = { view ->
                                view.resizeMode = playerResizeMode
                            },
                            modifier = Modifier.fillMaxSize()
                        )

                        if (isMinimized) {
                            IconButton(
                                onClick = { dismissWithAnimation() },
                                modifier = Modifier
                                    .align(Alignment.TopEnd)
                                    .padding(4.dp)
                                    .size(24.dp)
                                    .background(Color.Black.copy(alpha = 0.5f), CircleShape)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "Close",
                                    tint = Color.White,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }

                        // Real-time HDR & Visual Enhancement Render Layer
                        if (isHdrEnabled || colorEnhancementPreset != "None") {
                            Canvas(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .pointerInput(Unit) {}
                            ) {
                                val width = size.width
                                val height = size.height

                                // 1. HDR Mode Layer: Dynamically boosts highlights and deep contrast
                                if (isHdrEnabled) {
                                    drawRect(
                                        brush = Brush.radialGradient(
                                            colors = listOf(
                                                Color.White.copy(alpha = 0.35f),
                                                Color.Transparent,
                                                Color.Black.copy(alpha = 0.40f)
                                            ),
                                            center = androidx.compose.ui.geometry.Offset(width / 2f, height / 2f),
                                            radius = kotlin.math.max(width, height) * 0.75f
                                        ),
                                        blendMode = androidx.compose.ui.graphics.BlendMode.Overlay
                                    )
                                    // Gamut richness enhancement overlays
                                    drawRect(
                                        color = Color(0xFFFF4500).copy(alpha = 0.08f),
                                        blendMode = androidx.compose.ui.graphics.BlendMode.Color
                                    )
                                    drawRect(
                                        color = Color(0xFF1E90FF).copy(alpha = 0.05f),
                                        blendMode = androidx.compose.ui.graphics.BlendMode.Overlay
                                    )
                                }

                                // 2. Display Color Tuning presets
                                when (colorEnhancementPreset) {
                                    "Vibrant" -> {
                                        drawRect(
                                            brush = Brush.horizontalGradient(
                                                colors = listOf(
                                                    Color(0xFFFF007F).copy(alpha = 0.14f),
                                                    Color(0xFF00F5FF).copy(alpha = 0.14f)
                                                )
                                            ),
                                            blendMode = androidx.compose.ui.graphics.BlendMode.Color
                                        )
                                        drawRect(
                                            color = Color.White.copy(alpha = 0.10f),
                                            blendMode = androidx.compose.ui.graphics.BlendMode.Overlay
                                        )
                                    }
                                    "Cinematic Warm" -> {
                                        drawRect(
                                            color = Color(0xFFFFB300).copy(alpha = 0.22f),
                                            blendMode = androidx.compose.ui.graphics.BlendMode.Color
                                        )
                                        drawRect(
                                            color = Color(0xFFFF5722).copy(alpha = 0.08f),
                                            blendMode = androidx.compose.ui.graphics.BlendMode.Softlight
                                        )
                                    }
                                    "OLED Deep Black" -> {
                                        drawRect(
                                            brush = Brush.radialGradient(
                                                colors = listOf(
                                                    Color.Transparent,
                                                    Color.Black.copy(alpha = 0.55f)
                                                ),
                                                center = androidx.compose.ui.geometry.Offset(width / 2f, height / 2f),
                                                radius = kotlin.math.max(width, height) * 0.5f
                                            ),
                                            blendMode = androidx.compose.ui.graphics.BlendMode.Multiply
                                        )
                                        drawRect(
                                            color = Color.Black.copy(alpha = 0.12f),
                                            blendMode = androidx.compose.ui.graphics.BlendMode.Darken
                                        )
                                    }
                                    "Cool Breeze" -> {
                                        drawRect(
                                            color = Color(0xFF00E5FF).copy(alpha = 0.18f),
                                            blendMode = androidx.compose.ui.graphics.BlendMode.Color
                                        )
                                        drawRect(
                                            color = Color(0xFF1A237E).copy(alpha = 0.12f),
                                            blendMode = androidx.compose.ui.graphics.BlendMode.Softlight
                                        )
                                    }
                                }
                            }
                        }

                        // Double Tap overlay indicator
                        androidx.compose.animation.AnimatedVisibility(
                            visible = doubleTapIndicator != null,
                            enter = androidx.compose.animation.fadeIn(),
                            exit = androidx.compose.animation.fadeOut(),
                            modifier = Modifier.align(if (doubleTapIndicator == "rewind") Alignment.CenterStart else Alignment.CenterEnd)
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxHeight()
                                    .fillMaxWidth(0.4f)
                                    .background(
                                        Brush.horizontalGradient(
                                            if (doubleTapIndicator == "rewind") listOf(Color.White.copy(alpha=0.25f), Color.Transparent)
                                            else listOf(Color.Transparent, Color.White.copy(alpha=0.25f))
                                        ),
                                        shape = if (doubleTapIndicator == "rewind") RoundedCornerShape(topEnd = 150.dp, bottomEnd = 150.dp) else RoundedCornerShape(topStart = 150.dp, bottomStart = 150.dp)
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(
                                        imageVector = if (doubleTapIndicator == "rewind") Icons.Default.FastRewind else Icons.Default.FastForward,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(36.dp)
                                    )
                                    Spacer(Modifier.height(4.dp))
                                    Text(
                                        text = "10 seconds",
                                        color = Color.White,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }

                        // Scrubbing time popup
                        androidx.compose.animation.AnimatedVisibility(
                            visible = isScrubbing,
                            enter = androidx.compose.animation.fadeIn(),
                            exit = androidx.compose.animation.fadeOut(),
                            modifier = Modifier.align(Alignment.Center)
                        ) {
                            Box(
                                modifier = Modifier
                                    .background(Color.Black.copy(alpha = 0.6f), RoundedCornerShape(12.dp))
                                    .padding(horizontal = 24.dp, vertical = 12.dp)
                            ) {
                                val scrubMin = scrubPosition / 60000
                                val scrubSec = (scrubPosition % 60000) / 1000
                                Text(
                                    text = String.format(java.util.Locale.US, "%02d:%02d", scrubMin, scrubSec),
                                    color = Color.White,
                                    fontSize = 24.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }

                        // Inline Loading overlay for instant direct stream resolution
                        if (isStreamResolving) {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(Color.Black.copy(alpha = 0.85f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    CircularProgressIndicator(
                                        color = SleekPurpleLight,
                                        strokeWidth = 3.dp,
                                        modifier = Modifier.size(44.dp)
                                    )
                                    Text(
                                        text = "Resolving direct playback stream...",
                                        color = Color.White.copy(alpha = 0.9f),
                                        fontSize = 13.sp,
                                        fontStyle = androidx.compose.ui.text.font.FontStyle.Italic,
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                            }
                        }

                        // Overlay Action Controls
                        androidx.compose.animation.AnimatedVisibility(
                            visible = showControls && !isMinimized,
                            enter = androidx.compose.animation.fadeIn(),
                            exit = androidx.compose.animation.fadeOut(),
                            modifier = Modifier.fillMaxSize()
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(Color.Black.copy(alpha = 0.45f))
                            ) {
                                // Top Bar Header with ambient backdrop
                                Row(
                                    modifier = Modifier
                                        .align(Alignment.TopCenter)
                                        .fillMaxWidth()
                                        .background(Brush.verticalGradient(listOf(Color.Black.copy(alpha = 0.7f), Color.Transparent)))
                                        .padding(horizontal = 14.dp, vertical = 14.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    IconButton(
                                        onClick = { isMinimized = true },
                                        modifier = Modifier
                                            .size(38.dp)
                                            .background(Color.Black.copy(alpha = 0.5f), CircleShape)
                                            .border(1.dp, Color.White.copy(alpha = 0.15f), CircleShape)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.KeyboardArrowDown,
                                            contentDescription = "Minimize Player",
                                            tint = Color.White,
                                            modifier = Modifier.size(22.dp)
                                        )
                                    }

                                    Text(
                                        text = videoDetails?.title ?: download.title,
                                        color = Color.White,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        modifier = Modifier
                                            .weight(1f)
                                            .padding(horizontal = 12.dp)
                                    )

                                    // Real-time Video Player Settings Gear (Always available)
                                    Box(contentAlignment = Alignment.TopEnd) {
                                            IconButton(
                                                onClick = { isQualityMenuExpanded = !isQualityMenuExpanded },
                                                modifier = Modifier
                                                    .size(38.dp)
                                                    .background(Color.Black.copy(alpha = 0.5f), CircleShape)
                                                    .border(1.dp, Color.White.copy(alpha = 0.15f), CircleShape)
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.Settings,
                                                    contentDescription = "Quality Options",
                                                    tint = Color.White,
                                                    modifier = Modifier.size(18.dp)
                                                )
                                                        if (isQualityMenuExpanded) {
                                                val sheetState = androidx.compose.material3.rememberModalBottomSheetState(skipPartiallyExpanded = false)
                                                androidx.compose.material3.ModalBottomSheet(
                                                    onDismissRequest = { isQualityMenuExpanded = false },
                                                    sheetState = sheetState,
                                                    containerColor = SleekCardDark,
                                                    dragHandle = { androidx.compose.material3.BottomSheetDefaults.DragHandle(color = SleekTextSecondary) }
                                                ) {
                                                    Column(
                                                        modifier = Modifier
                                                            .fillMaxWidth()
                                                            .padding(horizontal = 16.dp)
                                                            .padding(bottom = 32.dp),
                                                        verticalArrangement = Arrangement.spacedBy(16.dp)
                                                    ) {
                                                        Text(
                                                            text = "PLAYER SETTINGS",
                                                            style = MaterialTheme.typography.titleMedium.copy(
                                                                fontWeight = FontWeight.Bold,
                                                                color = SleekPurpleDark,
                                                                letterSpacing = 1.sp
                                                            ),
                                                            modifier = Modifier.padding(horizontal = 10.dp)
                                                        )

                                                        Column(
                                                            modifier = Modifier.verticalScroll(rememberScrollState()),
                                                            verticalArrangement = Arrangement.spacedBy(8.dp)
                                                        ) {
                                                            // 1. Playback Speed Selector
                                                            Text(
                                                                text = "PLAYBACK SPEED",
                                                                fontWeight = FontWeight.ExtraBold,
                                                                color = SleekPurpleLight,
                                                                fontSize = 11.sp,
                                                                letterSpacing = 0.5.sp,
                                                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                                            )
                                                            Row(
                                                                modifier = Modifier
                                                                    .fillMaxWidth()
                                                                    .padding(horizontal = 10.dp, vertical = 4.dp),
                                                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                                                            ) {
                                                                val speeds = listOf(0.5f, 1.0f, 1.25f, 1.5f, 2.0f)
                                                                speeds.forEach { speed ->
                                                                    val isSelected = currentPlaySpeed == speed
                                                                    Box(
                                                                        modifier = Modifier
                                                                            .weight(1f)
                                                                            .clip(RoundedCornerShape(12.dp))
                                                                            .background(if (isSelected) SleekPurpleLight else SleekCard)
                                                                            .border(1.dp, if (isSelected) Color.Transparent else SleekBorderColor.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                                                                            .clickable { currentPlaySpeed = speed }
                                                                            .padding(vertical = 10.dp),
                                                                        contentAlignment = Alignment.Center
                                                                    ) {
                                                                        Text(
                                                                            text = "${speed}x",
                                                                            fontSize = 12.sp,
                                                                            fontWeight = if (isSelected) FontWeight.ExtraBold else FontWeight.Medium,
                                                                            color = if (isSelected) Color.Black else SleekTextPrimary
                                                                        )
                                                                    }
                                                                }
                                                            }

                                                            Box(modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp).height(0.5.dp).background(SleekBorderColor.copy(alpha = 0.4f)))

                                                            // 2. Fit/Fill/Zoom Resising Frame Mode Selector
                                                            Text(
                                                                text = "ASPECT RATIO",
                                                                fontWeight = FontWeight.ExtraBold,
                                                                color = SleekPurpleLight,
                                                                fontSize = 11.sp,
                                                                letterSpacing = 0.5.sp,
                                                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                                            )
                                                            Row(
                                                                modifier = Modifier
                                                                    .fillMaxWidth()
                                                                    .padding(horizontal = 10.dp, vertical = 4.dp),
                                                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                                                            ) {
                                                                val aspectModes = listOf(
                                                                    0 to "Fit",
                                                                    3 to "Fill",
                                                                    4 to "Zoom"
                                                                )
                                                                aspectModes.forEach { (mode, label) ->
                                                                    val isSelected = playerResizeMode == mode
                                                                    Box(
                                                                        modifier = Modifier
                                                                            .weight(1f)
                                                                            .clip(RoundedCornerShape(12.dp))
                                                                            .background(if (isSelected) SleekPurpleLight else SleekCard)
                                                                            .border(1.dp, if (isSelected) Color.Transparent else SleekBorderColor.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                                                                            .clickable { playerResizeMode = mode }
                                                                            .padding(vertical = 10.dp),
                                                                        contentAlignment = Alignment.Center
                                                                    ) {
                                                                        Text(
                                                                            text = label,
                                                                            fontSize = 12.sp,
                                                                            fontWeight = if (isSelected) FontWeight.ExtraBold else FontWeight.Medium,
                                                                            color = if (isSelected) Color.Black else SleekTextPrimary
                                                                        )
                                                                    }
                                                                }
                                                            }

                                                            Box(modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp).height(0.5.dp).background(SleekBorderColor.copy(alpha = 0.4f)))

                                                            // 3. Adaptive Quality Stream Selection
                                                            Text(
                                                                text = "VIDEO QUALITY",
                                                                fontWeight = FontWeight.ExtraBold,
                                                                color = SleekPurpleLight,
                                                                fontSize = 11.sp,
                                                                letterSpacing = 0.5.sp,
                                                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                                            )
                                                            // Split qualities into two rows for better fit
                                                            val qualityModes = listOf("Auto", "1080p", "720p", "480p", "360p", "240p", "144p")
                                                            Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 4.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                                                    qualityModes.take(4).forEach { mode ->
                                                                        val isSelected = currentQualityMode == mode
                                                                        Box(
                                                                            modifier = Modifier
                                                                                .weight(1f)
                                                                                .clip(RoundedCornerShape(12.dp))
                                                                                .background(if (isSelected) SleekPurpleLight else SleekCard)
                                                                                .border(1.dp, if (isSelected) Color.Transparent else SleekBorderColor.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                                                                                .clickable { currentQualityMode = mode }
                                                                                .padding(vertical = 10.dp),
                                                                            contentAlignment = Alignment.Center
                                                                        ) {
                                                                            Text(
                                                                                text = mode,
                                                                                fontSize = 12.sp,
                                                                                fontWeight = if (isSelected) FontWeight.ExtraBold else FontWeight.Medium,
                                                                                color = if (isSelected) Color.Black else SleekTextPrimary
                                                                            )
                                                                        }
                                                                    }
                                                                }
                                                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                                                    qualityModes.drop(4).forEach { mode ->
                                                                        val isSelected = currentQualityMode == mode
                                                                        Box(
                                                                            modifier = Modifier
                                                                                .weight(1f)
                                                                                .clip(RoundedCornerShape(12.dp))
                                                                                .background(if (isSelected) SleekPurpleLight else SleekCard)
                                                                                .border(1.dp, if (isSelected) Color.Transparent else SleekBorderColor.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                                                                                .clickable { currentQualityMode = mode }
                                                                                .padding(vertical = 10.dp),
                                                                            contentAlignment = Alignment.Center
                                                                        ) {
                                                                            Text(
                                                                                text = mode,
                                                                                fontSize = 12.sp,
                                                                                fontWeight = if (isSelected) FontWeight.ExtraBold else FontWeight.Medium,
                                                                                color = if (isSelected) Color.Black else SleekTextPrimary
                                                                            )
                                                                        }
                                                                    }
                                                                    // Add a dummy box to balance the second row
                                                                    Box(modifier = Modifier.weight(1f))
                                                                }
                                                            }

                                                            Box(modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp).height(0.5.dp).background(SleekBorderColor.copy(alpha = 0.4f)))

                                                            // 4. Repeat & Sleep Timer Quick Actions Row
                                                            Text(
                                                                text = "CONTROLS & SLEEP TIMERS",
                                                                fontWeight = FontWeight.ExtraBold,
                                                                color = SleekPurpleLight,
                                                                fontSize = 11.sp,
                                                                letterSpacing = 0.5.sp,
                                                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                                            )
                                                            Row(
                                                                modifier = Modifier
                                                                    .fillMaxWidth()
                                                                    .padding(horizontal = 10.dp, vertical = 4.dp),
                                                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                                                verticalAlignment = Alignment.CenterVertically
                                                            ) {
                                                                // Loop modes toggle
                                                                Box(
                                                                    modifier = Modifier
                                                                        .weight(1.1f)
                                                                        .clip(RoundedCornerShape(12.dp))
                                                                        .background(if (isLoopEnabled) SleekPurpleLight.copy(alpha = 0.15f) else SleekCard)
                                                                        .border(1.dp, if (isLoopEnabled) SleekPurpleLight else SleekBorderColor.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                                                                        .clickable { isLoopEnabled = !isLoopEnabled }
                                                                        .padding(vertical = 12.dp),
                                                                    contentAlignment = Alignment.Center
                                                                ) {
                                                                    Row(
                                                                        verticalAlignment = Alignment.CenterVertically,
                                                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                                                    ) {
                                                                        Icon(
                                                                            imageVector = Icons.Default.Refresh,
                                                                            contentDescription = "Loop",
                                                                            tint = if (isLoopEnabled) SleekPurpleLight else SleekTextPrimary,
                                                                            modifier = Modifier.size(16.dp)
                                                                        )
                                                                        Text(
                                                                            text = if (isLoopEnabled) "Loop: On" else "Loop: Off",
                                                                            fontSize = 12.sp,
                                                                            fontWeight = FontWeight.Bold,
                                                                            color = if (isLoopEnabled) SleekPurpleLight else SleekTextPrimary
                                                                        )
                                                                    }
                                                                }

                                                                // Sleep Timer toggle
                                                                Box(
                                                                    modifier = Modifier
                                                                        .weight(1.3f)
                                                                        .clip(RoundedCornerShape(12.dp))
                                                                        .background(if (sleepTimerMinutes > 0) SleekPurpleLight.copy(alpha = 0.15f) else SleekCard)
                                                                        .border(1.dp, if (sleepTimerMinutes > 0) SleekPurpleLight else SleekBorderColor.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                                                                        .clickable {
                                                                            sleepTimerMinutes = when (sleepTimerMinutes) {
                                                                                0 -> 10
                                                                                10 -> 30
                                                                                30 -> 60
                                                                                else -> 0
                                                                            }
                                                                            val msg = if (sleepTimerMinutes > 0) "Sleep timer set for $sleepTimerMinutes min" else "Sleep timer disabled"
                                                                            android.widget.Toast.makeText(context, msg, android.widget.Toast.LENGTH_SHORT).show()
                                                                        }
                                                                        .padding(vertical = 12.dp),
                                                                    contentAlignment = Alignment.Center
                                                                ) {
                                                                    Row(
                                                                        verticalAlignment = Alignment.CenterVertically,
                                                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                                                    ) {
                                                                        Icon(
                                                                            imageVector = Icons.Default.Settings,
                                                                            contentDescription = "Sleep",
                                                                            tint = if (sleepTimerMinutes > 0) SleekPurpleLight else SleekTextPrimary,
                                                                            modifier = Modifier.size(16.dp)
                                                                        )
                                                                        Text(
                                                                            text = if (sleepTimerMinutes > 0) "Off in ${sleepTimerMinutes}m" else "Sleep Timer",
                                                                            fontSize = 12.sp,
                                                                            fontWeight = FontWeight.Bold,
                                                                            color = if (sleepTimerMinutes > 0) SleekPurpleLight else SleekTextPrimary
                                                                        )
                                                                    }
                                                                }
                                                            }

                                                            // AUDIO ENHANCEMENTS
                                                            Text(
                                                                text = "AUDIO ENHANCEMENTS",
                                                                fontWeight = FontWeight.ExtraBold,
                                                                color = SleekPurpleLight,
                                                                fontSize = 11.sp,
                                                                letterSpacing = 0.5.sp,
                                                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp).padding(top = 8.dp)
                                                            )
                                                            Row(
                                                                modifier = Modifier
                                                                    .fillMaxWidth()
                                                                    .padding(horizontal = 10.dp, vertical = 4.dp),
                                                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                                                verticalAlignment = Alignment.CenterVertically
                                                            ) {
                                                                // Volume Booster toggle
                                                                Box(
                                                                    modifier = Modifier
                                                                        .weight(1f)
                                                                        .clip(RoundedCornerShape(12.dp))
                                                                        .background(if (isBoosted) SleekPurpleLight.copy(alpha = 0.15f) else SleekCard)
                                                                        .border(1.dp, if (isBoosted) SleekPurpleLight else SleekBorderColor.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                                                                        .clickable {
                                                                            isBoosted = !isBoosted
                                                                            loudnessEnhancer.enabled = isBoosted
                                                                        }
                                                                        .padding(vertical = 12.dp),
                                                                    contentAlignment = Alignment.Center
                                                                ) {
                                                                    Row(
                                                                        verticalAlignment = Alignment.CenterVertically,
                                                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                                                    ) {
                                                                        Icon(
                                                                            imageVector = Icons.Default.VolumeUp,
                                                                            contentDescription = "Volume Boost",
                                                                            tint = if (isBoosted) SleekPurpleLight else SleekTextPrimary,
                                                                            modifier = Modifier.size(16.dp)
                                                                        )
                                                                        Text(
                                                                            text = if (isBoosted) "Volume Boost: On" else "Volume Boost: Off",
                                                                            fontSize = 12.sp,
                                                                            fontWeight = FontWeight.Bold,
                                                                            color = if (isBoosted) SleekPurpleLight else SleekTextPrimary
                                                                        )
                                                                    }
                                                                }
                                                            }

                                                            // 4. Quality selector (Stream feeds only)
                                                            if (download.localPath.startsWith("http://") || download.localPath.startsWith("https://")) {
                                                                Box(modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp).height(0.5.dp).background(SleekBorderColor.copy(alpha = 0.4f)))

                                                                Text(
                                                                    text = "STREAM QUALITY",
                                                                    fontWeight = FontWeight.ExtraBold,
                                                                    color = SleekPurpleLight,
                                                                    fontSize = 11.sp,
                                                                    letterSpacing = 0.5.sp,
                                                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                                                )
                                                                
                                                                Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp)) {
                                                                    if (isLoadingFormats) {
                                                                        Text("Loading formats...", color = SleekTextPrimary, fontSize = 12.sp, modifier = Modifier.padding(8.dp))
                                                                    } else if (streamFormats.isEmpty()) {
                                                                        Text("Fetching qualities...", color = SleekTextSecondary, fontSize = 12.sp, modifier = Modifier.padding(8.dp))
                                                                    } else {
                                                                        streamFormats.forEach { format ->
                                                                            val isSelected = currentFormat?.downloadUrl == format.downloadUrl || (currentFormat == null && format.downloadUrl == download.localPath)
                                                                            Row(
                                                                                modifier = Modifier
                                                                                    .fillMaxWidth()
                                                                                    .clip(RoundedCornerShape(8.dp))
                                                                                    .clickable {
                                                                                        isQualityMenuExpanded = false
                                                                                        selectFormat(format)
                                                                                    }
                                                                                    .padding(12.dp),
                                                                                verticalAlignment = Alignment.CenterVertically,
                                                                                horizontalArrangement = Arrangement.spacedBy(16.dp)
                                                                            ) {
                                                                                if (isSelected) {
                                                                                    Icon(
                                                                                        imageVector = Icons.Default.Check,
                                                                                        contentDescription = "Selected",
                                                                                        tint = SleekPurpleLight,
                                                                                        modifier = Modifier.size(20.dp)
                                                                                    )
                                                                                } else {
                                                                                    Spacer(modifier = Modifier.size(20.dp))
                                                                                }
                                                                                Column {
                                                                                    Text(
                                                                                        text = "${format.quality} (${format.ext})",
                                                                                        color = if (isSelected) SleekPurpleLight else SleekTextPrimary,
                                                                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                                                                        fontSize = 14.sp
                                                                                    )
                                                                                    if (format.sizeText.isNotBlank()) {
                                                                                        Text(
                                                                                            text = format.sizeText,
                                                                                            color = SleekTextMuted,
                                                                                            fontSize = 11.sp
                                                                                        )
                                                                                    }
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }                                  }
                                        }
                                }

                                // Center Play/Pause Indicator with animated modern pulse glow
                                val pulseTransition = rememberInfiniteTransition(label = "player_pulse")
                                val pulseScale by pulseTransition.animateFloat(
                                    initialValue = 1.0f,
                                    targetValue = 1.08f,
                                    animationSpec = infiniteRepeatable(
                                        animation = tween(1200, easing = FastOutSlowInEasing),
                                        repeatMode = RepeatMode.Reverse
                                    ),
                                    label = "play_pulse_scale"
                                )
                                val pulseAlpha by pulseTransition.animateFloat(
                                    initialValue = 0.25f,
                                    targetValue = 0.55f,
                                    animationSpec = infiniteRepeatable(
                                        animation = tween(1200, easing = FastOutSlowInEasing),
                                        repeatMode = RepeatMode.Reverse
                                    ),
                                    label = "play_pulse_alpha"
                                )

                                Box(
                                    modifier = Modifier
                                        .align(Alignment.Center)
                                        .graphicsLayer {
                                            scaleX = pulseScale
                                            scaleY = pulseScale
                                        }
                                        .size(64.dp)
                                        .background(Color.Black.copy(alpha = 0.55f), CircleShape)
                                        .border(BorderStroke(1.2.dp, Brush.linearGradient(
                                            colors = listOf(Color.White.copy(alpha = pulseAlpha), Color.White.copy(alpha = 0.08f))
                                        )), CircleShape)
                                        .clickable {
                                            if (isPlaying) exoPlayer.pause() else exoPlayer.play()
                                        },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                        contentDescription = "Play/Pause Toggle",
                                        tint = Color.White,
                                        modifier = Modifier.size(36.dp)
                                    )
                                }

                                // Bottom Slider & Time Controllers
                                Column(
                                    modifier = Modifier
                                        .align(Alignment.BottomCenter)
                                        .fillMaxWidth()
                                        .background(
                                            Brush.verticalGradient(
                                                colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.85f))
                                            )
                                        )
                                        .padding(horizontal = 14.dp, vertical = 10.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        val displayPosition = if (isScrubbing) scrubPosition else currentPosition
                                        val elapsedMin = displayPosition / 60000
                                        val elapsedSec = (displayPosition % 60000) / 1000
                                        Text(
                                            text = String.format(java.util.Locale.US, "%02d:%02d", elapsedMin, elapsedSec),
                                            color = Color.White,
                                            fontSize = 11.sp,
                                            fontFamily = FontFamily.Monospace
                                        )

                                        PremiumSeekBar(
                                            value = if (duration > 0) displayPosition.toFloat() else 0f,
                                            onValueChange = { currentPosition = it.toLong(); exoPlayer.seekTo(currentPosition) },
                                            valueRange = 0f..(if (duration > 0) duration.toFloat() else 1f),
                                            modifier = Modifier
                                                .weight(1f)
                                                .padding(horizontal = 10.dp),
                                            activeColor = SleekPurpleLight,
                                            inactiveColor = Color.White.copy(alpha = 0.22f)
                                        )

                                        val durMin = duration / 60000
                                        val durSec = (duration % 60000) / 1000
                                        Text(
                                            text = String.format(java.util.Locale.US, "%02d:%02d", durMin, durSec),
                                            color = Color.White.copy(alpha = 0.8f),
                                            fontSize = 11.sp,
                                            fontFamily = FontFamily.Monospace
                                        )
                                    }
                                }
                            }
                        }
                    }

                    if (!isMinimized) {
                        // 2. Independently Scrollable Body Info Pages & Custom Lists (Just like YouTube mobile)
                        LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    contentPadding = PaddingValues(top = 12.dp, bottom = 24.dp)
                ) {
                    if (isLoadingDetails) {
                        // Skeleton shimmers for details loading
                        item {
                            Column(
                                modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Box(modifier = Modifier.width(280.dp).height(20.dp).background(animatedSkeletonColor, RoundedCornerShape(4.dp)))
                                Box(modifier = Modifier.width(160.dp).height(12.dp).background(animatedSkeletonColor, RoundedCornerShape(4.dp)))
                                Box(modifier = Modifier.fillMaxWidth().height(48.dp).background(animatedSkeletonColor, RoundedCornerShape(8.dp)))
                            }
                        }
                    } else {
                        // Dynamic detailed information from YouTube Data API
                        val details = videoDetails
                        
                        item {
                            Column(
                                modifier = Modifier.fillMaxWidth(),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                // Title
                                Text(
                                    text = details?.title ?: download.title,
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = SleekTextPrimary,
                                    lineHeight = 24.sp
                                )

                                // View Count & Publish Info
                                Text(
                                    text = "${details?.viewCountText ?: "85K views"} • ${details?.publishDateText ?: "2 weeks ago"}",
                                    color = SleekTextMuted,
                                    fontSize = 12.sp
                                )
                            }
                        }

                        // YouTube Action Drawer Row (Likes, Dislikes, Share, boost, extract)
                        item {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .horizontalScroll(rememberScrollState())
                                    .padding(vertical = 12.dp),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                // Like / Dislike Combined Pill (Modern Glass Gradient Look)
                                Row(
                                    modifier = Modifier
                                        .background(
                                            Brush.linearGradient(
                                                colors = listOf(SleekCard, SleekCardDark)
                                            ), 
                                            RoundedCornerShape(50)
                                        )
                                        .border(1.dp, SleekBorderColor.copy(alpha = 0.6f), RoundedCornerShape(50)),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(topStartPercent = 50, bottomStartPercent = 50))
                                            .background(if (likedState == 1) Color.White else Color.Transparent)
                                            .clickable { likedState = if (likedState == 1) 0 else 1 }
                                            .padding(horizontal = 14.dp, vertical = 8.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.ThumbUp,
                                            contentDescription = "Like",
                                            tint = if (likedState == 1) Color.Black else SleekTextPrimary,
                                            modifier = Modifier.size(15.dp)
                                        )
                                        Text(
                                            text = details?.likeCountText ?: "Like",
                                            color = if (likedState == 1) Color.Black else SleekTextPrimary,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }

                                    Box(modifier = Modifier.width(1.dp).height(18.dp).background(SleekBorderColor.copy(alpha = 0.6f)))

                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(topEndPercent = 50, bottomEndPercent = 50))
                                            .background(if (likedState == 2) Color.White else Color.Transparent)
                                            .clickable { likedState = if (likedState == 2) 0 else 2 }
                                            .padding(horizontal = 14.dp, vertical = 8.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.ThumbDown,
                                            contentDescription = "Dislike",
                                            tint = if (likedState == 2) Color.Black else SleekTextPrimary,
                                            modifier = Modifier.size(15.dp)
                                        )
                                    }
                                }

                                // Share Pill
                                Row(
                                    modifier = Modifier
                                        .background(
                                            Brush.linearGradient(
                                                colors = listOf(SleekCard, SleekCardDark)
                                            ), 
                                            RoundedCornerShape(50)
                                        )
                                        .border(1.dp, SleekBorderColor.copy(alpha = 0.6f), RoundedCornerShape(50))
                                        .clickable {
                                            val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                                                type = "text/plain"
                                                putExtra(android.content.Intent.EXTRA_TEXT, "Watch this on OctaStream: " + download.localPath)
                                            }
                                            context.startActivity(android.content.Intent.createChooser(intent, "Share video link"))
                                        }
                                        .padding(horizontal = 14.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Share,
                                        contentDescription = "Share Link",
                                        tint = SleekTextPrimary,
                                        modifier = Modifier.size(15.dp)
                                    )
                                    Text("SHARE", color = SleekTextPrimary, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }

                                // Download format pill
                                Row(
                                    modifier = Modifier
                                        .background(
                                            Brush.linearGradient(
                                                colors = listOf(SleekCard, SleekCardDark)
                                            ), 
                                            RoundedCornerShape(50)
                                        )
                                        .border(1.dp, SleekBorderColor.copy(alpha = 0.6f), RoundedCornerShape(50))
                                        .clickable {
                                            if (analyzedVideoResult != null) {
                                                showVideoDownloadSheet = true
                                            } else {
                                                android.widget.Toast.makeText(context, "Formats are still loading...", android.widget.Toast.LENGTH_SHORT).show()
                                            }
                                        }
                                        .padding(horizontal = 14.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.ArrowDownward,
                                        contentDescription = "Download formats",
                                        tint = SleekTextPrimary,
                                        modifier = Modifier.size(15.dp)
                                    )
                                    Text("DOWNLOAD", color = SleekTextPrimary, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }

                        // Creator Channel Area (Avatar, Subscribers, RED SUBSCRIBE button)
                        item {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(40.dp)
                                            .background(
                                                Brush.radialGradient(
                                                    colors = listOf(Color(0xFF262626), Color(0xFF0F0F0F))
                                                ),
                                                shape = CircleShape
                                            )
                                            .border(1.dp, SleekBorderColor, CircleShape),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = (details?.ownerChannelName ?: download.author).take(1).uppercase(),
                                            color = SleekTextPrimary,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 14.sp
                                        )
                                    }

                                    Column {
                                        Text(
                                            text = details?.ownerChannelName ?: download.author,
                                            fontWeight = FontWeight.Bold,
                                            color = SleekTextPrimary,
                                            fontSize = 14.sp
                                        )
                                        Text(
                                            text = details?.subscriberCountText ?: "1.24M subscribers",
                                            color = SleekTextMuted,
                                            fontSize = 11.sp
                                        )
                                    }
                                }

                                // Interactive SUBSCRIBE toggle button (Luxurious high-contrast White vs Card)
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(50))
                                        .background(if (isSubscribed) SleekCard else Color.White)
                                        .clickable { isSubscribed = !isSubscribed }
                                        .border(1.dp, if (isSubscribed) SleekBorderColor.copy(alpha = 0.6f) else Color.Transparent, RoundedCornerShape(50))
                                        .padding(horizontal = 16.dp, vertical = 8.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = if (isSubscribed) "SUBSCRIBED" else "SUBSCRIBE",
                                        color = if (isSubscribed) SleekTextPrimary else Color.Black,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        letterSpacing = 0.5.sp
                                    )
                                }
                            }
                        }

                        // HDR & Dynamic Visual Color Enhancements Pane
                        item {
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 8.dp)
                                    .border(1.dp, SleekBorderColor.copy(alpha = 0.6f), RoundedCornerShape(16.dp)),
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = SleekCard)
                            ) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(14.dp),
                                    verticalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    // Header Option Titles
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(
                                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Tune,
                                                contentDescription = "Enhancements",
                                                tint = SleekPurpleLight,
                                                modifier = Modifier.size(18.dp)
                                            )
                                            Text(
                                                text = "Display & Visual Enhancements",
                                                fontSize = 13.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = SleekTextPrimary
                                            )
                                        }

                                        // Quick HDR Toggle Button
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(50))
                                                .background(if (isHdrEnabled) SleekPurpleLight.copy(alpha = 0.15f) else Color.Transparent)
                                                .border(1.dp, if (isHdrEnabled) SleekPurpleLight else SleekBorderColor.copy(alpha = 0.5f), RoundedCornerShape(50))
                                                .clickable { isHdrEnabled = !isHdrEnabled }
                                                .padding(horizontal = 10.dp, vertical = 4.dp)
                                        ) {
                                            Box(
                                                modifier = Modifier
                                                    .size(6.dp)
                                                    .background(if (isHdrEnabled) SleekPurpleLight else SleekTextMuted, CircleShape)
                                            )
                                            Text(
                                                text = "HDR BOOST",
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.ExtraBold,
                                                color = if (isHdrEnabled) SleekPurpleLight else SleekTextPrimary,
                                                letterSpacing = 0.5.sp
                                            )
                                        }
                                    }

                                    Text(
                                        text = "Calibrate real-time color range, highlight tone luminance, and display output grade preset below.",
                                        fontSize = 11.sp,
                                        color = SleekTextSecondary,
                                        lineHeight = 15.sp
                                    )

                                    // Horizontally Scrollable Enhancement Presets list
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .horizontalScroll(rememberScrollState()),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        val presets = listOf(
                                            "None" to "Original",
                                            "Vibrant" to "Vibrant Display",
                                            "Cinematic Warm" to "Cinema Gold",
                                            "OLED Deep Black" to "OLED Contrast",
                                            "Cool Breeze" to "Cold Neon"
                                        )

                                        presets.forEach { (presetKey, presetLabel) ->
                                            val isSelected = colorEnhancementPreset == presetKey
                                            Box(
                                                modifier = Modifier
                                                    .clip(RoundedCornerShape(8.dp))
                                                    .background(if (isSelected) Color.White else SleekCardDark)
                                                    .border(1.dp, if (isSelected) Color.Transparent else SleekBorderColor.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                                                    .clickable { colorEnhancementPreset = presetKey }
                                                    .padding(horizontal = 12.dp, vertical = 8.dp)
                                            ) {
                                                Text(
                                                    text = presetLabel,
                                                    fontSize = 11.sp,
                                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                                    color = if (isSelected) Color.Black else SleekTextPrimary
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        // Expandable Description Box
                        item {
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 8.dp)
                                    .border(1.dp, SleekBorderColor.copy(alpha = 0.6f), RoundedCornerShape(16.dp))
                                    .clickable { isDescriptionExpanded = !isDescriptionExpanded },
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = SleekCard)
                            ) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(14.dp),
                                    verticalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "Description",
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = SleekTextPrimary
                                        )
                                        Icon(
                                            imageVector = if (isDescriptionExpanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                                            contentDescription = "Expand description",
                                            tint = SleekTextSecondary,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }

                                    Text(
                                        text = details?.description ?: "No description provided.",
                                        fontSize = 12.sp,
                                        color = SleekTextSecondary,
                                        maxLines = if (isDescriptionExpanded) 50 else 2,
                                        overflow = TextOverflow.Ellipsis,
                                        lineHeight = 17.sp
                                    )
                                }
                            }
                        }

                        // Dynamic Collapsible Comments Section with API trigger data mapping!
                        item {
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 6.dp)
                                    .border(1.dp, SleekBorderColor.copy(alpha = 0.6f), RoundedCornerShape(16.dp))
                                    .clickable { isCommentsExpanded = !isCommentsExpanded },
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = SleekCard)
                            ) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(14.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(
                                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = "Comments",
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = SleekTextPrimary
                                            )
                                            Box(
                                                modifier = Modifier
                                                    .background(SleekPurpleLight.copy(alpha = 0.15f), RoundedCornerShape(4.dp))
                                                    .padding(horizontal = 6.dp, vertical = 1.dp)
                                            ) {
                                                Text(
                                                    text = details?.commentCountText ?: "12",
                                                    fontSize = 10.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = SleekTextSecondary
                                                )
                                            }
                                        }

                                        Icon(
                                            imageVector = if (isCommentsExpanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                                            contentDescription = "Expand comments list",
                                            tint = SleekTextSecondary,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }

                                    val topComment = videoComments.firstOrNull()
                                    if (topComment != null && !isCommentsExpanded) {
                                        // Quick inline comment snippet
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Box(
                                                modifier = Modifier
                                                    .size(24.dp)
                                                    .background(SleekPurpleLight.copy(alpha = 0.1f), CircleShape)
                                                    .border(0.5.dp, SleekBorderColor, CircleShape),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Text(
                                                    text = topComment.authorName.take(2).uppercase().replace("@", ""),
                                                    color = SleekTextSecondary,
                                                    fontSize = 8.sp,
                                                    fontWeight = FontWeight.Bold
                                                )
                                            }
                                            Text(
                                                text = topComment.text,
                                                fontSize = 11.sp,
                                                color = SleekTextSecondary,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis,
                                                modifier = Modifier.weight(1f)
                                            )
                                        }
                                    }

                                    // Fully expanded comment row listings
                                    androidx.compose.animation.AnimatedVisibility(
                                        visible = isCommentsExpanded,
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Column(
                                            modifier = Modifier.fillMaxWidth(),
                                            verticalArrangement = Arrangement.spacedBy(10.dp)
                                        ) {
                                            HorizontalDivider(color = SleekBorderColor.copy(alpha = 0.5f), modifier = Modifier.padding(vertical = 4.dp))
                                            
                                            if (videoComments.isEmpty()) {
                                                Text(
                                                    text = "No comments found under this thread.",
                                                    color = SleekTextMuted,
                                                    fontSize = 11.sp,
                                                    modifier = Modifier.padding(vertical = 4.dp)
                                                )
                                            } else {
                                                videoComments.forEach { comment ->
                                                    Row(
                                                        modifier = Modifier.fillMaxWidth(),
                                                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                                                        verticalAlignment = Alignment.Top
                                                    ) {
                                                        Box(
                                                            modifier = Modifier
                                                                .size(28.dp)
                                                                .background(SleekPurpleLight.copy(alpha = 0.15f), CircleShape)
                                                                .border(0.5.dp, SleekBorderColor, CircleShape),
                                                            contentAlignment = Alignment.Center
                                                        ) {
                                                            Text(
                                                                text = comment.authorName.take(2).uppercase().replace("@", ""),
                                                                color = SleekTextSecondary,
                                                                fontSize = 9.sp,
                                                                fontWeight = FontWeight.Bold
                                                            )
                                                        }

                                                        Column(
                                                            modifier = Modifier.weight(1f),
                                                            verticalArrangement = Arrangement.spacedBy(2.dp)
                                                        ) {
                                                            Row(
                                                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                                                verticalAlignment = Alignment.CenterVertically
                                                            ) {
                                                                Text(
                                                                    text = comment.authorName,
                                                                    fontWeight = FontWeight.Bold,
                                                                    color = SleekTextPrimary,
                                                                    fontSize = 11.sp
                                                                )
                                                                Text(
                                                                    text = comment.timeText,
                                                                    color = SleekTextMuted,
                                                                    fontSize = 9.sp
                                                                )
                                                            }

                                                            Text(
                                                                text = comment.text,
                                                                fontSize = 11.sp,
                                                                color = SleekTextSecondary,
                                                                lineHeight = 14.sp
                                                            )

                                                            Row(
                                                                horizontalArrangement = Arrangement.spacedBy(4.dp),
                                                                verticalAlignment = Alignment.CenterVertically,
                                                                modifier = Modifier.padding(top = 2.dp)
                                                            ) {
                                                                Icon(
                                                                    imageVector = Icons.Default.ThumbUp,
                                                                    contentDescription = "Likes",
                                                                    tint = SleekTextMuted,
                                                                    modifier = Modifier.size(10.dp)
                                                                )
                                                                Text(
                                                                    text = comment.likes.toString(),
                                                                    color = SleekTextMuted,
                                                                    fontSize = 9.sp
                                                                )
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        // Up Next Segment recommendations header
                        item {
                            Text(
                                text = "Up Next Recommended Content",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = SleekTextPrimary,
                                modifier = Modifier.padding(top = 14.dp, bottom = 8.dp)
                            )
                        }

                        if (relatedVideos.isEmpty()) {
                            item {
                                Text(
                                    text = "Finding related video stream feeds...",
                                    color = SleekTextSecondary,
                                    fontSize = 11.sp,
                                    fontStyle = androidx.compose.ui.text.font.FontStyle.Italic,
                                    modifier = Modifier.padding(vertical = 4.dp, horizontal = 4.dp)
                                )
                            }
                            items(3) {
                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 6.dp)
                                        .border(1.dp, SleekBorderColor, RoundedCornerShape(12.dp)),
                                    shape = RoundedCornerShape(12.dp),
                                    colors = CardDefaults.cardColors(containerColor = SleekCard)
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(6.dp),
                                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .width(110.dp)
                                                .aspectRatio(16f / 9f)
                                                .clip(RoundedCornerShape(8.dp))
                                                .background(animatedSkeletonColor)
                                        )

                                        Column(
                                            modifier = Modifier.weight(1f),
                                            verticalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            Box(
                                                modifier = Modifier
                                                    .fillMaxWidth(0.9f)
                                                    .height(14.dp)
                                                    .background(animatedSkeletonColor, RoundedCornerShape(4.dp))
                                            )
                                            Box(
                                                modifier = Modifier
                                                    .fillMaxWidth(0.5f)
                                                    .height(10.dp)
                                                    .background(animatedSkeletonColor, RoundedCornerShape(4.dp))
                                            )
                                        }
                                    }
                                }
                            }
                        } else {
                            // Infinite Playable Recommendations Queue
                            items(relatedVideos) { item ->
                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 6.dp)
                                        .border(1.dp, SleekBorderColor, RoundedCornerShape(12.dp))
                                        .clickable { onPlayRelated(item) },
                                    shape = RoundedCornerShape(12.dp),
                                    colors = CardDefaults.cardColors(containerColor = SleekCard)
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(6.dp),
                                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .width(110.dp)
                                                .aspectRatio(16f / 9f)
                                                .background(Color.Black, RoundedCornerShape(8.dp))
                                        ) {
                                            AsyncImage(
                                                model = item.thumbnailUrl,
                                                contentDescription = item.title,
                                                contentScale = ContentScale.Crop,
                                                modifier = Modifier.fillMaxSize().clip(RoundedCornerShape(8.dp))
                                            )

                                            Box(
                                                modifier = Modifier
                                                    .align(Alignment.BottomEnd)
                                                    .padding(4.dp)
                                                    .background(Color.Black.copy(alpha = 0.85f), RoundedCornerShape(4.dp))
                                                    .padding(horizontal = 4.dp, vertical = 1.dp)
                                            ) {
                                                Text(
                                                    text = item.durationText,
                                                    color = Color.White,
                                                    fontSize = 9.sp,
                                                    fontFamily = FontFamily.Monospace,
                                                    fontWeight = FontWeight.Bold
                                                )
                                            }
                                        }

                                        Column(
                                            modifier = Modifier.weight(1f),
                                            verticalArrangement = Arrangement.spacedBy(2.dp)
                                        ) {
                                            Text(
                                                text = item.title,
                                                maxLines = 2,
                                                overflow = TextOverflow.Ellipsis,
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = SleekTextPrimary,
                                                lineHeight = 15.sp
                                            )
                                            
                                            Text(
                                                text = item.author,
                                                color = SleekTextMuted,
                                                fontSize = 11.sp,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                } // End of LazyColumn
                } // End of if (!isMinimized)
            } // End of Column
        } // End of Surface
    } // End of AnimatedVisibility
    } // End of Box

    if (showVideoDownloadSheet && analyzedVideoResult != null) {
        val sheetState = androidx.compose.material3.rememberModalBottomSheetState(skipPartiallyExpanded = false)
        androidx.compose.material3.ModalBottomSheet(
            onDismissRequest = { showVideoDownloadSheet = false },
            sheetState = sheetState,
            containerColor = SleekCardDark,
            dragHandle = { androidx.compose.material3.BottomSheetDefaults.DragHandle(color = SleekTextSecondary) }
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
                    .padding(bottom = 32.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    text = "DOWNLOAD OPTIONS",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = SleekPurpleDark,
                        letterSpacing = 1.sp
                    )
                )
                
                val videoFormats = analyzedVideoResult!!.formats.filter { it.type == "combined" || it.type == "video_only" }
                val audioFormats = analyzedVideoResult!!.formats.filter { it.type == "audio" }

                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    if (videoFormats.isNotEmpty()) {
                        item {
                            Text(
                                text = "VIDEO",
                                style = MaterialTheme.typography.labelSmall.copy(color = SleekTextSecondary),
                                modifier = Modifier.padding(bottom = 4.dp)
                            )
                        }
                        items(videoFormats) { format ->
                            FormatRowItem(
                                format = format, 
                                modifier = Modifier,
                                onDownloadClick = {
                                    viewModel.startDownload(analyzedVideoResult!!, format)
                                    showVideoDownloadSheet = false
                                },
                                onStreamClick = {
                                    // Normally streams, but they are already streaming! Just close it.
                                    showVideoDownloadSheet = false
                                }
                            )
                        }
                    }

                    if (audioFormats.isNotEmpty()) {
                        item {
                            Spacer(Modifier.height(8.dp))
                            Text(
                                text = "AUDIO",
                                style = MaterialTheme.typography.labelSmall.copy(color = SleekTextSecondary),
                                modifier = Modifier.padding(bottom = 4.dp)
                            )
                        }
                        items(audioFormats) { format ->
                            FormatRowItem(
                                format = format,
                                modifier = Modifier,
                                onDownloadClick = {
                                    viewModel.startDownload(analyzedVideoResult!!, format)
                                    showVideoDownloadSheet = false
                                },
                                onStreamClick = {
                                    showVideoDownloadSheet = false
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun YtdlpTab(
    viewModel: VideoDownloaderViewModel
) {
    val context = LocalContext.current
    
    val ytdlpLocalVersion by viewModel.ytdlpLocalVersion.collectAsStateWithLifecycle()
    val ytdlpOnlineVersion by viewModel.ytdlpOnlineVersion.collectAsStateWithLifecycle()
    val ytdlpVerificationStatus by viewModel.ytdlpVerificationStatus.collectAsStateWithLifecycle()
    val isYtdlpLoading by viewModel.isYtdlpLoading.collectAsStateWithLifecycle()
    val ytdlpProgress by viewModel.ytdlpProgress.collectAsStateWithLifecycle()

    // Setup Document Picker for raw uploads
    val systemUploadLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let {
            try {
                context.contentResolver.openInputStream(it)?.use { inputStream ->
                    val bytes = inputStream.readBytes()
                    viewModel.uploadYtdlpBytes(bytes, context)
                }
            } catch (e: Exception) {
                Log.e("YtdlpTab", "Failed to upload file stream bytes.", e)
            }
        }
    }

    // Auto-run verification on compose startup so they immediately see status
    LaunchedEffect(Unit) {
        viewModel.verifyYtdlp(context)
        viewModel.fetchLatestYtdlpVersionOnline()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Explanatory Card
        Card(
            colors = CardDefaults.cardColors(containerColor = SleekCard),
            shape = RoundedCornerShape(24.dp),
            border = BorderStroke(1.dp, SleekBorderColor.copy(alpha = 0.5f)),
            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = null,
                        tint = SleekPurpleDark
                    )
                    Text(
                        text = "Core Engine Controller",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = SleekPurpleDark
                        )
                    )
                }
                Text(
                    text = "Manage and verify the core downloader engine executable in the local sandboxed application environment.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = SleekTextSecondary
                )
            }
        }

        // Diagnostics Card
        Card(
            colors = CardDefaults.cardColors(containerColor = SleekCard),
            shape = RoundedCornerShape(24.dp),
            border = BorderStroke(1.dp, SleekBorderColor.copy(alpha = 0.5f)),
            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    text = "ENGINE DIAGNOSTICS",
                    style = MaterialTheme.typography.labelMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = SleekPurpleDark,
                        letterSpacing = 1.sp
                    )
                )

                // Online/Offline version rows
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Default GitHub Release", style = MaterialTheme.typography.titleSmall, color = SleekTextPrimary)
                        Text(ytdlpOnlineVersion, style = MaterialTheme.typography.bodyMedium, color = SleekTextSecondary)
                    }
                    Button(
                        onClick = { viewModel.fetchLatestYtdlpVersionOnline() },
                        colors = ButtonDefaults.buttonColors(containerColor = SleekPurpleDark, contentColor = SleekBg),
                        shape = RoundedCornerShape(50)
                    ) {
                        Text("CHECK", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }

                HorizontalDivider(color = SleekBorderColor.copy(alpha = 0.2f))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Local Installed Version", style = MaterialTheme.typography.titleSmall, color = SleekTextPrimary)
                        Text(ytdlpLocalVersion, style = MaterialTheme.typography.bodyMedium, color = SleekTextSecondary)
                    }
                    
                    val isPending = ytdlpLocalVersion.contains("Not") || ytdlpLocalVersion.isEmpty()
                    val hasUpdate = !isPending && 
                        ytdlpOnlineVersion.isNotEmpty() && 
                        !ytdlpOnlineVersion.contains("Checking") && 
                        !ytdlpOnlineVersion.contains("Error") && 
                        !ytdlpOnlineVersion.contains("Failed") &&
                        !ytdlpLocalVersion.contains(ytdlpOnlineVersion)

                    Box(
                        modifier = Modifier
                            .background(
                                color = if (isPending) SleekPurpleLight.copy(alpha = 0.1f) else if (hasUpdate) SleekPurpleLight.copy(alpha = 0.25f) else SleekPurpleLight.copy(alpha = 0.1f),
                                shape = RoundedCornerShape(12.dp)
                            )
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = if (isPending) "PENDING" else if (hasUpdate) "UPDATE AVAILABLE" else "UP TO DATE",
                            color = if (isPending) SleekTextMuted else if (hasUpdate) SleekPurpleDark else SleekTextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        )
                    }
                }
            }
        }

        // Action Panel Card
        Card(
            colors = CardDefaults.cardColors(containerColor = SleekCard),
            shape = RoundedCornerShape(24.dp),
            border = BorderStroke(1.dp, SleekBorderColor.copy(alpha = 0.5f)),
            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    text = "CONTROLS & COMPILING",
                    style = MaterialTheme.typography.labelMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = SleekPurpleDark,
                        letterSpacing = 1.sp
                    )
                )

                if (isYtdlpLoading) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        LinearProgressIndicator(
                            progress = { ytdlpProgress },
                            modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
                            color = SleekPurpleDark,
                            trackColor = SleekPurpleLight.copy(alpha = 0.3f)
                        )
                        Text(
                            text = String.format(Locale.getDefault(), "Processing: %.1f%%", ytdlpProgress * 100),
                            style = MaterialTheme.typography.bodySmall,
                            color = SleekTextSecondary
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Button(
                        onClick = { viewModel.updateYtdlpBinaries(context) },
                        colors = ButtonDefaults.buttonColors(containerColor = SleekPurpleDark),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.weight(1f).testTag("update_ytdlp_btn"),
                        enabled = !isYtdlpLoading
                    ) {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                            Text("UPDATE", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Button(
                        onClick = { systemUploadLauncher.launch("*/*") },
                        colors = ButtonDefaults.buttonColors(containerColor = SleekPurpleDark),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.weight(1f).testTag("upload_ytdlp_btn"),
                        enabled = !isYtdlpLoading
                    ) {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                            Text("UPLOAD", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Button(
                    onClick = { viewModel.verifyYtdlp(context) },
                    colors = ButtonDefaults.buttonColors(containerColor = SleekCardDark, contentColor = SleekPurpleDark),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth().testTag("verify_ytdlp_btn"),
                    enabled = !isYtdlpLoading,
                    border = BorderStroke(1.dp, SleekPurpleLight)
                ) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Check, contentDescription = null)
                        Text("VERIFY & TEST ENVIRONMENT", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }

                // Dynamic Adaptive Pipeline Diagnostics Hud Panel
                val report = remember(context) { YtdlpPipelineManager.runDiagnostics(context) }
                Card(
                    colors = CardDefaults.cardColors(containerColor = SleekPurpleLight.copy(alpha = 0.08f)),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth(),
                    border = BorderStroke(1.dp, SleekPurpleLight.copy(alpha = 0.2f))
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = "ACTIVE PIPELINE STATE",
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = SleekPurpleDark,
                                letterSpacing = 1.sp
                            )
                        )
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Selected Route:", style = MaterialTheme.typography.bodyMedium, color = SleekTextSecondary)
                            Box(
                                modifier = Modifier
                                    .background(SleekPurpleDark, shape = RoundedCornerShape(8.dp))
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = report.activeBackend.displayName.replace("Fallback 2: ", "").replace("Fallback 3: ", "").replace("Final Bypass: ", ""),
                                    color = SleekBg,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                        
                        HorizontalDivider(color = SleekBorderColor.copy(alpha = 0.15f))
                        
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("CPU / Architecture:", style = MaterialTheme.typography.bodySmall, color = SleekTextSecondary)
                            Text(report.systemArchitecture.split("[").first().trim(), style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold), color = SleekTextPrimary)
                        }
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Android OS Constraints:", style = MaterialTheme.typography.bodySmall, color = SleekTextSecondary)
                            Text("API ${report.sdkInt} (Android ${report.releaseVersion})", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold), color = SleekTextPrimary)
                        }
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("SELinux / W^X restriction:", style = MaterialTheme.typography.bodySmall, color = SleekTextSecondary)
                            Text(
                                text = if (report.wExRestricted) "ELIMINATED VIA FAILSURGE" else "NONE",
                                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                                color = if (report.wExRestricted) CrimsonFailure else EmeraldSuccess
                            )
                        }
                    }
                }

                HorizontalDivider(color = SleekBorderColor.copy(alpha = 0.2f))

                val customCommandInput by viewModel.customCommandInput.collectAsStateWithLifecycle()

                Column(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "CUSTOM CLI TERMINAL RUNNER",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = SleekPurpleDark,
                            letterSpacing = 1.sp
                        )
                    )
                    OutlinedTextField(
                        value = customCommandInput,
                        onValueChange = { viewModel.updateCustomCommandInput(it) },
                        placeholder = { Text("e.g. --version or --help", color = SleekTextSecondary.copy(alpha = 0.6f)) },
                        leadingIcon = {
                            Text(
                                " ./engine ",
                                color = SleekPurpleDark,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(start = 12.dp)
                            )
                        },
                        textStyle = LocalTextStyle.current.copy(fontFamily = FontFamily.Monospace, fontSize = 13.sp),
                        modifier = Modifier.fillMaxWidth().testTag("custom_command_input"),
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = SleekTextPrimary,
                            unfocusedTextColor = SleekTextPrimary,
                            focusedBorderColor = SleekPurpleDark,
                            unfocusedBorderColor = SleekBorderColor,
                            focusedContainerColor = SleekCardDark,
                            unfocusedContainerColor = SleekCardDark
                        )
                    )
                    Button(
                        onClick = { viewModel.executeCustomYtdlpCommand(context) },
                        colors = ButtonDefaults.buttonColors(containerColor = SleekPurpleDark, contentColor = SleekBg),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth().testTag("run_custom_command_btn"),
                        enabled = !isYtdlpLoading
                    ) {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                            Text("RUN CUSTOM COMMAND", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                }
            }
        }

        // Terminal Console Logs output block
        Card(
            colors = CardDefaults.cardColors(containerColor = SleekCardDark),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "CONSOLE STDOUT / VERIFICATION OUTPUT",
                        color = SleekTextSecondary,
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    )
                    Box(
                        modifier = Modifier
                            .background(SleekPurpleLight, shape = RoundedCornerShape(4.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "terminal",
                            color = EmeraldSuccess,
                            fontSize = 8.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
                
                SelectionContainer {
                    Text(
                        text = ytdlpVerificationStatus,
                        color = SleekTextSecondary,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                    )
                }
            }
        }
    }
}

enum class FloatingWidgetState {
    COLLAPSED,
    URL_INPUT,
    SHOW_RESULT
}

@Composable
fun FloatingSearchWidget(
    viewModel: VideoDownloaderViewModel,
    isPlayerOpen: Boolean,
    selectedTabIndex: Int,
    onClose: () -> Unit
) {
    val clipboardManager = LocalClipboardManager.current
    val context = LocalContext.current
    
    val isAnalyzing by viewModel.isAnalyzing.collectAsStateWithLifecycle()
    val analyzedVideo by viewModel.analyzedVideo.collectAsStateWithLifecycle()
    val activeDownloads by viewModel.activeDownloads.collectAsStateWithLifecycle()
    
    var widgetState by remember { mutableStateOf(FloatingWidgetState.COLLAPSED) }
    var enteredUrl by remember { mutableStateOf("") }
    
    var lastIsAnalyzing by remember { mutableStateOf(false) }
    LaunchedEffect(isAnalyzing) {
        if (lastIsAnalyzing && !isAnalyzing) {
            if (analyzedVideo != null) {
                widgetState = FloatingWidgetState.SHOW_RESULT
            }
        }
        if (isAnalyzing) {
            widgetState = FloatingWidgetState.COLLAPSED
        }
        lastIsAnalyzing = isAnalyzing
    }

    LaunchedEffect(isPlayerOpen) {
        if (isPlayerOpen) {
            widgetState = FloatingWidgetState.COLLAPSED
        }
    }

    LaunchedEffect(selectedTabIndex) {
        widgetState = FloatingWidgetState.COLLAPSED
    }
    
    val activeTasksCount = activeDownloads.size
    var lastActiveTasksCount by remember { mutableStateOf(0) }
    LaunchedEffect(activeDownloads) {
        if (activeDownloads.size > lastActiveTasksCount) {
            if (widgetState == FloatingWidgetState.SHOW_RESULT) {
                widgetState = FloatingWidgetState.COLLAPSED
            }
        }
        lastActiveTasksCount = activeDownloads.size
    }

    val activeTask = activeDownloads.values.firstOrNull {
        it.status == DownloadStatus.DOWNLOADING || it.status == DownloadStatus.PENDING
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val maxWidthPx = constraints.maxWidth.toFloat()
        val maxHeightPx = constraints.maxHeight.toFloat()
        
        var isPosInitialized by remember { mutableStateOf(false) }
        var offsetX by remember { mutableStateOf(0f) }
        var offsetY by remember { mutableStateOf(0f) }
        
        if (!isPosInitialized && maxWidthPx > 0) {
            offsetX = maxWidthPx * 0.15f
            offsetY = maxHeightPx * 0.6f
            isPosInitialized = true
        }
        
        val cardShape = when (widgetState) {
            FloatingWidgetState.COLLAPSED -> CircleShape
            FloatingWidgetState.URL_INPUT -> CircleShape
            FloatingWidgetState.SHOW_RESULT -> RoundedCornerShape(20.dp)
        }

        val cardWidth by animateDpAsState(
            targetValue = when (widgetState) {
                FloatingWidgetState.COLLAPSED -> 56.dp
                FloatingWidgetState.URL_INPUT -> 300.dp
                FloatingWidgetState.SHOW_RESULT -> 320.dp
            },
            animationSpec = spring(dampingRatio = Spring.DampingRatioLowBouncy, stiffness = Spring.StiffnessMedium),
            label = "width"
        )
        
        val cardHeight by animateDpAsState(
            targetValue = when (widgetState) {
                FloatingWidgetState.COLLAPSED -> 56.dp
                FloatingWidgetState.URL_INPUT -> 50.dp
                FloatingWidgetState.SHOW_RESULT -> 210.dp
            },
            animationSpec = spring(dampingRatio = Spring.DampingRatioLowBouncy, stiffness = Spring.StiffnessMedium),
            label = "height"
        )

        if (widgetState != FloatingWidgetState.COLLAPSED) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .clickable(
                        onClick = { widgetState = FloatingWidgetState.COLLAPSED },
                        indication = null,
                        interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() }
                    )
            )
        }

        Card(
            modifier = Modifier
                .offset { IntOffset(offsetX.roundToInt(), offsetY.roundToInt()) }
                .size(width = cardWidth, height = cardHeight)
                .pointerInput(Unit) {
                    detectDragGestures { change, dragAmount ->
                        change.consume()
                        offsetX = (offsetX + dragAmount.x).coerceIn(0f, maxOf(0f, maxWidthPx - 100f))
                        offsetY = (offsetY + dragAmount.y).coerceIn(0f, maxOf(0f, maxHeightPx - 150f))
                    }
                }
                .clickable(
                    indication = null,
                    interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() }
                ) {
                    // Consume tap/click events so they don't propagate to the full screen click-to-collapse box
                }
                .shadow(elevation = 12.dp, shape = cardShape)
                .border(1.5.dp, SleekPurpleDark.copy(alpha = 0.8f), cardShape),
            colors = CardDefaults.cardColors(containerColor = SleekCard),
            shape = cardShape
        ) {
            AnimatedContent(
                targetState = widgetState,
                transitionSpec = {
                    fadeIn(animationSpec = tween(150)) togetherWith fadeOut(animationSpec = tween(150))
                },
                modifier = Modifier.fillMaxSize(),
                label = "widget_anim"
            ) { state ->
                when (state) {
                    FloatingWidgetState.COLLAPSED -> {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .clickable {
                                    widgetState = FloatingWidgetState.URL_INPUT
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            if (activeTask != null) {
                                Box(contentAlignment = Alignment.Center, modifier = Modifier.size(46.dp)) {
                                    CircularProgressIndicator(
                                        progress = { activeTask.progress },
                                        color = Color.White,
                                        strokeWidth = 3.dp,
                                        modifier = Modifier.fillMaxSize()
                                    )
                                    Text(
                                        text = "${(activeTask.progress * 100).roundToInt()}%",
                                        color = Color.White,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            } else if (isAnalyzing) {
                                CircularProgressIndicator(
                                    color = Color.White,
                                    strokeWidth = 3.dp,
                                    modifier = Modifier.size(24.dp)
                                )
                            } else {
                                Icon(
                                    imageVector = Icons.Default.Search,
                                    contentDescription = "Search Floating",
                                    tint = Color.White,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                        }
                    }
                    FloatingWidgetState.URL_INPUT -> {
                        Row(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(horizontal = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            TextField(
                                value = enteredUrl,
                                onValueChange = { enteredUrl = it },
                                placeholder = {
                                    Text("Enter keyword/URL...", color = SleekTextMuted, fontSize = 11.sp)
                                },
                                textStyle = MaterialTheme.typography.bodySmall.copy(color = Color.White),
                                singleLine = true,
                                colors = TextFieldDefaults.colors(
                                    focusedContainerColor = Color.Transparent,
                                    unfocusedContainerColor = Color.Transparent,
                                    disabledContainerColor = Color.Transparent,
                                    focusedIndicatorColor = Color.Transparent,
                                    unfocusedIndicatorColor = Color.Transparent,
                                    disabledIndicatorColor = Color.Transparent
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .padding(vertical = 0.dp)
                            )

                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                if (enteredUrl.isNotBlank()) {
                                    IconButton(
                                        onClick = { enteredUrl = "" },
                                        modifier = Modifier.size(28.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Close,
                                            contentDescription = "Clear",
                                            tint = SleekTextMuted,
                                            modifier = Modifier.size(14.dp)
                                        )
                                    }
                                }

                                IconButton(
                                    onClick = {
                                        if (enteredUrl.isNotBlank()) {
                                            viewModel.updateUrlInput(enteredUrl)
                                            viewModel.analyzeVideo()
                                        }
                                    },
                                    modifier = Modifier
                                        .size(36.dp)
                                        .background(SleekPurpleDark, CircleShape)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Search,
                                        contentDescription = "Search",
                                        tint = Color.White,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }

                                IconButton(
                                    onClick = {
                                        widgetState = FloatingWidgetState.COLLAPSED
                                    },
                                    modifier = Modifier.size(28.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.KeyboardArrowDown,
                                        contentDescription = "Close",
                                        tint = SleekTextMuted,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }
                    }
                    FloatingWidgetState.SHOW_RESULT -> {
                        val video = analyzedVideo
                        if (video != null) {
                            Column(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(12.dp),
                                verticalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.Start,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "READY",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = EmeraldSuccess
                                        )
                                    )
                                }

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    AsyncImage(
                                        model = video.thumbnailUrl,
                                        contentDescription = null,
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier
                                            .size(width = 56.dp, height = 42.dp)
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(SleekCardDark)
                                    )
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = video.title,
                                            color = Color.White,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Text(
                                            text = video.author,
                                            color = SleekTextSecondary,
                                            fontSize = 9.sp,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                }

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    val videoFormat = video.formats.firstOrNull { it.type == "combined" } 
                                        ?: video.formats.firstOrNull { it.type == "video_only" }
                                    
                                    val audioFormat = video.formats.firstOrNull { it.type == "audio" }

                                    if (videoFormat != null) {
                                        Button(
                                            onClick = {
                                                viewModel.startDownload(video, videoFormat)
                                                widgetState = FloatingWidgetState.COLLAPSED
                                            },
                                            modifier = Modifier
                                                .weight(1f)
                                                .height(34.dp),
                                            shape = RoundedCornerShape(8.dp),
                                            colors = ButtonDefaults.buttonColors(
                                                containerColor = Color.White,
                                                contentColor = Color.Black
                                            ),
                                            contentPadding = PaddingValues(horizontal = 4.dp)
                                        ) {
                                            Text(
                                                text = "Video (${videoFormat.quality})",
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }
                                    }

                                    if (audioFormat != null) {
                                        Button(
                                            onClick = {
                                                viewModel.startDownload(video, audioFormat)
                                                widgetState = FloatingWidgetState.COLLAPSED
                                            },
                                            modifier = Modifier
                                                .weight(1.0f)
                                                .height(34.dp),
                                            shape = RoundedCornerShape(8.dp),
                                            colors = ButtonDefaults.buttonColors(
                                                containerColor = SleekPurpleContainer,
                                                contentColor = Color.White
                                            ),
                                            contentPadding = PaddingValues(horizontal = 4.dp),
                                            border = BorderStroke(1.dp, SleekBorderColor)
                                        ) {
                                            Text(
                                                text = "Audio",
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }
                                    }
                                }
                            }
                        } else {
                            Box(
                                modifier = Modifier.fillMaxSize(),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("No video loaded", color = SleekTextMuted, fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AudioPlayerDialog(
    download: DownloadEntity,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    var isBoosted by remember { mutableStateOf(false) }
    var currentSpeed by remember { mutableFloatStateOf(1.0f) }
    
    val exoPlayer = remember {
        com.example.ui.PlayerHolder.initialize(context)
    }

    LaunchedEffect(download.localPath) {
        val mediaItem = if (download.localPath.startsWith("http://") || download.localPath.startsWith("https://")) {
            androidx.media3.common.MediaItem.fromUri(Uri.parse(download.localPath))
        } else {
            androidx.media3.common.MediaItem.fromUri(Uri.fromFile(java.io.File(download.localPath)))
        }
        exoPlayer.setMediaItem(mediaItem)
        exoPlayer.prepare()
        exoPlayer.playWhenReady = true
        exoPlayer.repeatMode = androidx.media3.common.Player.REPEAT_MODE_ONE
    }
    
    val loudnessEnhancer = com.example.ui.PlayerHolder.loudnessEnhancer!!

    DisposableEffect(Unit) {
        val sessionToken = androidx.media3.session.SessionToken(context, android.content.ComponentName(context, com.example.PlaybackService::class.java))
        val controllerFuture = androidx.media3.session.MediaController.Builder(context, sessionToken).buildAsync()
        
        onDispose {
            androidx.media3.session.MediaController.releaseFuture(controllerFuture)
            com.example.ui.PlayerHolder.player?.stop()
        }
    }

    var isPlaying by remember { mutableStateOf(exoPlayer.isPlaying) }
    var currentPosition by remember { mutableLongStateOf(0L) }
    var duration by remember { mutableLongStateOf(0L) }

    DisposableEffect(exoPlayer) {
        val listener = object : androidx.media3.common.Player.Listener {
            override fun onIsPlayingChanged(isPlaying_: Boolean) {
                isPlaying = isPlaying_
            }
            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == androidx.media3.common.Player.STATE_READY) {
                    duration = exoPlayer.duration.coerceAtLeast(0L)
                }
            }
            override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                error.printStackTrace()
                android.widget.Toast.makeText(context, "Cannot stream this audio right now.", android.widget.Toast.LENGTH_SHORT).show()
            }
        }
        exoPlayer.addListener(listener)
        // Sync initial state
        isPlaying = exoPlayer.isPlaying
        if (exoPlayer.playbackState == androidx.media3.common.Player.STATE_READY) {
            duration = exoPlayer.duration.coerceAtLeast(0L)
        }
        onDispose { exoPlayer.removeListener(listener) }
    }

    // Set speed on startup or parameter change
    LaunchedEffect(currentSpeed, exoPlayer) {
        try {
            exoPlayer.setPlaybackSpeed(currentSpeed)
        } catch (e: Exception) {
            try {
                exoPlayer.playbackParameters = androidx.media3.common.PlaybackParameters(currentSpeed)
            } catch (ex: Exception) {}
        }
    }

    // Track position progress updates
    LaunchedEffect(isPlaying) {
        if (isPlaying) {
            while (true) {
                currentPosition = exoPlayer.currentPosition.coerceAtLeast(0L)
                kotlinx.coroutines.delay(100)
            }
        }
    }

    // Gentle rotation counter for the vinyl
    var currentAngle by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(isPlaying) {
        if (isPlaying) {
            while (true) {
                currentAngle = (currentAngle + 1.2f) % 360f
                kotlinx.coroutines.delay(16) // ~60fps
            }
        }
    }

    // Animated bar height states for audio visualizer spectrum
    val visualizerHeights = remember { List(16) { mutableStateOf(4f) } }
    LaunchedEffect(isPlaying) {
        if (isPlaying) {
            while (true) {
                for (i in visualizerHeights.indices) {
                    // Random fluctuation between 6dp and 48dp for lively visual impact
                    visualizerHeights[i].value = (6..48).random().toFloat()
                }
                kotlinx.coroutines.delay(100)
            }
        } else {
            for (i in visualizerHeights.indices) {
                visualizerHeights[i].value = 4f
            }
        }
    }

    var isMinimized by remember { mutableStateOf(false) }

    androidx.activity.compose.BackHandler {
        if (!isMinimized) {
            isMinimized = true
        } else {
            onDismiss()
        }
    }

    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.BottomEnd
    ) {
        androidx.compose.animation.AnimatedVisibility(
            visible = true,
            enter = androidx.compose.animation.fadeIn() + androidx.compose.animation.slideInVertically(initialOffsetY = { it / 2 }),
            exit = androidx.compose.animation.fadeOut() + androidx.compose.animation.slideOutVertically(targetOffsetY = { it / 2 }),
            modifier = if (isMinimized) {
                Modifier
                    .padding(bottom = 90.dp, end = 16.dp)
                    .width(200.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .pointerInput(Unit) { detectTapGestures(onTap = { isMinimized = false }) }
            } else {
                Modifier.fillMaxSize()
            }
        ) {
            Box(
                modifier = (if (isMinimized) Modifier.height(110.dp) else Modifier.fillMaxSize())
                    .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            Color(0xFF0F0F12), // Deep velvet black-grey
                            Color(0xFF020202)  // Infinite pure pitch black
                        )
                    )
                )
        ) {
            // Elegant background ambient glows
            Box(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .fillMaxWidth()
                    .height(300.dp)
                    .background(
                        Brush.radialGradient(
                            colors = listOf(
                                Color.White.copy(alpha = 0.04f),
                                Color.Transparent
                            )
                        )
                    )
            )

            if (!isMinimized) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 24.dp)
                        .navigationBarsPadding()
                        .statusBarsPadding(),
                    verticalArrangement = Arrangement.SpaceBetween,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                // 1. Top Bar Navigation
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = { isMinimized = true },
                        modifier = Modifier
                            .background(Color.White.copy(alpha = 0.05f), CircleShape)
                            .border(1.dp, Color.White.copy(alpha = 0.1f), CircleShape)
                    ) {
                        Icon(
                            imageVector = Icons.Default.KeyboardArrowDown,
                            contentDescription = "Collapse Player",
                            tint = Color.White
                        )
                    }

                    Text(
                        text = "NOW PLAYING",
                        color = Color.White.copy(alpha = 0.6f),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 2.sp,
                        fontFamily = FontFamily.Monospace
                    )

                    IconButton(
                        onClick = {
                            isBoosted = !isBoosted
                            loudnessEnhancer.enabled = isBoosted
                        },
                        modifier = Modifier
                            .background(
                                if (isBoosted) Color.White else Color.White.copy(alpha = 0.05f),
                                CircleShape
                            )
                            .border(
                                1.dp,
                                if (isBoosted) Color.White else Color.White.copy(alpha = 0.1f),
                                CircleShape
                            )
                    ) {
                        Icon(
                            imageVector = Icons.Default.VolumeUp,
                            contentDescription = "Volume Boost",
                            tint = if (isBoosted) Color.Black else Color.White
                        )
                    }
                }

                // 2. Vinyl Rotating Record Player Block
                Box(
                    modifier = Modifier
                        .padding(vertical = 24.dp)
                        .size(260.dp)
                        .shadow(24.dp, CircleShape)
                        .background(Color(0xFF121214), CircleShape)
                        .border(6.dp, Color(0xFF1E1E22), CircleShape)
                        .graphicsLayer(rotationZ = currentAngle),
                    contentAlignment = Alignment.Center
                ) {
                    // Outer Vinyl Grooves (Drawn via Canvas)
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val stroke = 1.5f
                        val centerOffset = size.width / 2
                        // Simple elegant microgrooves on vinyl
                        drawCircle(
                            color = Color.Black.copy(alpha = 0.65f),
                            radius = centerOffset - 24f,
                            style = androidx.compose.ui.graphics.drawscope.Stroke(width = stroke)
                        )
                        drawCircle(
                            color = Color.Black.copy(alpha = 0.45f),
                            radius = centerOffset - 48f,
                            style = androidx.compose.ui.graphics.drawscope.Stroke(width = stroke)
                        )
                        drawCircle(
                            color = Color.Black.copy(alpha = 0.35f),
                            radius = centerOffset - 72f,
                            style = androidx.compose.ui.graphics.drawscope.Stroke(width = stroke)
                        )
                        drawCircle(
                            color = Color.Black.copy(alpha = 0.25f),
                            radius = centerOffset - 96f,
                            style = androidx.compose.ui.graphics.drawscope.Stroke(width = stroke)
                        )
                    }

                    // Rotating Inner Album Label Image
                    Box(
                        modifier = Modifier
                            .size(110.dp)
                            .clip(CircleShape)
                            .background(Color.DarkGray)
                            .border(3.dp, Color.Black, CircleShape)
                    ) {
                        AsyncImage(
                            model = download.thumbnailUrl,
                            contentDescription = "Album Thumbnail",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                        
                        // Centered spindle hole decoration
                        Box(
                            modifier = Modifier
                                .align(Alignment.Center)
                                .size(14.dp)
                                .background(Color.Black, CircleShape)
                                .border(1.5.dp, Color.White.copy(alpha = 0.6f), CircleShape)
                        )
                    }
                }

                // 3. Audio Metadata and Animated Wave Visualizer
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = download.title,
                        color = Color.White,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.fillMaxWidth()
                    )
                    
                    Spacer(modifier = Modifier.height(4.dp))
                    
                    Text(
                        text = if (download.author.isNotBlank()) download.author else "Local Audio File",
                        color = Color.White.copy(alpha = 0.5f),
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium,
                        textAlign = TextAlign.Center,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )

                    Spacer(modifier = Modifier.height(18.dp))

                    // Animated Visualizer Row (Breathes and fluctuates in rhythm)
                    Row(
                        modifier = Modifier
                            .height(52.dp)
                            .fillMaxWidth(0.8f),
                        horizontalArrangement = Arrangement.spacedBy(4.dp, Alignment.CenterHorizontally),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        visualizerHeights.forEach { heightState ->
                            val animatedHeight by animateDpAsState(
                                targetValue = heightState.value.dp,
                                animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
                                label = "bar_height"
                            )
                            Box(
                                modifier = Modifier
                                    .width(3.dp)
                                    .height(animatedHeight)
                                    .background(
                                        brush = Brush.verticalGradient(
                                            colors = listOf(Color.White, Color.White.copy(alpha = 0.2f))
                                        ),
                                        shape = RoundedCornerShape(50)
                                    )
                            )
                        }
                    }
                }

                // 4. Progress Control Panel (Slider, Speed chips and Timers)
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 12.dp)
                ) {
                    // Time indicators row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val currentMin = currentPosition / 60000
                        val currentSec = (currentPosition % 60000) / 1000
                        Text(
                            text = String.format(Locale.US, "%02d:%02d", currentMin, currentSec),
                            color = Color.White.copy(alpha = 0.6f),
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace
                        )

                        val durMin = duration / 60000
                        val durSec = (duration % 60000) / 1000
                        Text(
                            text = String.format(Locale.US, "%02d:%02d", durMin, durSec),
                            color = Color.White.copy(alpha = 0.6f),
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    // Sliding seek bar progress tracker
                    PremiumSeekBar(
                        value = if (duration > 0) currentPosition.toFloat() else 0f,
                        onValueChange = {
                            currentPosition = it.toLong()
                            exoPlayer.seekTo(currentPosition)
                        },
                        valueRange = 0f..(if (duration > 0) duration.toFloat() else 1f),
                        modifier = Modifier.fillMaxWidth(),
                        activeColor = SleekPurpleLight,
                        inactiveColor = Color.White.copy(alpha = 0.15f)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Playback Speed Options Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val speeds = listOf(0.5f, 1.0f, 1.25f, 1.5f, 2.0f)
                        speeds.forEach { speed ->
                            val isSelected = currentSpeed == speed
                            Box(
                                modifier = Modifier
                                    .background(
                                        if (isSelected) Color.White else Color.White.copy(alpha = 0.05f),
                                        RoundedCornerShape(8.dp)
                                    )
                                    .border(
                                        1.dp,
                                        if (isSelected) Color.White else Color.White.copy(alpha = 0.1f),
                                        RoundedCornerShape(8.dp)
                                    )
                                    .clickable {
                                        currentSpeed = speed
                                    }
                                    .padding(horizontal = 10.dp, vertical = 4.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "${speed}x",
                                    color = if (isSelected) Color.Black else Color.White.copy(alpha = 0.7f),
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }

                // 5. Ultimate Playback Command Panel (Rewind, Play/Pause, Forward)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 32.dp),
                    horizontalArrangement = Arrangement.spacedBy(28.dp, Alignment.CenterHorizontally),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Rewind 10 Seconds
                    IconButton(
                        onClick = {
                            val target = (exoPlayer.currentPosition - 10000).coerceAtLeast(0L)
                            exoPlayer.seekTo(target)
                            currentPosition = target
                        },
                        modifier = Modifier
                            .size(52.dp)
                            .background(Color.White.copy(alpha = 0.05f), CircleShape)
                            .border(1.dp, Color.White.copy(alpha = 0.1f), CircleShape)
                    ) {
                        Icon(
                            imageVector = Icons.Default.FastRewind,
                            contentDescription = "Rewind 10 Seconds",
                            tint = Color.White,
                            modifier = Modifier.size(24.dp)
                        )
                    }

                    // Play / Pause glowing tactile circle
                    Box(
                        modifier = Modifier
                            .size(76.dp)
                            .shadow(8.dp, CircleShape)
                            .background(Color.White, CircleShape)
                            .clickable {
                                if (isPlaying) exoPlayer.pause() else exoPlayer.play()
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        AnimatedContent(
                            targetState = isPlaying,
                            transitionSpec = {
                                scaleIn() togetherWith scaleOut()
                            },
                            label = "play_pause_transition"
                        ) { playing ->
                            Icon(
                                imageVector = if (playing) Icons.Default.Pause else Icons.Default.PlayArrow,
                                contentDescription = if (playing) "Pause" else "Play",
                                tint = Color.Black,
                                modifier = Modifier.size(38.dp)
                            )
                        }
                    }

                    // Fast Forward 10 Seconds
                    IconButton(
                        onClick = {
                            val target = (exoPlayer.currentPosition + 10000).coerceAtMost(duration)
                            exoPlayer.seekTo(target)
                            currentPosition = target
                        },
                        modifier = Modifier
                            .size(52.dp)
                            .background(Color.White.copy(alpha = 0.05f), CircleShape)
                            .border(1.dp, Color.White.copy(alpha = 0.1f), CircleShape)
                    ) {
                        Icon(
                            imageVector = Icons.Default.FastForward,
                            contentDescription = "Forward 10 Seconds",
                            tint = Color.White,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }
            } // Close Column
            } else { // End if(!isMinimized)
                Row(
                    modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = download.title,
                            color = Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = if (isPlaying) "Playing" else "Paused",
                            color = Color.White.copy(alpha = 0.6f),
                            fontSize = 10.sp
                        )
                    }
                    IconButton(
                        onClick = { if (isPlaying) exoPlayer.pause() else exoPlayer.play() },
                        modifier = Modifier
                            .padding(end = 8.dp)
                            .size(36.dp)
                            .background(Color.White.copy(alpha = 0.1f), CircleShape)
                    ) {
                        Icon(
                            imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = "Play/Pause Toggle",
                            tint = Color.White
                        )
                    }
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .size(36.dp)
                            .background(Color.White.copy(alpha = 0.1f), CircleShape)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = Color.White
                        )
                    }
                }
            }
        }
    }
}
}
