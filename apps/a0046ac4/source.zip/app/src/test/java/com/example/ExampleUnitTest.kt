package com.example

import org.junit.Assert.*
import org.junit.Test
import com.yausername.youtubedl_android.mapper.VideoInfo

class ExampleUnitTest {
  @Test
  fun addition_isCorrect() {
    assertEquals(4, 2 + 2)
  }

  @Test
  fun reflectVideoInfo() {
      val fields = VideoInfo::class.java.declaredFields.map { it.name }
      println("Fields in VideoInfo: ${fields.joinToString(", ")}")
  }
}
