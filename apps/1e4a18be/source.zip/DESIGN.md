# Product Audit

## UX Goals
- **Frictionless Navigation:** Fast, seamless switching between configured games and accounts.
- **Clear State Representation:** Users must always know which game and account they are currently operating under.
- **Isolated Contexts:** Each account must feel like an entirely separate session to avoid cross-contamination.
- **Configurable Workspaces:** Simple, intuitive interfaces to add, modify, and delete game configurations and routes.

## User Personas
1. **The Power User:** Manages multiple accounts across several browser-based games or platforms. Needs rapid context switching without logging in and out constantly.
2. **The Administrator:** Needs to configure the exact routes (e.g., Gift, Wallet, Promotion) dynamically depending on the current platform structure.

# Information Architecture

## Navigation
The app utilizes a flat navigation structure centered around the Dashboard, avoiding deep nesting where possible.

- **Dashboard (Home):** The primary workspace and embedded browser view.
- **Game Manager:** Configuration for adding/editing supported games and their respective domains.
- **Route Manager:** Route definitions for specific games.
- **Account Manager:** Secure credential and session storage.
- **Settings:** App-wide preferences, theme, and data management.

## Screen Specifications

### Home (Dashboard)
- **Purpose:** Primary workspace for navigating game routes and executing tasks (e.g., claiming gift codes).
- **Layout:**
  - **Header:** Sticky top bar displaying the Current Game and Active Account selectors.
  - **Quick Actions:** A horizontal scrollable row of neon-accented, icon-first buttons for configured routes (Gift, Wallet, History, etc.).
  - **Input Area:** Specialized text field for rapid gift code entry.
  - **Browser View:** The central embedded WebView (isolated per account).
  - **Status & Console:** A subtle, collapsible log window at the bottom for status updates.

### Game & Route Manager
- **Purpose:** Configure domains and specific URL paths.
- **Layout:**
  - **List View:** Display active games with reorderable handles.
  - **Detail View:** Form to input Base URL and a dynamic list of route configurations (Route Name + URL Suffix).

### Account Manager
- **Purpose:** Handle multiple sessions securely.
- **Layout:**
  - **Card Grid:** Displays accounts tied to the current game.
  - **Status Indicators:** Clear visual cues (e.g., green dot) for active sessions.
  - **Actions:** Login, switch, or clear session.

### Settings
- **Purpose:** App configuration and data portability.
- **Layout:** Grouped list spanning Theme, Storage Management (Clear Cache/Cookies), and Backup/Restore functions.

# Component Library

## Color System (Neon Dark Theme)
- **Background:** Deep Charcoal (`#121212`) to True Black (`#000000`).
- **Surface:** Glassy, semi-transparent layers (`#1E1E1E` with alpha) for cards and modals.
- **Primary Accent:** Electric Purple (`#9D4EDD`).
- **Secondary Accent:** Cyan/Neon Blue (`#00F5D4`) for interactive highlights.
- **Error:** Bright Crimson (`#FF4D4D`).
- **On-Surface Text:** High contrast white/off-white for readability.

## Typography
- **Headings:** Bold, geometric sans-serif (e.g., *Outfit* or *Plus Jakarta Sans*) to provide a modern, technical feel.
- **Body:** Clean, legible sans-serif for UI elements and logs.
- **Scale:** Modular scale ensuring hierarchy, with distinct sizes for headers (24sp+), buttons (16sp), and overline/log text (12sp).

## Spacing System
- Strict adherence to the 8dp grid (4dp, 8dp, 16dp, 24dp, 32dp).
- **Padding:** Generous 16dp padding on standard screens; 24dp margins for prominent cards.

## Elevation & Depth
- Rely on subtle, colored drop shadows (e.g., a faint purple glow behind primary buttons) rather than traditional gray drop shadows.
- Use layered opacity (Surface -> Surface Variant) to separate content zones.

# Motion System

- **Transitions:** Fast, spring-based animations (stiffness: medium, damping: no bounciness) for screen transitions.
- **Micro-interactions:** 
  - Scale down slightly (`0.95f`) on button press with a vibrant ripple effect.
  - Smooth fade-in for WebViews upon loading completion.

# Empty, Loading, and Error States

- **Empty States:** Highly visual. E.g., if no games are configured, show a large, stylized icon with a clear "Add your first game" CTA.
- **Loading:** Use subtle linear progress indicators at the top edge of the WebView rather than blocking the UI with full-screen spinners.
- **Error States:** Contextual snackbars for failed network requests or invalid configurations; distinct inline error text for form validation.

# Accessibility & Adaptive Layouts

- **Touch Targets:** Minimum 48dp x 48dp on all interactive elements.
- **Contrast:** Ensure all text passes WCAG AA contrast ratios against the dark background.
- **Adaptive:** 
  - On larger screens (tablets), the Game/Account selection moves to a Side Navigation Rail.
  - The embedded WebView expands to fill the remaining space.

# Developer Notes

- **Platform Shift:** While the initial PRD specifies Flutter, this application is being architected natively for Android using **Kotlin**, **Jetpack Compose**, and **Room Database**. This provides superior performance and tighter OS integration.
- **State Management:** Utilizing `ViewModel` and `StateFlow` (equivalent to Riverpod in the Android ecosystem).
- **Web Engine:** Relying on Android's native `WebView` framework, wrapped in Compose, with careful attention to CookieManager for session isolation.

# UX QA Checklist
- [ ] Is the current Game and Account instantly recognizable?
- [ ] Can a user switch accounts in two taps or fewer?
- [ ] Are route buttons easily reachable (bottom of screen or sticky top)?
- [ ] Does the UI feel fast and responsive?
- [ ] Are empty states helpful rather than dead ends?
- [ ] Is the WebView state properly isolated between accounts?

# Future Improvements
- Cloud synchronization for game and route configurations.
- Custom theme engine for user-defined colors.
- Advanced scripting or macro integration for repetitive tasks within the WebView.
