package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.PurplePrimary
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.SurfaceVariantDark

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    containerColor = MaterialTheme.colorScheme.background
                ) { innerPadding ->
                    AutoGiftCodeClaimerScreen(modifier = Modifier.padding(innerPadding))
                }
            }
        }
    }
}

@Composable
fun AutoGiftCodeClaimerScreen(modifier: Modifier = Modifier) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(vertical = 16.dp)
    ) {
        item { HeaderSection() }
        item { NavigationSection() }
        item { GiftCodeInputSection() }
        item { MainActionsSection() }
        item { QuickActionsSection() }
        item { ManagementSection() }
        item { CurrentSessionSection() }
        item { LogWindowSection() }
    }
}

// ① HEADER
@Composable
fun HeaderSection() {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = Icons.Default.AutoAwesome,
                contentDescription = "Logo",
                tint = PurplePrimary,
                modifier = Modifier.size(28.dp)
            )
            Spacer(modifier = Modifier.width(12.dp))
            Text(
                text = "AUTO GIFT CODE CLAIMER",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.ExtraBold,
                color = MaterialTheme.colorScheme.onBackground
            )
        }
        IconButton(onClick = { /* Hide Panel Logic */ }) {
            Icon(
                imageVector = Icons.Default.ExpandLess,
                contentDescription = "Hide Panel",
                tint = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

// ② NAVIGATION
@Composable
fun NavigationSection() {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Platform Selector
        Surface(
            modifier = Modifier.weight(1f),
            color = SurfaceDark,
            shape = RoundedCornerShape(12.dp),
            onClick = { /* Open Game Selector */ }
        ) {
            Row(
                modifier = Modifier.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "91Club",
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Icon(
                    imageVector = Icons.Default.ArrowDropDown,
                    contentDescription = "Select Platform",
                    tint = NeonCyan
                )
            }
        }
        
        // Settings Button
        Surface(
            color = SurfaceDark,
            shape = RoundedCornerShape(12.dp),
            onClick = { /* Open Settings */ }
        ) {
            Box(modifier = Modifier.padding(16.dp)) {
                Icon(
                    imageVector = Icons.Default.Settings,
                    contentDescription = "Settings",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

// ③ GIFT CODE INPUT
@Composable
fun GiftCodeInputSection() {
    var giftCode by remember { mutableStateOf("") }
    
    OutlinedTextField(
        value = giftCode,
        onValueChange = { giftCode = it },
        modifier = Modifier.fillMaxWidth(),
        placeholder = { 
            Text("Paste Gift Code Here...", color = MaterialTheme.colorScheme.onSurfaceVariant) 
        },
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = NeonCyan,
            unfocusedBorderColor = SurfaceVariantDark,
            focusedTextColor = MaterialTheme.colorScheme.onBackground,
            unfocusedTextColor = MaterialTheme.colorScheme.onBackground
        ),
        shape = RoundedCornerShape(12.dp),
        keyboardOptions = KeyboardOptions.Default.copy(imeAction = ImeAction.Done),
        trailingIcon = {
            if (giftCode.isNotEmpty()) {
                IconButton(onClick = { giftCode = "" }) {
                    Icon(
                        imageVector = Icons.Default.Clear,
                        contentDescription = "Clear",
                        tint = MaterialTheme.colorScheme.error
                    )
                }
            }
        }
    )
}

// ④ MAIN ACTIONS
@Composable
fun MainActionsSection() {
    var autoFireEnabled by remember { mutableStateOf(false) }
    var filterEnabled by remember { mutableStateOf(false) }

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Auto Fire Toggle
        Surface(
            modifier = Modifier.weight(1f),
            color = if (autoFireEnabled) PurplePrimary.copy(alpha = 0.2f) else SurfaceDark,
            shape = RoundedCornerShape(12.dp),
            border = if (autoFireEnabled) border(PurplePrimary) else null,
            onClick = { autoFireEnabled = !autoFireEnabled }
        ) {
            Column(
                modifier = Modifier.padding(12.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(
                    Icons.Default.Autorenew, 
                    contentDescription = null, 
                    tint = if (autoFireEnabled) PurplePrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    "Auto Fire", 
                    fontSize = 10.sp, 
                    color = if (autoFireEnabled) PurplePrimary else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // Paste
        Surface(
            modifier = Modifier.weight(1f),
            color = SurfaceDark,
            shape = RoundedCornerShape(12.dp),
            onClick = { /* Paste logic */ }
        ) {
            Column(
                modifier = Modifier.padding(12.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(
                    Icons.Default.ContentPaste, 
                    contentDescription = null, 
                    tint = NeonCyan,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text("Paste", fontSize = 10.sp, color = NeonCyan)
            }
        }

        // Filter Toggle
        Surface(
            modifier = Modifier.weight(1f),
            color = if (filterEnabled) NeonCyan.copy(alpha = 0.2f) else SurfaceDark,
            shape = RoundedCornerShape(12.dp),
            border = if (filterEnabled) border(NeonCyan) else null,
            onClick = { filterEnabled = !filterEnabled }
        ) {
            Column(
                modifier = Modifier.padding(12.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(
                    Icons.Default.FilterAlt, 
                    contentDescription = null, 
                    tint = if (filterEnabled) NeonCyan else MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    "Filter", 
                    fontSize = 10.sp, 
                    color = if (filterEnabled) NeonCyan else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // FIRE Button
        Button(
            onClick = { /* Fire Logic */ },
            modifier = Modifier
                .weight(1.5f)
                .height(64.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = NeonCyan,
                contentColor = Color.Black
            ),
            shape = RoundedCornerShape(12.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.LocalFireDepartment, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("FIRE", fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
            }
        }
    }
}

private fun border(color: Color) = androidx.compose.foundation.BorderStroke(1.dp, color)

// ⑤ QUICK ACTIONS
@Composable
fun QuickActionsSection() {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        QuickActionButton("Login All", Icons.Default.Login)
        QuickActionButton("Refresh", Icons.Default.Refresh)
        QuickActionButton("Gift Page", Icons.Default.CardGiftcard)
        QuickActionButton("Account", Icons.Default.Person)
        QuickActionButton("Home", Icons.Default.Home)
    }
}

@Composable
fun QuickActionButton(title: String, icon: ImageVector) {
    Surface(
        color = SurfaceDark,
        shape = RoundedCornerShape(12.dp),
        onClick = { /* Action Logic */ }
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(icon, contentDescription = null, tint = PurplePrimary, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text(title, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurface)
        }
    }
}

// ⑥ MANAGEMENT
@Composable
fun ManagementSection() {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Management", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
        
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            ManagementButton("Manage IDs", Icons.Default.ManageAccounts, Modifier.weight(1f))
            ManagementButton("BG Claimer", Icons.Default.CloudSync, Modifier.weight(1f))
            ManagementButton("Telegram", Icons.Default.Send, Modifier.weight(1f))
        }
    }
}

@Composable
fun ManagementButton(title: String, icon: ImageVector, modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier,
        color = SurfaceVariantDark,
        shape = RoundedCornerShape(8.dp),
        onClick = { /* Management Logic */ }
    ) {
        Column(
            modifier = Modifier.padding(vertical = 12.dp, horizontal = 4.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.onSurface, modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.height(6.dp))
            Text(title, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, color = MaterialTheme.colorScheme.onSurface)
        }
    }
}

// ⑦ CURRENT SESSION
@Composable
fun CurrentSessionSection() {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = SurfaceDark,
        shape = RoundedCornerShape(12.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, SurfaceVariantDark)
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Bolt, contentDescription = "Active", tint = Color.Yellow, modifier = Modifier.size(24.dp))
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text("ID 1 | User", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                    Text("Session Active", fontSize = 12.sp, color = NeonCyan)
                }
            }
            
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Surface(
                    color = MaterialTheme.colorScheme.error.copy(alpha = 0.2f),
                    shape = RoundedCornerShape(8.dp),
                    onClick = { /* Stop Logic */ }
                ) {
                    Text(
                        "STOP", 
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                        color = MaterialTheme.colorScheme.error,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                }
                
                Surface(
                    color = SurfaceVariantDark,
                    shape = RoundedCornerShape(8.dp),
                    onClick = { /* Refresh Logic */ }
                ) {
                    Icon(
                        Icons.Default.Refresh, 
                        contentDescription = "Refresh Session",
                        modifier = Modifier.padding(8.dp).size(16.dp),
                        tint = MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }
    }
}

// ⑧ OUTPUT / LOG WINDOW
@Composable
fun LogWindowSection() {
    Column {
        Text(
            text = "Output Logs", 
            style = MaterialTheme.typography.labelLarge, 
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(bottom = 8.dp)
        )
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(200.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(Color.Black)
                .border(1.dp, SurfaceVariantDark, RoundedCornerShape(12.dp))
                .padding(12.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                LogLine("[INFO] Waiting for input...", MaterialTheme.colorScheme.onSurfaceVariant)
                LogLine("[LOGIN] Success for ID 1", NeonCyan)
                LogLine("[PASTE] Code received: ASD89F7", Color.White)
                LogLine("[FIRE] Processing route...", Color.Yellow)
                LogLine("[SUCCESS] Gift claimed successfully.", Color.Green)
            }
        }
    }
}

@Composable
fun LogLine(text: String, color: Color) {
    Text(
        text = text,
        color = color,
        fontFamily = FontFamily.Monospace,
        fontSize = 12.sp
    )
}
