package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val PurplePrimary = Color(0xFF9D4EDD)
val NeonCyan = Color(0xFF00F5D4)
val DarkBackground = Color(0xFF121212)
val SurfaceDark = Color(0xFF1E1E1E)
val SurfaceVariantDark = Color(0xFF2C2C2C)
val ErrorRed = Color(0xFFFF4D4D)
val TextPrimary = Color(0xFFF5F5F5)
val TextSecondary = Color(0xFFA0A0A0)
