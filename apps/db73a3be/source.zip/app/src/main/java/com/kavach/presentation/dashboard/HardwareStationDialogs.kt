package com.kavach.presentation.dashboard

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.BrightnessMedium
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.NetworkCheck
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Sensors
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject

@Composable
internal fun StatusBadgePill(
    label: String,
    color: Color,
    showDot: Boolean = true,
    modifier: Modifier = Modifier
) {
    Surface(
        color = color.copy(alpha = 0.14f),
        shape = RoundedCornerShape(50),
        border = BorderStroke(1.dp, color.copy(alpha = 0.45f)),
        modifier = modifier
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            if (showDot) {
                Box(
                    modifier = Modifier
                        .size(6.dp)
                        .clip(CircleShape)
                        .background(color)
                )
            }
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall.copy(
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.sp
                ),
                color = color,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
internal fun ExpandableTelemetrySection(
    title: String = "Details",
    summaryBadge: String? = null,
    accentColor: Color = CyanAccent,
    initiallyExpanded: Boolean = false,
    content: @Composable () -> Unit
) {
    var expanded by remember { mutableStateOf(initiallyExpanded) }

    Surface(
        color = ConsoleBg,
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, BorderSubtleColor),
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { expanded = !expanded }
                    .padding(horizontal = 14.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold),
                        color = TextPrimaryColor
                    )
                    if (!summaryBadge.isNullOrBlank()) {
                        StatusBadgePill(label = summaryBadge, color = accentColor, showDot = false)
                    }
                }
                Icon(
                    imageVector = if (expanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                    contentDescription = if (expanded) "Collapse" else "Expand",
                    tint = TextSecondaryColor,
                    modifier = Modifier.size(18.dp)
                )
            }

            AnimatedVisibility(
                visible = expanded,
                enter = fadeIn() + expandVertically(),
                exit = fadeOut() + shrinkVertically()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(start = 14.dp, end = 14.dp, bottom = 14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    HorizontalDivider(color = BorderSubtleColor, thickness = 0.5.dp)
                    content()
                }
            }
        }
    }
}

@Composable
internal fun CleanMetricChip(
    label: String,
    value: String,
    valueColor: Color = TextPrimaryColor,
    modifier: Modifier = Modifier
) {
    Surface(
        color = ConsoleBg,
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, BorderSubtleColor),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                color = TextSecondaryColor,
                maxLines = 1
            )
            Text(
                text = value,
                style = MaterialTheme.typography.bodyMedium.copy(
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                ),
                color = valueColor,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
internal fun StationDialogHeader(
    icon: ImageVector,
    iconTint: Color,
    title: String,
    badgeText: String,
    badgeColor: Color,
    onRefresh: (() -> Unit)? = null
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.weight(1f)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = iconTint,
                modifier = Modifier.size(22.dp)
            )
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = TextPrimaryColor,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            StatusBadgePill(label = badgeText, color = badgeColor)
            if (onRefresh != null) {
                IconButton(
                    onClick = onRefresh,
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "Refresh",
                        tint = TextSecondaryColor,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun BatteryStationDialog(
    onDismissRequest: () -> Unit,
    viewModel: DashboardViewModel
) {
    var details by remember { mutableStateOf<JSONObject?>(null) }
    val scope = rememberCoroutineScope()

    fun refresh() {
        scope.launch(Dispatchers.IO) {
            details = viewModel.getBatteryStationDetails()
        }
    }

    LaunchedEffect(Unit) { refresh() }

    val d = details
    val pct = d?.optInt("percent", 100) ?: 0
    val isCharging = d?.optBoolean("isCharging", false) ?: false
    val accent = if (d != null && pct < 20) CoralError else EmeraldAccent

    AlertDialog(
        onDismissRequest = onDismissRequest,
        containerColor = CardBg,
        modifier = Modifier.testTag("dialog_battery_station"),
        title = {
            StationDialogHeader(
                icon = Icons.Default.BatteryChargingFull,
                iconTint = accent,
                title = "Battery",
                badgeText = if (d == null) "..." else if (isCharging) "$pct% CHARGING" else "$pct%",
                badgeColor = accent,
                onRefresh = { refresh() }
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                if (d == null) {
                    Text("Loading...", color = TextSecondaryColor, style = MaterialTheme.typography.bodySmall)
                } else {
                    val plugType = d.optString("plugType", "NONE")
                    val healthStr = d.optString("health", "GOOD")
                    val tempC = d.optDouble("temperatureC", 25.0)
                    val voltMv = d.optInt("voltageMv", 0)
                    val tech = d.optString("technology", "Li-ion")
                    val isPowerSave = d.optBoolean("isPowerSaveMode", false)
                    val isIgnoringDoze = d.optBoolean("isIgnoringBatteryOptimizations", false)

                    Surface(
                        color = ConsoleBg,
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(1.dp, BorderSubtleColor),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            LinearProgressIndicator(
                                progress = { (pct / 100f).coerceIn(0f, 1f) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(8.dp)
                                    .clip(RoundedCornerShape(4.dp)),
                                color = accent,
                                trackColor = BorderSubtleColor
                            )
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                CleanMetricChip(
                                    label = "Temp",
                                    value = String.format(java.util.Locale.US, "%.1f°C", tempC),
                                    valueColor = if (tempC > 42) AmberAccent else TextPrimaryColor,
                                    modifier = Modifier.weight(1f)
                                )
                                CleanMetricChip(
                                    label = "Power",
                                    value = if (plugType == "NONE") "Battery" else plugType,
                                    valueColor = CyanAccent,
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }

                    ExpandableTelemetrySection(
                        title = "Diagnostics",
                        summaryBadge = healthStr,
                        accentColor = accent
                    ) {
                        StationTelemetryGrid(
                            items = listOf(
                                "Voltage" to if (voltMv > 0) "$voltMv mV" else "N/A",
                                "Technology" to tech,
                                "Power Save" to if (isPowerSave) "ON" else "OFF",
                                "Doze Mode" to if (isIgnoringDoze) "Unrestricted" else "Standard"
                            )
                        )
                    }

                    Button(
                        onClick = {
                            scope.launch(Dispatchers.IO) {
                                viewModel.requestIgnoreBatteryOptimizations()
                                delay(300)
                                details = viewModel.getBatteryStationDetails()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isIgnoringDoze) CardElevatedBg else EmeraldAccent
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("btn_battery_optimization")
                    ) {
                        Text(
                            text = if (isIgnoringDoze) "Unrestricted Active" else "Allow Background Run",
                            color = if (isIgnoringDoze) EmeraldAccent else Color.Black,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismissRequest) {
                Text("Done", color = CyanAccent, fontWeight = FontWeight.SemiBold)
            }
        }
    )
}

@Composable
fun SensorsStationDialog(
    onDismissRequest: () -> Unit,
    viewModel: DashboardViewModel
) {
    var details by remember { mutableStateOf<JSONObject?>(null) }
    val scope = rememberCoroutineScope()

    LaunchedEffect(Unit) {
        while (true) {
            withContext(Dispatchers.IO) {
                details = viewModel.getSensorsStationDetails()
            }
            delay(1000)
        }
    }

    val d = details
    val count = d?.optInt("sensorCount", 0) ?: 0

    AlertDialog(
        onDismissRequest = onDismissRequest,
        containerColor = CardBg,
        modifier = Modifier.testTag("dialog_sensors_station"),
        title = {
            StationDialogHeader(
                icon = Icons.Default.Sensors,
                iconTint = CyanAccent,
                title = "Sensors",
                badgeText = if (d == null) "..." else "$count ACTIVE",
                badgeColor = CyanAccent,
                onRefresh = {
                    scope.launch(Dispatchers.IO) {
                        details = viewModel.getSensorsStationDetails()
                    }
                }
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                if (d == null) {
                    Text("Loading...", color = TextSecondaryColor, style = MaterialTheme.typography.bodySmall)
                } else {
                    val accel = d.optJSONObject("accelerometer") ?: JSONObject()
                    val gyro = d.optJSONObject("gyroscope") ?: JSONObject()
                    val mag = d.optJSONObject("magnetometer") ?: JSONObject()
                    val lux = d.optDouble("lightLux", 0.0)
                    val prox = d.optDouble("proximityCm", 5.0)

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        CleanMetricChip(
                            label = "Light",
                            value = String.format(java.util.Locale.US, "%.0f lx", lux),
                            valueColor = AmberAccent,
                            modifier = Modifier.weight(1f)
                        )
                        CleanMetricChip(
                            label = "Proximity",
                            value = String.format(java.util.Locale.US, "%.1f cm", prox),
                            valueColor = CyanAccent,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    ExpandableTelemetrySection(
                        title = "Axis Telemetry",
                        summaryBadge = "LIVE",
                        accentColor = EmeraldAccent,
                        initiallyExpanded = true
                    ) {
                        StationTelemetryGrid(
                            items = listOf(
                                "Accel" to String.format(
                                    java.util.Locale.US,
                                    "%.1f, %.1f, %.1f",
                                    accel.optDouble("x", 0.0),
                                    accel.optDouble("y", 0.0),
                                    accel.optDouble("z", 9.8)
                                ),
                                "Gyro" to String.format(
                                    java.util.Locale.US,
                                    "%.1f, %.1f, %.1f",
                                    gyro.optDouble("x", 0.0),
                                    gyro.optDouble("y", 0.0),
                                    gyro.optDouble("z", 0.0)
                                ),
                                "Mag" to String.format(
                                    java.util.Locale.US,
                                    "%.0f, %.0f, %.0f µT",
                                    mag.optDouble("x", 0.0),
                                    mag.optDouble("y", 0.0),
                                    mag.optDouble("z", 0.0)
                                )
                            )
                        )
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismissRequest) {
                Text("Done", color = CyanAccent, fontWeight = FontWeight.SemiBold)
            }
        }
    )
}

@Composable
fun DisplayStationDialog(
    onDismissRequest: () -> Unit,
    viewModel: DashboardViewModel
) {
    var details by remember { mutableStateOf<JSONObject?>(null) }
    var brightnessLevel by remember { mutableFloatStateOf(128f) }
    var autoBrightness by remember { mutableStateOf(false) }
    var screenTimeoutSec by remember { mutableIntStateOf(60) }
    var isWakeLockHeld by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    fun refresh() {
        scope.launch(Dispatchers.IO) {
            val d = viewModel.getDisplayStationDetails()
            details = d
            brightnessLevel = d.optInt("currentBrightness", 128).toFloat()
            autoBrightness = d.optBoolean("isAutoBrightness", false)
            screenTimeoutSec = d.optInt("screenTimeoutSec", 60)
            isWakeLockHeld = d.optBoolean("isWakeLockHeld", false)
        }
    }

    LaunchedEffect(Unit) { refresh() }

    val d = details
    val w = d?.optInt("widthPixels", 1080) ?: 1080
    val h = d?.optInt("heightPixels", 2400) ?: 2400
    val hz = d?.optDouble("refreshRateHz", 60.0) ?: 60.0

    AlertDialog(
        onDismissRequest = onDismissRequest,
        containerColor = CardBg,
        modifier = Modifier.testTag("dialog_display_station"),
        title = {
            StationDialogHeader(
                icon = Icons.Default.BrightnessMedium,
                iconTint = AmberAccent,
                title = "Display",
                badgeText = if (d == null) "..." else "${hz.toInt()} Hz",
                badgeColor = AmberAccent,
                onRefresh = { refresh() }
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                if (d == null) {
                    Text("Loading...", color = TextSecondaryColor, style = MaterialTheme.typography.bodySmall)
                } else {
                    val density = d.optInt("densityDpi", 420)
                    val canWrite = d.optBoolean("canWriteSystemSettings", false)

                    Surface(
                        color = ConsoleBg,
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(1.dp, BorderSubtleColor),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("Brightness", style = MaterialTheme.typography.labelMedium, color = TextSecondaryColor)
                                StatusBadgePill(
                                    label = "${((brightnessLevel / 255f) * 100).toInt()}%",
                                    color = AmberAccent,
                                    showDot = false
                                )
                            }
                            Slider(
                                value = brightnessLevel,
                                onValueChange = { brightnessLevel = it },
                                onValueChangeFinished = {
                                    scope.launch(Dispatchers.IO) {
                                        viewModel.setDisplayBrightness(brightnessLevel.toInt())
                                    }
                                },
                                valueRange = 0f..255f,
                                colors = SliderDefaults.colors(
                                    thumbColor = AmberAccent,
                                    activeTrackColor = AmberAccent,
                                    inactiveTrackColor = BorderSubtleColor
                                ),
                                modifier = Modifier.testTag("slider_station_brightness")
                            )

                            HorizontalDivider(color = BorderSubtleColor, thickness = 0.5.dp)

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("Auto Brightness", color = TextPrimaryColor, style = MaterialTheme.typography.bodyMedium)
                                Switch(
                                    checked = autoBrightness,
                                    onCheckedChange = { next ->
                                        autoBrightness = next
                                        scope.launch(Dispatchers.IO) {
                                            viewModel.setDisplayAutoBrightness(next)
                                        }
                                    },
                                    colors = SwitchDefaults.colors(
                                        checkedThumbColor = Color.Black,
                                        checkedTrackColor = EmeraldAccent
                                    )
                                )
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Text("Keep Awake", color = TextPrimaryColor, style = MaterialTheme.typography.bodyMedium)
                                    if (isWakeLockHeld) {
                                        StatusBadgePill(label = "30m", color = AmberAccent, showDot = false)
                                    }
                                }
                                Switch(
                                    checked = isWakeLockHeld,
                                    onCheckedChange = { next ->
                                        isWakeLockHeld = next
                                        scope.launch(Dispatchers.IO) {
                                            viewModel.toggleScreenWakeLock(next)
                                        }
                                    },
                                    colors = SwitchDefaults.colors(
                                        checkedThumbColor = Color.Black,
                                        checkedTrackColor = AmberAccent
                                    )
                                )
                            }
                        }
                    }

                    // Screen timeout selector
                    Surface(
                        color = ConsoleBg,
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(1.dp, BorderSubtleColor),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text("Timeout", style = MaterialTheme.typography.labelMedium, color = TextSecondaryColor)
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                listOf(15, 30, 60, 300).forEach { sec ->
                                    val selected = screenTimeoutSec == sec
                                    OutlinedButton(
                                        onClick = {
                                            screenTimeoutSec = sec
                                            scope.launch(Dispatchers.IO) {
                                                viewModel.setDisplayTimeout(sec)
                                            }
                                        },
                                        border = BorderStroke(1.dp, if (selected) AmberAccent else BorderSubtleColor),
                                        shape = RoundedCornerShape(10.dp),
                                        contentPadding = PaddingValues(0.dp),
                                        modifier = Modifier
                                            .weight(1f)
                                            .height(40.dp)
                                    ) {
                                        Text(
                                            text = if (sec >= 60) "${sec / 60}m" else "${sec}s",
                                            color = if (selected) AmberAccent else TextSecondaryColor,
                                            style = MaterialTheme.typography.labelMedium.copy(fontFamily = FontFamily.Monospace)
                                        )
                                    }
                                }
                            }
                        }
                    }

                    ExpandableTelemetrySection(
                        title = "Panel Specs",
                        summaryBadge = "${w}×${h}",
                        accentColor = CyanAccent
                    ) {
                        StationTelemetryGrid(
                            items = listOf(
                                "Resolution" to "${w} × ${h}",
                                "Density" to "$density dpi",
                                "Write Access" to if (canWrite) "Granted" else "Required"
                            )
                        )
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismissRequest) {
                Text("Done", color = CyanAccent, fontWeight = FontWeight.SemiBold)
            }
        }
    )
}

@Composable
fun NetworkStationDialog(
    onDismissRequest: () -> Unit,
    viewModel: DashboardViewModel
) {
    var details by remember { mutableStateOf<JSONObject?>(null) }
    var modStatus by remember { mutableStateOf<JSONObject?>(null) }
    var blockScreenConfig by remember { mutableStateOf<JSONObject?>(null) }
    var exportMessage by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    fun refresh() {
        scope.launch(Dispatchers.IO) {
            details = viewModel.getNetworkStationDetails()
            modStatus = viewModel.getNetworkModerationStatus()
            blockScreenConfig = viewModel.getBlockScreenConfig()
        }
    }

    LaunchedEffect(Unit) { refresh() }

    val d = details
    val ms = modStatus
    val transport = d?.optString("activeTransport", "OFFLINE") ?: "..."
    val isConnected = d?.optBoolean("isConnected", false) ?: false
    val isVpnActive = ms?.optBoolean("isVpnActive", false) ?: false
    val totalBlocked = ms?.optLong("totalBlocked", 0L) ?: 0L
    val totalIntercepted = ms?.optLong("totalIntercepted", 0L) ?: 0L
    val blacklistedCount = ms?.optInt("blacklistedDomainsCount", 0) ?: 0
    val isBlockScreenOn = blockScreenConfig?.optBoolean("enabled", true) ?: true

    AlertDialog(
        onDismissRequest = onDismissRequest,
        containerColor = CardBg,
        modifier = Modifier.testTag("dialog_network_station"),
        title = {
            StationDialogHeader(
                icon = Icons.Default.NetworkCheck,
                iconTint = if (isConnected) CyanAccent else CoralError,
                title = "Network",
                badgeText = transport,
                badgeColor = if (isConnected) EmeraldAccent else CoralError,
                onRefresh = { refresh() }
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Primary Moderation & Firewall Card
                Surface(
                    color = ConsoleBg,
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(
                        1.dp,
                        if (isVpnActive) EmeraldAccent.copy(alpha = 0.5f) else BorderSubtleColor
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text(
                                    text = "DNS Firewall",
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                    color = TextPrimaryColor
                                )
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    StatusBadgePill(
                                        label = if (isVpnActive) "SHIELDED" else "PAUSED",
                                        color = if (isVpnActive) EmeraldAccent else AmberAccent
                                    )
                                    StatusBadgePill(
                                        label = "$blacklistedCount RULES",
                                        color = CyanAccent,
                                        showDot = false
                                    )
                                }
                            }

                            Switch(
                                checked = isVpnActive,
                                onCheckedChange = { enabled ->
                                    scope.launch(Dispatchers.IO) {
                                        viewModel.toggleNetworkModeratorVpn(enabled)
                                        delay(200)
                                        modStatus = viewModel.getNetworkModerationStatus()
                                    }
                                },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = Color.Black,
                                    checkedTrackColor = EmeraldAccent
                                )
                            )
                        }

                        if (isVpnActive) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                CleanMetricChip(
                                    label = "Blocked",
                                    value = "$totalBlocked",
                                    valueColor = if (totalBlocked > 0) CoralError else TextPrimaryColor,
                                    modifier = Modifier.weight(1f)
                                )
                                CleanMetricChip(
                                    label = "Queries",
                                    value = "$totalIntercepted",
                                    valueColor = CyanAccent,
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }

                        HorizontalDivider(color = BorderSubtleColor, thickness = 0.5.dp)

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Block Screen",
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextPrimaryColor
                            )
                            Switch(
                                checked = isBlockScreenOn,
                                onCheckedChange = { checked ->
                                    scope.launch(Dispatchers.IO) {
                                        blockScreenConfig = viewModel.setBlockScreenConfig(checked)
                                    }
                                },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = Color.Black,
                                    checkedTrackColor = EmeraldAccent
                                )
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedButton(
                                onClick = {
                                    scope.launch(Dispatchers.IO) {
                                        val res = viewModel.exportDnsLogs("csv")
                                        val count = res.optInt("exportedCount", 0)
                                        exportMessage = "Saved $count CSV"
                                    }
                                },
                                border = BorderStroke(1.dp, CyanAccent.copy(alpha = 0.5f)),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(40.dp)
                            ) {
                                Text("Export CSV", fontSize = 11.sp, color = CyanAccent, fontWeight = FontWeight.SemiBold)
                            }
                            OutlinedButton(
                                onClick = {
                                    scope.launch(Dispatchers.IO) {
                                        val res = viewModel.exportDnsLogs("json")
                                        val count = res.optInt("exportedCount", 0)
                                        exportMessage = "Saved $count JSON"
                                    }
                                },
                                border = BorderStroke(1.dp, PurpleAccent.copy(alpha = 0.5f)),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(40.dp)
                            ) {
                                Text("Export JSON", fontSize = 11.sp, color = PurpleAccent, fontWeight = FontWeight.SemiBold)
                            }
                        }

                        if (!exportMessage.isNullOrBlank()) {
                            StatusBadgePill(label = exportMessage!!, color = EmeraldAccent)
                        }
                    }
                }

                // Collapsible Network Interface Telemetry
                if (d != null) {
                    val isMetered = d.optBoolean("isMetered", false)
                    val wifi = d.optJSONObject("wifi")
                    val cell = d.optJSONObject("cellular")
                    val ips = d.optJSONArray("localIpv4Addresses")
                    val primaryIp = if (ips != null && ips.length() > 0) ips.optString(0) else null

                    ExpandableTelemetrySection(
                        title = "Connection Telemetry",
                        summaryBadge = primaryIp ?: if (isMetered) "Metered" else "Unmetered",
                        accentColor = CyanAccent
                    ) {
                        val rows = mutableListOf(
                            "Status" to if (isConnected) "Connected" else "Offline",
                            "Metered" to if (isMetered) "Yes" else "No"
                        )
                        if (wifi != null) {
                            rows.add("Wi-Fi" to wifi.optString("ssid", "Connected"))
                            rows.add("Signal" to "${wifi.optInt("rssiDbm")} dBm • ${wifi.optInt("linkSpeedMbps")} Mbps")
                        }
                        if (cell != null) {
                            rows.add("Carrier" to "${cell.optString("carrierName")} (${cell.optString("networkType")})")
                        }
                        if (ips != null && ips.length() > 0) {
                            val allIps = (0 until ips.length()).joinToString(", ") { ips.optString(it) }
                            rows.add("IPv4" to allIps)
                        }
                        StationTelemetryGrid(items = rows)
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismissRequest) {
                Text("Done", color = CyanAccent, fontWeight = FontWeight.SemiBold)
            }
        }
    )
}

@Composable
fun AudioStationDialog(
    onDismissRequest: () -> Unit,
    viewModel: DashboardViewModel
) {
    var details by remember { mutableStateOf<JSONObject?>(null) }
    var selectedRinger by remember { mutableStateOf("NORMAL") }
    val scope = rememberCoroutineScope()

    fun refresh() {
        scope.launch(Dispatchers.IO) {
            val d = viewModel.getAudioStationDetails()
            details = d
            selectedRinger = d.optString("ringerMode", "NORMAL")
        }
    }

    LaunchedEffect(Unit) { refresh() }

    val d = details
    AlertDialog(
        onDismissRequest = onDismissRequest,
        containerColor = CardBg,
        modifier = Modifier.testTag("dialog_audio_station"),
        title = {
            StationDialogHeader(
                icon = Icons.AutoMirrored.Filled.VolumeUp,
                iconTint = PurpleAccent,
                title = "Audio",
                badgeText = selectedRinger,
                badgeColor = PurpleAccent,
                onRefresh = { refresh() }
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                if (d == null) {
                    Text("Loading...", color = TextSecondaryColor, style = MaterialTheme.typography.bodySmall)
                } else {
                    Surface(
                        color = ConsoleBg,
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(1.dp, BorderSubtleColor),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text("Ringer", style = MaterialTheme.typography.labelMedium, color = TextSecondaryColor)
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                listOf("NORMAL", "VIBRATE", "SILENT").forEach { mode ->
                                    val selected = selectedRinger.equals(mode, ignoreCase = true)
                                    OutlinedButton(
                                        onClick = {
                                            selectedRinger = mode
                                            scope.launch(Dispatchers.IO) {
                                                viewModel.setRingerMode(mode)
                                            }
                                        },
                                        border = BorderStroke(1.dp, if (selected) PurpleAccent else BorderSubtleColor),
                                        shape = RoundedCornerShape(10.dp),
                                        contentPadding = PaddingValues(0.dp),
                                        modifier = Modifier
                                            .weight(1f)
                                            .height(40.dp)
                                    ) {
                                        Text(
                                            text = mode,
                                            color = if (selected) PurpleAccent else TextSecondaryColor,
                                            fontSize = 11.sp,
                                            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium
                                        )
                                    }
                                }
                            }
                        }
                    }

                    val streams = d.optJSONArray("streams")
                    if (streams != null) {
                        Surface(
                            color = ConsoleBg,
                            shape = RoundedCornerShape(14.dp),
                            border = BorderStroke(1.dp, BorderSubtleColor),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(14.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text("Streams", style = MaterialTheme.typography.labelMedium, color = TextSecondaryColor)
                                for (i in 0 until streams.length()) {
                                    val st = streams.optJSONObject(i) ?: continue
                                    val sName = st.optString("stream")
                                    var streamPct by remember(st) { mutableFloatStateOf(st.optInt("percentage").toFloat()) }

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        Text(
                                            text = sName,
                                            style = MaterialTheme.typography.labelMedium,
                                            color = TextPrimaryColor,
                                            modifier = Modifier.width(62.dp),
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Slider(
                                            value = streamPct,
                                            onValueChange = { streamPct = it },
                                            onValueChangeFinished = {
                                                scope.launch(Dispatchers.IO) {
                                                    viewModel.setAudioStreamVolume(sName, streamPct.toInt())
                                                }
                                            },
                                            valueRange = 0f..100f,
                                            colors = SliderDefaults.colors(
                                                thumbColor = PurpleAccent,
                                                activeTrackColor = PurpleAccent,
                                                inactiveTrackColor = BorderSubtleColor
                                            ),
                                            modifier = Modifier
                                                .weight(1f)
                                                .height(30.dp)
                                        )
                                        Text(
                                            text = "${streamPct.toInt()}%",
                                            style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace),
                                            color = PurpleAccent,
                                            modifier = Modifier.width(36.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismissRequest) {
                Text("Done", color = CyanAccent, fontWeight = FontWeight.SemiBold)
            }
        }
    )
}

@Composable
internal fun StationTelemetryGrid(
    items: List<Pair<String, String>>
) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        items.forEach { (label, value) ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = label,
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondaryColor
                )
                Spacer(modifier = Modifier.width(12.dp))
                Text(
                    text = value,
                    style = MaterialTheme.typography.bodySmall.copy(
                        fontWeight = FontWeight.SemiBold,
                        fontFamily = FontFamily.Monospace
                    ),
                    color = TextPrimaryColor,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}
