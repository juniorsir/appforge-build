package com.kavach.network

import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.HttpURLConnection
import java.net.InetAddress
import java.net.URL
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ConcurrentLinkedDeque

data class SiteMetadataVerdict(
    val domain: String,
    val rootDomain: String,
    val isAdult: Boolean,
    val confidenceScore: Int,
    val triggerSource: String, // TLD_HEURISTIC, BRAND_STEM, HTML_METADATA, RTA_RATING_TAG, FAMILY_DNS_1_1_1_3, BROWSER_UI_SCAN, CLEAN
    val pageTitle: String = "",
    val metaDescription: String = "",
    val metaKeywords: String = "",
    val rtaRating: String = "",
    val familyDnsBlocked: Boolean = false,
    val matchedIndicators: List<String> = emptyList(),
    val inspectedAtMs: Long = System.currentTimeMillis()
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("domain", domain)
        put("rootDomain", rootDomain)
        put("isAdult", isAdult)
        put("confidenceScore", confidenceScore)
        put("triggerSource", triggerSource)
        put("pageTitle", pageTitle)
        put("metaDescription", metaDescription)
        put("metaKeywords", metaKeywords)
        put("rtaRating", rtaRating)
        put("familyDnsBlocked", familyDnsBlocked)
        put("matchedIndicators", JSONArray(matchedIndicators))
        put("inspectedAtMs", inspectedAtMs)
    }
}

/**
 * 4-Layer Autonomous Site Metadata & Adult Content Classifier Engine:
 *  1. Fast Domain, Subdomain, TLD (.porn, .xxx, .sex, .adult, .cam) & Cross-TLD Brand Heuristics
 *  2. Live HTML <head> Metadata (<title>, <meta description>, <meta keywords>, RTA rating, 2257 age gates)
 *  3. Accessibility Browser Page-Title & On-Screen 18+ Age-Gate Scanner
 *  4. Cloudflare Family-Safe DNS (1.1.1.3 / 1.0.0.3) Zero-IP Sinkhole Verification
 */
class SiteMetadataAnalyzer(
    private val onAutoBlacklistDomain: (domain: String, rootDomain: String, verdict: SiteMetadataVerdict, companionCdns: List<String>) -> Unit
) {
    private val TAG = "SiteMetadataAnalyzer"
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    // Cache of already-inspected domains -> SiteMetadataVerdict
    private val verdictCache = ConcurrentHashMap<String, SiteMetadataVerdict>()
    // Domains currently being fetched asynchronously to avoid duplicate requests
    private val inFlightDomains = ConcurrentHashMap.newKeySet<String>()
    // Rolling window of recently queried domains (last 8 seconds) to correlate video/image CDNs
    private data class RecentDnsStamp(val domain: String, val timestampMs: Long)
    private val recentQueriedDomains = ConcurrentLinkedDeque<RecentDnsStamp>()

    // Safe infrastructure domains that should never be scraped or false-positived
    private val safeInfrastructureSuffixes = setOf(
        "google.com", "googleapis.com", "gstatic.com", "googleusercontent.com",
        "cloudflare.com", "cloudflareinsights.com", "cloudflare-dns.com",
        "microsoft.com", "apple.com", "icloud.com", "amazonaws.com", "cloudfront.net",
        "akamai.net", "akamaized.net", "fastly.net", "github.com", "githubusercontent.com",
        "wikipedia.org", "wikimedia.org", "mozilla.org", "mozilla.net", "firefox.com",
        "whatsapp.net", "whatsapp.com", "telegram.org", "signal.org",
        "android.com", "gvt1.com", "gvt2.com", "1e100.net", "in-addr.arpa", "ip6.arpa",
        "trycloudflare.com"
    )

    // Layer 1A: Explicit Adult TLDs
    private val adultTlds = setOf(
        "porn", "xxx", "sex", "adult", "cam", "cams", "erotica", "sexy", "strip"
    )

    // Layer 1B: Known Adult Brand Stems & Adult Ad/Video CDN Networks (matches across ANY TLD like .mov, .com, .tv, .io, .net)
    private val adultBrandAndCdnStems = setOf(
        "pornhub", "phncdn", "xvideos", "xv-cdn", "xnxx", "xnxx-cdn",
        "xhamster", "xhcdn", "redtube", "youporn", "spankbang", "sb-cd",
        "stripchat", "doppiocdn", "saawsedge", "rmhfrtnd", "whitetrafsa",
        "xxxiijmp", "magsrv", "zerodayromance", "tikporn", "pnperf", "pnstat",
        "chaturbate", "highwebmedia", "bongacams", "cam4", "camsoda",
        "myfreecams", "livejasmin", "flirt4free", "jerkmate", "imlive",
        "onlyfans", "fansly", "manyvids", "clips4sale", "fapello", "erome",
        "coomer", "simpcity", "eporner", "hqporner", "beeg", "tnaflix",
        "empflix", "motherless", "redgifs", "rule34", "nhentai", "hanime",
        "hentaihaven", "brazzers", "realitykings", "mofos", "bangbros",
        "naughtyamerica", "vixen", "blacked", "tushy", "teamskeet", "adulttime",
        "exoclick", "exosrv", "juicyads", "trafficjunky", "trafficstars",
        "plugrush", "ero-advertising", "adxpansion", "crakrevenue", "awempire",
        "xlovecam", "streamate", "naiadsystems", "bcvcdn"
    )

    // Exact known adult short domains where stem matching alone might be ambiguous
    private val exactAdultRootDomains = setOf(
        "bang.com", "tik.porn", "sex.com", "porn.com", "tube8.com", "xtube.com",
        "thumbzilla.com", "fuq.com", "apetube.com", "drtuber.com", "nuvid.com",
        "sunporno.com", "txxx.com", "upornia.com", "vjav.com", "javhd.com",
        "missav.com", "jable.tv", "supjav.com", "dmm.co.jp", "fanza.com"
    )

    // Layer 1C: High-confidence adult substring tokens in domain/subdomain labels
    private val adultHostnameTokens = listOf(
        "tikporn", "porno", "pornhd", "pornvid", "xxxvid", "xxxcam",
        "sexvid", "sexcam", "sextube", "camgirl", "camwhore", "livecam",
        "nsfw", "hentai", "javhd", "xvideo", "freebrazzers", "milf",
        "stripchat", "chaturbate", "brazzers", "redtube", "youporn",
        "xhamster", "spankbang", "onlyfans", "faphouse", "rule34"
    )

    // Safe English words containing substrings like "sex", "ass", "tit", "anal", "cum"
    private val safeSubstringAllowlist = listOf(
        "essex", "sussex", "middlesex", "wessex", "unisex", "sexton", "sextant",
        "analytics", "analysis", "analyze", "analyzer", "analog", "analogy", "canal", "banal", "arsenal",
        "document", "documentation", "circum", "accumulate", "cumulative", "encumber", "cucumber",
        "associate", "assistant", "assembly", "assert", "assign", "assume", "assure", "asset",
        "classic", "classify", "classroom", "passage", "passenger", "massive", "massage", "embassy", "compass",
        "title", "subtitle", "entitle", "institute", "constitution", "substitute", "attitude", "latitude", "altitude", "gratitude", "multitude",
        "cockpit", "peacock", "hancock", "babcock", "hitchcock", "weathercock",
        "scunthorpe", "penistone", "dickinson", "dickens", "therapist", "shitake"
    )

    // Layer 2 & 3: HTML Metadata & Page Title Adult Keyword Weights
    private val metadataAdultKeywords: Map<String, Int> = mapOf(
        "rta-5042-1996-1400-1577-rta" to 100,
        "18 u.s.c. 2257" to 95,
        "2257 exemption" to 95,
        "porn" to 55,
        "porno" to 60,
        "pornography" to 70,
        "xxx" to 55,
        "sex videos" to 75,
        "free sex" to 70,
        "fuck videos" to 80,
        "hardcore sex" to 85,
        "live sex cams" to 85,
        "adult cams" to 80,
        "cam girls" to 75,
        "naked girls" to 75,
        "nude cams" to 80,
        "hentai" to 65,
        "nsfw" to 50,
        "erotic videos" to 65,
        "adult video" to 65,
        "explicit sexual" to 80,
        "xvideos" to 90,
        "pornhub" to 90,
        "xnxx" to 90,
        "stripchat" to 90,
        "chaturbate" to 90,
        "onlyfans" to 75,
        "blowjob" to 75,
        "cumshot" to 85,
        "creampie" to 80,
        "gangbang" to 85,
        "masturbation" to 65,
        "milf" to 60,
        "threesome" to 65,
        "lesbian sex" to 75,
        "anal sex" to 80,
        "amateur porn" to 85,
        "hd porn" to 85,
        "free porn" to 85,
        "sex tube" to 80,
        "porn tube" to 85,
        "are you 18" to 45,
        "18 years of age" to 45,
        "must be 18+" to 50,
        "adult entertainment" to 60
    )

    fun extractRootDomain(rawHost: String): String {
        val host = rawHost.trim().lowercase(Locale.US).trimEnd('.')
        val parts = host.split(".")
        if (parts.size <= 2) return host
        val secondLast = parts[parts.size - 2]
        val last = parts.last()
        return if (secondLast in setOf("co", "com", "org", "net", "gov", "edu") && last.length == 2 && parts.size >= 3) {
            "${parts[parts.size - 3]}.$secondLast.$last"
        } else {
            "$secondLast.$last"
        }
    }

    fun isSafeInfrastructureDomain(domain: String): Boolean {
        val clean = domain.trim().lowercase(Locale.US).trimEnd('.')
        if (clean.isEmpty()) return true
        return safeInfrastructureSuffixes.any { clean == it || clean.endsWith(".$it") }
    }

    fun recordRecentDnsQuery(domain: String) {
        val clean = domain.trim().lowercase(Locale.US).trimEnd('.')
        if (clean.isEmpty() || isSafeInfrastructureDomain(clean)) return
        val now = System.currentTimeMillis()
        recentQueriedDomains.addLast(RecentDnsStamp(clean, now))
        while (recentQueriedDomains.size > 120) {
            recentQueriedDomains.pollFirst()
        }
    }

    /**
     * Finds any suspicious CDN / media / ad domains queried within the last 6 seconds
     * when a primary adult site is detected.
     */
    private fun findCoOccurringSuspectCdns(primaryRoot: String): List<String> {
        val now = System.currentTimeMillis()
        val results = mutableSetOf<String>()
        for (item in recentQueriedDomains) {
            if (now - item.timestampMs <= 6500L) {
                val root = extractRootDomain(item.domain)
                if (root != primaryRoot && !isSafeInfrastructureDomain(root)) {
                    val d = item.domain
                    if (d.contains("cdn") || d.contains("hls") || d.contains("edge") ||
                        d.contains("video") || d.contains("media") || d.contains("img") ||
                        d.contains("static") || d.contains("stream") || d.contains("go.") ||
                        d.contains("creative.") || d.contains("engine.") || d.contains("ratecams")
                    ) {
                        results.add(root)
                    }
                }
            }
        }
        return results.toList()
    }

    /**
     * Layer 1: Synchronous (<0.5ms) Domain, TLD & Cross-TLD Brand Heuristic Check.
     * Called directly inside shouldBlockDomain() before DNS resolution proceeds.
     */
    fun evaluateFastDomainHeuristics(rawDomain: String): SiteMetadataVerdict? {
        val domain = rawDomain.trim().lowercase(Locale.US).trimEnd('.')
        if (domain.isEmpty() || isSafeInfrastructureDomain(domain)) return null

        verdictCache[domain]?.let { cached ->
            if (cached.isAdult) return cached
        }

        val rootDomain = extractRootDomain(domain)
        verdictCache[rootDomain]?.let { cachedRoot ->
            if (cachedRoot.isAdult) return cachedRoot
        }

        val parts = domain.split(".")
        val tld = parts.lastOrNull().orEmpty()

        // 1A. Check Adult TLD (.porn, .xxx, .sex, .adult, .cam, .cams)
        if (tld in adultTlds) {
            val verdict = SiteMetadataVerdict(
                domain = domain,
                rootDomain = rootDomain,
                isAdult = true,
                confidenceScore = 98,
                triggerSource = "TLD_HEURISTIC",
                matchedIndicators = listOf("Adult TLD '.$tld' ($rootDomain)")
            )
            cacheAndTriggerBlock(verdict)
            return verdict
        }

        // 1B. Check exact adult root domains (e.g., bang.com, tik.porn)
        if (rootDomain in exactAdultRootDomains) {
            val verdict = SiteMetadataVerdict(
                domain = domain,
                rootDomain = rootDomain,
                isAdult = true,
                confidenceScore = 96,
                triggerSource = "BRAND_STEM",
                matchedIndicators = listOf("Known adult root domain '$rootDomain'")
            )
            cacheAndTriggerBlock(verdict)
            return verdict
        }

        // 1C. Check Cross-TLD Brand Stems & Adult CDN Networks (e.g. stripchat.mov, doppiocdn.com, xxxiijmp.com)
        for (label in parts) {
            if (label in adultBrandAndCdnStems) {
                val verdict = SiteMetadataVerdict(
                    domain = domain,
                    rootDomain = rootDomain,
                    isAdult = true,
                    confidenceScore = 95,
                    triggerSource = "BRAND_STEM",
                    matchedIndicators = listOf("Adult brand/CDN stem '$label' in '$domain'")
                )
                cacheAndTriggerBlock(verdict)
                return verdict
            }
        }

        // 1D. Check high-confidence adult tokens inside hostname labels (excluding safe English words)
        val isSafeWord = safeSubstringAllowlist.any { domain.contains(it) }
        if (!isSafeWord) {
            for (token in adultHostnameTokens) {
                if (domain.contains(token)) {
                    val verdict = SiteMetadataVerdict(
                        domain = domain,
                        rootDomain = rootDomain,
                        isAdult = true,
                        confidenceScore = 90,
                        triggerSource = "TLD_HEURISTIC",
                        matchedIndicators = listOf("Hostname adult token '$token' in '$domain'")
                    )
                    cacheAndTriggerBlock(verdict)
                    return verdict
                }
            }
        }

        return null
    }

    /**
     * Layer 2 (Async): Launches background HTML <head> Metadata & RTA tag inspection
     * for unknown domains visited while ADULT filtering is active.
     */
    fun inspectDomainMetadataAsync(rawDomain: String) {
        val domain = rawDomain.trim().lowercase(Locale.US).trimEnd('.')
        if (domain.isEmpty() || isSafeInfrastructureDomain(domain)) return
        val rootDomain = extractRootDomain(domain)
        if (verdictCache.containsKey(domain) || verdictCache.containsKey(rootDomain)) return
        if (!inFlightDomains.add(domain)) return

        scope.launch {
            try {
                // Always verify against Cloudflare Family DNS (1.1.1.3) + HTML <head> Metadata
                // so adult sites are detected and blocked even if the local VPN tunnel is turned off!
                val verdict = fetchAndAnalyzeSiteMetadata(domain, checkFamilyDns = true)
                verdictCache[domain] = verdict
                if (verdict.isAdult) {
                    verdictCache[rootDomain] = verdict
                    cacheAndTriggerBlock(verdict)
                }
            } catch (_: Throwable) {
            } finally {
                inFlightDomains.remove(domain)
            }
        }
    }

    /**
     * Layer 3: Live Browser UI / Page Title / Age-Gate Scanner.
     * Called by PerAppNetworkMonitor when Accessibility detects a browser URL + page title / visible text.
     */
    fun evaluateBrowserPageContext(
        rawUrlOrDomain: String,
        pageTitle: String,
        screenTextSample: String = ""
    ): SiteMetadataVerdict? {
        var cleanHost = rawUrlOrDomain.trim().lowercase(Locale.US)
        if (cleanHost.startsWith("http://")) cleanHost = cleanHost.removePrefix("http://")
        if (cleanHost.startsWith("https://")) cleanHost = cleanHost.removePrefix("https://")
        cleanHost = cleanHost.substringBefore("/").substringBefore("?").substringBefore("#").trimEnd('.')
        if (cleanHost.startsWith("www.")) cleanHost = cleanHost.removePrefix("www.")
        if (cleanHost.startsWith("m.")) cleanHost = cleanHost.removePrefix("m.")

        if (cleanHost.isEmpty() || isSafeInfrastructureDomain(cleanHost)) return null

        // Check fast domain heuristics first
        evaluateFastDomainHeuristics(cleanHost)?.let { return it }

        val combinedText = "$pageTitle $screenTextSample".lowercase(Locale.US)
        if (combinedText.isBlank()) return null

        var score = 0
        val matched = mutableListOf<String>()
        for ((kw, weight) in metadataAdultKeywords) {
            if (containsKeywordBounded(combinedText, kw)) {
                score += weight
                matched.add("Browser UI/Title matched '$kw' (+$weight)")
            }
        }

        if (score >= 55) {
            val rootDomain = extractRootDomain(cleanHost)
            val verdict = SiteMetadataVerdict(
                domain = cleanHost,
                rootDomain = rootDomain,
                isAdult = true,
                confidenceScore = score.coerceAtMost(100),
                triggerSource = "BROWSER_UI_SCAN",
                pageTitle = pageTitle,
                matchedIndicators = matched
            )
            cacheAndTriggerBlock(verdict)
            return verdict
        }
        return null
    }

    /**
     * Layer 4: Called when Cloudflare Family DNS (1.1.1.3 / 1.0.0.3) returns 0.0.0.0 sinkhole
     * for a domain.
     */
    fun onFamilyDnsSinkholeDetected(rawDomain: String): SiteMetadataVerdict {
        val domain = rawDomain.trim().lowercase(Locale.US).trimEnd('.')
        val rootDomain = extractRootDomain(domain)
        val verdict = SiteMetadataVerdict(
            domain = domain,
            rootDomain = rootDomain,
            isAdult = true,
            confidenceScore = 95,
            triggerSource = "FAMILY_DNS_1_1_1_3",
            familyDnsBlocked = true,
            matchedIndicators = listOf("Cloudflare Family DNS (1.1.1.3) sinkholed '$domain' -> 0.0.0.0")
        )
        cacheAndTriggerBlock(verdict)
        return verdict
    }

    /**
     * Full on-demand or background HTML <head> Metadata + RTA Tag + Family DNS Analyzer.
     */
    fun fetchAndAnalyzeSiteMetadata(rawTarget: String, checkFamilyDns: Boolean = true): SiteMetadataVerdict {
        var cleanHost = rawTarget.trim().lowercase(Locale.US)
        val targetUrl = if (cleanHost.startsWith("http://") || cleanHost.startsWith("https://")) {
            cleanHost
        } else {
            "https://$cleanHost"
        }
        if (cleanHost.startsWith("http://")) cleanHost = cleanHost.removePrefix("http://")
        if (cleanHost.startsWith("https://")) cleanHost = cleanHost.removePrefix("https://")
        cleanHost = cleanHost.substringBefore("/").substringBefore("?").substringBefore("#").trimEnd('.')
        if (cleanHost.startsWith("www.")) cleanHost = cleanHost.removePrefix("www.")
        if (cleanHost.startsWith("m.")) cleanHost = cleanHost.removePrefix("m.")

        val rootDomain = extractRootDomain(cleanHost)
        val indicators = mutableListOf<String>()
        var score = 0
        var primaryTrigger = "CLEAN"

        // 1. Check domain/TLD heuristics
        evaluateFastDomainHeuristics(cleanHost)?.let { fastVerdict ->
            score += fastVerdict.confidenceScore
            indicators.addAll(fastVerdict.matchedIndicators)
            primaryTrigger = fastVerdict.triggerSource
        }

        // 2. Optional Cloudflare Family DNS (1.1.1.3) check
        var familySinkholed = false
        if (checkFamilyDns && cleanHost.isNotEmpty()) {
            familySinkholed = queryCloudflareFamilyDnsSinkhole(cleanHost)
            if (familySinkholed) {
                score += 90
                indicators.add("Cloudflare Family DNS (1.1.1.3) returned 0.0.0.0 sinkhole")
                if (primaryTrigger == "CLEAN") primaryTrigger = "FAMILY_DNS_1_1_1_3"
            }
        }

        // 3. Fetch first 24 KB of HTML <head> to extract <title>, <meta description>, <meta keywords>, and RTA tags
        var title = ""
        var description = ""
        var keywords = ""
        var rtaRating = ""

        val htmlSnippet = fetchHtmlHeadSnippet(targetUrl) ?: fetchHtmlHeadSnippet("http://$cleanHost")
        if (!htmlSnippet.isNullOrBlank()) {
            title = extractRegexGroup(htmlSnippet, Regex("<title[^>]*>(.*?)</title>", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)))
            description = extractMetaContent(htmlSnippet, "description")
                .ifEmpty { extractMetaPropertyContent(htmlSnippet, "og:description") }
            keywords = extractMetaContent(htmlSnippet, "keywords")
            rtaRating = extractMetaContent(htmlSnippet, "rating")
                .ifEmpty { extractMetaContent(htmlSnippet, "RTA") }

            if (title.isEmpty()) {
                title = extractMetaPropertyContent(htmlSnippet, "og:title")
            }

            // Check explicit RTA / adult meta rating tag
            val ratingLower = rtaRating.lowercase(Locale.US)
            if (ratingLower.contains("rta-5042") ||
                ratingLower == "adult" ||
                ratingLower == "mature" ||
                ratingLower == "restricted" ||
                htmlSnippet.contains("RTA-5042-1996-1400-1577-RTA", ignoreCase = true)
            ) {
                score += 100
                if (rtaRating.isEmpty()) rtaRating = "RTA-5042-1996-1400-1577-RTA"
                indicators.add("Adult Rating Meta Tag detected: '$rtaRating'")
                primaryTrigger = "RTA_RATING_TAG"
            }

            // Scan extracted metadata text for adult terms
            val combinedMeta = "$title | $description | $keywords".lowercase(Locale.US)
            for ((kw, weight) in metadataAdultKeywords) {
                if (containsKeywordBounded(combinedMeta, kw)) {
                    score += weight
                    indicators.add("HTML Metadata matched '$kw' (+$weight)")
                    if (primaryTrigger == "CLEAN") primaryTrigger = "HTML_METADATA"
                }
            }
        }

        val finalScore = score.coerceIn(0, 100)
        val isAdult = finalScore >= 50

        val verdict = SiteMetadataVerdict(
            domain = cleanHost,
            rootDomain = rootDomain,
            isAdult = isAdult,
            confidenceScore = finalScore,
            triggerSource = if (isAdult && primaryTrigger == "CLEAN") "HTML_METADATA" else primaryTrigger,
            pageTitle = title.take(180),
            metaDescription = description.take(260),
            metaKeywords = keywords.take(220),
            rtaRating = rtaRating.take(80),
            familyDnsBlocked = familySinkholed,
            matchedIndicators = indicators
        )

        verdictCache[cleanHost] = verdict
        if (isAdult) {
            verdictCache[rootDomain] = verdict
            cacheAndTriggerBlock(verdict)
        }
        return verdict
    }

    private fun cacheAndTriggerBlock(verdict: SiteMetadataVerdict) {
        verdictCache[verdict.domain] = verdict
        verdictCache[verdict.rootDomain] = verdict
        val companionCdns = findCoOccurringSuspectCdns(verdict.rootDomain)
        try {
            onAutoBlacklistDomain(verdict.domain, verdict.rootDomain, verdict, companionCdns)
        } catch (t: Throwable) {
            Log.w(TAG, "onAutoBlacklistDomain error: ${t.message}")
        }
    }

    private fun containsKeywordBounded(text: String, keyword: String): Boolean {
        if (!text.contains(keyword)) return false
        if (keyword.contains(" ")) return true
        val regex = Regex("\\b${Regex.escape(keyword)}\\b", RegexOption.IGNORE_CASE)
        return regex.containsMatchIn(text)
    }

    private fun fetchHtmlHeadSnippet(urlStr: String): String? {
        var conn: HttpURLConnection? = null
        return try {
            val url = URL(urlStr)
            conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 2200
                readTimeout = 2200
                instanceFollowRedirects = true
                setRequestProperty(
                    "User-Agent",
                    "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"
                )
                setRequestProperty("Range", "bytes=0-24576")
            }
            val reader = BufferedReader(InputStreamReader(conn.inputStream, Charsets.UTF_8))
            val sb = StringBuilder()
            val buf = CharArray(2048)
            var total = 0
            while (total < 24576) {
                val n = reader.read(buf)
                if (n <= 0) break
                sb.append(buf, 0, n)
                total += n
                if (sb.indexOf("</head>", ignoreCase = true) >= 0 && total > 4096) break
            }
            reader.close()
            sb.toString()
        } catch (_: Throwable) {
            null
        } finally {
            try { conn?.disconnect() } catch (_: Throwable) {}
        }
    }

    private fun extractRegexGroup(html: String, regex: Regex): String {
        val m = regex.find(html) ?: return ""
        return m.groupValues.getOrNull(1)
            ?.replace(Regex("\\s+"), " ")
            ?.trim()
            .orEmpty()
    }

    private fun extractMetaContent(html: String, metaName: String): String {
        val r1 = Regex(
            "<meta[^>]+name=[\"']?${Regex.escape(metaName)}[\"']?[^>]+content=[\"']([^\"']*)[\"'][^>]*>",
            RegexOption.IGNORE_CASE
        )
        r1.find(html)?.groupValues?.getOrNull(1)?.trim()?.let { if (it.isNotEmpty()) return it }

        val r2 = Regex(
            "<meta[^>]+content=[\"']([^\"']*)[\"'][^>]+name=[\"']?${Regex.escape(metaName)}[\"']?[^>]*>",
            RegexOption.IGNORE_CASE
        )
        return r2.find(html)?.groupValues?.getOrNull(1)?.trim().orEmpty()
    }

    private fun extractMetaPropertyContent(html: String, propName: String): String {
        val r1 = Regex(
            "<meta[^>]+property=[\"']?${Regex.escape(propName)}[\"']?[^>]+content=[\"']([^\"']*)[\"'][^>]*>",
            RegexOption.IGNORE_CASE
        )
        r1.find(html)?.groupValues?.getOrNull(1)?.trim()?.let { if (it.isNotEmpty()) return it }

        val r2 = Regex(
            "<meta[^>]+content=[\"']([^\"']*)[\"'][^>]+property=[\"']?${Regex.escape(propName)}[\"']?[^>]*>",
            RegexOption.IGNORE_CASE
        )
        return r2.find(html)?.groupValues?.getOrNull(1)?.trim().orEmpty()
    }

    /**
     * Queries Cloudflare Family DNS (1.1.1.3:53) and AdGuard Family DNS (94.140.14.15:53)
     * directly via UDP and checks if the answer is sinkholed (0.0.0.0 or AdGuard Family block IP).
     */
    fun queryCloudflareFamilyDnsSinkhole(domain: String): Boolean {
        val clean = domain.trim().lowercase(Locale.US).trimEnd('.')
        if (clean.isEmpty() || clean.endsWith("trycloudflare.com") || clean.endsWith("cloudflare.com") || clean.endsWith("onrender.com")) {
            return false
        }
        val queryBytes = buildDnsAQueryPacket(clean)
        val familyResolvers = listOf(
            byteArrayOf(1, 1, 1, 3),
            byteArrayOf(94.toByte(), 140.toByte(), 14, 15),
            byteArrayOf(1, 0, 0, 3)
        )
        for (ipBytes in familyResolvers) {
            var socket: DatagramSocket? = null
            try {
                socket = DatagramSocket()
                com.kavach.services.AeroNetworkModeratorVpnService.activeInstance?.protect(socket)
                socket.soTimeout = 1100

                val resolverIp = InetAddress.getByAddress(ipBytes)
                socket.send(DatagramPacket(queryBytes, queryBytes.size, resolverIp, 53))

                val recvBuf = ByteArray(1024)
                val recvPacket = DatagramPacket(recvBuf, recvBuf.size)
                socket.receive(recvPacket)

                if (isDnsResponseZeroSinkhole(recvBuf.copyOf(recvPacket.length))) {
                    return true
                }
            } catch (_: Throwable) {
                // Try next family DNS resolver
            } finally {
                try { socket?.close() } catch (_: Throwable) {}
            }
        }
        return false
    }

    private fun buildDnsAQueryPacket(domain: String): ByteArray {
        val labels = domain.split(".")
        val out = java.io.ByteArrayOutputStream()
        // Header (12 bytes): ID=0x1337, Flags=0x0100 (Standard query, RD=1), QDCOUNT=1
        out.write(byteArrayOf(0x13, 0x37, 0x01, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00))
        for (label in labels) {
            val bytes = label.toByteArray(Charsets.US_ASCII)
            out.write(bytes.size)
            out.write(bytes)
        }
        out.write(0x00) // Root terminator
        out.write(byteArrayOf(0x00, 0x01)) // QTYPE = A (1)
        out.write(byteArrayOf(0x00, 0x01)) // QCLASS = IN (1)
        return out.toByteArray()
    }

    companion object {
        /**
         * Checks if a raw DNS response payload contains an IPv4 A record of 0.0.0.0
         * (Cloudflare Family 1.1.1.3 / 1.0.0.3) or AdGuard Family block IP (94.140.14.33 / 94.140.14.35).
         */
        fun isDnsResponseZeroSinkhole(dnsResponseBytes: ByteArray): Boolean {
            if (dnsResponseBytes.size < 28) return false
            val anCount = ((dnsResponseBytes[6].toInt() and 0xFF) shl 8) or (dnsResponseBytes[7].toInt() and 0xFF)
            if (anCount <= 0) return false
            var i = 12
            while (i <= dnsResponseBytes.size - 14) {
                if (dnsResponseBytes[i].toInt() == 0x00 &&
                    dnsResponseBytes[i + 1].toInt() == 0x01 && // Type A
                    dnsResponseBytes[i + 2].toInt() == 0x00 &&
                    dnsResponseBytes[i + 3].toInt() == 0x01 && // Class IN
                    dnsResponseBytes[i + 8].toInt() == 0x00 &&
                    dnsResponseBytes[i + 9].toInt() == 0x04    // RDLENGTH 4
                ) {
                    val b0 = dnsResponseBytes[i + 10].toInt() and 0xFF
                    val b1 = dnsResponseBytes[i + 11].toInt() and 0xFF
                    val b2 = dnsResponseBytes[i + 12].toInt() and 0xFF
                    val b3 = dnsResponseBytes[i + 13].toInt() and 0xFF
                    if (b0 == 0 && b1 == 0 && b2 == 0 && b3 == 0) {
                        return true
                    }
                    // AdGuard Family Safe Browsing / Adult block sinkhole IPs: 94.140.14.33, 94.140.14.35
                    if (b0 == 94 && b1 == 140 && b2 == 14 && (b3 == 33 || b3 == 35)) {
                        return true
                    }
                }
                i++
            }
            return false
        }
    }
}
