package com.kavach.network

import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.SharedPreferences
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.TrafficStats
import android.os.Build
import android.os.SystemClock
import android.system.OsConstants
import android.view.accessibility.AccessibilityNodeInfo
import com.kavach.accessibility.AccessibilityServiceRegistry
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.InetSocketAddress
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ConcurrentLinkedDeque
import kotlin.math.roundToInt

data class AppDomainVisitEntry(
    val timestampMs: Long,
    val packageName: String,
    val appName: String,
    val domainOrUrl: String,
    val pageTitle: String = "",
    val source: String = "DNS_QUERY", // DNS_QUERY, BROWSER_URL_BAR, ACTIVE_SOCKET
    val action: String = "ALLOWED",   // ALLOWED, BLOCKED
    val reason: String = ""
) {
    val formattedTime: String
        get() = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date(timestampMs))

    fun toJson(): JSONObject = JSONObject().apply {
        put("timestampMs", timestampMs)
        put("formattedTime", formattedTime)
        put("packageName", packageName)
        put("appName", appName)
        put("domainOrUrl", domainOrUrl)
        put("pageTitle", pageTitle)
        put("source", source)
        put("action", action)
        put("reason", reason)
    }
}

data class ActiveSocketConnection(
    val protocol: String,
    val localIp: String,
    val localPort: Int,
    val remoteIp: String,
    val remotePort: Int,
    val remoteService: String,
    val resolvedDomain: String,
    val state: String,
    val uid: Int,
    val packageName: String,
    val appName: String
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("protocol", protocol)
        put("localEndpoint", "$localIp:$localPort")
        put("localPort", localPort)
        put("remoteIp", remoteIp)
        put("remotePort", remotePort)
        put("remoteEndpoint", "$remoteIp:$remotePort")
        put("remoteService", remoteService)
        put("resolvedDomain", resolvedDomain)
        put("state", state)
        put("uid", uid)
        put("packageName", packageName)
        put("appName", appName)
    }
}

/**
 * Real-time Per-App Internet Traffic, Browsing URL/Domain Attribution, Active Socket Inspector,
 * and Per-App Network Firewall Engine.
 */
class PerAppNetworkMonitor(private val context: Context) {

    companion object {
        private const val PREFS_NAME = "aero_per_app_network_prefs"
        private const val KEY_NET_BLOCKED_PKGS = "net_blocked_packages"

        @Volatile
        var activeInstance: PerAppNetworkMonitor? = null
            private set

        private val knownBrowsers = setOf(
            "com.android.chrome",
            "com.chrome.beta",
            "com.chrome.dev",
            "org.mozilla.firefox",
            "org.mozilla.fenix",
            "com.brave.browser",
            "com.sec.android.app.sbrowser",
            "com.microsoft.emmx",
            "com.opera.browser",
            "com.opera.mini.native",
            "com.duckduckgo.mobile.android",
            "com.vivaldi.browser",
            "mark.via.gp"
        )
    }

    private val prefs: SharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    private val scope = CoroutineScope(
        SupervisorJob() + Dispatchers.IO + CoroutineExceptionHandler { _, _ -> }
    )
    private var samplerJob: Job? = null

    private data class UidTrafficSample(
        val uid: Int,
        val rxBytes: Long,
        val txBytes: Long,
        val rxPackets: Long,
        val txPackets: Long,
        val downloadBps: Long,
        val uploadBps: Long,
        val sampleElapsedMs: Long
    )

    private val uidSamples = ConcurrentHashMap<Int, UidTrafficSample>()
    private val uidToPackageCache = ConcurrentHashMap<Int, String>()
    private val packageToLabelCache = ConcurrentHashMap<String, String>()

    // Cached UID list refreshed infrequently (every 90s) to avoid polling PackageManager every 1.5s
    @Volatile
    private var cachedInstalledUids: IntArray = IntArray(0)
    @Volatile
    private var lastUidRefreshMs: Long = 0L
    @Volatile
    private var lastTrafficAccessMs: Long = 0L

    // Per-app visited domains & URLs
    private val perAppDomainHistory = ConcurrentHashMap<String, ConcurrentLinkedDeque<AppDomainVisitEntry>>()
    // Global live browsing & domain feed across all apps
    private val globalBrowsingFeed = ConcurrentLinkedDeque<AppDomainVisitEntry>()
    private val maxGlobalFeed = 220
    private val maxPerAppHistory = 60
    private val maxIpDomainCache = 350
    private val maxLabelCache = 250

    // Cache mapping resolved IPv4/IPv6 addresses back to their queried domain names
    private val ipToDomainCache = ConcurrentHashMap<String, String>()

    // Per-app network firewall blocklist
    private val blockedNetworkPackages = ConcurrentHashMap.newKeySet<String>()

    // Browser URL bar deduplication & fast foreground package cache
    @Volatile
    private var lastBrowserInspectMs: Long = 0L
    @Volatile
    private var lastBrowserBlockActionMs: Long = 0L
    @Volatile
    private var cachedForegroundPkg: String = ""
    @Volatile
    private var cachedForegroundTimeMs: Long = 0L
    private val lastUrlPerBrowser = ConcurrentHashMap<String, String>()
    private val mainHandler = android.os.Handler(android.os.Looper.getMainLooper())

    init {
        activeInstance = this
        val savedBlocked = prefs.getStringSet(KEY_NET_BLOCKED_PKGS, emptySet()) ?: emptySet()
        blockedNetworkPackages.addAll(savedBlocked)
        startUidBandwidthSampler()
    }

    private fun startUidBandwidthSampler() {
        samplerJob?.cancel()
        samplerJob = scope.launch {
            while (isActive) {
                try {
                    sampleAllUidsOnce()
                } catch (_: Throwable) {}
                val recentlyActive = (SystemClock.elapsedRealtime() - lastTrafficAccessMs) < 25_000L
                delay(if (recentlyActive) 2200L else 8000L)
            }
        }
    }

    private fun refreshInstalledUidsIfNeeded(nowElapsed: Long): IntArray {
        val existing = cachedInstalledUids
        if (existing.isNotEmpty() && (nowElapsed - lastUidRefreshMs) < 90_000L) {
            return existing
        }
        val pm = context.packageManager
        val apps = try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                pm.getInstalledApplications(PackageManager.ApplicationInfoFlags.of(0L))
            } else {
                @Suppress("DEPRECATION")
                pm.getInstalledApplications(0)
            }
        } catch (_: Throwable) {
            emptyList()
        }
        val uniqueUids = LinkedHashSet<Int>(apps.size)
        for (app in apps) {
            uniqueUids.add(app.uid)
            if (!uidToPackageCache.containsKey(app.uid)) {
                uidToPackageCache[app.uid] = app.packageName
            }
        }
        val result = uniqueUids.toIntArray()
        cachedInstalledUids = result
        lastUidRefreshMs = nowElapsed
        return result
    }

    @Synchronized
    fun sampleAllUidsOnce() {
        val nowElapsed = SystemClock.elapsedRealtime()
        val uids = refreshInstalledUidsIfNeeded(nowElapsed)

        for (uid in uids) {
            val curRx = TrafficStats.getUidRxBytes(uid).coerceAtLeast(0L)
            val curTx = TrafficStats.getUidTxBytes(uid).coerceAtLeast(0L)
            val curRxPkts = TrafficStats.getUidRxPackets(uid).coerceAtLeast(0L)
            val curTxPkts = TrafficStats.getUidTxPackets(uid).coerceAtLeast(0L)

            val prev = uidSamples[uid]
            if (prev == null) {
                uidSamples[uid] = UidTrafficSample(
                    uid = uid,
                    rxBytes = curRx,
                    txBytes = curTx,
                    rxPackets = curRxPkts,
                    txPackets = curTxPkts,
                    downloadBps = 0L,
                    uploadBps = 0L,
                    sampleElapsedMs = nowElapsed
                )
            } else {
                val deltaMs = (nowElapsed - prev.sampleElapsedMs).coerceAtLeast(1L)
                if (deltaMs >= 200L) {
                    val dlBps = (((curRx - prev.rxBytes).coerceAtLeast(0L)) * 1000L) / deltaMs
                    val ulBps = (((curTx - prev.txBytes).coerceAtLeast(0L)) * 1000L) / deltaMs
                    uidSamples[uid] = UidTrafficSample(
                        uid = uid,
                        rxBytes = curRx,
                        txBytes = curTx,
                        rxPackets = curRxPkts,
                        txPackets = curTxPkts,
                        downloadBps = dlBps,
                        uploadBps = ulBps,
                        sampleElapsedMs = nowElapsed
                    )
                }
            }
        }
    }

    fun trimCaches(aggressive: Boolean = false) {
        if (aggressive) {
            ipToDomainCache.clear()
            packageToLabelCache.clear()
            lastUrlPerBrowser.clear()
            while (globalBrowsingFeed.size > 60) {
                globalBrowsingFeed.pollFirst()
            }
            perAppDomainHistory.values.forEach { q ->
                while (q.size > 15) q.pollFirst()
            }
            return
        }
        if (ipToDomainCache.size > maxIpDomainCache) {
            val toDrop = ipToDomainCache.size - (maxIpDomainCache * 3 / 4)
            val it = ipToDomainCache.keys.iterator()
            var removed = 0
            while (it.hasNext() && removed < toDrop) {
                it.next()
                it.remove()
                removed++
            }
        }
        if (packageToLabelCache.size > maxLabelCache) {
            val toDrop = packageToLabelCache.size - (maxLabelCache * 3 / 4)
            val it = packageToLabelCache.keys.iterator()
            var removed = 0
            while (it.hasNext() && removed < toDrop) {
                it.next()
                it.remove()
                removed++
            }
        }
    }

    fun isAppNetworkBlocked(packageName: String?): Boolean {
        if (packageName.isNullOrBlank()) return false
        return blockedNetworkPackages.contains(packageName.trim())
    }

    fun getBlockedNetworkPackages(): Set<String> = blockedNetworkPackages.toSet()

    fun blockAppNetwork(target: String): JSONObject {
        val pkg = resolvePackageIdentifier(target) ?: target.trim()
        if (pkg.isBlank()) {
            return JSONObject().put("success", false).put("error", "Missing app name or package name")
        }
        if (pkg == context.packageName || pkg == "com.termux") {
            return JSONObject().put("success", false).put("error", "Cannot block network for bridge/Termux package: $pkg")
        }
        blockedNetworkPackages.add(pkg)
        prefs.edit().putStringSet(KEY_NET_BLOCKED_PKGS, blockedNetworkPackages.toSet()).apply()

        val label = resolveAppLabel(pkg)
        val uid = resolvePackageUid(pkg)

        // Best-effort shell iptables / netpolicy enforcement if root/shell privileges exist
        if (uid > 0) {
            scope.launch {
                try {
                    ProcessBuilder(
                        "su", "-c",
                        "iptables -C OUTPUT -m owner --uid-owner $uid -j REJECT 2>/dev/null || iptables -I OUTPUT -m owner --uid-owner $uid -j REJECT; cmd netpolicy add restrict-background-blacklist $uid"
                    ).start().waitFor(2, java.util.concurrent.TimeUnit.SECONDS)
                } catch (_: Throwable) {}
            }
        }

        // Ensure the DNS Moderator Engine is marked active and flush OS DNS cache
        com.kavach.services.AeroNetworkModeratorVpnService.networkModerationManager?.setVpnActive(true)
        com.kavach.services.AeroNetworkModeratorVpnService.activeInstance?.reloadVpnInterface()

        return JSONObject().apply {
            put("success", true)
            put("action", "APP_NETWORK_BLOCKED")
            put("appName", label)
            put("packageName", pkg)
            put("uid", uid)
            put("blockedAppsCount", blockedNetworkPackages.size)
            put("isVpnTunnelActive", com.kavach.services.AeroNetworkModeratorVpnService.isRunning)
            put("message", "Internet access blocked for $label ($pkg). All DNS & network requests for this app will be rejected.")
        }
    }

    fun unblockAppNetwork(target: String, unblockAll: Boolean = false): JSONObject {
        if (unblockAll || target.trim().equals("all", ignoreCase = true) || target.trim() == "*") {
            val count = blockedNetworkPackages.size
            val prevPkgs = blockedNetworkPackages.toSet()
            blockedNetworkPackages.clear()
            prefs.edit().putStringSet(KEY_NET_BLOCKED_PKGS, emptySet()).apply()
            scope.launch {
                for (p in prevPkgs) {
                    val u = resolvePackageUid(p)
                    if (u > 0) {
                        try {
                            ProcessBuilder(
                                "su", "-c",
                                "iptables -D OUTPUT -m owner --uid-owner $u -j REJECT 2>/dev/null; cmd netpolicy remove restrict-background-blacklist $u"
                            ).start().waitFor(2, java.util.concurrent.TimeUnit.SECONDS)
                        } catch (_: Throwable) {}
                    }
                }
            }
            return JSONObject().apply {
                put("success", true)
                put("action", "UNBLOCKED_ALL_APP_NETWORKS")
                put("clearedCount", count)
            }
        }

        val pkg = resolvePackageIdentifier(target) ?: target.trim()
        val removed = blockedNetworkPackages.remove(pkg)
        prefs.edit().putStringSet(KEY_NET_BLOCKED_PKGS, blockedNetworkPackages.toSet()).apply()
        val label = resolveAppLabel(pkg)
        val uid = resolvePackageUid(pkg)
        if (uid > 0) {
            scope.launch {
                try {
                    ProcessBuilder(
                        "su", "-c",
                        "iptables -D OUTPUT -m owner --uid-owner $uid -j REJECT 2>/dev/null; cmd netpolicy remove restrict-background-blacklist $uid"
                    ).start().waitFor(2, java.util.concurrent.TimeUnit.SECONDS)
                } catch (_: Throwable) {}
            }
        }

        com.kavach.services.AeroNetworkModeratorVpnService.activeInstance?.reloadVpnInterface()

        return JSONObject().apply {
            put("success", true)
            put("action", "APP_NETWORK_UNBLOCKED")
            put("appName", label)
            put("packageName", pkg)
            put("uid", uid)
            put("wasBlocked", removed)
            put("blockedAppsCount", blockedNetworkPackages.size)
        }
    }

    /**
     * Resolves which app (packageName) initiated a UDP DNS packet from the VPN interface.
     */
    fun resolveDnsPacketOwnerPackage(
        srcIp: String = "10.10.10.2",
        srcPort: Int,
        dstIp: String = "10.10.10.1",
        dstPort: Int = 53
    ): String {
        // 1. Try ConnectivityManager.getConnectionOwnerUid (API 29+)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && srcPort > 0) {
            try {
                val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
                if (cm != null) {
                    val uid = cm.getConnectionOwnerUid(
                        OsConstants.IPPROTO_UDP,
                        InetSocketAddress(srcIp, srcPort),
                        InetSocketAddress(dstIp, dstPort)
                    )
                    if (uid > 0) {
                        val pkg = resolvePackageForUid(uid)
                        if (pkg.isNotBlank()) return pkg
                    }
                }
            } catch (_: Throwable) {}
        }

        // 2. Try matching srcPort in /proc/net/udp only if an app firewall block is active
        if (srcPort > 0 && blockedNetworkPackages.isNotEmpty()) {
            val uid = findSocketOwnerUidByLocalPort(srcPort, isUdp = true)
            if (uid > 0) {
                val pkg = resolvePackageForUid(uid)
                if (pkg.isNotBlank()) return pkg
            }
        }

        // 3. Fallback to the current foreground application (cached for fast non-blocking DNS path)
        return queryForegroundPackage()
    }

    fun recordDomainQueryForApp(
        domain: String,
        packageName: String,
        action: String,
        reason: String = "",
        source: String = "DNS_QUERY",
        pageTitle: String = ""
    ) {
        val cleanDomain = domain.trim()
        if (cleanDomain.isEmpty()) return
        val pkg = packageName.ifBlank { queryForegroundPackage().ifBlank { "system" } }
        val appName = if (pkg == "system") "Android System / DNS" else resolveAppLabel(pkg)
        val now = System.currentTimeMillis()

        val entry = AppDomainVisitEntry(
            timestampMs = now,
            packageName = pkg,
            appName = appName,
            domainOrUrl = cleanDomain,
            pageTitle = pageTitle,
            source = source,
            action = action,
            reason = reason
        )

        val appDeque = perAppDomainHistory.getOrPut(pkg) { ConcurrentLinkedDeque() }
        // Avoid duplicate back-to-back entries within 1.5 seconds
        val last = appDeque.peekLast()
        if (last == null || last.domainOrUrl != cleanDomain || (now - last.timestampMs) > 1500L || last.action != action) {
            appDeque.addLast(entry)
            while (appDeque.size > maxPerAppHistory) {
                appDeque.pollFirst()
            }
        }

        val gLast = globalBrowsingFeed.peekLast()
        if (gLast == null || gLast.domainOrUrl != cleanDomain || gLast.packageName != pkg || (now - gLast.timestampMs) > 1500L) {
            globalBrowsingFeed.addLast(entry)
            while (globalBrowsingFeed.size > maxGlobalFeed) {
                globalBrowsingFeed.pollFirst()
            }
        }
    }

    fun cacheDnsResolvedIp(domain: String, ipAddress: String) {
        val d = domain.trim().lowercase().trimEnd('.')
        val ip = ipAddress.trim()
        if (d.isNotEmpty() && ip.isNotEmpty()) {
            ipToDomainCache[ip] = d
            if (ipToDomainCache.size > maxIpDomainCache + 40) {
                trimCaches(aggressive = false)
            }
        }
    }

    /**
     * Parses raw DNS response payload to extract IPv4 A records and map them to the queried domain.
     */
    fun parseAndCacheDnsResponseIps(domain: String, dnsResponseBytes: ByteArray) {
        try {
            if (dnsResponseBytes.size < 16) return
            val anCount = ((dnsResponseBytes[6].toInt() and 0xFF) shl 8) or (dnsResponseBytes[7].toInt() and 0xFF)
            if (anCount <= 0) return
            // Scan for IPv4 A record patterns (Type 0x0001, Class 0x0001, Length 0x0004)
            var i = 12
            while (i <= dnsResponseBytes.size - 14) {
                if (dnsResponseBytes[i].toInt() == 0x00 &&
                    dnsResponseBytes[i + 1].toInt() == 0x01 &&
                    dnsResponseBytes[i + 2].toInt() == 0x00 &&
                    dnsResponseBytes[i + 3].toInt() == 0x01 &&
                    dnsResponseBytes[i + 8].toInt() == 0x00 &&
                    dnsResponseBytes[i + 9].toInt() == 0x04
                ) {
                    val b1 = dnsResponseBytes[i + 10].toInt() and 0xFF
                    val b2 = dnsResponseBytes[i + 11].toInt() and 0xFF
                    val b3 = dnsResponseBytes[i + 12].toInt() and 0xFF
                    val b4 = dnsResponseBytes[i + 13].toInt() and 0xFF
                    val ipStr = "$b1.$b2.$b3.$b4"
                    cacheDnsResolvedIp(domain, ipStr)
                    i += 14
                } else {
                    i++
                }
            }
        } catch (_: Throwable) {}
    }

    /**
     * Called by TermuxAccessibilityService when a window or content change occurs.
     * Extracts the active browser URL / address bar and page title in real time!
     */
    fun onAccessibilityEventForBrowsing(packageName: String?) {
        val pkg = packageName?.trim().orEmpty()
        if (pkg.isEmpty()) return
        val now = System.currentTimeMillis()
        if (pkg != "com.android.systemui") {
            cachedForegroundPkg = pkg
            cachedForegroundTimeMs = now
        }
        if (now - lastBrowserInspectMs < 650L) return

        val isBrowser = knownBrowsers.contains(pkg) ||
            pkg.contains("browser", ignoreCase = true) ||
            pkg.contains("chrome", ignoreCase = true) ||
            pkg.contains("firefox", ignoreCase = true) ||
            pkg.contains("webview", ignoreCase = true) ||
            pkg.contains("youtube", ignoreCase = true)

        if (!isBrowser) return
        lastBrowserInspectMs = now

        val service = AccessibilityServiceRegistry.activeService ?: return
        val root = try { service.rootInActiveWindow } catch (_: Throwable) { null } ?: return

        scope.launch {
            try {
                val nodes = mutableListOf<AccessibilityNodeInfo>()
                collectNodes(root, nodes, maxNodes = 180)

                var detectedUrl = ""
                var detectedTitle = ""
                val screenTextBuilder = StringBuilder()

                for (node in nodes) {
                    val resId = try { node.viewIdResourceName?.lowercase().orEmpty() } catch (_: Throwable) { "" }
                    val txt = try { node.text?.toString()?.trim().orEmpty() } catch (_: Throwable) { "" }
                    if (txt.isEmpty()) continue

                    if (resId.contains("url_bar") ||
                        resId.contains("location_bar") ||
                        resId.contains("mozac_browser_toolbar_url_view") ||
                        resId.contains("omnibox") ||
                        resId.contains("url_field") ||
                        resId.contains("address_bar")
                    ) {
                        if (looksLikeUrlOrDomain(txt)) {
                            detectedUrl = txt
                        }
                    } else if (detectedUrl.isEmpty() && looksLikeUrlOrDomain(txt) && txt.length in 4..220 && !txt.contains(" ")) {
                        detectedUrl = txt
                    } else if (detectedTitle.isEmpty() && txt.length in 4..100 &&
                        (resId.contains("title") || node.className?.toString()?.contains("WebView") == true)
                    ) {
                        detectedTitle = txt
                    } else if (screenTextBuilder.length < 600 && txt.length in 3..140) {
                        screenTextBuilder.append(txt).append(" ")
                    }
                }

                if (detectedUrl.isNotBlank()) {
                    val prev = lastUrlPerBrowser[pkg]
                    val modMgr = com.kavach.services.AeroNetworkModeratorVpnService.networkModerationManager
                    var (isSiteBlocked, blockReason) = modMgr
                        ?.checkUrlOrDomainBlocked(detectedUrl, pkg)
                        ?: (isAppNetworkBlocked(pkg) to if (isAppNetworkBlocked(pkg)) "APP_FIREWALL" else "")

                    // Layer 3: If ADULT category is enabled and domain wasn't statically blocked yet,
                    // scan visible page title and screen text for adult content / 18+ age-gate markers
                    if (!isSiteBlocked && modMgr?.isAdultCategoryEnabled() == true) {
                        val uiVerdict = modMgr.siteMetadataAnalyzer.evaluateBrowserPageContext(
                            rawUrlOrDomain = detectedUrl,
                            pageTitle = detectedTitle,
                            screenTextSample = screenTextBuilder.toString()
                        )
                        if (uiVerdict != null && uiVerdict.isAdult) {
                            isSiteBlocked = true
                            blockReason = "AUTO_${uiVerdict.triggerSource}: ${uiVerdict.matchedIndicators.firstOrNull().orEmpty()}"
                        }
                    }

                    if (prev != detectedUrl || isSiteBlocked) {
                        lastUrlPerBrowser[pkg] = detectedUrl
                        recordDomainQueryForApp(
                            domain = detectedUrl,
                            packageName = pkg,
                            action = if (isSiteBlocked) "BLOCKED" else "ALLOWED",
                            reason = if (isSiteBlocked) blockReason.ifEmpty { "SITE_BLACKLIST" } else "ACTIVE_BROWSER_TAB",
                            source = "BROWSER_URL_BAR",
                            pageTitle = detectedTitle
                        )
                    }

                    // Active Browser Enforcement: if the site or browser app is blocked, immediately navigate away
                    if (isSiteBlocked && (now - lastBrowserBlockActionMs) > 1400L) {
                        lastBrowserBlockActionMs = now
                        lastUrlPerBrowser.remove(pkg)
                        try {
                            if (isAppNetworkBlocked(pkg)) {
                                service.performGlobalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_HOME)
                            } else {
                                service.performGlobalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_BACK)
                            }
                        } catch (_: Throwable) {}
                        modMgr?.triggerVisualBlockScreen(detectedUrl, blockReason.ifEmpty { "SITE_BLACKLIST" }, "BROWSER_GUARD")
                        mainHandler.post {
                            try {
                                android.widget.Toast.makeText(
                                    context,
                                    "🚫 Blocked by Aero Firewall: $detectedUrl",
                                    android.widget.Toast.LENGTH_SHORT
                                ).show()
                            } catch (_: Throwable) {}
                        }
                    }
                }
            } catch (_: Throwable) {}
        }
    }

    /**
     * Called when background HTML <head> Metadata or Family DNS analysis auto-blacklists a domain
     * after the browser has already started loading it.
     */
    fun enforceBrowserKickForAutoBlockedDomain(domain: String, rootDomain: String, reason: String) {
        val fgPkg = queryForegroundPackage()
        val isFgBrowser = knownBrowsers.contains(fgPkg) ||
            fgPkg.contains("chrome", ignoreCase = true) ||
            fgPkg.contains("browser", ignoreCase = true) ||
            fgPkg.contains("firefox", ignoreCase = true)

        val currentBrowserUrl = lastUrlPerBrowser[fgPkg].orEmpty().lowercase(Locale.US)
        val matchesActiveBrowser = isFgBrowser && (
            currentBrowserUrl.isEmpty() ||
                currentBrowserUrl.contains(rootDomain.lowercase(Locale.US)) ||
                currentBrowserUrl.contains(domain.lowercase(Locale.US))
            )

        recordDomainQueryForApp(
            domain = domain,
            packageName = fgPkg.ifBlank { "com.android.chrome" },
            action = "BLOCKED",
            reason = reason,
            source = "AUTO_METADATA"
        )

        if (matchesActiveBrowser) {
            val now = System.currentTimeMillis()
            if (now - lastBrowserBlockActionMs > 1200L) {
                lastBrowserBlockActionMs = now
                lastUrlPerBrowser.remove(fgPkg)
                try {
                    AccessibilityServiceRegistry.activeService?.performGlobalAction(
                        android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_BACK
                    )
                } catch (_: Throwable) {}
                com.kavach.services.AeroNetworkModeratorVpnService.networkModerationManager
                    ?.triggerVisualBlockScreen(rootDomain, reason, "AUTO_ADULT_CLASSIFIER")
                mainHandler.post {
                    try {
                        android.widget.Toast.makeText(
                            context,
                            "🚫 Auto-Blocked Adult Site ($rootDomain)",
                            android.widget.Toast.LENGTH_SHORT
                        ).show()
                    } catch (_: Throwable) {}
                }
            }
        }
    }

    private fun looksLikeUrlOrDomain(text: String): Boolean {
        val clean = text.trim().lowercase(Locale.US)
        if (clean.contains(" ") || clean.length < 4) return false
        if (clean.startsWith("http://") || clean.startsWith("https://")) return true
        val hostPart = clean.substringBefore("/")
        return hostPart.contains(".") &&
            !hostPart.endsWith(".") &&
            !hostPart.startsWith(".") &&
            Regex("^[a-z0-9.-]+\\.[a-z]{2,12}$").matches(hostPart)
    }

    private fun collectNodes(node: AccessibilityNodeInfo?, out: MutableList<AccessibilityNodeInfo>, maxNodes: Int) {
        if (node == null || out.size >= maxNodes) return
        out.add(node)
        val count = try { node.childCount } catch (_: Throwable) { 0 }
        for (i in 0 until count) {
            if (out.size >= maxNodes) break
            val child = try { node.getChild(i) } catch (_: Throwable) { null }
            if (child != null) collectNodes(child, out, maxNodes)
        }
    }

    /**
     * Returns a ranked JSON list of all network-active apps with live DL/UL speed, cumulative Rx/Tx MB,
     * firewall block status, and latest visited domain/URL.
     */
    fun getAllAppsLiveTrafficJson(topN: Int = 30, includeZeroTraffic: Boolean = false): JSONObject {
        lastTrafficAccessMs = SystemClock.elapsedRealtime()
        sampleAllUidsOnce()
        val pm = context.packageManager
        val apps = try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                pm.getInstalledApplications(PackageManager.ApplicationInfoFlags.of(0L))
            } else {
                @Suppress("DEPRECATION")
                pm.getInstalledApplications(0)
            }
        } catch (_: Throwable) {
            emptyList()
        }

        val fgPkg = queryForegroundPackage()
        val activeSockets = inspectActiveSockets()
        val socketsCountByPkg = activeSockets.groupingBy { it.packageName }.eachCount()

        data class AppRow(
            val packageName: String,
            val appName: String,
            val uid: Int,
            val isSystem: Boolean,
            val isBlocked: Boolean,
            val isForeground: Boolean,
            val dlKbps: Double,
            val ulKbps: Double,
            val rxMb: Double,
            val txMb: Double,
            val totalBytes: Long,
            val rxPackets: Long,
            val txPackets: Long,
            val activeSocketsCount: Int,
            val latestDomainOrUrl: String,
            val recentDomainsCount: Int
        )

        val rows = mutableListOf<AppRow>()
        val seenPkgs = HashSet<String>()

        for (app in apps) {
            val pkg = app.packageName
            if (!seenPkgs.add(pkg)) continue
            val uid = app.uid
            val sample = uidSamples[uid]
            val rxBytes = sample?.rxBytes ?: TrafficStats.getUidRxBytes(uid).coerceAtLeast(0L)
            val txBytes = sample?.txBytes ?: TrafficStats.getUidTxBytes(uid).coerceAtLeast(0L)
            val totalBytes = rxBytes + txBytes
            val dlKbps = ((sample?.downloadBps ?: 0L) / 102.4).roundToInt() / 10.0
            val ulKbps = ((sample?.uploadBps ?: 0L) / 102.4).roundToInt() / 10.0

            val domHistory = perAppDomainHistory[pkg]
            val latestDom = domHistory?.peekLast()?.domainOrUrl.orEmpty()
            val sockCount = socketsCountByPkg[pkg] ?: 0
            val isBlocked = blockedNetworkPackages.contains(pkg)
            val isFg = pkg == fgPkg

            if (!includeZeroTraffic &&
                totalBytes <= 0L &&
                dlKbps <= 0.0 &&
                ulKbps <= 0.0 &&
                latestDom.isEmpty() &&
                sockCount == 0 &&
                !isBlocked &&
                !isFg
            ) {
                continue
            }

            val label = resolveAppLabel(pkg)
            val isSys = (app.flags and ApplicationInfo.FLAG_SYSTEM) != 0
            rows.add(
                AppRow(
                    packageName = pkg,
                    appName = label,
                    uid = uid,
                    isSystem = isSys,
                    isBlocked = isBlocked,
                    isForeground = isFg,
                    dlKbps = dlKbps,
                    ulKbps = ulKbps,
                    rxMb = (rxBytes / (1024.0 * 1024.0) * 100.0).roundToInt() / 100.0,
                    txMb = (txBytes / (1024.0 * 1024.0) * 100.0).roundToInt() / 100.0,
                    totalBytes = totalBytes,
                    rxPackets = sample?.rxPackets ?: 0L,
                    txPackets = sample?.txPackets ?: 0L,
                    activeSocketsCount = sockCount,
                    latestDomainOrUrl = latestDom,
                    recentDomainsCount = domHistory?.size ?: 0
                )
            )
        }

        // Sort by: (1) Live speed (DL+UL), (2) Foreground app, (3) Recent domains/sockets, (4) Total bytes
        val sorted = rows.sortedWith(
            compareByDescending<AppRow> { it.dlKbps + it.ulKbps }
                .thenByDescending { it.isForeground }
                .thenByDescending { it.activeSocketsCount + it.recentDomainsCount }
                .thenByDescending { it.totalBytes }
        ).take(topN.coerceIn(1, 100))

        val appsArr = JSONArray()
        for (r in sorted) {
            appsArr.put(
                JSONObject().apply {
                    put("packageName", r.packageName)
                    put("appName", r.appName)
                    put("uid", r.uid)
                    put("isSystemApp", r.isSystem)
                    put("isNetworkBlocked", r.isBlocked)
                    put("isForeground", r.isForeground)
                    put("downloadKBps", r.dlKbps)
                    put("uploadKBps", r.ulKbps)
                    put("totalRxMB", r.rxMb)
                    put("totalTxMB", r.txMb)
                    put("totalBytes", r.totalBytes)
                    put("rxPackets", r.rxPackets)
                    put("txPackets", r.txPackets)
                    put("activeSocketsCount", r.activeSocketsCount)
                    put("latestDomainOrUrl", r.latestDomainOrUrl)
                    put("recentDomainsCount", r.recentDomainsCount)
                }
            )
        }

        val blockedArr = JSONArray()
        blockedNetworkPackages.sorted().forEach { pkg ->
            blockedArr.put(
                JSONObject().apply {
                    put("packageName", pkg)
                    put("appName", resolveAppLabel(pkg))
                }
            )
        }

        return JSONObject().apply {
            put("success", true)
            put("timestampMs", System.currentTimeMillis())
            put("foregroundPackage", fgPkg)
            put("foregroundAppName", if (fgPkg.isNotBlank()) resolveAppLabel(fgPkg) else "")
            put("isVpnFirewallActive", com.kavach.services.AeroNetworkModeratorVpnService.isRunning)
            put("blockedAppsCount", blockedNetworkPackages.size)
            put("blockedApps", blockedArr)
            put("appsCount", appsArr.length())
            put("apps", appsArr)
        }
    }

    /**
     * Deeply inspects live network activity for a single target app (by name or package):
     * - Instantaneous DL/UL speed & total Rx/Tx MB
     * - Active TCP/UDP sockets & remote IP:port endpoints + resolved domain names
     * - Live visited domains & browser URLs attributed to this app
     */
    fun getSingleAppLiveTrafficJson(target: String, limit: Int = 35): JSONObject {
        val pkg = resolvePackageIdentifier(target)
            ?: return JSONObject().put("success", false).put("error", "App not found for '$target'")

        sampleAllUidsOnce()
        val label = resolveAppLabel(pkg)
        val uid = resolvePackageUid(pkg)
        val sample = uidSamples[uid]
        val rxBytes = sample?.rxBytes ?: TrafficStats.getUidRxBytes(uid).coerceAtLeast(0L)
        val txBytes = sample?.txBytes ?: TrafficStats.getUidTxBytes(uid).coerceAtLeast(0L)
        val dlKbps = ((sample?.downloadBps ?: 0L) / 102.4).roundToInt() / 10.0
        val ulKbps = ((sample?.uploadBps ?: 0L) / 102.4).roundToInt() / 10.0

        val isBlocked = blockedNetworkPackages.contains(pkg)
        val isFg = queryForegroundPackage() == pkg

        // Active sockets for this app UID / package
        val sockets = inspectActiveSockets(filterUid = uid, filterPkg = pkg)
        val socketsArr = JSONArray()
        sockets.take(limit).forEach { socketsArr.put(it.toJson()) }

        // Visited domains & URLs for this app
        val historyList = perAppDomainHistory[pkg]?.toList()?.takeLast(limit)?.reversed() ?: emptyList()
        val domainsArr = JSONArray()
        historyList.forEach { domainsArr.put(it.toJson()) }

        val activeBrowserUrl = lastUrlPerBrowser[pkg].orEmpty()

        return JSONObject().apply {
            put("success", true)
            put("timestampMs", System.currentTimeMillis())
            put("appName", label)
            put("packageName", pkg)
            put("uid", uid)
            put("isForeground", isFg)
            put("isNetworkBlocked", isBlocked)
            put("downloadKBps", dlKbps)
            put("uploadKBps", ulKbps)
            put("totalRxMB", (rxBytes / (1024.0 * 1024.0) * 100.0).roundToInt() / 100.0)
            put("totalTxMB", (txBytes / (1024.0 * 1024.0) * 100.0).roundToInt() / 100.0)
            put("rxBytes", rxBytes)
            put("txBytes", txBytes)
            put("rxPackets", sample?.rxPackets ?: TrafficStats.getUidRxPackets(uid).coerceAtLeast(0L))
            put("txPackets", sample?.txPackets ?: TrafficStats.getUidTxPackets(uid).coerceAtLeast(0L))
            put("activeBrowserUrl", activeBrowserUrl)
            put("activeConnectionsCount", socketsArr.length())
            put("activeConnections", socketsArr)
            put("visitedDomainsCount", domainsArr.length())
            put("visitedDomains", domainsArr)
        }
    }

    /**
     * Returns current live web browsing session & domain stream across browsers and active apps.
     */
    fun getCurrentBrowsingSessionJson(limit: Int = 40): JSONObject {
        val fgPkg = queryForegroundPackage()
        if (fgPkg.isNotBlank()) {
            onAccessibilityEventForBrowsing(fgPkg)
        }
        val fgLabel = if (fgPkg.isNotBlank()) resolveAppLabel(fgPkg) else "None"
        val fgUrl = lastUrlPerBrowser[fgPkg].orEmpty()

        val browserTabsArr = JSONArray()
        for ((bPkg, url) in lastUrlPerBrowser) {
            if (url.isNotBlank()) {
                browserTabsArr.put(
                    JSONObject().apply {
                        put("packageName", bPkg)
                        put("appName", resolveAppLabel(bPkg))
                        put("activeUrl", url)
                        put("isForeground", bPkg == fgPkg)
                    }
                )
            }
        }

        val feedArr = JSONArray()
        val recent = globalBrowsingFeed.toList().takeLast(limit.coerceIn(1, 200)).reversed()
        for (item in recent) {
            feedArr.put(item.toJson())
        }

        val activeSockets = inspectActiveSockets()
        val remoteEndpointsArr = JSONArray()
        activeSockets
            .filter { it.remoteIp != "127.0.0.1" && it.remoteIp != "0.0.0.0" && it.remoteIp != "::" }
            .take(20)
            .forEach { remoteEndpointsArr.put(it.toJson()) }

        return JSONObject().apply {
            put("success", true)
            put("timestampMs", System.currentTimeMillis())
            put("foregroundPackage", fgPkg)
            put("foregroundAppName", fgLabel)
            put("foregroundActiveUrl", fgUrl)
            put("isVpnDnsMonitorActive", com.kavach.services.AeroNetworkModeratorVpnService.isRunning)
            put("isAccessibilityUrlReaderActive", AccessibilityServiceRegistry.activeService != null)
            put("activeBrowserTabsCount", browserTabsArr.length())
            put("activeBrowserTabs", browserTabsArr)
            put("browsingFeedCount", feedArr.length())
            put("browsingFeed", feedArr)
            put("activeRemoteSocketsCount", remoteEndpointsArr.length())
            put("activeRemoteSockets", remoteEndpointsArr)
        }
    }

    /**
     * Inspects active TCP/UDP sockets from /proc/net/tcp, /proc/net/tcp6, /proc/net/udp, /proc/net/udp6.
     */
    fun inspectActiveSockets(filterUid: Int? = null, filterPkg: String? = null): List<ActiveSocketConnection> {
        val results = mutableListOf<ActiveSocketConnection>()
        val seenKeys = HashSet<String>()

        val procFiles = listOf(
            "/proc/net/tcp" to "TCP",
            "/proc/net/tcp6" to "TCP6",
            "/proc/net/udp" to "UDP",
            "/proc/net/udp6" to "UDP6"
        )

        for ((path, proto) in procFiles) {
            try {
                val f = File(path)
                if (!f.exists() || !f.canRead()) continue
                val lines = f.readLines()
                for (idx in 1 until lines.size) {
                    val parts = lines[idx].trim().split(Regex("\\s+"))
                    if (parts.size < 8) continue
                    val localSpec = parts[1]
                    val remSpec = parts[2]
                    val stateHex = parts[3]
                    val uid = parts[7].toIntOrNull() ?: -1

                    if (filterUid != null && filterUid > 0 && uid != filterUid) continue
                    val pkg = resolvePackageForUid(uid)
                    if (filterPkg != null && pkg != filterPkg) continue

                    val (localIp, localPort) = parseProcAddressPort(localSpec)
                    val (remoteIp, remotePort) = parseProcAddressPort(remSpec)

                    // Skip idle listening sockets to 0.0.0.0:0 unless filtering for a specific app
                    if (remotePort == 0 && (remoteIp == "0.0.0.0" || remoteIp == "::")) continue

                    val stateStr = decodeSocketState(stateHex, proto.startsWith("UDP"))
                    val key = "$proto|$localPort|$remoteIp:$remotePort|$uid"
                    if (!seenKeys.add(key)) continue

                    val serviceLabel = resolvePortServiceLabel(remotePort, proto)
                    val resolvedDom = ipToDomainCache[remoteIp].orEmpty()
                    val appLabel = if (pkg.isNotBlank()) resolveAppLabel(pkg) else "UID $uid"

                    results.add(
                        ActiveSocketConnection(
                            protocol = proto,
                            localIp = localIp,
                            localPort = localPort,
                            remoteIp = remoteIp,
                            remotePort = remotePort,
                            remoteService = serviceLabel,
                            resolvedDomain = resolvedDom,
                            state = stateStr,
                            uid = uid,
                            packageName = pkg.ifBlank { "uid:$uid" },
                            appName = appLabel
                        )
                    )
                }
            } catch (_: Throwable) {}
        }

        return results.sortedWith(
            compareBy<ActiveSocketConnection> { it.state != "ESTABLISHED" }
                .thenByDescending { it.resolvedDomain.isNotEmpty() }
                .thenBy { it.remotePort }
        )
    }

    private fun findSocketOwnerUidByLocalPort(targetPort: Int, isUdp: Boolean): Int {
        val paths = if (isUdp) listOf("/proc/net/udp", "/proc/net/udp6") else listOf("/proc/net/tcp", "/proc/net/tcp6")
        val hexPort = "%04X".format(targetPort)
        for (p in paths) {
            try {
                val f = File(p)
                if (!f.exists() || !f.canRead()) continue
                for (line in f.readLines().drop(1)) {
                    val parts = line.trim().split(Regex("\\s+"))
                    if (parts.size >= 8 && parts[1].endsWith(":$hexPort", ignoreCase = true)) {
                        val uid = parts[7].toIntOrNull() ?: -1
                        if (uid > 0) return uid
                    }
                }
            } catch (_: Throwable) {}
        }
        return -1
    }

    private fun parseProcAddressPort(spec: String): Pair<String, Int> {
        val split = spec.split(":")
        if (split.size != 2) return "0.0.0.0" to 0
        val hexIp = split[0]
        val port = split[1].toIntOrNull(16) ?: 0

        if (hexIp.length == 8) {
            val b1 = hexIp.substring(6, 8).toIntOrNull(16) ?: 0
            val b2 = hexIp.substring(4, 6).toIntOrNull(16) ?: 0
            val b3 = hexIp.substring(2, 4).toIntOrNull(16) ?: 0
            val b4 = hexIp.substring(0, 2).toIntOrNull(16) ?: 0
            return "$b1.$b2.$b3.$b4" to port
        } else if (hexIp.length == 32) {
            // Check IPv4-mapped IPv6 (0000000000000000FFFF0000XXXXXXXX)
            if (hexIp.startsWith("0000000000000000FFFF0000", ignoreCase = true)) {
                val v4Part = hexIp.substring(24, 32)
                val b1 = v4Part.substring(6, 8).toIntOrNull(16) ?: 0
                val b2 = v4Part.substring(4, 6).toIntOrNull(16) ?: 0
                val b3 = v4Part.substring(2, 4).toIntOrNull(16) ?: 0
                val b4 = v4Part.substring(0, 2).toIntOrNull(16) ?: 0
                return "$b1.$b2.$b3.$b4" to port
            }
            if (hexIp.all { it == '0' }) return "::" to port
            return "ipv6" to port
        }
        return "0.0.0.0" to port
    }

    private fun decodeSocketState(stateHex: String, isUdp: Boolean): String {
        if (isUdp) return "ACTIVE_UDP"
        return when (stateHex.uppercase(Locale.US)) {
            "01" -> "ESTABLISHED"
            "02" -> "SYN_SENT"
            "03" -> "SYN_RECV"
            "04" -> "FIN_WAIT1"
            "05" -> "FIN_WAIT2"
            "06" -> "TIME_WAIT"
            "07" -> "CLOSE"
            "08" -> "CLOSE_WAIT"
            "09" -> "LAST_ACK"
            "0A" -> "LISTEN"
            "0B" -> "CLOSING"
            else -> "ACTIVE"
        }
    }

    private fun resolvePortServiceLabel(port: Int, proto: String): String {
        return when (port) {
            443 -> if (proto.startsWith("UDP")) "QUIC/HTTP3 (443)" else "HTTPS/TLS (443)"
            80, 8080 -> "HTTP ($port)"
            53 -> "DNS (53)"
            853 -> "DNS-over-TLS (853)"
            5228, 5229, 5230 -> "Google Push/FCM ($port)"
            123 -> "NTP Time (123)"
            22 -> "SSH (22)"
            else -> "$proto:$port"
        }
    }

    fun resolvePackageIdentifier(target: String): String? {
        com.kavach.hardware.AppGuardManager.activeInstance?.resolvePackageIdentifier(target)?.let { return it }
        val clean = target.trim()
        if (clean.isEmpty()) return null
        val pm = context.packageManager
        return try {
            val apps = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                pm.getInstalledApplications(PackageManager.ApplicationInfoFlags.of(0L))
            } else {
                @Suppress("DEPRECATION")
                pm.getInstalledApplications(0)
            }
            apps.firstOrNull {
                it.packageName.equals(clean, ignoreCase = true) ||
                    pm.getApplicationLabel(it)?.toString()?.equals(clean, ignoreCase = true) == true ||
                    pm.getApplicationLabel(it)?.toString()?.contains(clean, ignoreCase = true) == true ||
                    it.packageName.contains(clean, ignoreCase = true)
            }?.packageName
        } catch (_: Throwable) {
            null
        }
    }

    private fun resolvePackageForUid(uid: Int): String {
        if (uid <= 0) return ""
        uidToPackageCache[uid]?.let { return it }
        return try {
            val pkgs = context.packageManager.getPackagesForUid(uid)
            val chosen = pkgs?.firstOrNull().orEmpty()
            if (chosen.isNotBlank()) {
                uidToPackageCache[uid] = chosen
            }
            chosen
        } catch (_: Throwable) {
            ""
        }
    }

    private fun resolvePackageUid(pkg: String): Int {
        return try {
            val pm = context.packageManager
            val info = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                pm.getApplicationInfo(pkg, PackageManager.ApplicationInfoFlags.of(0L))
            } else {
                @Suppress("DEPRECATION")
                pm.getApplicationInfo(pkg, 0)
            }
            info.uid
        } catch (_: Throwable) {
            -1
        }
    }

    private fun resolveAppLabel(pkg: String): String {
        if (pkg.isBlank()) return ""
        packageToLabelCache[pkg]?.let { return it }
        return try {
            val pm = context.packageManager
            val info = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                pm.getApplicationInfo(pkg, PackageManager.ApplicationInfoFlags.of(0L))
            } else {
                @Suppress("DEPRECATION")
                pm.getApplicationInfo(pkg, 0)
            }
            val label = pm.getApplicationLabel(info)?.toString()?.trim().orEmpty().ifEmpty { pkg }
            packageToLabelCache[pkg] = label
            label
        } catch (_: Throwable) {
            pkg
        }
    }

    private fun queryForegroundPackage(): String {
        val now = System.currentTimeMillis()
        if (cachedForegroundPkg.isNotEmpty() && (now - cachedForegroundTimeMs) < 1200L) {
            return cachedForegroundPkg
        }
        try {
            val rootPkg = AccessibilityServiceRegistry.activeService
                ?.rootInActiveWindow?.packageName?.toString()?.trim().orEmpty()
            if (rootPkg.isNotEmpty() && rootPkg != "com.android.systemui") {
                cachedForegroundPkg = rootPkg
                cachedForegroundTimeMs = now
                return rootPkg
            }
        } catch (_: Throwable) {}
        return try {
            val usm = context.getSystemService(Context.USAGE_STATS_SERVICE) as? UsageStatsManager ?: return cachedForegroundPkg
            val stats = usm.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, now - 60_000L, now)
            val resolved = stats?.maxByOrNull { it.lastTimeUsed }?.packageName.orEmpty()
            if (resolved.isNotEmpty()) {
                cachedForegroundPkg = resolved
                cachedForegroundTimeMs = now
            }
            resolved
        } catch (_: Throwable) {
            cachedForegroundPkg
        }
    }
}
