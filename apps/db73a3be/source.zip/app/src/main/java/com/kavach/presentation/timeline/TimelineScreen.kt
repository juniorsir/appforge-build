package com.kavach.presentation.timeline

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.GpsFixed
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Route
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.kavach.data.local.LocationPointEntity
import com.kavach.data.local.TimelineEventEntity
import com.kavach.data.local.VaultCategory
import com.kavach.data.local.VaultSyncStatus
import com.kavach.ui.theme.JetBrainsMonoFamily
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val DeepOledBg = Color(0xFF05070B)
private val GlassSurface = Color(0xFF0C121C)
private val GlassInner = Color(0xFF080D15)
private val HairlineBorder = Color.White.copy(alpha = 0.08f)
private val EmeraldAccent = Color(0xFF10B981)
private val CyanAccent = Color(0xFF38BDF8)
private val AmberAccent = Color(0xFFF59E0B)
private val PurpleAccent = Color(0xFFA855F7)
private val CoralError = Color(0xFFF43F5E)
private val TextPrimary = Color(0xFFF8FAFC)
private val TextSecondary = Color(0xFF8B9AB0)

@Composable
fun TimelineScreen(
    viewModel: TimelineViewModel,
    onNavigateBack: () -> Unit
) {
    BackHandler(onBack = onNavigateBack)

    val state by viewModel.uiState.collectAsStateWithLifecycle()

    LaunchedEffect(Unit) {
        viewModel.refreshSummary()
    }

    Scaffold(
        containerColor = DeepOledBg,
        contentWindowInsets = WindowInsets(0, 0, 0, 0)
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(DeepOledBg)
                .padding(innerPadding)
                .windowInsetsPadding(WindowInsets.safeDrawing),
            contentAlignment = Alignment.TopCenter
        ) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 640.dp),
                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item(key = "header") {
                    TimelineTopBar(
                        isOnline = state.uiSummary.isOnline,
                        isBridgeConnected = state.uiSummary.isBridgeConnected,
                        onBack = onNavigateBack,
                        onRefresh = { viewModel.refreshSummary() }
                    )
                }

                item(key = "vault_health") {
                    VaultHealthCard(
                        state = state,
                        onSyncNow = { viewModel.triggerSyncNow() },
                        onExportJson = { viewModel.exportVault("json") },
                        onExportGpx = { viewModel.exportVault("gpx") },
                        onPruneExpired = { viewModel.pruneExpired() }
                    )
                }

                if (state.actionFeedback != null) {
                    item(key = "feedback_banner") {
                        Surface(
                            color = CyanAccent.copy(alpha = 0.12f),
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(0.8.dp, CyanAccent.copy(alpha = 0.4f))
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = state.actionFeedback.orEmpty(),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextPrimary,
                                    modifier = Modifier.weight(1f)
                                )
                                IconButton(
                                    onClick = { viewModel.dismissFeedback() },
                                    modifier = Modifier.minimumInteractiveComponentSize()
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Close,
                                        contentDescription = "Dismiss notification",
                                        tint = CyanAccent,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }
                    }
                }

                item(key = "filters") {
                    FiltersSection(
                        state = state,
                        onSelectCategory = viewModel::selectCategory,
                        onSelectWindow = viewModel::selectWindow,
                        onSearchChange = viewModel::updateSearchQuery,
                        onTogglePendingOnly = viewModel::togglePendingOnly
                    )
                }

                if (state.selectedCategory == TimelineCategoryFilter.ALL ||
                    state.selectedCategory == TimelineCategoryFilter.LOCATION
                ) {
                    item(key = "gps_path_card") {
                        GpsPathPreviewCard(
                            waypoints = state.locationPath,
                            selectedIndex = state.selectedWaypointIndex,
                            totalDistanceMeters = state.totalDistanceMeters,
                            maxSpeedKmh = state.maxSpeedKmh,
                            onStepWaypoint = { delta -> viewModel.stepWaypoint(delta, state.locationPath.size) },
                            onCaptureFix = { viewModel.captureGpsFixNow() }
                        )
                    }
                }

                item(key = "stream_header") {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 2.dp, start = 2.dp, end = 2.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "CHRONOLOGICAL TIMELINE (${state.events.size})",
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontFamily = JetBrainsMonoFamily,
                                letterSpacing = 0.8.sp
                            ),
                            color = TextSecondary
                        )
                        Text(
                            text = "Retained 20d post-sync",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontFamily = JetBrainsMonoFamily
                            ),
                            color = EmeraldAccent
                        )
                    }
                }

                if (state.events.isEmpty()) {
                    item(key = "empty_events") {
                        Surface(
                            color = GlassSurface,
                            shape = RoundedCornerShape(16.dp),
                            border = BorderStroke(0.8.dp, HairlineBorder),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(24.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.CloudOff,
                                    contentDescription = "Empty timeline",
                                    tint = TextSecondary,
                                    modifier = Modifier.size(30.dp)
                                )
                                Text(
                                    text = "No matching events in this window",
                                    style = MaterialTheme.typography.titleSmall,
                                    color = TextPrimary
                                )
                                Text(
                                    text = "AeroShare is continuously recording GPS movement, app launches, unlocks, notifications, DNS queries, and battery/network changes locally.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondary
                                )
                            }
                        }
                    }
                } else {
                    items(
                        items = state.events,
                        key = { it.id }
                    ) { event ->
                        TimelineEventCard(event = event)
                    }
                }

                item { Spacer(modifier = Modifier.height(16.dp)) }
            }
        }
    }
}

@Composable
private fun TimelineTopBar(
    isOnline: Boolean,
    isBridgeConnected: Boolean,
    onBack: () -> Unit,
    onRefresh: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            IconButton(
                onClick = onBack,
                modifier = Modifier
                    .minimumInteractiveComponentSize()
                    .testTag("timeline_back_button")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Back to Dashboard",
                    tint = TextPrimary
                )
            }
            Column {
                Text(
                    text = "Offline State Vault",
                    style = MaterialTheme.typography.titleLarge,
                    color = TextPrimary
                )
                Text(
                    text = "Always-on local timeline · 20d post-sync TTL",
                    style = MaterialTheme.typography.labelSmall,
                    color = TextSecondary
                )
            }
        }

        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            val badgeColor = when {
                isBridgeConnected -> EmeraldAccent
                isOnline -> CyanAccent
                else -> AmberAccent
            }
            val badgeLabel = when {
                isBridgeConnected -> "RELAY LIVE"
                isOnline -> "NET ONLY"
                else -> "OFFLINE"
            }
            Surface(
                color = badgeColor.copy(alpha = 0.14f),
                shape = RoundedCornerShape(50),
                border = BorderStroke(0.8.dp, badgeColor.copy(alpha = 0.4f))
            ) {
                Text(
                    text = badgeLabel,
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontFamily = JetBrainsMonoFamily,
                        fontSize = 10.sp
                    ),
                    color = badgeColor,
                    modifier = Modifier.padding(horizontal = 9.dp, vertical = 4.dp)
                )
            }

            IconButton(
                onClick = onRefresh,
                modifier = Modifier
                    .minimumInteractiveComponentSize()
                    .testTag("timeline_refresh_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Refresh,
                    contentDescription = "Refresh vault stats",
                    tint = TextSecondary,
                    modifier = Modifier.size(19.dp)
                )
            }
        }
    }
}

@Composable
private fun VaultHealthCard(
    state: TimelineUiState,
    onSyncNow: () -> Unit,
    onExportJson: () -> Unit,
    onExportGpx: () -> Unit,
    onPruneExpired: () -> Unit
) {
    val s = state.countSummary
    val pendingTotal = s.pendingEvents + s.pendingLocations + s.pendingSnapshots
    val syncedTotal = s.syncedEvents + s.syncedLocations + s.syncedSnapshots
    val oldestPendingText = if ((s.oldestPendingTimestamp ?: 0L) > 0L) {
        SimpleDateFormat("MMM d HH:mm", Locale.US).format(Date(s.oldestPendingTimestamp!!))
    } else {
        "None"
    }
    val lastSyncText = if (s.lastSuccessfulSyncAt > 0L) {
        SimpleDateFormat("MMM d HH:mm", Locale.US).format(Date(s.lastSuccessfulSyncAt))
    } else {
        "Awaiting reconnect"
    }

    Surface(
        color = GlassSurface,
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(0.8.dp, HairlineBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                VaultStatPill(
                    label = "Queued Offline",
                    value = pendingTotal.toString(),
                    accent = if (pendingTotal > 0) AmberAccent else EmeraldAccent,
                    modifier = Modifier.weight(1f)
                )
                VaultStatPill(
                    label = "Synced (20d)",
                    value = syncedTotal.toString(),
                    accent = EmeraldAccent,
                    modifier = Modifier.weight(1f)
                )
                VaultStatPill(
                    label = "GPS Points",
                    value = s.totalLocations.toString(),
                    accent = CyanAccent,
                    modifier = Modifier.weight(1f)
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Oldest pending: $oldestPendingText",
                    style = MaterialTheme.typography.labelSmall.copy(fontFamily = JetBrainsMonoFamily),
                    color = TextSecondary
                )
                Text(
                    text = "Last sync: $lastSyncText",
                    style = MaterialTheme.typography.labelSmall.copy(fontFamily = JetBrainsMonoFamily),
                    color = TextSecondary
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = onSyncNow,
                    enabled = !state.uiSummary.isSyncing,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = EmeraldAccent.copy(alpha = 0.2f),
                        contentColor = EmeraldAccent
                    ),
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("timeline_sync_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.CloudUpload,
                        contentDescription = "Push pending batch",
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(Modifier.width(6.dp))
                    Text(
                        text = if (state.uiSummary.isSyncing) "Syncing..." else "Push Sync",
                        style = MaterialTheme.typography.labelMedium
                    )
                }

                OutlinedButton(
                    onClick = onExportJson,
                    border = BorderStroke(0.8.dp, CyanAccent.copy(alpha = 0.45f)),
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 8.dp),
                    modifier = Modifier.testTag("timeline_export_json_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Download,
                        contentDescription = "Export JSON",
                        tint = CyanAccent,
                        modifier = Modifier.size(15.dp)
                    )
                    Spacer(Modifier.width(4.dp))
                    Text("JSON", style = MaterialTheme.typography.labelMedium, color = CyanAccent)
                }

                OutlinedButton(
                    onClick = onExportGpx,
                    border = BorderStroke(0.8.dp, PurpleAccent.copy(alpha = 0.45f)),
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 8.dp),
                    modifier = Modifier.testTag("timeline_export_gpx_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Route,
                        contentDescription = "Export GPX track",
                        tint = PurpleAccent,
                        modifier = Modifier.size(15.dp)
                    )
                    Spacer(Modifier.width(4.dp))
                    Text("GPX", style = MaterialTheme.typography.labelMedium, color = PurpleAccent)
                }

                IconButton(
                    onClick = onPruneExpired,
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("timeline_prune_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.DeleteSweep,
                        contentDescription = "Prune expired >20d records",
                        tint = TextSecondary,
                        modifier = Modifier.size(19.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun VaultStatPill(
    label: String,
    value: String,
    accent: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        color = GlassInner,
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(0.6.dp, accent.copy(alpha = 0.25f)),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            Text(
                text = value,
                style = MaterialTheme.typography.titleMedium.copy(
                    fontFamily = JetBrainsMonoFamily,
                    fontWeight = FontWeight.Bold
                ),
                color = accent
            )
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = TextSecondary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun FiltersSection(
    state: TimelineUiState,
    onSelectCategory: (TimelineCategoryFilter) -> Unit,
    onSelectWindow: (TimelineWindowFilter) -> Unit,
    onSearchChange: (String) -> Unit,
    onTogglePendingOnly: () -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedTextField(
            value = state.searchQuery,
            onValueChange = onSearchChange,
            singleLine = true,
            placeholder = {
                Text(
                    text = "Search apps, blocked domains, Wi-Fi SSIDs, notifications...",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
            },
            leadingIcon = {
                Icon(
                    imageVector = Icons.Default.Search,
                    contentDescription = "Search timeline",
                    tint = TextSecondary,
                    modifier = Modifier.size(18.dp)
                )
            },
            trailingIcon = {
                if (state.searchQuery.isNotEmpty()) {
                    IconButton(onClick = { onSearchChange("") }) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Clear search",
                            tint = TextSecondary,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            },
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = GlassSurface,
                unfocusedContainerColor = GlassSurface,
                focusedBorderColor = CyanAccent.copy(alpha = 0.6f),
                unfocusedBorderColor = HairlineBorder,
                focusedTextColor = TextPrimary,
                unfocusedTextColor = TextPrimary
            ),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("timeline_search_input")
        )

        // Category Chips
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            TimelineCategoryFilter.entries.forEach { cat ->
                val selected = state.selectedCategory == cat
                val chipColor = when (cat) {
                    TimelineCategoryFilter.ALL -> CyanAccent
                    TimelineCategoryFilter.LOCATION -> EmeraldAccent
                    TimelineCategoryFilter.APPS_UNLOCKS -> PurpleAccent
                    TimelineCategoryFilter.NOTIFICATIONS -> CyanAccent
                    TimelineCategoryFilter.DNS -> CoralError
                    TimelineCategoryFilter.POWER_NET -> AmberAccent
                }
                FilterChipPill(
                    label = cat.label,
                    selected = selected,
                    accent = chipColor,
                    tag = "timeline_filter_${cat.name.lowercase()}",
                    onClick = { onSelectCategory(cat) }
                )
            }
        }

        // Window + Pending-only Toggle
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            TimelineWindowFilter.entries.forEach { win ->
                FilterChipPill(
                    label = win.label,
                    selected = state.selectedWindow == win,
                    accent = CyanAccent,
                    tag = "timeline_window_${win.name.lowercase()}",
                    onClick = { onSelectWindow(win) }
                )
            }

            FilterChipPill(
                label = if (state.pendingOnly) "Queue Only ✓" else "Queue Only",
                selected = state.pendingOnly,
                accent = AmberAccent,
                tag = "timeline_pending_toggle",
                onClick = onTogglePendingOnly
            )
        }
    }
}

@Composable
private fun FilterChipPill(
    label: String,
    selected: Boolean,
    accent: Color,
    tag: String,
    onClick: () -> Unit
) {
    Surface(
        color = if (selected) accent.copy(alpha = 0.2f) else GlassSurface,
        shape = RoundedCornerShape(50),
        border = BorderStroke(
            width = 0.8.dp,
            color = if (selected) accent.copy(alpha = 0.7f) else HairlineBorder
        ),
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .clickable(onClick = onClick)
            .testTag(tag)
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall.copy(
                fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal
            ),
            color = if (selected) accent else TextSecondary,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp)
        )
    }
}

@Composable
private fun GpsPathPreviewCard(
    waypoints: List<LocationPointEntity>,
    selectedIndex: Int,
    totalDistanceMeters: Float,
    maxSpeedKmh: Float,
    onStepWaypoint: (Int) -> Unit,
    onCaptureFix: () -> Unit
) {
    Surface(
        color = GlassSurface,
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(0.8.dp, EmeraldAccent.copy(alpha = 0.25f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Route,
                        contentDescription = "GPS Path",
                        tint = EmeraldAccent,
                        modifier = Modifier.size(18.dp)
                    )
                    Text(
                        text = "GPS MOVEMENT PATH",
                        style = MaterialTheme.typography.labelMedium.copy(fontFamily = JetBrainsMonoFamily),
                        color = EmeraldAccent
                    )
                }

                TextButton(
                    onClick = onCaptureFix,
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                    modifier = Modifier.testTag("timeline_capture_gps_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.GpsFixed,
                        contentDescription = "Capture GPS Fix",
                        tint = CyanAccent,
                        modifier = Modifier.size(15.dp)
                    )
                    Spacer(Modifier.width(4.dp))
                    Text("Capture Fix", style = MaterialTheme.typography.labelSmall, color = CyanAccent)
                }
            }

            if (waypoints.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(110.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(GlassInner),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "No GPS waypoints stored in this window yet",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                }
            } else {
                // Interactive Path Canvas
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(160.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(GlassInner)
                ) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val w = size.width
                        val h = size.height
                        val pad = 28f

                        // Radar grid
                        val gridColor = Color.White.copy(alpha = 0.05f)
                        for (i in 1..3) {
                            val gx = w * (i / 4f)
                            val gy = h * (i / 4f)
                            drawLine(gridColor, Offset(gx, 0f), Offset(gx, h), strokeWidth = 1f)
                            drawLine(gridColor, Offset(0f, gy), Offset(w, gy), strokeWidth = 1f)
                        }

                        val minLat = waypoints.minOf { it.latitude }
                        val maxLat = waypoints.maxOf { it.latitude }
                        val minLon = waypoints.minOf { it.longitude }
                        val maxLon = waypoints.maxOf { it.longitude }
                        val latSpan = (maxLat - minLat).coerceAtLeast(0.0005)
                        val lonSpan = (maxLon - minLon).coerceAtLeast(0.0005)

                        val coords = waypoints.map { pt ->
                            val nx = ((pt.longitude - minLon) / lonSpan).toFloat()
                            val ny = 1f - ((pt.latitude - minLat) / latSpan).toFloat()
                            Offset(
                                x = pad + nx * (w - pad * 2f),
                                y = pad + ny * (h - pad * 2f)
                            )
                        }

                        if (coords.size >= 2) {
                            val routePath = Path().apply {
                                moveTo(coords.first().x, coords.first().y)
                                for (idx in 1 until coords.size) {
                                    lineTo(coords[idx].x, coords[idx].y)
                                }
                            }
                            drawPath(
                                path = routePath,
                                color = EmeraldAccent.copy(alpha = 0.85f),
                                style = Stroke(width = 4.5f, cap = StrokeCap.Round, join = StrokeJoin.Round)
                            )
                        }

                        // Waypoint dots
                        coords.forEachIndexed { idx, pt ->
                            val isStart = idx == 0
                            val isEnd = idx == coords.lastIndex
                            val isSelected = idx == selectedIndex
                            val dotColor = when {
                                isSelected -> AmberAccent
                                isStart -> CyanAccent
                                isEnd -> EmeraldAccent
                                else -> EmeraldAccent.copy(alpha = 0.55f)
                            }
                            val radius = when {
                                isSelected -> 9f
                                isStart || isEnd -> 6.5f
                                else -> 3.5f
                            }
                            drawCircle(color = dotColor, radius = radius, center = pt)
                            if (isSelected) {
                                drawCircle(
                                    color = AmberAccent.copy(alpha = 0.35f),
                                    radius = 16f,
                                    center = pt,
                                    style = Stroke(width = 2.5f)
                                )
                            }
                        }
                    }

                    // Overlay distance & speed badge
                    val distLabel = if (totalDistanceMeters >= 1000f) {
                        String.format(Locale.US, "%.2f km", totalDistanceMeters / 1000f)
                    } else {
                        String.format(Locale.US, "%.0f m", totalDistanceMeters)
                    }
                    Surface(
                        color = DeepOledBg.copy(alpha = 0.82f),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .align(Alignment.TopStart)
                            .padding(8.dp)
                    ) {
                        Text(
                            text = "${waypoints.size} pts · $distLabel · max ${String.format(Locale.US, "%.1f", maxSpeedKmh)} km/h",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontFamily = JetBrainsMonoFamily,
                                fontSize = 10.sp
                            ),
                            color = EmeraldAccent,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }

                // Selected waypoint inspector + prev/next stepper
                val activeWp = waypoints.getOrNull(selectedIndex)
                if (activeWp != null) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        IconButton(
                            onClick = { onStepWaypoint(-1) },
                            enabled = selectedIndex > 0,
                            modifier = Modifier
                                .minimumInteractiveComponentSize()
                                .testTag("timeline_waypoint_prev")
                        ) {
                            Icon(
                                imageVector = Icons.Default.ChevronLeft,
                                contentDescription = "Previous GPS point",
                                tint = if (selectedIndex > 0) TextPrimary else TextSecondary.copy(alpha = 0.3f)
                            )
                        }

                        Column(
                            modifier = Modifier.weight(1f),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = String.format(
                                    Locale.US,
                                    "#%d/%d · %.5f, %.5f (±%dm)",
                                    selectedIndex + 1,
                                    waypoints.size,
                                    activeWp.latitude,
                                    activeWp.longitude,
                                    activeWp.accuracyMeters.toInt()
                                ),
                                style = MaterialTheme.typography.labelSmall.copy(fontFamily = JetBrainsMonoFamily),
                                color = AmberAccent,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            val timeStr = SimpleDateFormat("MMM d HH:mm:ss", Locale.US).format(Date(activeWp.timestamp))
                            Text(
                                text = "$timeStr · ${activeWp.networkTransport} · Batt ${activeWp.batteryPercent}%",
                                style = MaterialTheme.typography.labelSmall,
                                color = TextSecondary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }

                        IconButton(
                            onClick = { onStepWaypoint(1) },
                            enabled = selectedIndex < waypoints.lastIndex,
                            modifier = Modifier
                                .minimumInteractiveComponentSize()
                                .testTag("timeline_waypoint_next")
                        ) {
                            Icon(
                                imageVector = Icons.Default.ChevronRight,
                                contentDescription = "Next GPS point",
                                tint = if (selectedIndex < waypoints.lastIndex) TextPrimary else TextSecondary.copy(alpha = 0.3f)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TimelineEventCard(event: TimelineEventEntity) {
    var expanded by remember { mutableStateOf(false) }

    val (icon, accent) = categoryIconAndColor(event.category, event.severity)
    val isSynced = event.syncStatus == VaultSyncStatus.SYNCED
    val timeFormatted = SimpleDateFormat("MMM d · HH:mm:ss", Locale.US).format(Date(event.timestamp))

    val syncBadgeText = if (isSynced && event.expiresAt != null) {
        val daysLeft = ((event.expiresAt - System.currentTimeMillis()) / 86_400_000L).coerceAtLeast(0L)
        "Synced · ${daysLeft}d left"
    } else if (isSynced) {
        "Synced · 20d"
    } else {
        "Queued Offline"
    }
    val syncColor = if (isSynced) EmeraldAccent else AmberAccent

    Surface(
        color = GlassSurface,
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(
            width = 0.8.dp,
            color = if (event.severity == "BLOCKED") CoralError.copy(alpha = 0.45f) else HairlineBorder
        ),
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .clickable { expanded = !expanded }
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.Top,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(34.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(accent.copy(alpha = 0.14f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = event.category,
                        tint = accent,
                        modifier = Modifier.size(18.dp)
                    )
                }

                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = event.subType,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontFamily = JetBrainsMonoFamily,
                                fontSize = 10.sp
                            ),
                            color = accent
                        )
                        Text(
                            text = timeFormatted,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontFamily = JetBrainsMonoFamily,
                                fontSize = 10.sp
                            ),
                            color = TextSecondary
                        )
                    }

                    Text(
                        text = event.title,
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                        color = TextPrimary,
                        maxLines = if (expanded) 4 else 1,
                        overflow = TextOverflow.Ellipsis
                    )

                    Text(
                        text = event.detail,
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary,
                        maxLines = if (expanded) 8 else 2,
                        overflow = TextOverflow.Ellipsis
                    )

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = if (isSynced) Icons.Default.CloudDone else Icons.Default.CloudOff,
                                contentDescription = syncBadgeText,
                                tint = syncColor,
                                modifier = Modifier.size(13.dp)
                            )
                            Text(
                                text = syncBadgeText,
                                style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                                color = syncColor
                            )
                        }

                        if (event.packageName.isNotBlank() || event.domain.isNotBlank()) {
                            Text(
                                text = event.domain.ifBlank { event.packageName },
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontFamily = JetBrainsMonoFamily,
                                    fontSize = 10.sp
                                ),
                                color = TextSecondary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }

            AnimatedVisibility(visible = expanded) {
                Column(modifier = Modifier.padding(top = 8.dp)) {
                    HorizontalDivider(color = HairlineBorder)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        text = "Metadata: ${event.metadataJson}",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontFamily = JetBrainsMonoFamily,
                            fontSize = 10.sp
                        ),
                        color = TextSecondary
                    )
                }
            }
        }
    }
}

private fun categoryIconAndColor(category: String, severity: String): Pair<ImageVector, Color> {
    if (severity == "BLOCKED") return Icons.Default.Shield to CoralError
    return when (category) {
        VaultCategory.LOCATION -> Icons.Default.LocationOn to EmeraldAccent
        VaultCategory.APP -> Icons.Default.Apps to PurpleAccent
        VaultCategory.UNLOCK -> Icons.Default.LockOpen to AmberAccent
        VaultCategory.NOTIFICATION -> Icons.Default.Notifications to CyanAccent
        VaultCategory.DNS -> Icons.Default.Public to CyanAccent
        VaultCategory.POWER -> Icons.Default.BatteryChargingFull to AmberAccent
        VaultCategory.NETWORK -> Icons.Default.Wifi to EmeraldAccent
        else -> Icons.Default.LocationOn to TextSecondary
    }
}
