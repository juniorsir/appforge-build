package com.kavach.ui.overlay

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.lang.ref.WeakReference

/**
 * High-priority visual block screen activity.
 * Guaranteed to appear on top of all applications when a restricted or adult
 * website is blocked by AeroShare network moderation.
 */
class BlockScreenActivity : ComponentActivity() {

    private data class BlockScreenUiState(
        val domain: String,
        val reason: String,
        val category: String,
        val customMessage: String,
        val autoDismissSeconds: Int,
        val isPreview: Boolean,
        val version: Int
    )

    private var uiState by mutableStateOf(
        BlockScreenUiState(
            domain = "restricted-site.com",
            reason = "Content Policy",
            category = "RESTRICTED",
            customMessage = "Restricted content is not allowed on this device",
            autoDismissSeconds = 6,
            isPreview = false,
            version = 0
        )
    )

    companion object {
        @Volatile
        private var activeRef: WeakReference<BlockScreenActivity>? = null

        fun dismissIfActive() {
            val activity = activeRef?.get() ?: return
            activity.runOnUiThread {
                if (!activity.isFinishing && !activity.isDestroyed) {
                    activity.finish()
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        activeRef = WeakReference(this)
        updateStateFromIntent(intent)

        setContent {
            val state = uiState
            BlockScreenContent(
                domain = state.domain,
                reason = state.reason,
                category = state.category,
                customMessage = state.customMessage,
                autoDismissSeconds = state.autoDismissSeconds,
                isPreview = state.isPreview,
                stateVersion = state.version,
                onDismiss = { finish() }
            )
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        updateStateFromIntent(intent)
    }

    override fun onDestroy() {
        if (activeRef?.get() === this) {
            activeRef = null
        }
        super.onDestroy()
    }

    private fun updateStateFromIntent(sourceIntent: Intent?) {
        val domain = sourceIntent?.getStringExtra("BLOCK_DOMAIN") ?: "restricted-site.com"
        val reason = sourceIntent?.getStringExtra("BLOCK_REASON") ?: "Content Policy"
        val category = sourceIntent?.getStringExtra("BLOCK_CATEGORY") ?: "RESTRICTED"
        val customMsg = sourceIntent?.getStringExtra("BLOCK_MESSAGE")
            ?.takeIf { it.isNotBlank() }
            ?: "Restricted content is not allowed on this device"
        val dismissSec = sourceIntent?.getIntExtra("BLOCK_DISMISS_SEC", 6) ?: 6
        val isPreview = sourceIntent?.getBooleanExtra("IS_PREVIEW", false) ?: false

        uiState = BlockScreenUiState(
            domain = domain,
            reason = reason,
            category = category,
            customMessage = customMsg,
            autoDismissSeconds = dismissSec,
            isPreview = isPreview,
            version = uiState.version + 1
        )
    }

    @Composable
    private fun BlockScreenContent(
        domain: String,
        reason: String,
        category: String,
        customMessage: String,
        autoDismissSeconds: Int,
        isPreview: Boolean,
        stateVersion: Int,
        onDismiss: () -> Unit
    ) {
        var secondsRemaining by remember(stateVersion, autoDismissSeconds) {
            mutableIntStateOf(if (autoDismissSeconds > 0) autoDismissSeconds else 6)
        }

        if (autoDismissSeconds > 0) {
            LaunchedEffect(stateVersion, autoDismissSeconds) {
                secondsRemaining = autoDismissSeconds
                while (secondsRemaining > 0) {
                    delay(1000L)
                    secondsRemaining--
                }
                onDismiss()
            }
        }

        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xCC0A0A12))
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null
                ) { /* Don't dismiss when tapping outside accidentally */ },
            contentAlignment = Alignment.Center
        ) {
            AnimatedVisibility(
                visible = true,
                enter = fadeIn(tween(250)) + slideInVertically(tween(300)) { it / 4 }
            ) {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth(0.92f)
                        .widthIn(max = 400.dp)
                        .padding(16.dp)
                        .testTag("block_screen_card"),
                    shape = RoundedCornerShape(20.dp),
                    color = Color(0xFF111722),
                    tonalElevation = 8.dp,
                    shadowElevation = 16.dp
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        // Header row with Icon, Badge, and Close Button
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(44.dp)
                                    .clip(CircleShape)
                                    .background(Color(0x26F43F5E)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Shield,
                                    contentDescription = "Blocked",
                                    tint = Color(0xFFF43F5E),
                                    modifier = Modifier.size(24.dp)
                                )
                            }

                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(50))
                                    .background(
                                        if (isPreview) Color(0x2438BDF8) else Color(0x24F43F5E)
                                    )
                                    .padding(horizontal = 10.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = if (isPreview) "PREVIEW" else category,
                                    color = if (isPreview) Color(0xFF38BDF8) else Color(0xFFF43F5E),
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            IconButton(
                                onClick = onDismiss,
                                modifier = Modifier.testTag("block_screen_close_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "Close",
                                    tint = Color(0xFF94A3B8)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Text(
                            text = if (isPreview) "Block Screen" else "Restricted",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFF8FAFC)
                            ),
                            textAlign = TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = domain,
                            style = MaterialTheme.typography.bodyMedium.copy(
                                fontFamily = FontFamily.Monospace,
                                color = Color(0xFFF43F5E),
                                fontWeight = FontWeight.SemiBold
                            ),
                            textAlign = TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            color = Color(0xFF0A0E14)
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Text(
                                    text = customMessage,
                                    style = MaterialTheme.typography.bodyLarge.copy(
                                        fontWeight = FontWeight.Medium,
                                        color = Color(0xFFF8FAFC)
                                    ),
                                    textAlign = TextAlign.Center
                                )

                                Text(
                                    text = reason,
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = Color(0xFF94A3B8),
                                        fontFamily = FontFamily.Monospace
                                    ),
                                    textAlign = TextAlign.Center
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(18.dp))

                        if (autoDismissSeconds > 0) {
                            val progress = (secondsRemaining.toFloat() / autoDismissSeconds.toFloat()).coerceIn(0f, 1f)
                            LinearProgressIndicator(
                                progress = { progress },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(4.dp)
                                    .clip(RoundedCornerShape(2.dp)),
                                color = Color(0xFFF43F5E),
                                trackColor = Color(0xFF1F2A3C)
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "${secondsRemaining}s",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = Color(0xFF94A3B8),
                                    fontFamily = FontFamily.Monospace
                                )
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                        }

                        Button(
                            onClick = onDismiss,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("block_screen_dismiss_button"),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFFF43F5E),
                                contentColor = Color.White
                            ),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text(
                                text = "Dismiss",
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                            )
                        }
                    }
                }
            }
        }
    }
}
