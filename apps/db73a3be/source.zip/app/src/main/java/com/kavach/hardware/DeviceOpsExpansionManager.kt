package com.kavach.hardware

import android.app.AppOpsManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.usage.UsageStatsManager
import android.content.BroadcastReceiver
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.PowerManager
import android.os.Process
import android.provider.Settings
import androidx.core.app.NotificationCompat
import com.kavach.R
import com.kavach.camera.BackgroundCameraCaptureEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

data class AppUsageQuotaItem(
    val packageName: String,
    val appName: String,
    val dailyLimitMinutes: Int,
    val usedTodayMinutes: Int = 0,
    val usedTodaySeconds: Int = 0,
    val isQuotaExceeded: Boolean = false
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("packageName", packageName)
        put("appName", appName)
        put("dailyLimitMinutes", dailyLimitMinutes)
        put("usedTodayMinutes", usedTodayMinutes)
        put("usedTodaySeconds", usedTodaySeconds)
        put("remainingMinutes", (dailyLimitMinutes - usedTodayMinutes).coerceAtLeast(0))
        put("isQuotaExceeded", isQuotaExceeded)
    }
}

data class UnlockSecurityEvent(
    val id: String,
    val eventType: String, // DEVICE_UNLOCKED, SCREEN_ON, SCREEN_OFF, INTRUDER_SNAP
    val foregroundPackage: String,
    val foregroundAppName: String,
    val batteryPercent: Int,
    val photoPath: String = "",
    val details: String = "",
    val timestampMs: Long = System.currentTimeMillis()
) {
    val formattedTime: String
        get() = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date(timestampMs))

    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("eventType", eventType)
        put("foregroundPackage", foregroundPackage)
        put("foregroundAppName", foregroundAppName)
        put("batteryPercent", batteryPercent)
        put("photoPath", photoPath)
        put("details", details)
        put("timestampMs", timestampMs)
        put("formattedTime", formattedTime)
    }
}

data class ClipboardHistoryEntry(
    val id: String,
    val text: String,
    val length: Int,
    val matchedKeywords: List<String> = emptyList(),
    val timestampMs: Long = System.currentTimeMillis()
) {
    val formattedTime: String
        get() = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date(timestampMs))

    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("text", text)
        put("length", length)
        put("matchedKeywords", JSONArray(matchedKeywords))
        put("timestampMs", timestampMs)
        put("formattedTime", formattedTime)
    }
}

data class NotificationHistoryEntry(
    val id: String,
    val packageName: String,
    val appName: String,
    val title: String,
    val text: String,
    val matchedKeywords: List<String> = emptyList(),
    val timestampMs: Long = System.currentTimeMillis()
) {
    val formattedTime: String
        get() = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date(timestampMs))

    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("packageName", packageName)
        put("appName", appName)
        put("title", title)
        put("text", text)
        put("matchedKeywords", JSONArray(matchedKeywords))
        put("timestampMs", timestampMs)
        put("formattedTime", formattedTime)
    }
}

data class AutomationRuleItem(
    val id: String,
    val name: String,
    val enabled: Boolean,
    val triggerType: String,   // battery_below, battery_above, charging, wifi_connected, time_daily, app_opened, device_unlocked
    val triggerValue: String,  // e.g. "20", "true", "23:00", "com.instagram.android"
    val actionType: String,    // torch, dnd, brightness, volume, tts, notify, block_app, unblock_app, force_stop, shell
    val actionValue: String,   // e.g. "on", "30", "Battery low", "com.zhiliaoapp.musically"
    val cooldownMinutes: Int = 15,
    val lastTriggeredMs: Long = 0L,
    val triggerCount: Int = 0
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("name", name)
        put("enabled", enabled)
        put("triggerType", triggerType)
        put("triggerValue", triggerValue)
        put("triggerSpec", if (triggerValue.isNotBlank()) "$triggerType:$triggerValue" else triggerType)
        put("actionType", actionType)
        put("actionValue", actionValue)
        put("actionSpec", if (actionValue.isNotBlank()) "$actionType:$actionValue" else actionType)
        put("cooldownMinutes", cooldownMinutes)
        put("lastTriggeredMs", lastTriggeredMs)
        put(
            "lastTriggeredFormatted",
            if (lastTriggeredMs > 0L) SimpleDateFormat("HH:mm:ss", Locale.US).format(Date(lastTriggeredMs)) else "Never"
        )
        put("triggerCount", triggerCount)
    }
}

/**
 * Coordinates the 5 advanced operational & security suites:
 * 1. App Usage Time Limits & Daily Screen-Time Analytics
 * 2. Intruder & Device Unlock Monitor with Security Alerts & Front-Camera Snap
 * 3. Clipboard & Notification History Logger with Keyword Watch Alerts
 * 4. Scheduled & Event-Driven Automation Rules Engine
 * 5. APK Backup Extractor & Remote APK Installer
 */
class DeviceOpsExpansionManager(
    private val context: Context,
    private val scope: CoroutineScope = CoroutineScope(Dispatchers.IO),
    private val appGuardManager: AppGuardManager,
    private val deviceBridgeManager: DeviceBridgeManager,
    private val backgroundCameraCaptureEngine: BackgroundCameraCaptureEngine,
    var onRealtimeAlertBroadcast: ((String, JSONObject) -> Unit)? = null
) {
    companion object {
        private const val PREFS_NAME = "aero_device_ops_expansion_prefs"
        private const val KEY_USAGE_QUOTAS = "usage_quotas_json"
        private const val KEY_QUOTA_BLOCKED_TODAY = "quota_blocked_today_set"
        private const val KEY_QUOTA_DAY_STAMP = "quota_day_stamp"
        private const val KEY_UNLOCK_ENABLED = "unlock_monitor_enabled"
        private const val KEY_UNLOCK_ALERT = "unlock_alert_enabled"
        private const val KEY_UNLOCK_PHOTO = "unlock_capture_photo"
        private const val KEY_UNLOCK_LOGS = "unlock_logs_json"
        private const val KEY_CLIP_HISTORY = "clipboard_history_json"
        private const val KEY_NOTIF_HISTORY = "notification_history_json"
        private const val KEY_WATCH_KEYWORDS = "watched_keywords_set"
        private const val KEY_AUTOMATION_RULES = "automation_rules_json"
        private const val CHANNEL_ID = "aero_ops_expansion_alerts"

        @Volatile
        var activeInstance: DeviceOpsExpansionManager? = null
            private set
    }

    private val prefs: SharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    private val usageQuotasMap = ConcurrentHashMap<String, Int>() // packageName -> dailyLimitMinutes
    private val quotaAutoBlockedToday = ConcurrentHashMap.newKeySet<String>()
    private var lastClipboardText: String = ""
    private var lastNotifDedupKey: String = ""
    private var lastNotifDedupMs: Long = 0L

    private val _usageQuotasFlow = MutableStateFlow<List<AppUsageQuotaItem>>(emptyList())
    val usageQuotasFlow: StateFlow<List<AppUsageQuotaItem>> = _usageQuotasFlow.asStateFlow()

    private val _unlockEventsFlow = MutableStateFlow<List<UnlockSecurityEvent>>(emptyList())
    val unlockEventsFlow: StateFlow<List<UnlockSecurityEvent>> = _unlockEventsFlow.asStateFlow()

    private val _unlockMonitorEnabled = MutableStateFlow(true)
    val unlockMonitorEnabled: StateFlow<Boolean> = _unlockMonitorEnabled.asStateFlow()

    private val _capturePhotoOnUnlock = MutableStateFlow(false)
    val capturePhotoOnUnlock: StateFlow<Boolean> = _capturePhotoOnUnlock.asStateFlow()

    private val _clipboardHistoryFlow = MutableStateFlow<List<ClipboardHistoryEntry>>(emptyList())
    val clipboardHistoryFlow: StateFlow<List<ClipboardHistoryEntry>> = _clipboardHistoryFlow.asStateFlow()

    private val _notificationHistoryFlow = MutableStateFlow<List<NotificationHistoryEntry>>(emptyList())
    val notificationHistoryFlow: StateFlow<List<NotificationHistoryEntry>> = _notificationHistoryFlow.asStateFlow()

    private val _watchedKeywordsFlow = MutableStateFlow<Set<String>>(emptySet())
    val watchedKeywordsFlow: StateFlow<Set<String>> = _watchedKeywordsFlow.asStateFlow()

    private val _automationRulesFlow = MutableStateFlow<List<AutomationRuleItem>>(emptyList())
    val automationRulesFlow: StateFlow<List<AutomationRuleItem>> = _automationRulesFlow.asStateFlow()

    private var backgroundLoopJob: Job? = null

    private val screenAndUnlockReceiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context?, intent: Intent?) {
            if (intent == null || !_unlockMonitorEnabled.value) return
            when (intent.action) {
                Intent.ACTION_USER_PRESENT -> handleDeviceUnlocked("DEVICE_UNLOCKED", "User unlocked device keyguard")
                Intent.ACTION_SCREEN_ON -> handleDeviceUnlocked("SCREEN_ON", "Display powered on")
                Intent.ACTION_SCREEN_OFF -> handleDeviceUnlocked("SCREEN_OFF", "Display powered off / locked")
            }
        }
    }

    init {
        activeInstance = this
        createNotificationChannel()
        loadPersistedState()
        registerScreenAndUnlockReceiver()
        registerClipboardMonitor()
        startBackgroundEvaluationLoop()
    }

    private fun currentDayStamp(): String =
        SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

    private fun loadPersistedState() {
        val savedDay = prefs.getString(KEY_QUOTA_DAY_STAMP, "") ?: ""
        val today = currentDayStamp()
        if (savedDay != today) {
            prefs.edit()
                .putString(KEY_QUOTA_DAY_STAMP, today)
                .putStringSet(KEY_QUOTA_BLOCKED_TODAY, emptySet())
                .apply()
        } else {
            val savedBlockedToday = prefs.getStringSet(KEY_QUOTA_BLOCKED_TODAY, emptySet()) ?: emptySet()
            quotaAutoBlockedToday.addAll(savedBlockedToday)
        }

        // 1. Load Usage Quotas
        try {
            val qJson = JSONObject(prefs.getString(KEY_USAGE_QUOTAS, "{}").orEmpty().ifBlank { "{}" })
            qJson.keys().forEach { pkg ->
                val mins = qJson.optInt(pkg, 0)
                if (mins > 0) usageQuotasMap[pkg] = mins
            }
        } catch (_: Exception) {}

        // 2. Load Unlock Monitor Settings & History
        _unlockMonitorEnabled.value = prefs.getBoolean(KEY_UNLOCK_ENABLED, true)
        _capturePhotoOnUnlock.value = prefs.getBoolean(KEY_UNLOCK_PHOTO, false)
        try {
            val arr = JSONArray(prefs.getString(KEY_UNLOCK_LOGS, "[]").orEmpty().ifBlank { "[]" })
            val list = mutableListOf<UnlockSecurityEvent>()
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                list.add(
                    UnlockSecurityEvent(
                        id = o.optString("id", "ul_$i"),
                        eventType = o.optString("eventType", "DEVICE_UNLOCKED"),
                        foregroundPackage = o.optString("foregroundPackage", ""),
                        foregroundAppName = o.optString("foregroundAppName", ""),
                        batteryPercent = o.optInt("batteryPercent", 0),
                        photoPath = o.optString("photoPath", ""),
                        details = o.optString("details", ""),
                        timestampMs = o.optLong("timestampMs", System.currentTimeMillis())
                    )
                )
            }
            _unlockEventsFlow.value = list
        } catch (_: Exception) {}

        // 3. Load Clipboard & Notification History + Watched Keywords
        _watchedKeywordsFlow.value = (prefs.getStringSet(KEY_WATCH_KEYWORDS, emptySet()) ?: emptySet()).toSet()
        try {
            val arr = JSONArray(prefs.getString(KEY_CLIP_HISTORY, "[]").orEmpty().ifBlank { "[]" })
            val list = mutableListOf<ClipboardHistoryEntry>()
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val kwArr = o.optJSONArray("matchedKeywords")
                val kws = mutableListOf<String>()
                if (kwArr != null) {
                    for (k in 0 until kwArr.length()) kws.add(kwArr.optString(k))
                }
                list.add(
                    ClipboardHistoryEntry(
                        id = o.optString("id", "clip_$i"),
                        text = o.optString("text", ""),
                        length = o.optInt("length", 0),
                        matchedKeywords = kws,
                        timestampMs = o.optLong("timestampMs", System.currentTimeMillis())
                    )
                )
            }
            _clipboardHistoryFlow.value = list
        } catch (_: Exception) {}

        try {
            val arr = JSONArray(prefs.getString(KEY_NOTIF_HISTORY, "[]").orEmpty().ifBlank { "[]" })
            val list = mutableListOf<NotificationHistoryEntry>()
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val kwArr = o.optJSONArray("matchedKeywords")
                val kws = mutableListOf<String>()
                if (kwArr != null) {
                    for (k in 0 until kwArr.length()) kws.add(kwArr.optString(k))
                }
                list.add(
                    NotificationHistoryEntry(
                        id = o.optString("id", "nf_$i"),
                        packageName = o.optString("packageName", ""),
                        appName = o.optString("appName", ""),
                        title = o.optString("title", ""),
                        text = o.optString("text", ""),
                        matchedKeywords = kws,
                        timestampMs = o.optLong("timestampMs", System.currentTimeMillis())
                    )
                )
            }
            _notificationHistoryFlow.value = list
        } catch (_: Exception) {}

        // 4. Load Automation Rules
        try {
            val arr = JSONArray(prefs.getString(KEY_AUTOMATION_RULES, "[]").orEmpty().ifBlank { "[]" })
            val list = mutableListOf<AutomationRuleItem>()
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                list.add(
                    AutomationRuleItem(
                        id = o.optString("id", "rule_$i"),
                        name = o.optString("name", "Rule ${i + 1}"),
                        enabled = o.optBoolean("enabled", true),
                        triggerType = o.optString("triggerType", "battery_below"),
                        triggerValue = o.optString("triggerValue", "20"),
                        actionType = o.optString("actionType", "notify"),
                        actionValue = o.optString("actionValue", "Low battery"),
                        cooldownMinutes = o.optInt("cooldownMinutes", 15),
                        lastTriggeredMs = o.optLong("lastTriggeredMs", 0L),
                        triggerCount = o.optInt("triggerCount", 0)
                    )
                )
            }
            _automationRulesFlow.value = list
        } catch (_: Exception) {}

        refreshUsageQuotasState()
    }

    // =========================================================================
    // SUITE 1: APP USAGE TIME LIMITS & DAILY SCREEN-TIME ANALYTICS
    // =========================================================================

    fun hasUsageStatsPermission(): Boolean {
        return try {
            val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
            val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                appOps.unsafeCheckOpNoThrow(
                    AppOpsManager.OPSTR_GET_USAGE_STATS,
                    Process.myUid(),
                    context.packageName
                )
            } else {
                @Suppress("DEPRECATION")
                appOps.checkOpNoThrow(
                    AppOpsManager.OPSTR_GET_USAGE_STATS,
                    Process.myUid(),
                    context.packageName
                )
            }
            mode == AppOpsManager.MODE_ALLOWED
        } catch (_: Exception) {
            false
        }
    }

    private fun queryTodayForegroundSecondsByPackage(): Map<String, Long> {
        val result = mutableMapOf<String, Long>()
        try {
            val usm = context.getSystemService(Context.USAGE_STATS_SERVICE) as? UsageStatsManager ?: return result
            val cal = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, 0)
                set(Calendar.MINUTE, 0)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }
            val startOfDayMs = cal.timeInMillis
            val nowMs = System.currentTimeMillis()
            val aggregated = usm.queryAndAggregateUsageStats(startOfDayMs, nowMs)
            for ((pkg, stats) in aggregated) {
                val fgSec = (stats.totalTimeInForeground / 1000L).coerceAtLeast(0L)
                if (fgSec > 0L) {
                    result[pkg] = fgSec
                }
            }
        } catch (_: Exception) {}
        return result
    }

    fun refreshUsageQuotasState() {
        val usageMap = queryTodayForegroundSecondsByPackage()
        val items = usageQuotasMap.entries.map { (pkg, limitMin) ->
            val usedSec = usageMap[pkg]?.toInt() ?: 0
            val usedMin = usedSec / 60
            AppUsageQuotaItem(
                packageName = pkg,
                appName = resolveAppLabel(pkg),
                dailyLimitMinutes = limitMin,
                usedTodayMinutes = usedMin,
                usedTodaySeconds = usedSec,
                isQuotaExceeded = usedMin >= limitMin
            )
        }.sortedByDescending { it.usedTodaySeconds }
        _usageQuotasFlow.value = items
    }

    fun getDailyScreenTimeStatsJson(topN: Int = 25): JSONObject {
        val hasPerm = hasUsageStatsPermission()
        val usageMap = queryTodayForegroundSecondsByPackage()
        val totalSeconds = usageMap.values.sum()
        val totalMinutes = (totalSeconds / 60L).toInt()
        val hours = totalMinutes / 60
        val mins = totalMinutes % 60
        val formattedTotal = if (hours > 0) "${hours}h ${mins}m" else "${mins}m"

        val appsArr = JSONArray()
        usageMap.entries
            .sortedByDescending { it.value }
            .take(topN.coerceIn(1, 100))
            .forEach { (pkg, sec) ->
                val minUsed = (sec / 60L).toInt()
                val limitMin = usageQuotasMap[pkg] ?: 0
                val pct = if (totalSeconds > 0) Math.round((sec.toDouble() / totalSeconds.toDouble()) * 1000.0) / 10.0 else 0.0
                appsArr.put(
                    JSONObject().apply {
                        put("packageName", pkg)
                        put("appName", resolveAppLabel(pkg))
                        put("foregroundSeconds", sec)
                        put("foregroundMinutes", minUsed)
                        put("formattedDuration", if (minUsed >= 60) "${minUsed / 60}h ${minUsed % 60}m" else "${minUsed}m ${sec % 60}s")
                        put("percentOfTotal", pct)
                        put("dailyLimitMinutes", limitMin)
                        put("isQuotaExceeded", limitMin > 0 && minUsed >= limitMin)
                        put("isBlocked", appGuardManager.isPackageBlocked(pkg))
                    }
                )
            }

        refreshUsageQuotasState()
        val quotasArr = JSONArray()
        _usageQuotasFlow.value.forEach { quotasArr.put(it.toJson()) }

        return JSONObject().apply {
            put("success", true)
            put("date", currentDayStamp())
            put("usageAccessPermissionGranted", hasPerm)
            put("totalScreenTimeSeconds", totalSeconds)
            put("totalScreenTimeMinutes", totalMinutes)
            put("totalScreenTimeFormatted", formattedTotal)
            put("activeQuotasCount", usageQuotasMap.size)
            put("quotas", quotasArr)
            put("topAppsCount", appsArr.length())
            put("apps", appsArr)
            if (!hasPerm) {
                put("hint", "Grant Usage Access permission in Settings -> Usage Access for full per-app screen-time analytics.")
            }
        }
    }

    fun setAppUsageLimit(target: String, dailyLimitMinutes: Int): JSONObject {
        val pkg = appGuardManager.resolvePackageIdentifier(target) ?: target.trim()
        if (pkg.isBlank()) {
            return JSONObject().put("success", false).put("error", "Missing app name or package name")
        }
        if (dailyLimitMinutes <= 0) {
            return removeAppUsageLimit(pkg)
        }
        usageQuotasMap[pkg] = dailyLimitMinutes
        saveUsageQuotas()
        evaluateUsageQuotasNow()
        refreshUsageQuotasState()

        val label = resolveAppLabel(pkg)
        val usedSec = queryTodayForegroundSecondsByPackage()[pkg]?.toInt() ?: 0
        val usedMin = usedSec / 60
        return JSONObject().apply {
            put("success", true)
            put("action", "USAGE_LIMIT_SET")
            put("appName", label)
            put("packageName", pkg)
            put("dailyLimitMinutes", dailyLimitMinutes)
            put("usedTodayMinutes", usedMin)
            put("isQuotaExceeded", usedMin >= dailyLimitMinutes)
        }
    }

    fun removeAppUsageLimit(target: String, removeAll: Boolean = false): JSONObject {
        if (removeAll || target.trim().equals("all", ignoreCase = true)) {
            val count = usageQuotasMap.size
            val prevBlocked = quotaAutoBlockedToday.toSet()
            usageQuotasMap.clear()
            quotaAutoBlockedToday.clear()
            saveUsageQuotas()
            prevBlocked.forEach { pkg -> appGuardManager.unblockApp(pkg) }
            refreshUsageQuotasState()
            return JSONObject().apply {
                put("success", true)
                put("action", "CLEARED_ALL_USAGE_LIMITS")
                put("removedCount", count)
            }
        }
        val pkg = appGuardManager.resolvePackageIdentifier(target) ?: target.trim()
        val removed = usageQuotasMap.remove(pkg) != null
        if (quotaAutoBlockedToday.remove(pkg)) {
            appGuardManager.unblockApp(pkg)
        }
        saveUsageQuotas()
        refreshUsageQuotasState()
        return JSONObject().apply {
            put("success", true)
            put("action", "USAGE_LIMIT_REMOVED")
            put("packageName", pkg)
            put("appName", resolveAppLabel(pkg))
            put("wasLimited", removed)
        }
    }

    private fun saveUsageQuotas() {
        val obj = JSONObject()
        usageQuotasMap.forEach { (pkg, mins) -> obj.put(pkg, mins) }
        prefs.edit()
            .putString(KEY_USAGE_QUOTAS, obj.toString())
            .putStringSet(KEY_QUOTA_BLOCKED_TODAY, quotaAutoBlockedToday.toSet())
            .putString(KEY_QUOTA_DAY_STAMP, currentDayStamp())
            .apply()
    }

    private fun evaluateUsageQuotasNow() {
        val today = currentDayStamp()
        val savedDay = prefs.getString(KEY_QUOTA_DAY_STAMP, "") ?: ""
        if (savedDay != today) {
            val toUnblock = quotaAutoBlockedToday.toSet()
            quotaAutoBlockedToday.clear()
            toUnblock.forEach { pkg -> appGuardManager.unblockApp(pkg) }
            prefs.edit()
                .putString(KEY_QUOTA_DAY_STAMP, today)
                .putStringSet(KEY_QUOTA_BLOCKED_TODAY, emptySet())
                .apply()
        }

        if (usageQuotasMap.isEmpty()) return
        val usageMap = queryTodayForegroundSecondsByPackage()
        for ((pkg, limitMin) in usageQuotasMap) {
            val usedSec = usageMap[pkg]?.toInt() ?: 0
            val usedMin = usedSec / 60
            if (usedMin >= limitMin && !appGuardManager.isPackageBlocked(pkg)) {
                val appName = resolveAppLabel(pkg)
                quotaAutoBlockedToday.add(pkg)
                saveUsageQuotas()
                appGuardManager.blockApp(pkg, silentEvent = false)
                val alertJson = JSONObject().apply {
                    put("type", "USAGE_LIMIT_ALERT")
                    put("eventType", "DAILY_QUOTA_EXCEEDED")
                    put("appName", appName)
                    put("packageName", pkg)
                    put("dailyLimitMinutes", limitMin)
                    put("usedTodayMinutes", usedMin)
                    put("message", "$appName reached its daily limit of ${limitMin}m (used ${usedMin}m) and has been blocked.")
                    put("timestampMs", System.currentTimeMillis())
                }
                postSystemNotification(
                    title = "⏳ Daily App Limit Reached: $appName",
                    body = "Used ${usedMin}m / ${limitMin}m today. App is now blocked for the rest of the day."
                )
                onRealtimeAlertBroadcast?.invoke("USAGE_LIMIT_ALERT", alertJson)
            }
        }
        refreshUsageQuotasState()
    }

    // =========================================================================
    // SUITE 2: INTRUDER & DEVICE UNLOCK MONITOR WITH SECURITY ALERTS
    // =========================================================================

    private fun registerScreenAndUnlockReceiver() {
        try {
            val filter = IntentFilter().apply {
                addAction(Intent.ACTION_USER_PRESENT)
                addAction(Intent.ACTION_SCREEN_ON)
                addAction(Intent.ACTION_SCREEN_OFF)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                context.registerReceiver(screenAndUnlockReceiver, filter, Context.RECEIVER_EXPORTED)
            } else {
                context.registerReceiver(screenAndUnlockReceiver, filter)
            }
        } catch (_: Exception) {}
    }

    private fun handleDeviceUnlocked(eventType: String, details: String) {
        scope.launch(Dispatchers.IO) {
            val fgPkg = queryCurrentForegroundPackage()
            val fgLabel = if (fgPkg.isNotBlank()) resolveAppLabel(fgPkg) else "Home / Lockscreen"
            val batt = getBatteryPercentage()
            var capturedPhotoPath = ""

            if (eventType == "DEVICE_UNLOCKED" && _capturePhotoOnUnlock.value) {
                try {
                    val snap = backgroundCameraCaptureEngine.capturePhoto(CameraCharacteristics.LENS_FACING_FRONT)
                    if (snap != null) {
                        capturedPhotoPath = snap.filePath
                    }
                } catch (_: Exception) {}
            }

            val evt = UnlockSecurityEvent(
                id = "ul_${System.currentTimeMillis()}",
                eventType = eventType,
                foregroundPackage = fgPkg,
                foregroundAppName = fgLabel,
                batteryPercent = batt,
                photoPath = capturedPhotoPath,
                details = details
            )
            val updated = (listOf(evt) + _unlockEventsFlow.value).take(100)
            _unlockEventsFlow.value = updated
            saveUnlockHistory(updated)

            com.kavach.telemetry.OfflineTelemetryVaultManager.activeInstance?.recordUnlockEvent(
                eventType = eventType,
                fgPackage = fgPkg,
                fgAppName = fgLabel,
                batteryPercent = batt,
                details = details
            )

            if (eventType == "DEVICE_UNLOCKED" && prefs.getBoolean(KEY_UNLOCK_ALERT, true)) {
                val alertJson = evt.toJson().apply {
                    put("type", "DEVICE_UNLOCK_ALERT")
                }
                onRealtimeAlertBroadcast?.invoke("DEVICE_UNLOCK_ALERT", alertJson)
            }

            if (eventType == "DEVICE_UNLOCKED") {
                evaluateAutomationRulesForEvent("device_unlocked", "true")
            }
        }
    }

    suspend fun triggerIntruderSnapshot(lens: String = "front"): JSONObject {
        val facing = if (lens.equals("back", ignoreCase = true)) {
            CameraCharacteristics.LENS_FACING_BACK
        } else {
            CameraCharacteristics.LENS_FACING_FRONT
        }
        val capture = backgroundCameraCaptureEngine.capturePhoto(facing)
        val fgPkg = queryCurrentForegroundPackage()
        val fgLabel = if (fgPkg.isNotBlank()) resolveAppLabel(fgPkg) else "Screen"
        val batt = getBatteryPercentage()
        return if (capture != null) {
            val evt = UnlockSecurityEvent(
                id = "snap_${System.currentTimeMillis()}",
                eventType = "INTRUDER_SNAP",
                foregroundPackage = fgPkg,
                foregroundAppName = fgLabel,
                batteryPercent = batt,
                photoPath = capture.filePath,
                details = "Manual intruder security snapshot (${lens.uppercase()} lens)"
            )
            val updated = (listOf(evt) + _unlockEventsFlow.value).take(100)
            _unlockEventsFlow.value = updated
            saveUnlockHistory(updated)
            com.kavach.telemetry.OfflineTelemetryVaultManager.activeInstance?.recordUnlockEvent(
                eventType = "INTRUDER_SNAP",
                fgPackage = fgPkg,
                fgAppName = fgLabel,
                batteryPercent = batt,
                details = evt.details
            )
            JSONObject().apply {
                put("success", true)
                put("event", evt.toJson())
                put("filePath", capture.filePath)
                put("fileSize", capture.fileSize)
            }
        } else {
            JSONObject().apply {
                put("success", false)
                put("error", "Camera snapshot failed. Verify Camera permission is granted.")
            }
        }
    }

    fun getUnlockMonitorStatusJson(limit: Int = 40): JSONObject {
        val pm = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
        val isInteractive = pm?.isInteractive ?: true
        val logsArr = JSONArray()
        _unlockEventsFlow.value.take(limit.coerceIn(1, 100)).forEach { logsArr.put(it.toJson()) }
        val totalUnlocks = _unlockEventsFlow.value.count { it.eventType == "DEVICE_UNLOCKED" }

        return JSONObject().apply {
            put("success", true)
            put("unlockMonitorEnabled", _unlockMonitorEnabled.value)
            put("alertOnUnlock", prefs.getBoolean(KEY_UNLOCK_ALERT, true))
            put("capturePhotoOnUnlock", _capturePhotoOnUnlock.value)
            put("isScreenCurrentlyOn", isInteractive)
            put("totalUnlockCountRecorded", totalUnlocks)
            put("eventsCount", _unlockEventsFlow.value.size)
            put("events", logsArr)
        }
    }

    fun updateUnlockPolicy(
        enabled: Boolean? = null,
        alertOnUnlock: Boolean? = null,
        capturePhotoOnUnlock: Boolean? = null
    ): JSONObject {
        val ed = prefs.edit()
        enabled?.let {
            _unlockMonitorEnabled.value = it
            ed.putBoolean(KEY_UNLOCK_ENABLED, it)
        }
        alertOnUnlock?.let {
            ed.putBoolean(KEY_UNLOCK_ALERT, it)
        }
        capturePhotoOnUnlock?.let {
            _capturePhotoOnUnlock.value = it
            ed.putBoolean(KEY_UNLOCK_PHOTO, it)
        }
        ed.apply()
        return getUnlockMonitorStatusJson(20)
    }

    fun clearUnlockLogs(): JSONObject {
        _unlockEventsFlow.value = emptyList()
        prefs.edit().putString(KEY_UNLOCK_LOGS, "[]").apply()
        return JSONObject().put("success", true).put("action", "UNLOCK_LOGS_CLEARED")
    }

    private fun saveUnlockHistory(list: List<UnlockSecurityEvent>) {
        try {
            val arr = JSONArray()
            list.take(100).forEach { arr.put(it.toJson()) }
            prefs.edit().putString(KEY_UNLOCK_LOGS, arr.toString()).apply()
        } catch (_: Exception) {}
    }

    // =========================================================================
    // SUITE 3: CLIPBOARD & NOTIFICATION HISTORY LOGGER WITH KEYWORD ALERTS
    // =========================================================================

    private fun registerClipboardMonitor() {
        try {
            val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager ?: return
            cm.addPrimaryClipChangedListener {
                try {
                    val clip = cm.primaryClip
                    if (clip != null && clip.itemCount > 0) {
                        val text = clip.getItemAt(0).coerceToText(context)?.toString()?.trim().orEmpty()
                        if (text.isNotEmpty() && text != lastClipboardText) {
                            lastClipboardText = text
                            onClipboardCaptured(text)
                        }
                    }
                } catch (_: Exception) {}
            }
        } catch (_: Exception) {}
    }

    fun onClipboardCaptured(text: String) {
        val clean = text.trim()
        if (clean.isEmpty()) return
        val matched = matchWatchedKeywords(clean)
        val entry = ClipboardHistoryEntry(
            id = "clip_${System.currentTimeMillis()}",
            text = clean.take(2000),
            length = clean.length,
            matchedKeywords = matched
        )
        val updated = (listOf(entry) + _clipboardHistoryFlow.value.filterNot { it.text == clean }).take(100)
        _clipboardHistoryFlow.value = updated
        saveClipboardHistory(updated)

        if (matched.isNotEmpty()) {
            val alertJson = JSONObject().apply {
                put("type", "KEYWORD_MATCH_ALERT")
                put("source", "CLIPBOARD")
                put("matchedKeywords", JSONArray(matched))
                put("preview", clean.take(160))
                put("timestampMs", entry.timestampMs)
                put("formattedTime", entry.formattedTime)
            }
            postSystemNotification(
                title = "🔍 Keyword Match in Clipboard: ${matched.joinToString(", ")}",
                body = clean.take(120)
            )
            onRealtimeAlertBroadcast?.invoke("KEYWORD_MATCH_ALERT", alertJson)
        }
    }

    fun onNotificationCaptured(packageName: String, title: String, text: String, postTime: Long) {
        if (packageName == context.packageName && title.startsWith("🔍 Keyword Match")) return
        val combined = "$title $text".trim()
        if (combined.isEmpty()) return

        val dedupKey = "$packageName|$title|$text"
        val now = System.currentTimeMillis()
        if (dedupKey == lastNotifDedupKey && (now - lastNotifDedupMs) < 2000L) return
        lastNotifDedupKey = dedupKey
        lastNotifDedupMs = now

        val appName = resolveAppLabel(packageName)
        val matched = matchWatchedKeywords(combined)
        val entry = NotificationHistoryEntry(
            id = "nf_${now}",
            packageName = packageName,
            appName = appName,
            title = title,
            text = text,
            matchedKeywords = matched,
            timestampMs = if (postTime > 0L) postTime else now
        )
        val updated = (listOf(entry) + _notificationHistoryFlow.value).take(120)
        _notificationHistoryFlow.value = updated
        saveNotificationHistory(updated)

        com.kavach.telemetry.OfflineTelemetryVaultManager.activeInstance?.recordNotificationEvent(
            packageName = packageName,
            appName = appName,
            title = title,
            text = text,
            postTime = entry.timestampMs,
            matchedKeywords = matched
        )

        if (matched.isNotEmpty()) {
            val alertJson = JSONObject().apply {
                put("type", "KEYWORD_MATCH_ALERT")
                put("source", "NOTIFICATION")
                put("appName", appName)
                put("packageName", packageName)
                put("matchedKeywords", JSONArray(matched))
                put("title", title)
                put("text", text.take(200))
                put("timestampMs", entry.timestampMs)
                put("formattedTime", entry.formattedTime)
            }
            postSystemNotification(
                title = "🔍 Keyword Match ($appName): ${matched.joinToString(", ")}",
                body = "$title: ${text.take(100)}"
            )
            onRealtimeAlertBroadcast?.invoke("KEYWORD_MATCH_ALERT", alertJson)
        }
    }

    private fun matchWatchedKeywords(content: String): List<String> {
        val keywords = _watchedKeywordsFlow.value
        if (keywords.isEmpty() || content.isBlank()) return emptyList()
        val lower = content.lowercase()
        return keywords.filter { kw ->
            val cleanKw = kw.trim().lowercase()
            cleanKw.isNotEmpty() && lower.contains(cleanKw)
        }
    }

    fun getClipboardHistoryJson(query: String = "", limit: Int = 50): JSONObject {
        val q = query.trim().lowercase()
        val filtered = _clipboardHistoryFlow.value.filter {
            q.isEmpty() || it.text.lowercase().contains(q)
        }.take(limit.coerceIn(1, 100))
        val arr = JSONArray()
        filtered.forEach { arr.put(it.toJson()) }
        return JSONObject().apply {
            put("success", true)
            put("totalEntries", _clipboardHistoryFlow.value.size)
            put("returnedCount", arr.length())
            put("watchedKeywords", JSONArray(_watchedKeywordsFlow.value.sorted()))
            put("entries", arr)
        }
    }

    fun getNotificationHistoryJson(query: String = "", limit: Int = 50): JSONObject {
        val q = query.trim().lowercase()
        val filtered = _notificationHistoryFlow.value.filter {
            q.isEmpty() ||
                it.title.lowercase().contains(q) ||
                it.text.lowercase().contains(q) ||
                it.appName.lowercase().contains(q) ||
                it.packageName.lowercase().contains(q)
        }.take(limit.coerceIn(1, 120))
        val arr = JSONArray()
        filtered.forEach { arr.put(it.toJson()) }
        return JSONObject().apply {
            put("success", true)
            put("totalEntries", _notificationHistoryFlow.value.size)
            put("returnedCount", arr.length())
            put("watchedKeywords", JSONArray(_watchedKeywordsFlow.value.sorted()))
            put("entries", arr)
        }
    }

    fun addWatchedKeyword(keyword: String): JSONObject {
        val clean = keyword.trim()
        if (clean.isEmpty()) {
            return JSONObject().put("success", false).put("error", "Keyword cannot be empty")
        }
        val updated = _watchedKeywordsFlow.value.toMutableSet().apply { add(clean) }
        _watchedKeywordsFlow.value = updated
        prefs.edit().putStringSet(KEY_WATCH_KEYWORDS, updated).apply()
        return JSONObject().apply {
            put("success", true)
            put("action", "KEYWORD_ADDED")
            put("keyword", clean)
            put("watchedKeywords", JSONArray(updated.sorted()))
        }
    }

    fun removeWatchedKeyword(keyword: String, clearAll: Boolean = false): JSONObject {
        if (clearAll || keyword.trim().equals("all", ignoreCase = true)) {
            _watchedKeywordsFlow.value = emptySet()
            prefs.edit().putStringSet(KEY_WATCH_KEYWORDS, emptySet()).apply()
            return JSONObject().apply {
                put("success", true)
                put("action", "KEYWORDS_CLEARED")
                put("watchedKeywords", JSONArray())
            }
        }
        val clean = keyword.trim()
        val updated = _watchedKeywordsFlow.value.toMutableSet()
        updated.removeIf { it.equals(clean, ignoreCase = true) }
        _watchedKeywordsFlow.value = updated
        prefs.edit().putStringSet(KEY_WATCH_KEYWORDS, updated).apply()
        return JSONObject().apply {
            put("success", true)
            put("action", "KEYWORD_REMOVED")
            put("keyword", clean)
            put("watchedKeywords", JSONArray(updated.sorted()))
        }
    }

    fun clearHistoryLogs(target: String = "all"): JSONObject {
        val t = target.trim().lowercase()
        if (t in listOf("all", "clip", "clipboard")) {
            _clipboardHistoryFlow.value = emptyList()
            prefs.edit().putString(KEY_CLIP_HISTORY, "[]").apply()
        }
        if (t in listOf("all", "notif", "notifications")) {
            _notificationHistoryFlow.value = emptyList()
            prefs.edit().putString(KEY_NOTIF_HISTORY, "[]").apply()
        }
        return JSONObject().put("success", true).put("cleared", t)
    }

    private fun saveClipboardHistory(list: List<ClipboardHistoryEntry>) {
        try {
            val arr = JSONArray()
            list.take(100).forEach { arr.put(it.toJson()) }
            prefs.edit().putString(KEY_CLIP_HISTORY, arr.toString()).apply()
        } catch (_: Exception) {}
    }

    private fun saveNotificationHistory(list: List<NotificationHistoryEntry>) {
        try {
            val arr = JSONArray()
            list.take(120).forEach { arr.put(it.toJson()) }
            prefs.edit().putString(KEY_NOTIF_HISTORY, arr.toString()).apply()
        } catch (_: Exception) {}
    }

    // =========================================================================
    // SUITE 4: SCHEDULED & EVENT-DRIVEN AUTOMATION RULES ENGINE
    // =========================================================================

    fun listAutomationRulesJson(): JSONObject {
        val arr = JSONArray()
        _automationRulesFlow.value.forEach { arr.put(it.toJson()) }
        return JSONObject().apply {
            put("success", true)
            put("rulesCount", _automationRulesFlow.value.size)
            put("activeRulesCount", _automationRulesFlow.value.count { it.enabled })
            put("rules", arr)
        }
    }

    fun addAutomationRule(
        name: String,
        triggerSpec: String,
        actionSpec: String,
        cooldownMinutes: Int = 15
    ): JSONObject {
        val tParts = triggerSpec.trim().split(":", limit = 2)
        val triggerType = tParts.getOrNull(0)?.trim()?.lowercase().orEmpty()
        val triggerValue = tParts.getOrNull(1)?.trim().orEmpty()

        val aParts = actionSpec.trim().split(":", limit = 2)
        val actionType = aParts.getOrNull(0)?.trim()?.lowercase().orEmpty()
        val actionValue = aParts.getOrNull(1)?.trim().orEmpty()

        if (triggerType.isEmpty() || actionType.isEmpty()) {
            return JSONObject()
                .put("success", false)
                .put("error", "Provide valid trigger (--when=type:value) and action (--do=type:value)")
        }

        val ruleId = "rule_${(System.currentTimeMillis() % 100000)}"
        val rule = AutomationRuleItem(
            id = ruleId,
            name = name.ifBlank { "$triggerType -> $actionType" },
            enabled = true,
            triggerType = triggerType,
            triggerValue = triggerValue,
            actionType = actionType,
            actionValue = actionValue,
            cooldownMinutes = cooldownMinutes.coerceIn(1, 1440)
        )
        val updated = _automationRulesFlow.value + rule
        _automationRulesFlow.value = updated
        saveAutomationRules(updated)

        return JSONObject().apply {
            put("success", true)
            put("action", "RULE_ADDED")
            put("rule", rule.toJson())
        }
    }

    fun removeAutomationRule(idOrName: String, removeAll: Boolean = false): JSONObject {
        if (removeAll || idOrName.trim().equals("all", ignoreCase = true)) {
            val cnt = _automationRulesFlow.value.size
            _automationRulesFlow.value = emptyList()
            saveAutomationRules(emptyList())
            return JSONObject().put("success", true).put("action", "CLEARED_ALL_RULES").put("removedCount", cnt)
        }
        val clean = idOrName.trim().lowercase()
        val before = _automationRulesFlow.value
        val updated = before.filterNot {
            it.id.lowercase() == clean || it.name.lowercase() == clean || it.name.lowercase().contains(clean)
        }
        _automationRulesFlow.value = updated
        saveAutomationRules(updated)
        return JSONObject().apply {
            put("success", true)
            put("action", "RULE_REMOVED")
            put("removedCount", before.size - updated.size)
            put("remainingRulesCount", updated.size)
        }
    }

    fun toggleAutomationRule(idOrName: String, enabled: Boolean): JSONObject {
        val clean = idOrName.trim().lowercase()
        var matchedRule: AutomationRuleItem? = null
        val updated = _automationRulesFlow.value.map { r ->
            if (r.id.lowercase() == clean || r.name.lowercase().contains(clean)) {
                val mod = r.copy(enabled = enabled)
                matchedRule = mod
                mod
            } else r
        }
        if (matchedRule == null) {
            return JSONObject().put("success", false).put("error", "Automation rule not found: '$idOrName'")
        }
        _automationRulesFlow.value = updated
        saveAutomationRules(updated)
        return JSONObject().apply {
            put("success", true)
            put("rule", matchedRule!!.toJson())
        }
    }

    fun testExecuteAutomationRule(idOrName: String): JSONObject {
        val clean = idOrName.trim().lowercase()
        val rule = _automationRulesFlow.value.firstOrNull {
            it.id.lowercase() == clean || it.name.lowercase().contains(clean)
        } ?: return JSONObject().put("success", false).put("error", "Rule not found: '$idOrName'")

        val execRes = executeRuleAction(rule)
        markRuleTriggered(rule.id)
        return JSONObject().apply {
            put("success", true)
            put("action", "RULE_TEST_EXECUTED")
            put("rule", rule.toJson())
            put("executionResult", execRes)
        }
    }

    private fun evaluatePeriodicAutomationRules() {
        val rules = _automationRulesFlow.value.filter { it.enabled }
        if (rules.isEmpty()) return

        val nowMs = System.currentTimeMillis()
        val battPct = getBatteryPercentage()
        val isCharging = isDeviceCharging()
        val (wifiConnected, wifiSsid) = getWifiState()
        val currentHm = SimpleDateFormat("HH:mm", Locale.US).format(Date(nowMs))
        val fgPkg = queryCurrentForegroundPackage()

        for (rule in rules) {
            val cooldownMs = rule.cooldownMinutes * 60_000L
            if (rule.lastTriggeredMs > 0L && (nowMs - rule.lastTriggeredMs) < cooldownMs) {
                continue
            }
            val matched = when (rule.triggerType) {
                "battery_below" -> {
                    val threshold = rule.triggerValue.toIntOrNull() ?: 20
                    battPct in 1..threshold
                }
                "battery_above" -> {
                    val threshold = rule.triggerValue.toIntOrNull() ?: 80
                    battPct >= threshold
                }
                "charging", "battery_charging" -> {
                    val want = rule.triggerValue.lowercase() !in listOf("false", "off", "0", "no")
                    isCharging == want
                }
                "wifi_connected", "wifi" -> {
                    val tv = rule.triggerValue.trim()
                    when (tv.lowercase()) {
                        "true", "on", "connected", "" -> wifiConnected
                        "false", "off", "disconnected" -> !wifiConnected
                        else -> wifiConnected && wifiSsid.equals(tv, ignoreCase = true)
                    }
                }
                "time_daily", "time", "schedule" -> {
                    currentHm == rule.triggerValue.trim()
                }
                "app_opened", "foreground_app" -> {
                    val targetPkg = appGuardManager.resolvePackageIdentifier(rule.triggerValue) ?: rule.triggerValue
                    fgPkg.isNotBlank() && fgPkg.equals(targetPkg, ignoreCase = true)
                }
                else -> false
            }

            if (matched) {
                triggerRuleAndBroadcast(rule)
            }
        }
    }

    private fun evaluateAutomationRulesForEvent(eventType: String, eventValue: String) {
        val nowMs = System.currentTimeMillis()
        for (rule in _automationRulesFlow.value.filter { it.enabled && it.triggerType == eventType }) {
            val cooldownMs = rule.cooldownMinutes * 60_000L
            if (rule.lastTriggeredMs > 0L && (nowMs - rule.lastTriggeredMs) < cooldownMs) continue
            if (rule.triggerValue.isBlank() || rule.triggerValue.equals(eventValue, ignoreCase = true)) {
                triggerRuleAndBroadcast(rule)
            }
        }
    }

    private fun triggerRuleAndBroadcast(rule: AutomationRuleItem) {
        val res = executeRuleAction(rule)
        markRuleTriggered(rule.id)
        val alertJson = JSONObject().apply {
            put("type", "AUTOMATION_RULE_TRIGGERED")
            put("ruleId", rule.id)
            put("ruleName", rule.name)
            put("triggerSpec", "${rule.triggerType}:${rule.triggerValue}")
            put("actionSpec", "${rule.actionType}:${rule.actionValue}")
            put("result", res)
            put("timestampMs", System.currentTimeMillis())
        }
        onRealtimeAlertBroadcast?.invoke("AUTOMATION_RULE_TRIGGERED", alertJson)
    }

    private fun executeRuleAction(rule: AutomationRuleItem): JSONObject {
        return try {
            when (rule.actionType.lowercase()) {
                "torch", "flashlight" -> {
                    val enable = rule.actionValue.lowercase() !in listOf("off", "false", "0")
                    deviceBridgeManager.handleSystemToggle(
                        JSONObject().put("target", "torch").put("state", if (enable) "on" else "off")
                    )
                }
                "dnd", "donotdisturb" -> {
                    val enable = rule.actionValue.lowercase() !in listOf("off", "false", "0")
                    deviceBridgeManager.handleSystemToggle(
                        JSONObject().put("target", "dnd").put("state", if (enable) "on" else "off")
                    )
                }
                "brightness" -> {
                    val lvl = rule.actionValue.toIntOrNull() ?: 100
                    deviceBridgeManager.setDisplayBrightness(lvl.coerceIn(5, 255))
                }
                "volume" -> {
                    val pct = rule.actionValue.toIntOrNull() ?: 50
                    deviceBridgeManager.setStreamVolumePercent("MEDIA", pct.coerceIn(0, 100))
                }
                "tts", "speak" -> {
                    deviceBridgeManager.speakText(rule.actionValue.ifBlank { "Automation rule ${rule.name} triggered" })
                }
                "notify", "notification" -> {
                    postSystemNotification("⚡ Automation Rule: ${rule.name}", rule.actionValue)
                    JSONObject().put("success", true).put("notified", rule.actionValue)
                }
                "block_app", "block" -> {
                    appGuardManager.blockApp(rule.actionValue)
                }
                "unblock_app", "unblock" -> {
                    appGuardManager.unblockApp(rule.actionValue)
                }
                "force_stop", "kill_app" -> {
                    appGuardManager.forceStopApp(rule.actionValue)
                }
                "shell", "cmd" -> {
                    deviceBridgeManager.executeShellCommand(rule.actionValue, timeoutMs = 10_000L)
                }
                else -> JSONObject().put("success", false).put("error", "Unknown actionType: ${rule.actionType}")
            }
        } catch (e: Exception) {
            JSONObject().put("success", false).put("error", e.message ?: "Action execution failed")
        }
    }

    private fun markRuleTriggered(ruleId: String) {
        val now = System.currentTimeMillis()
        val updated = _automationRulesFlow.value.map { r ->
            if (r.id == ruleId) r.copy(lastTriggeredMs = now, triggerCount = r.triggerCount + 1) else r
        }
        _automationRulesFlow.value = updated
        saveAutomationRules(updated)
    }

    private fun saveAutomationRules(list: List<AutomationRuleItem>) {
        try {
            val arr = JSONArray()
            list.forEach { arr.put(it.toJson()) }
            prefs.edit().putString(KEY_AUTOMATION_RULES, arr.toString()).apply()
        } catch (_: Exception) {}
    }

    // =========================================================================
    // SUITE 5: APK BACKUP EXTRACTOR & REMOTE APK INSTALLER
    // =========================================================================

    private fun getBackupDirectory(): File {
        val pubDownload = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
        val dir = File(pubDownload, "AeroShare/backups")
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    fun backupAppApk(target: String): JSONObject {
        val pkg = appGuardManager.resolvePackageIdentifier(target)
            ?: return JSONObject().put("success", false).put("error", "Installed package not found for '$target'")
        return try {
            val pm = context.packageManager
            val pInfo = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                pm.getPackageInfo(pkg, PackageManager.PackageInfoFlags.of(0L))
            } else {
                @Suppress("DEPRECATION")
                pm.getPackageInfo(pkg, 0)
            }
            val appInfo = pInfo.applicationInfo
                ?: return JSONObject().put("success", false).put("error", "ApplicationInfo unavailable for $pkg")
            val srcApk = File(appInfo.sourceDir)
            if (!srcApk.exists() || !srcApk.canRead()) {
                return JSONObject().put("success", false).put("error", "Source APK is not readable: ${appInfo.sourceDir}")
            }

            val label = pm.getApplicationLabel(appInfo)?.toString()?.trim().orEmpty().ifEmpty { pkg }
            val verName = (pInfo.versionName ?: "1.0").replace(Regex("[^a-zA-Z0-9._-]"), "_")
            val destFile = File(getBackupDirectory(), "${pkg}_v${verName}.apk")
            srcApk.inputStream().use { input ->
                destFile.outputStream().use { output ->
                    input.copyTo(output, bufferSize = 64 * 1024)
                }
            }

            val sha256 = computeFileSha256(destFile)
            val sizeMb = Math.round((destFile.length().toDouble() / (1024.0 * 1024.0)) * 100.0) / 100.0
            JSONObject().apply {
                put("success", true)
                put("action", "APK_BACKED_UP")
                put("appName", label)
                put("packageName", pkg)
                put("versionName", pInfo.versionName ?: "1.0")
                put("sourceApkPath", srcApk.absolutePath)
                put("backupFilePath", destFile.absolutePath)
                put("sizeBytes", destFile.length())
                put("sizeMb", sizeMb)
                put("sha256", sha256)
            }
        } catch (e: Exception) {
            JSONObject().put("success", false).put("error", e.message ?: "APK backup extraction failed")
        }
    }

    fun listBackedUpApksJson(): JSONObject {
        val dir = getBackupDirectory()
        val files = dir.listFiles { f -> f.isFile && f.name.endsWith(".apk", ignoreCase = true) }
            ?.sortedByDescending { it.lastModified() }
            ?: emptyList()
        val df = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
        val arr = JSONArray()
        for (f in files) {
            val sizeMb = Math.round((f.length().toDouble() / (1024.0 * 1024.0)) * 100.0) / 100.0
            arr.put(
                JSONObject().apply {
                    put("fileName", f.name)
                    put("filePath", f.absolutePath)
                    put("sizeBytes", f.length())
                    put("sizeMb", sizeMb)
                    put("lastModified", df.format(Date(f.lastModified())))
                }
            )
        }
        return JSONObject().apply {
            put("success", true)
            put("backupDirectory", dir.absolutePath)
            put("backupsCount", arr.length())
            put("backups", arr)
        }
    }

    fun verifyApkOrApp(targetOrPath: String): JSONObject {
        return AppVerifierAnalyzer.verifyApkOrApp(context, appGuardManager, targetOrPath)
    }

    fun installApkFromPath(rawPath: String, forceInstall: Boolean = false): JSONObject {
        val cleanPath = rawPath.trim()
        if (cleanPath.isEmpty()) {
            return JSONObject().put("success", false).put("error", "Missing APK file path")
        }
        val apkFile = if (cleanPath.startsWith("/")) {
            File(cleanPath)
        } else {
            val inBackups = File(getBackupDirectory(), cleanPath)
            if (inBackups.exists()) inBackups else File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), cleanPath)
        }
        if (!apkFile.exists() || !apkFile.isFile) {
            return JSONObject().put("success", false).put("error", "APK file not found: ${apkFile.absolutePath}")
        }

        // 0. Pre-Install Developer Signature & Capability Verification
        val verification = AppVerifierAnalyzer.verifyApkOrApp(context, appGuardManager, apkFile.absolutePath)
        val secAssess = verification.optJSONObject("securityAssessment")
        val safeToInstall = secAssess?.optBoolean("safeToInstall", true) ?: true
        val verdict = secAssess?.optString("verdict", "") ?: ""

        if (!safeToInstall && !forceInstall) {
            return JSONObject().apply {
                put("success", false)
                put("action", "BLOCKED_BY_VERIFIER")
                put("apkFilePath", apkFile.absolutePath)
                put("appName", verification.optString("appName", apkFile.name))
                put("packageName", verification.optString("packageName", ""))
                put("verification", verification)
                put("error", "Pre-install verification blocked installation: $verdict (Pass --force to override)")
            }
        }

        // 1. Try silent root/shell pm install -r first
        val shellCmds = listOf(
            arrayOf("su", "-c", "pm install -r \"${apkFile.absolutePath}\""),
            arrayOf("sh", "-c", "pm install -r \"${apkFile.absolutePath}\"")
        )
        for (cmdArr in shellCmds) {
            try {
                val proc = ProcessBuilder(*cmdArr)
                    .redirectErrorStream(true)
                    .start()
                val finished = proc.waitFor(10, java.util.concurrent.TimeUnit.SECONDS)
                val output = proc.inputStream.bufferedReader().readText().trim()
                if (finished && proc.exitValue() == 0 && output.contains("Success", ignoreCase = true)) {
                    return JSONObject().apply {
                        put("success", true)
                        put("action", "INSTALLED_SILENT")
                        put("apkFilePath", apkFile.absolutePath)
                        put("appName", verification.optString("appName", apkFile.name))
                        put("packageName", verification.optString("packageName", ""))
                        put("verification", verification)
                        put("message", "Verified developer signature and installed ${apkFile.name} silently.")
                    }
                }
            } catch (_: Exception) {}
        }

        // 2. Launch system package installer intent on device
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && !context.packageManager.canRequestPackageInstalls()) {
                val permIntent = Intent(
                    Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                    Uri.parse("package:${context.packageName}")
                ).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(permIntent)
                return JSONObject().apply {
                    put("success", true)
                    put("action", "INSTALL_PERMISSION_PROMPTED")
                    put("apkFilePath", apkFile.absolutePath)
                    put("appName", verification.optString("appName", apkFile.name))
                    put("packageName", verification.optString("packageName", ""))
                    put("verification", verification)
                    put("message", "Verified APK. Opened 'Install Unknown Apps' permission screen on phone — approve once and re-run apk-install.")
                }
            }

            @Suppress("DEPRECATION")
            val installIntent = Intent(Intent.ACTION_INSTALL_PACKAGE).apply {
                data = Uri.fromFile(apkFile)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                putExtra(Intent.EXTRA_NOT_UNKNOWN_SOURCE, true)
                putExtra(Intent.EXTRA_RETURN_RESULT, false)
            }
            context.startActivity(installIntent)
            JSONObject().apply {
                put("success", true)
                put("action", "INSTALL_PROMPT_LAUNCHED")
                put("apkFilePath", apkFile.absolutePath)
                put("appName", verification.optString("appName", apkFile.name))
                put("packageName", verification.optString("packageName", ""))
                put("verification", verification)
                put("message", "Verified developer & capabilities; launched package installer on phone screen for ${apkFile.name}")
            }
        } catch (e: Exception) {
            JSONObject().apply {
                put("success", false)
                put("apkFilePath", apkFile.absolutePath)
                put("verification", verification)
                put("error", e.message ?: "Could not launch APK installer")
            }
        }
    }

    // =========================================================================
    // BACKGROUND EVALUATION LOOP & HELPERS
    // =========================================================================

    private fun startBackgroundEvaluationLoop() {
        backgroundLoopJob?.cancel()
        backgroundLoopJob = scope.launch(Dispatchers.IO) {
            while (isActive) {
                try {
                    evaluateUsageQuotasNow()
                    evaluatePeriodicAutomationRules()
                } catch (_: Exception) {}
                delay(15_000L)
            }
        }
    }

    private fun queryCurrentForegroundPackage(): String {
        try {
            val rootPkg = com.kavach.accessibility.AccessibilityServiceRegistry.activeService
                ?.rootInActiveWindow?.packageName?.toString()?.trim().orEmpty()
            if (rootPkg.isNotEmpty()) return rootPkg
        } catch (_: Exception) {}
        return try {
            val usm = context.getSystemService(Context.USAGE_STATS_SERVICE) as? UsageStatsManager ?: return ""
            val now = System.currentTimeMillis()
            val stats = usm.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, now - 60_000L, now)
            stats?.maxByOrNull { it.lastTimeUsed }?.packageName.orEmpty()
        } catch (_: Exception) {
            ""
        }
    }

    private fun getBatteryPercentage(): Int {
        return try {
            val bm = context.getSystemService(Context.BATTERY_SERVICE) as? BatteryManager
            bm?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) ?: 100
        } catch (_: Exception) {
            100
        }
    }

    private fun isDeviceCharging(): Boolean {
        return try {
            val intent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val status = intent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
            status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
        } catch (_: Exception) {
            false
        }
    }

    private fun getWifiState(): Pair<Boolean, String> {
        return try {
            val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
            val net = cm?.activeNetwork
            val caps = if (net != null) cm.getNetworkCapabilities(net) else null
            val isWifi = caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true
            val wm = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
            @Suppress("DEPRECATION")
            val ssid = wm?.connectionInfo?.ssid?.trim('"').orEmpty()
            Pair(isWifi, ssid)
        } catch (_: Exception) {
            Pair(false, "")
        }
    }

    private fun resolveAppLabel(pkg: String): String {
        if (pkg.isBlank()) return ""
        return try {
            val pm = context.packageManager
            val appInfo = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                pm.getApplicationInfo(pkg, PackageManager.ApplicationInfoFlags.of(0L))
            } else {
                @Suppress("DEPRECATION")
                pm.getApplicationInfo(pkg, 0)
            }
            pm.getApplicationLabel(appInfo)?.toString()?.trim().orEmpty().ifEmpty { pkg }
        } catch (_: Exception) {
            pkg
        }
    }

    private fun computeFileSha256(file: File): String {
        return try {
            val md = MessageDigest.getInstance("SHA-256")
            file.inputStream().use { input ->
                val buf = ByteArray(32 * 1024)
                var read: Int
                while (input.read(buf).also { read = it } > 0) {
                    md.update(buf, 0, read)
                }
            }
            md.digest().joinToString("") { "%02x".format(it) }
        } catch (_: Exception) {
            ""
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "AeroShare Security, Quota & Automation Alerts",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Alerts for app usage time limits, keyword matches, unlock monitor, and automation rules"
            }
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
            nm?.createNotificationChannel(channel)
        }
    }

    private fun postSystemNotification(title: String, body: String) {
        try {
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager ?: return
            val notif = NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle(title)
                .setContentText(body)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)
                .build()
            nm.notify((System.currentTimeMillis() % 100000).toInt() + 9000, notif)
        } catch (_: Exception) {}
    }
}
