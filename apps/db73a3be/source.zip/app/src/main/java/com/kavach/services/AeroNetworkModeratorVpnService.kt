package com.kavach.services

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import android.util.Log
import androidx.core.app.NotificationCompat
import com.kavach.MainActivity
import com.kavach.R
import com.kavach.network.NetworkModerationManager
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.nio.ByteBuffer

/**
 * On-device VpnService for system-wide DNS packet inspection,
 * domain/IP moderation, and blocking.
 */
class AeroNetworkModeratorVpnService : VpnService() {

    private val TAG = "AeroNetworkVpn"
    private var vpnInterface: ParcelFileDescriptor? = null
    private val vpnScope = CoroutineScope(
        SupervisorJob() + Dispatchers.IO + CoroutineExceptionHandler { _, t ->
            Log.w("AeroNetworkVpn", "DNS worker warning: ${t.message}")
        }
    )
    private val dnsConcurrencyLimiter = Semaphore(permits = 20)
    private var workerJob: Job? = null
    @Volatile
    private var cachedSystemDns: List<InetAddress> = emptyList()
    @Volatile
    private var cachedSystemDnsMs: Long = 0L

    companion object {
        const val ACTION_START = "com.kavach.action.START_NETWORK_VPN"
        const val ACTION_STOP = "com.kavach.action.STOP_NETWORK_VPN"
        const val ACTION_PREPARE_VPN = "com.kavach.action.PREPARE_NETWORK_VPN"
        const val NOTIFICATION_CHANNEL_ID = "aero_network_moderator_channel"
        const val NOTIFICATION_ID = 2048

        @Volatile
        var isRunning: Boolean = false
            private set

        @Volatile
        var activeInstance: AeroNetworkModeratorVpnService? = null
            private set

        var networkModerationManager: NetworkModerationManager? = null

        fun startService(context: Context): String {
            // Always enable the in-app DNS/Domain Moderation Engine immediately
            networkModerationManager?.setVpnActive(true)

            val prepareIntent = try {
                VpnService.prepare(context)
            } catch (_: Throwable) {
                null
            }

            if (prepareIntent != null) {
                // VPN consent has not been granted yet -> open MainActivity to launch VPN consent dialog
                // and arm Accessibility auto-click if Accessibility service is active
                try {
                    com.kavach.hardware.AppGuardManager.activeInstance?.armVpnDialogAutoClick()
                    val actIntent = Intent(context, MainActivity::class.java).apply {
                        action = ACTION_PREPARE_VPN
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                    }
                    context.startActivity(actIntent)
                } catch (e: Throwable) {
                    Log.w("AeroNetworkVpn", "Could not launch MainActivity for VPN prepare: ${e.message}")
                }
                return "VPN_CONSENT_PROMPTED"
            }

            return startServiceDirect(context)
        }

        fun startServiceDirect(context: Context): String {
            networkModerationManager?.setVpnActive(true)
            val intent = Intent(context, AeroNetworkModeratorVpnService::class.java).apply {
                action = ACTION_START
            }
            return try {
                context.startService(intent)
                "STARTED_VPN"
            } catch (e: Throwable) {
                try {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        context.startForegroundService(intent)
                    }
                    "STARTED_VPN"
                } catch (e2: Throwable) {
                    Log.w("AeroNetworkVpn", "Background service start fallback (Moderation engine active): ${e2.message}")
                    "MODERATION_ENGINE_ACTIVE"
                }
            }
        }

        fun stopService(context: Context) {
            isRunning = false
            networkModerationManager?.setVpnActive(false)
            try {
                activeInstance?.stopVpnInternal()
                activeInstance?.stopSelf()
            } catch (_: Throwable) {}
            try {
                val intent = Intent(context, AeroNetworkModeratorVpnService::class.java)
                context.stopService(intent)
            } catch (_: Throwable) {}
        }
    }

    override fun onCreate() {
        super.onCreate()
        activeInstance = this
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action ?: ACTION_START
        if (action == ACTION_STOP) {
            stopVpnInternal()
            stopSelf()
            return START_NOT_STICKY
        }

        try {
            val notif = buildForegroundNotification()
            if (Build.VERSION.SDK_INT >= 34) {
                startForeground(
                    NOTIFICATION_ID,
                    notif,
                    android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
                )
            } else {
                startForeground(NOTIFICATION_ID, notif)
            }
        } catch (t: Throwable) {
            Log.w(TAG, "startForeground non-fatal fallback: ${t.message}")
        }

        startVpn()
        return START_STICKY
    }

    @Synchronized
    fun reloadVpnInterface() {
        if (!isRunning) return
        try {
            workerJob?.cancel()
            workerJob = null
            try { vpnInterface?.close() } catch (_: Throwable) {}
            vpnInterface = null
            isRunning = false
            startVpn()
        } catch (t: Throwable) {
            Log.w(TAG, "reloadVpnInterface failed: ${t.message}")
        }
    }

    private fun startVpn() {
        if (isRunning) return

        try {
            val prepareIntent = try { VpnService.prepare(this) } catch (_: Throwable) { null }
            if (prepareIntent != null) {
                Log.w(TAG, "VpnService.prepare() requires user consent; keeping DNS moderation engine active.")
                networkModerationManager?.setVpnActive(true)
                return
            }

            val builder = Builder()
                .setSession("Aero DNS Firewall & Network Moderator")
                .addAddress("10.10.10.2", 32)
                .addDnsServer("10.10.10.1")
                // Route virtual DNS (10.10.10.1/32) AND browser hardcoded DNS/DoH resolvers
                // so Chrome cannot bypass domain blocking via built-in Async DNS or DoH (8.8.8.8 / 1.1.1.1),
                // while our own upstream UDP socket uses protect(socket) to bypass the VPN cleanly.
                .addRoute("10.10.10.1", 32)
                .addRoute("8.8.8.8", 32)
                .addRoute("8.8.4.4", 32)
                .addRoute("1.1.1.1", 32)
                .addRoute("1.0.0.1", 32)
                .addRoute("9.9.9.9", 32)
                .allowBypass()
                .setMtu(1500)

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                builder.setMetered(false)
            }

            // Disallow Aura itself and Termux from VPN routing so Cloudflare tunnels and CLI bridge never loop
            listOf(packageName, "com.termux").forEach { exemptedPkg ->
                try {
                    builder.addDisallowedApplication(exemptedPkg)
                } catch (e: Exception) {
                    Log.w(TAG, "Could not disallow package $exemptedPkg: ${e.message}")
                }
            }

            vpnInterface = builder.establish()
            if (vpnInterface == null) {
                Log.w(TAG, "VPN Builder.establish() returned null - moderation engine remains active in-app")
                networkModerationManager?.setVpnActive(true)
                return
            }

            isRunning = true
            networkModerationManager?.setVpnActive(true)
            startDnsInspectionLoop(vpnInterface!!)
            Log.i(TAG, "Aero DNS Network Moderator VpnService successfully established")
        } catch (t: Throwable) {
            Log.e(TAG, "Failed to establish VpnService: ${t.message}", t)
            networkModerationManager?.setVpnActive(true)
        }
    }

    private fun startDnsInspectionLoop(pfd: ParcelFileDescriptor) {
        workerJob = vpnScope.launch {
            val inStream = FileInputStream(pfd.fileDescriptor)
            val outStream = FileOutputStream(pfd.fileDescriptor)
            val packetBuffer = ByteArray(4096)

            while (isActive && isRunning) {
                try {
                    val length = inStream.read(packetBuffer)
                    if (length <= 0) {
                        kotlinx.coroutines.delay(5)
                        continue
                    }

                    // Inspect reusable buffer before allocating a copy; cap concurrent DNS tasks
                    if (length > 28 && isUdpDnsPacket(packetBuffer, length) && dnsConcurrencyLimiter.tryAcquire()) {
                        val packet = packetBuffer.copyOf(length)
                        vpnScope.launch {
                            try {
                                handleDnsPacket(packet, outStream)
                            } finally {
                                dnsConcurrencyLimiter.release()
                            }
                        }
                    }
                } catch (e: Exception) {
                    if (!isActive || !isRunning) break
                    Log.w(TAG, "Exception in VPN read loop: ${e.message}")
                    kotlinx.coroutines.delay(15)
                }
            }
        }
    }

    private fun isUdpDnsPacket(data: ByteArray, length: Int = data.size): Boolean {
        if (length < 28) return false
        val version = (data[0].toInt() shr 4) and 0x0F
        if (version != 4) return false
        val protocol = data[9].toInt() and 0xFF
        if (protocol != 17) return false // 17 = UDP
        val ihl = (data[0].toInt() and 0x0F) * 4
        if (length < ihl + 8) return false
        val destPort = ((data[ihl + 2].toInt() and 0xFF) shl 8) or (data[ihl + 3].toInt() and 0xFF)
        return destPort == 53
    }

    private fun getUpstreamDnsServers(queriedDomain: String = ""): List<InetAddress> {
        val servers = mutableListOf<InetAddress>()
        val cleanDom = queriedDomain.trim().lowercase()

        // Always resolve relay & tunnel control domains via 8.8.8.8 so Family DNS never blocks the bridge
        if (cleanDom.endsWith("trycloudflare.com") || cleanDom.endsWith("cloudflare.com") || cleanDom.endsWith("onrender.com")) {
            try {
                servers.add(InetAddress.getByAddress(byteArrayOf(8, 8, 8, 8)))
                servers.add(InetAddress.getByAddress(byteArrayOf(8, 8, 4, 4)))
            } catch (_: Throwable) {}
            return servers
        }

        val preset = networkModerationManager?.activeDnsPreset ?: "family"
        val isAdultFilterOn = networkModerationManager?.isAdultCategoryEnabled() == true

        try {
            when (preset) {
                "adguard-family" -> {
                    servers.add(InetAddress.getByAddress(byteArrayOf(94.toByte(), 140.toByte(), 14, 15)))
                    servers.add(InetAddress.getByAddress(byteArrayOf(94.toByte(), 140.toByte(), 15, 16)))
                    servers.add(InetAddress.getByAddress(byteArrayOf(1, 1, 1, 3)))
                    servers.add(InetAddress.getByAddress(byteArrayOf(1, 0, 0, 3)))
                }
                "adguard" -> {
                    servers.add(InetAddress.getByAddress(byteArrayOf(94.toByte(), 140.toByte(), 14, 14)))
                    servers.add(InetAddress.getByAddress(byteArrayOf(94.toByte(), 140.toByte(), 15, 15)))
                }
                "security" -> {
                    servers.add(InetAddress.getByAddress(byteArrayOf(1, 1, 1, 2)))
                    servers.add(InetAddress.getByAddress(byteArrayOf(1, 0, 0, 2)))
                }
                "family" -> {
                    servers.add(InetAddress.getByAddress(byteArrayOf(1, 1, 1, 3)))
                    servers.add(InetAddress.getByAddress(byteArrayOf(1, 0, 0, 3)))
                    servers.add(InetAddress.getByAddress(byteArrayOf(94.toByte(), 140.toByte(), 14, 15)))
                }
                else -> {
                    if (isAdultFilterOn) {
                        servers.add(InetAddress.getByAddress(byteArrayOf(1, 1, 1, 3)))
                        servers.add(InetAddress.getByAddress(byteArrayOf(1, 0, 0, 3)))
                    }
                }
            }
        } catch (_: Throwable) {}

        val nowMs = System.currentTimeMillis()
        if (cachedSystemDns.isEmpty() || (nowMs - cachedSystemDnsMs) > 30_000L) {
            val refreshed = mutableListOf<InetAddress>()
            try {
                val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as? android.net.ConnectivityManager
                if (cm != null) {
                    @Suppress("DEPRECATION")
                    val networks = cm.allNetworks
                    for (net in networks) {
                        val caps = cm.getNetworkCapabilities(net) ?: continue
                        if (caps.hasTransport(android.net.NetworkCapabilities.TRANSPORT_VPN)) continue
                        if (!caps.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_INTERNET)) continue
                        val lp = cm.getLinkProperties(net) ?: continue
                        for (dns in lp.dnsServers) {
                            val addr = dns.address
                            if (addr != null && addr.size == 4 && dns.hostAddress != "10.10.10.1" && !refreshed.contains(dns)) {
                                refreshed.add(dns)
                            }
                        }
                    }
                }
            } catch (_: Throwable) {}
            cachedSystemDns = refreshed
            cachedSystemDnsMs = nowMs
        }
        for (dns in cachedSystemDns) {
            if (!servers.contains(dns)) servers.add(dns)
        }

        try {
            val googleDns = InetAddress.getByAddress(byteArrayOf(8, 8, 8, 8))
            if (!servers.contains(googleDns)) servers.add(googleDns)
        } catch (_: Throwable) {}

        try {
            val cloudflareDns = InetAddress.getByAddress(byteArrayOf(1, 1, 1, 1))
            if (!servers.contains(cloudflareDns)) servers.add(cloudflareDns)
        } catch (_: Throwable) {}

        return servers
    }

    private fun handleDnsPacket(
        packet: ByteArray,
        outStream: FileOutputStream
    ) {
        val ihl = (packet[0].toInt() and 0x0F) * 4
        val udpHeaderOffset = ihl
        val dnsPayloadOffset = udpHeaderOffset + 8
        if (packet.size <= dnsPayloadOffset) return

        val srcPort = ((packet[ihl].toInt() and 0xFF) shl 8) or (packet[ihl + 1].toInt() and 0xFF)
        val dnsData = packet.copyOfRange(dnsPayloadOffset, packet.size)
        val domain = extractQueryDomain(dnsData)

        if (domain.isNotBlank()) {
            val (isBlocked, reason) = try {
                networkModerationManager?.shouldBlockDomain(domain, srcPort = srcPort) ?: (false to "")
            } catch (_: Throwable) {
                false to ""
            }
            if (isBlocked) {
                Log.i(TAG, "🛡️ BLOCKED DNS query for '$domain' ($reason)")
                val blockResponse = createBlockedDnsResponse(dnsData)
                val ipPacketResponse = wrapInUdpIp(packet, blockResponse)
                try {
                    synchronized(outStream) {
                        outStream.write(ipPacketResponse)
                        outStream.flush()
                    }
                } catch (e: Exception) {
                    Log.w(TAG, "Failed to write DNS block response: ${e.message}")
                }
                return
            }
        }

        // Forward clean DNS query using a dedicated protected DatagramSocket per query
        val dnsServers = getUpstreamDnsServers(domain)
        val isAdultFilterOn = networkModerationManager?.isAdultCategoryEnabled() == true ||
            networkModerationManager?.activeDnsPreset in listOf("family", "adguard-family")
        for (upstreamIp in dnsServers) {
            var socket: DatagramSocket? = null
            try {
                socket = DatagramSocket()
                protect(socket)
                socket.soTimeout = 1500

                val sendPacket = DatagramPacket(dnsData, dnsData.size, upstreamIp, 53)
                socket.send(sendPacket)

                val recvBuf = ByteArray(2048)
                val recvPacket = DatagramPacket(recvBuf, recvBuf.size)
                socket.receive(recvPacket)

                val responseDnsPayload = recvBuf.copyOf(recvPacket.length)

                // Check if Cloudflare Family DNS (1.1.1.3 / 1.0.0.3) sinkholed this domain to 0.0.0.0
                if (isAdultFilterOn && domain.isNotBlank() &&
                    com.kavach.network.SiteMetadataAnalyzer.isDnsResponseZeroSinkhole(responseDnsPayload)
                ) {
                    Log.i(TAG, "🛡️ FAMILY DNS (1.1.1.3) SINKHOLED adult domain '$domain' -> Auto-blacklisting")
                    try {
                        networkModerationManager?.onFamilyDnsSinkholed(domain, srcPort = srcPort)
                    } catch (_: Throwable) {}
                    val blockResponse = createBlockedDnsResponse(dnsData)
                    val ipPacketResponse = wrapInUdpIp(packet, blockResponse)
                    synchronized(outStream) {
                        outStream.write(ipPacketResponse)
                        outStream.flush()
                    }
                    return
                }

                if (domain.isNotBlank()) {
                    try {
                        networkModerationManager?.perAppMonitor?.parseAndCacheDnsResponseIps(domain, responseDnsPayload)
                    } catch (_: Throwable) {}
                }
                val responseIpPacket = wrapInUdpIp(packet, responseDnsPayload)
                synchronized(outStream) {
                    outStream.write(responseIpPacket)
                    outStream.flush()
                }
                return
            } catch (_: Exception) {
                // Try next upstream DNS server
            } finally {
                try { socket?.close() } catch (_: Exception) {}
            }
        }
    }

    private fun extractQueryDomain(dnsData: ByteArray): String {
        if (dnsData.size < 12) return ""
        var pos = 12
        val sb = StringBuilder()
        while (pos < dnsData.size) {
            val len = dnsData[pos].toInt() and 0xFF
            if (len == 0) break
            if ((len and 0xC0) == 0xC0) break // compression pointer
            pos++
            if (pos + len > dnsData.size) break
            if (sb.isNotEmpty()) sb.append(".")
            for (i in 0 until len) {
                sb.append(dnsData[pos + i].toInt().toChar())
            }
            pos += len
        }
        return sb.toString().lowercase()
    }

    private fun createBlockedDnsResponse(request: ByteArray): ByteArray {
        val response = request.copyOf()
        if (response.size < 12) return response
        // Set QR=1 (response), RD=1, RA=1, RCODE=3 (NXDOMAIN)
        response[2] = ((response[2].toInt() and 0x79) or 0x81).toByte()
        response[3] = ((response[3].toInt() and 0x70) or 0x83).toByte()
        // Zero out answer/authority/additional counts for clean NXDOMAIN
        response[6] = 0
        response[7] = 0
        response[8] = 0
        response[9] = 0
        response[10] = 0
        response[11] = 0
        return response
    }

    private fun wrapInUdpIp(origPacket: ByteArray, payload: ByteArray): ByteArray {
        val ihl = 20 // Standard 20-byte IPv4 header without options
        val origIhl = (origPacket[0].toInt() and 0x0F) * 4
        val totalLength = ihl + 8 + payload.size
        val result = ByteArray(totalLength)

        // IPv4 Header (20 bytes)
        result[0] = 0x45.toByte() // Version 4, IHL 5 (20 bytes)
        result[1] = 0x00.toByte() // DSCP / ECN
        result[2] = ((totalLength shr 8) and 0xFF).toByte()
        result[3] = (totalLength and 0xFF).toByte()
        result[4] = origPacket[4] // Identification
        result[5] = origPacket[5]
        result[6] = 0x40.toByte() // Flags: Don't Fragment (DF)
        result[7] = 0x00.toByte() // Fragment offset
        result[8] = 64.toByte()   // TTL = 64
        result[9] = 17.toByte()   // Protocol = 17 (UDP)
        result[10] = 0            // Header checksum placeholder
        result[11] = 0

        // Swap IP src and dest from original packet
        System.arraycopy(origPacket, 16, result, 12, 4) // old dest (10.10.10.1) -> new src
        System.arraycopy(origPacket, 12, result, 16, 4) // old src (10.10.10.2) -> new dest

        // Calculate mandatory RFC 1071 IPv4 Header Checksum over the 20-byte IPv4 header
        var sum = 0
        var i = 0
        while (i < ihl) {
            val word = ((result[i].toInt() and 0xFF) shl 8) or (result[i + 1].toInt() and 0xFF)
            sum += word
            i += 2
        }
        while ((sum shr 16) != 0) {
            sum = (sum and 0xFFFF) + (sum shr 16)
        }
        val checksum = sum.inv() and 0xFFFF
        result[10] = ((checksum shr 8) and 0xFF).toByte()
        result[11] = (checksum and 0xFF).toByte()

        // Swap UDP ports from original UDP header (located at origIhl)
        val srcPort = ((origPacket[origIhl].toInt() and 0xFF) shl 8) or (origPacket[origIhl + 1].toInt() and 0xFF)
        val dstPort = ((origPacket[origIhl + 2].toInt() and 0xFF) shl 8) or (origPacket[origIhl + 3].toInt() and 0xFF)
        val udpOffset = ihl
        result[udpOffset] = ((dstPort shr 8) and 0xFF).toByte()
        result[udpOffset + 1] = (dstPort and 0xFF).toByte()
        result[udpOffset + 2] = ((srcPort shr 8) and 0xFF).toByte()
        result[udpOffset + 3] = (srcPort and 0xFF).toByte()

        // UDP Length (8-byte header + DNS payload)
        val udpLen = 8 + payload.size
        result[udpOffset + 4] = ((udpLen shr 8) and 0xFF).toByte()
        result[udpOffset + 5] = (udpLen and 0xFF).toByte()
        result[udpOffset + 6] = 0 // UDP checksum is optional in IPv4 (0 = unused)
        result[udpOffset + 7] = 0

        // Copy DNS payload
        System.arraycopy(payload, 0, result, udpOffset + 8, payload.size)
        return result
    }

    internal fun stopVpnInternal() {
        isRunning = false
        networkModerationManager?.setVpnActive(false)
        workerJob?.cancel()
        workerJob = null
        try {
            vpnInterface?.close()
        } catch (_: Throwable) {}
        vpnInterface = null
        try {
            stopForeground(true)
        } catch (_: Throwable) {}
        Log.i(TAG, "Aero DNS Network Moderator VpnService stopped")
    }

    override fun onDestroy() {
        stopVpnInternal()
        try { vpnScope.cancel() } catch (_: Throwable) {}
        activeInstance = null
        super.onDestroy()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                NOTIFICATION_CHANNEL_ID,
                "Aero Network Moderator VPN",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Foreground status for device-wide DNS moderation and domain blocking"
            }
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(channel)
        }
    }

    private fun buildForegroundNotification(): android.app.Notification {
        val launchIntent = Intent(this, MainActivity::class.java)
        val pending = PendingIntent.getActivity(
            this,
            0,
            launchIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, NOTIFICATION_CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentTitle("🛡️ Aero Network Moderator Active")
            .setContentText("Local DNS filtering and domain blacklisting active")
            .setOngoing(true)
            .setContentIntent(pending)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }
}
