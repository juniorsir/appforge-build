#!/usr/bin/env python3
"""
Termux-First Single-Window Agy HUD v2 Companion Daemon (agy_hud_daemon.py)

Connects to KaVach / AeroShare (http://127.0.0.1:8080 or ~/.aura_target_url with Bearer token
from ~/.aura_token) over RFC 6455 WebSocket + /api/hud/poll fallback.
Manages a persistent `agy` CLI session (`-p= --input-format stream-json --output-format
stream-json --dangerously-skip-permissions` with sticky ~/.agy_hud_conversation_id) and routes
chess prompts directly to `chess_autopilot`, pushing compact Single-Window HUD v2 updates to
POST /api/hud/state.

Usage:
    python agy_hud_daemon.py
    python agy_hud_daemon.py --new
    python agy_hud_daemon.py --url http://127.0.0.1:8080 --mode auto
    python agy_hud_daemon.py --self-test
"""

from __future__ import annotations

import argparse
import base64
import hashlib
import json
import os
import queue
import re
import signal
import socket
import struct
import subprocess
import sys
import tempfile
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid
from typing import Any, Dict, List, Optional, Tuple

DEFAULT_HTTP_URL = os.environ.get("AURA_HTTP_URL", "http://127.0.0.1:8080").rstrip("/")
CONVERSATION_ID_PATH = os.path.expanduser("~/.agy_hud_conversation_id")
BRIDGE_RUNTIME_PREFIX = (
    "Use KaVach local bridge (http://127.0.0.1:8080) with token from ~/.aura_token "
    "when device/UI control is needed.\n"
)

TOKEN_CANDIDATES = [
    os.path.expanduser("~/.aura_token"),
    os.path.join(os.path.dirname(os.path.abspath(__file__)), ".aura_token"),
]

MARKDOWN_LINK_RE = re.compile(r"!?\[([^\]]*)\]\(([^)\s]+)\)")
RAW_URI_RE = re.compile(r"(https?://[^\s<>'\"`\])]+|/(?:sdcard|storage/emulated/\d+|data/data/[^\s]+)/[^\s<>'\"`\])]+)")
IMAGE_EXTS = (".jpg", ".jpeg", ".png", ".webp", ".gif", ".bmp")
VIDEO_EXTS = (".mp4", ".mov", ".webm", ".mkv", ".m4v", ".m3u8")
AUDIO_EXTS = (".mp3", ".m4a", ".wav", ".ogg", ".flac", ".aac")
YOUTUBE_URL_RE = re.compile(
    r"(?:youtube\.com/(?:watch\?[^\s]*v=|embed/|shorts/)|youtu\.be/)([A-Za-z0-9_-]{6,})",
    re.IGNORECASE,
)

CHESS_SQUARE_RE = re.compile(
    r"\b(white|black)\s+(king|queen|rook|bishop|knight|pawn)\s+on\s+([a-h][1-8])\b",
    re.IGNORECASE,
)
CHESS_EVAL_RE = re.compile(r"^\s*(?:[+-]?\d+(?:\.\d+)?|#?-?M\d+)\s*$", re.IGNORECASE)

SENSITIVE_HIGH_RISK_PATTERNS = [
    re.compile(r"\brm\s+-rf?\b|\bmkfs\b|\bdd\s+if=", re.I),
    re.compile(r"\b(factory\s*reset|wipe\s*data|format\s*storage|erase\s*phone)\b", re.I),
    re.compile(r"\b(pay|transfer|send\s*money|upi|bank|checkout|purchase)\b", re.I),
]
SENSITIVE_MEDIUM_RISK_PATTERNS = [
    re.compile(r"\b(send\s+(message|whatsapp|email|sms|reply)|post\s+tweet|uninstall)\b", re.I),
    re.compile(r"\b(delete|remove)\s+(file|folder|contact|chat|photo)\b", re.I),
]

WEIGHTED_APP_ICON_RULES: List[Tuple[int, Tuple[str, ...], str, str]] = [
    (12, ("chess", "chess.com", "chessboard", "grandmaster", "checkmate", "com.chess"), "chess", "com.chess"),
    (12, ("lichess", "org.lichess.mobileapp"), "lichess", "org.lichess.mobileapp"),
    (11, ("youtube", "youtu.be", "yt", "com.google.android.youtube", "shorts"), "youtube", "com.google.android.youtube"),
    (11, ("whatsapp", "wa", "com.whatsapp"), "whatsapp", "com.whatsapp"),
    (11, ("spotify", "music", "podcast", "com.spotify.music"), "spotify", "com.spotify.music"),
    (11, ("vlc", "videolan", "org.videolan.vlc"), "vlc", "org.videolan.vlc"),
    (10, ("chrome", "browser", "http://", "https://", "com.android.chrome"), "chrome", "com.android.chrome"),
    (10, ("instagram", "reels", "com.instagram.android"), "instagram", "com.instagram.android"),
    (10, ("telegram", "org.telegram.messenger"), "telegram", "org.telegram.messenger"),
    (10, ("gmail", "email", "mail", "com.google.android.gm"), "gmail", "com.google.android.gm"),
    (10, ("settings", "wi-fi", "wifi", "bluetooth", "com.android.settings"), "settings", "com.android.settings"),
    (8, ("camera", "photo", "selfie", "take a photo"), "camera", ""),
    (8, ("call ", "dial", "sms", "contact"), "phone", ""),
    (5, ("token", "auth", "security", "shield", "lock"), "security", ""),
    (3, ("termux", "bash", "shell", "terminal", "cli", "com.termux"), "termux", "com.termux"),
    (2, ("code", "python", "script", "build", "compile", "kotlin", "gradle"), "code", ""),
]

_CHESS_AUTOPILOT_CACHE: Dict[str, Any] = {"loaded": False, "mod": None}


def _load_chess_autopilot():
    if _CHESS_AUTOPILOT_CACHE["loaded"]:
        return _CHESS_AUTOPILOT_CACHE["mod"]
    _CHESS_AUTOPILOT_CACHE["loaded"] = True
    for d in (
        os.path.dirname(os.path.realpath(__file__)),
        os.path.expanduser("~"),
        os.path.expanduser("~/downloads"),
    ):
        if d and d not in sys.path and os.path.exists(os.path.join(d, "chess_autopilot.py")):
            sys.path.insert(0, d)
    try:
        import chess_autopilot as ca  # type: ignore

        _CHESS_AUTOPILOT_CACHE["mod"] = ca
        return ca
    except Exception:
        return None


def resolve_default_url() -> str:
    env_url = os.environ.get("AURA_HTTP_URL", "").strip().rstrip("/")
    if env_url.startswith("http"):
        return env_url
    target_path = os.path.expanduser("~/.aura_target_url")
    if os.path.exists(target_path):
        try:
            val = open(target_path, "r", encoding="utf-8").read().strip().rstrip("/")
            if val.startswith("http"):
                return val
        except OSError:
            pass
    return DEFAULT_HTTP_URL


def load_auth_token(explicit_token: Optional[str] = None) -> str:
    if explicit_token:
        return explicit_token.strip()
    for env_key in ("AURA_API_TOKEN", "AURA_TOKEN", "AERO_TOKEN"):
        val = os.environ.get(env_key, "").strip()
        if val:
            return val
    for path in TOKEN_CANDIDATES:
        if os.path.exists(path):
            try:
                val = open(path, "r", encoding="utf-8").read().strip()
                if val:
                    return val
            except OSError:
                pass
    return ""


def load_conversation_id(path: str = CONVERSATION_ID_PATH) -> str:
    try:
        if os.path.exists(path):
            return open(path, "r", encoding="utf-8").read().strip()
    except OSError:
        pass
    return ""


def save_conversation_id(conv_id: str, path: str = CONVERSATION_ID_PATH) -> None:
    cleaned = (conv_id or "").strip()
    if not cleaned:
        return
    try:
        parent = os.path.dirname(os.path.abspath(path))
        if parent:
            os.makedirs(parent, exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            f.write(cleaned + "\n")
    except OSError:
        pass


def clear_conversation_id(path: str = CONVERSATION_ID_PATH) -> None:
    try:
        if os.path.exists(path):
            os.remove(path)
    except OSError:
        pass


def extract_conversation_id(event: Dict[str, Any]) -> str:
    if not isinstance(event, dict):
        return ""
    for key in ("conversation_id", "conversationId", "session_id", "sessionId"):
        val = event.get(key)
        if isinstance(val, str) and val.strip():
            return val.strip()
    for nested_key in ("session", "metadata", "result"):
        nested = event.get(nested_key)
        if isinstance(nested, dict):
            cid = extract_conversation_id(nested)
            if cid:
                return cid
    return ""


def infer_media_kind(uri: str) -> Optional[str]:
    low = (uri or "").lower()
    clean = low.split("?", 1)[0].split("#", 1)[0]
    if low.startswith("data:image/") or any(clean.endswith(ext) for ext in IMAGE_EXTS):
        return "image"
    if any(clean.endswith(ext) for ext in VIDEO_EXTS) or YOUTUBE_URL_RE.search(uri or ""):
        return "video"
    if any(clean.endswith(ext) for ext in AUDIO_EXTS):
        return "audio"
    return None


def extract_media_items_from_text(text: str) -> List[Dict[str, Any]]:
    """Extracts unique image/video/audio items for the HUD middle carousel."""
    if not text:
        return []
    found: List[Dict[str, Any]] = []
    seen = set()

    for m in MARKDOWN_LINK_RE.finditer(text):
        label, uri = m.group(1).strip(), m.group(2).strip().rstrip(".,;")
        kind = infer_media_kind(uri)
        if kind and uri not in seen:
            seen.add(uri)
            found.append({"id": f"m_{len(found)+1}", "kind": kind, "title": label or os.path.basename(uri) or kind.title(), "uri": uri})

    for m in RAW_URI_RE.finditer(text):
        uri = m.group(1).strip().rstrip(".,;)")
        kind = infer_media_kind(uri)
        if kind and uri not in seen:
            seen.add(uri)
            found.append({"id": f"m_{len(found)+1}", "kind": kind, "title": os.path.basename(uri.split("?")[0]) or kind.title(), "uri": uri})

    return found[:8]


def detect_sensitive_prompt_risk(text: str) -> Optional[Dict[str, Any]]:
    clean = (text or "").strip()
    if not clean:
        return None
    for pat in SENSITIVE_HIGH_RISK_PATTERNS:
        if pat.search(clean):
            return {
                "riskLevel": "high",
                "title": "High-Risk Action Requires Approval",
                "description": "Confirm before executing potentially destructive action.",
                "commandPreview": clean[:240],
            }
    for pat in SENSITIVE_MEDIUM_RISK_PATTERNS:
        if pat.search(clean):
            return {
                "riskLevel": "medium",
                "title": "Confirm Sensitive Action",
                "description": "Review this action before execution.",
                "commandPreview": clean[:240],
            }
    return None


def format_region_context_for_prompt(
    text: str,
    payload: Optional[Dict[str, Any]],
    action: str = "PROMPT",
) -> str:
    base = (text or "").strip()
    if not isinstance(payload, dict):
        return base
    region = payload.get("regionContext")
    if not isinstance(region, dict):
        return base
    x1, y1 = int(region.get("x1", 0)), int(region.get("y1", 0))
    x2, y2 = int(region.get("x2", 0)), int(region.get("y2", 0))
    sw, sh = int(region.get("screenWidth", 1080)), int(region.get("screenHeight", 2400))
    pkg = str(region.get("packageName") or "").strip()
    nodes = region.get("nodes") or []
    lines: List[str] = []
    for n in nodes[:12]:
        if isinstance(n, dict):
            lbl = str(n.get("text") or n.get("contentDescription") or n.get("viewId") or "").strip()
            if lbl:
                lines.append(f"- {lbl[:100]} @({int(n.get('centerX', 0))},{int(n.get('centerY', 0))})")
    header = f"[Snipped Region [{x1},{y1}]-[{x2},{y2}] on {sw}x{sh}" + (f" ({pkg})]" if pkg else "]")
    ctx_block = header + ("\n" + "\n".join(lines) if lines else "")
    return f"{base or 'Inspect this selected screen region.'}\n\n{ctx_block}"


def infer_app_icon(
    text: str,
    explicit_icon: str = "",
    explicit_package: str = "",
    preserve_package: str = "",
) -> Tuple[str, str]:
    clean_icon = explicit_icon.strip()
    clean_pkg = explicit_package.strip()
    if clean_pkg == "com.termux" and preserve_package and preserve_package != "com.termux":
        clean_pkg = ""
    if clean_icon or (clean_pkg and clean_pkg != "com.termux"):
        return clean_icon, clean_pkg

    hay = f" {(text or '').lower()} "
    best_score = 0
    best_pair: Tuple[str, str] = ("spark", "")
    for priority, keywords, icon_key, pkg in WEIGHTED_APP_ICON_RULES:
        for kw in keywords:
            if (len(kw.strip()) <= 3 and re.search(rf"(^|[^a-z0-9]){re.escape(kw.strip())}([^a-z0-9]|$)", hay)) or (
                len(kw.strip()) > 3 and kw in hay
            ):
                if priority > best_score:
                    best_score = priority
                    best_pair = (icon_key, pkg)
                break
    if best_score > 0:
        return best_pair
    if preserve_package and preserve_package != "com.termux":
        return clean_icon, preserve_package
    return "spark", clean_pkg


class KavachHudClient:
    """Zero-dependency HTTP client for Single-Window KaVach /api/hud/* endpoints."""

    def __init__(self, base_url: str, token: str, timeout: float = 5.0) -> None:
        self.base_url = base_url.rstrip("/")
        self.token = token.strip()
        self.timeout = timeout

    def _headers(self, json_body: bool = True) -> Dict[str, str]:
        headers = {"User-Agent": "AgyHudDaemon/3.0", "Accept": "application/json"}
        if json_body:
            headers["Content-Type"] = "application/json"
        if self.token:
            headers["Authorization"] = f"Bearer {self.token}"
            headers["X-API-Key"] = self.token
        return headers

    def request_json(self, method: str, path: str, payload: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        url = f"{self.base_url}{path}"
        data = json.dumps(payload).encode("utf-8") if payload is not None else None
        req = urllib.request.Request(url=url, data=data, headers=self._headers(payload is not None), method=method.upper())
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                raw = resp.read().decode("utf-8", errors="replace").strip()
                return json.loads(raw) if raw else {"success": True}
        except urllib.error.HTTPError as e:
            try:
                body = e.read().decode("utf-8", errors="replace")
                parsed = json.loads(body)
                if isinstance(parsed, dict):
                    parsed.setdefault("httpStatus", e.code)
                    return parsed
            except Exception:
                pass
            return {"success": False, "httpStatus": e.code, "error": str(e)}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def push_hud_state(self, state_payload: Dict[str, Any]) -> Dict[str, Any]:
        return self.request_json("POST", "/api/hud/state", state_payload)

    def patch_hud_state(self, patch_payload: Dict[str, Any]) -> Dict[str, Any]:
        return self.request_json("POST", "/api/hud/patch", patch_payload)

    def poll_hud_commands(self) -> Dict[str, Any]:
        return self.request_json("GET", "/api/hud/poll")

    def hide_hud(self) -> Dict[str, Any]:
        return self.request_json("POST", "/api/hud/hide", {})

    def push_approval(
        self,
        approval_id: str,
        title: str,
        description: str = "",
        command_preview: str = "",
        risk_level: str = "medium",
        allow_edit: bool = True,
        timeout_seconds: int = 30,
    ) -> Dict[str, Any]:
        return self.request_json(
            "POST",
            "/api/hud/approval",
            {
                "active": True,
                "id": approval_id,
                "title": title,
                "description": description,
                "commandPreview": command_preview,
                "riskLevel": risk_level,
                "allowEdit": bool(allow_edit),
                "editableText": command_preview,
                "timeoutSeconds": max(0, int(timeout_seconds)),
            },
        )

    def clear_approval(self) -> Dict[str, Any]:
        return self.request_json("POST", "/api/hud/approval", {"clear": True, "active": False})

    def fetch_ui_tree(self) -> Dict[str, Any]:
        return self.request_json("GET", "/api/ui/tree")


class StdlibWebSocketListener:
    """Pure-stdlib RFC 6455 WebSocket listener delivering live HUD_COMMAND frames."""

    def __init__(self, base_http_url: str, token: str, on_message, stop_event: threading.Event) -> None:
        self.base_http_url = base_http_url.rstrip("/")
        self.token = token
        self.on_message = on_message
        self.stop_event = stop_event
        self.connected = False
        self._sock: Optional[socket.socket] = None
        self._thread: Optional[threading.Thread] = None

    def start(self) -> None:
        self._thread = threading.Thread(target=self._run_loop, name="agy-ws-listener", daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self.connected = False
        if self._sock is not None:
            try:
                self._sock.close()
            except OSError:
                pass

    def _connect_and_read(self) -> None:
        parsed = urllib.parse.urlparse(self.base_http_url)
        host = parsed.hostname or "127.0.0.1"
        port = parsed.port or (443 if parsed.scheme == "https" else 8080)
        ws_path = f"/ws?token={urllib.parse.quote(self.token)}" if self.token else "/ws"

        sock = socket.create_connection((host, port), timeout=5.0)
        self._sock = sock
        key = base64.b64encode(os.urandom(16)).decode("ascii")
        headers = [
            f"GET {ws_path} HTTP/1.1",
            f"Host: {host}:{port}",
            "Upgrade: websocket",
            "Connection: Upgrade",
            f"Sec-WebSocket-Key: {key}",
            "Sec-WebSocket-Version: 13",
        ]
        if self.token:
            headers.append(f"Authorization: Bearer {self.token}")
            headers.append(f"X-API-Key: {self.token}")
        sock.sendall(("\r\n".join(headers) + "\r\n\r\n").encode("utf-8"))

        resp_buf = b""
        while b"\r\n\r\n" not in resp_buf and len(resp_buf) < 8192:
            chunk = sock.recv(1024)
            if not chunk:
                raise ConnectionError("WebSocket closed during handshake")
            resp_buf += chunk
        status_line = resp_buf.split(b"\r\n", 1)[0].decode("utf-8", errors="replace")
        if "101" not in status_line:
            raise ConnectionError(f"WebSocket rejected: {status_line}")

        expected_accept = base64.b64encode(
            hashlib.sha1((key + "258EAFA5-E914-47DA-95CA-C5AB0DC85B11").encode("utf-8")).digest()
        ).decode("ascii")
        if expected_accept.encode("ascii") not in resp_buf:
            raise ConnectionError("Invalid Sec-WebSocket-Accept")

        sock.settimeout(2.0)
        self.connected = True
        leftover = resp_buf.split(b"\r\n\r\n", 1)[1]

        def read_exact(n: int) -> bytes:
            nonlocal leftover
            while len(leftover) < n:
                if self.stop_event.is_set():
                    raise ConnectionAbortedError("Stopping")
                try:
                    data = sock.recv(max(4096, n - len(leftover)))
                except socket.timeout:
                    continue
                if not data:
                    raise ConnectionError("Socket EOF")
                leftover += data
            out, leftover = leftover[:n], leftover[n:]
            return out

        while not self.stop_event.is_set():
            hdr = read_exact(2)
            b0, b1 = hdr[0], hdr[1]
            opcode, masked, length = b0 & 0x0F, (b1 & 0x80) != 0, b1 & 0x7F
            if length == 126:
                length = struct.unpack("!H", read_exact(2))[0]
            elif length == 127:
                length = struct.unpack("!Q", read_exact(8))[0]
            mask_key = read_exact(4) if masked else b""
            payload = read_exact(length) if length > 0 else b""
            if masked and payload:
                payload = bytes(b ^ mask_key[i % 4] for i, b in enumerate(payload))
            if opcode == 0x8:
                break
            if opcode == 0x9:
                self._send_ws_frame(sock, 0xA, payload)
            elif opcode == 0x1:
                try:
                    msg = json.loads(payload.decode("utf-8", errors="replace"))
                    if isinstance(msg, dict):
                        self.on_message(msg)
                except Exception:
                    pass

    @staticmethod
    def _send_ws_frame(sock: socket.socket, opcode: int, payload: bytes) -> None:
        mask_key = os.urandom(4)
        hdr = bytearray([0x80 | (opcode & 0x0F)])
        ln = len(payload)
        if ln < 126:
            hdr.append(0x80 | ln)
        elif ln < 65536:
            hdr.append(0x80 | 126)
            hdr.extend(struct.pack("!H", ln))
        else:
            hdr.append(0x80 | 127)
            hdr.extend(struct.pack("!Q", ln))
        hdr.extend(mask_key)
        masked = bytes(b ^ mask_key[i % 4] for i, b in enumerate(payload))
        sock.sendall(bytes(hdr) + masked)

    def _run_loop(self) -> None:
        while not self.stop_event.is_set():
            try:
                self._connect_and_read()
            except Exception:
                pass
            finally:
                self.connected = False
                self.stop()
            if not self.stop_event.is_set():
                self.stop_event.wait(2.0)


class HudStateTracker:
    """Maintains Single-Window HUD v2 state and maps `agy` JSON events cleanly."""

    def __init__(self, auto_collapse_seconds: int = 4) -> None:
        self.auto_collapse_seconds = auto_collapse_seconds
        self.status = "IDLE"
        self.title = "Agy Ready"
        self.thinking_text = ""
        self.detailed_output = ""
        self.icon = "spark"
        self.app_package = ""
        self.progress_percent = -1
        self.steps: List[Dict[str, str]] = []
        self.quick_actions: List[Dict[str, str]] = []
        self.media_items: List[Dict[str, Any]] = []
        self.media_playing = False
        self.media_muted = False
        self.chess: Optional[Dict[str, Any]] = None
        self.hardware_chip: Optional[Dict[str, str]] = None
        self.logs: List[str] = []
        self._lock = threading.Lock()

    def _append_log_locked(self, line: str) -> None:
        cleaned = (line or "").strip()
        if not cleaned:
            return
        entry = f"[{time.strftime('%H:%M:%S')}] {cleaned[:180]}"
        if self.logs and self.logs[-1].endswith(cleaned[:180]):
            return
        self.logs.append(entry)
        if len(self.logs) > 20:
            self.logs = self.logs[-20:]

    def _merge_media_items_locked(self, items: List[Dict[str, Any]]) -> None:
        seen = {str(x.get("uri") or "") for x in self.media_items}
        for it in items:
            u = str(it.get("uri") or "")
            if u and u not in seen:
                seen.add(u)
                self.media_items.append(dict(it))
        self.media_items = self.media_items[:8]

    @classmethod
    def _extract_text_value(cls, value: Any, _depth: int = 0) -> str:
        if _depth > 4 or value is None:
            return ""
        if isinstance(value, str):
            return value.strip()
        if isinstance(value, list):
            parts: List[str] = []
            for item in value:
                if isinstance(item, dict) and str(item.get("type") or "").lower() == "thinking":
                    continue
                extracted = cls._extract_text_value(item, _depth + 1)
                if extracted:
                    parts.append(extracted)
            return "\n".join(parts).strip()
        if isinstance(value, dict):
            for key in ("summary", "response", "text", "message", "content", "output", "result", "error"):
                if key in value:
                    extracted = cls._extract_text_value(value.get(key), _depth + 1)
                    if extracted:
                        return extracted
            return ""
        return ""

    @classmethod
    def _extract_event_text(cls, event: Dict[str, Any], keys: Tuple[str, ...]) -> str:
        for key in keys:
            if key in event:
                extracted = cls._extract_text_value(event.get(key))
                if extracted:
                    return extracted
        return ""

    def begin_prompt(self, prompt_text: str) -> Dict[str, Any]:
        with self._lock:
            clean = prompt_text.strip()
            self.status = "WORKING"
            self.title = clean[:60] or "Running Task"
            self.thinking_text = "Thinking..."
            self.detailed_output = ""
            self.progress_percent = -1
            self.steps = []
            self.quick_actions = []
            self.media_items = []
            self.media_playing = False
            self.chess = None
            self.hardware_chip = None
            self.icon, self.app_package = infer_app_icon(clean)
            self._append_log_locked(f"Prompt: {clean}")
            return self.to_payload_locked()

    def apply_chess_payload(self, chess_payload: Dict[str, Any]) -> Dict[str, Any]:
        with self._lock:
            self.status = str(chess_payload.get("state") or chess_payload.get("status") or self.status)
            self.title = str(chess_payload.get("title") or self.title)[:60]
            self.thinking_text = str(chess_payload.get("thinkingText") or chess_payload.get("currentAction") or self.thinking_text)[:80]
            self.icon = "chess"
            self.app_package = "com.chess"
            if chess_payload.get("detailedOutput"):
                self.detailed_output = str(chess_payload["detailedOutput"])[:2400]
            tm = chess_payload.get("taskMap") if isinstance(chess_payload.get("taskMap"), dict) else {}
            if isinstance(chess_payload.get("chess"), dict):
                self.chess = dict(chess_payload["chess"])
            elif isinstance(tm.get("chess"), dict):
                self.chess = dict(tm["chess"])
            for ln in chess_payload.get("outputLogs") or []:
                if isinstance(ln, str) and ln.strip():
                    self._append_log_locked(ln)
            return self.to_payload_locked()

    def apply_agy_event(self, event: Dict[str, Any]) -> Dict[str, Any]:
        with self._lock:
            evt_type = str(event.get("type") or event.get("event") or "").lower()
            if not evt_type and (
                "response" in event
                or ("status" in event and "conversation_id" in event)
                or isinstance(event.get("result"), dict)
            ):
                evt_type = "result"

            if event.get("icon") or event.get("appPackage"):
                self.icon, self.app_package = infer_app_icon(
                    self.title,
                    str(event.get("icon") or ""),
                    str(event.get("appPackage") or ""),
                    preserve_package=self.app_package,
                )

            if isinstance(event.get("chess"), dict):
                self.chess = dict(event["chess"])
            elif isinstance(event.get("taskMap"), dict) and isinstance(event["taskMap"].get("chess"), dict):
                self.chess = dict(event["taskMap"]["chess"])

            if isinstance(event.get("hardwareChip"), dict):
                self.hardware_chip = dict(event["hardwareChip"])

            if isinstance(event.get("mediaItems"), list):
                self._merge_media_items_locked([x for x in event["mediaItems"] if isinstance(x, dict)])

            steps = event.get("steps") or event.get("tasks")
            if isinstance(steps, list):
                parsed: List[Dict[str, str]] = []
                for idx, st in enumerate(steps[:6]):
                    if isinstance(st, dict):
                        lbl = str(st.get("label") or st.get("title") or "").strip()
                        if lbl:
                            status_raw = str(st.get("status") or "pending").lower()
                            norm_st = "done" if status_raw in ("done", "completed") else ("doing" if status_raw in ("doing", "in_progress", "running") else "pending")
                            parsed.append({"id": str(st.get("id") or f"step_{idx+1}"), "label": lbl, "status": norm_st})
                            if norm_st == "doing":
                                self.thinking_text = lbl[:80]
                if parsed:
                    self.steps = parsed
                    self.status = "WORKING"

            tool_name = str(event.get("tool") or event.get("tool_name") or event.get("name") or (event.get("tool_use") or {}).get("name", "")).strip()
            if tool_name or evt_type in ("tool_use", "tool_call", "function_call"):
                self.status = "WORKING"
                self.thinking_text = f"Using {tool_name or 'tool'}..."
                self._append_log_locked(self.thinking_text)

            if evt_type in ("needs_input", "question", "ask_user", "input_required") or event.get("needs_input"):
                q = self._extract_event_text(event, ("question", "text", "message", "content", "response")) or "Needs your input"
                self.status = "NEEDS_INPUT"
                self.thinking_text = q[:80]
                self.detailed_output = q[:2400]
                self._append_log_locked(f"Needs input: {q}")
            elif evt_type in ("result", "done", "complete", "completed", "turn_complete", "final"):
                summary = self._extract_event_text(
                    event,
                    ("summary", "response", "text", "message", "content", "output", "result", "error"),
                ) or self.detailed_output or "Completed"
                first_line = summary.splitlines()[0].strip() if summary else "Completed"
                self.status = "DONE"
                self.thinking_text = first_line[:80]
                self.detailed_output = summary[:2400]
                self._merge_media_items_locked(extract_media_items_from_text(summary))
                self._append_log_locked(f"Done: {first_line[:140]}")
                for s in self.steps:
                    if s["status"] in ("doing", "pending"):
                        s["status"] = "done"
            elif evt_type in ("thinking",):
                thought = self._extract_event_text(event, ("text", "thinking", "content", "message"))
                if thought:
                    self.thinking_text = thought.splitlines()[0][:80]
            elif evt_type in ("status", "assistant", "message", "text", "delta"):
                txt = self._extract_event_text(event, ("text", "response", "content", "message", "output"))
                if txt:
                    self.status = "WORKING"
                    self.thinking_text = txt.splitlines()[0][:80]
                    if len(txt) > len(self.detailed_output) or evt_type in ("assistant", "message"):
                        self.detailed_output = txt[:2400]
                    self._merge_media_items_locked(extract_media_items_from_text(txt))

            return self.to_payload_locked()

    def mark_done(self, summary: str = "Completed") -> Dict[str, Any]:
        with self._lock:
            clean = (summary or self.detailed_output or "Completed").strip()
            self.status = "DONE"
            self.thinking_text = clean.splitlines()[0][:80] if clean else "Completed"
            if clean and not self.detailed_output:
                self.detailed_output = clean[:2400]
            self._merge_media_items_locked(extract_media_items_from_text(self.detailed_output))
            for s in self.steps:
                if s["status"] in ("doing", "pending"):
                    s["status"] = "done"
            return self.to_payload_locked()

    def mark_paused(self) -> Dict[str, Any]:
        with self._lock:
            if self.status == "WORKING":
                self.status = "PAUSED"
                self.thinking_text = "Paused"
            return self.to_payload_locked()

    def mark_resumed(self) -> Dict[str, Any]:
        with self._lock:
            if self.status == "PAUSED":
                self.status = "WORKING"
                self.thinking_text = "Resumed..."
            return self.to_payload_locked()

    def mark_stopped(self, force: bool = False) -> Dict[str, Any]:
        with self._lock:
            self.status = "STOPPED"
            self.thinking_text = "Force-stopped" if force else "Stopped by user"
            return self.to_payload_locked()

    def to_payload(self) -> Dict[str, Any]:
        with self._lock:
            return self.to_payload_locked()

    def to_payload_locked(self) -> Dict[str, Any]:
        payload: Dict[str, Any] = {
            "status": self.status,
            "state": self.status,
            "visible": True,
            "title": self.title,
            "thinkingText": self.thinking_text,
            "currentAction": self.thinking_text,
            "detailedOutput": self.detailed_output,
            "icon": self.icon,
            "appPackage": self.app_package,
            "progressPercent": self.progress_percent,
            "steps": list(self.steps),
            "quickActions": list(self.quick_actions),
            "mediaItems": list(self.media_items),
            "mediaPlaying": self.media_playing,
            "mediaMuted": self.media_muted,
            "logs": list(self.logs),
            "autoHideSeconds": self.auto_collapse_seconds if self.status == "DONE" else 0,
        }
        if self.chess is not None:
            payload["chess"] = dict(self.chess)
        if self.hardware_chip is not None:
            payload["hardwareChip"] = dict(self.hardware_chip)
        return payload


class AgySessionRunner:
    """Manages persistent Termux `agy` CLI process with sticky conversation ID reuse."""

    def __init__(
        self,
        agy_bin: str,
        mode: str,
        on_event,
        on_turn_finished,
        new_conversation: bool = False,
        conversation_id_file: str = CONVERSATION_ID_PATH,
    ) -> None:
        self.agy_bin = agy_bin
        self.requested_mode = mode
        self.conversation_id_file = conversation_id_file
        if new_conversation:
            clear_conversation_id(self.conversation_id_file)
            self.conversation_id = ""
        else:
            self.conversation_id = load_conversation_id(self.conversation_id_file)
        self.resolved_mode = self._detect_mode()
        self.on_event = on_event
        self.on_turn_finished = on_turn_finished
        self._proc: Optional[subprocess.Popen] = None
        self._proc_lock = threading.Lock()
        self._has_started_conversation = bool(self.conversation_id)

    def _detect_mode(self) -> str:
        if self.requested_mode in ("stream", "continue"):
            return self.requested_mode
        try:
            res = subprocess.run([self.agy_bin, "--help"], capture_output=True, text=True, timeout=3.0, check=False)
            help_text = (res.stdout or "") + "\n" + (res.stderr or "")
            if "--input-format" in help_text and "stream-json" in help_text:
                return "stream"
        except Exception:
            pass
        return "continue"

    @staticmethod
    def format_prompt_for_agy(prompt_text: str) -> str:
        stripped = (prompt_text or "").strip()
        if not stripped:
            return ""
        if "127.0.0.1:8080" in stripped or ".aura_token" in stripped:
            return stripped
        return f"{BRIDGE_RUNTIME_PREFIX}{stripped}"

    def build_stream_command(self) -> List[str]:
        cmd = [self.agy_bin, "-p=", "--input-format", "stream-json", "--output-format", "stream-json", "--dangerously-skip-permissions"]
        if self.conversation_id:
            cmd.extend(["--conversation", self.conversation_id])
        elif self._has_started_conversation:
            cmd.append("--continue")
        return cmd

    def build_continue_command(self, formatted_prompt: str) -> List[str]:
        cmd = [self.agy_bin, "--dangerously-skip-permissions"]
        if self.conversation_id:
            cmd.extend(["--conversation", self.conversation_id])
        elif self._has_started_conversation:
            cmd.append("--continue")
        cmd.append(formatted_prompt)
        return cmd

    @staticmethod
    def build_stream_stdin_envelope(formatted_prompt: str) -> Dict[str, Any]:
        return {
            "event": "user",
            "type": "user",
            "content": formatted_prompt,
            "message": {"role": "user", "content": formatted_prompt},
        }

    def _capture_conversation_id(self, evt: Dict[str, Any]) -> None:
        cid = extract_conversation_id(evt)
        if cid and cid != self.conversation_id:
            self.conversation_id = cid
            self._has_started_conversation = True
            save_conversation_id(cid, self.conversation_id_file)

    def send_prompt(self, prompt_text: str) -> None:
        formatted = self.format_prompt_for_agy(prompt_text)
        if self.resolved_mode == "stream" and self._send_prompt_stream_json(formatted):
            return
        self.resolved_mode = "continue"
        self._run_prompt_continue(formatted)

    def _ensure_stream_process(self) -> Optional[subprocess.Popen]:
        with self._proc_lock:
            if self._proc is not None and self._proc.poll() is None:
                return self._proc
            try:
                proc = subprocess.Popen(
                    self.build_stream_command(),
                    stdin=subprocess.PIPE,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT,
                    cwd=os.path.expanduser("~"),
                    text=True,
                    bufsize=1,
                )
                self._proc = proc
                threading.Thread(target=self._read_stream_stdout, args=(proc,), name="agy-stream-stdout", daemon=True).start()
                return proc
            except Exception:
                return None

    def _send_prompt_stream_json(self, formatted_prompt: str) -> bool:
        proc = self._ensure_stream_process()
        if proc is None or proc.stdin is None:
            return False
        try:
            proc.stdin.write(json.dumps(self.build_stream_stdin_envelope(formatted_prompt)) + "\n")
            proc.stdin.flush()
            self._has_started_conversation = True
            return True
        except Exception:
            return False

    def _read_stream_stdout(self, proc: subprocess.Popen) -> None:
        assert proc.stdout is not None
        for raw_line in proc.stdout:
            line = raw_line.strip()
            if not line:
                continue
            evt = self._parse_output_line(line)
            if evt is None:
                continue
            self._capture_conversation_id(evt)
            self.on_event(evt)
        self.on_turn_finished("Stream closed")

    def _run_prompt_continue(self, formatted_prompt: str) -> None:
        try:
            proc = subprocess.Popen(
                self.build_continue_command(formatted_prompt),
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                cwd=os.path.expanduser("~"),
                text=True,
                bufsize=1,
            )
        except Exception as e:
            self.on_event({"type": "done", "summary": f"Launch error: {e}"})
            self.on_turn_finished(str(e))
            return
        with self._proc_lock:
            self._proc = proc
        self._has_started_conversation = True
        last_line = "Completed"
        assert proc.stdout is not None
        for raw_line in proc.stdout:
            line = raw_line.strip()
            if not line:
                continue
            evt = self._parse_output_line(line)
            if evt is None:
                continue
            clean_last = HudStateTracker._extract_event_text(
                evt, ("summary", "response", "text", "message", "content", "output", "result")
            )
            last_line = clean_last or line
            self._capture_conversation_id(evt)
            self.on_event(evt)
        proc.wait()
        self.on_turn_finished(last_line[:80])

    def stop_active(self, force: bool = False) -> None:
        with self._proc_lock:
            proc = self._proc
        if proc is not None and proc.poll() is None:
            try:
                if force:
                    proc.kill()
                else:
                    if hasattr(signal, "SIGCONT"):
                        try:
                            proc.send_signal(signal.SIGCONT)
                        except Exception:
                            pass
                    proc.send_signal(signal.SIGINT)
            except Exception:
                pass

    def pause_active(self) -> None:
        with self._proc_lock:
            proc = self._proc
        if proc is not None and proc.poll() is None and hasattr(signal, "SIGSTOP"):
            try:
                proc.send_signal(signal.SIGSTOP)
            except Exception:
                pass

    def resume_active(self) -> None:
        with self._proc_lock:
            proc = self._proc
        if proc is not None and proc.poll() is None and hasattr(signal, "SIGCONT"):
            try:
                proc.send_signal(signal.SIGCONT)
            except Exception:
                pass

    @staticmethod
    def _is_ignorable_noise_line(line: str) -> bool:
        low = line.lower()
        return "error: logging before google.init:" in low or "server_zerog.go:" in low

    @classmethod
    def _parse_output_line(cls, line: str) -> Optional[Dict[str, Any]]:
        if cls._is_ignorable_noise_line(line):
            return None
        if line.startswith("{") and line.endswith("}"):
            try:
                parsed = json.loads(line)
                if isinstance(parsed, dict):
                    return parsed
            except Exception:
                pass
        return {"type": "status", "text": line}


class AgyHudDaemon:
    """Orchestrates Single-Window HUD v2 WS/HTTP commands, Agy CLI, and Chess Autopilot."""

    def __init__(
        self,
        base_url: str,
        token: str,
        agy_bin: str = "agy",
        mode: str = "auto",
        poll_interval: float = 0.75,
        auto_collapse_seconds: int = 4,
        new_conversation: bool = False,
        safe_guard: bool = False,
    ) -> None:
        self.client = KavachHudClient(base_url, token)
        self.tracker = HudStateTracker(auto_collapse_seconds=auto_collapse_seconds)
        self.poll_interval = poll_interval
        self.safe_guard = bool(safe_guard)
        self.stop_event = threading.Event()
        self.command_queue: "queue.Queue[Dict[str, Any]]" = queue.Queue()
        self._seen_cmd_ids: List[str] = []
        self._seen_lock = threading.Lock()
        self._approval_lock = threading.Lock()
        self._pending_approvals: Dict[str, Tuple[threading.Event, Dict[str, Any]]] = {}
        self._chess_lock = threading.Lock()
        self._chess_stop_event = threading.Event()
        self._chess_pause_event = threading.Event()
        self._chess_thread: Optional[threading.Thread] = None

        self.runner = AgySessionRunner(
            agy_bin=agy_bin,
            mode=mode,
            on_event=self._handle_agy_event,
            on_turn_finished=self._handle_turn_finished,
            new_conversation=new_conversation,
        )
        self.ws_listener = StdlibWebSocketListener(
            base_http_url=base_url,
            token=token,
            on_message=self._handle_ws_message,
            stop_event=self.stop_event,
        )

    def _enqueue_unique_command(self, cmd: Dict[str, Any]) -> bool:
        if cmd.get("type") != "HUD_COMMAND":
            return False
        cmd_id = str(cmd.get("id") or f"{cmd.get('timestamp')}:{cmd.get('action')}:{cmd.get('text')}")
        with self._seen_lock:
            if cmd_id in self._seen_cmd_ids:
                return False
            self._seen_cmd_ids.append(cmd_id)
            if len(self._seen_cmd_ids) > 256:
                self._seen_cmd_ids = self._seen_cmd_ids[-128:]
        action = str(cmd.get("action") or "PROMPT").upper()
        if action == "APPROVAL_RESPONSE":
            self._resolve_approval_response(cmd)
            return True
        if action in ("STOP", "FORCE_STOP", "PAUSE", "RESUME"):
            self._handle_control_command(action)
            return True
        self.command_queue.put(cmd)
        return True

    def _resolve_approval_response(self, cmd: Dict[str, Any]) -> bool:
        payload = cmd.get("payload") if isinstance(cmd.get("payload"), dict) else {}
        approval_id = str(payload.get("approvalId") or cmd.get("buttonId") or "").strip()
        decision = str(payload.get("decision") or "deny").lower().strip()
        edited_text = str(payload.get("editedText") or "").strip()
        with self._approval_lock:
            entry = self._pending_approvals.get(approval_id)
            if entry is None and len(self._pending_approvals) == 1:
                approval_id = next(iter(self._pending_approvals.keys()))
                entry = self._pending_approvals.get(approval_id)
            if entry is None:
                return False
            evt, box = entry
            box["approvalId"] = approval_id
            box["decision"] = decision if decision in ("approve", "edit", "deny") else "deny"
            if edited_text:
                box["editedText"] = edited_text
            evt.set()
            return True

    def request_approval(
        self,
        title: str,
        description: str = "",
        command_preview: str = "",
        risk_level: str = "medium",
        allow_edit: bool = True,
        timeout_seconds: float = 30.0,
        approval_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        aid = (approval_id or f"apr_{uuid.uuid4().hex[:8]}").strip()
        evt = threading.Event()
        box: Dict[str, Any] = {"approvalId": aid, "decision": "deny", "timedOut": False}
        with self._approval_lock:
            self._pending_approvals[aid] = (evt, box)
        try:
            self.client.push_approval(aid, title, description, command_preview, risk_level, allow_edit, int(round(timeout_seconds)))
            if not evt.wait(timeout=max(0.05, float(timeout_seconds))):
                box["decision"] = "deny"
                box["timedOut"] = True
                self.client.clear_approval()
            return dict(box)
        finally:
            with self._approval_lock:
                self._pending_approvals.pop(aid, None)

    def _stop_chess_autopilot(self, wait_timeout: float = 0.6) -> None:
        with self._chess_lock:
            th = self._chess_thread
            self._chess_stop_event.set()
            self._chess_pause_event.clear()
        if th is not None and th.is_alive() and th is not threading.current_thread():
            th.join(timeout=wait_timeout)

    @staticmethod
    def _classify_chess_command(prompt_text: str, has_chess_context: bool = False) -> Optional[str]:
        low = re.sub(r"\s+", " ", (prompt_text or "").strip().lower())
        if not low:
            return None
        if any(k in low for k in ("chess autopilot", "autopilot chess", "auto play chess", "autoplay chess", "play chess for me", "chess play", "chess-ai play")):
            return "one_move" if ("one move" in low or "single move" in low or "next move" in low) else "play"
        if low in ("auto play", "autoplay") and has_chess_context:
            return "play"
        if low in ("play 1 move", "chess play one move", "make best move") or ("make the best move" in low and ("chess" in low or has_chess_context)):
            return "one_move"
        if any(
            k in low
            for k in (
                "analyze the visible chess position",
                "check what opponent threats or tactics exist in the current chess board",
                "evaluate who is better in this chess position",
                "best chess move",
                "chess best move",
                "chess suggest",
                "chess status",
                "chess eval",
            )
        ):
            return "analyze"
        if has_chess_context and low in ("best move", "threats", "eval", "suggest"):
            return "analyze"
        return None

    def _dispatch_chess_command(self, cmd_kind: str, display_prompt: str) -> bool:
        ca = _load_chess_autopilot()
        if ca is None:
            return False
        ca.set_bridge_target(url=self.client.base_url, token=self.client.token)
        self._stop_chess_autopilot(wait_timeout=0.5)

        if cmd_kind == "analyze":
            self.client.push_hud_state(self.tracker.begin_prompt(display_prompt or "Chess Analysis"))
            try:
                res = ca.analyze_screen_position(depth=18, multipv=3, time_limit=0.35)
                if not res.get("success"):
                    self.client.push_hud_state(self.tracker.mark_done(res.get("error") or "No chess board visible"))
                    return True
                var_lines = [
                    f"{idx}. {v['san']} ({v['uci']}) · {v['evalCp']}" + (f" | {', '.join(v['motifs'])}" if v.get("motifs") else "")
                    for idx, v in enumerate(res.get("variations") or [], 1)
                ]
                payload = self.tracker.apply_chess_payload(
                    {
                        "state": "DONE",
                        "title": f"Chess · {res['playerColor'].title()} ({res['evalCp']})",
                        "thinkingText": f"Best: {res.get('bestSan') or '-'} ({res['evalCp']})",
                        "detailedOutput": f"Eval: {res['evalCp']} ({res['winProb']}% win)\n" + "\n".join(var_lines),
                        "chess": res.get("taskMap", {}).get("chess"),
                        "outputLogs": [f"Best move: {res.get('bestSan')} ({res['evalCp']})"],
                    }
                )
                self.client.push_hud_state(payload)
            except Exception as exc:
                self.client.push_hud_state(self.tracker.mark_done(f"Chess analysis error: {exc}"))
            return True

        max_moves = 1 if cmd_kind == "one_move" else 120
        self.client.push_hud_state(self.tracker.begin_prompt("Chess · 1 Move" if max_moves == 1 else "Chess Autopilot"))
        with self._chess_lock:
            self._chess_stop_event = threading.Event()
            self._chess_pause_event = threading.Event()
            stop_ev, pause_ev = self._chess_stop_event, self._chess_pause_event

        def _on_hud_update(cpayload: Dict[str, Any]) -> None:
            self.client.push_hud_state(self.tracker.apply_chess_payload(cpayload))

        def _run() -> None:
            try:
                trainer = ca.NeuralTrainer()
                ca.play_game(
                    depth=18,
                    hunt_brilliant=True,
                    max_moves=max_moves,
                    trainer=trainer,
                    enable_ponder=False,
                    stop_event=stop_ev,
                    pause_event=pause_ev,
                    hud_callback=_on_hud_update,
                    push_hud=False,
                    quiet=True,
                )
            except Exception as exc:
                if self.tracker.status not in ("DONE", "STOPPED"):
                    self.client.push_hud_state(self.tracker.mark_done(f"Chess error: {exc}"))

        th = threading.Thread(target=_run, name="agy-chess-autopilot", daemon=True)
        with self._chess_lock:
            self._chess_thread = th
        th.start()
        return True

    def _handle_control_command(self, action: str) -> None:
        if action in ("STOP", "FORCE_STOP"):
            force = action == "FORCE_STOP"
            with self._approval_lock:
                for aid, (evt, box) in list(self._pending_approvals.items()):
                    box.update({"approvalId": aid, "decision": "deny", "cancelled": True})
                    evt.set()
                self._pending_approvals.clear()
            self._stop_chess_autopilot(wait_timeout=0.4 if force else 0.1)
            self.runner.stop_active(force=force)
            self.client.push_hud_state(self.tracker.mark_stopped(force=force))
        elif action == "PAUSE":
            self._chess_pause_event.set()
            self.runner.pause_active()
            self.client.push_hud_state(self.tracker.mark_paused())
        elif action == "RESUME":
            self._chess_pause_event.clear()
            self.runner.resume_active()
            self.client.push_hud_state(self.tracker.mark_resumed())

    def _handle_ws_message(self, msg: Dict[str, Any]) -> None:
        self._enqueue_unique_command(msg)

    def _handle_agy_event(self, evt: Dict[str, Any]) -> None:
        self.client.push_hud_state(self.tracker.apply_agy_event(evt))

    def _handle_turn_finished(self, summary: str) -> None:
        if self.tracker.status not in ("DONE", "IDLE", "STOPPED"):
            self.client.push_hud_state(self.tracker.mark_done(summary))

    def _poll_loop(self) -> None:
        while not self.stop_event.is_set():
            wait_s = self.poll_interval * 2.5 if self.ws_listener.connected else self.poll_interval
            res = self.client.poll_hud_commands()
            if res.get("success") and isinstance(res.get("commands"), list):
                for cmd in res["commands"]:
                    if isinstance(cmd, dict):
                        self._enqueue_unique_command(cmd)
            self.stop_event.wait(wait_s)

    def _worker_loop(self) -> None:
        while not self.stop_event.is_set():
            try:
                cmd = self.command_queue.get(timeout=0.5)
            except queue.Empty:
                continue
            action = str(cmd.get("action") or "PROMPT").upper()
            text = str(cmd.get("text") or "").strip()
            cmd_payload = cmd.get("payload") if isinstance(cmd.get("payload"), dict) else None
            if action in ("STOP", "FORCE_STOP", "PAUSE", "RESUME"):
                self._handle_control_command(action)
                continue
            enriched = format_region_context_for_prompt(text, cmd_payload, action=action)
            if not enriched:
                continue
            display_prompt = text or enriched.splitlines()[0][:80]
            if self.safe_guard:
                risk = detect_sensitive_prompt_risk(display_prompt)
                if risk is not None:
                    dec = self.request_approval(
                        title=risk["title"],
                        description=risk["description"],
                        command_preview=risk["commandPreview"],
                        risk_level=risk["riskLevel"],
                    )
                    if dec.get("decision") == "deny":
                        self.client.push_hud_state(self.tracker.mark_stopped(force=False))
                        continue
                    if dec.get("decision") == "edit" and dec.get("editedText"):
                        display_prompt = str(dec["editedText"]).strip()
                        enriched = format_region_context_for_prompt(display_prompt, cmd_payload, action=action)

            has_chess_ctx = self.tracker.chess is not None or self.tracker.icon == "chess" or "chess" in (self.tracker.app_package or "")
            chess_cmd = self._classify_chess_command(display_prompt, has_chess_context=has_chess_ctx)
            if chess_cmd and self._dispatch_chess_command(chess_cmd, display_prompt):
                continue

            self._stop_chess_autopilot(wait_timeout=0.3)
            self.client.push_hud_state(self.tracker.begin_prompt(display_prompt))
            self.runner.send_prompt(enriched)

    def run(self) -> None:
        print(f"[AgyHudDaemon v2] target={self.client.base_url} | agy_mode={self.runner.resolved_mode}", flush=True)
        self.client.push_hud_state(self.tracker.to_payload())
        self.ws_listener.start()
        threading.Thread(target=self._poll_loop, name="agy-hud-poll", daemon=True).start()
        threading.Thread(target=self._worker_loop, name="agy-worker", daemon=True).start()
        try:
            while not self.stop_event.is_set():
                time.sleep(0.5)
        except KeyboardInterrupt:
            print("\n[AgyHudDaemon v2] Shutting down...", flush=True)
        finally:
            self.stop_event.set()
            self._stop_chess_autopilot(wait_timeout=0.5)
            self.ws_listener.stop()
            self.runner.stop_active()
            ca_mod = _CHESS_AUTOPILOT_CACHE.get("mod")
            if ca_mod is not None:
                ca_mod.cleanup_engine()
            self.client.hide_hud()


def run_self_test() -> int:
    from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

    state_history: List[Dict[str, Any]] = []
    approval_history: List[Dict[str, Any]] = []
    test_token = "self_test_token"

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, format: str, *args: Any) -> None:
            return

        def _send_json(self, code: int, obj: Dict[str, Any]) -> None:
            raw = json.dumps(obj).encode("utf-8")
            self.send_response(code)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(raw)))
            self.end_headers()
            self.wfile.write(raw)

        def do_GET(self) -> None:
            if self.path.startswith("/api/hud/poll"):
                self._send_json(200, {"success": True, "commands": []})
            else:
                self._send_json(404, {"success": False})

        def do_POST(self) -> None:
            ln = int(self.headers.get("Content-Length") or 0)
            body = json.loads(self.rfile.read(ln).decode("utf-8")) if ln > 0 else {}
            if self.path == "/api/hud/state":
                state_history.append(body)
                self._send_json(200, {"success": True, "state": body.get("status")})
            elif self.path == "/api/hud/approval":
                approval_history.append(body)
                self._send_json(200, {"success": True, "approvalActive": bool(body.get("active", True))})
            elif self.path == "/api/hud/hide":
                self._send_json(200, {"success": True})
            else:
                self._send_json(404, {"success": False})

    srv = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    base_url = f"http://127.0.0.1:{srv.server_address[1]}"
    client = KavachHudClient(base_url, test_token)

    tracker = HudStateTracker(auto_collapse_seconds=4)
    tracker.begin_prompt("hi")
    res = tracker.apply_agy_event({"type": "result", "result": {"conversation_id": "abc", "status": "SUCCESS", "response": "Hello!"}})
    assert res["status"] == "DONE" and res["detailedOutput"] == "Hello!"
    client.push_hud_state(res)
    assert len(state_history) == 1

    daemon = AgyHudDaemon(base_url=base_url, token=test_token, safe_guard=True)
    threading.Thread(
        target=lambda: (time.sleep(0.05), daemon._enqueue_unique_command({"id": "c1", "type": "HUD_COMMAND", "action": "APPROVAL_RESPONSE", "buttonId": "a1", "payload": {"approvalId": "a1", "decision": "approve"}})),
        daemon=True,
    ).start()
    out = daemon.request_approval("Test", command_preview="rm -rf /tmp/x", approval_id="a1", timeout_seconds=2.0)
    assert out["decision"] == "approve" and len(approval_history) == 1
    srv.shutdown()
    srv.server_close()
    print("SELF-TEST PASSED: Single-Window HUD v2 protocol verified.")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description="Single-Window KaVach HUD v2 Daemon")
    parser.add_argument("--url", default=resolve_default_url(), help="KaVach HTTP base URL")
    parser.add_argument("--token", default=None, help="Bearer token")
    parser.add_argument("--agy-bin", default="agy", help="agy CLI path")
    parser.add_argument("--mode", choices=("auto", "stream", "continue"), default="auto")
    parser.add_argument("--poll-interval", type=float, default=0.75)
    parser.add_argument("--auto-collapse", type=int, default=4)
    parser.add_argument("--new", action="store_true", help="Clear saved conversation ID")
    parser.add_argument("--safe-guard", action="store_true", help="Require HUD approval for risky prompts")
    parser.add_argument("--self-test", action="store_true")
    args = parser.parse_args()

    if args.self_test:
        return run_self_test()

    AgyHudDaemon(
        base_url=args.url,
        token=load_auth_token(args.token),
        agy_bin=args.agy_bin,
        mode=args.mode,
        poll_interval=args.poll_interval,
        auto_collapse_seconds=args.auto_collapse,
        new_conversation=args.new,
        safe_guard=args.safe_guard,
    ).run()
    return 0


if __name__ == "__main__":
    sys.exit(main())
