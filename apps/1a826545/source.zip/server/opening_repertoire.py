#!/usr/bin/env python3
"""
Grandmaster Opening Repertoire & ECO Database
Provides instant (0ms) opening moves for White and Black with sharp tactical lines
and classic sacrifice setups (Italian / Fried Liver / Evans Gambit / Greek Gift / Open Sicilian).
"""

import chess

# Key opening lines mapped by UCI move sequence
OPENING_TREE = {
    # ---------------------------------------------------------
    # 1. e4 (King's Pawn Opening)
    # ---------------------------------------------------------
    "": [("e2e4", "King's Pawn Opening (1. e4)", "B00")],

    # 1. e4 e5 (Open Game) -> Italian Game / Giuoco Piano / Fried Liver
    "e2e4 e7e5": [("g1f3", "King's Knight (2. Nf3)", "C40")],
    "e2e4 e7e5 g1f3 b8c6": [("f1c4", "Italian Game (3. Bc4)", "C50")],
    "e2e4 e7e5 g1f3 d7d6": [("d2d4", "Philidor Defense (3. d4)", "C41")],
    "e2e4 e7e5 g1f3 g8f6": [("f3e5", "Petrov Defense (3. Nxe5)", "C42")],

    # Italian Game vs 3... Bc5 (Giuoco Piano / Evans Gambit)
    "e2e4 e7e5 g1f3 b8c6 f1c4 f8c5": [
        ("b2b4", "Evans Gambit (4. b4!!) - Sharp Classical Pawn Sacrifice", "C51"),
        ("c2c3", "Giuoco Piano Mainline (4. c3)", "C53")
    ],
    # Evans Gambit Accepted: 4... Bxb4 5. c3 Ba5 6. d4
    "e2e4 e7e5 g1f3 b8c6 f1c4 f8c5 b2b4 c5b4": [("c2c3", "Evans Gambit: 5. c3", "C51")],
    "e2e4 e7e5 g1f3 b8c6 f1c4 f8c5 b2b4 c5b4 c2c3 b4a5": [("d2d4", "Evans Gambit: 6. d4! Central Break", "C52")],
    "e2e4 e7e5 g1f3 b8c6 f1c4 f8c5 b2b4 c5b4 c2c3 b4c5": [("d2d4", "Evans Gambit: 6. d4!", "C52")],

    # Giuoco Piano 4. c3 Nf6 5. d4 exd4 6. cxd4 Bb4+ 7. Nc3 (Möller Attack Sacrifice)
    "e2e4 e7e5 g1f3 b8c6 f1c4 f8c5 c2c3 g8f6": [("d2d4", "Giuoco Piano: 5. d4 Central Clash", "C54")],
    "e2e4 e7e5 g1f3 b8c6 f1c4 f8c5 c2c3 g8f6 d2d4 e5d4": [("c3d4", "Giuoco Piano: 6. cxd4", "C54")],
    "e2e4 e7e5 g1f3 b8c6 f1c4 f8c5 c2c3 g8f6 d2d4 e5d4 c3d4 c5b4": [("b1c3", "Möller Attack (7. Nc3!) - Sound Piece Sacrifice Line", "C54")],

    # Italian Game vs 3... Nf6 (Two Knights Defense -> Fried Liver Attack)
    "e2e4 e7e5 g1f3 b8c6 f1c4 g8f6": [("f3g5", "Two Knights Defense: 4. Ng5 (Knight Attack)", "C57")],
    "e2e4 e7e5 g1f3 b8c6 f1c4 g8f6 f3g5 d7d5": [("e4d5", "Two Knights: 5. exd5", "C57")],
    # Fried Liver Attack: 5... Nxd5 6. Nxf7!! (Official Brilliant Sacrifice)
    "e2e4 e7e5 g1f3 b8c6 f1c4 g8f6 f3g5 d7d5 e4d5 f6d5": [
        ("g5f7", "Fried Liver Attack (6. Nxf7!!) - Devastating King Sacrifice", "C57")
    ],
    # 5... Na5 6. Bb5+ c6 7. dxc6 bxc6 8. Bd3! (Polerio Defense Mainline)
    "e2e4 e7e5 g1f3 b8c6 f1c4 g8f6 f3g5 d7d5 e4d5 c6a5": [("c4b5", "Two Knights: 6. Bb5+ (Polerio Defense)", "C58")],
    "e2e4 e7e5 g1f3 b8c6 f1c4 g8f6 f3g5 d7d5 e4d5 c6a5 c4b5 c7c6": [("d5c6", "Two Knights: 7. dxc6", "C58")],
    "e2e4 e7e5 g1f3 b8c6 f1c4 g8f6 f3g5 d7d5 e4d5 c6a5 c4b5 c7c6 d5c6 b7c6": [("b5d3", "Two Knights: 8. Bd3! Mainline", "C58")],

    # ---------------------------------------------------------
    # 1. e4 c5 (Sicilian Defense) -> Open Sicilian
    # ---------------------------------------------------------
    "e2e4 c7c5": [("g1f3", "Sicilian Defense: 2. Nf3", "B20")],
    "e2e4 c7c5 g1f3 d7d6": [("d2d4", "Open Sicilian: 3. d4", "B50")],
    "e2e4 c7c5 g1f3 d7d6 d2d4 c5d4": [("f3d4", "Open Sicilian: 4. Nxd4", "B50")],
    "e2e4 c7c5 g1f3 d7d6 d2d4 c5d4 f3d4 g8f6": [("b1c3", "Open Sicilian: 5. Nc3", "B50")],
    # Najdorf: 5... a6 6. Bg5! (Aggressive Attack)
    "e2e4 c7c5 g1f3 d7d6 d2d4 c5d4 f3d4 g8f6 b1c3 a7a6": [("c1g5", "Sicilian Najdorf: 6. Bg5! (Classical Attack)", "B95")],
    # Classical: 5... Nc6 6. Bg5!
    "e2e4 c7c5 g1f3 d7d6 d2d4 c5d4 f3d4 g8f6 b1c3 b8c6": [("c1g5", "Sicilian Richter-Rauzer: 6. Bg5!", "B60")],
    # Dragon: 5... g6 6. Be3
    "e2e4 c7c5 g1f3 d7d6 d2d4 c5d4 f3d4 g8f6 b1c3 g7g6": [("c1e3", "Sicilian Dragon: 6. Be3 (Yugoslav Attack Setup)", "B75")],
    # Sicilian vs 2... e6 (Kan / Taimanov / Pin)
    "e2e4 c7c5 g1f3 e7e6": [("d2d4", "Open Sicilian: 3. d4", "B40")],
    "e2e4 c7c5 g1f3 e7e6 d2d4 c5d4": [("f3d4", "Open Sicilian: 4. Nxd4", "B40")],
    "e2e4 c7c5 g1f3 e7e6 d2d4 c5d4 f3d4 b8c6": [("b1c3", "Sicilian Taimanov: 5. Nc3", "B44")],
    # Sicilian vs 2... Nc6
    "e2e4 c7c5 g1f3 b8c6": [("d2d4", "Open Sicilian: 3. d4", "B30")],
    "e2e4 c7c5 g1f3 b8c6 d2d4 c5d4": [("f3d4", "Open Sicilian: 4. Nxd4", "B30")],

    # ---------------------------------------------------------
    # 1. e4 e6 (French Defense)
    # ---------------------------------------------------------
    "e2e4 e7e6": [("d2d4", "French Defense: 2. d4", "C00")],
    "e2e4 e7e6 d2d4 d7d5": [("b1c3", "French Defense: 3. Nc3 (Paulsen Classical)", "C10")],
    "e2e4 e7e6 d2d4 d7d5 b1c3 g8f6": [("c1g5", "French Classical: 4. Bg5", "C11")],
    "e2e4 e7e6 d2d4 d7d5 b1c3 f8b4": [("e4e5", "French Winawer: 4. e5", "C15")],
    "e2e4 e7e6 d2d4 d7d5 b1c3 d5e4": [("c3e4", "French Rubinstein: 4. Nxe4", "C10")],

    # ---------------------------------------------------------
    # 1. e4 c6 (Caro-Kann Defense)
    # ---------------------------------------------------------
    "e2e4 c7c6": [("d2d4", "Caro-Kann: 2. d4", "B12")],
    "e2e4 c7c6 d2d4 d7d5": [("b1c3", "Caro-Kann: 3. Nc3 (Classical)", "B18")],
    "e2e4 c7c6 d2d4 d7d5 b1c3 d5e4": [("c3e4", "Caro-Kann: 4. Nxe4", "B18")],
    "e2e4 c7c6 d2d4 d7d5 b1c3 d5e4 c3e4 c8f5": [("e4g3", "Caro-Kann: 5. Ng3 Bg6 6. h4", "B18")],
    "e2e4 c7c6 d2d4 d7d5 b1c3 d5e4 c3e4 b8d7": [("e4g5", "Caro-Kann: 5. Ng5! (Kasparov Attack Setup)", "B17")],

    # ---------------------------------------------------------
    # 1. e4 d6 / 1. e4 g6 (Pirc / Modern Defense)
    # ---------------------------------------------------------
    "e2e4 d7d6": [("d2d4", "Pirc Defense: 2. d4", "B07")],
    "e2e4 d7d6 d2d4 g8f6": [("b1c3", "Pirc Defense: 3. Nc3", "B07")],
    "e2e4 d7d6 d2d4 g8f6 b1c3 g7g6": [("f2f4", "Pirc Austrian Attack: 4. f4! (Decisive King Attack)", "B09")],
    "e2e4 g7g6": [("d2d4", "Modern Defense: 2. d4", "B06")],
    "e2e4 g7g6 d2d4 f8g7": [("b1c3", "Modern Defense: 3. Nc3", "B06")],

    # ---------------------------------------------------------
    # 1. e4 d5 (Scandinavian Defense)
    # ---------------------------------------------------------
    "e2e4 d7d5": [("e4d5", "Scandinavian Defense: 2. exd5", "B01")],
    "e2e4 d7d5 e4d5 d8d5": [("b1c3", "Scandinavian: 3. Nc3 Qa5 (Sharp Center Attack)", "B01")],
    "e2e4 d7d5 e4d5 g8f6": [("d2d4", "Scandinavian: 2... Nf6 3. d4 Modern Line", "B01")],

    # ---------------------------------------------------------
    # 1. d4 (Queen's Pawn Opening)
    # ---------------------------------------------------------
    "d2d4 d7d5": [("c2c4", "Queen's Gambit (2. c4)", "D06")],
    "d2d4 d7d5 c2c4 e7e6": [("b1c3", "Queen's Gambit Declined: 3. Nc3", "D30")],
    "d2d4 d7d5 c2c4 c7c6": [("g1f3", "Slav Defense: 3. Nf3", "D10")],
    "d2d4 g8f6": [("c2c4", "Indian Defense: 2. c4", "A45")],
    "d2d4 g8f6 c2c4 g7g6": [("b1c3", "King's Indian / Grünfeld: 3. Nc3", "E60")],
    "d2d4 g8f6 c2c4 e7e6": [("b1c3", "Nimzo-Indian Defense: 3. Nc3", "E20")],

    # ---------------------------------------------------------
    # Black Repertoires (When engine plays Black)
    # ---------------------------------------------------------
    "e2e4": [("c7c5", "Sicilian Defense (1... c5)", "B20")],
    "d2d4": [("g8f6", "Indian Defense (1... Nf6)", "A45")],
    "c2c4": [("e7e5", "English Opening: King's English (1... e5)", "A20")],
    "g1f3": [("d7d5", "Réti Opening: 1... d5", "A04")],
}

def get_book_move(move_history_uci_list):
    """
    Look up move in opening tree.
    Returns: (chess.Move or None, description_str, eco_code)
    """
    key = " ".join(move_history_uci_list).strip()
    candidates = OPENING_TREE.get(key)
    if candidates:
        uci, desc, eco = candidates[0]
        return chess.Move.from_uci(uci), desc, eco
    return None, None, None
