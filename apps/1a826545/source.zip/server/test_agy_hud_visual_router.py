import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(__file__))
import agy_hud_daemon as daemon


class SingleWindowHudV2Tests(unittest.TestCase):
    def test_plain_text_emits_no_media_or_chess_widgets(self):
        tracker = daemon.HudStateTracker(auto_collapse_seconds=4)
        begin_payload = tracker.begin_prompt("Summarize SOLID principles")
        self.assertEqual(begin_payload["status"], "WORKING")
        self.assertEqual(begin_payload["mediaItems"], [])
        self.assertNotIn("chess", begin_payload)

        msg_payload = tracker.apply_agy_event(
            {"type": "assistant", "text": "Single responsibility keeps classes modular and testable."}
        )
        self.assertEqual(msg_payload["mediaItems"], [])
        done_payload = tracker.mark_done("Summary ready")
        self.assertEqual(done_payload["status"], "DONE")
        self.assertEqual(done_payload["autoHideSeconds"], 4)

    def test_media_and_carousel_extraction_from_assistant_response(self):
        tracker = daemon.HudStateTracker(auto_collapse_seconds=4)
        tracker.begin_prompt("show visuals")
        tracker.apply_agy_event(
            {
                "type": "assistant",
                "text": (
                    "Here are the visuals: "
                    "![Shot](https://example.org/shot.png) "
                    "Clip: https://www.youtube.com/watch?v=jfKfPfyJRdk "
                    "Track: https://example.org/song.mp3"
                ),
            }
        )
        done = tracker.mark_done("Ready")
        kinds = [m["kind"] for m in done["mediaItems"]]
        self.assertEqual(kinds, ["image", "video", "audio"])

    def test_result_dict_unwraps_response_and_ignores_glog_noise(self):
        tracker = daemon.HudStateTracker(auto_collapse_seconds=4)
        tracker.begin_prompt("hi")
        nested_payload = tracker.apply_agy_event(
            {
                "type": "result",
                "result": {
                    "conversation_id": "80670a40-b7c0-4dd3-a71c-833cdb6914c7",
                    "status": "SUCCESS",
                    "response": "Hi again! Everything's ready—let me know what you need help with.\n",
                    "usage": {"total_tokens": 12533},
                },
            }
        )
        expected = "Hi again! Everything's ready—let me know what you need help with."
        self.assertEqual(nested_payload["status"], "DONE")
        self.assertEqual(nested_payload["detailedOutput"], expected)
        self.assertEqual(nested_payload["thinkingText"], expected)
        self.assertNotIn("conversation_id", nested_payload["detailedOutput"])

        self.assertIsNone(
            daemon.AgySessionRunner._parse_output_line(
                "ERROR: logging before google.Init: I1127 21:58:09.846275 1 server_zerog.go:46] Initialized Android local timezone to Asia/Kolkata"
            )
        )

    def test_chess_intent_classification_and_payload_merge(self):
        classify = daemon.AgyHudDaemon._classify_chess_command
        self.assertEqual(classify("chess autopilot play"), "play")
        self.assertEqual(classify("Auto Play", has_chess_context=True), "play")
        self.assertEqual(classify("chess play one move"), "one_move")
        self.assertEqual(classify("Best Move", has_chess_context=True), "analyze")
        self.assertEqual(classify("Check what opponent threats or tactics exist in the current chess board"), "analyze")
        self.assertIsNone(classify("Summarize SOLID principles"))

        tracker = daemon.HudStateTracker(auto_collapse_seconds=4)
        tracker.begin_prompt("Chess Autopilot")
        merged = tracker.apply_chess_payload(
            {
                "status": "DONE",
                "title": "Chess Autopilot · White",
                "thinkingText": "Played Nf3 (+0.3)",
                "detailedOutput": "Move 1: Nf3 (g1->f3)",
                "chess": {
                    "fen": "rnbqkbnr/pppppppp/8/8/8/5N2/PPPPPPPP/RNBQKB1R",
                    "playerColor": "white",
                    "evalCp": "+0.3",
                    "lastMove": {"from": "g1", "to": "f3"},
                },
            }
        )
        self.assertEqual(merged["icon"], "chess")
        self.assertEqual(merged["appPackage"], "com.chess")
        self.assertEqual(merged["chess"]["evalCp"], "+0.3")


if __name__ == "__main__":
    unittest.main()
