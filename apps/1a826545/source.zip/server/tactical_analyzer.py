#!/usr/bin/env python3
"""
Tactical Analyzer & Chess.com Move Classification Engine
Calculates:
- Precise Material Balance & Static Exchange Evaluation (SEE)
- Official Chess.com Brilliant Move (!!) Classification
- Great Move (!) Unique Resource Classification
- Tactical Motif Detection (Royal Forks, Pins, Mating Nets, Greek Gift)
- Logistic Win Probability Formula
"""

import math
import chess

PIECE_VALUES = {
    chess.PAWN: 100,
    chess.KNIGHT: 320,
    chess.BISHOP: 330,
    chess.ROOK: 500,
    chess.QUEEN: 900,
    chess.KING: 20000
}

def get_material_count(board, color):
    """Calculate total static material points for a color."""
    total = 0
    for pt, val in PIECE_VALUES.items():
        if pt == chess.KING:
            continue
        total += len(board.pieces(pt, color)) * val
    return total

def win_probability(centipawns):
    """
    Official Chess.com / Lichess win probability function.
    Maps centipawn eval into a percentage [0.0% - 100.0%].
    """
    if centipawns is None:
        return 50.0
    cp = max(-3000, min(3000, centipawns))
    prob = 1.0 / (1.0 + math.exp(-0.00368208 * cp))
    return round(prob * 100.0, 1)

def is_piece_hanging_or_sacrificed(board, move):
    """
    Determines if `move` is a genuine tactical piece sacrifice:
    1. Piece enters a square where enemy can capture it with lower/equal value or undefended.
    2. Piece moves away and leaves another friendly piece undefended (discovered sacrifice).
    """
    piece = board.piece_at(move.from_square)
    if not piece or piece.piece_type in (chess.PAWN, chess.KING):
        return False, None

    val_map = {chess.KNIGHT: 320, chess.BISHOP: 330, chess.ROOK: 500, chess.QUEEN: 900}
    moving_val = val_map.get(piece.piece_type, 0)
    dest_piece = board.piece_at(move.to_square)
    dest_val = val_map.get(dest_piece.piece_type, 100) if dest_piece else 0

    cloned = board.copy()
    cloned.push(move)
    opp = cloned.turn
    my_color = not opp

    # 1. Direct sacrifice on destination square
    for opp_move in cloned.legal_moves:
        if opp_move.to_square == move.to_square:
            opp_taker = cloned.piece_at(opp_move.from_square)
            if not opp_taker:
                continue
            opp_taker_val = val_map.get(opp_taker.piece_type, 100 if opp_taker.piece_type == chess.PAWN else 20000)
            # If taken by piece of lesser value
            if opp_taker_val <= moving_val and (moving_val - dest_val) >= 150:
                return True, f"{piece.symbol().upper()} sacrifice on {chess.square_name(move.to_square)} (takers available: {opp_taker.symbol().upper()})"
            # Or if destination square is undefended by our side
            if not cloned.is_attacked_by(my_color, move.to_square) and (moving_val - dest_val) >= 200:
                return True, f"Undefended {piece.symbol().upper()} sacrifice on {chess.square_name(move.to_square)}"

    # 2. Discovered sacrifice (leaves another piece hanging)
    for pt in [chess.QUEEN, chess.ROOK, chess.BISHOP, chess.KNIGHT]:
        for sq in cloned.pieces(pt, my_color):
            if sq == move.to_square:
                continue
            # Was this square attacked by opponent before?
            orig_atk = board.is_attacked_by(opp, sq)
            orig_def = board.is_attacked_by(my_color, sq)
            now_atk = cloned.is_attacked_by(opp, sq)
            now_def = cloned.is_attacked_by(my_color, sq)
            if now_atk and not now_def and (not orig_atk or orig_def):
                return True, f"Discovered sacrifice: leaves {chess.piece_name(pt).capitalize()} on {chess.square_name(sq)} en prise"

    return False, None

def detect_tactical_motifs(board, move):
    """
    Detects tactical motifs: Royal Fork, Pin, Greek Gift, Smothered Mate, Discovered Check.
    """
    motifs = []
    moving_piece = board.piece_at(move.from_square)
    if not moving_piece:
        return motifs

    cloned = board.copy()
    is_check = cloned.gives_check(move)
    cloned.push(move)
    opp_color = cloned.turn

    # 1. Royal Fork (Knight or Queen attacking King and Queen/Rook)
    if moving_piece.piece_type in (chess.KNIGHT, chess.QUEEN):
        attacks = cloned.attacks(move.to_square)
        attacked_kings = [sq for sq in attacks if cloned.piece_at(sq) and cloned.piece_at(sq).piece_type == chess.KING and cloned.piece_at(sq).color == opp_color]
        attacked_queens = [sq for sq in attacks if cloned.piece_at(sq) and cloned.piece_at(sq).piece_type == chess.QUEEN and cloned.piece_at(sq).color == opp_color]
        attacked_rooks = [sq for sq in attacks if cloned.piece_at(sq) and cloned.piece_at(sq).piece_type == chess.ROOK and cloned.piece_at(sq).color == opp_color]

        if attacked_kings and attacked_queens:
            motifs.append("👑 Royal Fork (King + Queen Attack!)")
        elif attacked_kings and attacked_rooks:
            motifs.append("⚡ Decisive Fork (King + Rook Attack)")
        elif attacked_queens and attacked_rooks:
            motifs.append("🎯 Double Attack (Queen + Rook)")

    # 2. Greek Gift Sacrifice (Bxh7+ or Bxh2+)
    to_sq_name = chess.square_name(move.to_square)
    if moving_piece.piece_type == chess.BISHOP and is_check:
        if (board.turn == chess.WHITE and to_sq_name == "h7") or (board.turn == chess.BLACK and to_sq_name == "h2"):
            motifs.append("🎁 Greek Gift Sacrifice (Classic King decimation)!!")

    # 3. Check / Discovered Check / Double Check / Smothered Mate
    if is_check:
        if cloned.is_checkmate():
            if moving_piece.piece_type == chess.KNIGHT:
                motifs.append("👑 Smothered Checkmate Delivered!!")
            elif to_sq_name[1] in ("1", "8"):
                motifs.append("🏆 Back-Rank Checkmate Delivered!")
            else:
                motifs.append("🏆 Decisive Checkmate Delivered!")
        else:
            # Check for double check
            checkers = cloned.checkers()
            if len(checkers) > 1:
                motifs.append("⚡ Double Check (Lethal Attack)!")
            else:
                motifs.append("⚔️ Check")

    # 4. Fried Liver Knight Sacrifice
    if moving_piece.piece_type == chess.KNIGHT and to_sq_name in ("f7", "f2") and is_check:
        motifs.append("🔥 Fried Liver Knight Attack (!!) on f7")

    return motifs

def classify_chess_com_move(board, candidate_moves_info, current_eval_cp):
    """
    Classifies the top engine choice using Chess.com's Game Review algorithms:
    - Brilliant (!!) : Sound material sacrifice in a contested or winning position
    - Great (!)      : Only winning move, or sole resource in a critical position
    - Best (★)       : Top engine move
    - Excellent (👍) : Strong move near best
    """
    if not candidate_moves_info:
        return "★ BEST", False, False, ""

    top_entry = candidate_moves_info[0]
    top_move = top_entry["pv"][0]
    top_score_obj = top_entry["score"].pov(board.turn)
    top_cp = top_score_obj.score(mate_score=10000) or 0

    # Official Chess.com Brilliant Move (!!) Criteria:
    # 1. Piece sacrifice occurs (Knight, Bishop, Rook, Queen)
    # 2. Position before the move is NOT already won (current_eval_cp <= 350, i.e. under +3.5)
    # 3. Position after the move is winning (top_cp >= 150 or mate)
    # 4. Piece sacrificed is truly en prise without an immediate equal trade
    selected_move = top_move
    selected_entry = top_entry
    is_brilliant = False
    is_great = False
    badge = "★ BEST"
    annotation = ""

    is_sac, sac_desc = is_piece_hanging_or_sacrificed(board, top_move)
    is_contested = (current_eval_cp is None or (-250 <= current_eval_cp <= 350))

    if is_sac and top_cp >= 30 and is_contested:
        is_brilliant = True
        badge = "🌟 BRILLIANT (!!)"
        annotation = sac_desc or "Genuine piece sacrifice creating decisive attack"
    elif is_sac and top_cp >= 30 and not is_contested:
        # If position was already winning (> +3.5), Chess.com awards Great (!), not Brilliant (!!)
        is_great = True
        badge = "💎 GREAT (!)"
        annotation = sac_desc or "Winning tactical sacrifice"
    elif len(candidate_moves_info) > 1:
        # Check MultiPV candidate moves for a sound sacrifice
        for entry in candidate_moves_info[1:]:
            cand_move = entry["pv"][0]
            cand_score = entry["score"].pov(board.turn).score(mate_score=10000) or 0
            # Sound sacrifice: evaluation remains positive/sound and within 85cp of top choice
            # or still decisively winning (>= +120 cp)
            eval_sound = (cand_score >= 30 and (top_cp - cand_score) <= 85) or (cand_score >= 120 and (top_cp - cand_score) <= 120)
            if eval_sound:
                sac_cand, cand_desc = is_piece_hanging_or_sacrificed(board, cand_move)
                if sac_cand:
                    selected_move = cand_move
                    selected_entry = entry
                    if is_contested:
                        is_brilliant = True
                        badge = "🌟 BRILLIANT (!!)"
                    else:
                        is_great = True
                        badge = "💎 GREAT (!)"
                    annotation = cand_desc or "Sound piece sacrifice maintaining winning attack"
                    break

    # If not Brilliant, check for Great Move (!)
    if not is_brilliant and len(candidate_moves_info) > 1:
        second_cp = candidate_moves_info[1]["score"].pov(board.turn).score(mate_score=10000) or 0
        # If top move is winning and #2 move loses or drops significantly (gap >= 180 cp)
        if top_cp >= 150 and (top_cp - second_cp) >= 180:
            is_great = True
            badge = "💎 GREAT (!)"
            annotation = "Sole winning resource in a critical position"
        elif current_eval_cp is not None and current_eval_cp < -200 and top_cp >= -50 and (top_cp - second_cp) >= 150:
            is_great = True
            badge = "💎 GREAT (!)"
            annotation = "Brilliant defensive save holding equality"

    # Tactical motifs
    motifs = detect_tactical_motifs(board, selected_move)
    if motifs:
        extra = " | " + ", ".join(motifs)
        annotation = (annotation + extra) if annotation else ", ".join(motifs)

    return badge, is_brilliant, is_great, annotation, selected_move, selected_entry
