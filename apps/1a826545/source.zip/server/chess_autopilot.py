#!/usr/bin/env python3
"""
Chess AI Autopilot (chess-ai) - Grandmaster 3600 Hyper-Intelligent Edition
Autonomous high-speed chess engine for Chess.com vs Super Grandmaster Bots.

Key Intelligence Upgrades:
- Integrated Grandmaster Opening Repertoire (0ms theoretical book moves)
- Mathematical Chess.com Brilliant Move (!!) & Great Move (!) classification
- Dynamic Adaptive Search Depth & Multi-PV Tactical Verification
- Dynamic Board Orientation Detection (Auto White/Black support)
- Persistent Move Stack & Continuous Castling / En Passant Tracking
- Beautiful Live ANSI Unicode Board HUD with Logistic Win Probability
- Complete Rate-Limit Immunity (Exponential Backoff)

Usage:
    chess-ai status          # Show live screen board with HUD & evaluation
    chess-ai suggest         # Analyze screen board and suggest top moves (no taps)
    chess-ai play [--depth 20] [--max-moves 70]
"""

import sys
import os
import time
import re
import json
import argparse
import atexit
import urllib.request
import urllib.error
import chess
import chess.engine
import threading
import random

_SELF_DIR = os.path.dirname(os.path.realpath(__file__))
if _SELF_DIR and _SELF_DIR not in sys.path:
    sys.path.insert(0, _SELF_DIR)

from opening_repertoire import get_book_move
from tactical_analyzer import (
    classify_chess_com_move,
    detect_tactical_motifs,
    win_probability,
    PIECE_VALUES
)
from neural_trainer import NeuralTrainer

STOCKFISH_PATH = "/data/data/com.termux/files/usr/bin/stockfish"
RANKS = "87654321"
FILES = "abcdefgh"

CACHED_CENTERS = {}
PLAYER_COLOR = chess.WHITE
COLOR_OVERRIDE = None
DYNAMIC_SAFE_BOUNDS = None
LAST_BOARD_CENTER = None

GLOBAL_ENGINE = None
_ENGINE_LOCK = threading.RLock()
_BRIDGE_URL_OVERRIDE = None
_TOKEN_OVERRIDE = None

def cleanup_engine():
    global GLOBAL_ENGINE
    with _ENGINE_LOCK:
        eng = GLOBAL_ENGINE
        GLOBAL_ENGINE = None
    if eng is not None:
        t = threading.Thread(target=eng.quit, daemon=True)
        t.start()
        t.join(timeout=0.5)
        if t.is_alive():
            try:
                eng.close()
            except Exception:
                pass

atexit.register(cleanup_engine)

def _load_active_device_entry():
    dev_file = os.path.expanduser("~/.aura_devices.json")
    if not os.path.exists(dev_file):
        return {}
    try:
        data = json.load(open(dev_file, "r", encoding="utf-8"))
        if isinstance(data, dict):
            for entry in data.values():
                if isinstance(entry, dict) and entry.get("active"):
                    return entry
            if isinstance(data.get("device2_local"), dict):
                return data["device2_local"]
    except Exception:
        pass
    return {}

def resolve_bridge_url(explicit_url=None):
    if explicit_url:
        return str(explicit_url).strip().rstrip("/")
    if _BRIDGE_URL_OVERRIDE:
        return str(_BRIDGE_URL_OVERRIDE).strip().rstrip("/")
    env_url = (os.environ.get("AURA_HTTP_URL") or "").strip().rstrip("/")
    if env_url.startswith("http"):
        return env_url
    target_file = os.path.expanduser("~/.aura_target_url")
    if os.path.exists(target_file):
        try:
            val = open(target_file, "r", encoding="utf-8").read().strip().rstrip("/")
            if val.startswith("http"):
                return val
        except Exception:
            pass
    active = _load_active_device_entry()
    if isinstance(active.get("url"), str) and active["url"].startswith("http"):
        return active["url"].strip().rstrip("/")
    return "http://127.0.0.1:8080"

def get_api_url():
    global API_URL
    API_URL = resolve_bridge_url()
    return API_URL

def set_bridge_target(url=None, token=None):
    global _BRIDGE_URL_OVERRIDE, _TOKEN_OVERRIDE, API_URL
    if url:
        _BRIDGE_URL_OVERRIDE = str(url).strip().rstrip("/")
    if token:
        _TOKEN_OVERRIDE = str(token).strip()
    API_URL = resolve_bridge_url()
    return API_URL

def get_auth_token():
    if _TOKEN_OVERRIDE:
        return _TOKEN_OVERRIDE
    env_tok = (os.environ.get("AURA_TOKEN") or "").strip()
    if env_tok:
        return env_tok
    for p in ["~/.aura_token", "/sdcard/Download/AeroShare/.aura_token", "/sdcard/Download/.aura_token"]:
        exp = os.path.expanduser(p)
        if os.path.exists(exp):
            try:
                t = open(exp, "r", encoding="utf-8").read().strip()
                if t:
                    return t
            except Exception:
                pass
    active = _load_active_device_entry()
    if active.get("token"):
        return str(active["token"]).strip()
    return ""

API_URL = resolve_bridge_url()

LAST_API_CALL_TIME = 0.0
MIN_API_INTERVAL = 0.08  # 80ms adaptive rate limiter to completely avoid HTTP 429

def throttle_api():
    global LAST_API_CALL_TIME
    now = time.time()
    elapsed = now - LAST_API_CALL_TIME
    if elapsed < MIN_API_INTERVAL:
        time.sleep(MIN_API_INTERVAL - elapsed)
    LAST_API_CALL_TIME = time.time()

def get_headers():
    return {
        "Authorization": f"Bearer {get_auth_token()}",
        "X-API-Key": get_auth_token(),
        "Content-Type": "application/json"
    }

def send_tap(x, y):
    throttle_api()
    base = get_api_url()
    data = json.dumps({"action": "TAP", "x": int(x), "y": int(y)}).encode()
    for attempt in range(4):
        try:
            req = urllib.request.Request(f"{base}/api/ui/action", data=data, headers=get_headers())
            with urllib.request.urlopen(req, timeout=3) as resp:
                return json.loads(resp.read().decode())
        except urllib.error.HTTPError as e:
            if e.code == 429:
                time.sleep(0.4)
                continue
            time.sleep(0.2)
        except Exception:
            time.sleep(0.2)
    return {}

def send_swipe(x1, y1, x2, y2, duration_ms=220):
    throttle_api()
    base = get_api_url()
    data = json.dumps({
        "action": "SWIPE",
        "startX": int(x1),
        "startY": int(y1),
        "endX": int(x2),
        "endY": int(y2),
        "durationMs": int(duration_ms)
    }).encode()
    for attempt in range(4):
        try:
            req = urllib.request.Request(f"{base}/api/ui/action", data=data, headers=get_headers())
            with urllib.request.urlopen(req, timeout=3) as resp:
                return json.loads(resp.read().decode())
        except urllib.error.HTTPError as e:
            if e.code == 429:
                time.sleep(0.4)
                continue
            time.sleep(0.2)
        except Exception:
            time.sleep(0.2)
    return {}

def focus_window():
    # Safely tap middle of static non-clickable banner/header inside current board window if known
    if LAST_BOARD_CENTER:
        bx, by = LAST_BOARD_CENTER
        send_tap(bx, max(40, by - 260))
    else:
        send_tap(1113, 55)

# =====================================================================
# Strict Board Touch Lock (Dynamic Bounds + Device 2 Safe Fallback)
# =====================================================================
BOARD_X_MIN = 887
BOARD_X_MAX = 1335
BOARD_Y_MIN = 213
BOARD_Y_MAX = 661

SAFE_X_MIN = 905
SAFE_X_MAX = 1315
SAFE_Y_MIN = 230
SAFE_Y_MAX = 645

def clamp_board_coords(x, y):
    """
    Strictly clamps any board touch or swipe coordinate inside the active 64 board squares.
    Uses dynamically observed board bounds when present, falling back to SAFE_* bounds.
    """
    x_min, x_max, y_min, y_max = DYNAMIC_SAFE_BOUNDS or (SAFE_X_MIN, SAFE_X_MAX, SAFE_Y_MIN, SAFE_Y_MAX)
    cx = max(x_min, min(x_max, int(x)))
    cy = max(y_min, min(y_max, int(y)))
    return cx, cy

def board_tap(x, y):
    """Dispatches a tap strictly clamped within the chessboard squares."""
    cx, cy = clamp_board_coords(x, y)
    return send_tap(cx, cy)

def board_swipe(x1, y1, x2, y2, duration_ms=220):
    """Dispatches a drag/swipe strictly clamped within the chessboard squares."""
    cx1, cy1 = clamp_board_coords(x1, y1)
    cx2, cy2 = clamp_board_coords(x2, y2)
    return send_swipe(cx1, cy1, cx2, cy2, duration_ms=duration_ms)

def ensure_at_latest_move(persistent_board=None, tree=None, force=False):
    """
    Checks if Chess.com has navigated to a historical past move (review/replay mode)
    which disables board touch, and taps the forward/latest button (>> / >)
    at (1318, 721) to return to the live position and re-enable board touch.
    """
    FORWARD_BUTTON_COORDS = (1318, 721)
    if tree is None and not force:
        tree = get_tree()

    is_review_active = force
    if not is_review_active and tree:
        for n in tree.get("nodes", []):
            def check_fwd(node):
                nonlocal is_review_active
                if is_review_active: return
                b = node.get("bounds", "") or node.get("boundsInScreen", "")
                d = (node.get("contentDescription") or "").lower()
                t = (node.get("text") or "").lower()
                if any(k in d or k in t for k in ["forward", "next move", "last move", "flip to end", "latest move"]):
                    is_review_active = True
                    return
                m = re.search(r"\[(\d+),(\d+)\]\[(\d+),(\d+)\]", b)
                if m:
                    x1, y1, x2, y2 = [int(v) for v in m.groups()]
                    # Check for active forward arrow icon in bottom move bar (X: 1300-1335, Y: 700-745)
                    if 1300 <= x1 <= 1335 and 700 <= y1 <= 745 and node.get("isClickable", True):
                        is_review_active = True
                        return
                for ch in node.get("children", []): check_fwd(ch)
            check_fwd(n)

    if not is_review_active and persistent_board and len(persistent_board.move_stack) > 1:
        # Check if visible board matches persistent board
        cur_fen, _, _ = parse_board_and_coords(tree=tree)
        if cur_fen and cur_fen != persistent_board.board_fen():
            is_review_active = True

    if is_review_active:
        print("[!] Detected past-move review mode (board touch disabled). Fast-forwarding to live move...")
        for attempt in range(4):
            send_tap(FORWARD_BUTTON_COORDS[0], FORWARD_BUTTON_COORDS[1])
            time.sleep(0.12)
            new_fen, _, _ = parse_board_and_coords()
            if persistent_board and new_fen == persistent_board.board_fen():
                print("[✓] Restored live board state! Board touch re-enabled.")
                return True
        print("[✓] Fast-forwarded to latest move.")
        return True
    return False

def get_engine():
    global GLOBAL_ENGINE
    if GLOBAL_ENGINE is not None:
        try:
            GLOBAL_ENGINE.ping()
            return GLOBAL_ENGINE
        except Exception:
            try:
                GLOBAL_ENGINE.quit()
            except Exception:
                pass
            GLOBAL_ENGINE = None
    engine = chess.engine.SimpleEngine.popen_uci(STOCKFISH_PATH)
    engine.configure({
        "Threads": 1,   # 1 thread: eliminates cross-core contention & leaves CPU cores free for Android UI
        "Hash": 16,     # 16MB Hash: avoids swap paging on 4GB RAM devices
        "Skill Level": 20
    })
    GLOBAL_ENGINE = engine
    return engine

def get_tree():
    throttle_api()
    base = get_api_url()
    for attempt in range(4):
        try:
            req = urllib.request.Request(f"{base}/api/ui/tree", data=b"{}", headers=get_headers())
            with urllib.request.urlopen(req, timeout=3) as resp:
                data = json.loads(resp.read().decode())
                if data.get("nodes") or data.get("tree") or data.get("uiTree"):
                    return data
                if attempt == 0:
                    focus_window()
                    time.sleep(0.25)
                    continue
                return data
        except urllib.error.HTTPError as e:
            if e.code == 429:
                time.sleep(0.4)
                continue
            time.sleep(0.2)
        except Exception:
            time.sleep(0.2)
    return {}

def check_game_status(tree):
    all_texts = []
    has_resign_button = False

    def scan(node):
        nonlocal has_resign_button
        if isinstance(node, list):
            for c in node: scan(c)
            return
        t = (node.get("text") or "").strip()
        d = (node.get("contentDescription") or "").strip()
        if t.lower() in ["resign", "abort"] or d.lower() in ["resign", "abort"]:
            has_resign_button = True
        if t: all_texts.append(t)
        if d: all_texts.append(d)
        for c in node.get("children", []):
            scan(c)

    scan(tree.get("nodes", []))

    # If the Resign button is visible, the game is definitely still active!
    if has_resign_button:
        return []

    # Check for definitive post-game signals
    game_over_tokens = []
    for s in all_texts:
        s_lower = s.lower()
        if any(term in s_lower for term in ["game review", "rematch", "next bot", "play again"]):
            game_over_tokens.append(s)
        elif any(s_lower.startswith(prefix) for prefix in ["white won", "black won", "draw by", "game over"]):
            game_over_tokens.append(s)
        elif s_lower in ["checkmate", "stalemate"]:
            game_over_tokens.append(s)

    return game_over_tokens

def parse_board_and_coords(tree=None, color_override=None):
    global CACHED_CENTERS, PLAYER_COLOR, DYNAMIC_SAFE_BOUNDS, LAST_BOARD_CENTER
    for attempt in range(2):
        if tree is None:
            tree = get_tree()
        squares = {}
        centers = {}
        rect_coords = []
        piece_map = {"Pawn": "p", "Knight": "n", "Bishop": "b", "Rook": "r", "Queen": "q", "King": "k"}

        def scan(node):
            if not isinstance(node, dict):
                return
            d = node.get("contentDescription", "") or ""
            b = node.get("boundsInScreen", "") or node.get("bounds", "")
            m1 = re.match(r"(White|Black)\s+(\w+)\s+on\s+([a-h][1-8])", d)
            m2 = re.match(r"([a-h][1-8]),\s*empty", d)
            if m1:
                squares[m1.group(3)] = (m1.group(1), m1.group(2))
            elif m2:
                squares[m2.group(1)] = None

            bounds_m = re.search(r"\[(\d+),(\d+)\]\[(\d+),(\d+)\]", b)
            sq_m = re.search(r"\b([a-h][1-8])\b", d)
            if bounds_m and sq_m:
                x1, y1, x2, y2 = [int(v) for v in bounds_m.groups()]
                rect_coords.append((x1, y1, x2, y2))
                centers[sq_m.group(1)] = ((x1 + x2) // 2, (y1 + y2) // 2)

            for c in node.get("children", []):
                scan(c)

        roots = tree.get("nodes") or tree.get("tree") or tree.get("uiTree") or []
        if isinstance(roots, dict):
            roots = [roots]
        for n in roots:
            scan(n)

        if len(rect_coords) >= 32:
            bx1 = min(r[0] for r in rect_coords)
            by1 = min(r[1] for r in rect_coords)
            bx2 = max(r[2] for r in rect_coords)
            by2 = max(r[3] for r in rect_coords)
            if bx2 - bx1 > 120 and by2 - by1 > 120:
                DYNAMIC_SAFE_BOUNDS = (bx1 + 10, bx2 - 10, by1 + 10, by2 - 10)
                LAST_BOARD_CENTER = ((bx1 + bx2) // 2, (by1 + by2) // 2)

        for sq_key, (cx, cy) in list(centers.items()):
            centers[sq_key] = clamp_board_coords(cx, cy)

        if centers and len(centers) >= 50:
            CACHED_CENTERS = centers

        if len(squares) >= 60:
            eff_override = color_override if color_override is not None else COLOR_OVERRIDE
            if eff_override is not None:
                PLAYER_COLOR = eff_override
            else:
                # Rule: The bottom of the screen is ALWAYS mine (the player's color).
                # In Android display coordinates, higher Y = lower / bottom of screen.
                effective_centers = centers if len(centers) >= 50 else (CACHED_CENTERS or centers)
                y_rank8 = [effective_centers[f + "8"][1] for f in FILES if f + "8" in effective_centers]
                y_rank1 = [effective_centers[f + "1"][1] for f in FILES if f + "1" in effective_centers]
                if y_rank8 and y_rank1:
                    avg_y8 = sum(y_rank8) / len(y_rank8)
                    avg_y1 = sum(y_rank1) / len(y_rank1)
                    if avg_y8 > avg_y1:
                        # Rank 8 is at the bottom of the screen -> Player is BLACK!
                        PLAYER_COLOR = chess.BLACK
                    else:
                        # Rank 1 is at the bottom of the screen -> Player is WHITE!
                        PLAYER_COLOR = chess.WHITE
                else:
                    # Fallback: check piece positions directly in bottom half of board
                    occupied = [(sq, v) for sq, v in squares.items() if v is not None and sq in effective_centers]
                    if occupied:
                        all_y = [effective_centers[sq][1] for sq, _ in occupied]
                        mid_y = (min(all_y) + max(all_y)) / 2.0
                        bottom_pieces = [v for sq, v in occupied if effective_centers[sq][1] > mid_y]
                        if bottom_pieces:
                            white_b = sum(1 for c, p in bottom_pieces if c == "White")
                            black_b = sum(1 for c, p in bottom_pieces if c == "Black")
                            PLAYER_COLOR = chess.BLACK if black_b > white_b else chess.WHITE

            fen_rows = []
            for rank in RANKS:
                row = ""
                empty_count = 0
                for file in FILES:
                    sq = file + rank
                    val = squares.get(sq)
                    if val is None:
                        empty_count += 1
                    else:
                        if empty_count > 0:
                            row += str(empty_count)
                            empty_count = 0
                        color, piece = val
                        p = piece_map.get(piece, "p")
                        row += p.upper() if color == "White" else p.lower()
                if empty_count > 0:
                    row += str(empty_count)
                fen_rows.append(row)
            return "/".join(fen_rows), squares, (CACHED_CENTERS or centers)

        if attempt == 0:
            focus_window()
        tree = None

    return None, {}, (CACHED_CENTERS or {})

def render_hud(board, last_move=None, score_cp=None, badge=None, annotation=None):
    unicode_pieces = {
        'r': '♜', 'n': '♞', 'b': '♝', 'q': '♛', 'k': '♚', 'p': '♟',
        'R': '♖', 'N': '♘', 'B': '♗', 'Q': '♕', 'K': '♔', 'P': '♙',
        '.': '·'
    }
    prob = win_probability(score_cp) if score_cp is not None else 50.0
    bar_width = 24
    white_fill = int((prob / 100.0) * bar_width)
    black_fill = bar_width - white_fill
    bar_str = f"[\033[92m{'█' * white_fill}\033[90m{'░' * black_fill}\033[0m] {prob:.1f}% Win"

    eval_str = f"{score_cp/100:+.2f}" if score_cp is not None else "+0.00"
    lines = []
    lines.append("\033[1;36m" + "="*56 + "\033[0m")
    lines.append(f" Eval: \033[1;93m{eval_str:<7}\033[0m | {bar_str}")
    if badge:
        lines.append(f" Quality: {badge}  \033[90m{annotation or ''}\033[0m")
    lines.append("     a   b   c   d   e   f   g   h")
    lines.append("   \033[90m┌───┬───┬───┬───┬───┬───┬───┬───┐\033[0m")
    for r in range(7, -1, -1):
        row_str = f" {r+1} \033[90m│\033[0m"
        for f in range(8):
            sq = chess.square(f, r)
            p = board.piece_at(sq)
            sym = unicode_pieces.get(p.symbol(), '·') if p else '·'
            if last_move and sq in (last_move.from_square, last_move.to_square):
                row_str += f" \033[43;30m{sym}\033[0m \033[90m│\033[0m"
            elif p and p.color == chess.WHITE:
                row_str += f" \033[97;1m{sym}\033[0m \033[90m│\033[0m"
            elif p and p.color == chess.BLACK:
                row_str += f" \033[36m{sym}\033[0m \033[90m│\033[0m"
            else:
                row_str += f" \033[90m{sym}\033[0m \033[90m│\033[0m"
        row_str += f" {r+1}"
        lines.append(row_str)
        if r > 0:
            lines.append("   \033[90m├───┼───┼───┼───┼───┼───┼───┤\033[0m")
    lines.append("   \033[90m└───┴───┴───┴───┴───┴───┴───┘\033[0m")
    lines.append("     a   b   c   d   e   f   g   h")
    lines.append("\033[1;36m" + "="*56 + "\033[0m")
    return "\n".join(lines)

def find_opponent_move(persistent_board, current_fen_str):
    """Reconstructs legal opponent move from persistent board state."""
    test_b = chess.Board(f"{current_fen_str} {('w' if persistent_board.turn == chess.WHITE else 'b')} - - 0 1")
    for m in persistent_board.legal_moves:
        cloned = persistent_board.copy()
        cloned.push(m)
        if cloned.board_fen() == test_b.board_fen():
            return m
    return None

class StatusAnimator:
    """
    Renders dynamic, non-blocking loading animations and grandmaster feedback
    instead of silent waiting and freezing.
    """
    SPINNER_FRAMES = ['⠋', '⠙', '⠹', '⠸', '⠼', '⠴', '⠦', '⠧', '⠇', '⠏']

    def __init__(self, quiet=False):
        self.frame_idx = 0
        self.is_active = False
        self.quiet = quiet

    def step(self, label, detail="", color="\033[96m"):
        if self.quiet:
            return
        self.is_active = True
        frame = self.SPINNER_FRAMES[self.frame_idx % len(self.SPINNER_FRAMES)]
        self.frame_idx += 1
        msg = f"\r\033[K {color}{frame}\033[0m \033[1m{label}\033[0m"
        if detail:
            msg += f" {detail}"
        sys.stdout.write(msg)
        sys.stdout.flush()

    def clear(self, final_line=None):
        if self.quiet:
            return
        if self.is_active:
            sys.stdout.write("\r\033[K")
            if final_line:
                sys.stdout.write(final_line + "\n")
            sys.stdout.flush()
            self.is_active = False

class BackgroundPonderer:
    """
    Ultra-Lightweight Grandmaster Anticipation:
    If enabled, performs a quick, bounded calculation burst (max 0.25s)
    on the opponent's clock, then instantly releases CPU.
    Disabled by default to keep the device silky smooth, cool, and 100% lag-free.
    """
    def __init__(self, stockfish_path=STOCKFISH_PATH, enabled=False):
        self.stockfish_path = stockfish_path
        self.enabled = enabled
        self.engine = None
        self.cache = {}
        self.thread = None
        self.stop_requested = False
        self.lock = threading.Lock()
        if self.enabled:
            try:
                self._ensure_engine()
            except Exception:
                pass

    def _ensure_engine(self):
        if not self.enabled:
            return
        if self.engine is None:
            self.engine = chess.engine.SimpleEngine.popen_uci(self.stockfish_path)
            self.engine.configure({"Threads": 1, "Hash": 16})

    def start_ponder(self, board, my_color):
        if not self.enabled:
            return
        self.stop_requested = False
        with self.lock:
            self.cache.clear()
        self.thread = threading.Thread(target=self._run, args=(board.copy(), my_color), daemon=True)
        self.thread.start()

    def _run(self, board, my_color):
        if not self.enabled:
            return
        try:
            self._ensure_engine()
            # Bounded brief burst: max 0.25s or depth 12, never an infinite loop!
            info_list = self.engine.analyse(board, chess.engine.Limit(time=0.25, depth=12), multipv=2)
            if not isinstance(info_list, list):
                info_list = [info_list]
            with self.lock:
                for info in info_list:
                    pv = info.get("pv", [])
                    if len(pv) >= 2:
                        opp_m = pv[0]
                        our_reply = pv[1]
                        score_pov = info.get("score").pov(my_color) if info.get("score") else None
                        score_cp = score_pov.score(mate_score=10000) if score_pov else None
                        self.cache[opp_m.uci()] = {
                            "reply": our_reply,
                            "score_cp": score_cp,
                            "depth": info.get("depth", 10),
                            "badge": "⚡ PONDER (0ms)",
                            "annot": "Pre-calculated reply"
                        }
        except Exception:
            pass

    def stop_ponder(self):
        self.stop_requested = True
        if self.thread and self.thread.is_alive():
            self.thread.join(timeout=0.15)

    def get_hit(self, opp_move_uci):
        if not self.enabled:
            return None
        with self.lock:
            return self.cache.get(opp_move_uci)

    def get_cache_size(self):
        if not self.enabled:
            return 0
        with self.lock:
            return len(self.cache)

    def cleanup(self):
        self.stop_ponder()
        if self.engine:
            try:
                self.engine.quit()
            except Exception:
                pass
            self.engine = None

def calculate_intelligent_move(engine, board, move_history_uci, target_depth=20, hunt_brilliant=True, trainer=None, seen_fens=None):
    """
    Hyper-intelligent decision engine combining:
    1. Grandmaster Opening Repertoire (0ms)
    2. Neural Network Experience Cache (Fast Thinking - 0ms)
    3. Dynamic Adaptive Depth & Multi-PV Chess.com Classifier
    """
    t0 = time.time()

    # Step 1: Check Grandmaster Opening Book
    book_move, book_desc, eco = get_book_move(move_history_uci)
    if book_move and book_move in board.legal_moves:
        calc_ms = (time.time() - t0) * 1000
        if trainer:
            trainer.record_move(board.board_fen(), book_move.uci(), None, "⚡ BOOK (📖)", f"{eco}: {book_desc}", calc_ms)
        return engine, book_move, None, "⚡ BOOK (📖)", True, False, f"{eco}: {book_desc}", calc_ms

    # Step 1.5: Neural Network Experience Cache (Fast Thinking 0ms)
    if trainer:
        fast_move, fast_score, fast_badge, fast_annot = trainer.query_fast_thinking(board)
        if fast_move and fast_move in board.legal_moves:
            calc_ms = (time.time() - t0) * 1000
            return engine, fast_move, fast_score, fast_badge, False, False, fast_annot, calc_ms

    # Step 2: Dynamic Depth Allocation
    legal_moves = list(board.legal_moves)
    if len(legal_moves) == 1:
        calc_ms = (time.time() - t0) * 1000
        if trainer:
            trainer.record_move(board.board_fen(), legal_moves[0].uci(), None, "★ BEST (Forced)", "Only legal move", calc_ms)
        return engine, legal_moves[0], None, "★ BEST (Forced)", False, False, "Only legal move available", calc_ms

    # Phase-adaptive search allocation:
    total_pieces = len(board.piece_map())
    move_num = len(move_history_uci) // 2 + 1
    # Chess.com Brilliant sacrifices strictly occur in contested opening & middlegame
    is_contested_phase = (total_pieces >= 12 and move_num <= 40)
    num_pv = 3 if (hunt_brilliant and is_contested_phase) else 1

    # Dynamic time allocation:
    # Sharp middlegame: 0.28s; Clean endgame conversion: 0.14s
    is_sharp = board.is_check() or any(board.is_capture(m) for m in legal_moves[:4])
    if not is_contested_phase:
        depth = max(18, target_depth)
        time_limit = 0.16 if is_sharp else 0.12
    else:
        depth = max(20, target_depth) if is_sharp else max(18, target_depth - 1)
        time_limit = 0.28 if is_sharp else 0.20

    info = None
    for attempt in range(2):
        try:
            cur_pv = num_pv if attempt == 0 else 1
            info = engine.analyse(board, chess.engine.Limit(time=time_limit, depth=depth), multipv=cur_pv)
            break
        except Exception:
            try: engine.quit()
            except Exception: pass
            time.sleep(0.08)
            engine = get_engine()

    if info is None:
        try:
            info = engine.analyse(board, chess.engine.Limit(time=0.15, depth=16))
        except Exception:
            return engine, legal_moves[0], None, "★ BEST", False, False, "Fallback", (time.time() - t0) * 1000

    calc_ms = (time.time() - t0) * 1000

    if not isinstance(info, list):
        info = [info]
    valid_infos = [c for c in info if c.get("pv")]

    if not valid_infos:
        return engine, legal_moves[0], None, "★ BEST", False, False, "", calc_ms

    current_eval_cp = valid_infos[0]["score"].pov(board.turn).score(mate_score=10000)

    # Anti-Draw & Anti-Repetition Filter:
    # If the top engine move leads to a 2-fold/3-fold repetition, 50-move draw, or stalemate,
    # choose an aggressive alternative move in Multi-PV that keeps winning chances alive!
    if len(valid_infos) > 1 and (current_eval_cp is None or current_eval_cp >= -150):
        top_m = valid_infos[0]["pv"][0]
        test_board = board.copy()
        test_board.push(top_m)
        res_fen = test_board.board_fen()
        leads_to_repeat = (seen_fens and seen_fens.count(res_fen) >= 1) or test_board.is_repetition(2) or test_board.is_repetition(3) or test_board.is_stalemate() or test_board.is_fifty_moves()
        if leads_to_repeat:
            print(f"[*] Choice {board.san(top_m)} results in repetition/draw. Filtering for winning alternative...")
            found_alt = False
            for alt_entry in valid_infos[1:]:
                alt_m = alt_entry["pv"][0]
                alt_test = board.copy()
                alt_test.push(alt_m)
                alt_res_fen = alt_test.board_fen()
                alt_repeat = (seen_fens and seen_fens.count(alt_res_fen) >= 1) or alt_test.is_repetition(2) or alt_test.is_repetition(3) or alt_test.is_stalemate() or alt_test.is_fifty_moves()
                if not alt_repeat:
                    alt_score = alt_entry["score"].pov(board.turn).score(mate_score=10000) or 0
                    allowed_drop = 150 if (current_eval_cp or 0) >= 200 else 90
                    if (current_eval_cp or 0) - alt_score <= allowed_drop:
                        print(f"[✓] Anti-Draw Filter activated: Selected {board.san(alt_m)} to play for the win!")
                        valid_infos.insert(0, alt_entry)
                        found_alt = True
                        break
            if not found_alt and len(legal_moves) > 1:
                for cand in legal_moves:
                    if cand == top_m: continue
                    alt_test = board.copy()
                    alt_test.push(cand)
                    if (seen_fens and alt_test.board_fen() in seen_fens) or alt_test.is_repetition(2) or alt_test.is_stalemate():
                        continue
                    try:
                        cand_info = engine.analyse(alt_test, chess.engine.Limit(time=0.08, depth=12))
                        cand_score = -cand_info["score"].pov(alt_test.turn).score(mate_score=10000) or 0
                        if cand_score >= -100:
                            print(f"[✓] Anti-Draw Breakout: Selected {board.san(cand)} ({cand_score:+d} cp) to prevent draw!")
                            valid_infos.insert(0, {"pv": [cand], "score": chess.engine.PovScore(chess.engine.Cp(cand_score), board.turn)})
                            break
                    except Exception:
                        pass

    badge, is_brill, is_great, annotation, move, entry = classify_chess_com_move(board, valid_infos, current_eval_cp)

    score_pov = entry["score"].pov(board.turn)
    score_cp = score_pov.score(mate_score=10000)

    if trainer:
        trainer.record_move(board.board_fen(), move.uci(), score_cp, badge, annotation, calc_ms)

    return engine, move, score_cp, badge, is_brill, is_great, annotation, calc_ms

def format_eval_cp(score_cp):
    if score_cp is None:
        return "+0.0"
    if abs(score_cp) >= 9000:
        mate_moves = max(1, (10000 - abs(score_cp) + 1) // 2)
        return f"+M{mate_moves}" if score_cp > 0 else f"-M{mate_moves}"
    pawns = score_cp / 100.0
    return f"{pawns:+.1f}"

def move_uci_to_dict(move_uci):
    cleaned = (move_uci or "").strip().lower()
    if len(cleaned) >= 4:
        return {"from": cleaned[:2], "to": cleaned[2:4]}
    return None

def build_chess_task_map(
    fen,
    player_color="white",
    eval_cp="+0.0",
    last_move=None,
    best_move=None,
    turn_label="",
    title="Chess Autopilot",
    persist_on_done=True,
):
    chess_obj = {
        "fen": fen or "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR",
        "playerColor": "black" if str(player_color).lower() == "black" else "white",
        "evalCp": str(eval_cp or "+0.0"),
    }
    if isinstance(last_move, str):
        last_move = move_uci_to_dict(last_move)
    if isinstance(best_move, str):
        best_move = move_uci_to_dict(best_move)
    if isinstance(last_move, dict) and last_move.get("from") and last_move.get("to"):
        chess_obj["lastMove"] = last_move
    if isinstance(best_move, dict) and best_move.get("from") and best_move.get("to"):
        chess_obj["bestMove"] = best_move
    if turn_label:
        chess_obj["turnLabel"] = str(turn_label)[:28]
    return {
        "active": True,
        "mode": "chess",
        "title": title[:48],
        "persistOnDone": bool(persist_on_done),
        "chess": chess_obj,
    }

def push_hud_state(payload):
    base = get_api_url()
    try:
        req = urllib.request.Request(
            f"{base}/api/hud/state",
            data=json.dumps(payload).encode("utf-8"),
            headers=get_headers(),
        )
        with urllib.request.urlopen(req, timeout=2.0) as resp:
            return json.loads(resp.read().decode() or '{"success": true}')
    except Exception:
        return {}

def _emit_chess_hud(
    hud_callback,
    push_hud,
    state,
    title,
    current_action,
    fen,
    player_color,
    eval_cp="+0.0",
    last_move=None,
    best_move=None,
    turn_label="",
    detailed_output="",
    logs=None,
    next_action="",
):
    if not hud_callback and not push_hud:
        return
    task_map = build_chess_task_map(
        fen=fen,
        player_color=player_color,
        eval_cp=eval_cp,
        last_move=last_move,
        best_move=best_move,
        turn_label=turn_label,
        title=title,
        persist_on_done=True,
    )
    payload = {
        "state": state,
        "title": title[:60],
        "currentAction": (current_action or "")[:80],
        "nextAction": (next_action or "")[:80],
        "icon": "chess",
        "appPackage": "com.chess",
        "actionKind": "playing",
        "detailedOutput": (detailed_output or "")[:2400],
        "outputLogs": list(logs or [])[-20:],
        "taskMap": task_map,
    }
    if hud_callback:
        try:
            hud_callback(payload)
        except Exception:
            pass
    elif push_hud:
        push_hud_state(payload)

def extract_turn_label_from_tree(tree):
    if not isinstance(tree, dict):
        return ""
    roots = tree.get("nodes") or tree.get("tree") or tree.get("uiTree") or []
    if isinstance(roots, dict):
        roots = [roots]
    found = ""
    def scan(node):
        nonlocal found
        if found or not isinstance(node, dict):
            return
        for field in (node.get("contentDescription"), node.get("text")):
            val = str(field or "").strip()
            low = val.lower()
            if any(k in low for k in ("your turn", "white to move", "black to move", "opponent's turn")):
                found = val[:28]
                return
        for c in node.get("children", []):
            scan(c)
    for n in roots:
        scan(n)
    return found

def analyze_screen_position(
    tree=None,
    depth=14,
    multipv=3,
    time_limit=0.18,
    board_hint=None,
    last_move=None,
    color_override=None,
    side_to_move=None,
):
    """
    Thread-safe Stockfish + tactical motif inspection on the visible board (or `board_hint`).
    Returns structured evaluation, top moves, SAN/UCI variations, and HUD `ChessTaskMapData`.
    """
    if board_hint is not None:
        board = board_hint.copy()
        fen_str = board.board_fen()
        centers = dict(CACHED_CENTERS)
        player_col = "black" if (color_override == chess.BLACK or PLAYER_COLOR == chess.BLACK) else "white"
        turn_label = "Black to move" if board.turn == chess.BLACK else "White to move"
    else:
        if tree is None:
            tree = get_tree()
        fen_str, _, centers = parse_board_and_coords(tree=tree, color_override=color_override)
        if not fen_str:
            return {"success": False, "error": "No active chess board found on screen."}
        player_col_obj = color_override if color_override is not None else PLAYER_COLOR
        player_col = "black" if player_col_obj == chess.BLACK else "white"
        turn_label = extract_turn_label_from_tree(tree)
        stm = side_to_move
        if stm is None:
            if "black" in turn_label.lower() or ("opponent" in turn_label.lower() and player_col == "white"):
                stm = "b"
            elif "white" in turn_label.lower() or ("opponent" in turn_label.lower() and player_col == "black"):
                stm = "w"
            else:
                stm = "b" if player_col == "black" else "w"
        board = chess.Board(f"{fen_str} {stm} - - 0 1")

    variations = []
    best_move_dict = None
    best_san = ""
    best_uci = ""
    score_cp = None
    win_prob = 50.0

    with _ENGINE_LOCK:
        if os.path.exists(STOCKFISH_PATH):
            engine = get_engine()
            info = engine.analyse(
                board,
                chess.engine.Limit(time=time_limit, depth=depth),
                multipv=max(1, int(multipv)),
            )
            if not isinstance(info, list):
                info = [info]
            for idx, entry in enumerate(info):
                pv = entry.get("pv") or []
                if not pv:
                    continue
                mv = pv[0]
                san = board.san(mv)
                uci = mv.uci()
                sc = entry["score"].white().score(mate_score=10000) if entry.get("score") else None
                motifs = detect_tactical_motifs(board, mv)
                if idx == 0:
                    score_cp = sc
                    best_san = san
                    best_uci = uci
                    best_move_dict = move_uci_to_dict(uci)
                    pov_score = entry["score"].pov(board.turn).score(mate_score=10000) if entry.get("score") else None
                    win_prob = win_probability(pov_score)
                variations.append(
                    {
                        "san": san,
                        "uci": uci,
                        "scoreCp": sc,
                        "evalCp": format_eval_cp(sc),
                        "motifs": motifs,
                    }
                )

    eval_str = format_eval_cp(score_cp)
    task_map = build_chess_task_map(
        fen=fen_str,
        player_color=player_col,
        eval_cp=eval_str,
        last_move=last_move,
        best_move=best_move_dict,
        turn_label=turn_label or ("White to move" if board.turn == chess.WHITE else "Black to move"),
        title="Chess Autopilot",
    )
    return {
        "success": True,
        "fen": fen_str,
        "playerColor": player_col,
        "sideToMove": "white" if board.turn == chess.WHITE else "black",
        "scoreCp": score_cp,
        "evalCp": eval_str,
        "winProb": win_prob,
        "turnLabel": task_map["chess"].get("turnLabel", ""),
        "lastMove": last_move,
        "bestMove": best_move_dict,
        "bestSan": best_san,
        "bestUci": best_uci,
        "variations": variations,
        "taskMap": task_map,
        "centers": centers,
        "board": board,
    }

def show_toast(msg):
    base = get_api_url()
    try:
        req = urllib.request.Request(
            f"{base}/api/toast",
            data=json.dumps({"message": str(msg), "text": str(msg)}).encode("utf-8"),
            headers=get_headers(),
        )
        with urllib.request.urlopen(req, timeout=1.5) as resp:
            if resp.status == 200:
                return
    except Exception:
        pass
    try:
        import subprocess
        subprocess.Popen(["termux-toast", "-g", "middle", "-b", "#1a1a1a", "-c", "#00FFCC", msg],
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception:
        pass

def wait_for_bridge(timeout=600, stop_event=None, quiet=False):
    base = get_api_url()
    t0 = time.time()
    animator = StatusAnimator(quiet=quiet)
    last_toast = 0
    while time.time() - t0 < timeout:
        if stop_event and stop_event.is_set():
            animator.clear()
            return False
        elapsed = time.time() - t0
        animator.step("Connecting to KaVach Bridge...", f"⏳ {int(elapsed)}s ({base})...", color="\033[93m")
        for path in ("/api/device", "/health"):
            try:
                req = urllib.request.Request(f"{base}{path}", headers=get_headers())
                with urllib.request.urlopen(req, timeout=1.0) as resp:
                    if resp.status == 200:
                        animator.clear(f" \033[92m✓ [KaVach Bridge Online]\033[0m {base} authenticated ({elapsed:.1f}s)!")
                        return True
            except Exception:
                pass
        now = time.time()
        if now - last_toast > 20 and not quiet:
            show_toast("♟️ Chess Autopilot: Tap KaVach app once to activate bridge!")
            last_toast = now
        time.sleep(0.15)
    animator.clear()
    return False

def wait_for_board(timeout=60, stop_event=None, quiet=False):
    base = get_api_url()
    t0 = time.time()
    animator = StatusAnimator(quiet=quiet)
    launched_chess = False
    while time.time() - t0 < timeout:
        if stop_event and stop_event.is_set():
            animator.clear()
            return None, {}, {}
        elapsed = time.time() - t0
        animator.step("Scanning for Chess Board...", f"⏳ {int(elapsed)}s | Parsing screen elements...", color="\033[93m")
        tree = get_tree()
        fen_str, squares, centers = parse_board_and_coords(tree=tree)
        if fen_str:
            animator.clear(f" \033[92m✓ [Chess Board Active]\033[0m 64-square layout verified ({elapsed:.1f}s)!")
            return fen_str, squares, centers
        if not launched_chess and time.time() - t0 > 1.2:
            try:
                # Auto-launch Chess app via bridge if not on screen
                req = urllib.request.Request(f"{base}/api/app/launch",
                                             data=json.dumps({"packageName": "com.chess"}).encode(),
                                             headers=get_headers())
                urllib.request.urlopen(req, timeout=1.5)
                launched_chess = True
            except Exception:
                pass
        time.sleep(0.35)
    animator.clear()
    return None, {}, {}

def _wait_if_paused(pause_event, stop_event):
    while pause_event is not None and pause_event.is_set():
        if stop_event is not None and stop_event.is_set():
            return False
        time.sleep(0.15)
    return not (stop_event is not None and stop_event.is_set())

def play_game(
    depth=20,
    hunt_brilliant=True,
    max_moves=120,
    trainer=None,
    match_num=1,
    enable_ponder=False,
    stop_event=None,
    pause_event=None,
    hud_callback=None,
    push_hud=True,
    quiet=False,
):
    global CACHED_CENTERS, PLAYER_COLOR
    hud_logs = []
    def log_hud(line):
        ts = time.strftime("%H:%M:%S")
        hud_logs.append(f"[{ts}] {line}")
        if len(hud_logs) > 20:
            del hud_logs[:-20]

    if not quiet:
        print("=" * 65)
        print(f" ♟️  CHESS AI AUTOPILOT — MATCH {match_num} vs MAXIMUM (3200)")
        print(f" Engine      : Stockfish 19 UCI + NNUE (Adaptive Depth {depth})")
        print(f" Profile     : {'⚡ Eco-Lite (1 Thread, 0% Opponent CPU, Anti-Lag)' if not enable_ponder else 'Anticipation Pondering'}")
        print(f" Sacrifice   : {'Sound Sacrifice Hunter (!!) Enabled' if hunt_brilliant else 'Pure Stockfish Max'}")
        print("=" * 65)

    if not os.path.exists(STOCKFISH_PATH):
        if not quiet:
            print(f"[!] Stockfish not found at {STOCKFISH_PATH}")
        return {"match": match_num, "result": "Stockfish missing", "moves": 0, "brilliant": 0, "great": 0, "duration": 0.0}

    if not wait_for_bridge(timeout=15 if hud_callback else 600, stop_event=stop_event, quiet=quiet):
        if not quiet:
            print("[!] Timed out waiting for KaVach bridge.")
        return {"match": match_num, "result": "Bridge offline", "moves": 0, "brilliant": 0, "great": 0, "duration": 0.0}

    CACHED_CENTERS = {}

    init_fen, init_squares, init_centers = wait_for_board(stop_event=stop_event, quiet=quiet)
    if not init_fen:
        if not quiet:
            print("[!] No active Chess board detected on screen.")
        return {"match": match_num, "result": "No board found", "moves": 0, "brilliant": 0, "great": 0, "duration": 0.0}

    color_label = "♚ BLACK (Bottom of Screen)" if PLAYER_COLOR == chess.BLACK else "♔ WHITE (Bottom of Screen)"
    player_col_str = "black" if PLAYER_COLOR == chess.BLACK else "white"
    if not quiet:
        print(f" Playing Side: \033[1;36m{color_label}\033[0m")
    log_hud(f"Autopilot Match {match_num} started ({player_col_str})")
    _emit_chess_hud(
        hud_callback, push_hud,
        state="WORKING",
        title=f"Chess Autopilot · {player_col_str.title()}",
        current_action=f"Match {match_num} active ({player_col_str})",
        fen=init_fen,
        player_color=player_col_str,
        eval_cp="+0.0",
        turn_label="Your turn" if PLAYER_COLOR == chess.WHITE else "Waiting for White",
        logs=hud_logs,
        next_action="Calculating next move",
    )

    with _ENGINE_LOCK:
        engine = get_engine()
    ponderer = BackgroundPonderer(enabled=enable_ponder)
    animator = StatusAnimator(quiet=quiet)

    game_start_time = time.time()
    move_count = 0
    brilliant_count = 0
    great_count = 0
    consecutive_empty = 0
    last_ponder_hit = None
    last_move_dict = None
    last_eval_str = "+0.0"
    status = []

    persistent_board = chess.Board()
    move_history_uci = []
    seen_fens = []

    # Instant start on move 0: reuse already detected board & coordinates
    fen_str = init_fen
    centers = init_centers

    try:
        while move_count < max_moves:
            if not _wait_if_paused(pause_event, stop_event):
                status = ["Stopped by user"]
                break
            if move_count > 0:
                tree = get_tree()
                status = check_game_status(tree)
                if status:
                    if not quiet:
                        print(f"\n[🏆] MATCH OVER! Status: {status}")
                    break

                # Ensure board has not slipped into past-move review mode
                ensure_at_latest_move(persistent_board, tree)

                fen_str, squares, centers = parse_board_and_coords(tree=tree)
                if not fen_str:
                    time.sleep(0.15)
                    consecutive_empty += 1
                    if consecutive_empty == 20:
                        focus_window()
                    if consecutive_empty > 100:
                        if not quiet:
                            print("\n[!] Lost board connection or game concluded.")
                        break
                    continue
                consecutive_empty = 0

            # Handle Black side: if playing as Black from standard position, wait for White to play first move
            if PLAYER_COLOR == chess.BLACK and move_count == 0:
                if fen_str == "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR":
                    t_opp_wait = time.time()
                    while time.time() - t_opp_wait < 35.0:
                        if not _wait_if_paused(pause_event, stop_event):
                            status = ["Stopped by user"]
                            break
                        elapsed = time.time() - t_opp_wait
                        animator.step("Waiting for Opponent...", f"⏳ {elapsed:.1f}s | Waiting for White to make first move...", color="\033[93m")
                        time.sleep(0.12)
                        opp_fen, _, _ = parse_board_and_coords()
                        if opp_fen and opp_fen != "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR":
                            animator.clear(f" \033[92m⚡ [White Moved]\033[0m First move detected ({elapsed:.1f}s)")
                            fen_str = opp_fen
                            break
                    if stop_event and stop_event.is_set():
                        break
                    if fen_str == "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR":
                        if not quiet:
                            print("[!] Opponent has not made a move yet.")
                        continue

            # Synchronize board state with continuous move and castling tracking
            turn_str = 'w' if PLAYER_COLOR == chess.WHITE else 'b'
            if move_count == 0:
                if PLAYER_COLOR == chess.WHITE:
                    if fen_str == "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR":
                        persistent_board = chess.Board()
                    else:
                        persistent_board = chess.Board(f"{fen_str} w - - 0 1")
                else:
                    persistent_board = chess.Board()
                    opp_m = find_opponent_move(persistent_board, fen_str)
                    if opp_m:
                        san_opp0 = persistent_board.san(opp_m)
                        last_move_dict = move_uci_to_dict(opp_m.uci())
                        persistent_board.push(opp_m)
                        move_history_uci.append(opp_m.uci())
                        seen_fens.append(persistent_board.board_fen())
                        log_hud(f"Opponent played: {san_opp0}")
                        if not quiet:
                            print(f"[*] Opponent played: {san_opp0}")
                    else:
                        persistent_board = chess.Board(f"{fen_str} b - - 0 1")
                seen_fens.append(persistent_board.board_fen())
            else:
                opp_move = find_opponent_move(persistent_board, fen_str)
                if opp_move:
                    san_opp = persistent_board.san(opp_move)
                    last_move_dict = move_uci_to_dict(opp_move.uci())
                    persistent_board.push(opp_move)
                    move_history_uci.append(opp_move.uci())
                    seen_fens.append(persistent_board.board_fen())
                    log_hud(f"Opponent played: {san_opp}")
                    if not quiet:
                        print(f"[*] Opponent played: {san_opp}")
                else:
                    reconstructed = chess.Board()
                    valid_recon = True
                    for u_m in move_history_uci:
                        try:
                            reconstructed.push_uci(u_m)
                        except Exception:
                            valid_recon = False
                            break
                    if valid_recon and reconstructed.board_fen() == fen_str:
                        persistent_board = reconstructed
                    else:
                        castling = ""
                        if persistent_board.has_kingside_castling_rights(chess.WHITE): castling += "K"
                        if persistent_board.has_queenside_castling_rights(chess.WHITE): castling += "Q"
                        if persistent_board.has_kingside_castling_rights(chess.BLACK): castling += "k"
                        if persistent_board.has_queenside_castling_rights(chess.BLACK): castling += "q"
                        castling = castling or "-"
                        try:
                            persistent_board = chess.Board(f"{fen_str} {turn_str} {castling} - 0 {move_count + 1}")
                        except Exception:
                            persistent_board = chess.Board(f"{fen_str} {turn_str} - - 0 {move_count + 1}")
                    seen_fens.append(persistent_board.board_fen())

            if persistent_board.is_game_over():
                print("\n" + "=" * 65)
                print(f" 🏆 GAME OVER! Result: {persistent_board.result()} | Outcome: {persistent_board.outcome()}")
                print("=" * 65)
                break

            seen_fens.append(persistent_board.board_fen())

            # Check if pre-calculated from Ponder Hit
            move = None
            score_cp = None
            badge = None
            is_brill = False
            is_great = False
            annotation = ""
            calc_ms = 0.0

            if last_ponder_hit and last_ponder_hit.get("reply") in persistent_board.legal_moves:
                hit_m = last_ponder_hit["reply"]
                test_b = persistent_board.copy()
                test_b.push(hit_m)
                # Anti-draw check on ponder move
                is_repeat = (seen_fens and seen_fens.count(test_b.board_fen()) >= 1) or test_b.is_repetition(2)
                if not is_repeat:
                    move = hit_m
                    score_cp = last_ponder_hit.get("score_cp")
                    badge = last_ponder_hit.get("badge", "⚡ PONDER (0ms)")
                    annotation = last_ponder_hit.get("annot", "Pre-calculated on opponent turn")
                    calc_ms = 0.0

                    # Human Grandmaster placing reflex with animated indicator
                    react_delay = random.uniform(0.35, 0.65)
                    t_react = time.time()
                    san_m = persistent_board.san(move)
                    while time.time() - t_react < react_delay:
                        animator.step("Human Reflex...", f"⚡ Placing {san_m} on board...", color="\033[96m")
                        time.sleep(0.08)
                    animator.clear()
            last_ponder_hit = None

            if not move:
                animator.step("Human Grandmaster Thinking...", "🧠 Calculating optimal continuation...", color="\033[96m")
                with _ENGINE_LOCK:
                    engine, move, score_cp, badge, is_brill, is_great, annotation, calc_ms = calculate_intelligent_move(
                        engine, persistent_board, move_history_uci, target_depth=depth, hunt_brilliant=hunt_brilliant, trainer=trainer, seen_fens=seen_fens
                    )
                animator.clear()

            if not move:
                if not quiet:
                    print("\n[!] No legal moves found.")
                break

            san = persistent_board.san(move)
            from_sq = chess.square_name(move.from_square)
            to_sq = chess.square_name(move.to_square)

            if is_brill:
                brilliant_count += 1
            if is_great:
                great_count += 1

            move_count += 1
            elapsed_total = time.time() - game_start_time
            white_cp = score_cp if (score_cp is not None and PLAYER_COLOR == chess.WHITE) else (-score_cp if score_cp is not None else None)
            last_eval_str = format_eval_cp(white_cp)
            our_move_dict = {"from": from_sq, "to": to_sq}

            log_hud(f"Move {move_count:02d}: {san} ({from_sq}->{to_sq}) | Eval {last_eval_str} | {badge}")
            if not quiet:
                print(f"\n[Move {move_count:02d}] {san:<8} ({from_sq}->{to_sq}) | {badge} [{calc_ms:.0f}ms, Total: {elapsed_total:.1f}s]")
                print(render_hud(persistent_board, move, score_cp, badge, annotation))

            # Push move to persistent history
            persistent_board.push(move)
            expected_fen = persistent_board.board_fen()
            seen_fens.append(expected_fen)
            move_history_uci.append(move.uci())
            last_move_dict = our_move_dict

            _emit_chess_hud(
                hud_callback, push_hud,
                state="WORKING",
                title=f"Chess Autopilot · {player_col_str.title()}",
                current_action=f"Played {san} ({last_eval_str})",
                fen=expected_fen,
                player_color=player_col_str,
                eval_cp=last_eval_str,
                last_move=our_move_dict,
                best_move=our_move_dict,
                turn_label=f"Move {move_count} · {san}",
                detailed_output=f"Move {move_count}: {san} ({from_sq}->{to_sq})\nEval: {last_eval_str}\n{badge}\n{annotation}",
                logs=hud_logs,
                next_action="Waiting for opponent move" if move_count < max_moves else "Finishing",
            )

            # Physical execution
            from_coords = centers.get(from_sq) or CACHED_CENTERS.get(from_sq)
            to_coords = centers.get(to_sq) or CACHED_CENTERS.get(to_sq)

            if not from_coords or not to_coords:
                bx, by, sq = 887.0, 213.0, 56.0
                from_coords = (int(bx + (FILES.index(from_sq[0]) + 0.5) * sq), int(by + (RANKS.index(from_sq[1]) + 0.5) * sq))
                to_coords = (int(bx + (FILES.index(to_sq[0]) + 0.5) * sq), int(by + (RANKS.index(to_sq[1]) + 0.5) * sq))

            # Strictly clamp all board coordinates to safe physical fence (Rank 1-8, Files a-h)
            from_x, from_y = clamp_board_coords(from_coords[0], from_coords[1])
            to_x, to_y = clamp_board_coords(to_coords[0], to_coords[1])

            # Physical execution with Active Confirmation & Instant Retry
            max_tap_retries = 3
            move_registered = False

            for tap_attempt in range(max_tap_retries):
                if tap_attempt == 0:
                    board_tap(from_x, from_y)
                    time.sleep(0.18)
                    board_tap(to_x, to_y)
                else:
                    # High-reliability physical drag-and-drop fallback inside board bounds
                    print(f"[*] Executing clamped drag gesture: {from_sq}->{to_sq} (({from_x}, {from_y}) -> ({to_x}, {to_y}))...")
                    board_swipe(from_x, from_y, to_x, to_y, duration_ms=250)

                # Auto-promote to Queen
                if move.promotion:
                    t_prom = time.time()
                    q_found = False
                    while time.time() - t_prom < 2.5:
                        cur_t = get_tree()
                        def find_q(node):
                            nonlocal q_found
                            if q_found: return
                            d = (node.get("contentDescription") or "").lower()
                            t = (node.get("text") or "").lower()
                            if "queen" in d or "queen" in t:
                                b = node.get("bounds", "")
                                m = re.search(r"\[(\d+),(\d+)\]\[(\d+),(\d+)\]", b)
                                if m:
                                    qx = (int(m.group(1)) + int(m.group(3))) // 2
                                    qy = (int(m.group(2)) + int(m.group(4))) // 2
                                    send_tap(qx, qy)
                                    q_found = True
                                    print(f"[✓] Auto-promoted to Queen at ({qx}, {qy})")
                                    return
                            for c in node.get("children", []):
                                find_q(c)
                        for n in cur_t.get("nodes", []):
                            find_q(n)
                        if q_found:
                            break
                        time.sleep(0.12)
                    if not q_found:
                        board_tap(to_x, to_y)

                # Confirm our move registered on screen
                t_conf = time.time()
                while time.time() - t_conf < 0.8:
                    cur_fen, _, _ = parse_board_and_coords()
                    if cur_fen == expected_fen:
                        move_registered = True
                        break
                    if cur_fen and find_opponent_move(persistent_board, cur_fen):
                        move_registered = True
                        break
                    time.sleep(0.1)

                if move_registered:
                    break
                else:
                    if tap_attempt < max_tap_retries - 1:
                        print(f"[*] Move tap not yet reflected on screen, checking review mode and retrying (attempt {tap_attempt + 2}/{max_tap_retries})...")
                        ensure_at_latest_move(persistent_board, force=True)
                        time.sleep(0.15)

            if persistent_board.is_game_over() or move_count >= max_moves:
                break

            # START BACKGROUND PONDERING ON OPPONENT'S TURN
            ponderer.start_ponder(persistent_board, PLAYER_COLOR)

            # Step 2: Resilient wait for opponent to move with live status animation
            t_wait = time.time()
            opponent_responded = False
            opp_m = None
            while time.time() - t_wait < 120.0:
                if not _wait_if_paused(pause_event, stop_event):
                    status = ["Stopped by user"]
                    break
                elapsed_wait = time.time() - t_wait
                p_cnt = ponderer.get_cache_size()
                detail = f"⏳ {elapsed_wait:.1f}s | 🧠 Pondering {p_cnt} reply lines..." if p_cnt else f"⏳ {elapsed_wait:.1f}s | ♟️ Opponent thinking..."
                animator.step("Waiting for Opponent...", detail, color="\033[93m")

                time.sleep(0.40)  # Gentle 400ms polling interval (eliminates Android Accessibility lag)
                cur_tree = get_tree()
                cur_status = check_game_status(cur_tree)
                if cur_status:
                    status = cur_status
                    animator.clear()
                    break

                if elapsed_wait > 8.0 and int(elapsed_wait * 10) % 50 == 0:
                    ensure_at_latest_move(persistent_board, cur_tree)

                cur_fen, _, _ = parse_board_and_coords(tree=cur_tree)
                if cur_fen and cur_fen != expected_fen:
                    opp_m = find_opponent_move(persistent_board, cur_fen)
                    if opp_m:
                        opponent_responded = True
                        break

            ponderer.stop_ponder()

            if stop_event and stop_event.is_set():
                break

            if not opponent_responded:
                animator.clear()
                final_tree = get_tree()
                if check_game_status(final_tree):
                    if not quiet:
                        print("\n[🏆] Match concluded! Dialog detected.")
                    break
                break

            # Opponent moved! Check for ponder hit
            hit = ponderer.get_hit(opp_m.uci())
            san_opp = persistent_board.san(opp_m)
            last_move_dict = move_uci_to_dict(opp_m.uci())
            log_hud(f"Opponent played: {san_opp} ({elapsed_wait:.1f}s)")
            if hit:
                animator.clear(f" \033[92m⚡ [PONDER HIT / Instant Reflex]\033[0m Opponent played: \033[1m{san_opp}\033[0m ({elapsed_wait:.1f}s) | Pre-calculated reply ready!")
                last_ponder_hit = hit
            else:
                animator.clear(f" \033[92m✓ [Opponent Moved]\033[0m Opponent played: \033[1m{san_opp}\033[0m ({elapsed_wait:.1f}s)")
                last_ponder_hit = None

    finally:
        ponderer.cleanup()
        animator.clear()
        import gc
        gc.collect()

    # Keep GLOBAL_ENGINE warm for instant next game startup!
    total_time = time.time() - game_start_time
    was_stopped = bool(stop_event and stop_event.is_set())
    result_str = "Stopped by user" if was_stopped else "Match Concluded"
    if not was_stopped:
        if persistent_board.is_checkmate():
            result_str = "Checkmate Victory"
        elif status:
            result_str = f"Ended ({status[0] if isinstance(status, list) else status})"

    if trainer:
        trainer.complete_match(match_num, "Maximum (3200)", result_str, total_time, brilliant_count, great_count, move_count)

    log_hud(f"Finished: {result_str} ({move_count} moves, {brilliant_count} !!, {great_count} !)")
    _emit_chess_hud(
        hud_callback, push_hud,
        state="STOPPED" if was_stopped else "DONE",
        title=f"Chess Autopilot · {player_col_str.title()}",
        current_action=f"{result_str} ({move_count} moves)",
        fen=persistent_board.board_fen(),
        player_color=player_col_str,
        eval_cp=last_eval_str,
        last_move=last_move_dict,
        turn_label=result_str[:28],
        detailed_output=(
            f"Result: {result_str}\n"
            f"Moves: {move_count} | Brilliant: {brilliant_count} (!!) | Great: {great_count} (!)\n"
            f"Eval: {last_eval_str} | Duration: {total_time:.1f}s"
        ),
        logs=hud_logs,
    )

    if not quiet:
        print("\n" + "=" * 65)
        print(" 🏁 MATCH COMPLETED")
        print(f" Result         : {result_str}")
        print(f" Total Moves    : {move_count}")
        print(f" Brilliant Moves: {brilliant_count} (!!)")
        print(f" Great Moves    : {great_count} (!)")
        print(f" Match Duration : {total_time:.1f} seconds ({total_time/60:.2f} mins)")
        print("=" * 65)

    return {
        "match": match_num,
        "result": result_str,
        "moves": move_count,
        "brilliant": brilliant_count,
        "great": great_count,
        "duration": round(total_time, 1),
        "fen": persistent_board.board_fen(),
        "evalCp": last_eval_str,
        "lastMove": last_move_dict,
        "playerColor": player_col_str,
    }

def play_tournament(
    matches=5,
    depth=20,
    hunt_brilliant=True,
    max_moves=120,
    enable_ponder=False,
    stop_event=None,
    pause_event=None,
    hud_callback=None,
    push_hud=True,
    quiet=False,
):
    trainer = NeuralTrainer()
    if not quiet:
        print("=" * 65)
        print(" 🏆 AUTONOMOUS 5-MATCH TOURNAMENT vs MAXIMUM (3200)")
        print(f" Matches to Play : {matches}")
        print(f" Engine          : Stockfish 19 UCI + NNUE (Adaptive Depth {depth})")
        print(f" Mode            : {'⚡ Eco-Lite (1 Thread, 0% Opponent CPU, Anti-Lag)' if not enable_ponder else 'Anticipation Pondering'}")
        print(f" Neural Memory   : {len(trainer.memory['positions'])} Learned Positions")
        print("=" * 65)

    tournament_results = []
    for m_idx in range(1, matches + 1):
        if stop_event and stop_event.is_set():
            break
        if not quiet:
            print("\n" + "#" * 65)
            print(f"  STARTING MATCH {m_idx} OF {matches} vs MAXIMUM (3200)")
            print("#" * 65)

        stats = play_game(
            depth=depth,
            hunt_brilliant=hunt_brilliant,
            max_moves=max_moves,
            trainer=trainer,
            match_num=m_idx,
            enable_ponder=enable_ponder,
            stop_event=stop_event,
            pause_event=pause_event,
            hud_callback=hud_callback,
            push_hud=push_hud,
            quiet=quiet,
        )
        tournament_results.append(stats)

        # Capture post-match screenshot
        try:
            req_cap = urllib.request.Request(f"{get_api_url()}/api/screen/capture", data=json.dumps({"quality": 85, "maxDimension": 1440}).encode(), headers=get_headers())
            resp = json.loads(urllib.request.urlopen(req_cap, timeout=5).read().decode())
            raw_b64 = resp.get("data") or resp.get("base64")
            if resp.get("success") and raw_b64:
                import base64
                img_data = base64.b64decode(raw_b64)
                cap_path = f"/data/data/com.termux/files/home/.gemini/antigravity-cli/brain/bcab2866-3535-4ad0-bf63-e39399ac377e/tournament_match_{m_idx}_result.jpg"
                with open(cap_path, "wb") as f: f.write(img_data)
                print(f"[✓] Saved match {m_idx} screenshot: {cap_path}")
        except Exception as e:
            print(f"[!] Screenshot capture error: {e}")

        if m_idx < matches:
            print(f"\n[*] Initiating Rematch for Match {m_idx + 1}...")
            time.sleep(0.5)
            tree = get_tree()
            rematch_tapped = False
            for n in tree.get("nodes", []):
                def find_rematch(node):
                    nonlocal rematch_tapped
                    if rematch_tapped: return
                    t = (node.get("text") or "").strip().lower()
                    d = (node.get("contentDescription") or "").strip().lower()
                    if "rematch" in t or "rematch" in d:
                        b = node.get("bounds", "")
                        m = re.search(r"\[(\d+),(\d+)\]\[(\d+),(\d+)\]", b)
                        if m:
                            rx = (int(m.group(1)) + int(m.group(3))) // 2
                            ry = (int(m.group(2)) + int(m.group(4))) // 2
                            send_tap(rx, ry)
                            rematch_tapped = True
                            print(f"[✓] Rematch tapped at ({rx}, {ry})")
                            return
                    for c in node.get("children", []): find_rematch(c)
                find_rematch(n)

            if not rematch_tapped:
                for n in tree.get("nodes", []):
                    def find_new(node):
                        nonlocal rematch_tapped
                        if rematch_tapped: return
                        t = (node.get("text") or "").strip().lower()
                        d = (node.get("contentDescription") or "").strip().lower()
                        if any(k in t or k in d for k in ["new game", "play again", "next bot"]):
                            b = node.get("bounds", "")
                            m = re.search(r"\[(\d+),(\d+)\]\[(\d+),(\d+)\]", b)
                            if m:
                                rx = (int(m.group(1)) + int(m.group(3))) // 2
                                ry = (int(m.group(2)) + int(m.group(4))) // 2
                                send_tap(rx, ry)
                                rematch_tapped = True
                                print(f"[✓] New Game tapped at ({rx}, {ry})")
                                return
                    find_new(n)

            # Fast polling for board reset to starting position
            t_reset = time.time()
            while time.time() - t_reset < 6.0:
                cur_f, _, _ = parse_board_and_coords()
                if cur_f and cur_f == "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR":
                    print("[✓] Fresh board detected!")
                    break
                time.sleep(0.12)

    print("\n" + "=" * 65)
    print(" 🏁 5-MATCH TOURNAMENT CONCLUDED")
    print(f" Total Neural Memory Size: {len(trainer.memory['positions'])} positions")
    for r in tournament_results:
        print(f" Match {r['match']}: {r['result']} | Moves: {r['moves']} | {r['brilliant']} !! | {r['great']} ! | Time: {r['duration']}s")
    print("=" * 65)
    return tournament_results

def inspect_status(as_json=False, push_hud=True, depth=18):
    if not wait_for_bridge(timeout=10, quiet=as_json):
        res = {"success": False, "error": f"KaVach bridge at {get_api_url()} is not active."}
        print(json.dumps(res, indent=2) if as_json else f"[!] {res['error']}")
        return res
    res = analyze_screen_position(depth=depth, multipv=1, time_limit=0.2)
    if not res.get("success"):
        print(json.dumps(res, indent=2) if as_json else f"[!] {res.get('error')}")
        return res
    if push_hud:
        _emit_chess_hud(
            None, True,
            state="DONE",
            title=f"Chess Eval · {res['playerColor'].title()}",
            current_action=f"Eval {res['evalCp']} · Best {res['bestSan']} ({res['winProb']}% win)",
            fen=res["fen"],
            player_color=res["playerColor"],
            eval_cp=res["evalCp"],
            best_move=res["bestMove"],
            turn_label=res["turnLabel"],
            detailed_output=f"Eval: {res['evalCp']} | Best Move: {res['bestSan']} ({res['bestUci']}) | Win Prob: {res['winProb']}%",
        )
    if as_json:
        clean_res = {k: v for k, v in res.items() if k not in ("board", "centers")}
        print(json.dumps(clean_res, indent=2))
        return clean_res
    print(render_hud(res["board"], None, res["scoreCp"], "⚡ LIVE SCREEN BOARD"))
    return res

def suggest_moves(as_json=False, push_hud=True, depth=20):
    if not wait_for_bridge(timeout=10, quiet=as_json):
        res = {"success": False, "error": f"KaVach bridge at {get_api_url()} is not active."}
        print(json.dumps(res, indent=2) if as_json else f"[!] {res['error']}")
        return res
    res = analyze_screen_position(depth=depth, multipv=3, time_limit=0.35)
    if not res.get("success"):
        print(json.dumps(res, indent=2) if as_json else f"[!] {res.get('error')}")
        return res
    lines_txt = []
    for i, var in enumerate(res["variations"]):
        motif_str = f" | {', '.join(var['motifs'])}" if var.get("motifs") else ""
        lines_txt.append(f"{i+1}. {var['san']} ({var['uci']}) · {var['evalCp']}{motif_str}")
    summary_body = f"Eval: {res['evalCp']} ({res['winProb']}% win)\n" + "\n".join(lines_txt)
    if push_hud:
        _emit_chess_hud(
            None, True,
            state="DONE",
            title=f"Chess Best Move · {res['bestSan']}",
            current_action=f"Best: {res['bestSan']} ({res['evalCp']})",
            fen=res["fen"],
            player_color=res["playerColor"],
            eval_cp=res["evalCp"],
            best_move=res["bestMove"],
            turn_label=res["turnLabel"],
            detailed_output=summary_body,
        )
    if as_json:
        clean_res = {k: v for k, v in res.items() if k not in ("board", "centers")}
        print(json.dumps(clean_res, indent=2))
        return clean_res
    print(render_hud(res["board"], None, res["scoreCp"]))
    print("\nTop Suggested Moves (Grandmaster Intelligence):")
    for ln in lines_txt:
        print(f"  {ln}")
    return res

def main(argv=None):
    global COLOR_OVERRIDE
    parser = argparse.ArgumentParser(description="Autonomous High-Speed Chess Engine for Chess.com")
    parser.add_argument("command", nargs="?", default="play", choices=["play", "tournament", "status", "suggest"], help="Command to run")
    parser.add_argument("--depth", type=int, default=20, help="Stockfish calculation depth (default: 20)")
    parser.add_argument("--no-brilliant", action="store_true", help="Disable brilliant sacrifice hunting")
    parser.add_argument("--max-moves", type=int, default=120, help="Max moves per match before stopping (default: 120)")
    parser.add_argument("--matches", type=int, default=5, help="Number of tournament matches (default: 5)")
    parser.add_argument("--ponder", action="store_true", help="Enable background pondering (default: False for 0%% idle CPU and zero lag)")
    parser.add_argument("--color", choices=["auto", "white", "black"], default="auto", help="Assume bottom of screen is mine (default: auto, or force white/black)")
    parser.add_argument("--url", default=None, help="Explicit KaVach bridge HTTP URL override (default: ~/.aura_target_url or http://127.0.0.1:8080)")
    parser.add_argument("--no-hud", action="store_true", help="Disable live /api/hud/state Chess TaskMap telemetry")
    parser.add_argument("--json", action="store_true", help="Emit structured JSON output for status/suggest")
    args = parser.parse_args(argv)

    if args.url:
        set_bridge_target(url=args.url)

    if args.color == "white":
        COLOR_OVERRIDE = chess.WHITE
    elif args.color == "black":
        COLOR_OVERRIDE = chess.BLACK
    else:
        COLOR_OVERRIDE = None

    push_hud = not args.no_hud
    if args.command == "play":
        trainer = NeuralTrainer()
        play_game(depth=args.depth, hunt_brilliant=not args.no_brilliant, max_moves=args.max_moves, trainer=trainer, enable_ponder=args.ponder, push_hud=push_hud)
    elif args.command == "tournament":
        play_tournament(matches=args.matches, depth=args.depth, hunt_brilliant=not args.no_brilliant, max_moves=args.max_moves, enable_ponder=args.ponder, push_hud=push_hud)
    elif args.command == "status":
        inspect_status(as_json=args.json, push_hud=push_hud, depth=args.depth)
    elif args.command == "suggest":
        suggest_moves(as_json=args.json, push_hud=push_hud, depth=args.depth)

if __name__ == "__main__":
    try:
        main()
    finally:
        cleanup_engine()
