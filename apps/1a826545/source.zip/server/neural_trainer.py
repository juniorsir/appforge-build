#!/usr/bin/env python3
"""
Neural Experience & Fast Thinking Engine (neural_trainer.py)
Accumulates neural NNUE evaluations, tactical motifs, and optimal lines
into a persistent memory bank for 0ms instant retrieval and progressive training.
"""

import os
import json
import time
import chess

MEMORY_FILE = os.path.expanduser("~/.chess_neural_memory.json")
MATCH_LOG_FILE = os.path.expanduser("~/.chess_matches_history.json")

class NeuralTrainer:
    def __init__(self):
        self.memory = self.load_memory()
        self.history = self.load_history()
        self.current_game_moves = []

    def load_memory(self):
        if os.path.exists(MEMORY_FILE):
            try:
                with open(MEMORY_FILE, "r") as f:
                    return json.load(f)
            except Exception:
                pass
        return {"positions": {}, "patterns": {}, "brilliant_lines": []}

    def load_history(self):
        if os.path.exists(MATCH_LOG_FILE):
            try:
                with open(MATCH_LOG_FILE, "r") as f:
                    return json.load(f)
            except Exception:
                pass
        return []

    def save_memory(self):
        try:
            with open(MEMORY_FILE, "w") as f:
                json.dump(self.memory, f, indent=2)
        except Exception as e:
            print(f"[!] Error saving neural memory: {e}")

    def save_history(self):
        try:
            with open(MATCH_LOG_FILE, "w") as f:
                json.dump(self.history, f, indent=2)
        except Exception as e:
            print(f"[!] Error saving match history: {e}")

    def query_fast_thinking(self, board):
        """
        0ms Neural Cache:
        If position has been solved with high confidence in previous games,
        return the learned best move instantly without waiting for Stockfish search.
        """
        fen_key = board.board_fen()
        entry = self.memory["positions"].get(fen_key)
        if entry:
            score = entry.get("score_cp")
            # Quality filter: only replay fast thinking if position is sound (neutral or winning)
            if score is not None and score < -30:
                return None, None, None, None
            move_uci = entry.get("best_move")
            if move_uci:
                m = chess.Move.from_uci(move_uci)
                if m in board.legal_moves:
                    return m, score or 0, entry.get("badge", "🧠 NEURAL (0ms)"), entry.get("annotation", "Trained Neural Experience")
        return None, None, None, None

    def record_move(self, board_fen, move_uci, score_cp, badge, annotation, calc_ms):
        """Records position evaluation into the neural memory bank."""
        self.current_game_moves.append({
            "fen": board_fen,
            "move": move_uci,
            "score_cp": score_cp,
            "badge": badge,
            "calc_ms": calc_ms,
            "timestamp": time.time()
        })

        # Update persistent position memory if quality is high
        if board_fen not in self.memory["positions"] or (score_cp is not None and score_cp > 100):
            self.memory["positions"][board_fen] = {
                "best_move": move_uci,
                "score_cp": score_cp,
                "badge": badge,
                "annotation": annotation,
                "visits": self.memory["positions"].get(board_fen, {}).get("visits", 0) + 1,
                "updated_at": time.time()
            }

        if "BRILLIANT" in badge.upper() or "GREAT" in badge.upper():
            if move_uci not in self.memory["brilliant_lines"]:
                self.memory["brilliant_lines"].append({
                    "fen": board_fen,
                    "move": move_uci,
                    "score_cp": score_cp,
                    "badge": badge
                })

    def complete_match(self, match_num, opponent, result, duration_sec, brilliant_cnt, great_cnt, total_moves):
        """Finalizes match stats, commits neural training, and logs tournament record."""
        record = {
            "match": match_num,
            "opponent": opponent,
            "result": result,
            "duration_sec": round(duration_sec, 1),
            "moves": total_moves,
            "brilliant_moves": brilliant_cnt,
            "great_moves": great_cnt,
            "learned_positions": len(self.current_game_moves),
            "total_neural_memory_size": len(self.memory["positions"]),
            "timestamp": time.time()
        }
        self.history.append(record)
        self.save_memory()
        self.save_history()
        self.current_game_moves = []
        return record
