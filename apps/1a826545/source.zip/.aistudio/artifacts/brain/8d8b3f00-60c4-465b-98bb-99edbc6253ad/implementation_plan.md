# Animated Apple Liquid Glass HUD Redesign

Redesigns the floating main HUD into a translucent Apple Liquid Glass command surface synchronized with the second window, replacing static white cards and text symbols with crisp vector controls, a Dynamic Island-style morphing pill, and layered 60fps Canvas and spring animations.

---

## User Review & Critical Decisions

> [!IMPORTANT]
> Because the interactive question prompt hit a frontend error, the plan below uses the recommended defaults aligned with your previous Apple glass UI preference. Review these choices before proceeding—reply with any adjustments or click **Proceed** to start building.

- **Visual Theme (Default: Apple Liquid Glass Dark)**: Switches the default HUD look to translucent frosted dark-slate glass with a top specular edge highlight, crisp white hairline rim, and luminous state accents—matching the redesigned second window while preserving remote JSON overrides for light or custom themes.
- **Animation Suite (Full Motion Upgrade)**: Adds a breathing/sonar status orb, live multi-bar waveform in collapsed and voice states, sweeping glass sheen reflections, spring pill-to-card morphing, stroke-drawn task checkmarks, shimmer progress bars, and staggered tray/task reveals.
- **Layout Footprint (Compact Dynamic Island + Focused Card)**: Keeps the HUD sleek and compact when collapsed (living orb, animated step ticker, live waveform/timer, and stop control) and cleanly structured when expanded.

---

## 1. Overview & Core Concept

- **What It Does**: Elevates the primary floating HUD from a flat white card with basic spinners into a fluid, responsive glass cockpit that visually communicates AI state, live step progress, voice activity, and user prompts through continuous motion rather than static text.
- **Target User & Context**: On-device automation and Termux/overlay users who glance at the floating HUD while interacting with underlying apps and need instant, unmistakable visual feedback without screen clutter.
- **Key Value**: Creates visual unity between the main HUD and the second visual window, makes active/paused/input/done states readable at a glance via motion cues, and delivers crisp tactile responsiveness on every tap and transition.

---

## 2. User Experience & Visual Design

### Key User Flows

1. **Idle & Collapsed Dynamic Island Pill**: The HUD rests as a compact frosted dark-glass capsule featuring a softly breathing violet/cyan status orb, crisp status label, and an illuminated Ask Agy pill.
2. **Active Task Execution (`WORKING`)**: The collapsed pill smoothly morphs to display the active app/step icon inside a rotating comet ring, a live step ticker that slides vertically on step changes, miniature animated activity waveform bars, elapsed timer, and a coral vector stop button.
3. **Spring Morph Expansion**: Tapping the pill springs open the full Apple Liquid Glass card (`alpha`, `scale`, `translationY`, and specular glass sheen sweep), revealing the sweeping aurora rim, animated shimmer progress bar, active step spotlight row, staggered task checklist, and unified bottom composer.
4. **Step Completion & Done Celebration**: As individual steps complete, each row's indicator animates a smooth stroke-drawn emerald checkmark with an overshoot pop; finishing the run triggers an emerald halo ripple and glass sheen sweep across the card before auto-collapsing.
5. **Voice, Approval & Tools Tray**: Tapping the mic transforms the composer rim into a multi-color reactive sweep with bouncing waveform bars; tapping the overflow menu reveals a frosted glass tools tray with crisp vector glyph toggles (Map, Opacity, Ghost, Snap, Pointer, Snip, Edge, Record, Pad, Diff, Voice).

### Visual Identity & Theme

- **Aesthetic Direction**: Apple Liquid Glass dark cockpit—translucent layered obsidian-slate surfaces, subtle top-edge specular glass rim, crisp hairline borders, zero emoji clutter on controls, and disciplined luminous accents.
- **Color Palette & Mood**:
  - Primary glass fill: deep translucent midnight slate (`#D90B1120`) with secondary inner capsule fill (`#B8162038`).
  - Glass border & specular edge: translucent white hairline (`#38FFFFFF`) with a soft top-lip sheen (`#52FFFFFF`).
  - Typography: high-contrast crisp white primary (`#F8FAFC`), cool slate secondary (`#94A3B8`), monospace tabular timers.
  - State accents: Electric Cyan (`#38BDF8` / `#0095F6`) for Working, Violet (`#818CF8`) for Ready/Idle, Warm Amber (`#F59E0B`) for Paused / Needs Input, Emerald (`#22C55E`) for Done, and Coral (`#F43F5E`) for Stopping / Voice Active.
- **Typography & Component Styling**: Bold sans-serif headers and active step callouts paired with compact monospace elapsed timers and progress metrics; unified SF Symbols-style Canvas vector icons replacing legacy text glyphs (`···`, `─`, `■`, `▲/▼`, tool emojis).

### Interactive Feedback & Motion

- **Living Status Orb & Sonar Ripples**: Replaces the static 6dp dot with a multi-ring Canvas orb—soft radial core breath when idle, orbiting dual-arc comet + expanding sonar pulse when working, warm rhythmic breath when awaiting input.
- **Live Activity & Voice Waveform**: Multi-bar Canvas equalizer that gently ripples with phase modulation during active execution or voice capture, pausing cleanly when detached or collapsed.
- **Specular Glass Sheen & Aurora Halo**: Adds a diagonal translucent white specular sheen sweep across the card on expand, state change, and completion, layered atop the existing sweeping aurora border and ambient inner halo.
- **Choreographed Task Rows & Path-Drawn Checkmarks**: Staggered vertical spring entry for task lists, subtle accent shimmer highlight on the active `doing` row, and `PathMeasure` progressive checkmark stroke draw + spring pop on transition to `done`.
- **Tactile Micro-Interactions**: Spring press compression (`0.93x` -> overshoot `1.0x`) with subtle haptic feedback on every pill, chip, vector button, and long-press drag lift.

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1: Translucent Dark Glass Default with Remote Override Preservation**
  - *Chosen Approach*: Update default resolved theme configuration to Apple Liquid Glass dark while honoring explicit `"mode": "light"` or `"custom"` overrides sent via state updates.
  - *Why*: Matches the redesigned diagrams/video window immediately out of the box without breaking remote theming APIs.
  - *Alternatives Considered*: Keeping white default unless toggled (rejected because the default launch look would remain unchanged).
- **Decision 2: Native Canvas & Animator Views Over Heavy External Animation Libraries**
  - *Chosen Approach*: Build custom 60fps Canvas views (status orb, waveform, path-drawn checkmark, glass sheen card) and Android property/value animators that auto-pause on `onDetachedFromWindow()` and collapse.
  - *Why*: Zero added APK size/dependency overhead, reliable rendering inside `WindowManager` system overlay contexts, and full battery safety when hidden.
  - *Alternatives Considered*: Adding Lottie JSON assets (rejected to keep bundle lightweight and allow instant dynamic state/accent recoloring).
- **Decision 3: Preserve Existing Coordinator & View Contracts**
  - *Chosen Approach*: Keep all accessibility `contentDescription`/`testTag` identifiers, long-press drag behavior, and `AgyOverlayLayoutCoordinator` sizing hooks intact while upgrading the visual surfaces and animators underneath.
  - *Why*: Ensures second-window left/above docking, auto-dodge, IME keyboard handoff, and existing Robolectric/UI automation tests continue working seamlessly.

---

## 4. Technical Architecture & Data Strategy *(Technical Reference)*

```
┌───────────────────────────────────────────────────────────────────────────┐
│                        AgyHudOverlayManager                               │
│  (StateFlow<AgyHudState> · Collapse/Expand Lifecycle · Coordinator Sync)  │
└───────────────┬───────────────────────────────────────────┬───────────────┘
                │                                           │
                ▼                                           ▼
┌───────────────────────────────┐           ┌───────────────────────────────┐
│   Collapsed Dynamic Island    │           │   Expanded Liquid Glass Card  │
│        (Bottom Dock Pill)     │           │    (AgyAuroraCardLayout)      │
│                               │           │                               │
│ • AgyStatusOrbView / Spinner  │◄─Spring──►│ • Specular Glass Sheen Sweep  │
│ • Live Step Slide Ticker      │  Morph    │ • Shimmer Progress Bar        │
│ • AgyWaveformBarsView         │           │ • Vector Header & Tools Tray  │
│ • Vector Stop / Ask Pill      │           │ • Staggered Tasks + CheckDraw │
│                               │           │ • Unified Voice/Text Composer │
└───────────────┬───────────────┘           └───────────────┬───────────────┘
                │                                           │
                └───────────────────┬───────────────────────┘
                                    ▼
┌───────────────────────────────────────────────────────────────────────────┐
│              Shared Canvas Animation & Vector Primitive Layer             │
│  AgyAuroraCardLayout · AgyStatusOrbView · AgyWaveformBarsView             │
│  AgyAnimatedCheckView · AgyLoadingBarView · AgyAppleVectorIconView        │
└───────────────────────────────────────────────────────────────────────────┘
```

### Data Model & State Mapping

- **Theme Defaults**: Default theme model resolves to Apple Liquid Glass dark tokens (`surface`, `secondarySurface`, `border`, `textPrimary`, `textSecondary`, specular highlight tint) unless explicitly overridden.
- **Animation Lifecycle Binding**: Every custom Canvas animator binds to both `isAttachedToWindow` and active visibility/collapse state (`!isCollapsed` for expanded views, `isCollapsed` for dock views), cancelling animators deterministically on detach or reset so zero background frame loops leak.
- **Interactive Component Mapping**:
  - Header controls (`stepsTogglePill`, `toolsMenuBtn`, `headerCollapseBtn`) & tools tray toggles use crisp vector glyphs (`AgyAppleVectorIconView` / `AgyGlyphButtonView`) with spring press feedback and active accent fills.
  - Collapsed pill click & double-tap continue driving expand + optional composer focus while triggering the spring morph + glass sheen reveal.
  - Task row state diffs (`prevStatuses` -> `nextStatus`) trigger `AgyAnimatedCheckView.playCheckAnimation()` only when a task newly transitions to `done`, avoiding distracting replays on unrelated state updates.
  - Bottom composer voice button animates live `AgyWaveformBarsView` alongside the voice aurora sweep while listening is active.
