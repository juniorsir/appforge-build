package com.kavach.ui.overlay

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.GppBad
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kavach.ui.theme.CrispBorder
import com.kavach.ui.theme.CrispHairline
import com.kavach.ui.theme.CrispInkPrimary
import com.kavach.ui.theme.CrispInkSecondary
import com.kavach.ui.theme.CrispSurfaceSubtle
import com.kavach.ui.theme.LiquidGlassTokens
import com.kavach.ui.theme.LiquidIconOrb
import kotlinx.coroutines.delay
import java.lang.ref.WeakReference

/**
 * High-priority Liquid Glass visual block screen activity.
 * Guaranteed to appear on top of all applications when a restricted or adult
 * website/app/query is blocked by AeroShare network moderation or Adult Content Shield.
 */
class BlockScreenActivity : ComponentActivity() {

    private data class BlockScreenUiState(
        val domain: String,
        val reason: String,
        val category: String,
        val customMessage: String,
        val autoDismissSeconds: Int,
        val isPreview: Boolean,
        val version: Int
    )

    private var uiState by mutableStateOf(
        BlockScreenUiState(
            domain = "restricted-site.com",
            reason = "Content Policy",
            category = "RESTRICTED",
            customMessage = "Restricted content is not allowed on this device",
            autoDismissSeconds = 6,
            isPreview = false,
            version = 0
        )
    )

    companion object {
        @Volatile
        private var activeRef: WeakReference<BlockScreenActivity>? = null

        fun dismissIfActive() {
            val activity = activeRef?.get() ?: return
            activity.runOnUiThread {
                if (!activity.isFinishing && !activity.isDestroyed) {
                    activity.finish()
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        activeRef = WeakReference(this)
        updateStateFromIntent(intent)

        setContent {
            val state = uiState
            BlockScreenContent(
                domain = state.domain,
                reason = state.reason,
                category = state.category,
                customMessage = state.customMessage,
                autoDismissSeconds = state.autoDismissSeconds,
                isPreview = state.isPreview,
                stateVersion = state.version,
                onDismiss = { finish() }
            )
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        updateStateFromIntent(intent)
    }

    override fun onDestroy() {
        if (activeRef?.get() === this) {
            activeRef = null
        }
        super.onDestroy()
    }

    private fun updateStateFromIntent(sourceIntent: Intent?) {
        val domain = sourceIntent?.getStringExtra("BLOCK_DOMAIN") ?: "restricted-site.com"
        val reason = sourceIntent?.getStringExtra("BLOCK_REASON") ?: "Content Policy"
        val category = sourceIntent?.getStringExtra("BLOCK_CATEGORY") ?: "RESTRICTED"
        val customMsg = sourceIntent?.getStringExtra("BLOCK_MESSAGE")
            ?.takeIf { it.isNotBlank() }
            ?: "Restricted content is not allowed on this device"
        val dismissSec = sourceIntent?.getIntExtra("BLOCK_DISMISS_SEC", 6) ?: 6
        val isPreview = sourceIntent?.getBooleanExtra("IS_PREVIEW", false) ?: false

        uiState = BlockScreenUiState(
            domain = domain,
            reason = reason,
            category = category,
            customMessage = customMsg,
            autoDismissSeconds = dismissSec,
            isPreview = isPreview,
            version = uiState.version + 1
        )
    }

    @Composable
    private fun BlockScreenContent(
        domain: String,
        reason: String,
        category: String,
        customMessage: String,
        autoDismissSeconds: Int,
        isPreview: Boolean,
        stateVersion: Int,
        onDismiss: () -> Unit
    ) {
        var secondsRemaining by remember(stateVersion, autoDismissSeconds) {
            mutableIntStateOf(if (autoDismissSeconds > 0) autoDismissSeconds else 6)
        }

        if (autoDismissSeconds > 0) {
            LaunchedEffect(stateVersion, autoDismissSeconds) {
                secondsRemaining = autoDismissSeconds
                while (secondsRemaining > 0) {
                    delay(1000L)
                    secondsRemaining--
                }
                onDismiss()
            }
        }

        val primaryAccent = if (isPreview) LiquidGlassTokens.CyanGlow else LiquidGlassTokens.CoralGlow

        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0x880F172A))
                .drawBehind {
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(
                                primaryAccent.copy(alpha = 0.18f),
                                LiquidGlassTokens.VioletGlow.copy(alpha = 0.08f),
                                Color.Transparent
                            ),
                            center = Offset(size.width * 0.5f, size.height * 0.42f),
                            radius = size.width * 0.85f
                        ),
                        radius = size.width * 0.85f,
                        center = Offset(size.width * 0.5f, size.height * 0.42f)
                    )
                }
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null
                ) { /* Prevent accidental outside tap dismissal */ },
            contentAlignment = Alignment.Center
        ) {
            AnimatedVisibility(
                visible = true,
                enter = fadeIn(tween(250)) + slideInVertically(tween(300)) { it / 4 }
            ) {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth(0.92f)
                        .widthIn(max = 410.dp)
                        .padding(16.dp)
                        .testTag("block_screen_card"),
                    shape = RoundedCornerShape(28.dp),
                    color = LiquidGlassTokens.GlassModalFill,
                    border = LiquidGlassTokens.specularBorder(
                        primaryTint = primaryAccent,
                        secondaryTint = LiquidGlassTokens.VioletGlow,
                        width = 1.2.dp
                    ),
                    tonalElevation = 12.dp,
                    shadowElevation = 24.dp
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(LiquidGlassTokens.TopRefractionSheen)
                    ) {
                        Column(
                            modifier = Modifier.padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            // Header row with Glowing LiquidIconOrb, Pill Badge, and Circular Glass Close Button
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                LiquidIconOrb(
                                    icon = if (isPreview) Icons.Rounded.Shield else Icons.Rounded.GppBad,
                                    tint = primaryAccent,
                                    contentDescription = "Blocked",
                                    size = 46.dp,
                                    iconSize = 24.dp,
                                    isCircle = true
                                )

                                Surface(
                                    shape = RoundedCornerShape(50),
                                    color = primaryAccent.copy(alpha = 0.14f),
                                    border = BorderStroke(0.9.dp, primaryAccent.copy(alpha = 0.45f))
                                ) {
                                    Text(
                                        text = if (isPreview) "PREVIEW" else category,
                                        color = primaryAccent,
                                        fontSize = 10.sp,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp)
                                    )
                                }

                                Surface(
                                    shape = CircleShape,
                                    color = CrispSurfaceSubtle,
                                    border = BorderStroke(1.dp, CrispHairline)
                                ) {
                                    IconButton(
                                        onClick = onDismiss,
                                        modifier = Modifier
                                            .size(38.dp)
                                            .testTag("block_screen_close_button")
                                    ) {
                                        Icon(
                                            imageVector = Icons.Rounded.Close,
                                            contentDescription = "Close",
                                            tint = CrispInkSecondary,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(18.dp))

                            Text(
                                text = if (isPreview) "Block Screen" else "Restricted",
                                style = MaterialTheme.typography.titleLarge.copy(
                                    fontWeight = FontWeight.ExtraBold,
                                    color = CrispInkPrimary
                                ),
                                textAlign = TextAlign.Center
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            Surface(
                                shape = RoundedCornerShape(50),
                                color = primaryAccent.copy(alpha = 0.10f),
                                border = BorderStroke(0.8.dp, primaryAccent.copy(alpha = 0.30f))
                            ) {
                                Text(
                                    text = domain,
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        fontFamily = FontFamily.Monospace,
                                        color = primaryAccent,
                                        fontWeight = FontWeight.SemiBold
                                    ),
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                                )
                            }

                            Spacer(modifier = Modifier.height(16.dp))

                            Surface(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(20.dp),
                                color = LiquidGlassTokens.GlassCapsuleFill,
                                border = BorderStroke(1.dp, CrispHairline)
                            ) {
                                Column(
                                    modifier = Modifier.padding(18.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Text(
                                        text = customMessage,
                                        style = MaterialTheme.typography.bodyLarge.copy(
                                            fontWeight = FontWeight.Medium,
                                            color = CrispInkPrimary
                                        ),
                                        textAlign = TextAlign.Center
                                    )

                                    Text(
                                        text = reason,
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            color = CrispInkSecondary,
                                            fontFamily = FontFamily.Monospace
                                        ),
                                        textAlign = TextAlign.Center
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(18.dp))

                            if (autoDismissSeconds > 0) {
                                val progress = (secondsRemaining.toFloat() / autoDismissSeconds.toFloat()).coerceIn(0f, 1f)
                                LinearProgressIndicator(
                                    progress = { progress },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(5.dp)
                                        .clip(RoundedCornerShape(50)),
                                    color = primaryAccent,
                                    trackColor = CrispBorder
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "${secondsRemaining}s",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = CrispInkSecondary,
                                        fontFamily = FontFamily.Monospace
                                    )
                                )
                                Spacer(modifier = Modifier.height(12.dp))
                            }

                            Button(
                                onClick = onDismiss,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(50.dp)
                                    .testTag("block_screen_dismiss_button"),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = primaryAccent,
                                    contentColor = Color.White
                                ),
                                shape = RoundedCornerShape(50)
                            ) {
                                Text(
                                    text = "Dismiss",
                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
