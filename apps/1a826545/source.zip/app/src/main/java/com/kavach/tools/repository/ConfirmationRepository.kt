package com.kavach.tools.repository

import kotlinx.coroutines.flow.Flow

enum class ConfirmationStatus {
    PENDING, APPROVED, REJECTED, TIMEOUT
}

data class ConfirmationRequest(
    val executionId: String,
    val toolId: String,
    val params: Map<String, Any>,
    val riskLevel: com.kavach.tools.core.RiskLevel,
    val status: ConfirmationStatus,
    val requestedAt: Long = System.currentTimeMillis()
)

interface ConfirmationRepository {
    fun getPendingRequests(): Flow<List<ConfirmationRequest>>
    fun getAllRequests(): Flow<List<ConfirmationRequest>>
    suspend fun addRequest(request: ConfirmationRequest)
    suspend fun updateStatus(executionId: String, status: ConfirmationStatus)
}
