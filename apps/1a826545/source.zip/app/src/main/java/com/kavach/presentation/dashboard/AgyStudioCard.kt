package com.kavach.presentation.dashboard

import android.Manifest
import android.content.pm.PackageManager
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.KeyboardArrowUp
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.PushPin
import androidx.compose.material.icons.rounded.Replay
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.kavach.data.local.AgyMacroEntity
import com.kavach.data.local.AgyRunHistoryEntity
import com.kavach.data.repository.AgyPowerRepository
import com.kavach.ui.overlay.AgyAppIconResolver
import com.kavach.ui.overlay.AgyVoiceInputController
import com.kavach.ui.theme.CrispAmber
import com.kavach.ui.theme.CrispBlue
import com.kavach.ui.theme.CrispEmerald
import com.kavach.ui.theme.CrispHairline
import com.kavach.ui.theme.CrispInkMuted
import com.kavach.ui.theme.CrispInkPrimary
import com.kavach.ui.theme.CrispInkSecondary
import com.kavach.ui.theme.CrispPillSwitch
import com.kavach.ui.theme.CrispRose
import com.kavach.ui.theme.CrispSurface
import com.kavach.ui.theme.CrispSurfaceSubtle
import com.kavach.ui.theme.JetBrainsMonoFamily
import java.util.Locale

private val STUDIO_ICON_PRESETS = listOf(
    "youtube" to "YouTube",
    "chrome" to "Chrome",
    "whatsapp" to "WhatsApp",
    "termux" to "Termux",
    "search" to "Search",
    "code" to "Code",
    "settings" to "Settings",
    "spark_ai" to "Agy AI"
)

@Composable
fun AgyStudioCard(
    macros: List<AgyMacroEntity>,
    runHistory: List<AgyRunHistoryEntity>,
    searchQuery: String,
    onSearchQueryChange: (String) -> Unit,
    onRunMacro: (AgyMacroEntity) -> Unit,
    onSaveMacro: (id: String?, title: String, prompt: String, iconHint: String, isPinned: Boolean) -> Unit,
    onToggleMacroPin: (AgyMacroEntity) -> Unit,
    onDeleteMacro: (String) -> Unit,
    onReplayRun: (AgyRunHistoryEntity) -> Unit,
    onCopyRunOutput: (String) -> Unit,
    onDeleteRun: (String) -> Unit,
    onClearHistory: () -> Unit
) {
    val context = LocalContext.current
    var selectedTab by remember { mutableIntStateOf(0) } // 0 = Workflows, 1 = History
    var isExpanded by remember { mutableStateOf(false) }
    var editingMacro by remember { mutableStateOf<AgyMacroEntity?>(null) }
    var showCreateDialog by remember { mutableStateOf(false) }
    var expandedRunId by remember { mutableStateOf<String?>(null) }

    if (showCreateDialog || editingMacro != null) {
        AgyMacroEditorDialog(
            initial = editingMacro,
            onDismiss = {
                showCreateDialog = false
                editingMacro = null
            },
            onSave = { title, prompt, iconHint, isPinned ->
                onSaveMacro(editingMacro?.id, title, prompt, iconHint, isPinned)
                showCreateDialog = false
                editingMacro = null
                Toast.makeText(context, "Workflow saved", Toast.LENGTH_SHORT).show()
            },
            onDelete = editingMacro?.let { macro ->
                {
                    onDeleteMacro(macro.id)
                    editingMacro = null
                    Toast.makeText(context, "Workflow removed", Toast.LENGTH_SHORT).show()
                }
            }
        )
    }

    Surface(
        color = CrispSurface,
        shape = RoundedCornerShape(22.dp),
        border = BorderStroke(0.85.dp, Color(0xFFE8ECF1)),
        shadowElevation = 0.75.dp,
        modifier = Modifier
            .fillMaxWidth()
            .testTag("agy_studio_card")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Calm Header Row: Title + Segmented Switcher + Expand/New
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Agy Studio",
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 14.sp
                        ),
                        color = CrispInkPrimary
                    )
                    Text(
                        text = if (selectedTab == 0) {
                            "${macros.size} workflows · pinned show in HUD"
                        } else {
                            "${runHistory.size} recorded runs · searchable"
                        },
                        style = MaterialTheme.typography.labelSmall.copy(fontSize = 11.sp),
                        color = CrispInkSecondary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    if (selectedTab == 0) {
                        Surface(
                            color = CrispBlue.copy(alpha = 0.10f),
                            shape = RoundedCornerShape(50),
                            modifier = Modifier
                                .clip(RoundedCornerShape(50))
                                .clickable { showCreateDialog = true }
                                .testTag("agy_studio_new_macro_button")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(3.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Add,
                                    contentDescription = "New Workflow",
                                    tint = CrispBlue,
                                    modifier = Modifier.size(14.dp)
                                )
                                Text(
                                    text = "New",
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
                                    color = CrispBlue
                                )
                            }
                        }
                    }

                    Surface(
                        color = Color(0xFFF3F4F6),
                        shape = CircleShape,
                        modifier = Modifier
                            .size(30.dp)
                            .clip(CircleShape)
                            .clickable { isExpanded = !isExpanded }
                            .testTag("agy_studio_expand_toggle")
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = if (isExpanded) Icons.Rounded.KeyboardArrowUp else Icons.Rounded.KeyboardArrowDown,
                                contentDescription = if (isExpanded) "Collapse Studio" else "Expand Studio",
                                tint = CrispInkSecondary,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }

            // Apple-Style Quiet Segmented Control
            Surface(
                color = Color(0xFFF3F4F6),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(3.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    StudioSegmentTab(
                        label = "Workflows",
                        count = macros.size,
                        selected = selectedTab == 0,
                        tag = "agy_studio_tab_workflows",
                        onClick = { selectedTab = 0 },
                        modifier = Modifier.weight(1f)
                    )
                    StudioSegmentTab(
                        label = "Run History",
                        count = runHistory.size,
                        selected = selectedTab == 1,
                        tag = "agy_studio_tab_history",
                        onClick = {
                            selectedTab = 1
                            isExpanded = true
                        },
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            AnimatedContent(
                targetState = selectedTab,
                transitionSpec = { fadeIn(tween(160)) togetherWith fadeOut(tween(120)) },
                label = "agy_studio_tab_content"
            ) { tab ->
                if (tab == 0) {
                    val visibleMacros = if (isExpanded) macros else macros.take(3)
                    Column(verticalArrangement = Arrangement.spacedBy(0.dp)) {
                        if (visibleMacros.isEmpty()) {
                            Text(
                                text = "No workflows yet. Tap + New to save a one-tap prompt.",
                                style = MaterialTheme.typography.bodySmall,
                                color = CrispInkSecondary,
                                modifier = Modifier.padding(vertical = 8.dp)
                            )
                        } else {
                            visibleMacros.forEachIndexed { idx, macro ->
                                if (idx > 0) {
                                    HorizontalDivider(
                                        color = Color(0xFFF1F4F8),
                                        thickness = 0.75.dp,
                                        modifier = Modifier.padding(start = 38.dp)
                                    )
                                }
                                StudioMacroRow(
                                    macro = macro,
                                    onRun = { onRunMacro(macro) },
                                    onTogglePin = { onToggleMacroPin(macro) },
                                    onEdit = { editingMacro = macro }
                                )
                            }
                            if (!isExpanded && macros.size > 3) {
                                Text(
                                    text = "Show all ${macros.size} workflows",
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
                                    color = CrispBlue,
                                    modifier = Modifier
                                        .padding(top = 8.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .clickable { isExpanded = true }
                                        .padding(horizontal = 4.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        // Minimalist Live Search Bar + Clear Action
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedTextField(
                                value = searchQuery,
                                onValueChange = onSearchQueryChange,
                                singleLine = true,
                                placeholder = {
                                    Text(
                                        text = "Search runs, prompts, or logs…",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = CrispInkMuted
                                    )
                                },
                                leadingIcon = {
                                    Icon(
                                        imageVector = Icons.Rounded.Search,
                                        contentDescription = null,
                                        tint = CrispInkMuted,
                                        modifier = Modifier.size(16.dp)
                                    )
                                },
                                trailingIcon = if (searchQuery.isNotEmpty()) {
                                    {
                                        Icon(
                                            imageVector = Icons.Rounded.Close,
                                            contentDescription = "Clear search",
                                            tint = CrispInkSecondary,
                                            modifier = Modifier
                                                .size(16.dp)
                                                .clickable { onSearchQueryChange("") }
                                        )
                                    }
                                } else null,
                                textStyle = MaterialTheme.typography.bodySmall.copy(color = CrispInkPrimary),
                                shape = RoundedCornerShape(50),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = CrispBlue,
                                    unfocusedBorderColor = Color(0xFFE8ECF1),
                                    focusedContainerColor = Color(0xFFF6F7F9),
                                    unfocusedContainerColor = Color(0xFFF6F7F9)
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("agy_history_search_input")
                            )

                            if (runHistory.isNotEmpty()) {
                                Text(
                                    text = "Clear",
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
                                    color = CrispInkSecondary,
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(50))
                                        .clickable(onClick = onClearHistory)
                                        .padding(horizontal = 8.dp, vertical = 8.dp)
                                        .testTag("agy_history_clear_button")
                                )
                            }
                        }

                        val visibleRuns = if (isExpanded) runHistory.take(20) else runHistory.take(3)
                        if (visibleRuns.isEmpty()) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.History,
                                    contentDescription = null,
                                    tint = CrispInkMuted,
                                    modifier = Modifier.size(18.dp)
                                )
                                Text(
                                    text = if (searchQuery.isNotBlank()) {
                                        "No runs match \"$searchQuery\"."
                                    } else {
                                        "Completed and stopped Agy tasks automatically appear here with full output and one-tap replay."
                                    },
                                    style = MaterialTheme.typography.bodySmall,
                                    color = CrispInkSecondary
                                )
                            }
                        } else {
                            Column(verticalArrangement = Arrangement.spacedBy(0.dp)) {
                                visibleRuns.forEachIndexed { idx, run ->
                                    if (idx > 0) {
                                        HorizontalDivider(
                                            color = Color(0xFFF1F4F8),
                                            thickness = 0.75.dp,
                                            modifier = Modifier.padding(start = 36.dp)
                                        )
                                    }
                                    StudioHistoryRow(
                                        run = run,
                                        expanded = expandedRunId == run.id,
                                        onToggleExpand = {
                                            expandedRunId = if (expandedRunId == run.id) null else run.id
                                        },
                                        onReplay = { onReplayRun(run) },
                                        onCopy = {
                                            val logs = AgyPowerRepository.parseLogsJson(run.outputLogsJson)
                                            val text = buildString {
                                                if (run.detailedOutput.isNotBlank()) append(run.detailedOutput)
                                                if (logs.isNotEmpty()) {
                                                    if (isNotEmpty()) append("\n\n")
                                                    append(logs.joinToString("\n"))
                                                }
                                            }.ifBlank { run.promptText.ifBlank { run.title } }
                                            onCopyRunOutput(text)
                                        },
                                        onDelete = { onDeleteRun(run.id) }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun StudioSegmentTab(
    label: String,
    count: Int,
    selected: Boolean,
    tag: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        color = if (selected) Color.White else Color.Transparent,
        shape = RoundedCornerShape(11.dp),
        shadowElevation = if (selected) 1.dp else 0.dp,
        modifier = modifier
            .clip(RoundedCornerShape(11.dp))
            .clickable(onClick = onClick)
            .testTag(tag)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 7.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelMedium.copy(
                    fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium,
                    fontSize = 12.sp
                ),
                color = if (selected) CrispInkPrimary else CrispInkSecondary
            )
            Spacer(Modifier.width(5.dp))
            Text(
                text = "$count",
                style = MaterialTheme.typography.labelSmall.copy(
                    fontFamily = JetBrainsMonoFamily,
                    fontSize = 10.sp
                ),
                color = if (selected) CrispBlue else CrispInkMuted
            )
        }
    }
}

@Composable
private fun StudioMacroRow(
    macro: AgyMacroEntity,
    onRun: () -> Unit,
    onTogglePin: () -> Unit,
    onEdit: () -> Unit
) {
    val context = LocalContext.current
    val resolvedIcon = remember(context, macro.iconHint, macro.title, macro.prompt) {
        AgyAppIconResolver.resolve(
            context = context,
            explicitIcon = macro.iconHint,
            explicitPackage = "",
            fallbackText = "${macro.title} ${macro.prompt}"
        )
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        StudioIconBadge(icon = resolvedIcon, size = 28.dp)

        Column(
            modifier = Modifier
                .weight(1f)
                .clickable(onClick = onEdit)
        ) {
            Text(
                text = macro.title,
                style = MaterialTheme.typography.bodyMedium.copy(
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 13.sp
                ),
                color = CrispInkPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = macro.prompt,
                style = MaterialTheme.typography.labelSmall.copy(fontSize = 11.sp),
                color = CrispInkSecondary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }

        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .size(32.dp)
                .clip(CircleShape)
                .clickable(onClick = onTogglePin)
                .testTag("agy_macro_pin_${macro.id}")
        ) {
            Icon(
                imageVector = Icons.Rounded.PushPin,
                contentDescription = if (macro.isPinned) "Unpin from HUD" else "Pin to HUD",
                tint = if (macro.isPinned) CrispBlue else CrispInkMuted.copy(alpha = 0.6f),
                modifier = Modifier.size(15.dp)
            )
        }

        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .size(32.dp)
                .clip(CircleShape)
                .clickable(onClick = onEdit)
                .testTag("agy_macro_edit_${macro.id}")
        ) {
            Icon(
                imageVector = Icons.Rounded.Edit,
                contentDescription = "Edit Workflow",
                tint = CrispInkMuted,
                modifier = Modifier.size(15.dp)
            )
        }

        Surface(
            color = CrispBlue.copy(alpha = 0.10f),
            shape = RoundedCornerShape(50),
            modifier = Modifier
                .clip(RoundedCornerShape(50))
                .clickable(onClick = onRun)
                .testTag("agy_macro_run_${macro.id}")
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 11.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(3.dp)
            ) {
                Icon(
                    imageVector = Icons.Rounded.PlayArrow,
                    contentDescription = "Run ${macro.title}",
                    tint = CrispBlue,
                    modifier = Modifier.size(14.dp)
                )
                Text(
                    text = "Run",
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
                    color = CrispBlue
                )
            }
        }
    }
}

@Composable
private fun StudioHistoryRow(
    run: AgyRunHistoryEntity,
    expanded: Boolean,
    onToggleExpand: () -> Unit,
    onReplay: () -> Unit,
    onCopy: () -> Unit,
    onDelete: () -> Unit
) {
    val context = LocalContext.current
    val resolvedIcon = remember(context, run.iconHint, run.appPackage, run.title, run.promptText) {
        AgyAppIconResolver.resolve(
            context = context,
            explicitIcon = run.iconHint,
            explicitPackage = run.appPackage,
            fallbackText = "${run.title} ${run.promptText}"
        )
    }
    val logs = remember(run.outputLogsJson) { AgyPowerRepository.parseLogsJson(run.outputLogsJson) }
    val isDone = run.finalState == "DONE"
    val statusColor = if (isDone) CrispEmerald else CrispRose

    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .clickable(onClick = onToggleExpand)
                .padding(vertical = 9.dp)
                .testTag("agy_history_row_${run.id}"),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            StudioIconBadge(icon = resolvedIcon, size = 26.dp)

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = run.title,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 13.sp
                    ),
                    color = CrispInkPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = if (isDone) "Done" else "Stopped",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 10.5.sp
                        ),
                        color = statusColor
                    )
                    Text(
                        text = "· ${formatCompactDuration(run.durationMs)} · ${formatRelativeAge(run.timestamp)}",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontFamily = JetBrainsMonoFamily,
                            fontSize = 10.sp
                        ),
                        color = CrispInkMuted,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            Icon(
                imageVector = if (expanded) Icons.Rounded.KeyboardArrowUp else Icons.Rounded.KeyboardArrowDown,
                contentDescription = if (expanded) "Collapse Output" else "Inspect Output",
                tint = CrispInkMuted,
                modifier = Modifier.size(18.dp)
            )
        }

        AnimatedVisibility(
            visible = expanded,
            enter = fadeIn() + expandVertically(),
            exit = fadeOut() + shrinkVertically()
        ) {
            Surface(
                color = Color(0xFFF7F8FA),
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(0.75.dp, Color(0xFFE8ECF1)),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 10.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(10.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (run.promptText.isNotBlank()) {
                        Text(
                            text = "Prompt: ${run.promptText}",
                            style = MaterialTheme.typography.labelSmall.copy(fontSize = 11.sp),
                            color = CrispInkSecondary
                        )
                    }

                    val bodyText = remember(run.detailedOutput, logs) {
                        buildString {
                            if (run.detailedOutput.isNotBlank()) append(run.detailedOutput)
                            if (logs.isNotEmpty()) {
                                if (isNotEmpty()) append("\n\n")
                                append(logs.joinToString("\n"))
                            }
                        }.ifBlank { "No output logs recorded for this run." }
                    }

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 136.dp)
                            .verticalScroll(rememberScrollState())
                    ) {
                        Text(
                            text = bodyText,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontFamily = JetBrainsMonoFamily,
                                fontSize = 10.sp,
                                lineHeight = 14.sp
                            ),
                            color = CrispInkPrimary
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            color = CrispBlue,
                            shape = RoundedCornerShape(50),
                            modifier = Modifier
                                .clip(RoundedCornerShape(50))
                                .clickable(onClick = onReplay)
                                .testTag("agy_history_replay_${run.id}")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Replay,
                                    contentDescription = "Replay Run",
                                    tint = Color.White,
                                    modifier = Modifier.size(13.dp)
                                )
                                Text(
                                    text = "Replay",
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
                                    color = Color.White
                                )
                            }
                        }

                        Surface(
                            color = Color.White,
                            shape = RoundedCornerShape(50),
                            border = BorderStroke(0.75.dp, CrispHairline),
                            modifier = Modifier
                                .clip(RoundedCornerShape(50))
                                .clickable(onClick = onCopy)
                                .testTag("agy_history_copy_${run.id}")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.ContentCopy,
                                    contentDescription = "Copy Output",
                                    tint = CrispInkSecondary,
                                    modifier = Modifier.size(13.dp)
                                )
                                Text(
                                    text = "Copy",
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Medium),
                                    color = CrispInkPrimary
                                )
                            }
                        }

                        Spacer(Modifier.weight(1f))

                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier
                                .size(30.dp)
                                .clip(CircleShape)
                                .clickable(onClick = onDelete)
                                .testTag("agy_history_delete_${run.id}")
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.DeleteOutline,
                                contentDescription = "Delete Run",
                                tint = CrispInkMuted,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AgyMacroEditorDialog(
    initial: AgyMacroEntity?,
    onDismiss: () -> Unit,
    onSave: (title: String, prompt: String, iconHint: String, isPinned: Boolean) -> Unit,
    onDelete: (() -> Unit)?
) {
    val context = LocalContext.current
    var title by remember(initial) { mutableStateOf(initial?.title.orEmpty()) }
    var prompt by remember(initial) { mutableStateOf(initial?.prompt.orEmpty()) }
    var iconHint by remember(initial) { mutableStateOf(initial?.iconHint ?: "spark_ai") }
    var isPinned by remember(initial) { mutableStateOf(initial?.isPinned ?: true) }
    var isVoiceListening by remember { mutableStateOf(false) }

    val voiceController = remember(context) {
        AgyVoiceInputController(
            context = context,
            onListeningChanged = { isVoiceListening = it },
            onPartialText = { partial -> prompt = partial },
            onFinalText = { finalText ->
                prompt = finalText
                if (title.isBlank()) {
                    title = finalText.split(" ").take(3).joinToString(" ")
                }
            },
            onErrorMessage = { msg ->
                Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
            }
        )
    }

    DisposableEffect(voiceController) {
        onDispose { voiceController.release() }
    }

    val micPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            voiceController.startListening()
        } else {
            Toast.makeText(context, "Microphone permission denied", Toast.LENGTH_SHORT).show()
        }
    }

    AlertDialog(
        onDismissRequest = {
            voiceController.stopListening()
            onDismiss()
        },
        containerColor = CrispSurface,
        shape = RoundedCornerShape(24.dp),
        title = {
            Text(
                text = if (initial == null) "New Workflow" else "Edit Workflow",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold),
                color = CrispInkPrimary
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    singleLine = true,
                    label = { Text("Name") },
                    placeholder = { Text("e.g. YouTube Focus") },
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("macro_editor_title_input")
                )

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    OutlinedTextField(
                        value = prompt,
                        onValueChange = { prompt = it },
                        minLines = 2,
                        maxLines = 4,
                        label = { Text("Prompt") },
                        placeholder = { Text("What should Agy do?") },
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("macro_editor_prompt_input")
                    )

                    Surface(
                        color = if (isVoiceListening) CrispBlue else CrispSurfaceSubtle,
                        shape = CircleShape,
                        border = BorderStroke(0.85.dp, if (isVoiceListening) CrispBlue else CrispHairline),
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .clickable {
                                val granted = ContextCompat.checkSelfPermission(
                                    context,
                                    Manifest.permission.RECORD_AUDIO
                                ) == PackageManager.PERMISSION_GRANTED
                                if (granted) {
                                    voiceController.toggleListening()
                                } else {
                                    micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                }
                            }
                            .testTag("macro_editor_voice_button")
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = if (isVoiceListening) Icons.Rounded.Stop else Icons.Rounded.Mic,
                                contentDescription = if (isVoiceListening) "Stop voice input" else "Dictate prompt",
                                tint = if (isVoiceListening) Color.White else CrispInkPrimary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }

                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = "Badge Icon",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Medium),
                        color = CrispInkSecondary
                    )
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        STUDIO_ICON_PRESETS.forEach { (key, label) ->
                            val selected = iconHint.equals(key, ignoreCase = true)
                            val previewIcon = remember(context, key) {
                                AgyAppIconResolver.resolve(context, explicitIcon = key, explicitPackage = "", fallbackText = label)
                            }
                            Surface(
                                color = if (selected) CrispBlue.copy(alpha = 0.12f) else Color(0xFFF5F6F8),
                                shape = RoundedCornerShape(50),
                                border = BorderStroke(
                                    0.85.dp,
                                    if (selected) CrispBlue else Color(0xFFE8ECF1)
                                ),
                                modifier = Modifier
                                    .clip(RoundedCornerShape(50))
                                    .clickable { iconHint = key }
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(5.dp)
                                ) {
                                    StudioIconBadge(icon = previewIcon, size = 16.dp)
                                    Text(
                                        text = label,
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium
                                        ),
                                        color = if (selected) CrispBlue else CrispInkPrimary
                                    )
                                }
                            }
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Pin to Floating Input Bar",
                            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Medium),
                            color = CrispInkPrimary
                        )
                        Text(
                            text = "Shows as a one-tap chip inside Window 1",
                            style = MaterialTheme.typography.labelSmall,
                            color = CrispInkSecondary
                        )
                    }
                    CrispPillSwitch(
                        checked = isPinned,
                        onCheckedChange = { isPinned = it },
                        modifier = Modifier.testTag("macro_editor_pin_switch")
                    )
                }
            }
        },
        confirmButton = {
            Button(
                enabled = title.isNotBlank() && prompt.isNotBlank(),
                onClick = {
                    voiceController.stopListening()
                    onSave(title.trim(), prompt.trim(), iconHint, isPinned)
                },
                shape = RoundedCornerShape(50),
                colors = ButtonDefaults.buttonColors(containerColor = CrispBlue, contentColor = Color.White),
                modifier = Modifier.testTag("macro_editor_save_button")
            ) {
                Text("Save", fontWeight = FontWeight.SemiBold)
            }
        },
        dismissButton = {
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                if (onDelete != null) {
                    TextButton(
                        onClick = {
                            voiceController.stopListening()
                            onDelete()
                        }
                    ) {
                        Text("Delete", color = CrispRose)
                    }
                }
                TextButton(
                    onClick = {
                        voiceController.stopListening()
                        onDismiss()
                    }
                ) {
                    Text("Cancel", color = CrispInkSecondary)
                }
            }
        }
    )
}

@Composable
private fun StudioIconBadge(
    icon: AgyAppIconResolver.ResolvedIcon,
    size: Dp
) {
    Canvas(modifier = Modifier.size(size)) {
        drawIntoCanvas { canvas ->
            AgyAppIconResolver.drawBadgeOnCanvas(
                canvas = canvas.nativeCanvas,
                width = this.size.width,
                height = this.size.height,
                icon = icon
            )
        }
    }
}

private fun formatCompactDuration(ms: Long): String {
    val safe = ms.coerceAtLeast(0L)
    return if (safe < 60_000L) {
        String.format(Locale.US, "%.1fs", safe / 1000.0)
    } else {
        val m = safe / 60_000L
        val s = (safe % 60_000L) / 1000L
        String.format(Locale.US, "%dm %02ds", m, s)
    }
}

private fun formatRelativeAge(timestampMs: Long): String {
    val diffSec = ((System.currentTimeMillis() - timestampMs).coerceAtLeast(0L)) / 1000L
    return when {
        diffSec < 60L -> "just now"
        diffSec < 3600L -> "${diffSec / 60L}m ago"
        diffSec < 86_400L -> "${diffSec / 3600L}h ago"
        else -> "${diffSec / 86_400L}d ago"
    }
}
