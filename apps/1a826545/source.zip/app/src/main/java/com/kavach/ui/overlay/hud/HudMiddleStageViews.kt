package com.kavach.ui.overlay.hud

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.SurfaceTexture
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.Surface
import android.view.TextureView
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import com.kavach.ui.overlay.AgyAppleVectorIconView
import com.kavach.ui.overlay.AgyMediaPlaybackController
import com.kavach.ui.overlay.AgyResultsMediaLoader
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

class ChessMiniBoardView(context: Context) : LinearLayout(context) {
    private val d = context.resources.displayMetrics.density.coerceAtLeast(1f)
    private var state: HudModels.ChessWidgetState = HudModels.ChessWidgetState()

    var onChessAction: ((label: String, commandText: String, actionType: String) -> Unit)? = null

    private val boardCanvas = object : View(context) {
        private val lightSqPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#CBD5E1") }
        private val darkSqPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#334155") }
        private val lastMovePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#66F59E0B") }
        private val arrowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#D938BDF8")
            style = Paint.Style.STROKE
            strokeCap = Paint.Cap.ROUND
        }
        private val arrowFillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#D938BDF8")
            style = Paint.Style.FILL
        }
        private val whitePiecePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#FFFFFF")
            textAlign = Paint.Align.CENTER
            setShadowLayer(2f, 0f, 1f, Color.BLACK)
        }
        private val blackPiecePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#0F172A")
            textAlign = Paint.Align.CENTER
            setShadowLayer(1.5f, 0f, 0.5f, Color.parseColor("#88FFFFFF"))
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val size = min(width, height).toFloat()
            if (size <= 0f) return
            val sq = size / 8f
            val isBlackBottom = state.playerColor == "black"
            val grid = parseFenGrid(state.fen)

            val lm = state.lastMove
            for (r in 0..7) {
                for (c in 0..7) {
                    val boardRank = if (isBlackBottom) r else 7 - r
                    val boardFile = if (isBlackBottom) 7 - c else c
                    val sqName = "${'a' + boardFile}${'1' + boardRank}"
                    val left = c * sq
                    val top = r * sq
                    val isLight = (boardRank + boardFile) % 2 == 1
                    canvas.drawRect(left, top, left + sq, top + sq, if (isLight) lightSqPaint else darkSqPaint)
                    if (lm != null && lm.isValid && (sqName == lm.from || sqName == lm.to)) {
                        canvas.drawRect(left, top, left + sq, top + sq, lastMovePaint)
                    }
                    val piece = grid[7 - boardRank][boardFile]
                    if (piece != '\u0000') {
                        val glyph = pieceGlyph(piece)
                        val isWhitePiece = piece.isUpperCase()
                        val paint = if (isWhitePiece) whitePiecePaint else blackPiecePaint
                        paint.textSize = sq * 0.72f
                        val yPos = top + sq * 0.5f - (paint.descent() + paint.ascent()) * 0.5f
                        canvas.drawText(glyph, left + sq * 0.5f, yPos, paint)
                    }
                }
            }

            val bm = state.bestMove
            if (bm != null && bm.isValid) {
                val fromPt = squareCenter(bm.from, sq, isBlackBottom)
                val toPt = squareCenter(bm.to, sq, isBlackBottom)
                if (fromPt != null && toPt != null) {
                    arrowPaint.strokeWidth = (sq * 0.22f).coerceAtLeast(3f)
                    canvas.drawLine(fromPt.first, fromPt.second, toPt.first, toPt.second, arrowPaint)
                    val angle = atan2((toPt.second - fromPt.second).toDouble(), (toPt.first - fromPt.first).toDouble())
                    val headLen = sq * 0.36f
                    val p = Path().apply {
                        moveTo(toPt.first, toPt.second)
                        lineTo(
                            (toPt.first - headLen * cos(angle - 0.5)).toFloat(),
                            (toPt.second - headLen * sin(angle - 0.5)).toFloat()
                        )
                        lineTo(
                            (toPt.first - headLen * cos(angle + 0.5)).toFloat(),
                            (toPt.second - headLen * sin(angle + 0.5)).toFloat()
                        )
                        close()
                    }
                    canvas.drawPath(p, arrowFillPaint)
                }
            }
        }

        private fun squareCenter(sqName: String, sq: Float, isBlackBottom: Boolean): Pair<Float, Float>? {
            if (sqName.length < 2) return null
            val f = sqName[0].lowercaseChar() - 'a'
            val r = sqName[1] - '1'
            if (f !in 0..7 || r !in 0..7) return null
            val col = if (isBlackBottom) 7 - f else f
            val row = if (isBlackBottom) r else 7 - r
            return (col + 0.5f) * sq to (row + 0.5f) * sq
        }

        private fun parseFenGrid(fen: String): Array<CharArray> {
            val grid = Array(8) { CharArray(8) { '\u0000' } }
            val rows = fen.substringBefore(' ').split('/')
            for (r in 0 until min(8, rows.size)) {
                var c = 0
                for (ch in rows[r]) {
                    if (c >= 8) break
                    if (ch.isDigit()) {
                        c += ch.digitToInt()
                    } else {
                        grid[r][c] = ch
                        c++
                    }
                }
            }
            return grid
        }

        private fun pieceGlyph(ch: Char): String = when (ch) {
            'K' -> "♔"; 'Q' -> "♕"; 'R' -> "♖"; 'B' -> "♗"; 'N' -> "♘"; 'P' -> "♙"
            'k' -> "♚"; 'q' -> "♛"; 'r' -> "♜"; 'b' -> "♝"; 'n' -> "♞"; 'p' -> "♟"
            else -> ""
        }
    }

    private val evalLabel = TextView(context).apply {
        textSize = 12f
        setTypeface(Typeface.MONOSPACE, Typeface.BOLD)
        setTextColor(Color.parseColor("#38BDF8"))
    }
    private val turnInfo = TextView(context).apply {
        textSize = 11f
        setTextColor(Color.parseColor("#FFB4C2D9"))
        maxLines = 2
        ellipsize = TextUtils.TruncateAt.END
    }
    private val moveInfo = TextView(context).apply {
        textSize = 11f
        setTypeface(Typeface.MONOSPACE, Typeface.NORMAL)
        setTextColor(Color.parseColor("#F8FAFC"))
        maxLines = 2
        ellipsize = TextUtils.TruncateAt.END
    }
    private val btnRow = LinearLayout(context).apply {
        orientation = HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
    }

    init {
        orientation = VERTICAL
        setPadding((8 * d).toInt(), (8 * d).toInt(), (8 * d).toInt(), (8 * d).toInt())
        background = GradientDrawable().apply {
            setColor(Color.parseColor("#CC11192B"))
            cornerRadius = 14f * d
            setStroke((1 * d).toInt(), Color.parseColor("#29FFFFFF"))
        }

        val topRow = LinearLayout(context).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val boardSize = (112 * d).toInt()
        topRow.addView(boardCanvas, LayoutParams(boardSize, boardSize).apply {
            marginEnd = (10 * d).toInt()
        })

        val metaCol = LinearLayout(context).apply {
            orientation = VERTICAL
            layoutParams = LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f)
        }
        metaCol.addView(evalLabel)
        metaCol.addView(turnInfo, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT).apply {
            topMargin = (2 * d).toInt()
        })
        metaCol.addView(moveInfo, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT).apply {
            topMargin = (4 * d).toInt()
        })
        metaCol.addView(btnRow, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT).apply {
            topMargin = (6 * d).toInt()
        })
        topRow.addView(metaCol)
        addView(topRow)
    }

    fun bind(chess: HudModels.ChessWidgetState, status: HudModels.HudStatus) {
        state = chess
        evalLabel.text = "Eval ${chess.evalCp} · ${chess.playerColor.replaceFirstChar { it.uppercase() }}"
        turnInfo.text = chess.turnLabel.ifBlank { "Live chess board" }
        val parts = mutableListOf<String>()
        chess.bestMove?.takeIf { it.isValid }?.let { parts.add("Best: ${it.from}→${it.to}") }
        chess.lastMove?.takeIf { it.isValid }?.let { parts.add("Last: ${it.from}→${it.to}") }
        moveInfo.text = parts.joinToString("  ")
        moveInfo.visibility = if (parts.isEmpty()) GONE else VISIBLE

        btnRow.removeAllViews()
        val chips = when (status) {
            HudModels.HudStatus.WORKING -> listOf(
                Triple("Pause", "", "PAUSE"),
                Triple("Stop", "", "STOP")
            )
            HudModels.HudStatus.PAUSED -> listOf(
                Triple("Resume", "", "RESUME"),
                Triple("Stop", "", "STOP")
            )
            else -> listOf(
                Triple("Best Move", "chess suggest", "PROMPT"),
                Triple("Auto Play", "chess autopilot play", "PROMPT"),
                Triple("1 Move", "chess play one move", "PROMPT")
            )
        }
        chips.forEachIndexed { idx, (lbl, cmd, act) ->
            val tv = TextView(context).apply {
                text = lbl
                textSize = 10.5f
                setTypeface(Typeface.DEFAULT_BOLD)
                setTextColor(
                    when (act) {
                        "STOP" -> Color.parseColor("#FDA4AF")
                        "PROMPT" -> Color.parseColor("#E0F2FE")
                        else -> Color.parseColor("#FDE68A")
                    }
                )
                setPadding((8 * d).toInt(), (4 * d).toInt(), (8 * d).toInt(), (4 * d).toInt())
                background = GradientDrawable().apply {
                    setColor(Color.parseColor("#24324E"))
                    cornerRadius = 999f
                }
                setOnClickListener { onChessAction?.invoke(lbl, cmd, act) }
            }
            btnRow.addView(tv, LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT).apply {
                if (idx > 0) marginStart = (5 * d).toInt()
            })
        }
        boardCanvas.invalidate()
    }
}

class MediaCarouselCardView(
    context: Context,
    private val playbackController: AgyMediaPlaybackController
) : FrameLayout(context) {
    private val d = context.resources.displayMetrics.density.coerceAtLeast(1f)
    private var items: List<HudModels.MediaItem> = emptyList()
    private var activeIndex: Int = 0
    private var startTouchX: Float = 0f

    var onPageChanged: ((Int) -> Unit)? = null
    var onTogglePlayPause: (() -> Unit)? = null
    var onToggleMute: (() -> Unit)? = null

    private val stageBox = FrameLayout(context).apply {
        background = GradientDrawable().apply {
            setColor(Color.parseColor("#FF101829"))
            cornerRadius = 14f * d
            setStroke((1 * d).toInt(), Color.parseColor("#26FFFFFF"))
        }
        clipToOutline = true
    }
    private val previewImage = ImageView(context).apply {
        scaleType = ImageView.ScaleType.CENTER_CROP
    }
    private val videoTexture = TextureView(context).apply {
        visibility = GONE
        surfaceTextureListener = object : TextureView.SurfaceTextureListener {
            override fun onSurfaceTextureAvailable(st: SurfaceTexture, width: Int, height: Int) {
                playbackController.bindVideoSurface(Surface(st))
            }
            override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, width: Int, height: Int) {}
            override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean {
                playbackController.bindVideoSurface(null)
                return true
            }
            override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
        }
    }
    private val scrimOverlay = FrameLayout(context).apply {
        background = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(Color.TRANSPARENT, Color.parseColor("#B8080D18"))
        )
    }
    private val titleLabel = TextView(context).apply {
        textSize = 12f
        setTypeface(Typeface.DEFAULT_BOLD)
        setTextColor(Color.parseColor("#F8FAFC"))
        maxLines = 1
        ellipsize = TextUtils.TruncateAt.END
    }
    private val subtitleLabel = TextView(context).apply {
        textSize = 10.5f
        setTextColor(Color.parseColor("#CBD5E1"))
        maxLines = 1
        ellipsize = TextUtils.TruncateAt.END
    }
    private val dotsRow = LinearLayout(context).apply {
        orientation = HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
    }
    private val playPauseBtn = AgyAppleVectorIconView(context, AgyAppleVectorIconView.IconType.PLAY_FILL).apply {
        glassStyle = AgyAppleVectorIconView.GlassStyle.GLASS_CIRCLE
        iconTint = Color.WHITE
        setOnClickListener { onTogglePlayPause?.invoke() }
    }
    private val muteBtn = AgyAppleVectorIconView(context, AgyAppleVectorIconView.IconType.SPEAKER_WAVE).apply {
        glassStyle = AgyAppleVectorIconView.GlassStyle.GLASS_CIRCLE
        iconTint = Color.WHITE
        setOnClickListener { onToggleMute?.invoke() }
    }

    init {
        val heightPx = (140 * d).toInt()
        addView(stageBox, LayoutParams(LayoutParams.MATCH_PARENT, heightPx))
        stageBox.addView(previewImage, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))
        stageBox.addView(videoTexture, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))
        stageBox.addView(scrimOverlay, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))

        val bottomBar = LinearLayout(context).apply {
            orientation = HORIZONTAL
            gravity = Gravity.BOTTOM
            setPadding((10 * d).toInt(), (8 * d).toInt(), (10 * d).toInt(), (8 * d).toInt())
        }
        val infoCol = LinearLayout(context).apply {
            orientation = VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f)
        }
        infoCol.addView(titleLabel)
        infoCol.addView(subtitleLabel)
        infoCol.addView(dotsRow, LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT).apply {
            topMargin = (4 * d).toInt()
        })
        bottomBar.addView(infoCol)

        val btnSize = (32 * d).toInt()
        bottomBar.addView(playPauseBtn, LinearLayout.LayoutParams(btnSize, btnSize).apply {
            marginStart = (6 * d).toInt()
        })
        bottomBar.addView(muteBtn, LinearLayout.LayoutParams(btnSize, btnSize).apply {
            marginStart = (6 * d).toInt()
        })
        stageBox.addView(bottomBar, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT, Gravity.BOTTOM))

        stageBox.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    startTouchX = event.x
                    false
                }
                MotionEvent.ACTION_UP -> {
                    val dx = event.x - startTouchX
                    if (abs(dx) > 40f * d && items.size > 1) {
                        val nextIdx = if (dx < 0) (activeIndex + 1) % items.size else (activeIndex - 1 + items.size) % items.size
                        activeIndex = nextIdx
                        onPageChanged?.invoke(nextIdx)
                        renderActiveItem()
                        true
                    } else {
                        false
                    }
                }
                else -> false
            }
        }
        stageBox.setOnClickListener {
            items.getOrNull(activeIndex)?.let { current ->
                if (!current.isPlayable && current.uri.isNotBlank()) {
                    AgyResultsMediaLoader.openInDefaultApp(context, current)
                } else {
                    onTogglePlayPause?.invoke()
                }
            }
        }
    }

    fun bind(nextItems: List<HudModels.MediaItem>, index: Int, playing: Boolean, muted: Boolean) {
        val listChanged = items != nextItems
        items = nextItems
        activeIndex = if (items.isEmpty()) 0 else index.coerceIn(0, items.lastIndex)
        playPauseBtn.iconType = if (playing) AgyAppleVectorIconView.IconType.PAUSE_FILL else AgyAppleVectorIconView.IconType.PLAY_FILL
        muteBtn.iconType = if (muted) AgyAppleVectorIconView.IconType.SPEAKER_SLASH else AgyAppleVectorIconView.IconType.SPEAKER_WAVE

        val current = items.getOrNull(activeIndex)
        val hasPlayable = current?.isPlayable == true || playing
        playPauseBtn.visibility = if (hasPlayable) VISIBLE else GONE
        muteBtn.visibility = if (hasPlayable) VISIBLE else GONE

        if (listChanged) {
            renderActiveItem()
        } else {
            updateDots()
        }
    }

    private fun renderActiveItem() {
        val current = items.getOrNull(activeIndex) ?: return
        titleLabel.text = current.title
        subtitleLabel.text = current.subtitle.ifBlank { current.kind.uppercase() }
        subtitleLabel.visibility = if (subtitleLabel.text.isNotBlank()) VISIBLE else GONE

        val isVideo = current.kind == "video" && !current.isWebEmbed && current.uri.isNotBlank()
        videoTexture.visibility = if (isVideo) VISIBLE else GONE
        previewImage.setImageBitmap(null)
        if (current.kind == "image" || current.kind == "video" || current.thumbnailUri.isNotBlank()) {
            AgyResultsMediaLoader.loadPreviewBitmap(context, current, maxDimensionPx = 640) { bmp: Bitmap? ->
                if (bmp != null && items.getOrNull(activeIndex)?.uri == current.uri) {
                    previewImage.setImageBitmap(bmp)
                }
            }
        }
        if (current.isPlayable && current.uri.isNotBlank()) {
            playbackController.applyPlayerData(
                HudModels.PlayerPlaybackConfig(
                    playlist = items.filter { it.isPlayable },
                    currentIndex = 0,
                    mediaMode = if (current.kind == "audio") "audio" else "video",
                    playing = false
                )
            )
        }
        updateDots()
    }

    private fun updateDots() {
        dotsRow.removeAllViews()
        if (items.size <= 1) {
            dotsRow.visibility = GONE
            return
        }
        dotsRow.visibility = VISIBLE
        val dotSize = (5 * d).toInt()
        items.indices.forEach { i ->
            val dot = View(context).apply {
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(if (i == activeIndex) Color.parseColor("#38BDF8") else Color.parseColor("#66FFFFFF"))
                }
            }
            dotsRow.addView(dot, LinearLayout.LayoutParams(dotSize, dotSize).apply {
                marginEnd = (4 * d).toInt()
            })
        }
    }
}

class ApprovalCardView(context: Context) : LinearLayout(context) {
    private val d = context.resources.displayMetrics.density.coerceAtLeast(1f)
    var onDecision: ((approvalId: String, decision: String, editedText: String) -> Unit)? = null
    var onEditFocusRequested: ((EditText) -> Unit)? = null

    private var activeId: String = ""
    private val riskBadge = TextView(context).apply {
        textSize = 10f
        setTypeface(Typeface.DEFAULT_BOLD)
        setPadding((7 * d).toInt(), (2 * d).toInt(), (7 * d).toInt(), (2 * d).toInt())
    }
    private val descText = TextView(context).apply {
        textSize = 11.5f
        setTextColor(Color.parseColor("#F8FAFC"))
        maxLines = 2
        ellipsize = TextUtils.TruncateAt.END
    }
    private val previewText = TextView(context).apply {
        textSize = 10.5f
        typeface = Typeface.MONOSPACE
        setTextColor(Color.parseColor("#BAE6FD"))
        setPadding((8 * d).toInt(), (6 * d).toInt(), (8 * d).toInt(), (6 * d).toInt())
        background = GradientDrawable().apply {
            setColor(Color.parseColor("#FF0B111E"))
            cornerRadius = 8f * d
        }
        maxLines = 3
        ellipsize = TextUtils.TruncateAt.END
    }
    private val editField = EditText(context).apply {
        visibility = GONE
        textSize = 11.5f
        setTextColor(Color.WHITE)
        setHintTextColor(Color.parseColor("#88CBD5E1"))
        background = GradientDrawable().apply {
            setColor(Color.parseColor("#FF172136"))
            cornerRadius = 8f * d
            setStroke((1 * d).toInt(), Color.parseColor("#4438BDF8"))
        }
        setPadding((8 * d).toInt(), (6 * d).toInt(), (8 * d).toInt(), (6 * d).toInt())
    }
    private val editBtn = buildActionPill("Edit", "#24324E", "#E0F2FE")
    private val approveBtn = buildActionPill("Approve", "#065F46", "#6EE7B7")
    private val denyBtn = buildActionPill("Deny", "#7F1D1D", "#FECACA")

    init {
        orientation = VERTICAL
        setPadding((10 * d).toInt(), (8 * d).toInt(), (10 * d).toInt(), (8 * d).toInt())
        background = GradientDrawable().apply {
            setColor(Color.parseColor("#E6162033"))
            cornerRadius = 14f * d
            setStroke((1 * d).toInt(), Color.parseColor("#66F59E0B"))
        }
        addView(riskBadge, LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT))
        addView(descText, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT).apply { topMargin = (4 * d).toInt() })
        addView(previewText, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT).apply { topMargin = (6 * d).toInt() })
        addView(editField, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT).apply { topMargin = (6 * d).toInt() })

        val row = LinearLayout(context).apply {
            orientation = HORIZONTAL
            gravity = Gravity.END
        }
        row.addView(denyBtn)
        row.addView(editBtn, LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT).apply { marginStart = (6 * d).toInt() })
        row.addView(approveBtn, LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT).apply { marginStart = (6 * d).toInt() })
        addView(row, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT).apply { topMargin = (8 * d).toInt() })

        editField.setOnClickListener { onEditFocusRequested?.invoke(editField) }
        editBtn.setOnClickListener {
            if (editField.visibility == GONE) {
                editField.visibility = VISIBLE
                previewText.visibility = GONE
                editBtn.text = "Send Edit"
                onEditFocusRequested?.invoke(editField)
            } else {
                onDecision?.invoke(activeId, "edit", editField.text?.toString().orEmpty())
            }
        }
        approveBtn.setOnClickListener { onDecision?.invoke(activeId, "approve", "") }
        denyBtn.setOnClickListener { onDecision?.invoke(activeId, "deny", "") }
    }

    fun bind(prompt: HudModels.ApprovalPrompt) {
        activeId = prompt.id
        riskBadge.text = "${prompt.riskLevel.uppercase()} RISK"
        val bgCol = when (prompt.riskLevel) {
            "high" -> Color.parseColor("#7F1D1D")
            "low" -> Color.parseColor("#064E3B")
            else -> Color.parseColor("#78350F")
        }
        riskBadge.background = GradientDrawable().apply {
            setColor(bgCol)
            cornerRadius = 999f
        }
        riskBadge.setTextColor(Color.WHITE)
        descText.text = prompt.description.ifBlank { prompt.title }
        previewText.text = prompt.commandPreview
        previewText.visibility = if (prompt.commandPreview.isNotBlank()) VISIBLE else GONE
        editField.visibility = GONE
        editField.setText(prompt.editableText.ifBlank { prompt.commandPreview })
        editBtn.text = "Edit"
        editBtn.visibility = if (prompt.allowEdit) VISIBLE else GONE
    }

    private fun buildActionPill(label: String, bgHex: String, fgHex: String): TextView {
        return TextView(context).apply {
            text = label
            textSize = 11f
            setTypeface(Typeface.DEFAULT_BOLD)
            setTextColor(Color.parseColor(fgHex))
            setPadding((11 * d).toInt(), (5 * d).toInt(), (11 * d).toInt(), (5 * d).toInt())
            background = GradientDrawable().apply {
                setColor(Color.parseColor(bgHex))
                cornerRadius = 999f
            }
        }
    }
}
