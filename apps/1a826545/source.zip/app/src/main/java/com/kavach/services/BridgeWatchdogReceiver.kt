package com.kavach.services

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import com.kavach.BaseApplication

/**
 * Ensures BaseApplication, AuraHttpServer (:8080), WebSocket auto-connect, and RealtimeConnectionService
 * remain alive across device reboots, package updates, and launcher visibility changes.
 */
class BridgeWatchdogReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        try {
            val app = context.applicationContext as? BaseApplication
            app?.ensureBackgroundBridgeConnected(startForegroundIfPossible = true)
            if (!RealtimeConnectionService.serviceState.value.isServiceRunning) {
                RealtimeConnectionService.ensureBridge(context.applicationContext)
            }
        } catch (e: Throwable) {
            Log.w("BridgeWatchdogReceiver", "Watchdog check failed: ${e.message}")
        }
    }
}
