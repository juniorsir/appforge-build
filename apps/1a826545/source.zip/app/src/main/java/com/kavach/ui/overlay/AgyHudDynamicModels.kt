package com.kavach.ui.overlay

import android.graphics.Color
import org.json.JSONArray
import org.json.JSONObject

/**
 * Dynamic, Agy-programmable theme, layout, progress, metric, banner, and modular content-block
 * schemas for the floating Agy HUD. All fields have safe defaults so legacy payloads remain
 * 100% backward-compatible.
 */
object AgyHudDynamicModels {

    fun parseColorOrNull(raw: String?): Int? {
        val trimmed = raw?.trim().orEmpty()
        if (trimmed.isEmpty()) return null
        return try {
            Color.parseColor(if (trimmed.startsWith("#")) trimmed else "#$trimmed")
        } catch (_: Exception) {
            null
        }
    }

    data class HudThemeConfig(
        val mode: String = "dark", // dark (Apple Liquid Glass) | light | custom
        val surfaceColor: String = "",
        val secondarySurfaceColor: String = "",
        val borderColor: String = "",
        val textPrimaryColor: String = "",
        val textSecondaryColor: String = "",
        val accentColor: String = "",
        val auroraColors: List<String> = emptyList(),
        val auroraEnabled: Boolean = true,
        val cornerRadiusDp: Float? = null,
        val opacity: Float? = null
    ) {
        fun toJson(): JSONObject = JSONObject().apply {
            put("mode", mode)
            if (surfaceColor.isNotBlank()) put("surfaceColor", surfaceColor)
            if (secondarySurfaceColor.isNotBlank()) put("secondarySurfaceColor", secondarySurfaceColor)
            if (borderColor.isNotBlank()) put("borderColor", borderColor)
            if (textPrimaryColor.isNotBlank()) put("textPrimaryColor", textPrimaryColor)
            if (textSecondaryColor.isNotBlank()) put("textSecondaryColor", textSecondaryColor)
            if (accentColor.isNotBlank()) put("accentColor", accentColor)
            if (auroraColors.isNotEmpty()) {
                put("auroraColors", JSONArray().apply { auroraColors.forEach { put(it) } })
            }
            put("auroraEnabled", auroraEnabled)
            if (cornerRadiusDp != null) put("cornerRadiusDp", cornerRadiusDp.toDouble())
            if (opacity != null) put("opacity", opacity.toDouble())
        }

        fun merge(patch: JSONObject): HudThemeConfig {
            val parsedAurora = if (patch.has("auroraColors")) {
                val arr = patch.optJSONArray("auroraColors") ?: JSONArray()
                buildList {
                    for (i in 0 until arr.length()) {
                        val c = arr.optString(i, "").trim()
                        if (c.isNotEmpty()) add(c)
                    }
                }
            } else auroraColors
            return copy(
                mode = if (patch.has("mode")) patch.optString("mode", mode).lowercase().trim().ifBlank { "dark" } else mode,
                surfaceColor = if (patch.has("surfaceColor")) patch.optString("surfaceColor", "").trim() else surfaceColor,
                secondarySurfaceColor = if (patch.has("secondarySurfaceColor")) patch.optString("secondarySurfaceColor", "").trim() else secondarySurfaceColor,
                borderColor = if (patch.has("borderColor")) patch.optString("borderColor", "").trim() else borderColor,
                textPrimaryColor = if (patch.has("textPrimaryColor")) patch.optString("textPrimaryColor", "").trim() else textPrimaryColor,
                textSecondaryColor = if (patch.has("textSecondaryColor")) patch.optString("textSecondaryColor", "").trim() else textSecondaryColor,
                accentColor = if (patch.has("accentColor")) patch.optString("accentColor", "").trim() else accentColor,
                auroraColors = parsedAurora,
                auroraEnabled = if (patch.has("auroraEnabled")) patch.optBoolean("auroraEnabled", auroraEnabled) else auroraEnabled,
                cornerRadiusDp = if (patch.has("cornerRadiusDp")) {
                    if (patch.isNull("cornerRadiusDp")) null else patch.optDouble("cornerRadiusDp", 24.0).toFloat().coerceIn(8f, 36f)
                } else cornerRadiusDp,
                opacity = if (patch.has("opacity")) {
                    if (patch.isNull("opacity")) null else patch.optDouble("opacity", 1.0).toFloat().coerceIn(0.35f, 1.0f)
                } else opacity
            )
        }

        companion object {
            fun fromJson(json: JSONObject?, base: HudThemeConfig = HudThemeConfig()): HudThemeConfig {
                if (json == null) return base
                return base.merge(json)
            }
        }
    }

    data class ResolvedHudTheme(
        val isDark: Boolean,
        val surface: Int,
        val secondarySurface: Int,
        val border: Int,
        val textPrimary: Int,
        val textSecondary: Int,
        val accent: Int,
        val auroraIntColors: IntArray?,
        val auroraEnabled: Boolean,
        val cornerRadiusDp: Float
    )

    fun resolveTheme(config: HudThemeConfig, defaultStateAccent: Int): ResolvedHudTheme {
        val explicitSurface = parseColorOrNull(config.surfaceColor)
        val isDark = when (config.mode.lowercase()) {
            "light" -> false
            "custom" -> explicitSurface?.let { isColorDark(it) } ?: true
            else -> true
        }
        val surface = explicitSurface ?: if (isDark) Color.parseColor("#FA0C1220") else Color.parseColor("#FAFFFFFF")
        val secondarySurface = parseColorOrNull(config.secondarySurfaceColor)
            ?: if (isDark) Color.parseColor("#FF172136") else Color.parseColor("#FFF1F5F9")
        val border = parseColorOrNull(config.borderColor)
            ?: if (isDark) Color.parseColor("#33FFFFFF") else Color.parseColor("#FFE2E8F0")
        val textPrimary = parseColorOrNull(config.textPrimaryColor)
            ?: if (isDark) Color.parseColor("#FFF8FAFC") else Color.parseColor("#FF0F172A")
        val textSecondary = parseColorOrNull(config.textSecondaryColor)
            ?: if (isDark) Color.parseColor("#FFB4C2D9") else Color.parseColor("#FF64748B")
        val accent = parseColorOrNull(config.accentColor) ?: defaultStateAccent
        val auroraParsed = config.auroraColors.mapNotNull { parseColorOrNull(it) }
        val auroraInts = when {
            auroraParsed.size >= 2 -> {
                if (auroraParsed.first() == auroraParsed.last()) auroraParsed.toIntArray()
                else (auroraParsed + auroraParsed.first()).toIntArray()
            }
            auroraParsed.size == 1 -> {
                val c = auroraParsed.first()
                intArrayOf(c, Color.argb(180, Color.red(c), Color.green(c), Color.blue(c)), c)
            }
            else -> null
        }
        return ResolvedHudTheme(
            isDark = isDark,
            surface = surface,
            secondarySurface = secondarySurface,
            border = border,
            textPrimary = textPrimary,
            textSecondary = textSecondary,
            accent = accent,
            auroraIntColors = auroraInts,
            auroraEnabled = config.auroraEnabled,
            cornerRadiusDp = config.cornerRadiusDp ?: 24f
        )
    }

    private fun isColorDark(color: Int): Boolean {
        val luminance = (0.299 * Color.red(color) + 0.587 * Color.green(color) + 0.114 * Color.blue(color)) / 255.0
        return luminance < 0.5
    }

    data class HudLayoutConfig(
        val collapsed: Boolean? = null,
        val detailsExpanded: Boolean? = null,
        val macrosDrawerOpen: Boolean? = null,
        val showComposer: Boolean = true,
        val showMic: Boolean = true,
        val showMacros: Boolean = true,
        val showStopButton: Boolean = true,
        val showStepsBadge: Boolean = true,
        val showOverflowMenu: Boolean = true,
        val showCollapseButton: Boolean = true,
        val inputPlaceholder: String = "",
        val position: String = "", // "" | "top" | "center" | "bottom"
        val xFraction: Float? = null,
        val yFraction: Float? = null,
        val widthFraction: Float? = null
    ) {
        fun toJson(): JSONObject = JSONObject().apply {
            if (collapsed != null) put("collapsed", collapsed)
            if (detailsExpanded != null) put("detailsExpanded", detailsExpanded)
            if (macrosDrawerOpen != null) put("macrosDrawerOpen", macrosDrawerOpen)
            put("showComposer", showComposer)
            put("showMic", showMic)
            put("showMacros", showMacros)
            put("showStopButton", showStopButton)
            put("showStepsBadge", showStepsBadge)
            put("showOverflowMenu", showOverflowMenu)
            put("showCollapseButton", showCollapseButton)
            if (inputPlaceholder.isNotBlank()) put("inputPlaceholder", inputPlaceholder)
            if (position.isNotBlank()) put("position", position)
            if (xFraction != null) put("xFraction", xFraction.toDouble())
            if (yFraction != null) put("yFraction", yFraction.toDouble())
            if (widthFraction != null) put("widthFraction", widthFraction.toDouble())
        }

        fun merge(patch: JSONObject): HudLayoutConfig = copy(
            collapsed = if (patch.has("collapsed")) {
                if (patch.isNull("collapsed")) null else patch.optBoolean("collapsed")
            } else collapsed,
            detailsExpanded = if (patch.has("detailsExpanded")) {
                if (patch.isNull("detailsExpanded")) null else patch.optBoolean("detailsExpanded")
            } else detailsExpanded,
            macrosDrawerOpen = if (patch.has("macrosDrawerOpen")) {
                if (patch.isNull("macrosDrawerOpen")) null else patch.optBoolean("macrosDrawerOpen")
            } else macrosDrawerOpen,
            showComposer = if (patch.has("showComposer")) patch.optBoolean("showComposer", showComposer) else showComposer,
            showMic = if (patch.has("showMic")) patch.optBoolean("showMic", showMic) else showMic,
            showMacros = if (patch.has("showMacros")) patch.optBoolean("showMacros", showMacros) else showMacros,
            showStopButton = if (patch.has("showStopButton")) patch.optBoolean("showStopButton", showStopButton) else showStopButton,
            showStepsBadge = if (patch.has("showStepsBadge")) patch.optBoolean("showStepsBadge", showStepsBadge) else showStepsBadge,
            showOverflowMenu = if (patch.has("showOverflowMenu")) patch.optBoolean("showOverflowMenu", showOverflowMenu) else showOverflowMenu,
            showCollapseButton = if (patch.has("showCollapseButton")) patch.optBoolean("showCollapseButton", showCollapseButton) else showCollapseButton,
            inputPlaceholder = if (patch.has("inputPlaceholder")) patch.optString("inputPlaceholder", "").trim() else inputPlaceholder,
            position = if (patch.has("position")) patch.optString("position", "").lowercase().trim() else position,
            xFraction = if (patch.has("xFraction")) {
                if (patch.isNull("xFraction")) null else patch.optDouble("xFraction", 0.5).toFloat().coerceIn(0f, 1f)
            } else xFraction,
            yFraction = if (patch.has("yFraction")) {
                if (patch.isNull("yFraction")) null else patch.optDouble("yFraction", 0.9).toFloat().coerceIn(0f, 1f)
            } else yFraction,
            widthFraction = if (patch.has("widthFraction")) {
                if (patch.isNull("widthFraction")) null else patch.optDouble("widthFraction", 0.88).toFloat().coerceIn(0.60f, 0.96f)
            } else widthFraction
        )

        companion object {
            fun fromJson(json: JSONObject?, base: HudLayoutConfig = HudLayoutConfig()): HudLayoutConfig {
                if (json == null) return base
                return base.merge(json)
            }
        }
    }

    data class HudProgressConfig(
        val visible: Boolean = false,
        val value: Float = -1f, // -1f = indeterminate, 0f..100f = determinate percent
        val label: String = "",
        val color: String = ""
    ) {
        val isDeterminate: Boolean get() = value >= 0f
        val fraction: Float get() = (value / 100f).coerceIn(0f, 1f)

        fun toJson(): JSONObject = JSONObject().apply {
            put("visible", visible)
            put("value", value.toDouble())
            if (label.isNotBlank()) put("label", label)
            if (color.isNotBlank()) put("color", color)
        }

        companion object {
            fun fromJson(raw: Any?, base: HudProgressConfig = HudProgressConfig()): HudProgressConfig {
                return when (raw) {
                    null -> HudProgressConfig(visible = false)
                    is Number -> {
                        val v = raw.toFloat()
                        HudProgressConfig(visible = true, value = if (v < 0f) -1f else v.coerceIn(0f, 100f))
                    }
                    is JSONObject -> {
                        val vis = if (raw.has("visible")) raw.optBoolean("visible", true) else true
                        val v = if (raw.has("value")) {
                            if (raw.isNull("value")) -1f else raw.optDouble("value", -1.0).toFloat()
                        } else if (raw.has("percent")) {
                            raw.optDouble("percent", -1.0).toFloat()
                        } else {
                            base.value
                        }
                        HudProgressConfig(
                            visible = vis,
                            value = if (v < 0f) -1f else v.coerceIn(0f, 100f),
                            label = if (raw.has("label")) raw.optString("label", "").trim() else base.label,
                            color = if (raw.has("color")) raw.optString("color", "").trim() else base.color
                        )
                    }
                    else -> base
                }
            }
        }
    }

    data class HudMetricItem(
        val id: String,
        val label: String,
        val value: String,
        val accentColor: String = "",
        val icon: String = ""
    ) {
        fun toJson(): JSONObject = JSONObject().apply {
            put("id", id)
            put("label", label)
            put("value", value)
            if (accentColor.isNotBlank()) put("accentColor", accentColor)
            if (icon.isNotBlank()) put("icon", icon)
        }

        companion object {
            fun fromJson(obj: JSONObject, fallbackIndex: Int = 0): HudMetricItem? {
                val lbl = obj.optString("label", "").trim()
                val valStr = obj.optString("value", "").trim()
                if (lbl.isEmpty() && valStr.isEmpty()) return null
                val id = obj.optString("id", lbl.lowercase().replace(" ", "_").ifBlank { "m_$fallbackIndex" }).trim()
                return HudMetricItem(
                    id = id,
                    label = lbl,
                    value = valStr,
                    accentColor = obj.optString("accentColor", obj.optString("color", "")).trim(),
                    icon = obj.optString("icon", "").trim()
                )
            }
        }
    }

    data class HudBannerConfig(
        val visible: Boolean = false,
        val level: String = "info", // info | success | warning | error
        val title: String = "",
        val message: String = "",
        val accentColor: String = ""
    ) {
        fun toJson(): JSONObject = JSONObject().apply {
            put("visible", visible)
            put("level", level)
            if (title.isNotBlank()) put("title", title)
            if (message.isNotBlank()) put("message", message)
            if (accentColor.isNotBlank()) put("accentColor", accentColor)
        }

        companion object {
            fun fromJson(raw: Any?): HudBannerConfig {
                return when (raw) {
                    null -> HudBannerConfig(visible = false)
                    is String -> {
                        val msg = raw.trim()
                        HudBannerConfig(visible = msg.isNotEmpty(), level = "info", message = msg)
                    }
                    is JSONObject -> {
                        val title = raw.optString("title", "").trim()
                        val msg = raw.optString("message", raw.optString("text", "")).trim()
                        val vis = if (raw.has("visible")) raw.optBoolean("visible", true) else (title.isNotEmpty() || msg.isNotEmpty())
                        HudBannerConfig(
                            visible = vis && (title.isNotEmpty() || msg.isNotEmpty()),
                            level = raw.optString("level", "info").lowercase().trim().ifBlank { "info" },
                            title = title,
                            message = msg,
                            accentColor = raw.optString("accentColor", raw.optString("color", "")).trim()
                        )
                    }
                    else -> HudBannerConfig(visible = false)
                }
            }
        }
    }

    data class HudContentBlock(
        val id: String,
        val type: String = "text", // kv | code | text | progress
        val title: String = "",
        val body: String = "",
        val items: List<Pair<String, String>> = emptyList(),
        val progressValue: Float? = null,
        val accentColor: String = "",
        val inDetails: Boolean = false
    ) {
        fun toJson(): JSONObject = JSONObject().apply {
            put("id", id)
            put("type", type)
            if (title.isNotBlank()) put("title", title)
            if (body.isNotBlank()) put("body", body)
            if (items.isNotEmpty()) {
                put("items", JSONArray().apply {
                    items.forEach { (k, v) ->
                        put(JSONObject().put("key", k).put("value", v))
                    }
                })
            }
            if (progressValue != null) put("progressValue", progressValue.toDouble())
            if (accentColor.isNotBlank()) put("accentColor", accentColor)
            put("inDetails", inDetails)
        }

        companion object {
            fun fromJson(obj: JSONObject, fallbackIndex: Int = 0): HudContentBlock? {
                val type = obj.optString("type", "text").lowercase().trim().ifBlank { "text" }
                val title = obj.optString("title", "").trim()
                val body = obj.optString("body", obj.optString("text", "")).trim()
                val items = mutableListOf<Pair<String, String>>()
                val itemsArr = obj.optJSONArray("items")
                if (itemsArr != null) {
                    for (i in 0 until itemsArr.length()) {
                        val row = itemsArr.optJSONObject(i) ?: continue
                        val k = row.optString("key", row.optString("label", "")).trim()
                        val v = row.optString("value", "").trim()
                        if (k.isNotEmpty() || v.isNotEmpty()) items.add(k to v)
                    }
                }
                val progressVal = if (obj.has("progressValue") || obj.has("value")) {
                    val rawKey = if (obj.has("progressValue")) "progressValue" else "value"
                    if (!obj.isNull(rawKey) && obj.opt(rawKey) is Number) {
                        obj.optDouble(rawKey, 0.0).toFloat().coerceIn(0f, 100f)
                    } else null
                } else null
                if (title.isEmpty() && body.isEmpty() && items.isEmpty() && progressVal == null) return null
                val id = obj.optString("id", "blk_$fallbackIndex").trim().ifBlank { "blk_$fallbackIndex" }
                return HudContentBlock(
                    id = id,
                    type = type,
                    title = title,
                    body = body,
                    items = items,
                    progressValue = progressVal,
                    accentColor = obj.optString("accentColor", obj.optString("color", "")).trim(),
                    inDetails = obj.optBoolean("inDetails", false)
                )
            }
        }
    }

    data class TaskMapPaneBounds(
        val x1: Int = 0,
        val y1: Int = 0,
        val x2: Int = 1080,
        val y2: Int = 2400,
        val screenWidth: Int = 1080,
        val screenHeight: Int = 2400
    ) {
        val width: Int get() = (x2 - x1).coerceAtLeast(1)
        val height: Int get() = (y2 - y1).coerceAtLeast(1)

        fun toJson(): JSONObject = JSONObject().apply {
            put("x1", x1)
            put("y1", y1)
            put("x2", x2)
            put("y2", y2)
            put("screenWidth", screenWidth)
            put("screenHeight", screenHeight)
        }

        companion object {
            fun fromJson(obj: JSONObject?): TaskMapPaneBounds? {
                if (obj == null) return null
                val x1 = obj.optInt("x1", 0)
                val y1 = obj.optInt("y1", 0)
                val x2 = obj.optInt("x2", obj.optInt("width", 1080) + x1)
                val y2 = obj.optInt("y2", obj.optInt("height", 2400) + y1)
                val sw = obj.optInt("screenWidth", x2.coerceAtLeast(1080))
                val sh = obj.optInt("screenHeight", y2.coerceAtLeast(2400))
                if (x2 <= x1 || y2 <= y1) return null
                return TaskMapPaneBounds(x1, y1, x2, y2, sw.coerceAtLeast(100), sh.coerceAtLeast(100))
            }
        }
    }

    data class ChessMoveSquare(
        val from: String = "",
        val to: String = ""
    ) {
        val isValid: Boolean get() = from.length >= 2 && to.length >= 2

        fun toJson(): JSONObject = JSONObject().apply {
            put("from", from)
            put("to", to)
        }

        companion object {
            fun fromAny(raw: Any?): ChessMoveSquare? {
                return when (raw) {
                    is JSONObject -> {
                        val f = raw.optString("from", "").trim().lowercase()
                        val t = raw.optString("to", "").trim().lowercase()
                        if (f.length >= 2 && t.length >= 2) ChessMoveSquare(f.take(2), t.take(2)) else null
                    }
                    is String -> {
                        val cleaned = raw.trim().lowercase().replace("->", "").replace(" ", "")
                        if (cleaned.length >= 4) ChessMoveSquare(cleaned.substring(0, 2), cleaned.substring(2, 4)) else null
                    }
                    else -> null
                }
            }
        }
    }

    data class ChessTaskMapData(
        val fen: String = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR",
        val playerColor: String = "white", // white | black
        val evalCp: String = "0.0",
        val lastMove: ChessMoveSquare? = null,
        val bestMove: ChessMoveSquare? = null,
        val turnLabel: String = ""
    ) {
        fun toJson(): JSONObject = JSONObject().apply {
            put("fen", fen)
            put("playerColor", playerColor)
            put("evalCp", evalCp)
            if (lastMove != null) put("lastMove", lastMove.toJson())
            if (bestMove != null) put("bestMove", bestMove.toJson())
            if (turnLabel.isNotBlank()) put("turnLabel", turnLabel)
        }

        companion object {
            fun fromJson(obj: JSONObject?): ChessTaskMapData? {
                if (obj == null) return null
                val fen = obj.optString("fen", "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR").trim()
                    .ifBlank { "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR" }
                val color = obj.optString("playerColor", "white").lowercase().trim()
                    .let { if (it == "black") "black" else "white" }
                val evalRaw = if (obj.has("evalCp")) {
                    val v = obj.opt("evalCp")
                    when (v) {
                        is Number -> {
                            val d = v.toDouble()
                            val pawns = if (kotlin.math.abs(d) >= 15.0) d / 100.0 else d
                            if (pawns >= 0) String.format(java.util.Locale.US, "+%.1f", pawns)
                            else String.format(java.util.Locale.US, "%.1f", pawns)
                        }
                        else -> v?.toString()?.trim().orEmpty().ifBlank { "0.0" }
                    }
                } else "0.0"
                return ChessTaskMapData(
                    fen = fen,
                    playerColor = color,
                    evalCp = evalRaw,
                    lastMove = ChessMoveSquare.fromAny(obj.opt("lastMove")),
                    bestMove = ChessMoveSquare.fromAny(obj.opt("bestMove")),
                    turnLabel = obj.optString("turnLabel", "").trim()
                )
            }
        }
    }

    data class MediaTaskMapData(
        val provider: String = "",
        val title: String = "Playing Media",
        val subtitle: String = "",
        val appPackage: String = "",
        val progressPercent: Float = 0f,
        val elapsedText: String = "",
        val durationText: String = "",
        val playing: Boolean = true
    ) {
        fun toJson(): JSONObject = JSONObject().apply {
            if (provider.isNotBlank()) put("provider", provider)
            put("title", title)
            if (subtitle.isNotBlank()) put("subtitle", subtitle)
            if (appPackage.isNotBlank()) put("appPackage", appPackage)
            put("progressPercent", progressPercent.toDouble())
            if (elapsedText.isNotBlank()) put("elapsedText", elapsedText)
            if (durationText.isNotBlank()) put("durationText", durationText)
            put("playing", playing)
        }

        companion object {
            fun fromJson(obj: JSONObject?): MediaTaskMapData? {
                if (obj == null) return null
                return MediaTaskMapData(
                    provider = obj.optString("provider", "").trim(),
                    title = obj.optString("title", "Now Playing").trim().ifBlank { "Now Playing" },
                    subtitle = obj.optString("subtitle", obj.optString("artist", obj.optString("channel", ""))).trim(),
                    appPackage = obj.optString("appPackage", "").trim(),
                    progressPercent = obj.optDouble("progressPercent", obj.optDouble("progress", 0.0)).toFloat().coerceIn(0f, 100f),
                    elapsedText = obj.optString("elapsedText", "").trim(),
                    durationText = obj.optString("durationText", "").trim(),
                    playing = obj.optBoolean("playing", true)
                )
            }
        }
    }

    data class TelemetryTaskMapData(
        val title: String = "Telemetry",
        val percent: Float = -1f,
        val accentColor: String = "",
        val metrics: List<Pair<String, String>> = emptyList()
    ) {
        fun toJson(): JSONObject = JSONObject().apply {
            put("title", title)
            put("percent", percent.toDouble())
            if (accentColor.isNotBlank()) put("accentColor", accentColor)
            put("metrics", JSONArray().apply {
                metrics.forEach { (k, v) -> put(JSONObject().put("label", k).put("value", v)) }
            })
        }

        companion object {
            fun fromJson(obj: JSONObject?): TelemetryTaskMapData? {
                if (obj == null) return null
                val metrics = mutableListOf<Pair<String, String>>()
                val arr = obj.optJSONArray("metrics")
                if (arr != null) {
                    for (i in 0 until arr.length()) {
                        val row = arr.optJSONObject(i) ?: continue
                        val lbl = row.optString("label", row.optString("key", "")).trim()
                        val valStr = row.optString("value", "").trim()
                        if (lbl.isNotEmpty() || valStr.isNotEmpty()) metrics.add(lbl to valStr)
                    }
                }
                return TelemetryTaskMapData(
                    title = obj.optString("title", "Telemetry").trim().ifBlank { "Telemetry" },
                    percent = obj.optDouble("percent", obj.optDouble("value", -1.0)).toFloat().let {
                        if (it < 0f) -1f else it.coerceIn(0f, 100f)
                    },
                    accentColor = obj.optString("accentColor", obj.optString("color", "")).trim(),
                    metrics = metrics
                )
            }
        }
    }

    data class TaskMapZone(
        val x1: Float,
        val y1: Float,
        val x2: Float,
        val y2: Float,
        val role: String = "panel", // search_bar | toggle | input | list_row | cta_button | target | header | card | panel
        val tag: String = "",
        val checked: Boolean? = null
    ) {
        fun toJson(): JSONObject = JSONObject().apply {
            put("x1", x1.toDouble())
            put("y1", y1.toDouble())
            put("x2", x2.toDouble())
            put("y2", y2.toDouble())
            put("role", role)
            put("tag", tag)
            if (checked != null) put("checked", checked)
        }

        companion object {
            fun fromJson(obj: JSONObject): TaskMapZone = TaskMapZone(
                x1 = obj.optDouble("x1", 0.0).toFloat(),
                y1 = obj.optDouble("y1", 0.0).toFloat(),
                x2 = obj.optDouble("x2", 0.0).toFloat(),
                y2 = obj.optDouble("y2", 0.0).toFloat(),
                role = obj.optString("role", "panel").trim().ifBlank { "panel" },
                tag = obj.optString("tag", "").trim(),
                checked = if (obj.has("checked") && !obj.isNull("checked")) obj.optBoolean("checked") else null
            )
        }
    }

    data class TaskMapActionVector(
        val type: String = "TAP",
        val x1: Float,
        val y1: Float,
        val x2: Float = x1,
        val y2: Float = y1
    ) {
        fun toJson(): JSONObject = JSONObject().apply {
            put("type", type)
            put("x1", x1.toDouble())
            put("y1", y1.toDouble())
            put("x2", x2.toDouble())
            put("y2", y2.toDouble())
        }

        companion object {
            fun fromJson(obj: JSONObject?): TaskMapActionVector? {
                if (obj == null) return null
                val x1 = obj.optDouble("x1", 0.0).toFloat()
                val y1 = obj.optDouble("y1", 0.0).toFloat()
                return TaskMapActionVector(
                    type = obj.optString("type", "TAP").uppercase().trim().ifBlank { "TAP" },
                    x1 = x1,
                    y1 = y1,
                    x2 = obj.optDouble("x2", x1.toDouble()).toFloat(),
                    y2 = obj.optDouble("y2", y1.toDouble()).toFloat()
                )
            }
        }
    }

    data class AppPaneTaskMapData(
        val targetPackage: String = "",
        val screenWidth: Int = 1080,
        val screenHeight: Int = 2400,
        val zones: List<TaskMapZone> = emptyList(),
        val actionVector: TaskMapActionVector? = null
    ) {
        fun toJson(): JSONObject = JSONObject().apply {
            if (targetPackage.isNotBlank()) put("targetPackage", targetPackage)
            put("screenWidth", screenWidth)
            put("screenHeight", screenHeight)
            put("zones", JSONArray().apply { zones.forEach { put(it.toJson()) } })
            if (actionVector != null) put("actionVector", actionVector.toJson())
        }

        companion object {
            fun fromJson(obj: JSONObject?): AppPaneTaskMapData? {
                if (obj == null) return null
                val zonesArr = obj.optJSONArray("zones") ?: JSONArray()
                val parsedZones = buildList {
                    for (i in 0 until zonesArr.length()) {
                        val z = zonesArr.optJSONObject(i) ?: continue
                        add(TaskMapZone.fromJson(z))
                    }
                }
                return AppPaneTaskMapData(
                    targetPackage = obj.optString("targetPackage", obj.optString("packageName", "")).trim(),
                    screenWidth = obj.optInt("screenWidth", 1080).coerceAtLeast(100),
                    screenHeight = obj.optInt("screenHeight", 2400).coerceAtLeast(100),
                    zones = parsedZones,
                    actionVector = TaskMapActionVector.fromJson(obj.optJSONObject("actionVector"))
                )
            }
        }
    }

    data class ResultMediaItem(
        val id: String = "",
        val kind: String = "image", // image | video | file
        val title: String = "",
        val subtitle: String = "",
        val uri: String = "",
        val thumbnailUri: String = "",
        val mimeType: String = "",
        val previewText: String = "",
        val fileSizeLabel: String = ""
    ) {
        fun toJson(): JSONObject = JSONObject().apply {
            if (id.isNotBlank()) put("id", id)
            put("kind", kind)
            if (title.isNotBlank()) put("title", title)
            if (subtitle.isNotBlank()) put("subtitle", subtitle)
            if (uri.isNotBlank()) put("uri", uri)
            if (thumbnailUri.isNotBlank()) put("thumbnailUri", thumbnailUri)
            if (mimeType.isNotBlank()) put("mimeType", mimeType)
            if (previewText.isNotBlank()) put("previewText", previewText)
            if (fileSizeLabel.isNotBlank()) put("fileSizeLabel", fileSizeLabel)
        }

        companion object {
            fun fromJson(obj: JSONObject, fallbackIndex: Int = 0): ResultMediaItem? {
                val uri = obj.optString("uri", obj.optString("url", obj.optString("path", ""))).trim()
                val title = obj.optString("title", obj.optString("name", obj.optString("caption", ""))).trim()
                val preview = obj.optString("previewText", obj.optString("excerpt", "")).trim()
                if (uri.isEmpty() && title.isEmpty() && preview.isEmpty()) return null
                val rawKind = obj.optString("kind", obj.optString("type", "")).lowercase().trim()
                val mime = obj.optString("mimeType", obj.optString("mime", "")).lowercase().trim()
                val inferredKind = when {
                    rawKind in setOf("image", "img", "photo", "picture") -> "image"
                    rawKind in setOf("video", "vid", "clip", "mp4") -> "video"
                    rawKind in setOf("file", "doc", "document", "pdf", "apk", "code") -> "file"
                    mime.startsWith("image/") -> "image"
                    mime.startsWith("video/") -> "video"
                    uri.lowercase().let { u ->
                        u.startsWith("data:image/") ||
                            u.substringBefore('?').substringBefore('#').let { clean ->
                                clean.endsWith(".jpg") || clean.endsWith(".jpeg") ||
                                    clean.endsWith(".png") || clean.endsWith(".webp") ||
                                    clean.endsWith(".gif") || clean.endsWith(".bmp")
                            }
                    } -> "image"
                    (uri.lowercase().substringBefore('?').substringBefore('#').let { clean ->
                        clean.endsWith(".mp4") || clean.endsWith(".mov") ||
                            clean.endsWith(".webm") || clean.endsWith(".mkv") ||
                            clean.endsWith(".m4v") || clean.endsWith(".m3u8")
                    } || PlayerTrackItem.extractYouTubeVideoId(uri) != null) -> "video"
                    else -> "file"
                }
                val id = obj.optString("id", "res_$fallbackIndex").trim().ifBlank { "res_$fallbackIndex" }
                val fallbackTitle = if (title.isNotEmpty()) title else uri.substringAfterLast('/').substringBefore('?').ifBlank {
                    when (inferredKind) {
                        "image" -> "Image ${fallbackIndex + 1}"
                        "video" -> "Video ${fallbackIndex + 1}"
                        else -> "File ${fallbackIndex + 1}"
                    }
                }
                return ResultMediaItem(
                    id = id,
                    kind = inferredKind,
                    title = fallbackTitle,
                    subtitle = obj.optString("subtitle", obj.optString("source", "")).trim(),
                    uri = uri,
                    thumbnailUri = obj.optString("thumbnailUri", obj.optString("thumbnail", obj.optString("poster", ""))).trim(),
                    mimeType = mime,
                    previewText = preview,
                    fileSizeLabel = obj.optString("fileSizeLabel", obj.optString("size", "")).trim()
                )
            }
        }
    }

    data class ResultsTaskMapData(
        val query: String = "",
        val summaryTitle: String = "",
        val summaryText: String = "",
        val sourceLabel: String = "",
        val loading: Boolean = false,
        val items: List<ResultMediaItem> = emptyList()
    ) {
        fun contentSignature(): String =
            "$query|$summaryTitle|$summaryText|$loading|${items.joinToString(",") { "${it.id}:${it.kind}:${it.uri}:${it.title}" }}"

        fun toJson(): JSONObject = JSONObject().apply {
            if (query.isNotBlank()) put("query", query)
            if (summaryTitle.isNotBlank()) put("summaryTitle", summaryTitle)
            if (summaryText.isNotBlank()) put("summaryText", summaryText)
            if (sourceLabel.isNotBlank()) put("sourceLabel", sourceLabel)
            put("loading", loading)
            put("items", JSONArray().apply { items.forEach { put(it.toJson()) } })
        }

        companion object {
            fun fromJson(obj: JSONObject?): ResultsTaskMapData? {
                if (obj == null) return null
                val arr = obj.optJSONArray("items") ?: obj.optJSONArray("media") ?: JSONArray()
                val parsedItems = buildList {
                    for (i in 0 until arr.length()) {
                        val row = arr.optJSONObject(i) ?: continue
                        ResultMediaItem.fromJson(row, i)?.let { add(it) }
                    }
                }
                val query = obj.optString("query", "").trim()
                val summaryTitle = obj.optString("summaryTitle", obj.optString("headline", "")).trim()
                val summaryText = obj.optString("summaryText", obj.optString("summary", obj.optString("answer", ""))).trim()
                val sourceLabel = obj.optString("sourceLabel", obj.optString("source", "")).trim()
                val loading = obj.optBoolean("loading", false)
                if (query.isEmpty() && summaryTitle.isEmpty() && summaryText.isEmpty() && parsedItems.isEmpty() && !loading) {
                    return null
                }
                return ResultsTaskMapData(
                    query = query,
                    summaryTitle = summaryTitle,
                    summaryText = summaryText,
                    sourceLabel = sourceLabel,
                    loading = loading,
                    items = parsedItems
                )
            }
        }
    }

    data class PlayerTrackItem(
        val id: String = "",
        val title: String = "Now Playing",
        val subtitle: String = "",
        val uri: String = "",
        val mimeType: String = "",
        val thumbnailUri: String = "",
        val isVideo: Boolean = true,
        val isWebEmbed: Boolean = false,
        val durationMs: Long = 0L
    ) {
        fun toResultMediaItem(): ResultMediaItem = ResultMediaItem(
            id = id.ifBlank { "track_0" },
            kind = if (isVideo) "video" else "file",
            title = title,
            subtitle = subtitle,
            uri = uri,
            thumbnailUri = thumbnailUri,
            mimeType = mimeType.ifBlank { if (isVideo) "video/mp4" else "audio/mpeg" }
        )

        fun toJson(): JSONObject = JSONObject().apply {
            if (id.isNotBlank()) put("id", id)
            put("title", title)
            if (subtitle.isNotBlank()) put("subtitle", subtitle)
            put("uri", uri)
            if (mimeType.isNotBlank()) put("mimeType", mimeType)
            if (thumbnailUri.isNotBlank()) put("thumbnailUri", thumbnailUri)
            put("isVideo", isVideo)
            put("isWebEmbed", isWebEmbed)
            if (durationMs > 0L) put("durationMs", durationMs)
        }

        companion object {
            fun extractYouTubeVideoId(rawUri: String): String? {
                val u = rawUri.trim()
                if (u.isEmpty()) return null
                // Direct 11-char ID if explicitly passed as youtube:ID
                if (u.startsWith("youtube:", ignoreCase = true)) {
                    return u.substringAfter(':').trim().takeIf { it.isNotEmpty() }
                }
                val lower = u.lowercase()
                val ytBeIdx = lower.indexOf("youtu.be/")
                if (ytBeIdx >= 0) {
                    val after = u.substring(ytBeIdx + "youtu.be/".length)
                    val id = after.substringBefore('?').substringBefore('&').substringBefore('#').substringBefore('/').trim()
                    if (id.isNotEmpty()) return id
                }
                if ("youtube.com/" in lower || "youtube-nocookie.com/" in lower) {
                    for (segment in listOf("/embed/", "/shorts/", "/live/")) {
                        val segIdx = lower.indexOf(segment)
                        if (segIdx >= 0) {
                            val after = u.substring(segIdx + segment.length)
                            val id = after.substringBefore('?').substringBefore('&').substringBefore('#').substringBefore('/').trim()
                            if (id.isNotEmpty()) return id
                        }
                    }
                    val query = u.substringAfter('?', "")
                    for (part in query.split('&')) {
                        val kv = part.split('=', limit = 2)
                        if (kv.size == 2 && kv[0].trim() == "v" && kv[1].isNotBlank()) {
                            return kv[1].substringBefore('#').trim()
                        }
                    }
                }
                return null
            }

            fun isWebEmbedUri(rawUri: String, explicitEmbed: Boolean = false): Boolean {
                if (explicitEmbed) return true
                val u = rawUri.trim().lowercase()
                if (u.isEmpty()) return false
                if (extractYouTubeVideoId(rawUri) != null) return true
                val clean = u.substringBefore('?').substringBefore('#')
                val hasDirectMediaExt = clean.endsWith(".mp3") || clean.endsWith(".mp4") ||
                    clean.endsWith(".m4a") || clean.endsWith(".wav") || clean.endsWith(".ogg") ||
                    clean.endsWith(".flac") || clean.endsWith(".aac") || clean.endsWith(".opus") ||
                    clean.endsWith(".webm") || clean.endsWith(".mkv") || clean.endsWith(".mov") ||
                    clean.endsWith(".m4v") || clean.endsWith(".3gp") || clean.endsWith(".m3u8")
                if (hasDirectMediaExt) return false
                return "youtube.com/" in u || "youtu.be/" in u || "vimeo.com/" in u ||
                    "soundcloud.com/" in u || "open.spotify.com/embed" in u || "/embed/" in u
            }

            fun resolveWebEmbedUrl(rawUri: String): String {
                val ytId = extractYouTubeVideoId(rawUri)
                if (ytId != null) {
                    return "https://www.youtube.com/embed/$ytId?autoplay=1&playsinline=1&enablejsapi=1&rel=0"
                }
                return rawUri.trim()
            }

            fun inferIsVideo(rawUri: String, mimeType: String, rawKind: String): Boolean {
                val k = rawKind.lowercase().trim()
                val m = mimeType.lowercase().trim()
                if (k in setOf("audio", "music", "song", "mp3", "podcast", "voice", "sound", "radio", "track")) {
                    return false
                }
                if (k in setOf("video", "vid", "clip", "movie", "mp4", "youtube", "embed")) {
                    return true
                }
                if (m.startsWith("audio/")) return false
                if (m.startsWith("video/")) return true
                val clean = rawUri.lowercase().substringBefore('?').substringBefore('#')
                if (clean.endsWith(".mp3") || clean.endsWith(".m4a") || clean.endsWith(".wav") ||
                    clean.endsWith(".ogg") || clean.endsWith(".flac") || clean.endsWith(".aac") ||
                    clean.endsWith(".opus")
                ) {
                    return false
                }
                return true
            }

            fun fromJson(raw: Any?, fallbackIndex: Int = 0): PlayerTrackItem? {
                return when (raw) {
                    is String -> {
                        val uri = raw.trim()
                        if (uri.isEmpty()) return null
                        val isVideo = inferIsVideo(uri, "", "")
                        val isEmbed = isWebEmbedUri(uri)
                        val fallbackTitle = extractYouTubeVideoId(uri)?.let { "YouTube ($it)" }
                            ?: uri.substringAfterLast('/').substringBefore('?').ifBlank {
                                if (isVideo) "Video ${fallbackIndex + 1}" else "Track ${fallbackIndex + 1}"
                            }
                        PlayerTrackItem(
                            id = "trk_$fallbackIndex",
                            title = fallbackTitle,
                            uri = uri,
                            isVideo = isVideo,
                            isWebEmbed = isEmbed
                        )
                    }
                    is JSONObject -> {
                        val videoId = raw.optString("videoId", raw.optString("youtubeId", "")).trim()
                        val rawUri = raw.optString(
                            "uri",
                            raw.optString("url", raw.optString("path", raw.optString("src", "")))
                        ).trim()
                        val uri = when {
                            rawUri.isNotEmpty() -> rawUri
                            videoId.isNotEmpty() -> "https://www.youtube.com/watch?v=$videoId"
                            else -> ""
                        }
                        val title = raw.optString(
                            "title",
                            raw.optString("name", raw.optString("track", ""))
                        ).trim()
                        if (uri.isEmpty() && title.isEmpty()) return null
                        val mime = raw.optString("mimeType", raw.optString("mime", "")).trim()
                        val rawKind = raw.optString(
                            "kind",
                            raw.optString("type", raw.optString("mediaType", ""))
                        ).trim()
                        val isVideo = if (raw.has("isVideo") && !raw.isNull("isVideo")) {
                            raw.optBoolean("isVideo", true)
                        } else {
                            inferIsVideo(uri, mime, rawKind)
                        }
                        val explicitEmbed = raw.optBoolean("isWebEmbed", raw.optBoolean("embed", false))
                        val isEmbed = isWebEmbedUri(uri, explicitEmbed)
                        val resolvedTitle = title.ifBlank {
                            extractYouTubeVideoId(uri)?.let { "YouTube ($it)" }
                                ?: uri.substringAfterLast('/').substringBefore('?').ifBlank {
                                    if (isVideo) "Video ${fallbackIndex + 1}" else "Track ${fallbackIndex + 1}"
                                }
                        }
                        val subtitle = raw.optString(
                            "subtitle",
                            raw.optString("artist", raw.optString("channel", raw.optString("author", "")))
                        ).trim()
                        val thumb = raw.optString(
                            "thumbnailUri",
                            raw.optString("thumbnailUrl", raw.optString("thumbnail", raw.optString("poster", raw.optString("cover", ""))))
                        ).trim()
                        val durMs = when {
                            raw.has("durationMs") -> raw.optLong("durationMs", 0L).coerceAtLeast(0L)
                            raw.has("durationSeconds") -> (raw.optDouble("durationSeconds", 0.0) * 1000.0).toLong().coerceAtLeast(0L)
                            raw.has("duration") -> {
                                val dVal = raw.optDouble("duration", 0.0)
                                if (dVal > 1000.0) dVal.toLong() else (dVal * 1000.0).toLong().coerceAtLeast(0L)
                            }
                            else -> 0L
                        }
                        PlayerTrackItem(
                            id = raw.optString("id", "trk_$fallbackIndex").trim().ifBlank { "trk_$fallbackIndex" },
                            title = resolvedTitle,
                            subtitle = subtitle,
                            uri = uri,
                            mimeType = mime,
                            thumbnailUri = thumb,
                            isVideo = isVideo,
                            isWebEmbed = isEmbed,
                            durationMs = durMs
                        )
                    }
                    else -> null
                }
            }
        }
    }

    data class PlayerTaskMapData(
        val mediaMode: String = "video", // video | audio
        val backgroundMode: Boolean = false, // true -> collapse to floating mini-pill & play in BG
        val playing: Boolean = true,
        val loop: Boolean = false,
        val muted: Boolean = false,
        val volume: Float = 1.0f, // 0.0f .. 1.0f
        val speed: Float = 1.0f, // 0.5f .. 2.0f
        val currentIndex: Int = 0,
        val positionMs: Long = 0L,
        val durationMs: Long = 0L,
        val action: String = "", // play | pause | toggle | next | prev | seek | set_mode | set_bg | enqueue | stop
        val playlist: List<PlayerTrackItem> = emptyList()
    ) {
        fun currentTrack(): PlayerTrackItem? {
            if (playlist.isEmpty()) return null
            return playlist[currentIndex.coerceIn(0, playlist.lastIndex)]
        }

        fun contentSignature(): String =
            "player:$mediaMode:${playlist.joinToString(",") { "${it.id}:${it.uri}:${it.title}" }}"

        fun toJson(): JSONObject = JSONObject().apply {
            put("mediaMode", mediaMode)
            put("backgroundMode", backgroundMode)
            put("bg", backgroundMode)
            put("playing", playing)
            put("loop", loop)
            put("muted", muted)
            put("volume", volume.toDouble())
            put("speed", speed.toDouble())
            put("currentIndex", currentIndex)
            put("positionMs", positionMs)
            if (durationMs > 0L) put("durationMs", durationMs)
            if (action.isNotBlank()) put("action", action)
            currentTrack()?.let { trk ->
                put("title", trk.title)
                if (trk.subtitle.isNotBlank()) put("subtitle", trk.subtitle)
                put("uri", trk.uri)
            }
            put("playlist", JSONArray().apply { playlist.forEach { put(it.toJson()) } })
        }

        companion object {
            fun hasPlayableFields(obj: JSONObject?): Boolean {
                if (obj == null) return false
                return obj.has("uri") || obj.has("url") || obj.has("path") || obj.has("src") ||
                    obj.has("videoId") || obj.has("youtubeId") ||
                    obj.has("playlist") || obj.has("tracks") || obj.has("queue") ||
                    obj.has("mediaMode") || obj.has("bg") || obj.has("backgroundMode") ||
                    obj.has("action") || obj.has("seekMs") || obj.has("positionMs")
            }

            fun fromJson(obj: JSONObject?, previous: PlayerTaskMapData? = null): PlayerTaskMapData? {
                if (obj == null) return previous
                val arr = obj.optJSONArray("playlist")
                    ?: obj.optJSONArray("tracks")
                    ?: obj.optJSONArray("queue")
                    ?: obj.optJSONArray("items")
                val parsedTracks = mutableListOf<PlayerTrackItem>()
                if (arr != null) {
                    for (i in 0 until arr.length()) {
                        PlayerTrackItem.fromJson(arr.opt(i), i)?.let { parsedTracks.add(it) }
                    }
                }
                val singleTrack = if (parsedTracks.isEmpty() &&
                    (obj.has("uri") || obj.has("url") || obj.has("path") || obj.has("src") || obj.has("videoId") || obj.has("youtubeId"))
                ) {
                    PlayerTrackItem.fromJson(obj, 0)
                } else null

                val actionRaw = obj.optString("action", obj.optString("command", "")).lowercase().trim()

                val resolvedPlaylist = when {
                    actionRaw == "enqueue" && previous != null -> {
                        val toAdd = if (parsedTracks.isNotEmpty()) parsedTracks else listOfNotNull(singleTrack)
                        previous.playlist + toAdd.mapIndexed { idx, item ->
                            item.copy(id = "trk_${previous.playlist.size + idx}")
                        }
                    }
                    parsedTracks.isNotEmpty() -> parsedTracks
                    singleTrack != null -> listOf(singleTrack)
                    previous != null -> previous.playlist
                    else -> emptyList()
                }

                val requestedIndex = when {
                    obj.has("currentIndex") -> obj.optInt("currentIndex", 0)
                    obj.has("trackIndex") -> obj.optInt("trackIndex", 0)
                    obj.has("index") -> obj.optInt("index", 0)
                    actionRaw == "next" && previous != null && resolvedPlaylist.isNotEmpty() ->
                        (previous.currentIndex + 1) % resolvedPlaylist.size
                    actionRaw in setOf("prev", "previous") && previous != null && resolvedPlaylist.isNotEmpty() ->
                        if (previous.currentIndex - 1 < 0) resolvedPlaylist.lastIndex else previous.currentIndex - 1
                    previous != null && parsedTracks.isEmpty() && singleTrack == null -> previous.currentIndex
                    else -> 0
                }
                val safeIndex = if (resolvedPlaylist.isEmpty()) 0 else requestedIndex.coerceIn(0, resolvedPlaylist.lastIndex)
                val activeTrack = resolvedPlaylist.getOrNull(safeIndex)

                val rawMediaMode = obj.optString(
                    "mediaMode",
                    obj.optString("playAs", obj.optString("viewMode", obj.optString("format", "")))
                ).lowercase().trim()
                val resolvedMediaMode = when {
                    rawMediaMode in setOf("audio", "music", "song", "audio_only", "audio-only", "mp3") -> "audio"
                    rawMediaMode in setOf("video", "vid", "mp4", "movie") -> "video"
                    obj.has("audioOnly") && obj.optBoolean("audioOnly", false) -> "audio"
                    previous != null && parsedTracks.isEmpty() && singleTrack == null -> previous.mediaMode
                    activeTrack != null -> if (activeTrack.isVideo) "video" else "audio"
                    else -> previous?.mediaMode ?: "video"
                }

                val bgMode = when {
                    obj.has("bg") && !obj.isNull("bg") -> obj.optBoolean("bg", false)
                    obj.has("backgroundMode") && !obj.isNull("backgroundMode") -> obj.optBoolean("backgroundMode", false)
                    obj.has("background") && !obj.isNull("background") -> obj.optBoolean("background", false)
                    rawMediaMode in setOf("bg", "background") -> true
                    else -> previous?.backgroundMode ?: false
                }

                val playing = when {
                    actionRaw in setOf("pause", "stop") -> false
                    actionRaw in setOf("play", "resume", "start") -> true
                    actionRaw == "toggle" -> !(previous?.playing ?: true)
                    obj.has("playing") && !obj.isNull("playing") -> obj.optBoolean("playing", true)
                    else -> previous?.playing ?: true
                }

                val loop = when {
                    actionRaw == "toggle_loop" -> !(previous?.loop ?: false)
                    obj.has("loop") && !obj.isNull("loop") -> obj.optBoolean("loop", false)
                    else -> previous?.loop ?: false
                }

                val muted = when {
                    actionRaw in setOf("mute", "unmute", "toggle_mute") -> when (actionRaw) {
                        "mute" -> true
                        "unmute" -> false
                        else -> !(previous?.muted ?: false)
                    }
                    obj.has("muted") && !obj.isNull("muted") -> obj.optBoolean("muted", false)
                    else -> previous?.muted ?: false
                }

                val volume = if (obj.has("volume") && !obj.isNull("volume")) {
                    val v = obj.optDouble("volume", 1.0).toFloat()
                    if (v > 1.0f) (v / 100f).coerceIn(0f, 1f) else v.coerceIn(0f, 1f)
                } else {
                    previous?.volume ?: 1.0f
                }

                val speed = if (obj.has("speed") && !obj.isNull("speed")) {
                    obj.optDouble("speed", 1.0).toFloat().coerceIn(0.5f, 2.5f)
                } else if (obj.has("playbackSpeed") && !obj.isNull("playbackSpeed")) {
                    obj.optDouble("playbackSpeed", 1.0).toFloat().coerceIn(0.5f, 2.5f)
                } else {
                    previous?.speed ?: 1.0f
                }

                val positionMs = when {
                    obj.has("seekMs") -> obj.optLong("seekMs", 0L).coerceAtLeast(0L)
                    obj.has("positionMs") -> obj.optLong("positionMs", 0L).coerceAtLeast(0L)
                    obj.has("seekSeconds") -> (obj.optDouble("seekSeconds", 0.0) * 1000.0).toLong().coerceAtLeast(0L)
                    else -> if (parsedTracks.isEmpty() && singleTrack == null) (previous?.positionMs ?: 0L) else 0L
                }

                val durationMs = when {
                    obj.has("durationMs") -> obj.optLong("durationMs", 0L).coerceAtLeast(0L)
                    activeTrack != null && activeTrack.durationMs > 0L -> activeTrack.durationMs
                    else -> previous?.durationMs ?: 0L
                }

                if (resolvedPlaylist.isEmpty() && actionRaw.isEmpty() && !hasPlayableFields(obj)) {
                    return null
                }

                return PlayerTaskMapData(
                    mediaMode = resolvedMediaMode,
                    backgroundMode = bgMode,
                    playing = playing,
                    loop = loop,
                    muted = muted,
                    volume = volume,
                    speed = speed,
                    currentIndex = safeIndex,
                    positionMs = positionMs,
                    durationMs = durationMs,
                    action = actionRaw,
                    playlist = resolvedPlaylist
                )
            }
        }
    }

    data class DiagramNode(
        val id: String,
        val label: String,
        val role: String = "step", // step | start | decision | end | service | actor
        val status: String = "pending", // pending | doing | done | error | highlight
        val group: String = "",
        val value: Float? = null,
        val layer: Int = -1
    ) {
        fun toJson(): JSONObject = JSONObject().apply {
            put("id", id)
            put("label", label)
            put("role", role)
            put("status", status)
            if (group.isNotBlank()) put("group", group)
            if (value != null) put("value", value.toDouble())
            if (layer >= 0) put("layer", layer)
        }

        companion object {
            fun normalizeStatus(raw: String): String = when (raw.lowercase().trim()) {
                "done", "completed", "complete", "success", "ok" -> "done"
                "doing", "active", "running", "in_progress", "working" -> "doing"
                "error", "failed", "fail", "blocked" -> "error"
                "highlight", "focus", "selected" -> "highlight"
                else -> "pending"
            }

            fun fromJson(raw: Any?, fallbackIndex: Int = 0): DiagramNode? {
                return when (raw) {
                    is String -> {
                        val lbl = raw.trim()
                        if (lbl.isEmpty()) null else DiagramNode(
                            id = "n_${fallbackIndex + 1}",
                            label = lbl
                        )
                    }
                    is JSONObject -> {
                        val id = raw.optString("id", raw.optString("key", "n_${fallbackIndex + 1}")).trim()
                            .ifBlank { "n_${fallbackIndex + 1}" }
                        val lbl = raw.optString("label", raw.optString("title", raw.optString("name", id))).trim()
                        if (lbl.isEmpty()) return null
                        DiagramNode(
                            id = id,
                            label = lbl.take(48),
                            role = raw.optString("role", raw.optString("shape", raw.optString("type", "step")))
                                .lowercase().trim().ifBlank { "step" },
                            status = normalizeStatus(raw.optString("status", raw.optString("state", "pending"))),
                            group = raw.optString("group", "").trim(),
                            value = if (raw.has("value") && !raw.isNull("value")) raw.optDouble("value").toFloat() else null,
                            layer = if (raw.has("layer") && !raw.isNull("layer")) raw.optInt("layer", -1) else -1
                        )
                    }
                    else -> null
                }
            }
        }
    }

    data class DiagramEdge(
        val fromId: String,
        val toId: String,
        val label: String = "",
        val active: Boolean = false,
        val dashed: Boolean = false
    ) {
        fun toJson(): JSONObject = JSONObject().apply {
            put("from", fromId)
            put("to", toId)
            if (label.isNotBlank()) put("label", label)
            put("active", active)
            if (dashed) put("dashed", true)
        }

        companion object {
            fun fromJson(obj: JSONObject?): DiagramEdge? {
                if (obj == null) return null
                val from = obj.optString("from", obj.optString("source", obj.optString("fromId", ""))).trim()
                val to = obj.optString("to", obj.optString("target", obj.optString("toId", ""))).trim()
                if (from.isEmpty() || to.isEmpty()) return null
                return DiagramEdge(
                    fromId = from,
                    toId = to,
                    label = obj.optString("label", obj.optString("message", obj.optString("text", ""))).trim().take(28),
                    active = obj.optBoolean("active", false),
                    dashed = obj.optBoolean("dashed", obj.optBoolean("reply", false))
                )
            }
        }
    }

    data class DiagramSeriesPoint(
        val label: String,
        val value: Float,
        val maxValue: Float = 100f,
        val colorHex: String = "",
        val status: String = ""
    ) {
        fun toJson(): JSONObject = JSONObject().apply {
            put("label", label)
            put("value", value.toDouble())
            put("maxValue", maxValue.toDouble())
            if (colorHex.isNotBlank()) put("color", colorHex)
            if (status.isNotBlank()) put("status", status)
        }

        companion object {
            fun fromJson(obj: JSONObject?, fallbackIndex: Int = 0): DiagramSeriesPoint? {
                if (obj == null) return null
                val label = obj.optString("label", obj.optString("name", obj.optString("title", "Item ${fallbackIndex + 1}"))).trim()
                val v = when {
                    obj.has("value") && !obj.isNull("value") -> obj.optDouble("value", Double.NaN)
                    obj.has("percent") && !obj.isNull("percent") -> obj.optDouble("percent", Double.NaN)
                    obj.has("y") && !obj.isNull("y") -> obj.optDouble("y", Double.NaN)
                    else -> Double.NaN
                }
                if (v.isNaN()) return null
                val maxV = obj.optDouble("maxValue", obj.optDouble("max", 100.0)).toFloat().coerceAtLeast(1f)
                return DiagramSeriesPoint(
                    label = label.take(24),
                    value = v.toFloat(),
                    maxValue = maxV,
                    colorHex = obj.optString("color", obj.optString("colorHex", "")).trim(),
                    status = obj.optString("status", "").trim().lowercase()
                )
            }
        }
    }

    data class DiagramTaskMapData(
        val diagramType: String = "flowchart", // flowchart | architecture | sequence | timeline | chart
        val subChartType: String = "bar", // bar | line | radial
        val title: String = "",
        val subtitle: String = "",
        val nodes: List<DiagramNode> = emptyList(),
        val edges: List<DiagramEdge> = emptyList(),
        val series: List<DiagramSeriesPoint> = emptyList(),
        val activeNodeId: String = ""
    ) {
        fun isEmpty(): Boolean = nodes.isEmpty() && series.isEmpty()

        fun contentSignature(): String = buildString {
            append(diagramType).append(':').append(subChartType).append(':').append(title).append(':')
            append(activeNodeId).append('|')
            append(nodes.joinToString(",") { "${it.id}:${it.label}:${it.status}" }).append('|')
            append(edges.joinToString(",") { "${it.fromId}->${it.toId}:${it.active}" }).append('|')
            append(series.joinToString(",") { "${it.label}=${it.value}" })
        }

        fun toJson(): JSONObject = JSONObject().apply {
            put("diagramType", diagramType)
            put("subChartType", subChartType)
            if (title.isNotBlank()) put("title", title)
            if (subtitle.isNotBlank()) put("subtitle", subtitle)
            if (activeNodeId.isNotBlank()) put("activeNodeId", activeNodeId)
            put("nodes", JSONArray().apply { nodes.forEach { put(it.toJson()) } })
            put("edges", JSONArray().apply { edges.forEach { put(it.toJson()) } })
            put("series", JSONArray().apply { series.forEach { put(it.toJson()) } })
        }

        companion object {
            private val MERMAID_BLOCK_REGEX = Regex("```mermaid\\s*\\n([\\s\\S]*?)```", RegexOption.IGNORE_CASE)
            private val MERMAID_FLOW_EDGE_REGEX = Regex(
                """^\s*([A-Za-z0-9_.\-]+)(?:\[([^\]]+)\]|\(([^)]+)\)|\{([^}]+)\})?\s*(?:--+>|==+>|-.+->)\s*(?:\|([^|]+)\|\s*)?([A-Za-z0-9_.\-]+)(?:\[([^\]]+)\]|\(([^)]+)\)|\{([^}]+)\})?"""
            )
            private val MERMAID_SEQ_MSG_REGEX = Regex(
                """^\s*([A-Za-z0-9_.\- ]+?)\s*(-+>>?|--+>>?|-+>|-->)\s*([A-Za-z0-9_.\- ]+?)\s*:\s*(.+)$"""
            )
            private val ARROW_CHAIN_REGEX = Regex("""([A-Za-z0-9_ .\-/()]{2,32})\s*(?:->|-->|=>|➜|→)\s*([A-Za-z0-9_ .\-/()]{2,32})""")
            private val PIE_ENTRY_REGEX = Regex("""^\s*"([^"]+)"\s*:\s*([0-9]+(?:\.[0-9]+)?)""")

            fun hasDiagramFields(obj: JSONObject?): Boolean {
                if (obj == null) return false
                return obj.has("diagramType") || obj.has("nodes") || obj.has("edges") ||
                    obj.has("series") || obj.has("mermaid") || obj.has("chartType")
            }

            fun fromJson(raw: Any?): DiagramTaskMapData? {
                if (raw == null) return null
                if (raw is String) {
                    return fromMermaidOrStructure(raw)
                }
                if (raw !is JSONObject) return null

                val mermaidRaw = raw.optString("mermaid", raw.optString("code", raw.optString("syntax", ""))).trim()
                if (mermaidRaw.isNotEmpty() && !raw.has("nodes") && !raw.has("series")) {
                    val parsedMermaid = fromMermaidOrStructure(
                        mermaidRaw,
                        title = raw.optString("title", "").trim()
                    )
                    if (parsedMermaid != null) return parsedMermaid
                }

                val typeRaw = raw.optString("diagramType", raw.optString("type", "flowchart")).lowercase().trim()
                val diagramType = when (typeRaw) {
                    "architecture", "arch", "system", "graph", "node_graph" -> "architecture"
                    "sequence", "seq" -> "sequence"
                    "timeline", "steps", "workflow", "pipeline" -> "timeline"
                    "chart", "bar", "line", "radial", "gauge", "plot" -> "chart"
                    else -> "flowchart"
                }
                val subChartRaw = raw.optString("subChartType", raw.optString("chartType", if (typeRaw in setOf("bar", "line", "radial", "gauge")) typeRaw else "bar"))
                    .lowercase().trim()
                val subChart = when (subChartRaw) {
                    "line", "sparkline", "area" -> "line"
                    "radial", "gauge", "ring", "pie", "donut" -> "radial"
                    else -> "bar"
                }

                val nodesArr = raw.optJSONArray("nodes") ?: raw.optJSONArray("steps") ?: raw.optJSONArray("actors") ?: JSONArray()
                val parsedNodes = buildList {
                    for (i in 0 until nodesArr.length()) {
                        DiagramNode.fromJson(nodesArr.opt(i), i)?.let { add(it) }
                    }
                }.take(16)

                val edgesArr = raw.optJSONArray("edges") ?: raw.optJSONArray("links") ?: raw.optJSONArray("messages") ?: JSONArray()
                val parsedEdges = buildList {
                    for (i in 0 until edgesArr.length()) {
                        DiagramEdge.fromJson(edgesArr.optJSONObject(i))?.let { add(it) }
                    }
                }.take(24)

                val seriesArr = raw.optJSONArray("series") ?: raw.optJSONArray("data") ?: raw.optJSONArray("points") ?: JSONArray()
                val parsedSeries = buildList {
                    for (i in 0 until seriesArr.length()) {
                        DiagramSeriesPoint.fromJson(seriesArr.optJSONObject(i), i)?.let { add(it) }
                    }
                }.take(12)

                if (parsedNodes.isEmpty() && parsedSeries.isEmpty()) return null

                val autoEdges = if (parsedEdges.isEmpty() && parsedNodes.size >= 2 && diagramType != "chart") {
                    parsedNodes.zipWithNext().map { (a, b) ->
                        DiagramEdge(fromId = a.id, toId = b.id, active = a.status == "doing" || b.status == "doing")
                    }
                } else {
                    parsedEdges
                }

                val activeId = raw.optString("activeNodeId", "").trim().ifBlank {
                    parsedNodes.firstOrNull { it.status == "doing" || it.status == "highlight" }?.id.orEmpty()
                }

                return DiagramTaskMapData(
                    diagramType = diagramType,
                    subChartType = subChart,
                    title = raw.optString("title", "").trim(),
                    subtitle = raw.optString("subtitle", "").trim(),
                    nodes = parsedNodes,
                    edges = autoEdges,
                    series = parsedSeries,
                    activeNodeId = activeId
                )
            }

            fun fromMetrics(metrics: List<HudMetricItem>, title: String = "Telemetry Chart"): DiagramTaskMapData? {
                if (metrics.isEmpty()) return null
                val pts = metrics.mapNotNull { m ->
                    val numeric = Regex("""[-+]?\d+(?:\.\d+)?""").find(m.value)?.value?.toFloatOrNull()
                        ?: return@mapNotNull null
                    val maxV = if ("%" in m.value) 100f else (numeric * 1.25f).coerceAtLeast(10f)
                    DiagramSeriesPoint(
                        label = m.label.take(16),
                        value = numeric,
                        maxValue = maxV,
                        status = if (numeric / maxV >= 0.85f) "highlight" else "doing",
                        colorHex = m.accentColor
                    )
                }.take(10)
                if (pts.isEmpty()) return null
                return DiagramTaskMapData(
                    diagramType = "chart",
                    subChartType = if (pts.size <= 3 && pts.all { it.maxValue == 100f }) "radial" else "bar",
                    title = title.ifBlank { "Metrics" },
                    series = pts
                )
            }

            fun fromMermaidOrStructure(rawText: String, title: String = "Diagram"): DiagramTaskMapData? {
                val text = rawText.trim()
                if (text.isEmpty()) return null

                val mermaidBlock = MERMAID_BLOCK_REGEX.find(text)?.groupValues?.getOrNull(1)?.trim()
                val body = mermaidBlock ?: text
                val lines = body.lines().map { it.trim() }.filter { it.isNotEmpty() && !it.startsWith("%%") }
                if (lines.isEmpty()) return null

                val firstLineLower = lines.first().lowercase()
                // 1. Sequence diagram parsing
                if (firstLineLower.startsWith("sequencediagram") || (mermaidBlock != null && lines.any { MERMAID_SEQ_MSG_REGEX.containsMatchIn(it) })) {
                    val actorMap = linkedMapOf<String, DiagramNode>()
                    val seqEdges = mutableListOf<DiagramEdge>()
                    for (line in lines) {
                        if (line.startsWith("participant ", ignoreCase = true) || line.startsWith("actor ", ignoreCase = true)) {
                            val parts = line.substringAfter(' ').split(" as ", ignoreCase = true, limit = 2)
                            val aid = parts[0].trim()
                            val albl = (parts.getOrNull(1) ?: aid).trim()
                            if (aid.isNotEmpty()) {
                                actorMap[aid] = DiagramNode(id = aid, label = albl.take(20), role = "actor", status = "done")
                            }
                            continue
                        }
                        val m = MERMAID_SEQ_MSG_REGEX.matchEntire(line) ?: continue
                        val from = m.groupValues[1].trim()
                        val arrow = m.groupValues[2]
                        val to = m.groupValues[3].trim()
                        val msg = m.groupValues[4].trim()
                        if (from !in actorMap) actorMap[from] = DiagramNode(id = from, label = from.take(20), role = "actor", status = "done")
                        if (to !in actorMap) actorMap[to] = DiagramNode(id = to, label = to.take(20), role = "actor", status = "done")
                        seqEdges.add(
                            DiagramEdge(
                                fromId = from,
                                toId = to,
                                label = msg.take(28),
                                active = seqEdges.isEmpty(),
                                dashed = arrow.startsWith("--")
                            )
                        )
                    }
                    if (actorMap.size >= 2 && seqEdges.isNotEmpty()) {
                        return DiagramTaskMapData(
                            diagramType = "sequence",
                            title = title.ifBlank { "Sequence" },
                            nodes = actorMap.values.toList().take(8),
                            edges = seqEdges.take(14)
                        )
                    }
                }

                // 2. Pie / Chart parsing in Mermaid
                if (firstLineLower.startsWith("pie")) {
                    val piePoints = lines.drop(1).mapNotNull { line ->
                        val m = PIE_ENTRY_REGEX.matchEntire(line) ?: return@mapNotNull null
                        val lbl = m.groupValues[1].trim()
                        val v = m.groupValues[2].toFloatOrNull() ?: return@mapNotNull null
                        DiagramSeriesPoint(label = lbl.take(16), value = v, maxValue = 100f)
                    }
                    if (piePoints.size >= 2) {
                        val sum = piePoints.sumOf { it.value.toDouble() }.toFloat().coerceAtLeast(1f)
                        val normalized = piePoints.map { it.copy(maxValue = sum) }
                        return DiagramTaskMapData(
                            diagramType = "chart",
                            subChartType = "radial",
                            title = title.ifBlank { "Breakdown" },
                            series = normalized.take(8)
                        )
                    }
                }

                // 3. Flowchart / Architecture node graph parsing
                if (firstLineLower.startsWith("graph ") || firstLineLower.startsWith("flowchart ") || mermaidBlock != null) {
                    val nodeMap = linkedMapOf<String, DiagramNode>()
                    val edges = mutableListOf<DiagramEdge>()
                    for (line in lines) {
                        val m = MERMAID_FLOW_EDGE_REGEX.find(line) ?: continue
                        val fromId = m.groupValues[1].trim()
                        val fromLbl = listOf(m.groupValues[2], m.groupValues[3], m.groupValues[4]).firstOrNull { it.isNotBlank() }?.trim() ?: fromId
                        val fromRole = if (m.groupValues[4].isNotBlank()) "decision" else if (m.groupValues[3].isNotBlank()) "start" else "step"
                        val edgeLbl = m.groupValues[5].trim()
                        val toId = m.groupValues[6].trim()
                        val toLbl = listOf(m.groupValues[7], m.groupValues[8], m.groupValues[9]).firstOrNull { it.isNotBlank() }?.trim() ?: toId
                        val toRole = if (m.groupValues[9].isNotBlank()) "decision" else if (m.groupValues[8].isNotBlank()) "end" else "step"
                        if (fromId !in nodeMap) nodeMap[fromId] = DiagramNode(id = fromId, label = fromLbl.take(28), role = fromRole, status = "done")
                        if (toId !in nodeMap) nodeMap[toId] = DiagramNode(id = toId, label = toLbl.take(28), role = toRole, status = "doing")
                        edges.add(
                            DiagramEdge(
                                fromId = fromId,
                                toId = toId,
                                label = edgeLbl.take(22),
                                active = "--" in line || "==" in line
                            )
                        )
                    }
                    if (nodeMap.size >= 2) {
                        return DiagramTaskMapData(
                            diagramType = "flowchart",
                            title = title.ifBlank { "Flowchart" },
                            nodes = nodeMap.values.toList().take(14),
                            edges = edges.take(20),
                            activeNodeId = nodeMap.values.lastOrNull()?.id.orEmpty()
                        )
                    }
                }

                // 4. Plain-text arrow chains (`Client -> Gateway -> Auth -> DB`)
                val arrowNodes = linkedMapOf<String, DiagramNode>()
                val arrowEdges = mutableListOf<DiagramEdge>()
                for (line in lines.take(12)) {
                    if ("->" !in line && "-->" !in line && "→" !in line && "➜" !in line) continue
                    val parts = line.split(Regex("""\s*(?:-->|->|=>|➜|→)\s*"""))
                        .map { it.trim().trim('"', '`', '*', '-') }
                        .filter { it.length in 2..36 }
                    if (parts.size >= 2) {
                        for (i in 0 until parts.lastIndex) {
                            val a = parts[i]
                            val b = parts[i + 1]
                            val aId = "n_${a.lowercase().replace(Regex("[^a-z0-9]+"), "_")}"
                            val bId = "n_${b.lowercase().replace(Regex("[^a-z0-9]+"), "_")}"
                            if (aId !in arrowNodes) {
                                arrowNodes[aId] = DiagramNode(
                                    id = aId,
                                    label = a.take(26),
                                    role = if (arrowNodes.isEmpty()) "start" else "step",
                                    status = "done"
                                )
                            }
                            if (bId !in arrowNodes) {
                                arrowNodes[bId] = DiagramNode(
                                    id = bId,
                                    label = b.take(26),
                                    role = if (i == parts.lastIndex - 1) "end" else "step",
                                    status = "doing"
                                )
                            }
                            arrowEdges.add(DiagramEdge(fromId = aId, toId = bId, active = true))
                        }
                    } else {
                        val m = ARROW_CHAIN_REGEX.find(line)
                        if (m != null) {
                            val a = m.groupValues[1].trim()
                            val b = m.groupValues[2].trim()
                            val aId = "n_${a.lowercase().replace(Regex("[^a-z0-9]+"), "_")}"
                            val bId = "n_${b.lowercase().replace(Regex("[^a-z0-9]+"), "_")}"
                            if (aId !in arrowNodes) arrowNodes[aId] = DiagramNode(id = aId, label = a.take(26), status = "done")
                            if (bId !in arrowNodes) arrowNodes[bId] = DiagramNode(id = bId, label = b.take(26), status = "doing")
                            arrowEdges.add(DiagramEdge(fromId = aId, toId = bId, active = true))
                        }
                    }
                }
                if (arrowNodes.size >= 3 && arrowEdges.size >= 2) {
                    return DiagramTaskMapData(
                        diagramType = "flowchart",
                        title = title.ifBlank { "Architecture Flow" },
                        nodes = arrowNodes.values.toList().take(12),
                        edges = arrowEdges.take(18),
                        activeNodeId = arrowNodes.values.lastOrNull()?.id.orEmpty()
                    )
                }

                return null
            }
        }
    }

    data class TaskMapConfig(
        val active: Boolean = false,
        val mode: String = "app_pane", // chess | media | telemetry | app_pane | results | player | diagram
        val title: String = "",
        val widthDp: Float = 176f,
        val opacity: Float? = null,
        val splitLabel: String = "",
        val paneMode: String = "pane", // pane | full
        val persistOnDone: Boolean = (mode == "results" || mode == "player" || mode == "diagram"),
        val paneBounds: TaskMapPaneBounds? = null,
        val chess: ChessTaskMapData? = null,
        val media: MediaTaskMapData? = null,
        val telemetry: TelemetryTaskMapData? = null,
        val appPane: AppPaneTaskMapData? = null,
        val results: ResultsTaskMapData? = null,
        val player: PlayerTaskMapData? = null,
        val diagram: DiagramTaskMapData? = null,
        val autoSynthesized: Boolean = false
    ) {
        fun contentSignature(): String = when (mode) {
            "results" -> "results:${results?.contentSignature().orEmpty()}:$title"
            "player" -> "player:${player?.contentSignature().orEmpty()}:$title"
            "diagram" -> "diagram:${diagram?.contentSignature().orEmpty()}:$title"
            else -> "$mode:$title:$active"
        }

        fun toJson(): JSONObject = JSONObject().apply {
            put("active", active)
            put("mode", mode)
            if (title.isNotBlank()) put("title", title)
            put("widthDp", widthDp.toDouble())
            if (opacity != null) put("opacity", opacity.toDouble())
            if (splitLabel.isNotBlank()) put("splitLabel", splitLabel)
            put("paneMode", paneMode)
            put("persistOnDone", persistOnDone)
            if (paneBounds != null) put("paneBounds", paneBounds.toJson())
            if (chess != null) put("chess", chess.toJson())
            if (media != null) put("media", media.toJson())
            if (telemetry != null) put("telemetry", telemetry.toJson())
            if (appPane != null) put("appPane", appPane.toJson())
            if (results != null) put("results", results.toJson())
            if (player != null) put("player", player.toJson())
            if (diagram != null) put("diagram", diagram.toJson())
        }

        companion object {
            fun fromJson(raw: Any?, previousPlayer: PlayerTaskMapData? = null): TaskMapConfig {
                if (raw !is JSONObject) return TaskMapConfig(active = false)
                val modeRaw = raw.optString("mode", "app_pane").lowercase().trim()
                val playerChildObj = raw.optJSONObject("player")
                val mediaChildObj = raw.optJSONObject("media")
                val diagramChildObj = raw.optJSONObject("diagram")
                val hasPlayableMedia = playerChildObj != null ||
                    (modeRaw in setOf("player", "music", "video", "audio")) ||
                    (modeRaw == "media" && (PlayerTaskMapData.hasPlayableFields(mediaChildObj) || PlayerTaskMapData.hasPlayableFields(raw)))
                val hasDiagram = diagramChildObj != null ||
                    modeRaw in setOf("diagram", "flowchart", "sequence", "timeline", "chart", "architecture") ||
                    DiagramTaskMapData.hasDiagramFields(raw)
                val mode = when {
                    hasPlayableMedia -> "player"
                    hasDiagram && modeRaw !in setOf("chess", "media", "telemetry", "app_pane", "results", "player") -> "diagram"
                    modeRaw in setOf("chess", "media", "telemetry", "app_pane", "results", "player", "diagram") -> modeRaw
                    else -> "app_pane"
                }
                val active = raw.optBoolean("active", hasPlayableMedia || (mode == "diagram" && hasDiagram))
                val defaultWidth = when (mode) {
                    "results" -> 224.0
                    "player" -> 228.0
                    "diagram" -> 236.0
                    else -> 176.0
                }
                val chessObj = raw.optJSONObject("chess") ?: if (mode == "chess" && raw.has("fen")) raw else null
                val mediaObj = mediaChildObj ?: if (mode == "media" && (raw.has("provider") || raw.has("playing"))) raw else null
                val telObj = raw.optJSONObject("telemetry") ?: if (mode == "telemetry" && (raw.has("metrics") || raw.has("percent"))) raw else null
                val paneObj = raw.optJSONObject("appPane") ?: if (mode == "app_pane" && (raw.has("zones") || raw.has("actionVector"))) raw else null
                val resultsObj = raw.optJSONObject("results") ?: if (
                    mode == "results" && (raw.has("items") || raw.has("summaryText") || raw.has("summary") || raw.has("query"))
                ) raw else null
                val playerSourceObj = playerChildObj
                    ?: (if (mode == "player") (mediaChildObj ?: raw) else null)
                val parsedPlayer = if (mode == "player") {
                    PlayerTaskMapData.fromJson(playerSourceObj, previousPlayer)
                } else null
                val diagramSource: Any? = when {
                    diagramChildObj != null -> diagramChildObj
                    mode == "diagram" && raw.has("diagram") -> raw.opt("diagram")
                    mode == "diagram" -> raw
                    else -> null
                }
                val parsedDiagram = if (mode == "diagram") {
                    DiagramTaskMapData.fromJson(diagramSource)
                } else null
                val defaultPersist = mode == "results" || mode == "player" || mode == "diagram"
                val persistOnDone = if (raw.has("persistOnDone") && !raw.isNull("persistOnDone")) {
                    raw.optBoolean("persistOnDone", defaultPersist)
                } else {
                    defaultPersist
                }
                val fallbackTitle = parsedPlayer?.currentTrack()?.title.orEmpty()
                    .ifBlank { parsedDiagram?.title.orEmpty() }
                return TaskMapConfig(
                    active = active,
                    mode = mode,
                    title = raw.optString("title", raw.optString("label", fallbackTitle)).trim(),
                    widthDp = raw.optDouble("widthDp", defaultWidth).toFloat().coerceIn(148f, 268f),
                    opacity = if (raw.has("opacity") && !raw.isNull("opacity")) raw.optDouble("opacity", 0.90).toFloat().coerceIn(0.25f, 1.0f) else null,
                    splitLabel = raw.optString("splitLabel", "").trim(),
                    paneMode = raw.optString("paneMode", "pane").lowercase().trim().let { if (it == "full") "full" else "pane" },
                    persistOnDone = persistOnDone,
                    paneBounds = TaskMapPaneBounds.fromJson(raw.optJSONObject("paneBounds")),
                    chess = ChessTaskMapData.fromJson(chessObj),
                    media = MediaTaskMapData.fromJson(mediaObj),
                    telemetry = TelemetryTaskMapData.fromJson(telObj),
                    appPane = AppPaneTaskMapData.fromJson(paneObj),
                    results = ResultsTaskMapData.fromJson(resultsObj),
                    player = parsedPlayer,
                    diagram = parsedDiagram
                )
            }
        }
    }

    data class ApprovalGateConfig(
        val active: Boolean = false,
        val id: String = "",
        val title: String = "Confirm Action",
        val description: String = "",
        val commandPreview: String = "",
        val riskLevel: String = "medium", // low | medium | high
        val approveLabel: String = "Approve",
        val denyLabel: String = "Deny",
        val allowEdit: Boolean = true,
        val editableText: String = "",
        val timeoutSeconds: Int = 0
    ) {
        fun toJson(): JSONObject = JSONObject().apply {
            put("active", active)
            if (id.isNotBlank()) put("id", id)
            put("title", title)
            if (description.isNotBlank()) put("description", description)
            if (commandPreview.isNotBlank()) put("commandPreview", commandPreview)
            put("riskLevel", riskLevel)
            put("approveLabel", approveLabel)
            put("denyLabel", denyLabel)
            put("allowEdit", allowEdit)
            if (editableText.isNotBlank()) put("editableText", editableText)
            put("timeoutSeconds", timeoutSeconds)
        }

        companion object {
            fun fromJson(raw: Any?): ApprovalGateConfig {
                if (raw !is JSONObject) return ApprovalGateConfig(active = false)
                val active = raw.optBoolean("active", true)
                val id = raw.optString("id", raw.optString("approvalId", "")).trim()
                val title = raw.optString("title", "Confirm Action").trim().ifBlank { "Confirm Action" }
                val description = raw.optString("description", raw.optString("message", raw.optString("summary", ""))).trim()
                val preview = raw.optString("commandPreview", raw.optString("command", raw.optString("preview", ""))).trim()
                val rawRisk = raw.optString("riskLevel", raw.optString("risk", "medium")).lowercase().trim()
                val riskLevel = when (rawRisk) {
                    "low", "safe", "info" -> "low"
                    "high", "critical", "danger", "destructive" -> "high"
                    else -> "medium"
                }
                val editable = raw.optString("editableText", preview).trim()
                val hasMeaningfulContent = id.isNotBlank() || description.isNotBlank() || preview.isNotBlank() || raw.has("title")
                return ApprovalGateConfig(
                    active = active && hasMeaningfulContent,
                    id = id.ifBlank { "apr_${System.currentTimeMillis() % 100000}" },
                    title = title,
                    description = description,
                    commandPreview = preview,
                    riskLevel = riskLevel,
                    approveLabel = raw.optString("approveLabel", "Approve").trim().ifBlank { "Approve" },
                    denyLabel = raw.optString("denyLabel", "Deny").trim().ifBlank { "Deny" },
                    allowEdit = raw.optBoolean("allowEdit", true),
                    editableText = editable,
                    timeoutSeconds = raw.optInt("timeoutSeconds", 0).coerceIn(0, 300)
                )
            }
        }
    }

    data class SnippedUiNode(
        val text: String = "",
        val contentDescription: String = "",
        val viewId: String = "",
        val className: String = "",
        val bounds: String = "",
        val centerX: Int = 0,
        val centerY: Int = 0,
        val clickable: Boolean = false
    ) {
        val displayLabel: String
            get() = text.ifBlank { contentDescription }.ifBlank {
                viewId.substringAfterLast('/').ifBlank { className.substringAfterLast('.') }
            }.trim()

        fun toJson(): JSONObject = JSONObject().apply {
            if (text.isNotBlank()) put("text", text)
            if (contentDescription.isNotBlank()) put("contentDescription", contentDescription)
            if (viewId.isNotBlank()) put("viewId", viewId)
            if (className.isNotBlank()) put("className", className)
            if (bounds.isNotBlank()) put("bounds", bounds)
            put("centerX", centerX)
            put("centerY", centerY)
            put("clickable", clickable)
        }

        companion object {
            fun fromJson(obj: JSONObject?): SnippedUiNode? {
                if (obj == null) return null
                return SnippedUiNode(
                    text = obj.optString("text", "").trim(),
                    contentDescription = obj.optString("contentDescription", "").trim(),
                    viewId = obj.optString("viewId", "").trim(),
                    className = obj.optString("className", "").trim(),
                    bounds = obj.optString("bounds", "").trim(),
                    centerX = obj.optInt("centerX", 0),
                    centerY = obj.optInt("centerY", 0),
                    clickable = obj.optBoolean("clickable", false)
                )
            }
        }
    }

    data class SnippedRegionContext(
        val x1: Int,
        val y1: Int,
        val x2: Int,
        val y2: Int,
        val screenWidth: Int = 1080,
        val screenHeight: Int = 2400,
        val packageName: String = "",
        val nodes: List<SnippedUiNode> = emptyList(),
        val screenshotBase64: String = "",
        val screenshotWidth: Int = 0,
        val screenshotHeight: Int = 0,
        val screenshotMimeType: String = "image/jpeg"
    ) {
        val widthPx: Int get() = (x2 - x1).coerceAtLeast(0)
        val heightPx: Int get() = (y2 - y1).coerceAtLeast(0)
        val hasScreenshot: Boolean get() = screenshotBase64.isNotBlank()

        fun summaryChipLabel(): String {
            val count = nodes.size
            return if (hasScreenshot) {
                if (count > 0) "✂ Snip ($count items)" else "✂ Snip (${widthPx}×${heightPx})"
            } else {
                if (count > 0) "✂ Region ($count items)" else "✂ Region (${widthPx}×${heightPx})"
            }
        }

        fun toJson(): JSONObject = JSONObject().apply {
            put("x1", x1)
            put("y1", y1)
            put("x2", x2)
            put("y2", y2)
            put("width", widthPx)
            put("height", heightPx)
            put("screenWidth", screenWidth)
            put("screenHeight", screenHeight)
            if (packageName.isNotBlank()) put("packageName", packageName)
            put("nodes", JSONArray().apply { nodes.forEach { put(it.toJson()) } })
            if (screenshotBase64.isNotBlank()) {
                put("screenshotBase64", screenshotBase64)
                put("screenshotMimeType", screenshotMimeType.ifBlank { "image/jpeg" })
                if (screenshotWidth > 0) put("screenshotWidth", screenshotWidth)
                if (screenshotHeight > 0) put("screenshotHeight", screenshotHeight)
            }
        }

        companion object {
            fun fromJson(obj: JSONObject?): SnippedRegionContext? {
                if (obj == null) return null
                val rawX1 = obj.optInt("x1", -1)
                val rawY1 = obj.optInt("y1", -1)
                val rawX2 = obj.optInt("x2", -1)
                val rawY2 = obj.optInt("y2", -1)
                if (rawX1 < 0 || rawY1 < 0 || rawX2 <= rawX1 || rawY2 <= rawY1) return null
                val arr = obj.optJSONArray("nodes") ?: JSONArray()
                val parsedNodes = buildList {
                    for (i in 0 until arr.length()) {
                        SnippedUiNode.fromJson(arr.optJSONObject(i))?.let { add(it) }
                    }
                }
                return SnippedRegionContext(
                    x1 = rawX1,
                    y1 = rawY1,
                    x2 = rawX2,
                    y2 = rawY2,
                    screenWidth = obj.optInt("screenWidth", 1080).coerceAtLeast(1),
                    screenHeight = obj.optInt("screenHeight", 2400).coerceAtLeast(1),
                    packageName = obj.optString("packageName", "").trim(),
                    nodes = parsedNodes,
                    screenshotBase64 = obj.optString("screenshotBase64", "").trim(),
                    screenshotWidth = obj.optInt("screenshotWidth", 0).coerceAtLeast(0),
                    screenshotHeight = obj.optInt("screenshotHeight", 0).coerceAtLeast(0),
                    screenshotMimeType = obj.optString("screenshotMimeType", "image/jpeg").trim().ifBlank { "image/jpeg" }
                )
            }
        }
    }

    data class QueuedPromptItem(
        val id: String,
        val text: String,
        val createdAtMs: Long = System.currentTimeMillis(),
        val regionContext: SnippedRegionContext? = null
    ) {
        fun toJson(): JSONObject = JSONObject().apply {
            put("id", id)
            put("text", text)
            put("createdAtMs", createdAtMs)
            if (regionContext != null) put("regionContext", regionContext.toJson())
        }
    }

    data class SmartSuggestionChip(
        val id: String,
        val label: String,
        val prompt: String,
        val iconHint: String = "spark_ai",
        val appPackage: String = ""
    ) {
        fun toJson(): JSONObject = JSONObject().apply {
            put("id", id)
            put("label", label)
            put("prompt", prompt)
            if (iconHint.isNotBlank()) put("iconHint", iconHint)
            if (appPackage.isNotBlank()) put("appPackage", appPackage)
        }

        companion object {
            fun fromJson(raw: Any?, fallbackIndex: Int = 0): SmartSuggestionChip? {
                return when (raw) {
                    is String -> {
                        val clean = raw.trim()
                        if (clean.isEmpty()) null else SmartSuggestionChip(
                            id = "sug_$fallbackIndex",
                            label = clean.take(28),
                            prompt = clean
                        )
                    }
                    is JSONObject -> {
                        val label = raw.optString("label", raw.optString("title", "")).trim()
                        val prompt = raw.optString("prompt", raw.optString("text", label)).trim()
                        if (label.isEmpty() && prompt.isEmpty()) return null
                        SmartSuggestionChip(
                            id = raw.optString("id", "sug_$fallbackIndex").trim().ifBlank { "sug_$fallbackIndex" },
                            label = label.ifBlank { prompt.take(28) },
                            prompt = prompt.ifBlank { label },
                            iconHint = raw.optString("iconHint", raw.optString("icon", "spark_ai")).trim().ifBlank { "spark_ai" },
                            appPackage = raw.optString("appPackage", "").trim()
                        )
                    }
                    else -> null
                }
            }
        }
    }

    data class SpotlightTarget(
        val id: String,
        val x1: Int,
        val y1: Int,
        val x2: Int,
        val y2: Int,
        val label: String = "",
        val stepNumber: Int = 1,
        val accentColor: String = "",
        val calloutPosition: String = "auto" // auto | top | bottom | left | right
    ) {
        fun toJson(): JSONObject = JSONObject().apply {
            put("id", id)
            put("x1", x1)
            put("y1", y1)
            put("x2", x2)
            put("y2", y2)
            if (label.isNotBlank()) put("label", label)
            put("stepNumber", stepNumber)
            if (accentColor.isNotBlank()) put("accentColor", accentColor)
            put("calloutPosition", calloutPosition)
        }

        companion object {
            fun fromJson(obj: JSONObject?, index: Int = 0): SpotlightTarget? {
                if (obj == null) return null
                val x1: Int
                val y1: Int
                val x2: Int
                val y2: Int
                if (obj.has("x1") && obj.has("y1") && obj.has("x2") && obj.has("y2")) {
                    x1 = obj.optInt("x1", 0)
                    y1 = obj.optInt("y1", 0)
                    x2 = obj.optInt("x2", 0)
                    y2 = obj.optInt("y2", 0)
                } else if (obj.has("left") && obj.has("top") && obj.has("right") && obj.has("bottom")) {
                    x1 = obj.optInt("left", 0)
                    y1 = obj.optInt("top", 0)
                    x2 = obj.optInt("right", 0)
                    y2 = obj.optInt("bottom", 0)
                } else if (obj.has("x") && obj.has("y")) {
                    val cx = obj.optInt("x", 0)
                    val cy = obj.optInt("y", 0)
                    val r = obj.optInt("radius", 64).coerceIn(24, 300)
                    x1 = (cx - r).coerceAtLeast(0)
                    y1 = (cy - r).coerceAtLeast(0)
                    x2 = cx + r
                    y2 = cy + r
                } else {
                    return null
                }
                val normX1 = minOf(x1, x2).coerceAtLeast(0)
                val normY1 = minOf(y1, y2).coerceAtLeast(0)
                val normX2 = maxOf(x1, x2)
                val normY2 = maxOf(y1, y2)
                if (normX2 - normX1 < 4 || normY2 - normY1 < 4) return null
                val rawPos = obj.optString("calloutPosition", "auto").lowercase().trim()
                val pos = if (rawPos in setOf("auto", "top", "bottom", "left", "right")) rawPos else "auto"
                return SpotlightTarget(
                    id = obj.optString("id", "spot_${index + 1}").trim().ifBlank { "spot_${index + 1}" },
                    x1 = normX1,
                    y1 = normY1,
                    x2 = normX2,
                    y2 = normY2,
                    label = obj.optString("label", obj.optString("tooltip", obj.optString("text", ""))).trim(),
                    stepNumber = obj.optInt("stepNumber", obj.optInt("step", index + 1)).coerceIn(1, 99),
                    accentColor = obj.optString("accentColor", obj.optString("color", "")).trim(),
                    calloutPosition = pos
                )
            }
        }
    }

    data class SpotlightConfig(
        val active: Boolean = false,
        val title: String = "",
        val dimAlpha: Float = 0.55f,
        val autoHideSeconds: Int = 0,
        val targets: List<SpotlightTarget> = emptyList()
    ) {
        fun toJson(): JSONObject = JSONObject().apply {
            put("active", active)
            if (title.isNotBlank()) put("title", title)
            put("dimAlpha", dimAlpha.toDouble())
            put("autoHideSeconds", autoHideSeconds)
            put("targets", JSONArray().apply { targets.forEach { put(it.toJson()) } })
        }

        companion object {
            fun fromJson(raw: Any?): SpotlightConfig {
                if (raw !is JSONObject) return SpotlightConfig(active = false)
                val arr = raw.optJSONArray("targets") ?: raw.optJSONArray("pins") ?: JSONArray()
                val parsed = buildList {
                    for (i in 0 until arr.length()) {
                        SpotlightTarget.fromJson(arr.optJSONObject(i), i)?.let { add(it) }
                    }
                }
                val active = raw.optBoolean("active", parsed.isNotEmpty()) && parsed.isNotEmpty()
                return SpotlightConfig(
                    active = active,
                    title = raw.optString("title", "").trim(),
                    dimAlpha = raw.optDouble("dimAlpha", 0.55).toFloat().coerceIn(0.15f, 0.85f),
                    autoHideSeconds = raw.optInt("autoHideSeconds", 0).coerceIn(0, 300),
                    targets = parsed
                )
            }
        }
    }

    // -------------------------------------------------------------------------
    // Advanced Suite Models:
    // 1. Demonstration Recorder (Teach-by-Example)
    // 2. Smart Clipboard & Cross-App Scratchpad Dropzone
    // 3. Live Screen Diff & Visual Watchdog Triggers
    // 4. Voice Co-Pilot (Spoken TTS & Hands-Free Reply)
    // -------------------------------------------------------------------------

    data class DemoStepItem(
        val index: Int = 1,
        val actionType: String = "TAP", // TAP | SWIPE | TYPE | LONG_PRESS
        val x: Int = 0,
        val y: Int = 0,
        val endX: Int = x,
        val endY: Int = y,
        val text: String = "",
        val nodeLabel: String = "",
        val viewId: String = "",
        val packageName: String = "",
        val timestampMs: Long = System.currentTimeMillis()
    ) {
        fun summaryLine(): String = buildString {
            append("$index. $actionType")
            when (actionType) {
                "TYPE" -> {
                    if (text.isNotBlank()) append(" \"${text.take(28)}\"")
                    if (nodeLabel.isNotBlank()) append(" into \"${nodeLabel.take(22)}\"")
                }
                "SWIPE" -> {
                    append(" ($x,$y)→($endX,$endY)")
                    if (nodeLabel.isNotBlank()) append(" on \"${nodeLabel.take(20)}\"")
                }
                else -> {
                    if (nodeLabel.isNotBlank()) {
                        append(" \"${nodeLabel.take(26)}\"")
                    } else if (viewId.isNotBlank()) {
                        append(" #${viewId.substringAfterLast('/')}")
                    }
                    if (x > 0 || y > 0) append(" @($x,$y)")
                }
            }
        }

        fun toJson(): JSONObject = JSONObject().apply {
            put("index", index)
            put("actionType", actionType)
            put("x", x)
            put("y", y)
            if (actionType == "SWIPE") {
                put("endX", endX)
                put("endY", endY)
            }
            if (text.isNotBlank()) put("text", text)
            if (nodeLabel.isNotBlank()) put("nodeLabel", nodeLabel)
            if (viewId.isNotBlank()) put("viewId", viewId)
            if (packageName.isNotBlank()) put("packageName", packageName)
            put("timestampMs", timestampMs)
        }

        companion object {
            fun fromJson(obj: JSONObject?, fallbackIndex: Int = 1): DemoStepItem? {
                if (obj == null) return null
                val rawAct = obj.optString("actionType", obj.optString("action", "TAP")).uppercase().trim()
                val act = if (rawAct in setOf("TAP", "SWIPE", "TYPE", "LONG_PRESS")) rawAct else "TAP"
                val x = obj.optInt("x", obj.optInt("x1", 0))
                val y = obj.optInt("y", obj.optInt("y1", 0))
                return DemoStepItem(
                    index = obj.optInt("index", fallbackIndex).coerceAtLeast(1),
                    actionType = act,
                    x = x,
                    y = y,
                    endX = obj.optInt("endX", obj.optInt("x2", x)),
                    endY = obj.optInt("endY", obj.optInt("y2", y)),
                    text = obj.optString("text", obj.optString("inputText", "")).trim(),
                    nodeLabel = obj.optString("nodeLabel", obj.optString("label", "")).trim(),
                    viewId = obj.optString("viewId", "").trim(),
                    packageName = obj.optString("packageName", "").trim(),
                    timestampMs = obj.optLong("timestampMs", System.currentTimeMillis())
                )
            }
        }
    }

    data class DemoRecordingSession(
        val id: String = "demo_0",
        val title: String = "Recorded Demonstration",
        val active: Boolean = false,
        val steps: List<DemoStepItem> = emptyList()
    ) {
        fun toMacroPrompt(customGoal: String = ""): String {
            val header = customGoal.trim().ifBlank { title.ifBlank { "Replay demonstrated workflow" } }
            if (steps.isEmpty()) return header
            val stepsDesc = steps.joinToString("; ") { s ->
                buildString {
                    append("Step ${s.index}: ${s.actionType}")
                    if (s.nodeLabel.isNotBlank()) append(" '${s.nodeLabel}'")
                    if (s.viewId.isNotBlank()) append(" (id=${s.viewId.substringAfterLast('/')})")
                    if (s.actionType == "TYPE" && s.text.isNotBlank()) append(" text='${s.text}'")
                    if (s.actionType == "SWIPE") append(" from (${s.x},${s.y}) to (${s.endX},${s.endY})")
                    else if (s.x > 0 || s.y > 0) append(" at (${s.x},${s.y})")
                    if (s.packageName.isNotBlank()) append(" in ${s.packageName}")
                }
            }
            return "$header — Follow demonstrated steps: $stepsDesc"
        }

        fun toJson(): JSONObject = JSONObject().apply {
            put("id", id)
            put("title", title)
            put("active", active)
            put("stepCount", steps.size)
            put("macroPrompt", toMacroPrompt())
            put("steps", JSONArray().apply { steps.forEach { put(it.toJson()) } })
        }

        companion object {
            fun fromJson(obj: JSONObject?): DemoRecordingSession {
                if (obj == null) return DemoRecordingSession()
                val arr = obj.optJSONArray("steps") ?: JSONArray()
                val parsed = buildList {
                    for (i in 0 until arr.length()) {
                        DemoStepItem.fromJson(arr.optJSONObject(i), i + 1)?.let { add(it) }
                    }
                }
                return DemoRecordingSession(
                    id = obj.optString("id", "demo_${System.currentTimeMillis() % 100000}").trim().ifBlank { "demo_0" },
                    title = obj.optString("title", "Recorded Demonstration").trim().ifBlank { "Recorded Demonstration" },
                    active = obj.optBoolean("active", false),
                    steps = parsed
                )
            }
        }
    }

    data class ScratchpadItem(
        val id: String = "",
        val kind: String = "text", // text | url | code | json
        val content: String = "",
        val label: String = "",
        val sourcePackage: String = "",
        val pinned: Boolean = false,
        val timestampMs: Long = System.currentTimeMillis()
    ) {
        val displayPreview: String
            get() = label.ifBlank { content.replace('\n', ' ').trim() }.take(44)

        fun toJson(): JSONObject = JSONObject().apply {
            put("id", id)
            put("kind", kind)
            put("content", content)
            if (label.isNotBlank()) put("label", label)
            if (sourcePackage.isNotBlank()) put("sourcePackage", sourcePackage)
            put("pinned", pinned)
            put("timestampMs", timestampMs)
        }

        companion object {
            fun inferKind(rawContent: String, explicitKind: String = ""): String {
                val k = explicitKind.lowercase().trim()
                if (k in setOf("text", "url", "code", "json")) return k
                val trimmed = rawContent.trim()
                return when {
                    trimmed.startsWith("http://", ignoreCase = true) ||
                        trimmed.startsWith("https://", ignoreCase = true) -> "url"
                    (trimmed.startsWith("{") && trimmed.endsWith("}")) ||
                        (trimmed.startsWith("[") && trimmed.endsWith("]")) -> "json"
                    trimmed.contains("fun ") || trimmed.contains("def ") ||
                        trimmed.contains("const ") || trimmed.contains("export ") ||
                        trimmed.contains("curl ") || trimmed.contains("#!/") ||
                        (trimmed.contains("\n") && (trimmed.contains("{") || trimmed.contains("=") || trimmed.contains(";"))) -> "code"
                    else -> "text"
                }
            }

            fun fromJson(raw: Any?, fallbackIndex: Int = 0): ScratchpadItem? {
                return when (raw) {
                    is String -> {
                        val c = raw.trim()
                        if (c.isEmpty()) null else ScratchpadItem(
                            id = "clip_$fallbackIndex",
                            kind = inferKind(c),
                            content = c
                        )
                    }
                    is JSONObject -> {
                        val c = raw.optString("content", raw.optString("text", raw.optString("value", ""))).trim()
                        if (c.isEmpty()) return null
                        ScratchpadItem(
                            id = raw.optString("id", "clip_$fallbackIndex").trim().ifBlank { "clip_$fallbackIndex" },
                            kind = inferKind(c, raw.optString("kind", raw.optString("type", ""))),
                            content = c,
                            label = raw.optString("label", raw.optString("title", "")).trim(),
                            sourcePackage = raw.optString("sourcePackage", raw.optString("appPackage", "")).trim(),
                            pinned = raw.optBoolean("pinned", false),
                            timestampMs = raw.optLong("timestampMs", System.currentTimeMillis())
                        )
                    }
                    else -> null
                }
            }
        }
    }

    data class ScreenWatchdogConfig(
        val id: String = "wd_0",
        val active: Boolean = false,
        val rule: String = "any_change", // any_change | text_contains | text_disappears | node_appears
        val targetText: String = "",
        val region: SnippedRegionContext? = null,
        val intervalMs: Long = 1500L,
        val triggerPrompt: String = "",
        val oneShot: Boolean = true,
        val triggeredCount: Int = 0,
        val lastTriggeredSummary: String = ""
    ) {
        fun statusSummaryChip(): String = buildString {
            append("👁 Watchdog: ")
            when (rule) {
                "text_contains" -> append("contains \"${targetText.take(16)}\"")
                "text_disappears" -> append("until \"${targetText.take(16)}\" gone")
                "node_appears" -> append("node \"${targetText.take(16)}\"")
                else -> append("any UI change")
            }
            if (region != null) {
                append(" in [${region.x1},${region.y1}]")
            }
        }

        fun toJson(): JSONObject = JSONObject().apply {
            put("id", id)
            put("active", active)
            put("rule", rule)
            if (targetText.isNotBlank()) put("targetText", targetText)
            if (region != null) put("region", region.toJson())
            put("intervalMs", intervalMs)
            if (triggerPrompt.isNotBlank()) put("triggerPrompt", triggerPrompt)
            put("oneShot", oneShot)
            put("triggeredCount", triggeredCount)
            if (lastTriggeredSummary.isNotBlank()) put("lastTriggeredSummary", lastTriggeredSummary)
        }

        companion object {
            fun fromJson(raw: Any?, fallbackRegion: SnippedRegionContext? = null): ScreenWatchdogConfig {
                if (raw !is JSONObject) return ScreenWatchdogConfig(active = false)
                val rawRule = raw.optString("rule", raw.optString("condition", "any_change")).lowercase().trim()
                val rule = when (rawRule) {
                    "contains", "text_contains", "appear", "appears" -> "text_contains"
                    "disappears", "text_disappears", "gone" -> "text_disappears"
                    "node", "node_appears", "view_id" -> "node_appears"
                    else -> "any_change"
                }
                val targetText = raw.optString("targetText", raw.optString("text", raw.optString("match", ""))).trim()
                val region = SnippedRegionContext.fromJson(raw.optJSONObject("region")) ?: fallbackRegion
                val active = raw.optBoolean("active", true) && !raw.optBoolean("clear", false)
                return ScreenWatchdogConfig(
                    id = raw.optString("id", "wd_${System.currentTimeMillis() % 100000}").trim().ifBlank { "wd_0" },
                    active = active,
                    rule = rule,
                    targetText = targetText,
                    region = region,
                    intervalMs = raw.optLong("intervalMs", 1500L).coerceIn(300L, 60_000L),
                    triggerPrompt = raw.optString("triggerPrompt", raw.optString("prompt", "")).trim(),
                    oneShot = raw.optBoolean("oneShot", true),
                    triggeredCount = raw.optInt("triggeredCount", 0).coerceAtLeast(0),
                    lastTriggeredSummary = raw.optString("lastTriggeredSummary", "").trim()
                )
            }
        }
    }

    data class VoiceCoPilotConfig(
        val enabled: Boolean = false,
        val autoSpeakDone: Boolean = true,
        val autoSpeakQuestion: Boolean = true,
        val autoListenOnQuestion: Boolean = true,
        val speechRate: Float = 1.0f,
        val speakText: String = ""
    ) {
        fun toJson(): JSONObject = JSONObject().apply {
            put("enabled", enabled)
            put("autoSpeakDone", autoSpeakDone)
            put("autoSpeakQuestion", autoSpeakQuestion)
            put("autoListenOnQuestion", autoListenOnQuestion)
            put("speechRate", speechRate.toDouble())
            if (speakText.isNotBlank()) put("speakText", speakText)
        }

        companion object {
            fun fromJson(raw: Any?, previous: VoiceCoPilotConfig = VoiceCoPilotConfig()): VoiceCoPilotConfig {
                if (raw !is JSONObject) return previous
                val speakNow = raw.optString("speakText", raw.optString("speak", raw.optString("tts", ""))).trim()
                val enabled = if (raw.has("enabled") && !raw.isNull("enabled")) {
                    raw.optBoolean("enabled", previous.enabled)
                } else if (speakNow.isNotEmpty()) {
                    true
                } else {
                    previous.enabled
                }
                return VoiceCoPilotConfig(
                    enabled = enabled,
                    autoSpeakDone = raw.optBoolean("autoSpeakDone", previous.autoSpeakDone),
                    autoSpeakQuestion = raw.optBoolean("autoSpeakQuestion", previous.autoSpeakQuestion),
                    autoListenOnQuestion = raw.optBoolean("autoListenOnQuestion", previous.autoListenOnQuestion),
                    speechRate = raw.optDouble("speechRate", previous.speechRate.toDouble()).toFloat().coerceIn(0.6f, 2.0f),
                    speakText = speakNow
                )
            }
        }
    }
}

