package com.kavach.domain.repository

import com.kavach.domain.model.AiResponseEvent
import com.kavach.domain.model.LlmConfig
import com.kavach.domain.model.LlmMessage
import kotlinx.coroutines.flow.Flow

interface LlmProvider {
    val type: com.kavach.domain.model.LlmProviderType

    /**
     * Streams tokens from the selected LLM provider based on conversation context,
     * recent messages, prompts, and config.
     */
    fun streamResponse(
        config: LlmConfig,
        systemPrompt: String,
        developerPrompt: String,
        messages: List<LlmMessage>,
        userMessage: String,
        sessionId: String,
        conversationId: String,
        messageId: String
    ): Flow<AiResponseEvent>
}
