package com.kavach.ui.theme

import androidx.compose.runtime.Immutable
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

/**
 * AURA ASSISTANT — Centralized Color Tokens
 * Crisp Light Mode palette with soft alabaster backgrounds, crisp white cards,
 * clean slate ink, and a disciplined Instagram/iOS cobalt blue accent.
 */
@Immutable
object AuraColors {
    // Crisp Light Canvas & Surface Baselines
    val Background = CrispBg
    val SurfaceDark = CrispSurface
    val SurfaceDarker = CrispSurfaceSubtle

    // Primary Text & Hierarchy
    val TextPrimary = CrispInkPrimary
    val TextSecondary = CrispInkSecondary
    val TextMuted = CrispInkMuted
    val TextVeryMuted = Color(0xFFCBD5E1)

    // Base Monochromes
    val White = Color(0xFFFFFFFF)
    val Black = Color(0xFF000000)
    val Transparent = Color(0x00000000)

    // Clean Light Fill Layers
    val GlassLevel1 = Color(0xFFF8FAFC)
    val GlassLevel2 = CrispSurfaceSubtle
    val GlassLevel3 = Color(0xFFE2E8F0)
    val GlassElevated = CrispSurface
    val GlassActive = CrispBlue.copy(alpha = 0.10f)

    // Button Fills
    val ButtonPrimaryBg = CrispBlue
    val ButtonPrimaryContent = White
    val ButtonSecondaryBg = CrispSurfaceSubtle
    val ButtonSecondaryContent = CrispInkPrimary
    val ButtonTertiaryContent = TextSecondary

    // Border Colors
    val BorderSubtle = CrispHairline
    val BorderFocused = CrispBorder
    val BorderActive = CrispBlue

    // Subtle Light Top Highlight
    val GlassHighlightBrush = Brush.verticalGradient(
        0.0f to White.copy(alpha = 0.65f),
        0.45f to White.copy(alpha = 0.20f),
        1.0f to Transparent
    )

    val GlassElevatedHighlightBrush = Brush.verticalGradient(
        0.0f to White.copy(alpha = 0.85f),
        0.4f to White.copy(alpha = 0.30f),
        1.0f to Transparent
    )

    // Semantic Status Colors
    val StatusReady = CrispEmerald
    val StatusActive = CrispBlue
    val StatusIdle = TextMuted
    val StatusError = CrispRose
    val StatusWarning = CrispAmber
}
