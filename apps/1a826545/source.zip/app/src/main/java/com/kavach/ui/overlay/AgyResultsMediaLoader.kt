package com.kavach.ui.overlay

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.util.Base64
import android.util.LruCache
import android.webkit.MimeTypeMap
import android.widget.Toast
import androidx.core.content.FileProvider
import com.kavach.ui.overlay.hud.HudModels
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/**
 * Lightweight asynchronous media & file helper for the Window 3 Query Results Carousel
 * and Lightbox without introducing heavy external image-loading library overhead inside
 * WindowManager overlays.
 */
object AgyResultsMediaLoader {

    private val mainHandler = Handler(Looper.getMainLooper())
    private val executor = Executors.newFixedThreadPool(2)

    private val httpClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(8, TimeUnit.SECONDS)
            .readTimeout(12, TimeUnit.SECONDS)
            .followRedirects(true)
            .build()
    }

    private val bitmapCache = object : LruCache<String, Bitmap>(28) {
        override fun sizeOf(key: String, value: Bitmap): Int = 1
    }

    fun resolveMimeType(item: HudModels.MediaItem): String {
        if (item.mimeType.isNotBlank()) return item.mimeType
        val cleanUri = item.uri.substringBefore('?').substringBefore('#').lowercase()
        val ext = cleanUri.substringAfterLast('.', "")
        if (ext.isNotEmpty()) {
            MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext)?.let { return it }
        }
        return when (item.kind) {
            "image" -> "image/*"
            "video" -> "video/*"
            else -> when (ext) {
                "pdf" -> "application/pdf"
                "apk" -> "application/vnd.android.package-archive"
                "json", "py", "kt", "js", "md", "log", "csv", "txt" -> "text/plain"
                else -> "*/*"
            }
        }
    }

    fun fileExtensionBadge(item: HudModels.MediaItem): String {
        if (item.kind == "image") return "IMG"
        if (item.kind == "video") return "VID"
        val clean = item.uri.substringBefore('?').substringBefore('#')
        val ext = clean.substringAfterLast('.', "").uppercase().take(4)
        return ext.ifBlank { "FILE" }
    }

    fun resolveDisplayUri(uriString: String): Uri? {
        val trimmed = uriString.trim()
        if (trimmed.isEmpty()) return null
        return if (trimmed.startsWith("/")) {
            Uri.fromFile(File(trimmed))
        } else {
            Uri.parse(trimmed)
        }
    }

    fun loadPreviewBitmap(
        context: Context,
        item: HudModels.MediaItem,
        maxDimensionPx: Int = 640,
        onResult: (Bitmap?) -> Unit
    ) {
        val source = item.thumbnailUri.ifBlank { item.uri }.trim()
        if (source.isEmpty()) {
            onResult(null)
            return
        }
        val cacheKey = "${item.kind}:$maxDimensionPx:$source"
        bitmapCache.get(cacheKey)?.let { cached ->
            if (!cached.isRecycled) {
                onResult(cached)
                return
            }
        }

        executor.execute {
            val bmp = try {
                if (item.kind == "video" && item.thumbnailUri.isBlank()) {
                    extractVideoFrame(context, source, maxDimensionPx)
                } else {
                    decodeImageSource(context, source, maxDimensionPx)
                }
            } catch (_: Exception) {
                null
            }
            if (bmp != null) {
                bitmapCache.put(cacheKey, bmp)
            }
            mainHandler.post { onResult(bmp) }
        }
    }

    fun readFileSnippet(
        context: Context,
        item: HudModels.MediaItem,
        onResult: (String) -> Unit
    ) {
        if (item.previewText.isNotBlank()) {
            onResult(item.previewText)
            return
        }
        val uri = item.uri.trim()
        if (uri.isEmpty()) {
            onResult("")
            return
        }
        executor.execute {
            val snippet = try {
                val file = when {
                    uri.startsWith("/") -> File(uri)
                    uri.startsWith("file://") -> File(Uri.parse(uri).path ?: "")
                    else -> null
                }
                if (file != null && file.exists() && file.isFile && isLikelyTextFile(file.name, item.mimeType)) {
                    file.inputStream().bufferedReader(Charsets.UTF_8).use { reader ->
                        val buf = CharArray(6144)
                        val count = reader.read(buf)
                        if (count > 0) String(buf, 0, count) else ""
                    }
                } else if (uri.startsWith("content://")) {
                    val mime = resolveMimeType(item)
                    if (mime.startsWith("text/") || mime.contains("json")) {
                        context.contentResolver.openInputStream(Uri.parse(uri))?.bufferedReader(Charsets.UTF_8)?.use { reader ->
                            val buf = CharArray(6144)
                            val count = reader.read(buf)
                            if (count > 0) String(buf, 0, count) else ""
                        }.orEmpty()
                    } else ""
                } else ""
            } catch (_: Exception) {
                ""
            }
            mainHandler.post { onResult(snippet) }
        }
    }

    fun openInDefaultApp(context: Context, item: HudModels.MediaItem): Boolean {
        val raw = item.uri.trim()
        if (raw.isEmpty()) {
            Toast.makeText(context, "No file or URL attached", Toast.LENGTH_SHORT).show()
            return false
        }
        return try {
            val resolvedUri: Uri = when {
                raw.startsWith("http://", ignoreCase = true) || raw.startsWith("https://", ignoreCase = true) -> {
                    Uri.parse(raw)
                }
                raw.startsWith("content://", ignoreCase = true) -> {
                    Uri.parse(raw)
                }
                raw.startsWith("file://", ignoreCase = true) || raw.startsWith("/") -> {
                    val path = if (raw.startsWith("file://")) Uri.parse(raw).path.orEmpty() else raw
                    val file = File(path)
                    try {
                        FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
                    } catch (_: Exception) {
                        Uri.fromFile(file)
                    }
                }
                else -> Uri.parse(raw)
            }

            val mime = resolveMimeType(item)
            val intent = Intent(Intent.ACTION_VIEW).apply {
                if (raw.startsWith("http://", ignoreCase = true) || raw.startsWith("https://", ignoreCase = true)) {
                    data = resolvedUri
                } else {
                    setDataAndType(resolvedUri, mime)
                }
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(intent)
            true
        } catch (_: ActivityNotFoundException) {
            Toast.makeText(context, "No Android app available to open ${item.title}", Toast.LENGTH_SHORT).show()
            false
        } catch (e: Exception) {
            Toast.makeText(context, "Unable to open: ${e.message ?: "error"}", Toast.LENGTH_SHORT).show()
            false
        }
    }

    private fun isLikelyTextFile(name: String, mime: String): Boolean {
        if (mime.startsWith("text/") || mime.contains("json") || mime.contains("xml")) return true
        val lower = name.lowercase()
        return listOf(".txt", ".md", ".py", ".kt", ".java", ".json", ".csv", ".log", ".sh", ".xml", ".yaml", ".yml")
            .any { lower.endsWith(it) }
    }

    private fun decodeImageSource(context: Context, source: String, maxDim: Int): Bitmap? {
        if (source.startsWith("data:image/", ignoreCase = true)) {
            val base64Part = source.substringAfter("base64,", "")
            if (base64Part.isEmpty()) return null
            val bytes = Base64.decode(base64Part, Base64.DEFAULT)
            return decodeSampledBytes(bytes, maxDim)
        }
        if (source.startsWith("http://", ignoreCase = true) || source.startsWith("https://", ignoreCase = true)) {
            val req = Request.Builder()
                .url(source)
                .header("User-Agent", "KaVachHud/2.0")
                .build()
            httpClient.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return null
                val bytes = resp.body?.bytes() ?: return null
                return decodeSampledBytes(bytes, maxDim)
            }
        }
        if (source.startsWith("content://", ignoreCase = true)) {
            val bytes = context.contentResolver.openInputStream(Uri.parse(source))?.use { it.readBytes() } ?: return null
            return decodeSampledBytes(bytes, maxDim)
        }
        val filePath = if (source.startsWith("file://")) Uri.parse(source).path.orEmpty() else source
        val file = File(filePath)
        if (!file.exists() || !file.isFile) return null
        val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.absolutePath, opts)
        opts.inSampleSize = computeSampleSize(opts.outWidth, opts.outHeight, maxDim)
        opts.inJustDecodeBounds = false
        return BitmapFactory.decodeFile(file.absolutePath, opts)
    }

    private fun extractVideoFrame(context: Context, source: String, maxDim: Int): Bitmap? {
        val retriever = MediaMetadataRetriever()
        return try {
            when {
                source.startsWith("http://", ignoreCase = true) || source.startsWith("https://", ignoreCase = true) -> {
                    retriever.setDataSource(source, HashMap())
                }
                source.startsWith("content://", ignoreCase = true) -> {
                    retriever.setDataSource(context, Uri.parse(source))
                }
                else -> {
                    val path = if (source.startsWith("file://")) Uri.parse(source).path.orEmpty() else source
                    if (!File(path).exists()) return null
                    retriever.setDataSource(path)
                }
            }
            val raw = retriever.getFrameAtTime(1_000_000L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                ?: retriever.frameAtTime
                ?: return null
            scaleBitmapDown(raw, maxDim)
        } catch (_: Exception) {
            null
        } finally {
            try {
                retriever.release()
            } catch (_: Exception) {}
        }
    }

    private fun decodeSampledBytes(bytes: ByteArray, maxDim: Int): Bitmap? {
        val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts)
        opts.inSampleSize = computeSampleSize(opts.outWidth, opts.outHeight, maxDim)
        opts.inJustDecodeBounds = false
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts)
    }

    private fun computeSampleSize(w: Int, h: Int, maxDim: Int): Int {
        var sample = 1
        val largest = maxOf(w, h)
        while (largest / sample > maxDim * 2) {
            sample *= 2
        }
        return sample.coerceAtLeast(1)
    }

    private fun scaleBitmapDown(bmp: Bitmap, maxDim: Int): Bitmap {
        val largest = maxOf(bmp.width, bmp.height)
        if (largest <= maxDim || largest <= 0) return bmp
        val ratio = maxDim.toFloat() / largest.toFloat()
        val w = (bmp.width * ratio).toInt().coerceAtLeast(1)
        val h = (bmp.height * ratio).toInt().coerceAtLeast(1)
        return Bitmap.createScaledBitmap(bmp, w, h, true)
    }
}
