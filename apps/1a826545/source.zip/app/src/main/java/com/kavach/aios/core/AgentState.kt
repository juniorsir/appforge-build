package com.kavach.aios.core

enum class AgentState {
    IDLE, BUSY, OFFLINE, ERROR
}

enum class HealthStatus {
    HEALTHY, WARNING, CRITICAL
}
