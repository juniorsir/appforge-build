package com.kavach.capabilities.camera

import com.kavach.capabilities.CapabilityResult

interface CameraRepository {
    suspend fun takePicture(): CapabilityResult<String> // Returns local file URI string
    suspend fun recordVideo(): CapabilityResult<String>
}
