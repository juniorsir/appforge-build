package com.kavach.presentation.timeline

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.kavach.BaseApplication
import com.kavach.data.local.LocationPointEntity
import com.kavach.data.local.TimelineEventEntity
import com.kavach.data.local.VaultCategory
import com.kavach.data.local.VaultCountSummary
import com.kavach.data.local.VaultSyncStatus
import com.kavach.hardware.DeviceBridgeManager
import com.kavach.telemetry.OfflineTelemetryVaultManager
import com.kavach.telemetry.TelemetryVaultExporter
import com.kavach.telemetry.VaultUiSummary
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Calendar

enum class TimelineCategoryFilter(val key: String, val label: String) {
    ALL("", "All"),
    LOCATION(VaultCategory.LOCATION, "GPS Paths"),
    APPS_UNLOCKS("APPS_UNLOCKS", "Apps & Unlocks"),
    NOTIFICATIONS(VaultCategory.NOTIFICATION, "Notifications"),
    DNS(VaultCategory.DNS, "DNS & Blocks"),
    POWER_NET("POWER_NET", "Power & Net")
}

enum class TimelineWindowFilter(val label: String, val durationMs: Long) {
    TODAY("Today", 0L),
    HOURS_24("24h", 24L * 3600_000L),
    DAYS_7("7d", 7L * 86_400_000L),
    DAYS_20("All 20d", 20L * 86_400_000L)
}

data class TimelineUiState(
    val uiSummary: VaultUiSummary = VaultUiSummary(),
    val countSummary: VaultCountSummary = VaultCountSummary(),
    val selectedCategory: TimelineCategoryFilter = TimelineCategoryFilter.ALL,
    val selectedWindow: TimelineWindowFilter = TimelineWindowFilter.HOURS_24,
    val searchQuery: String = "",
    val pendingOnly: Boolean = false,
    val events: List<TimelineEventEntity> = emptyList(),
    val locationPath: List<LocationPointEntity> = emptyList(),
    val totalDistanceMeters: Float = 0f,
    val maxSpeedKmh: Float = 0f,
    val selectedWaypointIndex: Int = -1,
    val actionFeedback: String? = null
)

class TimelineViewModel(
    private val vaultManager: OfflineTelemetryVaultManager,
    private val deviceBridgeManager: DeviceBridgeManager
) : ViewModel() {

    private val _selectedCategory = MutableStateFlow(TimelineCategoryFilter.ALL)
    private val _selectedWindow = MutableStateFlow(TimelineWindowFilter.HOURS_24)
    private val _searchQuery = MutableStateFlow("")
    private val _pendingOnly = MutableStateFlow(false)
    private val _selectedWaypointIndex = MutableStateFlow(-1)
    private val _countSummary = MutableStateFlow(VaultCountSummary())
    private val _actionFeedback = MutableStateFlow<String?>(null)

    private val filterFlow = combine(
        _selectedCategory,
        _selectedWindow,
        _searchQuery,
        _pendingOnly
    ) { cat, win, q, pend ->
        FilterParams(cat, win, q, pend)
    }

    val uiState: StateFlow<TimelineUiState> = combine(
        vaultManager.vaultUiSummaryFlow,
        _countSummary,
        filterFlow,
        vaultManager.recentEventsFlow,
        vaultManager.recentLocationsFlow,
        _selectedWaypointIndex,
        _actionFeedback
    ) { values ->
        val summary = values[0] as VaultUiSummary
        val counts = values[1] as VaultCountSummary
        val filter = values[2] as FilterParams
        @Suppress("UNCHECKED_CAST")
        val allEvents = values[3] as List<TimelineEventEntity>
        @Suppress("UNCHECKED_CAST")
        val allLocations = values[4] as List<LocationPointEntity>
        val selectedWp = values[5] as Int
        val feedback = values[6] as String?

        val sinceMs = computeSinceTimestamp(filter.window)
        val qLower = filter.query.trim().lowercase()

        val filteredEvents = allEvents.filter { evt ->
            if (evt.timestamp < sinceMs) return@filter false
            if (filter.pendingOnly && evt.syncStatus != VaultSyncStatus.PENDING) return@filter false
            val catMatch = when (filter.category) {
                TimelineCategoryFilter.ALL -> true
                TimelineCategoryFilter.LOCATION -> evt.category == VaultCategory.LOCATION
                TimelineCategoryFilter.APPS_UNLOCKS -> evt.category == VaultCategory.APP || evt.category == VaultCategory.UNLOCK
                TimelineCategoryFilter.NOTIFICATIONS -> evt.category == VaultCategory.NOTIFICATION
                TimelineCategoryFilter.DNS -> evt.category == VaultCategory.DNS
                TimelineCategoryFilter.POWER_NET -> evt.category == VaultCategory.POWER || evt.category == VaultCategory.NETWORK
            }
            if (!catMatch) return@filter false
            if (qLower.isNotEmpty()) {
                val hay = "${evt.title} ${evt.detail} ${evt.packageName} ${evt.domain} ${evt.subType}".lowercase()
                if (!hay.contains(qLower)) return@filter false
            }
            true
        }

        val pathAsc = allLocations
            .filter { loc ->
                loc.timestamp >= sinceMs &&
                    (!filter.pendingOnly || loc.syncStatus == VaultSyncStatus.PENDING)
            }
            .sortedBy { it.timestamp }

        val distMeters = TelemetryVaultExporter.computeTotalDistanceMeters(pathAsc)
        val maxSpdKmh = (pathAsc.maxOfOrNull { it.speedMps } ?: 0f) * 3.6f
        val effectiveIdx = if (pathAsc.isEmpty()) -1
        else if (selectedWp in pathAsc.indices) selectedWp else pathAsc.lastIndex

        TimelineUiState(
            uiSummary = summary,
            countSummary = counts,
            selectedCategory = filter.category,
            selectedWindow = filter.window,
            searchQuery = filter.query,
            pendingOnly = filter.pendingOnly,
            events = filteredEvents,
            locationPath = pathAsc,
            totalDistanceMeters = distMeters,
            maxSpeedKmh = maxSpdKmh,
            selectedWaypointIndex = effectiveIdx,
            actionFeedback = feedback
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000L),
        initialValue = TimelineUiState()
    )

    init {
        refreshSummary()
    }

    private data class FilterParams(
        val category: TimelineCategoryFilter,
        val window: TimelineWindowFilter,
        val query: String,
        val pendingOnly: Boolean
    )

    private fun computeSinceTimestamp(win: TimelineWindowFilter): Long {
        val now = System.currentTimeMillis()
        return when (win) {
            TimelineWindowFilter.TODAY -> {
                Calendar.getInstance().apply {
                    set(Calendar.HOUR_OF_DAY, 0)
                    set(Calendar.MINUTE, 0)
                    set(Calendar.SECOND, 0)
                    set(Calendar.MILLISECOND, 0)
                }.timeInMillis
            }
            else -> now - win.durationMs
        }
    }

    fun refreshSummary() {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                _countSummary.value = vaultManager.getSummary()
            } catch (_: Throwable) {}
        }
    }

    fun selectCategory(category: TimelineCategoryFilter) {
        _selectedCategory.value = category
    }

    fun selectWindow(window: TimelineWindowFilter) {
        _selectedWindow.value = window
        _selectedWaypointIndex.value = -1
    }

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun togglePendingOnly() {
        _pendingOnly.value = !_pendingOnly.value
    }

    fun stepWaypoint(delta: Int, totalCount: Int) {
        if (totalCount <= 0) return
        val current = _selectedWaypointIndex.value.let { if (it in 0 until totalCount) it else totalCount - 1 }
        val next = (current + delta).coerceIn(0, totalCount - 1)
        _selectedWaypointIndex.value = next
    }

    fun selectWaypoint(index: Int) {
        _selectedWaypointIndex.value = index
    }

    fun triggerSyncNow() {
        viewModelScope.launch(Dispatchers.IO) {
            val res = vaultManager.syncPendingBatchesInternal(manual = true)
            _countSummary.value = vaultManager.getSummary()
            _actionFeedback.value = res.optString("message", res.optString("error", "Sync complete"))
        }
    }

    fun captureGpsFixNow() {
        viewModelScope.launch(Dispatchers.IO) {
            val locJson = deviceBridgeManager.getCurrentLocationDetails()
            val ok = locJson.optBoolean("success", false)
            refreshSummary()
            _actionFeedback.value = if (ok) {
                "Captured GPS fix & stored in vault"
            } else {
                locJson.optString("error", "GPS fix unavailable — check location permission/provider")
            }
        }
    }

    fun exportVault(format: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val win = _selectedWindow.value
            val sinceMs = computeSinceTimestamp(win)
            val res = vaultManager.exportVaultJson(
                format = format,
                category = when (_selectedCategory.value) {
                    TimelineCategoryFilter.LOCATION -> "LOCATION"
                    TimelineCategoryFilter.NOTIFICATIONS -> "NOTIFICATION"
                    TimelineCategoryFilter.DNS -> "DNS"
                    else -> ""
                },
                sinceMs = sinceMs
            )
            val filePath = res.optString("filePath", "")
            val count = res.optInt("exportedEventsCount", 0) + res.optInt("exportedLocationsCount", 0)
            _actionFeedback.value = if (filePath.isNotBlank()) {
                "Exported $count items (${format.uppercase()}) to Downloads/AeroShare/${res.optString("fileName")}"
            } else {
                "Prepared ${format.uppercase()} export ($count items)"
            }
        }
    }

    fun pruneExpired() {
        viewModelScope.launch(Dispatchers.IO) {
            val count = vaultManager.pruneExpiredSyncedInternal()
            _countSummary.value = vaultManager.getSummary()
            _actionFeedback.value = if (count > 0) {
                "Pruned $count expired (>20d post-sync) records"
            } else {
                "No expired synced records to prune (unsynced queue preserved)"
            }
        }
    }

    fun dismissFeedback() {
        _actionFeedback.value = null
    }

    companion object {
        val Factory: ViewModelProvider.Factory = viewModelFactory {
            initializer {
                val app = this[ViewModelProvider.AndroidViewModelFactory.APPLICATION_KEY] as BaseApplication
                val container = app.container
                TimelineViewModel(
                    vaultManager = container.telemetryVaultManager,
                    deviceBridgeManager = container.deviceBridgeManager
                )
            }
        }
    }
}
