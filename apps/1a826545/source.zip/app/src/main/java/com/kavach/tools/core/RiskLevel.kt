package com.kavach.tools.core

enum class RiskLevel {
    SAFE, MEDIUM, HIGH, CRITICAL
}
