package com.kavach.accessibility

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Rect
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo
import com.kavach.accessibility.models.AccessibilityEventModel
import com.kavach.accessibility.models.AccessibilityNodeModel
import com.kavach.accessibility.models.AccessibilityServiceStatus
import com.kavach.accessibility.models.AccessibilityWindowModel
import com.kavach.accessibility.models.GestureRequestModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object AccessibilityServiceRegistry {
    @Volatile
    var activeService: AccessibilityService? = null
        set(value) {
            field = value
            onServiceStateChangedListener?.invoke(value != null)
        }

    var onServiceStateChangedListener: ((Boolean) -> Unit)? = null
}

class AccessibilityRepositoryImpl : AccessibilityRepository {

    private val _serviceStatus = MutableStateFlow(AccessibilityServiceStatus())
    override val serviceStatus: StateFlow<AccessibilityServiceStatus> = _serviceStatus.asStateFlow()

    private val _recentEvents = MutableStateFlow<List<AccessibilityEventModel>>(emptyList())
    override val recentEvents: StateFlow<List<AccessibilityEventModel>> = _recentEvents.asStateFlow()

    private val _logs = MutableStateFlow<List<String>>(emptyList())
    override val logs: StateFlow<List<String>> = _logs.asStateFlow()

    @Volatile
    var pointerVisualizer: com.kavach.ui.overlay.AgyPointerOverlayManager? = null

    private val logLock = Any()
    private val timeFormatThreadLocal = object : ThreadLocal<SimpleDateFormat>() {
        override fun initialValue(): SimpleDateFormat = SimpleDateFormat("HH:mm:ss.SSS", Locale.US)
    }

    init {
        // Track connection and active status changes
        updateStatus()
        AccessibilityServiceRegistry.onServiceStateChangedListener = {
            updateStatus()
        }
    }

    private fun updateStatus() {
        val isEnabled = AccessibilityServiceRegistry.activeService != null
        _serviceStatus.value = AccessibilityServiceStatus(
            isEnabled = isEnabled,
            lastConnectedTime = if (isEnabled) System.currentTimeMillis() else _serviceStatus.value.lastConnectedTime,
            recentEventsCount = _recentEvents.value.size,
            recentGesturesCount = _serviceStatus.value.recentGesturesCount
        )
        addLog("Accessibility service status updated. isEnabled = $isEnabled")
    }

    override fun triggerGesture(gesture: GestureRequestModel, onComplete: (Boolean) -> Unit) {
        if (!gesture.id.startsWith("ptr_")) {
            emitPointerForGesture(gesture)
        }
        dispatchGestureInternal(gesture, onComplete)
    }

    private fun emitPointerForGesture(gesture: GestureRequestModel) {
        val ptr = pointerVisualizer ?: return
        val typeUpper = gesture.type.uppercase()
        when {
            typeUpper in setOf(
                "BACK", "GLOBAL_BACK", "HOME", "GLOBAL_HOME", "RECENTS", "GLOBAL_RECENTS",
                "NOTIFICATIONS", "GLOBAL_NOTIFICATIONS", "QUICK_SETTINGS", "GLOBAL_QUICK_SETTINGS",
                "POWER_DIALOG", "GLOBAL_POWER_DIALOG", "LOCK_SCREEN", "GLOBAL_LOCK_SCREEN",
                "TAKE_SCREENSHOT", "SCREENSHOT"
            ) -> {
                ptr.showKeyBadge(typeUpper.removePrefix("GLOBAL_"))
            }
            typeUpper == "SWIPE" || typeUpper == "DRAG" -> {
                val verb = if (typeUpper == "DRAG") "Drag" else "Swipe"
                ptr.showSwipe(
                    x1 = gesture.startX,
                    y1 = gesture.startY,
                    x2 = gesture.endX,
                    y2 = gesture.endY,
                    durationMs = gesture.durationMs.takeIf { it > 0 } ?: 280L,
                    label = "$verb ${gesture.endX.toInt()},${gesture.endY.toInt()}"
                )
            }
            typeUpper == "LONG_CLICK" || typeUpper == "LONG_PRESS" -> {
                ptr.showLongPress(gesture.startX, gesture.startY, "Long Press")
            }
            else -> {
                ptr.showTap(gesture.startX, gesture.startY, "Tap ${gesture.startX.toInt()},${gesture.startY.toInt()}")
            }
        }
    }

    private fun dispatchGestureInternal(gesture: GestureRequestModel, onComplete: (Boolean) -> Unit) {
        val service = AccessibilityServiceRegistry.activeService
        if (service == null) {
            addLog("GESTURE ERROR: Cannot perform gesture; Accessibility Service is disabled.")
            onComplete(false)
            return
        }

        val typeUpper = gesture.type.uppercase()
        if (typeUpper == "BACK" || typeUpper == "GLOBAL_BACK") {
            val success = service.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)
            addLog("GLOBAL ACTION BACK: success=$success")
            onComplete(success)
            return
        }
        if (typeUpper == "HOME" || typeUpper == "GLOBAL_HOME") {
            val success = service.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME)
            addLog("GLOBAL ACTION HOME: success=$success")
            onComplete(success)
            return
        }
        if (typeUpper == "RECENTS" || typeUpper == "GLOBAL_RECENTS") {
            val success = service.performGlobalAction(AccessibilityService.GLOBAL_ACTION_RECENTS)
            addLog("GLOBAL ACTION RECENTS: success=$success")
            onComplete(success)
            return
        }
        if (typeUpper == "NOTIFICATIONS" || typeUpper == "GLOBAL_NOTIFICATIONS") {
            val success = service.performGlobalAction(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS)
            addLog("GLOBAL ACTION NOTIFICATIONS: success=$success")
            onComplete(success)
            return
        }
        if (typeUpper == "QUICK_SETTINGS" || typeUpper == "GLOBAL_QUICK_SETTINGS") {
            val success = service.performGlobalAction(AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS)
            addLog("GLOBAL ACTION QUICK_SETTINGS: success=$success")
            onComplete(success)
            return
        }
        if (typeUpper == "POWER_DIALOG" || typeUpper == "GLOBAL_POWER_DIALOG") {
            val success = service.performGlobalAction(AccessibilityService.GLOBAL_ACTION_POWER_DIALOG)
            addLog("GLOBAL ACTION POWER_DIALOG: success=$success")
            onComplete(success)
            return
        }
        if (typeUpper == "LOCK_SCREEN" || typeUpper == "GLOBAL_LOCK_SCREEN") {
            val success = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.P) {
                service.performGlobalAction(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN)
            } else false
            addLog("GLOBAL ACTION LOCK_SCREEN: success=$success")
            onComplete(success)
            return
        }
        if (typeUpper == "TAKE_SCREENSHOT" || typeUpper == "SCREENSHOT") {
            val success = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.P) {
                service.performGlobalAction(AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT)
            } else false
            addLog("GLOBAL ACTION TAKE_SCREENSHOT: success=$success")
            onComplete(success)
            return
        }

        try {
            val path = Path()
            path.moveTo(gesture.startX, gesture.startY)
            if (typeUpper == "SWIPE" || typeUpper == "DRAG") {
                path.lineTo(gesture.endX, gesture.endY)
            } else {
                // Click or Long-Click gesture
                path.lineTo(gesture.startX + 1f, gesture.startY + 1f)
            }

            val defaultDur = if (typeUpper == "LONG_CLICK" || typeUpper == "LONG_PRESS") 650L else 100L
            val stroke = GestureDescription.StrokeDescription(
                path,
                0L,
                if (gesture.durationMs <= 0) defaultDur else gesture.durationMs
            )

            val builder = GestureDescription.Builder()
            builder.addStroke(stroke)
            val desc = builder.build()

            addLog("DISPATCH GESTURE: type=${gesture.type}, start=(${gesture.startX}, ${gesture.startY}), duration=${gesture.durationMs}ms")
            
            service.dispatchGesture(desc, object : AccessibilityService.GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    addLog("GESTURE SUCCESS: id=${gesture.id}")
                    _serviceStatus.value = _serviceStatus.value.copy(
                        recentGesturesCount = _serviceStatus.value.recentGesturesCount + 1
                    )
                    onComplete(true)
                }

                override fun onCancelled(gestureDescription: GestureDescription?) {
                    addLog("GESTURE CANCELLED: id=${gesture.id}")
                    onComplete(false)
                }
            }, null)

        } catch (e: Exception) {
            addLog("GESTURE FAILURE: id=${gesture.id}, error=${e.message}")
            onComplete(false)
        }
    }

    override fun clickNodeByText(text: String, onComplete: (Boolean) -> Unit) {
        val matches = searchNodes(text = text, contentDescription = text, viewId = null)
        val target = matches.firstOrNull { it.isClickable } ?: matches.firstOrNull()
        if (target != null) {
            val bounds = target.bounds
            val regex = java.util.regex.Pattern.compile("\\d+")
            val matcher = regex.matcher(bounds)
            val nums = mutableListOf<Int>()
            while (matcher.find()) {
                nums.add(matcher.group().toInt())
            }
            if (nums.size == 4) {
                val cx = ((nums[0] + nums[2]) / 2).toFloat()
                val cy = ((nums[1] + nums[3]) / 2).toFloat()
                val cleanText = text.trim()
                val badgeLabel = if (cleanText.isNotEmpty()) {
                    "Tap \"${if (cleanText.length > 22) cleanText.take(22) + "…" else cleanText}\""
                } else {
                    "Tap ${cx.toInt()},${cy.toInt()}"
                }
                pointerVisualizer?.showTap(cx, cy, badgeLabel)
                val req = GestureRequestModel(
                    id = "click_text_" + System.currentTimeMillis(),
                    type = "CLICK",
                    startX = cx,
                    startY = cy,
                    durationMs = 100
                )
                dispatchGestureInternal(req, onComplete)
                return
            }
        }
        onComplete(false)
    }

    override fun performScroll(forward: Boolean, onComplete: (Boolean) -> Unit) {
        val startY = if (forward) 1400f else 400f
        val endY = if (forward) 300f else 1400f
        pointerVisualizer?.showSwipe(
            x1 = 500f,
            y1 = startY,
            x2 = 500f,
            y2 = endY,
            durationMs = 250L,
            label = if (forward) "Scroll Down" else "Scroll Up"
        )
        val req = GestureRequestModel(
            id = "scroll_" + System.currentTimeMillis(),
            type = "SWIPE",
            startX = 500f,
            startY = startY,
            endX = 500f,
            endY = endY,
            durationMs = 250
        )
        dispatchGestureInternal(req, onComplete)
    }

    override fun inputText(text: String, targetLabel: String?, onComplete: (Boolean) -> Unit) {
        val service = AccessibilityServiceRegistry.activeService
        if (service == null) {
            addLog("INPUT TEXT ERROR: Accessibility Service is disabled.")
            onComplete(false)
            return
        }
        val root = service.rootInActiveWindow
        if (root == null) {
            addLog("INPUT TEXT ERROR: rootInActiveWindow is null.")
            onComplete(false)
            return
        }

        fun findEditableNode(node: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
            if (node == null || isAgyHudNode(node)) return null
            if (!targetLabel.isNullOrBlank()) {
                val matchesTarget = (node.text?.toString()?.contains(targetLabel, ignoreCase = true) == true) ||
                        (node.contentDescription?.toString()?.contains(targetLabel, ignoreCase = true) == true) ||
                        (node.viewIdResourceName?.contains(targetLabel, ignoreCase = true) == true)
                if (matchesTarget && (node.isEditable || node.className?.toString()?.contains("EditText", ignoreCase = true) == true)) {
                    return node
                }
            } else if (node.isEditable && node.isFocused) {
                return node
            }
            for (i in 0 until node.childCount) {
                val found = findEditableNode(node.getChild(i))
                if (found != null) return found
            }
            return null
        }

        fun findAnyEditableNode(node: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
            if (node == null || isAgyHudNode(node)) return null
            if (node.isEditable || node.className?.toString()?.contains("EditText", ignoreCase = true) == true) {
                return node
            }
            for (i in 0 until node.childCount) {
                val found = findAnyEditableNode(node.getChild(i))
                if (found != null) return found
            }
            return null
        }

        val targetNode = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)?.takeIf { it.isEditable }
            ?: findEditableNode(root)
            ?: findAnyEditableNode(root)

        if (targetNode != null) {
            val bounds = Rect()
            targetNode.getBoundsInScreen(bounds)
            val cx = if (bounds.width() > 0) bounds.exactCenterX() else 0f
            val cy = if (bounds.height() > 0) bounds.exactCenterY() else 0f
            pointerVisualizer?.showTyping(cx, cy, text)

            val args = android.os.Bundle().apply {
                putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
            }
            targetNode.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
            val ok = targetNode.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
            addLog("INPUT TEXT: '$text' -> success=$ok")
            onComplete(ok)
        } else {
            addLog("INPUT TEXT FAILED: No editable text field found on screen.")
            onComplete(false)
        }
    }

    private val screenshotExecutor = java.util.concurrent.Executors.newSingleThreadExecutor()

    private data class RawCaptureResult(
        val bitmap: android.graphics.Bitmap? = null,
        val source: String = "",
        val errorDetail: String? = null,
        val errorCode: Int = -1
    )

    private fun captureRawScreenBitmap(): RawCaptureResult {
        val service = AccessibilityServiceRegistry.activeService
        var a11yErrorDetail: String? = null
        var lastErrorCode = -1

        if (service != null && android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
            for (attempt in 0..1) {
                val latch = java.util.concurrent.CountDownLatch(1)
                var capturedBitmap: android.graphics.Bitmap? = null
                var errorCode = -1
                var exceptionMsg: String? = null
                try {
                    service.takeScreenshot(
                        android.view.Display.DEFAULT_DISPLAY,
                        screenshotExecutor,
                        object : AccessibilityService.TakeScreenshotCallback {
                            override fun onSuccess(screenshot: AccessibilityService.ScreenshotResult) {
                                val buffer = screenshot.hardwareBuffer
                                var hwBitmap: android.graphics.Bitmap? = null
                                try {
                                    hwBitmap = android.graphics.Bitmap.wrapHardwareBuffer(
                                        buffer,
                                        screenshot.colorSpace
                                    )
                                    capturedBitmap = hwBitmap?.copy(android.graphics.Bitmap.Config.ARGB_8888, false)
                                } catch (e: Exception) {
                                    exceptionMsg = e.message
                                    addLog("SCREENSHOT BUFFER ERROR: ${e.message}")
                                } finally {
                                    hwBitmap?.recycle()
                                    try {
                                        buffer.close()
                                    } catch (_: Throwable) {}
                                    latch.countDown()
                                }
                            }

                            override fun onFailure(errCode: Int) {
                                errorCode = errCode
                                addLog("SCREENSHOT FAILED: code=$errCode")
                                latch.countDown()
                            }
                        }
                    )
                    if (!latch.await(3000, java.util.concurrent.TimeUnit.MILLISECONDS)) {
                        exceptionMsg = "Timed out waiting for Accessibility screenshot callback"
                    }
                } catch (e: Exception) {
                    exceptionMsg = e.message ?: e::class.java.simpleName
                    addLog("SCREENSHOT EXCEPTION: $exceptionMsg")
                }

                val bmp = capturedBitmap
                if (bmp != null) {
                    return RawCaptureResult(
                        bitmap = bmp,
                        source = "ACCESSIBILITY_SCREENSHOT"
                    )
                }

                lastErrorCode = errorCode
                a11yErrorDetail = when {
                    !exceptionMsg.isNullOrBlank() -> "Accessibility takeScreenshot error: $exceptionMsg"
                    errorCode == 3 -> "Accessibility takeScreenshot rate-limited (interval too short, retry in 1s)"
                    else -> "Accessibility takeScreenshot failed (errorCode=$errorCode)"
                }
                // Android 11+ enforces ~1s minimum interval between takeScreenshot calls (errorCode == 3)
                if (errorCode == 3 && attempt == 0) {
                    try {
                        Thread.sleep(600L)
                    } catch (_: InterruptedException) {
                        break
                    }
                } else {
                    break
                }
            }
        }

        // Fallback A: If our own app's Activity is currently resumed on screen, capture its live window
        // via PixelCopy (API 26+) or decorView.draw so snipping works immediately even before Accessibility is enabled.
        captureForegroundActivityBitmap()?.let { actBmp ->
            return RawCaptureResult(
                bitmap = actBmp,
                source = "ACTIVITY_PIXELCOPY"
            )
        }

        // Fallback B: try shell screencap if AccessibilityService is not active
        var proc: Process? = null
        try {
            proc = ProcessBuilder("sh", "-c", "screencap -p").start()
            val bytes = proc.inputStream.use { it.readBytes() }
            val finished = proc.waitFor(3, java.util.concurrent.TimeUnit.SECONDS)
            if (!finished) {
                proc.destroyForcibly()
            } else if (proc.exitValue() == 0 && bytes.size > 100) {
                val bmp = android.graphics.BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                if (bmp != null) {
                    return RawCaptureResult(
                        bitmap = bmp,
                        source = "SHELL_SCREENCAP"
                    )
                }
            }
        } catch (_: Exception) {
        } finally {
            try { proc?.destroy() } catch (_: Throwable) {}
        }

        return RawCaptureResult(
            bitmap = null,
            errorCode = lastErrorCode,
            errorDetail = when {
                !a11yErrorDetail.isNullOrBlank() -> "$a11yErrorDetail."
                service == null -> "Accessibility Service is not enabled. Enable 'AeroShare / Termux Accessibility' in Android Settings > Accessibility to capture screenshots."
                else -> "Live screenshot capture requires Android 11 (API 30) or higher."
            }
        )
    }

    private fun captureForegroundActivityBitmap(): android.graphics.Bitmap? {
        val activity = com.kavach.BaseApplication.currentResumedActivity() ?: return null
        val window = activity.window ?: return null
        val decor = window.decorView ?: return null
        val w = decor.width
        val h = decor.height
        if (w <= 0 || h <= 0) return null

        val mainHandler = android.os.Handler(android.os.Looper.getMainLooper())
        val loc = IntArray(2)
        val screenDims = IntArray(2)
        val metaLatch = java.util.concurrent.CountDownLatch(1)
        mainHandler.post {
            try {
                decor.getLocationOnScreen(loc)
                val wm = activity.windowManager
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
                    val b = wm.maximumWindowMetrics.bounds
                    screenDims[0] = b.width()
                    screenDims[1] = b.height()
                } else {
                    val dm = android.util.DisplayMetrics()
                    @Suppress("DEPRECATION")
                    wm.defaultDisplay?.getRealMetrics(dm)
                    screenDims[0] = dm.widthPixels
                    screenDims[1] = dm.heightPixels
                }
            } catch (_: Throwable) {
            } finally {
                metaLatch.countDown()
            }
        }
        try { metaLatch.await(300, java.util.concurrent.TimeUnit.MILLISECONDS) } catch (_: InterruptedException) {}

        var rawWinBmp: android.graphics.Bitmap? = null
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            val candidate = try {
                android.graphics.Bitmap.createBitmap(w, h, android.graphics.Bitmap.Config.ARGB_8888)
            } catch (_: Throwable) {
                null
            }
            if (candidate != null) {
                val copyLatch = java.util.concurrent.CountDownLatch(1)
                var copySuccess = false
                try {
                    android.view.PixelCopy.request(
                        window,
                        candidate,
                        { copyResult ->
                            copySuccess = (copyResult == android.view.PixelCopy.SUCCESS)
                            copyLatch.countDown()
                        },
                        mainHandler
                    )
                    copyLatch.await(1500, java.util.concurrent.TimeUnit.MILLISECONDS)
                } catch (_: Throwable) {
                    copySuccess = false
                }
                if (copySuccess) {
                    rawWinBmp = candidate
                } else if (!candidate.isRecycled) {
                    candidate.recycle()
                }
            }
        }

        if (rawWinBmp == null) {
            val drawLatch = java.util.concurrent.CountDownLatch(1)
            val fallbackBmp = try {
                android.graphics.Bitmap.createBitmap(w, h, android.graphics.Bitmap.Config.ARGB_8888)
            } catch (_: Throwable) {
                null
            }
            if (fallbackBmp != null) {
                var ok = false
                mainHandler.post {
                    try {
                        val canvas = android.graphics.Canvas(fallbackBmp)
                        decor.draw(canvas)
                        ok = true
                    } catch (_: Throwable) {
                        ok = false
                    } finally {
                        drawLatch.countDown()
                    }
                }
                try { drawLatch.await(800, java.util.concurrent.TimeUnit.MILLISECONDS) } catch (_: InterruptedException) {}
                if (ok) {
                    rawWinBmp = fallbackBmp
                } else if (!fallbackBmp.isRecycled) {
                    fallbackBmp.recycle()
                }
            }
        }

        val captured = rawWinBmp ?: return null
        val fullW = screenDims[0].takeIf { it > 0 } ?: w
        val fullH = screenDims[1].takeIf { it > 0 } ?: h
        if (loc[0] == 0 && loc[1] == 0 && captured.width == fullW && captured.height == fullH) {
            return captured
        }
        return try {
            val aligned = android.graphics.Bitmap.createBitmap(fullW, fullH, android.graphics.Bitmap.Config.ARGB_8888)
            val canvas = android.graphics.Canvas(aligned)
            canvas.drawColor(android.graphics.Color.BLACK)
            canvas.drawBitmap(captured, loc[0].toFloat(), loc[1].toFloat(), null)
            if (!captured.isRecycled) captured.recycle()
            aligned
        } catch (_: Throwable) {
            captured
        }
    }

    override fun takeScreenshotBase64(quality: Int, maxDimension: Int): org.json.JSONObject {
        val result = org.json.JSONObject()
        val raw = captureRawScreenBitmap()
        val bmp = raw.bitmap
        if (bmp != null) {
            val origW = bmp.width
            val origH = bmp.height
            val scale = if (origW > maxDimension || origH > maxDimension) {
                maxDimension.toFloat() / kotlin.math.max(origW, origH).toFloat()
            } else 1.0f
            val finalBmp = if (scale < 1.0f) {
                val scaled = android.graphics.Bitmap.createScaledBitmap(
                    bmp,
                    (origW * scale).toInt().coerceAtLeast(1),
                    (origH * scale).toInt().coerceAtLeast(1),
                    true
                )
                if (scaled !== bmp) bmp.recycle()
                scaled
            } else bmp

            val bytes: ByteArray
            val width: Int
            val height: Int
            try {
                val baos = java.io.ByteArrayOutputStream(32 * 1024)
                finalBmp.compress(android.graphics.Bitmap.CompressFormat.JPEG, quality.coerceIn(10, 100), baos)
                bytes = baos.toByteArray()
                width = finalBmp.width
                height = finalBmp.height
            } finally {
                if (!finalBmp.isRecycled) finalBmp.recycle()
            }
            val b64 = android.util.Base64.encodeToString(bytes, android.util.Base64.NO_WRAP)

            addLog("SCREENSHOT CAPTURED: ${width}x${height} (${bytes.size / 1024} KB)")
            result.put("success", true)
            result.put("format", "jpeg")
            result.put("width", width)
            result.put("height", height)
            result.put("sizeBytes", bytes.size)
            if (raw.source.isNotBlank()) result.put("source", raw.source)
            result.put("base64", b64)
            return result
        }

        result.put("success", false)
        if (raw.errorCode >= 0) result.put("errorCode", raw.errorCode)
        result.put("error", raw.errorDetail ?: "Screenshot capture failed")
        return result
    }

    override fun captureCroppedScreenshotBase64(
        x1: Int,
        y1: Int,
        x2: Int,
        y2: Int,
        screenWidth: Int,
        screenHeight: Int,
        quality: Int,
        maxDimension: Int
    ): org.json.JSONObject {
        val result = org.json.JSONObject()
        val raw = captureRawScreenBitmap()
        val fullBmp = raw.bitmap
        if (fullBmp == null) {
            result.put("success", false)
            if (raw.errorCode >= 0) result.put("errorCode", raw.errorCode)
            result.put("error", raw.errorDetail ?: "Screenshot capture failed")
            return result
        }

        try {
            val bw = fullBmp.width.coerceAtLeast(1)
            val bh = fullBmp.height.coerceAtLeast(1)
            val refW = screenWidth.coerceAtLeast(1).toFloat()
            val refH = screenHeight.coerceAtLeast(1).toFloat()
            val scaleX = bw.toFloat() / refW
            val scaleY = bh.toFloat() / refH

            val left = (kotlin.math.min(x1, x2) * scaleX).toInt().coerceIn(0, bw - 1)
            val top = (kotlin.math.min(y1, y2) * scaleY).toInt().coerceIn(0, bh - 1)
            val right = (kotlin.math.max(x1, x2) * scaleX).toInt().coerceIn(left + 1, bw)
            val bottom = (kotlin.math.max(y1, y2) * scaleY).toInt().coerceIn(top + 1, bh)

            val cropW = (right - left).coerceAtLeast(1)
            val cropH = (bottom - top).coerceAtLeast(1)
            val cropped = android.graphics.Bitmap.createBitmap(fullBmp, left, top, cropW, cropH)
            if (cropped !== fullBmp && !fullBmp.isRecycled) {
                fullBmp.recycle()
            }

            val downScale = if (cropW > maxDimension || cropH > maxDimension) {
                maxDimension.toFloat() / kotlin.math.max(cropW, cropH).toFloat()
            } else 1.0f
            val finalBmp = if (downScale < 1.0f) {
                val scaled = android.graphics.Bitmap.createScaledBitmap(
                    cropped,
                    (cropW * downScale).toInt().coerceAtLeast(1),
                    (cropH * downScale).toInt().coerceAtLeast(1),
                    true
                )
                if (scaled !== cropped && !cropped.isRecycled) cropped.recycle()
                scaled
            } else cropped

            val bytes: ByteArray
            val outW: Int
            val outH: Int
            try {
                val baos = java.io.ByteArrayOutputStream(24 * 1024)
                finalBmp.compress(android.graphics.Bitmap.CompressFormat.JPEG, quality.coerceIn(10, 100), baos)
                bytes = baos.toByteArray()
                outW = finalBmp.width
                outH = finalBmp.height
            } finally {
                if (!finalBmp.isRecycled) finalBmp.recycle()
            }
            val b64 = android.util.Base64.encodeToString(bytes, android.util.Base64.NO_WRAP)
            addLog("SNIP SCREENSHOT CAPTURED: ${outW}x${outH} (${bytes.size / 1024} KB)")
            result.put("success", true)
            result.put("format", "jpeg")
            result.put("mimeType", "image/jpeg")
            result.put("width", outW)
            result.put("height", outH)
            result.put("sizeBytes", bytes.size)
            if (raw.source.isNotBlank()) result.put("source", raw.source)
            result.put("base64", b64)
            return result
        } catch (e: Exception) {
            if (!fullBmp.isRecycled) fullBmp.recycle()
            result.put("success", false)
            result.put("error", e.message ?: "Failed cropping snip screenshot")
            return result
        }
    }

    override fun getFullNodeTree(): List<AccessibilityNodeModel> {
        val service = AccessibilityServiceRegistry.activeService
        if (service == null) {
            addLog("INSPECT ERROR: Service not active.")
            return emptyList()
        }

        val nodes = mutableListOf<AccessibilityNodeModel>()
        val windows = try { service.windows } catch (_: Throwable) { null }
        if (!windows.isNullOrEmpty()) {
            val appWindows = windows.filter { w ->
                w.type == AccessibilityWindowInfo.TYPE_APPLICATION && !isAgyHudWindow(w)
            }
            if (appWindows.isNotEmpty()) {
                for (w in appWindows) {
                    val wRoot = try { w.root } catch (_: Throwable) { null } ?: continue
                    convertNodeInfo(wRoot)?.let { nodes.add(it) }
                }
            }
        }

        if (nodes.isEmpty()) {
            val rootNode = service.rootInActiveWindow
            if (rootNode == null) {
                addLog("INSPECT WARNING: rootInActiveWindow returned null.")
                return emptyList()
            }
            convertNodeInfo(rootNode)?.let { nodes.add(it) }
        }
        return nodes
    }

    override fun getVisibleWindows(excludeHud: Boolean): List<AccessibilityWindowModel> {
        val service = AccessibilityServiceRegistry.activeService ?: return emptyList()
        val windows = try { service.windows } catch (_: Throwable) { null } ?: return emptyList()
        val result = mutableListOf<AccessibilityWindowModel>()
        for (w in windows) {
            if (excludeHud && isAgyHudWindow(w)) continue
            val rect = Rect()
            try {
                w.getBoundsInScreen(rect)
            } catch (_: Throwable) {}
            val pkg = try { w.root?.packageName?.toString() } catch (_: Throwable) { null }
            val typeStr = when (w.type) {
                AccessibilityWindowInfo.TYPE_APPLICATION -> "APPLICATION"
                AccessibilityWindowInfo.TYPE_INPUT_METHOD -> "INPUT_METHOD"
                AccessibilityWindowInfo.TYPE_SYSTEM -> "SYSTEM"
                AccessibilityWindowInfo.TYPE_ACCESSIBILITY_OVERLAY -> "ACCESSIBILITY_OVERLAY"
                else -> if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N &&
                    w.type == AccessibilityWindowInfo.TYPE_SPLIT_SCREEN_DIVIDER
                ) "SPLIT_SCREEN_DIVIDER" else "OTHER_${w.type}"
            }
            result.add(
                AccessibilityWindowModel(
                    id = w.id,
                    packageName = pkg,
                    type = typeStr,
                    bounds = "[${rect.left},${rect.top}][${rect.right},${rect.bottom}]",
                    left = rect.left,
                    top = rect.top,
                    right = rect.right,
                    bottom = rect.bottom,
                    isFocused = w.isFocused,
                    isActive = w.isActive
                )
            )
        }
        return result
    }

    internal fun isAgyHudWindow(window: AccessibilityWindowInfo?): Boolean {
        if (window == null) return false
        val titleStr = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
            try { window.title?.toString() } catch (_: Throwable) { null }
        } else null
        if (!titleStr.isNullOrBlank() && titleStr.contains(com.kavach.ui.overlay.AgyHudOverlayManager.HUD_NODE_TAG_PREFIX, ignoreCase = true)) {
            return true
        }
        val root = try { window.root } catch (_: Throwable) { null } ?: return false
        if (isAgyHudNode(root)) return true
        for (i in 0 until root.childCount.coerceAtMost(8)) {
            if (isAgyHudNode(root.getChild(i))) return true
        }
        return false
    }

    override fun searchNodes(text: String?, contentDescription: String?, viewId: String?): List<AccessibilityNodeModel> {
        val allNodes = getFullNodeTree()
        val results = mutableListOf<AccessibilityNodeModel>()
        
        fun searchRecursive(node: AccessibilityNodeModel) {
            var match = false
            if (text != null && node.text?.contains(text, ignoreCase = true) == true) match = true
            if (contentDescription != null && node.contentDescription?.contains(contentDescription, ignoreCase = true) == true) match = true
            if (viewId != null && node.viewId?.contains(viewId, ignoreCase = true) == true) match = true
            
            if (match) {
                results.add(node)
            }
            
            for (child in node.children) {
                searchRecursive(child)
            }
        }

        for (node in allNodes) {
            searchRecursive(node)
        }

        addLog("SEARCH NODES: query(text=$text, desc=$contentDescription, id=$viewId) -> found ${results.size} matches")
        return results
    }

    override fun addLog(message: String) {
        val timestamp = try {
            timeFormatThreadLocal.get()?.format(Date()) ?: "--:--:--"
        } catch (_: Throwable) {
            "--:--:--"
        }
        val formatted = "[$timestamp] $message"
        synchronized(logLock) {
            _logs.value = (listOf(formatted) + _logs.value).take(150)
        }
    }

    override fun addEvent(event: AccessibilityEventModel) {
        synchronized(logLock) {
            val updated = (listOf(event) + _recentEvents.value).take(100)
            _recentEvents.value = updated
            _serviceStatus.value = _serviceStatus.value.copy(
                recentEventsCount = updated.size
            )
        }
    }

    internal fun isAgyHudIdentifier(viewId: String?, contentDescription: String?): Boolean {
        val prefix = com.kavach.ui.overlay.AgyHudOverlayManager.HUD_NODE_TAG_PREFIX
        if (!viewId.isNullOrBlank() && viewId.contains(prefix, ignoreCase = true)) return true
        if (!contentDescription.isNullOrBlank() && contentDescription.contains(prefix, ignoreCase = true)) return true
        return false
    }

    private fun isAgyHudNode(node: AccessibilityNodeInfo?): Boolean {
        if (node == null) return false
        return isAgyHudIdentifier(
            viewId = node.viewIdResourceName,
            contentDescription = node.contentDescription?.toString()
        )
    }

    internal fun convertNodeInfo(node: AccessibilityNodeInfo?): AccessibilityNodeModel? {
        if (node == null || isAgyHudNode(node)) return null
        val bounds = Rect()
        node.getBoundsInScreen(bounds)

        val childList = mutableListOf<AccessibilityNodeModel>()
        for (i in 0 until node.childCount) {
            val child = node.getChild(i)
            if (child != null && !isAgyHudNode(child)) {
                convertNodeInfo(child)?.let { childList.add(it) }
            }
        }

        return AccessibilityNodeModel(
            text = node.text?.toString(),
            contentDescription = node.contentDescription?.toString(),
            viewId = node.viewIdResourceName,
            className = node.className?.toString(),
            isClickable = node.isClickable,
            isScrollable = node.isScrollable,
            isEditable = node.isEditable,
            isFocused = node.isFocused,
            bounds = "[${bounds.left},${bounds.top}][${bounds.right},${bounds.bottom}]",
            children = childList,
            packageName = node.packageName?.toString()
        )
    }
}
