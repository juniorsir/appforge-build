package com.kavach.aios.core

import com.kavach.aios.planning.Task
import com.kavach.aios.planning.TaskResult

interface Agent {
    val identity: AgentIdentity
    val healthStatus: HealthStatus
    var state: AgentState

    suspend fun initialize(): Boolean
    suspend fun executeTask(task: Task): TaskResult
    suspend fun shutdown(): Boolean
}
