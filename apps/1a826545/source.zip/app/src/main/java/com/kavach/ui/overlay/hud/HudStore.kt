package com.kavach.ui.overlay.hud

import android.content.Context
import android.media.AudioManager
import android.os.Build
import android.provider.Settings
import com.kavach.accessibility.models.AccessibilityNodeModel
import com.kavach.ui.overlay.AgyPointerOverlayManager
import com.kavach.ui.overlay.AgyRegionSnipOverlayManager
import com.kavach.ui.overlay.AgySmartSuggestionsResolver
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID
import java.util.concurrent.ConcurrentLinkedQueue

class HudStore(
    private val context: Context,
    private val onCommandBroadcast: ((JSONObject) -> Unit)? = null,
    private val onRunRecorded: ((RunRecord) -> Unit)? = null,
    private val onMediaControl: ((String) -> Unit)? = null
) {
    data class RunRecord(
        val title: String,
        val promptText: String,
        val finalState: String,
        val iconHint: String,
        val appPackage: String,
        val durationMs: Long,
        val stepCount: Int,
        val detailedOutput: String,
        val outputLogs: List<String>
    )

    private val stateLock = Any()
    private val commandQueue = ConcurrentLinkedQueue<JSONObject>()
    private val _uiState = MutableStateFlow(HudModels.HudUiState())
    val uiState: StateFlow<HudModels.HudUiState> = _uiState.asStateFlow()

    private val _isHudVisible = MutableStateFlow(false)
    val isHudVisible: StateFlow<Boolean> = _isHudVisible.asStateFlow()

    private val _pointerEnabledFlow = MutableStateFlow(true)
    val pointerEnabledFlow: StateFlow<Boolean> = _pointerEnabledFlow.asStateFlow()

    @Volatile
    var pointerOverlayManager: AgyPointerOverlayManager? = null
    @Volatile
    var regionSnipOverlayManager: AgyRegionSnipOverlayManager? = null
    @Volatile
    var foregroundPackageProvider: (() -> String?)? = null
    @Volatile
    var nodeTreeProvider: (() -> List<AccessibilityNodeModel>)? = null
    @Volatile
    var regionScreenshotProvider: ((Int, Int, Int, Int, Int, Int) -> AgyRegionSnipOverlayManager.CapturedRegionBitmap?)? = null

    @Volatile
    var onUiRenderRequested: ((HudModels.HudUiState) -> Unit)? = null
    @Volatile
    var onUiHideRequested: (() -> Unit)? = null
    @Volatile
    var onPassThroughRequested: ((Float, Float, Float, Float, Long) -> Boolean)? = null

    private var activePromptText: String = ""
    private var activeRunStartMs: Long = 0L

    fun hasOverlayPermission(): Boolean {
        return Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(context)
    }

    fun getOverlayPermissionIntent(): android.content.Intent? {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            android.content.Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                android.net.Uri.parse("package:${context.packageName}")
            ).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
        } else null
    }

    fun showHud(collapsed: Boolean = false): Boolean {
        if (!hasOverlayPermission()) return false
        val next = synchronized(stateLock) {
            val fgPkg = _uiState.value.appPackage.ifBlank { foregroundPackageProvider?.invoke().orEmpty() }
            val resolvedActions = if (_uiState.value.quickActions.isNotEmpty()) {
                _uiState.value.quickActions
            } else if (fgPkg.isNotBlank()) {
                AgySmartSuggestionsResolver.resolve(fgPkg, maxItems = 3)
            } else emptyList()
            _uiState.value.copy(
                isVisible = true,
                isCollapsed = collapsed,
                appPackage = fgPkg,
                quickActions = resolvedActions,
                updatedAtMs = System.currentTimeMillis()
            )
        }
        publishState(next)
        return true
    }

    fun setCollapsed(collapsed: Boolean) {
        val next = synchronized(stateLock) {
            _uiState.value.copy(
                isVisible = true,
                isCollapsed = collapsed,
                updatedAtMs = System.currentTimeMillis()
            )
        }
        publishState(next)
    }

    fun hideAll(): JSONObject {
        val next = synchronized(stateLock) {
            _uiState.value.copy(
                isVisible = false,
                updatedAtMs = System.currentTimeMillis()
            )
        }
        _uiState.value = next
        _isHudVisible.value = false
        pointerOverlayManager?.hidePointer()
        onUiHideRequested?.invoke()
        return JSONObject().apply {
            put("success", true)
            put("visible", false)
            put("state", next.status.wireName)
        }
    }

    fun resetState(): JSONObject {
        commandQueue.clear()
        val next = synchronized(stateLock) {
            HudModels.HudUiState(
                status = HudModels.HudStatus.IDLE,
                isVisible = _uiState.value.isVisible,
                isCollapsed = _uiState.value.isCollapsed,
                title = "Agy Ready",
                updatedAtMs = System.currentTimeMillis()
            )
        }
        publishState(next)
        return JSONObject().apply {
            put("success", true)
            put("state", next.status.wireName)
        }
    }

    fun updateState(json: JSONObject): JSONObject {
        val next = synchronized(stateLock) {
            val cur = _uiState.value
            val status = HudModels.HudStatus.parse(json.optString("status", json.optString("state", cur.status.wireName)))
            val title = json.optString("title", "").trim().ifBlank { cur.title.ifBlank { "Agy" } }
            val thinking = listOf("thinkingText", "currentAction", "subtitle", "nextAction")
                .firstNotNullOfOrNull { k -> json.optString(k, "").trim().takeIf { it.isNotEmpty() } }
                ?: if (status == HudModels.HudStatus.IDLE) "" else cur.thinkingText
            val detailed = listOf("detailedOutput", "answer", "summary")
                .firstNotNullOfOrNull { k -> if (json.has(k)) json.optString(k, "").trim() else null }
                ?: cur.detailedOutput

            val taskMapObj = json.optJSONObject("taskMap")
            val chess = parseChess(json, taskMapObj) ?: if (status == HudModels.HudStatus.IDLE && json.has("taskMap")) null else cur.chess
            val mediaList = parseMediaList(json, taskMapObj)
            val hardwareChip = parseHardwareChip(json, taskMapObj) ?: cur.hardwareChip
            val approval = if (json.has("approval")) HudModels.ApprovalPrompt.fromJson(json.optJSONObject("approval")) else if (status != HudModels.HudStatus.NEEDS_INPUT) null else cur.approval
            val steps = parseSteps(json) ?: cur.steps
            val actions = parseActions(json) ?: cur.quickActions
            val logs = parseLogs(json) ?: cur.logs

            val playerObj = taskMapObj?.optJSONObject("player") ?: json.optJSONObject("player")
            val mediaPlaying = when {
                json.has("mediaPlaying") -> json.optBoolean("mediaPlaying", false)
                playerObj != null -> playerObj.optBoolean("playing", false)
                else -> cur.mediaPlaying
            }
            val mediaMuted = when {
                json.has("mediaMuted") -> json.optBoolean("mediaMuted", false)
                playerObj != null -> playerObj.optBoolean("muted", false)
                else -> cur.mediaMuted
            }

            val icon = json.optString("icon", cur.iconKey).trim().ifBlank { "spark" }
            val pkg = json.optString("appPackage", cur.appPackage).trim()
            val progress = when {
                json.has("progressPercent") -> json.optInt("progressPercent", -1)
                json.optJSONObject("progress")?.has("percent") == true -> json.optJSONObject("progress")!!.optInt("percent", -1)
                else -> cur.progressPercent
            }

            if (cur.status != HudModels.HudStatus.WORKING && status == HudModels.HudStatus.WORKING) {
                activeRunStartMs = System.currentTimeMillis()
                activePromptText = title
            } else if (status == HudModels.HudStatus.DONE && cur.status != HudModels.HudStatus.DONE && activeRunStartMs > 0L) {
                recordCompletedRun(title, detailed, icon, pkg, steps.size, logs)
            }

            HudModels.HudUiState(
                status = status,
                isVisible = json.optBoolean("visible", true),
                isCollapsed = json.optBoolean("collapsed", cur.isCollapsed),
                title = title,
                thinkingText = thinking,
                detailedOutput = detailed,
                iconKey = icon,
                appPackage = pkg,
                progressPercent = progress,
                steps = steps,
                quickActions = actions,
                mediaItems = mediaList ?: cur.mediaItems,
                activeMediaIndex = json.optInt("activeMediaIndex", cur.activeMediaIndex).coerceAtLeast(0),
                mediaPlaying = mediaPlaying,
                mediaMuted = mediaMuted,
                chess = chess,
                approval = approval,
                hardwareChip = hardwareChip,
                logs = logs,
                autoHideSeconds = json.optInt("autoHideSeconds", cur.autoHideSeconds).coerceAtLeast(0),
                updatedAtMs = System.currentTimeMillis()
            )
        }
        if (json.has("pointerEnabled")) {
            setPointerConfig(
                enabled = json.optBoolean("pointerEnabled", true),
                showLabel = if (json.has("pointerShowLabel")) json.optBoolean("pointerShowLabel", true) else null
            )
        }
        publishState(next)
        return JSONObject().apply {
            put("success", true)
            put("state", next.status.wireName)
            put("visible", next.isVisible)
            put("pointerEnabled", _pointerEnabledFlow.value)
        }
    }

    fun patchState(json: JSONObject): JSONObject {
        val next = synchronized(stateLock) {
            val cur = _uiState.value
            val status = if (json.has("status") || json.has("state")) {
                HudModels.HudStatus.parse(json.optString("status", json.optString("state", cur.status.wireName)))
            } else cur.status
            val thinking = listOf("thinkingText", "currentAction", "subtitle")
                .firstNotNullOfOrNull { k -> if (json.has(k)) json.optString(k, "").trim() else null }
                ?: cur.thinkingText
            val detailed = listOf("detailedOutput", "answer", "summary")
                .firstNotNullOfOrNull { k -> if (json.has(k)) json.optString(k, "").trim() else null }
                ?: cur.detailedOutput

            val updatedLogs = cur.logs.toMutableList()
            val singleLog = json.optString("appendLog", "").trim()
            if (singleLog.isNotEmpty()) updatedLogs.add(singleLog)
            json.optJSONArray("appendLogs")?.let { arr ->
                for (i in 0 until arr.length()) {
                    val line = arr.optString(i, "").trim()
                    if (line.isNotEmpty()) updatedLogs.add(line)
                }
            }

            val taskMapObj = json.optJSONObject("taskMap")
            val updatedChess = parseChess(json, taskMapObj) ?: cur.chess
            val updatedMedia = parseMediaList(json, taskMapObj) ?: cur.mediaItems
            val updatedHw = parseHardwareChip(json, taskMapObj) ?: cur.hardwareChip
            val updatedProgress = when {
                json.has("progressPercent") -> json.optInt("progressPercent", cur.progressPercent)
                json.has("setProgress") -> json.optJSONObject("setProgress")?.optInt("percent", cur.progressPercent) ?: cur.progressPercent
                else -> cur.progressPercent
            }

            cur.copy(
                status = status,
                title = json.optString("title", "").trim().ifBlank { cur.title },
                thinkingText = thinking,
                detailedOutput = detailed,
                progressPercent = updatedProgress,
                chess = updatedChess,
                mediaItems = updatedMedia,
                hardwareChip = updatedHw,
                logs = updatedLogs.takeLast(24),
                isVisible = json.optBoolean("visible", if (cur.isVisible) true else status != HudModels.HudStatus.IDLE),
                updatedAtMs = System.currentTimeMillis()
            )
        }
        publishState(next)
        return JSONObject().apply {
            put("success", true)
            put("state", next.status.wireName)
            put("patched", true)
        }
    }

    fun setApprovalGate(json: JSONObject): JSONObject {
        val approval = HudModels.ApprovalPrompt.fromJson(json)
        val next = synchronized(stateLock) {
            val cur = _uiState.value
            if (approval == null) {
                cur.copy(approval = null, status = if (cur.status == HudModels.HudStatus.NEEDS_INPUT) HudModels.HudStatus.WORKING else cur.status)
            } else {
                cur.copy(
                    status = HudModels.HudStatus.NEEDS_INPUT,
                    isVisible = true,
                    isCollapsed = false,
                    title = approval.title,
                    thinkingText = approval.description.ifBlank { "Waiting for approval..." },
                    approval = approval,
                    updatedAtMs = System.currentTimeMillis()
                )
            }
        }
        publishState(next)
        return JSONObject().apply {
            put("success", true)
            put("approvalActive", approval != null)
            put("state", next.status.wireName)
        }
    }

    fun setPointerConfig(enabled: Boolean?, showLabel: Boolean?): JSONObject {
        val pm = pointerOverlayManager
        if (enabled != null) {
            _pointerEnabledFlow.value = enabled
        }
        pm?.setPointerConfig(enabled = enabled, showLabel = showLabel)
        return JSONObject().apply {
            put("success", true)
            put("pointerEnabled", pm?.isPointerEnabled() ?: _pointerEnabledFlow.value)
            put("showLabel", pm?.isShowLabelEnabled() ?: true)
        }
    }

    fun enqueueAndBroadcastCommand(
        text: String,
        action: String = "PROMPT",
        buttonId: String = "",
        payload: JSONObject? = null
    ) {
        val cmd = JSONObject().apply {
            put("type", "HUD_COMMAND")
            put("id", "cmd_${UUID.randomUUID().toString().take(8)}")
            put("timestamp", System.currentTimeMillis())
            put("action", action.uppercase())
            put("text", text)
            if (buttonId.isNotBlank()) put("buttonId", buttonId)
            if (payload != null) put("payload", payload)
        }
        commandQueue.offer(cmd)
        onCommandBroadcast?.invoke(cmd)
        if (action.equals("PROMPT", ignoreCase = true) && text.isNotBlank()) {
            activePromptText = text
            activeRunStartMs = System.currentTimeMillis()
            val optimistic = synchronized(stateLock) {
                _uiState.value.copy(
                    status = HudModels.HudStatus.WORKING,
                    isVisible = true,
                    title = text.take(48),
                    thinkingText = "Sending to Agy...",
                    approval = null,
                    updatedAtMs = System.currentTimeMillis()
                )
            }
            publishState(optimistic)
        }
    }

    fun pollCommands(): JSONObject {
        val items = JSONArray()
        while (true) {
            val next = commandQueue.poll() ?: break
            items.put(next)
        }
        return JSONObject().apply {
            put("success", true)
            put("count", items.length())
            put("commands", items)
            put("state", _uiState.value.status.wireName)
        }
    }

    fun handleRemoteCommand(json: JSONObject): JSONObject {
        val action = json.optString("action", "PROMPT").trim().uppercase()
        when (action) {
            "HIDE" -> return hideAll()
            "COLLAPSE" -> {
                setCollapsed(true)
                return JSONObject().apply { put("success", true); put("collapsed", true) }
            }
            "EXPAND" -> {
                setCollapsed(false)
                return JSONObject().apply { put("success", true); put("collapsed", false) }
            }
            "TOGGLE_POINTER" -> {
                val en = if (json.has("enabled")) json.optBoolean("enabled", true) else !_pointerEnabledFlow.value
                val sl = if (json.has("showLabel")) json.optBoolean("showLabel", true) else null
                return setPointerConfig(enabled = en, showLabel = sl)
            }
            "RESET" -> return resetState()
            else -> {
                val text = json.optString("text", "").trim()
                val buttonId = json.optString("buttonId", "").trim()
                enqueueAndBroadcastCommand(text = text, action = action, buttonId = buttonId, payload = json.optJSONObject("payload"))
            }
        }
        return JSONObject().apply {
            put("success", true)
            put("state", _uiState.value.status.wireName)
        }
    }

    fun toggleMediaPlayPause(onLocalToggle: ((Boolean) -> Unit)? = null) {
        val state = _uiState.value
        val active = state.mediaItems.getOrNull(state.activeMediaIndex.coerceIn(0, (state.mediaItems.size - 1).coerceAtLeast(0)))
        if (active != null && active.isPlayable && active.uri.isNotBlank()) {
            val nextPlaying = !state.mediaPlaying
            _uiState.value = state.copy(mediaPlaying = nextPlaying)
            onLocalToggle?.invoke(nextPlaying)
        } else {
            onMediaControl?.invoke("PLAY_PAUSE")
            try {
                val am = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
                val now = android.os.SystemClock.uptimeMillis()
                am?.dispatchMediaKeyEvent(android.view.KeyEvent(now, now, android.view.KeyEvent.ACTION_DOWN, android.view.KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE, 0))
                am?.dispatchMediaKeyEvent(android.view.KeyEvent(now, now, android.view.KeyEvent.ACTION_UP, android.view.KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE, 0))
            } catch (_: Throwable) {}
        }
    }

    fun toggleMediaMute(onLocalMute: ((Boolean) -> Unit)? = null) {
        val state = _uiState.value
        val nextMuted = !state.mediaMuted
        _uiState.value = state.copy(mediaMuted = nextMuted)
        val active = state.mediaItems.getOrNull(state.activeMediaIndex.coerceIn(0, (state.mediaItems.size - 1).coerceAtLeast(0)))
        if (active != null && active.isPlayable && active.uri.isNotBlank()) {
            onLocalMute?.invoke(nextMuted)
        } else {
            try {
                val am = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && am != null) {
                    val dir = if (nextMuted) AudioManager.ADJUST_MUTE else AudioManager.ADJUST_UNMUTE
                    am.adjustStreamVolume(AudioManager.STREAM_MUSIC, dir, 0)
                }
            } catch (_: Throwable) {}
        }
    }

    fun setActiveMediaIndex(index: Int) {
        val cur = _uiState.value
        if (cur.mediaItems.isEmpty()) return
        val clamped = index.coerceIn(0, cur.mediaItems.lastIndex)
        if (clamped != cur.activeMediaIndex) {
            _uiState.value = cur.copy(activeMediaIndex = clamped)
        }
    }

    fun temporarilyPassThroughIfColliding(x1: Float, y1: Float, x2: Float, y2: Float, durationMs: Long): Boolean {
        return onPassThroughRequested?.invoke(x1, y1, x2, y2, durationMs) ?: false
    }

    private fun publishState(state: HudModels.HudUiState) {
        _uiState.value = state
        _isHudVisible.value = state.isVisible
        if (state.isVisible) {
            onUiRenderRequested?.invoke(state)
        } else {
            onUiHideRequested?.invoke()
        }
    }

    private fun recordCompletedRun(title: String, detailed: String, icon: String, pkg: String, stepCount: Int, logs: List<String>) {
        val dur = if (activeRunStartMs > 0L) (System.currentTimeMillis() - activeRunStartMs).coerceAtLeast(0L) else 0L
        activeRunStartMs = 0L
        onRunRecorded?.invoke(
            RunRecord(
                title = title,
                promptText = activePromptText.ifBlank { title },
                finalState = "DONE",
                iconHint = icon,
                appPackage = pkg,
                durationMs = dur,
                stepCount = stepCount,
                detailedOutput = detailed,
                outputLogs = logs
            )
        )
    }

    private fun parseChess(root: JSONObject, taskMap: JSONObject?): HudModels.ChessWidgetState? {
        val direct = root.optJSONObject("chess")
        if (direct != null) return HudModels.ChessWidgetState.fromJson(direct)
        val tmChess = taskMap?.optJSONObject("chess")
        if (tmChess != null) return HudModels.ChessWidgetState.fromJson(tmChess)
        return null
    }

    private fun parseMediaList(root: JSONObject, taskMap: JSONObject?): List<HudModels.MediaItem>? {
        val arr = root.optJSONArray("mediaItems")
            ?: taskMap?.optJSONObject("results")?.optJSONArray("items")
            ?: taskMap?.optJSONObject("player")?.optJSONArray("playlist")
            ?: return null
        val out = mutableListOf<HudModels.MediaItem>()
        for (i in 0 until arr.length()) {
            HudModels.MediaItem.fromJson(arr.optJSONObject(i), i)?.let { out.add(it) }
        }
        return out
    }

    private fun parseHardwareChip(root: JSONObject, taskMap: JSONObject?): HudModels.HardwareChip? {
        root.optJSONObject("hardwareChip")?.let { return HudModels.HardwareChip.fromJson(it) }
        val tmMedia = taskMap?.optJSONObject("media")
        if (tmMedia != null) {
            val title = tmMedia.optString("title", "").trim()
            if (title.isNotEmpty()) {
                return HudModels.HardwareChip(
                    label = tmMedia.optString("provider", "Media").ifBlank { "Media" },
                    value = title,
                    iconHint = "music"
                )
            }
        }
        val metricsArr = root.optJSONArray("metrics")
        if (metricsArr != null && metricsArr.length() > 0) {
            val m = metricsArr.optJSONObject(0)
            if (m != null) {
                return HudModels.HardwareChip(
                    label = m.optString("label", "Status"),
                    value = m.optString("value", "")
                )
            }
        }
        return null
    }

    private fun parseSteps(root: JSONObject): List<HudModels.HudStep>? {
        val arr = root.optJSONArray("steps") ?: root.optJSONArray("tasks") ?: return null
        val out = mutableListOf<HudModels.HudStep>()
        for (i in 0 until arr.length()) {
            HudModels.HudStep.fromJson(arr.optJSONObject(i), i)?.let { out.add(it) }
        }
        return out
    }

    private fun parseActions(root: JSONObject): List<HudModels.QuickAction>? {
        val arr = root.optJSONArray("quickActions") ?: return null
        val out = mutableListOf<HudModels.QuickAction>()
        for (i in 0 until arr.length()) {
            HudModels.QuickAction.fromJson(arr.optJSONObject(i))?.let { out.add(it) }
        }
        return out
    }

    private fun parseLogs(root: JSONObject): List<String>? {
        val arr = root.optJSONArray("outputLogs") ?: root.optJSONArray("logs") ?: return null
        val out = mutableListOf<String>()
        for (i in 0 until arr.length()) {
            val s = arr.optString(i, "").trim()
            if (s.isNotEmpty()) out.add(s)
        }
        return out.takeLast(24)
    }
}
