package com.kavach.services

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.wifi.WifiManager
import android.os.Binder
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.kavach.MainActivity
import com.kavach.accessibility.models.GestureRequestModel
import com.kavach.audio.AudioChunkListener
import com.kavach.domain.model.AccessibilityGestureMessage
import com.kavach.domain.model.AccessibilityInspectMessage
import com.kavach.domain.model.AccessibilityInspectResultMessage
import com.kavach.domain.model.AudioStreamMessage
import com.kavach.domain.model.NetworkMessage
import com.kavach.domain.model.RealtimeConnectionState
import com.kavach.domain.model.SessionState
import com.kavach.util.AndroidLogger
import com.kavach.util.AppLogger
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

/**
 * Android Foreground Service managing the decoupled Termux AIOS WebSocket connection,
 * session authentication, reconnect loop, heartbeat, and real-time audio pipeline.
 *
 * Architecture:
 * TERMUX AIOS (127.0.0.1:8000)
 *      ↓
 * WebSocket Server
 *      ↓
 * Android Foreground Service (RealtimeConnectionService)
 *      ↓
 * Android Compose UI (observes StateFlow)
 */
class RealtimeConnectionService : Service() {

    private val logger: AppLogger = AndroidLogger()
    private val tag = "RealtimeConnectionService"

    private val serviceJob = SupervisorJob()
    private val serviceExceptionHandler = kotlinx.coroutines.CoroutineExceptionHandler { _, throwable ->
        logger.e(tag, "Caught unhandled coroutine exception in serviceScope: ${throwable.message}", throwable)
    }
    private val serviceScope = CoroutineScope(Dispatchers.Default + serviceJob + serviceExceptionHandler)
    private val sequenceNumber = AtomicLong(0)
    private val isAudioActive = AtomicBoolean(false)

    private val binder = LocalBinder()

    private var wakeLock: PowerManager.WakeLock? = null
    private var wifiLock: WifiManager.WifiLock? = null
    private var connectivityManager: ConnectivityManager? = null
    private var networkCallback: ConnectivityManager.NetworkCallback? = null

    inner class LocalBinder : Binder() {
        val service: RealtimeConnectionService get() = this@RealtimeConnectionService
    }

    private val audioCaptureEngine by lazy {
        (application as com.kavach.BaseApplication).container.audioCaptureEngine
    }

    private val webSocketRepository by lazy {
        (application as com.kavach.BaseApplication).container.webSocketRepository
    }

    private val sessionRepository by lazy {
        (application as com.kavach.BaseApplication).container.sessionRepository
    }

    override fun onCreate() {
        super.onCreate()
        logger.i(tag, "Foreground Service created.")
        try {
            val container = (application as? com.kavach.BaseApplication)?.container
            container?.httpServer?.start()
            container?.telemetryVaultManager?.startAlwaysOnMonitoring()
        } catch (_: Throwable) {}
        createNotificationChannel()
        registerNetworkCallback()

        _serviceState.update { it.copy(isServiceRunning = true) }

        // Observe and synchronize low-level repository state to unified Service State
        serviceScope.launch {
            webSocketRepository.connectionState.collect { state ->
                try {
                    _serviceState.update { it.copy(status = state) }
                    if (state == SessionState.ConnectionState.CONNECTED) {
                        acquireLocks()
                    } else if (state == SessionState.ConnectionState.DISCONNECTED || state == SessionState.ConnectionState.ERROR) {
                        releaseLocks()
                    }
                    updateNotification(_serviceState.value)
                } catch (t: Throwable) {
                    logger.w(tag, "Error syncing connectionState UI/notification: ${t.message}")
                }
            }
        }
        serviceScope.launch {
            webSocketRepository.sessionId.collect { sid ->
                _serviceState.update { it.copy(sessionId = sid) }
            }
        }
        serviceScope.launch {
            webSocketRepository.latencyMs.collect { lat ->
                _serviceState.update { it.copy(rtt = if (lat > 0) lat else null) }
            }
        }
        serviceScope.launch {
            webSocketRepository.lastConnectedAt.collect { connAt ->
                _serviceState.update { it.copy(lastConnectedAt = connAt) }
            }
        }
        serviceScope.launch {
            webSocketRepository.lastFailureReason.collect { err ->
                _serviceState.update { it.copy(lastError = err) }
            }
        }
        serviceScope.launch {
            webSocketRepository.activeUrlFlow.collect { url ->
                _serviceState.update { it.copy(serverUrl = url, transport = "WebSocket ($url)") }
            }
        }
        serviceScope.launch {
            webSocketRepository.retryCount.collect { retries ->
                _serviceState.update { it.copy(reconnectAttempt = retries) }
            }
        }
        serviceScope.launch {
            webSocketRepository.bytesSent.collect { bSent ->
                _serviceState.update { it.copy(bytesSent = bSent) }
            }
        }
        serviceScope.launch {
            webSocketRepository.bytesReceived.collect { bRecv ->
                _serviceState.update { it.copy(bytesReceived = bRecv) }
            }
        }
        serviceScope.launch {
            webSocketRepository.queueSize.collect { q ->
                _serviceState.update { it.copy(queueSize = q) }
            }
        }

        // Configure audio engine listener to stream PCM frames to WebSocket
        val reusablePcmHolder = ThreadLocal<ByteArray>()
        audioCaptureEngine.setChunkListener(object : AudioChunkListener {
            override fun onAudioChunk(chunk: ShortArray, rms: Double) {
                if (_serviceState.value.status != SessionState.ConnectionState.CONNECTED) return

                val neededLen = chunk.size * 2
                var byteArray = reusablePcmHolder.get()
                if (byteArray == null || byteArray.size != neededLen) {
                    byteArray = ByteArray(neededLen)
                    reusablePcmHolder.set(byteArray)
                }
                for (i in chunk.indices) {
                    val value = chunk[i].toInt()
                    byteArray[i * 2] = (value and 0xFF).toByte()
                    byteArray[i * 2 + 1] = ((value shr 8) and 0xFF).toByte()
                }

                val base64Data = android.util.Base64.encodeToString(byteArray, android.util.Base64.NO_WRAP)
                val currentSession = sessionRepository.currentSession.value

                val message = AudioStreamMessage(
                    timestamp = System.currentTimeMillis(),
                    sessionId = _serviceState.value.sessionId ?: currentSession.sessionId,
                    sequenceNumber = sequenceNumber.incrementAndGet(),
                    dataBase64 = base64Data
                )

                serviceScope.launch {
                    webSocketRepository.sendMessage(message)
                }
            }
        })

        // Collect incoming messages to process remote gestures and node tree inspections securely
        serviceScope.launch {
            try {
                webSocketRepository.incomingMessages.collect { networkMessage ->
                    handleIncomingNetworkMessage(networkMessage)
                }
            } catch (e: CancellationException) {
                logger.i(tag, "Incoming WebSocket loop cancelled.")
            } catch (e: Exception) {
                logger.e(tag, "Error in incoming WebSocket loop", e)
            }
        }
    }

    private fun handleIncomingNetworkMessage(message: NetworkMessage) {
        val app = application as com.kavach.BaseApplication
        val accessibilityRepository = app.container.accessibilityRepository

        when (message) {
            is AccessibilityGestureMessage -> {
                logger.i(tag, "Received remote accessibility gesture: ID=${message.gestureId}, Type=${message.gestureType}")
                val request = GestureRequestModel(
                    id = message.gestureId,
                    type = message.gestureType,
                    startX = message.startX,
                    startY = message.startY,
                    endX = message.endX,
                    endY = message.endY,
                    durationMs = message.durationMs
                )
                accessibilityRepository.triggerGesture(request) { success ->
                    logger.i(tag, "Remote gesture ${message.gestureId} execution result: success=$success")
                }
            }
            is AccessibilityInspectMessage -> {
                logger.i(tag, "Received remote accessibility screen inspection request")
                serviceScope.launch {
                    try {
                        val results = if (message.searchByText != null || message.searchByDesc != null || message.searchById != null) {
                            accessibilityRepository.searchNodes(
                                text = message.searchByText,
                                contentDescription = message.searchByDesc,
                                viewId = message.searchById
                            )
                        } else {
                            accessibilityRepository.getFullNodeTree()
                        }

                        val response = AccessibilityInspectResultMessage(
                            timestamp = System.currentTimeMillis(),
                            sessionId = message.sessionId,
                            nodes = results,
                            queryExecuted = "search(text=${message.searchByText}, desc=${message.searchByDesc}, id=${message.searchById})"
                        )
                        webSocketRepository.sendMessage(response)
                        logger.i(tag, "Dispatched accessibility screen inspection result back over WebSocket")
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Exception) {
                        logger.e(tag, "Failed to run accessibility node query remotely", e)
                    }
                }
            }
            else -> {
                // Handled elsewhere
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action
        logger.i(tag, "onStartCommand received. Action: $action")

        if (intent == null) {
            // Process killed by OS and restarted via START_STICKY
            logger.i(tag, "Recreated by system after process kill. Checking auto-reconnect preferences.")
            startForegroundMode()
            val prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val shouldAutoConnect = prefs.getBoolean(KEY_AUTO_CONNECT, false)
            val configuredDefault = getDefaultOrConfiguredServerUrl()
            val rawSavedUrl = prefs.getString(KEY_SAVED_URL, configuredDefault) ?: configuredDefault
            val savedUrl = if (
                rawSavedUrl.contains("trycloudflare.com") ||
                (configuredDefault != LOCAL_WS_URL && (rawSavedUrl == LOCAL_WS_URL || rawSavedUrl.trimEnd('/').endsWith("/p")))
            ) {
                configuredDefault
            } else {
                rawSavedUrl
            }

            if (shouldAutoConnect) {
                connectInternal(savedUrl)
            }
            return START_STICKY
        }

        when (action) {
            ACTION_CONNECT -> {
                val explicitUrl = intent.getStringExtra(EXTRA_SERVER_URL)?.takeIf { it.isNotBlank() }
                val candidates = getCandidateUrls(this, explicitUrl)
                val primaryUrl = candidates.firstOrNull() ?: LOCAL_WS_URL
                saveConnectionPreference(primaryUrl, true)
                _serviceState.update { current ->
                    val nextStatus = if (current.status == SessionState.ConnectionState.CONNECTED) {
                        SessionState.ConnectionState.CONNECTED
                    } else {
                        SessionState.ConnectionState.CONNECTING
                    }
                    current.copy(status = nextStatus, serverUrl = primaryUrl)
                }
                startForegroundMode()
                connectBestAvailableInternal(candidates, forceSwitch = explicitUrl != null)
            }
            ACTION_DISCONNECT -> {
                saveConnectionPreference(null, false)
                serviceScope.launch {
                    webSocketRepository.disconnect()
                }
            }
            ACTION_RECONNECT -> {
                val explicitUrl = intent.getStringExtra(EXTRA_SERVER_URL)?.takeIf { it.isNotBlank() }
                val candidates = getCandidateUrls(this, explicitUrl)
                val primaryUrl = candidates.firstOrNull() ?: DEFAULT_SERVER_URL
                saveConnectionPreference(primaryUrl, true)
                _serviceState.update { it.copy(status = SessionState.ConnectionState.CONNECTING, serverUrl = primaryUrl) }
                startForegroundMode()
                serviceScope.launch {
                    webSocketRepository.disconnect()
                    kotlinx.coroutines.delay(250)
                    webSocketRepository.connectBestAvailable(candidates, forceSwitch = true)
                }
            }
            ACTION_START -> {
                sequenceNumber.set(0)
                isAudioActive.set(true)
                val explicitUrl = intent.getStringExtra(EXTRA_SERVER_URL)?.takeIf { it.isNotBlank() }
                val candidates = getCandidateUrls(this, explicitUrl)
                val primaryUrl = candidates.firstOrNull() ?: DEFAULT_SERVER_URL
                saveConnectionPreference(primaryUrl, true)
                _serviceState.update { current ->
                    val nextStatus = if (current.status == SessionState.ConnectionState.CONNECTED) {
                        SessionState.ConnectionState.CONNECTED
                    } else {
                        SessionState.ConnectionState.CONNECTING
                    }
                    current.copy(status = nextStatus, serverUrl = primaryUrl)
                }
                startForegroundMode()
                try {
                    audioCaptureEngine.start()
                } catch (t: Throwable) {
                    logger.w(tag, "audioCaptureEngine.start non-fatal: ${t.message}")
                }
                connectBestAvailableInternal(candidates, forceSwitch = explicitUrl != null)
            }
            ACTION_STOP -> {
                isAudioActive.set(false)
                try {
                    audioCaptureEngine.stop()
                } catch (_: Throwable) {}
                saveConnectionPreference(null, false)
                serviceScope.launch {
                    try {
                        webSocketRepository.disconnect()
                    } catch (_: Throwable) {}
                }
                try {
                    stopForeground(STOP_FOREGROUND_REMOVE)
                } catch (t: Throwable) {
                    logger.w(tag, "stopForeground non-fatal error: ${t.message}")
                }
                try {
                    stopSelf()
                } catch (_: Throwable) {}
            }
            ACTION_PAUSE -> {
                try { audioCaptureEngine.pause() } catch (_: Throwable) {}
            }
            ACTION_RESUME -> {
                try { audioCaptureEngine.resume() } catch (_: Throwable) {}
            }
            ACTION_ENSURE_BRIDGE -> {
                startForegroundMode()
                val candidates = getCandidateUrls(this)
                if (candidates.isNotEmpty()) {
                    connectBestAvailableInternal(candidates, forceSwitch = false)
                }
            }
        }

        return START_STICKY
    }

    private fun connectInternal(url: String) {
        val candidates = getCandidateUrls(this, url)
        connectBestAvailableInternal(candidates, forceSwitch = true)
    }

    private fun connectBestAvailableInternal(candidates: List<String>, forceSwitch: Boolean) {
        serviceScope.launch {
            try {
                webSocketRepository.connectBestAvailable(candidates, forceSwitch = forceSwitch)
            } catch (t: Throwable) {
                logger.w(tag, "connectBestAvailableInternal non-fatal: ${t.message}")
            }
        }
    }

    private fun saveConnectionPreference(url: String?, autoConnect: Boolean) {
        val prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().apply {
            putBoolean(KEY_AUTO_CONNECT, autoConnect)
            if (url != null && isCompleteConnectableUrl(url)) {
                putString(KEY_SAVED_URL, url)
                if (isRemoteTunnelUrl(url)) {
                    putString(KEY_LAST_AUTH_TUNNEL_URL, url)
                }
            }
            apply()
        }
    }

    private fun startForegroundMode() {
        try {
            val notification = buildNotification(_serviceState.value)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val hasMicPermission = ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.RECORD_AUDIO
                ) == PackageManager.PERMISSION_GRANTED
                val serviceType = if (isAudioActive.get() && hasMicPermission) {
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE or ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
                } else {
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
                }
                try {
                    startForeground(NOTIFICATION_ID, notification, serviceType)
                } catch (sec: SecurityException) {
                    logger.w(tag, "FGS start with type=$serviceType denied (${sec.message}); retrying with DATA_SYNC")
                    startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
                }
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
        } catch (t: Throwable) {
            // Avoid crashing the entire process on Android 12-16 ForegroundServiceStartNotAllowedException
            // or OEM notification exceptions when started from background context.
            logger.w(tag, "startForegroundMode non-fatal fallback: ${t.javaClass.simpleName}: ${t.message}")
        }
    }

    private fun updateNotification(state: RealtimeConnectionState) {
        try {
            val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager ?: return
            val notification = buildNotification(state)
            notificationManager.notify(NOTIFICATION_ID, notification)
        } catch (t: Throwable) {
            logger.w(tag, "updateNotification non-fatal error: ${t.message}")
        }
    }

    private fun buildNotification(state: RealtimeConnectionState): Notification {
        val notificationIntent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            notificationIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val disconnectIntent = Intent(this, RealtimeConnectionService::class.java).apply {
            action = ACTION_DISCONNECT
        }
        val disconnectPendingIntent = PendingIntent.getService(
            this,
            1,
            disconnectIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val reconnectIntent = Intent(this, RealtimeConnectionService::class.java).apply {
            action = ACTION_RECONNECT
            putExtra(EXTRA_SERVER_URL, state.serverUrl ?: DEFAULT_SERVER_URL)
        }
        val reconnectPendingIntent = PendingIntent.getService(
            this,
            2,
            reconnectIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val activeTarget = state.serverUrl ?: DEFAULT_SERVER_URL
        val (title, text) = when (state.status) {
            SessionState.ConnectionState.CONNECTED -> {
                val rttStr = state.rtt?.let { " (${it}ms RTT)" } ?: ""
                Pair("AeroShare Bridge: Connected", "Active tunnel: $activeTarget$rttStr")
            }
            SessionState.ConnectionState.AUTHENTICATING -> {
                Pair("AeroShare Bridge: Connected", "Authenticated session active ($activeTarget)")
            }
            SessionState.ConnectionState.CONNECTING -> {
                Pair("AeroShare Bridge: Connecting", "Connecting to $activeTarget...")
            }
            SessionState.ConnectionState.RECONNECTING -> {
                Pair("AeroShare Bridge: Reconnecting", "Attempt #${state.reconnectAttempt} to $activeTarget")
            }
            SessionState.ConnectionState.ERROR -> {
                Pair("AeroShare Bridge: Retrying", state.lastError ?: "Reconnecting to $activeTarget")
            }
            SessionState.ConnectionState.DISCONNECTED -> {
                Pair("AeroShare Bridge: HTTP :8080 Ready", "Local bridge active - Tap to open console")
            }
        }

        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(title)
            .setContentText(text)
            .setSmallIcon(android.R.drawable.stat_notify_sync)
            .setContentIntent(pendingIntent)
            .setOngoing(state.status != SessionState.ConnectionState.DISCONNECTED)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setPriority(NotificationCompat.PRIORITY_LOW)

        if (state.status == SessionState.ConnectionState.CONNECTED) {
            builder.addAction(android.R.drawable.ic_menu_close_clear_cancel, "Disconnect", disconnectPendingIntent)
        } else if (state.status == SessionState.ConnectionState.ERROR || state.status == SessionState.ConnectionState.DISCONNECTED) {
            builder.addAction(android.R.drawable.stat_notify_sync, "Connect", reconnectPendingIntent)
        }

        return builder.build()
    }

    private fun acquireLocks() {
        try {
            if (wakeLock == null) {
                val powerManager = getSystemService(Context.POWER_SERVICE) as? PowerManager
                wakeLock = powerManager?.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "AeroShare:WebSocketWakeLock")?.apply {
                    setReferenceCounted(false)
                    acquire(15 * 60 * 1000L) // 15 mins timeout
                }
            } else if (wakeLock?.isHeld == false) {
                wakeLock?.acquire(15 * 60 * 1000L)
            }

            if (wifiLock == null) {
                val wifiManager = applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
                val lockMode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    WifiManager.WIFI_MODE_FULL_LOW_LATENCY
                } else {
                    @Suppress("DEPRECATION")
                    WifiManager.WIFI_MODE_FULL_HIGH_PERF
                }
                wifiLock = wifiManager?.createWifiLock(lockMode, "AeroShare:WebSocketWifiLock")?.apply {
                    setReferenceCounted(false)
                    acquire()
                }
            } else if (wifiLock?.isHeld == false) {
                wifiLock?.acquire()
            }
        } catch (e: Exception) {
            logger.w(tag, "Could not acquire wake/wifi locks: ${e.message}")
        }
    }

    private fun releaseLocks() {
        try {
            if (wakeLock?.isHeld == true) {
                wakeLock?.release()
            }
            if (wifiLock?.isHeld == true) {
                wifiLock?.release()
            }
        } catch (e: Exception) {
            logger.w(tag, "Error releasing wake/wifi locks: ${e.message}")
        }
    }

    private fun registerNetworkCallback() {
        try {
            connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
            val request = NetworkRequest.Builder()
                .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                .build()
            networkCallback = object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) {
                    val status = _serviceState.value.status
                    val prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                    val shouldAutoConnect = prefs.getBoolean(KEY_AUTO_CONNECT, true)
                    if (shouldAutoConnect && (
                        status == SessionState.ConnectionState.ERROR ||
                        status == SessionState.ConnectionState.RECONNECTING ||
                        status == SessionState.ConnectionState.DISCONNECTED
                    )) {
                        logger.i(tag, "Network available. Connecting best available bridge endpoint...")
                        connectBestAvailableInternal(getCandidateUrls(this@RealtimeConnectionService), forceSwitch = false)
                    }
                }
            }
            networkCallback?.let { connectivityManager?.registerNetworkCallback(request, it) }
        } catch (e: Exception) {
            logger.w(tag, "Failed to register network callback: ${e.message}")
        }
    }

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onDestroy() {
        logger.i(tag, "Service destroyed.")
        _serviceState.update { it.copy(isServiceRunning = false) }
        releaseLocks()
        try {
            networkCallback?.let { connectivityManager?.unregisterNetworkCallback(it) }
        } catch (e: Exception) {
            // Ignore
        }
        audioCaptureEngine.setChunkListener(null)
        audioCaptureEngine.stop()
        serviceJob.cancel()
        super.onDestroy()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Termux AIOS Bridge Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Maintains persistent background WebSocket connection and telemetry with Termux AIOS."
                setShowBadge(false)
            }
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
        }
    }

    companion object {
        private const val NOTIFICATION_ID = 4001
        private const val CHANNEL_ID = "termux_aios_bridge_foreground_channel"

        private const val PREFS_NAME = "termux_bridge_prefs"
        private const val KEY_AUTO_CONNECT = "key_auto_connect"
        private const val KEY_SAVED_URL = "key_saved_url"
        private const val KEY_LAST_AUTH_TUNNEL_URL = "key_last_auth_tunnel_url"

        const val RENDER_RELAY_HOST = "https://private-relay-bridge.onrender.com"
        const val CLOUDFLARE_WS_URL = "wss://private-relay-bridge.onrender.com/p/"
        const val CLOUDFLARE_TUNNEL_URL = RENDER_RELAY_HOST
        const val LOCAL_WS_URL = "ws://127.0.0.1:8000/ws"
        const val DEFAULT_SERVER_URL = LOCAL_WS_URL

        fun isRemoteTunnelUrl(url: String?): Boolean {
            if (url.isNullOrBlank()) return false
            return !url.contains("127.0.0.1") && !url.contains("localhost")
        }

        fun isCompleteConnectableUrl(url: String?): Boolean {
            val trimmed = url?.trim()?.trimEnd('/') ?: return false
            if (trimmed.isBlank()) return false
            if (trimmed.contains("trycloudflare.com") || trimmed.contains(":8080")) return false
            val lower = trimmed.lowercase(java.util.Locale.US)
            if (lower.endsWith("/p") || lower.endsWith("/c") || lower.endsWith("/p/ws") || lower.endsWith("/c/ws")) {
                return false
            }
            return true
        }

        fun getLastAuthenticatedTunnelUrl(context: Context): String? {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val savedAuth = prefs.getString(KEY_LAST_AUTH_TUNNEL_URL, null)
            if (isCompleteConnectableUrl(savedAuth) && isRemoteTunnelUrl(savedAuth)) {
                return savedAuth
            }
            val savedMain = prefs.getString(KEY_SAVED_URL, null)
            if (isCompleteConnectableUrl(savedMain) && isRemoteTunnelUrl(savedMain)) {
                return savedMain
            }
            val configured = getDefaultOrConfiguredServerUrl()
            return if (isRemoteTunnelUrl(configured) && isCompleteConnectableUrl(configured)) configured else null
        }

        fun getCandidateUrls(context: Context, preferredUrl: String? = null): List<String> {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val saved = prefs.getString(KEY_SAVED_URL, null)
            val savedAuth = prefs.getString(KEY_LAST_AUTH_TUNNEL_URL, null)
            val configured = getDefaultOrConfiguredServerUrl()

            val ordered = mutableListOf<String>()
            fun addIfValid(candidate: String?) {
                if (isCompleteConnectableUrl(candidate)) {
                    val clean = candidate!!.trim()
                    if (!ordered.contains(clean)) {
                        ordered.add(clean)
                    }
                }
            }

            addIfValid(preferredUrl)
            addIfValid(saved)
            addIfValid(savedAuth)
            addIfValid(configured)
            addIfValid(LOCAL_WS_URL)
            return ordered
        }

        fun getDefaultOrConfiguredServerUrl(): String {
            val envKey = try {
                com.kavach.BuildConfig.RENDER_PHONE_KEY.trim()
            } catch (_: Throwable) {
                ""
            }
            return if (envKey.isNotEmpty() && envKey != "MY_RENDER_PHONE_KEY") {
                "${CLOUDFLARE_WS_URL}${envKey}/ws"
            } else {
                LOCAL_WS_URL
            }
        }

        const val ACTION_CONNECT = "com.kavach.services.action.CONNECT"
        const val ACTION_DISCONNECT = "com.kavach.services.action.DISCONNECT"
        const val ACTION_RECONNECT = "com.kavach.services.action.RECONNECT"
        const val ACTION_START = "com.kavach.services.action.START"
        const val ACTION_STOP = "com.kavach.services.action.STOP"
        const val ACTION_PAUSE = "com.kavach.services.action.PAUSE"
        const val ACTION_RESUME = "com.kavach.services.action.RESUME"
        const val ACTION_ENSURE_BRIDGE = "com.kavach.services.action.ENSURE_BRIDGE"

        const val EXTRA_SERVER_URL = "extra_server_url"

        private val _serviceState = MutableStateFlow(RealtimeConnectionState())
        val serviceState: StateFlow<RealtimeConnectionState> = _serviceState.asStateFlow()

        fun ensureBridge(context: Context) {
            try {
                val intent = Intent(context, RealtimeConnectionService::class.java).apply {
                    action = ACTION_ENSURE_BRIDGE
                }
                startServiceCompat(context, intent)
            } catch (_: Throwable) {}
        }

        /**
         * Connect to Termux AIOS server via Foreground Service.
         * When [url] is null, preserves the user's previously saved relay/local URL.
         */
        fun connect(context: Context, url: String? = null) {
            val intent = Intent(context, RealtimeConnectionService::class.java).apply {
                action = ACTION_CONNECT
                if (!url.isNullOrBlank()) {
                    putExtra(EXTRA_SERVER_URL, url)
                }
            }
            startServiceCompat(context, intent)
        }

        /**
         * Disconnect cleanly from Termux AIOS server.
         */
        fun disconnect(context: Context) {
            try {
                val intent = Intent(context, RealtimeConnectionService::class.java).apply {
                    action = ACTION_DISCONNECT
                }
                context.startService(intent)
            } catch (_: Throwable) {}
        }

        /**
         * Reconnect to Termux AIOS server.
         */
        fun reconnect(context: Context, url: String = DEFAULT_SERVER_URL) {
            val intent = Intent(context, RealtimeConnectionService::class.java).apply {
                action = ACTION_RECONNECT
                putExtra(EXTRA_SERVER_URL, url)
            }
            startServiceCompat(context, intent)
        }

        /**
         * Start audio capture and foreground service.
         */
        fun start(context: Context, url: String = DEFAULT_SERVER_URL) {
            val intent = Intent(context, RealtimeConnectionService::class.java).apply {
                action = ACTION_START
                putExtra(EXTRA_SERVER_URL, url)
            }
            startServiceCompat(context, intent)
        }

        /**
         * Stop audio capture and stop foreground service.
         */
        fun stop(context: Context) {
            try {
                val intent = Intent(context, RealtimeConnectionService::class.java).apply {
                    action = ACTION_STOP
                }
                context.startService(intent)
            } catch (_: Throwable) {}
        }

        /**
         * Pause audio recording in service.
         */
        fun pause(context: Context) {
            try {
                val intent = Intent(context, RealtimeConnectionService::class.java).apply {
                    action = ACTION_PAUSE
                }
                context.startService(intent)
            } catch (_: Throwable) {}
        }

        /**
         * Resume audio recording in service.
         */
        fun resume(context: Context) {
            try {
                val intent = Intent(context, RealtimeConnectionService::class.java).apply {
                    action = ACTION_RESUME
                }
                context.startService(intent)
            } catch (_: Throwable) {}
        }

        private fun startServiceCompat(context: Context, intent: Intent) {
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    context.startForegroundService(intent)
                } else {
                    context.startService(intent)
                }
            } catch (t: Throwable) {
                android.util.Log.w("RealtimeConnectionService", "startServiceCompat failed (${t.javaClass.simpleName}): ${t.message}")
            }
        }
    }
}
