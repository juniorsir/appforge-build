package com.kavach.ui.theme

import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)

// Crisp Light Mode Palette (Instagram / Apple iOS Clean Light Aesthetic)
val CrispBg = Color(0xFFF5F7FA)
val CrispSurface = Color(0xFFFFFFFF)
val CrispSurfaceSubtle = Color(0xFFF1F5F9)
val CrispSurfaceElevated = Color(0xFFFFFFFF)
val CrispBorder = Color(0xFFE2E8F0)
val CrispHairline = Color(0xFFE5E7EB)

val CrispInkPrimary = Color(0xFF0F172A)
val CrispInkSecondary = Color(0xFF475569)
val CrispInkMuted = Color(0xFF94A3B8)

val CrispBlue = Color(0xFF0095F6)
val CrispBlueDark = Color(0xFF0284C7)
val CrispIndigo = Color(0xFF4F46E5)
val CrispEmerald = Color(0xFF16A34A)
val CrispAmber = Color(0xFFD97706)
val CrispRose = Color(0xFFE11D48)

// Legacy aliases mapped cleanly to Crisp Light Mode so all modules stay cohesive
val ObsidianBg = CrispBg
val ObsidianSurface = CrispSurface
val ObsidianSurfaceVariant = CrispSurfaceSubtle
val ObsidianSurfaceElevated = CrispSurfaceElevated

val NeonCyan = CrispBlue
val NeonCyanBright = CrispBlue
val ElectricViolet = CrispIndigo
val ElectricPurple = CrispIndigo
val NeonEmerald = CrispEmerald
val NeonAmber = CrispAmber
val NeonRose = CrispRose

// Primary Semantic Palette Tokens
val HighDensityBackground = CrispBg
val HighDensitySurface = CrispSurface
val HighDensitySurfaceVariant = CrispSurfaceSubtle
val HighDensityPrimary = CrispBlue
val HighDensityOnPrimary = Color(0xFFFFFFFF)
val HighDensitySecondary = CrispSurfaceSubtle
val HighDensityOnSecondary = CrispInkPrimary
val HighDensityTertiary = CrispIndigo
val HighDensityOnBackground = CrispInkPrimary
val HighDensityOnSurface = CrispInkPrimary
val HighDensityOnSurfaceVariant = CrispInkSecondary
val HighDensityOutline = CrispBorder

// Alert & status colors (clean light tinted chips)
val CrimsonBg = Color(0xFFFFF1F2)
val CrimsonBorder = Color(0xFFFECDD3)
val CrimsonText = Color(0xFFBE123C)
val CrimsonIndicator = CrispRose

// Active/success mint colors
val MintIndicator = CrispEmerald
val MintBg = Color(0xFFECFDF5)
val MintBorder = Color(0xFFA7F3D0)
val MintText = Color(0xFF15803D)
