package com.kavach.ui.theme

import android.os.Build
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val CrispLightColorScheme = lightColorScheme(
    primary = CrispBlue,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFE0F2FE),
    onPrimaryContainer = Color(0xFF0C4A6E),
    secondary = CrispSurfaceSubtle,
    onSecondary = CrispInkPrimary,
    secondaryContainer = Color(0xFFE2E8F0),
    onSecondaryContainer = CrispInkPrimary,
    tertiary = CrispIndigo,
    onTertiary = Color.White,
    background = CrispBg,
    onBackground = CrispInkPrimary,
    surface = CrispSurface,
    onSurface = CrispInkPrimary,
    surfaceVariant = CrispSurfaceSubtle,
    onSurfaceVariant = CrispInkSecondary,
    outline = CrispBorder,
    outlineVariant = CrispHairline,
    error = CrispRose,
    onError = Color.White
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = false,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit,
) {
    val colorScheme =
        when {
            dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
                val context = LocalContext.current
                dynamicLightColorScheme(context)
            }
            else -> CrispLightColorScheme
        }

    MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
