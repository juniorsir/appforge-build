package com.kavach

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.kavach.presentation.dashboard.DashboardScreen
import com.kavach.presentation.dashboard.DashboardViewModel
import com.kavach.ui.security.FaceDeviceAuthDialog
import com.kavach.ui.theme.MyApplicationTheme

/**
 * Main Activity hosting the single-screen AeroShare Device Bridge & Command Console.
 */
class MainActivity : ComponentActivity() {
    private val requestMultiplePermissionsLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        permissions.entries.forEach {
            android.util.Log.d("MainActivity", "Permission ${it.key} granted: ${it.value}")
        }
    }

    private val vpnConsentLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            com.kavach.services.AeroNetworkModeratorVpnService.startServiceDirect(applicationContext)
        } else {
            // Even if VPN tunnel dialog was dismissed, keep the in-app DNS moderation engine active
            com.kavach.services.AeroNetworkModeratorVpnService.networkModerationManager?.setVpnActive(true)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        handleAuthIntent(intent)
        handleVpnPrepareIntent(intent)

        val candidatePermissions = mutableListOf(
            android.Manifest.permission.CAMERA,
            android.Manifest.permission.RECORD_AUDIO,
            android.Manifest.permission.ACCESS_FINE_LOCATION,
            android.Manifest.permission.ACCESS_COARSE_LOCATION
        )
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
            candidatePermissions.add(android.Manifest.permission.POST_NOTIFICATIONS)
        }
        val missingPermissions = candidatePermissions.filter { perm ->
            androidx.core.content.ContextCompat.checkSelfPermission(
                this,
                perm
            ) != android.content.pm.PackageManager.PERMISSION_GRANTED
        }
        if (missingPermissions.isNotEmpty()) {
            try {
                requestMultiplePermissionsLauncher.launch(missingPermissions.toTypedArray())
            } catch (t: Throwable) {
                android.util.Log.w("MainActivity", "Failed launching runtime permission prompt", t)
            }
        }

        enableEdgeToEdge(
            statusBarStyle = androidx.activity.SystemBarStyle.light(
                android.graphics.Color.TRANSPARENT,
                android.graphics.Color.TRANSPARENT
            ),
            navigationBarStyle = androidx.activity.SystemBarStyle.light(
                android.graphics.Color.TRANSPARENT,
                android.graphics.Color.TRANSPARENT
            )
        )

        try {
            com.kavach.services.RealtimeConnectionService.connect(applicationContext)
        } catch (e: Throwable) {
            android.util.Log.w("MainActivity", "Failed starting RealtimeConnectionService", e)
        }

        setContent {
            MyApplicationTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    val appContainer = (applicationContext as? BaseApplication)?.container
                    val pendingPairRequest = appContainer?.securityShield?.latestPendingPairRequest?.collectAsStateWithLifecycle()?.value

                    if (pendingPairRequest != null && appContainer != null) {
                        FaceDeviceAuthDialog(
                            request = pendingPairRequest,
                            onAuthorize = { reqId ->
                                appContainer.securityShield.approvePendingPairRequest(reqId)
                            },
                            onDeny = { reqId ->
                                appContainer.securityShield.denyPendingPairRequest(reqId)
                            },
                            onDismiss = {
                                appContainer.securityShield.dismissPendingPairRequest()
                            }
                        )
                    }

                    val dashboardViewModel: DashboardViewModel = viewModel(
                        factory = DashboardViewModel.Factory
                    )
                    val timelineViewModel: com.kavach.presentation.timeline.TimelineViewModel = viewModel(
                        factory = com.kavach.presentation.timeline.TimelineViewModel.Factory
                    )
                    var showTimelineScreen by rememberSaveable {
                        mutableStateOf(false)
                    }

                    if (showTimelineScreen) {
                        com.kavach.presentation.timeline.TimelineScreen(
                            viewModel = timelineViewModel,
                            onNavigateBack = { showTimelineScreen = false }
                        )
                    } else {
                        DashboardScreen(
                            onNavigateToTimeline = { showTimelineScreen = true },
                            viewModel = dashboardViewModel
                        )
                    }
                }
            }
        }
    }

    override fun onNewIntent(intent: android.content.Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleAuthIntent(intent)
        handleVpnPrepareIntent(intent)
    }

    private fun handleAuthIntent(intent: android.content.Intent?) {
        val reqId = intent?.getStringExtra("AUTH_REQUEST_ID") ?: return
        val appContainer = (applicationContext as? BaseApplication)?.container ?: return
        val req = appContainer.securityShield.getPendingPairRequest(reqId)
        if (req != null) {
            appContainer.securityShield.showPendingPairRequest(req)
        }
    }

    private fun handleVpnPrepareIntent(intent: android.content.Intent?) {
        if (intent?.action != com.kavach.services.AeroNetworkModeratorVpnService.ACTION_PREPARE_VPN) return
        try {
            val prep = android.net.VpnService.prepare(this)
            if (prep != null) {
                vpnConsentLauncher.launch(prep)
            } else {
                com.kavach.services.AeroNetworkModeratorVpnService.startServiceDirect(applicationContext)
            }
        } catch (e: Throwable) {
            android.util.Log.w("MainActivity", "Failed launching VPN consent dialog", e)
        }
    }
}
