package com.kavach.tools.repository

import com.kavach.tools.plugins.Plugin
import kotlinx.coroutines.flow.Flow

interface PluginRegistryRepository {
    fun getPlugins(): Flow<List<Plugin>>
    suspend fun registerPlugin(plugin: Plugin): Boolean
    suspend fun unregisterPlugin(pluginId: String): Boolean
    suspend fun getPluginById(pluginId: String): Plugin?
}
