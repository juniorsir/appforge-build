package com.kavach.security

import android.accessibilityservice.AccessibilityService
import android.app.DownloadManager
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.database.Cursor
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.FileObserver
import android.os.Handler
import android.os.Looper
import android.util.Base64
import android.util.Log
import android.widget.Toast
import com.kavach.accessibility.AccessibilityServiceRegistry
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.URLDecoder
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ConcurrentLinkedDeque
import java.util.concurrent.atomic.AtomicBoolean
import java.util.zip.ZipFile

data class AdultShieldPolicyUi(
    val strictModeEnabled: Boolean = true,
    val blockWebAndVideo: Boolean = true,
    val blockReadingAndManga: Boolean = true,
    val blockAdultSearches: Boolean = true,
    val blockAdultAppsAndApks: Boolean = true,
    val quarantineDownloads: Boolean = true,
    val forceSafeSearchDns: Boolean = true,
    val blockBypassVpns: Boolean = true,
    val blockIncognitoTabs: Boolean = true,
    val blockSettingsTampering: Boolean = true,
    val blockClipboardAndNotifs: Boolean = true,
    val adminLockEnabled: Boolean = true,
    val hasCustomPin: Boolean = false,
    val totalBlockedEvents: Long = 0L,
    val webVideoBlockedCount: Long = 0L,
    val readingMangaBlockedCount: Long = 0L,
    val searchBlockedCount: Long = 0L,
    val appApkBlockedCount: Long = 0L,
    val bypassBlockedCount: Long = 0L,
    val quarantinedFilesCount: Int = 0,
    val lastViolationTarget: String = "",
    val lastViolationChannel: String = "",
    val lastViolationTimeMs: Long = 0L
)

data class AdultShieldViolationEvent(
    val id: String,
    val timestampMs: Long,
    val channel: String, // WEB_VIDEO, READING_MANGA, SEARCH_QUERY, APP_APK, BYPASS_ATTEMPT, INCOGNITO_BLOCKED, TAMPER_ATTEMPT, CLIPBOARD_GUARD, QUARANTINE
    val target: String,
    val packageName: String,
    val reason: String,
    val actionTaken: String
) {
    val formattedTime: String
        get() = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date(timestampMs))

    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("timestampMs", timestampMs)
        put("formattedTime", formattedTime)
        put("channel", channel)
        put("target", target)
        put("packageName", packageName)
        put("reason", reason)
        put("actionTaken", actionTaken)
    }
}

data class QuarantinedFileEntry(
    val id: String,
    val originalFileName: String,
    val originalPath: String,
    val quarantinePath: String,
    val fileSizeBytes: Long,
    val channel: String,
    val reason: String,
    val packageName: String = "",
    val timestampMs: Long = System.currentTimeMillis()
) {
    val formattedTime: String
        get() = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date(timestampMs))

    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("originalFileName", originalFileName)
        put("originalPath", originalPath)
        put("quarantinePath", quarantinePath)
        put("fileSizeBytes", fileSizeBytes)
        put("channel", channel)
        put("reason", reason)
        put("packageName", packageName)
        put("timestampMs", timestampMs)
        put("formattedTime", formattedTime)
    }
}

data class ShieldVerdict(
    val blocked: Boolean,
    val channel: String = "",
    val target: String = "",
    val reason: String = "",
    val confidence: Int = 0
)

/**
 * Multi-Channel Adult Content Shield & Anti-Bypass Engine:
 *  1. Adult Sites, Video Streams, Cam Sites, Adult AI Generators & Image Boards
 *  2. Adult Reading, Erotica, NSFW Stories, 18+ Manga/Doujinshi/Manhwa & Forums
 *  3. Adult App Downloads, Sideloaded APKs, Disguised ZIP/CBZ Archives, Store Pages & File Quarantine
 *  4. Adult Search Queries (including Leetspeak & Zero-Width Obfuscated Queries) across Browsers & Apps
 *  5. Anti-Bypass & Anti-Tamper Protections:
 *     - Force SafeSearch VIP DNS (Google 216.239.38.120, YouTube Restricted 216.239.38.120, Bing Strict 204.79.197.220, DuckDuckGo Safe 52.142.124.215)
 *       + CleanBrowsing Family DNS (185.228.168.168 / 185.228.169.168) + Cloudflare Family (1.1.1.3)
 *     - Incognito / Private / Tor / Secret Browsing Tab Blocker
 *     - System Settings Anti-Tamper Guard (prevents disabling Aero VPN, Accessibility Service, or Force-Stopping the Shield)
 *     - Clipboard & Notification Adult Link / Magnet URI Scrubber
 *     - Unauthorized VPN/Proxy/DNS-over-HTTPS Bypass App Blocker
 *     - Biometric / PIN Admin Lock with temporary maintenance unlock window
 */
class AdultContentShieldManager(
    private val context: Context
) {
    companion object {
        private const val TAG = "AdultContentShield"
        private const val PREFS_NAME = "aero_adult_content_shield_prefs"
        private const val MAX_VIOLATION_HISTORY = 100
        private const val MAX_QUARANTINE_ENTRIES = 80
        private const val DEFAULT_ADMIN_PIN = "1234"

        @Volatile
        var activeInstance: AdultContentShieldManager? = null
            private set

        // Google SafeSearch & YouTube Restricted Mode VIP: forcesafesearch.google.com / restrict.youtube.com -> 216.239.38.120
        val GOOGLE_SAFESEARCH_VIP = byteArrayOf(216.toByte(), 239.toByte(), 38, 120)
        // Bing Strict SafeSearch VIP: strict.bing.com -> 204.79.197.220
        val BING_SAFESEARCH_VIP = byteArrayOf(204.toByte(), 79, 197.toByte(), 220.toByte())
        // DuckDuckGo SafeSearch VIP: safe.duckduckgo.com -> 52.142.124.215
        val DUCKDUCKGO_SAFESEARCH_VIP = byteArrayOf(52, 142.toByte(), 124, 215.toByte())
        // CleanBrowsing Family Filter DNS IPv4s: 185.228.168.168 & 185.228.169.168
        val CLEANBROWSING_FAMILY_PRIMARY = byteArrayOf(185.toByte(), 228.toByte(), 168.toByte(), 168.toByte())
        val CLEANBROWSING_FAMILY_SECONDARY = byteArrayOf(185.toByte(), 228.toByte(), 169.toByte(), 168.toByte())

        // Pre-compiled Regex instances for zero-allocation hot paths
        private val GOOGLE_CC_TLD_REGEX = Regex("^(www\\.)?google\\.(com|[a-z]{2}|co\\.[a-z]{2}|com\\.[a-z]{2})$")
        private val NSFW_SUBREDDIT_REGEX = Regex("/r/(nsfw|gonewild|hentai|rule34|porn|sexstories|erotica|realgirls|cumsluts|milf|ecchi|doujinshi|nsfw_gif|asiansgonewild|indiansgonewild| dirtyr4r|sluttyconfessions|nsfw_videos|jav|manhwa18)\\b")
        private val ZERO_WIDTH_REGEX = Regex("[\\u200B-\\u200F\\u202A-\\u202E\\u2060\\uFEFF]")
        private val QUERY_SEPARATOR_REGEX = Regex("[+_\\-%20]+")
        private val SAFE_FILENAME_CHARS_REGEX = Regex("[^a-zA-Z0-9._-]")
        private val BASE64_URL_CANDIDATE_REGEX = Regex("\\b(aHR0cHM6Ly9[A-Za-z0-9+/=]{12,200}|aHR0cDovL[A-Za-z0-9+/=]{12,200})\\b")

        // Safe words that contain substrings like "sex", "ass", "cum", "anal", "tit", "cock" (Scunthorpe protection)
        val SAFE_SUBSTRING_ALLOWLIST = setOf(
            "essex", "sussex", "middlesex", "wessex", "unisex", "sexton", "sextant", "bissextile",
            "analytics", "analysis", "analyze", "analyzer", "analog", "analogy", "canal", "banal", "arsenal", "artisanal",
            "document", "documentation", "circum", "accumulate", "cumulative", "encumber", "cucumber", "succumb", "incumbent",
            "associate", "assistant", "assembly", "assert", "assign", "assume", "assure", "asset", "assess", "assessment",
            "classic", "classify", "classroom", "passage", "passenger", "massive", "massage", "embassy", "compass", "chassis",
            "title", "subtitle", "entitle", "institute", "constitution", "substitute", "attitude", "latitude", "altitude", "gratitude", "multitude",
            "cockpit", "peacock", "hancock", "babcock", "hitchcock", "weathercock", "shuttlecock", "cockatoo", "woodcock",
            "scunthorpe", "penistone", "dickinson", "dickens", "therapist", "shitake", "shiitake", "mansfield", "grapefruit", "drape", "scrape"
        )

        // Adult Web Video, Tube, Cam, Undress AI & Deepfake Domains/Stems
        val ADULT_WEB_VIDEO_AND_AI_STEMS = setOf(
            "pornhub", "xvideos", "xnxx", "xhamster", "redtube", "youporn", "spankbang",
            "eporner", "hqporner", "beeg", "tnaflix", "tube8", "thumbzilla", "motherless",
            "heavy-r", "daftsex", "sxyprn", "txxx", "vjav", "javhd", "missav", "jable",
            "supjav", "chaturbate", "stripchat", "bongacams", "livejasmin", "myfreecams",
            "camsoda", "cam4", "flirt4free", "imlive", "streamate", "onlyfans.com", "fansly.com",
            "fapello", "coomer.su", "kemono.su", "simpcity", "thothub", "erome", "redgifs",
            "brazzers", "realitykings", "bangbros", "naughtyamerica", "vixen.com", "tushy.com",
            "blacked.com", "deeper.com", "teamSkeet", "evilangel", "kink.com", "adulttime",
            "undress.ai", "deepnude", "clothoff", "nudify", "soulgen.net", "promptchan.ai",
            "pornx.ai", "pornpen.ai", "seduced.ai", "sukebei.nyaa", "empornium", "pornolab", "pornleech"
        )

        // Adult Reading, Erotica, Manga, Doujinshi, Manhwa, Visual Novel, NSFW AI Chat & Forum Domains/Stems
        val ADULT_READING_AND_MANGA_STEMS = setOf(
            "literotica", "lushstories", "sexstories", "xnxxstories", "indiansexstories",
            "nifty.org", "asstr.org", "adult-fanfiction", "eroticstories", "storiesonline",
            "bdsmlibrary", "mcstories", "chyoa", "hentai-foundry", "furaffinity", "e621",
            "nhentai", "hitomi.la", "e-hentai", "exhentai", "ehviewer", "fakku", "tsumino",
            "pururin", "hentaifox", "imhentai", "simply-hentai", "hentai2read", "hentairead",
            "asmhentai", "3hentai", "9hentai", "hentaiera", "hentaihand", "hentainexus",
            "multporn", "8muses", "allporncomic", "hdporncomics", "myreadingmanga",
            "yaoimangaonline", "mangago", "vyvymanga", "manhwa18", "manhwatop", "manhwahentai",
            "hiperdex", "toonily", "manytoon", "toomics", "lezhhin", "ero-manga", "doujinshi",
            "f95zone", "lewdcorner", "ulmf", "vndb-nsfw", "dlsite", "nutaku", "eroges",
            "ryuugames", "igg-games-adult", "kimochi", "eroge", "itch-nsfw",
            "gelbooru", "danbooru", "rule34", "sankakucomplex", "yande.re", "konachan",
            "realbooru", "xbooru", "tbib.org", "hypnohub", "paheal", "derpibooru-nsfw",
            "r18.pixiv",
            // Adult AI Character Erotica & NSFW Roleplay Chat Platforms
            "crushon.ai", "janitorai", "spicychat.ai", "venus.chub", "chub.ai", "candy.ai",
            "dreamgf.ai", "kupid.ai", "muah.ai"
        )

        // Explicit Adult Search Query Tokens & Phrases
        val EXPLICIT_SEARCH_PHRASES = mapOf(
            "porn" to 90,
            "porno" to 90,
            "pornography" to 95,
            "xxx" to 90,
            "xvideos" to 100,
            "pornhub" to 100,
            "xnxx" to 100,
            "xhamster" to 100,
            "redtube" to 100,
            "youporn" to 100,
            "spankbang" to 100,
            "onlyfans leak" to 100,
            "onlyfans nude" to 100,
            "fapello" to 95,
            "erome" to 95,
            "redgifs" to 95,
            "chaturbate" to 100,
            "stripchat" to 100,
            "livejasmin" to 100,
            "bongacams" to 100,
            "brazzers" to 100,
            "naughtyamerica" to 100,
            "hentai" to 90,
            "nhentai" to 100,
            "rule34" to 95,
            "rule 34" to 95,
            "e-hentai" to 100,
            "hitomi.la" to 100,
            "doujinshi 18" to 90,
            "uncensored hentai" to 100,
            "adult manhwa" to 90,
            "18+ manhwa" to 90,
            "manhwa18" to 95,
            "literotica" to 100,
            "erotic stories" to 90,
            "sex stories" to 95,
            "incest stories" to 100,
            "taboo sex stories" to 100,
            "nsfw stories" to 85,
            "smut fanfic" to 85,
            "lemon fanfic" to 80,
            "sex videos" to 95,
            "free sex videos" to 100,
            "hd sex video" to 95,
            "nude videos" to 90,
            "naked girls" to 90,
            "naked women" to 90,
            "nude girls" to 90,
            "leaked nudes" to 95,
            "celebs nude" to 95,
            "camgirl" to 90,
            "live sex cam" to 100,
            "blowjob" to 95,
            "handjob" to 95,
            "footjob" to 95,
            "cumshot" to 100,
            "creampie" to 95,
            "gangbang" to 100,
            "deepthroat" to 95,
            "doggystyle" to 95,
            "anal sex" to 95,
            "lesbian porn" to 100,
            "gay porn" to 100,
            "milf porn" to 100,
            "teen porn" to 100,
            "jav uncensored" to 100,
            "jav hd" to 95,
            "missav" to 100,
            "f95zone" to 95,
            "nutaku" to 95,
            "adult apk" to 95,
            "porn apk" to 100,
            "hentai apk" to 100,
            "18+ game apk" to 95,
            "eroge apk" to 95,
            "undress ai" to 95,
            "deepnude" to 100,
            "nudify ai" to 95,
            "nsfw ai chat" to 90
        )

        // On-Screen Adult Story / Fiction / Manga / Age-Gate Indicators (weighted)
        val ON_SCREEN_READING_INDICATORS = mapOf(
            "archive warning: explicit" to 65,
            "rating: explicit" to 65,
            "18+ adult fiction" to 80,
            "erotic fiction" to 75,
            "adult story archive" to 80,
            "literotica.com" to 100,
            "lushstories" to 95,
            "nhentai.net" to 100,
            "hitomi.la" to 100,
            "e-hentai.org" to 100,
            "f95zone.to" to 100,
            "manhwa18" to 95,
            "uncensored hentai" to 90,
            "doujinshi 18+" to 85,
            "mature content: 18+" to 70,
            "this work contains explicit sexual" to 90,
            "warning: 18+ only" to 75,
            "you must be 18 years or older" to 65,
            "confirm you are over 18" to 65,
            "nsfw 18+" to 70,
            "explicit sexual content" to 80,
            "non-consensual sexual" to 85,
            "rta-5042-1996-1400-1577-rta" to 100,
            "18 u.s.c. 2257" to 95
        )

        // Incognito / Private Browsing / Secret Mode UI Markers
        val INCOGNITO_SCREEN_MARKERS = listOf(
            "you've gone incognito",
            "you have gone incognito",
            "new incognito tab",
            "close all incognito tabs",
            "incognito mode",
            "private browsing",
            "you are in a private window",
            "new private tab",
            "inprivate browsing",
            "you've gone inprivate",
            "secret mode",
            "private tab with tor"
        )

        // Known Adult App Package Tokens & Labels
        val ADULT_PACKAGE_AND_APK_TOKENS = setOf(
            "pornhub", "xvideos", "xnxx", "xhamster", "redtube", "youporn", "spankbang",
            "stripchat", "chaturbate", "bongacams", "livejasmin", "camsoda", "cam4",
            "onlyfans", "fansly", "nhentai", "ehviewer", "exhentai", "hitomi", "fakku",
            "hentai", "hanime", "rule34", "booru", "gelbooru", "danbooru", "nutaku",
            "f95zone", "eroge", "dlsite", "literotica", "sexstories", "manhwa18",
            "porn", "xxx", "erotic", "nsfw", "javhd", "missav", "brazzers", "adulttime",
            "crushon", "spicychat", "janitorai", "deepnude", "undress"
        )

        // Known VPN / Proxy / Tor / DoH Bypass Apps (excluding our own package & Termux)
        val BYPASS_VPN_AND_DNS_PACKAGES = setOf(
            "com.psiphon3",
            "com.psiphon3.subscription",
            "org.getlantern.lantern",
            "com.fast.free.unblock.thunder.vpn",
            "free.vpn.unblock.proxy.turbovpn",
            "free.vpn.unblock.proxy.vpn.master.pro",
            "ch.protonvpn.android",
            "com.windscribe.vpn",
            "com.nordvpn.android",
            "com.expressvpn.vpn",
            "com.surfshark.vpnclient.android",
            "com.ixolit.ipvanish",
            "com.cyberghostvpn.android",
            "com.mullvad.mullvadvpn",
            "org.torproject.android",
            "org.torproject.torbrowser",
            "org.torproject.torbrowser_alpha",
            "app.intra",
            "com.celzero.bravedns", // RethinkDNS
            "com.cloudflare.onedotonedotonedotone", // 1.1.1.1 WARP
            "com.adguard.android",
            "com.nextdns.app",
            "com.tailscale.ipn",
            "com.wireguard.android",
            "de.blinkt.openvpn",
            "net.openvpn.openvpn",
            "com.v2ray.ang",
            "io.nekohasekai.sagernet",
            "moe.nb4a"
        )
    }

    private val prefs: SharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    private val mainHandler = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(
        SupervisorJob() + Dispatchers.IO + CoroutineExceptionHandler { _, _ -> }
    )

    private val violationHistory = ConcurrentLinkedDeque<AdultShieldViolationEvent>()
    private val quarantinedFiles = ConcurrentLinkedDeque<QuarantinedFileEntry>()
    private val recentEnforcementDedup = ConcurrentHashMap<String, Long>()
    private val scannedSafeFilesCache = ConcurrentHashMap<String, Long>() // filePath -> lastModified
    private val boundedRegexCache = ConcurrentHashMap<String, Regex>()
    private val isScanningDownloads = AtomicBoolean(false)
    private val downloadObservers = mutableListOf<FileObserver>()

    private val quarantineDir: File by lazy {
        File(context.filesDir, "adult_quarantine").apply {
            if (!exists()) mkdirs()
        }
    }

    @Volatile var strictModeEnabled: Boolean = true
        private set
    @Volatile var blockWebAndVideo: Boolean = true
        private set
    @Volatile var blockReadingAndManga: Boolean = true
        private set
    @Volatile var blockAdultSearches: Boolean = true
        private set
    @Volatile var blockAdultAppsAndApks: Boolean = true
        private set
    @Volatile var quarantineDownloads: Boolean = true
        private set
    @Volatile var forceSafeSearchDns: Boolean = true
        private set
    @Volatile var blockBypassVpns: Boolean = true
        private set
    @Volatile var blockIncognitoTabs: Boolean = true
        private set
    @Volatile var blockSettingsTampering: Boolean = true
        private set
    @Volatile var blockClipboardAndNotifs: Boolean = true
        private set
    @Volatile var adminLockEnabled: Boolean = true
        private set
    @Volatile private var adminPinHash: String = ""
    @Volatile private var adminUnlockedUntilMs: Long = 0L

    @Volatile private var totalBlockedEvents: Long = 0L
    @Volatile private var webVideoBlockedCount: Long = 0L
    @Volatile private var readingMangaBlockedCount: Long = 0L
    @Volatile private var searchBlockedCount: Long = 0L
    @Volatile private var appApkBlockedCount: Long = 0L
    @Volatile private var bypassBlockedCount: Long = 0L
    @Volatile private var lastViolationTarget: String = ""
    @Volatile private var lastViolationChannel: String = ""
    @Volatile private var lastViolationTimeMs: Long = 0L

    private val _policyState = MutableStateFlow(AdultShieldPolicyUi())
    val policyState: StateFlow<AdultShieldPolicyUi> = _policyState.asStateFlow()

    private val downloadCompleteReceiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context?, intent: Intent?) {
            if (intent?.action != DownloadManager.ACTION_DOWNLOAD_COMPLETE) return
            val downloadId = intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1L)
            scope.launch {
                inspectCompletedDownloadId(downloadId)
                scanAndQuarantineDownloads()
            }
        }
    }

    init {
        activeInstance = this
        loadPersistedState()
        registerDownloadCompleteReceiver()
        startDownloadDirectoryFileObservers()
        updatePolicyFlow()
        scope.launch {
            scanAndQuarantineDownloads()
        }
    }

    private fun loadPersistedState() {
        strictModeEnabled = prefs.getBoolean("strict_mode_enabled", true)
        blockWebAndVideo = prefs.getBoolean("block_web_video", true)
        blockReadingAndManga = prefs.getBoolean("block_reading_manga", true)
        blockAdultSearches = prefs.getBoolean("block_adult_searches", true)
        blockAdultAppsAndApks = prefs.getBoolean("block_adult_apps_apks", true)
        quarantineDownloads = prefs.getBoolean("quarantine_downloads", true)
        forceSafeSearchDns = prefs.getBoolean("force_safesearch_dns", true)
        blockBypassVpns = prefs.getBoolean("block_bypass_vpns", true)
        blockIncognitoTabs = prefs.getBoolean("block_incognito_tabs", true)
        blockSettingsTampering = prefs.getBoolean("block_settings_tampering", true)
        blockClipboardAndNotifs = prefs.getBoolean("block_clipboard_notifs", true)
        adminLockEnabled = prefs.getBoolean("admin_lock_enabled", true)
        adminPinHash = prefs.getString("admin_pin_hash", "").orEmpty()

        totalBlockedEvents = prefs.getLong("total_blocked_events", 0L)
        webVideoBlockedCount = prefs.getLong("web_video_blocked", 0L)
        readingMangaBlockedCount = prefs.getLong("reading_manga_blocked", 0L)
        searchBlockedCount = prefs.getLong("search_blocked", 0L)
        appApkBlockedCount = prefs.getLong("app_apk_blocked", 0L)
        bypassBlockedCount = prefs.getLong("bypass_blocked", 0L)
        lastViolationTarget = prefs.getString("last_violation_target", "").orEmpty()
        lastViolationChannel = prefs.getString("last_violation_channel", "").orEmpty()
        lastViolationTimeMs = prefs.getLong("last_violation_time_ms", 0L)

        try {
            val rawViolations = prefs.getString("violation_history_json", "[]").orEmpty()
            val arr = JSONArray(rawViolations)
            for (i in 0 until arr.length()) {
                val obj = arr.optJSONObject(i) ?: continue
                violationHistory.addLast(
                    AdultShieldViolationEvent(
                        id = obj.optString("id", "v_$i"),
                        timestampMs = obj.optLong("timestampMs", 0L),
                        channel = obj.optString("channel", "WEB_VIDEO"),
                        target = obj.optString("target", ""),
                        packageName = obj.optString("packageName", ""),
                        reason = obj.optString("reason", ""),
                        actionTaken = obj.optString("actionTaken", "")
                    )
                )
            }
        } catch (_: Throwable) {}

        try {
            val rawQuarantine = prefs.getString("quarantine_history_json", "[]").orEmpty()
            val arr = JSONArray(rawQuarantine)
            for (i in 0 until arr.length()) {
                val obj = arr.optJSONObject(i) ?: continue
                quarantinedFiles.addLast(
                    QuarantinedFileEntry(
                        id = obj.optString("id", "q_$i"),
                        originalFileName = obj.optString("originalFileName", ""),
                        originalPath = obj.optString("originalPath", ""),
                        quarantinePath = obj.optString("quarantinePath", ""),
                        fileSizeBytes = obj.optLong("fileSizeBytes", 0L),
                        channel = obj.optString("channel", "APP_APK"),
                        reason = obj.optString("reason", ""),
                        packageName = obj.optString("packageName", ""),
                        timestampMs = obj.optLong("timestampMs", 0L)
                    )
                )
            }
        } catch (_: Throwable) {}
    }

    private fun savePersistedState() {
        try {
            val vArr = JSONArray()
            violationHistory.toList().takeLast(MAX_VIOLATION_HISTORY).forEach { vArr.put(it.toJson()) }
            val qArr = JSONArray()
            quarantinedFiles.toList().takeLast(MAX_QUARANTINE_ENTRIES).forEach { qArr.put(it.toJson()) }

            prefs.edit()
                .putBoolean("strict_mode_enabled", strictModeEnabled)
                .putBoolean("block_web_video", blockWebAndVideo)
                .putBoolean("block_reading_manga", blockReadingAndManga)
                .putBoolean("block_adult_searches", blockAdultSearches)
                .putBoolean("block_adult_apps_apks", blockAdultAppsAndApks)
                .putBoolean("quarantine_downloads", quarantineDownloads)
                .putBoolean("force_safesearch_dns", forceSafeSearchDns)
                .putBoolean("block_bypass_vpns", blockBypassVpns)
                .putBoolean("block_incognito_tabs", blockIncognitoTabs)
                .putBoolean("block_settings_tampering", blockSettingsTampering)
                .putBoolean("block_clipboard_notifs", blockClipboardAndNotifs)
                .putBoolean("admin_lock_enabled", adminLockEnabled)
                .putString("admin_pin_hash", adminPinHash)
                .putLong("total_blocked_events", totalBlockedEvents)
                .putLong("web_video_blocked", webVideoBlockedCount)
                .putLong("reading_manga_blocked", readingMangaBlockedCount)
                .putLong("search_blocked", searchBlockedCount)
                .putLong("app_apk_blocked", appApkBlockedCount)
                .putLong("bypass_blocked", bypassBlockedCount)
                .putString("last_violation_target", lastViolationTarget)
                .putString("last_violation_channel", lastViolationChannel)
                .putLong("last_violation_time_ms", lastViolationTimeMs)
                .putString("violation_history_json", vArr.toString())
                .putString("quarantine_history_json", qArr.toString())
                .apply()
        } catch (_: Throwable) {}
    }

    private fun updatePolicyFlow() {
        _policyState.value = AdultShieldPolicyUi(
            strictModeEnabled = strictModeEnabled,
            blockWebAndVideo = blockWebAndVideo,
            blockReadingAndManga = blockReadingAndManga,
            blockAdultSearches = blockAdultSearches,
            blockAdultAppsAndApks = blockAdultAppsAndApks,
            quarantineDownloads = quarantineDownloads,
            forceSafeSearchDns = forceSafeSearchDns,
            blockBypassVpns = blockBypassVpns,
            blockIncognitoTabs = blockIncognitoTabs,
            blockSettingsTampering = blockSettingsTampering,
            blockClipboardAndNotifs = blockClipboardAndNotifs,
            adminLockEnabled = adminLockEnabled,
            hasCustomPin = adminPinHash.isNotEmpty(),
            totalBlockedEvents = totalBlockedEvents,
            webVideoBlockedCount = webVideoBlockedCount,
            readingMangaBlockedCount = readingMangaBlockedCount,
            searchBlockedCount = searchBlockedCount,
            appApkBlockedCount = appApkBlockedCount,
            bypassBlockedCount = bypassBlockedCount,
            quarantinedFilesCount = quarantinedFiles.size,
            lastViolationTarget = lastViolationTarget,
            lastViolationChannel = lastViolationChannel,
            lastViolationTimeMs = lastViolationTimeMs
        )
    }

    private fun registerDownloadCompleteReceiver() {
        try {
            val filter = IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                context.registerReceiver(downloadCompleteReceiver, filter, Context.RECEIVER_EXPORTED)
            } else {
                context.registerReceiver(downloadCompleteReceiver, filter)
            }
        } catch (e: Throwable) {
            Log.w(TAG, "DownloadReceiver registration warning: ${e.message}")
        }
    }

    /**
     * Real-time FileObserver on public & app Download folders so direct browser/Telegram/APK downloads
     * that bypass Android's DownloadManager are inspected immediately upon file write completion.
     */
    private fun startDownloadDirectoryFileObservers() {
        try {
            val dirs = mutableListOf<File>()
            val pubDl = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            if (pubDl != null && pubDl.exists()) {
                dirs.add(pubDl)
                val aeroDl = File(pubDl, "AeroShare")
                if (aeroDl.exists()) dirs.add(aeroDl)
            }
            context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)?.let {
                if (it.exists()) dirs.add(it)
            }
            for (dir in dirs) {
                val mask = FileObserver.CLOSE_WRITE or FileObserver.MOVED_TO
                @Suppress("DEPRECATION")
                val obs = object : FileObserver(dir.absolutePath, mask) {
                    override fun onEvent(event: Int, path: String?) {
                        if (path.isNullOrBlank() || path.endsWith(".crdownload") || path.endsWith(".part") || path.endsWith(".tmp")) return
                        val targetFile = File(dir, path)
                        scope.launch {
                            try {
                                if (targetFile.exists() && targetFile.isFile) {
                                    val verdict = inspectFileForAdultOrBypassContent(targetFile)
                                    if (verdict.blocked) {
                                        if (quarantineDownloads) {
                                            quarantineFile(targetFile, verdict.reason, verdict.channel, "file_observer")
                                        } else {
                                            enforceViolation(verdict, packageName = "file_observer", kickHome = false)
                                        }
                                    }
                                }
                            } catch (_: Throwable) {}
                        }
                    }
                }
                obs.startWatching()
                downloadObservers.add(obs)
            }
        } catch (t: Throwable) {
            Log.w(TAG, "FileObserver setup skipped: ${t.message}")
        }
    }

    fun trimCaches(aggressive: Boolean = false) {
        if (aggressive) {
            recentEnforcementDedup.clear()
            scannedSafeFilesCache.clear()
            boundedRegexCache.clear()
            while (violationHistory.size > 50) {
                violationHistory.pollFirst()
            }
            return
        }
        val now = System.currentTimeMillis()
        if (recentEnforcementDedup.size > 120) {
            recentEnforcementDedup.entries.removeIf { (now - it.value) > 30_000L }
        }
        if (scannedSafeFilesCache.size > 200) {
            scannedSafeFilesCache.clear()
        }
        if (boundedRegexCache.size > 150) {
            boundedRegexCache.clear()
        }
    }

    // =========================================================================
    // Admin Lock, PIN / Biometric Verification & Temporary Maintenance Window
    // =========================================================================

    private fun sha256Hex(input: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(input.trim().toByteArray(Charsets.UTF_8))
        return bytes.joinToString("") { "%02x".format(it) }
    }

    fun isAdminSessionTemporarilyUnlocked(): Boolean =
        System.currentTimeMillis() < adminUnlockedUntilMs

    fun verifyAdminPin(pin: String?): Boolean {
        val clean = pin?.trim().orEmpty()
        if (clean.isEmpty()) return false
        val matched = if (adminPinHash.isEmpty()) {
            clean == DEFAULT_ADMIN_PIN
        } else {
            sha256Hex(clean) == adminPinHash
        }
        if (matched) {
            // Grant a 3-minute admin maintenance window so authorized Settings changes aren't blocked
            adminUnlockedUntilMs = System.currentTimeMillis() + 3 * 60_000L
        }
        return matched
    }

    fun unlockAdminSession(pin: String?, durationMinutes: Int = 5, biometricVerified: Boolean = false): JSONObject {
        if (!biometricVerified && !verifyAdminPin(pin)) {
            return JSONObject().put("success", false).put("error", "Invalid Admin PIN")
        }
        val mins = durationMinutes.coerceIn(1, 60)
        adminUnlockedUntilMs = System.currentTimeMillis() + mins * 60_000L
        return JSONObject().apply {
            put("success", true)
            put("action", "ADMIN_SESSION_UNLOCKED")
            put("unlockedForMinutes", mins)
            put("unlockedUntilMs", adminUnlockedUntilMs)
        }
    }

    fun setAdminPin(currentPin: String?, newPin: String, biometricVerified: Boolean = false): JSONObject {
        val cleanNew = newPin.trim()
        if (cleanNew.length < 4) {
            return JSONObject().put("success", false).put("error", "PIN must be at least 4 digits/characters")
        }
        if (adminPinHash.isNotEmpty() && !biometricVerified && !verifyAdminPin(currentPin)) {
            return JSONObject().put("success", false).put("error", "Current Admin PIN is incorrect")
        }
        adminPinHash = sha256Hex(cleanNew)
        adminLockEnabled = true
        savePersistedState()
        updatePolicyFlow()
        return JSONObject().apply {
            put("success", true)
            put("action", "ADMIN_PIN_UPDATED")
            put("adminLockEnabled", adminLockEnabled)
            put("hasCustomPin", true)
        }
    }

    fun updateShieldPolicy(
        strictMode: Boolean? = null,
        webAndVideo: Boolean? = null,
        readingAndManga: Boolean? = null,
        adultSearches: Boolean? = null,
        adultAppsAndApks: Boolean? = null,
        quarantineFiles: Boolean? = null,
        safeSearchDns: Boolean? = null,
        bypassVpns: Boolean? = null,
        incognitoTabs: Boolean? = null,
        settingsTampering: Boolean? = null,
        clipboardAndNotifs: Boolean? = null,
        adminLock: Boolean? = null,
        pin: String? = null,
        biometricVerified: Boolean = false
    ): JSONObject {
        val isWeakening = (strictMode == false && strictModeEnabled) ||
            (webAndVideo == false && blockWebAndVideo) ||
            (readingAndManga == false && blockReadingAndManga) ||
            (adultSearches == false && blockAdultSearches) ||
            (adultAppsAndApks == false && blockAdultAppsAndApks) ||
            (quarantineFiles == false && quarantineDownloads) ||
            (safeSearchDns == false && forceSafeSearchDns) ||
            (bypassVpns == false && blockBypassVpns) ||
            (incognitoTabs == false && blockIncognitoTabs) ||
            (settingsTampering == false && blockSettingsTampering) ||
            (clipboardAndNotifs == false && blockClipboardAndNotifs) ||
            (adminLock == false && adminLockEnabled)

        if (isWeakening && adminLockEnabled && !biometricVerified && !verifyAdminPin(pin)) {
            recordViolation(
                channel = "BYPASS_ATTEMPT",
                target = "Adult Shield Policy Lock",
                packageName = context.packageName,
                reason = "Unauthorized attempt to disable Adult Content Shield without valid Admin PIN or Biometric Auth",
                actionTaken = "DENIED_BY_ADMIN_LOCK"
            )
            return JSONObject().apply {
                put("success", false)
                put("requiresAdminAuth", true)
                put("error", "Admin PIN or Biometric authentication is required to disable or weaken Adult Content Shield protections.")
            }
        }

        strictMode?.let { strictModeEnabled = it }
        webAndVideo?.let { blockWebAndVideo = it }
        readingAndManga?.let { blockReadingAndManga = it }
        adultSearches?.let { blockAdultSearches = it }
        adultAppsAndApks?.let { blockAdultAppsAndApks = it }
        quarantineFiles?.let { quarantineDownloads = it }
        safeSearchDns?.let { forceSafeSearchDns = it }
        bypassVpns?.let { blockBypassVpns = it }
        incognitoTabs?.let { blockIncognitoTabs = it }
        settingsTampering?.let { blockSettingsTampering = it }
        clipboardAndNotifs?.let { blockClipboardAndNotifs = it }
        adminLock?.let { adminLockEnabled = it }

        val netMod = com.kavach.network.NetworkModerationManager.activeInstance
        if (strictModeEnabled && (blockWebAndVideo || blockReadingAndManga)) {
            netMod?.setCategoryEnabled("ADULT", true)
        }
        com.kavach.services.AeroNetworkModeratorVpnService.activeInstance?.reloadVpnInterface()

        savePersistedState()
        updatePolicyFlow()
        return getStatusJson()
    }

    // =========================================================================
    // 1. SafeSearch VIP DNS Resolution Helper (Google / YouTube / Bing / DuckDuckGo)
    // =========================================================================

    /**
     * If forceSafeSearchDns is active, returns the SafeSearch VIP IPv4 address (4 bytes)
     * for Google Search, YouTube Restricted Mode, Bing Strict SafeSearch, or DuckDuckGo SafeSearch.
     */
    fun getSafeSearchVipForDomain(rawDomain: String): ByteArray? {
        if (!strictModeEnabled || !forceSafeSearchDns) return null
        val dom = rawDomain.trim().lowercase(Locale.US).trimEnd('.')
        if (dom.isEmpty()) return null

        // Google Search domains across all ccTLDs (www.google.com, google.com, www.google.co.in, www.google.co.uk, etc.)
        if (dom == "google.com" || dom == "www.google.com" || GOOGLE_CC_TLD_REGEX.matches(dom)) {
            return GOOGLE_SAFESEARCH_VIP
        }

        // YouTube Restricted Mode domains
        if (dom == "www.youtube.com" ||
            dom == "m.youtube.com" ||
            dom == "youtubei.googleapis.com" ||
            dom == "youtube.googleapis.com" ||
            dom == "www.youtube-nocookie.com"
        ) {
            return GOOGLE_SAFESEARCH_VIP
        }

        // Bing Strict SafeSearch domains
        if (dom == "bing.com" || dom == "www.bing.com" || dom == "m.bing.com") {
            return BING_SAFESEARCH_VIP
        }

        // DuckDuckGo SafeSearch domains
        if (dom == "duckduckgo.com" ||
            dom == "www.duckduckgo.com" ||
            dom == "start.duckduckgo.com" ||
            dom == "html.duckduckgo.com" ||
            dom == "lite.duckduckgo.com"
        ) {
            return DUCKDUCKGO_SAFESEARCH_VIP
        }

        return null
    }

    // =========================================================================
    // 2. Adult Search Query, Leetspeak De-Obfuscation & URL Inspector
    // =========================================================================

    /**
     * Normalizes leetspeak & zero-width obfuscated text (e.g. "p0rnhub" -> "pornhub", "h3nt4i" -> "hentai",
     * "x.v.i.d.e.o.s" -> "xvideos") so users cannot evade search or URL filters using character substitutions.
     */
    internal fun deobfuscateText(raw: String): String {
        val stripped = raw.replace(ZERO_WIDTH_REGEX, "").lowercase(Locale.US)
        val sb = StringBuilder(stripped.length)
        for (ch in stripped) {
            when (ch) {
                '0' -> sb.append('o')
                '1', '!' -> sb.append('i')
                '3' -> sb.append('e')
                '4', '@' -> sb.append('a')
                '5', '$' -> sb.append('s')
                else -> sb.append(ch)
            }
        }
        return sb.toString()
    }

    fun evaluateUrlOrSearchQuery(rawUrlOrQuery: String, packageName: String = ""): ShieldVerdict {
        if (!strictModeEnabled) return ShieldVerdict(blocked = false)
        val raw = rawUrlOrQuery.trim()
        if (raw.isEmpty()) return ShieldVerdict(blocked = false)
        val lower = raw.lowercase(Locale.US).replace(ZERO_WIDTH_REGEX, "")
        val deobfuscated = deobfuscateText(lower)

        // 0. Check Adult Magnet / Torrent URIs (magnet:?xt=urn:btih:...)
        if (lower.startsWith("magnet:?") || lower.endsWith(".torrent")) {
            val magnetClean = lower.replace(QUERY_SEPARATOR_REGEX, " ")
            val magnetDeobf = deobfuscateText(magnetClean)
            for ((phrase, _) in EXPLICIT_SEARCH_PHRASES) {
                if (containsBoundedPhrase(magnetClean, phrase) || containsBoundedPhrase(magnetDeobf, phrase)) {
                    return ShieldVerdict(
                        blocked = true,
                        channel = "WEB_VIDEO",
                        target = raw.take(120),
                        reason = "Adult torrent/magnet link blocked (matched '$phrase')",
                        confidence = 97
                    )
                }
            }
        }

        // 0B. Check if URL/domain matches Adult Web Video, Tube, Cam, Undress AI, or Deepfake stems
        if (blockWebAndVideo && (lower.contains("://") || lower.contains("www.") || lower.contains("."))) {
            for (stem in ADULT_WEB_VIDEO_AND_AI_STEMS) {
                if (lower.contains(stem) || deobfuscated.contains(stem)) {
                    return ShieldVerdict(
                        blocked = true,
                        channel = "WEB_VIDEO",
                        target = raw.take(120),
                        reason = "Adult video/cam/AI site '$stem' blocked",
                        confidence = 97
                    )
                }
            }
        }

        // 1. Check if URL/domain matches Adult Reading, Stories, Manga, Doujinshi, Adult AI, or Forum stems
        if (blockReadingAndManga) {
            for (stem in ADULT_READING_AND_MANGA_STEMS) {
                if (lower.contains(stem) || deobfuscated.contains(stem)) {
                    return ShieldVerdict(
                        blocked = true,
                        channel = "READING_MANGA",
                        target = raw.take(120),
                        reason = "Adult reading/manga/AI/forum platform '$stem' blocked",
                        confidence = 96
                    )
                }
            }
            NSFW_SUBREDDIT_REGEX.find(lower)?.let { m ->
                return ShieldVerdict(
                    blocked = true,
                    channel = "READING_MANGA",
                    target = raw.take(120),
                    reason = "NSFW forum/subreddit '${m.value}' blocked",
                    confidence = 95
                )
            }
            if (lower.contains("view_adult=true") || lower.contains("adult_warning=true") || lower.contains("r18=1") || lower.contains("mode=r18")) {
                return ShieldVerdict(
                    blocked = true,
                    channel = "READING_MANGA",
                    target = raw.take(120),
                    reason = "18+ adult content bypass parameter detected in URL",
                    confidence = 90
                )
            }
        }

        // 2. Check Search Queries in URL parameters (?q=, &q=, ?p=, ?query=, ?search=, ?text=, ?wd=, ?keyword=, ?tags=) or raw search text
        if (blockAdultSearches) {
            val extractedQuery = extractSearchQueryFromUrlOrText(raw)
            if (extractedQuery.isNotBlank()) {
                val queryVerdict = evaluateRawSearchText(extractedQuery)
                if (queryVerdict.blocked) {
                    return queryVerdict
                }
            }
        }

        // 3. Check direct APK download URLs for adult or bypass apps
        if (blockAdultAppsAndApks && (lower.endsWith(".apk") || lower.contains(".apk?"))) {
            for (token in ADULT_PACKAGE_AND_APK_TOKENS) {
                if ((lower.contains(token) || deobfuscated.contains(token)) && !containsSafeAllowlistedWord(lower)) {
                    return ShieldVerdict(
                        blocked = true,
                        channel = "APP_APK",
                        target = raw.take(120),
                        reason = "Adult APK download URL blocked ('$token')",
                        confidence = 95
                    )
                }
            }
        }

        return ShieldVerdict(blocked = false)
    }

    private fun extractSearchQueryFromUrlOrText(input: String): String {
        val trim = input.trim()
        if (trim.contains("?") || trim.contains("&") || trim.startsWith("http://") || trim.startsWith("https://")) {
            val queryPart = trim.substringAfter("?", "")
            if (queryPart.isNotEmpty()) {
                val params = queryPart.substringBefore("#").split("&")
                val searchKeys = setOf("q", "p", "query", "search", "search_query", "text", "wd", "keyword", "keywords", "tags", "s", "k")
                for (param in params) {
                    val eqIdx = param.indexOf('=')
                    if (eqIdx > 0) {
                        val key = param.substring(0, eqIdx).lowercase(Locale.US)
                        val rawVal = param.substring(eqIdx + 1)
                        if (key in searchKeys && rawVal.isNotBlank()) {
                            return try {
                                URLDecoder.decode(rawVal.replace("+", " "), "UTF-8")
                            } catch (_: Throwable) {
                                rawVal.replace("+", " ").replace("%20", " ")
                            }
                        }
                    }
                }
            }
            return ""
        }
        if (trim.contains(" ") || !trim.contains(".")) {
            return trim
        }
        return ""
    }

    fun evaluateRawSearchText(rawQuery: String): ShieldVerdict {
        if (!strictModeEnabled || !blockAdultSearches) return ShieldVerdict(blocked = false)
        val normalized = rawQuery.trim().lowercase(Locale.US)
            .replace(ZERO_WIDTH_REGEX, "")
            .replace(QUERY_SEPARATOR_REGEX, " ")
        if (normalized.length < 3) return ShieldVerdict(blocked = false)

        // Filter out safe allowlisted words so "essex", "document", "analytics", "scunthorpe" are never blocked
        var cleanedQuery = normalized
        for (safeWord in SAFE_SUBSTRING_ALLOWLIST) {
            if (cleanedQuery.contains(safeWord)) {
                cleanedQuery = cleanedQuery.replace(safeWord, " ")
            }
        }
        val deobfuscatedQuery = deobfuscateText(cleanedQuery)

        var totalScore = 0
        var matchedTerm = ""
        for ((phrase, weight) in EXPLICIT_SEARCH_PHRASES) {
            if (containsBoundedPhrase(cleanedQuery, phrase) || containsBoundedPhrase(deobfuscatedQuery, phrase)) {
                totalScore += weight
                if (matchedTerm.isEmpty()) matchedTerm = phrase
            }
        }

        if (totalScore >= 80) {
            return ShieldVerdict(
                blocked = true,
                channel = "SEARCH_QUERY",
                target = rawQuery.take(100),
                reason = "Explicit adult search query blocked (matched '$matchedTerm')",
                confidence = totalScore.coerceAtMost(100)
            )
        }
        return ShieldVerdict(blocked = false)
    }

    // =========================================================================
    // 3. Live On-Screen Content Scanner (Reading, Manga, Incognito, Anti-Tamper & Store Pages)
    // =========================================================================

    fun evaluateOnScreenContent(
        packageName: String,
        detectedUrl: String,
        detectedTitle: String,
        focusedSearchText: String,
        screenTextSample: String,
        hasIncognitoUiNode: Boolean = false
    ): ShieldVerdict {
        if (!strictModeEnabled) return ShieldVerdict(blocked = false)
        if (packageName == context.packageName || packageName == "com.android.systemui") {
            return ShieldVerdict(blocked = false)
        }

        val combinedScreen = "$detectedTitle | $screenTextSample".lowercase(Locale.US)

        // 0A. System Settings & VPN Dialog Anti-Tamper Protection
        if (blockSettingsTampering && adminLockEnabled && !isAdminSessionTemporarilyUnlocked()) {
            val isSettingsOrVpnDialog = packageName == "com.android.settings" ||
                packageName == "com.android.vpndialogs" ||
                packageName.contains("permissioncontroller", ignoreCase = true)

            if (isSettingsOrVpnDialog && combinedScreen.isNotBlank()) {
                val mentionsOurShield = combinedScreen.contains("aeroshare") ||
                    combinedScreen.contains("aero dns") ||
                    combinedScreen.contains("aero network moderator") ||
                    combinedScreen.contains("termux accessibility")

                val mentionsTamperAction = combinedScreen.contains("disconnect vpn") ||
                    combinedScreen.contains("forget vpn") ||
                    combinedScreen.contains("turn off") ||
                    combinedScreen.contains("stop service") ||
                    combinedScreen.contains("force stop") ||
                    combinedScreen.contains("clear storage") ||
                    combinedScreen.contains("clear data") ||
                    combinedScreen.contains("uninstall")

                if (mentionsOurShield && mentionsTamperAction) {
                    return ShieldVerdict(
                        blocked = true,
                        channel = "BYPASS_ATTEMPT",
                        target = "System Settings Tamper Protection",
                        reason = "Blocked attempt to disable or tamper with Aero Adult Content Shield / VPN / Accessibility without Admin PIN",
                        confidence = 99
                    )
                }
            }
        }

        // 0B. Incognito / Private Browsing / Secret Mode Blocker
        if (blockIncognitoTabs) {
            if (hasIncognitoUiNode || INCOGNITO_SCREEN_MARKERS.any { combinedScreen.contains(it) }) {
                return ShieldVerdict(
                    blocked = true,
                    channel = "BYPASS_ATTEMPT",
                    target = "Incognito / Private Browsing Tab",
                    reason = "Incognito and Private Browsing tabs are restricted while Adult Content Shield is active",
                    confidence = 95
                )
            }
        }

        // 1. Check active URL or search query in URL
        if (detectedUrl.isNotBlank()) {
            val urlVerdict = evaluateUrlOrSearchQuery(detectedUrl, packageName)
            if (urlVerdict.blocked) return urlVerdict
        }

        // 2. Check focused search bar / omnibox query text
        if (focusedSearchText.isNotBlank() && blockAdultSearches) {
            val searchVerdict = evaluateRawSearchText(focusedSearchText)
            if (searchVerdict.blocked) return searchVerdict
        }

        if (combinedScreen.isBlank()) return ShieldVerdict(blocked = false)

        // 3. Check Package Installer / App Store pages for Adult Apps or Bypass VPNs
        val isInstallerOrStore = packageName.contains("packageinstaller", ignoreCase = true) ||
            packageName.contains("vending", ignoreCase = true) ||
            packageName.contains("fdroid", ignoreCase = true) ||
            packageName.contains("aurora", ignoreCase = true) ||
            packageName.contains("apkpure", ignoreCase = true) ||
            packageName.contains("apkmirror", ignoreCase = true) ||
            packageName.contains("uptodown", ignoreCase = true) ||
            packageName.contains("tap.tap", ignoreCase = true)

        if (isInstallerOrStore && (blockAdultAppsAndApks || blockBypassVpns)) {
            for (adultTok in ADULT_PACKAGE_AND_APK_TOKENS) {
                if (containsBoundedPhrase(combinedScreen, adultTok) && !containsSafeAllowlistedWord(combinedScreen)) {
                    return ShieldVerdict(
                        blocked = true,
                        channel = "APP_APK",
                        target = detectedTitle.ifBlank { adultTok }.take(90),
                        reason = "Adult app store page / APK installer blocked (matched '$adultTok')",
                        confidence = 92
                    )
                }
            }
        }

        // 4. Check On-Screen Reading, Stories, Manga, Erotica & 18+ Fiction Indicators
        if (blockReadingAndManga) {
            var readingScore = 0
            val matchedIndicators = mutableListOf<String>()
            for ((indicator, weight) in ON_SCREEN_READING_INDICATORS) {
                if (combinedScreen.contains(indicator)) {
                    readingScore += weight
                    matchedIndicators.add(indicator)
                }
            }
            for (stem in ADULT_READING_AND_MANGA_STEMS) {
                if (containsBoundedPhrase(combinedScreen, stem)) {
                    readingScore += 85
                    matchedIndicators.add(stem)
                }
            }
            if (readingScore >= 75) {
                return ShieldVerdict(
                    blocked = true,
                    channel = "READING_MANGA",
                    target = detectedUrl.ifBlank { detectedTitle.ifBlank { packageName } }.take(100),
                    reason = "On-screen adult reading/manga/erotica detected (${matchedIndicators.firstOrNull().orEmpty()})",
                    confidence = readingScore.coerceAtMost(100)
                )
            }
        }

        return ShieldVerdict(blocked = false)
    }

    // =========================================================================
    // 4. Clipboard & Notification Adult Link / Magnet / Base64 Scrubber
    // =========================================================================

    /**
     * Inspects copied clipboard text for adult URLs, magnet links, or base64-encoded adult links.
     * If detected, scrubs the device clipboard and records a violation.
     */
    fun inspectAndSanitizeClipboard(rawClipboardText: String): ShieldVerdict {
        if (!strictModeEnabled || !blockClipboardAndNotifs) return ShieldVerdict(blocked = false)
        val clean = rawClipboardText.trim()
        if (clean.length < 5 || clean.startsWith("[REDACTED BY ADULT CONTENT SHIELD]")) {
            return ShieldVerdict(blocked = false)
        }

        // Decode any Base64 URL candidates (e.g. aHR0cHM6Ly9wb3JuaHViLmNvbQ==)
        var expandedText = clean
        BASE64_URL_CANDIDATE_REGEX.findAll(clean).take(3).forEach { match ->
            try {
                val decoded = String(Base64.decode(match.value, Base64.DEFAULT), Charsets.UTF_8)
                if (decoded.startsWith("http://") || decoded.startsWith("https://") || decoded.startsWith("magnet:")) {
                    expandedText = "$expandedText $decoded"
                }
            } catch (_: Throwable) {}
        }

        val urlVerdict = evaluateUrlOrSearchQuery(expandedText, "clipboard")
        val netMod = com.kavach.network.NetworkModerationManager.activeInstance
        val (domainBlocked, domainReason) = if (!urlVerdict.blocked && (expandedText.contains("://") || expandedText.contains("www."))) {
            netMod?.checkUrlOrDomainBlocked(expandedText) ?: (false to "")
        } else {
            false to ""
        }

        if (urlVerdict.blocked || domainBlocked) {
            val reason = if (urlVerdict.blocked) urlVerdict.reason else "Clipboard adult URL blocked ($domainReason)"
            mainHandler.post {
                try {
                    val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
                    cm?.setPrimaryClip(ClipData.newPlainText("AeroShield", "[REDACTED BY ADULT CONTENT SHIELD]"))
                } catch (_: Throwable) {}
            }
            val verdict = ShieldVerdict(
                blocked = true,
                channel = "CLIPBOARD_GUARD",
                target = clean.take(80),
                reason = "$reason (Clipboard scrubbed)",
                confidence = 95
            )
            recordViolation(
                channel = verdict.channel,
                target = verdict.target,
                packageName = "clipboard",
                reason = verdict.reason,
                actionTaken = "CLIPBOARD_SCRUBBED"
            )
            return verdict
        }
        return ShieldVerdict(blocked = false)
    }

    /**
     * Inspects incoming notifications for adult URLs, NSFW group links, or explicit adult alerts.
     */
    fun inspectNotificationContent(packageName: String, title: String, text: String): ShieldVerdict {
        if (!strictModeEnabled || !blockClipboardAndNotifs) return ShieldVerdict(blocked = false)
        if (packageName == context.packageName) return ShieldVerdict(blocked = false)
        val combined = "$title $text".trim()
        if (combined.length < 5) return ShieldVerdict(blocked = false)

        val verdict = evaluateUrlOrSearchQuery(combined, packageName)
        if (verdict.blocked) {
            recordViolation(
                channel = verdict.channel,
                target = "$title: ${text.take(60)}",
                packageName = packageName,
                reason = "Notification contained prohibited adult content (${verdict.reason})",
                actionTaken = "NOTIFICATION_FLAGGED_AND_DISMISSED"
            )
            return verdict
        }
        return ShieldVerdict(blocked = false)
    }

    // =========================================================================
    // 5. App & APK Package Inspector + ZIP/CBZ Archive Scanner + Bypass VPN Blocker
    // =========================================================================

    fun evaluateInstalledOrLaunchingPackage(packageName: String, appLabel: String = ""): ShieldVerdict {
        if (!strictModeEnabled) return ShieldVerdict(blocked = false)
        val pkg = packageName.trim().lowercase(Locale.US)
        if (pkg.isEmpty() || pkg == context.packageName.lowercase(Locale.US) || pkg == "com.termux") {
            return ShieldVerdict(blocked = false)
        }

        // 1. Check unauthorized VPN / Proxy / Tor / DoH bypass apps
        if (blockBypassVpns) {
            if (pkg in BYPASS_VPN_AND_DNS_PACKAGES ||
                pkg.contains(".vpn") || pkg.startsWith("vpn.") ||
                pkg.contains("torbrowser") || pkg.contains("psiphon") || pkg.contains("lantern")
            ) {
                return ShieldVerdict(
                    blocked = true,
                    channel = "BYPASS_ATTEMPT",
                    target = appLabel.ifBlank { packageName },
                    reason = "Unauthorized VPN/DNS bypass app blocked ($packageName)",
                    confidence = 98
                )
            }
        }

        // 2. Check Adult App packages & labels
        if (blockAdultAppsAndApks) {
            val combined = "$pkg ${appLabel.lowercase(Locale.US)}"
            if (!containsSafeAllowlistedWord(combined)) {
                for (token in ADULT_PACKAGE_AND_APK_TOKENS) {
                    if (pkg.contains(token) || containsBoundedPhrase(appLabel.lowercase(Locale.US), token)) {
                        return ShieldVerdict(
                            blocked = true,
                            channel = "APP_APK",
                            target = appLabel.ifBlank { packageName },
                            reason = "Adult application package blocked (matched '$token' in $packageName)",
                            confidence = 95
                        )
                    }
                }
            }
        }

        return ShieldVerdict(blocked = false)
    }

    /**
     * Inspects an un-installed .apk file, disguised .zip/.cbz archive, or downloaded story/media file on disk.
     */
    fun inspectFileForAdultOrBypassContent(file: File): ShieldVerdict {
        if (!strictModeEnabled || !file.exists() || !file.isFile) return ShieldVerdict(blocked = false)
        val nameLower = file.name.lowercase(Locale.US)
        val deobfName = deobfuscateText(nameLower)

        val cachedMod = scannedSafeFilesCache[file.absolutePath]
        if (cachedMod != null && cachedMod == file.lastModified()) {
            return ShieldVerdict(blocked = false)
        }

        // 1. If it's an APK file, inspect internal package name and app label via PackageManager.getPackageArchiveInfo
        if (nameLower.endsWith(".apk") || nameLower.endsWith(".xapk") || nameLower.endsWith(".apks")) {
            if (nameLower.endsWith(".apk")) {
                try {
                    val pm = context.packageManager
                    val pkgInfo = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        pm.getPackageArchiveInfo(file.absolutePath, PackageManager.PackageInfoFlags.of(0L))
                    } else {
                        @Suppress("DEPRECATION")
                        pm.getPackageArchiveInfo(file.absolutePath, 0)
                    }
                    if (pkgInfo != null) {
                        val apkPkg = pkgInfo.packageName.orEmpty()
                        val appInfo = pkgInfo.applicationInfo
                        val apkLabel = if (appInfo != null) {
                            appInfo.sourceDir = file.absolutePath
                            appInfo.publicSourceDir = file.absolutePath
                            try { pm.getApplicationLabel(appInfo)?.toString().orEmpty() } catch (_: Throwable) { "" }
                        } else ""

                        val pkgVerdict = evaluateInstalledOrLaunchingPackage(apkPkg, apkLabel)
                        if (pkgVerdict.blocked) {
                            return pkgVerdict.copy(
                                target = "${file.name} ($apkPkg)",
                                reason = "${pkgVerdict.reason} [APK Archive]"
                            )
                        }
                    }
                } catch (_: Throwable) {}
            }

            if (!containsSafeAllowlistedWord(nameLower)) {
                for (token in ADULT_PACKAGE_AND_APK_TOKENS) {
                    if (nameLower.contains(token) || deobfName.contains(token)) {
                        return ShieldVerdict(
                            blocked = true,
                            channel = "APP_APK",
                            target = file.name,
                            reason = "Adult APK installer file detected (matched '$token')",
                            confidence = 94
                        )
                    }
                }
            }
        }

        // 2. Zero-RAM ZIP / CBZ Central Directory Entry Inspection (catches disguised .zip/.cbz archives containing adult .apk or manga chapters)
        if ((nameLower.endsWith(".zip") || nameLower.endsWith(".cbz") || nameLower.endsWith(".xapk")) &&
            file.length() in 32..(500L * 1024L * 1024L)
        ) {
            try {
                ZipFile(file).use { zip ->
                    val entries = zip.entries()
                    var inspectedEntries = 0
                    while (entries.hasMoreElements() && inspectedEntries < 120) {
                        val entry = entries.nextElement()
                        inspectedEntries++
                        val entryNameLower = entry.name.lowercase(Locale.US)
                        if ( containsSafeAllowlistedWord(entryNameLower)) continue
                        for (stem in ADULT_READING_AND_MANGA_STEMS) {
                            if (entryNameLower.contains(stem)) {
                                val ch = if (entryNameLower.endsWith(".apk")) "APP_APK" else "READING_MANGA"
                                return ShieldVerdict(
                                    blocked = true,
                                    channel = ch,
                                    target = "${file.name} -> ${entry.name.take(60)}",
                                    reason = "Archive contains adult manga/APK entry (matched '$stem')",
                                    confidence = 94
                                )
                            }
                        }
                        for (token in ADULT_PACKAGE_AND_APK_TOKENS) {
                            if (containsBoundedFilenameToken(entryNameLower, token)) {
                                val ch = if (entryNameLower.endsWith(".apk")) "APP_APK" else "READING_MANGA"
                                return ShieldVerdict(
                                    blocked = true,
                                    channel = ch,
                                    target = "${file.name} -> ${entry.name.take(60)}",
                                    reason = "Disguised archive contains prohibited adult entry ('$token' in '${entry.name.take(40)}')",
                                    confidence = 93
                                )
                            }
                        }
                    }
                }
            } catch (_: Throwable) {}
        }

        // 3. Check downloaded media/reading files (.mp4, .mkv, .webm, .pdf, .epub, .cbz, .cbr, .zip, .txt, .html, .torrent)
        val inspectableExts = listOf(
            ".mp4", ".mkv", ".webm", ".avi", ".mov", ".gif", ".torrent",
            ".pdf", ".epub", ".mobi", ".cbz", ".cbr", ".txt", ".html", ".htm", ".zip", ".rar"
        )
        if (inspectableExts.any { nameLower.endsWith(it) } && !containsSafeAllowlistedWord(nameLower)) {
            for (stem in ADULT_READING_AND_MANGA_STEMS) {
                if (nameLower.contains(stem) || deobfName.contains(stem)) {
                    return ShieldVerdict(
                        blocked = true,
                        channel = "READING_MANGA",
                        target = file.name,
                        reason = "Downloaded adult manga/story file detected (matched '$stem')",
                        confidence = 93
                    )
                }
            }
            for (token in ADULT_PACKAGE_AND_APK_TOKENS) {
                if (containsBoundedFilenameToken(nameLower, token) || containsBoundedFilenameToken(deobfName, token)) {
                    val ch = if (nameLower.endsWith(".pdf") || nameLower.endsWith(".epub") || nameLower.endsWith(".cbz") || nameLower.endsWith(".txt")) {
                        "READING_MANGA"
                    } else {
                        "WEB_VIDEO"
                    }
                    return ShieldVerdict(
                        blocked = true,
                        channel = ch,
                        target = file.name,
                        reason = "Downloaded adult file detected (matched '$token' in '${file.name}')",
                        confidence = 91
                    )
                }
            }
        }

        scannedSafeFilesCache[file.absolutePath] = file.lastModified()
        return ShieldVerdict(blocked = false)
    }

    // =========================================================================
    // 6. Instant Enforcement: Kick-Back, Block Screen & File Quarantine
    // =========================================================================

    fun enforceViolation(
        verdict: ShieldVerdict,
        packageName: String = "",
        kickHome: Boolean = false
    ) {
        if (!verdict.blocked) return
        val now = System.currentTimeMillis()
        val dedupKey = "${verdict.channel}|${verdict.target}|$packageName"
        val lastMs = recentEnforcementDedup[dedupKey] ?: 0L
        if (now - lastMs < 1500L) return
        recentEnforcementDedup[dedupKey] = now

        val accService = AccessibilityServiceRegistry.activeService
        if (accService != null) {
            try {
                if (kickHome || verdict.channel in listOf("APP_APK", "BYPASS_ATTEMPT", "TAMPER_ATTEMPT")) {
                    accService.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME)
                } else {
                    accService.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)
                }
            } catch (_: Throwable) {}
        }

        val actionLabel = if (kickHome) "KICK_HOME_AND_BLOCK_SCREEN" else "KICK_BACK_AND_BLOCK_SCREEN"
        recordViolation(
            channel = verdict.channel,
            target = verdict.target,
            packageName = packageName,
            reason = verdict.reason,
            actionTaken = actionLabel
        )

        com.kavach.network.NetworkModerationManager.activeInstance?.triggerVisualBlockScreen(
            domain = verdict.target.ifBlank { "Restricted Adult Content" },
            reason = verdict.reason,
            category = "ADULT_SHIELD_${verdict.channel}"
        )

        mainHandler.post {
            try {
                Toast.makeText(
                    context,
                    "🛡️ Adult Shield Blocked (${verdict.channel}): ${verdict.target.take(45)}",
                    Toast.LENGTH_SHORT
                ).show()
            } catch (_: Throwable) {}
        }
    }

    private fun inspectCompletedDownloadId(downloadId: Long) {
        if (downloadId <= 0L || !strictModeEnabled) return
        val dm = context.getSystemService(Context.DOWNLOAD_SERVICE) as? DownloadManager ?: return
        var cursor: Cursor? = null
        try {
            cursor = dm.query(DownloadManager.Query().setFilterById(downloadId))
            if (cursor != null && cursor.moveToFirst()) {
                val uriIdx = cursor.getColumnIndex(DownloadManager.COLUMN_LOCAL_URI)
                val titleIdx = cursor.getColumnIndex(DownloadManager.COLUMN_TITLE)
                val uriStr = if (uriIdx >= 0) cursor.getString(uriIdx).orEmpty() else ""
                val titleStr = if (titleIdx >= 0) cursor.getString(titleIdx).orEmpty() else ""

                if (uriStr.startsWith("file://")) {
                    val f = File(Uri.parse(uriStr).path.orEmpty())
                    if (f.exists()) {
                        val verdict = inspectFileForAdultOrBypassContent(f)
                        if (verdict.blocked && quarantineDownloads) {
                            quarantineFile(f, verdict.reason, verdict.channel)
                            dm.remove(downloadId)
                            return
                        }
                    }
                }
                if (titleStr.isNotBlank()) {
                    val tempVerdict = evaluateUrlOrSearchQuery(titleStr)
                    if (tempVerdict.blocked && quarantineDownloads) {
                        dm.remove(downloadId)
                        recordViolation(
                            channel = tempVerdict.channel,
                            target = titleStr,
                            packageName = "com.android.providers.downloads",
                            reason = "Removed prohibited adult download from DownloadManager: ${tempVerdict.reason}",
                            actionTaken = "QUARANTINED_DOWNLOAD"
                        )
                    }
                }
            }
        } catch (_: Throwable) {
        } finally {
            try { cursor?.close() } catch (_: Throwable) {}
        }
    }

    /**
     * Scans standard Download folders (`/sdcard/Download`, `/sdcard/Download/AeroShare`, app external downloads)
     * and quarantines any adult `.apk`, disguised `.zip`/`.cbz`, video, or reading/manga archive files.
     */
    fun scanAndQuarantineDownloads(): JSONObject {
        if (!isScanningDownloads.compareAndSet(false, true)) {
            return JSONObject().apply {
                put("success", true)
                put("status", "SCAN_ALREADY_IN_PROGRESS")
                put("totalQuarantinedCount", quarantinedFiles.size)
            }
        }
        try {
            val dirsToScan = mutableListOf<File>()
            try {
                val publicDl = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                if (publicDl != null && publicDl.exists()) {
                    dirsToScan.add(publicDl)
                    val aeroShareDl = File(publicDl, "AeroShare")
                    if (aeroShareDl.exists()) dirsToScan.add(aeroShareDl)
                }
            } catch (_: Throwable) {}
            try {
                context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)?.let {
                    if (it.exists()) dirsToScan.add(it)
                }
            } catch (_: Throwable) {}

            var scannedCount = 0
            val newlyQuarantined = JSONArray()

            for (dir in dirsToScan) {
                val files = try { dir.listFiles() } catch (_: Throwable) { null } ?: continue
                for (file in files.take(150)) {
                    if (!file.isFile) continue
                    scannedCount++
                    val verdict = inspectFileForAdultOrBypassContent(file)
                    if (verdict.blocked) {
                        if (quarantineDownloads) {
                            val qEntry = quarantineFile(file, verdict.reason, verdict.channel)
                            if (qEntry != null) {
                                newlyQuarantined.put(qEntry.toJson())
                            }
                        } else {
                            enforceViolation(verdict, packageName = "downloads_scanner", kickHome = false)
                        }
                    }
                }
            }

            return JSONObject().apply {
                put("success", true)
                put("scannedFilesCount", scannedCount)
                put("newlyQuarantinedCount", newlyQuarantined.length())
                put("newlyQuarantined", newlyQuarantined)
                put("totalQuarantinedCount", quarantinedFiles.size)
            }
        } finally {
            isScanningDownloads.set(false)
        }
    }

    fun quarantineFile(
        file: File,
        reason: String,
        channel: String = "APP_APK",
        packageName: String = ""
    ): QuarantinedFileEntry? {
        if (!file.exists()) return null
        val now = System.currentTimeMillis()
        val id = "qf_${now}_${UUID.randomUUID().toString().take(5)}"
        val origName = file.name
        val origPath = file.absolutePath
        val sizeBytes = file.length()
        val destFile = File(quarantineDir, "${id}_${origName.replace(SAFE_FILENAME_CHARS_REGEX, "_")}.quarantined")

        try {
            val renamed = file.renameTo(destFile)
            if (!renamed) {
                file.copyTo(destFile, overwrite = true)
                file.delete()
            }
        } catch (_: Throwable) {
            try { file.delete() } catch (_: Throwable) {}
        }

        val entry = QuarantinedFileEntry(
            id = id,
            originalFileName = origName,
            originalPath = origPath,
            quarantinePath = if (destFile.exists()) destFile.absolutePath else "PURGED",
            fileSizeBytes = sizeBytes,
            channel = channel,
            reason = reason,
            packageName = packageName,
            timestampMs = now
        )
        quarantinedFiles.addLast(entry)
        while (quarantinedFiles.size > MAX_QUARANTINE_ENTRIES) {
            val oldest = quarantinedFiles.pollFirst()
            if (oldest != null && oldest.quarantinePath != "PURGED") {
                try { File(oldest.quarantinePath).delete() } catch (_: Throwable) {}
            }
        }

        recordViolation(
            channel = channel,
            target = origName,
            packageName = packageName.ifBlank { "file_quarantine" },
            reason = "$reason (Quarantined ${sizeBytes / 1024} KB)",
            actionTaken = "QUARANTINED_FILE"
        )

        com.kavach.network.NetworkModerationManager.activeInstance?.triggerVisualBlockScreen(
            domain = origName,
            reason = "Quarantined Adult/Restricted File: $reason",
            category = "FILE_QUARANTINE"
        )

        return entry
    }

    fun purgeAllQuarantinedFiles(pin: String? = null, biometricVerified: Boolean = false): JSONObject {
        if (adminLockEnabled && !biometricVerified && !verifyAdminPin(pin)) {
            return JSONObject().put("success", false).put("error", "Admin PIN or Biometric verification required")
        }
        var deletedCount = 0
        for (item in quarantinedFiles) {
            if (item.quarantinePath != "PURGED") {
                try {
                    val f = File(item.quarantinePath)
                    if (f.exists() && f.delete()) deletedCount++
                } catch (_: Throwable) {}
            }
        }
        val clearedEntries = quarantinedFiles.size
        quarantinedFiles.clear()
        savePersistedState()
        updatePolicyFlow()
        return JSONObject().apply {
            put("success", true)
            put("action", "QUARANTINE_PURGED")
            put("clearedEntries", clearedEntries)
            put("deletedFilesFromDisk", deletedCount)
        }
    }

    fun recordViolation(
        channel: String,
        target: String,
        packageName: String,
        reason: String,
        actionTaken: String
    ): AdultShieldViolationEvent {
        val now = System.currentTimeMillis()
        totalBlockedEvents++
        when (channel.uppercase(Locale.US)) {
            "WEB_VIDEO" -> webVideoBlockedCount++
            "READING_MANGA" -> readingMangaBlockedCount++
            "SEARCH_QUERY" -> searchBlockedCount++
            "APP_APK" -> appApkBlockedCount++
            "BYPASS_ATTEMPT", "INCOGNITO_BLOCKED", "TAMPER_ATTEMPT", "CLIPBOARD_GUARD" -> bypassBlockedCount++
        }
        lastViolationTarget = target.take(120)
        lastViolationChannel = channel
        lastViolationTimeMs = now

        val evt = AdultShieldViolationEvent(
            id = "as_${now}_${UUID.randomUUID().toString().take(5)}",
            timestampMs = now,
            channel = channel,
            target = target.take(160),
            packageName = packageName,
            reason = reason,
            actionTaken = actionTaken
        )
        violationHistory.addLast(evt)
        while (violationHistory.size > MAX_VIOLATION_HISTORY) {
            violationHistory.pollFirst()
        }

        savePersistedState()
        updatePolicyFlow()

        com.kavach.telemetry.OfflineTelemetryVaultManager.activeInstance?.recordAdultShieldEvent(
            channel = channel,
            target = target,
            reason = reason,
            packageName = packageName,
            actionTaken = actionTaken
        )

        return evt
    }

    // =========================================================================
    // JSON Status, Logs, Quarantine & Diagnostic Test APIs
    // =========================================================================

    fun getStatusJson(): JSONObject {
        val recentArr = JSONArray()
        violationHistory.toList().takeLast(20).reversed().forEach { recentArr.put(it.toJson()) }
        val quarantineArr = JSONArray()
        quarantinedFiles.toList().takeLast(20).reversed().forEach { quarantineArr.put(it.toJson()) }

        return JSONObject().apply {
            put("success", true)
            put("strictModeEnabled", strictModeEnabled)
            put("blockWebAndVideo", blockWebAndVideo)
            put("blockReadingAndManga", blockReadingAndManga)
            put("blockAdultSearches", blockAdultSearches)
            put("blockAdultAppsAndApks", blockAdultAppsAndApks)
            put("quarantineDownloads", quarantineDownloads)
            put("forceSafeSearchDns", forceSafeSearchDns)
            put("blockBypassVpns", blockBypassVpns)
            put("blockIncognitoTabs", blockIncognitoTabs)
            put("blockSettingsTampering", blockSettingsTampering)
            put("blockClipboardAndNotifs", blockClipboardAndNotifs)
            put("adminLockEnabled", adminLockEnabled)
            put("isAdminTemporarilyUnlocked", isAdminSessionTemporarilyUnlocked())
            put("hasCustomPin", adminPinHash.isNotEmpty())
            put("defaultPinHint", if (adminPinHash.isEmpty()) "1234" else "CUSTOM_SET")
            put("safeSearchVips", JSONObject().apply {
                put("googleSearch", "216.239.38.120 (forcesafesearch.google.com)")
                put("youtubeRestricted", "216.239.38.120 (restrict.youtube.com)")
                put("bingStrict", "204.79.197.220 (strict.bing.com)")
                put("duckDuckGoSafe", "52.142.124.215 (safe.duckduckgo.com)")
                put("cleanBrowsingFamilyDns", "185.228.168.168 / 185.228.169.168")
                put("cloudflareFamilyDns", "1.1.1.3 / 1.0.0.3")
            })
            put("stats", JSONObject().apply {
                put("totalBlockedEvents", totalBlockedEvents)
                put("webVideoBlockedCount", webVideoBlockedCount)
                put("readingMangaBlockedCount", readingMangaBlockedCount)
                put("searchBlockedCount", searchBlockedCount)
                put("appApkBlockedCount", appApkBlockedCount)
                put("bypassBlockedCount", bypassBlockedCount)
                put("quarantinedFilesCount", quarantinedFiles.size)
                put("lastViolationTarget", lastViolationTarget)
                put("lastViolationChannel", lastViolationChannel)
                put("lastViolationTimeMs", lastViolationTimeMs)
            })
            put("recentViolationsCount", violationHistory.size)
            put("recentViolations", recentArr)
            put("quarantinedFiles", quarantineArr)
        }
    }

    fun getViolationLogsJson(limit: Int = 50): JSONObject {
        val arr = JSONArray()
        violationHistory.toList().takeLast(limit.coerceIn(1, MAX_VIOLATION_HISTORY)).reversed()
            .forEach { arr.put(it.toJson()) }
        return JSONObject().apply {
            put("success", true)
            put("count", arr.length())
            put("totalBlockedEvents", totalBlockedEvents)
            put("violations", arr)
        }
    }

    fun getQuarantineListJson(): JSONObject {
        val arr = JSONArray()
        quarantinedFiles.toList().reversed().forEach { arr.put(it.toJson()) }
        return JSONObject().apply {
            put("success", true)
            put("count", arr.length())
            put("quarantineDirectory", quarantineDir.absolutePath)
            put("quarantinedFiles", arr)
        }
    }

    /**
     * Diagnostic evaluator for testing any URL, domain, search query, or package name against all channels.
     */
    fun testTargetAgainstShieldJson(rawTarget: String): JSONObject {
        val target = rawTarget.trim()
        if (target.isEmpty()) {
            return JSONObject().put("success", false).put("error", "Target cannot be empty")
        }

        val vipBytes = getSafeSearchVipForDomain(target)
        val vipIp = vipBytes?.joinToString(".") { (it.toInt() and 0xFF).toString() }.orEmpty()

        val urlOrQueryVerdict = evaluateUrlOrSearchQuery(target)
        val rawSearchVerdict = evaluateRawSearchText(target)
        val pkgVerdict = evaluateInstalledOrLaunchingPackage(target, target)

        val netMod = com.kavach.network.NetworkModerationManager.activeInstance
        val (domainBlocked, domainReason) = netMod?.checkUrlOrDomainBlocked(target) ?: (false to "")

        val finalBlocked = urlOrQueryVerdict.blocked || rawSearchVerdict.blocked || pkgVerdict.blocked || domainBlocked
        val primaryChannel = when {
            urlOrQueryVerdict.blocked -> urlOrQueryVerdict.channel
            rawSearchVerdict.blocked -> rawSearchVerdict.channel
            pkgVerdict.blocked -> pkgVerdict.channel
            domainBlocked -> "WEB_VIDEO"
            vipIp.isNotEmpty() -> "SAFESEARCH_VIP"
            else -> "CLEAN"
        }
        val primaryReason = when {
            urlOrQueryVerdict.blocked -> urlOrQueryVerdict.reason
            rawSearchVerdict.blocked -> rawSearchVerdict.reason
            pkgVerdict.blocked -> pkgVerdict.reason
            domainBlocked -> domainReason
            vipIp.isNotEmpty() -> "Rewritten to SafeSearch VIP ($vipIp)"
            else -> "Allowed (Clean)"
        }

        return JSONObject().apply {
            put("success", true)
            put("target", target)
            put("blocked", finalBlocked)
            put("channel", primaryChannel)
            put("reason", primaryReason)
            put("safeSearchVipRewriteIp", vipIp)
        }
    }

    private fun containsSafeAllowlistedWord(text: String): Boolean {
        val lower = text.lowercase(Locale.US)
        return SAFE_SUBSTRING_ALLOWLIST.any { lower.contains(it) }
    }

    private fun containsBoundedPhrase(text: String, phrase: String): Boolean {
        if (!text.contains(phrase)) return false
        if (phrase.contains(" ") || phrase.contains(".") || phrase.contains("-")) return true
        val regex = boundedRegexCache.getOrPut("wb_$phrase") {
            Regex("\\b${Regex.escape(phrase)}\\b", RegexOption.IGNORE_CASE)
        }
        return regex.containsMatchIn(text)
    }

    private fun containsBoundedFilenameToken(fileNameLower: String, token: String): Boolean {
        if (!fileNameLower.contains(token)) return false
        val regex = boundedRegexCache.getOrPut("fn_$token") {
            Regex("(^|[^a-z0-9])${Regex.escape(token)}([^a-z0-9]|$)")
        }
        return regex.containsMatchIn(fileNameLower)
    }
}
