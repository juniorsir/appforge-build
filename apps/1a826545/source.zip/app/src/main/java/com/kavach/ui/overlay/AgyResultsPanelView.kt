package com.kavach.ui.overlay

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.util.AttributeSet
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * Interactive Summary Card + Horizontal Swipe Media/File Carousel rendered inside Window 3
 * (`agy_task_map`) when `taskMap.mode == "results"`.
 */
class AgyResultsPanelView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : LinearLayout(context, attrs, defStyleAttr) {

    var onItemClicked: ((List<AgyHudDynamicModels.ResultMediaItem>, Int) -> Unit)? = null
    var onVideoItemClicked: ((AgyHudDynamicModels.ResultMediaItem) -> Unit)? = null

    private val density: Float get() = context.resources.displayMetrics.density
    private val mainHandler = Handler(Looper.getMainLooper())

    private var currentConfig: AgyHudDynamicModels.TaskMapConfig = AgyHudDynamicModels.TaskMapConfig()
    private var currentTheme: AgyHudDynamicModels.ResolvedHudTheme =
        AgyHudDynamicModels.resolveTheme(AgyHudDynamicModels.HudThemeConfig(), Color.parseColor("#0095F6"))
    private var lastSignature: String = ""
    private var currentItems: List<AgyHudDynamicModels.ResultMediaItem> = emptyList()
    private var currentIndex: Int = 0
    private var summaryExpanded: Boolean = false
    private var carouselPageWidthPx: Int = 0

    // Summary Card Views (kept View.GONE so text answers remain strictly in Main HUD)
    private val summaryCard: LinearLayout
    private val metaRow: LinearLayout
    private val queryChipText: TextView
    private val sourceLabelText: TextView
    private val summaryTitleText: TextView
    private val summaryBodyText: TextView
    private val summaryMoreBtn: TextView
    private val loadingRow: LinearLayout
    private val loadingLabel: TextView

    // Carousel Views
    private val carouselSection: LinearLayout
    private val carouselPager: HorizontalScrollView
    private val carouselTrack: LinearLayout
    private val cardWrappers = mutableListOf<View>()
    private val footerNavRow: LinearLayout
    private val prevArrowBtn: AgyAppleVectorIconView
    private val dotsContainer: LinearLayout
    private val counterBadgeText: TextView
    private val nextArrowBtn: AgyAppleVectorIconView

    init {
        val d = density
        orientation = VERTICAL
        tag = "${AgyHudOverlayManager.HUD_NODE_TAG_PREFIX}results_panel"
        contentDescription = "${AgyHudOverlayManager.HUD_NODE_TAG_PREFIX}results_panel"
        layoutParams = LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

        // 1. Summary Card above Carousel
        summaryCard = LinearLayout(context).apply {
            orientation = VERTICAL
            setPadding((9 * d).toInt(), (8 * d).toInt(), (9 * d).toInt(), (8 * d).toInt())
            layoutParams = LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                .apply { bottomMargin = (6 * d).toInt() }
        }

        metaRow = LinearLayout(context).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                .apply { bottomMargin = (4 * d).toInt() }
        }

        queryChipText = TextView(context).apply {
            textSize = 9.5f
            setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            setPadding((6 * d).toInt(), (2 * d).toInt(), (6 * d).toInt(), (2 * d).toInt())
            layoutParams = LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }

        sourceLabelText = TextView(context).apply {
            textSize = 8.5f
            typeface = Typeface.MONOSPACE
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            setPadding((5 * d).toInt(), (2 * d).toInt(), (5 * d).toInt(), (2 * d).toInt())
            layoutParams = LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                .apply { marginStart = (4 * d).toInt() }
        }
        metaRow.addView(queryChipText)
        metaRow.addView(sourceLabelText)
        summaryCard.addView(metaRow)

        summaryTitleText = TextView(context).apply {
            textSize = 12f
            setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
            layoutParams = LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                .apply { bottomMargin = (3 * d).toInt() }
        }
        summaryCard.addView(summaryTitleText)

        summaryBodyText = TextView(context).apply {
            textSize = 10.5f
            setLineSpacing(1.5f * d, 1.12f)
            maxLines = 4
            ellipsize = TextUtils.TruncateAt.END
            layoutParams = LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            setOnClickListener { toggleSummaryExpanded() }
        }
        summaryCard.addView(summaryBodyText)

        summaryMoreBtn = TextView(context).apply {
            text = "More ▾"
            textSize = 9.5f
            setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
            setPadding(0, (3 * d).toInt(), (4 * d).toInt(), 0)
            layoutParams = LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            visibility = View.GONE
            setOnClickListener { toggleSummaryExpanded() }
        }
        summaryCard.addView(summaryMoreBtn)

        loadingRow = LinearLayout(context).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                .apply { topMargin = (5 * d).toInt() }
            visibility = View.GONE
        }
        val spinner = ProgressBar(context).apply {
            layoutParams = LayoutParams((14 * d).toInt(), (14 * d).toInt()).apply { marginEnd = (6 * d).toInt() }
        }
        loadingLabel = TextView(context).apply {
            text = "Gathering results…"
            textSize = 9.5f
            typeface = Typeface.MONOSPACE
        }
        loadingRow.addView(spinner)
        loadingRow.addView(loadingLabel)
        summaryCard.addView(loadingRow)

        summaryCard.visibility = View.GONE
        addView(summaryCard)

        // 2. Swipeable Horizontal Media / File Carousel
        carouselSection = LinearLayout(context).apply {
            orientation = VERTICAL
            layoutParams = LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            visibility = View.GONE
        }

        carouselTrack = LinearLayout(context).apply {
            orientation = HORIZONTAL
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }

        var downX = 0f
        var downScrollX = 0
        carouselPager = object : HorizontalScrollView(context) {
            override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
                super.onSizeChanged(w, h, oldw, oldh)
                if (w > 0 && w != carouselPageWidthPx) {
                    carouselPageWidthPx = w
                    updateCarouselCardWidths()
                    post { snapToIndex(currentIndex, smooth = false) }
                }
            }
        }.apply {
            isHorizontalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            layoutParams = LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            addView(carouselTrack)
            setOnTouchListener { _, ev ->
                when (ev.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        downX = ev.rawX
                        downScrollX = scrollX
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        val pageW = resolvePageWidthPx()
                        if (pageW > 0 && currentItems.size > 1) {
                            val dx = downX - ev.rawX
                            val targetIdx = when {
                                abs(dx) > pageW * 0.18f -> {
                                    if (dx > 0) (currentIndex + 1).coerceAtMost(currentItems.lastIndex)
                                    else (currentIndex - 1).coerceAtLeast(0)
                                }
                                else -> ((scrollX.toFloat() / pageW.toFloat()).roundToInt())
                                    .coerceIn(0, currentItems.lastIndex)
                            }
                            post { selectIndex(targetIdx, smooth = true) }
                        }
                    }
                }
                false
            }
        }
        carouselSection.addView(carouselPager)

        // Footer Controls: [‹] [ • • • ] [1/N] [›]
        footerNavRow = LinearLayout(context).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                .apply { topMargin = (6 * d).toInt() }
        }

        fun navArrow(icon: AgyAppleVectorIconView.IconType, desc: String, delta: Int): AgyAppleVectorIconView {
            return AgyAppleVectorIconView(context, icon).apply {
                iconSizeDp = 12f
                minTouchSizeDp = 26f
                glassStyle = AgyAppleVectorIconView.GlassStyle.GLASS_CIRCLE
                layoutParams = LayoutParams((26 * d).toInt(), (26 * d).toInt())
                contentDescription = "${AgyHudOverlayManager.HUD_NODE_TAG_PREFIX}$desc"
                tag = "${AgyHudOverlayManager.HUD_NODE_TAG_PREFIX}$desc"
                setOnClickListener {
                    selectIndex((currentIndex + delta).coerceIn(0, (currentItems.size - 1).coerceAtLeast(0)), smooth = true)
                }
            }
        }

        prevArrowBtn = navArrow(AgyAppleVectorIconView.IconType.CHEVRON_LEFT, "results_prev", -1)
        dotsContainer = LinearLayout(context).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER
            layoutParams = LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        counterBadgeText = TextView(context).apply {
            textSize = 9.5f
            typeface = Typeface.MONOSPACE
            setPadding((6 * d).toInt(), (2 * d).toInt(), (6 * d).toInt(), (2 * d).toInt())
            layoutParams = LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                .apply { marginEnd = (4 * d).toInt() }
        }
        nextArrowBtn = navArrow(AgyAppleVectorIconView.IconType.CHEVRON_RIGHT, "results_next", 1)

        footerNavRow.addView(prevArrowBtn)
        footerNavRow.addView(dotsContainer)
        footerNavRow.addView(counterBadgeText)
        footerNavRow.addView(nextArrowBtn)
        carouselSection.addView(footerNavRow)

        addView(carouselSection)
    }

    fun getCurrentIndex(): Int = currentIndex
    fun getItemCount(): Int = currentItems.size
    fun isSummaryExpanded(): Boolean = summaryExpanded
    fun isSummaryCardVisible(): Boolean = summaryCard.visibility == View.VISIBLE

    fun toggleSummaryExpanded() {
        summaryExpanded = !summaryExpanded
        summaryBodyText.maxLines = if (summaryExpanded) 18 else 4
        summaryMoreBtn.text = if (summaryExpanded) "Less" else "More"
    }

    fun selectIndex(index: Int, smooth: Boolean = true) {
        if (currentItems.isEmpty()) return
        currentIndex = index.coerceIn(0, currentItems.lastIndex)
        snapToIndex(currentIndex, smooth)
        updateFooterIndicators()
    }

    fun updateResults(
        config: AgyHudDynamicModels.TaskMapConfig,
        theme: AgyHudDynamicModels.ResolvedHudTheme
    ) {
        currentConfig = config
        currentTheme = theme
        val data = config.results ?: AgyHudDynamicModels.ResultsTaskMapData(
            query = config.title,
            summaryTitle = config.title.ifBlank { "Results" },
            summaryText = "No results payload provided."
        )
        val sig = data.contentSignature()
        val dataChanged = sig != lastSignature
        lastSignature = sig

        val d = density
        if (carouselPageWidthPx <= 0) {
            carouselPageWidthPx = ((config.widthDp - 18f).coerceAtLeast(130f) * d).toInt()
        }

        // Left window is strictly Visuals & Media only — text summaries belong in Main HUD
        summaryCard.visibility = View.GONE
        loadingRow.visibility = View.GONE

        // Rebuild carousel if items changed or theme/width updated
        currentItems = data.items
        if (currentItems.isEmpty()) {
            carouselSection.visibility = View.GONE
            carouselTrack.removeAllViews()
            cardWrappers.clear()
            currentIndex = 0
            return
        }

        carouselSection.visibility = View.VISIBLE
        if (dataChanged) {
            if (currentIndex > currentItems.lastIndex) {
                currentIndex = 0
            }
            rebuildCarouselCards(theme)
        } else {
            updateCarouselCardWidths()
        }
        updateFooterIndicators()
        mainHandler.post { snapToIndex(currentIndex, smooth = false) }
    }

    private fun resolvePageWidthPx(): Int {
        val measuredW = carouselPager.width
        if (measuredW > 0) return measuredW
        if (carouselPageWidthPx > 0) return carouselPageWidthPx
        val d = density
        return ((currentConfig.widthDp - 18f).coerceAtLeast(140f) * d).toInt()
    }

    private fun rebuildCarouselCards(theme: AgyHudDynamicModels.ResolvedHudTheme) {
        val d = density
        val pageW = resolvePageWidthPx()
        carouselTrack.removeAllViews()
        cardWrappers.clear()

        currentItems.forEachIndexed { idx, item ->
            val card = LinearLayout(context).apply {
                orientation = VERTICAL
                setPadding((7 * d).toInt(), (7 * d).toInt(), (7 * d).toInt(), (8 * d).toInt())
                layoutParams = LayoutParams(pageW, ViewGroup.LayoutParams.WRAP_CONTENT)
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = 12f * d
                    setColor(theme.secondarySurface)
                    setStroke((0.9f * d).toInt().coerceAtLeast(1), theme.border)
                }
                tag = "${AgyHudOverlayManager.HUD_NODE_TAG_PREFIX}result_card_$idx"
                contentDescription = "${AgyHudOverlayManager.HUD_NODE_TAG_PREFIX}result_card_$idx"
                setOnClickListener {
                    if (item.kind == "video" && onVideoItemClicked != null) {
                        onVideoItemClicked?.invoke(item)
                    } else {
                        onItemClicked?.invoke(currentItems, idx)
                    }
                }
            }

            // Preview frame
            val previewFrame = FrameLayout(context).apply {
                layoutParams = LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (132 * d).toInt())
                    .apply { bottomMargin = (6 * d).toInt() }
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = 11f * d
                    setColor(if (theme.isDark) Color.parseColor("#FF020617") else Color.parseColor("#FFE2E8F0"))
                }
                clipChildren = true
                clipToPadding = true
            }

            val imgView = ImageView(context).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                layoutParams = FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
            }
            previewFrame.addView(imgView)

            val fileExcerptTv = TextView(context).apply {
                visibility = View.GONE
            }
            previewFrame.addView(fileExcerptTv)

            val fallbackCenterIcon = AgyAppleVectorIconView(
                context,
                if (item.kind == "image") AgyAppleVectorIconView.IconType.PHOTO_STACK else AgyAppleVectorIconView.IconType.LIST_BULLET
            ).apply {
                glassStyle = AgyAppleVectorIconView.GlassStyle.GLASS_CIRCLE
                glassFillColor = if (theme.isDark) Color.parseColor("#661E293B") else Color.parseColor("#CCFFFFFF")
                glassBorderColor = theme.border
                iconTint = theme.textSecondary
                iconSizeDp = 22f
                minTouchSizeDp = 44f
                isClickable = false
                layoutParams = FrameLayout.LayoutParams((44 * d).toInt(), (44 * d).toInt(), Gravity.CENTER)
                visibility = View.GONE
            }
            previewFrame.addView(fallbackCenterIcon)

            if (item.kind == "video") {
                val playPill = AgyAppleVectorIconView(context, AgyAppleVectorIconView.IconType.PLAY_FILL).apply {
                    iconSizeDp = 17f
                    minTouchSizeDp = 40f
                    glassStyle = AgyAppleVectorIconView.GlassStyle.ACCENT_CIRCLE
                    accentColor = Color.parseColor("#CC0F172A")
                    iconTint = Color.WHITE
                    isClickable = false
                    layoutParams = FrameLayout.LayoutParams((40 * d).toInt(), (40 * d).toInt(), Gravity.CENTER)
                }
                previewFrame.addView(playPill)
            }

            val badgeColor = when (item.kind) {
                "video" -> Color.parseColor("#FFE11D48")
                "file" -> Color.parseColor("#FFD97706")
                else -> theme.accent
            }
            val kindChip = TextView(context).apply {
                text = AgyResultsMediaLoader.fileExtensionBadge(item)
                textSize = 8.5f
                setTypeface(Typeface.MONOSPACE, Typeface.BOLD)
                setTextColor(Color.WHITE)
                setPadding((5 * d).toInt(), (2 * d).toInt(), (5 * d).toInt(), (2 * d).toInt())
                layoutParams = FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    Gravity.TOP or Gravity.START
                ).apply {
                    leftMargin = (6 * d).toInt()
                    topMargin = (6 * d).toInt()
                }
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = 5f * d
                    setColor(badgeColor)
                }
            }
            previewFrame.addView(kindChip)

            val expandHint = AgyAppleVectorIconView(context, AgyAppleVectorIconView.IconType.ARROW_EXPAND).apply {
                iconSizeDp = 11f
                minTouchSizeDp = 24f
                glassStyle = AgyAppleVectorIconView.GlassStyle.GLASS_CIRCLE
                glassFillColor = Color.parseColor("#990F172A")
                glassBorderColor = Color.parseColor("#44FFFFFF")
                iconTint = Color.WHITE
                isClickable = false
                layoutParams = FrameLayout.LayoutParams((24 * d).toInt(), (24 * d).toInt(), Gravity.TOP or Gravity.END).apply {
                    rightMargin = (6 * d).toInt()
                    topMargin = (6 * d).toInt()
                }
            }
            previewFrame.addView(expandHint)

            // Populate visual preview asynchronously
            when (item.kind) {
                "image", "video" -> {
                    fallbackCenterIcon.visibility = if (item.kind == "video") View.GONE else View.VISIBLE
                    AgyResultsMediaLoader.loadPreviewBitmap(context, item, maxDimensionPx = 480) { bmp ->
                        if (bmp != null) {
                            imgView.setImageBitmap(bmp)
                            fallbackCenterIcon.visibility = View.GONE
                        }
                    }
                }
                else -> {
                    imgView.visibility = View.GONE
                    fallbackCenterIcon.visibility = View.VISIBLE
                }
            }

            card.addView(previewFrame)

            // Title & Subtitle below preview
            val cardTitle = TextView(context).apply {
                text = item.title
                textSize = 11f
                setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
                setTextColor(theme.textPrimary)
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
            }
            card.addView(cardTitle)

            val subLabel = buildString {
                if (item.subtitle.isNotBlank()) append(item.subtitle)
                if (item.fileSizeLabel.isNotBlank()) {
                    if (isNotEmpty()) append(" • ")
                    append(item.fileSizeLabel)
                }
            }
            if (subLabel.isNotBlank()) {
                val cardSub = TextView(context).apply {
                    text = subLabel
                    textSize = 9.5f
                    setTextColor(theme.textSecondary)
                    maxLines = 1
                    ellipsize = TextUtils.TruncateAt.END
                    layoutParams = LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                        .apply { topMargin = (1 * d).toInt() }
                }
                card.addView(cardSub)
            }

            carouselTrack.addView(card)
            cardWrappers.add(card)
        }
    }

    private fun updateCarouselCardWidths() {
        val pageW = resolvePageWidthPx()
        if (pageW <= 0) return
        cardWrappers.forEach { child ->
            val lp = child.layoutParams ?: LayoutParams(pageW, ViewGroup.LayoutParams.WRAP_CONTENT)
            if (lp.width != pageW) {
                lp.width = pageW
                child.layoutParams = lp
            }
        }
    }

    private fun snapToIndex(index: Int, smooth: Boolean) {
        val pageW = resolvePageWidthPx()
        if (pageW <= 0) return
        val targetX = index.coerceIn(0, (currentItems.size - 1).coerceAtLeast(0)) * pageW
        if (smooth) {
            carouselPager.smoothScrollTo(targetX, 0)
        } else {
            carouselPager.scrollTo(targetX, 0)
        }
    }

    private fun updateFooterIndicators() {
        val d = density
        val count = currentItems.size
        val multi = count > 1
        footerNavRow.visibility = if (multi) View.VISIBLE else View.GONE
        if (!multi) return

        fun styleArrow(btn: AgyAppleVectorIconView, enabled: Boolean) {
            btn.isEnabled = enabled
            btn.alpha = if (enabled) 1f else 0.35f
            btn.accentColor = currentTheme.accent
            btn.glassStyle = AgyAppleVectorIconView.GlassStyle.GLASS_CIRCLE
            btn.glassFillColor = currentTheme.secondarySurface
            btn.glassBorderColor = currentTheme.border
            btn.iconTint = currentTheme.textPrimary
        }
        styleArrow(prevArrowBtn, currentIndex > 0)
        styleArrow(nextArrowBtn, currentIndex < count - 1)

        counterBadgeText.apply {
            text = "${currentIndex + 1}/$count"
            setTextColor(currentTheme.textSecondary)
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = 999f * d
                setColor(currentTheme.secondarySurface)
            }
        }

        dotsContainer.removeAllViews()
        val maxDots = count.coerceAtMost(8)
        val dotWindowStart = if (count <= maxDots) 0 else (currentIndex - maxDots / 2).coerceIn(0, count - maxDots)
        for (i in dotWindowStart until (dotWindowStart + maxDots)) {
            val selected = i == currentIndex
            val dot = View(context).apply {
                val w = ((if (selected) 14f else 5f) * d).toInt()
                val h = (5f * d).toInt()
                layoutParams = LayoutParams(w, h).apply {
                    marginStart = (2 * d).toInt()
                    marginEnd = (2 * d).toInt()
                }
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = 999f * d
                    setColor(if (selected) currentTheme.accent else currentTheme.border)
                }
                setOnClickListener { selectIndex(i, smooth = true) }
            }
            dotsContainer.addView(dot)
        }
    }
}
