package com.kavach.presentation.permissions

import android.app.Activity
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CameraAlt
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.LockOpen
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.OpenInNew
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material.icons.rounded.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.kavach.capabilities.permissions.PermissionCategory
import com.kavach.capabilities.permissions.PermissionItem
import com.kavach.capabilities.permissions.PermissionManager
import com.kavach.capabilities.permissions.PermissionState
import com.kavach.capabilities.permissions.SpecialSettingType
import com.kavach.ui.theme.AuraColors
import com.kavach.ui.theme.AuraTypography
import com.kavach.ui.theme.CrispBlue
import com.kavach.ui.theme.CrispBorder
import com.kavach.ui.theme.CrispEmerald
import com.kavach.ui.theme.CrispHairline
import com.kavach.ui.theme.CrispIndigo
import com.kavach.ui.theme.CrispPillSwitch
import com.kavach.ui.theme.CrispSurfaceSubtle
import com.kavach.ui.theme.LiquidGlassTokens
import com.kavach.ui.theme.LiquidIconOrb

private val EmeraldAccent = CrispEmerald
private val CyanAccent = CrispBlue
private val VioletAccent = CrispIndigo

/**
 * High-performance, full-spectrum 45+ Permission & Capability Access Hub
 * styled with Dark Obsidian Liquid Glass (28.dp modal, 50% full-pill search & buttons, glowing icon orbs).
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PermissionsManagerDialog(
    onDismissRequest: () -> Unit,
    permissionManager: PermissionManager,
    onOpenCameraStation: () -> Unit = {},
    onOpenMicStation: () -> Unit = {},
    onOpenNotifStation: () -> Unit = {},
    onOpenStorageStation: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val activity = context as? Activity

    var refreshNonce by remember { mutableIntStateOf(0) }
    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf<PermissionCategory?>(null) }
    var showOnlyMissing by remember { mutableStateOf(false) }

    val lifecycleOwner = androidx.lifecycle.compose.LocalLifecycleOwner.current
    androidx.compose.runtime.DisposableEffect(lifecycleOwner) {
        val observer = androidx.lifecycle.LifecycleEventObserver { _, event ->
            if (event == androidx.lifecycle.Lifecycle.Event.ON_RESUME) {
                refreshNonce++
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    val batchPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        val grantedCount = results.values.count { it }
        Toast.makeText(
            context,
            "Granted $grantedCount of ${results.size} requested permissions",
            Toast.LENGTH_SHORT
        ).show()
        refreshNonce++
    }

    val singlePermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { _ ->
        refreshNonce++
    }

    val allPermissions = permissionManager.allDefinedPermissions

    val evaluatedPermissions = remember(refreshNonce, allPermissions) {
        allPermissions
            .map { item -> item to permissionManager.getPermissionItemState(item, activity) }
            .filter { (_, state) ->
                state != PermissionState.NOT_REQUIRED && state != PermissionState.HARDWARE_UNAVAILABLE
            }
            .sortedWith(
                compareBy<Pair<PermissionItem, PermissionState>>(
                    { (_, state) -> state == PermissionState.GRANTED },
                    { (item, _) -> !(item.isRuntime || item.specialSettingType != SpecialSettingType.NONE) },
                    { (item, _) -> item.specialSettingType == SpecialSettingType.NONE }
                )
            )
    }

    val totalCount = evaluatedPermissions.size
    val grantedCount = evaluatedPermissions.count { it.second == PermissionState.GRANTED }
    val missingCount = evaluatedPermissions.count { it.second == PermissionState.DENIED }
    val missingRuntimeList = remember(refreshNonce, evaluatedPermissions) {
        permissionManager.getRuntimePermissionsToRequest()
    }
    val missingRuntimeCount = missingRuntimeList.size
    val progressFraction = if (totalCount > 0) grantedCount.toFloat() / totalCount else 1f

    val filteredList = evaluatedPermissions.filter { (item, state) ->
        val matchesCategory = selectedCategory == null || item.category == selectedCategory
        val matchesQuery = searchQuery.isEmpty() ||
                item.displayName.contains(searchQuery, ignoreCase = true) ||
                item.permission.contains(searchQuery, ignoreCase = true) ||
                item.category.displayName.contains(searchQuery, ignoreCase = true)
        val matchesMissing = !showOnlyMissing || (state == PermissionState.DENIED)

        matchesCategory && matchesQuery && matchesMissing
    }

    Dialog(
        onDismissRequest = onDismissRequest,
        properties = DialogProperties(
            usePlatformDefaultWidth = false,
            dismissOnBackPress = true,
            dismissOnClickOutside = true
        )
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0x660F172A))
                .padding(horizontal = 12.dp, vertical = 18.dp),
            contentAlignment = Alignment.Center
        ) {
            Surface(
                modifier = modifier
                    .fillMaxWidth()
                    .widthIn(max = 680.dp)
                    .fillMaxHeight(0.92f)
                    .clip(RoundedCornerShape(28.dp)),
                shape = RoundedCornerShape(28.dp),
                border = LiquidGlassTokens.specularBorder(
                    primaryTint = CyanAccent,
                    secondaryTint = VioletAccent,
                    width = 1.2.dp
                ),
                color = LiquidGlassTokens.GlassModalFill
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(LiquidGlassTokens.TopRefractionSheen)
                ) {
                    // Liquid Glass Top Header Bar
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 18.dp, vertical = 14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            modifier = Modifier.weight(1f),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            LiquidIconOrb(
                                icon = Icons.Rounded.Shield,
                                tint = EmeraldAccent,
                                size = 40.dp,
                                iconSize = 20.dp,
                                isCircle = true
                            )

                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(
                                    text = "Permissions",
                                    style = AuraTypography.SectionTitle.copy(fontSize = 18.sp, fontWeight = FontWeight.Bold),
                                    color = AuraColors.TextPrimary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Surface(
                                    shape = RoundedCornerShape(50),
                                    color = (if (missingCount == 0) EmeraldAccent else AuraColors.StatusWarning).copy(alpha = 0.16f),
                                    border = BorderStroke(
                                        0.8.dp,
                                        (if (missingCount == 0) EmeraldAccent else AuraColors.StatusWarning).copy(alpha = 0.45f)
                                    )
                                ) {
                                    Text(
                                        text = "$grantedCount/$totalCount",
                                        style = AuraTypography.TechnicalMono.copy(fontSize = 11.sp, fontWeight = FontWeight.Bold),
                                        color = if (missingCount == 0) EmeraldAccent else AuraColors.StatusWarning,
                                        maxLines = 1,
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.width(8.dp))

                        IconButton(
                            onClick = onDismissRequest,
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(CrispSurfaceSubtle)
                                .border(1.dp, CrispHairline, CircleShape)
                                .testTag("close_permissions_dialog_button")
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Close,
                                contentDescription = "Close",
                                tint = AuraColors.TextPrimary,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    // Progress & Instagram-Style Full-Pill Action Buttons
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 18.dp, vertical = 6.dp)
                    ) {
                        LinearProgressIndicator(
                            progress = { progressFraction },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .clip(RoundedCornerShape(50)),
                            color = EmeraldAccent,
                            trackColor = AuraColors.BorderSubtle
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Button(
                                onClick = {
                                    if (missingRuntimeList.isNotEmpty()) {
                                        batchPermissionLauncher.launch(missingRuntimeList.toTypedArray())
                                    } else {
                                        val firstMissingSpecial = evaluatedPermissions.firstOrNull {
                                            it.second == PermissionState.DENIED && it.first.specialSettingType != SpecialSettingType.NONE
                                        }?.first
                                        if (firstMissingSpecial != null) {
                                            showOnlyMissing = true
                                            try {
                                                context.startActivity(permissionManager.createSpecialIntent(firstMissingSpecial))
                                            } catch (_: Exception) {}
                                        } else {
                                            Toast.makeText(context, "All permissions are active!", Toast.LENGTH_SHORT).show()
                                        }
                                    }
                                },
                                modifier = Modifier
                                    .weight(1.2f)
                                    .height(46.dp)
                                    .testTag("batch_grant_permissions_button"),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = EmeraldAccent,
                                    contentColor = Color.White
                                ),
                                shape = RoundedCornerShape(50)
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.LockOpen,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = when {
                                        missingRuntimeCount > 0 -> "Grant ($missingRuntimeCount)"
                                        missingCount > 0 -> "Enable ($missingCount)"
                                        else -> "Active"
                                    },
                                    style = AuraTypography.ButtonLabel.copy(fontSize = 12.sp, fontWeight = FontWeight.Bold),
                                    maxLines = 1
                                )
                            }

                            OutlinedButton(
                                onClick = {
                                    try {
                                        context.startActivity(permissionManager.createAppSettingsIntent())
                                    } catch (e: Exception) {
                                        Toast.makeText(context, "Could not open settings", Toast.LENGTH_SHORT).show()
                                    }
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(46.dp)
                                    .testTag("open_app_settings_button"),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    contentColor = AuraColors.TextPrimary
                                ),
                                border = BorderStroke(1.dp, CyanAccent.copy(alpha = 0.45f)),
                                shape = RoundedCornerShape(50)
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Settings,
                                    contentDescription = null,
                                    modifier = Modifier.size(15.dp),
                                    tint = CyanAccent
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Settings",
                                    style = AuraTypography.ButtonLabel.copy(fontSize = 12.sp),
                                    maxLines = 1
                                )
                            }
                        }
                    }

                    val isCameraActive = remember(refreshNonce) { permissionManager.hasPermission(android.Manifest.permission.CAMERA) }
                    val isMicActive = remember(refreshNonce) { permissionManager.hasPermission(android.Manifest.permission.RECORD_AUDIO) }
                    val isNotifActive = remember(refreshNonce) {
                        if (android.os.Build.VERSION.SDK_INT >= 33) permissionManager.hasPermission("android.permission.POST_NOTIFICATIONS") else true
                    }
                    val isStorageActive = remember(refreshNonce) {
                        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
                            android.os.Environment.isExternalStorageManager()
                        } else {
                            permissionManager.hasPermission(android.Manifest.permission.READ_EXTERNAL_STORAGE)
                        }
                    }

                    // 1-Row Liquid Glass Station Quick Capsules
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 18.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        StationQuickCard(
                            label = "Camera",
                            icon = Icons.Rounded.CameraAlt,
                            isActive = isCameraActive,
                            activeColor = CyanAccent,
                            onClick = onOpenCameraStation,
                            modifier = Modifier.weight(1f)
                        )
                        StationQuickCard(
                            label = "Mic",
                            icon = Icons.Rounded.Mic,
                            isActive = isMicActive,
                            activeColor = Color(0xFFF59E0B),
                            onClick = onOpenMicStation,
                            modifier = Modifier.weight(1f)
                        )
                        StationQuickCard(
                            label = "Notif",
                            icon = Icons.Rounded.Notifications,
                            isActive = isNotifActive,
                            activeColor = VioletAccent,
                            onClick = onOpenNotifStation,
                            modifier = Modifier.weight(1f)
                        )
                        StationQuickCard(
                            label = "Storage",
                            icon = Icons.Rounded.Folder,
                            isActive = isStorageActive,
                            activeColor = EmeraldAccent,
                            onClick = onOpenStorageStation,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    // Instagram-Style Full-Pill Search & Filter Controls
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 18.dp, vertical = 8.dp)
                    ) {
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { searchQuery = it },
                            placeholder = {
                                Text(
                                    text = "Search permissions...",
                                    style = AuraTypography.BodyMedium.copy(fontSize = 13.sp),
                                    color = AuraColors.TextMuted
                                )
                            },
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Rounded.Search,
                                    contentDescription = null,
                                    tint = CyanAccent,
                                    modifier = Modifier.size(18.dp)
                                )
                            },
                            trailingIcon = {
                                if (searchQuery.isNotEmpty()) {
                                    IconButton(onClick = { searchQuery = "" }) {
                                        Icon(
                                            imageVector = Icons.Rounded.Close,
                                            contentDescription = "Clear search",
                                            tint = AuraColors.TextMuted,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                            },
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                                .testTag("permissions_search_field"),
                            shape = RoundedCornerShape(50),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = CyanAccent,
                                unfocusedBorderColor = CrispBorder,
                                focusedContainerColor = LiquidGlassTokens.GlassPillInputFill,
                                unfocusedContainerColor = LiquidGlassTokens.GlassPillInputFill,
                                focusedTextColor = AuraColors.TextPrimary,
                                unfocusedTextColor = AuraColors.TextPrimary
                            )
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        // Full-Pill Filter Chips Row
                        LazyRow(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            contentPadding = PaddingValues(vertical = 2.dp)
                        ) {
                            item {
                                FilterChip(
                                    selected = selectedCategory == null && !showOnlyMissing,
                                    onClick = {
                                        selectedCategory = null
                                        showOnlyMissing = false
                                    },
                                    shape = RoundedCornerShape(50),
                                    label = { Text("All ($totalCount)", fontSize = 11.sp) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = CyanAccent.copy(alpha = 0.2f),
                                        selectedLabelColor = CyanAccent,
                                        containerColor = LiquidGlassTokens.GlassCapsuleFill,
                                        labelColor = AuraColors.TextSecondary
                                    ),
                                    border = FilterChipDefaults.filterChipBorder(
                                        enabled = true,
                                        selected = selectedCategory == null && !showOnlyMissing,
                                        borderColor = AuraColors.BorderSubtle,
                                        selectedBorderColor = CyanAccent
                                    )
                                )
                            }

                            item {
                                FilterChip(
                                    selected = showOnlyMissing,
                                    onClick = { showOnlyMissing = !showOnlyMissing },
                                    shape = RoundedCornerShape(50),
                                    label = { Text("Missing ($missingCount)", fontSize = 11.sp) },
                                    leadingIcon = {
                                        Icon(
                                            imageVector = Icons.Rounded.Warning,
                                            contentDescription = null,
                                            modifier = Modifier.size(13.dp),
                                            tint = if (showOnlyMissing) AuraColors.StatusWarning else AuraColors.TextMuted
                                        )
                                    },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = AuraColors.StatusWarning.copy(alpha = 0.2f),
                                        selectedLabelColor = AuraColors.StatusWarning,
                                        containerColor = LiquidGlassTokens.GlassCapsuleFill,
                                        labelColor = AuraColors.TextSecondary
                                    ),
                                    border = FilterChipDefaults.filterChipBorder(
                                        enabled = true,
                                        selected = showOnlyMissing,
                                        borderColor = AuraColors.BorderSubtle,
                                        selectedBorderColor = AuraColors.StatusWarning
                                    )
                                )
                            }

                            items(PermissionCategory.values()) { category ->
                                val categoryCount = evaluatedPermissions.count { it.first.category == category }
                                if (categoryCount > 0) {
                                    FilterChip(
                                        selected = selectedCategory == category,
                                        onClick = {
                                            selectedCategory = if (selectedCategory == category) null else category
                                        },
                                        shape = RoundedCornerShape(50),
                                        label = { Text("${category.displayName} ($categoryCount)", fontSize = 11.sp) },
                                        colors = FilterChipDefaults.filterChipColors(
                                            selectedContainerColor = EmeraldAccent.copy(alpha = 0.2f),
                                            selectedLabelColor = EmeraldAccent,
                                            containerColor = LiquidGlassTokens.GlassCapsuleFill,
                                            labelColor = AuraColors.TextSecondary
                                        ),
                                        border = FilterChipDefaults.filterChipBorder(
                                            enabled = true,
                                            selected = selectedCategory == category,
                                            borderColor = AuraColors.BorderSubtle,
                                            selectedBorderColor = EmeraldAccent
                                        )
                                    )
                                }
                            }
                        }
                    }

                    // Permissions List
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                            .padding(horizontal = 18.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        contentPadding = PaddingValues(top = 4.dp, bottom = 18.dp)
                    ) {
                        if (filteredList.isEmpty()) {
                            item {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 32.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "Empty",
                                        style = AuraTypography.BodyMedium,
                                        color = AuraColors.TextMuted
                                    )
                                }
                            }
                        } else {
                            items(
                                items = filteredList,
                                key = { it.first.id }
                            ) { (item, state) ->
                                PermissionItemCard(
                                    item = item,
                                    state = state,
                                    onToggle = { enable ->
                                        if (item.isRuntime) {
                                            if (enable) {
                                                singlePermissionLauncher.launch(item.permission)
                                            } else {
                                                try {
                                                    context.startActivity(permissionManager.createAppSettingsIntent())
                                                } catch (_: Exception) {}
                                            }
                                        } else if (item.specialSettingType != SpecialSettingType.NONE) {
                                            try {
                                                context.startActivity(permissionManager.createSpecialIntent(item))
                                            } catch (_: Exception) {}
                                        } else {
                                            try {
                                                context.startActivity(permissionManager.createAppSettingsIntent())
                                            } catch (_: Exception) {}
                                        }
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PermissionItemCard(
    item: PermissionItem,
    state: PermissionState,
    onToggle: (Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    val isGranted = state == PermissionState.GRANTED || state == PermissionState.NOT_REQUIRED
    val isInteractive = item.isRuntime || item.specialSettingType != SpecialSettingType.NONE

    val cardBorderColor by animateColorAsState(
        targetValue = when {
            !isGranted -> AuraColors.StatusWarning.copy(alpha = 0.5f)
            isInteractive -> EmeraldAccent.copy(alpha = 0.35f)
            else -> AuraColors.BorderSubtle
        },
        label = "cardBorderColor"
    )

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("permission_card_${item.id}")
            .clickable(enabled = isInteractive) {
                onToggle(!isGranted)
            },
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = LiquidGlassTokens.GlassCapsuleFill
        ),
        border = CardDefaults.outlinedCardBorder().copy(
            brush = androidx.compose.ui.graphics.SolidColor(cardBorderColor)
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = item.displayName,
                    style = AuraTypography.SectionTitle.copy(fontSize = 14.sp, fontWeight = FontWeight.SemiBold),
                    color = AuraColors.TextPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                Spacer(modifier = Modifier.height(2.dp))

                Text(
                    text = item.category.displayName,
                    style = AuraTypography.TechnicalMono.copy(fontSize = 10.sp),
                    color = AuraColors.TextMuted,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            Spacer(modifier = Modifier.width(10.dp))

            if (isInteractive) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    if (item.specialSettingType != SpecialSettingType.NONE) {
                        Icon(
                            imageVector = Icons.Rounded.OpenInNew,
                            contentDescription = "System Setting",
                            modifier = Modifier.size(14.dp),
                            tint = if (isGranted) EmeraldAccent else AuraColors.StatusWarning
                        )
                    }

                    CrispPillSwitch(
                        checked = isGranted,
                        onCheckedChange = { onToggle(it) },
                        checkedTrackColor = EmeraldAccent,
                        switchContentDescription = "Toggle ${item.displayName}",
                        modifier = Modifier.testTag("permission_toggle_${item.id}")
                    )
                }
            } else {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    modifier = Modifier
                        .clip(RoundedCornerShape(50))
                        .background(EmeraldAccent.copy(alpha = 0.14f))
                        .border(1.dp, EmeraldAccent.copy(alpha = 0.35f), RoundedCornerShape(50))
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Check,
                        contentDescription = "Enabled",
                        tint = EmeraldAccent,
                        modifier = Modifier.size(12.dp)
                    )
                    Text(
                        text = "Active",
                        style = AuraTypography.TechnicalLabel.copy(fontSize = 10.sp, fontWeight = FontWeight.Bold),
                        color = EmeraldAccent
                    )
                }
            }
        }
    }
}

@Composable
private fun StationQuickCard(
    label: String,
    icon: ImageVector,
    isActive: Boolean,
    activeColor: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        color = LiquidGlassTokens.GlassCapsuleFill,
        shape = RoundedCornerShape(18.dp),
        border = BorderStroke(1.dp, if (isActive) activeColor.copy(alpha = 0.55f) else AuraColors.BorderSubtle),
        modifier = modifier
            .height(60.dp)
            .clip(RoundedCornerShape(18.dp))
            .clickable(onClick = onClick)
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(7.dp)
                    .size(6.dp)
                    .clip(CircleShape)
                    .background(if (isActive) activeColor else AuraColors.StatusWarning)
            )
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 6.dp, vertical = 6.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = label,
                    tint = if (isActive) activeColor else AuraColors.TextMuted,
                    modifier = Modifier.size(19.dp)
                )
                Spacer(modifier = Modifier.height(3.dp))
                Text(
                    text = label,
                    style = AuraTypography.ButtonLabel.copy(fontSize = 11.sp, fontWeight = FontWeight.SemiBold),
                    color = AuraColors.TextPrimary,
                    maxLines = 1
                )
            }
        }
    }
}
