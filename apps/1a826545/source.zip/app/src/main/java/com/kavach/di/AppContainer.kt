package com.kavach.di

import android.content.Context
import android.media.AudioManager
import android.os.BatteryManager
import android.app.ActivityManager
import android.net.wifi.WifiManager
import android.net.ConnectivityManager
import android.content.pm.PackageManager
import android.content.pm.ApplicationInfo
import android.provider.Settings
import androidx.core.content.ContextCompat
import android.Manifest
import androidx.room.Room
import com.kavach.data.local.CompanionDatabase
import com.kavach.data.remote.RealtimeWebSocketClient
import com.kavach.data.remote.RealtimeWebSocketClientStub
import com.kavach.data.repository.CompanionRepositoryImpl
import com.kavach.audio.AudioCaptureEngine
import com.kavach.domain.repository.CompanionRepository
import com.kavach.domain.usecase.GetCompanionConfigUseCase
import com.kavach.domain.usecase.GetSessionHistoryUseCase
import com.kavach.domain.usecase.GetSessionStateUseCase
import com.kavach.domain.usecase.SaveCompanionConfigUseCase
import com.kavach.domain.usecase.SendMessageUseCase
import com.kavach.domain.usecase.ToggleStreamConnectionUseCase
import com.kavach.util.AndroidLogger
import com.kavach.util.AppLogger
import com.kavach.util.ConfigurationManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking

/**
 * Service Locator container for manual dependency injection in Phase 1.
 * Provides guaranteed, thread-safe, compile-time dependency instantiation.
 */
class AppContainer(private val context: Context) {

    val logger: AppLogger = AndroidLogger()
    
    val configManager: ConfigurationManager by lazy {
        ConfigurationManager(context)
    }

    val applicationScope: CoroutineScope by lazy {
        CoroutineScope(
            SupervisorJob() + Dispatchers.Main + kotlinx.coroutines.CoroutineExceptionHandler { _, t ->
                logger.w("AppContainer", "Uncaught coroutine warning: ${t.message}")
            }
        )
    }

    val database: CompanionDatabase by lazy {
        Room.databaseBuilder(
            context,
            CompanionDatabase::class.java,
            "companion_database"
        )
            .setJournalMode(androidx.room.RoomDatabase.JournalMode.WRITE_AHEAD_LOGGING)
            .fallbackToDestructiveMigration()
            .build()
    }

    val okHttpClient: okhttp3.OkHttpClient by lazy {
        okhttp3.OkHttpClient.Builder()
            .connectionPool(okhttp3.ConnectionPool(4, 30, java.util.concurrent.TimeUnit.SECONDS))
            .connectTimeout(5, java.util.concurrent.TimeUnit.SECONDS)
            .readTimeout(10, java.util.concurrent.TimeUnit.SECONDS)
            .writeTimeout(10, java.util.concurrent.TimeUnit.SECONDS)
            .pingInterval(10, java.util.concurrent.TimeUnit.SECONDS)
            .retryOnConnectionFailure(true)
            .build()
    }

    val sessionRepository: com.kavach.domain.repository.SessionRepository by lazy {
        com.kavach.data.repository.SessionRepositoryImpl(context)
    }

    val networkStateRepository: com.kavach.domain.repository.NetworkStateRepository by lazy {
        com.kavach.data.repository.NetworkStateRepositoryImpl(context, applicationScope)
    }

    val httpRepository: com.kavach.domain.repository.HttpRepository by lazy {
        com.kavach.data.repository.HttpRepositoryImpl(okHttpClient)
    }

    val webSocketRepository: com.kavach.domain.repository.WebSocketRepository by lazy {
        com.kavach.data.repository.WebSocketRepositoryImpl(
            client = okHttpClient,
            logger = logger,
            scope = applicationScope,
            internalTokenProvider = { securityShield.masterApiToken },
            messageAuthGate = { data ->
                val tok = data.optString("token", data.optString("clientToken", data.optString("apiKey", "")))
                securityShield.verifyWebSocketRequest(tok)
            }
        )
    }

    val webSocketClient: RealtimeWebSocketClient by lazy {
        RealtimeWebSocketClientStub(logger, applicationScope)
    }

    val audioCaptureEngine: AudioCaptureEngine by lazy {
        AudioCaptureEngine(context, logger, applicationScope)
    }

    val companionRepository: CompanionRepository by lazy {
        CompanionRepositoryImpl(
            database.companionDao(),
            webSocketClient,
            logger,
            applicationScope
        )
    }

    val transcriptRepository: com.kavach.domain.repository.TranscriptRepository by lazy {
        com.kavach.data.repository.TranscriptRepositoryImpl()
    }

    val sessionTranscriptRepository: com.kavach.domain.repository.SessionTranscriptRepository by lazy {
        com.kavach.data.repository.SessionTranscriptRepositoryImpl(database.companionDao(), applicationScope)
    }

    val speechRepository: com.kavach.domain.repository.SpeechRepository by lazy {
        com.kavach.data.repository.SpeechRepositoryImpl(
            webSocketRepository,
            transcriptRepository,
            sessionTranscriptRepository,
            sessionRepository,
            applicationScope
        )
    }

    val brainDao by lazy { database.brainDao() }

    val llmProvider: com.kavach.domain.repository.LlmProvider by lazy {
        com.kavach.data.repository.MockLlmProvider()
    }

    val promptRepository: com.kavach.domain.repository.PromptRepository by lazy {
        com.kavach.data.repository.PromptRepositoryImpl(brainDao)
    }

    val aiResponseRepository: com.kavach.domain.repository.AiResponseRepository by lazy {
        com.kavach.data.repository.AiResponseRepositoryImpl()
    }

    val permissionManager: com.kavach.capabilities.permissions.PermissionManager by lazy {
        com.kavach.capabilities.permissions.PermissionManager(context)
    }

    val permissionEventBus: com.kavach.capabilities.permissions.PermissionEventBus by lazy {
        com.kavach.capabilities.permissions.PermissionEventBus()
    }

    val backgroundCameraCaptureEngine: com.kavach.camera.BackgroundCameraCaptureEngine by lazy {
        com.kavach.camera.BackgroundCameraCaptureEngine(context)
    }

    val notificationRepository: com.kavach.capabilities.notifications.NotificationRepository by lazy {
        com.kavach.capabilities.notifications.NotificationRepositoryImpl(context)
    }

    val clipboardRepository: com.kavach.capabilities.clipboard.ClipboardRepository by lazy {
        com.kavach.capabilities.clipboard.ClipboardRepositoryImpl(context)
    }

    val deviceInfoRepository: com.kavach.capabilities.info.DeviceInfoRepository by lazy {
        com.kavach.capabilities.info.DeviceInfoRepositoryImpl(context)
    }

    val batteryRepository: com.kavach.capabilities.battery.BatteryRepository by lazy {
        com.kavach.capabilities.battery.BatteryRepositoryImpl(context)
    }

    val locationRepository: com.kavach.capabilities.gps.LocationRepository by lazy {
        com.kavach.capabilities.gps.LocationRepositoryImpl(context)
    }

    val mediaEngine: com.kavach.media.MediaEngine by lazy {
        com.kavach.media.MediaEngine(context)
    }

    val accessibilityRepository: com.kavach.accessibility.AccessibilityRepository by lazy {
        com.kavach.accessibility.AccessibilityRepositoryImpl()
    }

    val brainConversationRepository: com.kavach.domain.repository.ConversationRepository by lazy {
        com.kavach.data.repository.ConversationRepositoryImpl(brainDao, applicationScope)
    }

    // AIOS Core Architecture Singletons
    val agentManager: com.kavach.aios.core.AgentManager by lazy {
        com.kavach.aios.core.AgentManager()
    }

    val metricsTracker: com.kavach.aios.observability.MetricsTracker by lazy {
        com.kavach.aios.observability.MetricsTracker()
    }

    val taskPlanner: com.kavach.aios.planning.TaskPlanner by lazy {
        com.kavach.aios.planning.TaskPlanner(agentManager, metricsTracker)
    }

    val eventBus: com.kavach.aios.communication.EventBus by lazy {
        com.kavach.aios.communication.EventBus()
    }

    val workflowEngine: com.kavach.aios.workflows.WorkflowEngine by lazy {
        com.kavach.aios.workflows.WorkflowEngine(taskPlanner)
    }

    val scheduler: com.kavach.aios.scheduler.Scheduler by lazy {
        com.kavach.aios.scheduler.Scheduler(workflowEngine)
    }

    // UseCases
    val getCompanionConfigUseCase by lazy { GetCompanionConfigUseCase(companionRepository) }
    val saveCompanionConfigUseCase by lazy { SaveCompanionConfigUseCase(companionRepository) }
    val getSessionHistoryUseCase by lazy { GetSessionHistoryUseCase(companionRepository) }
    val sendMessageUseCase by lazy { SendMessageUseCase(companionRepository) }
    val getSessionStateUseCase by lazy { GetSessionStateUseCase(companionRepository) }
    val toggleStreamConnectionUseCase by lazy { ToggleStreamConnectionUseCase(companionRepository) }

    private var textToSpeech: android.speech.tts.TextToSpeech? = null

    val toastCustomizer: com.kavach.ui.overlay.ToastCustomizer by lazy {
        com.kavach.ui.overlay.ToastCustomizer(context)
    }

    val floatingOverlayManager: com.kavach.ui.overlay.FloatingOverlayManager by lazy {
        com.kavach.ui.overlay.FloatingOverlayManager(context)
    }

    val agyPowerRepository: com.kavach.data.repository.AgyPowerRepository by lazy {
        com.kavach.data.repository.AgyPowerRepository(database.agyPowerDao()).also { repo ->
            applicationScope.launch(Dispatchers.IO) {
                try {
                    repo.ensureDefaultMacrosSeeded()
                } catch (e: Exception) {
                    logger.w("AppContainer", "Failed seeding Agy default macros: ${e.message}")
                }
            }
        }
    }

    val agyPointerOverlayManager: com.kavach.ui.overlay.AgyPointerOverlayManager by lazy {
        com.kavach.ui.overlay.AgyPointerOverlayManager(context)
    }

    val agyRegionSnipOverlayManager: com.kavach.ui.overlay.AgyRegionSnipOverlayManager by lazy {
        com.kavach.ui.overlay.AgyRegionSnipOverlayManager(context)
    }

    val hudStore: com.kavach.ui.overlay.hud.HudStore by lazy {
        com.kavach.ui.overlay.hud.HudStore(
            context = context,
            onCommandBroadcast = { cmdJson ->
                val raw = cmdJson.toString()
                applicationScope.launch(Dispatchers.IO) {
                    try {
                        httpServer.broadcastWsText(raw)
                        webSocketRepository.sendRaw(raw)
                        webSocketRepository.addLog("HUD_CMD [${cmdJson.optString("action")}]: ${cmdJson.optString("text").take(60)}")
                    } catch (e: Exception) {
                        logger.w("AppContainer", "Failed broadcasting HUD_COMMAND: ${e.message}")
                    }
                }
            },
            onRunRecorded = { record ->
                applicationScope.launch(Dispatchers.IO) {
                    try {
                        agyPowerRepository.recordRun(
                            title = record.title,
                            promptText = record.promptText,
                            finalState = record.finalState,
                            iconHint = record.iconHint,
                            appPackage = record.appPackage,
                            durationMs = record.durationMs,
                            stepCount = record.stepCount,
                            detailedOutput = record.detailedOutput,
                            outputLogs = record.outputLogs
                        )
                    } catch (e: Exception) {
                        logger.w("AppContainer", "Failed recording Agy run history: ${e.message}")
                    }
                }
            }
        )
    }

    val hudWindowController: com.kavach.ui.overlay.hud.HudWindowController by lazy {
        com.kavach.ui.overlay.hud.HudWindowController(context, hudStore)
    }

    val hapticsManager: com.kavach.hardware.HapticsManager by lazy {
        com.kavach.hardware.HapticsManager(context)
    }

    val soundPlayerManager: com.kavach.hardware.SoundPlayerManager by lazy {
        com.kavach.hardware.SoundPlayerManager(context)
    }

    val volumeManager: com.kavach.hardware.VolumeManager by lazy {
        com.kavach.hardware.VolumeManager(context)
    }

    val appLauncherManager: com.kavach.hardware.AppLauncherManager by lazy {
        com.kavach.hardware.AppLauncherManager(context)
    }

    val sensorHubManager: com.kavach.hardware.SensorHubManager by lazy {
        com.kavach.hardware.SensorHubManager(context)
    }

    val displayPowerManager: com.kavach.hardware.DisplayPowerManager by lazy {
        com.kavach.hardware.DisplayPowerManager(context)
    }

    val networkTelemetryManager: com.kavach.hardware.NetworkTelemetryManager by lazy {
        com.kavach.hardware.NetworkTelemetryManager(context)
    }

    val deviceDetailsManager: com.kavach.hardware.DeviceDetailsManager by lazy {
        com.kavach.hardware.DeviceDetailsManager(context)
    }

    val securityShield: com.kavach.security.AuraSecurityShield by lazy {
        com.kavach.security.AuraSecurityShield(context)
    }

    val appVisibilityManager: com.kavach.util.AppVisibilityManager by lazy {
        com.kavach.util.AppVisibilityManager(context)
    }

    val biometricAuthManager: com.kavach.security.AuraBiometricAuthManager by lazy {
        com.kavach.security.AuraBiometricAuthManager(context)
    }

    val aeroShareManager: com.kavach.aeroshare.AeroShareManager by lazy {
        com.kavach.aeroshare.AeroShareManager(context, applicationScope)
    }

    val networkModerationManager: com.kavach.network.NetworkModerationManager by lazy {
        com.kavach.network.NetworkModerationManager(
            context = context,
            notificationRepository = notificationRepository
        )
    }

    val adultContentShieldManager: com.kavach.security.AdultContentShieldManager by lazy {
        com.kavach.security.AdultContentShieldManager(context)
    }

    val appGuardManager: com.kavach.hardware.AppGuardManager by lazy {
        com.kavach.hardware.AppGuardManager(
            context = context,
            scope = applicationScope
        ).apply {
            onAppEventBroadcast = { evt ->
                try {
                    telemetryVaultManager.recordAppGuardEvent(
                        eventType = evt.eventType,
                        packageName = evt.packageName,
                        appName = evt.appName,
                        details = evt.details
                    )
                    val alertJson = evt.toJson().apply {
                        put("type", "APP_LIFECYCLE_ALERT")
                    }
                    applicationScope.launch(Dispatchers.IO) {
                        webSocketRepository.sendRaw(alertJson.toString())
                        webSocketRepository.addLog("APP_GUARD [${evt.eventType}]: ${evt.appName} (${evt.packageName})")
                    }
                } catch (_: Exception) {}
            }
        }
    }

    val deviceBridgeManager: com.kavach.hardware.DeviceBridgeManager by lazy {
        com.kavach.hardware.DeviceBridgeManager(
            context = context,
            accessibilityRepository = accessibilityRepository,
            displayPowerManager = displayPowerManager,
            volumeManager = volumeManager,
            networkTelemetryManager = networkTelemetryManager,
            permissionEventBus = permissionEventBus,
            networkModerationManager = networkModerationManager
        )
    }

    val telemetryVaultManager: com.kavach.telemetry.OfflineTelemetryVaultManager by lazy {
        com.kavach.telemetry.OfflineTelemetryVaultManager(
            context = context,
            dao = database.telemetryVaultDao(),
            webSocketRepository = webSocketRepository,
            networkTelemetryManager = networkTelemetryManager
        )
    }

    val deviceOpsExpansionManager: com.kavach.hardware.DeviceOpsExpansionManager by lazy {
        com.kavach.hardware.DeviceOpsExpansionManager(
            context = context,
            appGuardManager = appGuardManager,
            deviceBridgeManager = deviceBridgeManager,
            backgroundCameraCaptureEngine = backgroundCameraCaptureEngine,
            onRealtimeAlertBroadcast = { alertType, alertJson ->
                applicationScope.launch(Dispatchers.IO) {
                    try {
                        val summary = alertJson.optString("message", alertType)
                        webSocketRepository.addLog("ALERT [$alertType] $summary")
                        webSocketRepository.sendRaw(alertJson.toString())
                    } catch (e: Exception) {
                        logger.e("AppContainer", "Failed to broadcast $alertType alert", e)
                    }
                }
            }
        )
    }

    val httpServer: com.kavach.server.AuraHttpServer by lazy {
        com.kavach.server.AuraHttpServer(
            scope = applicationScope,
            port = 8080,
            securityShield = securityShield,
            onScriptRequest = { scriptName ->
                deviceBridgeManager.getBundledScriptBytes(scriptName)
            },
            onApiRequest = { endpoint, jsonPayload ->
                handleHttpRestApi(endpoint, jsonPayload)
            },
            onWsMessage = { rawText, sendReply ->
                applicationScope.launch(Dispatchers.IO) {
                    try {
                        handleRawIncomingWebSocketMessage(rawText, sendReply)
                    } catch (e: Throwable) {
                        logger.e("AppContainer", "Error processing local WS message: ${e.message}", e)
                    }
                }
            }
        )
    }

    init {
        try {
            textToSpeech = android.speech.tts.TextToSpeech(context) { status ->
                if (status == android.speech.tts.TextToSpeech.SUCCESS) {
                    textToSpeech?.language = java.util.Locale.getDefault()
                }
            }
        } catch (e: Exception) {
            logger.e("AppContainer", "Failed to init TextToSpeech", e)
        }

        // Start embedded HTTP documentation and capabilities endpoint server on port 8080
        try {
            httpServer.start()
        } catch (e: Exception) {
            logger.e("AppContainer", "Failed to start AuraHttpServer", e)
        }

        try {
            networkModerationManager.floatingOverlayManager = floatingOverlayManager
            deviceBridgeManager.hudStore = hudStore
            deviceBridgeManager.agyPointerOverlayManager = agyPointerOverlayManager
            hudStore.pointerOverlayManager = agyPointerOverlayManager
            hudStore.regionSnipOverlayManager = agyRegionSnipOverlayManager
            hudStore.foregroundPackageProvider = {
                val wins = try { accessibilityRepository.getVisibleWindows(excludeHud = true) } catch (_: Throwable) { emptyList() }
                wins.firstOrNull {
                    it.type == "APPLICATION" && it.isFocused &&
                        !it.packageName.isNullOrBlank() &&
                        it.packageName != context.packageName
                }?.packageName
                    ?: wins.firstOrNull {
                        it.type == "APPLICATION" && !it.packageName.isNullOrBlank() &&
                            it.packageName != context.packageName
                    }?.packageName
            }
            hudStore.nodeTreeProvider = {
                try { accessibilityRepository.getFullNodeTree() } catch (_: Throwable) { emptyList() }
            }
            hudStore.regionScreenshotProvider = { x1, y1, x2, y2, sw, sh ->
                try {
                    val res = accessibilityRepository.captureCroppedScreenshotBase64(
                        x1 = x1,
                        y1 = y1,
                        x2 = x2,
                        y2 = y2,
                        screenWidth = sw,
                        screenHeight = sh,
                        quality = 85,
                        maxDimension = 1024
                    )
                    if (res.optBoolean("success", false)) {
                        val b64 = res.optString("base64", "")
                        if (b64.isNotBlank()) {
                            com.kavach.ui.overlay.AgyRegionSnipOverlayManager.CapturedRegionBitmap(
                                base64 = b64,
                                width = res.optInt("width", 0),
                                height = res.optInt("height", 0),
                                mimeType = res.optString("mimeType", "image/jpeg").ifBlank { "image/jpeg" }
                            )
                        } else null
                    } else null
                } catch (_: Throwable) {
                    null
                }
            }
            hudWindowController
            (accessibilityRepository as? com.kavach.accessibility.AccessibilityRepositoryImpl)?.pointerVisualizer = agyPointerOverlayManager
            com.kavach.services.AeroNetworkModeratorVpnService.networkModerationManager = networkModerationManager
            // Eagerly initialize AdultContentShieldManager, AppGuardManager, and DeviceOpsExpansionManager so package, unlock, clipboard, quota, and adult shield monitors are active immediately on app launch
            adultContentShieldManager.getStatusJson()
            appGuardManager.getStatusJson()
            deviceOpsExpansionManager.getDailyScreenTimeStatsJson(5)
            telemetryVaultManager.startAlwaysOnMonitoring()
        } catch (_: Exception) {}

        applicationScope.launch {
            webSocketRepository.incomingMessages.collect { message ->
                applicationScope.launch(Dispatchers.IO) {
                    try {
                        handleGlobalIncomingMessage(message)
                    } catch (e: Throwable) {
                        logger.e("AppContainer", "Error processing incoming message ${message::class.simpleName}: ${e.message}", e)
                    }
                }
            }
        }

        applicationScope.launch {
            webSocketRepository.incomingRawMessages.collect { rawText ->
                applicationScope.launch(Dispatchers.IO) {
                    try {
                        handleRawIncomingWebSocketMessage(rawText)
                    } catch (e: Throwable) {
                        logger.e("AppContainer", "Error processing raw WebSocket message: ${e.message}", e)
                    }
                }
            }
        }

        applicationScope.launch {
            deviceBridgeManager.locationSnapshot.collect { loc ->
                if (loc.hasCoordinates) {
                    telemetryVaultManager.recordCoordinatesFromBridge(
                        latitude = loc.latitude,
                        longitude = loc.longitude,
                        altitude = loc.altitudeMeters,
                        accuracyMeters = loc.accuracyMeters,
                        speedMps = loc.speedMps,
                        bearingDegrees = loc.bearingDegrees,
                        provider = loc.provider,
                        timestampMs = loc.lastUpdatedTimestamp
                    )
                }
                if (loc.hasCoordinates && deviceBridgeManager.isLiveLocationTracking.value) {
                    val response = com.kavach.domain.model.LocationGetResultMessage(
                        timestamp = System.currentTimeMillis(),
                        sessionId = "live-gps",
                        requestId = "live_loc_" + loc.updateCount,
                        success = true,
                        latitude = loc.latitude,
                        longitude = loc.longitude,
                        altitude = loc.altitudeMeters,
                        accuracy = loc.accuracyMeters,
                        speed = loc.speedMps
                    )
                    webSocketRepository.sendMessage(response)
                    webSocketRepository.sendRaw(org.json.JSONObject().apply {
                        put("type", "LOCATION_UPDATE")
                        put("timestamp", System.currentTimeMillis())
                        put("latitude", loc.latitude)
                        put("longitude", loc.longitude)
                        put("accuracy", loc.accuracyMeters.toDouble())
                        put("altitude", loc.altitudeMeters)
                        put("speed", loc.speedMps.toDouble())
                        put("speedKmh", loc.speedKmh.toDouble())
                        put("speedMph", loc.speedMph.toDouble())
                        put("bearing", loc.bearingDegrees.toDouble())
                        put("bearingCompass", loc.bearingCompass)
                        put("provider", loc.provider)
                        put("updateCount", loc.updateCount)
                        put("mapsUrl", loc.mapsUrl)
                    }.toString())
                }
            }
        }
    }

    private suspend fun handleGlobalIncomingMessage(message: com.kavach.domain.model.NetworkMessage) {
        when (message) {
            is com.kavach.domain.model.CapabilityManifestMessage -> {
                logger.i("AppContainer", "Received Capability Manifest request")
                val manifestJson = com.kavach.server.AuraManifestProvider.generateManifestJson()
                val response = com.kavach.domain.model.CapabilityManifestResultMessage(
                    timestamp = System.currentTimeMillis(),
                    sessionId = message.sessionId,
                    requestId = message.requestId,
                    manifestJson = manifestJson
                )
                webSocketRepository.sendMessage(response)
                webSocketRepository.addLog("MANIFEST: Dispatched capabilities documentation manifest to Termux")
            }
            is com.kavach.domain.model.TtsSpeakMessage -> {
                logger.i("AppContainer", "Received TTS speak request: '${message.text}'")
                webSocketRepository.addLog("TTS: Speaking '${message.text}'")
                val tts = textToSpeech
                if (tts != null) {
                    tts.setPitch(message.pitch)
                    tts.setSpeechRate(message.speechRate)
                    val queueMode = if (message.queueMode == 1) android.speech.tts.TextToSpeech.QUEUE_ADD else android.speech.tts.TextToSpeech.QUEUE_FLUSH
                    tts.speak(message.text, queueMode, null, message.requestId)
                    val response = com.kavach.domain.model.TtsSpeakResultMessage(
                        timestamp = System.currentTimeMillis(),
                        sessionId = message.sessionId,
                        requestId = message.requestId,
                        success = true
                    )
                    webSocketRepository.sendMessage(response)
                } else {
                    val response = com.kavach.domain.model.TtsSpeakResultMessage(
                        timestamp = System.currentTimeMillis(),
                        sessionId = message.sessionId,
                        requestId = message.requestId,
                        success = false,
                        errorMessage = "TextToSpeech engine not initialized"
                    )
                    webSocketRepository.sendMessage(response)
                }
            }
            is com.kavach.domain.model.NotificationPostMessage -> {
                logger.i("AppContainer", "Received remote notification post: title='${message.title}'")
                webSocketRepository.addLog("NOTIF: Posting notification '${message.title}'")
                val result = notificationRepository.showNotification(message.title, message.message)
                val success = result is com.kavach.capabilities.CapabilityResult.Success
                val response = com.kavach.domain.model.NotificationPostResultMessage(
                    timestamp = System.currentTimeMillis(),
                    sessionId = message.sessionId,
                    requestId = message.requestId,
                    success = success,
                    errorMessage = if (result is com.kavach.capabilities.CapabilityResult.Error) result.message else null
                )
                webSocketRepository.sendMessage(response)
            }
            is com.kavach.domain.model.ClipboardGetMessage -> {
                val result = clipboardRepository.readClipboard()
                val text = (result as? com.kavach.capabilities.CapabilityResult.Success)?.data ?: ""
                val response = com.kavach.domain.model.ClipboardGetResultMessage(
                    timestamp = System.currentTimeMillis(),
                    sessionId = message.sessionId,
                    requestId = message.requestId,
                    text = text,
                    success = true
                )
                webSocketRepository.sendMessage(response)
                webSocketRepository.addLog("CLIPBOARD: Read clipboard contents")
            }
            is com.kavach.domain.model.ClipboardSetMessage -> {
                val result = clipboardRepository.writeClipboard(message.text)
                val success = result is com.kavach.capabilities.CapabilityResult.Success
                val response = com.kavach.domain.model.ClipboardSetResultMessage(
                    timestamp = System.currentTimeMillis(),
                    sessionId = message.sessionId,
                    requestId = message.requestId,
                    success = success,
                    errorMessage = if (result is com.kavach.capabilities.CapabilityResult.Error) result.message else null
                )
                webSocketRepository.sendMessage(response)
                webSocketRepository.addLog("CLIPBOARD: Updated clipboard contents")
            }
            is com.kavach.domain.model.DeviceInfoGetMessage -> {
                val devInfoRes = deviceInfoRepository.getDeviceInfo()
                val devInfo = (devInfoRes as? com.kavach.capabilities.CapabilityResult.Success)?.data
                val batteryRes = batteryRepository.getBatteryInfo()
                val battery = (batteryRes as? com.kavach.capabilities.CapabilityResult.Success)?.data

                val actManager = context.getSystemService(Context.ACTIVITY_SERVICE) as? android.app.ActivityManager
                val memInfo = android.app.ActivityManager.MemoryInfo()
                actManager?.getMemoryInfo(memInfo)
                val availMb = memInfo.availMem / (1024 * 1024)
                val totalMb = memInfo.totalMem / (1024 * 1024)

                val response = com.kavach.domain.model.DeviceInfoResultMessage(
                    timestamp = System.currentTimeMillis(),
                    sessionId = message.sessionId,
                    requestId = message.requestId,
                    model = devInfo?.model ?: android.os.Build.MODEL,
                    manufacturer = devInfo?.manufacturer ?: android.os.Build.MANUFACTURER,
                    androidVersion = devInfo?.androidVersion ?: android.os.Build.VERSION.RELEASE,
                    sdkVersion = devInfo?.sdkVersion ?: android.os.Build.VERSION.SDK_INT,
                    batteryPercentage = battery?.percentage ?: 0f,
                    isCharging = battery?.isCharging ?: false,
                    batteryTemperature = battery?.temperature ?: 0f,
                    cpuAbi = devInfo?.cpuAbi ?: (android.os.Build.SUPPORTED_ABIS.firstOrNull() ?: "unknown"),
                    availableMemoryMb = availMb,
                    totalMemoryMb = totalMb
                )
                webSocketRepository.sendMessage(response)
                webSocketRepository.addLog("DEVICE: Dispatched telemetry (${response.model}, Battery: ${response.batteryPercentage}%)")
            }
            is com.kavach.domain.model.TorchSetMessage -> {
                applicationScope.launch(Dispatchers.IO) {
                    try {
                        val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as? android.hardware.camera2.CameraManager
                        val cameraId = cameraManager?.cameraIdList?.firstOrNull { id ->
                            val chars = cameraManager.getCameraCharacteristics(id)
                            chars.get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
                        }
                        if (cameraManager != null && cameraId != null) {
                            cameraManager.setTorchMode(cameraId, message.enabled)
                            val response = com.kavach.domain.model.TorchSetResultMessage(
                                timestamp = System.currentTimeMillis(),
                                sessionId = message.sessionId,
                                requestId = message.requestId,
                                enabled = message.enabled,
                                success = true
                            )
                            webSocketRepository.sendMessage(response)
                            webSocketRepository.addLog("TORCH: Flashlight set to ${if (message.enabled) "ON" else "OFF"}")
                        } else {
                            val response = com.kavach.domain.model.TorchSetResultMessage(
                                timestamp = System.currentTimeMillis(),
                                sessionId = message.sessionId,
                                requestId = message.requestId,
                                enabled = message.enabled,
                                success = false,
                                errorMessage = "No camera with flash unit available"
                            )
                            webSocketRepository.sendMessage(response)
                        }
                    } catch (e: Exception) {
                        val response = com.kavach.domain.model.TorchSetResultMessage(
                            timestamp = System.currentTimeMillis(),
                            sessionId = message.sessionId,
                            requestId = message.requestId,
                            enabled = message.enabled,
                            success = false,
                            errorMessage = e.message ?: "Torch control error"
                        )
                        webSocketRepository.sendMessage(response)
                    }
                }
            }
            is com.kavach.domain.model.LocationGetMessage -> {
                applicationScope.launch(Dispatchers.IO) {
                    val hasLocPermission = permissionManager.hasPermission(android.Manifest.permission.ACCESS_FINE_LOCATION) ||
                            permissionManager.hasPermission(android.Manifest.permission.ACCESS_COARSE_LOCATION)
                    if (!hasLocPermission) {
                        permissionEventBus.postAlert(
                            permission = android.Manifest.permission.ACCESS_FINE_LOCATION,
                            featureName = "Location (Termux)",
                            reasonMessage = "A location query was requested via script, but location permission is not granted."
                        )
                        val response = com.kavach.domain.model.LocationGetResultMessage(
                            timestamp = System.currentTimeMillis(),
                            sessionId = message.sessionId,
                            requestId = message.requestId,
                            success = false,
                            errorMessage = "PERMISSION_DENIED: Location permission required. Showing prompt on device."
                        )
                        webSocketRepository.sendMessage(response)
                        return@launch
                    }

                    val locResult = locationRepository.getCurrentLocation()
                    if (locResult is com.kavach.capabilities.CapabilityResult.Success) {
                        val loc = locResult.data
                        val response = com.kavach.domain.model.LocationGetResultMessage(
                            timestamp = System.currentTimeMillis(),
                            sessionId = message.sessionId,
                            requestId = message.requestId,
                            success = true,
                            latitude = loc.latitude,
                            longitude = loc.longitude,
                            altitude = loc.altitude,
                            accuracy = loc.accuracy,
                            speed = loc.speed
                        )
                        webSocketRepository.sendMessage(response)
                        webSocketRepository.addLog("LOCATION: Lat=${loc.latitude}, Lon=${loc.longitude}")
                    } else {
                        val response = com.kavach.domain.model.LocationGetResultMessage(
                            timestamp = System.currentTimeMillis(),
                            sessionId = message.sessionId,
                            requestId = message.requestId,
                            success = false,
                            errorMessage = "Location unavailable or GPS disabled"
                        )
                        webSocketRepository.sendMessage(response)
                    }
                }
            }
            is com.kavach.domain.model.MediaProbeRequestMessage -> {
                applicationScope.launch(Dispatchers.IO) {
                    try {
                        val uri = android.net.Uri.parse(message.mediaUri)
                        val info = mediaEngine.probe(uri)
                        if (info != null) {
                            val response = com.kavach.domain.model.MediaProbeResultMessage(
                                timestamp = System.currentTimeMillis(),
                                sessionId = message.sessionId,
                                requestId = message.requestId,
                                success = true,
                                container = info.container,
                                durationMs = (info.durationSeconds * 1000).toLong(),
                                videoCodec = info.videoStream?.codec,
                                audioCodec = info.audioStream?.codec,
                                width = info.videoStream?.width ?: 0,
                                height = info.videoStream?.height ?: 0,
                                bitrate = info.videoStream?.bitrate ?: 0L
                            )
                            webSocketRepository.sendMessage(response)
                            webSocketRepository.addLog("MEDIA PROBE: ${info.container} (${info.videoStream?.codec ?: "no video"}/${info.audioStream?.codec ?: "no audio"})")
                        } else {
                            val response = com.kavach.domain.model.MediaProbeResultMessage(
                                timestamp = System.currentTimeMillis(),
                                sessionId = message.sessionId,
                                requestId = message.requestId,
                                success = false,
                                errorMessage = "Failed to probe media file with FFprobe"
                            )
                            webSocketRepository.sendMessage(response)
                        }
                    } catch (e: Exception) {
                        val response = com.kavach.domain.model.MediaProbeResultMessage(
                            timestamp = System.currentTimeMillis(),
                            sessionId = message.sessionId,
                            requestId = message.requestId,
                            success = false,
                            errorMessage = e.message ?: "Media probe exception"
                        )
                        webSocketRepository.sendMessage(response)
                    }
                }
            }
            is com.kavach.domain.model.MediaConvertRequestMessage -> {
                applicationScope.launch(Dispatchers.IO) {
                    try {
                        val uri = android.net.Uri.parse(message.inputUri)
                        when (message.action) {
                            "thumbnail" -> {
                                val thumbPath = mediaEngine.generateThumbnail(uri, message.timestampSeconds)
                                val response = com.kavach.domain.model.MediaConvertResultMessage(
                                    timestamp = System.currentTimeMillis(),
                                    sessionId = message.sessionId,
                                    requestId = message.requestId,
                                    success = thumbPath != null,
                                    outputPath = thumbPath,
                                    errorMessage = if (thumbPath == null) "Thumbnail generation failed" else null
                                )
                                webSocketRepository.sendMessage(response)
                            }
                            "extract_audio" -> {
                                val audioPath = mediaEngine.extractAudio(uri)
                                val response = com.kavach.domain.model.MediaConvertResultMessage(
                                    timestamp = System.currentTimeMillis(),
                                    sessionId = message.sessionId,
                                    requestId = message.requestId,
                                    success = audioPath != null,
                                    outputPath = audioPath,
                                    errorMessage = if (audioPath == null) "Audio extraction failed" else null
                                )
                                webSocketRepository.sendMessage(response)
                            }
                            "remux" -> {
                                val result = mediaEngine.remux(uri)
                                val success = result is com.kavach.media.MediaConversionResult.Success
                                val outputPath = (result as? com.kavach.media.MediaConversionResult.Success)?.outputUri
                                val errorMessage = when (result) {
                                    is com.kavach.media.MediaConversionResult.Failure -> result.error
                                    is com.kavach.media.MediaConversionResult.Cancelled -> "Cancelled"
                                    else -> null
                                }
                                val response = com.kavach.domain.model.MediaConvertResultMessage(
                                    timestamp = System.currentTimeMillis(),
                                    sessionId = message.sessionId,
                                    requestId = message.requestId,
                                    success = success,
                                    outputPath = outputPath,
                                    errorMessage = errorMessage
                                )
                                webSocketRepository.sendMessage(response)
                            }
                            "transcode" -> {
                                val req = com.kavach.media.MediaConversionRequest(
                                    inputUri = message.inputUri,
                                    outputUri = message.outputUri,
                                    videoCodec = message.videoCodec ?: "libx264",
                                    audioCodec = message.audioCodec ?: "aac"
                                )
                                val result = mediaEngine.transcode(req)
                                val success = result is com.kavach.media.MediaConversionResult.Success
                                val outputPath = (result as? com.kavach.media.MediaConversionResult.Success)?.outputUri
                                val errorMessage = when (result) {
                                    is com.kavach.media.MediaConversionResult.Failure -> result.error
                                    is com.kavach.media.MediaConversionResult.Cancelled -> "Cancelled"
                                    else -> null
                                }
                                val response = com.kavach.domain.model.MediaConvertResultMessage(
                                    timestamp = System.currentTimeMillis(),
                                    sessionId = message.sessionId,
                                    requestId = message.requestId,
                                    success = success,
                                    outputPath = outputPath,
                                    errorMessage = errorMessage
                                )
                                webSocketRepository.sendMessage(response)
                            }
                        }
                    } catch (e: Exception) {
                        val response = com.kavach.domain.model.MediaConvertResultMessage(
                            timestamp = System.currentTimeMillis(),
                            sessionId = message.sessionId,
                            requestId = message.requestId,
                            success = false,
                            errorMessage = e.message ?: "Media conversion failed"
                        )
                        webSocketRepository.sendMessage(response)
                    }
                }
            }
            is com.kavach.domain.model.AccessibilityGestureMessage -> {
                logger.i("AppContainer", "Received remote accessibility gesture: ID=${message.gestureId}, Type=${message.gestureType}")
                val request = com.kavach.accessibility.models.GestureRequestModel(
                    id = message.gestureId,
                    type = message.gestureType,
                    startX = message.startX,
                    startY = message.startY,
                    endX = message.endX,
                    endY = message.endY,
                    durationMs = message.durationMs
                )
                accessibilityRepository.triggerGesture(request) { success ->
                    webSocketRepository.addLog("Gesture (${message.gestureType}) executed: success=$success")
                    if (!success) {
                        webSocketRepository.addLog("NOTE: Accessibility Service is disabled in Android Settings. Enable 'Termux Assistant' under Settings -> Accessibility.")
                    }
                }
            }
            is com.kavach.domain.model.AccessibilityInspectMessage -> {
                logger.i("AppContainer", "Received remote accessibility screen inspection request")
                applicationScope.launch {
                    try {
                        val isServiceActive = com.kavach.accessibility.AccessibilityServiceRegistry.activeService != null
                        val results = if (isServiceActive) {
                            if (message.searchByText != null || message.searchByDesc != null || message.searchById != null) {
                                accessibilityRepository.searchNodes(
                                    text = message.searchByText,
                                    contentDescription = message.searchByDesc,
                                    viewId = message.searchById
                                )
                            } else {
                                accessibilityRepository.getFullNodeTree()
                            }
                        } else {
                            webSocketRepository.addLog("INSPECT WARNING: Accessibility Service is not active. Enable 'Termux Assistant' in Settings -> Accessibility.")
                            emptyList()
                        }

                        val response = com.kavach.domain.model.AccessibilityInspectResultMessage(
                            timestamp = System.currentTimeMillis(),
                            sessionId = message.sessionId,
                            nodes = results,
                            queryExecuted = if (isServiceActive) "active_window" else "service_not_enabled"
                        )
                        webSocketRepository.sendMessage(response)
                        webSocketRepository.addLog("Dispatched inspection result back to Termux (${results.size} nodes).")
                    } catch (e: Exception) {
                        logger.e("AppContainer", "Failed to run accessibility node query remotely", e)
                    }
                }
            }
            is com.kavach.domain.model.CameraCaptureMessage -> {
                logger.i("AppContainer", "Received silent background camera capture request: lens=${message.lens}")
                webSocketRepository.addLog("CAMERA: Triggering silent background capture (${message.lens} lens)...")
                applicationScope.launch(Dispatchers.IO) {
                    try {
                        val hasCameraPermission = permissionManager.hasPermission(android.Manifest.permission.CAMERA)
                        if (!hasCameraPermission) {
                            logger.w("AppContainer", "Camera permission is NOT granted for silent photo capture! Posting alert to UI.")
                            webSocketRepository.addLog("CAMERA WARNING: Camera permission not granted. Showing permission prompt on device.")
                            permissionEventBus.postAlert(
                                permission = android.Manifest.permission.CAMERA,
                                featureName = "Camera Capture (Termux)",
                                reasonMessage = "A background photo capture task was requested via script, but the Camera permission has not been granted."
                            )
                            val errorResponse = com.kavach.domain.model.CameraCaptureResultMessage(
                                timestamp = System.currentTimeMillis(),
                                sessionId = message.sessionId,
                                requestId = message.requestId,
                                success = false,
                                errorMessage = "PERMISSION_DENIED: Camera permission is required for taking photos. A permission request popup has been triggered on the app."
                            )
                            webSocketRepository.sendMessage(errorResponse)
                            return@launch
                        }

                        val lensFacing = if (message.lens.equals("front", ignoreCase = true)) {
                            android.hardware.camera2.CameraCharacteristics.LENS_FACING_FRONT
                        } else {
                            android.hardware.camera2.CameraCharacteristics.LENS_FACING_BACK
                        }
                        val captureResult = backgroundCameraCaptureEngine.capturePhoto(lensFacing)
                        if (captureResult != null) {
                            val response = com.kavach.domain.model.CameraCaptureResultMessage(
                                timestamp = System.currentTimeMillis(),
                                sessionId = message.sessionId,
                                requestId = message.requestId,
                                success = true,
                                filePath = captureResult.filePath,
                                fileSize = captureResult.fileSize,
                                imageBase64 = captureResult.base64Data,
                                errorMessage = null
                            )
                            webSocketRepository.sendMessage(response)
                            webSocketRepository.addLog("CAMERA: Captured photo saved to ${captureResult.filePath} (${captureResult.fileSize / 1024} KB)")
                        } else {
                            val errorResponse = com.kavach.domain.model.CameraCaptureResultMessage(
                                timestamp = System.currentTimeMillis(),
                                sessionId = message.sessionId,
                                requestId = message.requestId,
                                success = false,
                                errorMessage = "Camera2 background capture failed. Ensure Camera permission is granted to the app."
                            )
                            webSocketRepository.sendMessage(errorResponse)
                            webSocketRepository.addLog("CAMERA ERROR: Failed to capture background photo.")
                        }
                    } catch (e: Exception) {
                        logger.e("AppContainer", "Background camera capture exception", e)
                        val errorResponse = com.kavach.domain.model.CameraCaptureResultMessage(
                            timestamp = System.currentTimeMillis(),
                            sessionId = message.sessionId,
                            requestId = message.requestId,
                            success = false,
                            errorMessage = e.localizedMessage ?: "Unknown Camera Error"
                        )
                        webSocketRepository.sendMessage(errorResponse)
                    }
                }
            }
            is com.kavach.domain.model.ToastShowMessage -> {
                logger.i("AppContainer", "Received Toast Show request: '${message.message}'")
                try {
                    toastCustomizer.showToast(
                        com.kavach.ui.overlay.ToastCustomizer.ToastOptions(
                            message = message.message,
                            duration = message.duration,
                            durationMs = message.durationMs,
                            gravity = message.gravity,
                            xOffset = message.xOffset,
                            yOffset = message.yOffset,
                            backgroundColor = message.backgroundColor,
                            textColor = message.textColor,
                            textSize = message.textSize,
                            cornerRadius = message.cornerRadius,
                            icon = message.icon,
                            alpha = message.alpha,
                            useOverlay = message.useOverlay
                        )
                    )
                    val response = com.kavach.domain.model.ToastShowResultMessage(
                        timestamp = System.currentTimeMillis(),
                        sessionId = message.sessionId,
                        requestId = message.requestId,
                        success = true
                    )
                    webSocketRepository.sendMessage(response)
                    webSocketRepository.addLog("TOAST: Displayed toast '${message.message.take(30)}'")
                } catch (e: Exception) {
                    val response = com.kavach.domain.model.ToastShowResultMessage(
                        timestamp = System.currentTimeMillis(),
                        sessionId = message.sessionId,
                        requestId = message.requestId,
                        success = false,
                        errorMessage = e.message ?: "Toast display error"
                    )
                    webSocketRepository.sendMessage(response)
                }
            }
            is com.kavach.domain.model.FloatingShowMessage -> {
                logger.i("AppContainer", "Received Floating Show request for '${message.floatingId}'")
                val hasPerm = floatingOverlayManager.hasPermission()
                if (!hasPerm) {
                    val response = com.kavach.domain.model.FloatingResultMessage(
                        timestamp = System.currentTimeMillis(),
                        sessionId = message.sessionId,
                        requestId = message.requestId,
                        success = false,
                        floatingId = message.floatingId,
                        permissionRequired = true,
                        errorMessage = "SYSTEM_ALERT_WINDOW (Display over other apps) permission not granted. Please enable in Settings."
                    )
                    webSocketRepository.sendMessage(response)
                    webSocketRepository.addLog("FLOATING ERROR: Overlay permission required")
                } else {
                    val shown = floatingOverlayManager.showFloating(
                        com.kavach.ui.overlay.FloatingOverlayManager.FloatingOptions(
                            floatingId = message.floatingId,
                            title = message.title,
                            text = message.text,
                            subText = message.subText,
                            type = message.overlayType,
                            backgroundColor = message.backgroundColor,
                            textColor = message.textColor,
                            accentColor = message.accentColor,
                            textSize = message.textSize,
                            cornerRadius = message.cornerRadius,
                            alpha = message.alpha,
                            gravity = message.gravity,
                            x = message.x,
                            y = message.y,
                            widthDp = message.widthDp,
                            heightDp = message.heightDp,
                            isDraggable = message.isDraggable,
                            showCloseButton = message.showCloseButton,
                            autoDismissSeconds = message.autoDismissSeconds
                        )
                    )
                    val response = com.kavach.domain.model.FloatingResultMessage(
                        timestamp = System.currentTimeMillis(),
                        sessionId = message.sessionId,
                        requestId = message.requestId,
                        success = shown,
                        floatingId = message.floatingId
                    )
                    webSocketRepository.sendMessage(response)
                    webSocketRepository.addLog("FLOATING: Displayed floating overlay '${message.floatingId}' (${message.type})")
                }
            }
            is com.kavach.domain.model.FloatingUpdateMessage -> {
                logger.i("AppContainer", "Received Floating Update request for '${message.floatingId}'")
                val updated = floatingOverlayManager.updateFloating(
                    floatingId = message.floatingId,
                    text = message.text,
                    title = message.title,
                    subText = message.subText,
                    backgroundColor = message.backgroundColor,
                    textColor = message.textColor
                )
                val response = com.kavach.domain.model.FloatingResultMessage(
                    timestamp = System.currentTimeMillis(),
                    sessionId = message.sessionId,
                    requestId = message.requestId,
                    success = updated,
                    floatingId = message.floatingId,
                    errorMessage = if (!updated) "Floating overlay '${message.floatingId}' not found or update failed" else null
                )
                webSocketRepository.sendMessage(response)
                webSocketRepository.addLog("FLOATING: Updated overlay '${message.floatingId}' (success=$updated)")
            }
            is com.kavach.domain.model.FloatingHideMessage -> {
                logger.i("AppContainer", "Received Floating Hide request")
                if (message.floatingId != null) {
                    val hidden = floatingOverlayManager.hideFloating(message.floatingId)
                    val response = com.kavach.domain.model.FloatingResultMessage(
                        timestamp = System.currentTimeMillis(),
                        sessionId = message.sessionId,
                        requestId = message.requestId,
                        success = hidden,
                        floatingId = message.floatingId
                    )
                    webSocketRepository.sendMessage(response)
                    webSocketRepository.addLog("FLOATING: Dismissed overlay '${message.floatingId}'")
                } else {
                    floatingOverlayManager.hideAllFloating()
                    val response = com.kavach.domain.model.FloatingResultMessage(
                        timestamp = System.currentTimeMillis(),
                        sessionId = message.sessionId,
                        requestId = message.requestId,
                        success = true
                    )
                    webSocketRepository.sendMessage(response)
                    webSocketRepository.addLog("FLOATING: Dismissed all active floating overlays")
                }
            }
            is com.kavach.domain.model.VibrateTriggerMessage -> {
                logger.i("AppContainer", "Received Vibrate Trigger request (preset=${message.preset}, dur=${message.durationMs}ms)")
                val ok = hapticsManager.vibrate(
                    durationMs = message.durationMs,
                    preset = message.preset,
                    pattern = message.patternMs,
                    amplitude = message.amplitude
                )
                val response = com.kavach.domain.model.VibrateTriggerResultMessage(
                    timestamp = System.currentTimeMillis(),
                    sessionId = message.sessionId,
                    requestId = message.requestId,
                    success = ok,
                    errorMessage = if (!ok) "Vibration not supported or hardware failed" else null
                )
                webSocketRepository.sendMessage(response)
                webSocketRepository.addLog("VIBRATE: Triggered haptic (success=$ok)")
            }
            is com.kavach.domain.model.AudioPlayMessage -> {
                logger.i("AppContainer", "Received Audio Play request (type=${message.soundType})")
                val ok = when (message.soundType?.lowercase()) {
                    "beep" -> soundPlayerManager.playBeep(toneType = message.beepTone)
                    "file" -> message.audioPath?.let { soundPlayerManager.playAudioFile(it, loop = message.loop) } ?: false
                    else -> soundPlayerManager.playSystemSound(type = message.soundType ?: "notification", loop = message.loop)
                }
                val response = com.kavach.domain.model.AudioPlayResultMessage(
                    timestamp = System.currentTimeMillis(),
                    sessionId = message.sessionId,
                    requestId = message.requestId,
                    success = ok,
                    errorMessage = if (!ok) "Failed to play audio resource" else null
                )
                webSocketRepository.sendMessage(response)
                webSocketRepository.addLog("AUDIO: Play sound type '${message.soundType}' (success=$ok)")
            }
            is com.kavach.domain.model.AudioStopMessage -> {
                soundPlayerManager.stop()
                val response = com.kavach.domain.model.AudioStopResultMessage(
                    timestamp = System.currentTimeMillis(),
                    sessionId = message.sessionId,
                    requestId = message.requestId,
                    success = true
                )
                webSocketRepository.sendMessage(response)
                webSocketRepository.addLog("AUDIO: Stopped audio playback")
            }
            is com.kavach.domain.model.VolumeGetMessage -> {
                logger.i("AppContainer", "Received Volume Get request")
                val status = volumeManager.getAudioStatus()
                val streamData = status.streams.map {
                    com.kavach.domain.model.StreamVolumeData(
                        stream = it.stream,
                        currentVolume = it.currentVolume,
                        maxVolume = it.maxVolume,
                        minVolume = it.minVolume,
                        percentage = it.percentage
                    )
                }
                val response = com.kavach.domain.model.VolumeGetResultMessage(
                    timestamp = System.currentTimeMillis(),
                    sessionId = message.sessionId,
                    requestId = message.requestId,
                    ringerMode = status.ringerMode,
                    isMusicActive = status.isMusicActive,
                    isSpeakerphoneOn = status.isSpeakerphoneOn,
                    streams = streamData
                )
                webSocketRepository.sendMessage(response)
                webSocketRepository.addLog("VOLUME: Fetched volume status (mode=${status.ringerMode})")
            }
            is com.kavach.domain.model.VolumeSetMessage -> {
                logger.i("AppContainer", "Received Volume Set request (stream=${message.stream}, vol=${message.volume})")
                var ok = true
                if (message.volume != null) {
                    ok = volumeManager.setStreamVolume(message.stream, message.volume, message.showUi)
                }
                if (message.ringerMode != null) {
                    ok = volumeManager.setRingerMode(message.ringerMode) && ok
                }
                val response = com.kavach.domain.model.VolumeSetResultMessage(
                    timestamp = System.currentTimeMillis(),
                    sessionId = message.sessionId,
                    requestId = message.requestId,
                    success = ok,
                    errorMessage = if (!ok) "Failed to set volume/ringer settings" else null
                )
                webSocketRepository.sendMessage(response)
                webSocketRepository.addLog("VOLUME: Set volume for ${message.stream} (success=$ok)")
            }
            is com.kavach.domain.model.AppListMessage -> {
                logger.i("AppContainer", "Received App List request")
                val list = appLauncherManager.getInstalledApps(message.includeSystem)
                val appData = list.map {
                    com.kavach.domain.model.AppEntryData(
                        appName = it.appName,
                        packageName = it.packageName,
                        versionName = it.versionName,
                        isSystemApp = it.isSystemApp
                    )
                }
                val response = com.kavach.domain.model.AppListResultMessage(
                    timestamp = System.currentTimeMillis(),
                    sessionId = message.sessionId,
                    requestId = message.requestId,
                    totalApps = appData.size,
                    apps = appData
                )
                webSocketRepository.sendMessage(response)
                webSocketRepository.addLog("APPS: Returned ${appData.size} installed applications")
            }
            is com.kavach.domain.model.AppLaunchMessage -> {
                logger.i("AppContainer", "Received App Launch request")
                val (ok, target) = when {
                    !message.packageName.isNullOrBlank() -> {
                        Pair(appLauncherManager.launchApp(message.packageName), message.packageName)
                    }
                    !message.url.isNullOrBlank() -> {
                        Pair(appLauncherManager.openUrl(message.url), message.url)
                    }
                    else -> Pair(false, null)
                }
                val response = com.kavach.domain.model.AppLaunchResultMessage(
                    timestamp = System.currentTimeMillis(),
                    sessionId = message.sessionId,
                    requestId = message.requestId,
                    success = ok,
                    launchedTarget = target,
                    errorMessage = if (!ok) "Target not found or launch failed" else null
                )
                webSocketRepository.sendMessage(response)
                webSocketRepository.addLog("APPS: Launched '$target' (success=$ok)")
            }
            is com.kavach.domain.model.MediaTrimMessage -> {
                applicationScope.launch(Dispatchers.IO) {
                    try {
                        val uri = android.net.Uri.parse(message.mediaUri)
                        val out = mediaEngine.trimVideo(uri, message.startSeconds, message.durationSeconds, message.exact)
                        val response = com.kavach.domain.model.MediaTrimResultMessage(
                            timestamp = System.currentTimeMillis(),
                            sessionId = message.sessionId,
                            requestId = message.requestId,
                            success = out != null,
                            outputPath = out,
                            errorMessage = if (out == null) "Trim operation failed" else null
                        )
                        webSocketRepository.sendMessage(response)
                        webSocketRepository.addLog("FFMPEG: Trimmed video (out: $out)")
                    } catch (e: Exception) {
                        val response = com.kavach.domain.model.MediaTrimResultMessage(
                            timestamp = System.currentTimeMillis(),
                            sessionId = message.sessionId,
                            requestId = message.requestId,
                            success = false,
                            errorMessage = e.message ?: "Trim failed"
                        )
                        webSocketRepository.sendMessage(response)
                    }
                }
            }
            is com.kavach.domain.model.MediaGifMessage -> {
                applicationScope.launch(Dispatchers.IO) {
                    try {
                        val uri = android.net.Uri.parse(message.mediaUri)
                        val out = mediaEngine.generateGif(uri, message.startSeconds, message.durationSeconds, message.fps, message.width)
                        val response = com.kavach.domain.model.MediaGifResultMessage(
                            timestamp = System.currentTimeMillis(),
                            sessionId = message.sessionId,
                            requestId = message.requestId,
                            success = out != null,
                            outputPath = out,
                            errorMessage = if (out == null) "GIF generation failed" else null
                        )
                        webSocketRepository.sendMessage(response)
                        webSocketRepository.addLog("FFMPEG: Created GIF (out: $out)")
                    } catch (e: Exception) {
                        val response = com.kavach.domain.model.MediaGifResultMessage(
                            timestamp = System.currentTimeMillis(),
                            sessionId = message.sessionId,
                            requestId = message.requestId,
                            success = false,
                            errorMessage = e.message ?: "GIF generation failed"
                        )
                        webSocketRepository.sendMessage(response)
                    }
                }
            }
            is com.kavach.domain.model.MediaSpeedMessage -> {
                applicationScope.launch(Dispatchers.IO) {
                    try {
                        val uri = android.net.Uri.parse(message.mediaUri)
                        val out = mediaEngine.changeSpeed(uri, message.speedFactor)
                        val response = com.kavach.domain.model.MediaSpeedResultMessage(
                            timestamp = System.currentTimeMillis(),
                            sessionId = message.sessionId,
                            requestId = message.requestId,
                            success = out != null,
                            outputPath = out,
                            errorMessage = if (out == null) "Speed change failed" else null
                        )
                        webSocketRepository.sendMessage(response)
                        webSocketRepository.addLog("FFMPEG: Changed speed x${message.speedFactor} (out: $out)")
                    } catch (e: Exception) {
                        val response = com.kavach.domain.model.MediaSpeedResultMessage(
                            timestamp = System.currentTimeMillis(),
                            sessionId = message.sessionId,
                            requestId = message.requestId,
                            success = false,
                            errorMessage = e.message ?: "Speed change failed"
                        )
                        webSocketRepository.sendMessage(response)
                    }
                }
            }
            is com.kavach.domain.model.MediaMuteMessage -> {
                applicationScope.launch(Dispatchers.IO) {
                    try {
                        val uri = android.net.Uri.parse(message.mediaUri)
                        val out = mediaEngine.muteVideo(uri)
                        val response = com.kavach.domain.model.MediaMuteResultMessage(
                            timestamp = System.currentTimeMillis(),
                            sessionId = message.sessionId,
                            requestId = message.requestId,
                            success = out != null,
                            outputPath = out,
                            errorMessage = if (out == null) "Mute operation failed" else null
                        )
                        webSocketRepository.sendMessage(response)
                        webSocketRepository.addLog("FFMPEG: Stripped audio (out: $out)")
                    } catch (e: Exception) {
                        val response = com.kavach.domain.model.MediaMuteResultMessage(
                            timestamp = System.currentTimeMillis(),
                            sessionId = message.sessionId,
                            requestId = message.requestId,
                            success = false,
                            errorMessage = e.message ?: "Mute failed"
                        )
                        webSocketRepository.sendMessage(response)
                    }
                }
            }
            is com.kavach.domain.model.SensorGetMessage -> {
                applicationScope.launch(Dispatchers.IO) {
                    val snap = sensorHubManager.getSnapshot()
                    val response = com.kavach.domain.model.SensorGetResultMessage(
                        timestamp = System.currentTimeMillis(),
                        sessionId = message.sessionId,
                        requestId = message.requestId,
                        accelerometer = snap.accelerometer?.let { com.kavach.domain.model.SensorVectorData(it.x, it.y, it.z) },
                        gyroscope = snap.gyroscope?.let { com.kavach.domain.model.SensorVectorData(it.x, it.y, it.z) },
                        magneticField = snap.magneticField?.let { com.kavach.domain.model.SensorVectorData(it.x, it.y, it.z) },
                        compassHeadingDegrees = snap.compassHeadingDegrees,
                        compassCardinal = snap.compassCardinal,
                        ambientLightLux = snap.ambientLightLux,
                        proximityCm = snap.proximityCm,
                        isNear = snap.isNear,
                        pressureHpa = snap.pressureHpa,
                        ambientTemperatureC = snap.ambientTemperatureC,
                        relativeHumidityPct = snap.relativeHumidityPct,
                        stepCount = snap.stepCount,
                        availableSensors = snap.availableSensorNames
                    )
                    webSocketRepository.sendMessage(response)
                    webSocketRepository.addLog("SENSOR: Dispatched snapshot (${snap.availableSensorNames.size} sensors)")
                }
            }
            is com.kavach.domain.model.DisplayGetMessage -> {
                val disp = displayPowerManager.getDisplayDetails()
                val response = com.kavach.domain.model.DisplayGetResultMessage(
                    timestamp = System.currentTimeMillis(),
                    sessionId = message.sessionId,
                    requestId = message.requestId,
                    widthPixels = disp.widthPixels,
                    heightPixels = disp.heightPixels,
                    densityDpi = disp.densityDpi,
                    densityScale = disp.densityScale,
                    refreshRateHz = disp.refreshRateHz,
                    orientation = disp.orientation,
                    isHdr = disp.isHdr,
                    currentBrightness = disp.currentBrightness,
                    isAutoBrightness = disp.isAutoBrightness,
                    screenTimeoutMs = disp.screenTimeoutMs,
                    isInteractive = disp.isInteractive,
                    isPowerSaveMode = disp.isPowerSaveMode
                )
                webSocketRepository.sendMessage(response)
                webSocketRepository.addLog("DISPLAY: Dispatched info (${disp.widthPixels}x${disp.heightPixels}, bright=${disp.currentBrightness})")
            }
            is com.kavach.domain.model.DisplaySetMessage -> {
                var ok = true
                var err: String? = null
                if (message.brightness != null) {
                    val brightOk = displayPowerManager.setBrightness(message.brightness)
                    if (!brightOk) {
                        ok = false
                        err = "Failed to set brightness (requires WRITE_SETTINGS permission)"
                    }
                }
                if (message.autoBrightness != null) {
                    val autoOk = displayPowerManager.setAutoBrightness(message.autoBrightness)
                    if (!autoOk) {
                        ok = false
                        err = "Failed to set auto-brightness"
                    }
                }
                if (message.keepScreenOn != null) {
                    if (message.keepScreenOn) {
                        displayPowerManager.acquireWakeLock()
                    } else {
                        displayPowerManager.releaseWakeLock()
                    }
                }
                val response = com.kavach.domain.model.DisplaySetResultMessage(
                    timestamp = System.currentTimeMillis(),
                    sessionId = message.sessionId,
                    requestId = message.requestId,
                    success = ok,
                    errorMessage = err
                )
                webSocketRepository.sendMessage(response)
                webSocketRepository.addLog("DISPLAY: Updated settings (success=$ok)")
            }
            is com.kavach.domain.model.NetworkTelemetryGetMessage -> {
                val net = networkTelemetryManager.getTelemetry()
                val response = com.kavach.domain.model.NetworkTelemetryGetResultMessage(
                    timestamp = System.currentTimeMillis(),
                    sessionId = message.sessionId,
                    requestId = message.requestId,
                    activeTransport = net.activeTransport,
                    isConnected = net.isConnected,
                    isMetered = net.isMetered,
                    wifi = net.wifi?.let {
                        com.kavach.domain.model.WifiInfoData(
                            ssid = it.ssid,
                            bssid = it.bssid,
                            rssiDbm = it.rssiDbm,
                            signalLevel = it.signalLevel,
                            linkSpeedMbps = it.linkSpeedMbps,
                            frequencyMhz = it.frequencyMhz,
                            wifiStandard = it.wifiStandard,
                            ipAddress = it.ipAddress
                        )
                    },
                    cellular = net.cellular?.let {
                        com.kavach.domain.model.CellularInfoData(
                            carrierName = it.carrierName,
                            networkType = it.networkType,
                            isRoaming = it.isRoaming,
                            simState = it.simState
                        )
                    },
                    localIpv4Addresses = net.localIpv4Addresses
                )
                webSocketRepository.sendMessage(response)
                webSocketRepository.addLog("NETWORK: Dispatched telemetry (transport=${net.activeTransport})")
            }
            is com.kavach.domain.model.DeviceDetailsGetMessage -> {
                val dev = deviceDetailsManager.getDeviceInfo()
                val response = com.kavach.domain.model.DeviceDetailsGetResultMessage(
                    timestamp = System.currentTimeMillis(),
                    sessionId = message.sessionId,
                    requestId = message.requestId,
                    manufacturer = dev.manufacturer,
                    model = dev.model,
                    brand = dev.brand,
                    board = dev.board,
                    hardware = dev.hardware,
                    androidVersion = dev.androidVersion,
                    sdkInt = dev.sdkInt,
                    securityPatch = dev.securityPatch,
                    primaryAbi = dev.primaryAbi,
                    supportedAbis = dev.supportedAbis,
                    cpuCores = dev.cpuCores,
                    ramTotalGb = dev.ramTotalGb,
                    ramAvailableGb = dev.ramAvailableGb,
                    ramUsedPct = dev.ramUsedPct,
                    storageTotalGb = dev.storageTotalGb,
                    storageFreeGb = dev.storageFreeGb,
                    storageUsedPct = dev.storageUsedPct,
                    uptimeSeconds = dev.uptimeSeconds,
                    batteryPct = dev.batteryPct,
                    isCharging = dev.isCharging,
                    batteryTempC = dev.batteryTempC,
                    isThermalThrottling = dev.isThermalThrottling
                )
                webSocketRepository.sendMessage(response)
                webSocketRepository.addLog("DEVICE: Dispatched detailed specs (${dev.manufacturer} ${dev.model})")
            }
            else -> {
                // AI_STREAM and other dynamic packets are handled in handleRawIncomingWebSocketMessage
            }
        }
    }

    private fun handleRawIncomingWebSocketMessage(rawText: String, replySink: ((String) -> Unit)? = null) {
        fun sendWsReply(payload: String) {
            if (replySink != null) {
                try {
                    replySink.invoke(payload)
                } catch (_: Exception) {}
            } else {
                applicationScope.launch {
                    webSocketRepository.sendRaw(payload)
                }
            }
        }
        val data = try { org.json.JSONObject(rawText) } catch (e: Exception) { return }
        val type = data.optString("type", "").uppercase()

        // 0. Ignore handshake greetings, heartbeats, telemetry updates, and outbound result/error packets to prevent relay loops
        if (type.isEmpty() ||
            type in listOf(
                "HELLO",
                "PING",
                "PONG",
                "AUTH_REQUIRED",
                "AUTH_SUCCESS",
                "AUTH_FAILED",
                "REGISTER_SUCCESS",
                "REGISTER_FAILED",
                "AUTH_LOGIN_RESULT",
                "AUTH_POLL_RESULT",
                "HTTP_RPC_RESULT",
                "ACCESSIBILITY_SCREEN_UPDATE",
                "AUDIO_STREAM",
                "AUDIO_END",
                "STATUS",
                "HEARTBEAT",
                "ERROR",
                "STT_RESULT",
                "STT_PARTIAL",
                "STT_FINAL",
                "STT_START",
                "STT_END",
                "STT_ERROR",
                "TTS_STREAM",
                "AI_END"
            ) ||
            type.endsWith("_RESULT")
        ) {
            return
        }

        // 1. Device Pairing, Interactive On-Device Login & Client Registration Handshake
        if (type == "HTTP_RPC") {
            val endpoint = data.optString("endpoint", "")
            if (endpoint in listOf("/api/auth/login", "/api/auth/poll", "/api/auth/pair", "/api/pair/verify", "/api/auth/status")) {
                // Scrub spoofable internal keys from untrusted WebSocket RPC payloads
                data.remove("_socketClientIp")
                data.remove("_isMasterTokenAuth")
                data.put("_socketClientIp", "ws-relay")
                val wsTok = data.optString("token", data.optString("clientToken", data.optString("apiKey", "")))
                data.put("_isMasterTokenAuth", securityShield.isMasterToken(wsTok, null))

                val res = if (securityShield.isPanicLockdown) {
                    org.json.JSONObject().apply {
                        put("success", false)
                        put("error", "403 Forbidden: Device is in Panic Lockdown.")
                    }
                } else {
                    handleHttpRestApi(endpoint, data)
                }
                res.put("type", "HTTP_RPC_RESULT")
                res.put("endpoint", endpoint)
                res.put("requestId", data.optString("requestId", res.optString("requestId", "")))
                res.put("reqId", data.optString("reqId", data.optString("requestId", "")))
                sendWsReply(res.toString())
                return
            }
        }

        when (type) {
            "AUTH_LOGIN", "PAIR_LOGIN" -> {
                if (securityShield.isPanicLockdown) {
                    val locked = org.json.JSONObject().apply {
                        put("type", "AUTH_LOGIN_RESULT")
                        put("success", false)
                        put("error", "Device is in Panic Lockdown.")
                    }
                    sendWsReply(locked.toString())
                    return
                }
                val clientName = data.optString("clientName", "Termux Bridge")
                val realIp = "ws-relay"
                val deviceId = data.optString(
                    "securityDeviceId",
                    data.optString("deviceId", "SEC-DEV-" + System.currentTimeMillis().toString(16).uppercase().takeLast(8))
                )
                val req = securityShield.createPendingPairRequest(clientName, realIp, deviceId)

                android.os.Handler(android.os.Looper.getMainLooper()).post {
                    try {
                        notificationRepository.showAuthNotification(
                            title = "🔐 Authentication Required",
                            message = "Security Device ID: $deviceId ($clientName) requests access. Tap to approve.",
                            securityDeviceId = deviceId,
                            requestId = req.requestId
                        )
                        toastCustomizer.showToast(
                            com.kavach.ui.overlay.ToastCustomizer.ToastOptions(
                                message = "🔐 Auth Request: $deviceId ($clientName)",
                                icon = "security"
                            )
                        )
                    } catch (_: Exception) {}
                }

                val resp = org.json.JSONObject().apply {
                    put("type", "AUTH_LOGIN_RESULT")
                    put("requestId", req.requestId)
                    put("reqId", data.optString("reqId", req.requestId))
                    put("success", true)
                    put("deviceId", req.deviceId)
                    put("securityDeviceId", req.deviceId)
                    put("status", "PENDING")
                    put("message", "Authentication request created on Android device.")
                }
                sendWsReply(resp.toString())
                webSocketRepository.addLog("WS AUTH_LOGIN: Pending approval for $clientName ($deviceId)")
                return
            }
            "AUTH_POLL", "PAIR_POLL" -> {
                val reqId = data.optString("requestId", data.optString("id", ""))
                val devId = data.optString("securityDeviceId", data.optString("deviceId", ""))
                val req = securityShield.getPendingPairRequestForPoll(reqId, devId)

                val resp = org.json.JSONObject().apply {
                    put("type", "AUTH_POLL_RESULT")
                    put("reqId", data.optString("reqId", reqId))
                    if (req != null) {
                        put("requestId", req.requestId)
                        put("deviceId", req.deviceId)
                        put("securityDeviceId", req.deviceId)
                        put("status", req.status)
                        if (req.status == "APPROVED") {
                            val tok = req.clientToken
                            if (!tok.isNullOrBlank()) {
                                put("success", true)
                                put("clientToken", tok)
                                put("clientName", req.clientName)
                                securityShield.markApprovedPairTokenDelivered(req.requestId)
                            } else {
                                put("success", false)
                                put("error", "Pairing token already consumed or expired. Please run 'python send_cmd.py login' again.")
                            }
                        } else if (req.status == "DENIED") {
                            put("success", true)
                            put("error", "Authentication was denied by user")
                        } else {
                            put("success", true)
                        }
                    } else {
                        put("success", false)
                        put("error", "Request or Device ID not found or expired")
                    }
                }
                sendWsReply(resp.toString())
                return
            }
            "REGISTER_REQUEST", "PAIR_REQUEST" -> {
                val pairingCode = data.optString("pairingCode", data.optString("code", data.optString("token", "")))
                val clientName = data.optString("clientName", "Termux-Workstation")
                val deviceId = data.optString("deviceId", "client_" + System.currentTimeMillis())

                val (success, tokenOrError) = securityShield.pairClientDevice(
                    pairingCodeOrToken = pairingCode,
                    clientName = clientName,
                    clientIp = "ws-relay",
                    providedDeviceId = deviceId
                )

                val resp = org.json.JSONObject().apply {
                    put("type", if (success) "REGISTER_SUCCESS" else "REGISTER_FAILED")
                    put("success", success)
                    if (success) {
                        put("clientToken", tokenOrError)
                        put("deviceId", deviceId)
                        put("clientName", clientName)
                        put("message", "Device successfully paired and authenticated")
                    } else {
                        put("error", tokenOrError)
                        put("hint", "Verify 6-digit pairing code on phone screen.")
                    }
                }
                sendWsReply(resp.toString())
                webSocketRepository.addLog("WS PAIRING: ${if (success) "SUCCESS for $clientName" else "FAILED ($tokenOrError)"}")
                return
            }
            "AUTH_REQUEST", "AUTH_RESPONSE" -> {
                val token = data.optString("token", data.optString("clientToken", data.optString("apiKey", "")))
                val isValid = securityShield.verifyWebSocketRequest(token)
                val resp = org.json.JSONObject().apply {
                    put("type", if (isValid) "AUTH_SUCCESS" else "AUTH_FAILED")
                    put("success", isValid)
                    if (isValid) {
                        put("message", "Session authenticated")
                    } else {
                        put("error", "Unauthorized token. Pairing registration required.")
                    }
                }
                sendWsReply(resp.toString())
                webSocketRepository.addLog("WS AUTH: ${if (isValid) "SUCCESS" else "FAILED"}")
                return
            }
        }

        // 2. Strict Token Guard for ALL privileged WebSocket actions (no clientIp or sessionId bypass)
        val providedToken = data.optString("token", data.optString("clientToken", data.optString("apiKey", "")))
        val isAuthorized = securityShield.verifyWebSocketRequest(providedToken)

        if (!isAuthorized) {
            val errJson = org.json.JSONObject().apply {
                put("type", "AUTH_REQUIRED")
                put("requestId", data.optString("requestId", ""))
                put("reqId", data.optString("reqId", data.optString("requestId", "")))
                put("success", false)
                put("error", "401 Unauthorized: Remote command requires device pairing or valid token.")
                put("hint", "Run 'python send_cmd.py login' or pass 'token' in payload.")
            }
            sendWsReply(errJson.toString())
            webSocketRepository.addLog("WS BLOCKED: Unauthorized command '$type' rejected")
            return
        }

        // Scrub spoofable internal keys on WS HTTP_RPC forward and set real master flag from verified token
        if (type == "HTTP_RPC") {
            data.remove("_socketClientIp")
            data.put("_socketClientIp", "ws-relay")
            data.put("_isMasterTokenAuth", securityShield.isMasterToken(providedToken, null))
        }

        // 3. Dispatch Authenticated Commands
        when (type) {
            "HTTP_RPC" -> {
                val endpoint = data.optString("endpoint", "")
                val res = handleHttpRestApi(endpoint, data)
                res.put("type", "HTTP_RPC_RESULT")
                res.put("endpoint", endpoint)
                res.put("requestId", data.optString("requestId", res.optString("requestId", "")))
                res.put("reqId", data.optString("reqId", data.optString("requestId", "")))
                sendWsReply(res.toString())
                webSocketRepository.addLog("WS HTTP_RPC [$endpoint] -> ok=${res.optBoolean("success", true)}")
            }
            "AI_STREAM" -> handleAiStreamCommand(data, replySink)
            "ACCESSIBILITY_GESTURE" -> handleAccessibilityGestureRaw(data)
            "ACCESSIBILITY_INSPECT", "UI_TREE" -> handleAccessibilityInspectRaw(data, replySink)
            "SHELL_EXEC", "SHELL" -> {
                val cmd = data.optString("cmd", data.optString("command", ""))
                val timeoutMs = data.optLong("timeout_ms", data.optLong("timeoutMs", 15000L))
                val cwd = if (data.has("cwd")) data.optString("cwd") else null
                val res = deviceBridgeManager.executeShellCommand(cmd, timeoutMs, cwd)
                res.put("type", "SHELL_EXEC_RESULT")
                res.put("requestId", data.optString("requestId", ""))
                res.put("reqId", data.optString("reqId", data.optString("requestId", "")))
                sendWsReply(res.toString())
                webSocketRepository.addLog("WS SHELL [$cmd] -> exit=${res.optInt("exit_code", -1)} (${res.optLong("duration_ms")}ms)")
            }
            "UI_ACTION", "ACCESSIBILITY_TEXT" -> {
                val res = deviceBridgeManager.handleUiAction(data)
                res.put("type", "UI_ACTION_RESULT")
                res.put("requestId", data.optString("requestId", ""))
                res.put("reqId", data.optString("reqId", data.optString("requestId", "")))
                sendWsReply(res.toString())
                webSocketRepository.addLog("WS UI_ACTION [${res.optString("action")}] -> ok=${res.optBoolean("success")}")
            }
            "SCREEN_CAPTURE", "SCREENSHOT" -> {
                val quality = data.optInt("quality", 72)
                val maxDim = data.optInt("maxDimension", 960)
                val res = accessibilityRepository.takeScreenshotBase64(quality, maxDim)
                res.put("type", "SCREEN_CAPTURE_RESULT")
                res.put("sessionId", data.optString("sessionId", ""))
                res.put("requestId", data.optString("requestId", ""))
                res.put("reqId", data.optString("reqId", data.optString("requestId", "")))
                sendWsReply(res.toString())
                webSocketRepository.addLog("WS SCREEN_CAPTURE -> ok=${res.optBoolean("success")}")
            }
            "SYSTEM_TOGGLE" -> {
                val res = deviceBridgeManager.handleSystemToggle(data)
                res.put("type", "SYSTEM_TOGGLE_RESULT")
                res.put("requestId", data.optString("requestId", ""))
                res.put("reqId", data.optString("reqId", data.optString("requestId", "")))
                sendWsReply(res.toString())
                webSocketRepository.addLog("WS SYSTEM_TOGGLE [${res.optString("target")}] -> ok=${res.optBoolean("success")}")
            }
            "SYSTEM_STATUS" -> {
                val res = deviceBridgeManager.getSystemStatus()
                res.put("type", "SYSTEM_STATUS_RESULT")
                res.put("requestId", data.optString("requestId", ""))
                res.put("reqId", data.optString("reqId", data.optString("requestId", "")))
                sendWsReply(res.toString())
                webSocketRepository.addLog("WS SYSTEM_STATUS -> dispatched")
            }
            "FS_OP", "FILE_OP" -> {
                val op = data.optString("op", data.optString("operation", data.optString("action", "list")))
                val res = deviceBridgeManager.handleFileOperation(op, data)
                res.put("type", "FS_OP_RESULT")
                res.put("op", op)
                res.put("requestId", data.optString("requestId", ""))
                res.put("reqId", data.optString("reqId", data.optString("requestId", "")))
                sendWsReply(res.toString())
                webSocketRepository.addLog("WS FS_OP [$op] -> ok=${res.optBoolean("success")}")
            }
            "LOCATION_LIVE_START", "LOCATION_TRACK_START" -> {
                val interval = data.optLong("intervalMs", 1000L)
                val res = deviceBridgeManager.startLiveLocationTracking(interval)
                res.put("type", "LOCATION_LIVE_STATUS")
                sendWsReply(res.toString())
                webSocketRepository.addLog("WS LOCATION_LIVE_START -> ok=${res.optBoolean("success")}")
            }
            "LOCATION_LIVE_STOP", "LOCATION_TRACK_STOP" -> {
                val res = deviceBridgeManager.stopLiveLocationTracking()
                res.put("type", "LOCATION_LIVE_STATUS")
                sendWsReply(res.toString())
                webSocketRepository.addLog("WS LOCATION_LIVE_STOP -> stopped")
            }
            "CLIPBOARD_OP", "CLIPBOARD_GET", "CLIPBOARD_SET" -> {
                val op = if (type == "CLIPBOARD_SET" || data.has("text")) "set" else data.optString("op", "get")
                val res = org.json.JSONObject().apply {
                    put("type", "CLIPBOARD_RESULT")
                    put("requestId", data.optString("requestId", ""))
                    put("reqId", data.optString("reqId", data.optString("requestId", "")))
                    if (op.equals("set", ignoreCase = true)) {
                        val txt = data.optString("text", "")
                        val ok = deviceBridgeManager.setClipboardText(txt)
                        put("success", ok)
                        put("text", txt)
                    } else {
                        val txt = deviceBridgeManager.getClipboardText()
                        put("success", true)
                        put("text", txt)
                    }
                }
                sendWsReply(res.toString())
                webSocketRepository.addLog("WS CLIPBOARD [$op] -> ok=${res.optBoolean("success")}")
            }
            else -> handleAiStreamCommand(data, replySink)
        }
    }

    fun sendAiResponse(action: String, data: Map<String, Any?>, replySink: ((String) -> Unit)? = null) {
        val json = org.json.JSONObject()
        json.put("type", "AI_STREAM_RESULT")
        json.put("action", action)
        json.put("success", data["success"] as? Boolean ?: true)
        for ((k, v) in data) {
            if (k != "success") {
                if (v is Map<*, *>) {
                    val subObj = org.json.JSONObject()
                    for ((subK, subV) in v) {
                        subObj.put(subK.toString(), subV)
                    }
                    json.put(k, subObj)
                } else if (v is List<*>) {
                    val arr = org.json.JSONArray()
                    for (item in v) {
                        if (item is Map<*, *>) {
                            val subObj = org.json.JSONObject()
                            for ((subK, subV) in item) {
                                subObj.put(subK.toString(), subV)
                            }
                            arr.put(subObj)
                        } else {
                            arr.put(item)
                        }
                    }
                    json.put(k, arr)
                } else {
                    json.put(k, v)
                }
            }
        }
        if (replySink != null) {
            try {
                replySink.invoke(json.toString())
            } catch (_: Exception) {}
            webSocketRepository.addLog("AI_STREAM_RESULT [$action]: success=${json.optBoolean("success")}")
        } else {
            applicationScope.launch {
                webSocketRepository.sendRaw(json.toString())
                webSocketRepository.addLog("AI_STREAM_RESULT [$action]: success=${json.optBoolean("success")}")
            }
        }
    }

    private fun checkPermissionStatus(permission: String): String {
        return if (ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED) {
            "AVAILABLE"
        } else {
            "PERMISSION_REQUIRED"
        }
    }

    private fun handleAiStreamCommand(data: org.json.JSONObject, replySink: ((String) -> Unit)? = null) {
        val action = data.optString("action", "").uppercase()
        if (action.isBlank()) {
            val textChunk = data.optString("textChunk", data.optString("text", data.optString("message", ""))).trim()
            if (textChunk.isNotBlank()) {
                webSocketRepository.addLog("WS Termux: $textChunk")
                try {
                    android.os.Handler(android.os.Looper.getMainLooper()).post {
                        android.widget.Toast.makeText(context, "Termux: $textChunk", android.widget.Toast.LENGTH_SHORT).show()
                    }
                } catch (ignored: Exception) {}
                val reqId = data.optString("requestId", data.optString("reqId", ""))
                sendAiResponse(
                    "MESSAGE",
                    mapOf("success" to true, "textChunk" to textChunk, "requestId" to reqId, "reqId" to reqId),
                    replySink
                )
            }
            return
        }

        logger.i("AppContainer", "Handling AI_STREAM command action: $action")
        webSocketRepository.addLog("AI_STREAM action: $action")

        try {
            when (action) {
                "TTS" -> {
                    val text = data.optString("text", data.optString("message", ""))
                    val pitch = data.optDouble("pitch", 1.0).toFloat()
                    val rate = data.optDouble("rate", 1.0).toFloat()
                    val tts = textToSpeech
                    if (tts != null) {
                        tts.setPitch(pitch)
                        tts.setSpeechRate(rate)
                        tts.speak(text, android.speech.tts.TextToSpeech.QUEUE_FLUSH, null, "acagent_tts")
                        sendAiResponse("TTS", mapOf("success" to true, "text" to text))
                    } else {
                        sendAiResponse("TTS", mapOf("success" to false, "error" to "TTS not initialized"))
                    }
                }
                "TOAST" -> {
                    val message = data.optString("message", data.optString("text", "Aura Alert"))
                    val icon = data.optString("icon", "info")
                    android.os.Handler(android.os.Looper.getMainLooper()).post {
                        toastCustomizer.showToast(
                            com.kavach.ui.overlay.ToastCustomizer.ToastOptions(
                                message = message,
                                icon = icon
                            )
                        )
                    }
                    sendAiResponse("TOAST", mapOf("success" to true, "message" to message))
                }
                "VIBRATE" -> {
                    val ok = if (data.has("durationMs")) {
                        val ms = data.optLong("durationMs", 100)
                        hapticsManager.vibrate(durationMs = ms)
                    } else {
                        val preset = data.optString("preset", "TICK")
                        hapticsManager.vibrate(preset = preset)
                    }
                    sendAiResponse("VIBRATE", mapOf("success" to ok))
                }
                "TORCH" -> {
                    val enabled = data.optBoolean("enabled", true)
                    val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as? android.hardware.camera2.CameraManager
                    var ok = false
                    var errorMsg: String? = null
                    try {
                        val cameraId = cameraManager?.cameraIdList?.firstOrNull { id ->
                            val chars = cameraManager.getCameraCharacteristics(id)
                            chars.get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
                        }
                        if (cameraManager != null && cameraId != null) {
                            cameraManager.setTorchMode(cameraId, enabled)
                            ok = true
                        } else {
                            errorMsg = "No flash unit available on device"
                        }
                    } catch (e: Exception) {
                        errorMsg = e.message
                    }
                    if (ok) {
                        sendAiResponse("TORCH", mapOf("success" to true, "enabled" to enabled))
                    } else {
                        sendAiResponse("TORCH", mapOf("success" to false, "error" to (errorMsg ?: "Failed to set torch")))
                    }
                }
                "AUDIO_PLAY" -> {
                    val type = data.optString("type", "notification")
                    val ok = soundPlayerManager.playSystemSound(type)
                    sendAiResponse("AUDIO_PLAY", mapOf("success" to ok, "type" to type))
                }
                "AUDIO_STOP" -> {
                    soundPlayerManager.stop()
                    sendAiResponse("AUDIO_STOP", mapOf("success" to true))
                }
                "VOLUME_GET" -> {
                    val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
                    sendAiResponse("VOLUME_GET", mapOf(
                        "success" to true,
                        "mediaVolume" to am.getStreamVolume(AudioManager.STREAM_MUSIC),
                        "mediaMax" to am.getStreamMaxVolume(AudioManager.STREAM_MUSIC),
                        "notifVolume" to am.getStreamVolume(AudioManager.STREAM_NOTIFICATION),
                        "ringVolume" to am.getStreamVolume(AudioManager.STREAM_RING),
                        "alarmVolume" to am.getStreamVolume(AudioManager.STREAM_ALARM),
                        "ringerMode" to when (am.ringerMode) {
                            AudioManager.RINGER_MODE_NORMAL -> "NORMAL"
                            AudioManager.RINGER_MODE_VIBRATE -> "VIBRATE"
                            AudioManager.RINGER_MODE_SILENT -> "SILENT"
                            else -> "UNKNOWN"
                        }
                    ))
                }
                "VOLUME_SET" -> {
                    val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
                    if (data.has("ringerMode")) {
                        volumeManager.setRingerMode(data.optString("ringerMode").uppercase())
                    } else {
                        val stream = data.optString("stream", "MEDIA")
                        val volume = data.optInt("volume", 5)
                        volumeManager.setStreamVolume(stream, volume)
                    }
                    sendAiResponse("VOLUME_SET", mapOf("success" to true))
                }
                "FLOATING_SHOW" -> {
                    val id = data.optString("floatingId", "default_floating")
                    val title = data.optString("title", "Aura System HUD")
                    val text = data.optString("text", "")
                    val subText = if (data.has("subText")) data.optString("subText") else null
                    val type = data.optString("type", "HUD")
                    val isDraggable = data.optBoolean("isDraggable", true)
                    val ok = floatingOverlayManager.showFloating(
                        com.kavach.ui.overlay.FloatingOverlayManager.FloatingOptions(
                            floatingId = id,
                            title = title,
                            text = text,
                            subText = subText,
                            type = type,
                            isDraggable = isDraggable
                        )
                    )
                    sendAiResponse("FLOATING_SHOW", mapOf("success" to ok, "floatingId" to id))
                }
                "FLOATING_HIDE" -> {
                    val id = data.optString("floatingId", "default_floating")
                    val ok = floatingOverlayManager.hideFloating(id)
                    sendAiResponse("FLOATING_HIDE", mapOf("success" to ok, "floatingId" to id))
                }
                "HUD_STATE" -> {
                    val res = hudStore.updateState(data)
                    sendAiResponse("HUD_STATE", mapOf("success" to res.optBoolean("success", true), "state" to res.optString("state")))
                }
                "HUD_PATCH" -> {
                    val res = hudStore.patchState(data)
                    sendAiResponse("HUD_PATCH", mapOf("success" to res.optBoolean("success", true), "state" to res.optString("state"), "patched" to true))
                }
                "HUD_COMMAND" -> {
                    val res = hudStore.handleRemoteCommand(data)
                    sendAiResponse("HUD_COMMAND", mapOf("success" to res.optBoolean("success", true), "state" to res.optString("state")))
                }
                "HUD_HIDE" -> {
                    val res = hudStore.hideAll()
                    sendAiResponse("HUD_HIDE", mapOf("success" to res.optBoolean("success", true)))
                }
                "HUD_RESET" -> {
                    val res = hudStore.resetState()
                    sendAiResponse("HUD_RESET", mapOf("success" to res.optBoolean("success", true), "state" to res.optString("state")))
                }
                "HUD_POLL" -> {
                    val res = hudStore.pollCommands()
                    sendAiResponse("HUD_POLL", mapOf("success" to true, "count" to res.optInt("count", 0), "state" to res.optString("state")))
                }
                "HUD_APPROVAL" -> {
                    val res = hudStore.setApprovalGate(data)
                    sendAiResponse("HUD_APPROVAL", mapOf("success" to res.optBoolean("success", true), "approvalActive" to res.optBoolean("approvalActive", false)))
                }
                "HUD_POINTER" -> {
                    val enabled = if (data.has("enabled") || data.has("pointerEnabled")) {
                        data.optBoolean("enabled", data.optBoolean("pointerEnabled", true))
                    } else if (data.has("showLabel") && !data.has("enabled")) {
                        null
                    } else {
                        !agyPointerOverlayManager.isPointerEnabled()
                    }
                    val showLabel = if (data.has("showLabel") && !data.isNull("showLabel")) {
                        data.optBoolean("showLabel", true)
                    } else null
                    val res = hudStore.setPointerConfig(enabled = enabled, showLabel = showLabel)
                    sendAiResponse(
                        "HUD_POINTER",
                        mapOf(
                            "success" to true,
                            "pointerEnabled" to res.optBoolean("pointerEnabled", true),
                            "showLabel" to res.optBoolean("showLabel", true)
                        )
                    )
                }
                "SENSORS" -> {
                    val snap = sensorHubManager.getSnapshot()
                    sendAiResponse("SENSORS", mapOf(
                        "success" to true,
                        "ambientLightLux" to (snap.ambientLightLux ?: 0f),
                        "pressureHpa" to (snap.pressureHpa ?: 1013.25f),
                        "compassHeadingDegrees" to (snap.compassHeadingDegrees ?: 0f),
                        "compassCardinal" to (snap.compassCardinal ?: "N"),
                        "proximityCm" to (snap.proximityCm ?: 5.0f),
                        "isNear" to (snap.isNear ?: false),
                        "accelerometer" to mapOf(
                            "x" to (snap.accelerometer?.x ?: 0f),
                            "y" to (snap.accelerometer?.y ?: 0f),
                            "z" to (snap.accelerometer?.z ?: 0f)
                        ),
                        "gyroscope" to mapOf(
                            "x" to (snap.gyroscope?.x ?: 0f),
                            "y" to (snap.gyroscope?.y ?: 0f),
                            "z" to (snap.gyroscope?.z ?: 0f)
                        )
                    ))
                }
                "DEVICE_INFO" -> {
                    val dev = deviceDetailsManager.getDeviceInfo()
                    sendAiResponse("DEVICE_INFO", mapOf(
                        "success" to true,
                        "manufacturer" to dev.manufacturer,
                        "model" to dev.model,
                        "androidVersion" to dev.androidVersion,
                        "sdkInt" to dev.sdkInt,
                        "cpuCores" to dev.cpuCores,
                        "ramTotalGb" to dev.ramTotalGb,
                        "ramAvailableGb" to dev.ramAvailableGb,
                        "ramUsedPct" to dev.ramUsedPct,
                        "storageTotalGb" to dev.storageTotalGb,
                        "storageFreeGb" to dev.storageFreeGb,
                        "batteryPct" to dev.batteryPct,
                        "batteryTempC" to dev.batteryTempC,
                        "isCharging" to dev.isCharging,
                        "isThermalThrottling" to dev.isThermalThrottling
                    ))
                }
                "NETWORK_INFO" -> {
                    val net = networkTelemetryManager.getTelemetry()
                    val wifiMap = net.wifi?.let {
                        mapOf(
                            "ssid" to it.ssid,
                            "rssiDbm" to it.rssiDbm,
                            "signalLevel" to it.signalLevel,
                            "linkSpeedMbps" to it.linkSpeedMbps,
                            "wifiStandard" to it.wifiStandard
                        )
                    } ?: emptyMap<String, Any>()
                    sendAiResponse("NETWORK_INFO", mapOf(
                        "success" to true,
                        "isConnected" to net.isConnected,
                        "activeTransport" to net.activeTransport,
                        "isMetered" to net.isMetered,
                        "localIpv4Addresses" to net.localIpv4Addresses,
                        "wifi" to wifiMap
                    ))
                }
                "APP_LIST" -> {
                    val includeSystem = data.optBoolean("includeSystem", false)
                    val filter = data.optString("filter", data.optString("query", ""))
                    var apps = appLauncherManager.getInstalledApps(includeSystem)
                    if (filter.isNotBlank()) {
                        apps = apps.filter { it.appName.contains(filter, ignoreCase = true) || it.packageName.contains(filter, ignoreCase = true) }
                    }
                    val appMaps = apps.map {
                        mapOf(
                            "label" to it.appName,
                            "appName" to it.appName,
                            "packageName" to it.packageName,
                            "versionName" to (it.versionName ?: ""),
                            "isSystemApp" to it.isSystemApp
                        )
                    }
                    sendAiResponse("APP_LIST", mapOf("success" to true, "totalApps" to appMaps.size, "apps" to appMaps))
                }
                "APP_LAUNCH" -> {
                    val pkg = data.optString("packageName", data.optString("app", data.optString("target", data.optString("query", ""))))
                    val url = data.optString("url", "")
                    val target = if (pkg.isNotBlank()) pkg else url
                    val ok = if (pkg.isNotBlank()) appLauncherManager.launchApp(pkg) else if (url.isNotBlank()) appLauncherManager.openUrl(url) else false
                    if (ok) {
                        sendAiResponse("APP_LAUNCH", mapOf("success" to true, "launchedTarget" to target))
                    } else {
                        sendAiResponse("APP_LAUNCH", mapOf("success" to false, "error" to "Could not find or launch target '$target'"))
                    }
                }
                "NOTIFICATION" -> {
                    val title = data.optString("title", "Aura Alert")
                    val message = data.optString("message", data.optString("text", ""))
                    val res = notificationRepository.showNotification(title, message)
                    sendAiResponse("NOTIFICATION", mapOf("success" to (res is com.kavach.capabilities.CapabilityResult.Success)))
                }
                "CLIPBOARD_SET" -> {
                    val text = data.optString("text", "")
                    val res = clipboardRepository.writeClipboard(text)
                    sendAiResponse("CLIPBOARD_SET", mapOf("success" to (res is com.kavach.capabilities.CapabilityResult.Success)))
                }
                "CLIPBOARD_GET" -> {
                    val res = clipboardRepository.readClipboard()
                    val text = (res as? com.kavach.capabilities.CapabilityResult.Success)?.data ?: ""
                    sendAiResponse("CLIPBOARD_GET", mapOf("success" to true, "text" to text))
                }
                "BRIGHTNESS" -> {
                    val level = data.optInt("brightness", 128)
                    val ok = displayPowerManager.setBrightness(level)
                    sendAiResponse("BRIGHTNESS", mapOf("success" to ok, "brightness" to level))
                }
                "CAPABILITIES" -> {
                    val isAccessibility = com.kavach.accessibility.AccessibilityServiceRegistry.activeService != null
                    val canOverlay = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) Settings.canDrawOverlays(context) else true
                    val caps = listOf(
                        mapOf("name" to "TTS", "category" to "AUDIO", "status" to "AVAILABLE"),
                        mapOf("name" to "MICROPHONE", "category" to "AUDIO", "status" to checkPermissionStatus(Manifest.permission.RECORD_AUDIO)),
                        mapOf("name" to "CAMERA", "category" to "CAMERA", "status" to checkPermissionStatus(Manifest.permission.CAMERA)),
                        mapOf("name" to "TORCH", "category" to "CAMERA", "status" to "AVAILABLE"),
                        mapOf("name" to "VIBRATOR", "category" to "HAPTICS", "status" to "AVAILABLE"),
                        mapOf("name" to "ACCELEROMETER", "category" to "SENSORS", "status" to "AVAILABLE"),
                        mapOf("name" to "GYROSCOPE", "category" to "SENSORS", "status" to "AVAILABLE"),
                        mapOf("name" to "LIGHT_SENSOR", "category" to "SENSORS", "status" to "AVAILABLE"),
                        mapOf("name" to "GPS", "category" to "LOCATION", "status" to checkPermissionStatus(Manifest.permission.ACCESS_FINE_LOCATION)),
                        mapOf("name" to "WIFI", "category" to "NETWORK", "status" to "AVAILABLE"),
                        mapOf("name" to "NOTIFICATIONS", "category" to "NOTIFICATIONS", "status" to if (android.os.Build.VERSION.SDK_INT >= 33) checkPermissionStatus(Manifest.permission.POST_NOTIFICATIONS) else "AVAILABLE"),
                        mapOf("name" to "CLIPBOARD", "category" to "STORAGE", "status" to "AVAILABLE"),
                        mapOf("name" to "ACCESSIBILITY", "category" to "ACCESSIBILITY", "status" to if (isAccessibility) "AVAILABLE" else "PERMISSION_REQUIRED"),
                        mapOf("name" to "FLOATING_HUD", "category" to "DISPLAY", "status" to if (canOverlay) "AVAILABLE" else "PERMISSION_REQUIRED"),
                        mapOf("name" to "FFMPEG_MEDIA", "category" to "MEDIA", "status" to "AVAILABLE"),
                        mapOf("name" to "APP_LAUNCHER", "category" to "SYSTEM", "status" to "AVAILABLE"),
                        mapOf("name" to "VOLUME_CONTROL", "category" to "AUDIO", "status" to "AVAILABLE"),
                        mapOf("name" to "BATTERY_MONITOR", "category" to "HARDWARE", "status" to "AVAILABLE")
                    )
                    sendAiResponse("CAPABILITIES", mapOf("success" to true, "totalCapabilities" to caps.size, "capabilities" to caps))
                }
                "LOCATION", "GPS" -> {
                    applicationScope.launch {
                        val loc = locationRepository.getCurrentLocation()
                        if (loc is com.kavach.capabilities.CapabilityResult.Success && loc.data != null) {
                            sendAiResponse("LOCATION", mapOf(
                                "success" to true,
                                "latitude" to loc.data.latitude,
                                "longitude" to loc.data.longitude,
                                "altitude" to loc.data.altitude,
                                "speed" to loc.data.speed,
                                "heading" to loc.data.heading,
                                "accuracy" to loc.data.accuracy
                            ))
                        } else {
                            sendAiResponse("LOCATION", mapOf("success" to false, "error" to "Location unavailable"))
                        }
                    }
                }
                "CAMERA_CAPTURE", "PHOTO" -> {
                    applicationScope.launch {
                        val res = backgroundCameraCaptureEngine.takePicture()
                        if (res is com.kavach.capabilities.CapabilityResult.Success && res.data != null) {
                            sendAiResponse("CAMERA_CAPTURE", mapOf("success" to true, "filePath" to res.data))
                        } else {
                            sendAiResponse("CAMERA_CAPTURE", mapOf("success" to false, "error" to "Camera capture unavailable"))
                        }
                    }
                }
                "DISPLAY_INFO" -> {
                    val disp = displayPowerManager.getDisplayDetails()
                    sendAiResponse("DISPLAY_INFO", mapOf(
                        "success" to true,
                        "widthPx" to disp.widthPixels,
                        "heightPx" to disp.heightPixels,
                        "densityDpi" to disp.densityDpi,
                        "refreshRateHz" to disp.refreshRateHz,
                        "orientation" to disp.orientation,
                        "isHdr" to disp.isHdr,
                        "brightness" to disp.currentBrightness,
                        "isInteractive" to disp.isInteractive,
                        "isPowerSaveMode" to disp.isPowerSaveMode
                    ))
                }
                "MEDIA_PROBE" -> {
                    val uriStr = data.optString("uri", data.optString("path", ""))
                    if (uriStr.isNotBlank()) {
                        applicationScope.launch {
                            val probe = mediaEngine.probe(android.net.Uri.parse(uriStr))
                            if (probe != null) {
                                sendAiResponse("MEDIA_PROBE", mapOf(
                                    "success" to true,
                                    "durationSeconds" to probe.durationSeconds,
                                    "container" to (probe.container ?: "unknown"),
                                    "bitrate" to (probe.videoStream?.bitrate ?: probe.audioStream?.bitrate ?: 0L),
                                    "width" to (probe.videoStream?.width ?: 0),
                                    "height" to (probe.videoStream?.height ?: 0),
                                    "codec" to (probe.videoStream?.codec ?: "unknown")
                                ))
                            } else {
                                sendAiResponse("MEDIA_PROBE", mapOf("success" to false, "error" to "Probe failed"))
                            }
                        }
                    } else {
                        sendAiResponse("MEDIA_PROBE", mapOf("success" to false, "error" to "Missing uri"))
                    }
                }
                "MEDIA_TRIM" -> {
                    val uriStr = data.optString("uri", "")
                    val startSec = data.optDouble("startSeconds", 0.0)
                    val durSec = data.optDouble("durationSeconds", 5.0)
                    applicationScope.launch {
                        val outPath = mediaEngine.trimVideo(android.net.Uri.parse(uriStr), startSec, durSec)
                        sendAiResponse("MEDIA_TRIM", mapOf("success" to (outPath != null), "outputPath" to (outPath ?: "")))
                    }
                }
                "MEDIA_GIF" -> {
                    val uriStr = data.optString("uri", "")
                    val startSec = data.optDouble("startSeconds", 0.0)
                    val durSec = data.optDouble("durationSeconds", 3.0)
                    applicationScope.launch {
                        val outPath = mediaEngine.generateGif(android.net.Uri.parse(uriStr), startSec, durSec)
                        sendAiResponse("MEDIA_GIF", mapOf("success" to (outPath != null), "outputPath" to (outPath ?: "")))
                    }
                }
                "MEDIA_MUTE" -> {
                    val uriStr = data.optString("uri", "")
                    applicationScope.launch {
                        val outPath = mediaEngine.muteVideo(android.net.Uri.parse(uriStr))
                        sendAiResponse("MEDIA_MUTE", mapOf("success" to (outPath != null), "outputPath" to (outPath ?: "")))
                    }
                }
                "MEDIA_SPEED" -> {
                    val uriStr = data.optString("uri", "")
                    val speed = data.optDouble("speedFactor", 1.5)
                    applicationScope.launch {
                        val outPath = mediaEngine.changeSpeed(android.net.Uri.parse(uriStr), speed)
                        sendAiResponse("MEDIA_SPEED", mapOf("success" to (outPath != null), "outputPath" to (outPath ?: "")))
                    }
                }
                "WAKE_LOCK" -> {
                    val acquire = data.optBoolean("acquire", true)
                    val ok = if (acquire) displayPowerManager.acquireWakeLock() else { displayPowerManager.releaseWakeLock(); true }
                    sendAiResponse("WAKE_LOCK", mapOf("success" to ok, "acquired" to acquire))
                }
                else -> {
                    sendAiResponse("ERROR", mapOf("success" to false, "error" to "Unknown action: $action"))
                }
            }
        } catch (e: Exception) {
            logger.e("AppContainer", "Error handling AI_STREAM action $action: ${e.message}", e)
            sendAiResponse(action, mapOf("success" to false, "error" to (e.message ?: "Execution failed")))
        }
    }

    private fun handleAccessibilityGestureRaw(data: org.json.JSONObject) {
        val action = data.optString("action", data.optString("gestureType", "CLICK")).uppercase()
        val durationMs = data.optLong("durationMs", 100L)
        val serviceActive = com.kavach.accessibility.AccessibilityServiceRegistry.activeService != null

        if (!serviceActive) {
            webSocketRepository.addLog("ACCESSIBILITY WARNING: Accessibility Service not active. Enable Termux Assistant in Settings.")
            return
        }

        when (action) {
            "TAP", "CLICK" -> {
                if (data.has("text") || data.has("label")) {
                    val searchLabel = data.optString("text", data.optString("label", ""))
                    accessibilityRepository.clickNodeByText(searchLabel) { ok ->
                        webSocketRepository.addLog("ACCESSIBILITY TAP text='$searchLabel': success=$ok")
                    }
                } else {
                    val x = data.optDouble("x", data.optDouble("startX", 0.0)).toFloat()
                    val y = data.optDouble("y", data.optDouble("startY", 0.0)).toFloat()
                    val req = com.kavach.accessibility.models.GestureRequestModel(
                        id = "tap-" + System.currentTimeMillis(),
                        type = "CLICK",
                        startX = x,
                        startY = y,
                        durationMs = durationMs
                    )
                    accessibilityRepository.triggerGesture(req) { ok ->
                        webSocketRepository.addLog("ACCESSIBILITY TAP at ($x, $y): success=$ok")
                    }
                }
            }
            "SWIPE", "DRAG" -> {
                val startX = data.optDouble("startX", 500.0).toFloat()
                val startY = data.optDouble("startY", 1500.0).toFloat()
                val endX = data.optDouble("endX", 500.0).toFloat()
                val endY = data.optDouble("endY", 300.0).toFloat()
                val req = com.kavach.accessibility.models.GestureRequestModel(
                    id = "swipe-" + System.currentTimeMillis(),
                    type = "SWIPE",
                    startX = startX,
                    startY = startY,
                    endX = endX,
                    endY = endY,
                    durationMs = durationMs
                )
                accessibilityRepository.triggerGesture(req) { ok ->
                    webSocketRepository.addLog("ACCESSIBILITY SWIPE from ($startX, $startY) to ($endX, $endY): success=$ok")
                }
            }
            "BACK" -> {
                val req = com.kavach.accessibility.models.GestureRequestModel(id = "back", type = "BACK", startX = 0f, startY = 0f)
                accessibilityRepository.triggerGesture(req) { }
            }
            "HOME" -> {
                val req = com.kavach.accessibility.models.GestureRequestModel(id = "home", type = "HOME", startX = 0f, startY = 0f)
                accessibilityRepository.triggerGesture(req) { }
            }
            "RECENTS" -> {
                val req = com.kavach.accessibility.models.GestureRequestModel(id = "recents", type = "RECENTS", startX = 0f, startY = 0f)
                accessibilityRepository.triggerGesture(req) { }
            }
            "NOTIFICATIONS" -> {
                val req = com.kavach.accessibility.models.GestureRequestModel(id = "notif", type = "NOTIFICATIONS", startX = 0f, startY = 0f)
                accessibilityRepository.triggerGesture(req) { }
            }
            "NEXT", "SCROLL_DOWN", "SCROLL_FORWARD" -> {
                accessibilityRepository.performScroll(forward = true) { ok ->
                    webSocketRepository.addLog("ACCESSIBILITY SCROLL_DOWN: success=$ok")
                }
            }
            "SCROLL_UP", "SCROLL_BACKWARD" -> {
                accessibilityRepository.performScroll(forward = false) { ok ->
                    webSocketRepository.addLog("ACCESSIBILITY SCROLL_UP: success=$ok")
                }
            }
        }
    }

    private fun handleAccessibilityInspectRaw(data: org.json.JSONObject, replySink: ((String) -> Unit)? = null) {
        val isServiceActive = com.kavach.accessibility.AccessibilityServiceRegistry.activeService != null
        val searchByText = if (data.has("searchByText")) data.optString("searchByText") else if (data.has("text")) data.optString("text") else null
        val searchByDesc = if (data.has("searchByDesc")) data.optString("searchByDesc") else if (data.has("desc")) data.optString("desc") else null
        val searchById = if (data.has("searchById")) data.optString("searchById") else if (data.has("viewId")) data.optString("viewId") else null

        val results = if (isServiceActive) {
            if (searchByText != null || searchByDesc != null || searchById != null) {
                accessibilityRepository.searchNodes(
                    text = searchByText,
                    contentDescription = searchByDesc,
                    viewId = searchById
                )
            } else {
                accessibilityRepository.getFullNodeTree()
            }
        } else {
            emptyList()
        }

        val respJson = org.json.JSONObject()
        respJson.put("type", "ACCESSIBILITY_INSPECT_RESULT")
        respJson.put("timestamp", System.currentTimeMillis())
        respJson.put("sessionId", data.optString("sessionId", "inspect"))
        respJson.put("success", isServiceActive)
        val arr = org.json.JSONArray()
        fun nodeToJson(node: com.kavach.accessibility.models.AccessibilityNodeModel): org.json.JSONObject {
            return org.json.JSONObject().apply {
                put("className", node.className ?: "")
                put("text", node.text ?: "")
                put("contentDescription", node.contentDescription ?: "")
                put("viewId", node.viewId ?: "")
                put("isClickable", node.isClickable)
                put("isScrollable", node.isScrollable)
                put("bounds", node.bounds)
                put("boundsInScreen", node.bounds)
                val cArr = org.json.JSONArray()
                for (child in node.children) {
                    cArr.put(nodeToJson(child))
                }
                put("children", cArr)
            }
        }
        for (rootNode in results) {
            arr.put(nodeToJson(rootNode))
        }
        respJson.put("nodes", arr)

        if (replySink != null) {
            try {
                replySink.invoke(respJson.toString())
            } catch (_: Exception) {}
            webSocketRepository.addLog("INSPECT: Returned ${results.size} root UI node(s)")
        } else {
            applicationScope.launch {
                webSocketRepository.sendRaw(respJson.toString())
                webSocketRepository.addLog("INSPECT: Returned ${results.size} root UI node(s)")
            }
        }
    }

    private fun handleHttpRestApi(endpoint: String, json: org.json.JSONObject): org.json.JSONObject {
        val cleanEndpoint = endpoint.substringBefore("?").trim().trimEnd('/')
        val result = org.json.JSONObject()
        try {
            when (cleanEndpoint) {
                "/api/tts" -> {
                    val text = json.optString("text", json.optString("message", "Hello from Aura"))
                    val pitch = json.optDouble("pitch", 1.0).toFloat()
                    val rate = json.optDouble("rate", 1.0).toFloat()
                    textToSpeech?.setPitch(pitch)
                    textToSpeech?.setSpeechRate(rate)
                    textToSpeech?.speak(text, android.speech.tts.TextToSpeech.QUEUE_FLUSH, null, "aura_http_tts")
                    result.put("success", true)
                    result.put("spokenText", text)
                }
                "/api/toast" -> {
                    val msg = json.optString("message", json.optString("text", "Aura Alert"))
                    val icon = json.optString("icon", "info")
                    val gravity = json.optString("gravity", "BOTTOM")
                    toastCustomizer.showToast(
                        com.kavach.ui.overlay.ToastCustomizer.ToastOptions(
                            message = msg,
                            icon = icon,
                            gravity = gravity,
                            backgroundColor = json.optString("backgroundColor", null),
                            textColor = json.optString("textColor", null)
                        )
                    )
                    result.put("success", true)
                    result.put("message", msg)
                }
                "/api/vibrate" -> {
                    val preset = json.optString("preset", null)
                    val dur = json.optLong("durationMs", 100L)
                    val ok = hapticsManager.vibrate(durationMs = dur, preset = preset)
                    result.put("success", ok)
                }
                "/api/audio/play" -> {
                    val type = json.optString("type", "notification")
                    val ok = soundPlayerManager.playSystemSound(type)
                    result.put("success", ok)
                }
                "/api/audio/stop" -> {
                    soundPlayerManager.stop()
                    result.put("success", true)
                }
                "/api/volume" -> {
                    if (json.has("stream") || json.has("volume") || json.has("ringerMode")) {
                        val stream = json.optString("stream", "MEDIA")
                        val vol = if (json.has("volume")) json.optInt("volume") else null
                        val rMode = json.optString("ringerMode", null)
                        if (vol != null) volumeManager.setStreamVolume(stream, vol)
                        if (rMode != null) volumeManager.setRingerMode(rMode)
                        result.put("success", true)
                    } else {
                        val status = volumeManager.getAudioStatus()
                        result.put("success", true)
                        result.put("ringerMode", status.ringerMode)
                        val arr = org.json.JSONArray()
                        status.streams.forEach {
                            arr.put(org.json.JSONObject().apply {
                                put("stream", it.stream)
                                put("volume", it.currentVolume)
                                put("max", it.maxVolume)
                                put("percentage", it.percentage)
                            })
                        }
                        result.put("streams", arr)
                    }
                }
                "/api/app/list" -> {
                    val includeSystem = json.optBoolean("includeSystem", false) || json.optBoolean("system", false) || json.optString("system", "").equals("true", ignoreCase = true)
                    val filter = json.optString("filter", "").ifBlank { json.optString("query", "").ifBlank { json.optString("search", "") } }
                    var apps = appLauncherManager.getInstalledApps(includeSystem)
                    if (filter.isNotBlank()) {
                        apps = apps.filter { it.appName.contains(filter, ignoreCase = true) || it.packageName.contains(filter, ignoreCase = true) }
                    }
                    val arr = org.json.JSONArray()
                    apps.forEach {
                        arr.put(org.json.JSONObject().apply {
                            put("appName", it.appName)
                            put("packageName", it.packageName)
                            put("versionName", it.versionName)
                            put("isSystemApp", it.isSystemApp)
                        })
                    }
                    result.put("success", true)
                    result.put("totalApps", apps.size)
                    result.put("apps", arr)
                }
                "/api/app/launch" -> {
                    val pkg = json.optString("packageName", "").ifBlank { json.optString("app", "").ifBlank { json.optString("query", "").ifBlank { json.optString("target", "") } } }
                    val url = json.optString("url", "")
                    val target = if (pkg.isNotBlank()) pkg else url
                    val ok = if (pkg.isNotBlank()) appLauncherManager.launchApp(pkg) else if (url.isNotBlank()) appLauncherManager.openUrl(url) else false
                    result.put("success", ok)
                    result.put("target", target)
                    if (!ok) {
                        result.put("error", if (target.isBlank()) "No app name or package specified" else "Could not find or launch '$target'")
                    }
                }
                "/api/torch" -> {
                    val enable = json.optBoolean("enabled", true)
                    var ok = false
                    try {
                        val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as? android.hardware.camera2.CameraManager
                        val cameraId = cameraManager?.cameraIdList?.firstOrNull { id ->
                            val chars = cameraManager.getCameraCharacteristics(id)
                            chars.get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
                        }
                        if (cameraManager != null && cameraId != null) {
                            cameraManager.setTorchMode(cameraId, enable)
                            ok = true
                        }
                    } catch (e: Exception) {
                        logger.e("AppContainer", "HTTP torch toggle failed", e)
                    }
                    result.put("success", ok)
                    result.put("torchEnabled", enable)
                }
                "/api/floating" -> {
                    val title = json.optString("title", "⚡ Aura Remote")
                    val text = json.optString("text", "Aura Floating HUD")
                    val subText = if (json.has("subText")) json.optString("subText") else null
                    val type = json.optString("type", "HUD")
                    val floatingId = json.optString("floatingId", "http_float")
                    val isDraggable = json.optBoolean("isDraggable", true)
                    val gravity = json.optString("gravity", "TOP_RIGHT")
                    val autoDismiss = json.optInt("autoDismiss", json.optInt("autoDismissSeconds", 0))

                    if (!floatingOverlayManager.hasPermission()) {
                        // Display as toast so user receives instant visual feedback
                        android.os.Handler(android.os.Looper.getMainLooper()).post {
                            toastCustomizer.showToast(
                                com.kavach.ui.overlay.ToastCustomizer.ToastOptions(
                                    message = "[$title] $text",
                                    icon = "layers"
                                )
                            )
                        }
                        result.put("success", false)
                        result.put("displayedAsToast", true)
                        result.put("error", "SYSTEM_ALERT_WINDOW permission required for persistent floating overlay. Enable 'Display over other apps' in Android Settings -> Apps -> Aura.")
                    } else {
                        val shown = floatingOverlayManager.showFloating(
                            com.kavach.ui.overlay.FloatingOverlayManager.FloatingOptions(
                                floatingId = floatingId,
                                title = title,
                                text = text,
                                subText = subText,
                                type = type,
                                gravity = gravity,
                                isDraggable = isDraggable,
                                autoDismissSeconds = autoDismiss
                            )
                        )
                        result.put("success", shown)
                        result.put("floatingId", floatingId)
                    }
                }
                "/api/hud/state" -> {
                    val res = hudStore.updateState(json)
                    val keys = res.keys()
                    while (keys.hasNext()) {
                        val k = keys.next()
                        result.put(k, res.get(k))
                    }
                }
                "/api/hud/patch" -> {
                    val res = hudStore.patchState(json)
                    val keys = res.keys()
                    while (keys.hasNext()) {
                        val k = keys.next()
                        result.put(k, res.get(k))
                    }
                }
                "/api/hud/reset" -> {
                    val res = hudStore.resetState()
                    val keys = res.keys()
                    while (keys.hasNext()) {
                        val k = keys.next()
                        result.put(k, res.get(k))
                    }
                }
                "/api/hud/command" -> {
                    val res = hudStore.handleRemoteCommand(json)
                    val keys = res.keys()
                    while (keys.hasNext()) {
                        val k = keys.next()
                        result.put(k, res.get(k))
                    }
                }
                "/api/hud/poll" -> {
                    val res = hudStore.pollCommands()
                    val keys = res.keys()
                    while (keys.hasNext()) {
                        val k = keys.next()
                        result.put(k, res.get(k))
                    }
                }
                "/api/hud/hide" -> {
                    val res = hudStore.hideAll()
                    val keys = res.keys()
                    while (keys.hasNext()) {
                        val k = keys.next()
                        result.put(k, res.get(k))
                    }
                }
                "/api/hud/pointer" -> {
                    val hasEnabled = json.has("enabled") || json.has("pointerEnabled")
                    val hasShowLabel = json.has("showLabel") && !json.isNull("showLabel")
                    val enabled = when {
                        hasEnabled -> json.optBoolean("enabled", json.optBoolean("pointerEnabled", true))
                        hasShowLabel -> null
                        else -> !agyPointerOverlayManager.isPointerEnabled()
                    }
                    val showLabel = if (hasShowLabel) json.optBoolean("showLabel", true) else null
                    val res = hudStore.setPointerConfig(enabled = enabled, showLabel = showLabel)
                    val keys = res.keys()
                    while (keys.hasNext()) {
                        val k = keys.next()
                        result.put(k, res.get(k))
                    }
                }
                "/api/hud/approval" -> {
                    val res = hudStore.setApprovalGate(json)
                    val keys = res.keys()
                    while (keys.hasNext()) {
                        val k = keys.next()
                        result.put(k, res.get(k))
                    }
                }
                "/api/notification" -> {
                    val title = json.optString("title", "Aura Notification")
                    val body = json.optString("message", json.optString("text", "Hello from HTTP API"))
                    val notifResult = notificationRepository.showNotification(title, body)
                    val ok = notifResult is com.kavach.capabilities.CapabilityResult.Success
                    result.put("success", ok)
                }
                "/api/sensors" -> {
                    val snap = sensorHubManager.getSnapshot()
                    result.put("success", true)
                    result.put("availableSensors", org.json.JSONArray(snap.availableSensorNames))
                    snap.ambientLightLux?.let { result.put("ambientLightLux", it.toDouble()) }
                    snap.proximityCm?.let { result.put("proximityCm", it.toDouble()) }
                    snap.isNear?.let { result.put("isNear", it) }
                    snap.pressureHpa?.let { result.put("pressureHpa", it.toDouble()) }
                    snap.compassHeadingDegrees?.let { result.put("compassHeadingDegrees", it.toDouble()) }
                    snap.compassCardinal?.let { result.put("compassCardinal", it) }
                    snap.stepCount?.let { result.put("stepCount", it.toDouble()) }
                    snap.accelerometer?.let {
                        result.put("accelerometer", org.json.JSONObject().apply {
                            put("x", it.x.toDouble())
                            put("y", it.y.toDouble())
                            put("z", it.z.toDouble())
                        })
                    }
                    snap.gyroscope?.let {
                        result.put("gyroscope", org.json.JSONObject().apply {
                            put("x", it.x.toDouble())
                            put("y", it.y.toDouble())
                            put("z", it.z.toDouble())
                        })
                    }
                }
                "/api/display" -> {
                    if (json.has("brightness") || json.has("autoBrightness") || json.has("keepScreenOn")) {
                        if (json.has("brightness")) displayPowerManager.setBrightness(json.optInt("brightness"))
                        if (json.has("autoBrightness")) displayPowerManager.setAutoBrightness(json.optBoolean("autoBrightness"))
                        if (json.has("keepScreenOn")) {
                            if (json.optBoolean("keepScreenOn")) {
                                displayPowerManager.acquireWakeLock()
                            } else {
                                displayPowerManager.releaseWakeLock()
                            }
                        }
                        result.put("success", true)
                    } else {
                        val disp = displayPowerManager.getDisplayDetails()
                        result.put("success", true)
                        result.put("widthPixels", disp.widthPixels)
                        result.put("heightPixels", disp.heightPixels)
                        result.put("densityDpi", disp.densityDpi)
                        result.put("refreshRateHz", disp.refreshRateHz.toDouble())
                        result.put("orientation", disp.orientation)
                        result.put("currentBrightness", disp.currentBrightness)
                        result.put("isAutoBrightness", disp.isAutoBrightness)
                        result.put("screenTimeoutMs", disp.screenTimeoutMs)
                        result.put("isInteractive", disp.isInteractive)
                        result.put("isPowerSaveMode", disp.isPowerSaveMode)
                    }
                }
                "/api/network" -> {
                    val net = networkTelemetryManager.getTelemetry()
                    result.put("success", true)
                    result.put("activeTransport", net.activeTransport)
                    result.put("isConnected", net.isConnected)
                    result.put("isMetered", net.isMetered)
                    result.put("localIpv4Addresses", org.json.JSONArray(net.localIpv4Addresses))
                    net.wifi?.let {
                        result.put("wifi", org.json.JSONObject().apply {
                            put("ssid", it.ssid)
                            put("rssiDbm", it.rssiDbm)
                            put("signalLevel", it.signalLevel)
                            put("linkSpeedMbps", it.linkSpeedMbps)
                            put("wifiStandard", it.wifiStandard)
                            put("ipAddress", it.ipAddress ?: "")
                        })
                    }
                    net.cellular?.let {
                        result.put("cellular", org.json.JSONObject().apply {
                            put("carrierName", it.carrierName)
                            put("networkType", it.networkType)
                            put("isRoaming", it.isRoaming)
                        })
                    }
                }
                "/api/device" -> {
                    val dev = deviceDetailsManager.getDeviceInfo()
                    result.put("success", true)
                    result.put("manufacturer", dev.manufacturer)
                    result.put("model", dev.model)
                    result.put("androidVersion", dev.androidVersion)
                    result.put("sdkInt", dev.sdkInt)
                    result.put("cpuCores", dev.cpuCores)
                    result.put("ramTotalGb", dev.ramTotalGb)
                    result.put("ramAvailableGb", dev.ramAvailableGb)
                    result.put("ramUsedPct", dev.ramUsedPct)
                    result.put("storageTotalGb", dev.storageTotalGb)
                    result.put("storageFreeGb", dev.storageFreeGb)
                    result.put("storageUsedPct", dev.storageUsedPct)
                    result.put("uptimeSeconds", dev.uptimeSeconds)
                    result.put("batteryPct", dev.batteryPct)
                    result.put("isCharging", dev.isCharging)
                    result.put("batteryTempC", dev.batteryTempC)
                    result.put("isThermalThrottling", dev.isThermalThrottling)
                }
                "/api/clipboard" -> {
                    if (json.has("text") && json.optString("text").isNotBlank()) {
                        val text = json.optString("text")
                        val res = clipboardRepository.writeClipboard(text)
                        result.put("success", res is com.kavach.capabilities.CapabilityResult.Success)
                    } else {
                        val res = clipboardRepository.readClipboard()
                        val text = (res as? com.kavach.capabilities.CapabilityResult.Success)?.data ?: ""
                        result.put("success", true)
                        result.put("text", text)
                    }
                }
                "/api/screen/brightness" -> {
                    val level = json.optInt("brightness", 128)
                    val ok = displayPowerManager.setBrightness(level)
                    result.put("success", ok)
                    result.put("brightness", level)
                }
                "/api/capabilities" -> {
                    val isAccessibility = com.kavach.accessibility.AccessibilityServiceRegistry.activeService != null
                    val canOverlay = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) Settings.canDrawOverlays(context) else true
                    val caps = listOf(
                        mapOf("name" to "TTS", "category" to "AUDIO", "status" to "AVAILABLE"),
                        mapOf("name" to "MICROPHONE", "category" to "AUDIO", "status" to checkPermissionStatus(Manifest.permission.RECORD_AUDIO)),
                        mapOf("name" to "CAMERA", "category" to "CAMERA", "status" to checkPermissionStatus(Manifest.permission.CAMERA)),
                        mapOf("name" to "TORCH", "category" to "CAMERA", "status" to "AVAILABLE"),
                        mapOf("name" to "VIBRATOR", "category" to "HAPTICS", "status" to "AVAILABLE"),
                        mapOf("name" to "ACCELEROMETER", "category" to "SENSORS", "status" to "AVAILABLE"),
                        mapOf("name" to "GYROSCOPE", "category" to "SENSORS", "status" to "AVAILABLE"),
                        mapOf("name" to "LIGHT_SENSOR", "category" to "SENSORS", "status" to "AVAILABLE"),
                        mapOf("name" to "GPS", "category" to "LOCATION", "status" to checkPermissionStatus(Manifest.permission.ACCESS_FINE_LOCATION)),
                        mapOf("name" to "WIFI", "category" to "NETWORK", "status" to "AVAILABLE"),
                        mapOf("name" to "NOTIFICATIONS", "category" to "NOTIFICATIONS", "status" to if (android.os.Build.VERSION.SDK_INT >= 33) checkPermissionStatus(Manifest.permission.POST_NOTIFICATIONS) else "AVAILABLE"),
                        mapOf("name" to "CLIPBOARD", "category" to "STORAGE", "status" to "AVAILABLE"),
                        mapOf("name" to "ACCESSIBILITY", "category" to "ACCESSIBILITY", "status" to if (isAccessibility) "AVAILABLE" else "PERMISSION_REQUIRED"),
                        mapOf("name" to "FLOATING_HUD", "category" to "DISPLAY", "status" to if (canOverlay) "AVAILABLE" else "PERMISSION_REQUIRED")
                    )
                    val arr = org.json.JSONArray()
                    for (c in caps) arr.put(org.json.JSONObject(c))
                    result.put("success", true)
                    result.put("capabilities", arr)
                }
                "/api/accessibility/tap" -> {
                    if (json.has("text") || json.has("label")) {
                        val text = json.optString("text", json.optString("label", ""))
                        accessibilityRepository.clickNodeByText(text) { }
                        result.put("success", true)
                        result.put("target", text)
                    } else {
                        val x = json.optDouble("x", 500.0).toFloat()
                        val y = json.optDouble("y", 1000.0).toFloat()
                        val req = com.kavach.accessibility.models.GestureRequestModel(
                            id = "http_tap",
                            type = "CLICK",
                            startX = x,
                            startY = y,
                            durationMs = 100
                        )
                        accessibilityRepository.triggerGesture(req) { }
                        result.put("success", true)
                    }
                }
                "/api/accessibility/swipe" -> {
                    val startX = json.optDouble("startX", 500.0).toFloat()
                    val startY = json.optDouble("startY", 1500.0).toFloat()
                    val endX = json.optDouble("endX", 500.0).toFloat()
                    val endY = json.optDouble("endY", 300.0).toFloat()
                    val dur = json.optLong("durationMs", 250L)
                    val req = com.kavach.accessibility.models.GestureRequestModel(
                        id = "http_swipe",
                        type = "SWIPE",
                        startX = startX,
                        startY = startY,
                        endX = endX,
                        endY = endY,
                        durationMs = dur
                    )
                    accessibilityRepository.triggerGesture(req) { }
                    result.put("success", true)
                }
                "/api/accessibility/key" -> {
                    val key = json.optString("key", json.optString("action", "BACK")).uppercase()
                    val req = com.kavach.accessibility.models.GestureRequestModel(
                        id = "http_key",
                        type = key,
                        startX = 0f,
                        startY = 0f
                    )
                    accessibilityRepository.triggerGesture(req) { }
                    result.put("success", true)
                    result.put("key", key)
                }
                "/api/accessibility/inspect" -> {
                    val isServiceActive = com.kavach.accessibility.AccessibilityServiceRegistry.activeService != null
                    val searchByText = if (json.has("text")) json.optString("text") else null
                    val results = if (isServiceActive) {
                        if (searchByText != null) {
                            accessibilityRepository.searchNodes(searchByText, null, null)
                        } else {
                            accessibilityRepository.getFullNodeTree()
                        }
                    } else {
                        emptyList()
                    }
                    result.put("success", isServiceActive)
                    val arr = org.json.JSONArray()
                    fun nodeToJson(node: com.kavach.accessibility.models.AccessibilityNodeModel): org.json.JSONObject {
                        return org.json.JSONObject().apply {
                            put("className", node.className ?: "")
                            put("text", node.text ?: "")
                            put("contentDescription", node.contentDescription ?: "")
                            put("viewId", node.viewId ?: "")
                            put("isClickable", node.isClickable)
                            put("bounds", node.bounds)
                            put("boundsInScreen", node.bounds)
                            val cArr = org.json.JSONArray()
                            for (child in node.children) {
                                cArr.put(nodeToJson(child))
                            }
                            put("children", cArr)
                        }
                    }
                    for (rootNode in results) {
                        arr.put(nodeToJson(rootNode))
                    }
                    result.put("nodes", arr)
                }
                "/api/share/devices" -> {
                    val devices = aeroShareManager.discoveredDevices.value
                    result.put("success", true)
                    result.put("count", devices.size)
                    result.put("localDeviceName", aeroShareManager.localDeviceName)
                    result.put("localIp", aeroShareManager.getLocalIpAddress() ?: "127.0.0.1")
                    result.put("isRadarActive", aeroShareManager.isRadarActive.value)
                    val arr = org.json.JSONArray()
                    devices.forEach { dev ->
                        arr.put(org.json.JSONObject().apply {
                            put("id", dev.id)
                            put("name", dev.name)
                            put("ip", dev.ip)
                            put("port", dev.port)
                            put("deviceType", dev.deviceType.name)
                            put("rssi", dev.rssi)
                            put("isSecure", dev.isSecure)
                        })
                    }
                    result.put("devices", arr)
                }
                "/api/share/radar" -> {
                    val enable = json.optBoolean("enabled", !aeroShareManager.isRadarActive.value)
                    if (enable) aeroShareManager.startDiscovery() else aeroShareManager.stopDiscovery()
                    result.put("success", true)
                    result.put("isRadarActive", aeroShareManager.isRadarActive.value)
                }
                "/api/share/send" -> {
                    val targetIp = json.optString("ip", json.optString("target", "")).ifBlank {
                        aeroShareManager.discoveredDevices.value.firstOrNull()?.ip ?: "127.0.0.1"
                    }
                    val targetPort = json.optInt("port", 8080)
                    val peerName = json.optString("peerName", "Peer Device")
                    val filePath = json.optString("filePath", json.optString("path", ""))
                    val textContent = json.optString("text", "")

                    if (filePath.isNotBlank()) {
                        val file = java.io.File(filePath)
                        if (file.exists() && file.isFile) {
                            val txId = aeroShareManager.sendFile(file, targetIp, targetPort, peerName)
                            result.put("success", true)
                            result.put("transferId", txId)
                            result.put("fileName", file.name)
                            result.put("sizeBytes", file.length())
                            result.put("targetIp", targetIp)
                        } else {
                            result.put("success", false)
                            result.put("error", "File does not exist at path: $filePath")
                        }
                    } else if (textContent.isNotBlank()) {
                        val ok = aeroShareManager.sendTextSnippet(textContent, targetIp, targetPort)
                        result.put("success", ok)
                        result.put("text", textContent)
                        result.put("targetIp", targetIp)
                    } else {
                        result.put("success", false)
                        result.put("error", "Must provide either filePath or text")
                    }
                }
                "/api/share/clip" -> {
                    val text = json.optString("text", "")
                    val sender = json.optString("sender", "Nearby Aero Device")
                    if (text.isNotBlank()) {
                        clipboardRepository.writeClipboard(text)
                        android.os.Handler(android.os.Looper.getMainLooper()).post {
                            toastCustomizer.showToast(
                                com.kavach.ui.overlay.ToastCustomizer.ToastOptions(
                                    message = "AeroShare: Snippet from $sender",
                                    icon = "content_copy"
                                )
                            )
                        }
                        result.put("success", true)
                        result.put("receivedText", text)
                    } else {
                        val currentText = (clipboardRepository.readClipboard() as? com.kavach.capabilities.CapabilityResult.Success)?.data ?: ""
                        result.put("success", true)
                        result.put("clipboardText", currentText)
                    }
                }
                "/api/share/transfers" -> {
                    val active = aeroShareManager.activeTransfers.value
                    result.put("success", true)
                    result.put("count", active.size)
                    val arr = org.json.JSONArray()
                    active.forEach { tx ->
                        arr.put(org.json.JSONObject().apply {
                            put("id", tx.id)
                            put("fileName", tx.fileName)
                            put("sizeBytes", tx.sizeBytes)
                            put("transferredBytes", tx.transferredBytes)
                            put("progressPct", (tx.progressPct * 100).toInt())
                            put("speedBytesPerSec", tx.speedBytesPerSec)
                            put("etaSeconds", tx.etaSeconds)
                            put("status", tx.status.name)
                            put("direction", tx.direction.name)
                            put("peerName", tx.peerName)
                            put("peerIp", tx.peerIp)
                        })
                    }
                    result.put("transfers", arr)
                }
                "/api/share/history" -> {
                    val history = aeroShareManager.transferHistory.value
                    result.put("success", true)
                    result.put("count", history.size)
                    val arr = org.json.JSONArray()
                    history.forEach { tx ->
                        arr.put(org.json.JSONObject().apply {
                            put("id", tx.id)
                            put("fileName", tx.fileName)
                            put("sizeBytes", tx.sizeBytes)
                            put("status", tx.status.name)
                            put("direction", tx.direction.name)
                            put("peerName", tx.peerName)
                            put("completedAt", tx.completedAt ?: tx.createdAt)
                            put("error", tx.errorMessage ?: "")
                        })
                    }
                    result.put("history", arr)
                }
                "/api/share/cancel" -> {
                    val txId = json.optString("id", json.optString("transferId", ""))
                    val ok = if (txId.isNotBlank()) aeroShareManager.cancelTransfer(txId) else false
                    result.put("success", ok)
                    result.put("transferId", txId)
                }
                "/api/open" -> {
                    val target = json.optString("url", json.optString("uri", json.optString("target", ""))).trim()
                    val action = json.optString("action", android.content.Intent.ACTION_VIEW)
                    val mimeType = if (json.has("mimeType") || json.has("type")) json.optString("mimeType", json.optString("type", null)) else null
                    var ok = false
                    var errorMessage: String? = null

                    // Strict URL / URI Validation & Whitelist
                    val isSafeWebUrl = target.startsWith("http://", ignoreCase = true) || target.startsWith("https://", ignoreCase = true)
                    val isSafeScheme = target.startsWith("tel:", ignoreCase = true) || 
                            target.startsWith("mailto:", ignoreCase = true) || 
                            target.startsWith("geo:", ignoreCase = true)
                    val isSafePublicFile = target.startsWith("/storage/emulated/0/") || target.startsWith("/sdcard/")

                    val isDangerousScheme = target.startsWith("javascript:", ignoreCase = true) ||
                            target.startsWith("file:///data/", ignoreCase = true) ||
                            target.startsWith("/data/data/", ignoreCase = true) ||
                            target.startsWith("/data/user/", ignoreCase = true) ||
                            target.startsWith("content://", ignoreCase = true) ||
                            target.startsWith("intent:", ignoreCase = true) ||
                            target.startsWith("jar:", ignoreCase = true)

                    if (isDangerousScheme || (!isSafeWebUrl && !isSafeScheme && !isSafePublicFile && !target.contains("://"))) {
                        errorMessage = "403 Forbidden: Dangerous or unauthorized URL scheme/target rejected."
                    } else {
                        try {
                            val uri = if (isSafeWebUrl || isSafeScheme) {
                                android.net.Uri.parse(target)
                            } else if (isSafePublicFile) {
                                val f = java.io.File(target)
                                if (f.exists()) android.net.Uri.fromFile(f) else null
                            } else {
                                android.net.Uri.parse(target)
                            }

                            if (uri != null) {
                                val intent = android.content.Intent(action).apply {
                                    if (mimeType != null) {
                                        setDataAndType(uri, mimeType)
                                    } else {
                                        data = uri
                                    }
                                    addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                                }
                                context.startActivity(intent)
                                ok = true
                            } else {
                                errorMessage = "Target resource not found."
                            }
                        } catch (e: Exception) {
                            errorMessage = e.message ?: "Failed to open target"
                            logger.e("AppContainer", "Failed to open target: $target", e)
                        }
                    }

                    result.put("success", ok)
                    result.put("target", target)
                    if (errorMessage != null) {
                        result.put("error", errorMessage)
                    }
                }
                "/api/audio/tone" -> {
                    val freqHz = json.optInt("frequency", json.optInt("freq", 440))
                    val durationMs = json.optInt("durationMs", json.optInt("duration", 500))
                    var ok = false
                    try {
                        applicationScope.launch(kotlinx.coroutines.Dispatchers.Default) {
                            val sampleRate = 44100
                            val numSamples = (durationMs * sampleRate) / 1000
                            val sample = DoubleArray(numSamples)
                            val generatedSnd = ByteArray(2 * numSamples)
                            for (i in 0 until numSamples) {
                                sample[i] = kotlin.math.sin(2.0 * Math.PI * i.toDouble() / (sampleRate.toDouble() / freqHz.toDouble()))
                            }
                            var idx = 0
                            for (dVal in sample) {
                                val d = kotlin.math.max(-1.0, kotlin.math.min(1.0, dVal))
                                val `val` = (d * 32767).toInt().toShort()
                                generatedSnd[idx++] = (`val`.toInt() and 0x00ff).toByte()
                                generatedSnd[idx++] = ((`val`.toInt() and 0xff00) ushr 8).toByte()
                            }
                            val audioTrack = android.media.AudioTrack(
                                android.media.AudioManager.STREAM_MUSIC,
                                sampleRate,
                                android.media.AudioFormat.CHANNEL_OUT_MONO,
                                android.media.AudioFormat.ENCODING_PCM_16BIT,
                                generatedSnd.size,
                                android.media.AudioTrack.MODE_STATIC
                            )
                            audioTrack.write(generatedSnd, 0, generatedSnd.size)
                            audioTrack.play()
                            kotlinx.coroutines.delay(durationMs.toLong() + 50)
                            audioTrack.release()
                        }
                        ok = true
                    } catch (e: Exception) {
                        logger.e("AppContainer", "Failed to generate tone", e)
                    }
                    result.put("success", ok)
                    result.put("frequencyHz", freqHz)
                    result.put("durationMs", durationMs)
                }
                "/api/battery" -> {
                    val dev = deviceDetailsManager.getDeviceInfo()
                    result.put("success", true)
                    result.put("batteryPct", dev.batteryPct)
                    result.put("isCharging", dev.isCharging)
                    result.put("batteryTempC", dev.batteryTempC)
                    result.put("isThermalThrottling", dev.isThermalThrottling)
                    result.put("uptimeSeconds", dev.uptimeSeconds)
                    result.put("isIgnoringBatteryOptimizations", displayPowerManager.isIgnoringBatteryOptimizations())
                }
                "/api/battery/optimization", "/api/power/optimization" -> {
                    val action = json.optString("action", "STATUS").uppercase()
                    val isIgnoring = displayPowerManager.isIgnoringBatteryOptimizations()
                    var requested = false

                    if (action == "REQUEST" || action == "EXEMPT" || action == "DISABLE") {
                        requested = displayPowerManager.requestIgnoreBatteryOptimizations()
                    } else if (action == "SETTINGS" || action == "OPEN") {
                        requested = displayPowerManager.openBatteryOptimizationSettings()
                    }

                    result.put("success", true)
                    result.put("isIgnoringBatteryOptimizations", isIgnoring)
                    result.put("status", if (isIgnoring) "UNRESTRICTED" else "OPTIMIZED")
                    result.put("packageName", context.packageName)
                    result.put("actionRequested", requested)
                    result.put("hint", if (!isIgnoring) {
                        "In Android Settings > Battery Optimisation, switch top filter dropdown from 'Not optimised' to 'All apps' to see AeroShare, or run with action='REQUEST'."
                    } else {
                        "AeroShare is unrestricted and allowed to run in the background."
                    })
                }
                "/api/system/action" -> {
                    val actionName = json.optString("action", json.optString("key", "HOME")).uppercase()
                    val req = com.kavach.accessibility.models.GestureRequestModel(
                        id = "http_sys_action",
                        type = actionName,
                        startX = 0f,
                        startY = 0f
                    )
                    accessibilityRepository.triggerGesture(req) { }
                    result.put("success", true)
                    result.put("action", actionName)
                }
                "/api/media/control" -> {
                    val cmd = json.optString("command", json.optString("action", "PLAY_PAUSE")).uppercase()
                    val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? android.media.AudioManager
                    val keyEventCode = when (cmd) {
                        "PLAY", "PAUSE", "PLAY_PAUSE", "TOGGLE" -> android.view.KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE
                        "NEXT", "SKIP" -> android.view.KeyEvent.KEYCODE_MEDIA_NEXT
                        "PREV", "PREVIOUS" -> android.view.KeyEvent.KEYCODE_MEDIA_PREVIOUS
                        "STOP" -> android.view.KeyEvent.KEYCODE_MEDIA_STOP
                        else -> android.view.KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE
                    }
                    var ok = false
                    try {
                        if (audioManager != null) {
                            val down = android.view.KeyEvent(android.view.KeyEvent.ACTION_DOWN, keyEventCode)
                            val up = android.view.KeyEvent(android.view.KeyEvent.ACTION_UP, keyEventCode)
                            audioManager.dispatchMediaKeyEvent(down)
                            audioManager.dispatchMediaKeyEvent(up)
                            ok = true
                        }
                    } catch (e: Exception) {
                        logger.e("AppContainer", "Failed to dispatch media key event", e)
                    }
                    result.put("success", ok)
                    result.put("command", cmd)
                }
                "/api/storage/files" -> {
                    val folderName = json.optString("folder", json.optString("dir", "DOWNLOADS")).uppercase()
                    val dir = when (folderName) {
                        "DOWNLOADS", "DOWNLOAD" -> android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOWNLOADS)
                        "DCIM", "CAMERA", "PHOTOS" -> android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DCIM)
                        "DOCUMENTS", "DOCS" -> android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOCUMENTS)
                        "MOVIES", "VIDEO" -> android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_MOVIES)
                        "MUSIC", "AUDIO" -> android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_MUSIC)
                        else -> {
                            val customPath = json.optString("folder", "")
                            if (customPath.startsWith("/")) java.io.File(customPath) else android.os.Environment.getExternalStorageDirectory()
                        }
                    }
                    val limit = json.optInt("limit", 50)
                    val filesArr = org.json.JSONArray()
                    if (dir != null && dir.exists() && dir.isDirectory) {
                        val list = dir.listFiles()?.sortedByDescending { it.lastModified() }?.take(limit) ?: emptyList()
                        for (f in list) {
                            filesArr.put(org.json.JSONObject().apply {
                                put("name", f.name)
                                put("path", f.absolutePath)
                                put("sizeBytes", f.length())
                                put("isDirectory", f.isDirectory)
                                put("lastModified", f.lastModified())
                            })
                        }
                    }
                    result.put("success", true)
                    result.put("directory", dir?.absolutePath ?: "")
                    result.put("totalFiles", filesArr.length())
                    result.put("files", filesArr)
                }
                "/api/sms/compose" -> {
                    val phone = json.optString("phone", json.optString("to", json.optString("number", "")))
                    val body = json.optString("message", json.optString("body", json.optString("text", "")))
                    var ok = false
                    try {
                        val uri = android.net.Uri.parse("smsto:${phone.trim()}")
                        val intent = android.content.Intent(android.content.Intent.ACTION_SENDTO, uri).apply {
                            if (body.isNotBlank()) {
                                putExtra("sms_body", body)
                            }
                            addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                        context.startActivity(intent)
                        ok = true
                    } catch (e: Exception) {
                        logger.e("AppContainer", "Failed to launch SMS composer", e)
                    }
                    result.put("success", ok)
                    result.put("phone", phone)
                }
                "/api/security/status" -> {
                    val (_, remainingMs) = securityShield.getActivePairingCode()
                    result.put("success", true)
                    result.put("authMode", securityShield.authMode)
                    result.put("isPanicLockdown", securityShield.isPanicLockdown)
                    result.put("isStrictAuth", securityShield.authMode == com.kavach.security.AuraSecurityShield.AUTH_MODE_STRICT)
                    result.put("localTrustEnabled", securityShield.authMode == com.kavach.security.AuraSecurityShield.AUTH_MODE_LOCAL_TRUST)
                    result.put("tokenPrefix", securityShield.masterApiToken.take(12) + "...")
                    result.put("pairedDevicesCount", securityShield.listPairedDevices().size)
                    result.put("pairingCodeRemainingSec", remainingMs / 1000)
                    result.put("isBiometricsAvailable", biometricAuthManager.isBiometricOrDeviceCredentialAvailable())
                }
                "/api/security/pair/code" -> {
                    result.put("success", false)
                    result.put("error", "Pairing code is only displayed on the Android device screen for security.")
                }
                "/api/security/pair/register", "/api/pair/register" -> {
                    val code = json.optString("code", json.optString("pairingCode", json.optString("token", "")))
                    val clientName = json.optString("clientName", "Remote Client")
                    val verifiedIp = json.optString("_socketClientIp", "unknown")
                    val deviceId = json.optString("deviceId", "client_" + System.currentTimeMillis())

                    val (ok, tokenOrError) = securityShield.pairClientDevice(
                        pairingCodeOrToken = code,
                        clientName = clientName,
                        clientIp = verifiedIp,
                        providedDeviceId = deviceId
                    )

                    result.put("success", ok)
                    if (ok) {
                        result.put("clientToken", tokenOrError)
                        result.put("deviceId", deviceId)
                        result.put("clientName", clientName)
                        result.put("message", "Device paired successfully! Store clientToken for Bearer authorization.")
                    } else {
                        result.put("error", tokenOrError)
                        result.put("hint", "Read the active 6-digit pairing code from the device screen.")
                    }
                }
                "/api/security/pair/request", "/api/pair/request", "/api/auth/login" -> {
                    if (securityShield.isPanicLockdown) {
                        result.put("success", false)
                        result.put("error", "403 Forbidden: Device is in Panic Lockdown.")
                    } else {
                        val clientName = json.optString("clientName", "Termux Bridge")
                        val verifiedIp = json.optString("_socketClientIp", "unknown")
                        val deviceId = json.optString("securityDeviceId", json.optString("deviceId", "SEC-DEV-" + System.currentTimeMillis().toString(16).uppercase().takeLast(8)))
                        val req = securityShield.createPendingPairRequest(clientName, verifiedIp, deviceId)

                        // Post a high-priority system notification on the phone for user Face/PIN authentication
                        android.os.Handler(android.os.Looper.getMainLooper()).post {
                            try {
                                notificationRepository.showAuthNotification(
                                    title = "🔐 Authentication Required",
                                    message = "Security Device ID: $deviceId ($clientName @ $verifiedIp) requests access. Tap to verify.",
                                    securityDeviceId = deviceId,
                                    requestId = req.requestId
                                )
                                toastCustomizer.showToast(
                                    com.kavach.ui.overlay.ToastCustomizer.ToastOptions(
                                        message = "🔐 Auth Request: $deviceId ($verifiedIp)",
                                        icon = "security"
                                    )
                                )
                            } catch (ignored: Exception) {}
                        }

                        result.put("success", true)
                        result.put("requestId", req.requestId)
                        result.put("deviceId", req.deviceId)
                        result.put("securityDeviceId", req.deviceId)
                        result.put("status", "PENDING")
                        result.put("message", "Authentication request created. Notification and verification prompt sent to Android device.")
                    }
                }
                "/api/security/pair/poll", "/api/pair/poll", "/api/auth/poll" -> {
                    val reqId = json.optString("requestId", json.optString("id", ""))
                    val devId = json.optString("securityDeviceId", json.optString("deviceId", ""))
                    val req = securityShield.getPendingPairRequestForPoll(reqId, devId)

                    if (req != null) {
                        result.put("requestId", req.requestId)
                        result.put("deviceId", req.deviceId)
                        result.put("securityDeviceId", req.deviceId)
                        result.put("status", req.status)
                        if (req.status == "APPROVED") {
                            val tok = req.clientToken
                            if (!tok.isNullOrBlank()) {
                                result.put("success", true)
                                result.put("clientToken", tok)
                                result.put("clientName", req.clientName)
                                securityShield.markApprovedPairTokenDelivered(req.requestId)
                            } else {
                                result.put("success", false)
                                result.put("error", "Pairing token already consumed or expired. Please run 'python send_cmd.py login' again.")
                            }
                        } else if (req.status == "DENIED") {
                            result.put("success", true)
                            result.put("error", "Authentication was denied by user")
                        } else {
                            result.put("success", true)
                        }
                    } else {
                        result.put("success", false)
                        result.put("error", "Request or Device ID not found or expired")
                    }
                }
                "/api/security/pair/pending" -> {
                    val pending = securityShield.listPendingPairRequests()
                    result.put("success", true)
                    result.put("count", pending.size)
                    val arr = org.json.JSONArray()
                    pending.forEach { r -> arr.put(r.toJson()) }
                    result.put("pendingRequests", arr)
                }
                "/api/security/pair/approve", "/api/security/pair/deny" -> {
                    result.put("success", false)
                    result.put("error", "Pairing approvals and denials can only be confirmed directly on the Android device.")
                }
                "/api/security/lockdown" -> {
                    val requestedEnable = json.optBoolean("enabled", true)
                    val isMaster = json.optBoolean("_isMasterTokenAuth", false)
                    if (!requestedEnable && !isMaster) {
                        result.put("success", false)
                        result.put("error", "Panic lockdown can only be unlocked inside the Android app or with the master key.")
                    } else {
                        securityShield.isPanicLockdown = requestedEnable
                        result.put("success", true)
                        result.put("isPanicLockdown", requestedEnable)
                        result.put("message", if (requestedEnable) "🚨 PANIC LOCKDOWN ACTIVE: All network connections frozen" else "✅ Panic lockdown released")
                    }
                }
                "/api/security/devices" -> {
                    val devices = securityShield.listPairedDevices()
                    result.put("success", true)
                    result.put("count", devices.size)
                    val arr = org.json.JSONArray()
                    devices.forEach { d ->
                        arr.put(d.toJson())
                    }
                    result.put("pairedDevices", arr)
                }
                "/api/security/revoke" -> {
                    val isMaster = json.optBoolean("_isMasterTokenAuth", false)
                    if (!isMaster) {
                        result.put("success", false)
                        result.put("error", "403 Forbidden: Revoking paired devices via API requires the master token.")
                    } else {
                        val devId = json.optString("deviceId", json.optString("id", ""))
                        val ok = if (devId.isNotBlank()) securityShield.revokeClientDevice(devId) else false
                        result.put("success", ok)
                        result.put("deviceId", devId)
                        if (!ok) result.put("error", "Device ID not found or already revoked")
                    }
                }
                "/api/security/biometrics" -> {
                    result.put("success", true)
                    val bioStatus = biometricAuthManager.getBiometricStatus()
                    for ((k, v) in bioStatus) {
                        if (v is List<*>) {
                            result.put(k, org.json.JSONArray(v))
                        } else {
                            result.put(k, v)
                        }
                    }
                    result.put("requireBiometricForPairing", securityShield.requireBiometricsForPairing)
                    result.put("requireBiometricForRemoteActions", securityShield.requireBiometricsForRemoteActions)
                }
                "/api/security/mode" -> {
                    val isMaster = json.optBoolean("_isMasterTokenAuth", false)
                    val mode = json.optString("mode", "").uppercase()
                    if (!isMaster) {
                        result.put("success", false)
                        result.put("error", "403 Forbidden: Changing auth mode via API requires the master token or on-device UI.")
                    } else if (mode in listOf(com.kavach.security.AuraSecurityShield.AUTH_MODE_LOCAL_TRUST, com.kavach.security.AuraSecurityShield.AUTH_MODE_STRICT)) {
                        securityShield.authMode = mode
                        result.put("success", true)
                        result.put("authMode", mode)
                    } else {
                        result.put("success", false)
                        result.put("error", "Invalid auth mode. Allowed values: STRICT, LOCAL_TRUST")
                    }
                }
                "/api/security/token" -> {
                    result.put("success", false)
                    result.put("tokenPrefix", securityShield.masterApiToken.take(12) + "...")
                    result.put("error", "Raw master token cannot be retrieved over network endpoints. Copy it directly from the app UI.")
                }
                "/api/shell/exec", "/api/shell" -> {
                    val cmd = json.optString("cmd", json.optString("command", json.optString("raw", "")))
                    val timeoutMs = json.optLong("timeout_ms", json.optLong("timeoutMs", 15000L))
                    val cwd = if (json.has("cwd")) json.optString("cwd") else null
                    val execRes = deviceBridgeManager.executeShellCommand(cmd, timeoutMs, cwd)
                    execRes.keys().forEach { k -> result.put(k, execRes.get(k)) }
                }
                "/api/screen/capture", "/api/screenshot" -> {
                    val quality = json.optInt("quality", 75)
                    val maxDim = json.optInt("maxDimension", 1280)
                    val capRes = accessibilityRepository.takeScreenshotBase64(quality, maxDim)
                    capRes.keys().forEach { k -> result.put(k, capRes.get(k)) }
                }
                "/api/ui/tree" -> {
                    val isServiceActive = com.kavach.accessibility.AccessibilityServiceRegistry.activeService != null
                    val searchByText = if (json.has("text")) json.optString("text") else null
                    val results = if (isServiceActive) {
                        if (searchByText != null) {
                            accessibilityRepository.searchNodes(searchByText, null, null)
                        } else {
                            accessibilityRepository.getFullNodeTree()
                        }
                    } else emptyList()
                    val visibleWindows = if (isServiceActive) {
                        accessibilityRepository.getVisibleWindows(excludeHud = true)
                    } else emptyList()

                    val wm = context.getSystemService(Context.WINDOW_SERVICE) as? android.view.WindowManager
                    val realDm = android.util.DisplayMetrics()
                    @Suppress("DEPRECATION")
                    wm?.defaultDisplay?.getRealMetrics(realDm)
                    val screenW = realDm.widthPixels.takeIf { it > 0 } ?: context.resources.displayMetrics.widthPixels.coerceAtLeast(1080)
                    val screenH = realDm.heightPixels.takeIf { it > 0 } ?: context.resources.displayMetrics.heightPixels.coerceAtLeast(1920)
                    @Suppress("DEPRECATION")
                    val rotCode = wm?.defaultDisplay?.rotation ?: android.view.Surface.ROTATION_0
                    val rotDeg = when (rotCode) {
                        android.view.Surface.ROTATION_90 -> 90
                        android.view.Surface.ROTATION_180 -> 180
                        android.view.Surface.ROTATION_270 -> 270
                        else -> 0
                    }
                    val orientationStr = if (screenW > screenH || rotDeg == 90 || rotDeg == 270) "landscape" else "portrait"

                    result.put("success", isServiceActive)
                    result.put("display", org.json.JSONObject().apply {
                        put("width", screenW)
                        put("height", screenH)
                        put("rotation", rotDeg)
                        put("orientation", orientationStr)
                    })

                    val winArr = org.json.JSONArray()
                    for (w in visibleWindows) {
                        winArr.put(org.json.JSONObject().apply {
                            put("id", w.id)
                            put("packageName", w.packageName ?: "")
                            put("type", w.type)
                            put("bounds", w.bounds)
                            put("left", w.left)
                            put("top", w.top)
                            put("right", w.right)
                            put("bottom", w.bottom)
                            put("isFocused", w.isFocused)
                            put("isActive", w.isActive)
                        })
                    }
                    result.put("windows", winArr)

                    val appWindows = visibleWindows.filter { it.type == "APPLICATION" && it.right > it.left && it.bottom > it.top }
                    val hasDivider = visibleWindows.any { it.type == "SPLIT_SCREEN_DIVIDER" }
                    val isSplit = hasDivider || appWindows.size >= 2
                    val axis = if (!isSplit) {
                        "NONE"
                    } else if (appWindows.size >= 2) {
                        val dx = kotlin.math.abs(appWindows[0].left - appWindows[1].left)
                        val dy = kotlin.math.abs(appWindows[0].top - appWindows[1].top)
                        if (dx > dy) "LEFT_RIGHT" else "TOP_BOTTOM"
                    } else if (screenW > screenH) {
                        "LEFT_RIGHT"
                    } else {
                        "TOP_BOTTOM"
                    }
                    val targetWin = appWindows.firstOrNull {
                        it.isFocused && !it.packageName.isNullOrBlank() && it.packageName != "com.termux" && it.packageName != context.packageName
                    } ?: appWindows.firstOrNull {
                        !it.packageName.isNullOrBlank() && it.packageName != "com.termux" && it.packageName != context.packageName
                    } ?: appWindows.firstOrNull { it.isFocused } ?: appWindows.firstOrNull()

                    val targetPkg = targetWin?.packageName?.takeIf { it.isNotBlank() }
                        ?: results.firstOrNull { !it.packageName.isNullOrBlank() && it.packageName != "com.termux" && it.packageName != context.packageName }?.packageName
                        ?: results.firstOrNull()?.packageName
                        ?: ""

                    result.put("splitScreen", org.json.JSONObject().apply {
                        put("active", isSplit)
                        put("axis", axis)
                        put("targetPackage", targetPkg)
                        if (targetWin != null) {
                            put("paneBounds", org.json.JSONObject().apply {
                                put("x1", targetWin.left)
                                put("y1", targetWin.top)
                                put("x2", targetWin.right)
                                put("y2", targetWin.bottom)
                                put("screenWidth", screenW)
                                put("screenHeight", screenH)
                            })
                        }
                    })

                    val arr = org.json.JSONArray()
                    fun nodeToJson(node: com.kavach.accessibility.models.AccessibilityNodeModel): org.json.JSONObject {
                        return org.json.JSONObject().apply {
                            put("className", node.className ?: "")
                            put("packageName", node.packageName ?: "")
                            put("text", node.text ?: "")
                            put("contentDescription", node.contentDescription ?: "")
                            put("viewId", node.viewId ?: "")
                            put("isClickable", node.isClickable)
                            put("isEditable", node.isEditable)
                            put("isScrollable", node.isScrollable)
                            put("bounds", node.bounds)
                            put("boundsInScreen", node.bounds)
                            val cArr = org.json.JSONArray()
                            for (child in node.children) cArr.put(nodeToJson(child))
                            put("children", cArr)
                        }
                    }
                    for (rootNode in results) arr.put(nodeToJson(rootNode))
                    result.put("nodes", arr)
                    if (!isServiceActive) {
                        result.put("error", "Accessibility Service is disabled. Enable it in Settings > Accessibility.")
                    }
                }
                "/api/ui/action", "/api/accessibility/text" -> {
                    if (endpoint == "/api/accessibility/text" && !json.has("action")) {
                        json.put("action", "INPUT_TEXT")
                    }
                    val uiRes = deviceBridgeManager.handleUiAction(json)
                    uiRes.keys().forEach { k -> result.put(k, uiRes.get(k)) }
                }
                "/api/system/toggle" -> {
                    val sysRes = deviceBridgeManager.handleSystemToggle(json)
                    sysRes.keys().forEach { k -> result.put(k, sysRes.get(k)) }
                }
                "/api/system/status" -> {
                    val statRes = deviceBridgeManager.getSystemStatus()
                    statRes.keys().forEach { k -> result.put(k, statRes.get(k)) }
                }
                "/api/fs/list" -> {
                    val fsRes = deviceBridgeManager.handleFileOperation("list", json)
                    fsRes.keys().forEach { k -> result.put(k, fsRes.get(k)) }
                }
                "/api/fs/read" -> {
                    val fsRes = deviceBridgeManager.handleFileOperation("read", json)
                    fsRes.keys().forEach { k -> result.put(k, fsRes.get(k)) }
                }
                "/api/fs/write" -> {
                    val fsRes = deviceBridgeManager.handleFileOperation("write", json)
                    fsRes.keys().forEach { k -> result.put(k, fsRes.get(k)) }
                }
                "/api/fs/delete" -> {
                    val fsRes = deviceBridgeManager.handleFileOperation("delete", json)
                    fsRes.keys().forEach { k -> result.put(k, fsRes.get(k)) }
                }
                "/api/fs/stat" -> {
                    val fsRes = deviceBridgeManager.handleFileOperation("stat", json)
                    fsRes.keys().forEach { k -> result.put(k, fsRes.get(k)) }
                }
                "/api/clipboard/get" -> {
                    val txt = deviceBridgeManager.getClipboardText()
                    result.put("success", true)
                    result.put("text", txt)
                    result.put("clipboardText", txt)
                }
                "/api/clipboard/set" -> {
                    val txt = json.optString("text", json.optString("content", ""))
                    val ok = deviceBridgeManager.setClipboardText(txt)
                    result.put("success", ok)
                    result.put("text", txt)
                }
                "/api/server/export" -> {
                    val expRes = deviceBridgeManager.exportServerScriptsToStorage()
                    expRes.keys().forEach { k -> result.put(k, expRes.get(k)) }
                }
                "/api/location", "/api/gps", "/api/location/get" -> {
                    val locRes = deviceBridgeManager.getCurrentLocationDetails()
                    locRes.keys().forEach { k -> result.put(k, locRes.get(k)) }
                }
                "/api/location/live", "/api/location/track", "/api/gps/live" -> {
                    val action = json.optString("action", "").uppercase()
                    val enable = if (json.has("enabled")) json.optBoolean("enabled") else null
                    val interval = json.optLong("intervalMs", json.optLong("interval", 1000L))
                    val trackRes = when {
                        enable == true || action == "START" -> deviceBridgeManager.startLiveLocationTracking(interval)
                        enable == false || action == "STOP" -> deviceBridgeManager.stopLiveLocationTracking()
                        action == "TOGGLE" -> deviceBridgeManager.toggleLiveLocationTracking()
                        else -> {
                            val stat = org.json.JSONObject()
                            stat.put("success", true)
                            stat.put("isLiveTracking", deviceBridgeManager.isLiveLocationTracking.value)
                            val cur = deviceBridgeManager.locationSnapshot.value
                            stat.put("hasCoordinates", cur.hasCoordinates)
                            stat.put("latitude", cur.latitude)
                            stat.put("longitude", cur.longitude)
                            stat.put("speedKmh", cur.speedKmh.toDouble())
                            stat.put("speedMph", cur.speedMph.toDouble())
                            stat.put("accuracy", cur.accuracyMeters.toDouble())
                            stat.put("bearing", cur.bearingDegrees.toDouble())
                            stat.put("updateCount", cur.updateCount)
                            stat
                        }
                    }
                    trackRes.keys().forEach { k -> result.put(k, trackRes.get(k)) }
                }
                "/api/permissions", "/api/permissions/status", "/api/permissions/list" -> {
                    val pRes = deviceBridgeManager.getPermissionsOverview()
                    pRes.keys().forEach { k -> result.put(k, pRes.get(k)) }
                }
                "/api/permissions/request", "/api/permissions/grant", "/api/permissions/open" -> {
                    val perm = json.optString("permission", json.optString("id", json.optString("name", "")))
                    val openSettings = json.optBoolean("settings", json.optBoolean("openSettings", false))
                    val reqRes = deviceBridgeManager.requestPermissionOrSetting(perm, openSettings)
                    reqRes.keys().forEach { k -> result.put(k, reqRes.get(k)) }
                }
                "/api/camera/status", "/api/camera/details" -> {
                    val camRes = deviceBridgeManager.getCameraStationDetails()
                    camRes.keys().forEach { k -> result.put(k, camRes.get(k)) }
                }
                "/api/camera/test", "/api/camera/capture" -> {
                    val testRes = deviceBridgeManager.openCameraCapture()
                    testRes.keys().forEach { k -> result.put(k, testRes.get(k)) }
                }
                "/api/audio/status", "/api/mic/status", "/api/mic/details" -> {
                    val micRes = deviceBridgeManager.getMicrophoneStationDetails()
                    micRes.keys().forEach { k -> result.put(k, micRes.get(k)) }
                }
                "/api/audio/test_record", "/api/mic/test", "/api/mic/record" -> {
                    val dur = json.optInt("durationSec", json.optInt("duration", 3))
                    val recRes = deviceBridgeManager.testRecordMicrophone(dur)
                    recRes.keys().forEach { k -> result.put(k, recRes.get(k)) }
                }
                "/api/audio/realtime/start", "/api/mic/live/start", "/api/mic/stream/start", "/api/audio/live/start" -> {
                    val startRes = deviceBridgeManager.startRealtimeRecording()
                    startRes.keys().forEach { k -> result.put(k, startRes.get(k)) }
                }
                "/api/audio/realtime/stop", "/api/mic/live/stop", "/api/mic/stream/stop", "/api/audio/live/stop" -> {
                    val stopRes = deviceBridgeManager.stopRealtimeRecording()
                    stopRes.keys().forEach { k -> result.put(k, stopRes.get(k)) }
                }
                "/api/audio/realtime/status", "/api/mic/live/status", "/api/mic/stream/status", "/api/audio/live/status" -> {
                    val statusRes = deviceBridgeManager.getRealtimeAudioStatus()
                    statusRes.keys().forEach { k -> result.put(k, statusRes.get(k)) }
                }
                "/api/audio/play_file", "/api/mic/play" -> {
                    val filePath = json.optString("filePath", json.optString("path", ""))
                    val playRes = deviceBridgeManager.playAudioFile(filePath)
                    playRes.keys().forEach { k -> result.put(k, playRes.get(k)) }
                }
                "/api/notif/status", "/api/notification/status", "/api/notifications/status" -> {
                    val notifRes = deviceBridgeManager.getNotificationStationDetails()
                    notifRes.keys().forEach { k -> result.put(k, notifRes.get(k)) }
                }
                "/api/notif/test", "/api/notification/test", "/api/notifications/test" -> {
                    val title = json.optString("title", "AeroShare Hardware Test")
                    val msg = json.optString("message", json.optString("text", "Test notification from AeroShare!"))
                    val sendRes = deviceBridgeManager.sendTestNotification(title, msg)
                    sendRes.keys().forEach { k -> result.put(k, sendRes.get(k)) }
                }
                "/api/storage/status", "/api/storage/details" -> {
                    val storRes = deviceBridgeManager.getStorageStationDetails()
                    storRes.keys().forEach { k -> result.put(k, storRes.get(k)) }
                }
                "/api/storage/test" -> {
                    val testRes = deviceBridgeManager.getStorageStationDetails()
                    testRes.put("testStatus", "ACCESSIBLE")
                    testRes.keys().forEach { k -> result.put(k, testRes.get(k)) }
                }
                "/api/help", "/api/docs", "/api/commands/help" -> {
                    val helpObj = org.json.JSONObject().apply {
                        put("success", true)
                        put("service", "Aero Hardware Bridge API")
                        put("port", 8080)
                        put("authHeader", "X-API-Key: <token> or Authorization: Bearer <token>")
                        put("hardwareStations", org.json.JSONObject().apply {
                            put("battery", org.json.JSONObject().apply {
                                put("endpoint", "/api/battery/status or /api/battery")
                                put("description", "Query battery capacity, charging status, temperature, voltage, health, and Doze exemption")
                                put("cliCommand", "python send_cmd.py battery")
                            })
                            put("sensors", org.json.JSONObject().apply {
                                put("endpoint", "/api/sensors/status or /api/sensors")
                                put("description", "Query live Accelerometer, Gyroscope, Lux, Proximity, Magnetometer, and complete sensor list")
                                put("cliCommand", "python send_cmd.py sensors")
                            })
                            put("display", org.json.JSONObject().apply {
                                put("statusEndpoint", "/api/display/status or /api/display")
                                put("brightnessEndpoint", "/api/display/brightness")
                                put("brightnessPayload", "{ \"brightness\": 0..255 }")
                                put("autoBrightnessEndpoint", "/api/display/auto_brightness")
                                put("autoBrightnessPayload", "{ \"enabled\": true|false }")
                                put("timeoutEndpoint", "/api/display/timeout")
                                put("timeoutPayload", "{ \"seconds\": 15..1800 }")
                                put("wakelockEndpoint", "/api/display/wakelock")
                                put("wakelockPayload", "{ \"enable\": true|false }")
                                put("cliCommand", "python send_cmd.py display [brightness <0-255> | auto <on|off> | timeout <sec> | wakelock <on|off>]")
                            })
                            put("network", org.json.JSONObject().apply {
                                put("endpoint", "/api/network/status or /api/network")
                                put("speedEndpoint", "/api/network/speed")
                                put("categoriesEndpoint", "/api/network/moderation/categories")
                                put("analyticsEndpoint", "/api/network/moderation/analytics")
                                put("diagnosticsEndpoints", listOf("/api/network/diag/ping", "/api/network/diag/dns", "/api/network/diag/port"))
                                put("description", "Query active transport, live Rx/Tx bandwidth speed, DNS category blocklists (ADS, TRACKERS, MALWARE, ADULT, SOCIAL, GAMBLING), per-domain traffic analytics, and Ping/DNS/Port diagnostics")
                                put("cliCommand", "python send_cmd.py [network | net-speed | net-filter | net-diag]")
                            })
                            put("appGuard", org.json.JSONObject().apply {
                                put("statusEndpoint", "/api/apps/guard/status")
                                put("blockEndpoint", "/api/apps/guard/block")
                                put("unblockEndpoint", "/api/apps/guard/unblock")
                                put("uninstallEndpoint", "/api/apps/guard/uninstall")
                                put("forceStopEndpoint", "/api/apps/guard/force-stop")
                                put("settingsEndpoint", "/api/apps/guard/settings")
                                put("infoEndpoint", "/api/apps/guard/info")
                                put("eventsEndpoint", "/api/apps/guard/events")
                                put("description", "Real-time app installation/update/uninstallation monitoring & alerts, foreground app blocker, remote uninstaller, force-stop, and deep APK/permission inspector")
                                put("cliCommand", "python send_cmd.py app-guard [status | block <app> | unblock <app|all> | uninstall <app> | force-stop <app> | info <app> | events | policy]")
                            })
                            put("audio", org.json.JSONObject().apply {
                                put("statusEndpoint", "/api/audio/status")
                                put("volumeEndpoint", "/api/audio/volume")
                                put("volumePayload", "{ \"stream\": \"MEDIA\"|\"RING\"|\"ALARM\"|\"CALL\"|\"NOTIF\", \"percent\": 0..100 }")
                                put("ringerModeEndpoint", "/api/audio/ringer_mode")
                                put("ringerModePayload", "{ \"mode\": \"NORMAL\"|\"VIBRATE\"|\"SILENT\" }")
                                put("realtimeStartEndpoint", "/api/audio/realtime/start")
                                put("realtimeStopEndpoint", "/api/audio/realtime/stop")
                                put("realtimeStatusEndpoint", "/api/audio/realtime/status")
                                put("playEndpoint", "/api/audio/play_file")
                                put("playPayload", "{ \"filePath\": \"/path/to/audio.wav\" }")
                                put("cliCommand", "python send_cmd.py audio [volume <stream> <percent> | ringer <mode> | record-live | stop-live | status-live | play <path>]")
                            })
                        })
                        put("availableEndpoints", org.json.JSONArray(listOf(
                            "/api/help", "/api/battery/status", "/api/sensors/status",
                            "/api/display/status", "/api/display/brightness", "/api/display/auto_brightness",
                            "/api/display/timeout", "/api/display/wakelock",
                            "/api/network/status", "/api/network/speed",
                            "/api/network/moderation/status", "/api/network/moderation/block", "/api/network/moderation/unblock",
                            "/api/network/moderation/rules", "/api/network/moderation/logs", "/api/network/moderation/service",
                            "/api/network/moderation/categories", "/api/network/moderation/category", "/api/network/moderation/analytics",
                            "/api/network/moderation/inspect-site", "/api/network/inspect-site",
                            "/api/network/moderation/private-dns", "/api/network/private-dns",
                            "/api/network/diag/ping", "/api/network/diag/dns", "/api/network/diag/port",
                            "/api/apps/guard/status", "/api/apps/guard/block", "/api/apps/guard/unblock",
                            "/api/apps/guard/uninstall", "/api/apps/guard/force-stop", "/api/apps/guard/settings",
                            "/api/apps/guard/info", "/api/apps/guard/events",
                            "/api/audio/status", "/api/audio/volume", "/api/audio/ringer_mode",
                            "/api/audio/realtime/start", "/api/audio/realtime/stop", "/api/audio/realtime/status", "/api/audio/play_file",
                            "/api/camera/status", "/api/camera/test",
                            "/api/notif/status", "/api/notif/test",
                            "/api/storage/status", "/api/storage/test",
                            "/api/permissions/status", "/api/permissions/request",
                            "/api/shell/exec", "/api/screen/capture"
                        )))
                    }
                    for (k in helpObj.keys()) {
                        result.put(k, helpObj.get(k))
                    }
                }
                "/api/battery/status" -> {
                    val battRes = deviceBridgeManager.getBatteryStationDetails()
                    battRes.keys().forEach { k -> result.put(k, battRes.get(k)) }
                }
                "/api/sensors/status" -> {
                    val sensRes = deviceBridgeManager.getSensorsStationDetails()
                    sensRes.keys().forEach { k -> result.put(k, sensRes.get(k)) }
                }
                "/api/display/status" -> {
                    val dispRes = deviceBridgeManager.getDisplayStationDetails()
                    dispRes.keys().forEach { k -> result.put(k, dispRes.get(k)) }
                }
                "/api/display/brightness" -> {
                    val level = json.optInt("brightness", json.optInt("level", 128))
                    val bRes = deviceBridgeManager.setDisplayBrightness(level)
                    bRes.keys().forEach { k -> result.put(k, bRes.get(k)) }
                }
                "/api/display/auto_brightness", "/api/display/auto" -> {
                    val enabled = json.optBoolean("enabled", json.optBoolean("autoBrightness", true))
                    val abRes = deviceBridgeManager.setDisplayAutoBrightness(enabled)
                    abRes.keys().forEach { k -> result.put(k, abRes.get(k)) }
                }
                "/api/display/timeout" -> {
                    val sec = json.optInt("seconds", json.optInt("timeout", 60))
                    val toRes = deviceBridgeManager.setDisplayTimeout(sec)
                    toRes.keys().forEach { k -> result.put(k, toRes.get(k)) }
                }
                "/api/display/wakelock" -> {
                    val enable = json.optBoolean("enable", json.optBoolean("enabled", true))
                    val wlRes = deviceBridgeManager.toggleScreenWakeLock(enable)
                    wlRes.keys().forEach { k -> result.put(k, wlRes.get(k)) }
                }
                "/api/network/status" -> {
                    val netRes = deviceBridgeManager.getNetworkStationDetails()
                    netRes.keys().forEach { k -> result.put(k, netRes.get(k)) }
                }
                "/api/network/moderation/status" -> {
                    val modRes = deviceBridgeManager.getNetworkModerationStatus()
                    modRes.keys().forEach { k -> result.put(k, modRes.get(k)) }
                }
                "/api/network/moderation/block" -> {
                    val domain = json.optString("domain", json.optString("host", ""))
                    val ip = json.optString("ip", "")
                    if (domain.isNotBlank()) {
                        val blRes = deviceBridgeManager.blockNetworkDomain(domain)
                        blRes.keys().forEach { k -> result.put(k, blRes.get(k)) }
                    } else if (ip.isNotBlank()) {
                        val blRes = deviceBridgeManager.blockNetworkIp(ip)
                        blRes.keys().forEach { k -> result.put(k, blRes.get(k)) }
                    } else {
                        result.put("success", false)
                        result.put("error", "Provide 'domain' or 'ip' to block")
                    }
                }
                "/api/network/moderation/unblock" -> {
                    val domain = json.optString("domain", json.optString("host", ""))
                    val ip = json.optString("ip", "")
                    if (domain.isNotBlank()) {
                        val ubRes = deviceBridgeManager.unblockNetworkDomain(domain)
                        ubRes.keys().forEach { k -> result.put(k, ubRes.get(k)) }
                    } else if (ip.isNotBlank()) {
                        val ubRes = deviceBridgeManager.unblockNetworkIp(ip)
                        ubRes.keys().forEach { k -> result.put(k, ubRes.get(k)) }
                    } else {
                        result.put("success", false)
                        result.put("error", "Provide 'domain' or 'ip' to unblock")
                    }
                }
                "/api/network/moderation/rules" -> {
                    val rulesRes = deviceBridgeManager.getNetworkModerationRules()
                    rulesRes.keys().forEach { k -> result.put(k, rulesRes.get(k)) }
                }
                "/api/network/moderation/logs" -> {
                    val limit = json.optInt("limit", 50)
                    val logsRes = deviceBridgeManager.getNetworkModerationLogs(limit)
                    logsRes.keys().forEach { k -> result.put(k, logsRes.get(k)) }
                }
                "/api/network/moderation/service" -> {
                    val action = json.optString("action", if (json.optBoolean("start", true)) "start" else "stop").lowercase()
                    val vpnRes = deviceBridgeManager.toggleNetworkModeratorVpn(action == "start" || action == "enable")
                    vpnRes.keys().forEach { k -> result.put(k, vpnRes.get(k)) }
                }
                "/api/network/moderation/categories" -> {
                    val catRes = deviceBridgeManager.getNetworkCategoriesStatus()
                    catRes.keys().forEach { k -> result.put(k, catRes.get(k)) }
                }
                "/api/network/moderation/category" -> {
                    val cat = json.optString("category", json.optString("name", ""))
                    val enabled = json.optBoolean("enabled", json.optString("action", "enable").lowercase() != "disable")
                    val setRes = deviceBridgeManager.setNetworkCategoryEnabled(cat, enabled)
                    setRes.keys().forEach { k -> result.put(k, setRes.get(k)) }
                }
                "/api/network/moderation/analytics" -> {
                    val topN = json.optInt("top", json.optInt("limit", 20))
                    val anaRes = deviceBridgeManager.getNetworkDomainAnalytics(topN)
                    anaRes.keys().forEach { k -> result.put(k, anaRes.get(k)) }
                }
                "/api/network/moderation/inspect-site", "/api/network/inspect-site" -> {
                    val target = json.optString("target", json.optString("domain", json.optString("url", "")))
                    val inspRes = networkModerationManager.inspectSiteMetadataJson(target)
                    inspRes.keys().forEach { k -> result.put(k, inspRes.get(k)) }
                }
                "/api/adult-shield/status", "/api/adult-shield", "/api/network/moderation/adult-shield" -> {
                    val stRes = adultContentShieldManager.getStatusJson()
                    stRes.keys().forEach { k -> result.put(k, stRes.get(k)) }
                }
                "/api/adult-shield/policy", "/api/adult-shield/config" -> {
                    val strictMode = if (json.has("strictModeEnabled")) json.optBoolean("strictModeEnabled")
                        else if (json.has("enabled")) json.optBoolean("enabled") else null
                    val webAndVideo = if (json.has("blockWebAndVideo")) json.optBoolean("blockWebAndVideo") else null
                    val readingAndManga = if (json.has("blockReadingAndManga")) json.optBoolean("blockReadingAndManga") else null
                    val adultSearches = if (json.has("blockAdultSearches")) json.optBoolean("blockAdultSearches") else null
                    val adultAppsAndApks = if (json.has("blockAdultAppsAndApks")) json.optBoolean("blockAdultAppsAndApks") else null
                    val quarantineFiles = if (json.has("quarantineDownloads")) json.optBoolean("quarantineDownloads") else null
                    val safeSearchDns = if (json.has("forceSafeSearchDns")) json.optBoolean("forceSafeSearchDns") else null
                    val bypassVpns = if (json.has("blockBypassVpns")) json.optBoolean("blockBypassVpns") else null
                    val incognitoTabs = if (json.has("blockIncognitoTabs")) json.optBoolean("blockIncognitoTabs") else null
                    val settingsTampering = if (json.has("blockSettingsTampering")) json.optBoolean("blockSettingsTampering") else null
                    val clipboardAndNotifs = if (json.has("blockClipboardAndNotifs")) json.optBoolean("blockClipboardAndNotifs") else null
                    val adminLock = if (json.has("adminLockEnabled")) json.optBoolean("adminLockEnabled") else null
                    val pin = json.optString("pin", json.optString("adminPin", "")).takeIf { it.isNotEmpty() }
                    val bio = json.optBoolean("biometricVerified", false)
                    val polRes = adultContentShieldManager.updateShieldPolicy(
                        strictMode = strictMode,
                        webAndVideo = webAndVideo,
                        readingAndManga = readingAndManga,
                        adultSearches = adultSearches,
                        adultAppsAndApks = adultAppsAndApks,
                        quarantineFiles = quarantineFiles,
                        safeSearchDns = safeSearchDns,
                        bypassVpns = bypassVpns,
                        incognitoTabs = incognitoTabs,
                        settingsTampering = settingsTampering,
                        clipboardAndNotifs = clipboardAndNotifs,
                        adminLock = adminLock,
                        pin = pin,
                        biometricVerified = bio
                    )
                    polRes.keys().forEach { k -> result.put(k, polRes.get(k)) }
                }
                "/api/adult-shield/unlock" -> {
                    val pin = json.optString("pin", json.optString("adminPin", "")).takeIf { it.isNotEmpty() }
                    val minutes = json.optInt("durationMinutes", json.optInt("minutes", 5))
                    val bio = json.optBoolean("biometricVerified", false)
                    val unlRes = adultContentShieldManager.unlockAdminSession(pin, minutes, bio)
                    unlRes.keys().forEach { k -> result.put(k, unlRes.get(k)) }
                }
                "/api/adult-shield/logs", "/api/adult-shield/violations" -> {
                    val limit = json.optInt("limit", 50)
                    val logRes = adultContentShieldManager.getViolationLogsJson(limit)
                    logRes.keys().forEach { k -> result.put(k, logRes.get(k)) }
                }
                "/api/adult-shield/quarantine" -> {
                    val action = json.optString("action", "list").lowercase()
                    val qRes = if (action == "purge" || action == "clear" || json.optBoolean("purge", false)) {
                        val pin = json.optString("pin", json.optString("adminPin", ""))
                        adultContentShieldManager.purgeAllQuarantinedFiles(pin = pin)
                    } else {
                        adultContentShieldManager.getQuarantineListJson()
                    }
                    qRes.keys().forEach { k -> result.put(k, qRes.get(k)) }
                }
                "/api/adult-shield/scan" -> {
                    val scanRes = adultContentShieldManager.scanAndQuarantineDownloads()
                    scanRes.keys().forEach { k -> result.put(k, scanRes.get(k)) }
                }
                "/api/adult-shield/test", "/api/adult-shield/check" -> {
                    val target = json.optString("target", json.optString("query", json.optString("url", "")))
                    val testRes = adultContentShieldManager.testTargetAgainstShieldJson(target)
                    testRes.keys().forEach { k -> result.put(k, testRes.get(k)) }
                }
                "/api/adult-shield/pin" -> {
                    val currentPin = json.optString("currentPin", json.optString("oldPin", ""))
                    val newPin = json.optString("newPin", json.optString("pin", ""))
                    val pinRes = adultContentShieldManager.setAdminPin(currentPin, newPin)
                    pinRes.keys().forEach { k -> result.put(k, pinRes.get(k)) }
                }
                "/api/network/moderation/private-dns", "/api/network/private-dns" -> {
                    val preset = json.optString("preset", json.optString("hostname", json.optString("mode", json.optString("target", "status"))))
                    val allowUi = json.optBoolean("allowUiAutomation", true)
                    val dnsRes = networkModerationManager.configureSystemPrivateDns(preset, allowUiAutomation = allowUi)
                    dnsRes.keys().forEach { k -> result.put(k, dnsRes.get(k)) }
                }
                "/api/network/moderation/export", "/api/network/export", "/api/network/logs/export" -> {
                    val format = json.optString("format", "csv")
                    val includeAllowed = json.optBoolean("includeAllowed", json.optBoolean("all", true))
                    val limit = json.optInt("limit", 1000)
                    val expRes = networkModerationManager.exportAuditLogs(format, includeAllowed, limit)
                    expRes.keys().forEach { k -> result.put(k, expRes.get(k)) }
                }
                "/api/network/moderation/block-screen", "/api/network/block-screen" -> {
                    val hasEnabled = json.has("enabled")
                    val hasMsg = json.has("message") || json.has("customMessage")
                    val hasDismiss = json.has("autoDismissSeconds") || json.has("dismiss")
                    val test = json.optBoolean("test", json.optBoolean("preview", json.optBoolean("trigger", json.optBoolean("show", false))))
                    val hide = json.optBoolean("hide", json.optBoolean("close", json.optBoolean("dismissNow", false)))
                    if (hide) {
                        networkModerationManager.dismissVisualBlockScreen()
                        result.put("success", true)
                        result.put("message", "Block screen overlay dismissed")
                    } else if (hasEnabled || hasMsg || hasDismiss || test) {
                        val enabled = if (hasEnabled) json.optBoolean("enabled") else null
                        val msg = if (hasMsg) json.optString("message", json.optString("customMessage")) else null
                        val dismiss = if (hasDismiss) json.optInt("autoDismissSeconds", json.optInt("dismiss", 6)) else null
                        val domain = json.optString("domain", "sample-restricted-site.com")
                        val updateRes = networkModerationManager.setBlockScreenConfig(
                            enabled = enabled,
                            message = msg,
                            dismissSec = dismiss,
                            preview = test || hasMsg,
                            previewDomain = domain,
                            previewReason = if (hasMsg) "Updated Message Preview" else "Manual CLI Test Verification",
                            previewCategory = if (hasMsg) "PREVIEW" else "VERIFICATION"
                        )
                        updateRes.keys().forEach { k -> result.put(k, updateRes.get(k)) }
                    } else {
                        val cfgRes = networkModerationManager.getBlockScreenConfig()
                        cfgRes.keys().forEach { k -> result.put(k, cfgRes.get(k)) }
                    }
                }
                "/api/network/speed", "/api/network/bandwidth" -> {
                    val spdRes = deviceBridgeManager.getNetworkLiveBandwidthSpeed()
                    spdRes.keys().forEach { k -> result.put(k, spdRes.get(k)) }
                }
                "/api/network/apps", "/api/network/per-app" -> {
                    val topN = json.optInt("top", json.optInt("limit", 30))
                    val includeZero = json.optBoolean("includeAll", json.optBoolean("all", false))
                    val appsRes = networkModerationManager.perAppMonitor.getAllAppsLiveTrafficJson(topN, includeZero)
                    appsRes.keys().forEach { k -> result.put(k, appsRes.get(k)) }
                }
                "/api/network/app/inspect", "/api/network/app" -> {
                    val target = json.optString("target", "").ifBlank {
                        json.optString("package", "").ifBlank {
                            json.optString("packageName", "").ifBlank { json.optString("app", "") }
                        }
                    }
                    val limit = json.optInt("limit", 35)
                    val appRes = networkModerationManager.perAppMonitor.getSingleAppLiveTrafficJson(target, limit)
                    appRes.keys().forEach { k -> result.put(k, appRes.get(k)) }
                }
                "/api/network/app/block" -> {
                    val target = json.optString("target", "").ifBlank {
                        json.optString("package", "").ifBlank {
                            json.optString("packageName", "").ifBlank { json.optString("app", "") }
                        }
                    }
                    val blkRes = networkModerationManager.perAppMonitor.blockAppNetwork(target)
                    blkRes.keys().forEach { k -> result.put(k, blkRes.get(k)) }
                }
                "/api/network/app/unblock" -> {
                    val target = json.optString("target", "").ifBlank {
                        json.optString("package", "").ifBlank {
                            json.optString("packageName", "").ifBlank { json.optString("app", "all") }
                        }
                    }
                    val all = json.optBoolean("all", target.equals("all", ignoreCase = true) || target == "*")
                    val unbRes = networkModerationManager.perAppMonitor.unblockAppNetwork(target, all)
                    unbRes.keys().forEach { k -> result.put(k, unbRes.get(k)) }
                }
                "/api/network/browsing", "/api/network/connections" -> {
                    val limit = json.optInt("limit", 40)
                    val brRes = networkModerationManager.perAppMonitor.getCurrentBrowsingSessionJson(limit)
                    brRes.keys().forEach { k -> result.put(k, brRes.get(k)) }
                }
                "/api/network/diag/ping" -> {
                    val host = json.optString("host", json.optString("target", "8.8.8.8"))
                    val count = json.optInt("count", 3)
                    val pingRes = deviceBridgeManager.runNetworkPing(host, count)
                    pingRes.keys().forEach { k -> result.put(k, pingRes.get(k)) }
                }
                "/api/network/diag/dns" -> {
                    val domain = json.optString("domain", json.optString("host", "google.com"))
                    val dnsRes = deviceBridgeManager.runNetworkDnsLookup(domain)
                    dnsRes.keys().forEach { k -> result.put(k, dnsRes.get(k)) }
                }
                "/api/network/diag/port" -> {
                    val host = json.optString("host", "127.0.0.1")
                    val port = json.optInt("port", 80)
                    val timeoutMs = json.optInt("timeoutMs", 3000)
                    val portRes = deviceBridgeManager.runNetworkPortCheck(host, port, timeoutMs)
                    portRes.keys().forEach { k -> result.put(k, portRes.get(k)) }
                }
                "/api/config/url" -> {
                    val rawUrl = json.optString("publicBaseUrl", json.optString("publicUrl", json.optString("url", ""))).trim().trimEnd('/')
                    val wsUrl = when {
                        rawUrl.startsWith("wss://") || rawUrl.startsWith("ws://") -> if (rawUrl.endsWith("/ws")) rawUrl else "$rawUrl/ws"
                        rawUrl.startsWith("https://") -> "wss://" + rawUrl.removePrefix("https://").removeSuffix("/ws") + "/ws"
                        rawUrl.startsWith("http://") -> "ws://" + rawUrl.removePrefix("http://").removeSuffix("/ws") + "/ws"
                        else -> ""
                    }
                    result.put("success", true)
                    if (wsUrl.isNotBlank()) {
                        com.kavach.services.RealtimeConnectionService.reconnect(context, wsUrl)
                        result.put("wsUrl", wsUrl)
                    }
                }
                "/api/audio/volume" -> {
                    val stream = json.optString("stream", "MEDIA")
                    val pct = json.optInt("percent", json.optInt("volume", 50))
                    val vRes = deviceBridgeManager.setAudioStreamVolume(stream, pct)
                    vRes.keys().forEach { k -> result.put(k, vRes.get(k)) }
                }
                "/api/audio/ringer_mode" -> {
                    val mode = json.optString("mode", json.optString("ringerMode", "NORMAL"))
                    val rRes = deviceBridgeManager.setRingerMode(mode)
                    rRes.keys().forEach { k -> result.put(k, rRes.get(k)) }
                }
                "/api/apps/guard/status", "/api/apps/guard" -> {
                    val stRes = appGuardManager.getStatusJson()
                    stRes.keys().forEach { k -> result.put(k, stRes.get(k)) }
                }
                "/api/apps/guard/block", "/api/apps/block" -> {
                    val target = json.optString("target", "").ifBlank {
                        json.optString("package", "").ifBlank {
                            json.optString("packageName", "").ifBlank { json.optString("app", "") }
                        }
                    }
                    val bRes = appGuardManager.blockApp(target)
                    bRes.keys().forEach { k -> result.put(k, bRes.get(k)) }
                }
                "/api/apps/guard/unblock", "/api/apps/unblock" -> {
                    val target = json.optString("target", "").ifBlank {
                        json.optString("package", "").ifBlank {
                            json.optString("packageName", "").ifBlank { json.optString("app", "") }
                        }
                    }
                    val all = json.optBoolean("all", target.equals("all", ignoreCase = true))
                    val ubRes = appGuardManager.unblockApp(target, unblockAll = all)
                    ubRes.keys().forEach { k -> result.put(k, ubRes.get(k)) }
                }
                "/api/apps/guard/uninstall", "/api/apps/uninstall" -> {
                    val target = json.optString("target", "").ifBlank {
                        json.optString("package", "").ifBlank {
                            json.optString("packageName", "").ifBlank { json.optString("app", "") }
                        }
                    }
                    val unRes = appGuardManager.uninstallApp(target)
                    unRes.keys().forEach { k -> result.put(k, unRes.get(k)) }
                }
                "/api/apps/guard/force-stop", "/api/apps/force-stop", "/api/apps/kill" -> {
                    val target = json.optString("target", "").ifBlank {
                        json.optString("package", "").ifBlank {
                            json.optString("packageName", "").ifBlank { json.optString("app", "") }
                        }
                    }
                    val fsRes = appGuardManager.forceStopApp(target)
                    fsRes.keys().forEach { k -> result.put(k, fsRes.get(k)) }
                }
                "/api/apps/guard/settings", "/api/apps/settings" -> {
                    val target = json.optString("target", "").ifBlank {
                        json.optString("package", "").ifBlank {
                            json.optString("packageName", "").ifBlank { json.optString("app", "") }
                        }
                    }
                    if (target.isNotBlank()) {
                        val sRes = appGuardManager.openAppSettings(target)
                        sRes.keys().forEach { k -> result.put(k, sRes.get(k)) }
                    } else {
                        val alertInst = if (json.has("alertOnInstall")) json.optBoolean("alertOnInstall") else null
                        val alertUninst = if (json.has("alertOnUninstall")) json.optBoolean("alertOnUninstall") else null
                        val alertBlk = if (json.has("alertOnBlockedLaunch")) json.optBoolean("alertOnBlockedLaunch") else null
                        val autoBlk = if (json.has("autoBlockNewInstalls")) json.optBoolean("autoBlockNewInstalls") else null
                        val polRes = appGuardManager.updatePolicy(alertInst, alertUninst, alertBlk, autoBlk)
                        polRes.keys().forEach { k -> result.put(k, polRes.get(k)) }
                    }
                }
                "/api/apps/guard/policy", "/api/apps/policy" -> {
                    val alertInst = if (json.has("alertOnInstall")) json.optBoolean("alertOnInstall") else null
                    val alertUninst = if (json.has("alertOnUninstall")) json.optBoolean("alertOnUninstall") else null
                    val alertBlk = if (json.has("alertOnBlockedLaunch")) json.optBoolean("alertOnBlockedLaunch") else null
                    val autoBlk = if (json.has("autoBlockNewInstalls")) json.optBoolean("autoBlockNewInstalls") else null
                    val polRes = appGuardManager.updatePolicy(alertInst, alertUninst, alertBlk, autoBlk)
                    polRes.keys().forEach { k -> result.put(k, polRes.get(k)) }
                }
                "/api/apps/guard/info", "/api/apps/info" -> {
                    val target = json.optString("target", "").ifBlank {
                        json.optString("package", "").ifBlank {
                            json.optString("packageName", "").ifBlank { json.optString("app", "") }
                        }
                    }
                    val infoRes = appGuardManager.getAppDetailsJson(target)
                    infoRes.keys().forEach { k -> result.put(k, infoRes.get(k)) }
                }
                "/api/apps/guard/events/clear", "/api/apps/events/clear" -> {
                    val clRes = appGuardManager.clearEvents()
                    clRes.keys().forEach { k -> result.put(k, clRes.get(k)) }
                }
                "/api/apps/guard/events", "/api/apps/events" -> {
                    if (json.optBoolean("clear", false)) {
                        val clRes = appGuardManager.clearEvents()
                        clRes.keys().forEach { k -> result.put(k, clRes.get(k)) }
                    } else {
                        val stRes = appGuardManager.getStatusJson()
                        result.put("success", true)
                        result.put("eventsCount", stRes.optInt("recentEventsCount", 0))
                        result.put("events", stRes.optJSONArray("recentEvents") ?: org.json.JSONArray())
                    }
                }
                // ------------------------------------------------------------------
                // SUITE 1: APP USAGE TIME LIMITS & DAILY SCREEN-TIME ANALYTICS
                // ------------------------------------------------------------------
                "/api/apps/usage/stats", "/api/apps/usage" -> {
                    val topN = json.optInt("top", json.optInt("limit", 25))
                    val stRes = deviceOpsExpansionManager.getDailyScreenTimeStatsJson(topN)
                    stRes.keys().forEach { k -> result.put(k, stRes.get(k)) }
                }
                "/api/apps/usage/limit/set", "/api/apps/usage/limit" -> {
                    val target = json.optString("target", "").ifBlank {
                        json.optString("package", "").ifBlank {
                            json.optString("packageName", "").ifBlank { json.optString("app", "") }
                        }
                    }
                    val minutes = json.optInt("dailyLimitMinutes", json.optInt("minutes", json.optInt("limit", 0)))
                    val limRes = deviceOpsExpansionManager.setAppUsageLimit(target, minutes)
                    limRes.keys().forEach { k -> result.put(k, limRes.get(k)) }
                }
                "/api/apps/usage/limit/remove" -> {
                    val target = json.optString("target", "").ifBlank {
                        json.optString("package", "").ifBlank {
                            json.optString("packageName", "").ifBlank { json.optString("app", "") }
                        }
                    }
                    val all = json.optBoolean("all", target.equals("all", ignoreCase = true) || target == "*")
                    val rmRes = deviceOpsExpansionManager.removeAppUsageLimit(target, all)
                    rmRes.keys().forEach { k -> result.put(k, rmRes.get(k)) }
                }
                // ------------------------------------------------------------------
                // SUITE 2: INTRUDER & DEVICE UNLOCK MONITOR
                // ------------------------------------------------------------------
                "/api/security/unlock/status", "/api/security/unlock/logs", "/api/security/intruder/status" -> {
                    val limit = json.optInt("limit", 40)
                    val unRes = deviceOpsExpansionManager.getUnlockMonitorStatusJson(limit)
                    unRes.keys().forEach { k -> result.put(k, unRes.get(k)) }
                }
                "/api/security/unlock/policy", "/api/security/intruder/policy" -> {
                    val enabled = if (json.has("enabled")) json.optBoolean("enabled") else null
                    val alertOnUnlock = if (json.has("alertOnUnlock")) json.optBoolean("alertOnUnlock") else null
                    val capturePhoto = if (json.has("capturePhotoOnUnlock")) json.optBoolean("capturePhotoOnUnlock")
                    else if (json.has("photo")) json.optBoolean("photo") else null
                    val polRes = deviceOpsExpansionManager.updateUnlockPolicy(enabled, alertOnUnlock, capturePhoto)
                    polRes.keys().forEach { k -> result.put(k, polRes.get(k)) }
                }
                "/api/security/unlock/snap", "/api/security/intruder/snap" -> {
                    val lens = json.optString("lens", json.optString("camera", "front"))
                    val snapRes = kotlinx.coroutines.runBlocking {
                        deviceOpsExpansionManager.triggerIntruderSnapshot(lens)
                    }
                    snapRes.keys().forEach { k -> result.put(k, snapRes.get(k)) }
                }
                "/api/security/unlock/clear", "/api/security/intruder/clear" -> {
                    val clRes = deviceOpsExpansionManager.clearUnlockLogs()
                    clRes.keys().forEach { k -> result.put(k, clRes.get(k)) }
                }
                // ------------------------------------------------------------------
                // SUITE 3: CLIPBOARD & NOTIFICATION HISTORY + KEYWORD WATCH
                // ------------------------------------------------------------------
                "/api/history/clipboard", "/api/clipboard/history" -> {
                    val query = json.optString("query", json.optString("search", ""))
                    val limit = json.optInt("limit", 50)
                    val chRes = deviceOpsExpansionManager.getClipboardHistoryJson(query, limit)
                    chRes.keys().forEach { k -> result.put(k, chRes.get(k)) }
                }
                "/api/history/notifications", "/api/notifications/history" -> {
                    val query = json.optString("query", json.optString("search", ""))
                    val limit = json.optInt("limit", 60)
                    val nhRes = deviceOpsExpansionManager.getNotificationHistoryJson(query, limit)
                    nhRes.keys().forEach { k -> result.put(k, nhRes.get(k)) }
                }
                "/api/history/keywords/add", "/api/keywords/add" -> {
                    val kw = json.optString("keyword", json.optString("word", json.optString("target", "")))
                    val kwRes = deviceOpsExpansionManager.addWatchedKeyword(kw)
                    kwRes.keys().forEach { k -> result.put(k, kwRes.get(k)) }
                }
                "/api/history/keywords/remove", "/api/keywords/remove" -> {
                    val kw = json.optString("keyword", json.optString("word", json.optString("target", "")))
                    val all = json.optBoolean("all", kw.equals("all", ignoreCase = true) || kw == "*")
                    val kwRes = deviceOpsExpansionManager.removeWatchedKeyword(kw, all)
                    kwRes.keys().forEach { k -> result.put(k, kwRes.get(k)) }
                }
                "/api/history/keywords/list", "/api/keywords/list", "/api/keywords" -> {
                    val chRes = deviceOpsExpansionManager.getClipboardHistoryJson("", 5)
                    result.put("success", true)
                    result.put("watchedKeywords", chRes.optJSONArray("watchedKeywords") ?: org.json.JSONArray())
                    result.put("clipboardTotalCount", chRes.optInt("totalCount", 0))
                }
                "/api/history/clear" -> {
                    val target = json.optString("target", "all")
                    val clRes = deviceOpsExpansionManager.clearHistoryLogs(target)
                    clRes.keys().forEach { k -> result.put(k, clRes.get(k)) }
                }
                // ------------------------------------------------------------------
                // SUITE 4: SCHEDULED & EVENT-DRIVEN AUTOMATION RULES
                // ------------------------------------------------------------------
                "/api/automation/rules/list", "/api/automation/rules" -> {
                    val rlRes = deviceOpsExpansionManager.listAutomationRulesJson()
                    rlRes.keys().forEach { k -> result.put(k, rlRes.get(k)) }
                }
                "/api/automation/rules/add" -> {
                    val name = json.optString("name", json.optString("title", "Rule"))
                    val trigger = json.optString("trigger", json.optString("when", ""))
                    val action = json.optString("action", json.optString("do", ""))
                    val cooldown = json.optInt("cooldownMinutes", json.optInt("cooldown", 15))
                    val addRes = deviceOpsExpansionManager.addAutomationRule(name, trigger, action, cooldown)
                    addRes.keys().forEach { k -> result.put(k, addRes.get(k)) }
                }
                "/api/automation/rules/remove" -> {
                    val target = json.optString("target", json.optString("id", json.optString("name", "")))
                    val all = json.optBoolean("all", target.equals("all", ignoreCase = true) || target == "*")
                    val rmRes = deviceOpsExpansionManager.removeAutomationRule(target, all)
                    rmRes.keys().forEach { k -> result.put(k, rmRes.get(k)) }
                }
                "/api/automation/rules/toggle" -> {
                    val target = json.optString("target", json.optString("id", json.optString("name", "")))
                    val enabled = json.optBoolean("enabled", true)
                    val tgRes = deviceOpsExpansionManager.toggleAutomationRule(target, enabled)
                    tgRes.keys().forEach { k -> result.put(k, tgRes.get(k)) }
                }
                "/api/automation/rules/test", "/api/automation/rules/run" -> {
                    val target = json.optString("target", json.optString("id", json.optString("name", "")))
                    val tsRes = deviceOpsExpansionManager.testExecuteAutomationRule(target)
                    tsRes.keys().forEach { k -> result.put(k, tsRes.get(k)) }
                }
                // ------------------------------------------------------------------
                // SUITE 5: APK BACKUP EXTRACTOR & REMOTE APK INSTALLER
                // ------------------------------------------------------------------
                "/api/apps/apk/backup", "/api/apk/backup" -> {
                    val target = json.optString("target", "").ifBlank {
                        json.optString("package", "").ifBlank {
                            json.optString("packageName", "").ifBlank { json.optString("app", "") }
                        }
                    }
                    val bkRes = deviceOpsExpansionManager.backupAppApk(target)
                    bkRes.keys().forEach { k -> result.put(k, bkRes.get(k)) }
                }
                "/api/apps/apk/backups", "/api/apps/apk/list", "/api/apk/backups" -> {
                    val lsRes = deviceOpsExpansionManager.listBackedUpApksJson()
                    lsRes.keys().forEach { k -> result.put(k, lsRes.get(k)) }
                }
                "/api/apps/apk/verify", "/api/apps/verify", "/api/apk/verify" -> {
                    val target = json.optString("target", "").ifBlank {
                        json.optString("path", "").ifBlank {
                            json.optString("package", "").ifBlank {
                                json.optString("packageName", "").ifBlank { json.optString("app", "") }
                            }
                        }
                    }
                    val vRes = deviceOpsExpansionManager.verifyApkOrApp(target)
                    vRes.keys().forEach { k -> result.put(k, vRes.get(k)) }
                }
                "/api/apps/apk/install", "/api/apk/install" -> {
                    val path = json.optString("path", json.optString("apkPath", json.optString("file", json.optString("target", ""))))
                    val force = json.optBoolean("force", false)
                    val inRes = deviceOpsExpansionManager.installApkFromPath(path, force)
                    inRes.keys().forEach { k -> result.put(k, inRes.get(k)) }
                }
                "/api/app/visibility" -> {
                    if (json.has("hidden") || json.has("hide") || json.has("visible")) {
                        val targetHidden = when {
                            json.has("hidden") -> json.optBoolean("hidden")
                            json.has("hide") -> json.optBoolean("hide")
                            else -> !json.optBoolean("visible", true)
                        }
                        appVisibilityManager.setAppHidden(targetHidden)
                    }
                    val visRes = appVisibilityManager.getStatusJson()
                    visRes.keys().forEach { k -> result.put(k, visRes.get(k)) }
                }
                "/api/app/hide" -> {
                    appVisibilityManager.setAppHidden(true)
                    val visRes = appVisibilityManager.getStatusJson()
                    visRes.keys().forEach { k -> result.put(k, visRes.get(k)) }
                }
                "/api/app/unhide", "/api/app/show" -> {
                    appVisibilityManager.setAppHidden(false)
                    val visRes = appVisibilityManager.getStatusJson()
                    visRes.keys().forEach { k -> result.put(k, visRes.get(k)) }
                }
                // ------------------------------------------------------------------
                // OFFLINE TELEMETRY VAULT & 20-DAY POST-SYNC TIMELINE
                // ------------------------------------------------------------------
                "/api/vault/status", "/api/timeline/status" -> {
                    val vRes = telemetryVaultManager.getStatusJson()
                    vRes.keys().forEach { k -> result.put(k, vRes.get(k)) }
                }
                "/api/vault/timeline", "/api/timeline/events", "/api/vault/events" -> {
                    val category = json.optString("category", "")
                    val sinceHours = json.optDouble("sinceHours", json.optDouble("hours", 0.0))
                    val sinceDays = json.optDouble("days", 0.0)
                    val explicitSince = json.optLong("sinceMs", 0L)
                    val now = System.currentTimeMillis()
                    val sinceMs = when {
                        explicitSince > 0L -> explicitSince
                        sinceHours > 0.0 -> now - (sinceHours * 3600_000.0).toLong()
                        sinceDays > 0.0 -> now - (sinceDays * 86_400_000.0).toLong()
                        else -> 0L
                    }
                    val untilMs = json.optLong("untilMs", Long.MAX_VALUE)
                    val query = json.optString("query", json.optString("search", ""))
                    val pendingOnly = json.optBoolean("pendingOnly", false)
                    val limit = json.optInt("limit", 150)
                    val offset = json.optInt("offset", 0)
                    val tRes = telemetryVaultManager.queryTimelineJson(
                        category = category,
                        sinceMs = sinceMs,
                        untilMs = untilMs,
                        searchQuery = query,
                        pendingOnly = pendingOnly,
                        limit = limit,
                        offset = offset
                    )
                    tRes.keys().forEach { k -> result.put(k, tRes.get(k)) }
                }
                "/api/vault/location", "/api/timeline/location", "/api/vault/paths" -> {
                    val sinceHours = json.optDouble("sinceHours", json.optDouble("hours", 0.0))
                    val sinceDays = json.optDouble("days", 0.0)
                    val explicitSince = json.optLong("sinceMs", 0L)
                    val now = System.currentTimeMillis()
                    val sinceMs = when {
                        explicitSince > 0L -> explicitSince
                        sinceHours > 0.0 -> now - (sinceHours * 3600_000.0).toLong()
                        sinceDays > 0.0 -> now - (sinceDays * 86_400_000.0).toLong()
                        else -> 0L
                    }
                    val untilMs = json.optLong("untilMs", Long.MAX_VALUE)
                    val pendingOnly = json.optBoolean("pendingOnly", false)
                    val limit = json.optInt("limit", 500)
                    val lRes = telemetryVaultManager.queryLocationPathJson(sinceMs, untilMs, pendingOnly, limit)
                    lRes.keys().forEach { k -> result.put(k, lRes.get(k)) }
                }
                "/api/vault/snapshots", "/api/timeline/snapshots" -> {
                    val sinceHours = json.optDouble("sinceHours", json.optDouble("hours", 24.0))
                    val explicitSince = json.optLong("sinceMs", 0L)
                    val sinceMs = if (explicitSince > 0L) explicitSince else (System.currentTimeMillis() - (sinceHours * 3600_000.0).toLong())
                    val pendingOnly = json.optBoolean("pendingOnly", false)
                    val limit = json.optInt("limit", 100)
                    val sRes = telemetryVaultManager.querySnapshotsJson(sinceMs, Long.MAX_VALUE, pendingOnly, limit)
                    sRes.keys().forEach { k -> result.put(k, sRes.get(k)) }
                }
                "/api/vault/sync", "/api/timeline/sync" -> {
                    val sRes = kotlinx.coroutines.runBlocking {
                        telemetryVaultManager.syncPendingBatchesInternal(manual = true)
                    }
                    sRes.keys().forEach { k -> result.put(k, sRes.get(k)) }
                }
                "/api/vault/export", "/api/timeline/export" -> {
                    val format = json.optString("format", "json")
                    val category = json.optString("category", "")
                    val sinceHours = json.optDouble("sinceHours", json.optDouble("hours", 0.0))
                    val sinceDays = json.optDouble("days", 0.0)
                    val explicitSince = json.optLong("sinceMs", 0L)
                    val now = System.currentTimeMillis()
                    val sinceMs = when {
                        explicitSince > 0L -> explicitSince
                        sinceHours > 0.0 -> now - (sinceHours * 3600_000.0).toLong()
                        sinceDays > 0.0 -> now - (sinceDays * 86_400_000.0).toLong()
                        else -> 0L
                    }
                    val limit = json.optInt("limit", 1500)
                    val eRes = telemetryVaultManager.exportVaultJson(format, category, sinceMs, Long.MAX_VALUE, limit)
                    eRes.keys().forEach { k -> result.put(k, eRes.get(k)) }
                }
                "/api/vault/prune", "/api/timeline/prune" -> {
                    val clearSynced = json.optBoolean("clearSynced", false)
                    val removed = kotlinx.coroutines.runBlocking {
                        if (clearSynced) telemetryVaultManager.clearAllSyncedHistory()
                        else telemetryVaultManager.pruneExpiredSyncedInternal()
                    }
                    result.put("success", true)
                    result.put("prunedCount", removed)
                    result.put("clearSynced", clearSynced)
                    result.put("retentionDaysAfterSync", com.kavach.telemetry.OfflineTelemetryVaultManager.RETENTION_AFTER_SYNC_DAYS)
                }
                else -> {
                    result.put("success", false)
                    result.put("error", "Unknown API endpoint: $endpoint")
                }
            }
        } catch (e: Exception) {
            result.put("success", false)
            result.put("error", e.message ?: "Exception in API handler")
        }
        if (endpoint != "/api/auth/poll" && endpoint != "/api/pair/poll" && endpoint != "/api/security/pair/poll") {
            webSocketRepository.addLog("HTTP $endpoint -> ${if (result.optBoolean("success", false)) "200 OK" else "ERR: ${result.optString("error", "failed")}"}")
        }
        return result
    }

    fun trimMemory(aggressive: Boolean) {
        try {
            com.kavach.hardware.AppGuardManager.activeInstance?.trimCaches(aggressive)
        } catch (_: Throwable) {}
        try {
            com.kavach.network.PerAppNetworkMonitor.activeInstance?.trimCaches(aggressive)
        } catch (_: Throwable) {}
        try {
            com.kavach.telemetry.OfflineTelemetryVaultManager.activeInstance?.trimCaches(aggressive)
        } catch (_: Throwable) {}
        try {
            com.kavach.network.NetworkModerationManager.activeInstance?.trimCaches(aggressive)
        } catch (_: Throwable) {}
        try {
            com.kavach.security.AdultContentShieldManager.activeInstance?.trimCaches(aggressive)
        } catch (_: Throwable) {}
        try {
            if (aggressive) {
                okHttpClient.connectionPool.evictAll()
            }
        } catch (_: Throwable) {}
    }
}
