package com.kavach.ui.overlay

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.core.content.ContextCompat
import java.util.Locale

/**
 * Lightweight main-thread Android on-device SpeechRecognizer controller shared by
 * the Floating Input Bar (Window 1), HUD Simulator, and Dashboard Macro Creator.
 */
class AgyVoiceInputController(
    private val context: Context,
    private val onListeningChanged: (Boolean) -> Unit,
    private val onPartialText: (String) -> Unit,
    private val onFinalText: (String) -> Unit,
    private val onErrorMessage: (String) -> Unit
) {
    private val mainHandler = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    @Volatile
    var isListening: Boolean = false
        private set

    fun hasAudioPermission(): Boolean {
        return ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED
    }

    fun isAvailable(): Boolean = SpeechRecognizer.isRecognitionAvailable(context)

    fun toggleListening() {
        if (isListening) {
            stopListening()
        } else {
            startListening()
        }
    }

    fun startListening(): Boolean {
        if (!hasAudioPermission()) {
            onErrorMessage("Grant Microphone permission to use voice input")
            return false
        }
        if (!isAvailable()) {
            onErrorMessage("On-device speech recognition is unavailable")
            return false
        }
        runOnMain {
            try {
                destroyInternal()
                val sr = SpeechRecognizer.createSpeechRecognizer(context.applicationContext)
                recognizer = sr
                sr.setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) {
                        setListeningState(true)
                    }

                    override fun onBeginningOfSpeech() {}
                    override fun onRmsChanged(rmsdB: Float) {}
                    override fun onBufferReceived(buffer: ByteArray?) {}

                    override fun onEndOfSpeech() {
                        setListeningState(false)
                    }

                    override fun onError(error: Int) {
                        setListeningState(false)
                        val msg = when (error) {
                            SpeechRecognizer.ERROR_AUDIO -> "Microphone audio error"
                            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission required"
                            SpeechRecognizer.ERROR_NETWORK,
                            SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Speech service network timeout"
                            SpeechRecognizer.ERROR_NO_MATCH -> "No speech detected"
                            SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Listening timed out"
                            else -> "Voice input stopped"
                        }
                        if (error != SpeechRecognizer.ERROR_CLIENT) {
                            onErrorMessage(msg)
                        }
                        destroyInternal()
                    }

                    override fun onResults(results: Bundle?) {
                        setListeningState(false)
                        val best = results
                            ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                            ?.firstOrNull()
                            ?.trim()
                            .orEmpty()
                        if (best.isNotEmpty()) {
                            onFinalText(best)
                        }
                        destroyInternal()
                    }

                    override fun onPartialResults(partialResults: Bundle?) {
                        val partial = partialResults
                            ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                            ?.firstOrNull()
                            ?.trim()
                            .orEmpty()
                        if (partial.isNotEmpty()) {
                            onPartialText(partial)
                        }
                    }

                    override fun onEvent(eventType: Int, params: Bundle?) {}
                })

                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(
                        RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                        RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
                    )
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
                    putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                    putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
                }
                setListeningState(true)
                sr.startListening(intent)
            } catch (e: Exception) {
                setListeningState(false)
                onErrorMessage(e.message ?: "Unable to start voice recognition")
                destroyInternal()
            }
        }
        return true
    }

    fun stopListening() {
        runOnMain {
            try {
                recognizer?.stopListening()
            } catch (_: Exception) {}
            setListeningState(false)
            destroyInternal()
        }
    }

    fun release() {
        runOnMain {
            setListeningState(false)
            destroyInternal()
        }
    }

    private fun destroyInternal() {
        try {
            recognizer?.cancel()
            recognizer?.destroy()
        } catch (_: Exception) {}
        recognizer = null
    }

    private fun setListeningState(active: Boolean) {
        if (isListening == active) return
        isListening = active
        onListeningChanged(active)
    }

    private fun runOnMain(block: () -> Unit) {
        if (Looper.myLooper() == Looper.getMainLooper()) {
            block()
        } else {
            mainHandler.post(block)
        }
    }
}
