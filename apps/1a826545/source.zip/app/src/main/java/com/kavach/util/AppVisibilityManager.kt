package com.kavach.util

import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import org.json.JSONObject

/**
 * Controls whether the app's launcher entry (LauncherAlias) is shown in the device's
 * launcher / apps list while keeping MainActivity and background services operational.
 *
 * Note on Android 10+ (API 29+):
 * AOSP LauncherAppsService injects a synthetic App Info icon when all launcher entries are
 * disabled unless `show_hidden_icon_apps_enabled=0` (via root/ADB WRITE_SECURE_SETTINGS)
 * or the app is Device/Profile Owner.
 */
class AppVisibilityManager(private val context: Context) {

    private val tag = "AppVisibilityManager"
    private val prefs = context.getSharedPreferences("aero_visibility_prefs", Context.MODE_PRIVATE)
    private val launcherComponent = ComponentName(context, "com.kavach.LauncherAlias")
    private val ioScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    companion object {
        private const val GLOBAL_SHOW_HIDDEN_ICONS = "show_hidden_icon_apps_enabled"
        const val ADB_HIDE_SYNTHETIC_CMD = "adb shell settings put global show_hidden_icon_apps_enabled 0"
    }

    private val _isAppHidden = MutableStateFlow(queryIsHidden())
    val isAppHidden: StateFlow<Boolean> = _isAppHidden.asStateFlow()

    private val _isSyntheticIconForced = MutableStateFlow(computeSyntheticIconForced(_isAppHidden.value))
    val isSyntheticIconForced: StateFlow<Boolean> = _isSyntheticIconForced.asStateFlow()

    private fun queryIsHidden(): Boolean {
        return try {
            val state = context.packageManager.getComponentEnabledSetting(launcherComponent)
            state == PackageManager.COMPONENT_ENABLED_STATE_DISABLED ||
                state == PackageManager.COMPONENT_ENABLED_STATE_DISABLED_USER
        } catch (e: Exception) {
            Log.w(tag, "Unable to query launcher entry state: ${e.message}")
            prefs.getBoolean("is_app_hidden", false)
        }
    }

    fun queryLauncherEntriesCount(): Int {
        return try {
            val intent = android.content.Intent(android.content.Intent.ACTION_MAIN).apply {
                addCategory(android.content.Intent.CATEGORY_LAUNCHER)
                setPackage(context.packageName)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                context.packageManager.queryIntentActivities(
                    intent,
                    PackageManager.ResolveInfoFlags.of(0L)
                ).size
            } else {
                @Suppress("DEPRECATION")
                context.packageManager.queryIntentActivities(intent, 0).size
            }
        } catch (_: Throwable) {
            if (queryIsHidden()) 0 else 1
        }
    }

    private fun computeSyntheticIconForced(hidden: Boolean): Boolean {
        if (!hidden || Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return false
        if (isDeviceOrProfileOwner()) return false
        return try {
            Settings.Global.getInt(context.contentResolver, GLOBAL_SHOW_HIDDEN_ICONS, 1) != 0
        } catch (_: Throwable) {
            true
        }
    }

    private fun isWriteSecureSettingsGranted(): Boolean {
        return try {
            context.checkSelfPermission(android.Manifest.permission.WRITE_SECURE_SETTINGS) ==
                PackageManager.PERMISSION_GRANTED
        } catch (_: Throwable) {
            false
        }
    }

    private fun isDeviceOrProfileOwner(): Boolean {
        return try {
            val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as? DevicePolicyManager
            dpm?.isDeviceOwnerApp(context.packageName) == true ||
                dpm?.isProfileOwnerApp(context.packageName) == true
        } catch (_: Throwable) {
            false
        }
    }

    fun syncPersistedState(allowBridgeStart: Boolean = false) {
        val savedHidden = prefs.getBoolean("is_app_hidden", false)
        val currentHidden = queryIsHidden()
        if (savedHidden != currentHidden) {
            setAppHidden(savedHidden, ensureBridgeService = allowBridgeStart)
        } else {
            if (savedHidden) {
                trySuppressSyntheticIconIfPrivileged(allowBlockingSu = false)
            }
            refreshState()
        }
    }

    fun refreshState(): Boolean {
        val hidden = queryIsHidden()
        _isAppHidden.value = hidden
        _isSyntheticIconForced.value = computeSyntheticIconForced(hidden)
        return hidden
    }

    fun setAppHidden(hidden: Boolean, ensureBridgeService: Boolean = true): Boolean {
        return try {
            if (ensureBridgeService) {
                // 1. Ensure foreground bridge service is active so OS keeps the process high-priority
                com.kavach.services.RealtimeConnectionService.ensureBridge(context)

                // 2. Schedule a short watchdog check in case an aggressive OEM ROM restarts the process
                scheduleWatchdogAlarm()
            }

            val newState = if (hidden) {
                PackageManager.COMPONENT_ENABLED_STATE_DISABLED
            } else {
                PackageManager.COMPONENT_ENABLED_STATE_ENABLED
            }

            // Apply component state synchronously using DONT_KILL_APP so PackageManager
            // commits immediately and getStatusJson() reflects the real verified state.
            context.packageManager.setComponentEnabledSetting(
                launcherComponent,
                newState,
                PackageManager.DONT_KILL_APP
            )

            prefs.edit().putBoolean("is_app_hidden", hidden).apply()

            if (hidden) {
                val isMainThread = android.os.Looper.myLooper() == android.os.Looper.getMainLooper()
                trySuppressSyntheticIconIfPrivileged(allowBlockingSu = !isMainThread)
            }

            val actualHidden = refreshState()
            Log.i(
                tag,
                "App launcher visibility applied: requestedHidden=$hidden, actualHidden=$actualHidden, launcherEntries=${queryLauncherEntriesCount()}, syntheticFallback=${_isSyntheticIconForced.value}"
            )
            actualHidden == hidden
        } catch (e: Exception) {
            Log.e(tag, "Failed to update app visibility: ${e.message}", e)
            refreshState()
            false
        }
    }

    private fun trySuppressSyntheticIconIfPrivileged(allowBlockingSu: Boolean) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return
        // 1. Direct WRITE_SECURE_SETTINGS update (succeeds if granted via ADB/system)
        try {
            if (isWriteSecureSettingsGranted()) {
                Settings.Global.putInt(context.contentResolver, GLOBAL_SHOW_HIDDEN_ICONS, 0)
                _isSyntheticIconForced.value = computeSyntheticIconForced(_isAppHidden.value)
                return
            }
        } catch (_: Throwable) {}

        // 2. Attempt root shell suppression if device is rooted
        val runSu = {
            try {
                val proc = Runtime.getRuntime().exec(arrayOf("su", "-c", "settings put global $GLOBAL_SHOW_HIDDEN_ICONS 0"))
                val finished = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    proc.waitFor(450L, java.util.concurrent.TimeUnit.MILLISECONDS)
                } else {
                    proc.waitFor() == 0
                }
                if (finished && proc.exitValue() == 0) {
                    _isSyntheticIconForced.value = computeSyntheticIconForced(_isAppHidden.value)
                    Log.i(tag, "Suppressed Android 10+ synthetic icon via root")
                } else {
                    proc.destroy()
                }
            } catch (_: Throwable) {
                // Non-rooted device: expected
            }
        }

        if (allowBlockingSu) {
            runSu()
        } else {
            ioScope.launch { runSu() }
        }
    }

    private fun scheduleWatchdogAlarm() {
        try {
            val am = context.getSystemService(Context.ALARM_SERVICE) as? android.app.AlarmManager ?: return
            val intent = android.content.Intent(context, com.kavach.services.BridgeWatchdogReceiver::class.java)
            val pi = android.app.PendingIntent.getBroadcast(
                context,
                7741,
                intent,
                android.app.PendingIntent.FLAG_IMMUTABLE or android.app.PendingIntent.FLAG_UPDATE_CURRENT
            )
            val triggerAt = android.os.SystemClock.elapsedRealtime() + 1500L
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                if (am.canScheduleExactAlarms()) {
                    am.setExactAndAllowWhileIdle(android.app.AlarmManager.ELAPSED_REALTIME_WAKEUP, triggerAt, pi)
                } else {
                    am.setAndAllowWhileIdle(android.app.AlarmManager.ELAPSED_REALTIME_WAKEUP, triggerAt, pi)
                }
            } else {
                am.setExactAndAllowWhileIdle(android.app.AlarmManager.ELAPSED_REALTIME_WAKEUP, triggerAt, pi)
            }
        } catch (e: Throwable) {
            Log.w(tag, "Could not schedule watchdog alarm: ${e.message}")
        }
    }

    fun getStatusJson(): JSONObject {
        val hidden = refreshState()
        val syntheticFallback = _isSyntheticIconForced.value
        val launcherEntries = queryLauncherEntriesCount()
        val adbGrantCmd = "adb shell pm grant ${context.packageName} android.permission.WRITE_SECURE_SETTINGS"
        return JSONObject().apply {
            put("success", true)
            put("hidden", hidden)
            put("fullyHidden", hidden && !syntheticFallback)
            put("visible", !hidden)
            put("packageName", context.packageName)
            put("launcherComponent", launcherComponent.flattenToShortString())
            put("launcherEntriesCount", launcherEntries)
            put("mainActivityEnabled", true)
            put("osSyntheticIconFallback", syntheticFallback)
            put("writeSecureSettingsGranted", isWriteSecureSettingsGranted())
            put("adbHideCommand", ADB_HIDE_SYNTHETIC_CMD)
            put("adbGrantCommand", adbGrantCmd)
            put(
                "osNote",
                if (hidden && syntheticFallback) {
                    "Android 10+ disables the launcher shortcut but forces a synthetic App Info icon in the app drawer unless WRITE_SECURE_SETTINGS or ADB/root sets show_hidden_icon_apps_enabled=0."
                } else {
                    ""
                }
            )
            put("reopenHint", "Tap the persistent AeroShare notification or run: python send_cmd.py show-app")
        }
    }
}
