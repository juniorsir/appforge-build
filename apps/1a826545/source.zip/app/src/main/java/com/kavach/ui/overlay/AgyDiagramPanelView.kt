package com.kavach.ui.overlay

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PointF
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.text.TextUtils
import android.util.AttributeSet
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.LinearInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Interactive Visual Diagram Canvas (`agy_hud_diagram_panel`) rendered inside Window 3 (`agy_task_map`)
 * when `taskMap.mode == "diagram"`.
 *
 * Supports:
 * 1. Interactive Flowcharts & Architecture Node Graphs (`flowchart` / `architecture`)
 * 2. Sequence & Step-by-Step Timeline Diagrams (`sequence` / `timeline`)
 * 3. Visual Charts, Sparklines & Radial Gauges (`chart` -> `bar` | `line` | `radial`)
 *
 * Features Apple dark-glass inline SVG controls (`AgyAppleVectorIconView`) for live diagram mode
 * switching, zoom/reset, tap-to-inspect node selection, and full-screen lightbox expansion.
 */
class AgyDiagramPanelView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : FrameLayout(context, attrs, defStyleAttr) {

    var onRequestExpandSnapshot: ((Bitmap, String, String) -> Unit)? = null
    var onModeSwitched: ((String) -> Unit)? = null

    private val density: Float get() = context.resources.displayMetrics.density.coerceAtLeast(1f)

    private var currentConfig: AgyHudDynamicModels.TaskMapConfig = AgyHudDynamicModels.TaskMapConfig()
    private var currentTheme: AgyHudDynamicModels.ResolvedHudTheme =
        AgyHudDynamicModels.resolveTheme(AgyHudDynamicModels.HudThemeConfig(mode = "dark"), Color.parseColor("#6366F1"))
    private var activeData: AgyHudDynamicModels.DiagramTaskMapData = AgyHudDynamicModels.DiagramTaskMapData()
    private var viewModeOverride: String? = null
    private var subChartOverride: String? = null
    private var zoomScale: Float = 1.0f
    private var panX: Float = 0f
    private var panY: Float = 0f
    private var selectedNodeId: String = ""
    private var lastContentSig: String = ""

    private val surfaceView: DiagramCanvasSurface
    private val selectedChipView: TextView
    private val bottomGlassDock: LinearLayout
    private val flowModeBtn: AgyAppleVectorIconView
    private val seqModeBtn: AgyAppleVectorIconView
    private val chartModeBtn: AgyAppleVectorIconView
    private val zoomOutBtn: AgyAppleVectorIconView
    private val fitResetBtn: AgyAppleVectorIconView
    private val zoomInBtn: AgyAppleVectorIconView
    private val expandBtn: AgyAppleVectorIconView
    private val lastSafeBounds = RectF()
    private val lastNodeBounds = linkedMapOf<String, RectF>()

    init {
        val d = density
        tag = "${AgyHudOverlayManager.HUD_NODE_TAG_PREFIX}diagram_panel"
        contentDescription = "${AgyHudOverlayManager.HUD_NODE_TAG_PREFIX}diagram_panel"
        layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            (236 * d).toInt()
        )
        clipChildren = true
        clipToPadding = true

        surfaceView = DiagramCanvasSurface(context).apply {
            layoutParams = LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            tag = "${AgyHudOverlayManager.HUD_NODE_TAG_PREFIX}diagram_canvas"
            contentDescription = "${AgyHudOverlayManager.HUD_NODE_TAG_PREFIX}diagram_canvas"
        }
        addView(surfaceView)

        // Top-left compact floating glass pill showing tapped node / active step title
        selectedChipView = TextView(context).apply {
            textSize = 9.5f
            setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            setTextColor(Color.WHITE)
            setPadding((8 * d).toInt(), (4 * d).toInt(), (8 * d).toInt(), (4 * d).toInt())
            layoutParams = LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP or Gravity.START
            ).apply {
                leftMargin = (7 * d).toInt()
                topMargin = (7 * d).toInt()
                rightMargin = (7 * d).toInt()
            }
            visibility = View.GONE
            setOnClickListener {
                selectedNodeId = ""
                refreshOverlayControls()
                surfaceView.invalidate()
            }
        }
        addView(selectedChipView)

        // Bottom centered translucent Apple glass inline control dock
        bottomGlassDock = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding((5 * d).toInt(), (4 * d).toInt(), (5 * d).toInt(), (4 * d).toInt())
            layoutParams = LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            ).apply {
                bottomMargin = (7 * d).toInt()
            }
        }

        fun dockBtn(
            icon: AgyAppleVectorIconView.IconType,
            desc: String,
            onClick: () -> Unit
        ): AgyAppleVectorIconView {
            return AgyAppleVectorIconView(context, icon).apply {
                iconSizeDp = 12.5f
                minTouchSizeDp = 26f
                glassStyle = AgyAppleVectorIconView.GlassStyle.GLASS_CIRCLE
                layoutParams = LinearLayout.LayoutParams((26 * d).toInt(), (26 * d).toInt()).apply {
                    marginStart = (2 * d).toInt()
                    marginEnd = (2 * d).toInt()
                }
                tag = "${AgyHudOverlayManager.HUD_NODE_TAG_PREFIX}$desc"
                contentDescription = "${AgyHudOverlayManager.HUD_NODE_TAG_PREFIX}$desc"
                setOnClickListener { onClick() }
            }
        }

        flowModeBtn = dockBtn(AgyAppleVectorIconView.IconType.DIAGRAM_FLOW, "diagram_mode_flow") {
            switchVisualMode("flowchart")
        }
        seqModeBtn = dockBtn(AgyAppleVectorIconView.IconType.DIAGRAM_SEQUENCE, "diagram_mode_sequence") {
            switchVisualMode("sequence")
        }
        chartModeBtn = dockBtn(AgyAppleVectorIconView.IconType.CHART_BAR, "diagram_mode_chart") {
            if (resolvedVisualMode() == "chart") {
                val curSub = subChartOverride ?: activeData.subChartType
                subChartOverride = when (curSub) {
                    "bar" -> "line"
                    "line" -> "radial"
                    else -> "bar"
                }
                refreshOverlayControls()
                surfaceView.invalidate()
            } else {
                switchVisualMode("chart")
            }
        }
        zoomOutBtn = dockBtn(AgyAppleVectorIconView.IconType.ZOOM_OUT, "diagram_zoom_out") {
            adjustZoom(-0.22f)
        }
        fitResetBtn = dockBtn(AgyAppleVectorIconView.IconType.FIT_RESET, "diagram_fit_reset") {
            resetViewport()
        }
        zoomInBtn = dockBtn(AgyAppleVectorIconView.IconType.ZOOM_IN, "diagram_zoom_in") {
            adjustZoom(0.22f)
        }
        expandBtn = dockBtn(AgyAppleVectorIconView.IconType.ARROW_EXPAND, "diagram_expand") {
            val w = width.coerceAtLeast((240 * d).toInt()) * 2
            val h = height.coerceAtLeast((220 * d).toInt()) * 2
            val bmp = renderSnapshotBitmap(w.coerceIn(720, 1280), h.coerceIn(580, 1080))
            val title = activeData.title.ifBlank { currentConfig.title.ifBlank { "Diagram" } }
            val sub = "${resolvedVisualMode().replaceFirstChar { it.uppercase() }} • ${activeData.nodes.size.coerceAtLeast(activeData.series.size)} items"
            onRequestExpandSnapshot?.invoke(bmp, title, sub)
        }

        bottomGlassDock.addView(flowModeBtn)
        bottomGlassDock.addView(seqModeBtn)
        bottomGlassDock.addView(chartModeBtn)
        bottomGlassDock.addView(zoomOutBtn)
        bottomGlassDock.addView(fitResetBtn)
        bottomGlassDock.addView(zoomInBtn)
        bottomGlassDock.addView(expandBtn)
        addView(bottomGlassDock)
    }

    fun getCurrentDiagramType(): String = resolvedVisualMode()
    fun getZoomScale(): Float = zoomScale
    fun getPanOffset(): Pair<Float, Float> = panX to panY
    fun getSelectedNodeId(): String = selectedNodeId
    fun getRenderedData(): AgyHudDynamicModels.DiagramTaskMapData = activeData
    fun getLastSafeContentBounds(): RectF = RectF(lastSafeBounds)
    fun getLastRenderedNodeBounds(): Map<String, RectF> = lastNodeBounds.mapValues { RectF(it.value) }
    fun getBottomDockReservedTopY(): Float {
        val dockH = bottomGlassDock.height.takeIf { it > 0 }?.toFloat() ?: (34f * density)
        val margin = 7f * density
        return (height.toFloat() - dockH - margin).coerceAtLeast(0f)
    }

    fun switchVisualMode(mode: String) {
        viewModeOverride = mode
        panX = 0f
        panY = 0f
        refreshOverlayControls()
        surfaceView.invalidate()
        onModeSwitched?.invoke(mode)
    }

    fun adjustZoom(delta: Float) {
        zoomScale = (zoomScale + delta).coerceIn(0.75f, 2.0f)
        if (abs(zoomScale - 1.0f) < 0.08f) {
            zoomScale = 1.0f
            panX = 0f
            panY = 0f
        }
        refreshOverlayControls()
        surfaceView.invalidate()
    }

    fun resetViewport() {
        zoomScale = 1.0f
        panX = 0f
        panY = 0f
        selectedNodeId = ""
        refreshOverlayControls()
        surfaceView.invalidate()
    }

    fun selectNode(nodeId: String) {
        selectedNodeId = if (selectedNodeId == nodeId) "" else nodeId
        refreshOverlayControls()
        surfaceView.invalidate()
    }

    fun renderSnapshotBitmap(widthPx: Int = 920, heightPx: Int = 720): Bitmap {
        val bmp = Bitmap.createBitmap(widthPx.coerceAtLeast(320), heightPx.coerceAtLeast(280), Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        surfaceView.drawDiagramOnCanvas(canvas, bmp.width.toFloat(), bmp.height.toFloat(), snapshotScaleBoost = 1.65f)
        return bmp
    }

    fun updateDiagram(
        config: AgyHudDynamicModels.TaskMapConfig,
        theme: AgyHudDynamicModels.ResolvedHudTheme
    ) {
        currentConfig = config
        currentTheme = theme
        val d = density
        val data = config.diagram ?: AgyHudDynamicModels.DiagramTaskMapData()
        val sig = data.contentSignature()
        if (sig != lastContentSig) {
            lastContentSig = sig
            activeData = data
            viewModeOverride = null
            subChartOverride = null
            zoomScale = 1.0f
            panX = 0f
            panY = 0f
            selectedNodeId = data.activeNodeId
        }

        val targetHeightDp = when (resolvedVisualMode()) {
            "sequence" -> (190f + (activeData.edges.size * 18f)).coerceIn(210f, 276f)
            "chart" -> 212f
            else -> if (activeData.nodes.size >= 6) 256f else 224f
        }
        val desiredH = (targetHeightDp * d).toInt()
        AgyVisualWindowRouter.updateLayoutParamsSafe(this, ViewGroup.LayoutParams.MATCH_PARENT, desiredH)

        background = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = 14f * d
            setColor(if (theme.isDark) Color.parseColor("#FF060B19") else Color.parseColor("#FFF8FAFC"))
            setStroke((1f * d).toInt().coerceAtLeast(1), theme.border)
        }

        refreshOverlayControls()
        surfaceView.updatePulseState()
        surfaceView.invalidate()
    }

    private fun resolvedVisualMode(): String {
        val mode = (viewModeOverride ?: activeData.diagramType).lowercase().trim()
        // If chart is requested without explicit numeric series, fall back gracefully if nodes can derive numeric counts
        return when (mode) {
            "architecture", "flowchart" -> "flowchart"
            "sequence", "timeline" -> if (mode == "sequence" || activeData.edges.any { it.label.isNotBlank() }) mode else "timeline"
            "chart" -> "chart"
            else -> if (activeData.series.isNotEmpty() && activeData.nodes.isEmpty()) "chart" else "flowchart"
        }
    }

    private fun effectiveSeriesForChart(): List<AgyHudDynamicModels.DiagramSeriesPoint> {
        if (activeData.series.isNotEmpty()) return activeData.series
        if (activeData.nodes.isEmpty()) return emptyList()
        return activeData.nodes.mapIndexed { idx, node ->
            val v = node.value ?: when (node.status) {
                "done" -> 100f
                "doing" -> 62f
                "highlight" -> 80f
                "error" -> 30f
                else -> (35f + (idx * 11f) % 45f)
            }
            AgyHudDynamicModels.DiagramSeriesPoint(
                label = node.label.take(12),
                value = v,
                maxValue = 100f,
                status = node.status
            )
        }
    }

    private fun refreshOverlayControls() {
        val d = density
        val theme = currentTheme
        val mode = resolvedVisualMode()

        bottomGlassDock.background = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = 999f * d
            setColor(if (theme.isDark) Color.parseColor("#C20F172A") else Color.parseColor("#D9FFFFFF"))
            setStroke((0.9f * d).toInt().coerceAtLeast(1), if (theme.isDark) Color.parseColor("#38FFFFFF") else theme.border)
        }

        fun styleDockBtn(btn: AgyAppleVectorIconView, active: Boolean) {
            btn.accentColor = theme.accent
            if (active) {
                btn.glassStyle = AgyAppleVectorIconView.GlassStyle.ACCENT_CIRCLE
                btn.iconTint = Color.WHITE
            } else {
                btn.glassStyle = AgyAppleVectorIconView.GlassStyle.GLASS_CIRCLE
                btn.glassFillColor = if (theme.isDark) Color.parseColor("#551E293B") else Color.parseColor("#FFE2E8F0")
                btn.glassBorderColor = if (theme.isDark) Color.parseColor("#30FFFFFF") else theme.border
                btn.iconTint = if (theme.isDark) Color.parseColor("#FFE2E8F0") else theme.textPrimary
            }
        }

        styleDockBtn(flowModeBtn, mode == "flowchart")
        styleDockBtn(seqModeBtn, mode == "sequence" || mode == "timeline")
        styleDockBtn(chartModeBtn, mode == "chart")
        styleDockBtn(zoomOutBtn, false)
        styleDockBtn(fitResetBtn, abs(zoomScale - 1.0f) > 0.05f || abs(panX) > 2f || abs(panY) > 2f)
        styleDockBtn(zoomInBtn, false)
        styleDockBtn(expandBtn, false)

        val selectedNode = activeData.nodes.firstOrNull { it.id == selectedNodeId }
        if (selectedNode != null) {
            selectedChipView.visibility = View.VISIBLE
            selectedChipView.text = "${selectedNode.label} • ${selectedNode.status.uppercase()}"
            selectedChipView.setTextColor(if (theme.isDark) Color.WHITE else theme.textPrimary)
            selectedChipView.background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = 999f * d
                setColor(if (theme.isDark) Color.parseColor("#CC0F172A") else Color.parseColor("#E6FFFFFF"))
                setStroke((0.9f * d).toInt().coerceAtLeast(1), statusColorFor(selectedNode.status))
            }
        } else {
            selectedChipView.visibility = View.GONE
        }
    }

    private fun statusColorFor(status: String): Int = when (status.lowercase()) {
        "done" -> Color.parseColor("#10B981")
        "doing" -> currentTheme.accent
        "error" -> Color.parseColor("#F43F5E")
        "highlight" -> Color.parseColor("#F59E0B")
        else -> if (currentTheme.isDark) Color.parseColor("#64748B") else Color.parseColor("#94A3B8")
    }

    override fun onDetachedFromWindow() {
        surfaceView.stopPulse()
        super.onDetachedFromWindow()
    }

    private inner class DiagramCanvasSurface(context: Context) : View(context) {
        private val d = density
        private val hitTargets = mutableListOf<Pair<RectF, String>>()

        private var pulsePhase: Float = 0f
        private var pulseAnimator: ValueAnimator? = null

        private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
        }
        private val edgePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
        }
        private val edgeDashEffect = DashPathEffect(floatArrayOf(5f * d, 4f * d), 0f)
        private val nodeFillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
        }
        private val nodeStrokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
        }
        private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
        }
        private val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
        }
        private val subLabelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            typeface = Typeface.MONOSPACE
            textAlign = Paint.Align.CENTER
        }
        private val edgePath = Path()
        private val arrowPath = Path()
        private val tmpRect = RectF()

        private var downX = 0f
        private var downY = 0f
        private var startPanX = 0f
        private var startPanY = 0f
        private var dragging = false

        fun updatePulseState() {
            val animatorsOk = Build.VERSION.SDK_INT < Build.VERSION_CODES.O || ValueAnimator.areAnimatorsEnabled()
            val needsPulse = animatorsOk && (
                activeData.nodes.any { it.status == "doing" } ||
                    activeData.edges.any { it.active }
                )
            if (needsPulse && pulseAnimator == null) {
                pulseAnimator = ValueAnimator.ofFloat(0f, 1f).apply {
                    duration = 2000L
                    repeatCount = ValueAnimator.INFINITE
                    interpolator = LinearInterpolator()
                    addUpdateListener {
                        pulsePhase = it.animatedValue as Float
                        invalidate()
                    }
                    start()
                }
            } else if (!needsPulse) {
                stopPulse()
            }
        }

        fun stopPulse() {
            pulseAnimator?.cancel()
            pulseAnimator = null
        }

        override fun onTouchEvent(event: MotionEvent?): Boolean {
            val ev = event ?: return false
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = ev.x
                    downY = ev.y
                    startPanX = panX
                    startPanY = panY
                    dragging = false
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = ev.x - downX
                    val dy = ev.y - downY
                    if (!dragging && hypot(dx.toDouble(), dy.toDouble()) > 8.0 * d) {
                        dragging = true
                    }
                    if (dragging && zoomScale > 1.02f) {
                        val maxPan = (width.coerceAtLeast(1) * (zoomScale - 1f) * 0.65f)
                        panX = (startPanX + dx).coerceIn(-maxPan, maxPan)
                        panY = (startPanY + dy).coerceIn(-maxPan, maxPan)
                        invalidate()
                        return true
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (!dragging) {
                        val hit = hitTargets.lastOrNull { it.first.contains(ev.x, ev.y) }
                        if (hit != null) {
                            selectNode(hit.second)
                        } else if (selectedNodeId.isNotEmpty()) {
                            selectedNodeId = ""
                            refreshOverlayControls()
                            invalidate()
                        }
                    }
                    dragging = false
                    return true
                }
                MotionEvent.ACTION_CANCEL -> {
                    dragging = false
                }
            }
            return super.onTouchEvent(ev)
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val w = width.toFloat()
            val h = height.toFloat()
            if (w <= 4f || h <= 4f) return
            drawDiagramOnCanvas(canvas, w, h, snapshotScaleBoost = 1.0f)
        }

        fun drawDiagramOnCanvas(
            canvas: Canvas,
            w: Float,
            h: Float,
            snapshotScaleBoost: Float
        ) {
            val theme = currentTheme
            val s = d * snapshotScaleBoost
            hitTargets.clear()
            if (snapshotScaleBoost == 1.0f) {
                lastNodeBounds.clear()
            }

            // Background dot-matrix grid
            val bgColor = if (theme.isDark) Color.parseColor("#FF060B19") else Color.parseColor("#FFF8FAFC")
            canvas.drawColor(bgColor)
            gridPaint.color = if (theme.isDark) Color.parseColor("#2494A3B8") else Color.parseColor("#22475569")
            val gridStep = 14f * s
            var gx = gridStep * 0.5f
            while (gx < w) {
                var gy = gridStep * 0.5f
                while (gy < h) {
                    canvas.drawCircle(gx, gy, 0.9f * s, gridPaint)
                    gy += gridStep
                }
                gx += gridStep
            }

            if (activeData.isEmpty()) {
                labelPaint.textSize = 11f * s
                labelPaint.color = theme.textSecondary
                canvas.drawText("No diagram nodes", w / 2f, h / 2f, labelPaint)
                return
            }

            canvas.save()
            if (snapshotScaleBoost == 1.0f) {
                canvas.translate(panX, panY)
                canvas.scale(zoomScale, zoomScale, w / 2f, h / 2f)
            }

            val topPad = (if (selectedNodeId.isNotEmpty() && snapshotScaleBoost == 1.0f) 32f else 12f) * s
            val measuredDockH = if (snapshotScaleBoost == 1.0f && bottomGlassDock.height > 0) {
                bottomGlassDock.height.toFloat() + 14f * d
            } else {
                (if (snapshotScaleBoost == 1.0f) 48f else 18f) * s
            }
            val bottomPad = max(measuredDockH, (if (snapshotScaleBoost == 1.0f) 46f else 18f) * s)
            val sidePad = 12f * s
            val contentRect = RectF(sidePad, topPad, (w - sidePad).coerceAtLeast(sidePad + 40f), (h - bottomPad).coerceAtLeast(topPad + 40f))
            if (snapshotScaleBoost == 1.0f) {
                lastSafeBounds.set(contentRect)
            }

            when (resolvedVisualMode()) {
                "sequence" -> drawSequenceDiagram(canvas, contentRect, s)
                "timeline" -> drawTimelineDiagram(canvas, contentRect, s)
                "chart" -> drawChartDiagram(canvas, contentRect, s)
                else -> drawFlowchartDiagram(canvas, contentRect, s)
            }

            canvas.restore()
        }

        private fun drawFlowchartDiagram(canvas: Canvas, bounds: RectF, s: Float) {
            val nodes = activeData.nodes.ifEmpty {
                effectiveSeriesForChart().mapIndexed { idx, pt ->
                    AgyHudDynamicModels.DiagramNode("pt_$idx", pt.label, status = pt.status.ifBlank { "done" }, value = pt.value)
                }
            }
            if (nodes.isEmpty()) return

            // Topological layer assignment (respect explicit layer if present)
            val layerMap = mutableMapOf<String, Int>()
            nodes.forEachIndexed { idx, n ->
                if (n.layer >= 0) layerMap[n.id] = n.layer
                else if (idx == 0) layerMap[n.id] = 0
            }
            val inDegree = mutableMapOf<String, Int>()
            nodes.forEach { inDegree[it.id] = 0 }
            activeData.edges.forEach { e -> inDegree[e.toId] = (inDegree[e.toId] ?: 0) + 1 }
            nodes.forEach { if ((inDegree[it.id] ?: 0) == 0 && it.id !in layerMap) layerMap[it.id] = 0 }

            repeat(nodes.size + 1) {
                var changed = false
                for (edge in activeData.edges) {
                    val fl = layerMap[edge.fromId] ?: 0
                    val tl = layerMap[edge.toId] ?: 0
                    if (tl <= fl) {
                        layerMap[edge.toId] = (fl + 1).coerceAtMost(7)
                        changed = true
                    }
                }
                if (!changed) return@repeat
            }
            nodes.forEachIndexed { idx, n ->
                if (n.id !in layerMap) layerMap[n.id] = min(idx, 5)
            }

            val grouped = nodes.groupBy { layerMap[it.id] ?: 0 }.toSortedMap()
            val layerCount = grouped.size.coerceAtLeast(1)
            val layerKeys = grouped.keys.toList()

            val nodeRects = mutableMapOf<String, RectF>()
            val rowH = bounds.height() / layerCount.toFloat()
            val nodeHeight = min(30f * s, (rowH * 0.62f)).coerceAtLeast(20f * s)

            layerKeys.forEachIndexed { rowIdx, layerKey ->
                val rowNodes = grouped[layerKey].orEmpty()
                val cols = rowNodes.size.coerceAtLeast(1)
                val colW = bounds.width() / cols.toFloat()
                val nodeWidth = min(96f * s, (colW * 0.84f)).coerceAtLeast(46f * s)
                val cy = bounds.top + rowH * (rowIdx + 0.5f)
                rowNodes.forEachIndexed { colIdx, node ->
                    val cx = bounds.left + colW * (colIdx + 0.5f)
                    val rect = RectF(cx - nodeWidth / 2f, cy - nodeHeight / 2f, cx + nodeWidth / 2f, cy + nodeHeight / 2f)
                    nodeRects[node.id] = rect
                }
            }

            // Draw smooth cubic Bezier edges first
            val edgesToDraw = if (activeData.edges.isNotEmpty()) {
                activeData.edges
            } else {
                nodes.zipWithNext().map { (a, b) -> AgyHudDynamicModels.DiagramEdge(a.id, b.id, active = b.status == "doing") }
            }

            for (edge in edgesToDraw) {
                val r1 = nodeRects[edge.fromId] ?: continue
                val r2 = nodeRects[edge.toId] ?: continue
                val isConnectedToSelected = selectedNodeId.isNotEmpty() &&
                    (edge.fromId == selectedNodeId || edge.toId == selectedNodeId)
                val x1 = r1.centerX()
                val y1 = r1.bottom
                val x2 = r2.centerX()
                val y2 = r2.top

                val sameRow = abs(r1.centerY() - r2.centerY()) < 10f * s
                val sx: Float
                val sy: Float
                val ex: Float
                val ey: Float
                val c1x: Float
                val c1y: Float
                val c2x: Float
                val c2y: Float
                if (sameRow) {
                    val leftToRight = r2.centerX() >= r1.centerX()
                    sx = if (leftToRight) r1.right else r1.left
                    sy = r1.centerY()
                    ex = if (leftToRight) r2.left else r2.right
                    ey = r2.centerY()
                    c1x = (sx + ex) / 2f
                    c1y = sy
                    c2x = (sx + ex) / 2f
                    c2y = ey
                } else {
                    sx = x1
                    sy = y1
                    ex = x2
                    ey = y2
                    val midY = (sy + ey) / 2f
                    c1x = sx
                    c1y = midY
                    c2x = ex
                    c2y = midY
                }

                val edgeColor = when {
                    isConnectedToSelected || edge.active -> currentTheme.accent
                    currentTheme.isDark -> Color.parseColor("#FF475569")
                    else -> Color.parseColor("#FF94A3B8")
                }

                edgePath.reset()
                edgePath.moveTo(sx, sy)
                edgePath.cubicTo(c1x, c1y, c2x, c2y, ex, ey)
                edgePaint.color = edgeColor
                edgePaint.strokeWidth = (if (edge.active || isConnectedToSelected) 2.0f else 1.4f) * s
                edgePaint.pathEffect = if (edge.dashed) edgeDashEffect else null
                canvas.drawPath(edgePath, edgePaint)
                edgePaint.pathEffect = null

                // Arrowhead
                val angle = atan2((ey - c2y).toDouble(), (ex - c2x).toDouble())
                drawArrowHead(canvas, ex, ey, angle, edgeColor, s)

                // Traveling pulse bead along active edges
                if (edge.active || isConnectedToSelected) {
                    val pt = evalCubicBezier(sx, sy, c1x, c1y, c2x, c2y, ex, ey, pulsePhase)
                    glowPaint.color = Color.argb(90, Color.red(currentTheme.accent), Color.green(currentTheme.accent), Color.blue(currentTheme.accent))
                    canvas.drawCircle(pt.x, pt.y, 4.5f * s, glowPaint)
                    glowPaint.color = Color.WHITE
                    canvas.drawCircle(pt.x, pt.y, 2.0f * s, glowPaint)
                }

                // Compact edge label chip
                if (edge.label.isNotBlank()) {
                    val midPt = evalCubicBezier(sx, sy, c1x, c1y, c2x, c2y, ex, ey, 0.5f)
                    subLabelPaint.textSize = 7.5f * s
                    val tw = subLabelPaint.measureText(edge.label)
                    val chipRect = RectF(midPt.x - tw / 2f - 4f * s, midPt.y - 6f * s, midPt.x + tw / 2f + 4f * s, midPt.y + 6f * s)
                    nodeFillPaint.color = if (currentTheme.isDark) Color.parseColor("#E60F172A") else Color.parseColor("#F0FFFFFF")
                    canvas.drawRoundRect(chipRect, 999f * s, 999f * s, nodeFillPaint)
                    subLabelPaint.color = currentTheme.textSecondary
                    canvas.drawText(edge.label, midPt.x, midPt.y + 2.5f * s, subLabelPaint)
                }
            }

            // Draw nodes
            for (node in nodes) {
                val r = nodeRects[node.id] ?: continue
                hitTargets.add(RectF(r) to node.id)
                if (d == s) {
                    lastNodeBounds[node.id] = RectF(r)
                }
                val statusCol = statusColorFor(node.status)
                val isSelected = node.id == selectedNodeId
                val isDoing = node.status == "doing"

                if (isDoing || isSelected) {
                    val pulseAlpha = if (isSelected) 72 else (36 + (34 * sin(pulsePhase * 2f * PI)).toInt().coerceAtLeast(0))
                    glowPaint.color = Color.argb(pulseAlpha, Color.red(statusCol), Color.green(statusCol), Color.blue(statusCol))
                    tmpRect.set(r.left - 3.5f * s, r.top - 3.5f * s, r.right + 3.5f * s, r.bottom + 3.5f * s)
                    canvas.drawRoundRect(tmpRect, 11f * s, 11f * s, glowPaint)
                }

                val fillColor = when {
                    isSelected -> if (currentTheme.isDark) Color.parseColor("#FF1E293B") else Color.parseColor("#FFE0F2FE")
                    currentTheme.isDark -> Color.parseColor("#FF0F172A")
                    else -> Color.WHITE
                }
                nodeFillPaint.color = fillColor
                nodeStrokePaint.color = statusCol
                nodeStrokePaint.strokeWidth = (if (isSelected || isDoing) 1.9f else 1.2f) * s

                when (node.role) {
                    "decision" -> {
                        val diamond = Path().apply {
                            moveTo(r.centerX(), r.top - 2f * s)
                            lineTo(r.right + 2f * s, r.centerY())
                            lineTo(r.centerX(), r.bottom + 2f * s)
                            lineTo(r.left - 2f * s, r.centerY())
                            close()
                        }
                        canvas.drawPath(diamond, nodeFillPaint)
                        canvas.drawPath(diamond, nodeStrokePaint)
                    }
                    "start", "end" -> {
                        val pillR = r.height() / 2f
                        canvas.drawRoundRect(r, pillR, pillR, nodeFillPaint)
                        canvas.drawRoundRect(r, pillR, pillR, nodeStrokePaint)
                    }
                    else -> {
                        val cornerR = 8f * s
                        canvas.drawRoundRect(r, cornerR, cornerR, nodeFillPaint)
                        canvas.drawRoundRect(r, cornerR, cornerR, nodeStrokePaint)
                    }
                }

                // Status indicator dot on left edge
                nodeFillPaint.color = statusCol
                canvas.drawCircle(r.left + 7f * s, r.centerY(), 2.6f * s, nodeFillPaint)

                // Concise centered/trimmed node label
                labelPaint.textSize = 9.0f * s
                labelPaint.color = if (currentTheme.isDark) Color.parseColor("#FFF8FAFC") else currentTheme.textPrimary
                val maxChars = max(6, ((r.width() - 18f * s) / (5.1f * s)).toInt())
                val trimmed = if (node.label.length > maxChars) node.label.take(maxChars - 1) + "…" else node.label
                val fm = labelPaint.fontMetrics
                val textY = r.centerY() - (fm.ascent + fm.descent) / 2f
                canvas.drawText(trimmed, r.centerX() + 3f * s, textY, labelPaint)
            }
        }

        private fun drawSequenceDiagram(canvas: Canvas, bounds: RectF, s: Float) {
            val actors = activeData.nodes.ifEmpty {
                listOf(
                    AgyHudDynamicModels.DiagramNode("a1", "User", role = "actor", status = "done"),
                    AgyHudDynamicModels.DiagramNode("a2", "Agy", role = "actor", status = "doing")
                )
            }.take(5)
            val count = actors.size.coerceAtLeast(1)
            val colW = bounds.width() / count.toFloat()
            val headerH = 22f * s
            val headerY = bounds.top + headerH / 2f
            val lifelineTop = bounds.top + headerH + 4f * s
            val lifelineBottom = bounds.bottom - 4f * s

            val actorCenterX = mutableMapOf<String, Float>()

            actors.forEachIndexed { idx, actor ->
                val cx = bounds.left + colW * (idx + 0.5f)
                actorCenterX[actor.id] = cx
                val boxW = min(72f * s, colW * 0.86f)
                val rect = RectF(cx - boxW / 2f, headerY - headerH / 2f, cx + boxW / 2f, headerY + headerH / 2f)
                hitTargets.add(RectF(rect) to actor.id)

                val col = statusColorFor(actor.status)
                nodeFillPaint.color = if (currentTheme.isDark) Color.parseColor("#FF0F172A") else Color.WHITE
                nodeStrokePaint.color = if (actor.id == selectedNodeId) currentTheme.accent else col
                nodeStrokePaint.strokeWidth = 1.4f * s
                canvas.drawRoundRect(rect, 7f * s, 7f * s, nodeFillPaint)
                canvas.drawRoundRect(rect, 7f * s, 7f * s, nodeStrokePaint)

                labelPaint.textSize = 8.5f * s
                labelPaint.color = if (currentTheme.isDark) Color.WHITE else currentTheme.textPrimary
                val fm = labelPaint.fontMetrics
                val lbl = if (actor.label.length > 10) actor.label.take(9) + "…" else actor.label
                canvas.drawText(lbl, cx, rect.centerY() - (fm.ascent + fm.descent) / 2f, labelPaint)

                // Dashed vertical lifeline
                edgePaint.color = if (currentTheme.isDark) Color.parseColor("#FF334155") else Color.parseColor("#FFCBD5E1")
                edgePaint.strokeWidth = 1.2f * s
                edgePaint.pathEffect = edgeDashEffect
                canvas.drawLine(cx, lifelineTop, cx, lifelineBottom, edgePaint)
                edgePaint.pathEffect = null
            }

            val messages = if (activeData.edges.isNotEmpty()) {
                activeData.edges
            } else {
                actors.zipWithNext().mapIndexed { idx, (a, b) ->
                    AgyHudDynamicModels.DiagramEdge(a.id, b.id, label = "Step ${idx + 1}", active = b.status == "doing")
                }
            }.take(8)
            if (messages.isEmpty()) return

            val msgSpan = (lifelineBottom - lifelineTop - 10f * s).coerceAtLeast(30f * s)
            val stepY = msgSpan / messages.size.toFloat()

            messages.forEachIndexed { idx, msg ->
                val x1 = actorCenterX[msg.fromId] ?: actors.firstOrNull()?.let { actorCenterX[it.id] } ?: bounds.left
                val x2 = actorCenterX[msg.toId] ?: actors.lastOrNull()?.let { actorCenterX[it.id] } ?: bounds.right
                val y = lifelineTop + stepY * (idx + 0.55f)
                val col = if (msg.active) currentTheme.accent else if (currentTheme.isDark) Color.parseColor("#FF94A3B8") else Color.parseColor("#FF475569")

                edgePaint.color = col
                edgePaint.strokeWidth = (if (msg.active) 2.0f else 1.4f) * s
                edgePaint.pathEffect = if (msg.dashed) edgeDashEffect else null
                if (abs(x1 - x2) < 6f * s) {
                    // Self-call loop
                    val loopR = RectF(x1, y - 6f * s, x1 + 22f * s, y + 6f * s)
                    canvas.drawArc(loopR, -90f, 180f, false, edgePaint)
                    drawArrowHead(canvas, x1, y + 6f * s, PI, col, s)
                } else {
                    canvas.drawLine(x1, y, x2, y, edgePaint)
                    val angle = if (x2 >= x1) 0.0 else PI
                    drawArrowHead(canvas, x2, y, angle, col, s)
                }
                edgePaint.pathEffect = null

                val txt = msg.label.ifBlank { "#${idx + 1}" }
                subLabelPaint.textSize = 7.8f * s
                subLabelPaint.color = if (msg.active) currentTheme.accent else currentTheme.textSecondary
                canvas.drawText(txt.take(20), (x1 + x2) / 2f, y - 4f * s, subLabelPaint)

                if (msg.active && abs(x1 - x2) >= 6f * s) {
                    val px = x1 + (x2 - x1) * pulsePhase
                    glowPaint.color = Color.WHITE
                    canvas.drawCircle(px, y, 2.2f * s, glowPaint)
                }
            }
        }

        private fun drawTimelineDiagram(canvas: Canvas, bounds: RectF, s: Float) {
            val nodes = activeData.nodes.take(8)
            if (nodes.isEmpty()) return
            val railX = bounds.left + 20f * s
            val rowH = bounds.height() / nodes.size.toFloat()

            // Vertical track rail
            val firstY = bounds.top + rowH * 0.5f
            val lastY = bounds.top + rowH * (nodes.size - 0.5f)
            edgePaint.color = if (currentTheme.isDark) Color.parseColor("#FF334155") else Color.parseColor("#FFCBD5E1")
            edgePaint.strokeWidth = 2.0f * s
            canvas.drawLine(railX, firstY, railX, lastY, edgePaint)

            nodes.forEachIndexed { idx, node ->
                val cy = bounds.top + rowH * (idx + 0.5f)
                val statusCol = statusColorFor(node.status)
                val isSelected = node.id == selectedNodeId
                val cardLeft = railX + 14f * s
                val cardH = min(28f * s, rowH * 0.78f)
                val cardRect = RectF(cardLeft, cy - cardH / 2f, bounds.right - 2f * s, cy + cardH / 2f)
                hitTargets.add(RectF(railX - 10f * s, cardRect.top, cardRect.right, cardRect.bottom) to node.id)

                if (node.status == "doing" || isSelected) {
                    glowPaint.color = Color.argb(80, Color.red(statusCol), Color.green(statusCol), Color.blue(statusCol))
                    canvas.drawCircle(railX, cy, (7.5f + 2f * sin(pulsePhase * 2f * PI).toFloat()) * s, glowPaint)
                }
                nodeFillPaint.color = statusCol
                canvas.drawCircle(railX, cy, 4.5f * s, nodeFillPaint)

                nodeFillPaint.color = if (isSelected) {
                    if (currentTheme.isDark) Color.parseColor("#FF1E293B") else Color.parseColor("#FFE0F2FE")
                } else if (currentTheme.isDark) {
                    Color.parseColor("#FF0F172A")
                } else {
                    Color.WHITE
                }
                nodeStrokePaint.color = if (isSelected || node.status == "doing") statusCol else currentTheme.border
                nodeStrokePaint.strokeWidth = (if (isSelected || node.status == "doing") 1.6f else 1.0f) * s
                canvas.drawRoundRect(cardRect, 8f * s, 8f * s, nodeFillPaint)
                canvas.drawRoundRect(cardRect, 8f * s, 8f * s, nodeStrokePaint)

                labelPaint.textAlign = Paint.Align.LEFT
                labelPaint.textSize = 9.2f * s
                labelPaint.color = if (currentTheme.isDark) Color.WHITE else currentTheme.textPrimary
                val fm = labelPaint.fontMetrics
                canvas.drawText(
                    node.label.take(26),
                    cardRect.left + 8f * s,
                    cardRect.centerY() - (fm.ascent + fm.descent) / 2f,
                    labelPaint
                )
                labelPaint.textAlign = Paint.Align.CENTER
            }
        }

        private fun drawChartDiagram(canvas: Canvas, bounds: RectF, s: Float) {
            val series = effectiveSeriesForChart()
            if (series.isEmpty()) return
            val chartKind = subChartOverride ?: activeData.subChartType
            when (chartKind) {
                "radial" -> drawRadialGauges(canvas, bounds, series, s)
                "line" -> drawLineSparkChart(canvas, bounds, series, s)
                else -> drawBarChart(canvas, bounds, series, s)
            }
        }

        private fun drawBarChart(
            canvas: Canvas,
            bounds: RectF,
            series: List<AgyHudDynamicModels.DiagramSeriesPoint>,
            s: Float
        ) {
            val plotBottom = bounds.bottom - 18f * s
            val plotTop = bounds.top + 14f * s
            val plotH = (plotBottom - plotTop).coerceAtLeast(30f * s)

            // Baseline
            edgePaint.color = currentTheme.border
            edgePaint.strokeWidth = 1f * s
            canvas.drawLine(bounds.left, plotBottom, bounds.right, plotBottom, edgePaint)

            val slotW = bounds.width() / series.size.toFloat()
            val barW = min(28f * s, slotW * 0.62f).coerceAtLeast(10f * s)
            val palette = listOf(
                currentTheme.accent,
                Color.parseColor("#10B981"),
                Color.parseColor("#F59E0B"),
                Color.parseColor("#EC4899"),
                Color.parseColor("#38BDF8")
            )

            series.forEachIndexed { idx, pt ->
                val frac = (pt.value / pt.maxValue.coerceAtLeast(1f)).coerceIn(0.05f, 1f)
                val cx = bounds.left + slotW * (idx + 0.5f)
                val topY = plotBottom - plotH * frac
                val barRect = RectF(cx - barW / 2f, topY, cx + barW / 2f, plotBottom)
                hitTargets.add(RectF(barRect.left - 4f * s, plotTop, barRect.right + 4f * s, bounds.bottom) to pt.label)

                val col = parseOptionalColor(pt.colorHex) ?: palette[idx % palette.size]
                nodeFillPaint.shader = LinearGradient(
                    0f, barRect.top, 0f, barRect.bottom,
                    col,
                    Color.argb(120, Color.red(col), Color.green(col), Color.blue(col)),
                    Shader.TileMode.CLAMP
                )
                canvas.drawRoundRect(barRect, 5f * s, 5f * s, nodeFillPaint)
                nodeFillPaint.shader = null

                // Value text above bar
                subLabelPaint.textSize = 7.8f * s
                subLabelPaint.color = if (currentTheme.isDark) Color.WHITE else currentTheme.textPrimary
                val valStr = if (pt.value % 1f == 0f) pt.value.toInt().toString() else String.format("%.1f", pt.value)
                canvas.drawText(valStr, cx, topY - 4f * s, subLabelPaint)

                // Category tag below baseline
                subLabelPaint.color = currentTheme.textSecondary
                canvas.drawText(pt.label.take(7), cx, plotBottom + 11f * s, subLabelPaint)
            }
        }

        private fun drawLineSparkChart(
            canvas: Canvas,
            bounds: RectF,
            series: List<AgyHudDynamicModels.DiagramSeriesPoint>,
            s: Float
        ) {
            val plotBottom = bounds.bottom - 18f * s
            val plotTop = bounds.top + 14f * s
            val plotH = (plotBottom - plotTop).coerceAtLeast(30f * s)
            val maxV = max(1f, series.maxOf { max(it.value, it.maxValue) })

            val points = series.mapIndexed { idx, pt ->
                val x = if (series.size == 1) bounds.centerX() else bounds.left + 8f * s + (bounds.width() - 16f * s) * (idx.toFloat() / (series.size - 1))
                val y = plotBottom - plotH * (pt.value / maxV).coerceIn(0.05f, 1f)
                PointF(x, y)
            }

            // Fill gradient under curve
            val areaPath = Path()
            val linePath = Path()
            points.forEachIndexed { idx, p ->
                if (idx == 0) {
                    linePath.moveTo(p.x, p.y)
                    areaPath.moveTo(p.x, plotBottom)
                    areaPath.lineTo(p.x, p.y)
                } else {
                    val prev = points[idx - 1]
                    val midX = (prev.x + p.x) / 2f
                    linePath.cubicTo(midX, prev.y, midX, p.y, p.x, p.y)
                    areaPath.cubicTo(midX, prev.y, midX, p.y, p.x, p.y)
                }
            }
            areaPath.lineTo(points.last().x, plotBottom)
            areaPath.close()

            nodeFillPaint.shader = LinearGradient(
                0f, plotTop, 0f, plotBottom,
                Color.argb(95, Color.red(currentTheme.accent), Color.green(currentTheme.accent), Color.blue(currentTheme.accent)),
                Color.argb(8, Color.red(currentTheme.accent), Color.green(currentTheme.accent), Color.blue(currentTheme.accent)),
                Shader.TileMode.CLAMP
            )
            canvas.drawPath(areaPath, nodeFillPaint)
            nodeFillPaint.shader = null

            edgePaint.color = currentTheme.accent
            edgePaint.strokeWidth = 2.2f * s
            canvas.drawPath(linePath, edgePaint)

            points.forEachIndexed { idx, p ->
                nodeFillPaint.color = Color.WHITE
                canvas.drawCircle(p.x, p.y, 3.2f * s, nodeFillPaint)
                nodeStrokePaint.color = currentTheme.accent
                nodeStrokePaint.strokeWidth = 1.6f * s
                canvas.drawCircle(p.x, p.y, 3.2f * s, nodeStrokePaint)

                subLabelPaint.textSize = 7.4f * s
                subLabelPaint.color = currentTheme.textSecondary
                canvas.drawText(series[idx].label.take(6), p.x, plotBottom + 11f * s, subLabelPaint)
            }
        }

        private fun drawRadialGauges(
            canvas: Canvas,
            bounds: RectF,
            series: List<AgyHudDynamicModels.DiagramSeriesPoint>,
            s: Float
        ) {
            val items = series.take(4)
            val cols = min(items.size, 2).coerceAtLeast(1)
            val rows = ((items.size + cols - 1) / cols).coerceAtLeast(1)
            val cellW = bounds.width() / cols.toFloat()
            val cellH = bounds.height() / rows.toFloat()
            val palette = listOf(
                currentTheme.accent,
                Color.parseColor("#10B981"),
                Color.parseColor("#F59E0B"),
                Color.parseColor("#EC4899")
            )

            items.forEachIndexed { idx, pt ->
                val c = idx % cols
                val r = idx / cols
                val cx = bounds.left + cellW * (c + 0.5f)
                val cy = bounds.top + cellH * (r + 0.45f)
                val radius = (min(cellW, cellH) * 0.34f).coerceAtLeast(14f * s)
                val arcRect = RectF(cx - radius, cy - radius, cx + radius, cy + radius)
                val col = parseOptionalColor(pt.colorHex) ?: palette[idx % palette.size]
                val pct = (pt.value / pt.maxValue.coerceAtLeast(1f)).coerceIn(0f, 1f)

                nodeStrokePaint.strokeCap = Paint.Cap.ROUND
                nodeStrokePaint.strokeWidth = 4.6f * s
                nodeStrokePaint.color = if (currentTheme.isDark) Color.parseColor("#FF1E293B") else Color.parseColor("#FFE2E8F0")
                canvas.drawOval(arcRect, nodeStrokePaint)

                nodeStrokePaint.color = col
                canvas.drawArc(arcRect, -90f, 360f * pct, false, nodeStrokePaint)

                labelPaint.textSize = 9.0f * s
                labelPaint.color = if (currentTheme.isDark) Color.WHITE else currentTheme.textPrimary
                val fm = labelPaint.fontMetrics
                canvas.drawText("${(pct * 100).toInt()}%", cx, cy - (fm.ascent + fm.descent) / 2f, labelPaint)

                subLabelPaint.textSize = 7.6f * s
                subLabelPaint.color = currentTheme.textSecondary
                canvas.drawText(pt.label.take(11), cx, cy + radius + 11f * s, subLabelPaint)
            }
        }

        private fun drawArrowHead(canvas: Canvas, x: Float, y: Float, angleRad: Double, color: Int, s: Float) {
            val len = 6.0f * s
            val spread = 0.48
            arrowPath.reset()
            arrowPath.moveTo(x, y)
            arrowPath.lineTo((x - len * cos(angleRad - spread)).toFloat(), (y - len * sin(angleRad - spread)).toFloat())
            arrowPath.lineTo((x - len * cos(angleRad + spread)).toFloat(), (y - len * sin(angleRad + spread)).toFloat())
            arrowPath.close()
            nodeFillPaint.color = color
            canvas.drawPath(arrowPath, nodeFillPaint)
        }

        private fun evalCubicBezier(
            x0: Float, y0: Float,
            x1: Float, y1: Float,
            x2: Float, y2: Float,
            x3: Float, y3: Float,
            t: Float
        ): PointF {
            val u = 1f - t
            val tt = t * t
            val uu = u * u
            val uuu = uu * u
            val ttt = tt * t
            val px = uuu * x0 + 3f * uu * t * x1 + 3f * u * tt * x2 + ttt * x3
            val py = uuu * y0 + 3f * uu * t * y1 + 3f * u * tt * y2 + ttt * y3
            return PointF(px, py)
        }

        private fun parseOptionalColor(hex: String): Int? {
            if (hex.isBlank()) return null
            return try {
                Color.parseColor(hex)
            } catch (_: Exception) {
                null
            }
        }
    }
}
