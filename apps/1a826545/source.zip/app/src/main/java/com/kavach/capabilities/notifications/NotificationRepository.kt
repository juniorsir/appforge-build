package com.kavach.capabilities.notifications

import com.kavach.capabilities.CapabilityResult

interface NotificationRepository {
    fun showNotification(title: String, message: String): CapabilityResult<Unit>
    fun showProgressNotification(title: String, progress: Int, max: Int): CapabilityResult<Unit>
    fun showAuthNotification(title: String, message: String, securityDeviceId: String, requestId: String): CapabilityResult<Unit>
}
