package com.kavach.tools.execution

import com.kavach.capabilities.permissions.PermissionManager
import com.kavach.tools.core.Tool
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class PermissionValidator @Inject constructor(
    private val permissionManager: PermissionManager
) {
    fun validatePermissions(tool: Tool): List<String> {
        return permissionManager.getMissingPermissions(tool.requiredPermissions)
    }
}
