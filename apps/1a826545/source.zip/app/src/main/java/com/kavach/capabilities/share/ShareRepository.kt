package com.kavach.capabilities.share

import com.kavach.capabilities.CapabilityResult

interface ShareRepository {
    fun shareText(text: String): CapabilityResult<Unit>
}
