package com.kavach.ui.overlay

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.util.LruCache
import android.view.View
import kotlin.math.min

/**
 * Hybrid 3-Tier App & Task Icon Engine for the Agy HUD.
 *
 * Tier 1: Active target foreground package (never overwritten by Termux or generic verbs).
 * Tier 2: Installed launcher app fuzzy lookup + weighted domain specs (Chess, Lichess, YouTube,
 *         Spotify, VLC, Calculator, Clock, etc.) avoiding keyword collisions ("video" -> Camera,
 *         "python"/"tap" overriding target apps).
 * Tier 3: Live 13dp circular corner action sub-badge (`watching`, `tapping`, `typing`, `coding`,
 *         `searching`, `playing`, `security`).
 */
object AgyAppIconResolver {

    enum class BadgeKind {
        YOUTUBE,
        WHATSAPP,
        CHROME,
        TERMUX,
        INSTAGRAM,
        TELEGRAM,
        SPOTIFY,
        GMAIL,
        MAPS,
        SETTINGS,
        GITHUB,
        PLAY_STORE,
        CHESS,
        CALCULATOR,
        CLOCK,
        VLC,
        CAMERA,
        FILES,
        PHONE,
        SEARCH,
        CODE,
        TAP,
        SECURITY,
        SPARK_AI
    }

    enum class ActionKind {
        NONE,
        WATCHING,
        TAPPING,
        TYPING,
        CODING,
        SEARCHING,
        PLAYING,
        SECURITY;

        companion object {
            fun fromHint(raw: String?, fallbackText: String = ""): ActionKind {
                val clean = raw?.trim()?.lowercase().orEmpty()
                when (clean) {
                    "watching", "watch", "inspect", "screen", "view" -> return WATCHING
                    "tapping", "tap", "click", "drag", "swipe", "gesture", "scroll" -> return TAPPING
                    "typing", "type", "input", "write", "text" -> return TYPING
                    "coding", "code", "terminal", "shell", "build", "python", "script", "daemon" -> return CODING
                    "searching", "search", "find", "lookup", "query" -> return SEARCHING
                    "playing", "play", "media", "stream", "music" -> return PLAYING
                    "security", "shield", "auth", "verify", "lock", "audit" -> return SECURITY
                    "none", "idle", "" -> if (clean == "none") return NONE
                }
                val hay = " ${fallbackText.lowercase()} "
                return when {
                    hay.containsAny("inspect", "ui tree", "watching", "screen watch", "reading screen") -> WATCHING
                    hay.containsAny("typing", "input_text", "enter text", "type ") -> TYPING
                    hay.containsAny("tap ", "click", "swipe", "drag", "scroll", "move ") -> TAPPING
                    hay.containsAny("playing", "now playing", "playback", "music", "video") -> PLAYING
                    hay.containsAny("search", "lookup", "query", "find ") -> SEARCHING
                    hay.containsAny("security", "token", "auth", "shield", "audit", "verify") -> SECURITY
                    hay.containsAny("python", "gradle", "compile", "script", "bash", "shell", "code", "daemon") -> CODING
                    else -> NONE
                }
            }

            private fun String.containsAny(vararg needles: String): Boolean = needles.any { this.contains(it) }
        }
    }

    data class ResolvedIcon(
        val key: String,
        val kind: BadgeKind,
        val packageName: String?,
        val accentColor: Int,
        val bgColor: Int,
        val appBitmap: Bitmap? = null,
        val actionKind: ActionKind = ActionKind.NONE
    )

    private data class AliasSpec(
        val key: String,
        val kind: BadgeKind,
        val packageName: String?,
        val accentColor: Int,
        val bgColor: Int,
        val keywords: List<String>,
        val basePriority: Int = 10 // App/domain specs >= 10, generic verbs/shell <= 3
    )

    private data class CachedLauncherApp(
        val appName: String,
        val appNameLower: String,
        val packageName: String
    )

    private val specs: List<AliasSpec> = listOf(
        AliasSpec(
            key = "youtube",
            kind = BadgeKind.YOUTUBE,
            packageName = "com.google.android.youtube",
            accentColor = Color.parseColor("#FF0033"),
            bgColor = Color.parseColor("#FFE5EA"),
            keywords = listOf("youtube", "yt", "youtu.be", "com.google.android.youtube")
        ),
        AliasSpec(
            key = "whatsapp",
            kind = BadgeKind.WHATSAPP,
            packageName = "com.whatsapp",
            accentColor = Color.parseColor("#16A34A"),
            bgColor = Color.parseColor("#DCFCE7"),
            keywords = listOf("whatsapp", "wa.me", "com.whatsapp")
        ),
        AliasSpec(
            key = "chrome",
            kind = BadgeKind.CHROME,
            packageName = "com.android.chrome",
            accentColor = Color.parseColor("#2563EB"),
            bgColor = Color.parseColor("#DBEAFE"),
            keywords = listOf("chrome", "browser", "webpage", "website", "http://", "https://", "com.android.chrome")
        ),
        AliasSpec(
            key = "termux",
            kind = BadgeKind.TERMUX,
            packageName = "com.termux",
            accentColor = Color.parseColor("#0EA5E9"),
            bgColor = Color.parseColor("#0F172A"),
            keywords = listOf("termux", "shell", "bash", "terminal", "cli", "daemon", "ssh", "pkg", "com.termux")
        ),
        AliasSpec(
            key = "instagram",
            kind = BadgeKind.INSTAGRAM,
            packageName = "com.instagram.android",
            accentColor = Color.parseColor("#E11D48"),
            bgColor = Color.parseColor("#FCE7F3"),
            keywords = listOf("instagram", "insta", "reels", "com.instagram.android")
        ),
        AliasSpec(
            key = "telegram",
            kind = BadgeKind.TELEGRAM,
            packageName = "org.telegram.messenger",
            accentColor = Color.parseColor("#0284C7"),
            bgColor = Color.parseColor("#E0F2FE"),
            keywords = listOf("telegram", "org.telegram.messenger")
        ),
        AliasSpec(
            key = "spotify",
            kind = BadgeKind.SPOTIFY,
            packageName = "com.spotify.music",
            accentColor = Color.parseColor("#16A34A"),
            bgColor = Color.parseColor("#DCFCE7"),
            keywords = listOf("spotify", "music", "playlist", "podcast", "com.spotify.music")
        ),
        AliasSpec(
            key = "gmail",
            kind = BadgeKind.GMAIL,
            packageName = "com.google.android.gm",
            accentColor = Color.parseColor("#DC2626"),
            bgColor = Color.parseColor("#FEE2E2"),
            keywords = listOf("gmail", "email", "inbox", "mail", "com.google.android.gm")
        ),
        AliasSpec(
            key = "maps",
            kind = BadgeKind.MAPS,
            packageName = "com.google.android.apps.maps",
            accentColor = Color.parseColor("#059669"),
            bgColor = Color.parseColor("#D1FAE5"),
            keywords = listOf("maps", "navigate", "navigation", "gps", "location", "com.google.android.apps.maps")
        ),
        AliasSpec(
            key = "settings",
            kind = BadgeKind.SETTINGS,
            packageName = "com.android.settings",
            accentColor = Color.parseColor("#475569"),
            bgColor = Color.parseColor("#E2E8F0"),
            keywords = listOf("settings", "wi-fi", "wifi", "bluetooth", "system", "config", "com.android.settings")
        ),
        AliasSpec(
            key = "github",
            kind = BadgeKind.GITHUB,
            packageName = "com.github.android",
            accentColor = Color.parseColor("#1E293B"),
            bgColor = Color.parseColor("#E2E8F0"),
            keywords = listOf("github", "git ", "repo", "commit", "pull request", "com.github.android")
        ),
        AliasSpec(
            key = "playstore",
            kind = BadgeKind.PLAY_STORE,
            packageName = "com.android.vending",
            accentColor = Color.parseColor("#0284C7"),
            bgColor = Color.parseColor("#E0F2FE"),
            keywords = listOf("play store", "playstore", "install app", "com.android.vending")
        ),
        AliasSpec(
            key = "chess",
            kind = BadgeKind.CHESS,
            packageName = "com.chess",
            accentColor = Color.parseColor("#16A34A"),
            bgColor = Color.parseColor("#DCFCE7"),
            keywords = listOf("chess", "chess.com", "chessboard", "grandmaster", "checkmate", "com.chess"),
            basePriority = 12
        ),
        AliasSpec(
            key = "lichess",
            kind = BadgeKind.CHESS,
            packageName = "org.lichess.mobileapp",
            accentColor = Color.parseColor("#1E293B"),
            bgColor = Color.parseColor("#E2E8F0"),
            keywords = listOf("lichess", "org.lichess.mobileapp"),
            basePriority = 12
        ),
        AliasSpec(
            key = "vlc",
            kind = BadgeKind.VLC,
            packageName = "org.videolan.vlc",
            accentColor = Color.parseColor("#EA580C"),
            bgColor = Color.parseColor("#FFEDD5"),
            keywords = listOf("vlc", "videolan", "org.videolan.vlc"),
            basePriority = 11
        ),
        AliasSpec(
            key = "calculator",
            kind = BadgeKind.CALCULATOR,
            packageName = "com.google.android.calculator",
            accentColor = Color.parseColor("#0284C7"),
            bgColor = Color.parseColor("#E0F2FE"),
            keywords = listOf("calculator", "calc", "com.google.android.calculator", "com.android.calculator2"),
            basePriority = 11
        ),
        AliasSpec(
            key = "clock",
            kind = BadgeKind.CLOCK,
            packageName = "com.google.android.deskclock",
            accentColor = Color.parseColor("#4F46E5"),
            bgColor = Color.parseColor("#E0E7FF"),
            keywords = listOf("clock", "alarm", "timer", "stopwatch", "deskclock", "com.google.android.deskclock"),
            basePriority = 10
        ),
        AliasSpec(
            key = "termux",
            kind = BadgeKind.TERMUX,
            packageName = "com.termux",
            accentColor = Color.parseColor("#0EA5E9"),
            bgColor = Color.parseColor("#0F172A"),
            keywords = listOf("termux", "shell", "bash", "terminal", "cli", "daemon", "ssh", "pkg", "com.termux"),
            basePriority = 3
        ),
        AliasSpec(
            key = "camera",
            kind = BadgeKind.CAMERA,
            packageName = null,
            accentColor = Color.parseColor("#4F46E5"),
            bgColor = Color.parseColor("#E0E7FF"),
            keywords = listOf("camera", "photo", "selfie", "take picture", "take a photo", "camera capture"),
            basePriority = 8
        ),
        AliasSpec(
            key = "files",
            kind = BadgeKind.FILES,
            packageName = null,
            accentColor = Color.parseColor("#D97706"),
            bgColor = Color.parseColor("#FEF3C7"),
            keywords = listOf("file", "folder", "download", "sdcard", "export", "storage", "save"),
            basePriority = 4
        ),
        AliasSpec(
            key = "phone",
            kind = BadgeKind.PHONE,
            packageName = null,
            accentColor = Color.parseColor("#16A34A"),
            bgColor = Color.parseColor("#DCFCE7"),
            keywords = listOf("call ", "dial", "phone", "sms", "text message", "contact"),
            basePriority = 8
        ),
        AliasSpec(
            key = "tap",
            kind = BadgeKind.TAP,
            packageName = null,
            accentColor = Color.parseColor("#0095F6"),
            bgColor = Color.parseColor("#E0F2FE"),
            keywords = listOf("tap ", "click", "swipe", "scroll", "ui tree", "hierarchy", "screen", "button"),
            basePriority = 2
        ),
        AliasSpec(
            key = "security",
            kind = BadgeKind.SECURITY,
            packageName = null,
            accentColor = Color.parseColor("#059669"),
            bgColor = Color.parseColor("#D1FAE5"),
            keywords = listOf("token", "auth", "bridge", "relay", "verify", "shield", "vpn", "lock", "firewall"),
            basePriority = 5
        ),
        AliasSpec(
            key = "code",
            kind = BadgeKind.CODE,
            packageName = null,
            accentColor = Color.parseColor("#7C3AED"),
            bgColor = Color.parseColor("#EDE9FE"),
            keywords = listOf("code", "script", "python", "gradle", "build", "compile", "deploy", "json", "api", "debug"),
            basePriority = 2
        ),
        AliasSpec(
            key = "search",
            kind = BadgeKind.SEARCH,
            packageName = null,
            accentColor = Color.parseColor("#0095F6"),
            bgColor = Color.parseColor("#DBEAFE"),
            keywords = listOf("search", "find", "lookup", "query", "inspect", "check"),
            basePriority = 2
        )
    )

    private val bitmapCache = object : LruCache<String, Bitmap>(48) {
        override fun sizeOf(key: String, value: Bitmap): Int = 1
    }
    private val missingPackageCache = HashSet<String>()
    @Volatile
    private var launcherCache: List<CachedLauncherApp> = emptyList()
    @Volatile
    private var launcherCacheAtMs: Long = 0L

    private fun getInstalledLauncherApps(context: Context?): List<CachedLauncherApp> {
        if (context == null) return emptyList()
        val now = System.currentTimeMillis()
        val cached = launcherCache
        if (cached.isNotEmpty() && now - launcherCacheAtMs < 60_000L) {
            return cached
        }
        return try {
            val pm = context.packageManager
            val intent = Intent(Intent.ACTION_MAIN, null).apply {
                addCategory(Intent.CATEGORY_LAUNCHER)
            }
            val infos = pm.queryIntentActivities(intent, 0)
            val seen = HashSet<String>()
            val list = buildList {
                for (ri in infos) {
                    val pkg = ri.activityInfo?.packageName ?: continue
                    if (!seen.add(pkg)) continue
                    val lbl = try { ri.loadLabel(pm).toString().trim() } catch (_: Exception) { pkg }
                    if (lbl.isNotEmpty()) {
                        add(CachedLauncherApp(lbl, lbl.lowercase(), pkg))
                    }
                }
            }
            launcherCache = list
            launcherCacheAtMs = now
            list
        } catch (_: Exception) {
            cached
        }
    }

    /**
     * Resolves an explicit packageName / icon key or infers the best app/task icon using the
     * 3-Tier resolution pipeline, plus live ActionKind for the 13dp corner sub-badge.
     */
    fun resolve(
        context: Context?,
        explicitIcon: String = "",
        explicitPackage: String = "",
        fallbackText: String = "",
        actionKindHint: String = ""
    ): ResolvedIcon {
        val cleanPkg = explicitPackage.trim()
        val cleanIcon = explicitIcon.trim().lowercase()
        val combinedText = "$cleanIcon $cleanPkg $fallbackText".lowercase()
        val resolvedAction = ActionKind.fromHint(actionKindHint, "$cleanIcon $fallbackText")

        // Tier 1: Explicit concrete package (or explicit non-generic icon key)
        val nonTermuxExplicitPkg = cleanPkg.takeIf { it.isNotBlank() && it != "com.termux" }
        val explicitSpec = specs.firstOrNull { spec ->
            (cleanIcon.isNotEmpty() && (spec.key == cleanIcon || spec.keywords.any { it == cleanIcon })) ||
                (nonTermuxExplicitPkg != null && spec.packageName.equals(nonTermuxExplicitPkg, ignoreCase = true))
        }

        if (nonTermuxExplicitPkg != null) {
            val realBitmap = if (context != null) loadInstalledAppBitmap(context, nonTermuxExplicitPkg) else null
            if (realBitmap != null || explicitSpec != null) {
                return ResolvedIcon(
                    key = explicitSpec?.key ?: nonTermuxExplicitPkg,
                    kind = explicitSpec?.kind ?: BadgeKind.SPARK_AI,
                    packageName = nonTermuxExplicitPkg,
                    accentColor = explicitSpec?.accentColor ?: Color.parseColor("#0095F6"),
                    bgColor = explicitSpec?.bgColor ?: Color.parseColor("#E0F2FE"),
                    appBitmap = realBitmap,
                    actionKind = resolvedAction
                )
            }
        }

        // Tier 2A: Installed launcher app fuzzy match (skip generic short labels & Termux unless specific)
        var bestInstalled: Pair<Int, CachedLauncherApp>? = null
        if (context != null && combinedText.isNotBlank()) {
            for (app in getInstalledLauncherApps(context)) {
                if (app.packageName == "com.termux" || app.packageName == context.packageName) continue
                val lbl = app.appNameLower
                if (lbl.length < 3) continue
                val wordHit = Regex("(^|[^a-z0-9])${Regex.escape(lbl)}([^a-z0-9]|$)").containsMatchIn(combinedText)
                val pkgHit = combinedText.contains(app.packageName.lowercase())
                val score = when {
                    pkgHit -> 24
                    wordHit -> 18 + lbl.length.coerceAtMost(8)
                    else -> 0
                }
                if (score > 0 && (bestInstalled == null || score > bestInstalled.first)) {
                    bestInstalled = score to app
                }
            }
        }

        // Tier 2B: Scored AliasSpec evaluation (so domain apps beat generic verbs like python/tap)
        var bestSpec: Pair<Int, AliasSpec>? = if (explicitSpec != null) 22 to explicitSpec else null
        if (bestSpec == null) {
            for (spec in specs) {
                var specScore = 0
                for (kw in spec.keywords) {
                    val matched = if (kw.length <= 2) {
                        Regex("(^|[^a-z0-9])${Regex.escape(kw)}([^a-z0-9]|$)").containsMatchIn(combinedText)
                    } else {
                        combinedText.contains(kw)
                    }
                    if (matched) {
                        val exactPkgOrWord = kw == spec.key || kw == spec.packageName ||
                            Regex("(^|[^a-z0-9])${Regex.escape(kw.trim())}([^a-z0-9]|$)").containsMatchIn(combinedText)
                        val candidate = spec.basePriority + if (exactPkgOrWord) 5 else 2
                        if (candidate > specScore) specScore = candidate
                    }
                }
                if (specScore > 0 && (bestSpec == null || specScore > bestSpec.first)) {
                    bestSpec = specScore to spec
                }
            }
        }

        // Prefer installed app match when it scores at least as strongly as AliasSpec
        val installedWinner = bestInstalled
        val specWinner = bestSpec
        if (installedWinner != null && (specWinner == null || installedWinner.first >= specWinner.first)) {
            val app = installedWinner.second
            val realBmp = context?.let { loadInstalledAppBitmap(it, app.packageName) }
            val matchingSpec = specs.firstOrNull { it.packageName.equals(app.packageName, ignoreCase = true) }
            if (realBmp != null || matchingSpec != null) {
                return ResolvedIcon(
                    key = matchingSpec?.key ?: app.appNameLower,
                    kind = matchingSpec?.kind ?: BadgeKind.SPARK_AI,
                    packageName = app.packageName,
                    accentColor = matchingSpec?.accentColor ?: Color.parseColor("#0095F6"),
                    bgColor = matchingSpec?.bgColor ?: Color.parseColor("#E0F2FE"),
                    appBitmap = realBmp,
                    actionKind = resolvedAction
                )
            }
        }

        val matchedSpec = specWinner?.second
        val targetPackage = cleanPkg.ifBlank { matchedSpec?.packageName.orEmpty() }.takeIf { it.isNotBlank() }
        val realBitmap = if (context != null && targetPackage != null) {
            loadInstalledAppBitmap(context, targetPackage)
        } else {
            null
        }

        return if (matchedSpec != null) {
            ResolvedIcon(
                key = matchedSpec.key,
                kind = matchedSpec.kind,
                packageName = targetPackage,
                accentColor = matchedSpec.accentColor,
                bgColor = matchedSpec.bgColor,
                appBitmap = realBitmap,
                actionKind = resolvedAction
            )
        } else {
            ResolvedIcon(
                key = targetPackage ?: "spark_ai",
                kind = BadgeKind.SPARK_AI,
                packageName = targetPackage,
                accentColor = Color.parseColor("#4F46E5"),
                bgColor = Color.parseColor("#EEF2FF"),
                appBitmap = realBitmap,
                actionKind = resolvedAction
            )
        }
    }

    private fun loadInstalledAppBitmap(context: Context, packageName: String): Bitmap? {
        bitmapCache.get(packageName)?.let { return it }
        if (missingPackageCache.contains(packageName)) return null
        return try {
            val drawable = context.packageManager.getApplicationIcon(packageName)
            val bmp = drawableToSquircleBitmap(drawable, 72)
            if (bmp != null) {
                bitmapCache.put(packageName, bmp)
            }
            bmp
        } catch (_: Exception) {
            missingPackageCache.add(packageName)
            null
        }
    }

    private fun drawableToSquircleBitmap(drawable: Drawable, sizePx: Int): Bitmap? {
        return try {
            val raw = if (drawable is BitmapDrawable && drawable.bitmap != null &&
                drawable.bitmap.width == sizePx && drawable.bitmap.height == sizePx
            ) {
                drawable.bitmap
            } else {
                val out = Bitmap.createBitmap(sizePx, sizePx, Bitmap.Config.ARGB_8888)
                val canvas = Canvas(out)
                drawable.setBounds(0, 0, sizePx, sizePx)
                drawable.draw(canvas)
                out
            }
            // Clip cleanly into a rounded squircle so legacy icons look uniform & crisp
            val clipped = Bitmap.createBitmap(sizePx, sizePx, Bitmap.Config.ARGB_8888)
            val c = Canvas(clipped)
            val paint = Paint(Paint.ANTI_ALIAS_FLAG)
            val rect = RectF(0f, 0f, sizePx.toFloat(), sizePx.toFloat())
            val radius = sizePx * 0.26f
            c.drawRoundRect(rect, radius, radius, paint)
            paint.xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC_IN)
            c.drawBitmap(raw, null, rect, paint)
            clipped
        } catch (_: Exception) {
            null
        }
    }

    /**
     * Draws a crisp custom vector badge directly onto any Android Canvas (used by both the
     * floating WindowManager View and Jetpack Compose via nativeCanvas).
     */
    fun drawBadgeOnCanvas(canvas: Canvas, width: Float, height: Float, icon: ResolvedIcon) {
        val sz = min(width, height)
        if (sz <= 1f) return
        val left = (width - sz) * 0.5f
        val top = (height - sz) * 0.5f
        val rect = RectF(left, top, left + sz, top + sz)
        val radius = sz * 0.28f

        // 1. If a real installed Android app icon Bitmap was resolved, draw it with a crisp rim!
        val bmp = icon.appBitmap
        if (bmp != null && !bmp.isRecycled) {
            val imgPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
            canvas.drawBitmap(bmp, null, rect, imgPaint)
            val rimPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE
                strokeWidth = (sz * 0.045f).coerceAtLeast(1f)
                color = Color.parseColor("#220F172A")
            }
            canvas.drawRoundRect(rect, radius, radius, rimPaint)
            return
        }

        // 2. Otherwise render a vibrant, tailor-made vector brand/task badge
        val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
        val fgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            color = icon.accentColor
        }
        val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
            strokeWidth = (sz * 0.095f).coerceAtLeast(1.4f)
            color = icon.accentColor
        }

        val cx = left + sz * 0.5f
        val cy = top + sz * 0.5f

        when (icon.kind) {
            BadgeKind.YOUTUBE -> {
                bgPaint.color = Color.parseColor("#FF0033")
                canvas.drawRoundRect(rect, radius, radius, bgPaint)
                fgPaint.color = Color.WHITE
                val tri = Path().apply {
                    moveTo(cx - sz * 0.14f, cy - sz * 0.18f)
                    lineTo(cx + sz * 0.22f, cy)
                    lineTo(cx - sz * 0.14f, cy + sz * 0.18f)
                    close()
                }
                canvas.drawPath(tri, fgPaint)
            }

            BadgeKind.WHATSAPP -> {
                bgPaint.color = Color.parseColor("#22C55E")
                canvas.drawRoundRect(rect, radius, radius, bgPaint)
                strokePaint.color = Color.WHITE
                strokePaint.strokeWidth = sz * 0.085f
                canvas.drawCircle(cx, cy - sz * 0.02f, sz * 0.24f, strokePaint)
                fgPaint.color = Color.WHITE
                val tail = Path().apply {
                    moveTo(cx - sz * 0.20f, cy + sz * 0.14f)
                    lineTo(cx - sz * 0.26f, cy + sz * 0.28f)
                    lineTo(cx - sz * 0.08f, cy + sz * 0.21f)
                    close()
                }
                canvas.drawPath(tail, fgPaint)
            }

            BadgeKind.CHROME -> {
                bgPaint.color = Color.parseColor("#EFF6FF")
                canvas.drawRoundRect(rect, radius, radius, bgPaint)
                val rOuter = sz * 0.30f
                val arcRect = RectF(cx - rOuter, cy - rOuter, cx + rOuter, cy + rOuter)
                strokePaint.strokeWidth = sz * 0.11f
                strokePaint.color = Color.parseColor("#EA4335")
                canvas.drawArc(arcRect, -150f, 120f, false, strokePaint)
                strokePaint.color = Color.parseColor("#FBBC04")
                canvas.drawArc(arcRect, -30f, 120f, false, strokePaint)
                strokePaint.color = Color.parseColor("#34A853")
                canvas.drawArc(arcRect, 90f, 120f, false, strokePaint)
                fgPaint.color = Color.parseColor("#2563EB")
                canvas.drawCircle(cx, cy, sz * 0.14f, fgPaint)
            }

            BadgeKind.TERMUX -> {
                bgPaint.color = Color.parseColor("#0F172A")
                canvas.drawRoundRect(rect, radius, radius, bgPaint)
                strokePaint.color = Color.parseColor("#38BDF8")
                strokePaint.strokeWidth = sz * 0.095f
                val chevron = Path().apply {
                    moveTo(cx - sz * 0.22f, cy - sz * 0.15f)
                    lineTo(cx - sz * 0.04f, cy)
                    lineTo(cx - sz * 0.22f, cy + sz * 0.15f)
                }
                canvas.drawPath(chevron, strokePaint)
                strokePaint.color = Color.parseColor("#E2E8F0")
                canvas.drawLine(cx + sz * 0.04f, cy + sz * 0.15f, cx + sz * 0.24f, cy + sz * 0.15f, strokePaint)
            }

            BadgeKind.INSTAGRAM -> {
                bgPaint.shader = LinearGradient(
                    left, top + sz, left + sz, top,
                    intArrayOf(Color.parseColor("#F59E0B"), Color.parseColor("#E11D48"), Color.parseColor("#7C3AED")),
                    null,
                    Shader.TileMode.CLAMP
                )
                canvas.drawRoundRect(rect, radius, radius, bgPaint)
                strokePaint.color = Color.WHITE
                strokePaint.strokeWidth = sz * 0.085f
                val inner = RectF(cx - sz * 0.24f, cy - sz * 0.24f, cx + sz * 0.24f, cy + sz * 0.24f)
                canvas.drawRoundRect(inner, sz * 0.12f, sz * 0.12f, strokePaint)
                canvas.drawCircle(cx, cy, sz * 0.11f, strokePaint)
            }

            BadgeKind.TELEGRAM -> {
                bgPaint.color = Color.parseColor("#0EA5E9")
                canvas.drawRoundRect(rect, radius, radius, bgPaint)
                fgPaint.color = Color.WHITE
                val plane = Path().apply {
                    moveTo(cx + sz * 0.25f, cy - sz * 0.20f)
                    lineTo(cx - sz * 0.25f, cy - sz * 0.01f)
                    lineTo(cx - sz * 0.04f, cy + sz * 0.08f)
                    lineTo(cx + sz * 0.09f, cy + sz * 0.24f)
                    close()
                }
                canvas.drawPath(plane, fgPaint)
            }

            BadgeKind.SPOTIFY -> {
                bgPaint.color = Color.parseColor("#16A34A")
                canvas.drawRoundRect(rect, radius, radius, bgPaint)
                strokePaint.color = Color.WHITE
                strokePaint.strokeWidth = sz * 0.08f
                val w1 = RectF(cx - sz * 0.24f, cy - sz * 0.18f, cx + sz * 0.24f, cy + sz * 0.14f)
                canvas.drawArc(w1, 210f, 120f, false, strokePaint)
                val w2 = RectF(cx - sz * 0.18f, cy - sz * 0.04f, cx + sz * 0.18f, cy + sz * 0.22f)
                canvas.drawArc(w2, 210f, 120f, false, strokePaint)
            }

            BadgeKind.GMAIL -> {
                bgPaint.color = Color.parseColor("#FEE2E2")
                canvas.drawRoundRect(rect, radius, radius, bgPaint)
                strokePaint.color = Color.parseColor("#DC2626")
                strokePaint.strokeWidth = sz * 0.09f
                val env = RectF(cx - sz * 0.26f, cy - sz * 0.18f, cx + sz * 0.26f, cy + sz * 0.18f)
                canvas.drawRoundRect(env, sz * 0.06f, sz * 0.06f, strokePaint)
                val flap = Path().apply {
                    moveTo(env.left + sz * 0.02f, env.top + sz * 0.03f)
                    lineTo(cx, cy + sz * 0.04f)
                    lineTo(env.right - sz * 0.02f, env.top + sz * 0.03f)
                }
                canvas.drawPath(flap, strokePaint)
            }

            BadgeKind.MAPS -> {
                bgPaint.color = Color.parseColor("#D1FAE5")
                canvas.drawRoundRect(rect, radius, radius, bgPaint)
                fgPaint.color = Color.parseColor("#059669")
                canvas.drawCircle(cx, cy - sz * 0.07f, sz * 0.19f, fgPaint)
                val tip = Path().apply {
                    moveTo(cx - sz * 0.15f, cy)
                    lineTo(cx, cy + sz * 0.27f)
                    lineTo(cx + sz * 0.15f, cy)
                    close()
                }
                canvas.drawPath(tip, fgPaint)
                fgPaint.color = Color.WHITE
                canvas.drawCircle(cx, cy - sz * 0.07f, sz * 0.075f, fgPaint)
            }

            BadgeKind.SETTINGS -> {
                bgPaint.color = Color.parseColor("#E2E8F0")
                canvas.drawRoundRect(rect, radius, radius, bgPaint)
                strokePaint.color = Color.parseColor("#475569")
                strokePaint.strokeWidth = sz * 0.10f
                canvas.drawCircle(cx, cy, sz * 0.20f, strokePaint)
                fgPaint.color = Color.parseColor("#475569")
                canvas.drawCircle(cx, cy, sz * 0.07f, fgPaint)
            }

            BadgeKind.GITHUB -> {
                bgPaint.color = Color.parseColor("#1E293B")
                canvas.drawRoundRect(rect, radius, radius, bgPaint)
                strokePaint.color = Color.WHITE
                strokePaint.strokeWidth = sz * 0.085f
                canvas.drawLine(cx - sz * 0.14f, cy - sz * 0.18f, cx - sz * 0.14f, cy + sz * 0.18f, strokePaint)
                canvas.drawLine(cx - sz * 0.14f, cy + sz * 0.04f, cx + sz * 0.14f, cy - sz * 0.10f, strokePaint)
                fgPaint.color = Color.WHITE
                canvas.drawCircle(cx - sz * 0.14f, cy - sz * 0.18f, sz * 0.07f, fgPaint)
                canvas.drawCircle(cx - sz * 0.14f, cy + sz * 0.18f, sz * 0.07f, fgPaint)
                canvas.drawCircle(cx + sz * 0.14f, cy - sz * 0.10f, sz * 0.07f, fgPaint)
            }

            BadgeKind.PLAY_STORE -> {
                bgPaint.color = Color.parseColor("#E0F2FE")
                canvas.drawRoundRect(rect, radius, radius, bgPaint)
                fgPaint.color = Color.parseColor("#0284C7")
                val prism = Path().apply {
                    moveTo(cx - sz * 0.16f, cy - sz * 0.22f)
                    lineTo(cx + sz * 0.24f, cy)
                    lineTo(cx - sz * 0.16f, cy + sz * 0.22f)
                    close()
                }
                canvas.drawPath(prism, fgPaint)
            }

            BadgeKind.CHESS -> {
                bgPaint.color = Color.parseColor("#14532D")
                canvas.drawRoundRect(rect, radius, radius, bgPaint)
                // Crisp 2x2 board motif + crown/knight silhouette
                val half = sz * 0.5f
                fgPaint.color = Color.parseColor("#22C55E")
                canvas.drawRect(left + sz * 0.14f, top + sz * 0.14f, cx, cy, fgPaint)
                canvas.drawRect(cx, cy, left + sz * 0.86f, top + sz * 0.86f, fgPaint)
                fgPaint.color = Color.WHITE
                val crown = Path().apply {
                    moveTo(cx - sz * 0.22f, cy + sz * 0.18f)
                    lineTo(cx - sz * 0.24f, cy - sz * 0.14f)
                    lineTo(cx - sz * 0.08f, cy - sz * 0.02f)
                    lineTo(cx, cy - sz * 0.22f)
                    lineTo(cx + sz * 0.08f, cy - sz * 0.02f)
                    lineTo(cx + sz * 0.24f, cy - sz * 0.14f)
                    lineTo(cx + sz * 0.22f, cy + sz * 0.18f)
                    close()
                }
                canvas.drawPath(crown, fgPaint)
            }

            BadgeKind.CALCULATOR -> {
                bgPaint.color = Color.parseColor("#E0F2FE")
                canvas.drawRoundRect(rect, radius, radius, bgPaint)
                fgPaint.color = Color.parseColor("#0284C7")
                val pad = sz * 0.22f
                canvas.drawRoundRect(RectF(left + pad, top + pad, left + sz - pad, cy - sz * 0.04f), sz * 0.06f, sz * 0.06f, fgPaint)
                val r = sz * 0.06f
                canvas.drawCircle(cx - sz * 0.14f, cy + sz * 0.10f, r, fgPaint)
                canvas.drawCircle(cx + sz * 0.14f, cy + sz * 0.10f, r, fgPaint)
                canvas.drawCircle(cx - sz * 0.14f, cy + sz * 0.24f, r, fgPaint)
                canvas.drawCircle(cx + sz * 0.14f, cy + sz * 0.24f, r, fgPaint)
            }

            BadgeKind.CLOCK -> {
                bgPaint.color = Color.parseColor("#E0E7FF")
                canvas.drawRoundRect(rect, radius, radius, bgPaint)
                strokePaint.color = Color.parseColor("#4F46E5")
                strokePaint.strokeWidth = sz * 0.085f
                canvas.drawCircle(cx, cy, sz * 0.26f, strokePaint)
                canvas.drawLine(cx, cy, cx, cy - sz * 0.14f, strokePaint)
                canvas.drawLine(cx, cy, cx + sz * 0.12f, cy + sz * 0.06f, strokePaint)
            }

            BadgeKind.VLC -> {
                bgPaint.color = Color.parseColor("#FFEDD5")
                canvas.drawRoundRect(rect, radius, radius, bgPaint)
                fgPaint.color = Color.parseColor("#EA580C")
                val cone = Path().apply {
                    moveTo(cx, top + sz * 0.20f)
                    lineTo(cx + sz * 0.24f, top + sz * 0.76f)
                    lineTo(cx - sz * 0.24f, top + sz * 0.76f)
                    close()
                }
                canvas.drawPath(cone, fgPaint)
                fgPaint.color = Color.WHITE
                canvas.drawRect(cx - sz * 0.14f, cy + sz * 0.02f, cx + sz * 0.14f, cy + sz * 0.11f, fgPaint)
            }

            BadgeKind.CAMERA -> {
                bgPaint.color = Color.parseColor("#E0E7FF")
                canvas.drawRoundRect(rect, radius, radius, bgPaint)
                strokePaint.color = Color.parseColor("#4F46E5")
                strokePaint.strokeWidth = sz * 0.085f
                val body = RectF(cx - sz * 0.26f, cy - sz * 0.16f, cx + sz * 0.26f, cy + sz * 0.20f)
                canvas.drawRoundRect(body, sz * 0.08f, sz * 0.08f, strokePaint)
                canvas.drawCircle(cx, cy + sz * 0.02f, sz * 0.10f, strokePaint)
            }

            BadgeKind.FILES -> {
                bgPaint.color = Color.parseColor("#FEF3C7")
                canvas.drawRoundRect(rect, radius, radius, bgPaint)
                fgPaint.color = Color.parseColor("#D97706")
                val tab = RectF(cx - sz * 0.26f, cy - sz * 0.20f, cx - sz * 0.02f, cy - sz * 0.08f)
                canvas.drawRoundRect(tab, sz * 0.05f, sz * 0.05f, fgPaint)
                val folder = RectF(cx - sz * 0.26f, cy - sz * 0.12f, cx + sz * 0.26f, cy + sz * 0.20f)
                canvas.drawRoundRect(folder, sz * 0.08f, sz * 0.08f, fgPaint)
            }

            BadgeKind.PHONE -> {
                bgPaint.color = Color.parseColor("#DCFCE7")
                canvas.drawRoundRect(rect, radius, radius, bgPaint)
                strokePaint.color = Color.parseColor("#16A34A")
                strokePaint.strokeWidth = sz * 0.10f
                val phoneArc = RectF(cx - sz * 0.20f, cy - sz * 0.20f, cx + sz * 0.20f, cy + sz * 0.20f)
                canvas.drawArc(phoneArc, 125f, 110f, false, strokePaint)
            }

            BadgeKind.TAP -> {
                bgPaint.color = Color.parseColor("#E0F2FE")
                canvas.drawRoundRect(rect, radius, radius, bgPaint)
                strokePaint.color = Color.parseColor("#0095F6")
                strokePaint.strokeWidth = sz * 0.08f
                canvas.drawCircle(cx, cy, sz * 0.22f, strokePaint)
                fgPaint.color = Color.parseColor("#0095F6")
                canvas.drawCircle(cx, cy, sz * 0.09f, fgPaint)
            }

            BadgeKind.SECURITY -> {
                bgPaint.color = Color.parseColor("#D1FAE5")
                canvas.drawRoundRect(rect, radius, radius, bgPaint)
                fgPaint.color = Color.parseColor("#059669")
                val shield = Path().apply {
                    moveTo(cx, cy - sz * 0.25f)
                    lineTo(cx + sz * 0.21f, cy - sz * 0.15f)
                    lineTo(cx + sz * 0.18f, cy + sz * 0.08f)
                    lineTo(cx, cy + sz * 0.26f)
                    lineTo(cx - sz * 0.18f, cy + sz * 0.08f)
                    lineTo(cx - sz * 0.21f, cy - sz * 0.15f)
                    close()
                }
                canvas.drawPath(shield, fgPaint)
            }

            BadgeKind.CODE -> {
                bgPaint.color = Color.parseColor("#EDE9FE")
                canvas.drawRoundRect(rect, radius, radius, bgPaint)
                val txtPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = Color.parseColor("#7C3AED")
                    textSize = sz * 0.44f
                    typeface = Typeface.MONOSPACE
                    isFakeBoldText = true
                    textAlign = Paint.Align.CENTER
                }
                val fm = txtPaint.fontMetrics
                canvas.drawText("</>", cx, cy - (fm.ascent + fm.descent) * 0.5f, txtPaint)
            }

            BadgeKind.SEARCH -> {
                bgPaint.color = Color.parseColor("#DBEAFE")
                canvas.drawRoundRect(rect, radius, radius, bgPaint)
                strokePaint.color = Color.parseColor("#0095F6")
                strokePaint.strokeWidth = sz * 0.09f
                canvas.drawCircle(cx - sz * 0.05f, cy - sz * 0.05f, sz * 0.17f, strokePaint)
                canvas.drawLine(cx + sz * 0.08f, cy + sz * 0.08f, cx + sz * 0.24f, cy + sz * 0.24f, strokePaint)
            }

            BadgeKind.SPARK_AI -> {
                bgPaint.shader = LinearGradient(
                    left, top, left + sz, top + sz,
                    Color.parseColor("#0095F6"),
                    Color.parseColor("#7C3AED"),
                    Shader.TileMode.CLAMP
                )
                canvas.drawRoundRect(rect, radius, radius, bgPaint)
                drawFourPointSpark(canvas, cx, cy, sz * 0.28f, Color.WHITE)
            }
        }
    }

    /**
     * Tier 3 Corner Action Sub-Badge (13dp circular pill at bottom-right of the squircle icon)
     * indicating the live step action (`watching`, `tapping`, `typing`, `coding`, `searching`,
     * `playing`, `security`).
     */
    fun drawActionSubBadge(
        canvas: Canvas,
        width: Float,
        height: Float,
        actionKind: ActionKind,
        surfaceRingColor: Int = Color.WHITE
    ) {
        if (actionKind == ActionKind.NONE) return
        val sz = min(width, height)
        if (sz < 16f) return
        val r = (sz * 0.22f).coerceIn(5.5f, 16f)
        val cx = width - r - 0.5f
        val cy = height - r - 0.5f

        val badgeColor = when (actionKind) {
            ActionKind.WATCHING -> Color.parseColor("#0284C7")
            ActionKind.TAPPING -> Color.parseColor("#0095F6")
            ActionKind.TYPING -> Color.parseColor("#7C3AED")
            ActionKind.CODING -> Color.parseColor("#1E293B")
            ActionKind.SEARCHING -> Color.parseColor("#2563EB")
            ActionKind.PLAYING -> Color.parseColor("#16A34A")
            ActionKind.SECURITY -> Color.parseColor("#059669")
            ActionKind.NONE -> return
        }

        val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            color = surfaceRingColor
        }
        canvas.drawCircle(cx, cy, r + (r * 0.22f).coerceAtLeast(1.5f), ringPaint)

        val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            color = badgeColor
        }
        canvas.drawCircle(cx, cy, r, fillPaint)

        val fgFill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            color = Color.WHITE
        }
        val fgStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
            strokeWidth = (r * 0.22f).coerceAtLeast(1.1f)
            color = Color.WHITE
        }

        when (actionKind) {
            ActionKind.WATCHING -> {
                val eye = Path().apply {
                    moveTo(cx - r * 0.56f, cy)
                    quadTo(cx, cy - r * 0.48f, cx + r * 0.56f, cy)
                    quadTo(cx, cy + r * 0.48f, cx - r * 0.56f, cy)
                    close()
                }
                canvas.drawPath(eye, fgStroke)
                canvas.drawCircle(cx, cy, r * 0.18f, fgFill)
            }
            ActionKind.TAPPING -> {
                val arrow = Path().apply {
                    moveTo(cx - r * 0.30f, cy - r * 0.42f)
                    lineTo(cx - r * 0.30f, cy + r * 0.34f)
                    lineTo(cx - r * 0.04f, cy + r * 0.16f)
                    lineTo(cx + r * 0.18f, cy + r * 0.42f)
                    lineTo(cx + r * 0.32f, cy + r * 0.32f)
                    lineTo(cx + r * 0.08f, cy + r * 0.08f)
                    lineTo(cx + r * 0.38f, cy + r * 0.08f)
                    close()
                }
                canvas.drawPath(arrow, fgFill)
            }
            ActionKind.TYPING -> {
                val kb = RectF(cx - r * 0.50f, cy - r * 0.32f, cx + r * 0.50f, cy + r * 0.32f)
                canvas.drawRoundRect(kb, r * 0.14f, r * 0.14f, fgStroke)
                canvas.drawLine(cx - r * 0.26f, cy + r * 0.10f, cx + r * 0.26f, cy + r * 0.10f, fgStroke)
            }
            ActionKind.CODING -> {
                val chev = Path().apply {
                    moveTo(cx - r * 0.35f, cy - r * 0.28f)
                    lineTo(cx - r * 0.05f, cy)
                    lineTo(cx - r * 0.35f, cy + r * 0.28f)
                }
                canvas.drawPath(chev, fgStroke)
                canvas.drawLine(cx + r * 0.04f, cy + r * 0.26f, cx + r * 0.38f, cy + r * 0.26f, fgStroke)
            }
            ActionKind.SEARCHING -> {
                canvas.drawCircle(cx - r * 0.10f, cy - r * 0.10f, r * 0.30f, fgStroke)
                canvas.drawLine(cx + r * 0.12f, cy + r * 0.12f, cx + r * 0.42f, cy + r * 0.42f, fgStroke)
            }
            ActionKind.PLAYING -> {
                val tri = Path().apply {
                    moveTo(cx - r * 0.24f, cy - r * 0.36f)
                    lineTo(cx + r * 0.42f, cy)
                    lineTo(cx - r * 0.24f, cy + r * 0.36f)
                    close()
                }
                canvas.drawPath(tri, fgFill)
            }
            ActionKind.SECURITY -> {
                val sh = Path().apply {
                    moveTo(cx, cy - r * 0.46f)
                    lineTo(cx + r * 0.38f, cy - r * 0.26f)
                    lineTo(cx + r * 0.32f, cy + r * 0.16f)
                    lineTo(cx, cy + r * 0.48f)
                    lineTo(cx - r * 0.32f, cy + r * 0.16f)
                    lineTo(cx - r * 0.38f, cy - r * 0.26f)
                    close()
                }
                canvas.drawPath(sh, fgFill)
            }
            ActionKind.NONE -> Unit
        }
    }

    fun drawFourPointSpark(canvas: Canvas, cx: Float, cy: Float, r: Float, color: Int) {
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            this.color = color
        }
        val inner = r * 0.26f
        val path = Path().apply {
            moveTo(cx, cy - r)
            quadTo(cx + inner * 0.45f, cy - inner * 0.45f, cx + r, cy)
            quadTo(cx + inner * 0.45f, cy + inner * 0.45f, cx, cy + r)
            quadTo(cx - inner * 0.45f, cy + inner * 0.45f, cx - r, cy)
            quadTo(cx - inner * 0.45f, cy - inner * 0.45f, cx, cy - r)
            close()
        }
        canvas.drawPath(path, paint)
    }
}

/**
 * Lightweight Android View displaying a resolved hybrid App/Task icon badge + optional 13dp
 * circular corner Action Sub-Badge in the floating HUD.
 */
class AgyIconBadgeView(context: Context) : View(context) {
    private var resolvedIcon: AgyAppIconResolver.ResolvedIcon =
        AgyAppIconResolver.resolve(context = null)
    private var ringColor: Int = Color.WHITE

    fun setIcon(icon: AgyAppIconResolver.ResolvedIcon, subBadgeRingColor: Int = Color.WHITE) {
        if (resolvedIcon.key == icon.key &&
            resolvedIcon.appBitmap === icon.appBitmap &&
            resolvedIcon.actionKind == icon.actionKind &&
            ringColor == subBadgeRingColor
        ) {
            return
        }
        resolvedIcon = icon
        ringColor = subBadgeRingColor
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val subPad = if (resolvedIcon.actionKind != AgyAppIconResolver.ActionKind.NONE) {
            (width.coerceAtMost(height) * 0.08f)
        } else 0f
        if (subPad > 0f) {
            canvas.save()
            AgyAppIconResolver.drawBadgeOnCanvas(
                canvas,
                width.toFloat() - subPad,
                height.toFloat() - subPad,
                resolvedIcon
            )
            canvas.restore()
            AgyAppIconResolver.drawActionSubBadge(
                canvas = canvas,
                width = width.toFloat(),
                height = height.toFloat(),
                actionKind = resolvedIcon.actionKind,
                surfaceRingColor = ringColor
            )
        } else {
            AgyAppIconResolver.drawBadgeOnCanvas(canvas, width.toFloat(), height.toFloat(), resolvedIcon)
        }
    }
}
