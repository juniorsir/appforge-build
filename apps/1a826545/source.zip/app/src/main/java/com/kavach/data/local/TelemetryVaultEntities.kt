package com.kavach.data.local

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

object VaultSyncStatus {
    const val PENDING = "PENDING"
    const val SYNCED = "SYNCED"
}

object VaultCategory {
    const val LOCATION = "LOCATION"
    const val APP = "APP"
    const val UNLOCK = "UNLOCK"
    const val NOTIFICATION = "NOTIFICATION"
    const val DNS = "DNS"
    const val POWER = "POWER"
    const val NETWORK = "NETWORK"
}

@Entity(
    tableName = "timeline_events",
    indices = [
        Index(value = ["timestamp"]),
        Index(value = ["category", "timestamp"]),
        Index(value = ["syncStatus", "timestamp"]),
        Index(value = ["expiresAt"])
    ]
)
data class TimelineEventEntity(
    @PrimaryKey val id: String,
    val timestamp: Long,
    val category: String,
    val subType: String,
    val title: String,
    val detail: String,
    val packageName: String = "",
    val domain: String = "",
    val severity: String = "INFO", // INFO, WARN, BLOCKED, ALERT
    val metadataJson: String = "{}",
    val syncStatus: String = VaultSyncStatus.PENDING,
    val syncedAt: Long? = null,
    val expiresAt: Long? = null
)

@Entity(
    tableName = "location_points",
    indices = [
        Index(value = ["timestamp"]),
        Index(value = ["syncStatus", "timestamp"]),
        Index(value = ["expiresAt"])
    ]
)
data class LocationPointEntity(
    @PrimaryKey val id: String,
    val timestamp: Long,
    val latitude: Double,
    val longitude: Double,
    val altitude: Double = 0.0,
    val accuracyMeters: Float = 0f,
    val speedMps: Float = 0f,
    val bearingDegrees: Float = 0f,
    val provider: String = "gps",
    val batteryPercent: Int = -1,
    val networkTransport: String = "UNKNOWN",
    val distanceFromPrevMeters: Float = 0f,
    val syncStatus: String = VaultSyncStatus.PENDING,
    val syncedAt: Long? = null,
    val expiresAt: Long? = null
)

@Entity(
    tableName = "device_snapshots",
    indices = [
        Index(value = ["timestamp"]),
        Index(value = ["syncStatus", "timestamp"]),
        Index(value = ["expiresAt"])
    ]
)
data class DeviceSnapshotEntity(
    @PrimaryKey val id: String,
    val timestamp: Long,
    val batteryPercent: Int,
    val isCharging: Boolean,
    val batteryTempC: Float,
    val networkConnected: Boolean,
    val networkTransport: String,
    val wifiSsid: String = "",
    val wifiRssiDbm: Int = 0,
    val cellularType: String = "",
    val foregroundPackage: String = "",
    val isInteractive: Boolean = true,
    val syncStatus: String = VaultSyncStatus.PENDING,
    val syncedAt: Long? = null,
    val expiresAt: Long? = null
)

@Entity(tableName = "sync_watermarks")
data class SyncWatermarkEntity(
    @PrimaryKey val id: String = "default",
    val lastSyncAttemptAt: Long = 0L,
    val lastSuccessfulSyncAt: Long = 0L,
    val totalSyncedEvents: Long = 0L,
    val totalSyncedLocations: Long = 0L,
    val totalSyncedSnapshots: Long = 0L,
    val lastSyncBatchSummary: String = "",
    val lastPrunedAt: Long = 0L,
    val totalPrunedCount: Long = 0L
)
