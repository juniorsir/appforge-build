package com.kavach.domain.repository

import com.kavach.domain.model.Transcript
import kotlinx.coroutines.flow.StateFlow

interface SessionTranscriptRepository {
    fun getTranscriptsForSession(sessionId: String): StateFlow<List<Transcript>>
    suspend fun saveTranscript(transcript: Transcript)
    suspend fun deleteTranscriptsForSession(sessionId: String)
}
