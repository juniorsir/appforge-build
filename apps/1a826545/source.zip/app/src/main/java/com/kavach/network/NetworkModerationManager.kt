package com.kavach.network

import android.content.Context
import android.net.TrafficStats
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import com.kavach.capabilities.notifications.NotificationRepository
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ConcurrentLinkedDeque
import java.util.concurrent.TimeUnit
import kotlin.math.roundToInt
import android.os.Environment

data class NetworkModerationStatusUi(
    val isVpnActive: Boolean = false,
    val totalIntercepted: Long = 0L,
    val totalBlocked: Long = 0L,
    val blacklistedDomainsCount: Int = 0,
    val blacklistedIpsCount: Int = 0,
    val lastBlockedTarget: String? = null,
    val lastBlockedTimestamp: Long = 0L
)

data class NetworkAuditLog(
    val timestamp: Long,
    val domain: String,
    val queryType: String,
    val action: String, // "BLOCKED" or "ALLOWED"
    val reason: String,
    val clientIp: String = "127.0.0.1",
    val packageName: String = ""
)

/**
 * Manages network monitoring, domain/IP blacklists, category blocklists,
 * per-domain traffic analytics, live bandwidth speed metering, and active diagnostics
 * (Ping, DNS Lookup, TCP Port Check) for Aero's Internet Controller Suite.
 */
class NetworkModerationManager(
    private val context: Context,
    private val notificationRepository: NotificationRepository? = null
) {
    private val TAG = "NetworkModeration"
    private val mainHandler = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO + CoroutineExceptionHandler { _, _ -> })
    val perAppMonitor = PerAppNetworkMonitor(context)

    companion object {
        @Volatile
        var activeInstance: NetworkModerationManager? = null
            private set
    }

    private val prefs = context.getSharedPreferences("aero_net_moderation_prefs", Context.MODE_PRIVATE)

    private val blacklistedDomains = ConcurrentHashMap.newKeySet<String>().apply {
        add("doubleclick.net")
        add("telemetry.badguy.com")
        add("ads.example.com")
        add("tracker.analytics-tracker.com")
        add("malware-domain-alert.org")
    }

    private val blacklistedIps = ConcurrentHashMap.newKeySet<String>().apply {
        add("198.51.100.1")
        add("203.0.113.5")
    }

    // Curated Category Blocklist Presets
    private val categoryDomainPresets: Map<String, Set<String>> = mapOf(
        "ADS" to setOf(
            "doubleclick.net", "googlesyndication.com", "googleadservices.com",
            "adservice.google.com", "adnxs.com", "taboola.com", "outbrain.com",
            "criteo.com", "pubmatic.com", "rubiconproject.com", "openx.net",
            "adsrvr.org", "advertising.com", "unityads.unity3d.com", "applovin.com"
        ),
        "TRACKERS" to setOf(
            "google-analytics.com", "ssl.google-analytics.com", "mixpanel.com",
            "segment.io", "segment.com", "amplitude.com", "hotjar.com",
            "fullstory.com", "appsflyer.com", "adjust.com", "branch.io",
            "scorecardresearch.com", "quantserve.com", "newrelic.com", "bugsnag.com"
        ),
        "MALWARE" to setOf(
            "malware-domain-alert.org", "telemetry.badguy.com", "phishing-login-verify.com",
            "cryptominer-pool.org", "botnet-c2-sinkhole.net", "evil-payload-drop.net",
            "ransomware-tracker.org", "trojan-updater.com"
        ),
        "ADULT" to setOf(
            "pornhub.com", "phncdn.com", "xvideos.com", "xv-cdn.com", "xnxx.com", "xnxx-cdn.com",
            "redtube.com", "youporn.com", "xhamster.com", "xhcdn.com", "spankbang.com",
            "onlyfans.com", "chaturbate.com", "brazzers.com", "eporner.com", "stripchat.com",
            "nhentai.net", "literotica.com", "hitomi.la", "e-hentai.org", "exhentai.org",
            "f95zone.to", "rule34.xxx", "gelbooru.com", "danbooru.donmai.us", "manhwa18.cc",
            "erome.com", "redgifs.com", "motherless.com", "nutaku.net", "dlsite.com", "lushstories.com"
        ),
        "SOCIAL" to setOf(
            "tiktok.com", "tiktokv.com", "tiktokcdn.com", "musical.ly", "instagram.com",
            "cdninstagram.com", "facebook.com", "fb.com", "fbcdn.net", "snapchat.com",
            "threads.net", "pinterest.com", "reddit.com", "redd.it", "twitter.com", "x.com", "twimg.com"
        ),
        "GAMBLING" to setOf(
            "bet365.com", "draftkings.com", "fanduel.com", "pokerstars.com",
            "888casino.com", "betway.com", "williamhill.com", "stake.com",
            "bovada.lv", "unibet.com", "1xbet.com", "parimatch.com", "roobet.com"
        )
    )

    private val enabledCategories = ConcurrentHashMap.newKeySet<String>().apply {
        add("ADS")
        add("TRACKERS")
        add("MALWARE")
        add("ADULT")
    }

    private val autoLearnedAdultDomains = ConcurrentHashMap<String, String>() // domain -> trigger reason

    val siteMetadataAnalyzer = SiteMetadataAnalyzer { domain, rootDomain, verdict, companionCdns ->
        var newlyAdded = false
        if (rootDomain.isNotEmpty() && blacklistedDomains.add(rootDomain)) {
            newlyAdded = true
        }
        if (domain.isNotEmpty() && domain != rootDomain && blacklistedDomains.add(domain)) {
            newlyAdded = true
        }
        for (cdn in companionCdns) {
            if (cdn.isNotEmpty() && blacklistedDomains.add(cdn)) {
                autoLearnedAdultDomains[cdn] = "AUTO_COMPANION_CDN (with $rootDomain)"
                newlyAdded = true
            }
        }
        val reasonSummary = "AUTO_${verdict.triggerSource} (score=${verdict.confidenceScore}%)"
        autoLearnedAdultDomains[rootDomain] = reasonSummary
        if (domain != rootDomain) {
            autoLearnedAdultDomains[domain] = reasonSummary
        }

        if (newlyAdded) {
            saveModerationPrefs()
            updateStatus()
            com.kavach.services.AeroNetworkModeratorVpnService.activeInstance?.reloadVpnInterface()
            perAppMonitor.enforceBrowserKickForAutoBlockedDomain(domain, rootDomain, reasonSummary)
        }
    }

    @Volatile
    var activeDnsPreset: String = "family"

    @Volatile
    var isBlockScreenEnabled: Boolean = true

    @Volatile
    var blockScreenCustomMessage: String = "Restricted content is not allowed on this device"

    @Volatile
    var blockScreenAutoDismissSec: Int = 6

    var floatingOverlayManager: com.kavach.ui.overlay.FloatingOverlayManager? = null

    @Volatile
    private var lastVisualBlockTimeMs: Long = 0L

    @Volatile
    private var lastVisualBlockKey: String = ""

    fun triggerVisualBlockScreen(
        domain: String = "restricted-site.com",
        reason: String = "Restricted Category Match",
        category: String = "RESTRICTED",
        isPreview: Boolean = false
    ): Boolean {
        if (!isBlockScreenEnabled && !isPreview) return false
        val cleanDomain = normalizeDomainInput(domain).ifBlank { domain }
        val effectiveMsg = blockScreenCustomMessage.ifBlank { "Restricted content is not allowed on this device" }
        val dismissSec = if (blockScreenAutoDismissSec > 0) blockScreenAutoDismissSec else 6

        val now = System.currentTimeMillis()
        val dedupKey = "$cleanDomain|$effectiveMsg|$isPreview"
        if (dedupKey == lastVisualBlockKey && (now - lastVisualBlockTimeMs) < 400L) {
            return true
        }
        lastVisualBlockKey = dedupKey
        lastVisualBlockTimeMs = now

        val titleText = if (isPreview) "🛡️ Block Screen Preview: $cleanDomain" else "🛡️ Access Blocked: $cleanDomain"
        val bodyText = "$effectiveMsg\nPolicy: $reason ($category)"

        mainHandler.post {
            // Ensure no floating overlay remains active alongside BlockScreenActivity (prevents double overlays)
            try {
                floatingOverlayManager?.hideFloating("block_screen_alert")
            } catch (_: Throwable) {}

            var launchedActivity = false
            try {
                val activityIntent = android.content.Intent(context, com.kavach.ui.overlay.BlockScreenActivity::class.java).apply {
                    addFlags(
                        android.content.Intent.FLAG_ACTIVITY_NEW_TASK or
                            android.content.Intent.FLAG_ACTIVITY_CLEAR_TOP or
                            android.content.Intent.FLAG_ACTIVITY_SINGLE_TOP
                    )
                    putExtra("BLOCK_DOMAIN", cleanDomain)
                    putExtra("BLOCK_REASON", reason)
                    putExtra("BLOCK_CATEGORY", category)
                    putExtra("BLOCK_MESSAGE", effectiveMsg)
                    putExtra("BLOCK_DISMISS_SEC", dismissSec)
                    putExtra("IS_PREVIEW", isPreview)
                }
                context.startActivity(activityIntent)
                launchedActivity = true
            } catch (e: Exception) {
                Log.w(TAG, "Could not launch BlockScreenActivity: ${e.message}")
            }

            if (!launchedActivity) {
                try {
                    val mgr = floatingOverlayManager
                    if (mgr != null && mgr.hasPermission()) {
                        mgr.showFloating(
                            com.kavach.ui.overlay.FloatingOverlayManager.FloatingOptions(
                                floatingId = "block_screen_alert",
                                title = titleText,
                                text = bodyText,
                                subText = "Tap ✕ to dismiss",
                                type = "CARD",
                                backgroundColor = "#F0111722",
                                textColor = "#FFFFFF",
                                accentColor = "#F43F5E",
                                textSize = 13.5f,
                                cornerRadius = 16,
                                alpha = 0.98f,
                                gravity = "CENTER",
                                x = 0,
                                y = 0,
                                widthDp = 340,
                                isDraggable = false,
                                showCloseButton = true,
                                autoDismissSeconds = dismissSec
                            )
                        )
                    } else {
                        android.widget.Toast.makeText(
                            context,
                            "🛡️ $cleanDomain: $effectiveMsg",
                            android.widget.Toast.LENGTH_LONG
                        ).show()
                    }
                } catch (e: Exception) {
                    Log.w(TAG, "Error displaying fallback block screen overlay", e)
                }
            }

            if (!isPreview) {
                try {
                    notificationRepository?.showNotification(
                        title = "🛡️ Access Restricted: $cleanDomain",
                        message = "$effectiveMsg ($reason)"
                    )
                } catch (_: Throwable) {}
            }
        }
        return true
    }

    fun dismissVisualBlockScreen(): Boolean {
        mainHandler.post {
            try {
                com.kavach.ui.overlay.BlockScreenActivity.dismissIfActive()
            } catch (_: Throwable) {}
            try {
                floatingOverlayManager?.hideFloating("block_screen_alert")
            } catch (_: Throwable) {}
        }
        return true
    }

    init {
        activeInstance = this
        prefs.getStringSet("saved_custom_domains", null)?.let { saved ->
            blacklistedDomains.addAll(saved)
        }
        prefs.getStringSet("saved_enabled_categories", null)?.let { savedCats ->
            enabledCategories.clear()
            enabledCategories.addAll(savedCats)
        }
        prefs.getString("saved_dns_preset", null)?.let { savedPreset ->
            if (savedPreset.isNotBlank()) activeDnsPreset = savedPreset
        }
        isBlockScreenEnabled = prefs.getBoolean("saved_block_screen_enabled", true)
        val savedMsg = prefs.getString("saved_block_screen_msg", null)
        blockScreenCustomMessage = if (!savedMsg.isNullOrBlank()) {
            savedMsg.trim()
        } else {
            "Restricted content is not allowed on this device"
        }
        blockScreenAutoDismissSec = prefs.getInt("saved_block_screen_dismiss_sec", 6)

        prefs.getStringSet("saved_auto_learned_domains", null)?.forEach { entry ->
            val parts = entry.split("|", limit = 2)
            if (parts.isNotEmpty() && parts[0].isNotBlank()) {
                autoLearnedAdultDomains[parts[0]] = parts.getOrNull(1) ?: "AUTO_CLASSIFIER"
                blacklistedDomains.add(parts[0])
            }
        }
        // Background self-healing check: if OS Private DNS is stuck on a hostname that blocks trycloudflare.com or fails on this ISP, reset to Automatic
        scope.launch {
            try {
                delay(1500)
                checkAndAutoHealBrokenSystemDns()
                if (android.net.VpnService.prepare(context) == null &&
                    (enabledCategories.contains("ADULT") || activeDnsPreset in listOf("family", "adguard-family", "adguard"))
                ) {
                    com.kavach.services.AeroNetworkModeratorVpnService.startServiceDirect(context)
                }
            } catch (_: Throwable) {}
        }
    }

    fun trimCaches(aggressive: Boolean = false) {
        perAppMonitor.trimCaches(aggressive)
        siteMetadataAnalyzer.trimCaches(aggressive)
        com.kavach.security.AdultContentShieldManager.activeInstance?.trimCaches(aggressive)
        if (aggressive) {
            domainQueryCounts.clear()
            domainBlockedCounts.clear()
            lastAlertTimePerDomain.clear()
            while (auditLogs.size > 60) {
                auditLogs.pollFirst()
            }
            return
        }
        val cap = 350
        if (domainQueryCounts.size > cap) {
            val it = domainQueryCounts.keys.iterator()
            var n = domainQueryCounts.size - 250
            while (it.hasNext() && n > 0) {
                it.next(); it.remove(); n--
            }
        }
        if (domainBlockedCounts.size > cap) {
            val it = domainBlockedCounts.keys.iterator()
            var n = domainBlockedCounts.size - 250
            while (it.hasNext() && n > 0) {
                it.next(); it.remove(); n--
            }
        }
        if (lastAlertTimePerDomain.size > 150) {
            val cutoff = System.currentTimeMillis() - 60_000L
            lastAlertTimePerDomain.entries.removeIf { it.value < cutoff }
        }
    }

    private fun saveModerationPrefs() {
        try {
            val autoSet = autoLearnedAdultDomains.entries.map { "${it.key}|${it.value}" }.toSet()
            prefs.edit()
                .putStringSet("saved_custom_domains", blacklistedDomains.toSet())
                .putStringSet("saved_enabled_categories", enabledCategories.toSet())
                .putStringSet("saved_auto_learned_domains", autoSet)
                .putString("saved_dns_preset", activeDnsPreset)
                .putBoolean("saved_block_screen_enabled", isBlockScreenEnabled)
                .putString("saved_block_screen_msg", blockScreenCustomMessage)
                .putInt("saved_block_screen_dismiss_sec", blockScreenAutoDismissSec)
                .apply()
        } catch (_: Throwable) {}
    }

    fun isAdultCategoryEnabled(): Boolean =
        enabledCategories.contains("ADULT") || activeDnsPreset in listOf("family", "adguard-family")

    fun getBlockScreenConfig(): JSONObject {
        val effectiveMsg = blockScreenCustomMessage.ifBlank { "Restricted content is not allowed on this device" }
        return JSONObject().apply {
            put("success", true)
            put("enabled", isBlockScreenEnabled)
            put("customMessage", effectiveMsg)
            put("autoDismissSeconds", blockScreenAutoDismissSec)
            put("hasOverlayPermission", floatingOverlayManager?.hasPermission() ?: false)
        }
    }

    fun setBlockScreenConfig(
        enabled: Boolean?,
        message: String?,
        dismissSec: Int?,
        preview: Boolean = false,
        previewDomain: String = "sample-blocked-domain.com",
        previewReason: String? = null,
        previewCategory: String = "PREVIEW"
    ): JSONObject {
        if (enabled != null) isBlockScreenEnabled = enabled
        var msgUpdated = false
        if (!message.isNullOrBlank()) {
            blockScreenCustomMessage = message.trim()
            msgUpdated = true
        }
        if (dismissSec != null && dismissSec in 0..60) blockScreenAutoDismissSec = dismissSec
        saveModerationPrefs()
        val shouldPreview = preview || msgUpdated
        if (shouldPreview) {
            triggerVisualBlockScreen(
                domain = previewDomain.ifBlank { "sample-blocked-domain.com" },
                reason = previewReason ?: if (msgUpdated) "Updated Message Preview" else "CLI Test Verification",
                category = previewCategory,
                isPreview = true
            )
        }
        return getBlockScreenConfig().apply {
            put("previewTriggered", shouldPreview)
        }
    }

    fun exportAuditLogs(format: String = "csv", includeAllowed: Boolean = true, limit: Int = 1000): JSONObject {
        val cleanFormat = format.trim().lowercase()
        val allLogs = auditLogs.toList().takeLast(limit.coerceIn(1, 5000)).reversed().filter {
            includeAllowed || it.action == "BLOCKED"
        }
        val count = allLogs.size
        val timestampStr = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val fileName = "dns_audit_log_$timestampStr.${if (cleanFormat == "json") "json" else "csv"}"

        val downloadDir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "AeroShare").apply {
            if (!exists()) mkdirs()
        }
        val targetFile = File(downloadDir, fileName)

        val contentStr = if (cleanFormat == "json") {
            val jsonArr = JSONArray()
            for (item in allLogs) {
                jsonArr.put(JSONObject().apply {
                    put("timestamp", item.timestamp)
                    put("datetime", SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date(item.timestamp)))
                    put("domain", item.domain)
                    put("action", item.action)
                    put("reason", item.reason)
                    put("queryType", item.queryType)
                    put("packageName", item.packageName)
                })
            }
            jsonArr.toString(2)
        } else {
            val sb = StringBuilder()
            sb.append("timestamp,datetime,domain,action,reason,queryType,packageName\n")
            for (item in allLogs) {
                val dt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date(item.timestamp))
                val safeDomain = item.domain.replace(",", ";")
                val safeReason = item.reason.replace(",", ";")
                val safePkg = item.packageName.replace(",", ";")
                sb.append("${item.timestamp},\"$dt\",\"$safeDomain\",${item.action},\"$safeReason\",${item.queryType},\"$safePkg\"\n")
            }
            sb.toString()
        }

        try {
            targetFile.writeText(contentStr, Charsets.UTF_8)
        } catch (_: Exception) {}

        return JSONObject().apply {
            put("success", true)
            put("format", cleanFormat)
            put("exportedCount", count)
            put("fileName", fileName)
            put("filePath", targetFile.absolutePath)
            put("fileSizeBytes", contentStr.toByteArray(Charsets.UTF_8).size)
            put("preview", contentStr.take(500))
        }
    }

    // Per-domain & Per-category traffic hit analytics
    private val domainQueryCounts = ConcurrentHashMap<String, Long>()
    private val domainBlockedCounts = ConcurrentHashMap<String, Long>()
    private val categoryBlockedCounts = ConcurrentHashMap<String, Long>()

    // Live Bandwidth & Speed Meter sampling state
    @Volatile
    private var lastSampleTimeMs: Long = SystemClock.elapsedRealtime()
    @Volatile
    private var lastRxBytes: Long = TrafficStats.getTotalRxBytes().coerceAtLeast(0L)
    @Volatile
    private var lastTxBytes: Long = TrafficStats.getTotalTxBytes().coerceAtLeast(0L)
    @Volatile
    private var latestRxBps: Long = 0L
    @Volatile
    private var latestTxBps: Long = 0L

    private val auditLogs = ConcurrentLinkedDeque<NetworkAuditLog>()
    private val maxAuditLogs = 250

    private val lastAlertTimePerDomain = ConcurrentHashMap<String, Long>()
    private val alertDeduplicationWindowMs = 3000L

    private val _status = MutableStateFlow(
        NetworkModerationStatusUi(
            blacklistedDomainsCount = getEffectiveBlockedDomainCount(),
            blacklistedIpsCount = blacklistedIps.size
        )
    )
    val status: StateFlow<NetworkModerationStatusUi> = _status.asStateFlow()

    private var totalInterceptedQueries = 0L
    private var totalBlockedQueries = 0L

    private fun getEffectiveBlockedDomainCount(): Int {
        val combined = HashSet<String>(blacklistedDomains)
        for (cat in enabledCategories) {
            categoryDomainPresets[cat]?.let { combined.addAll(it) }
        }
        return combined.size
    }

    fun setVpnActive(active: Boolean) {
        _status.value = _status.value.copy(isVpnActive = active)
    }

    private val dohBootstrapDomains = setOf(
        "dns.google",
        "dns.google.com",
        "8888.google",
        "cloudflare-dns.com",
        "one.one.one.one",
        "1dot1dot1dot1.cloudflare-dns.com",
        "mozilla.cloudflare-dns.com",
        "doh.opendns.com",
        "dns.quad9.net",
        "dns.adguard.com",
        "doh.cleanbrowsing.org",
        "_dns.resolver.arpa"
    )

    private val companionCdnDomains = mapOf(
        "youtube.com" to listOf("youtu.be", "googlevideo.com", "ytimg.com", "youtubei.googleapis.com"),
        "youtu.be" to listOf("youtube.com", "googlevideo.com", "ytimg.com"),
        "instagram.com" to listOf("cdninstagram.com", "ig.me"),
        "facebook.com" to listOf("fb.com", "fbcdn.net", "fbsbx.com", "messenger.com"),
        "tiktok.com" to listOf("tiktokv.com", "tiktokcdn.com", "musical.ly", "byteoversea.com"),
        "twitter.com" to listOf("x.com", "twimg.com", "t.co"),
        "x.com" to listOf("twitter.com", "twimg.com", "t.co"),
        "reddit.com" to listOf("redd.it", "redditmedia.com", "redditstatic.com")
    )

    fun normalizeDomainInput(raw: String): String {
        var clean = raw.trim().lowercase()
        if (clean.startsWith("http://")) clean = clean.removePrefix("http://")
        if (clean.startsWith("https://")) clean = clean.removePrefix("https://")
        clean = clean.substringBefore("/").substringBefore("?").substringBefore("#").substringBefore(":")
        clean = clean.trimEnd('.')
        if (clean.startsWith("www.")) clean = clean.removePrefix("www.")
        if (clean.startsWith("m.")) clean = clean.removePrefix("m.")
        return clean.trim()
    }

    /**
     * Checks if a browser URL or domain matches any custom blacklist rule, enabled category preset,
     * or Per-App Network Firewall rule without incrementing DNS packet counters.
     */
    fun checkUrlOrDomainBlocked(rawUrlOrDomain: String, packageName: String = ""): Pair<Boolean, String> {
        if (packageName.isNotBlank() && perAppMonitor.isAppNetworkBlocked(packageName)) {
            return true to "APP_FIREWALL: blocked internet for '$packageName'"
        }
        // Check Multi-Channel Adult Content Shield (URL path, NSFW forums, reading/manga, search queries, adult APKs)
        com.kavach.security.AdultContentShieldManager.activeInstance
            ?.evaluateUrlOrSearchQuery(rawUrlOrDomain, packageName)
            ?.let { shieldVerdict ->
                if (shieldVerdict.blocked) {
                    return true to "ADULT_SHIELD_${shieldVerdict.channel}: ${shieldVerdict.reason}"
                }
            }

        val host = normalizeDomainInput(rawUrlOrDomain)
        if (host.isEmpty()) return false to ""

        for (b in blacklistedDomains) {
            val cleanB = normalizeDomainInput(b)
            if (cleanB.isNotEmpty() && (host == cleanB || host.endsWith(".$cleanB"))) {
                return true to "CUSTOM_BLACKLIST: matched '$cleanB'"
            }
        }
        for (cat in enabledCategories) {
            val presets = categoryDomainPresets[cat] ?: continue
            for (presetDomain in presets) {
                val cleanPreset = normalizeDomainInput(presetDomain)
                if (cleanPreset.isNotEmpty() && (host == cleanPreset || host.endsWith(".$cleanPreset"))) {
                    return true to "CATEGORY_$cat: matched '$cleanPreset'"
                }
            }
        }
        if (enabledCategories.contains("ADULT") ||
            com.kavach.security.AdultContentShieldManager.activeInstance?.strictModeEnabled == true
        ) {
            siteMetadataAnalyzer.evaluateFastDomainHeuristics(host)?.let { verdict ->
                return true to "AUTO_${verdict.triggerSource}: matched '${verdict.rootDomain}'"
            }
            siteMetadataAnalyzer.inspectDomainMetadataAsync(host)
        }
        return false to ""
    }

    /**
     * Checks if a queried domain matches any custom blacklist rule, enabled category preset,
     * Per-App Network Firewall rule, or Autonomous Adult Site Classifier.
     */
    fun shouldBlockDomain(rawDomain: String, srcPort: Int = 0): Pair<Boolean, String> {
        val domain = rawDomain.trim().lowercase().trimEnd('.')
        if (domain.isEmpty()) return false to ""

        // Prevent browsers (Chrome/Firefox/Brave) from upgrading to encrypted DoH so all DNS stays inspectable
        if (dohBootstrapDomains.any { domain == it || domain.endsWith(".$it") }) {
            return true to "DOH_BYPASS_PREVENTION"
        }

        val ownerPkg = perAppMonitor.resolveDnsPacketOwnerPackage(srcPort = srcPort)

        totalInterceptedQueries++
        domainQueryCounts[domain] = (domainQueryCounts[domain] ?: 0L) + 1L

        // 0. Per-App Network Firewall check
        if (ownerPkg.isNotBlank() && perAppMonitor.isAppNetworkBlocked(ownerPkg)) {
            domainBlockedCounts[domain] = (domainBlockedCounts[domain] ?: 0L) + 1L
            categoryBlockedCounts["APP_FIREWALL"] = (categoryBlockedCounts["APP_FIREWALL"] ?: 0L) + 1L
            val reason = "APP_FIREWALL: blocked internet for '$ownerPkg'"
            perAppMonitor.recordDomainQueryForApp(domain, ownerPkg, "BLOCKED", reason, "DNS_QUERY")
            recordBlock(domain, reason, ownerPkg)
            return true to "APP_FIREWALL"
        }

        // 1. Custom & Auto-Learned domain blacklist check
        for (b in blacklistedDomains) {
            val cleanB = b.trim().lowercase().trimEnd('.')
            if (domain == cleanB || domain.endsWith(".$cleanB")) {
                domainBlockedCounts[domain] = (domainBlockedCounts[domain] ?: 0L) + 1L
                val autoTag = autoLearnedAdultDomains[cleanB] ?: autoLearnedAdultDomains[domain]
                val catKey = if (autoTag != null) "ADULT" else "CUSTOM"
                categoryBlockedCounts[catKey] = (categoryBlockedCounts[catKey] ?: 0L) + 1L
                val reason = if (autoTag != null) "$autoTag: matched '$cleanB'" else "CUSTOM_BLACKLIST: matched '$cleanB'"
                perAppMonitor.recordDomainQueryForApp(domain, ownerPkg, "BLOCKED", reason, "DNS_QUERY")
                recordBlock(domain, reason, ownerPkg)
                return true to (autoTag ?: "CUSTOM_BLACKLIST")
            }
        }

        // 2. Enabled Category Blocklists check
        for (cat in enabledCategories) {
            val presets = categoryDomainPresets[cat] ?: continue
            for (presetDomain in presets) {
                val cleanPreset = presetDomain.trim().lowercase().trimEnd('.')
                if (domain == cleanPreset || domain.endsWith(".$cleanPreset")) {
                    domainBlockedCounts[domain] = (domainBlockedCounts[domain] ?: 0L) + 1L
                    categoryBlockedCounts[cat] = (categoryBlockedCounts[cat] ?: 0L) + 1L
                    val reason = "CATEGORY_$cat: matched '$cleanPreset'"
                    perAppMonitor.recordDomainQueryForApp(domain, ownerPkg, "BLOCKED", reason, "DNS_QUERY")
                    recordBlock(domain, reason, ownerPkg)
                    return true to "CATEGORY_$cat"
                }
            }
        }

        // 3. Autonomous Adult Site Classifier (Fast Heuristics + Async HTML <head> Metadata Scraper)
        if (enabledCategories.contains("ADULT")) {
            siteMetadataAnalyzer.recordRecentDnsQuery(domain)
            val heuristicVerdict = siteMetadataAnalyzer.evaluateFastDomainHeuristics(domain)
            if (heuristicVerdict != null && heuristicVerdict.isAdult) {
                domainBlockedCounts[domain] = (domainBlockedCounts[domain] ?: 0L) + 1L
                categoryBlockedCounts["ADULT"] = (categoryBlockedCounts["ADULT"] ?: 0L) + 1L
                val reason = "AUTO_${heuristicVerdict.triggerSource}: ${heuristicVerdict.matchedIndicators.firstOrNull().orEmpty()}"
                perAppMonitor.recordDomainQueryForApp(domain, ownerPkg, "BLOCKED", reason, "DNS_QUERY")
                recordBlock(domain, reason, ownerPkg)
                return true to "AUTO_${heuristicVerdict.triggerSource}"
            }
            // Launch non-blocking background HTML <head> metadata & RTA rating tag inspection
            siteMetadataAnalyzer.inspectDomainMetadataAsync(domain)
        }

        // Allowed
        perAppMonitor.recordDomainQueryForApp(domain, ownerPkg, "ALLOWED", "CLEAN", "DNS_QUERY")
        recordAllowed(domain, ownerPkg)
        if (domainQueryCounts.size > 400) {
            trimCaches(aggressive = false)
        }
        updateStatus()
        return false to ""
    }

    /**
     * Called by AeroNetworkModeratorVpnService when Cloudflare Family DNS (1.1.1.3 / 1.0.0.3)
     * returns a 0.0.0.0 sinkhole for a queried domain.
     */
    fun onFamilyDnsSinkholed(rawDomain: String, srcPort: Int = 0) {
        val domain = rawDomain.trim().lowercase().trimEnd('.')
        if (domain.isEmpty()) return
        val ownerPkg = perAppMonitor.resolveDnsPacketOwnerPackage(srcPort = srcPort)
        val verdict = siteMetadataAnalyzer.onFamilyDnsSinkholeDetected(domain)
        domainBlockedCounts[domain] = (domainBlockedCounts[domain] ?: 0L) + 1L
        categoryBlockedCounts["ADULT"] = (categoryBlockedCounts["ADULT"] ?: 0L) + 1L
        val reason = "AUTO_${verdict.triggerSource}: sinkholed by 1.1.1.3"
        perAppMonitor.recordDomainQueryForApp(domain, ownerPkg, "BLOCKED", reason, "DNS_QUERY")
        recordBlock(domain, reason, ownerPkg)
    }

    /**
     * On-demand Site Metadata & Adult Content Inspector API (/api/network/moderation/inspect-site).
     */
    fun inspectSiteMetadataJson(target: String): JSONObject {
        val verdict = siteMetadataAnalyzer.fetchAndAnalyzeSiteMetadata(target, checkFamilyDns = true)
        return verdict.toJson().apply {
            put("success", true)
            put("autoBlacklisted", verdict.isAdult)
            put("effectiveTotalBlockedDomains", getEffectiveBlockedDomainCount())
        }
    }

    /**
     * Checks if a target IP is in the blacklist.
     */
    fun shouldBlockIp(ip: String): Boolean {
        val cleanIp = ip.trim()
        if (blacklistedIps.contains(cleanIp)) {
            totalInterceptedQueries++
            domainQueryCounts[cleanIp] = (domainQueryCounts[cleanIp] ?: 0L) + 1L
            domainBlockedCounts[cleanIp] = (domainBlockedCounts[cleanIp] ?: 0L) + 1L
            categoryBlockedCounts["IP_BLACKLIST"] = (categoryBlockedCounts["IP_BLACKLIST"] ?: 0L) + 1L
            recordBlock(cleanIp, "IP_BLACKLIST")
            return true
        }
        return false
    }

    private fun recordBlock(target: String, reason: String, packageName: String = "") {
        totalBlockedQueries++
        val now = System.currentTimeMillis()

        val logEntry = NetworkAuditLog(
            timestamp = now,
            domain = target,
            queryType = "DNS_A",
            action = "BLOCKED",
            reason = reason,
            packageName = packageName
        )
        addAuditLog(logEntry)
        com.kavach.telemetry.OfflineTelemetryVaultManager.activeInstance?.recordDnsEvent(
            domain = target,
            action = "BLOCKED",
            reason = reason,
            packageName = packageName,
            queryType = "DNS_A"
        )

        _status.value = _status.value.copy(
            totalIntercepted = totalInterceptedQueries,
            totalBlocked = totalBlockedQueries,
            blacklistedDomainsCount = getEffectiveBlockedDomainCount(),
            blacklistedIpsCount = blacklistedIps.size,
            lastBlockedTarget = target,
            lastBlockedTimestamp = now
        )

        // Show Visual Block Screen overlay if enabled and foreground package is a browser/user app
        if (packageName.isBlank() || packageName.contains("chrome", ignoreCase = true) ||
            packageName.contains("browser", ignoreCase = true) || packageName.contains("firefox", ignoreCase = true)
        ) {
            triggerVisualBlockScreen(target, reason, "FIREWALL_POLICY")
        }

        // Notification alert with 3-second deduplication per domain
        val lastAlert = lastAlertTimePerDomain[target] ?: 0L
        if (now - lastAlert >= alertDeduplicationWindowMs) {
            lastAlertTimePerDomain[target] = now
            postSecurityAlert(target, reason)
        }
    }

    private fun recordAllowed(domain: String, packageName: String = "") {
        if (auditLogs.size >= maxAuditLogs && auditLogs.peekFirst()?.action == "ALLOWED") {
            auditLogs.pollFirst()
        }
        val logEntry = NetworkAuditLog(
            timestamp = System.currentTimeMillis(),
            domain = domain,
            queryType = "DNS_QUERY",
            action = "ALLOWED",
            reason = "CLEAN",
            packageName = packageName
        )
        addAuditLog(logEntry)
        com.kavach.telemetry.OfflineTelemetryVaultManager.activeInstance?.recordDnsEvent(
            domain = domain,
            action = "ALLOWED",
            reason = "CLEAN",
            packageName = packageName,
            queryType = "DNS_QUERY"
        )
    }

    private fun addAuditLog(entry: NetworkAuditLog) {
        auditLogs.addLast(entry)
        while (auditLogs.size > maxAuditLogs) {
            auditLogs.pollFirst()
        }
    }

    private fun postSecurityAlert(target: String, reason: String) {
        mainHandler.post {
            try {
                notificationRepository?.showNotification(
                    title = "🛡️ Blocked Blacklisted Target",
                    message = "Blocked request to '$target' ($reason)"
                )
            } catch (e: Exception) {
                Log.e(TAG, "Failed to post security alert notification", e)
            }
        }
    }

    private fun updateStatus() {
        _status.value = _status.value.copy(
            totalIntercepted = totalInterceptedQueries,
            totalBlocked = totalBlockedQueries,
            blacklistedDomainsCount = getEffectiveBlockedDomainCount(),
            blacklistedIpsCount = blacklistedIps.size
        )
    }

    // -------------------------------------------------------------------------
    // API Rule Manipulation Methods
    // -------------------------------------------------------------------------

    fun addBlacklistDomain(domain: String): JSONObject {
        val clean = normalizeDomainInput(domain)
        val res = JSONObject()
        if (clean.isEmpty()) {
            res.put("success", false)
            res.put("error", "Domain cannot be empty")
            return res
        }
        val added = blacklistedDomains.add(clean)
        val companionsAdded = JSONArray()
        companionCdnDomains[clean]?.forEach { comp ->
            if (blacklistedDomains.add(comp)) {
                companionsAdded.put(comp)
            }
        }
        saveModerationPrefs()
        updateStatus()

        // Reload VPN interface to flush Android's OS DNS cache immediately
        com.kavach.services.AeroNetworkModeratorVpnService.activeInstance?.reloadVpnInterface()

        res.put("success", true)
        res.put("domain", clean)
        res.put("companionDomainsBlocked", companionsAdded)
        res.put("action", if (added) "ADDED" else "ALREADY_EXISTS")
        res.put("totalBlacklistedDomains", getEffectiveBlockedDomainCount())
        return res
    }

    fun removeBlacklistDomain(domain: String): JSONObject {
        val rawTrim = domain.trim()
        val res = JSONObject()
        if (rawTrim.equals("all", ignoreCase = true) || rawTrim == "*") {
            val count = blacklistedDomains.size
            blacklistedDomains.clear()
            autoLearnedAdultDomains.clear()
            saveModerationPrefs()
            updateStatus()
            com.kavach.services.AeroNetworkModeratorVpnService.activeInstance?.reloadVpnInterface()
            res.put("success", true)
            res.put("domain", "ALL")
            res.put("clearedCount", count)
            res.put("action", "CLEARED_ALL")
            res.put("totalBlacklistedDomains", getEffectiveBlockedDomainCount())
            return res
        }

        val clean = normalizeDomainInput(domain)
        val removed = blacklistedDomains.remove(clean)
        autoLearnedAdultDomains.remove(clean)
        companionCdnDomains[clean]?.forEach { comp ->
            blacklistedDomains.remove(comp)
            autoLearnedAdultDomains.remove(comp)
        }
        saveModerationPrefs()
        updateStatus()
        com.kavach.services.AeroNetworkModeratorVpnService.activeInstance?.reloadVpnInterface()

        res.put("success", true)
        res.put("domain", clean)
        res.put("action", if (removed) "REMOVED" else "NOT_FOUND")
        res.put("totalBlacklistedDomains", getEffectiveBlockedDomainCount())
        return res
    }

    fun addBlacklistIp(ip: String): JSONObject {
        val clean = ip.trim()
        val res = JSONObject()
        if (clean.isEmpty()) {
            res.put("success", false)
            res.put("error", "IP address cannot be empty")
            return res
        }
        val added = blacklistedIps.add(clean)
        updateStatus()
        res.put("success", true)
        res.put("ip", clean)
        res.put("action", if (added) "ADDED" else "ALREADY_EXISTS")
        res.put("totalBlacklistedIps", blacklistedIps.size)
        return res
    }

    fun removeBlacklistIp(ip: String): JSONObject {
        val clean = ip.trim()
        val res = JSONObject()
        val removed = blacklistedIps.remove(clean)
        updateStatus()
        res.put("success", true)
        res.put("ip", clean)
        res.put("action", if (removed) "REMOVED" else "NOT_FOUND")
        res.put("totalBlacklistedIps", blacklistedIps.size)
        return res
    }

    fun getRules(): JSONObject {
        val res = JSONObject()
        val dArr = JSONArray()
        blacklistedDomains.sorted().forEach { dArr.put(it) }
        val autoObj = JSONObject()
        autoLearnedAdultDomains.entries.sortedBy { it.key }.forEach { (dom, reason) ->
            autoObj.put(dom, reason)
        }
        val ipArr = JSONArray()
        blacklistedIps.sorted().forEach { ipArr.put(it) }
        val catArr = JSONArray()
        val catDetailsObj = JSONObject()
        enabledCategories.sorted().forEach { cat ->
            catArr.put(cat)
            val presetDomains = categoryDomainPresets[cat]?.sorted() ?: emptyList()
            catDetailsObj.put(cat, JSONArray(presetDomains))
        }
        val blockedAppsArr = JSONArray()
        perAppMonitor.getBlockedNetworkPackages().sorted().forEach { blockedAppsArr.put(it) }

        res.put("success", true)
        res.put("domains", dArr)
        res.put("domainCount", dArr.length())
        res.put("autoLearnedDomains", autoObj)
        res.put("autoLearnedCount", autoLearnedAdultDomains.size)
        res.put("ips", ipArr)
        res.put("ipCount", ipArr.length())
        res.put("enabledCategories", catArr)
        res.put("enabledCategoryDomains", catDetailsObj)
        res.put("blockedApps", blockedAppsArr)
        res.put("effectiveTotalBlockedDomains", getEffectiveBlockedDomainCount())
        return res
    }

    // -------------------------------------------------------------------------
    // Category Blocklists Management
    // -------------------------------------------------------------------------

    fun getCategoriesStatus(): JSONObject {
        val res = JSONObject()
        val categoriesArr = JSONArray()
        for ((catName, domainsSet) in categoryDomainPresets) {
            val isEn = enabledCategories.contains(catName)
            val hits = categoryBlockedCounts[catName] ?: 0L
            val sampleArr = JSONArray()
            domainsSet.take(6).forEach { sampleArr.put(it) }
            categoriesArr.put(JSONObject().apply {
                put("category", catName)
                put("enabled", isEn)
                put("domainCount", domainsSet.size)
                put("blockedHits", hits)
                put("sampleDomains", sampleArr)
            })
        }
        res.put("success", true)
        res.put("categories", categoriesArr)
        res.put("enabledCategories", JSONArray(enabledCategories.sorted()))
        res.put("effectiveTotalBlockedDomains", getEffectiveBlockedDomainCount())
        return res
    }

    fun setCategoryEnabled(category: String, enabled: Boolean): JSONObject {
        val cleanCat = category.trim().uppercase()
        val res = JSONObject()

        // Also accept DNS presets like "DNS:FAMILY", "DNS:ADGUARD-FAMILY", "DNS_FAMILY", or direct preset names
        if (cleanCat in listOf("FAMILY", "ADGUARD-FAMILY", "ADGUARD", "SECURITY", "AUTO", "OFF") ||
            cleanCat.startsWith("DNS:") || cleanCat.startsWith("DNS_")
        ) {
            val presetName = cleanCat.removePrefix("DNS:").removePrefix("DNS_").lowercase()
            return configureSystemPrivateDns(presetName)
        }

        if (!categoryDomainPresets.containsKey(cleanCat)) {
            res.put("success", false)
            res.put("error", "Unknown category '$category'. Available: ${categoryDomainPresets.keys.joinToString(", ")}")
            return res
        }
        if (enabled) {
            enabledCategories.add(cleanCat)
        } else {
            enabledCategories.remove(cleanCat)
        }
        saveModerationPrefs()
        updateStatus()
        com.kavach.services.AeroNetworkModeratorVpnService.activeInstance?.reloadVpnInterface()

        // If VPN is not active and a category is enabled, auto-start VPN if prepared,
        // and for ADULT/MALWARE categories auto-configure System Private DNS (family.cloudflare-dns.com)
        var autoPrivateDnsObj: JSONObject? = null
        if (enabled) {
            if (cleanCat == "ADULT") {
                if (activeDnsPreset !in listOf("family", "adguard-family")) {
                    activeDnsPreset = "family"
                }
                autoPrivateDnsObj = configureSystemPrivateDns(activeDnsPreset, allowUiAutomation = false)
            } else if (cleanCat == "ADS" || cleanCat == "TRACKERS") {
                if (enabledCategories.contains("ADULT")) {
                    activeDnsPreset = "adguard-family"
                }
            }
            if (!_status.value.isVpnActive) {
                try {
                    if (android.net.VpnService.prepare(context) == null) {
                        com.kavach.services.AeroNetworkModeratorVpnService.startServiceDirect(context)
                    }
                } catch (_: Exception) {}
            }
        }

        res.put("success", true)
        res.put("category", cleanCat)
        res.put("enabled", enabled)
        res.put("categoryDomainCount", categoryDomainPresets[cleanCat]?.size ?: 0)
        res.put("enabledCategories", JSONArray(enabledCategories.sorted()))
        res.put("effectiveTotalBlockedDomains", getEffectiveBlockedDomainCount())
        if (autoPrivateDnsObj != null) {
            res.put("privateDnsAutoUpdate", autoPrivateDnsObj)
        }
        return res
    }

    // -------------------------------------------------------------------------
    // Per-Domain Query Frequency & Traffic Analytics
    // -------------------------------------------------------------------------

    fun getDomainAnalytics(topN: Int = 20): JSONObject {
        val limit = topN.coerceIn(1, 100)
        val topQueriedArr = JSONArray()
        domainQueryCounts.entries
            .sortedByDescending { it.value }
            .take(limit)
            .forEach { (dom, count) ->
                val blk = domainBlockedCounts[dom] ?: 0L
                topQueriedArr.put(JSONObject().apply {
                    put("domain", dom)
                    put("queries", count)
                    put("blocked", blk)
                    put("status", if (blk > 0) "BLOCKED" else "ALLOWED")
                })
            }

        val topBlockedArr = JSONArray()
        domainBlockedCounts.entries
            .sortedByDescending { it.value }
            .take(limit)
            .forEach { (dom, blkCount) ->
                topBlockedArr.put(JSONObject().apply {
                    put("domain", dom)
                    put("blockedCount", blkCount)
                    put("totalQueries", domainQueryCounts[dom] ?: blkCount)
                })
            }

        val catHitsObj = JSONObject()
        for ((cat, hits) in categoryBlockedCounts) {
            catHitsObj.put(cat, hits)
        }

        val blockRatePct = if (totalInterceptedQueries > 0) {
            ((totalBlockedQueries.toDouble() / totalInterceptedQueries.toDouble()) * 1000.0).roundToInt() / 10.0
        } else 0.0

        return JSONObject().apply {
            put("success", true)
            put("totalQueries", totalInterceptedQueries)
            put("totalBlocked", totalBlockedQueries)
            put("totalAllowed", (totalInterceptedQueries - totalBlockedQueries).coerceAtLeast(0L))
            put("uniqueDomainsQueried", domainQueryCounts.size)
            put("blockRatePercent", blockRatePct)
            put("topQueriedDomains", topQueriedArr)
            put("topBlockedDomains", topBlockedArr)
            put("categoryBreakdown", catHitsObj)
        }
    }

    // -------------------------------------------------------------------------
    // Live Network Bandwidth & Data Usage Speed Meter
    // -------------------------------------------------------------------------

    @Synchronized
    fun getLiveBandwidthSpeed(): JSONObject {
        val nowElapsed = SystemClock.elapsedRealtime()
        val curRx = TrafficStats.getTotalRxBytes().coerceAtLeast(0L)
        val curTx = TrafficStats.getTotalTxBytes().coerceAtLeast(0L)
        val mobRx = TrafficStats.getMobileRxBytes().coerceAtLeast(0L)
        val mobTx = TrafficStats.getMobileTxBytes().coerceAtLeast(0L)
        val wifiRx = (curRx - mobRx).coerceAtLeast(0L)
        val wifiTx = (curTx - mobTx).coerceAtLeast(0L)

        var deltaMs = nowElapsed - lastSampleTimeMs
        if (deltaMs < 150L) {
            // Take a short 250ms hardware sample so single API/CLI calls get an instant live speed reading
            try {
                Thread.sleep(250)
            } catch (_: Exception) {}
            val afterElapsed = SystemClock.elapsedRealtime()
            val afterRx = TrafficStats.getTotalRxBytes().coerceAtLeast(0L)
            val afterTx = TrafficStats.getTotalTxBytes().coerceAtLeast(0L)
            deltaMs = (afterElapsed - nowElapsed).coerceAtLeast(1L)
            latestRxBps = (((afterRx - curRx).coerceAtLeast(0L)) * 1000L) / deltaMs
            latestTxBps = (((afterTx - curTx).coerceAtLeast(0L)) * 1000L) / deltaMs
            lastSampleTimeMs = afterElapsed
            lastRxBytes = afterRx
            lastTxBytes = afterTx
        } else {
            latestRxBps = (((curRx - lastRxBytes).coerceAtLeast(0L)) * 1000L) / deltaMs
            latestTxBps = (((curTx - lastTxBytes).coerceAtLeast(0L)) * 1000L) / deltaMs
            lastSampleTimeMs = nowElapsed
            lastRxBytes = curRx
            lastTxBytes = curTx
        }

        val rxKbps = (latestRxBps / 102.4).roundToInt() / 10.0
        val txKbps = (latestTxBps / 102.4).roundToInt() / 10.0
        val rxMbps = ((latestRxBps * 8.0) / 1_000_000.0 * 100.0).roundToInt() / 100.0
        val txMbps = ((latestTxBps * 8.0) / 1_000_000.0 * 100.0).roundToInt() / 100.0

        return JSONObject().apply {
            put("success", true)
            put("timestamp", System.currentTimeMillis())
            put("downloadBytesPerSec", latestRxBps)
            put("uploadBytesPerSec", latestTxBps)
            put("downloadKBps", rxKbps)
            put("uploadKBps", txKbps)
            put("downloadMbps", rxMbps)
            put("uploadMbps", txMbps)
            put("totalBootRxBytes", lastRxBytes)
            put("totalBootTxBytes", lastTxBytes)
            put("totalBootRxMB", (lastRxBytes / (1024.0 * 1024.0) * 10.0).roundToInt() / 10.0)
            put("totalBootTxMB", (lastTxBytes / (1024.0 * 1024.0) * 10.0).roundToInt() / 10.0)
            put("wifiRxMB", (wifiRx / (1024.0 * 1024.0) * 10.0).roundToInt() / 10.0)
            put("wifiTxMB", (wifiTx / (1024.0 * 1024.0) * 10.0).roundToInt() / 10.0)
            put("mobileRxMB", (mobRx / (1024.0 * 1024.0) * 10.0).roundToInt() / 10.0)
            put("mobileTxMB", (mobTx / (1024.0 * 1024.0) * 10.0).roundToInt() / 10.0)
            put("totalRxPackets", TrafficStats.getTotalRxPackets().coerceAtLeast(0L))
            put("totalTxPackets", TrafficStats.getTotalTxPackets().coerceAtLeast(0L))
        }
    }

    // -------------------------------------------------------------------------
    // Active Network Diagnostics: Ping, DNS Lookup & Port Reachability
    // -------------------------------------------------------------------------

    fun pingHost(rawHost: String, count: Int = 3): JSONObject {
        val host = rawHost.trim().replace(Regex("[^a-zA-Z0-9.\\-:]"), "")
        val res = JSONObject()
        if (host.isEmpty()) {
            res.put("success", false)
            res.put("error", "Invalid or empty host")
            return res
        }
        val safeCount = count.coerceIn(1, 10)
        val startMs = System.currentTimeMillis()
        try {
            val proc = ProcessBuilder("ping", "-c", safeCount.toString(), "-W", "3", host)
                .redirectErrorStream(true)
                .start()
            val output = proc.inputStream.bufferedReader().readText()
            val finished = proc.waitFor(12, TimeUnit.SECONDS)
            val exitCode = if (finished) proc.exitValue() else -1

            // Parse rtt min/avg/max/mdev = 12.345/15.678/19.012/2.345 ms
            var minRtt = -1.0
            var avgRtt = -1.0
            var maxRtt = -1.0
            val rttRegex = Regex("=\\s*([0-9.]+)/([0-9.]+)/([0-9.]+)")
            rttRegex.find(output)?.let { m ->
                minRtt = m.groupValues[1].toDoubleOrNull() ?: -1.0
                avgRtt = m.groupValues[2].toDoubleOrNull() ?: -1.0
                maxRtt = m.groupValues[3].toDoubleOrNull() ?: -1.0
            }

            // Fallback to InetAddress.isReachable / TCP connect RTT if ICMP is restricted in container
            if (avgRtt < 0) {
                val rtts = mutableListOf<Double>()
                for (i in 0 until safeCount) {
                    val t0 = System.nanoTime()
                    val reachable = try {
                        Socket().use { s ->
                            s.connect(InetSocketAddress(host, 443), 2500)
                            true
                        }
                    } catch (_: Exception) {
                        try {
                            InetAddress.getByName(host).isReachable(2500)
                        } catch (_: Exception) {
                            false
                        }
                    }
                    if (reachable) {
                        rtts.add((System.nanoTime() - t0) / 1_000_000.0)
                    }
                }
                if (rtts.isNotEmpty()) {
                    minRtt = (rtts.minOrNull() ?: 0.0 * 100.0).roundToInt() / 100.0
                    avgRtt = (rtts.average() * 100.0).roundToInt() / 100.0
                    maxRtt = (rtts.maxOrNull() ?: 0.0 * 100.0).roundToInt() / 100.0
                }
            }

            res.put("success", exitCode == 0 || avgRtt >= 0)
            res.put("host", host)
            res.put("packetsCount", safeCount)
            res.put("minRttMs", minRtt)
            res.put("avgRttMs", avgRtt)
            res.put("maxRttMs", maxRtt)
            res.put("elapsedMs", System.currentTimeMillis() - startMs)
            res.put("rawOutput", output.trim())
        } catch (e: Exception) {
            res.put("success", false)
            res.put("host", host)
            res.put("error", e.message ?: "Ping execution failed")
        }
        return res
    }

    fun dnsLookup(rawDomain: String): JSONObject {
        val domain = rawDomain.trim().lowercase().trimEnd('.')
        val res = JSONObject()
        if (domain.isEmpty()) {
            res.put("success", false)
            res.put("error", "Domain cannot be empty")
            return res
        }

        val (isBlockedByPolicy, blockReason) = shouldBlockDomain(domain)
        val t0 = System.nanoTime()
        return try {
            val addresses = InetAddress.getAllByName(domain)
            val elapsedMs = ((System.nanoTime() - t0) / 1_000_000.0 * 100.0).roundToInt() / 100.0
            val ipv4Arr = JSONArray()
            val ipv6Arr = JSONArray()
            for (addr in addresses) {
                val hostAddr = addr.hostAddress ?: continue
                perAppMonitor.cacheDnsResolvedIp(domain, hostAddr)
                if (hostAddr.contains(":")) ipv6Arr.put(hostAddr) else ipv4Arr.put(hostAddr)
            }
            res.put("success", true)
            res.put("domain", domain)
            res.put("lookupTimeMs", elapsedMs)
            res.put("ipv4Addresses", ipv4Arr)
            res.put("ipv6Addresses", ipv6Arr)
            res.put("totalRecords", ipv4Arr.length() + ipv6Arr.length())
            res.put("blockedByModerationPolicy", isBlockedByPolicy)
            res.put("moderationVerdict", if (isBlockedByPolicy) blockReason else "ALLOWED")
            res
        } catch (e: Exception) {
            val elapsedMs = ((System.nanoTime() - t0) / 1_000_000.0 * 100.0).roundToInt() / 100.0
            res.put("success", false)
            res.put("domain", domain)
            res.put("lookupTimeMs", elapsedMs)
            res.put("blockedByModerationPolicy", isBlockedByPolicy)
            res.put("moderationVerdict", if (isBlockedByPolicy) blockReason else "NXDOMAIN_OR_UNREACHABLE")
            res.put("error", e.message ?: "DNS resolution failed")
            res
        }
    }

    fun checkTcpPort(rawHost: String, port: Int, timeoutMs: Int = 3000): JSONObject {
        val host = rawHost.trim()
        val res = JSONObject()
        if (host.isEmpty() || port !in 1..65535) {
            res.put("success", false)
            res.put("error", "Provide a valid host and port (1..65535)")
            return res
        }
        val t0 = System.nanoTime()
        return try {
            Socket().use { socket ->
                socket.connect(InetSocketAddress(host, port), timeoutMs.coerceIn(300, 10000))
            }
            val rttMs = ((System.nanoTime() - t0) / 1_000_000.0 * 100.0).roundToInt() / 100.0
            res.put("success", true)
            res.put("host", host)
            res.put("port", port)
            res.put("open", true)
            res.put("connectRttMs", rttMs)
            res
        } catch (e: Exception) {
            val rttMs = ((System.nanoTime() - t0) / 1_000_000.0 * 100.0).roundToInt() / 100.0
            res.put("success", true)
            res.put("host", host)
            res.put("port", port)
            res.put("open", false)
            res.put("connectRttMs", rttMs)
            res.put("reason", e.message ?: "Connection refused or timed out")
            res
        }
    }

    fun getAuditLogs(limit: Int = 50): JSONObject {
        val res = JSONObject()
        val arr = JSONArray()
        val list = auditLogs.toList().takeLast(limit.coerceIn(1, maxAuditLogs)).reversed()
        for (item in list) {
            arr.put(JSONObject().apply {
                put("timestamp", item.timestamp)
                put("domain", item.domain)
                put("queryType", item.queryType)
                put("action", item.action)
                put("reason", item.reason)
                put("packageName", item.packageName)
            })
        }
        res.put("success", true)
        res.put("count", arr.length())
        res.put("logs", arr)
        return res
    }

    fun clearAuditLogs(): JSONObject {
        auditLogs.clear()
        return JSONObject().apply {
            put("success", true)
            put("action", "AUDIT_LOGS_CLEARED")
        }
    }

    fun getModerationStatus(): JSONObject {
        val st = _status.value
        val dnsSt = getSystemPrivateDnsStatus()
        return JSONObject().apply {
            put("success", true)
            put("isVpnActive", st.isVpnActive)
            put("totalIntercepted", st.totalIntercepted)
            put("totalBlocked", st.totalBlocked)
            put("blacklistedDomainsCount", getEffectiveBlockedDomainCount())
            put("customBlacklistedDomainsCount", blacklistedDomains.size)
            put("autoLearnedDomainsCount", autoLearnedAdultDomains.size)
            put("blacklistedIpsCount", blacklistedIps.size)
            put("enabledCategories", JSONArray(enabledCategories.sorted()))
            put("lastBlockedTarget", st.lastBlockedTarget ?: "")
            put("lastBlockedTimestamp", st.lastBlockedTimestamp)
            put("privateDnsMode", dnsSt.optString("mode", "opportunistic"))
            put("privateDnsSpecifier", dnsSt.optString("specifier", ""))
            put("privateDnsFamilyProtected", dnsSt.optBoolean("isFamilyProtected", false))
        }
    }

    // -------------------------------------------------------------------------
    // VPN-less & Auto-VPN Smart DNS Protection Engine
    // -------------------------------------------------------------------------

    private fun checkAndAutoHealBrokenSystemDns() {
        try {
            val osMode = android.provider.Settings.Global.getString(context.contentResolver, "private_dns_mode") ?: ""
            if (osMode == "hostname") {
                val canResolve = try {
                    InetAddress.getByName("private-relay-bridge.onrender.com")
                    InetAddress.getByName("www.google.com")
                    true
                } catch (_: Throwable) {
                    false
                }
                if (!canResolve) {
                    // OS Private DNS is blocking tunnel or failing on ISP port 853 -> auto-heal back to opportunistic
                    var healed = false
                    try {
                        healed = android.provider.Settings.Global.putString(
                            context.contentResolver,
                            "private_dns_mode",
                            "opportunistic"
                        )
                    } catch (_: Exception) {}
                    if (!healed) {
                        try {
                            Runtime.getRuntime().exec(arrayOf("sh", "-c", "settings put global private_dns_mode opportunistic"))
                                .waitFor(1000, TimeUnit.MILLISECONDS)
                        } catch (_: Exception) {}
                    }
                    val afterMode = android.provider.Settings.Global.getString(context.contentResolver, "private_dns_mode") ?: ""
                    if (afterMode == "hostname") {
                        com.kavach.hardware.AppGuardManager.activeInstance
                            ?.autoConfigurePrivateDnsViaAccessibility("opportunistic", "")
                    }
                }
            }
        } catch (_: Throwable) {}
    }

    fun getSystemPrivateDnsStatus(): JSONObject {
        var osMode = "opportunistic"
        var osSpecifier = ""
        try {
            osMode = android.provider.Settings.Global.getString(context.contentResolver, "private_dns_mode")
                ?.ifBlank { "opportunistic" } ?: "opportunistic"
            osSpecifier = android.provider.Settings.Global.getString(context.contentResolver, "private_dns_specifier")
                ?: ""
        } catch (_: Exception) {}

        val lowerSpec = osSpecifier.lowercase()
        val isFamilyProtected = activeDnsPreset in listOf("family", "adguard-family") ||
            enabledCategories.contains("ADULT") ||
            (osMode == "hostname" && (
                lowerSpec.contains("family.cloudflare-dns.com") ||
                    lowerSpec.contains("family.adguard-dns.com") ||
                    lowerSpec.contains("cleanbrowsing.org") ||
                    lowerSpec.contains("1.1.1.3")
                ))
        val isAdBlockProtected = activeDnsPreset in listOf("adguard-family", "adguard") ||
            enabledCategories.contains("ADS") ||
            (osMode == "hostname" && (
                lowerSpec.contains("adguard") ||
                    lowerSpec.contains("nextdns") ||
                    lowerSpec.contains("controld")
                ))

        val upstreamDesc = when (activeDnsPreset) {
            "adguard-family" -> "AdGuard Family (94.140.14.15) + Cloudflare Family (1.1.1.3)"
            "adguard" -> "AdGuard DNS (94.140.14.14 / 94.140.15.15)"
            "security" -> "Cloudflare Security (1.1.1.2 / 1.0.0.2)"
            "family" -> "Cloudflare Family (1.1.1.3 / 1.0.0.3) + AdGuard Family (94.140.14.15)"
            else -> "Standard DNS (8.8.8.8 / 1.1.1.1)"
        }

        return JSONObject().apply {
            put("success", true)
            put("activeDnsPreset", activeDnsPreset)
            put("upstreamResolvers", upstreamDesc)
            put("mode", if (osMode == "hostname") osMode else "smart-engine ($activeDnsPreset)")
            put("specifier", if (osSpecifier.isNotBlank()) osSpecifier else upstreamDesc)
            put("osPrivateDnsMode", osMode)
            put("osPrivateDnsSpecifier", osSpecifier)
            put("isFamilyProtected", isFamilyProtected)
            put("isAdBlockProtected", isAdBlockProtected)
            put("isVpnActive", _status.value.isVpnActive)
            put("accessibilityGuardActive", com.kavach.accessibility.AccessibilityServiceRegistry.activeService != null)
            put("enabledCategories", JSONArray(enabledCategories.sorted()))
            put("effectiveTotalBlockedDomains", getEffectiveBlockedDomainCount())
            put("availablePresets", JSONObject().apply {
                put("family", "Cloudflare Family 1.1.1.3 + Live HTML Metadata Guard (Blocks Adult + Malware)")
                put("adguard-family", "AdGuard Family 94.140.14.15 + 1.1.1.3 (Blocks Adult + Ads + Trackers)")
                put("adguard", "AdGuard DNS 94.140.14.14 (Blocks Ads + Trackers)")
                put("security", "Cloudflare Security 1.1.1.2 (Blocks Malware + Phishing)")
                put("auto", "Standard DNS + Reset OS Private DNS to Automatic")
                put("off", "Disable Family DNS preset & reset OS Private DNS to Automatic")
            })
        }
    }

    /**
     * Configures AeroShare's Dual-Engine Smart DNS Protection (UDP 53 Upstream Resolver + Auto-VPN +
     * VPN-less Accessibility Browser URL & HTML Metadata Scanner) without breaking ISP DNS or Cloudflare Tunnels.
     */
    fun configureSystemPrivateDns(presetOrHostname: String, allowUiAutomation: Boolean = false): JSONObject {
        val clean = presetOrHostname.trim().lowercase()
        if (clean.isEmpty() || clean == "status" || clean == "get" || clean == "info") {
            return getSystemPrivateDnsStatus()
        }

        val (presetKey, targetMode, targetHost, presetLabel) = when (clean) {
            "family", "adult", "cloudflare-family", "1.1.1.3" ->
                listOf("family", "hostname", "family.cloudflare-dns.com", "Cloudflare Family (1.1.1.3) + Adult Metadata Guard")
            "adguard-family", "family-ads", "all" ->
                listOf("adguard-family", "hostname", "family.adguard-dns.com", "AdGuard Family (94.140.14.15) + Adult & Ad Block")
            "adguard", "ads", "adblock" ->
                listOf("adguard", "hostname", "dns.adguard-dns.com", "AdGuard DNS (94.140.14.14 Ads + Trackers Block)")
            "security", "malware", "1.1.1.2" ->
                listOf("security", "hostname", "security.cloudflare-dns.com", "Cloudflare Security (1.1.1.2 Malware + Phishing Block)")
            "cleanbrowsing", "clean" ->
                listOf("family", "hostname", "family-filter-dns.cleanbrowsing.org", "CleanBrowsing Family Filter + 1.1.1.3")
            "auto", "automatic", "opportunistic", "default", "repair", "fix" ->
                listOf("auto", "opportunistic", "", "Automatic DNS (OS Private DNS healed to Automatic)")
            "off", "disable", "disabled", "none" ->
                listOf("off", "opportunistic", "", "DNS Filter Preset Off (OS Private DNS set to Automatic)")
            else -> {
                if (clean.contains(".")) {
                    listOf("family", "hostname", clean, "Custom DNS ($clean)")
                } else {
                    return JSONObject().apply {
                        put("success", false)
                        put("error", "Unknown DNS preset '$presetOrHostname'. Use: family, adguard-family, adguard, security, auto, off.")
                    }
                }
            }
        }

        // 1. Update active DNS preset and auto-enable matching protection categories
        activeDnsPreset = presetKey
        when (presetKey) {
            "family" -> {
                enabledCategories.add("ADULT")
                enabledCategories.add("MALWARE")
            }
            "adguard-family" -> {
                enabledCategories.add("ADULT")
                enabledCategories.add("ADS")
                enabledCategories.add("TRACKERS")
                enabledCategories.add("MALWARE")
            }
            "adguard" -> {
                enabledCategories.add("ADS")
                enabledCategories.add("TRACKERS")
            }
            "security" -> {
                enabledCategories.add("MALWARE")
            }
            "off" -> {
                enabledCategories.remove("ADULT")
            }
        }
        saveModerationPrefs()
        updateStatus()

        // 2. Auto-start or reload the DNS Firewall VPN service if enabled
        var vpnStateMsg = "VPN_OFF_BROWSER_GUARD_ACTIVE"
        if (presetKey != "off") {
            try {
                if (_status.value.isVpnActive) {
                    com.kavach.services.AeroNetworkModeratorVpnService.activeInstance?.reloadVpnInterface()
                    vpnStateMsg = "VPN_RELOADED_WITH_${presetKey.uppercase()}"
                } else {
                    vpnStateMsg = com.kavach.services.AeroNetworkModeratorVpnService.startService(context)
                }
            } catch (_: Throwable) {}
        }

        // 3. Safe OS Settings.Global Private DNS handling:
        //    - If preset is "auto" / "off" / "repair", or if OS Private DNS is stuck on "hostname" and breaking DNS,
        //      revert OS Private DNS to "opportunistic" (Automatic) so trycloudflare.com and ISP DNS never break.
        var methodUsed = "SMART_UPSTREAM_UDP_AND_BROWSER_GUARD"
        var osResetDispatched = false
        val currentOsMode = try {
            android.provider.Settings.Global.getString(context.contentResolver, "private_dns_mode") ?: "opportunistic"
        } catch (_: Exception) { "opportunistic" }

        if (targetMode == "opportunistic" || currentOsMode == "hostname") {
            var resetDirectly = false
            try {
                resetDirectly = android.provider.Settings.Global.putString(
                    context.contentResolver,
                    "private_dns_mode",
                    "opportunistic"
                )
            } catch (_: Exception) {}
            if (!resetDirectly) {
                try {
                    Runtime.getRuntime().exec(arrayOf("sh", "-c", "settings put global private_dns_mode opportunistic"))
                        .waitFor(1000, TimeUnit.MILLISECONDS)
                } catch (_: Exception) {}
            }
            val verifyMode = try {
                android.provider.Settings.Global.getString(context.contentResolver, "private_dns_mode") ?: ""
            } catch (_: Exception) { "" }

            if (verifyMode == "hostname" && (targetMode == "opportunistic" || allowUiAutomation)) {
                osResetDispatched = com.kavach.hardware.AppGuardManager.activeInstance
                    ?.autoConfigurePrivateDnsViaAccessibility("opportunistic", "") == true
                if (osResetDispatched) {
                    methodUsed = "RESET_OS_PRIVATE_DNS_TO_AUTOMATIC"
                }
            }
        }

        val currentStatus = getSystemPrivateDnsStatus()
        return JSONObject().apply {
            put("success", true)
            put("requestedPreset", presetKey)
            put("presetDescription", presetLabel)
            put("targetMode", currentStatus.optString("mode", ""))
            put("targetHostname", currentStatus.optString("upstreamResolvers", targetHost))
            put("methodUsed", "$methodUsed ($vpnStateMsg)")
            put("currentMode", currentStatus.optString("mode", ""))
            put("currentSpecifier", currentStatus.optString("specifier", ""))
            put("isVpnActive", _status.value.isVpnActive)
            put("vpnlessBrowserGuardActive", com.kavach.accessibility.AccessibilityServiceRegistry.activeService != null)
            put("enabledCategories", JSONArray(enabledCategories.sorted()))
            put("effectiveTotalBlockedDomains", getEffectiveBlockedDomainCount())
        }
    }
}
