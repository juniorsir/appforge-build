package com.kavach.capabilities.storage

import com.kavach.capabilities.CapabilityResult

interface StorageRepository {
    suspend fun readTextFile(uriString: String): CapabilityResult<String>
    suspend fun writeTextFile(fileName: String, content: String): CapabilityResult<String> // Returns new URI
    suspend fun deleteFile(uriString: String): CapabilityResult<Boolean>
}
