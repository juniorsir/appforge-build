package com.kavach.domain.repository

import com.kavach.domain.model.SessionData
import kotlinx.coroutines.flow.StateFlow

interface SessionRepository {
    /**
     * Flow emitting the currently active session configuration and metadata.
     */
    val currentSession: StateFlow<SessionData>

    /**
     * Re-initializes a new session context (with fresh session ID and conversation ID).
     */
    suspend fun createNewSession(): SessionData

    /**
     * Returns a persistent unique device ID.
     */
    fun getDeviceId(): String

    /**
     * Returns a placeholder for user identity.
     */
    fun getUserIdPlaceholder(): String
}
