package com.kavach.ui.overlay

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.util.Log
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONObject
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Live Animated Virtual Mouse Cursor & Gesture Visualizer Overlay.
 *
 * Renders across all apps in a single full-screen touch-transparent WindowManager overlay
 * (`FLAG_NOT_TOUCHABLE or FLAG_NOT_FOCUSABLE`) tagged with `agy_hud_pointer` so
 * `AccessibilityRepositoryImpl.getFullNodeTree()` excludes it automatically.
 */
class AgyPointerOverlayManager(
    private val context: Context
) {
    companion object {
        private const val TAG = "AgyPointerOverlayMgr"
        const val POINTER_NODE_TAG = "agy_hud_pointer"
        private const val CURSOR_MOVE_DURATION_MS = 130L
        private const val INACTIVITY_FADE_DELAY_MS = 1500L
        private const val FADE_OUT_DURATION_MS = 260L
    }

    enum class PointerMode {
        IDLE,
        TAP,
        LONG_PRESS,
        SWIPE,
        TYPING,
        KEY_BADGE
    }

    data class PointerVisualState(
        val enabled: Boolean = true,
        val showLabel: Boolean = true,
        val visible: Boolean = false,
        val mode: PointerMode = PointerMode.IDLE,
        val cursorX: Float = 0f,
        val cursorY: Float = 0f,
        val startX: Float = 0f,
        val startY: Float = 0f,
        val endX: Float = 0f,
        val endY: Float = 0f,
        val label: String = "",
        val isAmber: Boolean = false,
        val timestampMs: Long = 0L
    )

    private val mainHandler = Handler(Looper.getMainLooper())
    private val windowManager: WindowManager? by lazy {
        context.getSystemService(Context.WINDOW_SERVICE) as? WindowManager
    }

    private val _pointerEnabledFlow = MutableStateFlow(true)
    val pointerEnabledFlow: StateFlow<Boolean> = _pointerEnabledFlow.asStateFlow()

    private val _showLabelFlow = MutableStateFlow(true)
    val showLabelFlow: StateFlow<Boolean> = _showLabelFlow.asStateFlow()

    private val _pointerStateFlow = MutableStateFlow(PointerVisualState())
    val pointerStateFlow: StateFlow<PointerVisualState> = _pointerStateFlow.asStateFlow()

    private var rootContainer: FrameLayout? = null
    private var canvasView: AgyPointerCanvasView? = null
    private var lastKnownX: Float = -1f
    private var lastKnownY: Float = -1f
    private var idleFadeRunnable: Runnable? = null

    fun isPointerEnabled(): Boolean = _pointerEnabledFlow.value
    fun isShowLabelEnabled(): Boolean = _showLabelFlow.value

    fun setPointerEnabled(enabled: Boolean): JSONObject =
        setPointerConfig(enabled = enabled, showLabel = null)

    fun setPointerConfig(enabled: Boolean? = null, showLabel: Boolean? = null): JSONObject {
        val nextEnabled = enabled ?: _pointerEnabledFlow.value
        val nextShowLabel = showLabel ?: _showLabelFlow.value
        _pointerEnabledFlow.value = nextEnabled
        _showLabelFlow.value = nextShowLabel
        if (!nextEnabled) {
            hidePointer()
        } else {
            _pointerStateFlow.value = _pointerStateFlow.value.copy(
                enabled = true,
                showLabel = nextShowLabel
            )
            runOnMain {
                canvasView?.setShowLabel(nextShowLabel)
            }
        }
        return JSONObject().apply {
            put("success", true)
            put("pointerEnabled", nextEnabled)
            put("enabled", nextEnabled)
            put("showLabel", nextShowLabel)
        }
    }

    fun showTap(x: Float, y: Float, label: String = "") {
        val cleanLabel = label.trim().ifBlank { "Tap ${x.toInt()},${y.toInt()}" }
        dispatchPointerUpdate(
            mode = PointerMode.TAP,
            targetX = x,
            targetY = y,
            startX = x,
            startY = y,
            endX = x,
            endY = y,
            durationMs = 420L,
            label = cleanLabel,
            isAmber = false
        )
    }

    fun showLongPress(x: Float, y: Float, label: String = "") {
        val cleanLabel = label.trim().ifBlank { "Hold ${x.toInt()},${y.toInt()}" }
        dispatchPointerUpdate(
            mode = PointerMode.LONG_PRESS,
            targetX = x,
            targetY = y,
            startX = x,
            startY = y,
            endX = x,
            endY = y,
            durationMs = 680L,
            label = cleanLabel,
            isAmber = true
        )
    }

    fun showSwipe(
        x1: Float,
        y1: Float,
        x2: Float,
        y2: Float,
        durationMs: Long = 300L,
        label: String = ""
    ) {
        val cleanLabel = label.trim().ifBlank { "Drag ${x2.toInt()},${y2.toInt()}" }
        dispatchPointerUpdate(
            mode = PointerMode.SWIPE,
            targetX = x2,
            targetY = y2,
            startX = x1,
            startY = y1,
            endX = x2,
            endY = y2,
            durationMs = durationMs.coerceIn(180L, 950L),
            label = cleanLabel,
            isAmber = false
        )
    }

    fun showTyping(x: Float, y: Float, textPreview: String = "") {
        val (rx, ry) = if (x > 0f || y > 0f) {
            x to y
        } else {
            resolveFallbackPoint()
        }
        val snippet = textPreview.trim().replace("\n", " ").let {
            if (it.length > 18) it.take(18) + "…" else it
        }
        val cleanLabel = if (snippet.isNotEmpty()) "Typing \"$snippet\"" else "Typing..."
        dispatchPointerUpdate(
            mode = PointerMode.TYPING,
            targetX = rx,
            targetY = ry,
            startX = rx,
            startY = ry,
            endX = rx,
            endY = ry,
            durationMs = 450L,
            label = cleanLabel,
            isAmber = false
        )
    }

    fun showKeyBadge(keyName: String) {
        val (kx, ky) = resolveFallbackPoint()
        val cleanKey = keyName.trim().uppercase().ifBlank { "KEY" }
        dispatchPointerUpdate(
            mode = PointerMode.KEY_BADGE,
            targetX = kx,
            targetY = ky,
            startX = kx,
            startY = ky,
            endX = kx,
            endY = ky,
            durationMs = 360L,
            label = "Key: $cleanKey",
            isAmber = false
        )
    }

    fun hidePointer() {
        val current = _pointerStateFlow.value
        _pointerStateFlow.value = current.copy(
            enabled = _pointerEnabledFlow.value,
            visible = false,
            mode = PointerMode.IDLE
        )
        runOnMain {
            idleFadeRunnable?.let { mainHandler.removeCallbacks(it) }
            idleFadeRunnable = null
            canvasView?.resetImmediately()
            rootContainer?.let { root ->
                try {
                    windowManager?.removeView(root)
                } catch (e: Exception) {
                    Log.w(TAG, "Error removing pointer overlay: ${e.message}")
                }
            }
            rootContainer = null
            canvasView = null
        }
    }

    private fun resolveFallbackPoint(): Pair<Float, Float> {
        if (lastKnownX >= 0f && lastKnownY >= 0f) {
            return lastKnownX to lastKnownY
        }
        val dm = context.resources.displayMetrics
        val w = dm.widthPixels.coerceAtLeast(360)
        val h = dm.heightPixels.coerceAtLeast(640)
        return (w * 0.5f) to (h * 0.62f)
    }

    private fun dispatchPointerUpdate(
        mode: PointerMode,
        targetX: Float,
        targetY: Float,
        startX: Float,
        startY: Float,
        endX: Float,
        endY: Float,
        durationMs: Long,
        label: String,
        isAmber: Boolean
    ) {
        if (!_pointerEnabledFlow.value) return

        val prevX = if (lastKnownX >= 0f) lastKnownX else startX
        val prevY = if (lastKnownY >= 0f) lastKnownY else startY
        lastKnownX = targetX
        lastKnownY = targetY

        _pointerStateFlow.value = PointerVisualState(
            enabled = true,
            showLabel = _showLabelFlow.value,
            visible = true,
            mode = mode,
            cursorX = targetX,
            cursorY = targetY,
            startX = startX,
            startY = startY,
            endX = endX,
            endY = endY,
            label = label,
            isAmber = isAmber,
            timestampMs = System.currentTimeMillis()
        )

        runOnMain {
            if (!_pointerEnabledFlow.value || !hasOverlayPermission()) return@runOnMain
            ensureAttached()
            rootContainer?.visibility = View.VISIBLE
            canvasView?.setShowLabel(_showLabelFlow.value)
            canvasView?.startGesture(
                mode = mode,
                fromX = prevX,
                fromY = prevY,
                startX = startX,
                startY = startY,
                endX = endX,
                endY = endY,
                gestureDurationMs = durationMs,
                label = label,
                isAmber = isAmber
            )
            scheduleIdleFade()
        }
    }

    private fun scheduleIdleFade() {
        idleFadeRunnable?.let { mainHandler.removeCallbacks(it) }
        val r = Runnable {
            canvasView?.fadeOut {
                _pointerStateFlow.value = _pointerStateFlow.value.copy(visible = false)
                rootContainer?.visibility = View.GONE
            }
        }
        idleFadeRunnable = r
        mainHandler.postDelayed(r, INACTIVITY_FADE_DELAY_MS)
    }

    private fun ensureAttached() {
        if (rootContainer != null && canvasView != null) return
        val wm = windowManager ?: return

        val root = FrameLayout(context).apply {
            tag = POINTER_NODE_TAG
            contentDescription = POINTER_NODE_TAG
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                transitionName = POINTER_NODE_TAG
            }
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS
            isClickable = false
            isFocusable = false
        }

        val view = AgyPointerCanvasView(context).apply {
            tag = POINTER_NODE_TAG
            contentDescription = POINTER_NODE_TAG
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
            isClickable = false
            isFocusable = false
        }

        root.addView(
            view,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
        )

        val windowType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            windowType,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }

        try {
            wm.addView(root, params)
            rootContainer = root
            canvasView = view
        } catch (e: Exception) {
            Log.e(TAG, "Failed attaching agy_hud_pointer overlay: ${e.message}")
        }
    }

    private fun hasOverlayPermission(): Boolean {
        return Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(context)
    }

    private fun runOnMain(block: () -> Unit) {
        if (Looper.myLooper() == Looper.getMainLooper()) {
            block()
        } else {
            mainHandler.post(block)
        }
    }
}

/**
 * Custom Canvas View rendering the animated vector mouse arrow cursor, expanding concentric
 * tap/long-press ripples, glowing swipe/scroll vector trails, and edge-clamped action pill badge.
 */
class AgyPointerCanvasView(context: Context) : View(context) {

    private val density = resources.displayMetrics.density
    private val cyanPrimary = Color.parseColor("#00E5FF")
    private val cyanSecondary = Color.parseColor("#0095F6")
    private val amberPrimary = Color.parseColor("#F59E0B")
    private val amberLight = Color.parseColor("#FDE68A")
    private val pillBgColor = Color.parseColor("#D90F172A")
    private val pillTextColor = Color.parseColor("#F8FAFC")

    private var activeMode = AgyPointerOverlayManager.PointerMode.IDLE
    private var cursorX = 0f
    private var cursorY = 0f
    private var trailStartX = 0f
    private var trailStartY = 0f
    private var trailEndX = 0f
    private var trailEndY = 0f
    private var actionLabel = ""
    private var showLabel = true
    private var isAmberAccent = false

    private var moveProgress = 1f
    private var effectProgress = 0f
    private var overlayAlpha = 0f

    fun setShowLabel(enabled: Boolean) {
        if (showLabel == enabled) return
        showLabel = enabled
        invalidate()
    }

    private var moveAnimator: ValueAnimator? = null
    private var effectAnimator: ValueAnimator? = null
    private var fadeAnimator: ValueAnimator? = null

    private val cursorPath = Path()
    private val pillRect = RectF()
    private val arrowHeadPath = Path()

    private val cursorFillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.WHITE
        setShadowLayer(4f * density, 0f, 1.5f * density, Color.argb(115, 15, 23, 42))
    }

    private val cursorGlowStrokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeJoin = Paint.Join.ROUND
        strokeCap = Paint.Cap.ROUND
        strokeWidth = 2.6f * density
        color = cyanPrimary
    }

    private val cursorInnerEdgePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeJoin = Paint.Join.ROUND
        strokeCap = Paint.Cap.ROUND
        strokeWidth = 1.15f * density
        color = Color.parseColor("#0F172A")
    }

    private val ripplePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
    }

    private val rippleGlowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }

    private val trailGlowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeWidth = 9f * density
    }

    private val trailCorePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeWidth = 3.2f * density
    }

    private val trailDashPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeWidth = 1.8f * density
        pathEffect = DashPathEffect(floatArrayOf(6f * density, 5f * density), 0f)
        color = Color.argb(170, 255, 255, 255)
    }

    private val pillBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = pillBgColor
        setShadowLayer(5f * density, 0f, 2f * density, Color.argb(95, 0, 0, 0))
    }

    private val pillBorderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1.1f * density
    }

    private val pillDotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }

    private val pillTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = pillTextColor
        textSize = 11.5f * density
        typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
    }

    init {
        setLayerType(LAYER_TYPE_SOFTWARE, null)
    }

    fun startGesture(
        mode: AgyPointerOverlayManager.PointerMode,
        fromX: Float,
        fromY: Float,
        startX: Float,
        startY: Float,
        endX: Float,
        endY: Float,
        gestureDurationMs: Long,
        label: String,
        isAmber: Boolean
    ) {
        moveAnimator?.cancel()
        effectAnimator?.cancel()
        fadeAnimator?.cancel()

        activeMode = mode
        trailStartX = startX
        trailStartY = startY
        trailEndX = endX
        trailEndY = endY
        actionLabel = label
        isAmberAccent = isAmber
        overlayAlpha = 1f
        effectProgress = 0f

        if (mode == AgyPointerOverlayManager.PointerMode.SWIPE) {
            cursorX = startX
            cursorY = startY
            moveProgress = 1f
            effectAnimator = ValueAnimator.ofFloat(0f, 1f).apply {
                duration = gestureDurationMs.coerceIn(180L, 950L)
                interpolator = DecelerateInterpolator(1.35f)
                addUpdateListener { anim ->
                    val t = anim.animatedValue as Float
                    effectProgress = t
                    cursorX = startX + (endX - startX) * t
                    cursorY = startY + (endY - startY) * t
                    invalidate()
                }
                start()
            }
        } else {
            val startMoveX = if (fromX >= 0f) fromX else endX
            val startMoveY = if (fromY >= 0f) fromY else endY
            cursorX = startMoveX
            cursorY = startMoveY
            moveProgress = 0f
            moveAnimator = ValueAnimator.ofFloat(0f, 1f).apply {
                duration = 130L
                interpolator = DecelerateInterpolator(1.6f)
                addUpdateListener { anim ->
                    val t = anim.animatedValue as Float
                    moveProgress = t
                    cursorX = startMoveX + (endX - startMoveX) * t
                    cursorY = startMoveY + (endY - startMoveY) * t
                    invalidate()
                }
                start()
            }

            effectAnimator = ValueAnimator.ofFloat(0f, 1f).apply {
                duration = gestureDurationMs.coerceIn(320L, 850L)
                interpolator = DecelerateInterpolator(1.25f)
                addUpdateListener { anim ->
                    effectProgress = anim.animatedValue as Float
                    invalidate()
                }
                start()
            }
        }
        invalidate()
    }

    fun fadeOut(onFinished: () -> Unit) {
        fadeAnimator?.cancel()
        val initialAlpha = overlayAlpha
        if (initialAlpha <= 0.01f) {
            onFinished()
            return
        }
        fadeAnimator = ValueAnimator.ofFloat(initialAlpha, 0f).apply {
            duration = 260L
            addUpdateListener { anim ->
                overlayAlpha = anim.animatedValue as Float
                invalidate()
            }
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) {
                    overlayAlpha = 0f
                    activeMode = AgyPointerOverlayManager.PointerMode.IDLE
                    invalidate()
                    onFinished()
                }
            })
            start()
        }
    }

    fun resetImmediately() {
        moveAnimator?.cancel()
        effectAnimator?.cancel()
        fadeAnimator?.cancel()
        overlayAlpha = 0f
        activeMode = AgyPointerOverlayManager.PointerMode.IDLE
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (overlayAlpha <= 0.01f || activeMode == AgyPointerOverlayManager.PointerMode.IDLE) return

        val primaryAccent = if (isAmberAccent) amberPrimary else cyanPrimary
        val secondaryAccent = if (isAmberAccent) amberLight else cyanSecondary
        val alphaInt = (overlayAlpha.coerceIn(0f, 1f) * 255).toInt()

        // 1. Gesture-specific trail or concentric tap ripple
        when (activeMode) {
            AgyPointerOverlayManager.PointerMode.SWIPE -> {
                drawSwipeTrail(canvas, primaryAccent, secondaryAccent, alphaInt)
            }
            AgyPointerOverlayManager.PointerMode.TAP,
            AgyPointerOverlayManager.PointerMode.LONG_PRESS -> {
                drawConcentricRipple(canvas, primaryAccent, secondaryAccent, alphaInt)
            }
            AgyPointerOverlayManager.PointerMode.TYPING -> {
                drawTypingPulse(canvas, primaryAccent, alphaInt)
            }
            else -> Unit
        }

        // 2. Sharp vector mouse arrow cursor at (cursorX, cursorY)
        drawVectorCursor(canvas, cursorX, cursorY, primaryAccent, alphaInt)

        // 3. Compact semi-transparent pill badge anchored next to cursor tip
        if (showLabel && actionLabel.isNotBlank()) {
            drawActionPill(canvas, cursorX, cursorY, actionLabel, primaryAccent, alphaInt)
        }
    }

    private fun drawConcentricRipple(
        canvas: Canvas,
        primaryAccent: Int,
        secondaryAccent: Int,
        baseAlpha: Int
    ) {
        val p = effectProgress.coerceIn(0f, 1f)
        val fade = (1f - p).coerceIn(0f, 1f)
        val outerRadius = (8f + p * 34f) * density
        val innerRadius = (4f + ((p - 0.15f).coerceAtLeast(0f) / 0.85f) * 22f) * density

        rippleGlowPaint.color = Color.argb(
            (baseAlpha * 0.20f * fade).toInt(),
            Color.red(primaryAccent),
            Color.green(primaryAccent),
            Color.blue(primaryAccent)
        )
        canvas.drawCircle(trailEndX, trailEndY, outerRadius * 0.65f, rippleGlowPaint)

        ripplePaint.strokeWidth = (2.6f - p * 1.4f).coerceAtLeast(1f) * density
        ripplePaint.color = Color.argb(
            (baseAlpha * 0.92f * fade).toInt(),
            Color.red(primaryAccent),
            Color.green(primaryAccent),
            Color.blue(primaryAccent)
        )
        canvas.drawCircle(trailEndX, trailEndY, outerRadius, ripplePaint)

        if (p > 0.15f) {
            val innerFade = (1f - (p - 0.15f) / 0.85f).coerceIn(0f, 1f)
            ripplePaint.strokeWidth = 1.7f * density
            ripplePaint.color = Color.argb(
                (baseAlpha * 0.72f * innerFade).toInt(),
                Color.red(secondaryAccent),
                Color.green(secondaryAccent),
                Color.blue(secondaryAccent)
            )
            canvas.drawCircle(trailEndX, trailEndY, innerRadius, ripplePaint)
        }
    }

    private fun drawTypingPulse(canvas: Canvas, primaryAccent: Int, baseAlpha: Int) {
        val p = effectProgress.coerceIn(0f, 1f)
        val fade = (1f - p * 0.75f).coerceIn(0.2f, 1f)
        val radius = (10f + p * 14f) * density
        rippleGlowPaint.color = Color.argb(
            (baseAlpha * 0.16f * fade).toInt(),
            Color.red(primaryAccent),
            Color.green(primaryAccent),
            Color.blue(primaryAccent)
        )
        canvas.drawCircle(trailEndX, trailEndY, radius, rippleGlowPaint)
        ripplePaint.strokeWidth = 1.6f * density
        ripplePaint.color = Color.argb(
            (baseAlpha * 0.80f * fade).toInt(),
            Color.red(primaryAccent),
            Color.green(primaryAccent),
            Color.blue(primaryAccent)
        )
        canvas.drawCircle(trailEndX, trailEndY, radius, ripplePaint)
    }

    private fun drawSwipeTrail(
        canvas: Canvas,
        primaryAccent: Int,
        secondaryAccent: Int,
        baseAlpha: Int
    ) {
        val curEndX = trailStartX + (trailEndX - trailStartX) * effectProgress.coerceIn(0.05f, 1f)
        val curEndY = trailStartY + (trailEndY - trailStartY) * effectProgress.coerceIn(0.05f, 1f)

        val gradient = LinearGradient(
            trailStartX,
            trailStartY,
            curEndX,
            curEndY,
            Color.argb((baseAlpha * 0.22f).toInt(), Color.red(secondaryAccent), Color.green(secondaryAccent), Color.blue(secondaryAccent)),
            Color.argb((baseAlpha * 0.95f).toInt(), Color.red(primaryAccent), Color.green(primaryAccent), Color.blue(primaryAccent)),
            Shader.TileMode.CLAMP
        )

        trailGlowPaint.shader = gradient
        trailGlowPaint.alpha = (baseAlpha * 0.30f).toInt()
        canvas.drawLine(trailStartX, trailStartY, curEndX, curEndY, trailGlowPaint)

        trailCorePaint.shader = gradient
        trailCorePaint.alpha = baseAlpha
        canvas.drawLine(trailStartX, trailStartY, curEndX, curEndY, trailCorePaint)

        trailDashPaint.alpha = (baseAlpha * 0.7f).toInt()
        canvas.drawLine(trailStartX, trailStartY, curEndX, curEndY, trailDashPaint)

        // Start anchor ring
        ripplePaint.strokeWidth = 1.8f * density
        ripplePaint.color = Color.argb((baseAlpha * 0.65f).toInt(), Color.red(secondaryAccent), Color.green(secondaryAccent), Color.blue(secondaryAccent))
        canvas.drawCircle(trailStartX, trailStartY, 5.5f * density, ripplePaint)

        // Arrowhead at current tip
        val dx = curEndX - trailStartX
        val dy = curEndY - trailStartY
        if (dx * dx + dy * dy > 16f) {
            val angle = atan2(dy.toDouble(), dx.toDouble())
            val headLen = 9f * density
            arrowHeadPath.reset()
            arrowHeadPath.moveTo(curEndX, curEndY)
            arrowHeadPath.lineTo(
                (curEndX - headLen * cos(angle - 0.52)).toFloat(),
                (curEndY - headLen * sin(angle - 0.52)).toFloat()
            )
            arrowHeadPath.lineTo(
                (curEndX - headLen * cos(angle + 0.52)).toFloat(),
                (curEndY - headLen * sin(angle + 0.52)).toFloat()
            )
            arrowHeadPath.close()
            rippleGlowPaint.color = Color.argb(baseAlpha, Color.red(primaryAccent), Color.green(primaryAccent), Color.blue(primaryAccent))
            canvas.drawPath(arrowHeadPath, rippleGlowPaint)
        }
    }

    private fun drawVectorCursor(
        canvas: Canvas,
        x: Float,
        y: Float,
        glowColor: Int,
        baseAlpha: Int
    ) {
        val s = density
        cursorPath.reset()
        cursorPath.moveTo(x, y)
        cursorPath.lineTo(x, y + 21.5f * s)
        cursorPath.lineTo(x + 5.6f * s, y + 16.4f * s)
        cursorPath.lineTo(x + 9.4f * s, y + 24.4f * s)
        cursorPath.lineTo(x + 12.6f * s, y + 22.9f * s)
        cursorPath.lineTo(x + 8.9f * s, y + 15.0f * s)
        cursorPath.lineTo(x + 15.8f * s, y + 15.0f * s)
        cursorPath.close()

        cursorGlowStrokePaint.color = Color.argb(
            (baseAlpha * 0.72f).toInt(),
            Color.red(glowColor),
            Color.green(glowColor),
            Color.blue(glowColor)
        )
        canvas.drawPath(cursorPath, cursorGlowStrokePaint)

        cursorFillPaint.alpha = baseAlpha
        canvas.drawPath(cursorPath, cursorFillPaint)

        cursorInnerEdgePaint.alpha = (baseAlpha * 0.45f).toInt()
        canvas.drawPath(cursorPath, cursorInnerEdgePaint)
    }

    private fun drawActionPill(
        canvas: Canvas,
        tipX: Float,
        tipY: Float,
        label: String,
        accentColor: Int,
        baseAlpha: Int
    ) {
        val textWidth = pillTextPaint.measureText(label)
        val dotDiameter = 6f * density
        val padH = 10f * density
        val gap = 6f * density
        val pillWidth = padH * 2f + dotDiameter + gap + textWidth
        val pillHeight = 25f * density
        val margin = 10f * density

        val viewW = max(width.toFloat(), resources.displayMetrics.widthPixels.toFloat())
        val viewH = max(height.toFloat(), resources.displayMetrics.heightPixels.toFloat())

        val preferredLeft = tipX + 18f * density
        val left = if (preferredLeft + pillWidth + margin > viewW) {
            max(margin, tipX - pillWidth - 10f * density)
        } else {
            max(margin, preferredLeft)
        }

        val preferredTop = tipY + 18f * density
        val top = if (preferredTop + pillHeight + margin > viewH) {
            max(margin, tipY - pillHeight - 10f * density)
        } else {
            max(margin, preferredTop)
        }

        pillRect.set(left, top, left + pillWidth, top + pillHeight)
        val radius = pillHeight * 0.5f

        pillBgPaint.alpha = (baseAlpha * 0.88f).toInt()
        canvas.drawRoundRect(pillRect, radius, radius, pillBgPaint)

        pillBorderPaint.color = Color.argb(
            (baseAlpha * 0.78f).toInt(),
            Color.red(accentColor),
            Color.green(accentColor),
            Color.blue(accentColor)
        )
        canvas.drawRoundRect(pillRect, radius, radius, pillBorderPaint)

        pillDotPaint.color = Color.argb(
            baseAlpha,
            Color.red(accentColor),
            Color.green(accentColor),
            Color.blue(accentColor)
        )
        val dotCx = left + padH + dotDiameter * 0.5f
        val dotCy = pillRect.centerY()
        canvas.drawCircle(dotCx, dotCy, dotDiameter * 0.5f, pillDotPaint)

        pillTextPaint.alpha = baseAlpha
        val fm = pillTextPaint.fontMetrics
        val textY = pillRect.centerY() - (fm.ascent + fm.descent) * 0.5f
        canvas.drawText(label, left + padH + dotDiameter + gap, textY, pillTextPaint)
    }
}
