package com.kavach.ui.overlay

import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout

/**
 * Unified Visual Intent & Priority Router for Window 3 (`agy_task_map`).
 *
 * Centralizes all Left-Window routing decisions into deterministic, pure functions so that
 * live UI automation, auto-playing video streams, visual media carousels, and auto-generated
 * diagrams/charts follow a single clear precedence chain:
 *
 * 1. Explicit active `player` or `diagram`
 * 2. Active `results`: video-only -> auto-play `player`; empty items -> never show plain text (synthesize diagram or hide); else visual carousel
 * 3. Explicit `app_pane` / `chess` / `media` / `telemetry`
 * 4. Active `screenWatch` -> live `app_pane` wireframe
 * 5. Smart contextual synthesis -> Mermaid/arrows -> Numeric Metrics/Percentages -> Multi-step Tasks -> Hidden
 */
object AgyVisualWindowRouter {

    private val TEXT_METRIC_PERCENT_REGEX =
        Regex("""(?:^|[,;\n•\-*]\s*)([A-Za-z][A-Za-z0-9 /_-]{1,18})\s*[:=]\s*([-+]?\d+(?:\.\d+)?)\s*%""")

    fun resolve(state: AgyHudOverlayManager.AgyHudState): AgyHudDynamicModels.TaskMapConfig {
        val tm = state.taskMap
        if (tm.active) {
            if (tm.mode == "results") {
                val items = tm.results?.items.orEmpty()
                if (items.isNotEmpty() && items.all { it.kind == "video" && it.uri.isNotBlank() }) {
                    val tracks = items.mapIndexed { idx, v ->
                        AgyHudDynamicModels.PlayerTrackItem(
                            id = v.id.ifBlank { "vid_$idx" },
                            title = v.title,
                            subtitle = v.subtitle,
                            uri = v.uri,
                            mimeType = v.mimeType,
                            thumbnailUri = v.thumbnailUri,
                            isVideo = true,
                            isWebEmbed = AgyHudDynamicModels.PlayerTrackItem.isWebEmbedUri(v.uri)
                        )
                    }
                    return AgyHudDynamicModels.TaskMapConfig(
                        active = true,
                        mode = "player",
                        title = tracks.first().title,
                        widthDp = 228f,
                        persistOnDone = true,
                        player = AgyHudDynamicModels.PlayerTaskMapData(
                            mediaMode = "video",
                            backgroundMode = false,
                            playing = true,
                            playlist = tracks
                        )
                    )
                }
                if (items.isEmpty()) {
                    // Text-only summaries belong exclusively in the Main HUD.
                    return synthesizeDiagram(state) ?: AgyHudDynamicModels.TaskMapConfig(active = false)
                }
            }
            return tm
        }

        val sw = state.screenWatch
        if (sw.active) {
            return AgyHudDynamicModels.TaskMapConfig(
                active = true,
                mode = "app_pane",
                title = sw.label.ifBlank { "App Pane" },
                appPane = AgyHudDynamicModels.AppPaneTaskMapData(
                    targetPackage = state.appPackage,
                    screenWidth = sw.screenWidth,
                    screenHeight = sw.screenHeight,
                    zones = sw.zones.map { z ->
                        AgyHudDynamicModels.TaskMapZone(
                            x1 = z.x1,
                            y1 = z.y1,
                            x2 = z.x2,
                            y2 = z.y2,
                            role = z.role,
                            tag = z.tag
                        )
                    },
                    actionVector = sw.actionVector?.let { v ->
                        AgyHudDynamicModels.TaskMapActionVector(
                            type = v.type,
                            x1 = v.x1,
                            y1 = v.y1,
                            x2 = v.x2,
                            y2 = v.y2
                        )
                    }
                )
            )
        }

        synthesizeDiagram(state)?.let { return it }
        return tm.copy(active = false)
    }

    fun synthesizeDiagram(state: AgyHudOverlayManager.AgyHudState): AgyHudDynamicModels.TaskMapConfig? {
        val fromText = AgyHudDynamicModels.DiagramTaskMapData.fromMermaidOrStructure(
            rawText = state.detailedOutput,
            title = state.title.ifBlank { "Visual Diagram" }
        )
        if (fromText != null) {
            return AgyHudDynamicModels.TaskMapConfig(
                active = true,
                mode = "diagram",
                title = fromText.title.ifBlank { state.title.ifBlank { "Visual Diagram" } },
                widthDp = 236f,
                persistOnDone = true,
                diagram = fromText,
                autoSynthesized = true
            )
        }

        if (state.metrics.size >= 2) {
            val chart = AgyHudDynamicModels.DiagramTaskMapData.fromMetrics(
                metrics = state.metrics,
                title = state.title.ifBlank { "Metrics" }
            )
            if (chart != null) {
                return AgyHudDynamicModels.TaskMapConfig(
                    active = true,
                    mode = "diagram",
                    title = chart.title,
                    widthDp = 236f,
                    persistOnDone = true,
                    diagram = chart,
                    autoSynthesized = true
                )
            }
        }

        extractChartFromText(state.detailedOutput, state.title.ifBlank { "Breakdown" })?.let { chart ->
            return AgyHudDynamicModels.TaskMapConfig(
                active = true,
                mode = "diagram",
                title = chart.title,
                widthDp = 236f,
                persistOnDone = true,
                diagram = chart,
                autoSynthesized = true
            )
        }

        if (state.tasks.size >= 2) {
            val nodes = state.tasks.take(10).mapIndexed { idx, t ->
                val normStatus = when (t.status.lowercase()) {
                    "done" -> "done"
                    "doing" -> "doing"
                    "stopped", "needs_input" -> "error"
                    else -> "pending"
                }
                AgyHudDynamicModels.DiagramNode(
                    id = t.id.ifBlank { "step_${idx + 1}" },
                    label = t.label.ifBlank { "Step ${idx + 1}" }.take(28),
                    role = when (idx) {
                        0 -> "start"
                        state.tasks.lastIndex -> "end"
                        else -> "step"
                    },
                    status = normStatus,
                    layer = idx
                )
            }
            val edges = nodes.zipWithNext().map { (a, b) ->
                AgyHudDynamicModels.DiagramEdge(
                    fromId = a.id,
                    toId = b.id,
                    active = a.status == "doing" || b.status == "doing"
                )
            }
            val diag = AgyHudDynamicModels.DiagramTaskMapData(
                diagramType = "flowchart",
                title = state.title.ifBlank { "Task Flow" },
                nodes = nodes,
                edges = edges,
                activeNodeId = nodes.firstOrNull { it.status == "doing" }?.id.orEmpty()
            )
            return AgyHudDynamicModels.TaskMapConfig(
                active = true,
                mode = "diagram",
                title = diag.title,
                widthDp = 236f,
                persistOnDone = state.state == "DONE",
                diagram = diag,
                autoSynthesized = true
            )
        }

        return null
    }

    fun extractChartFromText(rawText: String, title: String = "Breakdown"): AgyHudDynamicModels.DiagramTaskMapData? {
        val text = rawText.trim()
        if (text.isEmpty()) return null
        val points = TEXT_METRIC_PERCENT_REGEX.findAll(text)
            .mapNotNull { m ->
                val lbl = m.groupValues[1].trim()
                val pct = m.groupValues[2].toFloatOrNull() ?: return@mapNotNull null
                if (lbl.isBlank()) return@mapNotNull null
                AgyHudDynamicModels.DiagramSeriesPoint(
                    label = lbl.take(16),
                    value = pct.coerceIn(0f, 100f),
                    maxValue = 100f,
                    status = if (pct >= 80f) "highlight" else "doing"
                )
            }
            .distinctBy { it.label.lowercase() }
            .take(6)
            .toList()
        if (points.size < 2) return null
        return AgyHudDynamicModels.DiagramTaskMapData(
            diagramType = "chart",
            subChartType = if (points.size <= 3) "radial" else "bar",
            title = title.ifBlank { "Metrics" },
            series = points
        )
    }

    fun dismissSignatureForClearedDiagram(state: AgyHudOverlayManager.AgyHudState): String? {
        return synthesizeDiagram(state)?.contentSignature()
    }

    /**
     * Mutates a child View's dimensions without replacing its parent-specific [ViewGroup.LayoutParams]
     * subclass (preventing `ViewGroup$LayoutParams cannot be cast to LinearLayout$LayoutParams` crashes).
     */
    fun updateLayoutParamsSafe(
        view: View,
        width: Int = ViewGroup.LayoutParams.MATCH_PARENT,
        height: Int
    ) {
        val lp = view.layoutParams
        if (lp == null) {
            val parent = view.parent
            view.layoutParams = when (parent) {
                is LinearLayout -> LinearLayout.LayoutParams(width, height)
                is FrameLayout -> FrameLayout.LayoutParams(width, height)
                else -> LinearLayout.LayoutParams(width, height)
            }
        } else if (lp.width != width || lp.height != height) {
            lp.width = width
            lp.height = height
            view.layoutParams = lp
        }
    }
}
