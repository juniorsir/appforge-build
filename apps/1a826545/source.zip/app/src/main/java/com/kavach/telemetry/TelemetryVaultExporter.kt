package com.kavach.telemetry

import android.os.Environment
import com.kavach.data.local.DeviceSnapshotEntity
import com.kavach.data.local.LocationPointEntity
import com.kavach.data.local.TimelineEventEntity
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/**
 * Serialization, GPS distance analytics, and JSON / CSV / GPX export helpers
 * for the offline telemetry vault.
 */
object TelemetryVaultExporter {

    private fun formatIsoUtc(ts: Long): String {
        val sdf = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US)
        sdf.timeZone = TimeZone.getTimeZone("UTC")
        return sdf.format(Date(ts))
    }

    private fun formatLocal(ts: Long): String =
        SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date(ts))

    fun eventToJson(e: TimelineEventEntity): JSONObject = JSONObject().apply {
        put("id", e.id)
        put("timestamp", e.timestamp)
        put("datetime", formatLocal(e.timestamp))
        put("category", e.category)
        put("subType", e.subType)
        put("title", e.title)
        put("detail", e.detail)
        put("packageName", e.packageName)
        put("domain", e.domain)
        put("severity", e.severity)
        put("syncStatus", e.syncStatus)
        put("syncedAt", e.syncedAt ?: 0L)
        put("expiresAt", e.expiresAt ?: 0L)
    }

    fun locationToJson(p: LocationPointEntity): JSONObject = JSONObject().apply {
        put("id", p.id)
        put("timestamp", p.timestamp)
        put("datetime", formatLocal(p.timestamp))
        put("latitude", p.latitude)
        put("longitude", p.longitude)
        put("altitude", p.altitude)
        put("accuracyMeters", p.accuracyMeters.toDouble())
        put("speedMps", p.speedMps.toDouble())
        put("speedKmh", (p.speedMps * 3.6).toDouble())
        put("bearingDegrees", p.bearingDegrees.toDouble())
        put("provider", p.provider)
        put("batteryPercent", p.batteryPercent)
        put("networkTransport", p.networkTransport)
        put("distanceFromPrevMeters", p.distanceFromPrevMeters.toDouble())
        put("mapsUrl", String.format(Locale.US, "https://maps.google.com/?q=%.6f,%.6f", p.latitude, p.longitude))
        put("syncStatus", p.syncStatus)
        put("syncedAt", p.syncedAt ?: 0L)
        put("expiresAt", p.expiresAt ?: 0L)
    }

    fun snapshotToJson(s: DeviceSnapshotEntity): JSONObject = JSONObject().apply {
        put("id", s.id)
        put("timestamp", s.timestamp)
        put("datetime", formatLocal(s.timestamp))
        put("batteryPercent", s.batteryPercent)
        put("isCharging", s.isCharging)
        put("batteryTempC", s.batteryTempC.toDouble())
        put("networkConnected", s.networkConnected)
        put("networkTransport", s.networkTransport)
        put("wifiSsid", s.wifiSsid)
        put("wifiRssiDbm", s.wifiRssiDbm)
        put("cellularType", s.cellularType)
        put("foregroundPackage", s.foregroundPackage)
        put("isInteractive", s.isInteractive)
        put("syncStatus", s.syncStatus)
        put("syncedAt", s.syncedAt ?: 0L)
        put("expiresAt", s.expiresAt ?: 0L)
    }

    fun computeTotalDistanceMeters(points: List<LocationPointEntity>): Float {
        if (points.size < 2) return 0f
        var total = 0f
        for (i in 1 until points.size) {
            total += OfflineTelemetryVaultManager.haversineMeters(
                points[i - 1].latitude,
                points[i - 1].longitude,
                points[i].latitude,
                points[i].longitude
            )
        }
        return total
    }

    fun buildLocationPathReportJson(points: List<LocationPointEntity>): JSONObject {
        val totalDistM = computeTotalDistanceMeters(points)
        val maxSpeedMps = points.maxOfOrNull { it.speedMps } ?: 0f
        val spanMs = if (points.size >= 2) (points.last().timestamp - points.first().timestamp).coerceAtLeast(0L) else 0L
        val arr = JSONArray()
        points.forEach { arr.put(locationToJson(it)) }

        return JSONObject().apply {
            put("success", true)
            put("waypointCount", points.size)
            put("totalDistanceMeters", totalDistM.toDouble())
            put("totalDistanceKm", totalDistM / 1000.0)
            put("maxSpeedKmh", (maxSpeedMps * 3.6).toDouble())
            put("durationSeconds", spanMs / 1000L)
            put("startTimestamp", points.firstOrNull()?.timestamp ?: 0L)
            put("endTimestamp", points.lastOrNull()?.timestamp ?: 0L)
            put("waypoints", arr)
        }
    }

    fun exportToDownloadsAndPayload(
        format: String,
        category: String,
        events: List<TimelineEventEntity>,
        locations: List<LocationPointEntity>,
        snapshots: List<DeviceSnapshotEntity>
    ): JSONObject {
        val cleanFormat = format.trim().lowercase().let {
            if (it in listOf("csv", "gpx", "json")) it else "json"
        }
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val catTag = if (category.isBlank()) "all" else category.lowercase()
        val fileName = "aeroshare_vault_${catTag}_$stamp.$cleanFormat"

        val contentStr = when (cleanFormat) {
            "gpx" -> buildGpx(locations)
            "csv" -> buildCsv(events, locations)
            else -> buildJson(category, events, locations, snapshots)
        }

        var savedPath = ""
        try {
            val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "AeroShare").apply {
                if (!exists()) mkdirs()
            }
            val target = File(dir, fileName)
            target.writeText(contentStr, Charsets.UTF_8)
            savedPath = target.absolutePath
        } catch (_: Throwable) {}

        return JSONObject().apply {
            put("success", true)
            put("format", cleanFormat)
            put("fileName", fileName)
            put("filePath", savedPath)
            put("exportedEventsCount", events.size)
            put("exportedLocationsCount", locations.size)
            put("exportedSnapshotsCount", snapshots.size)
            put("fileSizeBytes", contentStr.toByteArray(Charsets.UTF_8).size)
            put("content", contentStr)
        }
    }

    private fun buildJson(
        category: String,
        events: List<TimelineEventEntity>,
        locations: List<LocationPointEntity>,
        snapshots: List<DeviceSnapshotEntity>
    ): String {
        val root = JSONObject().apply {
            put("exportedAt", formatLocal(System.currentTimeMillis()))
            put("categoryFilter", category.ifBlank { "ALL" })
            put("retentionPolicy", "20_DAYS_AFTER_SYNC")
            put("eventsCount", events.size)
            put("locationsCount", locations.size)
            put("snapshotsCount", snapshots.size)
            put("events", JSONArray().apply { events.forEach { put(eventToJson(it)) } })
            put("locationPath", JSONArray().apply { locations.forEach { put(locationToJson(it)) } })
            put("deviceSnapshots", JSONArray().apply { snapshots.forEach { put(snapshotToJson(it)) } })
        }
        return root.toString(2)
    }

    private fun buildCsv(
        events: List<TimelineEventEntity>,
        locations: List<LocationPointEntity>
    ): String {
        val sb = StringBuilder()
        sb.append("recordType,timestamp,datetime,category,subType,titleOrLat,detailOrLon,packageOrProvider,domainOrAccuracy,severity,syncStatus,expiresAt\n")
        for (e in events) {
            val safeTitle = e.title.replace("\"", "'").replace(",", ";")
            val safeDetail = e.detail.replace("\"", "'").replace(",", ";")
            sb.append("EVENT,${e.timestamp},\"${formatLocal(e.timestamp)}\",${e.category},${e.subType},\"$safeTitle\",\"$safeDetail\",\"${e.packageName}\",\"${e.domain}\",${e.severity},${e.syncStatus},${e.expiresAt ?: 0L}\n")
        }
        for (p in locations) {
            sb.append("GPS,${p.timestamp},\"${formatLocal(p.timestamp)}\",LOCATION,GPS_WAYPOINT,${p.latitude},${p.longitude},${p.provider},${p.accuracyMeters},INFO,${p.syncStatus},${p.expiresAt ?: 0L}\n")
        }
        return sb.toString()
    }

    private fun buildGpx(locations: List<LocationPointEntity>): String {
        val sb = StringBuilder()
        sb.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n")
        sb.append("<gpx version=\"1.1\" creator=\"AeroShare Offline Vault\" xmlns=\"http://www.topografix.com/GPX/1/1\">\n")
        sb.append("  <trk>\n")
        sb.append("    <name>AeroShare Location Path</name>\n")
        sb.append("    <trkseg>\n")
        for (p in locations) {
            sb.append("      <trkpt lat=\"${p.latitude}\" lon=\"${p.longitude}\">\n")
            sb.append("        <ele>${p.altitude}</ele>\n")
            sb.append("        <time>${formatIsoUtc(p.timestamp)}</time>\n")
            sb.append("        <desc>provider=${p.provider}; acc=${p.accuracyMeters}m; batt=${p.batteryPercent}%; net=${p.networkTransport}; sync=${p.syncStatus}</desc>\n")
            sb.append("      </trkpt>\n")
        }
        sb.append("    </trkseg>\n")
        sb.append("  </trk>\n")
        sb.append("</gpx>\n")
        return sb.toString()
    }
}
