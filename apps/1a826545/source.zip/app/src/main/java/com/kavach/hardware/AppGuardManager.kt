package com.kavach.hardware

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.app.ActivityManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.content.pm.ApplicationInfo
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.graphics.Path
import android.graphics.Rect
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.util.Log
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast
import androidx.core.app.NotificationCompat
import com.kavach.MainActivity
import com.kavach.R
import com.kavach.accessibility.AccessibilityServiceRegistry
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

data class AppLifecycleEvent(
    val id: String,
    val eventType: String, // INSTALLED, UPDATED, UNINSTALLED, BLOCKED_LAUNCH, APP_BLOCKED, APP_UNBLOCKED
    val appName: String,
    val packageName: String,
    val versionName: String = "",
    val installerSource: String = "",
    val details: String = "",
    val timestampMs: Long = System.currentTimeMillis()
) {
    val formattedTime: String
        get() = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date(timestampMs))

    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("eventType", eventType)
        put("appName", appName)
        put("packageName", packageName)
        put("versionName", versionName)
        put("installerSource", installerSource)
        put("details", details)
        put("timestampMs", timestampMs)
        put("formattedTime", formattedTime)
    }
}

/**
 * Monitors real-time app installations, updates, and uninstallations; dispatches on-device and
 * WebSocket alerts; enforces real-time app blocking; and provides package uninstallation,
 * force-stop, and deep inspection controls.
 */
class AppGuardManager(
    private val context: Context,
    private val scope: CoroutineScope
) {
    companion object {
        private const val TAG = "AppGuardManager"
        private const val PREFS_NAME = "aero_app_guard_prefs"
        private const val KEY_BLOCKED_PKGS = "blocked_packages"
        private const val KEY_ALERT_INSTALL = "alert_on_install"
        private const val KEY_ALERT_UNINSTALL = "alert_on_uninstall"
        private const val KEY_ALERT_BLOCKED = "alert_on_blocked"
        private const val KEY_AUTO_BLOCK_NEW = "auto_block_new_installs"
        private const val KEY_EVENT_HISTORY = "event_history_json"
        private const val CHANNEL_ID = "aero_app_guard_alerts"

        @Volatile
        var activeInstance: AppGuardManager? = null
            private set
    }

    private val prefs: SharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    private val mainHandler = Handler(Looper.getMainLooper())
    private val appLabelsCache = ConcurrentHashMap<String, String>()
    private val lastBlockInterceptMs = ConcurrentHashMap<String, Long>()

    private val _blockedPackages = MutableStateFlow<Set<String>>(emptySet())
    val blockedPackages: StateFlow<Set<String>> = _blockedPackages.asStateFlow()

    private val _alertOnInstall = MutableStateFlow(true)
    val alertOnInstall: StateFlow<Boolean> = _alertOnInstall.asStateFlow()

    private val _alertOnUninstall = MutableStateFlow(true)
    val alertOnUninstall: StateFlow<Boolean> = _alertOnUninstall.asStateFlow()

    private val _alertOnBlockedLaunch = MutableStateFlow(true)
    val alertOnBlockedLaunch: StateFlow<Boolean> = _alertOnBlockedLaunch.asStateFlow()

    private val _autoBlockNewInstalls = MutableStateFlow(false)
    val autoBlockNewInstalls: StateFlow<Boolean> = _autoBlockNewInstalls.asStateFlow()

    private val _recentEvents = MutableStateFlow<List<AppLifecycleEvent>>(emptyList())
    val recentEvents: StateFlow<List<AppLifecycleEvent>> = _recentEvents.asStateFlow()

    var onAppEventBroadcast: ((AppLifecycleEvent) -> Unit)? = null
    var onAppsChangedCallback: (() -> Unit)? = null

    private var monitorJob: Job? = null

    private val protectedPackages = setOf(
        context.packageName,
        "com.android.systemui",
        "com.android.settings",
        "com.google.android.packageinstaller",
        "com.android.packageinstaller",
        "com.termux"
    )

    private val packageReceiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context?, intent: Intent?) {
            if (intent == null) return
            val pkg = intent.data?.schemeSpecificPart?.trim().orEmpty()
            if (pkg.isEmpty()) return
            val isReplacing = intent.getBooleanExtra(Intent.EXTRA_REPLACING, false)

            when (intent.action) {
                Intent.ACTION_PACKAGE_ADDED -> {
                    if (!isReplacing) {
                        handlePackageInstalled(pkg)
                    } else {
                        handlePackageUpdated(pkg)
                    }
                }
                Intent.ACTION_PACKAGE_REPLACED -> {
                    handlePackageUpdated(pkg)
                }
                Intent.ACTION_PACKAGE_REMOVED -> {
                    if (!isReplacing) {
                        handlePackageUninstalled(pkg)
                    }
                }
            }
        }
    }

    init {
        activeInstance = this
        loadPersistedState()
        createAlertNotificationChannel()
        registerPackageReceiver()
        startForegroundBlockerLoop()
    }

    private fun loadPersistedState() {
        val savedBlocked = prefs.getStringSet(KEY_BLOCKED_PKGS, emptySet()) ?: emptySet()
        _blockedPackages.value = savedBlocked.toSet()
        _alertOnInstall.value = prefs.getBoolean(KEY_ALERT_INSTALL, true)
        _alertOnUninstall.value = prefs.getBoolean(KEY_ALERT_UNINSTALL, true)
        _alertOnBlockedLaunch.value = prefs.getBoolean(KEY_ALERT_BLOCKED, true)
        _autoBlockNewInstalls.value = prefs.getBoolean(KEY_AUTO_BLOCK_NEW, false)

        val rawHistory = prefs.getString(KEY_EVENT_HISTORY, "[]").orEmpty()
        try {
            val arr = JSONArray(rawHistory)
            val loaded = mutableListOf<AppLifecycleEvent>()
            for (i in 0 until arr.length()) {
                val obj = arr.optJSONObject(i) ?: continue
                loaded.add(
                    AppLifecycleEvent(
                        id = obj.optString("id", "evt_$i"),
                        eventType = obj.optString("eventType", "INSTALLED"),
                        appName = obj.optString("appName", ""),
                        packageName = obj.optString("packageName", ""),
                        versionName = obj.optString("versionName", ""),
                        installerSource = obj.optString("installerSource", ""),
                        details = obj.optString("details", ""),
                        timestampMs = obj.optLong("timestampMs", System.currentTimeMillis())
                    )
                )
            }
            _recentEvents.value = loaded
        } catch (_: Exception) {}
    }

    private fun saveEventHistory(events: List<AppLifecycleEvent>) {
        try {
            val arr = JSONArray()
            events.take(80).forEach { arr.put(it.toJson()) }
            prefs.edit().putString(KEY_EVENT_HISTORY, arr.toString()).apply()
        } catch (_: Exception) {}
    }

    fun trimCaches(aggressive: Boolean = false) {
        if (aggressive) {
            appLabelsCache.clear()
            lastBlockInterceptMs.clear()
        } else if (appLabelsCache.size > 200) {
            val it = appLabelsCache.keys.iterator()
            var n = appLabelsCache.size - 150
            while (it.hasNext() && n > 0) {
                it.next(); it.remove(); n--
            }
        }
    }

    private fun registerPackageReceiver() {
        try {
            val filter = IntentFilter().apply {
                addAction(Intent.ACTION_PACKAGE_ADDED)
                addAction(Intent.ACTION_PACKAGE_REPLACED)
                addAction(Intent.ACTION_PACKAGE_REMOVED)
                addDataScheme("package")
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                context.registerReceiver(packageReceiver, filter, Context.RECEIVER_EXPORTED)
            } else {
                context.registerReceiver(packageReceiver, filter)
            }
            Log.i(TAG, "Real-time Package Installation/Uninstallation BroadcastReceiver registered")
        } catch (e: Exception) {
            Log.e(TAG, "Failed registering package receiver: ${e.message}", e)
        }
    }

    private fun startForegroundBlockerLoop() {
        monitorJob?.cancel()
        monitorJob = scope.launch(Dispatchers.IO) {
            while (isActive) {
                val blocked = _blockedPackages.value
                try {
                    if (blocked.isNotEmpty()) {
                        val fgPkg = detectForegroundPackageViaUsageStats()
                        if (fgPkg != null && blocked.contains(fgPkg)) {
                            interceptForegroundPackage(fgPkg, source = "USAGE_STATS_MONITOR")
                        }
                    }
                } catch (_: Exception) {}
                delay(if (blocked.isEmpty()) 5000L else 1200L)
            }
        }
    }

    private fun detectForegroundPackageViaUsageStats(): String? {
        return try {
            val usm = context.getSystemService(Context.USAGE_STATS_SERVICE) as? UsageStatsManager ?: return null
            val now = System.currentTimeMillis()
            val events = usm.queryEvents(now - 5000L, now)
            val event = UsageEvents.Event()
            var latestPkg: String? = null
            var latestTime = 0L
            while (events.hasNextEvent()) {
                events.getNextEvent(event)
                if (event.eventType == UsageEvents.Event.ACTIVITY_RESUMED ||
                    event.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND
                ) {
                    if (event.timeStamp >= latestTime) {
                        latestTime = event.timeStamp
                        latestPkg = event.packageName
                    }
                }
            }
            latestPkg
        } catch (_: Exception) {
            null
        }
    }

    private fun handlePackageInstalled(pkg: String) {
        scope.launch(Dispatchers.IO) {
            val label = resolveAppLabel(pkg)
            appLabelsCache[pkg] = label
            val version = resolveVersionName(pkg)
            val installer = resolveInstallerName(pkg)

            val adultShield = com.kavach.security.AdultContentShieldManager.activeInstance
            val shieldVerdict = adultShield?.evaluateInstalledOrLaunchingPackage(pkg, label)
            val blockedByAdultShield = shieldVerdict?.blocked == true && !protectedPackages.contains(pkg)

            val autoBlocked = if ((_autoBlockNewInstalls.value || blockedByAdultShield) && !protectedPackages.contains(pkg)) {
                blockApp(pkg, silentEvent = true)
                if (blockedByAdultShield) {
                    com.kavach.network.PerAppNetworkMonitor.activeInstance?.blockAppNetwork(pkg)
                }
                true
            } else false

            if (blockedByAdultShield && shieldVerdict != null) {
                adultShield?.enforceViolation(shieldVerdict, packageName = pkg, kickHome = true)
            }

            val detailMsg = buildString {
                append("New app installed ($version) via $installer")
                if (blockedByAdultShield) {
                    append(" • AUTO-BLOCKED by Adult Content Shield (${shieldVerdict?.reason})")
                } else if (autoBlocked) {
                    append(" • AUTO-BLOCKED by Lockdown Policy")
                }
            }
            val evt = recordEvent(
                eventType = "INSTALLED",
                appName = label,
                packageName = pkg,
                versionName = version,
                installerSource = installer,
                details = detailMsg
            )

            if (_alertOnInstall.value) {
                postSystemAlertNotification(
                    title = if (autoBlocked) "🛡️ New App Installed & Auto-Blocked: $label" else "📦 New App Installed: $label",
                    body = "$pkg ($version) • Source: $installer",
                    packageName = pkg,
                    includeUninstallAction = true
                )
            }
            onAppsChangedCallback?.invoke()
            onAppEventBroadcast?.invoke(evt)
        }
    }

    private fun handlePackageUpdated(pkg: String) {
        scope.launch(Dispatchers.IO) {
            val label = resolveAppLabel(pkg)
            appLabelsCache[pkg] = label
            val version = resolveVersionName(pkg)
            val installer = resolveInstallerName(pkg)
            val evt = recordEvent(
                eventType = "UPDATED",
                appName = label,
                packageName = pkg,
                versionName = version,
                installerSource = installer,
                details = "App updated to $version via $installer"
            )
            if (_alertOnInstall.value) {
                postSystemAlertNotification(
                    title = "🔄 App Updated: $label",
                    body = "$pkg updated to $version ($installer)",
                    packageName = pkg,
                    includeUninstallAction = true
                )
            }
            onAppsChangedCallback?.invoke()
            onAppEventBroadcast?.invoke(evt)
        }
    }

    private fun handlePackageUninstalled(pkg: String) {
        scope.launch(Dispatchers.IO) {
            val label = appLabelsCache.remove(pkg) ?: pkg
            val evt = recordEvent(
                eventType = "UNINSTALLED",
                appName = label,
                packageName = pkg,
                details = "App uninstalled from device"
            )
            if (_alertOnUninstall.value) {
                postSystemAlertNotification(
                    title = "🗑️ App Uninstalled: $label",
                    body = "Package $pkg was removed from the device.",
                    packageName = pkg,
                    includeUninstallAction = false
                )
            }
            onAppsChangedCallback?.invoke()
            onAppEventBroadcast?.invoke(evt)
        }
    }

    fun isPackageBlocked(packageName: String?): Boolean {
        if (packageName.isNullOrBlank()) return false
        return _blockedPackages.value.contains(packageName.trim())
    }

    /**
     * Called immediately by TermuxAccessibilityService or UsageStats monitor when a package
     * enters the foreground. If blocked (or prohibited by AdultContentShieldManager), navigates Home,
     * kills background processes, and alerts.
     */
    fun interceptForegroundPackage(packageName: String?, source: String = "ACCESSIBILITY_GUARD"): Boolean {
        val pkg = packageName?.trim().orEmpty()
        if (pkg.isEmpty() || protectedPackages.contains(pkg)) return false

        var isBlocked = _blockedPackages.value.contains(pkg)
        val adultShield = com.kavach.security.AdultContentShieldManager.activeInstance
        var shieldVerdict: com.kavach.security.ShieldVerdict? = null

        if (!isBlocked && adultShield != null && adultShield.strictModeEnabled) {
            val label = appLabelsCache[pkg] ?: resolveAppLabel(pkg)
            val v = adultShield.evaluateInstalledOrLaunchingPackage(pkg, label)
            if (v.blocked) {
                shieldVerdict = v
                isBlocked = true
                blockApp(pkg, silentEvent = true)
                com.kavach.network.PerAppNetworkMonitor.activeInstance?.blockAppNetwork(pkg)
            }
        }

        if (!isBlocked) return false

        val now = System.currentTimeMillis()
        val lastMs = lastBlockInterceptMs[pkg] ?: 0L
        // Always perform Home action immediately so the user cannot interact with the blocked app
        val accService = AccessibilityServiceRegistry.activeService
        if (accService != null) {
            try {
                accService.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME)
            } catch (_: Exception) {}
        }
        try {
            val am = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
            am?.killBackgroundProcesses(pkg)
        } catch (_: Exception) {}

        if (shieldVerdict != null) {
            adultShield?.enforceViolation(shieldVerdict, packageName = pkg, kickHome = true)
        }

        // Throttle toast/notification/event creation to once every 2.5 seconds per blocked launch attempt
        if (now - lastMs >= 2500L) {
            lastBlockInterceptMs[pkg] = now
            val label = resolveAppLabel(pkg)
            mainHandler.post {
                try {
                    Toast.makeText(
                        context,
                        "⛔ Blocked by AeroShare App Guard: $label",
                        Toast.LENGTH_SHORT
                    ).show()
                } catch (_: Exception) {}
            }
            val evt = recordEvent(
                eventType = "BLOCKED_LAUNCH",
                appName = label,
                packageName = pkg,
                details = if (shieldVerdict != null) "Blocked by Adult Content Shield (${shieldVerdict.reason})" else "Blocked foreground launch attempt ($source)"
            )
            if (_alertOnBlockedLaunch.value) {
                postSystemAlertNotification(
                    title = "⛔ Blocked App Launch: $label",
                    body = "$pkg was prevented from opening ($source).",
                    packageName = pkg,
                    includeUninstallAction = true
                )
            }
            onAppEventBroadcast?.invoke(evt)
        }
        return true
    }

    fun resolvePackageIdentifier(target: String): String? {
        val clean = target.trim()
        if (clean.isEmpty()) return null
        val pm = context.packageManager
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                pm.getPackageInfo(clean, PackageManager.PackageInfoFlags.of(0L))
            } else {
                @Suppress("DEPRECATION")
                pm.getPackageInfo(clean, 0)
            }
            return clean
        } catch (_: Exception) {}

        // Search by app label or partial package name
        val lower = clean.lowercase()
        return try {
            val apps = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                pm.getInstalledApplications(PackageManager.ApplicationInfoFlags.of(0L))
            } else {
                @Suppress("DEPRECATION")
                pm.getInstalledApplications(0)
            }
            val exactLabel = apps.firstOrNull {
                pm.getApplicationLabel(it)?.toString()?.trim()?.lowercase() == lower
            }
            if (exactLabel != null) return exactLabel.packageName

            val partialMatch = apps.firstOrNull {
                val lbl = pm.getApplicationLabel(it)?.toString()?.trim()?.lowercase().orEmpty()
                lbl.contains(lower) || it.packageName.lowercase().contains(lower)
            }
            partialMatch?.packageName
        } catch (_: Exception) {
            null
        }
    }

    fun blockApp(target: String, silentEvent: Boolean = false): JSONObject {
        val pkg = resolvePackageIdentifier(target) ?: target.trim()
        if (pkg.isEmpty()) {
            return JSONObject().put("success", false).put("error", "Missing package name or app name")
        }
        if (protectedPackages.contains(pkg)) {
            return JSONObject()
                .put("success", false)
                .put("packageName", pkg)
                .put("error", "Cannot block protected system/bridge package: $pkg")
        }
        val updated = _blockedPackages.value.toMutableSet().apply { add(pkg) }
        _blockedPackages.value = updated
        prefs.edit().putStringSet(KEY_BLOCKED_PKGS, updated).apply()

        val label = resolveAppLabel(pkg)
        try {
            val am = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
            am?.killBackgroundProcesses(pkg)
        } catch (_: Exception) {}

        if (!silentEvent) {
            val evt = recordEvent(
                eventType = "APP_BLOCKED",
                appName = label,
                packageName = pkg,
                details = "App added to active blocklist"
            )
            onAppEventBroadcast?.invoke(evt)
        }
        onAppsChangedCallback?.invoke()

        return JSONObject().apply {
            put("success", true)
            put("action", "BLOCKED")
            put("appName", label)
            put("packageName", pkg)
            put("blockedCount", updated.size)
            put("isAccessibilityEnforcementActive", AccessibilityServiceRegistry.activeService != null)
        }
    }

    fun unblockApp(target: String, unblockAll: Boolean = false): JSONObject {
        if (unblockAll || target.trim().equals("all", ignoreCase = true)) {
            val count = _blockedPackages.value.size
            _blockedPackages.value = emptySet()
            prefs.edit().putStringSet(KEY_BLOCKED_PKGS, emptySet()).apply()
            recordEvent(
                eventType = "APP_UNBLOCKED",
                appName = "All Blocked Apps",
                packageName = "*",
                details = "Cleared $count blocked app(s)"
            )
            onAppsChangedCallback?.invoke()
            return JSONObject().apply {
                put("success", true)
                put("action", "UNBLOCKED_ALL")
                put("clearedCount", count)
            }
        }
        val pkg = resolvePackageIdentifier(target) ?: target.trim()
        val updated = _blockedPackages.value.toMutableSet()
        val removed = updated.remove(pkg)
        _blockedPackages.value = updated
        prefs.edit().putStringSet(KEY_BLOCKED_PKGS, updated).apply()
        val label = resolveAppLabel(pkg)
        if (removed) {
            val evt = recordEvent(
                eventType = "APP_UNBLOCKED",
                appName = label,
                packageName = pkg,
                details = "App removed from blocklist"
            )
            onAppEventBroadcast?.invoke(evt)
        }
        onAppsChangedCallback?.invoke()
        return JSONObject().apply {
            put("success", true)
            put("action", "UNBLOCKED")
            put("appName", label)
            put("packageName", pkg)
            put("wasBlocked", removed)
            put("blockedCount", updated.size)
        }
    }

    @Volatile
    private var pendingAutoConfirmPkg: String? = null

    @Volatile
    private var pendingAutoConfirmDeadlineMs: Long = 0L

    @Volatile
    private var lastAutoClickedLabel: String? = null

    fun armVpnDialogAutoClick(durationMs: Long = 10_000L) {
        pendingAutoConfirmPkg = "vpn_consent"
        pendingAutoConfirmDeadlineMs = System.currentTimeMillis() + durationMs
        lastAutoClickedLabel = null
        scope.launch(Dispatchers.Default) {
            val end = System.currentTimeMillis() + 3500L
            while (System.currentTimeMillis() < end && pendingAutoConfirmPkg == "vpn_consent") {
                val clicked = tryClickUninstallOrDisableConfirmNodes("vpn_consent")
                if (clicked != null) {
                    pendingAutoConfirmPkg = null
                    break
                }
                delay(220L)
            }
        }
    }

    fun onAccessibilityWindowChanged(packageName: String?) {
        val targetPkg = pendingAutoConfirmPkg ?: return
        if (System.currentTimeMillis() > pendingAutoConfirmDeadlineMs) {
            pendingAutoConfirmPkg = null
            return
        }
        val pkgLower = packageName?.lowercase().orEmpty()
        if (pkgLower.contains("packageinstaller") ||
            pkgLower.contains("permissioncontroller") ||
            pkgLower.contains("vpndialogs") ||
            pkgLower.contains("settings") ||
            pkgLower.contains("miui") ||
            pkgLower.contains("samsung")
        ) {
            tryClickUninstallOrDisableConfirmNodes(targetPkg)
        }
    }

    private fun tryClickUninstallOrDisableConfirmNodes(targetPkg: String): String? {
        val service = AccessibilityServiceRegistry.activeService ?: return null
        val roots = mutableListOf<AccessibilityNodeInfo>()
        try {
            service.rootInActiveWindow?.let { roots.add(it) }
        } catch (_: Exception) {}
        try {
            service.windows?.forEach { win ->
                win.root?.let { r -> if (!roots.contains(r)) roots.add(r) }
            }
        } catch (_: Exception) {}
        if (roots.isEmpty()) return null

        // Priority 1: Positive dialog confirmation buttons (android:id/button1 or "disable app", "ok", "uninstall")
        val dialogConfirmLabels = listOf(
            "disable app",
            "uninstall",
            "uninstall updates",
            "ok",
            "delete",
            "remove",
            "yes",
            "confirm"
        )
        // Priority 2: Action buttons inside Settings -> App Info ("disable", "uninstall")
        val settingsActionLabels = listOf(
            "disable",
            "uninstall"
        )
        val negativeLabels = setOf("cancel", "no", "keep", "don't", "close", "open", "force stop")

        for (root in roots) {
            val allNodes = mutableListOf<AccessibilityNodeInfo>()
            collectNodesRecursively(root, allNodes)

            // 1. Check standard Android dialog positive button ID (android:id/button1)
            for (node in allNodes) {
                val resId = try { node.viewIdResourceName?.lowercase().orEmpty() } catch (_: Exception) { "" }
                val txt = try { node.text?.toString()?.trim().orEmpty() } catch (_: Exception) { "" }
                val txtLower = txt.lowercase()
                if ((resId.endsWith(":id/button1") || resId.contains("positive_button")) &&
                    txtLower !in negativeLabels &&
                    node.isEnabled
                ) {
                    if (performClickOrTapNode(service, node)) {
                        val clicked = txt.ifEmpty { "OK" }
                        lastAutoClickedLabel = clicked
                        return clicked
                    }
                }
            }

            // 2. Check explicit confirmation button text in dialogs
            for (labelTarget in dialogConfirmLabels) {
                for (node in allNodes) {
                    val txt = try { node.text?.toString()?.trim().orEmpty() } catch (_: Exception) { "" }
                    val desc = try { node.contentDescription?.toString()?.trim().orEmpty() } catch (_: Exception) { "" }
                    val candidate = txt.ifEmpty { desc }.lowercase()
                    val cls = try { node.className?.toString()?.lowercase().orEmpty() } catch (_: Exception) { "" }
                    val isBtnLike = cls.contains("button") || node.isClickable || (node.parent?.isClickable == true)
                    if (isBtnLike && node.isEnabled && candidate == labelTarget && candidate !in negativeLabels) {
                        if (performClickOrTapNode(service, node)) {
                            val clicked = txt.ifEmpty { desc.ifEmpty { labelTarget } }
                            lastAutoClickedLabel = clicked
                            return clicked
                        }
                    }
                }
            }

            // 3. Check Settings App Info screen "Disable" / "Uninstall" button
            for (labelTarget in settingsActionLabels) {
                for (node in allNodes) {
                    val txt = try { node.text?.toString()?.trim().orEmpty() } catch (_: Exception) { "" }
                    val desc = try { node.contentDescription?.toString()?.trim().orEmpty() } catch (_: Exception) { "" }
                    val candidate = txt.ifEmpty { desc }.lowercase()
                    if (node.isEnabled && candidate == labelTarget) {
                        if (performClickOrTapNode(service, node)) {
                            val clicked = txt.ifEmpty { desc.ifEmpty { labelTarget } }
                            lastAutoClickedLabel = clicked
                            return clicked
                        }
                    }
                }
            }
        }
        return null
    }

    private fun collectNodesRecursively(node: AccessibilityNodeInfo?, out: MutableList<AccessibilityNodeInfo>) {
        if (node == null || out.size > 400) return
        out.add(node)
        val count = try { node.childCount } catch (_: Exception) { 0 }
        for (i in 0 until count) {
            val child = try { node.getChild(i) } catch (_: Exception) { null }
            if (child != null) {
                collectNodesRecursively(child, out)
            }
        }
    }

    private fun performClickOrTapNode(service: AccessibilityService, node: AccessibilityNodeInfo): Boolean {
        try {
            if (node.isClickable && node.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                return true
            }
            var parent = node.parent
            var depth = 0
            while (parent != null && depth < 4) {
                if (parent.isClickable && parent.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                    return true
                }
                parent = parent.parent
                depth++
            }
            val rect = Rect()
            node.getBoundsInScreen(rect)
            if (rect.width() > 0 && rect.height() > 0 && Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                val cx = rect.exactCenterX()
                val cy = rect.exactCenterY()
                val path = Path().apply { moveTo(cx, cy) }
                val stroke = GestureDescription.StrokeDescription(path, 0L, 60L)
                val gesture = GestureDescription.Builder().addStroke(stroke).build()
                return service.dispatchGesture(gesture, null, null)
            }
        } catch (_: Exception) {}
        return false
    }

    fun uninstallApp(target: String): JSONObject {
        val pkg = resolvePackageIdentifier(target)
        if (pkg.isNullOrBlank()) {
            return JSONObject().put("success", false).put("error", "App not found for '$target'")
        }
        if (pkg == context.packageName) {
            return JSONObject().put("success", false).put("error", "Cannot uninstall AeroShare host app")
        }
        val label = resolveAppLabel(pkg)
        var isSys = false
        var isUpdatedSys = false
        try {
            val pm = context.packageManager
            val ai = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                pm.getApplicationInfo(pkg, PackageManager.ApplicationInfoFlags.of(0L))
            } else {
                @Suppress("DEPRECATION")
                pm.getApplicationInfo(pkg, 0)
            }
            isSys = (ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0
            isUpdatedSys = (ai.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0
        } catch (_: Exception) {}

        // 1. Try silent root / shell pm uninstall or disable-user first (0 confirmation if privileged)
        val silentCommands = buildList {
            add("su -c 'pm uninstall $pkg'")
            add("su -c 'pm uninstall -k --user 0 $pkg'")
            if (isSys) add("su -c 'pm disable-user --user 0 $pkg'")
            add("pm uninstall $pkg")
            add("pm uninstall -k --user 0 $pkg")
            add("cmd package uninstall $pkg")
            add("cmd package uninstall -k --user 0 $pkg")
            if (isSys) add("cmd package disable-user --user 0 $pkg")
        }
        for (cmd in silentCommands) {
            try {
                val proc = ProcessBuilder("sh", "-c", cmd).redirectErrorStream(true).start()
                val finished = proc.waitFor(1800, java.util.concurrent.TimeUnit.MILLISECONDS)
                val output = proc.inputStream.bufferedReader().readText().trim()
                if (finished && proc.exitValue() == 0 &&
                    (output.contains("Success", ignoreCase = true) || output.contains("new state: disabled", ignoreCase = true))
                ) {
                    return JSONObject().apply {
                        put("success", true)
                        put("action", "UNINSTALLED_SILENT")
                        put("appName", label)
                        put("packageName", pkg)
                        put("isSystemApp", isSys)
                        put("autoConfirmed", true)
                        put("message", "Silently uninstalled/disabled $label ($pkg) with zero confirmation.")
                    }
                }
            } catch (_: Exception) {}
        }

        // 2. Arm Zero-Confirmation Accessibility Auto-Clicker
        val accActive = AccessibilityServiceRegistry.activeService != null
        lastAutoClickedLabel = null
        pendingAutoConfirmPkg = pkg
        pendingAutoConfirmDeadlineMs = System.currentTimeMillis() + 8000L

        return try {
            // For base system apps without updates (like factory YouTube), ACTION_DELETE is rejected by Android OS,
            // so we launch App Details to auto-click "Disable" -> "Disable app" AND enforce App Guard block + force-stop.
            if (isSys && !isUpdatedSys) {
                blockApp(pkg, silentEvent = true)
                forceStopApp(pkg)
                if (accActive) {
                    val detailsIntent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg")).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                    }
                    context.startActivity(detailsIntent)
                } else {
                    val deleteIntent = Intent(Intent.ACTION_DELETE, Uri.parse("package:$pkg")).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    context.startActivity(deleteIntent)
                }
            } else {
                val deleteIntent = Intent(Intent.ACTION_DELETE, Uri.parse("package:$pkg")).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(deleteIntent)
                if (isSys) {
                    blockApp(pkg, silentEvent = true)
                    forceStopApp(pkg)
                }
            }

            // Poll & auto-click confirmation dialog buttons automatically if AccessibilityService is active
            val clickedSteps = mutableListOf<String>()
            if (accActive) {
                val startWait = System.currentTimeMillis()
                while (System.currentTimeMillis() - startWait < 3200L) {
                    Thread.sleep(220L)
                    val clicked = tryClickUninstallOrDisableConfirmNodes(pkg)
                    if (clicked != null && !clickedSteps.contains(clicked)) {
                        clickedSteps.add(clicked)
                        // If we clicked the final confirmation ("OK" / "Disable app"), wait briefly and finish
                        if (clicked.equals("OK", ignoreCase = true) ||
                            clicked.equals("Disable app", ignoreCase = true) ||
                            (!isSys && clicked.equals("Uninstall", ignoreCase = true))
                        ) {
                            Thread.sleep(350L)
                            break
                        }
                    }
                }
                if (isSys) {
                    try {
                        AccessibilityServiceRegistry.activeService?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME)
                    } catch (_: Exception) {}
                }
                pendingAutoConfirmPkg = null
            }

            val autoConfirmed = clickedSteps.isNotEmpty()
            JSONObject().apply {
                put("success", true)
                put(
                    "action",
                    when {
                        autoConfirmed && isSys -> "SYSTEM_APP_AUTO_DISABLED_AND_BLOCKED"
                        autoConfirmed -> "UNINSTALLED_AUTO_CONFIRMED"
                        isSys -> "SYSTEM_APP_BLOCKED_AND_STOPPED"
                        else -> "UNINSTALL_PROMPT_LAUNCHED"
                    }
                )
                put("appName", label)
                put("packageName", pkg)
                put("isSystemApp", isSys)
                put("autoConfirmed", autoConfirmed)
                put("accessibilityActive", accActive)
                put("clickedButtons", JSONArray(clickedSteps))
                put(
                    "message",
                    when {
                        autoConfirmed && isSys ->
                            "Auto-confirmed (${clickedSteps.joinToString(" -> ")}) + blocked & force-stopped $label ($pkg) with zero manual confirmation."
                        autoConfirmed ->
                            "Auto-confirmed uninstall (${clickedSteps.joinToString(" -> ")}) for $label ($pkg) with zero manual confirmation."
                        isSys && !accActive ->
                            "Force-stopped & blocked $label ($pkg) immediately. Enable AeroShare Accessibility once ('python send_cmd.py permissions settings accessibility') for automatic zero-confirmation clicking."
                        isSys ->
                            "Force-stopped & blocked $label ($pkg) so it cannot open."
                        !accActive ->
                            "Launched uninstall dialog for $label ($pkg). Enable AeroShare Accessibility once ('python send_cmd.py permissions settings accessibility') so future uninstalls auto-click 'OK' without confirmation!"
                        else ->
                            "Triggered uninstall for $label ($pkg) with auto-confirmation watcher active."
                    }
                )
            }
        } catch (e: Exception) {
            pendingAutoConfirmPkg = null
            JSONObject().apply {
                put("success", false)
                put("packageName", pkg)
                put("isSystemApp", isSys)
                put("error", e.message ?: "Failed to launch uninstaller for $pkg")
            }
        }
    }

    fun forceStopApp(target: String): JSONObject {
        val pkg = resolvePackageIdentifier(target)
        if (pkg.isNullOrBlank()) {
            return JSONObject().put("success", false).put("error", "App not found for '$target'")
        }
        val label = resolveAppLabel(pkg)
        var killedBg = false
        try {
            val am = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
            am?.killBackgroundProcesses(pkg)
            killedBg = true
        } catch (_: Exception) {}

        var shellStopped = false
        try {
            val proc = ProcessBuilder("sh", "-c", "am force-stop $pkg").redirectErrorStream(true).start()
            shellStopped = proc.waitFor(2000, java.util.concurrent.TimeUnit.MILLISECONDS) && proc.exitValue() == 0
        } catch (_: Exception) {}

        return JSONObject().apply {
            put("success", killedBg || shellStopped)
            put("action", "FORCE_STOPPED")
            put("appName", label)
            put("packageName", pkg)
            put("killedBackgroundProcesses", killedBg)
            put("shellForceStopped", shellStopped)
        }
    }

    fun openAppSettings(target: String): JSONObject {
        val pkg = resolvePackageIdentifier(target) ?: target.trim()
        if (pkg.isEmpty()) {
            return JSONObject().put("success", false).put("error", "Missing package name")
        }
        return try {
            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg")).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            JSONObject().apply {
                put("success", true)
                put("action", "OPENED_APP_DETAILS")
                put("packageName", pkg)
                put("appName", resolveAppLabel(pkg))
            }
        } catch (e: Exception) {
            JSONObject().put("success", false).put("error", e.message ?: "Could not open App Info")
        }
    }

    fun updatePolicy(
        alertInstall: Boolean? = null,
        alertUninstall: Boolean? = null,
        alertBlocked: Boolean? = null,
        autoBlockNew: Boolean? = null
    ): JSONObject {
        val editor = prefs.edit()
        alertInstall?.let {
            _alertOnInstall.value = it
            editor.putBoolean(KEY_ALERT_INSTALL, it)
        }
        alertUninstall?.let {
            _alertOnUninstall.value = it
            editor.putBoolean(KEY_ALERT_UNINSTALL, it)
        }
        alertBlocked?.let {
            _alertOnBlockedLaunch.value = it
            editor.putBoolean(KEY_ALERT_BLOCKED, it)
        }
        autoBlockNew?.let {
            _autoBlockNewInstalls.value = it
            editor.putBoolean(KEY_AUTO_BLOCK_NEW, it)
        }
        editor.apply()
        return getStatusJson()
    }

    fun clearEvents(): JSONObject {
        _recentEvents.value = emptyList()
        prefs.edit().putString(KEY_EVENT_HISTORY, "[]").apply()
        return JSONObject().put("success", true).put("action", "EVENTS_CLEARED")
    }

    fun getAppDetailsJson(target: String): JSONObject {
        return AppVerifierAnalyzer.verifyApkOrApp(context, this, target)
    }

    fun getStatusJson(): JSONObject {
        val blockedArr = JSONArray()
        _blockedPackages.value.sorted().forEach { pkg ->
            blockedArr.put(
                JSONObject().apply {
                    put("packageName", pkg)
                    put("appName", resolveAppLabel(pkg))
                }
            )
        }
        val eventsArr = JSONArray()
        _recentEvents.value.take(30).forEach { eventsArr.put(it.toJson()) }

        return JSONObject().apply {
            put("success", true)
            put("monitoringActive", true)
            put("alertOnInstall", _alertOnInstall.value)
            put("alertOnUninstall", _alertOnUninstall.value)
            put("alertOnBlockedLaunch", _alertOnBlockedLaunch.value)
            put("autoBlockNewInstalls", _autoBlockNewInstalls.value)
            put("isAccessibilityBlockerActive", AccessibilityServiceRegistry.activeService != null)
            put("blockedCount", _blockedPackages.value.size)
            put("blockedApps", blockedArr)
            put("recentEventsCount", _recentEvents.value.size)
            put("recentEvents", eventsArr)
        }
    }

    private fun recordEvent(
        eventType: String,
        appName: String,
        packageName: String,
        versionName: String = "",
        installerSource: String = "",
        details: String = ""
    ): AppLifecycleEvent {
        val evt = AppLifecycleEvent(
            id = "ag_${System.currentTimeMillis()}",
            eventType = eventType,
            appName = appName,
            packageName = packageName,
            versionName = versionName,
            installerSource = installerSource,
            details = details
        )
        val updated = (listOf(evt) + _recentEvents.value).take(80)
        _recentEvents.value = updated
        saveEventHistory(updated)
        return evt
    }

    private fun resolveAppLabel(pkg: String): String {
        appLabelsCache[pkg]?.let { if (it.isNotBlank()) return it }
        return try {
            val pm = context.packageManager
            val appInfo = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                pm.getApplicationInfo(pkg, PackageManager.ApplicationInfoFlags.of(0L))
            } else {
                @Suppress("DEPRECATION")
                pm.getApplicationInfo(pkg, 0)
            }
            val label = pm.getApplicationLabel(appInfo)?.toString()?.trim().orEmpty().ifEmpty { pkg }
            if (appLabelsCache.size > 200) trimCaches(aggressive = false)
            appLabelsCache[pkg] = label
            label
        } catch (_: Exception) {
            pkg
        }
    }

    private fun resolveVersionName(pkg: String): String {
        return try {
            val pm = context.packageManager
            val info = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                pm.getPackageInfo(pkg, PackageManager.PackageInfoFlags.of(0L))
            } else {
                @Suppress("DEPRECATION")
                pm.getPackageInfo(pkg, 0)
            }
            info.versionName ?: "1.0"
        } catch (_: Exception) {
            "1.0"
        }
    }

    private fun resolveInstallerName(pkg: String): String {
        val rawInstaller = try {
            val pm = context.packageManager
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                pm.getInstallSourceInfo(pkg).installingPackageName
            } else {
                @Suppress("DEPRECATION")
                pm.getInstallerPackageName(pkg)
            }
        } catch (_: Exception) {
            null
        }
        return when (rawInstaller) {
            "com.android.vending" -> "Google Play Store"
            "com.google.android.packageinstaller", "com.android.packageinstaller" -> "Package Installer (APK)"
            "com.sec.android.app.samsungapps" -> "Samsung Galaxy Store"
            null, "" -> "System / ADB / Sideload"
            else -> rawInstaller
        }
    }

    private fun createAlertNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val chan = NotificationChannel(
                CHANNEL_ID,
                "App Guard & Installation Alerts",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Real-time alerts when apps are installed, updated, uninstalled, or blocked"
            }
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
            nm?.createNotificationChannel(chan)
        }
    }

    private fun postSystemAlertNotification(
        title: String,
        body: String,
        packageName: String,
        includeUninstallAction: Boolean
    ) {
        try {
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager ?: return
            val piFlags = PendingIntent.FLAG_UPDATE_CURRENT or
                (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_IMMUTABLE else 0)

            val openIntent = Intent(context, MainActivity::class.java)
            val openPending = PendingIntent.getActivity(context, packageName.hashCode(), openIntent, piFlags)

            val builder = NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_lock_lock)
                .setContentTitle(title)
                .setContentText(body)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)
                .setContentIntent(openPending)

            if (includeUninstallAction && packageName != context.packageName) {
                val deleteIntent = Intent(Intent.ACTION_DELETE, Uri.parse("package:$packageName")).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                val deletePending = PendingIntent.getActivity(
                    context,
                    packageName.hashCode() + 1,
                    deleteIntent,
                    piFlags
                )
                builder.addAction(android.R.drawable.ic_menu_delete, "Uninstall", deletePending)

                val infoIntent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                val infoPending = PendingIntent.getActivity(
                    context,
                    packageName.hashCode() + 2,
                    infoIntent,
                    piFlags
                )
                builder.addAction(android.R.drawable.ic_menu_info_details, "App Info", infoPending)
            }

            nm.notify((System.currentTimeMillis() % 100000).toInt() + 7000, builder.build())
        } catch (_: Exception) {}
    }

    /**
     * Zero-touch Accessibility automation for configuring Android System Private DNS (DNS-over-TLS)
     * when WRITE_SECURE_SETTINGS is not granted and VPN is disabled.
     * Opens Wireless/Network Settings, locates "Private DNS", selects the requested mode
     * ("hostname", "opportunistic", or "off"), enters the DNS-over-TLS hostname (e.g. family.cloudflare-dns.com),
     * and taps Save.
     */
    fun autoConfigurePrivateDnsViaAccessibility(mode: String, hostname: String): Boolean {
        val service = AccessibilityServiceRegistry.activeService ?: return false
        try {
            val wirelessIntent = Intent(Settings.ACTION_WIRELESS_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            }
            context.startActivity(wirelessIntent)
        } catch (_: Exception) {
            try {
                val netIntent = Intent(Settings.ACTION_SETTINGS).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(netIntent)
            } catch (_: Exception) {
                return false
            }
        }

        scope.launch {
            var openedDialog = false
            var enteredHostname = mode != "hostname"
            var clickedSave = false

            for (step in 1..20) {
                delay(320L)
                val svc = AccessibilityServiceRegistry.activeService ?: break
                val allNodes = mutableListOf<AccessibilityNodeInfo>()
                collectNodesRecursively(svc.rootInActiveWindow, allNodes)
                if (allNodes.isEmpty()) continue

                // Step 1: If the Private DNS dialog is not yet open, look for "Private DNS" item and tap it
                if (!openedDialog) {
                    val hasSaveButton = allNodes.any { n ->
                        val t = n.text?.toString()?.trim()?.lowercase() ?: ""
                        t == "save" || n.viewIdResourceName?.lowercase()?.contains("button1") == true
                    }
                    if (hasSaveButton) {
                        openedDialog = true
                    } else {
                        val privateDnsNode = allNodes.firstOrNull { n ->
                            val t = n.text?.toString()?.trim()?.lowercase() ?: ""
                            val d = n.contentDescription?.toString()?.trim()?.lowercase() ?: ""
                            t.contains("private dns") || d.contains("private dns")
                        }
                        if (privateDnsNode != null) {
                            performClickOrTapNode(svc, privateDnsNode)
                            openedDialog = true
                            continue
                        }
                        // Also check if we need to tap "More connection settings" or "Connection & sharing"
                        val moreConnNode = allNodes.firstOrNull { n ->
                            val t = n.text?.toString()?.trim()?.lowercase() ?: ""
                            t.contains("more connection") || t.contains("connection & sharing") || t.contains("network & internet")
                        }
                        if (moreConnNode != null) {
                            performClickOrTapNode(svc, moreConnNode)
                            continue
                        }
                    }
                }

                // Step 2: Inside the Private DNS dialog, select the target radio option and fill hostname
                if (openedDialog && !clickedSave) {
                    val targetRadioNode = when (mode) {
                        "off" -> allNodes.firstOrNull { n ->
                            val t = n.text?.toString()?.trim()?.lowercase() ?: ""
                            t == "off" || t == "disabled"
                        }
                        "opportunistic" -> allNodes.firstOrNull { n ->
                            val t = n.text?.toString()?.trim()?.lowercase() ?: ""
                            t == "automatic" || t.contains("automatic")
                        }
                        else -> allNodes.firstOrNull { n ->
                            val t = n.text?.toString()?.trim()?.lowercase() ?: ""
                            t.contains("private dns provider hostname") ||
                                t.contains("designated private dns") ||
                                t.contains("specified dns") ||
                                (t.contains("hostname") && !n.isEditable)
                        }
                    }
                    if (targetRadioNode != null) {
                        performClickOrTapNode(svc, targetRadioNode)
                        delay(180L)
                    }

                    val freshNodes = mutableListOf<AccessibilityNodeInfo>()
                    collectNodesRecursively(svc.rootInActiveWindow, freshNodes)
                    if (mode == "hostname" && hostname.isNotBlank()) {
                        val editNode = freshNodes.firstOrNull { n ->
                            n.isEditable || n.className?.toString()?.contains("EditText", ignoreCase = true) == true
                        }
                        if (editNode != null) {
                            val args = android.os.Bundle().apply {
                                putCharSequence(
                                    AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,
                                    hostname
                                )
                            }
                            editNode.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
                            val setOk = editNode.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
                            if (setOk) {
                                enteredHostname = true
                            }
                        }
                    }

                    if (enteredHostname || step >= 10) {
                        val saveNode = freshNodes.firstOrNull { n ->
                            val t = n.text?.toString()?.trim()?.lowercase() ?: ""
                            val resId = n.viewIdResourceName?.lowercase() ?: ""
                            t == "save" || t == "ok" || t == "confirm" || resId.endsWith(":id/button1")
                        }
                        if (saveNode != null) {
                            performClickOrTapNode(svc, saveNode)
                            clickedSave = true
                            delay(250L)
                            svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)
                            break
                        }
                    }
                }
            }
        }
        return true
    }
}
