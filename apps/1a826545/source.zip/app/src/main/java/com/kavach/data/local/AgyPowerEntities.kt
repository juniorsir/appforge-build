package com.kavach.data.local

import androidx.room.Dao
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "agy_macros")
data class AgyMacroEntity(
    @PrimaryKey val id: String,
    val title: String,
    val prompt: String,
    val iconHint: String = "spark_ai",
    val category: String = "General",
    val isPinned: Boolean = true,
    val useCount: Int = 0,
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "agy_run_history")
data class AgyRunHistoryEntity(
    @PrimaryKey val id: String,
    val title: String,
    val promptText: String,
    val finalState: String, // DONE | STOPPED
    val iconHint: String = "",
    val appPackage: String = "",
    val durationMs: Long = 0L,
    val stepCount: Int = 0,
    val detailedOutput: String = "",
    val outputLogsJson: String = "[]",
    val timestamp: Long = System.currentTimeMillis()
)

@Dao
interface AgyPowerDao {

    @Query("SELECT * FROM agy_macros ORDER BY isPinned DESC, useCount DESC, updatedAt DESC")
    fun observeMacros(): Flow<List<AgyMacroEntity>>

    @Query("SELECT * FROM agy_macros WHERE isPinned = 1 ORDER BY useCount DESC, updatedAt DESC LIMIT 12")
    fun observePinnedMacros(): Flow<List<AgyMacroEntity>>

    @Query("SELECT COUNT(*) FROM agy_macros")
    suspend fun countMacros(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertMacro(macro: AgyMacroEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertMacros(macros: List<AgyMacroEntity>)

    @Query("UPDATE agy_macros SET useCount = useCount + 1, updatedAt = :now WHERE id = :id")
    suspend fun incrementMacroUse(id: String, now: Long = System.currentTimeMillis())

    @Query("UPDATE agy_macros SET isPinned = :pinned, updatedAt = :now WHERE id = :id")
    suspend fun setMacroPinned(id: String, pinned: Boolean, now: Long = System.currentTimeMillis())

    @Query("DELETE FROM agy_macros WHERE id = :id")
    suspend fun deleteMacro(id: String)

    @Query("SELECT * FROM agy_run_history ORDER BY timestamp DESC LIMIT 100")
    fun observeRunHistory(): Flow<List<AgyRunHistoryEntity>>

    @Query(
        """
        SELECT * FROM agy_run_history
        WHERE title LIKE '%' || :query || '%'
           OR promptText LIKE '%' || :query || '%'
           OR detailedOutput LIKE '%' || :query || '%'
           OR outputLogsJson LIKE '%' || :query || '%'
        ORDER BY timestamp DESC
        LIMIT 100
        """
    )
    fun searchRunHistory(query: String): Flow<List<AgyRunHistoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRun(run: AgyRunHistoryEntity)

    @Query("DELETE FROM agy_run_history WHERE id = :id")
    suspend fun deleteRun(id: String)

    @Query("DELETE FROM agy_run_history")
    suspend fun clearRunHistory()

    @Query(
        """
        DELETE FROM agy_run_history
        WHERE id NOT IN (
            SELECT id FROM agy_run_history ORDER BY timestamp DESC LIMIT :keepCount
        )
        """
    )
    suspend fun pruneOldRuns(keepCount: Int = 100)
}
