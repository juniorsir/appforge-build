package com.kavach.ui.overlay.hud

import android.animation.LayoutTransition
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.kavach.ui.overlay.AgyAppIconResolver
import com.kavach.ui.overlay.AgyAppleVectorIconView
import com.kavach.ui.overlay.AgyIconBadgeView
import com.kavach.ui.overlay.AgyMediaPlaybackController
import com.kavach.ui.overlay.AgySmartSuggestionsResolver
import com.kavach.ui.overlay.AgyVoiceInputController
import org.json.JSONObject
import kotlin.math.abs

/**
 * Single-Window KaVach HUD v2 Controller.
 *
 * One draggable, collapsible frosted-obsidian floating card structured into 3 clean vertical zones:
 * 1. Top Header (44dp): Icon/Logo + Title & Live Thinking Line + Stop/Collapse Button
 * 2. Middle Area (adaptive): Media Carousel (Play/Pause & Mute ONLY) / Live Chess Board / Approval Gate / Quick Actions & Status
 * 3. Bottom Bar (48dp): Integrated Input Pill (Mic + Rotating Casual Hints + Snip Badge + Snip Icon + Enter)
 */
class HudWindowController(
    private val context: Context,
    private val store: HudStore
) {
    private val d = context.resources.displayMetrics.density.coerceAtLeast(1f)
    private val mainHandler = Handler(Looper.getMainLooper())
    private val windowManager: WindowManager? by lazy {
        context.getSystemService(Context.WINDOW_SERVICE) as? WindowManager
    }
    private val imm: InputMethodManager? by lazy {
        context.getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
    }

    private val playbackController = AgyMediaPlaybackController(context)
    private val voiceController = AgyVoiceInputController(
        context = context,
        onListeningChanged = { listening ->
            runOnMain { updateMicVisualState(listening) }
        },
        onPartialText = { partial ->
            runOnMain {
                if (partial.isNotBlank()) inputEditText?.setText(partial)
            }
        },
        onFinalText = { spoken ->
            runOnMain {
                if (spoken.isNotBlank()) {
                    inputEditText?.setText(spoken)
                    inputEditText?.setSelection(spoken.length)
                    acquireInputFocus(inputEditText)
                }
            }
        },
        onErrorMessage = { msg ->
            runOnMain { Toast.makeText(context, msg, Toast.LENGTH_SHORT).show() }
        }
    )

    private var rootCard: LinearLayout? = null
    private var rootParams: WindowManager.LayoutParams? = null
    private var headerBar: LinearLayout? = null
    private var headerIconView: AgyIconBadgeView? = null
    private var headerStatusDot: View? = null
    private var headerTitleText: TextView? = null
    private var headerThinkingText: TextView? = null
    private var headerStopBtn: AgyAppleVectorIconView? = null
    private var headerCollapseBtn: AgyAppleVectorIconView? = null

    private var middleScroll: ScrollView? = null
    private var middleHost: LinearLayout? = null
    private var approvalCardView: ApprovalCardView? = null
    private var chessBoardView: ChessMiniBoardView? = null
    private var mediaCarouselView: MediaCarouselCardView? = null
    private var hardwareChipView: TextView? = null
    private var outputCardText: TextView? = null
    private var stepsHost: LinearLayout? = null
    private var quickActionsRow: LinearLayout? = null

    private var bottomPillContainer: LinearLayout? = null
    private var micBtn: AgyAppleVectorIconView? = null
    private var snipChipBadge: TextView? = null
    private var inputEditText: EditText? = null
    private var snipBtn: AgyAppleVectorIconView? = null
    private var sendBtn: TextView? = null

    private var pendingSnipContext: HudModels.SnippedRegionContext? = null
    private var activeRenderState: HudModels.HudUiState = HudModels.HudUiState()
    private var passThroughRestoreToken = 0
    private var autoHideRunnable: Runnable? = null

    init {
        store.onUiRenderRequested = { state -> runOnMain { render(state) } }
        store.onUiHideRequested = { runOnMain { dismissOverlayWindow() } }
        store.onPassThroughRequested = { x1, y1, x2, y2, dur -> temporarilyPassThroughIfColliding(x1, y1, x2, y2, dur) }
        playbackController.onStateChanged = { snap ->
            runOnMain {
                if (activeRenderState.mediaPlaying != snap.isPlaying || activeRenderState.mediaMuted != snap.isMuted) {
                    mediaCarouselView?.bind(activeRenderState.mediaItems, activeRenderState.activeMediaIndex, snap.isPlaying, snap.isMuted)
                }
            }
        }
    }

    private fun runOnMain(block: () -> Unit) {
        if (Looper.myLooper() == Looper.getMainLooper()) block() else mainHandler.post(block)
    }

    private fun nextRandomHint(): String {
        return HudModels.RANDOM_INPUT_HINTS.random()
    }

    private fun ensureWindowAttached(state: HudModels.HudUiState) {
        if (rootCard != null) return
        val wm = windowManager ?: return

        val screenW = context.resources.displayMetrics.widthPixels.coerceAtLeast((320 * d).toInt())
        val cardWidthPx = if (state.isCollapsed) (236 * d).toInt() else (screenW - (24 * d).toInt()).coerceAtMost((340 * d).toInt())

        val card = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            contentDescription = "${HudModels.HUD_NODE_TAG_PREFIX}window"
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#F50B111E"))
                cornerRadius = 22f * d
                setStroke((1 * d).toInt(), Color.parseColor("#2EFFFFFF"))
            }
            elevation = 14f * d
            clipToOutline = true
            layoutTransition = LayoutTransition().apply {
                setDuration(170L)
            }
        }

        // 1. TOP HEADER (44dp)
        val header = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            contentDescription = "${HudModels.HUD_NODE_TAG_PREFIX}header"
            setPadding((10 * d).toInt(), (6 * d).toInt(), (8 * d).toInt(), (6 * d).toInt())
        }
        val iconFrame = FrameLayout(context)
        val iconView = AgyIconBadgeView(context)
        val iconSz = (28 * d).toInt()
        iconFrame.addView(iconView, FrameLayout.LayoutParams(iconSz, iconSz))
        val dotSz = (8 * d).toInt()
        val dotView = View(context).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#38BDF8"))
                setStroke((1.5f * d).toInt(), Color.parseColor("#0B111E"))
            }
        }
        iconFrame.addView(dotView, FrameLayout.LayoutParams(dotSz, dotSz, Gravity.TOP or Gravity.END))
        header.addView(iconFrame, LinearLayout.LayoutParams(iconSz, iconSz))

        val titleCol = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                marginStart = (9 * d).toInt()
                marginEnd = (6 * d).toInt()
            }
        }
        val titleTv = TextView(context).apply {
            textSize = 13f
            setTypeface(Typeface.DEFAULT_BOLD)
            setTextColor(Color.parseColor("#F8FAFC"))
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        val thinkingTv = TextView(context).apply {
            textSize = 11f
            setTextColor(Color.parseColor("#FFB4C2D9"))
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        titleCol.addView(titleTv)
        titleCol.addView(thinkingTv)
        header.addView(titleCol)

        val btnSz = (28 * d).toInt()
        val stopBtn = AgyAppleVectorIconView(context, AgyAppleVectorIconView.IconType.STOP_SQUARE).apply {
            visibility = View.GONE
            glassStyle = AgyAppleVectorIconView.GlassStyle.GLASS_CIRCLE
            iconTint = Color.parseColor("#FDA4AF")
            setOnClickListener {
                store.enqueueAndBroadcastCommand(text = "", action = "STOP")
            }
        }
        header.addView(stopBtn, LinearLayout.LayoutParams(btnSz, btnSz).apply { marginEnd = (4 * d).toInt() })

        val collapseBtn = AgyAppleVectorIconView(context, AgyAppleVectorIconView.IconType.MINUS).apply {
            glassStyle = AgyAppleVectorIconView.GlassStyle.GLASS_CIRCLE
            iconTint = Color.parseColor("#CBD5E1")
            setOnClickListener {
                val nextCollapsed = !activeRenderState.isCollapsed
                if (nextCollapsed) releaseInputFocus()
                store.setCollapsed(nextCollapsed)
            }
        }
        header.addView(collapseBtn, LinearLayout.LayoutParams(btnSz, btnSz))
        attachDragTouch(header) {
            if (activeRenderState.isCollapsed) {
                store.setCollapsed(false)
            }
        }
        card.addView(header, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))

        // 2. ADAPTIVE MIDDLE AREA (max ~210dp)
        val midScroll = ScrollView(context).apply {
            isVerticalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
        }
        val midHost = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((10 * d).toInt(), 0, (10 * d).toInt(), (8 * d).toInt())
        }

        val approvalView = ApprovalCardView(context).apply {
            visibility = View.GONE
            onDecision = { id, decision, edited ->
                releaseInputFocus()
                val p = JSONObject().apply {
                    put("approvalId", id)
                    put("decision", decision)
                    if (edited.isNotBlank()) put("editedText", edited)
                }
                store.enqueueAndBroadcastCommand(text = decision, action = "APPROVAL_RESPONSE", buttonId = id, payload = p)
                store.setApprovalGate(JSONObject().put("clear", true))
            }
            onEditFocusRequested = { et -> acquireInputFocus(et) }
        }
        midHost.addView(approvalView, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
            bottomMargin = (6 * d).toInt()
        })

        val chessView = ChessMiniBoardView(context).apply {
            visibility = View.GONE
            onChessAction = { _, cmd, act ->
                store.enqueueAndBroadcastCommand(text = cmd, action = act)
            }
        }
        midHost.addView(chessView, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
            bottomMargin = (6 * d).toInt()
        })

        val carouselView = MediaCarouselCardView(context, playbackController).apply {
            visibility = View.GONE
            onPageChanged = { idx -> store.setActiveMediaIndex(idx) }
            onTogglePlayPause = {
                store.toggleMediaPlayPause { playing -> playbackController.setPlaying(playing) }
            }
            onToggleMute = {
                store.toggleMediaMute { _ -> playbackController.toggleMute() }
            }
        }
        midHost.addView(carouselView, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
            bottomMargin = (6 * d).toInt()
        })

        val hwChip = TextView(context).apply {
            visibility = View.GONE
            textSize = 11f
            setTextColor(Color.parseColor("#38BDF8"))
            setPadding((9 * d).toInt(), (4 * d).toInt(), (9 * d).toInt(), (4 * d).toInt())
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#1A38BDF8"))
                cornerRadius = 999f
            }
        }
        midHost.addView(hwChip, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
            bottomMargin = (6 * d).toInt()
        })

        val outText = TextView(context).apply {
            visibility = View.GONE
            textSize = 12f
            setTextColor(Color.parseColor("#E2E8F0"))
            setPadding((10 * d).toInt(), (8 * d).toInt(), (10 * d).toInt(), (8 * d).toInt())
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#99172136"))
                cornerRadius = 12f * d
            }
            setOnClickListener {
                val content = text?.toString().orEmpty()
                if (content.isNotBlank()) {
                    val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
                    cm?.setPrimaryClip(ClipData.newPlainText("Agy Output", content))
                    Toast.makeText(context, "Copied response", Toast.LENGTH_SHORT).show()
                }
            }
        }
        midHost.addView(outText, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
            bottomMargin = (6 * d).toInt()
        })

        val stHost = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
        }
        midHost.addView(stHost, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
            bottomMargin = (6 * d).toInt()
        })

        val qaScroll = HorizontalScrollView(context).apply {
            isHorizontalScrollBarEnabled = false
        }
        val qaRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        qaScroll.addView(qaRow)
        midHost.addView(qaScroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))

        midScroll.addView(midHost)
        card.addView(midScroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))

        // 3. BOTTOM INPUT PILL (48dp)
        val pill = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            contentDescription = "${HudModels.HUD_NODE_TAG_PREFIX}input_pill"
            setPadding((6 * d).toInt(), (4 * d).toInt(), (6 * d).toInt(), (4 * d).toInt())
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#FF172136"))
                cornerRadius = 999f
                setStroke((1 * d).toInt(), Color.parseColor("#33FFFFFF"))
            }
        }

        val micButton = AgyAppleVectorIconView(context, AgyAppleVectorIconView.IconType.WAVEFORM).apply {
            glassStyle = AgyAppleVectorIconView.GlassStyle.SUBTLE_CHIP
            iconTint = Color.parseColor("#38BDF8")
            setOnClickListener { voiceController.toggleListening() }
        }
        val pillBtnSz = (32 * d).toInt()
        pill.addView(micButton, LinearLayout.LayoutParams(pillBtnSz, pillBtnSz))

        val snipBadge = TextView(context).apply {
            visibility = View.GONE
            textSize = 10f
            setTypeface(Typeface.DEFAULT_BOLD)
            setTextColor(Color.parseColor("#38BDF8"))
            setPadding((7 * d).toInt(), (3 * d).toInt(), (7 * d).toInt(), (3 * d).toInt())
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#2438BDF8"))
                cornerRadius = 999f
            }
            setOnClickListener {
                pendingSnipContext = null
                visibility = View.GONE
            }
        }
        pill.addView(snipBadge, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
            marginStart = (4 * d).toInt()
        })

        val edit = EditText(context).apply {
            hint = nextRandomHint()
            textSize = 12.5f
            setTextColor(Color.parseColor("#F8FAFC"))
            setHintTextColor(Color.parseColor("#8894A3B8"))
            background = null
            maxLines = 2
            imeOptions = EditorInfo.IME_ACTION_SEND
            setPadding((8 * d).toInt(), (4 * d).toInt(), (6 * d).toInt(), (4 * d).toInt())
            setOnClickListener { acquireInputFocus(this) }
            setOnEditorActionListener { _, actionId, event ->
                if (actionId == EditorInfo.IME_ACTION_SEND ||
                    (event?.keyCode == KeyEvent.KEYCODE_ENTER && event.action == KeyEvent.ACTION_DOWN)
                ) {
                    submitPrompt()
                    true
                } else false
            }
        }
        pill.addView(edit, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))

        val snipIcon = AgyAppleVectorIconView(context, AgyAppleVectorIconView.IconType.SCISSORS).apply {
            glassStyle = AgyAppleVectorIconView.GlassStyle.SUBTLE_CHIP
            iconTint = Color.parseColor("#CBD5E1")
            setOnClickListener { launchOnDemandSnip() }
        }
        pill.addView(snipIcon, LinearLayout.LayoutParams(pillBtnSz, pillBtnSz).apply {
            marginEnd = (4 * d).toInt()
        })

        val enterBtn = TextView(context).apply {
            text = "↵"
            textSize = 14f
            gravity = Gravity.CENTER
            setTypeface(Typeface.DEFAULT_BOLD)
            setTextColor(Color.parseColor("#0B111E"))
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#38BDF8"))
            }
            setOnClickListener { submitPrompt() }
        }
        pill.addView(enterBtn, LinearLayout.LayoutParams(pillBtnSz, pillBtnSz))

        card.addView(pill, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
            setMargins((8 * d).toInt(), 0, (8 * d).toInt(), (8 * d).toInt())
        })

        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            cardWidthPx,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            x = 0
            y = (42 * d).toInt()
        }

        card.setOnTouchListener { _, ev ->
            if (ev.actionMasked == MotionEvent.ACTION_OUTSIDE) {
                releaseInputFocus()
            }
            false
        }

        try {
            wm.addView(card, params)
            rootCard = card
            rootParams = params
            headerBar = header
            headerIconView = iconView
            headerStatusDot = dotView
            headerTitleText = titleTv
            headerThinkingText = thinkingTv
            headerStopBtn = stopBtn
            headerCollapseBtn = collapseBtn
            middleScroll = midScroll
            middleHost = midHost
            approvalCardView = approvalView
            chessBoardView = chessView
            mediaCarouselView = carouselView
            hardwareChipView = hwChip
            outputCardText = outText
            stepsHost = stHost
            quickActionsRow = qaRow
            bottomPillContainer = pill
            micBtn = micButton
            snipChipBadge = snipBadge
            inputEditText = edit
            snipBtn = snipIcon
            sendBtn = enterBtn
        } catch (_: Throwable) {
            rootCard = null
            rootParams = null
        }
    }

    private fun render(state: HudModels.HudUiState) {
        if (!store.hasOverlayPermission() || !state.isVisible) {
            dismissOverlayWindow()
            return
        }
        activeRenderState = state
        ensureWindowAttached(state)
        val params = rootParams ?: return
        val card = rootCard ?: return

        val dotColor = when (state.status) {
            HudModels.HudStatus.WORKING -> Color.parseColor("#38BDF8")
            HudModels.HudStatus.PAUSED -> Color.parseColor("#F59E0B")
            HudModels.HudStatus.NEEDS_INPUT -> Color.parseColor("#F59E0B")
            HudModels.HudStatus.DONE -> Color.parseColor("#34D399")
            HudModels.HudStatus.STOPPED, HudModels.HudStatus.ERROR -> Color.parseColor("#F43F5E")
            HudModels.HudStatus.IDLE -> Color.parseColor("#94A3B8")
        }
        (headerStatusDot?.background as? GradientDrawable)?.setColor(dotColor)

        val resolvedIcon = AgyAppIconResolver.resolve(
            context = context,
            explicitIcon = state.iconKey,
            explicitPackage = state.appPackage,
            fallbackText = state.title
        )
        headerIconView?.setIcon(resolvedIcon, Color.parseColor("#0B111E"))
        headerTitleText?.text = state.title.ifBlank { "Agy Ready" }
        val subtitleFallback = when {
            state.thinkingText.isNotBlank() -> state.thinkingText
            state.progressPercent in 0..100 -> "Progress ${state.progressPercent}%"
            state.status == HudModels.HudStatus.IDLE -> "Ready"
            else -> state.status.wireName.lowercase().replaceFirstChar { it.uppercase() }
        }
        headerThinkingText?.text = subtitleFallback

        val isRunning = state.status == HudModels.HudStatus.WORKING || state.status == HudModels.HudStatus.PAUSED
        headerStopBtn?.visibility = if (isRunning && !state.isCollapsed) View.VISIBLE else View.GONE
        headerCollapseBtn?.iconType = if (state.isCollapsed) AgyAppleVectorIconView.IconType.ARROW_EXPAND else AgyAppleVectorIconView.IconType.MINUS

        if (state.isCollapsed) {
            middleScroll?.visibility = View.GONE
            bottomPillContainer?.visibility = View.GONE
            params.width = (236 * d).toInt()
        } else {
            val screenW = context.resources.displayMetrics.widthPixels.coerceAtLeast((320 * d).toInt())
            params.width = (screenW - (24 * d).toInt()).coerceAtMost((340 * d).toInt())
            bottomPillContainer?.visibility = View.VISIBLE

            val fgPkg = state.appPackage.ifBlank { store.foregroundPackageProvider?.invoke().orEmpty() }
            val resolvedActions = if (state.quickActions.isNotEmpty()) {
                state.quickActions
            } else if (fgPkg.isNotBlank()) {
                AgySmartSuggestionsResolver.resolve(fgPkg, maxItems = 3)
            } else emptyList()

            val effectiveState = state.copy(quickActions = resolvedActions)
            val showMiddle = effectiveState.hasMiddleContent
            middleScroll?.visibility = if (showMiddle) View.VISIBLE else View.GONE

            // Middle Stage Priority Slots
            approvalCardView?.apply {
                if (effectiveState.approval != null) {
                    visibility = View.VISIBLE
                    bind(effectiveState.approval)
                } else {
                    visibility = View.GONE
                }
            }
            chessBoardView?.apply {
                if (effectiveState.chess != null && effectiveState.approval == null) {
                    visibility = View.VISIBLE
                    bind(effectiveState.chess, effectiveState.status)
                } else {
                    visibility = View.GONE
                }
            }
            mediaCarouselView?.apply {
                if (effectiveState.mediaItems.isNotEmpty() && effectiveState.approval == null && effectiveState.chess == null) {
                    visibility = View.VISIBLE
                    bind(effectiveState.mediaItems, effectiveState.activeMediaIndex, effectiveState.mediaPlaying, effectiveState.mediaMuted)
                } else {
                    visibility = View.GONE
                }
            }
            hardwareChipView?.apply {
                val hw = effectiveState.hardwareChip
                if (hw != null) {
                    visibility = View.VISIBLE
                    text = if (hw.value.isNotBlank()) "${hw.label}: ${hw.value}" else hw.label
                } else {
                    visibility = View.GONE
                }
            }
            outputCardText?.apply {
                val showText = effectiveState.detailedOutput.isNotBlank() && effectiveState.chess == null && effectiveState.approval == null
                if (showText) {
                    visibility = View.VISIBLE
                    text = effectiveState.detailedOutput
                } else {
                    visibility = View.GONE
                }
            }
            stepsHost?.apply {
                removeAllViews()
                if (effectiveState.steps.isNotEmpty() && effectiveState.chess == null && effectiveState.mediaItems.isEmpty()) {
                    visibility = View.VISIBLE
                    effectiveState.steps.take(5).forEach { step ->
                        val mark = when (step.status) {
                            "done" -> "✓"
                            "doing" -> "▶"
                            "stopped" -> "■"
                            else -> "○"
                        }
                        val tv = TextView(context).apply {
                            text = "$mark  ${step.label}"
                            textSize = 11f
                            setTextColor(
                                when (step.status) {
                                    "done" -> Color.parseColor("#34D399")
                                    "doing" -> Color.parseColor("#38BDF8")
                                    else -> Color.parseColor("#CBD5E1")
                                }
                            )
                            maxLines = 1
                            ellipsize = TextUtils.TruncateAt.END
                        }
                        addView(tv, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                            topMargin = (2 * d).toInt()
                        })
                    }
                } else {
                    visibility = View.GONE
                }
            }
            quickActionsRow?.apply {
                removeAllViews()
                if (effectiveState.quickActions.isNotEmpty() && effectiveState.chess == null && effectiveState.approval == null) {
                    visibility = View.VISIBLE
                    effectiveState.quickActions.take(3).forEachIndexed { idx, act ->
                        val chip = TextView(context).apply {
                            text = act.label
                            textSize = 11f
                            setTypeface(Typeface.DEFAULT_BOLD)
                            setTextColor(Color.parseColor("#E0F2FE"))
                            setPadding((10 * d).toInt(), (5 * d).toInt(), (10 * d).toInt(), (5 * d).toInt())
                            background = GradientDrawable().apply {
                                setColor(Color.parseColor("#24324E"))
                                cornerRadius = 999f
                            }
                            setOnClickListener {
                                store.enqueueAndBroadcastCommand(
                                    text = act.commandText,
                                    action = act.actionType,
                                    buttonId = act.id
                                )
                            }
                        }
                        addView(chip, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                            if (idx > 0) marginStart = (6 * d).toInt()
                        })
                    }
                } else {
                    visibility = View.GONE
                }
            }

            // Cap middleScroll height cleanly to <= 210dp
            midMeasureAndCapHeight()
        }

        try {
            windowManager?.updateViewLayout(card, params)
        } catch (_: Throwable) {}

        scheduleAutoHideIfNeeded(state)
    }

    private fun midMeasureAndCapHeight() {
        val ms = middleScroll ?: return
        val maxH = (210 * d).toInt()
        ms.measure(
            View.MeasureSpec.makeMeasureSpec(rootParams?.width ?: (320 * d).toInt(), View.MeasureSpec.AT_MOST),
            View.MeasureSpec.makeMeasureSpec(maxH * 2, View.MeasureSpec.AT_MOST)
        )
        val lp = ms.layoutParams ?: return
        val targetH = if (ms.measuredHeight > maxH) maxH else ViewGroup.LayoutParams.WRAP_CONTENT
        if (lp.height != targetH) {
            lp.height = targetH
            ms.layoutParams = lp
        }
    }

    private fun scheduleAutoHideIfNeeded(state: HudModels.HudUiState) {
        autoHideRunnable?.let { mainHandler.removeCallbacks(it) }
        autoHideRunnable = null
        if (state.autoHideSeconds > 0 && state.status == HudModels.HudStatus.DONE && state.chess == null && state.mediaItems.isEmpty()) {
            val r = Runnable { store.setCollapsed(true) }
            autoHideRunnable = r
            mainHandler.postDelayed(r, state.autoHideSeconds * 1000L)
        }
    }

    private fun submitPrompt() {
        val rawText = inputEditText?.text?.toString()?.trim().orEmpty()
        val snip = pendingSnipContext
        if (rawText.isEmpty() && snip == null) return

        val cmdText = rawText.ifBlank { "Inspect the selected region on screen" }
        val payload = snip?.let { JSONObject().put("regionContext", it.toJson()) }
        store.enqueueAndBroadcastCommand(text = cmdText, action = "PROMPT", payload = payload)

        pendingSnipContext = null
        snipChipBadge?.visibility = View.GONE
        inputEditText?.setText("")
        inputEditText?.hint = nextRandomHint()
        releaseInputFocus()
    }

    private fun launchOnDemandSnip() {
        val snipMgr = store.regionSnipOverlayManager ?: run {
            Toast.makeText(context, "Region snip unavailable", Toast.LENGTH_SHORT).show()
            return
        }
        releaseInputFocus()
        rootCard?.visibility = View.INVISIBLE
        val started = snipMgr.startSnip(
            nodeTreeProvider = store.nodeTreeProvider,
            foregroundPackageProvider = store.foregroundPackageProvider,
            screenshotProvider = store.regionScreenshotProvider,
            onComplete = { ctx ->
                runOnMain {
                    rootCard?.visibility = View.VISIBLE
                    pendingSnipContext = ctx
                    snipChipBadge?.apply {
                        text = "${ctx.summaryBadgeText} ✕"
                        visibility = View.VISIBLE
                    }
                    acquireInputFocus(inputEditText)
                }
            },
            onCancel = {
                runOnMain { rootCard?.visibility = View.VISIBLE }
            }
        )
        if (!started) {
            rootCard?.visibility = View.VISIBLE
        }
    }

    private fun updateMicVisualState(listening: Boolean) {
        micBtn?.iconTint = if (listening) Color.parseColor("#F43F5E") else Color.parseColor("#38BDF8")
    }

    private fun acquireInputFocus(target: EditText?) {
        val card = rootCard ?: return
        val params = rootParams ?: return
        if ((params.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE) != 0) {
            params.flags = params.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE.inv()
            params.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
            try {
                windowManager?.updateViewLayout(card, params)
            } catch (_: Throwable) {}
        }
        target?.requestFocus()
        mainHandler.post {
            target?.let { imm?.showSoftInput(it, InputMethodManager.SHOW_IMPLICIT) }
        }
    }

    private fun releaseInputFocus() {
        val card = rootCard ?: return
        val params = rootParams ?: return
        inputEditText?.clearFocus()
        try {
            imm?.hideSoftInputFromWindow(card.windowToken, 0)
        } catch (_: Throwable) {}
        if ((params.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE) == 0) {
            params.flags = params.flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
            try {
                windowManager?.updateViewLayout(card, params)
            } catch (_: Throwable) {}
        }
    }

    private fun attachDragTouch(view: View, onSingleTap: (() -> Unit)? = null) {
        var downRawX = 0f
        var downRawY = 0f
        var startX = 0
        var startY = 0
        var dragged = false
        val slop = 8f * d

        view.setOnTouchListener { _, ev ->
            val params = rootParams ?: return@setOnTouchListener false
            val card = rootCard ?: return@setOnTouchListener false
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downRawX = ev.rawX
                    downRawY = ev.rawY
                    startX = params.x
                    startY = params.y
                    dragged = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = ev.rawX - downRawX
                    val dy = ev.rawY - downRawY
                    if (!dragged && (abs(dx) > slop || abs(dy) > slop)) {
                        dragged = true
                    }
                    if (dragged) {
                        val dm = context.resources.displayMetrics
                        val halfRange = ((dm.widthPixels - card.width) / 2).coerceAtLeast(0)
                        params.x = (startX + dx.toInt()).coerceIn(-halfRange, halfRange)
                        params.y = (startY + dy.toInt()).coerceIn((20 * d).toInt(), (dm.heightPixels - card.height - (24 * d).toInt()).coerceAtLeast((40 * d).toInt()))
                        try {
                            windowManager?.updateViewLayout(card, params)
                        } catch (_: Throwable) {}
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!dragged) {
                        onSingleTap?.invoke()
                    }
                    true
                }
                else -> false
            }
        }
    }

    fun temporarilyPassThroughIfColliding(x1: Float, y1: Float, x2: Float, y2: Float, durationMs: Long): Boolean {
        val card = rootCard ?: return false
        val params = rootParams ?: return false
        if (card.visibility != View.VISIBLE) return false
        val loc = IntArray(2)
        card.getLocationOnScreen(loc)
        val hudRect = Rect(loc[0], loc[1], loc[0] + card.width, loc[1] + card.height)
        val minX = minOf(x1, x2).toInt()
        val maxX = maxOf(x1, x2).toInt()
        val minY = minOf(y1, y2).toInt()
        val maxY = maxOf(y1, y2).toInt()
        val gestureRect = Rect(minX - 16, minY - 16, maxX + 16, maxY + 16)
        if (!Rect.intersects(hudRect, gestureRect)) return false

        val token = ++passThroughRestoreToken
        runOnMain {
            params.flags = params.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
            try { windowManager?.updateViewLayout(card, params) } catch (_: Throwable) {}
        }
        mainHandler.postDelayed({
            if (token == passThroughRestoreToken) {
                params.flags = params.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
                try { windowManager?.updateViewLayout(card, params) } catch (_: Throwable) {}
            }
        }, durationMs.coerceIn(150L, 4000L))
        return true
    }

    private fun dismissOverlayWindow() {
        autoHideRunnable?.let { mainHandler.removeCallbacks(it) }
        autoHideRunnable = null
        voiceController.release()
        playbackController.stopAndRelease()
        releaseInputFocus()
        rootCard?.let { card ->
            try {
                windowManager?.removeViewImmediate(card)
            } catch (_: Throwable) {}
        }
        rootCard = null
        rootParams = null
    }
}
