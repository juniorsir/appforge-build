package com.kavach.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import kotlinx.coroutines.flow.Flow

data class VaultCountSummary(
    val totalEvents: Int = 0,
    val pendingEvents: Int = 0,
    val syncedEvents: Int = 0,
    val totalLocations: Int = 0,
    val pendingLocations: Int = 0,
    val syncedLocations: Int = 0,
    val totalSnapshots: Int = 0,
    val pendingSnapshots: Int = 0,
    val syncedSnapshots: Int = 0,
    val oldestPendingTimestamp: Long? = null,
    val earliestExpiresAt: Long? = null,
    val lastSuccessfulSyncAt: Long = 0L,
    val lastPrunedAt: Long = 0L,
    val totalPrunedCount: Long = 0L
)

@Dao
interface TelemetryVaultDao {

    // --- Inserts ---

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEvent(event: TimelineEventEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEvents(events: List<TimelineEventEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLocationPoint(point: LocationPointEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDeviceSnapshot(snapshot: DeviceSnapshotEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertWatermark(watermark: SyncWatermarkEntity)

    // --- Live UI Flows ---

    @Query("SELECT * FROM timeline_events ORDER BY timestamp DESC LIMIT :limit")
    fun observeRecentEvents(limit: Int = 250): Flow<List<TimelineEventEntity>>

    @Query("SELECT * FROM location_points ORDER BY timestamp DESC LIMIT :limit")
    fun observeRecentLocations(limit: Int = 400): Flow<List<LocationPointEntity>>

    @Query("SELECT * FROM device_snapshots ORDER BY timestamp DESC LIMIT :limit")
    fun observeRecentSnapshots(limit: Int = 100): Flow<List<DeviceSnapshotEntity>>

    @Query("SELECT * FROM sync_watermarks WHERE id = 'default' LIMIT 1")
    fun observeWatermark(): Flow<SyncWatermarkEntity?>

    @Query("SELECT * FROM sync_watermarks WHERE id = 'default' LIMIT 1")
    suspend fun getWatermark(): SyncWatermarkEntity?

    // --- Aggregate Count Flows for Vault Strip & Timeline Banner ---

    @Query("SELECT COUNT(*) FROM timeline_events")
    fun observeTotalEventsCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM timeline_events WHERE syncStatus = 'PENDING'")
    fun observePendingEventsCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM location_points")
    fun observeTotalLocationsCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM location_points WHERE syncStatus = 'PENDING'")
    fun observePendingLocationsCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM device_snapshots WHERE syncStatus = 'PENDING'")
    fun observePendingSnapshotsCount(): Flow<Int>

    // --- Synchronous / Suspend Queries ---

    @Query("SELECT * FROM location_points ORDER BY timestamp DESC LIMIT 1")
    suspend fun getLatestLocationPoint(): LocationPointEntity?

    @Query("SELECT * FROM device_snapshots ORDER BY timestamp DESC LIMIT 1")
    suspend fun getLatestDeviceSnapshot(): DeviceSnapshotEntity?

    @Query(
        """
        SELECT * FROM timeline_events
        WHERE timestamp >= :sinceMs AND timestamp <= :untilMs
          AND (:category = '' OR category = :category)
          AND (:pendingOnly = 0 OR syncStatus = 'PENDING')
          AND (:searchQuery = '' OR title LIKE '%' || :searchQuery || '%' OR detail LIKE '%' || :searchQuery || '%' OR packageName LIKE '%' || :searchQuery || '%' OR domain LIKE '%' || :searchQuery || '%')
        ORDER BY timestamp DESC
        LIMIT :limit OFFSET :offset
        """
    )
    suspend fun queryEvents(
        sinceMs: Long,
        untilMs: Long,
        category: String = "",
        pendingOnly: Boolean = false,
        searchQuery: String = "",
        limit: Int = 200,
        offset: Int = 0
    ): List<TimelineEventEntity>

    @Query(
        """
        SELECT * FROM location_points
        WHERE timestamp >= :sinceMs AND timestamp <= :untilMs
          AND (:pendingOnly = 0 OR syncStatus = 'PENDING')
        ORDER BY timestamp ASC
        LIMIT :limit
        """
    )
    suspend fun queryLocationPathAsc(
        sinceMs: Long,
        untilMs: Long,
        pendingOnly: Boolean = false,
        limit: Int = 1000
    ): List<LocationPointEntity>

    @Query(
        """
        SELECT * FROM device_snapshots
        WHERE timestamp >= :sinceMs AND timestamp <= :untilMs
          AND (:pendingOnly = 0 OR syncStatus = 'PENDING')
        ORDER BY timestamp DESC
        LIMIT :limit
        """
    )
    suspend fun querySnapshots(
        sinceMs: Long,
        untilMs: Long,
        pendingOnly: Boolean = false,
        limit: Int = 200
    ): List<DeviceSnapshotEntity>

    // --- Reconnect Sync Batch Queries ---

    @Query("SELECT * FROM timeline_events WHERE syncStatus = 'PENDING' ORDER BY timestamp ASC LIMIT :limit")
    suspend fun getPendingEventsBatch(limit: Int = 50): List<TimelineEventEntity>

    @Query("SELECT * FROM location_points WHERE syncStatus = 'PENDING' ORDER BY timestamp ASC LIMIT :limit")
    suspend fun getPendingLocationsBatch(limit: Int = 50): List<LocationPointEntity>

    @Query("SELECT * FROM device_snapshots WHERE syncStatus = 'PENDING' ORDER BY timestamp ASC LIMIT :limit")
    suspend fun getPendingSnapshotsBatch(limit: Int = 25): List<DeviceSnapshotEntity>

    @Query("UPDATE timeline_events SET syncStatus = 'SYNCED', syncedAt = :syncedAt, expiresAt = :expiresAt WHERE id IN (:ids)")
    suspend fun markEventsSynced(ids: List<String>, syncedAt: Long, expiresAt: Long)

    @Query("UPDATE location_points SET syncStatus = 'SYNCED', syncedAt = :syncedAt, expiresAt = :expiresAt WHERE id IN (:ids)")
    suspend fun markLocationsSynced(ids: List<String>, syncedAt: Long, expiresAt: Long)

    @Query("UPDATE device_snapshots SET syncStatus = 'SYNCED', syncedAt = :syncedAt, expiresAt = :expiresAt WHERE id IN (:ids)")
    suspend fun markSnapshotsSynced(ids: List<String>, syncedAt: Long, expiresAt: Long)

    // --- Retention & Stats ---

    @Query("SELECT COUNT(*) FROM timeline_events")
    suspend fun countAllEvents(): Int

    @Query("SELECT COUNT(*) FROM timeline_events WHERE syncStatus = 'PENDING'")
    suspend fun countPendingEvents(): Int

    @Query("SELECT COUNT(*) FROM timeline_events WHERE syncStatus = 'SYNCED'")
    suspend fun countSyncedEvents(): Int

    @Query("SELECT COUNT(*) FROM location_points")
    suspend fun countAllLocations(): Int

    @Query("SELECT COUNT(*) FROM location_points WHERE syncStatus = 'PENDING'")
    suspend fun countPendingLocations(): Int

    @Query("SELECT COUNT(*) FROM location_points WHERE syncStatus = 'SYNCED'")
    suspend fun countSyncedLocations(): Int

    @Query("SELECT COUNT(*) FROM device_snapshots")
    suspend fun countAllSnapshots(): Int

    @Query("SELECT COUNT(*) FROM device_snapshots WHERE syncStatus = 'PENDING'")
    suspend fun countPendingSnapshots(): Int

    @Query("SELECT COUNT(*) FROM device_snapshots WHERE syncStatus = 'SYNCED'")
    suspend fun countSyncedSnapshots(): Int

    @Query(
        """
        SELECT MIN(ts) FROM (
            SELECT MIN(timestamp) AS ts FROM timeline_events WHERE syncStatus = 'PENDING'
            UNION ALL
            SELECT MIN(timestamp) AS ts FROM location_points WHERE syncStatus = 'PENDING'
            UNION ALL
            SELECT MIN(timestamp) AS ts FROM device_snapshots WHERE syncStatus = 'PENDING'
        ) WHERE ts IS NOT NULL
        """
    )
    suspend fun getOldestPendingTimestamp(): Long?

    @Query(
        """
        SELECT MIN(exp) FROM (
            SELECT MIN(expiresAt) AS exp FROM timeline_events WHERE syncStatus = 'SYNCED' AND expiresAt IS NOT NULL
            UNION ALL
            SELECT MIN(expiresAt) AS exp FROM location_points WHERE syncStatus = 'SYNCED' AND expiresAt IS NOT NULL
            UNION ALL
            SELECT MIN(expiresAt) AS exp FROM device_snapshots WHERE syncStatus = 'SYNCED' AND expiresAt IS NOT NULL
        ) WHERE exp IS NOT NULL
        """
    )
    suspend fun getEarliestExpirationTimestamp(): Long?

    // --- 20-Day Post-Sync Retention Pruner (NEVER deletes PENDING rows) ---

    @Query("DELETE FROM timeline_events WHERE syncStatus = 'SYNCED' AND expiresAt IS NOT NULL AND expiresAt <= :nowMs")
    suspend fun pruneExpiredEvents(nowMs: Long): Int

    @Query("DELETE FROM location_points WHERE syncStatus = 'SYNCED' AND expiresAt IS NOT NULL AND expiresAt <= :nowMs")
    suspend fun pruneExpiredLocations(nowMs: Long): Int

    @Query("DELETE FROM device_snapshots WHERE syncStatus = 'SYNCED' AND expiresAt IS NOT NULL AND expiresAt <= :nowMs")
    suspend fun pruneExpiredSnapshots(nowMs: Long): Int

    @Query("DELETE FROM timeline_events WHERE syncStatus = 'SYNCED'")
    suspend fun clearSyncedEvents(): Int

    @Query("DELETE FROM location_points WHERE syncStatus = 'SYNCED'")
    suspend fun clearSyncedLocations(): Int

    @Query("DELETE FROM device_snapshots WHERE syncStatus = 'SYNCED'")
    suspend fun clearSyncedSnapshots(): Int

    @Transaction
    suspend fun pruneAllExpiredSynced(nowMs: Long): Int {
        val e = pruneExpiredEvents(nowMs)
        val l = pruneExpiredLocations(nowMs)
        val s = pruneExpiredSnapshots(nowMs)
        return e + l + s
    }

    @Transaction
    suspend fun clearAllSynced(): Int {
        val e = clearSyncedEvents()
        val l = clearSyncedLocations()
        val s = clearSyncedSnapshots()
        return e + l + s
    }

    @Transaction
    suspend fun getVaultCountSummary(): VaultCountSummary {
        val wm = getWatermark()
        return VaultCountSummary(
            totalEvents = countAllEvents(),
            pendingEvents = countPendingEvents(),
            syncedEvents = countSyncedEvents(),
            totalLocations = countAllLocations(),
            pendingLocations = countPendingLocations(),
            syncedLocations = countSyncedLocations(),
            totalSnapshots = countAllSnapshots(),
            pendingSnapshots = countPendingSnapshots(),
            syncedSnapshots = countSyncedSnapshots(),
            oldestPendingTimestamp = getOldestPendingTimestamp(),
            earliestExpiresAt = getEarliestExpirationTimestamp(),
            lastSuccessfulSyncAt = wm?.lastSuccessfulSyncAt ?: 0L,
            lastPrunedAt = wm?.lastPrunedAt ?: 0L,
            totalPrunedCount = wm?.totalPrunedCount ?: 0L
        )
    }
}
