package com.kavach.hardware

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.content.pm.Signature
import android.os.Build
import android.os.Environment
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.File
import java.security.MessageDigest
import java.security.cert.CertificateFactory
import java.security.cert.X509Certificate
import java.security.interfaces.ECPublicKey
import java.security.interfaces.RSAPublicKey
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object AppVerifierAnalyzer {

    private data class CapabilityRule(
        val id: String,
        val icon: String,
        val title: String,
        val whatItDoes: String,
        val risk: String, // LOW, MODERATE, HIGH
        val matchingPermissions: Set<String>
    )

    private val capabilityRules = listOf(
        CapabilityRule(
            id = "NETWORK_INTERNET",
            icon = "🌐",
            title = "Internet & Network Communication",
            whatItDoes = "Connects to remote servers, downloads/uploads data, and checks Wi-Fi or cellular network state.",
            risk = "LOW",
            matchingPermissions = setOf(
                "android.permission.INTERNET",
                "android.permission.ACCESS_NETWORK_STATE",
                "android.permission.ACCESS_WIFI_STATE",
                "android.permission.CHANGE_WIFI_STATE",
                "android.permission.CHANGE_NETWORK_STATE"
            )
        ),
        CapabilityRule(
            id = "CAMERA_CAPTURE",
            icon = "📸",
            title = "Camera & Photo/Video Capture",
            whatItDoes = "Takes pictures, scans QR codes/documents, or records video using the front or rear camera.",
            risk = "MODERATE",
            matchingPermissions = setOf("android.permission.CAMERA")
        ),
        CapabilityRule(
            id = "MICROPHONE_AUDIO",
            icon = "🎙️",
            title = "Microphone & Voice Recording",
            whatItDoes = "Records voice, ambient sound, or audio streams using the device microphone.",
            risk = "MODERATE",
            matchingPermissions = setOf("android.permission.RECORD_AUDIO")
        ),
        CapabilityRule(
            id = "LOCATION_TRACKING",
            icon = "📍",
            title = "GPS & Location Tracking",
            whatItDoes = "Accesses precise GPS coordinates or approximate network location to track where the device is.",
            risk = "MODERATE",
            matchingPermissions = setOf(
                "android.permission.ACCESS_FINE_LOCATION",
                "android.permission.ACCESS_COARSE_LOCATION",
                "android.permission.ACCESS_BACKGROUND_LOCATION"
            )
        ),
        CapabilityRule(
            id = "SMS_MESSAGING",
            icon = "💬",
            title = "SMS & Text Messaging Access",
            whatItDoes = "Reads incoming SMS/OTP codes, views message history, or sends SMS messages directly.",
            risk = "HIGH",
            matchingPermissions = setOf(
                "android.permission.SEND_SMS",
                "android.permission.READ_SMS",
                "android.permission.RECEIVE_SMS",
                "android.permission.RECEIVE_MMS"
            )
        ),
        CapabilityRule(
            id = "PHONE_CALLS",
            icon = "📞",
            title = "Phone Calls & Call Logs",
            whatItDoes = "Places phone calls, inspects active call state/cellular identity, or reads call history logs.",
            risk = "HIGH",
            matchingPermissions = setOf(
                "android.permission.CALL_PHONE",
                "android.permission.READ_PHONE_STATE",
                "android.permission.READ_PHONE_NUMBERS",
                "android.permission.READ_CALL_LOG",
                "android.permission.WRITE_CALL_LOG",
                "android.permission.ANSWER_PHONE_CALLS"
            )
        ),
        CapabilityRule(
            id = "CONTACTS_ACCOUNTS",
            icon = "👥",
            title = "Contacts & User Accounts",
            whatItDoes = "Reads or modifies your saved address book contacts and discovers accounts on the phone.",
            risk = "MODERATE",
            matchingPermissions = setOf(
                "android.permission.READ_CONTACTS",
                "android.permission.WRITE_CONTACTS",
                "android.permission.GET_ACCOUNTS"
            )
        ),
        CapabilityRule(
            id = "STORAGE_FILES",
            icon = "💾",
            title = "Device Storage, Photos & Files",
            whatItDoes = "Reads or writes files, documents, photos, videos, and audio on shared storage.",
            risk = "MODERATE",
            matchingPermissions = setOf(
                "android.permission.MANAGE_EXTERNAL_STORAGE",
                "android.permission.READ_EXTERNAL_STORAGE",
                "android.permission.WRITE_EXTERNAL_STORAGE",
                "android.permission.READ_MEDIA_IMAGES",
                "android.permission.READ_MEDIA_VIDEO",
                "android.permission.READ_MEDIA_AUDIO"
            )
        ),
        CapabilityRule(
            id = "OVERLAY_SYSTEM_UI",
            icon = "🪟",
            title = "Screen Overlay & System Settings",
            whatItDoes = "Draws floating windows over other apps or modifies global system settings.",
            risk = "HIGH",
            matchingPermissions = setOf(
                "android.permission.SYSTEM_ALERT_WINDOW",
                "android.permission.WRITE_SETTINGS"
            )
        ),
        CapabilityRule(
            id = "APP_INSTALL_CONTROL",
            icon = "📦",
            title = "App Installation, Uninstallation & Discovery",
            whatItDoes = "Can trigger APK installations, request app removals, or inspect all installed packages.",
            risk = "HIGH",
            matchingPermissions = setOf(
                "android.permission.REQUEST_INSTALL_PACKAGES",
                "android.permission.REQUEST_DELETE_PACKAGES",
                "android.permission.QUERY_ALL_PACKAGES"
            )
        ),
        CapabilityRule(
            id = "BACKGROUND_PERSISTENCE",
            icon = "🔄",
            title = "Background Execution & Auto-Start on Boot",
            whatItDoes = "Starts automatically when the phone boots up and keeps background/foreground services running.",
            risk = "LOW",
            matchingPermissions = setOf(
                "android.permission.RECEIVE_BOOT_COMPLETED",
                "android.permission.FOREGROUND_SERVICE",
                "android.permission.WAKE_LOCK",
                "android.permission.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS"
            )
        ),
        CapabilityRule(
            id = "HARDWARE_PERIPHERALS",
            icon = "🔐",
            title = "Biometrics, Bluetooth, Notifications & Haptics",
            whatItDoes = "Uses fingerprint/face authentication, connects to Bluetooth/NFC devices, or posts alerts.",
            risk = "LOW",
            matchingPermissions = setOf(
                "android.permission.USE_BIOMETRIC",
                "android.permission.USE_FINGERPRINT",
                "android.permission.BLUETOOTH",
                "android.permission.BLUETOOTH_ADMIN",
                "android.permission.BLUETOOTH_CONNECT",
                "android.permission.BLUETOOTH_SCAN",
                "android.permission.NFC",
                "android.permission.VIBRATE",
                "android.permission.POST_NOTIFICATIONS"
            )
        )
    )

    fun resolveApkFileCandidate(rawTarget: String): File? {
        val clean = rawTarget.trim()
        if (clean.isEmpty()) return null
        val backupDir = File(
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
            "AeroShare/backups"
        )
        val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)

        val candidates = mutableListOf<File>()
        if (clean.startsWith("/")) {
            candidates.add(File(clean))
        } else if (clean.endsWith(".apk", ignoreCase = true)) {
            candidates.add(File(backupDir, clean))
            candidates.add(File(downloadsDir, clean))
            candidates.add(File(clean))
        }
        return candidates.firstOrNull { it.exists() && it.isFile }
    }

    /**
     * Deeply inspects either an uninstalled APK file OR an installed app by name/package.
     * Returns Developer Certificate Verification, Upgrade Signature Check, "What This App Does"
     * functional breakdown, Manifest Components, and Security Risk Assessment.
     */
    fun verifyApkOrApp(
        context: Context,
        appGuardManager: AppGuardManager,
        targetOrPath: String
    ): JSONObject {
        val clean = targetOrPath.trim()
        if (clean.isEmpty()) {
            return JSONObject().put("success", false).put("error", "Missing APK file path or app/package name")
        }

        val apkFile = resolveApkFileCandidate(clean)
        return if (apkFile != null) {
            inspectArchiveApkFile(context, appGuardManager, apkFile)
        } else {
            val pkg = appGuardManager.resolvePackageIdentifier(clean)
                ?: return JSONObject().put("success", false).put("error", "Neither APK file nor installed app found for '$clean'")
            inspectInstalledPackage(context, appGuardManager, pkg)
        }
    }

    @Suppress("DEPRECATION")
    private fun getFlagsForInspection(): Int {
        var flags = PackageManager.GET_PERMISSIONS or
            PackageManager.GET_ACTIVITIES or
            PackageManager.GET_SERVICES or
            PackageManager.GET_RECEIVERS or
            PackageManager.GET_PROVIDERS or
            PackageManager.GET_META_DATA
        flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            flags or PackageManager.GET_SIGNING_CERTIFICATES
        } else {
            flags or PackageManager.GET_SIGNATURES
        }
        return flags
    }

    private fun inspectArchiveApkFile(
        context: Context,
        appGuardManager: AppGuardManager,
        apkFile: File
    ): JSONObject {
        val pm = context.packageManager
        val flags = getFlagsForInspection()
        val pkgInfo: PackageInfo = try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                pm.getPackageArchiveInfo(apkFile.absolutePath, PackageManager.PackageInfoFlags.of(flags.toLong()))
            } else {
                @Suppress("DEPRECATION")
                pm.getPackageArchiveInfo(apkFile.absolutePath, flags)
            }
        } catch (e: Exception) {
            null
        } ?: return JSONObject().apply {
            put("success", false)
            put("apkFilePath", apkFile.absolutePath)
            put("error", "Invalid or corrupted APK archive: ${apkFile.name}")
        }

        // Attach sourceDir and publicSourceDir so loadLabel / loadDescription work on archive
        pkgInfo.applicationInfo?.let { appInfo ->
            appInfo.sourceDir = apkFile.absolutePath
            appInfo.publicSourceDir = apkFile.absolutePath
        }

        return buildVerificationReport(
            context = context,
            appGuardManager = appGuardManager,
            pkgInfo = pkgInfo,
            sourceType = "APK_FILE",
            apkFile = apkFile
        )
    }

    private fun inspectInstalledPackage(
        context: Context,
        appGuardManager: AppGuardManager,
        packageName: String
    ): JSONObject {
        val pm = context.packageManager
        val flags = getFlagsForInspection()
        val pkgInfo: PackageInfo = try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                pm.getPackageInfo(packageName, PackageManager.PackageInfoFlags.of(flags.toLong()))
            } else {
                @Suppress("DEPRECATION")
                pm.getPackageInfo(packageName, flags)
            }
        } catch (e: Exception) {
            return JSONObject().put("success", false).put("error", "Could not read PackageInfo for $packageName: ${e.message}")
        }

        val srcFile = pkgInfo.applicationInfo?.sourceDir?.let { File(it) }?.takeIf { it.exists() }
        return buildVerificationReport(
            context = context,
            appGuardManager = appGuardManager,
            pkgInfo = pkgInfo,
            sourceType = "INSTALLED_APP",
            apkFile = srcFile
        )
    }

    private fun buildVerificationReport(
        context: Context,
        appGuardManager: AppGuardManager,
        pkgInfo: PackageInfo,
        sourceType: String,
        apkFile: File?
    ): JSONObject {
        val pm = context.packageManager
        val pkg = pkgInfo.packageName.orEmpty()
        val appInfo = pkgInfo.applicationInfo
        val appName = try {
            if (appInfo != null) pm.getApplicationLabel(appInfo)?.toString()?.trim().orEmpty().ifEmpty { pkg } else pkg
        } catch (_: Exception) {
            pkg
        }
        val appDescription = try {
            appInfo?.loadDescription(pm)?.toString()?.trim().orEmpty()
        } catch (_: Exception) {
            ""
        }

        val versionName = pkgInfo.versionName ?: "1.0"
        val versionCode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            pkgInfo.longVersionCode
        } else {
            @Suppress("DEPRECATION")
            pkgInfo.versionCode.toLong()
        }
        val targetSdk = appInfo?.targetSdkVersion ?: 0
        val minSdk = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) appInfo?.minSdkVersion ?: 0 else 0
        val isSystemApp = appInfo != null && ((appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0)
        val isDebuggableApp = appInfo != null && ((appInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE) != 0)

        val sizeBytes = apkFile?.length() ?: 0L
        val sizeMb = if (sizeBytes > 0) Math.round((sizeBytes.toDouble() / (1024.0 * 1024.0)) * 100.0) / 100.0 else 0.0
        val apkSha256 = if (apkFile != null && apkFile.exists() && apkFile.length() < 150L * 1024L * 1024L) {
            computeFileDigest(apkFile, "SHA-256")
        } else ""

        // 1. Extract Developer Certificate & Signature Details
        val signatures = extractSignatures(pkgInfo, apkFile)
        val devCertJson = parseDeveloperCertificateInfo(pkg, signatures, isSystemApp)

        // 2. Check if already installed (for pre-install upgrade verification)
        val installedComparison = compareAgainstInstalledPackage(context, pkg, versionCode, devCertJson.optString("sha256Fingerprint", ""))
        devCertJson.put("upgradeCheck", installedComparison)

        // 3. Analyze Permissions & Capabilities ("What This App Does")
        val reqPerms = pkgInfo.requestedPermissions ?: emptyArray()
        val reqFlags = pkgInfo.requestedPermissionsFlags ?: IntArray(0)
        val grantedPerms = mutableListOf<String>()
        val deniedPerms = mutableListOf<String>()
        val allPermsSet = reqPerms.toSet()

        for (i in reqPerms.indices) {
            val pName = reqPerms[i]
            val isGranted = if (sourceType == "INSTALLED_APP") {
                i < reqFlags.size && (reqFlags[i] and PackageInfo.REQUESTED_PERMISSION_GRANTED) != 0
            } else {
                false
            }
            if (isGranted) grantedPerms.add(pName) else deniedPerms.add(pName)
        }

        // Manifest components
        val activities = pkgInfo.activities?.mapNotNull { it.name } ?: emptyList()
        val services = pkgInfo.services?.mapNotNull { it.name } ?: emptyList()
        val receivers = pkgInfo.receivers?.mapNotNull { it.name } ?: emptyList()
        val providers = pkgInfo.providers?.mapNotNull { it.name } ?: emptyList()

        val capabilitiesArr = JSONArray()
        val capabilityTitles = mutableListOf<String>()
        var highRiskCapCount = 0
        var modRiskCapCount = 0

        for (rule in capabilityRules) {
            val matched = rule.matchingPermissions.intersect(allPermsSet)
            if (matched.isNotEmpty()) {
                if (rule.risk == "HIGH") highRiskCapCount++
                if (rule.risk == "MODERATE") modRiskCapCount++
                capabilityTitles.add(rule.title)
                val matchedArr = JSONArray()
                matched.sorted().forEach { matchedArr.put(it.removePrefix("android.permission.")) }
                capabilitiesArr.put(
                    JSONObject().apply {
                        put("id", rule.id)
                        put("icon", rule.icon)
                        put("title", rule.title)
                        put("whatItDoes", rule.whatItDoes)
                        put("risk", rule.risk)
                        put("permissions", matchedArr)
                    }
                )
            }
        }

        // Detect special service capabilities from declared services/receivers
        val hasAccessibilityService = services.any { it.contains("Accessibility", ignoreCase = true) }
        val hasNotificationListener = services.any { it.contains("NotificationListener", ignoreCase = true) || it.contains("Notification", ignoreCase = true) }
        val hasDeviceAdmin = receivers.any { it.contains("Admin", ignoreCase = true) || it.contains("DeviceAdmin", ignoreCase = true) }

        if (hasAccessibilityService) {
            highRiskCapCount++
            capabilityTitles.add("Accessibility Screen Reader & UI Automation")
            capabilitiesArr.put(
                JSONObject().apply {
                    put("id", "ACCESSIBILITY_SERVICE")
                    put("icon", "♿")
                    put("title", "Accessibility Screen Inspection & Auto-Click")
                    put("whatItDoes", "Can read screen content across apps and perform automated taps/gestures.")
                    put("risk", "HIGH")
                    put("permissions", JSONArray().put("BIND_ACCESSIBILITY_SERVICE"))
                }
            )
        }
        if (hasNotificationListener) {
            modRiskCapCount++
            capabilityTitles.add("Notification Listener")
            capabilitiesArr.put(
                JSONObject().apply {
                    put("id", "NOTIFICATION_LISTENER")
                    put("icon", "🔔")
                    put("title", "Status Bar Notification Reader")
                    put("whatItDoes", "Can read incoming status bar notifications from other apps.")
                    put("risk", "MODERATE")
                    put("permissions", JSONArray().put("BIND_NOTIFICATION_LISTENER_SERVICE"))
                }
            )
        }

        val categoryName = inferAppCategory(appInfo, pkg, appName, allPermsSet, services)
        val whatItDoesSummary = buildWhatAppDoesSummary(
            appName = appName,
            pkg = pkg,
            category = categoryName,
            appDescription = appDescription,
            developerInfo = devCertJson,
            capabilityTitles = capabilityTitles,
            activitiesCount = activities.size,
            servicesCount = services.size,
            receiversCount = receivers.size,
            isSystemApp = isSystemApp
        )

        // 4. Compute Security & Trust Assessment
        val securityAssessment = buildSecurityAssessment(
            devCertJson = devCertJson,
            installedComparison = installedComparison,
            targetSdk = targetSdk,
            isDebuggableApp = isDebuggableApp,
            isSystemApp = isSystemApp,
            allPermsSet = allPermsSet,
            highRiskCapCount = highRiskCapCount,
            modRiskCapCount = modRiskCapCount,
            hasDeviceAdmin = hasDeviceAdmin
        )

        val df = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
        val installerSource = if (sourceType == "INSTALLED_APP") {
            resolveInstallerLabel(context, pkg)
        } else {
            "Local APK Archive (${apkFile?.name ?: "APK"})"
        }

        return JSONObject().apply {
            put("success", true)
            put("sourceType", sourceType)
            put("appName", appName)
            put("packageName", pkg)
            put("versionName", versionName)
            put("versionCode", versionCode)
            put("category", categoryName)
            put("whatAppDoes", whatItDoesSummary)
            put("appDescription", appDescription)
            put("targetSdk", targetSdk)
            put("minSdk", minSdk)
            put("isSystemApp", isSystemApp)
            put("isDebuggable", isDebuggableApp)
            put("isBlocked", appGuardManager.isPackageBlocked(pkg))
            put("isEnabled", appInfo?.enabled ?: true)
            put("installerSource", installerSource)
            put("apkSizeMb", sizeMb)
            put("apkSizeBytes", sizeBytes)
            put("sourceApkPath", apkFile?.absolutePath ?: appInfo?.sourceDir.orEmpty())
            put("apkSha256", apkSha256)
            if (pkgInfo.firstInstallTime > 0) {
                put("firstInstallTime", df.format(Date(pkgInfo.firstInstallTime)))
            } else {
                put("firstInstallTime", "Not Installed (Pre-Install APK)")
            }
            if (pkgInfo.lastUpdateTime > 0) {
                put("lastUpdateTime", df.format(Date(pkgInfo.lastUpdateTime)))
            } else {
                put("lastUpdateTime", "N/A")
            }

            // Developer & Signature Verification block
            put("developerInfo", devCertJson)

            // Capabilities ("What This App Can Do")
            put("capabilitiesCount", capabilitiesArr.length())
            put("capabilities", capabilitiesArr)

            // Manifest Components summary
            put("components", JSONObject().apply {
                put("activitiesCount", activities.size)
                put("servicesCount", services.size)
                put("receiversCount", receivers.size)
                put("providersCount", providers.size)
                put("sampleActivities", JSONArray(activities.take(8)))
                put("sampleServices", JSONArray(services.take(8)))
                put("sampleReceivers", JSONArray(receivers.take(8)))
                put("sampleProviders", JSONArray(providers.take(5)))
            })

            // Security & Pre-Install Risk Verdict
            put("securityAssessment", securityAssessment)

            // Raw Permissions
            put("totalPermissionsCount", reqPerms.size)
            put("grantedPermissionsCount", grantedPerms.size)
            put("deniedPermissionsCount", deniedPerms.size)
            put("grantedPermissions", JSONArray(grantedPerms))
            put("deniedPermissions", JSONArray(deniedPerms))
            put("requestedPermissions", JSONArray(reqPerms.toList()))
        }
    }

    @Suppress("DEPRECATION")
    private fun extractSignatures(pkgInfo: PackageInfo, apkFile: File?): List<Signature> {
        val list = mutableListOf<Signature>()
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                val signingInfo = pkgInfo.signingInfo
                if (signingInfo != null) {
                    val certs = if (signingInfo.hasMultipleSigners()) {
                        signingInfo.apkContentsSigners
                    } else {
                        signingInfo.signingCertificateHistory
                    }
                    if (!certs.isNullOrEmpty()) {
                        list.addAll(certs)
                    }
                }
            }
            if (list.isEmpty() && !pkgInfo.signatures.isNullOrEmpty()) {
                list.addAll(pkgInfo.signatures!!)
            }
        } catch (_: Exception) {}
        return list
    }

    private fun parseDeveloperCertificateInfo(
        packageName: String,
        signatures: List<Signature>,
        isSystemApp: Boolean
    ): JSONObject {
        if (signatures.isEmpty()) {
            return JSONObject().apply {
                put("isSigned", false)
                put("developerName", "Unsigned / Unknown")
                put("organization", "Unknown")
                put("verifiedPublisher", "Unverified (No Signature Found)")
                put("isTrustedPublisher", false)
                put("isDebugCertificate", false)
                put("isSelfSigned", false)
                put("sha256Fingerprint", "")
                put("sha1Fingerprint", "")
            }
        }

        val primarySig = signatures.first()
        val rawBytes = primarySig.toByteArray()
        val sha256Colon = computeBytesDigestColon(rawBytes, "SHA-256")
        val sha1Colon = computeBytesDigestColon(rawBytes, "SHA-1")

        return try {
            val cf = CertificateFactory.getInstance("X.509")
            val cert = cf.generateCertificate(ByteArrayInputStream(rawBytes)) as X509Certificate
            val subjectDn = cert.subjectX500Principal.name
            val issuerDn = cert.issuerX500Principal.name
            val dnMap = parseDistinguishedName(subjectDn)

            val cn = dnMap["CN"].orEmpty()
            val org = dnMap["O"].orEmpty()
            val ou = dnMap["OU"].orEmpty()
            val locality = listOfNotNull(dnMap["L"], dnMap["ST"], dnMap["C"]).filter { it.isNotBlank() }.joinToString(", ")

            val isDebugCert = subjectDn.contains("CN=Android Debug", ignoreCase = true) ||
                (cn.equals("Android Debug", ignoreCase = true))

            val isSelfSigned = subjectDn == issuerDn
            val now = Date()
            val isExpired = now.after(cert.notAfter)
            val df = SimpleDateFormat("yyyy-MM-dd", Locale.US)

            val keyAlgo = cert.publicKey.algorithm
            val keyBits = when (val pk = cert.publicKey) {
                is RSAPublicKey -> pk.modulus.bitLength()
                is ECPublicKey -> pk.params.order.bitLength()
                else -> 0
            }
            val pubKeySpec = if (keyBits > 0) "$keyAlgo $keyBits-bit" else keyAlgo

            val verifiedPublisher = resolveKnownPublisher(packageName, cn, org, ou, isSystemApp, isDebugCert)
            val isTrustedPublisher = verifiedPublisher != null && !isDebugCert

            val displayDeveloper = when {
                !verifiedPublisher.isNullOrBlank() -> verifiedPublisher
                org.isNotBlank() && cn.isNotBlank() && !org.equals(cn, ignoreCase = true) -> "$org ($cn)"
                org.isNotBlank() -> org
                cn.isNotBlank() -> cn
                ou.isNotBlank() -> ou
                else -> "Independent Android Developer"
            }

            JSONObject().apply {
                put("isSigned", true)
                put("signersCount", signatures.size)
                put("developerName", displayDeveloper)
                put("commonName", cn.ifBlank { "N/A" })
                put("organization", org.ifBlank { "N/A" })
                put("organizationalUnit", ou.ifBlank { "N/A" })
                put("location", locality.ifBlank { "N/A" })
                put("subjectDn", subjectDn)
                put("issuerDn", issuerDn)
                put("verifiedPublisher", verifiedPublisher ?: if (isDebugCert) "Debug / Test Build Key" else "Independent / Custom Signer")
                put("isTrustedPublisher", isTrustedPublisher)
                put("isDebugCertificate", isDebugCert)
                put("isSelfSigned", isSelfSigned)
                put("isExpired", isExpired)
                put("validFrom", df.format(cert.notBefore))
                put("validUntil", df.format(cert.notAfter))
                put("serialNumber", cert.serialNumber.toString(16).uppercase(Locale.US))
                put("signatureAlgorithm", cert.sigAlgName)
                put("publicKeyAlgorithm", pubKeySpec)
                put("sha256Fingerprint", sha256Colon)
                put("sha1Fingerprint", sha1Colon)
            }
        } catch (e: Exception) {
            JSONObject().apply {
                put("isSigned", true)
                put("developerName", "Signed Package (Raw Cert)")
                put("organization", "Unknown")
                put("verifiedPublisher", "Custom Signer")
                put("isTrustedPublisher", false)
                put("isDebugCertificate", false)
                put("sha256Fingerprint", sha256Colon)
                put("sha1Fingerprint", sha1Colon)
            }
        }
    }

    private fun compareAgainstInstalledPackage(
        context: Context,
        packageName: String,
        candidateVersionCode: Long,
        candidateSha256: String
    ): JSONObject {
        if (packageName.isBlank()) {
            return JSONObject().put("isAlreadyInstalled", false).put("status", "NEW_INSTALL")
        }
        val pm = context.packageManager
        val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            PackageManager.GET_SIGNING_CERTIFICATES
        } else {
            @Suppress("DEPRECATION")
            PackageManager.GET_SIGNATURES
        }
        val installedInfo: PackageInfo = try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                pm.getPackageInfo(packageName, PackageManager.PackageInfoFlags.of(flags.toLong()))
            } else {
                @Suppress("DEPRECATION")
                pm.getPackageInfo(packageName, flags)
            }
        } catch (_: Exception) {
            return JSONObject().apply {
                put("isAlreadyInstalled", false)
                put("status", "NEW_INSTALL")
                put("summary", "New installation (package is not currently installed on device).")
            }
        }

        val installedSigs = extractSignatures(installedInfo, null)
        val installedSha256 = if (installedSigs.isNotEmpty()) {
            computeBytesDigestColon(installedSigs.first().toByteArray(), "SHA-256")
        } else ""

        val installedVerCode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            installedInfo.longVersionCode
        } else {
            @Suppress("DEPRECATION")
            installedInfo.versionCode.toLong()
        }
        val installedVerName = installedInfo.versionName ?: "1.0"

        val sigMatch = candidateSha256.isNotEmpty() && installedSha256.isNotEmpty() &&
            candidateSha256.equals(installedSha256, ignoreCase = true)

        val status = when {
            !sigMatch -> "MISMATCH_TAMPERED"
            candidateVersionCode > installedVerCode -> "SAFE_UPGRADE"
            candidateVersionCode == installedVerCode -> "SAME_VERSION_REINSTALL"
            else -> "DOWNGRADE_WARNING"
        }

        val summary = when (status) {
            "MISMATCH_TAMPERED" -> "🚨 CRITICAL: Signing certificate DOES NOT MATCH the currently installed app ($installedVerName)! This APK was signed by a different developer or modified."
            "SAFE_UPGRADE" -> "✅ Verified upgrade from v$installedVerName ($installedVerCode) -> v$candidateVersionCode signed by the exact same developer."
            "SAME_VERSION_REINSTALL" -> "✅ Verified signature match with currently installed v$installedVerName ($installedVerCode)."
            "DOWNGRADE_WARNING" -> "⚠️ Signature matches developer, but APK version ($candidateVersionCode) is older than installed v$installedVerName ($installedVerCode)."
            else -> "Installed on device"
        }

        return JSONObject().apply {
            put("isAlreadyInstalled", true)
            put("installedVersionName", installedVerName)
            put("installedVersionCode", installedVerCode)
            put("installedSha256", installedSha256)
            put("signatureMatchesInstalled", sigMatch)
            put("status", status)
            put("summary", summary)
        }
    }

    private fun inferAppCategory(
        appInfo: ApplicationInfo?,
        pkg: String,
        appName: String,
        perms: Set<String>,
        services: List<String>
    ): String {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && appInfo != null) {
            when (appInfo.category) {
                ApplicationInfo.CATEGORY_GAME -> return "Game & Interactive Entertainment"
                ApplicationInfo.CATEGORY_AUDIO -> return "Music & Audio Player"
                ApplicationInfo.CATEGORY_VIDEO -> return "Video & Streaming Media"
                ApplicationInfo.CATEGORY_IMAGE -> return "Photography & Image Editor"
                ApplicationInfo.CATEGORY_SOCIAL -> return "Social Networking & Messaging"
                ApplicationInfo.CATEGORY_NEWS -> return "News & Reading"
                ApplicationInfo.CATEGORY_MAPS -> return "Maps, GPS & Navigation"
                ApplicationInfo.CATEGORY_PRODUCTIVITY -> return "Productivity & Workspace"
                ApplicationInfo.CATEGORY_ACCESSIBILITY -> return "Accessibility & Automation Tool"
            }
        }
        val lowerPkg = pkg.lowercase(Locale.US)
        val lowerName = appName.lowercase(Locale.US)
        return when {
            lowerPkg.contains("youtube") || lowerPkg.contains("video") || lowerPkg.contains("netflix") || lowerPkg.contains("player") ->
                "Video & Streaming Media"
            lowerPkg.contains("music") || lowerPkg.contains("spotify") || lowerPkg.contains("audio") ->
                "Music & Audio"
            lowerPkg.contains("chrome") || lowerPkg.contains("browser") || lowerPkg.contains("firefox") ->
                "Web Browser & Internet"
            lowerPkg.contains("termux") || lowerPkg.contains("shell") || lowerPkg.contains("kavach") || lowerPkg.contains("aicompanion") ->
                "Developer, Terminal & Remote Bridge"
            lowerPkg.contains("camera") || lowerName.contains("camera") || lowerPkg.contains("photos") ->
                "Camera & Photography"
            lowerPkg.contains("dialer") || lowerPkg.contains("messaging") || lowerPkg.contains("whatsapp") || lowerPkg.contains("telegram") || lowerPkg.contains("gm") ->
                "Communication, Calls & Messaging"
            lowerPkg.contains("maps") || lowerPkg.contains("location") ->
                "Maps & Navigation"
            lowerPkg.contains("calendar") || lowerPkg.contains("deskclock") || lowerPkg.contains("docs") || lowerPkg.contains("notes") ->
                "Productivity & Daily Utility"
            lowerPkg.contains("settings") || lowerPkg.contains("systemui") || lowerPkg.contains("packageinstaller") ->
                "Android System Core"
            services.any { it.contains("Accessibility", ignoreCase = true) } ->
                "Accessibility & Device Automation"
            perms.contains("android.permission.CAMERA") && perms.contains("android.permission.RECORD_AUDIO") ->
                "Multimedia & Communication App"
            else -> "General Android Application"
        }
    }

    private fun buildWhatAppDoesSummary(
        appName: String,
        pkg: String,
        category: String,
        appDescription: String,
        developerInfo: JSONObject,
        capabilityTitles: List<String>,
        activitiesCount: Int,
        servicesCount: Int,
        receiversCount: Int,
        isSystemApp: Boolean
    ): String {
        val devName = developerInfo.optString("developerName", "Unknown Developer")
        val appTypeStr = if (isSystemApp) "Pre-installed Android System app" else "User-installable application"
        val baseDesc = if (appDescription.isNotBlank()) {
            "$appDescription "
        } else {
            "$appName ($category) is a $appTypeStr published by $devName. "
        }

        val capPart = if (capabilityTitles.isEmpty()) {
            "It operates in a sandboxed environment without requesting sensitive hardware or network permissions."
        } else {
            val topCaps = capabilityTitles.take(5).joinToString(", ")
            val more = if (capabilityTitles.size > 5) " (+${capabilityTitles.size - 5} more)" else ""
            "Key functional behaviors: $topCaps$more."
        }

        val compPart = "Declares $activitiesCount screen activity(s), $servicesCount background service(s), and $receiversCount event receiver(s)."
        return "$baseDesc$capPart $compPart"
    }

    private fun buildSecurityAssessment(
        devCertJson: JSONObject,
        installedComparison: JSONObject,
        targetSdk: Int,
        isDebuggableApp: Boolean,
        isSystemApp: Boolean,
        allPermsSet: Set<String>,
        highRiskCapCount: Int,
        modRiskCapCount: Int,
        hasDeviceAdmin: Boolean
    ): JSONObject {
        var score = 100
        val warnings = mutableListOf<String>()
        val positiveSignals = mutableListOf<String>()

        val isSigned = devCertJson.optBoolean("isSigned", false)
        val isTrusted = devCertJson.optBoolean("isTrustedPublisher", false)
        val isDebugCert = devCertJson.optBoolean("isDebugCertificate", false)
        val isExpired = devCertJson.optBoolean("isExpired", false)
        val upgradeStatus = installedComparison.optString("status", "NEW_INSTALL")

        if (!isSigned) {
            score -= 60
            warnings.add("CRITICAL: Package has no valid cryptographic signature.")
        } else {
            positiveSignals.add("Cryptographically signed (${devCertJson.optString("signatureAlgorithm", "X.509")})")
        }

        if (upgradeStatus == "MISMATCH_TAMPERED") {
            score -= 70
            warnings.add("CRITICAL SIGNATURE MISMATCH: APK is signed by a DIFFERENT developer than the currently installed version on this phone!")
        } else if (upgradeStatus == "SAFE_UPGRADE" || upgradeStatus == "SAME_VERSION_REINSTALL") {
            positiveSignals.add("Signing certificate matches the currently installed app on device")
        }

        if (isTrusted) {
            positiveSignals.add("Verified Publisher: ${devCertJson.optString("verifiedPublisher")}")
        }

        if (isDebugCert && !isSystemApp) {
            score -= 18
            warnings.add("Signed with an Android Debug/Test key instead of a production release certificate.")
        }

        if (isDebuggableApp && !isSystemApp) {
            score -= 10
            warnings.add("Manifest has android:debuggable='true' enabled.")
        }

        if (isExpired) {
            score -= 15
            warnings.add("Developer signing certificate validity date has expired (${devCertJson.optString("validUntil")}).")
        }

        if (targetSdk in 1..27) {
            score -= 15
            warnings.add("Targets legacy Android SDK ($targetSdk) which may bypass modern runtime permission restrictions.")
        } else if (targetSdk >= 31) {
            positiveSignals.add("Targets modern Android SDK (API $targetSdk)")
        }

        val hasInternet = allPermsSet.contains("android.permission.INTERNET")
        val hasSms = allPermsSet.any { it.contains("SMS") }
        val hasContacts = allPermsSet.any { it.contains("CONTACTS") }
        val hasCallLog = allPermsSet.any { it.contains("CALL_LOG") }
        val hasInstallPkg = allPermsSet.contains("android.permission.REQUEST_INSTALL_PACKAGES")

        if (hasInternet && hasSms && !isSystemApp) {
            score -= 15
            warnings.add("Requests both SMS access and Internet access (can read/forward SMS or OTP messages).")
        }
        if (hasInternet && (hasContacts || hasCallLog) && !isSystemApp && !isTrusted) {
            score -= 10
            warnings.add("Can access Contacts/Call Logs alongside full Internet connectivity.")
        }
        if (hasInstallPkg && !isSystemApp) {
            score -= 10
            warnings.add("Can request installation of additional APK packages (REQUEST_INSTALL_PACKAGES).")
        }
        if (hasDeviceAdmin && !isSystemApp) {
            score -= 15
            warnings.add("Declares Device Administrator receiver (can lock device or restrict uninstallation).")
        }

        if (!isTrusted && !isSystemApp) {
            score -= (highRiskCapCount * 6 + modRiskCapCount * 2).coerceAtMost(25)
        }

        val finalScore = score.coerceIn(0, 100)
        val riskLevel = when {
            upgradeStatus == "MISMATCH_TAMPERED" || !isSigned -> "CRITICAL"
            finalScore >= 80 -> "LOW"
            finalScore >= 55 -> "MODERATE"
            else -> "HIGH"
        }

        val verdict = when (riskLevel) {
            "CRITICAL" -> "🚨 DO NOT INSTALL — Signature Mismatch or Unsigned APK"
            "LOW" -> "✅ VERIFIED & SAFE — Trusted Developer & Normal Capabilities"
            "MODERATE" -> "⚠️ MODERATE RISK — Review Developer & Requested Capabilities Before Installing"
            else -> "🔴 HIGH RISK — Unverified Signer with Sensitive Device Permissions"
        }

        return JSONObject().apply {
            put("trustScore", finalScore)
            put("riskLevel", riskLevel)
            put("verdict", verdict)
            put("safeToInstall", riskLevel != "CRITICAL")
            put("warnings", JSONArray(warnings))
            put("positiveSignals", JSONArray(positiveSignals))
        }
    }

    private fun resolveKnownPublisher(
        pkg: String,
        cn: String,
        org: String,
        ou: String,
        isSystemApp: Boolean,
        isDebugCert: Boolean
    ): String? {
        if (isDebugCert) return null
        val combined = "$cn $org $ou".lowercase(Locale.US)
        return when {
            combined.contains("google") || (isSystemApp && pkg.startsWith("com.google.")) ->
                "Google LLC (Official)"
            combined.contains("android") && isSystemApp ->
                "Android Open Source Project / System"
            combined.contains("samsung") ->
                "Samsung Electronics Co., Ltd."
            combined.contains("meta") || combined.contains("facebook") ->
                "Meta Platforms, Inc."
            combined.contains("microsoft") ->
                "Microsoft Corporation"
            combined.contains("mozilla") ->
                "Mozilla Corporation"
            combined.contains("termux") ->
                "Termux Official Project"
            isSystemApp ->
                "Device OEM / System Pre-Installed"
            else -> null
        }
    }

    private fun parseDistinguishedName(dn: String): Map<String, String> {
        val result = mutableMapOf<String, String>()
        var currentKey = StringBuilder()
        var currentVal = StringBuilder()
        var inQuotes = false
        var escaped = false
        var parsingKey = true

        for (ch in dn) {
            if (escaped) {
                if (parsingKey) currentKey.append(ch) else currentVal.append(ch)
                escaped = false
                continue
            }
            when (ch) {
                '\\' -> escaped = true
                '"' -> inQuotes = !inQuotes
                '=' -> if (!inQuotes && parsingKey) {
                    parsingKey = false
                } else {
                    if (parsingKey) currentKey.append(ch) else currentVal.append(ch)
                }
                ',' -> if (!inQuotes) {
                    val k = currentKey.toString().trim().uppercase(Locale.US)
                    val v = currentVal.toString().trim()
                    if (k.isNotEmpty() && !result.containsKey(k)) {
                        result[k] = v
                    }
                    currentKey = StringBuilder()
                    currentVal = StringBuilder()
                    parsingKey = true
                } else {
                    currentVal.append(ch)
                }
                else -> if (parsingKey) currentKey.append(ch) else currentVal.append(ch)
            }
        }
        val lastK = currentKey.toString().trim().uppercase(Locale.US)
        val lastV = currentVal.toString().trim()
        if (lastK.isNotEmpty() && !result.containsKey(lastK)) {
            result[lastK] = lastV
        }
        return result
    }

    private fun resolveInstallerLabel(context: Context, pkg: String): String {
        val rawInstaller = try {
            val pm = context.packageManager
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                pm.getInstallSourceInfo(pkg).installingPackageName
            } else {
                @Suppress("DEPRECATION")
                pm.getInstallerPackageName(pkg)
            }
        } catch (_: Exception) {
            null
        }
        return when (rawInstaller) {
            "com.android.vending" -> "Google Play Store"
            "com.google.android.packageinstaller", "com.android.packageinstaller" -> "Package Installer (APK)"
            "com.sec.android.app.samsungapps" -> "Samsung Galaxy Store"
            null, "" -> "System / ADB / Sideload"
            else -> rawInstaller
        }
    }

    private fun computeBytesDigestColon(bytes: ByteArray, algorithm: String): String {
        return try {
            val md = MessageDigest.getInstance(algorithm)
            md.digest(bytes).joinToString(":") { "%02X".format(it) }
        } catch (_: Exception) {
            ""
        }
    }

    private fun computeFileDigest(file: File, algorithm: String): String {
        return try {
            val md = MessageDigest.getInstance(algorithm)
            file.inputStream().use { input ->
                val buf = ByteArray(32 * 1024)
                var read: Int
                while (input.read(buf).also { read = it } > 0) {
                    md.update(buf, 0, read)
                }
            }
            md.digest().joinToString("") { "%02x".format(it) }
        } catch (_: Exception) {
            ""
        }
    }
}
