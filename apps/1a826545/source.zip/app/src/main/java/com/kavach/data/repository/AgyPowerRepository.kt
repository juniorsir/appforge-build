package com.kavach.data.repository

import com.kavach.data.local.AgyMacroEntity
import com.kavach.data.local.AgyPowerDao
import com.kavach.data.local.AgyRunHistoryEntity
import kotlinx.coroutines.flow.Flow
import org.json.JSONArray
import java.util.UUID

class AgyPowerRepository(
    private val dao: AgyPowerDao
) {
    val macrosFlow: Flow<List<AgyMacroEntity>> = dao.observeMacros()
    val pinnedMacrosFlow: Flow<List<AgyMacroEntity>> = dao.observePinnedMacros()
    val runHistoryFlow: Flow<List<AgyRunHistoryEntity>> = dao.observeRunHistory()

    fun searchRunHistory(query: String): Flow<List<AgyRunHistoryEntity>> {
        val trimmed = query.trim()
        return if (trimmed.isEmpty()) dao.observeRunHistory() else dao.searchRunHistory(trimmed)
    }

    suspend fun ensureDefaultMacrosSeeded() {
        if (dao.countMacros() > 0) return
        val now = System.currentTimeMillis()
        dao.upsertMacros(
            listOf(
                AgyMacroEntity(
                    id = "macro_yt_focus",
                    title = "YouTube Focus",
                    prompt = "Open YouTube and play lo-fi coding beats",
                    iconHint = "youtube",
                    category = "Media",
                    isPinned = true,
                    useCount = 3,
                    updatedAt = now - 3000L
                ),
                AgyMacroEntity(
                    id = "macro_termux_status",
                    title = "Termux Status",
                    prompt = "Check Termux bridge health, battery, and active tasks",
                    iconHint = "termux",
                    category = "System",
                    isPinned = true,
                    useCount = 2,
                    updatedAt = now - 2000L
                ),
                AgyMacroEntity(
                    id = "macro_chrome_summary",
                    title = "Chrome Summary",
                    prompt = "Summarize the current open Chrome tab and copy key bullets",
                    iconHint = "chrome",
                    category = "Web",
                    isPinned = true,
                    useCount = 1,
                    updatedAt = now - 1000L
                ),
                AgyMacroEntity(
                    id = "macro_whatsapp_draft",
                    title = "WhatsApp Draft",
                    prompt = "Draft a concise WhatsApp status update and ask before sending",
                    iconHint = "whatsapp",
                    category = "Messaging",
                    isPinned = true,
                    useCount = 0,
                    updatedAt = now
                )
            )
        )
    }

    suspend fun saveMacro(
        id: String? = null,
        title: String,
        prompt: String,
        iconHint: String = "spark_ai",
        category: String = "Custom",
        isPinned: Boolean = true
    ): AgyMacroEntity {
        val entity = AgyMacroEntity(
            id = id?.takeIf { it.isNotBlank() } ?: "macro_${UUID.randomUUID().toString().take(8)}",
            title = title.trim(),
            prompt = prompt.trim(),
            iconHint = iconHint.trim().ifBlank { "spark_ai" },
            category = category.trim().ifBlank { "Custom" },
            isPinned = isPinned,
            updatedAt = System.currentTimeMillis()
        )
        dao.upsertMacro(entity)
        return entity
    }

    suspend fun markMacroUsed(id: String) {
        dao.incrementMacroUse(id)
    }

    suspend fun toggleMacroPinned(id: String, pinned: Boolean) {
        dao.setMacroPinned(id, pinned)
    }

    suspend fun deleteMacro(id: String) {
        dao.deleteMacro(id)
    }

    suspend fun recordRun(
        title: String,
        promptText: String,
        finalState: String,
        iconHint: String = "",
        appPackage: String = "",
        durationMs: Long = 0L,
        stepCount: Int = 0,
        detailedOutput: String = "",
        outputLogs: List<String> = emptyList()
    ): AgyRunHistoryEntity {
        val logsJson = JSONArray().apply {
            outputLogs.forEach { put(it) }
        }.toString()
        val entry = AgyRunHistoryEntity(
            id = "run_${UUID.randomUUID().toString().take(10)}",
            title = title.trim().ifBlank { "Agy Task" },
            promptText = promptText.trim(),
            finalState = finalState.uppercase().trim(),
            iconHint = iconHint.trim(),
            appPackage = appPackage.trim(),
            durationMs = durationMs.coerceAtLeast(0L),
            stepCount = stepCount.coerceAtLeast(0),
            detailedOutput = detailedOutput.trim(),
            outputLogsJson = logsJson,
            timestamp = System.currentTimeMillis()
        )
        dao.insertRun(entry)
        dao.pruneOldRuns(keepCount = 100)
        return entry
    }

    suspend fun deleteRun(id: String) {
        dao.deleteRun(id)
    }

    suspend fun clearRunHistory() {
        dao.clearRunHistory()
    }

    companion object {
        fun parseLogsJson(logsJson: String): List<String> {
            if (logsJson.isBlank()) return emptyList()
            return try {
                val arr = JSONArray(logsJson)
                buildList {
                    for (i in 0 until arr.length()) {
                        val line = arr.optString(i, "").trim()
                        if (line.isNotEmpty()) add(line)
                    }
                }
            } catch (_: Exception) {
                emptyList()
            }
        }
    }
}
