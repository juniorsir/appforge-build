package com.kavach.data.repository

import com.kavach.domain.model.NetworkMessage
import com.kavach.domain.model.PingMessage
import com.kavach.domain.model.PongMessage
import com.kavach.domain.model.SessionState
import com.kavach.domain.repository.WebSocketRepository
import com.kavach.util.AppLogger
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.serialization.json.Json
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import java.util.concurrent.ConcurrentLinkedQueue

class WebSocketRepositoryImpl(
    private val client: OkHttpClient,
    private val logger: AppLogger,
    private val scope: CoroutineScope,
    private val internalTokenProvider: (() -> String?)? = null,
    private val messageAuthGate: ((org.json.JSONObject) -> Boolean)? = null
) : WebSocketRepository {

    private val tag = "WebSocketRepository"

    private val json = Json {
        ignoreUnknownKeys = true
        classDiscriminator = "type"
    }

    @Volatile
    private var webSocket: WebSocket? = null
    @Volatile
    private var activeUrl: String? = null
    @Volatile
    private var isUserDisconnected = true
    private val candidateUrls = java.util.concurrent.CopyOnWriteArrayList<String>()
    private val candidateIndex = java.util.concurrent.atomic.AtomicInteger(0)

    // State Flows
    private val _connectionState = MutableStateFlow(SessionState.ConnectionState.DISCONNECTED)
    override val connectionState: StateFlow<SessionState.ConnectionState> = _connectionState.asStateFlow()

    private val _incomingMessages = MutableSharedFlow<NetworkMessage>()
    override val incomingMessages: SharedFlow<NetworkMessage> = _incomingMessages.asSharedFlow()

    private val _incomingRawMessages = MutableSharedFlow<String>()
    override val incomingRawMessages: SharedFlow<String> = _incomingRawMessages.asSharedFlow()

    private val _latencyMs = MutableStateFlow(0L)
    override val latencyMs: StateFlow<Long> = _latencyMs.asStateFlow()

    private val _bytesSent = MutableStateFlow(0L)
    override val bytesSent: StateFlow<Long> = _bytesSent.asStateFlow()

    private val _bytesReceived = MutableStateFlow(0L)
    override val bytesReceived: StateFlow<Long> = _bytesReceived.asStateFlow()

    private val _queueSize = MutableStateFlow(0)
    override val queueSize: StateFlow<Int> = _queueSize.asStateFlow()

    private val _retryCount = MutableStateFlow(0)
    override val retryCount: StateFlow<Int> = _retryCount.asStateFlow()

    private val _connectionLogs = MutableStateFlow<List<String>>(emptyList())
    override val connectionLogs: StateFlow<List<String>> = _connectionLogs.asStateFlow()

    private val _lastFailureReason = MutableStateFlow<String?>(null)
    override val lastFailureReason: StateFlow<String?> = _lastFailureReason.asStateFlow()

    private val _sessionId = MutableStateFlow<String?>(null)
    override val sessionId: StateFlow<String?> = _sessionId.asStateFlow()

    private val _lastConnectedAt = MutableStateFlow<Long?>(null)
    override val lastConnectedAt: StateFlow<Long?> = _lastConnectedAt.asStateFlow()

    private val _activeUrlFlow = MutableStateFlow(
        com.kavach.services.RealtimeConnectionService.getDefaultOrConfiguredServerUrl()
    )
    override val activeUrlFlow: StateFlow<String> = _activeUrlFlow.asStateFlow()

    // Offline Queue
    private val messageQueue = ConcurrentLinkedQueue<NetworkMessage>()

    // Background Jobs
    private var heartbeatJob: Job? = null
    private var reconnectJob: Job? = null

    // Latency Tracking variables
    private var lastPingId: String? = null
    private var lastPingTimestamp = 0L

    // Thread-safe date formatter and lock for concurrent logging across OkHttp/IO/Main threads
    private val logLock = Any()
    private val timeFormatThreadLocal = object : ThreadLocal<SimpleDateFormat>() {
        override fun initialValue(): SimpleDateFormat = SimpleDateFormat("HH:mm:ss.SSS", Locale.US)
    }

    private fun normalizeWebSocketUrl(rawUrl: String): String {
        var u = rawUrl.trim()
        if (u.startsWith("https://", ignoreCase = true)) {
            u = "wss://" + u.substring(8)
        } else if (u.startsWith("http://", ignoreCase = true)) {
            u = "ws://" + u.substring(7)
        } else if (!u.startsWith("ws://", ignoreCase = true) && !u.startsWith("wss://", ignoreCase = true)) {
            u = "wss://$u"
        }
        val uriPart = u.substringAfter("://")
        val hasQuery = uriPart.contains("?")
        if (!hasQuery) {
            val trimmed = u.trimEnd('/')
            val isRelayPath = trimmed.contains("onrender.com", ignoreCase = true) ||
                trimmed.contains("/p/", ignoreCase = true) ||
                trimmed.contains("/c/", ignoreCase = true) ||
                trimmed.contains("/r/", ignoreCase = true)
            if (!trimmed.endsWith("/ws", ignoreCase = true) && (!uriPart.contains("/") || isRelayPath)) {
                u = "$trimmed/ws"
            }
        }
        return u
    }

    private fun isCompleteConnectableUrl(url: String): Boolean {
        val trimmed = url.trim().trimEnd('/')
        if (trimmed.isBlank()) return false
        if (trimmed.startsWith("ws://127.0.0.1:8080", ignoreCase = true) ||
            trimmed.startsWith("ws://localhost:8080", ignoreCase = true)
        ) {
            return false
        }
        val lower = trimmed.lowercase(Locale.US)
        if (lower.endsWith("/p") || lower.endsWith("/c") || lower.endsWith("/p/ws") || lower.endsWith("/c/ws")) {
            return false
        }
        return true
    }

    override fun setFallbackCandidates(urls: List<String>) {
        val normalized = urls
            .map { normalizeWebSocketUrl(it) }
            .filter { isCompleteConnectableUrl(it) }
            .distinct()
        candidateUrls.clear()
        candidateUrls.addAll(normalized)
    }

    override suspend fun connectBestAvailable(candidates: List<String>, forceSwitch: Boolean) {
        setFallbackCandidates(candidates)
        val available = candidateUrls.toList()
        if (available.isEmpty()) return

        val currentState = _connectionState.value
        val currentActive = activeUrl
        if (!forceSwitch && currentActive != null && available.contains(currentActive) && (
            currentState == SessionState.ConnectionState.CONNECTED ||
            currentState == SessionState.ConnectionState.CONNECTING ||
            currentState == SessionState.ConnectionState.AUTHENTICATING
        )) {
            return
        }

        candidateIndex.set(0)
        connect(available.first())
    }

    override suspend fun connect(url: String) {
        val normalized = normalizeWebSocketUrl(url)
        if (!isCompleteConnectableUrl(normalized)) {
            _lastFailureReason.value = "Enter Render PHONE_KEY or select Local mode"
            addLog("CONNECTION BLOCKED: Incomplete URL ($normalized)")
            return
        }
        if (!candidateUrls.contains(normalized)) {
            candidateUrls.add(0, normalized)
        }
        val idx = candidateUrls.indexOf(normalized)
        if (idx >= 0) {
            candidateIndex.set(idx)
        }

        val previousUrl = activeUrl
        isUserDisconnected = false
        activeUrl = normalized
        _activeUrlFlow.value = normalized
        reconnectJob?.cancel()
        _lastFailureReason.value = null

        if (previousUrl == normalized && (
            _connectionState.value == SessionState.ConnectionState.CONNECTED ||
            _connectionState.value == SessionState.ConnectionState.CONNECTING ||
            _connectionState.value == SessionState.ConnectionState.AUTHENTICATING
        )) {
            addLog("Connection request ignored: Already ${_connectionState.value} to $normalized")
            return
        }

        val oldSocket = webSocket
        webSocket = null
        try {
            oldSocket?.close(1000, "Switching endpoint")
        } catch (_: Exception) {}

        establishConnection(normalized)
    }

    private fun establishConnection(url: String) {
        addLog("Initiating connection to $url")
        _activeUrlFlow.value = url
        activeUrl = url
        _connectionState.value = SessionState.ConnectionState.CONNECTING

        val reqBuilder = Request.Builder().url(url)
        if (url.startsWith("ws://127.0.0.1:8080") || url.startsWith("ws://localhost:8080")) {
            val internalTok = internalTokenProvider?.invoke()
            if (!internalTok.isNullOrBlank()) {
                reqBuilder.addHeader("Authorization", "Bearer $internalTok")
            }
        }
        val request = reqBuilder.build()

        val createdSocket = client.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                if (this@WebSocketRepositoryImpl.webSocket !== webSocket) return
                _connectionState.value = SessionState.ConnectionState.CONNECTED
                _retryCount.value = 0
                _lastConnectedAt.value = System.currentTimeMillis()
                _lastFailureReason.value = null
                val initialSession = _sessionId.value ?: ("session-" + System.currentTimeMillis())
                _sessionId.value = initialSession
                addLog("WebSocket Connected to $url (Session: $initialSession)")
                logger.i(tag, "WebSocket Connected: $url")

                // Send HELLO packet to initiate authenticated session
                val hello = com.kavach.domain.model.HelloMessage(
                    timestamp = System.currentTimeMillis(),
                    sessionId = initialSession,
                    clientName = "CompanionAndroid",
                    deviceId = "android-localhost-bridge",
                    protocolVersion = "1.0.0"
                )
                sendActual(hello)

                // Start periodic Ping heartbeats (must run after _connectionState is CONNECTED)
                startHeartbeat()

                // Resend queued offline messages
                flushQueue()
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                if (this@WebSocketRepositoryImpl.webSocket !== webSocket) return
                scope.launch(Dispatchers.Default) {
                    try {
                        val len = text.toByteArray(Charsets.UTF_8).size.toLong()
                        _bytesReceived.value += len

                        val rootObj = try { org.json.JSONObject(text) } catch (e: Exception) { null }
                        val type = rootObj?.optString("type", "") ?: ""

                        if (_connectionState.value != SessionState.ConnectionState.CONNECTED) {
                            _connectionState.value = SessionState.ConnectionState.CONNECTED
                            _retryCount.value = 0
                            _lastConnectedAt.value = System.currentTimeMillis()
                            _lastFailureReason.value = null
                            startHeartbeat()
                        }
                        val sess = rootObj?.optString("sessionId", "") ?: ""
                        if (sess.isNotEmpty() && _sessionId.value.isNullOrEmpty()) {
                            _sessionId.value = sess
                        }

                        // Always emit raw text to incomingRawMessages for ACAgent and dynamic relay handlers
                        _incomingRawMessages.emit(text)

                        // Attempt typed deserialization
                        var parsedMessage: NetworkMessage? = null
                        try {
                            parsedMessage = json.decodeFromString(NetworkMessage.serializer(), text)
                        } catch (e: Exception) {
                            // If typed decode failed, synthesize an AiStreamMessage if type is AI_STREAM
                            if (type.equals("AI_STREAM", ignoreCase = true) && rootObj != null) {
                                val act = if (rootObj.has("action")) rootObj.optString("action") else null
                                val txt = rootObj.optString("textChunk", rootObj.optString("text", rootObj.optString("message", "")))
                                val isFin = rootObj.optBoolean("isFinal", true)
                                val ts = rootObj.optLong("timestamp", System.currentTimeMillis())
                                val sId = rootObj.optString("sessionId", "ai-stream")
                                parsedMessage = com.kavach.domain.model.AiStreamMessage(
                                    timestamp = ts,
                                    sessionId = sId,
                                    textChunk = txt,
                                    isFinal = isFin,
                                    action = act,
                                    rawJson = text
                                )
                            }
                        }

                        if (parsedMessage != null) {
                            // Handle PONG specifically to compute round-trip latency
                            if (parsedMessage is PongMessage) {
                                if (parsedMessage.pingId == lastPingId) {
                                    val rtt = System.currentTimeMillis() - lastPingTimestamp
                                    _latencyMs.value = rtt
                                    addLog("HEARTBEAT PONG: latency=${rtt}ms")
                                }
                                _incomingMessages.emit(parsedMessage)
                            } else {
                                val upperType = type.uppercase()
                                val isPassiveOrResult = upperType.isEmpty() ||
                                    upperType in listOf(
                                        "HELLO", "PING", "PONG",
                                        "AUTH_REQUIRED", "AUTH_SUCCESS", "AUTH_FAILED",
                                        "REGISTER_SUCCESS", "REGISTER_FAILED",
                                        "AUTH_LOGIN_RESULT", "AUTH_POLL_RESULT",
                                        "HTTP_RPC_RESULT", "ACCESSIBILITY_SCREEN_UPDATE",
                                        "AUDIO_STREAM", "AUDIO_END", "STATUS", "HEARTBEAT",
                                        "ERROR", "STT_RESULT", "STT_PARTIAL", "STT_FINAL",
                                        "STT_START", "STT_END", "STT_ERROR", "TTS_STREAM", "AI_END"
                                    ) || upperType.endsWith("_RESULT")

                                val allowed = isPassiveOrResult ||
                                    messageAuthGate == null ||
                                    (rootObj != null && messageAuthGate.invoke(rootObj))

                                if (allowed) {
                                    addLog("RECV [${parsedMessage::class.simpleName ?: "Packet"}]")
                                    _incomingMessages.emit(parsedMessage)
                                }
                            }
                        } else {
                            addLog("RECV RAW [type=$type, action=${rootObj?.optString("action")}]")
                        }
                    } catch (t: Throwable) {
                        if (t is kotlinx.coroutines.CancellationException) throw t
                        logger.e(tag, "Failed handling WS packet: ${t.message}", t)
                        addLog("PARSE ERROR: Failed handling packet. ${t.message}")
                    }
                }
            }

            override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
                if (this@WebSocketRepositoryImpl.webSocket !== webSocket) return
                addLog("Server closing connection. Code: $code, Reason: $reason")
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                if (this@WebSocketRepositoryImpl.webSocket !== webSocket) return
                _connectionState.value = SessionState.ConnectionState.DISCONNECTED
                addLog("Connection closed. Code: $code")
                stopHeartbeat()
                handleUnexpectedDisconnect()
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                if (this@WebSocketRepositoryImpl.webSocket !== webSocket) return
                val isDedicatedRemoteRelay = url.contains("onrender.com") ||
                    url.contains("/p/") ||
                    url.contains("/c/") ||
                    url.contains("/r/")

                val failureDetail = when {
                    response != null && response.code == 404 && isDedicatedRemoteRelay ->
                        "Relay HTTP 404: Verify PHONE_KEY path (/p/<PHONE_KEY>/ws)"
                    response != null && response.code in listOf(502, 503, 504) && isDedicatedRemoteRelay ->
                        "Render Relay Sleeping / Waking Up (HTTP ${response.code})"
                    response != null && response.code == 530 -> "Cloudflare Tunnel Offline (HTTP 530): Tunnel has expired or origin is inactive"
                    response != null -> "HTTP ${response.code} ${response.message}".trim()
                    t is java.net.ProtocolException && (t.message?.contains("530") == true || t.localizedMessage?.contains("530") == true) ->
                        "Cloudflare Tunnel Offline (HTTP 530): Tunnel expired or inactive"
                    t is java.net.ConnectException -> "Connection refused: Termux server is not listening on port 8000"
                    t is java.net.UnknownServiceException -> "Cleartext HTTP/WS not permitted: ${t.message}"
                    t is java.net.SocketTimeoutException -> "Connection timeout connecting to socket (${t.message})"
                    t is java.net.UnknownHostException -> "Unknown host (${t.message})"
                    t is java.net.ProtocolException -> "WebSocket handshake failed: ${t.message}"
                    t is java.net.SocketException && t.message?.contains("reset", ignoreCase = true) == true -> "Connection reset by peer (${t.message})"
                    else -> "${t.javaClass.simpleName}: ${t.localizedMessage ?: t.message ?: "Socket failure"}"
                }
                _lastFailureReason.value = failureDetail
                _connectionState.value = SessionState.ConnectionState.ERROR
                addLog("CRITICAL: Socket failure - $failureDetail")
                logger.w(tag, "Socket connection error: $failureDetail")
                stopHeartbeat()
                handleUnexpectedDisconnect()
            }
        })
        this.webSocket = createdSocket
    }

    override suspend fun disconnect() {
        isUserDisconnected = true
        activeUrl = null
        reconnectJob?.cancel()
        stopHeartbeat()
        
        webSocket?.close(1000, "User disconnected")
        webSocket = null
        _connectionState.value = SessionState.ConnectionState.DISCONNECTED
        addLog("User triggered Manual Disconnect.")
    }

    override suspend fun sendMessage(message: NetworkMessage) {
        if (!message.validate()) {
            addLog("VALIDATION ERROR: Blocked invalid ${message.type} packet")
            return
        }

        if (_connectionState.value != SessionState.ConnectionState.CONNECTED) {
            // Queue messages while disconnected
            messageQueue.add(message)
            _queueSize.value = messageQueue.size
            addLog("OFFLINE: Queued ${message.type} packet in buffer.")
            return
        }

        sendActual(message)
    }

    override suspend fun sendRaw(text: String): Boolean {
        val ws = webSocket
        return if (ws != null && _connectionState.value == SessionState.ConnectionState.CONNECTED) {
            val ok = ws.send(text)
            if (ok) {
                _bytesSent.value += text.toByteArray(Charsets.UTF_8).size.toLong()
            }
            ok
        } else {
            false
        }
    }

    private fun sendActual(message: NetworkMessage): Boolean {
        return try {
            val jsonStr = json.encodeToString(NetworkMessage.serializer(), message)
            val isSuccess = webSocket?.send(jsonStr) ?: false
            if (isSuccess) {
                val packetBytes = jsonStr.toByteArray(Charsets.UTF_8).size.toLong()
                _bytesSent.value += packetBytes
                if (message !is PingMessage) {
                    addLog("SENT: ${message.type} packet (${packetBytes} B)")
                }
            } else {
                addLog("FAILED SEND: WebSocket send buffer rejected packet")
            }
            isSuccess
        } catch (e: Exception) {
            addLog("FAILED SEND: ${e.localizedMessage}")
            false
        }
    }

    private fun flushQueue() {
        scope.launch(Dispatchers.Default) {
            if (messageQueue.isEmpty()) return@launch
            addLog("ONLINE: Reconnected! Flushing ${messageQueue.size} queued packets...")
            
            while (connectionState.value == SessionState.ConnectionState.CONNECTED && !messageQueue.isEmpty()) {
                val nextMsg = messageQueue.peek() ?: break
                val success = sendActual(nextMsg)
                if (success) {
                    messageQueue.poll()
                    _queueSize.value = messageQueue.size
                } else {
                    addLog("FLUSH ABORT: Interrupted during drain. Retrying later.")
                    break
                }
            }
        }
    }

    private fun handleUnexpectedDisconnect() {
        if (isUserDisconnected || activeUrl == null) return

        reconnectJob?.cancel()
        _connectionState.value = SessionState.ConnectionState.RECONNECTING
        reconnectJob = scope.launch(Dispatchers.Default) {
            val retries = _retryCount.value + 1
            _retryCount.value = retries
            val available = candidateUrls.toList()
            val backoffMs = if (available.size > 1 && retries <= available.size) {
                // Quickly probe the next available candidate (authenticated tunnel or local)
                1200L
            } else {
                calculateExponentialBackoff(retries)
            }

            val targetUrl = if (available.isNotEmpty()) {
                val nextIdx = candidateIndex.incrementAndGet() % available.size
                available[nextIdx]
            } else {
                activeUrl ?: com.kavach.services.RealtimeConnectionService.DEFAULT_SERVER_URL
            }
            addLog("RECONNECTING: Waiting ${backoffMs / 1000.0}s (Retry #$retries) -> $targetUrl...")
            delay(backoffMs)

            if (!isUserDisconnected) {
                activeUrl = targetUrl
                _activeUrlFlow.value = targetUrl
                establishConnection(targetUrl)
            }
        }
    }

    private fun calculateExponentialBackoff(attempt: Int): Long {
        val isTunnelDown = _lastFailureReason.value?.contains("530") == true
        return if (isTunnelDown) {
            // When tunnel is inactive (530), backoff smoothly to avoid tight polling loops
            when (attempt) {
                1 -> 3000L   // 3s
                2 -> 6000L   // 6s
                3 -> 12000L  // 12s
                else -> 30000L // 30s maximum
            }
        } else {
            when (attempt) {
                1 -> 1500L   // 1.5s
                2 -> 3000L   // 3s
                3 -> 6000L   // 6s
                4 -> 12000L  // 12s
                else -> 30000L // 30s maximum
            }
        }
    }

    private fun startHeartbeat() {
        heartbeatJob?.cancel()
        heartbeatJob = scope.launch(Dispatchers.Default) {
            while (_connectionState.value == SessionState.ConnectionState.CONNECTED) {
                delay(5000) // Heartbeat check every 5 seconds
                if (_connectionState.value == SessionState.ConnectionState.CONNECTED) {
                    val pingId = UUID.randomUUID().toString()
                    lastPingId = pingId
                    lastPingTimestamp = System.currentTimeMillis()

                    val ping = PingMessage(
                        timestamp = lastPingTimestamp,
                        sessionId = "heartbeat-session",
                        pingId = pingId
                    )
                    sendActual(ping)
                }
            }
        }
    }

    private fun stopHeartbeat() {
        heartbeatJob?.cancel()
        heartbeatJob = null
    }

    override fun clearLogs() {
        synchronized(logLock) {
            _connectionLogs.value = emptyList()
        }
    }

    override fun addLog(entry: String) {
        val timeStamp = try {
            timeFormatThreadLocal.get()?.format(Date()) ?: "--:--:--"
        } catch (_: Throwable) {
            "--:--:--"
        }
        val formatted = "[$timeStamp] $entry"
        synchronized(logLock) {
            val current = _connectionLogs.value.toMutableList()
            current.add(0, formatted) // Prepend to show latest log at the top
            if (current.size > 200) {
                current.removeAt(current.size - 1) // Cap log limit at 200 elements
            }
            _connectionLogs.value = current
        }
    }
}
