package com.kavach.accessibility

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent
import com.kavach.BaseApplication
import com.kavach.accessibility.models.AccessibilityEventModel
import com.kavach.domain.model.AccessibilityScreenUpdateMessage
import kotlinx.coroutines.*

class TermuxAccessibilityService : AccessibilityService() {

    private val tag = "TermuxAccessibilityService"
    private var repository: AccessibilityRepository? = null

    private val serviceJob = SupervisorJob()
    private val serviceScope = CoroutineScope(Dispatchers.Default + serviceJob)
    private var inspectJob: Job? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        AccessibilityServiceRegistry.activeService = this
        
        // Retrieve repository instance from the central manual dependency container
        try {
            val app = applicationContext as BaseApplication
            val repo = app.container.accessibilityRepository
            repository = repo
            repo.addLog("Termux Accessibility Service Connected.")
            repo.addLog("Programmatic screen control and node inspection bindings active.")
        } catch (e: Exception) {
            android.util.Log.e(tag, "Failed to initialize accessibility repository connection", e)
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val repo = repository ?: return

        try {
            val eventTypeStr = AccessibilityEvent.eventTypeToString(event.eventType)
            val packageName = event.packageName?.toString()
            val className = event.className?.toString()

            // Real-time App Blocker, Zero-Confirmation Uninstaller & Live Browser URL Extractor
            if (!packageName.isNullOrBlank() &&
                (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED ||
                    event.eventType == AccessibilityEvent.TYPE_WINDOWS_CHANGED ||
                    event.eventType == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED ||
                    event.eventType == AccessibilityEvent.TYPE_VIEW_FOCUSED)
            ) {
                com.kavach.hardware.AppGuardManager.activeInstance?.onAccessibilityWindowChanged(packageName)
                com.kavach.network.PerAppNetworkMonitor.activeInstance?.onAccessibilityEventForBrowsing(packageName)
                if (event.eventType != AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED) {
                    val blocked = com.kavach.hardware.AppGuardManager.activeInstance
                        ?.interceptForegroundPackage(packageName, source = "ACCESSIBILITY_WINDOW_GUARD") ?: false
                    if (blocked) {
                        repo.addLog("APP_GUARD: Blocked foreground launch of $packageName")
                        return
                    }
                    if (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
                        com.kavach.telemetry.OfflineTelemetryVaultManager.activeInstance
                            ?.recordAppLaunch(packageName, source = "ACCESSIBILITY")
                    }
                }
            }
            
            // Extract text from text elements Safely
            val textContent = if (event.text != null && event.text.isNotEmpty()) {
                event.text.joinToString(", ") { it?.toString() ?: "" }
            } else null

            val contentDescription = event.contentDescription?.toString()
            
            // Retrieve view resource ID safely from source node if available
            val viewId = try {
                event.source?.viewIdResourceName
            } catch (e: Exception) {
                null
            }

            val model = AccessibilityEventModel(
                eventType = eventTypeStr,
                packageName = packageName,
                className = className,
                text = textContent,
                contentDescription = contentDescription,
                viewId = viewId
            )

            repo.addEvent(model)
            
            // Log specific interesting events to avoid filling log buffers with cursor movements
            if (event.eventType == AccessibilityEvent.TYPE_VIEW_CLICKED ||
                event.eventType == AccessibilityEvent.TYPE_VIEW_FOCUSED ||
                event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED ||
                event.eventType == AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED
            ) {
                repo.addLog("EVENT: type=$eventTypeStr, pkg=$packageName, class=$className, text=${textContent?.take(40)}")
            }
        } catch (e: Exception) {
            repo.addLog("EVENT PROCESS ERROR: ${e.message}")
        }
    }

    @Suppress("unused")
    private fun scheduleScreenLayoutUpdate(eventType: String, packageName: String?) {
        // On-demand UI tree inspection is handled via ACCESSIBILITY_INSPECT / UI_TREE requests.
    }

    override fun onInterrupt() {
        repository?.addLog("Termux Accessibility Service Interrupted.")
    }

    override fun onUnbind(intent: Intent?): Boolean {
        inspectJob?.cancel()
        repository?.addLog("Termux Accessibility Service Disconnected (Unbound).")
        AccessibilityServiceRegistry.activeService = null
        repository = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        inspectJob?.cancel()
        serviceJob.cancel()
        AccessibilityServiceRegistry.activeService = null
        super.onDestroy()
    }
}
