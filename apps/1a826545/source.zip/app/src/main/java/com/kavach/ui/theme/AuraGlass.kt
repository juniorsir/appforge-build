package com.kavach.ui.theme

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * Crisp Light Mode Glass & Component Specifications:
 * Clean pure-white surfaces, soft gray hairline borders, single cobalt blue accent,
 * and sleek iOS/Instagram-style animated pill switches.
 */
@Immutable
enum class AuraGlassLevel(
    val bgAlpha: Float,
    val borderAlpha: Float,
    val highlightAlpha: Float
) {
    LEVEL_1(bgAlpha = 0.92f, borderAlpha = 0.08f, highlightAlpha = 0.04f),
    LEVEL_2(bgAlpha = 0.95f, borderAlpha = 0.10f, highlightAlpha = 0.06f),
    LEVEL_3(bgAlpha = 0.97f, borderAlpha = 0.12f, highlightAlpha = 0.08f),
    ELEVATED(bgAlpha = 1.0f, borderAlpha = 0.14f, highlightAlpha = 0.10f),
    ACTIVE(bgAlpha = 1.0f, borderAlpha = 0.18f, highlightAlpha = 0.12f);

    fun backgroundColor(): Color = CrispSurface.copy(alpha = bgAlpha)
    fun borderColor(): Color = Color(0xFF0F172A).copy(alpha = borderAlpha)

    fun createHighlightBrush(): Brush = Brush.verticalGradient(
        0.0f to Color.White.copy(alpha = highlightAlpha),
        1.0f to Color.Transparent
    )
}

object LiquidGlassTokens {
    val ObsidianVoid = CrispBg                  // #F5F7FA clean cool alabaster canvas
    val GlassCardFill = CrispSurface            // #FFFFFF pure crisp white card
    val GlassModalFill = CrispSurface           // #FFFFFF pure crisp white modal
    val GlassCapsuleFill = CrispSurfaceSubtle   // #F1F5F9 soft neutral gray pill/row
    val GlassPillInputFill = CrispSurfaceSubtle // #F1F5F9 clean Instagram-style search/input fill
    val HairlineStroke = CrispHairline          // #E5E7EB refined 1dp hairline border

    val CyanGlow = CrispBlue                    // #0095F6 Instagram/iOS cobalt blue
    val VioletGlow = CrispIndigo                // #4F46E5 crisp indigo
    val EmeraldGlow = CrispEmerald              // #16A34A crisp emerald
    val AmberGlow = CrispAmber                  // #D97706 warm amber
    val CoralGlow = CrispRose                   // #E11D48 clean rose red

    val OuterCardShape = RoundedCornerShape(22.dp)
    val InnerCapsuleShape = RoundedCornerShape(14.dp)
    val FullPillShape = RoundedCornerShape(50)

    fun specularBorder(
        primaryTint: Color = CrispHairline,
        secondaryTint: Color = CrispBorder,
        width: Dp = 0.85.dp,
        intensity: Float = 1f
    ): BorderStroke {
        // Keep card outlines whisper-thin and neutral unless explicitly alert-tinted
        val strokeColor = if (primaryTint == CrispRose || primaryTint == CrispAmber) {
            primaryTint.copy(alpha = (0.32f * intensity).coerceAtMost(0.48f))
        } else {
            Color(0xFFE8ECF1)
        }
        return BorderStroke(width = width, color = strokeColor)
    }

    val TopRefractionSheen = Brush.verticalGradient(
        0.0f to Color.White.copy(alpha = 0.6f),
        1.0f to Color.Transparent
    )
}

/**
 * Ultra-clean Google/Apple minimalist canvas (#F6F7F9 whisper-soft alabaster).
 */
fun Modifier.liquidObsidianBackground(
    primaryAura: Color = LiquidGlassTokens.CyanGlow,
    secondaryAura: Color = LiquidGlassTokens.VioletGlow
): Modifier = this.background(
    Brush.verticalGradient(
        0.0f to Color(0xFFF8F9FB),
        0.5f to Color(0xFFF5F6F8),
        1.0f to Color(0xFFF2F4F7)
    )
)

/**
 * Pure elevated white grouped card with whisper-thin hairline stroke and gentle depth.
 */
@Composable
fun LiquidGlassCard(
    modifier: Modifier = Modifier,
    accentTint: Color = LiquidGlassTokens.HairlineStroke,
    secondaryTint: Color = LiquidGlassTokens.HairlineStroke,
    shape: Shape = LiquidGlassTokens.OuterCardShape,
    containerColor: Color = LiquidGlassTokens.GlassCardFill,
    content: @Composable BoxScope.() -> Unit
) {
    Surface(
        color = containerColor,
        shape = shape,
        shadowElevation = 0.75.dp,
        border = LiquidGlassTokens.specularBorder(
            primaryTint = accentTint,
            secondaryTint = secondaryTint
        ),
        modifier = modifier.fillMaxWidth()
    ) {
        Box(
            modifier = Modifier.fillMaxWidth(),
            content = content
        )
    }
}

/**
 * Clean soft-tinted icon badge (no harsh neon borders).
 */
@Composable
fun LiquidIconOrb(
    icon: ImageVector,
    tint: Color,
    contentDescription: String? = null,
    size: Dp = 36.dp,
    iconSize: Dp = 18.dp,
    isCircle: Boolean = false,
    modifier: Modifier = Modifier
) {
    val shape = if (isCircle) CircleShape else RoundedCornerShape((size.value * 0.30f).dp)
    Box(
        modifier = modifier
            .size(size)
            .clip(shape)
            .background(tint.copy(alpha = 0.11f)),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = contentDescription,
            tint = tint,
            modifier = Modifier.size(iconSize)
        )
    }
}

/**
 * Sleek iOS / Instagram-style smooth spring-animated pill switch.
 * Replaces chunky default Material 3 switches while maintaining a full 48.dp touch target.
 */
@Composable
fun CrispPillSwitch(
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    modifier: Modifier = Modifier,
    checkedTrackColor: Color = CrispBlue,
    uncheckedTrackColor: Color = Color(0xFFD1D5DB),
    thumbColor: Color = Color.White,
    enabled: Boolean = true,
    switchContentDescription: String? = null
) {
    val trackColor by animateColorAsState(
        targetValue = if (checked) checkedTrackColor else uncheckedTrackColor,
        animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
        label = "pill_switch_track"
    )
    val thumbOffset by animateDpAsState(
        targetValue = if (checked) 20.dp else 0.dp,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioNoBouncy,
            stiffness = Spring.StiffnessMedium
        ),
        label = "pill_switch_thumb"
    )

    val interactionSource = remember { MutableInteractionSource() }
    Box(
        contentAlignment = Alignment.Center,
        modifier = modifier
            .size(width = 52.dp, height = 40.dp)
            .semantics {
                if (switchContentDescription != null) {
                    contentDescription = switchContentDescription
                }
            }
            .clickable(
                enabled = enabled,
                role = Role.Switch,
                interactionSource = interactionSource,
                indication = null,
                onClick = { onCheckedChange(!checked) }
            )
    ) {
        Box(
            modifier = Modifier
                .width(48.dp)
                .height(28.dp)
                .clip(RoundedCornerShape(50))
                .background(if (enabled) trackColor else trackColor.copy(alpha = 0.5f))
                .padding(3.dp),
            contentAlignment = Alignment.CenterStart
        ) {
            Box(
                modifier = Modifier
                    .offset(x = thumbOffset)
                    .size(22.dp)
                    .shadow(elevation = 2.dp, shape = CircleShape)
                    .clip(CircleShape)
                    .background(thumbColor)
            )
        }
    }
}
