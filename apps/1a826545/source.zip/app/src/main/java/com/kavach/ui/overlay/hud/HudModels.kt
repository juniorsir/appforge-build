package com.kavach.ui.overlay.hud

import org.json.JSONArray
import org.json.JSONObject

object HudModels {
    const val HUD_NODE_TAG_PREFIX = "agy_hud_"

    val RANDOM_INPUT_HINTS = listOf(
        "whatsup bro...",
        "tell me...",
        "ask anything...",
        "what's the move?",
        "say or snip something..."
    )

    enum class HudStatus(val wireName: String) {
        IDLE("IDLE"),
        WORKING("WORKING"),
        PAUSED("PAUSED"),
        NEEDS_INPUT("NEEDS_INPUT"),
        STOPPED("STOPPED"),
        DONE("DONE"),
        ERROR("ERROR");

        companion object {
            fun parse(raw: String?): HudStatus {
                return when (raw?.trim()?.uppercase()) {
                    "WORKING", "RUNNING", "ACTIVE", "STOPPING" -> WORKING
                    "PAUSED" -> PAUSED
                    "NEEDS_INPUT", "NEEDS_APPROVAL", "WAITING", "QUESTION" -> NEEDS_INPUT
                    "STOPPED", "CANCELLED" -> STOPPED
                    "DONE", "COMPLETED", "COMPLETE", "SUCCESS" -> DONE
                    "ERROR", "FAILED" -> ERROR
                    else -> IDLE
                }
            }
        }
    }

    data class QuickAction(
        val id: String = "",
        val label: String,
        val commandText: String,
        val actionType: String = "PROMPT", // PROMPT | STOP | FORCE_STOP | PAUSE | RESUME | COPY_OUTPUT | CUSTOM
        val iconHint: String = "",
        val appPackage: String = ""
    ) {
        fun toJson(): JSONObject = JSONObject().apply {
            if (id.isNotBlank()) put("id", id)
            put("label", label)
            put("commandText", commandText)
            put("actionType", actionType)
            if (iconHint.isNotBlank()) put("iconHint", iconHint)
            if (appPackage.isNotBlank()) put("appPackage", appPackage)
        }

        companion object {
            fun fromJson(obj: JSONObject?): QuickAction? {
                if (obj == null) return null
                val label = obj.optString("label", "").trim()
                if (label.isEmpty()) return null
                return QuickAction(
                    id = obj.optString("id", "").trim(),
                    label = label,
                    commandText = obj.optString("commandText", obj.optString("prompt", "")).trim(),
                    actionType = obj.optString("actionType", "PROMPT").trim().uppercase().ifBlank { "PROMPT" },
                    iconHint = obj.optString("iconHint", obj.optString("icon", "")).trim(),
                    appPackage = obj.optString("appPackage", "").trim()
                )
            }
        }
    }

    data class HudStep(
        val id: String,
        val label: String,
        val status: String = "pending", // done | doing | pending | stopped
        val detail: String = ""
    ) {
        companion object {
            fun fromJson(obj: JSONObject?, idx: Int): HudStep? {
                if (obj == null) return null
                val label = obj.optString("label", obj.optString("title", "")).trim()
                if (label.isEmpty()) return null
                return HudStep(
                    id = obj.optString("id", "step_${idx + 1}").trim().ifBlank { "step_${idx + 1}" },
                    label = label,
                    status = obj.optString("status", "pending").trim().lowercase().ifBlank { "pending" },
                    detail = obj.optString("detail", "").trim()
                )
            }
        }
    }

    data class MediaItem(
        val id: String = "",
        val kind: String = "image", // image | video | audio | file
        val title: String = "Media",
        val subtitle: String = "",
        val uri: String = "",
        val thumbnailUri: String = "",
        val mimeType: String = "",
        val durationMs: Long = 0L,
        val previewText: String = ""
    ) {
        val isPlayable: Boolean
            get() = kind == "video" || kind == "audio"

        val isWebEmbed: Boolean
            get() = isWebEmbedUri(uri)

        companion object {
            fun isWebEmbedUri(raw: String?): Boolean {
                val lower = raw?.lowercase().orEmpty()
                return lower.contains("youtube.com/") || lower.contains("youtu.be/")
            }

            fun resolveWebEmbedUrl(raw: String): String {
                val trimmed = raw.trim()
                val ytMatch = Regex("(?:youtube\\.com/(?:watch\\?v=|shorts/|embed/)|youtu\\.be/)([A-Za-z0-9_-]{6,})")
                    .find(trimmed)
                val vid = ytMatch?.groupValues?.getOrNull(1)
                return if (!vid.isNullOrBlank()) {
                    "https://www.youtube.com/embed/$vid?autoplay=1&playsinline=1"
                } else {
                    trimmed
                }
            }

            fun inferKind(uri: String, explicitKind: String = "", mimeType: String = ""): String {
                val k = explicitKind.trim().lowercase()
                if (k in listOf("image", "video", "audio", "file")) return k
                val mime = mimeType.lowercase()
                if (mime.startsWith("image/")) return "image"
                if (mime.startsWith("video/")) return "video"
                if (mime.startsWith("audio/")) return "audio"
                val clean = uri.substringBefore('?').substringBefore('#').lowercase()
                return when {
                    uri.startsWith("data:image/", ignoreCase = true) ||
                        clean.endsWith(".png") || clean.endsWith(".jpg") || clean.endsWith(".jpeg") ||
                        clean.endsWith(".webp") || clean.endsWith(".gif") -> "image"
                    isWebEmbedUri(uri) || clean.endsWith(".mp4") || clean.endsWith(".mov") ||
                        clean.endsWith(".webm") || clean.endsWith(".mkv") || clean.endsWith(".m3u8") -> "video"
                    clean.endsWith(".mp3") || clean.endsWith(".m4a") || clean.endsWith(".wav") ||
                        clean.endsWith(".ogg") || clean.endsWith(".flac") -> "audio"
                    else -> "file"
                }
            }

            fun fromJson(obj: JSONObject?, idx: Int = 0): MediaItem? {
                if (obj == null) return null
                val uri = obj.optString("uri", obj.optString("url", "")).trim()
                val thumb = obj.optString("thumbnailUri", obj.optString("thumbnail", "")).trim()
                val mime = obj.optString("mimeType", "").trim()
                val kind = inferKind(uri, obj.optString("kind", obj.optString("type", "")), mime)
                val title = obj.optString("title", obj.optString("name", "")).trim()
                    .ifBlank { if (kind == "audio") "Track ${idx + 1}" else if (kind == "video") "Video ${idx + 1}" else "Item ${idx + 1}" }
                if (uri.isEmpty() && thumb.isEmpty() && obj.optString("previewText", "").isBlank()) return null
                return MediaItem(
                    id = obj.optString("id", "media_${idx + 1}").trim().ifBlank { "media_${idx + 1}" },
                    kind = kind,
                    title = title,
                    subtitle = obj.optString("subtitle", obj.optString("artist", "")).trim(),
                    uri = uri,
                    thumbnailUri = thumb,
                    mimeType = mime,
                    durationMs = obj.optLong("durationMs", 0L),
                    previewText = obj.optString("previewText", "").trim()
                )
            }
        }
    }

    data class PlayerPlaybackConfig(
        val playlist: List<MediaItem> = emptyList(),
        val currentIndex: Int = 0,
        val mediaMode: String = "video",
        val backgroundMode: Boolean = false,
        val playing: Boolean = false,
        val loop: Boolean = false,
        val muted: Boolean = false,
        val volume: Float = 1.0f,
        val speed: Float = 1.0f,
        val positionMs: Long = 0L,
        val durationMs: Long = 0L,
        val action: String = ""
    )

    data class ChessMoveSquare(
        val from: String = "",
        val to: String = ""
    ) {
        val isValid: Boolean get() = from.length >= 2 && to.length >= 2

        companion object {
            fun fromAny(raw: Any?): ChessMoveSquare? = when (raw) {
                is JSONObject -> {
                    val f = raw.optString("from", "").trim().lowercase()
                    val t = raw.optString("to", "").trim().lowercase()
                    if (f.length >= 2 && t.length >= 2) ChessMoveSquare(f.take(2), t.take(2)) else null
                }
                is String -> {
                    val cleaned = raw.trim().lowercase().replace("->", "").replace(" ", "")
                    if (cleaned.length >= 4) ChessMoveSquare(cleaned.substring(0, 2), cleaned.substring(2, 4)) else null
                }
                else -> null
            }
        }
    }

    data class ChessWidgetState(
        val fen: String = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR",
        val playerColor: String = "white",
        val evalCp: String = "+0.0",
        val lastMove: ChessMoveSquare? = null,
        val bestMove: ChessMoveSquare? = null,
        val turnLabel: String = ""
    ) {
        companion object {
            fun fromJson(obj: JSONObject?): ChessWidgetState? {
                if (obj == null) return null
                val fen = obj.optString("fen", "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR").trim()
                    .ifBlank { "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR" }
                val color = if (obj.optString("playerColor", "white").trim().equals("black", ignoreCase = true)) "black" else "white"
                val evalRaw = if (obj.has("evalCp")) {
                    val v = obj.opt("evalCp")
                    if (v is Number) {
                        val d = v.toDouble()
                        val pawns = if (kotlin.math.abs(d) >= 15.0) d / 100.0 else d
                        if (pawns >= 0) String.format(java.util.Locale.US, "+%.1f", pawns)
                        else String.format(java.util.Locale.US, "%.1f", pawns)
                    } else v?.toString()?.trim().orEmpty().ifBlank { "+0.0" }
                } else "+0.0"
                return ChessWidgetState(
                    fen = fen,
                    playerColor = color,
                    evalCp = evalRaw,
                    lastMove = ChessMoveSquare.fromAny(obj.opt("lastMove")),
                    bestMove = ChessMoveSquare.fromAny(obj.opt("bestMove")),
                    turnLabel = obj.optString("turnLabel", "").trim()
                )
            }
        }
    }

    data class ApprovalPrompt(
        val id: String = "",
        val title: String = "Approval Needed",
        val description: String = "",
        val commandPreview: String = "",
        val riskLevel: String = "medium",
        val allowEdit: Boolean = true,
        val editableText: String = "",
        val timeoutSeconds: Int = 30
    ) {
        companion object {
            fun fromJson(obj: JSONObject?): ApprovalPrompt? {
                if (obj == null) return null
                if (obj.optBoolean("clear", false)) return null
                if (obj.has("active") && !obj.optBoolean("active", true)) return null
                val title = obj.optString("title", "Approval Needed").trim().ifBlank { "Approval Needed" }
                val preview = obj.optString("commandPreview", "").trim()
                return ApprovalPrompt(
                    id = obj.optString("id", obj.optString("approvalId", "apr_${System.currentTimeMillis()}")).trim(),
                    title = title,
                    description = obj.optString("description", obj.optString("message", "")).trim(),
                    commandPreview = preview,
                    riskLevel = obj.optString("riskLevel", "medium").trim().lowercase(),
                    allowEdit = obj.optBoolean("allowEdit", true),
                    editableText = obj.optString("editableText", preview),
                    timeoutSeconds = obj.optInt("timeoutSeconds", 30).coerceIn(0, 300)
                )
            }
        }
    }

    data class HardwareChip(
        val label: String,
        val value: String,
        val iconHint: String = "system"
    ) {
        companion object {
            fun fromJson(obj: JSONObject?): HardwareChip? {
                if (obj == null) return null
                val lbl = obj.optString("label", "").trim()
                val valStr = obj.optString("value", "").trim()
                if (lbl.isEmpty() && valStr.isEmpty()) return null
                return HardwareChip(
                    label = lbl.ifBlank { "Status" },
                    value = valStr,
                    iconHint = obj.optString("iconHint", obj.optString("icon", "system")).trim()
                )
            }
        }
    }

    data class SnippedUiNode(
        val text: String = "",
        val contentDescription: String = "",
        val viewId: String = "",
        val className: String = "",
        val bounds: String = "",
        val centerX: Int = 0,
        val centerY: Int = 0,
        val clickable: Boolean = false
    ) {
        fun toJson(): JSONObject = JSONObject().apply {
            if (text.isNotBlank()) put("text", text)
            if (contentDescription.isNotBlank()) put("contentDescription", contentDescription)
            if (viewId.isNotBlank()) put("viewId", viewId)
            if (className.isNotBlank()) put("className", className)
            if (bounds.isNotBlank()) put("bounds", bounds)
            put("centerX", centerX)
            put("centerY", centerY)
            put("clickable", clickable)
        }
    }

    data class SnippedRegionContext(
        val x1: Int,
        val y1: Int,
        val x2: Int,
        val y2: Int,
        val screenWidth: Int,
        val screenHeight: Int,
        val packageName: String = "",
        val nodes: List<SnippedUiNode> = emptyList(),
        val screenshotBase64: String = "",
        val screenshotMimeType: String = "image/jpeg",
        val screenshotWidth: Int = 0,
        val screenshotHeight: Int = 0
    ) {
        val summaryBadgeText: String
            get() {
                val app = packageName.substringAfterLast('.').ifBlank { "Screen" }
                return "Snip $app (${nodes.size})"
            }

        fun toJson(): JSONObject = JSONObject().apply {
            put("x1", x1)
            put("y1", y1)
            put("x2", x2)
            put("y2", y2)
            put("screenWidth", screenWidth)
            put("screenHeight", screenHeight)
            if (packageName.isNotBlank()) put("packageName", packageName)
            put("nodes", JSONArray().apply { nodes.forEach { put(it.toJson()) } })
            if (screenshotBase64.isNotBlank()) {
                put("screenshotBase64", screenshotBase64)
                put("screenshotMimeType", screenshotMimeType)
                put("screenshotWidth", screenshotWidth)
                put("screenshotHeight", screenshotHeight)
            }
        }
    }

    data class HudUiState(
        val status: HudStatus = HudStatus.IDLE,
        val isVisible: Boolean = false,
        val isCollapsed: Boolean = false,
        val title: String = "Agy Ready",
        val thinkingText: String = "",
        val detailedOutput: String = "",
        val iconKey: String = "spark",
        val appPackage: String = "",
        val progressPercent: Int = -1,
        val steps: List<HudStep> = emptyList(),
        val quickActions: List<QuickAction> = emptyList(),
        val mediaItems: List<MediaItem> = emptyList(),
        val activeMediaIndex: Int = 0,
        val mediaPlaying: Boolean = false,
        val mediaMuted: Boolean = false,
        val chess: ChessWidgetState? = null,
        val approval: ApprovalPrompt? = null,
        val hardwareChip: HardwareChip? = null,
        val logs: List<String> = emptyList(),
        val autoHideSeconds: Int = 0,
        val updatedAtMs: Long = System.currentTimeMillis()
    ) {
        val hasMiddleContent: Boolean
            get() = approval != null ||
                chess != null ||
                mediaItems.isNotEmpty() ||
                detailedOutput.isNotBlank() ||
                steps.isNotEmpty() ||
                hardwareChip != null ||
                quickActions.isNotEmpty()
    }
}
