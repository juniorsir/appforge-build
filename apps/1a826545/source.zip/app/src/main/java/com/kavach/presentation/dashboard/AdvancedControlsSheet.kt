package com.kavach.presentation.dashboard

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.ClearAll
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Launch
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.RingVolume
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Sensors
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val SheetBg = Color(0xFF0E141E)
private val TileBg = Color(0xFF151E2E)
private val InputBg = Color(0xFF0A0E14)
private val SubtleBorder = Color(0xFF223046)
private val Emerald = Color(0xFF10B981)
private val Cyan = Color(0xFF38BDF8)
private val Amber = Color(0xFFF59E0B)
private val Coral = Color(0xFFF43F5E)
private val TextMain = Color(0xFFF8FAFC)
private val TextMuted = Color(0xFF94A3B8)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdvancedControlsBottomSheet(
    initialTab: Int = 0,
    viewModel: DashboardViewModel,
    onDismiss: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var selectedTab by remember(initialTab) { mutableIntStateOf(initialTab.coerceIn(0, 4)) }

    LaunchedEffect(selectedTab) {
        when (selectedTab) {
            2 -> {
                viewModel.refreshNotifications()
                viewModel.loadInstalledApps("")
            }
            4 -> {
                viewModel.searchContacts("")
            }
        }
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = SheetBg,
        contentColor = TextMain
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.86f)
                .padding(horizontal = 16.dp)
                .padding(bottom = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Compact Header Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Controls",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = TextMain
                )
                IconButton(
                    onClick = onDismiss,
                    modifier = Modifier
                        .size(36.dp)
                        .testTag("close_advanced_controls_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Close",
                        tint = TextMuted
                    )
                }
            }

            // 5-Tab Pill Selector (Audio, Touch, System, Media, Comms)
            val tabs = listOf(
                Triple(0, "Audio", Icons.AutoMirrored.Filled.VolumeUp),
                Triple(1, "Touch", Icons.Default.TouchApp),
                Triple(2, "System", Icons.Default.Apps),
                Triple(3, "Media", Icons.Default.CameraAlt),
                Triple(4, "Comms", Icons.Default.Call)
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                tabs.forEach { (idx, title, icon) ->
                    val active = selectedTab == idx
                    Surface(
                        color = if (active) Cyan.copy(alpha = 0.16f) else TileBg,
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, if (active) Cyan.copy(alpha = 0.7f) else SubtleBorder),
                        modifier = Modifier
                            .weight(1f)
                            .height(50.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .clickable { selectedTab = idx }
                            .testTag("adv_tab_${title.lowercase()}")
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = icon,
                                contentDescription = title,
                                tint = if (active) Cyan else TextMuted,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = title,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontSize = 10.sp,
                                    fontWeight = if (active) FontWeight.Bold else FontWeight.Medium
                                ),
                                color = if (active) TextMain else TextMuted,
                                maxLines = 1
                            )
                        }
                    }
                }
            }

            HorizontalDivider(color = SubtleBorder)

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
            ) {
                when (selectedTab) {
                    0 -> AudioAndTtsTab(viewModel)
                    1 -> TouchAndGesturePadTab(viewModel)
                    2 -> AppAndSystemToolsTab(viewModel)
                    3 -> CameraMediaAndFilesTab(viewModel)
                    4 -> TelephonyAndCommsTab(viewModel)
                }
            }
        }
    }
}

@Composable
private fun AudioAndTtsTab(viewModel: DashboardViewModel) {
    val volumeStreams by viewModel.volumeStreams.collectAsState()
    val isSpeaking by viewModel.isSpeakingTts.collectAsState()
    val isRecording by viewModel.isRecordingAudio.collectAsState()

    var ttsInput by remember { mutableStateOf("") }
    var mediaSlider by remember(volumeStreams.mediaPercent) { mutableFloatStateOf(volumeStreams.mediaPercent.toFloat()) }
    var ringSlider by remember(volumeStreams.ringPercent) { mutableFloatStateOf(volumeStreams.ringPercent.toFloat()) }
    var alarmSlider by remember(volumeStreams.alarmPercent) { mutableFloatStateOf(volumeStreams.alarmPercent.toFloat()) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // 1. Text-to-Speech (TTS) Card
        Surface(
            color = TileBg,
            shape = RoundedCornerShape(14.dp),
            border = BorderStroke(1.dp, SubtleBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "Speech",
                    style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.SemiBold),
                    color = TextMain
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = ttsInput,
                        onValueChange = { ttsInput = it },
                        placeholder = { Text("Speak...", color = TextMuted, fontSize = 12.sp) },
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Cyan,
                            unfocusedBorderColor = SubtleBorder,
                            focusedContainerColor = InputBg,
                            unfocusedContainerColor = InputBg
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("tts_text_input")
                    )

                    Button(
                        onClick = {
                            if (isSpeaking) {
                                viewModel.stopTts()
                            } else {
                                val phrase = ttsInput.ifBlank { "AeroShare bridge online and ready" }
                                viewModel.speakText(phrase)
                            }
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isSpeaking) Coral else Emerald
                        ),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .height(50.dp)
                            .testTag("tts_speak_button")
                    ) {
                        Icon(
                            imageVector = if (isSpeaking) Icons.Default.Stop else Icons.Default.PlayArrow,
                            contentDescription = "Speak",
                            tint = Color.Black,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (isSpeaking) "Stop" else "Speak",
                            color = Color.Black,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // Quick TTS Phrases
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf("Online", "Hello", "Alert", "Test").forEach { phrase ->
                        SmallActionPill(
                            label = phrase,
                            color = Cyan,
                            onClick = {
                                ttsInput = phrase
                                viewModel.speakText(phrase)
                            }
                        )
                    }
                }
            }
        }

        // 2. Microphone Audio Clip Recorder
        Surface(
            color = TileBg,
            shape = RoundedCornerShape(14.dp),
            border = BorderStroke(1.dp, SubtleBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = Icons.Default.Mic,
                        contentDescription = null,
                        tint = if (isRecording) Coral else Emerald,
                        modifier = Modifier.size(22.dp)
                    )
                    Text(
                        text = if (isRecording) "Recording" else "Recorder",
                        style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.SemiBold),
                        color = TextMain
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    SmallActionPill(
                        label = if (isRecording) "Busy" else "5s",
                        color = if (isRecording) Coral else Emerald,
                        onClick = { if (!isRecording) viewModel.recordAudioClip(5) }
                    )
                    SmallActionPill(
                        label = "10s",
                        color = Cyan,
                        onClick = { if (!isRecording) viewModel.recordAudioClip(10) }
                    )
                }
            }
        }

        // 3. Multi-Stream Volume Sliders
        Surface(
            color = TileBg,
            shape = RoundedCornerShape(14.dp),
            border = BorderStroke(1.dp, SubtleBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = "Volumes",
                    style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.SemiBold),
                    color = TextMain
                )

                StreamSliderRow(
                    icon = Icons.AutoMirrored.Filled.VolumeUp,
                    label = "Media",
                    value = mediaSlider,
                    tint = Cyan,
                    onValueChange = { mediaSlider = it },
                    onValueChangeFinished = { viewModel.setStreamVolumePercent("MEDIA", mediaSlider.toInt()) }
                )

                StreamSliderRow(
                    icon = Icons.Default.RingVolume,
                    label = "Ring",
                    value = ringSlider,
                    tint = Emerald,
                    onValueChange = { ringSlider = it },
                    onValueChangeFinished = { viewModel.setStreamVolumePercent("RING", ringSlider.toInt()) }
                )

                StreamSliderRow(
                    icon = Icons.Default.Alarm,
                    label = "Alarm",
                    value = alarmSlider,
                    tint = Amber,
                    onValueChange = { alarmSlider = it },
                    onValueChangeFinished = { viewModel.setStreamVolumePercent("ALARM", alarmSlider.toInt()) }
                )
            }
        }
    }
}

@Composable
private fun StreamSliderRow(
    icon: ImageVector,
    label: String,
    value: Float,
    tint: Color,
    onValueChange: (Float) -> Unit,
    onValueChangeFinished: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Icon(imageVector = icon, contentDescription = label, tint = tint, modifier = Modifier.size(18.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            color = TextMain,
            modifier = Modifier.width(46.dp)
        )
        Slider(
            value = value,
            onValueChange = onValueChange,
            onValueChangeFinished = onValueChangeFinished,
            valueRange = 0f..100f,
            colors = SliderDefaults.colors(
                thumbColor = tint,
                activeTrackColor = tint,
                inactiveTrackColor = SubtleBorder
            ),
            modifier = Modifier
                .weight(1f)
                .height(30.dp)
        )
        Text(
            text = "${value.toInt()}%",
            style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace),
            color = TextMuted,
            modifier = Modifier.width(36.dp)
        )
    }
}

@Composable
private fun TouchAndGesturePadTab(viewModel: DashboardViewModel) {
    var tapX by remember { mutableStateOf("540") }
    var tapY by remember { mutableStateOf("1200") }
    var textToInject by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // 1. Directional Swipe & Scroll Pad
        Surface(
            color = TileBg,
            shape = RoundedCornerShape(14.dp),
            border = BorderStroke(1.dp, SubtleBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = "Swipe",
                    style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.SemiBold),
                    color = TextMain
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    PadActionBtn("Up", Icons.Default.KeyboardArrowUp, Cyan, Modifier.weight(1f)) {
                        viewModel.performDirectionalSwipe("UP")
                    }
                    PadActionBtn("Down", Icons.Default.KeyboardArrowDown, Cyan, Modifier.weight(1f)) {
                        viewModel.performDirectionalSwipe("DOWN")
                    }
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    PadActionBtn("Left", Icons.AutoMirrored.Filled.ArrowBack, Emerald, Modifier.weight(1f)) {
                        viewModel.performDirectionalSwipe("LEFT")
                    }
                    PadActionBtn("Right", Icons.AutoMirrored.Filled.ArrowForward, Emerald, Modifier.weight(1f)) {
                        viewModel.performDirectionalSwipe("RIGHT")
                    }
                }
                Text(
                    text = "Scroll",
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold),
                    color = TextMuted
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    PadActionBtn("Up", Icons.Default.KeyboardArrowUp, Amber, Modifier.weight(1f)) {
                        viewModel.performScroll("UP")
                    }
                    PadActionBtn("Down", Icons.Default.KeyboardArrowDown, Amber, Modifier.weight(1f)) {
                        viewModel.performScroll("DOWN")
                    }
                }
            }
        }

        // 2. Coordinate Tap (X, Y)
        Surface(
            color = TileBg,
            shape = RoundedCornerShape(14.dp),
            border = BorderStroke(1.dp, SubtleBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "Coordinates",
                    style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.SemiBold),
                    color = TextMain
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = tapX,
                        onValueChange = { tapX = it.filter { c -> c.isDigit() } },
                        label = { Text("X", fontSize = 11.sp) },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = tapY,
                        onValueChange = { tapY = it.filter { c -> c.isDigit() } },
                        label = { Text("Y", fontSize = 11.sp) },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    )
                    Button(
                        onClick = {
                            val x = tapX.toFloatOrNull() ?: 540f
                            val y = tapY.toFloatOrNull() ?: 1200f
                            viewModel.performCoordinateTap(x, y, isLongPress = false)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Emerald),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.height(50.dp)
                    ) {
                        Text("Tap", color = Color.Black, fontWeight = FontWeight.Bold)
                    }
                    OutlinedButton(
                        onClick = {
                            val x = tapX.toFloatOrNull() ?: 540f
                            val y = tapY.toFloatOrNull() ?: 1200f
                            viewModel.performCoordinateTap(x, y, isLongPress = true)
                        },
                        border = BorderStroke(1.dp, Amber),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.height(50.dp)
                    ) {
                        Text("Hold", color = Amber, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // 3. Text Injection & Hardware Keys
        Surface(
            color = TileBg,
            shape = RoundedCornerShape(14.dp),
            border = BorderStroke(1.dp, SubtleBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "Keyboard",
                    style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.SemiBold),
                    color = TextMain
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = textToInject,
                        onValueChange = { textToInject = it },
                        placeholder = { Text("Type...", color = TextMuted, fontSize = 12.sp) },
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    )
                    Button(
                        onClick = {
                            if (textToInject.isNotBlank()) {
                                viewModel.injectInputText(textToInject)
                                textToInject = ""
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Cyan),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.height(50.dp)
                    ) {
                        Text("Type", color = Color.Black, fontWeight = FontWeight.Bold)
                    }
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf("ENTER", "TAB", "SPACE", "BACKSPACE", "WAKE", "POWER").forEach { keyName ->
                        SmallActionPill(
                            label = keyName,
                            color = Cyan,
                            onClick = { viewModel.sendHardwareKey(keyName) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun PadActionBtn(
    label: String,
    icon: ImageVector,
    tint: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Surface(
        color = InputBg,
        shape = RoundedCornerShape(10.dp),
        border = BorderStroke(1.dp, SubtleBorder),
        modifier = modifier
            .height(46.dp)
            .clip(RoundedCornerShape(10.dp))
            .clickable(onClick = onClick)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center,
            modifier = Modifier.padding(horizontal = 10.dp)
        ) {
            Icon(imageVector = icon, contentDescription = label, tint = tint, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold),
                color = TextMain
            )
        }
    }
}

@Composable
private fun AppAndSystemToolsTab(viewModel: DashboardViewModel) {
    val telemetry by viewModel.systemTelemetry.collectAsState()
    val apps by viewModel.installedApps.collectAsState()
    val notifications by viewModel.activeNotifications.collectAsState()
    val isNotifConnected by viewModel.isNotificationListenerConnected.collectAsState()
    val blockedPackages by viewModel.blockedPackages.collectAsState()
    val alertOnInstall by viewModel.alertOnInstall.collectAsState()
    val alertOnUninstall by viewModel.alertOnUninstall.collectAsState()
    val autoBlockNewInstalls by viewModel.autoBlockNewInstalls.collectAsState()
    val appGuardEvents by viewModel.appGuardEvents.collectAsState()
    val usageQuotas by viewModel.usageQuotasFlow.collectAsState()
    val unlockEvents by viewModel.unlockEventsFlow.collectAsState()
    val unlockMonitorEnabled by viewModel.unlockMonitorEnabled.collectAsState()
    val capturePhotoOnUnlock by viewModel.capturePhotoOnUnlock.collectAsState()
    val watchedKeywords by viewModel.watchedKeywordsFlow.collectAsState()
    val automationRules by viewModel.automationRulesFlow.collectAsState()
    val context = LocalContext.current

    var appSearchQuery by remember { mutableStateOf("") }
    var appFilterMode by remember { mutableStateOf("ALL") } // ALL, BLOCKED, SYSTEM
    var includeSystemApps by remember { mutableStateOf(false) }
    var keywordInput by remember { mutableStateOf("") }

    val filteredApps = remember(apps, blockedPackages, appFilterMode) {
        when (appFilterMode) {
            "BLOCKED" -> apps.filter { it.isBlocked || blockedPackages.contains(it.packageName) }
            "SYSTEM" -> apps.filter { it.isSystemApp }
            else -> apps
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // 1. App Guard: Real-Time Installation Monitor, Alerts & App Blocker
        item {
            Surface(
                color = TileBg,
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.dp, Cyan.copy(alpha = 0.45f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Security,
                                contentDescription = "App Guard",
                                tint = Emerald,
                                modifier = Modifier.size(18.dp)
                            )
                            Text(
                                text = "Guard",
                                style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                                color = TextMain
                            )
                        }

                        Surface(
                            color = if (blockedPackages.isNotEmpty()) Coral.copy(alpha = 0.18f) else Emerald.copy(alpha = 0.16f),
                            shape = RoundedCornerShape(999.dp),
                            border = BorderStroke(
                                1.dp,
                                if (blockedPackages.isNotEmpty()) Coral.copy(alpha = 0.6f) else Emerald.copy(alpha = 0.6f)
                            )
                        ) {
                            Text(
                                text = if (blockedPackages.isNotEmpty()) "${blockedPackages.size} Blocked" else "Active",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 10.sp
                                ),
                                color = if (blockedPackages.isNotEmpty()) Coral else Emerald,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }

                    // Policy Toggle Pills
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        val alertsActive = alertOnInstall && alertOnUninstall
                        SmallActionPill(
                            label = "Alerts",
                            color = if (alertsActive) Emerald else TextMuted,
                            onClick = {
                                val next = !alertsActive
                                viewModel.updateAppGuardPolicy(alertInstall = next, alertUninstall = next)
                            }
                        )
                        SmallActionPill(
                            label = "AutoBlock",
                            color = if (autoBlockNewInstalls) Amber else TextMuted,
                            onClick = {
                                viewModel.updateAppGuardPolicy(autoBlockNew = !autoBlockNewInstalls)
                            }
                        )
                        if (blockedPackages.isNotEmpty()) {
                            SmallActionPill(
                                label = "Unblock (${blockedPackages.size})",
                                color = Coral,
                                onClick = {
                                    viewModel.toggleBlockApp("all")
                                }
                            )
                        }
                    }

                    // Recent Package Installation / Uninstallation / Blocked Launch Events
                    if (appGuardEvents.isNotEmpty()) {
                        HorizontalDivider(color = SubtleBorder)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Activity (${appGuardEvents.size})",
                                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold),
                                color = TextMain
                            )
                            Text(
                                text = "Clear",
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                color = Cyan,
                                modifier = Modifier
                                    .clickable { viewModel.clearAppGuardEvents() }
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }

                        appGuardEvents.take(4).forEach { evt ->
                            val badgeColor = when (evt.eventType) {
                                "INSTALLED" -> Emerald
                                "UPDATED" -> Cyan
                                "UNINSTALLED" -> Amber
                                "BLOCKED_LAUNCH", "APP_BLOCKED" -> Coral
                                else -> Cyan
                            }
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(InputBg)
                                    .padding(horizontal = 10.dp, vertical = 6.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Text(
                                            text = evt.eventType,
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                fontFamily = FontFamily.Monospace,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 9.sp
                                            ),
                                            color = badgeColor
                                        )
                                        Text(
                                            text = evt.appName,
                                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold),
                                            color = TextMain,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                    Text(
                                        text = "${evt.packageName} • ${evt.details.ifBlank { evt.installerSource }}",
                                        style = MaterialTheme.typography.bodySmall.copy(fontSize = 10.sp),
                                        color = TextMuted,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                                Text(
                                    text = evt.formattedTime,
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = 10.sp
                                    ),
                                    color = TextMuted
                                )
                            }
                        }
                    }
                }
            }
        }

        // 1B. Security, Screen-Time Quotas, Keyword Watch & Automation Rules Hub
        item {
            Surface(
                color = TileBg,
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.dp, Emerald.copy(alpha = 0.4f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(
                                text = "Quotas",
                                style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                                color = TextMain
                            )
                            Text(
                                text = "${usageQuotas.size}·${watchedKeywords.size}·${automationRules.size}",
                                style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace, fontSize = 10.sp),
                                color = TextMuted
                            )
                        }
                        SmallActionPill(
                            label = "Usage",
                            color = Cyan,
                            onClick = {
                                try {
                                    context.startActivity(
                                        Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).apply {
                                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                        }
                                    )
                                } catch (_: Exception) {}
                            }
                        )
                    }

                    // Quick Intruder & Automation Controls
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        SmallActionPill(
                            label = "Unlocks",
                            color = if (unlockMonitorEnabled) Emerald else TextMuted,
                            onClick = { viewModel.updateUnlockMonitorPolicy(enabled = !unlockMonitorEnabled) }
                        )
                        SmallActionPill(
                            label = "Snap",
                            color = if (capturePhotoOnUnlock) Coral else TextMuted,
                            onClick = { viewModel.updateUnlockMonitorPolicy(capturePhoto = !capturePhotoOnUnlock) }
                        )
                        SmallActionPill(
                            label = "Capture",
                            color = Amber,
                            onClick = { viewModel.triggerIntruderSnapNow("front") }
                        )
                        SmallActionPill(
                            label = "+Battery",
                            color = Cyan,
                            onClick = {
                                viewModel.addQuickAutomationRule(
                                    name = "Low Battery Alert",
                                    triggerSpec = "battery_below:20",
                                    actionSpec = "notify:Battery below 20%"
                                )
                            }
                        )
                    }

                    // Keyword Watch Input Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = keywordInput,
                            onValueChange = { keywordInput = it },
                            placeholder = {
                                Text(
                                    "Keyword...",
                                    fontSize = 11.sp,
                                    color = TextMuted
                                )
                            },
                            singleLine = true,
                            textStyle = MaterialTheme.typography.bodySmall.copy(color = TextMain, fontSize = 12.sp),
                            modifier = Modifier
                                .weight(1f)
                                .height(46.dp)
                                .testTag("keyword_watch_input"),
                            shape = RoundedCornerShape(10.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = Emerald,
                                unfocusedBorderColor = SubtleBorder,
                                focusedContainerColor = InputBg,
                                unfocusedContainerColor = InputBg
                            )
                        )
                        Button(
                            onClick = {
                                if (keywordInput.isNotBlank()) {
                                    viewModel.addWatchedKeyword(keywordInput.trim())
                                    keywordInput = ""
                                }
                            },
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Emerald.copy(alpha = 0.2f),
                                contentColor = Emerald
                            ),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 10.dp),
                            modifier = Modifier.testTag("add_keyword_watch_button")
                        ) {
                            Text("Watch", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    if (watchedKeywords.isNotEmpty()) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            watchedKeywords.forEach { kw ->
                                SmallActionPill(
                                    label = "$kw ×",
                                    color = Amber,
                                    onClick = { viewModel.removeWatchedKeyword(kw) }
                                )
                            }
                        }
                    }
                }
            }
        }

        // 2. Live System & Sensor Telemetry Strip
        item {
            Surface(
                color = TileBg,
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.dp, SubtleBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Telemetry",
                            style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.SemiBold),
                            color = TextMain
                        )
                        SmallActionPill(
                            label = "Refresh",
                            color = Cyan,
                            onClick = { viewModel.refreshNotifications() }
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        TelemetryMiniBadge(
                            icon = Icons.Default.BatteryChargingFull,
                            label = "Battery",
                            value = "${telemetry.batteryPercent}% (${telemetry.batteryTempC}°C)",
                            tint = Emerald,
                            modifier = Modifier.weight(1f)
                        )
                        TelemetryMiniBadge(
                            icon = Icons.Default.Memory,
                            label = "RAM",
                            value = "${telemetry.ramUsedMb}/${telemetry.ramTotalMb} MB",
                            tint = Cyan,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        TelemetryMiniBadge(
                            icon = Icons.Default.Storage,
                            label = "Storage",
                            value = String.format("%.1f / %.1f GB", telemetry.storageFreeGb, telemetry.storageTotalGb),
                            tint = Amber,
                            modifier = Modifier.weight(1f)
                        )
                        TelemetryMiniBadge(
                            icon = Icons.Default.Sensors,
                            label = "Sensors",
                            value = String.format("Z:%.1f | %.0f lx", telemetry.accelZ, telemetry.lightLux),
                            tint = Emerald,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }

        // 3. Active Notifications Card
        item {
            Surface(
                color = TileBg,
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.dp, SubtleBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Notifications,
                                contentDescription = null,
                                tint = Amber,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = "Notifications (${notifications.size})",
                                style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.SemiBold),
                                color = TextMain
                            )
                        }

                        if (!isNotifConnected) {
                            SmallActionPill(
                                label = "Enable",
                                color = Amber,
                                onClick = {
                                    try {
                                        context.startActivity(
                                            Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).apply {
                                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                            }
                                        )
                                    } catch (_: Exception) {}
                                }
                            )
                        } else if (notifications.isNotEmpty()) {
                            SmallActionPill(
                                label = "Clear",
                                color = Coral,
                                onClick = { viewModel.dismissAllNotifications() }
                            )
                        }
                    }

                    if (notifications.isNotEmpty()) {
                        notifications.take(3).forEach { notif ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(InputBg)
                                    .padding(horizontal = 10.dp, vertical = 6.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = notif.title,
                                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold),
                                        color = TextMain,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    if (notif.text.isNotEmpty()) {
                                        Text(
                                            text = notif.text,
                                            style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                                            color = TextMuted,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                }
                                if (notif.isClearable) {
                                    IconButton(
                                        onClick = { viewModel.dismissNotification(notif.key) },
                                        modifier = Modifier.size(28.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Close,
                                            contentDescription = "Dismiss",
                                            tint = TextMuted,
                                            modifier = Modifier.size(14.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // 4. App Search & Filter Bar
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = appSearchQuery,
                    onValueChange = {
                        appSearchQuery = it
                        viewModel.loadInstalledApps(it, includeSystem = includeSystemApps)
                    },
                    placeholder = {
                        Text(
                            "Search (${filteredApps.size})...",
                            color = TextMuted,
                            fontSize = 12.sp
                        )
                    },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = TextMuted) },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Cyan,
                        unfocusedBorderColor = SubtleBorder,
                        focusedContainerColor = TileBg,
                        unfocusedContainerColor = TileBg
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("app_guard_search_input")
                )

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    SmallActionPill(
                        label = "All (${apps.size})",
                        color = if (appFilterMode == "ALL") Cyan else TextMuted,
                        onClick = { appFilterMode = "ALL" }
                    )
                    SmallActionPill(
                        label = "Blocked (${blockedPackages.size})",
                        color = if (appFilterMode == "BLOCKED") Coral else TextMuted,
                        onClick = { appFilterMode = "BLOCKED" }
                    )
                    SmallActionPill(
                        label = "System",
                        color = if (includeSystemApps) Amber else TextMuted,
                        onClick = {
                            includeSystemApps = !includeSystemApps
                            viewModel.loadInstalledApps(appSearchQuery, includeSystem = includeSystemApps)
                        }
                    )
                }
            }
        }

        // 5. Installed Apps with Block / Unblock, Uninstall, Force Stop, Info & Launch Controls
        items(filteredApps, key = { it.packageName }) { app ->
            val isBlocked = app.isBlocked || blockedPackages.contains(app.packageName)
            Surface(
                color = TileBg,
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(
                    1.dp,
                    if (isBlocked) Coral.copy(alpha = 0.65f) else SubtleBorder
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("app_item_card_${app.packageName}")
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text(
                                    text = app.name,
                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                                    color = if (isBlocked) Coral else TextMain,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                if (app.versionName.isNotBlank()) {
                                    Text(
                                        text = "v${app.versionName}",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontFamily = FontFamily.Monospace,
                                            fontSize = 10.sp
                                        ),
                                        color = TextMuted
                                    )
                                }
                                if (isBlocked) {
                                    Surface(
                                        color = Coral.copy(alpha = 0.2f),
                                        shape = RoundedCornerShape(4.dp)
                                    ) {
                                        Text(
                                            text = "BLOCKED",
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 9.sp
                                            ),
                                            color = Coral,
                                            modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                                        )
                                    }
                                } else if (app.isSystemApp) {
                                    Surface(
                                        color = Amber.copy(alpha = 0.15f),
                                        shape = RoundedCornerShape(4.dp)
                                    ) {
                                        Text(
                                            text = "SYSTEM",
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 9.sp
                                            ),
                                            color = Amber,
                                            modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                            }
                            Text(
                                text = app.packageName,
                                style = MaterialTheme.typography.bodySmall.copy(
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 10.sp
                                ),
                                color = TextMuted,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }

                    // Rich Per-App Action Controls Row
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // 1. Block / Unblock
                        SmallActionPill(
                            label = if (isBlocked) "Unblock" else "Block",
                            color = if (isBlocked) Emerald else Coral,
                            onClick = { viewModel.toggleBlockApp(app.packageName) }
                        )

                        // 2. Uninstall
                        SmallActionPill(
                            label = "Uninstall",
                            color = Amber,
                            onClick = { viewModel.uninstallApp(app.packageName) }
                        )

                        // 3. Force Stop
                        SmallActionPill(
                            label = "Stop",
                            color = Cyan,
                            onClick = { viewModel.forceStopApp(app.packageName) }
                        )

                        // 4. APK Backup Extractor
                        SmallActionPill(
                            label = "Backup",
                            color = Emerald,
                            onClick = { viewModel.backupAppApk(app.packageName) }
                        )

                        // 5. Daily 30m Screen-Time Quota Toggle
                        val activeQuota = usageQuotas.firstOrNull { it.packageName == app.packageName }
                        SmallActionPill(
                            label = if (activeQuota != null) "${activeQuota.dailyLimitMinutes}m" else "30m",
                            color = if (activeQuota != null) Amber else Cyan,
                            onClick = {
                                if (activeQuota != null) {
                                    viewModel.setAppDailyLimit(app.packageName, 0)
                                } else {
                                    viewModel.setAppDailyLimit(app.packageName, 30)
                                }
                            }
                        )

                        // 6. App Info / Settings
                        SmallActionPill(
                            label = "Info",
                            color = TextMuted,
                            onClick = { viewModel.openAppSettings(app.packageName) }
                        )

                        // 7. Launch App
                        if (!isBlocked) {
                            SmallActionPill(
                                label = "Open",
                                color = Emerald,
                                onClick = { viewModel.launchApp(app.packageName) }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TelemetryMiniBadge(
    icon: ImageVector,
    label: String,
    value: String,
    tint: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        color = InputBg,
        shape = RoundedCornerShape(10.dp),
        border = BorderStroke(1.dp, SubtleBorder),
        modifier = modifier
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(imageVector = icon, contentDescription = label, tint = tint, modifier = Modifier.size(16.dp))
            Column {
                Text(text = label, style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp), color = TextMuted)
                Text(
                    text = value,
                    style = MaterialTheme.typography.labelMedium.copy(
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.SemiBold
                    ),
                    color = TextMain,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
private fun CameraMediaAndFilesTab(viewModel: DashboardViewModel) {
    var urlToOpen by remember { mutableStateOf("https://") }
    var shareText by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // 1. Quick Camera, Screenshot & Script Export Tiles
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            PadActionBtn(
                label = "Camera",
                icon = Icons.Default.CameraAlt,
                tint = Cyan,
                modifier = Modifier.weight(1f)
            ) {
                viewModel.openCameraCapture()
            }
            PadActionBtn(
                label = "Screenshot",
                icon = Icons.Default.TouchApp,
                tint = Emerald,
                modifier = Modifier.weight(1f)
            ) {
                viewModel.captureScreenshot()
            }
        }

        // 2. Export Server Scripts to /sdcard/Download/AeroShare
        Surface(
            color = TileBg,
            shape = RoundedCornerShape(14.dp),
            border = BorderStroke(1.dp, SubtleBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(imageVector = Icons.Default.Code, contentDescription = null, tint = Emerald, modifier = Modifier.size(22.dp))
                    Text(
                        text = "Scripts",
                        style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.SemiBold),
                        color = TextMain
                    )
                }
                Button(
                    onClick = { viewModel.exportServerScripts() },
                    colors = ButtonDefaults.buttonColors(containerColor = Emerald),
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp)
                ) {
                    Text("Export", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            }
        }

        // 3. Open URL / Deep Link on Device
        Surface(
            color = TileBg,
            shape = RoundedCornerShape(14.dp),
            border = BorderStroke(1.dp, SubtleBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = "Browser",
                    style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.SemiBold),
                    color = TextMain
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = urlToOpen,
                        onValueChange = { urlToOpen = it },
                        placeholder = { Text("https://...", color = TextMuted, fontSize = 12.sp) },
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    )
                    Button(
                        onClick = { viewModel.openUrlOnDevice(urlToOpen) },
                        colors = ButtonDefaults.buttonColors(containerColor = Cyan),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.height(50.dp)
                    ) {
                        Icon(Icons.Default.Launch, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Open", color = Color.Black, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // 4. System Share Sheet Trigger
        Surface(
            color = TileBg,
            shape = RoundedCornerShape(14.dp),
            border = BorderStroke(1.dp, SubtleBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = "Share",
                    style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.SemiBold),
                    color = TextMain
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = shareText,
                        onValueChange = { shareText = it },
                        placeholder = { Text("Text...", color = TextMuted, fontSize = 12.sp) },
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    )
                    Button(
                        onClick = { viewModel.shareTextContent(shareText) },
                        colors = ButtonDefaults.buttonColors(containerColor = Amber),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.height(50.dp)
                    ) {
                        Icon(Icons.Default.Share, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Share", color = Color.Black, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun TelephonyAndCommsTab(viewModel: DashboardViewModel) {
    val contacts by viewModel.contactsList.collectAsState()
    var phoneInput by remember { mutableStateOf("") }
    var smsBody by remember { mutableStateOf("") }
    var contactSearch by remember { mutableStateOf("") }

    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // 1. Dialer & SMS Composer Card
        Surface(
            color = TileBg,
            shape = RoundedCornerShape(14.dp),
            border = BorderStroke(1.dp, SubtleBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = phoneInput,
                        onValueChange = { phoneInput = it },
                        placeholder = { Text("Phone...", color = TextMuted, fontSize = 12.sp) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("comms_phone_input")
                    )
                    Button(
                        onClick = { viewModel.dialPhoneNumber(phoneInput) },
                        colors = ButtonDefaults.buttonColors(containerColor = Emerald),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .height(50.dp)
                            .testTag("comms_dial_button")
                    ) {
                        Icon(Icons.Default.Call, contentDescription = "Call", tint = Color.Black, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Call", color = Color.Black, fontWeight = FontWeight.Bold)
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = smsBody,
                        onValueChange = { smsBody = it },
                        placeholder = { Text("Message...", color = TextMuted, fontSize = 12.sp) },
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("comms_sms_input")
                    )
                    Button(
                        onClick = {
                            if (phoneInput.isNotBlank() && smsBody.isNotBlank()) {
                                viewModel.sendQuickSms(phoneInput, smsBody)
                                smsBody = ""
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Cyan),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .height(50.dp)
                            .testTag("comms_send_sms_button")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send SMS", tint = Color.Black, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("SMS", color = Color.Black, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // 2. Contacts Lookup
        OutlinedTextField(
            value = contactSearch,
            onValueChange = {
                contactSearch = it
                viewModel.searchContacts(it)
            },
            placeholder = { Text("Contacts (${contacts.size})...", color = TextMuted, fontSize = 12.sp) },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = TextMuted) },
            singleLine = true,
            shape = RoundedCornerShape(12.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = Cyan,
                unfocusedBorderColor = SubtleBorder,
                focusedContainerColor = TileBg,
                unfocusedContainerColor = TileBg
            ),
            modifier = Modifier.fillMaxWidth()
        )

        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            items(contacts, key = { "${it.name}|${it.phone}" }) { contact ->
                Surface(
                    color = TileBg,
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, SubtleBorder),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .clickable { phoneInput = contact.phone }
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.Person, contentDescription = null, tint = Cyan, modifier = Modifier.size(18.dp))
                            Column {
                                Text(
                                    text = contact.name,
                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                                    color = TextMain,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = contact.phone,
                                    style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace),
                                    color = TextMuted
                                )
                            }
                        }
                        SmallActionPill(
                            label = "Dial",
                            color = Emerald,
                            onClick = {
                                phoneInput = contact.phone
                                viewModel.dialPhoneNumber(contact.phone)
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SmallActionPill(
    label: String,
    color: Color,
    onClick: () -> Unit
) {
    Surface(
        color = color.copy(alpha = 0.15f),
        shape = RoundedCornerShape(8.dp),
        border = BorderStroke(1.dp, color.copy(alpha = 0.55f)),
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .clickable(onClick = onClick)
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
            color = color,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
        )
    }
}
