package com.kavach.ui.overlay

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.view.MotionEvent
import android.view.View
import kotlin.math.min

/**
 * Custom Canvas renderer for Apple SF Symbols-inspired vector SVG icons and translucent
 * frosted-glass inline buttons used across the Left-Window Media Player and Task Map header.
 *
 * All icons are drawn on a normalized 24x24 virtual coordinate space with smooth rounded caps,
 * rounded joins, and zero emoji glyph dependencies.
 */
class AgyAppleVectorIconView(
    context: Context,
    initialIcon: IconType = IconType.PLAY_FILL
) : View(context) {

    enum class IconType {
        NONE,
        PLAY_FILL,
        PAUSE_FILL,
        BACKWARD_FILL,
        FORWARD_FILL,
        VIDEO_FILL,
        MUSIC_NOTE,
        WAVEFORM,
        PIP_ENTER,
        ARROW_EXPAND,
        REPEAT,
        SPEAKER_WAVE,
        SPEAKER_SLASH,
        LIST_BULLET,
        RESIZE_PANE,
        OPACITY_DROP,
        MINUS,
        XMARK,
        MAP_GRID,
        DIAGRAM_FLOW,
        DIAGRAM_SEQUENCE,
        CHART_BAR,
        ZOOM_IN,
        ZOOM_OUT,
        FIT_RESET,
        PHOTO_STACK,
        CHEVRON_LEFT,
        CHEVRON_RIGHT,
        CHEVRON_UP,
        CHEVRON_DOWN,
        ELLIPSIS,
        SPARKLES,
        SCISSORS,
        STOP_SQUARE
    }

    enum class GlassStyle {
        NONE,
        GLASS_CIRCLE,
        GLASS_PILL,
        ACCENT_CIRCLE,
        ACCENT_PILL,
        SUBTLE_CHIP
    }

    private val d = context.resources.displayMetrics.density.coerceAtLeast(1f)

    var iconType: IconType = initialIcon
        set(value) {
            if (field != value) {
                field = value
                invalidate()
            }
        }

    var labelText: String = ""
        set(value) {
            if (field != value) {
                field = value
                requestLayout()
                invalidate()
            }
        }

    var iconTint: Int = Color.WHITE
        set(value) {
            if (field != value) {
                field = value
                invalidate()
            }
        }

    var glassStyle: GlassStyle = GlassStyle.GLASS_CIRCLE
        set(value) {
            if (field != value) {
                field = value
                invalidate()
            }
        }

    var accentColor: Int = Color.parseColor("#EC4899")
        set(value) {
            if (field != value) {
                field = value
                invalidate()
            }
        }

    var glassFillColor: Int = Color.parseColor("#960F172A")
        set(value) {
            if (field != value) {
                field = value
                invalidate()
            }
        }

    var glassBorderColor: Int = Color.parseColor("#42FFFFFF")
        set(value) {
            if (field != value) {
                field = value
                invalidate()
            }
        }

    var iconSizeDp: Float = 15f
        set(value) {
            if (field != value) {
                field = value
                requestLayout()
                invalidate()
            }
        }

    var minTouchSizeDp: Float = 30f
        set(value) {
            if (field != value) {
                field = value
                requestLayout()
                invalidate()
            }
        }

    private var isPressedState: Boolean = false

    private val bgFillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val bgStrokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1f * d
    }
    private val iconFillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val iconStrokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        textSize = 9.5f * d
    }

    private val bgRect = RectF()
    private val path = Path()

    init {
        isClickable = true
        isFocusable = true
    }

    /**
     * Convenience helper for compatibility with tests or callers reading a button label.
     */
    fun describeState(): String = if (labelText.isNotBlank()) labelText else iconType.name

    override fun onTouchEvent(event: MotionEvent?): Boolean {
        when (event?.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                isPressedState = true
                invalidate()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (isPressedState) {
                    isPressedState = false
                    invalidate()
                }
            }
        }
        return super.onTouchEvent(event)
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val minPx = (minTouchSizeDp * d).toInt()
        val iconPx = if (iconType == IconType.NONE) 0 else (iconSizeDp * d).toInt()
        textPaint.textSize = 9.5f * d
        val textW = if (labelText.isNotBlank()) textPaint.measureText(labelText).toInt() else 0
        val gapPx = if (iconType != IconType.NONE && labelText.isNotBlank()) (4 * d).toInt() else 0
        val hPad = if (labelText.isNotBlank()) (16 * d).toInt() else (12 * d).toInt()
        val desiredW = (iconPx + gapPx + textW + hPad).coerceAtLeast(minPx)
        val desiredH = minPx

        val resolvedW = resolveSize(desiredW, widthMeasureSpec)
        val resolvedH = resolveSize(desiredH, heightMeasureSpec)
        setMeasuredDimension(resolvedW, resolvedH)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        // 1. Draw translucent glass or accent pill/circle background
        if (glassStyle != GlassStyle.NONE) {
            val inset = 0.75f * d
            bgRect.set(inset, inset, w - inset, h - inset)
            val radius = when (glassStyle) {
                GlassStyle.GLASS_CIRCLE, GlassStyle.ACCENT_CIRCLE -> min(bgRect.width(), bgRect.height()) / 2f
                else -> 999f * d
            }
            val baseFill = when (glassStyle) {
                GlassStyle.ACCENT_CIRCLE, GlassStyle.ACCENT_PILL -> accentColor
                else -> glassFillColor
            }
            bgFillPaint.color = if (isPressedState) blendColor(baseFill, Color.WHITE, 0.16f) else baseFill
            canvas.drawRoundRect(bgRect, radius, radius, bgFillPaint)

            bgStrokePaint.strokeWidth = 0.9f * d
            bgStrokePaint.color = when (glassStyle) {
                GlassStyle.ACCENT_CIRCLE, GlassStyle.ACCENT_PILL -> Color.argb(95, 255, 255, 255)
                else -> glassBorderColor
            }
            canvas.drawRoundRect(bgRect, radius, radius, bgStrokePaint)
        }

        // 2. Compute horizontal centering of icon + optional inline text label
        val iconSide = if (iconType == IconType.NONE) 0f else iconSizeDp * d
        textPaint.color = iconTint
        textPaint.textSize = 9.5f * d
        val hasLabel = labelText.isNotBlank()
        val textWidth = if (hasLabel) textPaint.measureText(labelText) else 0f
        val gap = if (iconType != IconType.NONE && hasLabel) 3.5f * d else 0f
        val totalContentW = iconSide + gap + textWidth
        val startX = (w - totalContentW) / 2f

        if (iconType != IconType.NONE) {
            val iconTop = (h - iconSide) / 2f
            drawVectorIcon(canvas, iconType, startX, iconTop, iconSide, iconTint)
        }

        if (hasLabel) {
            val textX = startX + iconSide + gap
            val fm = textPaint.fontMetrics
            val textY = h / 2f - (fm.ascent + fm.descent) / 2f
            canvas.drawText(labelText, textX, textY, textPaint)
        }
    }

    private fun drawVectorIcon(
        canvas: Canvas,
        type: IconType,
        left: Float,
        top: Float,
        size: Float,
        color: Int
    ) {
        val u = size / 24f
        fun sx(v: Float): Float = left + v * u
        fun sy(v: Float): Float = top + v * u

        iconFillPaint.color = color
        iconStrokePaint.color = color
        iconStrokePaint.strokeWidth = (2.05f * u).coerceAtLeast(1.2f * d)

        path.reset()
        when (type) {
            IconType.NONE -> Unit

            IconType.PLAY_FILL -> {
                // Apple SF play.fill — optically shifted slightly right
                path.moveTo(sx(7.2f), sy(4.8f))
                path.lineTo(sx(19.2f), sy(12.0f))
                path.lineTo(sx(7.2f), sy(19.2f))
                path.close()
                canvas.drawPath(path, iconFillPaint)
                canvas.drawPath(path, iconStrokePaint.apply { strokeWidth = 1.4f * u })
            }

            IconType.PAUSE_FILL -> {
                // Apple SF pause.fill — two crisp rounded vertical bars
                val r = 1.6f * u
                canvas.drawRoundRect(RectF(sx(6.2f), sy(4.8f), sx(10.2f), sy(19.2f)), r, r, iconFillPaint)
                canvas.drawRoundRect(RectF(sx(13.8f), sy(4.8f), sx(17.8f), sy(19.2f)), r, r, iconFillPaint)
            }

            IconType.BACKWARD_FILL -> {
                // Apple SF backward.end.fill / backward.fill
                val r = 1.0f * u
                canvas.drawRoundRect(RectF(sx(4.5f), sy(5.8f), sx(6.7f), sy(18.2f)), r, r, iconFillPaint)
                path.moveTo(sx(18.6f), sy(5.6f))
                path.lineTo(sx(8.6f), sy(12.0f))
                path.lineTo(sx(18.6f), sy(18.4f))
                path.close()
                canvas.drawPath(path, iconFillPaint)
            }

            IconType.FORWARD_FILL -> {
                // Apple SF forward.end.fill / forward.fill
                val r = 1.0f * u
                path.moveTo(sx(5.4f), sy(5.6f))
                path.lineTo(sx(15.4f), sy(12.0f))
                path.lineTo(sx(5.4f), sy(18.4f))
                path.close()
                canvas.drawPath(path, iconFillPaint)
                canvas.drawRoundRect(RectF(sx(17.3f), sy(5.8f), sx(19.5f), sy(18.2f)), r, r, iconFillPaint)
            }

            IconType.VIDEO_FILL -> {
                // Apple SF video.fill — rounded camera body + right lens cone
                val r = 2.4f * u
                canvas.drawRoundRect(RectF(sx(2.8f), sy(6.2f), sx(15.2f), sy(17.8f)), r, r, iconFillPaint)
                path.moveTo(sx(15.8f), sy(10.0f))
                path.lineTo(sx(21.2f), sy(7.0f))
                path.lineTo(sx(21.2f), sy(17.0f))
                path.lineTo(sx(15.8f), sy(14.0f))
                path.close()
                canvas.drawPath(path, iconFillPaint)
            }

            IconType.MUSIC_NOTE -> {
                // Apple SF music.note — beamed eighth notes
                iconStrokePaint.strokeWidth = 2.1f * u
                path.moveTo(sx(9.5f), sy(16.8f))
                path.lineTo(sx(9.5f), sy(6.4f))
                path.lineTo(sx(19.0f), sy(4.6f))
                path.lineTo(sx(19.0f), sy(15.0f))
                canvas.drawPath(path, iconStrokePaint)
                canvas.drawCircle(sx(7.3f), sy(17.2f), 2.5f * u, iconFillPaint)
                canvas.drawCircle(sx(16.8f), sy(15.4f), 2.5f * u, iconFillPaint)
            }

            IconType.WAVEFORM -> {
                // Apple SF waveform — 5 symmetric vertical bars
                iconStrokePaint.strokeWidth = 2.1f * u
                canvas.drawLine(sx(4.0f), sy(10.0f), sx(4.0f), sy(14.0f), iconStrokePaint)
                canvas.drawLine(sx(8.0f), sy(6.5f), sx(8.0f), sy(17.5f), iconStrokePaint)
                canvas.drawLine(sx(12.0f), sy(3.8f), sx(12.0f), sy(20.2f), iconStrokePaint)
                canvas.drawLine(sx(16.0f), sy(7.2f), sx(16.0f), sy(16.8f), iconStrokePaint)
                canvas.drawLine(sx(20.0f), sy(9.5f), sx(20.0f), sy(14.5f), iconStrokePaint)
            }

            IconType.PIP_ENTER -> {
                // Apple SF pip.enter — outer screen frame + filled bottom-right PiP window
                iconStrokePaint.strokeWidth = 1.9f * u
                val r = 2.4f * u
                canvas.drawRoundRect(RectF(sx(3.0f), sy(4.8f), sx(21.0f), sy(19.2f)), r, r, iconStrokePaint)
                val pipR = 1.4f * u
                canvas.drawRoundRect(RectF(sx(12.2f), sy(11.6f), sx(19.0f), sy(17.2f)), pipR, pipR, iconFillPaint)
                // Diagonal arrow pointing into PiP
                path.moveTo(sx(6.4f), sy(7.8f))
                path.lineTo(sx(10.6f), sy(11.2f))
                path.moveTo(sx(10.6f), sy(8.4f))
                path.lineTo(sx(10.6f), sy(11.2f))
                path.lineTo(sx(7.8f), sy(11.2f))
                canvas.drawPath(path, iconStrokePaint)
            }

            IconType.ARROW_EXPAND -> {
                // Apple SF arrow.up.left.and.arrow.down.right
                iconStrokePaint.strokeWidth = 2.0f * u
                // Top-right expand arrow
                path.moveTo(sx(14.2f), sy(4.8f))
                path.lineTo(sx(19.2f), sy(4.8f))
                path.lineTo(sx(19.2f), sy(9.8f))
                path.moveTo(sx(19.0f), sy(5.0f))
                path.lineTo(sx(13.2f), sy(10.8f))
                // Bottom-left expand arrow
                path.moveTo(sx(9.8f), sy(19.2f))
                path.lineTo(sx(4.8f), sy(19.2f))
                path.lineTo(sx(4.8f), sy(14.2f))
                path.moveTo(sx(5.0f), sy(19.0f))
                path.lineTo(sx(10.8f), sy(13.2f))
                canvas.drawPath(path, iconStrokePaint)
            }

            IconType.REPEAT -> {
                // Apple SF repeat — dual loop tracks with arrowheads
                iconStrokePaint.strokeWidth = 1.95f * u
                // Top loop
                path.moveTo(sx(17.0f), sy(4.5f))
                path.lineTo(sx(19.8f), sy(7.2f))
                path.lineTo(sx(17.0f), sy(9.9f))
                path.moveTo(sx(4.5f), sy(11.2f))
                path.lineTo(sx(4.5f), sy(8.8f))
                path.quadTo(sx(4.5f), sy(7.2f), sx(6.5f), sy(7.2f))
                path.lineTo(sx(19.4f), sy(7.2f))
                // Bottom loop
                path.moveTo(sx(7.0f), sy(19.5f))
                path.lineTo(sx(4.2f), sy(16.8f))
                path.lineTo(sx(7.0f), sy(14.1f))
                path.moveTo(sx(19.5f), sy(12.8f))
                path.lineTo(sx(19.5f), sy(15.2f))
                path.quadTo(sx(19.5f), sy(16.8f), sx(17.5f), sy(16.8f))
                path.lineTo(sx(4.6f), sy(16.8f))
                canvas.drawPath(path, iconStrokePaint)
            }

            IconType.SPEAKER_WAVE -> {
                // Apple SF speaker.wave.2.fill
                path.moveTo(sx(3.8f), sy(9.5f))
                path.lineTo(sx(7.2f), sy(9.5f))
                path.lineTo(sx(11.6f), sy(5.6f))
                path.lineTo(sx(11.6f), sy(18.4f))
                path.lineTo(sx(7.2f), sy(14.5f))
                path.lineTo(sx(3.8f), sy(14.5f))
                path.close()
                canvas.drawPath(path, iconFillPaint)

                iconStrokePaint.strokeWidth = 1.95f * u
                val wave1 = RectF(sx(11.2f), sy(8.4f), sx(16.4f), sy(15.6f))
                canvas.drawArc(wave1, -48f, 96f, false, iconStrokePaint)
                val wave2 = RectF(sx(13.0f), sy(5.6f), sx(20.4f), sy(18.4f))
                canvas.drawArc(wave2, -52f, 104f, false, iconStrokePaint)
            }

            IconType.SPEAKER_SLASH -> {
                // Apple SF speaker.slash.fill
                path.moveTo(sx(3.8f), sy(9.5f))
                path.lineTo(sx(7.2f), sy(9.5f))
                path.lineTo(sx(11.6f), sy(5.6f))
                path.lineTo(sx(11.6f), sy(18.4f))
                path.lineTo(sx(7.2f), sy(14.5f))
                path.lineTo(sx(3.8f), sy(14.5f))
                path.close()
                canvas.drawPath(path, iconFillPaint)

                iconStrokePaint.strokeWidth = 2.0f * u
                canvas.drawLine(sx(15.0f), sy(9.0f), sx(20.2f), sy(15.0f), iconStrokePaint)
                canvas.drawLine(sx(20.2f), sy(9.0f), sx(15.0f), sy(15.0f), iconStrokePaint)
            }

            IconType.LIST_BULLET -> {
                // Apple SF list.bullet
                iconStrokePaint.strokeWidth = 2.0f * u
                val rows = floatArrayOf(6.8f, 12.0f, 17.2f)
                for (ry in rows) {
                    canvas.drawCircle(sx(5.2f), sy(ry), 1.35f * u, iconFillPaint)
                    canvas.drawLine(sx(9.2f), sy(ry), sx(19.6f), sy(ry), iconStrokePaint)
                }
            }

            IconType.RESIZE_PANE -> {
                // Apple SF sidebar.left / rectangle.split.2x1
                iconStrokePaint.strokeWidth = 1.9f * u
                val r = 2.4f * u
                canvas.drawRoundRect(RectF(sx(3.2f), sy(4.8f), sx(20.8f), sy(19.2f)), r, r, iconStrokePaint)
                canvas.drawLine(sx(9.8f), sy(5.2f), sx(9.8f), sy(18.8f), iconStrokePaint)
            }

            IconType.OPACITY_DROP -> {
                // Apple SF circle.lefthalf.filled
                iconStrokePaint.strokeWidth = 1.9f * u
                val rect = RectF(sx(4.2f), sy(4.2f), sx(19.8f), sy(19.8f))
                canvas.drawOval(rect, iconStrokePaint)
                canvas.drawArc(rect, 90f, 180f, true, iconFillPaint)
            }

            IconType.MINUS -> {
                // Apple SF minus
                iconStrokePaint.strokeWidth = 2.4f * u
                canvas.drawLine(sx(5.5f), sy(12.0f), sx(18.5f), sy(12.0f), iconStrokePaint)
            }

            IconType.XMARK -> {
                // Apple SF xmark
                iconStrokePaint.strokeWidth = 2.2f * u
                canvas.drawLine(sx(6.4f), sy(6.4f), sx(17.6f), sy(17.6f), iconStrokePaint)
                canvas.drawLine(sx(17.6f), sy(6.4f), sx(6.4f), sy(17.6f), iconStrokePaint)
            }

            IconType.MAP_GRID -> {
                // Apple SF square.grid.2x2
                val r = 1.4f * u
                iconStrokePaint.strokeWidth = 1.8f * u
                canvas.drawRoundRect(RectF(sx(4.0f), sy(4.0f), sx(10.6f), sy(10.6f)), r, r, iconStrokePaint)
                canvas.drawRoundRect(RectF(sx(13.4f), sy(4.0f), sx(20.0f), sy(10.6f)), r, r, iconStrokePaint)
                canvas.drawRoundRect(RectF(sx(4.0f), sy(13.4f), sx(10.6f), sy(20.0f)), r, r, iconStrokePaint)
                canvas.drawRoundRect(RectF(sx(13.4f), sy(13.4f), sx(20.0f), sy(20.0f)), r, r, iconStrokePaint)
            }

            IconType.DIAGRAM_FLOW -> {
                // Apple SF arrow.triangle.branch / hierarchy flowchart nodes
                iconStrokePaint.strokeWidth = 1.85f * u
                val r = 1.6f * u
                // Top root node
                canvas.drawRoundRect(RectF(sx(8.2f), sy(3.4f), sx(15.8f), sy(8.2f)), r, r, iconStrokePaint)
                // Two child nodes
                canvas.drawRoundRect(RectF(sx(3.0f), sy(15.6f), sx(10.2f), sy(20.6f)), r, r, iconStrokePaint)
                canvas.drawRoundRect(RectF(sx(13.8f), sy(15.6f), sx(21.0f), sy(20.6f)), r, r, iconStrokePaint)
                // Connecting stem + fork
                path.moveTo(sx(12.0f), sy(8.2f))
                path.lineTo(sx(12.0f), sy(11.8f))
                path.moveTo(sx(6.6f), sy(15.6f))
                path.lineTo(sx(6.6f), sy(11.8f))
                path.lineTo(sx(17.4f), sy(11.8f))
                path.lineTo(sx(17.4f), sy(15.6f))
                canvas.drawPath(path, iconStrokePaint)
            }

            IconType.DIAGRAM_SEQUENCE -> {
                // Two vertical lifelines + bidirectional horizontal sequence arrows
                iconStrokePaint.strokeWidth = 1.75f * u
                canvas.drawCircle(sx(6.2f), sy(5.0f), 1.8f * u, iconFillPaint)
                canvas.drawCircle(sx(17.8f), sy(5.0f), 1.8f * u, iconFillPaint)
                canvas.drawLine(sx(6.2f), sy(7.4f), sx(6.2f), sy(20.4f), iconStrokePaint)
                canvas.drawLine(sx(17.8f), sy(7.4f), sx(17.8f), sy(20.4f), iconStrokePaint)
                // Forward message arrow
                path.moveTo(sx(8.0f), sy(11.0f))
                path.lineTo(sx(15.8f), sy(11.0f))
                path.moveTo(sx(13.8f), sy(9.2f))
                path.lineTo(sx(15.8f), sy(11.0f))
                path.lineTo(sx(13.8f), sy(12.8f))
                // Return message arrow
                path.moveTo(sx(16.0f), sy(16.8f))
                path.lineTo(sx(8.2f), sy(16.8f))
                path.moveTo(sx(10.2f), sy(15.0f))
                path.lineTo(sx(8.2f), sy(16.8f))
                path.lineTo(sx(10.2f), sy(18.6f))
                canvas.drawPath(path, iconStrokePaint)
            }

            IconType.CHART_BAR -> {
                // Apple SF chart.bar.fill
                val r = 1.4f * u
                canvas.drawRoundRect(RectF(sx(3.8f), sy(12.4f), sx(8.0f), sy(20.0f)), r, r, iconFillPaint)
                canvas.drawRoundRect(RectF(sx(9.9f), sy(4.6f), sx(14.1f), sy(20.0f)), r, r, iconFillPaint)
                canvas.drawRoundRect(RectF(sx(16.0f), sy(8.8f), sx(20.2f), sy(20.0f)), r, r, iconFillPaint)
            }

            IconType.ZOOM_IN -> {
                // Apple SF plus.magnifyingglass
                iconStrokePaint.strokeWidth = 1.9f * u
                canvas.drawCircle(sx(10.4f), sy(10.4f), 6.2f * u, iconStrokePaint)
                canvas.drawLine(sx(15.0f), sy(15.0f), sx(20.4f), sy(20.4f), iconStrokePaint)
                canvas.drawLine(sx(10.4f), sy(7.7f), sx(10.4f), sy(13.1f), iconStrokePaint)
                canvas.drawLine(sx(7.7f), sy(10.4f), sx(13.1f), sy(10.4f), iconStrokePaint)
            }

            IconType.ZOOM_OUT -> {
                // Apple SF minus.magnifyingglass
                iconStrokePaint.strokeWidth = 1.9f * u
                canvas.drawCircle(sx(10.4f), sy(10.4f), 6.2f * u, iconStrokePaint)
                canvas.drawLine(sx(15.0f), sy(15.0f), sx(20.4f), sy(20.4f), iconStrokePaint)
                canvas.drawLine(sx(7.7f), sy(10.4f), sx(13.1f), sy(10.4f), iconStrokePaint)
            }

            IconType.FIT_RESET -> {
                // Apple SF viewfinder / 4-corner fit-to-canvas brackets + center dot
                iconStrokePaint.strokeWidth = 1.85f * u
                // Top-left corner
                path.moveTo(sx(4.0f), sy(8.2f))
                path.lineTo(sx(4.0f), sy(4.0f))
                path.lineTo(sx(8.2f), sy(4.0f))
                // Top-right corner
                path.moveTo(sx(15.8f), sy(4.0f))
                path.lineTo(sx(20.0f), sy(4.0f))
                path.lineTo(sx(20.0f), sy(8.2f))
                // Bottom-right corner
                path.moveTo(sx(20.0f), sy(15.8f))
                path.lineTo(sx(20.0f), sy(20.0f))
                path.lineTo(sx(15.8f), sy(20.0f))
                // Bottom-left corner
                path.moveTo(sx(8.2f), sy(20.0f))
                path.lineTo(sx(4.0f), sy(20.0f))
                path.lineTo(sx(4.0f), sy(15.8f))
                canvas.drawPath(path, iconStrokePaint)
                canvas.drawCircle(sx(12.0f), sy(12.0f), 1.9f * u, iconFillPaint)
            }

            IconType.PHOTO_STACK -> {
                // Apple SF photo
                iconStrokePaint.strokeWidth = 1.85f * u
                val r = 2.4f * u
                canvas.drawRoundRect(RectF(sx(3.2f), sy(4.8f), sx(20.8f), sy(19.2f)), r, r, iconStrokePaint)
                canvas.drawCircle(sx(8.2f), sy(9.2f), 1.5f * u, iconFillPaint)
                path.moveTo(sx(4.4f), sy(17.8f))
                path.lineTo(sx(9.8f), sy(12.2f))
                path.lineTo(sx(13.4f), sy(15.6f))
                path.lineTo(sx(16.2f), sy(12.8f))
                path.lineTo(sx(19.8f), sy(17.8f))
                canvas.drawPath(path, iconStrokePaint)
            }

            IconType.CHEVRON_LEFT -> {
                // Apple SF chevron.left
                iconStrokePaint.strokeWidth = 2.3f * u
                path.moveTo(sx(15.0f), sy(5.4f))
                path.lineTo(sx(8.4f), sy(12.0f))
                path.lineTo(sx(15.0f), sy(18.6f))
                canvas.drawPath(path, iconStrokePaint)
            }

            IconType.CHEVRON_RIGHT -> {
                // Apple SF chevron.right
                iconStrokePaint.strokeWidth = 2.3f * u
                path.moveTo(sx(9.0f), sy(5.4f))
                path.lineTo(sx(15.6f), sy(12.0f))
                path.lineTo(sx(9.0f), sy(18.6f))
                canvas.drawPath(path, iconStrokePaint)
            }

            IconType.CHEVRON_UP -> {
                iconStrokePaint.strokeWidth = 2.3f * u
                path.moveTo(sx(5.4f), sy(14.8f))
                path.lineTo(sx(12.0f), sy(8.4f))
                path.lineTo(sx(18.6f), sy(14.8f))
                canvas.drawPath(path, iconStrokePaint)
            }

            IconType.CHEVRON_DOWN -> {
                iconStrokePaint.strokeWidth = 2.3f * u
                path.moveTo(sx(5.4f), sy(9.2f))
                path.lineTo(sx(12.0f), sy(15.6f))
                path.lineTo(sx(18.6f), sy(9.2f))
                canvas.drawPath(path, iconStrokePaint)
            }

            IconType.ELLIPSIS -> {
                // Apple SF ellipsis — 3 crisp balanced dots
                val r = 1.65f * u
                canvas.drawCircle(sx(5.5f), sy(12.0f), r, iconFillPaint)
                canvas.drawCircle(sx(12.0f), sy(12.0f), r, iconFillPaint)
                canvas.drawCircle(sx(18.5f), sy(12.0f), r, iconFillPaint)
            }

            IconType.SPARKLES -> {
                // 4-point AI star + tiny accent star
                path.moveTo(sx(11.0f), sy(3.2f))
                path.quadTo(sx(11.4f), sy(10.6f), sx(18.8f), sy(11.0f))
                path.quadTo(sx(11.4f), sy(11.4f), sx(11.0f), sy(18.8f))
                path.quadTo(sx(10.6f), sy(11.4f), sx(3.2f), sy(11.0f))
                path.quadTo(sx(10.6f), sy(10.6f), sx(11.0f), sy(3.2f))
                path.close()
                canvas.drawPath(path, iconFillPaint)

                path.reset()
                path.moveTo(sx(18.4f), sy(15.0f))
                path.quadTo(sx(18.6f), sy(18.0f), sx(21.4f), sy(18.2f))
                path.quadTo(sx(18.6f), sy(18.4f), sx(18.4f), sy(21.2f))
                path.quadTo(sx(18.2f), sy(18.4f), sx(15.4f), sy(18.2f))
                path.quadTo(sx(18.2f), sy(18.0f), sx(18.4f), sy(15.0f))
                path.close()
                canvas.drawPath(path, iconFillPaint)
            }

            IconType.SCISSORS -> {
                // Apple SF scissors — crisp dual loops + crossing blades
                iconStrokePaint.strokeWidth = 1.85f * u
                canvas.drawCircle(sx(6.6f), sy(7.4f), 2.5f * u, iconStrokePaint)
                canvas.drawCircle(sx(6.6f), sy(16.6f), 2.5f * u, iconStrokePaint)
                canvas.drawLine(sx(8.8f), sy(8.8f), sx(19.6f), sy(17.8f), iconStrokePaint)
                canvas.drawLine(sx(8.8f), sy(15.2f), sx(19.6f), sy(6.2f), iconStrokePaint)
            }

            IconType.STOP_SQUARE -> {
                val r = 2.2f * u
                canvas.drawRoundRect(RectF(sx(5.6f), sy(5.6f), sx(18.4f), sy(18.4f)), r, r, iconFillPaint)
            }
        }
    }

    private fun blendColor(base: Int, overlay: Int, ratio: Float): Int {
        val r = (Color.red(base) * (1f - ratio) + Color.red(overlay) * ratio).toInt().coerceIn(0, 255)
        val g = (Color.green(base) * (1f - ratio) + Color.green(overlay) * ratio).toInt().coerceIn(0, 255)
        val b = (Color.blue(base) * (1f - ratio) + Color.blue(overlay) * ratio).toInt().coerceIn(0, 255)
        return Color.argb(Color.alpha(base), r, g, b)
    }
}
