package com.kavach.ui.overlay

import com.kavach.ui.overlay.hud.HudModels

/**
 * Pure app-aware contextual quick action resolver for the Single-Window HUD v2.
 */
object AgySmartSuggestionsResolver {

    fun resolve(
        appPackage: String?,
        explicitSuggestions: List<HudModels.QuickAction> = emptyList(),
        maxItems: Int = 3
    ): List<HudModels.QuickAction> {
        if (explicitSuggestions.isNotEmpty()) {
            return explicitSuggestions.take(maxItems.coerceIn(1, 5))
        }
        val pkg = appPackage?.lowercase()?.trim().orEmpty()
        val chips = when {
            pkg.contains("youtube") || pkg.contains("revanced") || pkg.contains("newpipe") -> listOf(
                HudModels.QuickAction("yt_summarize", "Summarize video", "Summarize the current YouTube video and key takeaways", "PROMPT", "youtube", pkg),
                HudModels.QuickAction("yt_skip_ad", "Skip ad / Play", "Skip any ad on YouTube and ensure playback is running", "PROMPT", "youtube", pkg),
                HudModels.QuickAction("yt_chapters", "Key moments", "Inspect the current YouTube video chapters and jump to the main section", "PROMPT", "youtube", pkg)
            )
            pkg.contains("chrome") || pkg.contains("firefox") || pkg.contains("brave") ||
                pkg.contains("edge") || pkg.contains("opera") || pkg.contains("browser") -> listOf(
                HudModels.QuickAction("web_tldr", "TL;DR page", "Read the active browser page and give me a concise TL;DR summary", "PROMPT", "chrome", pkg),
                HudModels.QuickAction("web_extract", "Key facts", "Extract the key facts, links, and numbers from the visible webpage", "PROMPT", "chrome", pkg),
                HudModels.QuickAction("web_translate", "Explain simply", "Explain what is on this browser screen in simple terms", "PROMPT", "chrome", pkg)
            )
            pkg.contains("whatsapp") || pkg.contains("telegram") || pkg.contains("messaging") ||
                pkg.contains("mms") || pkg.contains("discord") || pkg.contains("slack") -> listOf(
                HudModels.QuickAction("chat_reply", "Draft reply", "Read the latest chat messages and draft a helpful reply without sending it yet", "PROMPT", "chat", pkg),
                HudModels.QuickAction("chat_summarize", "Summarize chat", "Summarize the visible conversation thread and any action items", "PROMPT", "chat", pkg),
                HudModels.QuickAction("chat_unread", "Dates & tasks", "Pull out any dates, names, or tasks mentioned in this chat", "PROMPT", "chat", pkg)
            )
            pkg.contains("settings") -> listOf(
                HudModels.QuickAction("set_explain", "Explain setting", "Explain the settings currently shown on screen and recommended values", "PROMPT", "settings", pkg),
                HudModels.QuickAction("set_battery", "Battery tips", "Check how to optimize battery and background usage for this screen", "PROMPT", "settings", pkg),
                HudModels.QuickAction("set_wifi", "Check network", "Check my current network and connectivity status", "PROMPT", "settings", pkg)
            )
            pkg.contains("chess") || pkg.contains("lichess") -> listOf(
                HudModels.QuickAction("chess_best", "Best Move", "chess suggest", "PROMPT", "chess", pkg),
                HudModels.QuickAction("chess_auto", "Auto Play", "chess autopilot play", "PROMPT", "chess", pkg),
                HudModels.QuickAction("chess_one", "Play 1 Move", "chess play one move", "PROMPT", "chess", pkg)
            )
            pkg.contains("termux") -> listOf(
                HudModels.QuickAction("term_error", "Explain output", "Inspect the current Termux output and explain any errors or next steps", "PROMPT", "termux", pkg),
                HudModels.QuickAction("term_status", "System status", "Check running background processes, battery, and memory status", "PROMPT", "termux", pkg),
                HudModels.QuickAction("term_git", "Git summary", "Summarize current git status and recent changes in the active workspace", "PROMPT", "termux", pkg)
            )
            else -> listOf(
                HudModels.QuickAction("gen_screen", "Explain screen", "Inspect what is currently on my screen and summarize it", "PROMPT", "spark_ai", pkg),
                HudModels.QuickAction("gen_guide", "Guide me", "Look at this screen and guide me step-by-step", "PROMPT", "spark_ai", pkg),
                HudModels.QuickAction("gen_status", "Device status", "Give me a quick overview of battery, network, and active apps", "PROMPT", "spark_ai", pkg)
            )
        }
        return chips.take(maxItems.coerceIn(1, 5))
    }

    fun shortAppLabel(appPackage: String?): String {
        val pkg = appPackage?.lowercase()?.trim().orEmpty()
        return when {
            pkg.isEmpty() -> ""
            pkg.contains("youtube") -> "YouTube"
            pkg.contains("chrome") -> "Chrome"
            pkg.contains("firefox") -> "Firefox"
            pkg.contains("brave") -> "Brave"
            pkg.contains("whatsapp") -> "WhatsApp"
            pkg.contains("telegram") -> "Telegram"
            pkg.contains("settings") -> "Settings"
            pkg.contains("chess") || pkg.contains("lichess") -> "Chess"
            pkg.contains("termux") -> "Termux"
            pkg.contains("instagram") -> "Instagram"
            pkg.contains("gmail") -> "Gmail"
            pkg.contains("discord") -> "Discord"
            else -> pkg.substringAfterLast('.').replaceFirstChar { it.uppercase() }.take(14)
        }
    }
}
