package com.kavach.ui.overlay

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PathMeasure
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.view.animation.LinearInterpolator
import android.view.animation.OvershootInterpolator
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/**
 * Living multi-layered Canvas status orb for the Apple Liquid Glass HUD.
 *
 * Renders:
 * - Soft breathing radial core + outer halo in IDLE / DONE / PAUSED states
 * - Orbiting dual-arc comet + expanding concentric sonar ripple ring in WORKING / VOICE / STOPPING
 * - Warm rhythmic attention pulse in NEEDS_INPUT
 */
class AgyStatusOrbView(context: Context) : View(context) {

    private val d = context.resources.displayMetrics.density.coerceAtLeast(1f)
    private var stateName: String = "IDLE"
    private var accentColor: Int = Color.parseColor("#818CF8")
    private var animating: Boolean = false
    private var phase: Float = 0f
    private var animator: ValueAnimator? = null

    private val haloPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val ripplePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1.4f * d
    }
    private val corePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val specPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.argb(175, 255, 255, 255)
    }
    private val orbitPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeWidth = 1.75f * d
    }
    private val arcRect = RectF()

    fun isAnimating(): Boolean = animating
    fun currentStateName(): String = stateName

    fun setOrbState(state: String, color: Int, active: Boolean) {
        val nextState = state.uppercase().ifBlank { "IDLE" }
        val changed = stateName != nextState || accentColor != color || animating != active
        stateName = nextState
        accentColor = color
        animating = active
        if (active) {
            startAnimatorIfNeeded(forceRestart = changed && animator != null)
        } else {
            stopAnimator()
        }
        invalidate()
    }

    private fun durationForState(): Long = when (stateName) {
        "STOPPING" -> 950L
        "WORKING", "VOICE", "VOICE_LISTENING" -> 1350L
        "NEEDS_INPUT" -> 1500L
        "PAUSED" -> 2400L
        "DONE" -> 2200L
        else -> 2800L
    }

    private fun startAnimatorIfNeeded(forceRestart: Boolean = false) {
        if (!animating) return
        if (animator != null && !forceRestart) return
        stopAnimator()
        animator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = durationForState()
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener { anim ->
                phase = anim.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    private fun stopAnimator() {
        animator?.cancel()
        animator = null
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (animating && animator == null) {
            startAnimatorIfNeeded()
        }
    }

    override fun onDetachedFromWindow() {
        stopAnimator()
        super.onDetachedFromWindow()
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val sz = (18 * d).toInt()
        setMeasuredDimension(resolveSize(sz, widthMeasureSpec), resolveSize(sz, heightMeasureSpec))
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        val cx = w * 0.5f
        val cy = h * 0.5f
        val maxR = min(w, h) * 0.46f
        val breath = 0.5f + 0.5f * sin(phase * 2.0 * PI).toFloat()
        val rCol = Color.red(accentColor)
        val gCol = Color.green(accentColor)
        val bCol = Color.blue(accentColor)

        // 1. Soft radial glow halo
        val haloR = maxR * (0.82f + 0.18f * breath)
        haloPaint.shader = RadialGradient(
            cx, cy, haloR.coerceAtLeast(1f),
            intArrayOf(
                Color.argb((88 + 56 * breath).toInt().coerceIn(0, 160), rCol, gCol, bCol),
                Color.argb(0, rCol, gCol, bCol)
            ),
            null,
            Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, haloR, haloPaint)

        // 2. Sonar ripple / orbiting comet for live active states
        val isLive = stateName == "WORKING" || stateName == "VOICE" ||
            stateName == "VOICE_LISTENING" || stateName == "NEEDS_INPUT" || stateName == "STOPPING"
        if (isLive) {
            val rippleProgress = phase
            val rippleR = maxR * (0.48f + 0.50f * rippleProgress)
            val rippleAlpha = ((1f - rippleProgress) * 185f).toInt().coerceIn(0, 185)
            ripplePaint.color = Color.argb(rippleAlpha, rCol, gCol, bCol)
            canvas.drawCircle(cx, cy, rippleR, ripplePaint)

            if (stateName == "WORKING" || stateName == "VOICE" || stateName == "VOICE_LISTENING") {
                val orbitR = maxR * 0.72f
                arcRect.set(cx - orbitR, cy - orbitR, cx + orbitR, cy + orbitR)
                val sweepStart = phase * 360f
                orbitPaint.color = Color.argb(220, rCol, gCol, bCol)
                canvas.drawArc(arcRect, sweepStart, 115f, false, orbitPaint)
                orbitPaint.color = Color.argb(120, 255, 255, 255)
                canvas.drawArc(arcRect, sweepStart + 180f, 65f, false, orbitPaint)
            }
        } else if (stateName == "DONE") {
            val ringR = maxR * (0.68f + 0.14f * breath)
            ripplePaint.color = Color.argb((110 * (1f - 0.35f * breath)).toInt(), rCol, gCol, bCol)
            canvas.drawCircle(cx, cy, ringR, ripplePaint)
        }

        // 3. Inner luminous core + glass specular glint
        val coreR = maxR * (if (isLive) (0.36f + 0.08f * breath) else (0.38f + 0.06f * breath))
        corePaint.color = accentColor
        canvas.drawCircle(cx, cy, coreR, corePaint)

        val glintR = (coreR * 0.34f).coerceAtLeast(1f)
        canvas.drawCircle(cx - coreR * 0.30f, cy - coreR * 0.30f, glintR, specPaint)
    }
}

/**
 * Multi-bar live Canvas equalizer / activity waveform for Dynamic Island pill & voice mode.
 */
class AgyWaveformBarsView @JvmOverloads constructor(
    context: Context,
    private val barCount: Int = 4
) : View(context) {

    private val d = context.resources.displayMetrics.density.coerceAtLeast(1f)
    private var phase: Float = 0f
    private var animating: Boolean = false
    private var primaryColor: Int = Color.parseColor("#38BDF8")
    private var secondaryColor: Int = Color.parseColor("#818CF8")
    private var animator: ValueAnimator? = null

    private val barPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val barRect = RectF()

    fun isAnimating(): Boolean = animating

    fun setColors(primary: Int, secondary: Int = primary) {
        primaryColor = primary
        secondaryColor = secondary
        invalidate()
    }

    fun setAnimating(active: Boolean) {
        if (animating == active) return
        animating = active
        if (active) {
            startAnimator()
        } else {
            stopAnimator()
            invalidate()
        }
    }

    private fun startAnimator() {
        stopAnimator()
        animator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 920L
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener { anim ->
                phase = anim.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    private fun stopAnimator() {
        animator?.cancel()
        animator = null
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (animating && animator == null) {
            startAnimator()
        }
    }

    override fun onDetachedFromWindow() {
        stopAnimator()
        super.onDetachedFromWindow()
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val count = barCount.coerceIn(3, 8)
        val desiredW = ((count * 4.5f + 2f) * d).toInt()
        val desiredH = (14 * d).toInt()
        setMeasuredDimension(resolveSize(desiredW, widthMeasureSpec), resolveSize(desiredH, heightMeasureSpec))
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        val count = barCount.coerceIn(3, 8)
        val barW = (2.3f * d).coerceAtLeast(2f)
        val gap = if (count > 1) ((w - count * barW) / (count - 1)).coerceIn(1.5f * d, 4f * d) else 0f
        val totalW = count * barW + (count - 1) * gap
        val startX = (w - totalW) * 0.5f
        val minH = h * 0.28f
        val maxH = h * 0.90f

        barPaint.shader = LinearGradient(
            0f, 0f, w, h,
            primaryColor, secondaryColor,
            Shader.TileMode.CLAMP
        )

        for (i in 0 until count) {
            val norm = if (animating) {
                val theta = (phase * 2.0 * PI) + (i * 0.95)
                val harmonic = 0.5f + 0.5f * sin(theta).toFloat()
                val mod = 0.72f + 0.28f * cos(phase * 4.0 * PI + i * 1.4).toFloat()
                (harmonic * mod).coerceIn(0.08f, 1f)
            } else {
                0.24f
            }
            val barH = minH + (maxH - minH) * norm
            val left = startX + i * (barW + gap)
            val top = (h - barH) * 0.5f
            barRect.set(left, top, left + barW, top + barH)
            barPaint.alpha = if (animating) (185 + (70 * norm).toInt()).coerceIn(185, 255) else 130
            canvas.drawRoundRect(barRect, barW * 0.5f, barW * 0.5f, barPaint)
        }
        barPaint.alpha = 255
    }
}

/**
 * Progressive PathMeasure stroke-drawn checkmark & status badge for HUD task rows.
 */
class AgyAnimatedCheckView(context: Context) : View(context) {

    private val d = context.resources.displayMetrics.density.coerceAtLeast(1f)
    private var status: String = "pending"
    private var accentColor: Int = Color.parseColor("#22C55E")
    private var drawFraction: Float = 1f
    private var popScale: Float = 1f
    private var checkAnimator: ValueAnimator? = null
    private var popAnimator: ValueAnimator? = null

    private val circleFillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val circleStrokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1.4f * d
    }
    private val glyphPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        strokeWidth = 1.85f * d
    }

    private val checkPath = Path()
    private val partialPath = Path()
    private val pathMeasure = PathMeasure()

    fun isCheckAnimating(): Boolean = checkAnimator?.isRunning == true

    fun setStatus(nextStatus: String, color: Int, animateCheck: Boolean) {
        val normalized = nextStatus.lowercase().ifBlank { "pending" }
        status = normalized
        accentColor = color
        if (normalized == "done" && animateCheck) {
            playCheckAnimation()
        } else {
            cancelAnimators()
            drawFraction = 1f
            popScale = 1f
            invalidate()
        }
    }

    fun playCheckAnimation() {
        cancelAnimators()
        drawFraction = 0f
        popScale = 0.65f
        checkAnimator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 280L
            interpolator = DecelerateInterpolator()
            addUpdateListener { anim ->
                drawFraction = anim.animatedValue as Float
                invalidate()
            }
            start()
        }
        popAnimator = ValueAnimator.ofFloat(0.65f, 1f).apply {
            duration = 320L
            interpolator = OvershootInterpolator(1.9f)
            addUpdateListener { anim ->
                popScale = anim.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    private fun cancelAnimators() {
        checkAnimator?.cancel()
        checkAnimator = null
        popAnimator?.cancel()
        popAnimator = null
    }

    override fun onDetachedFromWindow() {
        cancelAnimators()
        super.onDetachedFromWindow()
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val sz = (18 * d).toInt()
        setMeasuredDimension(resolveSize(sz, widthMeasureSpec), resolveSize(sz, heightMeasureSpec))
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        val cx = w * 0.5f
        val cy = h * 0.5f
        val r = (min(w, h) * 0.42f) * popScale
        val rCol = Color.red(accentColor)
        val gCol = Color.green(accentColor)
        val bCol = Color.blue(accentColor)

        when (status) {
            "done" -> {
                circleFillPaint.color = Color.argb(38, rCol, gCol, bCol)
                circleStrokePaint.color = Color.argb(170, rCol, gCol, bCol)
                canvas.drawCircle(cx, cy, r, circleFillPaint)
                canvas.drawCircle(cx, cy, r, circleStrokePaint)

                checkPath.reset()
                checkPath.moveTo(cx - r * 0.44f, cy + r * 0.04f)
                checkPath.lineTo(cx - r * 0.12f, cy + r * 0.36f)
                checkPath.lineTo(cx + r * 0.48f, cy - r * 0.34f)
                pathMeasure.setPath(checkPath, false)
                partialPath.reset()
                pathMeasure.getSegment(0f, pathMeasure.length * drawFraction.coerceIn(0f, 1f), partialPath, true)
                glyphPaint.color = accentColor
                canvas.drawPath(partialPath, glyphPaint)
            }
            "needs_input" -> {
                circleFillPaint.color = Color.argb(36, rCol, gCol, bCol)
                circleStrokePaint.color = accentColor
                canvas.drawCircle(cx, cy, r, circleFillPaint)
                canvas.drawCircle(cx, cy, r, circleStrokePaint)
                // Clean '?' glyph stroke
                glyphPaint.color = accentColor
                val qRect = RectF(cx - r * 0.28f, cy - r * 0.42f, cx + r * 0.28f, cy + r * 0.02f)
                canvas.drawArc(qRect, -170f, 235f, false, glyphPaint)
                canvas.drawLine(cx, cy + r * 0.04f, cx, cy + r * 0.22f, glyphPaint)
                circleFillPaint.color = accentColor
                canvas.drawCircle(cx, cy + r * 0.46f, (1.1f * d), circleFillPaint)
            }
            "stopped", "error", "failed" -> {
                circleFillPaint.color = Color.argb(36, rCol, gCol, bCol)
                circleStrokePaint.color = accentColor
                canvas.drawCircle(cx, cy, r, circleFillPaint)
                canvas.drawCircle(cx, cy, r, circleStrokePaint)
                glyphPaint.color = accentColor
                val arm = r * 0.34f
                canvas.drawLine(cx - arm, cy - arm, cx + arm, cy + arm, glyphPaint)
                canvas.drawLine(cx + arm, cy - arm, cx - arm, cy + arm, glyphPaint)
            }
            else -> {
                circleStrokePaint.color = Color.argb(120, rCol, gCol, bCol)
                canvas.drawCircle(cx, cy, r * 0.78f, circleStrokePaint)
            }
        }
    }
}
