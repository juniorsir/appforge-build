package com.kavach.security

import android.content.Context
import android.os.Build
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.concurrent.ConcurrentHashMap
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

/**
 * Data class representing a registered / paired client device.
 */
data class PairedClient(
    val deviceId: String,
    val clientName: String,
    val clientToken: String,
    val clientIp: String,
    val pairedAt: Long,
    var lastSeenAt: Long = System.currentTimeMillis(),
    var isRevoked: Boolean = false
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("deviceId", deviceId)
        put("clientName", clientName)
        put("clientTokenPrefix", clientToken.take(12) + "...")
        put("clientIp", clientIp)
        put("pairedAt", pairedAt)
        put("lastSeenAt", lastSeenAt)
        put("isRevoked", isRevoked)
    }
}

/**
 * Data class representing an interactive 1-tap approval pairing request from a remote client.
 */
data class PendingPairRequest(
    val requestId: String,
    val clientName: String,
    val clientIp: String,
    val deviceId: String,
    val requestedAt: Long = System.currentTimeMillis(),
    var status: String = "PENDING", // PENDING, APPROVED, DENIED
    var clientToken: String? = null,
    var deliveredAt: Long? = null
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("requestId", requestId)
        put("clientName", clientName)
        put("clientIp", clientIp)
        put("deviceId", deviceId)
        put("requestedAt", requestedAt)
        put("status", status)
        if (clientToken != null) {
            put("clientToken", clientToken)
        }
    }
}

/**
 * High-Security, Zero-Friction Defense Shield for Aura HTTP REST API, WebSocket Automation Bridge, & AeroShare.
 *
 * Capabilities:
 * - 1-Tap Biometric / Notification Approval: Pair remote devices effortlessly from phone prompts.
 * - 6-Digit Dynamic Device Pairing fallback PIN.
 * - Persistent Paired Client Device Trust Registry with instant revocation.
 * - Panic Lockdown switch for instant remote freeze.
 * - Constant-time cryptographic token verification (Timing-attack resistant).
 * - Per-IP Sliding-Window Rate Limiting (150 req/min) & Brute-Force IP Lockouts.
 * - Biometric / Face Authentication status and policies.
 * - OWASP Hardened Security Headers on all HTTP responses.
 */
class AuraSecurityShield(private val context: Context) {

    private val TAG = "AuraSecurityShield"
    private val prefs = context.getSharedPreferences("aura_security_shield_v2", Context.MODE_PRIVATE)

    companion object {
        const val AUTH_MODE_STRICT = "STRICT"           // Every request (HTTP, WS, & loopback) requires a valid token
        const val AUTH_MODE_LOCAL_TRUST = "LOCAL_TRUST" // Direct non-proxied HTTP loopback only; LAN & WebSocket require token
        const val AUTH_MODE_OPEN = "OPEN"               // Deprecated legacy constant - treated identically to STRICT

        private const val MAX_REQUESTS_PER_MINUTE = 150
        private const val MAX_FAILED_ATTEMPTS = 5
        private const val LOCKOUT_DURATION_MS = 60_000L // 60s lockout
        private const val PAIRING_CODE_VALIDITY_MS = 5 * 60_000L // 5 minutes validity
        private const val PAIR_REQUEST_TTL_MS = 2 * 60_000L // 2 minutes max pending window
        private const val MAX_PENDING_PAIR_REQUESTS = 5
        private const val PREF_HARDENED_V2 = "hardened_strict_v2"
    }

    // Dynamic Master Secret Token
    val masterApiToken: String
        get() = prefs.getString("master_api_token", null) ?: generateAndStoreMasterToken()

    var authMode: String
        get() {
            val saved = prefs.getString("auth_mode", AUTH_MODE_STRICT) ?: AUTH_MODE_STRICT
            return if (saved == AUTH_MODE_LOCAL_TRUST) AUTH_MODE_LOCAL_TRUST else AUTH_MODE_STRICT
        }
        set(value) {
            val safeMode = if (value == AUTH_MODE_LOCAL_TRUST) AUTH_MODE_LOCAL_TRUST else AUTH_MODE_STRICT
            prefs.edit().putString("auth_mode", safeMode).apply()
            _authModeFlow.value = safeMode
        }

    var isPanicLockdown: Boolean
        get() = prefs.getBoolean("panic_lockdown", false)
        set(value) {
            prefs.edit().putBoolean("panic_lockdown", value).apply()
            _isPanicLockdownFlow.value = value
        }

    var requireBiometricsForPairing: Boolean
        get() = prefs.getBoolean("require_biometric_pairing", true)
        set(value) = prefs.edit().putBoolean("require_biometric_pairing", value).apply()

    var requireBiometricsForRemoteActions: Boolean
        get() = prefs.getBoolean("require_biometric_actions", false)
        set(value) = prefs.edit().putBoolean("require_biometric_actions", value).apply()

    // 6-digit active pairing code & expiry timestamp
    @Volatile
    private var currentPairingCode: String? = null
    @Volatile
    private var pairingCodeExpiryMs: Long = 0L

    // Paired Clients Registry: deviceId -> PairedClient
    private val pairedClients = ConcurrentHashMap<String, PairedClient>()

    // Token -> deviceId mapping for ultra-fast constant-time lookups
    private val tokenToDeviceIdMap = ConcurrentHashMap<String, String>()

    // Pending 1-tap Pair Requests: requestId -> PendingPairRequest
    private val pendingPairRequests = ConcurrentHashMap<String, PendingPairRequest>()

    private val _latestPendingPairRequest = MutableStateFlow<PendingPairRequest?>(null)
    val latestPendingPairRequest: StateFlow<PendingPairRequest?> = _latestPendingPairRequest.asStateFlow()

    private val _pairedDevicesFlow = MutableStateFlow<List<PairedClient>>(emptyList())
    val pairedDevicesFlow: StateFlow<List<PairedClient>> = _pairedDevicesFlow.asStateFlow()

    private val _pendingPairRequestsFlow = MutableStateFlow<List<PendingPairRequest>>(emptyList())
    val pendingPairRequestsFlow: StateFlow<List<PendingPairRequest>> = _pendingPairRequestsFlow.asStateFlow()

    private val _authModeFlow = MutableStateFlow(AUTH_MODE_STRICT)
    val authModeFlow: StateFlow<String> = _authModeFlow.asStateFlow()

    private val _isPanicLockdownFlow = MutableStateFlow(false)
    val isPanicLockdownFlow: StateFlow<Boolean> = _isPanicLockdownFlow.asStateFlow()

    // Rate Limiting Storage: IP -> (windowStartTimeMs, requestCount)
    private val rateLimitMap = ConcurrentHashMap<String, Pair<Long, Int>>()

    // Brute-force Tracking: IP -> (failedCount, lockoutUntilMs)
    private val failedAttemptsMap = ConcurrentHashMap<String, Pair<Int, Long>>()

    init {
        if (!prefs.contains("master_api_token")) {
            generateAndStoreMasterToken()
        }
        if (!prefs.getBoolean(PREF_HARDENED_V2, false)) {
            prefs.edit()
                .putString("auth_mode", AUTH_MODE_STRICT)
                .putBoolean(PREF_HARDENED_V2, true)
                .apply()
        } else if (prefs.getString("auth_mode", AUTH_MODE_STRICT) == AUTH_MODE_OPEN) {
            prefs.edit().putString("auth_mode", AUTH_MODE_STRICT).apply()
        }
        // Scrub any legacy public .aura_token files exported to Downloads and rotate master token if exposed
        if (scrubLegacyPublicTokenFiles()) {
            generateAndStoreMasterToken()
            Log.w(TAG, "Removed legacy public .aura_token file and rotated master API token.")
        }
        _authModeFlow.value = authMode
        _isPanicLockdownFlow.value = isPanicLockdown
        failedAttemptsMap.clear()
        loadPairedClients()
        emitPendingRequests()
        generatePairingCode()
    }

    private fun emitPairedDevices() {
        _pairedDevicesFlow.value = pairedClients.values
            .filter { !it.isRevoked }
            .sortedByDescending { it.lastSeenAt }
    }

    private fun emitPendingRequests() {
        _pendingPairRequestsFlow.value = pendingPairRequests.values
            .filter { it.status == "PENDING" }
            .sortedByDescending { it.requestedAt }
    }

    private fun scrubLegacyPublicTokenFiles(): Boolean {
        var foundExposed = false
        try {
            val downloads = android.os.Environment.getExternalStoragePublicDirectory(
                android.os.Environment.DIRECTORY_DOWNLOADS
            )
            if (downloads != null) {
                listOf(
                    java.io.File(downloads, ".aura_token"),
                    java.io.File(java.io.File(downloads, "AeroShare"), ".aura_token")
                ).forEach { file ->
                    if (file.exists()) {
                        foundExposed = true
                        runCatching { file.delete() }
                    }
                }
            }
        } catch (_: Exception) {}
        return foundExposed
    }

    private fun generateAndStoreMasterToken(): String {
        val randomBytes = ByteArray(24)
        SecureRandom().nextBytes(randomBytes)
        val token = "aura_sec_" + randomBytes.joinToString("") { "%02x".format(it) }
        prefs.edit().putString("master_api_token", token).commit()
        Log.i(TAG, "Generated master secure API Token: ${token.take(15)}...")
        return token
    }

    /**
     * Rotates the master API token, revokes all paired devices, clears pending requests,
     * and rotates the 6-digit pairing code.
     */
    @Synchronized
    fun rotateMasterTokenAndRevokeAll(): String {
        val newToken = generateAndStoreMasterToken()
        pairedClients.clear()
        tokenToDeviceIdMap.clear()
        pendingPairRequests.clear()
        _latestPendingPairRequest.value = null
        savePairedClients()
        emitPairedDevices()
        emitPendingRequests()
        generatePairingCode()
        failedAttemptsMap.clear()
        Log.w(TAG, "Security keys rotated and all paired devices revoked.")
        return newToken
    }

    /**
     * Generates a new 6-digit cryptographic pairing code valid for 5 minutes.
     */
    @Synchronized
    fun generatePairingCode(): String {
        val secureRandom = SecureRandom()
        val code = String.format("%06d", secureRandom.nextInt(1_000_000))
        currentPairingCode = code
        pairingCodeExpiryMs = System.currentTimeMillis() + PAIRING_CODE_VALIDITY_MS
        Log.i(TAG, "New 6-digit Device Pairing Code generated (Valid for 5 mins)")
        return code
    }

    /**
     * Gets the active pairing code (regenerating if expired).
     */
    fun getActivePairingCode(): Pair<String, Long> {
        val now = System.currentTimeMillis()
        if (currentPairingCode == null || now > pairingCodeExpiryMs) {
            val newCode = generatePairingCode()
            return Pair(newCode, pairingCodeExpiryMs - now)
        }
        return Pair(currentPairingCode!!, (pairingCodeExpiryMs - now).coerceAtLeast(0L))
    }

    private fun pruneExpiredPairRequests() {
        val now = System.currentTimeMillis()
        pendingPairRequests.entries.removeIf { (_, req) ->
            now - req.requestedAt > PAIR_REQUEST_TTL_MS
        }
    }

    /**
     * Creates an interactive 1-tap pending pairing request from a remote device.
     */
    @Synchronized
    fun createPendingPairRequest(
        clientName: String,
        clientIp: String,
        providedDeviceId: String? = null
    ): PendingPairRequest {
        pruneExpiredPairRequests()
        // Cap pending queue to prevent notification spam
        val pendingList = pendingPairRequests.values
            .filter { it.status == "PENDING" }
            .sortedBy { it.requestedAt }
        if (pendingList.size >= MAX_PENDING_PAIR_REQUESTS) {
            pendingList.take(pendingList.size - MAX_PENDING_PAIR_REQUESTS + 1).forEach { old ->
                pendingPairRequests.remove(old.requestId)
            }
        }

        val randomBytes = ByteArray(8)
        SecureRandom().nextBytes(randomBytes)
        val reqId = "req_" + randomBytes.joinToString("") { "%02x".format(it) }
        val devId = providedDeviceId?.ifBlank { null } ?: "dev_" + SecureRandom().nextInt(1_000_000)
        val request = PendingPairRequest(
            requestId = reqId,
            clientName = clientName.ifBlank { "Remote Device ($clientIp)" }.take(64),
            clientIp = clientIp,
            deviceId = devId.take(64)
        )
        pendingPairRequests[reqId] = request
        _latestPendingPairRequest.value = request
        emitPendingRequests()
        Log.i(TAG, "Created 1-tap pending pair request: $reqId for ${request.clientName} ($clientIp)")
        return request
    }

    /**
     * Approves a pending pair request and generates the permanent client token.
     */
    @Synchronized
    fun approvePendingPairRequest(requestId: String): Pair<Boolean, String?> {
        val req = pendingPairRequests[requestId] ?: return Pair(false, "Request ID not found")
        val now = System.currentTimeMillis()

        val randomBytes = ByteArray(24)
        SecureRandom().nextBytes(randomBytes)
        val clientToken = "aura_cli_" + randomBytes.joinToString("") { "%02x".format(it) }

        val paired = PairedClient(
            deviceId = req.deviceId,
            clientName = req.clientName,
            clientToken = clientToken,
            clientIp = req.clientIp,
            pairedAt = now,
            lastSeenAt = now,
            isRevoked = false
        )

        pairedClients[req.deviceId] = paired
        tokenToDeviceIdMap[clientToken] = req.deviceId
        savePairedClients()
        emitPairedDevices()

        req.status = "APPROVED"
        req.clientToken = clientToken

        if (_latestPendingPairRequest.value?.requestId == requestId) {
            _latestPendingPairRequest.value = null
        }
        emitPendingRequests()

        Log.i(TAG, "1-Tap Pair Request APPROVED: ${req.clientName} (Token: ${clientToken.take(12)}...)")
        return Pair(true, clientToken)
    }

    /**
     * Denies a pending pair request.
     */
    @Synchronized
    fun denyPendingPairRequest(requestId: String): Boolean {
        val req = pendingPairRequests[requestId] ?: return false
        req.status = "DENIED"
        if (_latestPendingPairRequest.value?.requestId == requestId) {
            _latestPendingPairRequest.value = null
        }
        emitPendingRequests()
        // Explicitly revoke and remove device if previously registered
        revokeClientDevice(req.deviceId)
        recordFailedAttempt(req.clientIp)
        Log.i(TAG, "1-Tap Pair Request DENIED: ${req.clientName}")
        return true
    }

    fun dismissPendingPairRequest() {
        _latestPendingPairRequest.value = null
    }

    fun showPendingPairRequest(request: PendingPairRequest) {
        _latestPendingPairRequest.value = request
    }

    fun getPendingPairRequest(requestId: String): PendingPairRequest? {
        pruneExpiredPairRequests()
        return pendingPairRequests[requestId]
    }

    fun getPendingPairRequestForPoll(requestId: String, deviceId: String): PendingPairRequest? {
        pruneExpiredPairRequests()
        val req = if (requestId.isNotBlank()) {
            pendingPairRequests[requestId]
        } else null
        val matched = if (req != null) {
            if (deviceId.isNotBlank() && !req.deviceId.equals(deviceId, ignoreCase = true)) {
                null
            } else {
                req
            }
        } else if (deviceId.isNotBlank()) {
            pendingPairRequests.values.find { it.deviceId.equals(deviceId, ignoreCase = true) }
        } else {
            null
        }
        if (matched != null && matched.status == "APPROVED") {
            val firstDelivered = matched.deliveredAt
            if (firstDelivered != null && System.currentTimeMillis() - firstDelivered > 20_000L) {
                matched.clientToken = null
            }
        }
        return matched
    }

    /**
     * Marks an approved pairing token as delivered so duplicate/retried poll requests
     * within a short 20s network grace window still receive the token reliably, after
     * which it is automatically scrubbed (or scrubbed immediately on first verified API call).
     */
    fun markApprovedPairTokenDelivered(requestId: String) {
        pendingPairRequests[requestId]?.let { req ->
            if (req.status == "APPROVED" && req.deliveredAt == null) {
                req.deliveredAt = System.currentTimeMillis()
            }
        }
    }

    fun consumeApprovedPairToken(requestId: String) {
        pendingPairRequests[requestId]?.let { req ->
            if (req.status == "APPROVED") {
                // Scrub token from transient poll cache once delivered
                req.clientToken = null
            }
        }
    }

    fun getPendingPairRequestByDeviceId(deviceId: String): PendingPairRequest? {
        pruneExpiredPairRequests()
        return pendingPairRequests.values.find { it.deviceId.equals(deviceId, ignoreCase = true) }
    }

    fun isDeviceAuthorized(deviceId: String): Boolean {
        val client = pairedClients[deviceId]
        return client != null && !client.isRevoked
    }

    fun listPendingPairRequests(): List<PendingPairRequest> {
        pruneExpiredPairRequests()
        return pendingPairRequests.values.filter { it.status == "PENDING" }
    }

    /**
     * Registers and pairs a new client device using the 6-digit pairing code or master token.
     */
    @Synchronized
    fun pairClientDevice(
        pairingCodeOrToken: String,
        clientName: String,
        clientIp: String,
        providedDeviceId: String? = null
    ): Pair<Boolean, String> {
        if (isPanicLockdown) {
            return Pair(false, "Device is in Panic Lockdown.")
        }
        if (isIpLockedOut(clientIp)) {
            return Pair(false, "Too many failed pairing attempts. Locked out for 60s.")
        }
        val now = System.currentTimeMillis()
        val candidate = pairingCodeOrToken.trim()

        val isCodeValid = candidate.isNotEmpty() &&
                currentPairingCode != null &&
                now <= pairingCodeExpiryMs &&
                constantTimeEquals(candidate, currentPairingCode!!)

        val isMasterToken = candidate.isNotEmpty() && constantTimeEquals(candidate, masterApiToken)

        if (!isCodeValid && !isMasterToken) {
            recordFailedAttempt(clientIp)
            val fails = failedAttemptsMap[clientIp]?.first ?: 0
            if (fails >= MAX_FAILED_ATTEMPTS) {
                // Rotate pairing code on brute-force attempt
                generatePairingCode()
            }
            return Pair(false, "Invalid or expired pairing code.")
        }

        // Generate high-entropy client session token
        val deviceId = providedDeviceId?.ifBlank { null } ?: "dev_" + SecureRandom().nextInt(1_000_000)
        val randomBytes = ByteArray(24)
        SecureRandom().nextBytes(randomBytes)
        val clientToken = "aura_cli_" + randomBytes.joinToString("") { "%02x".format(it) }

        val paired = PairedClient(
            deviceId = deviceId,
            clientName = clientName.ifBlank { "Remote Client ($clientIp)" },
            clientToken = clientToken,
            clientIp = clientIp,
            pairedAt = now,
            lastSeenAt = now,
            isRevoked = false
        )

        pairedClients[deviceId] = paired
        tokenToDeviceIdMap[clientToken] = deviceId
        savePairedClients()
        emitPairedDevices()

        // Rotate pairing code after successful pairing to prevent reuse
        generatePairingCode()
        failedAttemptsMap.remove(clientIp)

        Log.i(TAG, "Device successfully paired: ${paired.clientName} (ID: $deviceId)")
        return Pair(true, clientToken)
    }

    /**
     * Revokes access for a paired device ID.
     */
    @Synchronized
    fun revokeClientDevice(deviceId: String): Boolean {
        val client = pairedClients[deviceId] ?: return false
        client.isRevoked = true
        tokenToDeviceIdMap.remove(client.clientToken)
        pairedClients.remove(deviceId)
        savePairedClients()
        emitPairedDevices()
        Log.i(TAG, "Device pairing revoked: $deviceId")
        return true
    }

    /**
     * Lists all currently registered paired devices.
     */
    fun listPairedDevices(): List<PairedClient> {
        return pairedClients.values.toList()
    }

    /**
     * Checks if client IP is temporarily locked out.
     */
    fun isIpLockedOut(clientIp: String): Boolean {
        if (isPanicLockdown) {
            return true
        }

        val entry = failedAttemptsMap[clientIp] ?: return false
        val now = System.currentTimeMillis()
        if (entry.first >= MAX_FAILED_ATTEMPTS) {
            if (now < entry.second) {
                return true
            } else {
                failedAttemptsMap.remove(clientIp)
            }
        }
        return false
    }

    /**
     * Checks and increments rate limit for client IP.
     */
    fun checkRateLimit(clientIp: String): Boolean {
        val now = System.currentTimeMillis()
        val entry = rateLimitMap[clientIp]

        if (entry == null || now - entry.first > 60_000L) {
            rateLimitMap[clientIp] = Pair(now, 1)
            return true
        }

        val count = entry.second
        if (count >= MAX_REQUESTS_PER_MINUTE) {
            Log.w(TAG, "Rate limit exceeded for client: $clientIp ($count reqs/min)")
            return false
        }

        rateLimitMap[clientIp] = Pair(entry.first, count + 1)
        return true
    }

    /**
     * Verifies if an HTTP request is authorized.
     * - In STRICT mode (default): ALL requests, including loopback, require a valid Bearer/API token.
     * - In LOCAL_TRUST mode: ONLY direct non-proxied TCP loopback is auto-trusted; remote/proxied requests strictly require a valid token.
     */
    fun verifyRequest(
        clientIp: String,
        providedAuthHeader: String?,
        providedQueryToken: String?,
        hasProxyHeaders: Boolean = false
    ): Boolean {
        if (isPanicLockdown) {
            Log.w(TAG, "Blocked request during PANIC LOCKDOWN from IP: $clientIp")
            return false
        }

        if (isIpLockedOut(clientIp)) {
            Log.w(TAG, "Blocked request from locked-out IP: $clientIp")
            return false
        }

        val isTrustedDirectLoopback = !hasProxyHeaders && isLoopback(clientIp)
        if (authMode == AUTH_MODE_LOCAL_TRUST && isTrustedDirectLoopback) {
            return true
        }

        val candidate = extractToken(providedAuthHeader, providedQueryToken)
        if (candidate.isNullOrBlank()) {
            recordFailedAttempt(clientIp)
            return false
        }

        val isAuthorized = verifyToken(candidate, clientIp)
        if (isAuthorized) {
            failedAttemptsMap.remove(clientIp)
            return true
        } else {
            recordFailedAttempt(clientIp)
            return false
        }
    }

    /**
     * Verifies WebSocket commands strictly by token. Never trusts JSON-supplied clientIp.
     */
    fun verifyWebSocketRequest(providedToken: String?): Boolean {
        if (isPanicLockdown) {
            Log.w(TAG, "Blocked WebSocket command during PANIC LOCKDOWN")
            return false
        }
        val token = providedToken?.trim().orEmpty()
        if (token.isEmpty()) {
            recordFailedAttempt("ws-unauthenticated")
            return false
        }
        val ok = verifyToken(token, "ws-client")
        if (!ok) {
            recordFailedAttempt("ws-unauthenticated")
        } else {
            failedAttemptsMap.remove("ws-unauthenticated")
        }
        return ok
    }

    fun isMasterToken(providedAuthHeader: String?, providedQueryToken: String? = null): Boolean {
        val candidate = extractToken(providedAuthHeader, providedQueryToken) ?: return false
        return candidate.isNotEmpty() && constantTimeEquals(candidate, masterApiToken)
    }

    /**
     * Validates candidate token against master API token or active paired client tokens.
     */
    fun verifyToken(candidate: String, clientIp: String): Boolean {
        if (isPanicLockdown) {
            return false
        }
        if (candidate.isBlank()) {
            return false
        }

        // 1. Check Master Token
        if (constantTimeEquals(candidate, masterApiToken)) {
            return true
        }

        // 2. Check Paired Clients Registry
        val now = System.currentTimeMillis()
        val deviceId = tokenToDeviceIdMap[candidate]
        if (deviceId != null) {
            val client = pairedClients[deviceId]
            if (client != null && !client.isRevoked) {
                scrubPendingTokenForDevice(deviceId)
                if (now - client.lastSeenAt > 2000L) {
                    pairedClients[deviceId] = client.copy(lastSeenAt = now)
                    emitPairedDevices()
                }
                return true
            }
        }

        // Fallback linear scan with constant-time equality
        for (client in pairedClients.values) {
            if (!client.isRevoked && constantTimeEquals(candidate, client.clientToken)) {
                tokenToDeviceIdMap[client.clientToken] = client.deviceId
                scrubPendingTokenForDevice(client.deviceId)
                if (now - client.lastSeenAt > 2000L) {
                    pairedClients[client.deviceId] = client.copy(lastSeenAt = now)
                    emitPairedDevices()
                }
                return true
            }
        }

        return false
    }

    private fun scrubPendingTokenForDevice(deviceId: String) {
        pendingPairRequests.values.forEach { req ->
            if (req.deviceId.equals(deviceId, ignoreCase = true) && req.clientToken != null) {
                req.clientToken = null
            }
        }
    }

    private fun extractToken(authHeader: String?, queryToken: String?): String? {
        if (!authHeader.isNullOrBlank()) {
            val trimmed = authHeader.trim()
            if (trimmed.startsWith("Bearer ", ignoreCase = true)) {
                return trimmed.substring(7).trim()
            }
            if (trimmed.startsWith("ApiKey ", ignoreCase = true)) {
                return trimmed.substring(7).trim()
            }
            return trimmed
        }
        if (!queryToken.isNullOrBlank()) {
            return queryToken.trim()
        }
        return null
    }

    private fun recordFailedAttempt(clientIp: String) {
        val now = System.currentTimeMillis()
        val entry = failedAttemptsMap[clientIp]
        val currentCount = (entry?.first ?: 0) + 1
        val lockoutUntil = if (currentCount >= MAX_FAILED_ATTEMPTS) now + LOCKOUT_DURATION_MS else 0L

        failedAttemptsMap[clientIp] = Pair(currentCount, lockoutUntil)
        Log.w(TAG, "Failed auth attempt $currentCount/$MAX_FAILED_ATTEMPTS from IP: $clientIp")
    }

    fun isLoopback(ip: String): Boolean {
        return ip == "127.0.0.1" || ip == "0:0:0:0:0:0:0:1" || ip == "::1" || ip == "localhost"
    }

    /**
     * Constant-time equality check to eliminate timing side-channel attacks.
     */
    private fun constantTimeEquals(a: String, b: String): Boolean {
        val aBytes = a.toByteArray(Charsets.UTF_8)
        val bBytes = b.toByteArray(Charsets.UTF_8)
        return MessageDigest.isEqual(aBytes, bBytes)
    }

    /**
     * Computes HMAC-SHA256 signature for payload verification.
     */
    fun signPayload(payload: String): String {
        val mac = Mac.getInstance("HmacSHA256")
        val secretKey = SecretKeySpec(masterApiToken.toByteArray(Charsets.UTF_8), "HmacSHA256")
        mac.init(secretKey)
        val hash = mac.doFinal(payload.toByteArray(Charsets.UTF_8))
        return hash.joinToString("") { "%02x".format(it) }
    }

    /**
     * Verifies HMAC-SHA256 signature.
     */
    fun verifySignature(payload: String, signatureHex: String): Boolean {
        val expected = signPayload(payload)
        return constantTimeEquals(expected, signatureHex)
    }

    /**
     * Returns standard OWASP hardened security headers.
     */
    fun getSecurityHeaders(): Map<String, String> {
        return mapOf(
            "X-Content-Type-Options" to "nosniff",
            "X-Frame-Options" to "DENY",
            "X-XSS-Protection" to "1; mode=block",
            "Content-Security-Policy" to "default-src 'self'",
            "Strict-Transport-Security" to "max-age=31536000; includeSubDomains",
            "Cache-Control" to "no-store, no-cache, must-revalidate, private",
            "Server" to "AuraSecurityShield/3.0"
        )
    }

    /**
     * Saves paired devices to persistent SharedPreferences.
     */
    private fun savePairedClients() {
        try {
            val array = JSONArray()
            pairedClients.values.forEach { client ->
                val obj = JSONObject().apply {
                    put("deviceId", client.deviceId)
                    put("clientName", client.clientName)
                    put("clientToken", client.clientToken)
                    put("clientIp", client.clientIp)
                    put("pairedAt", client.pairedAt)
                    put("lastSeenAt", client.lastSeenAt)
                    put("isRevoked", client.isRevoked)
                }
                array.put(obj)
            }
            prefs.edit().putString("paired_clients_json", array.toString()).commit()
        } catch (e: Exception) {
            Log.e(TAG, "Failed to persist paired clients", e)
        }
    }

    /**
     * Loads paired devices from persistent storage.
     */
    private fun loadPairedClients() {
        try {
            val jsonStr = prefs.getString("paired_clients_json", null) ?: return
            val array = JSONArray(jsonStr)
            pairedClients.clear()
            tokenToDeviceIdMap.clear()
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                val client = PairedClient(
                    deviceId = obj.getString("deviceId"),
                    clientName = obj.optString("clientName", "Paired Client"),
                    clientToken = obj.getString("clientToken"),
                    clientIp = obj.optString("clientIp", ""),
                    pairedAt = obj.optLong("pairedAt", System.currentTimeMillis()),
                    lastSeenAt = obj.optLong("lastSeenAt", System.currentTimeMillis()),
                    isRevoked = obj.optBoolean("isRevoked", false)
                )
                if (!client.isRevoked) {
                    pairedClients[client.deviceId] = client
                    tokenToDeviceIdMap[client.clientToken] = client.deviceId
                }
            }
            Log.i(TAG, "Loaded ${pairedClients.size} active paired devices from secure storage.")
            emitPairedDevices()
        } catch (e: Exception) {
            Log.e(TAG, "Failed to load paired clients from storage", e)
        }
    }
}
