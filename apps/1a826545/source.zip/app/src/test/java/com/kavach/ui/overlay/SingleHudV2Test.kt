package com.kavach.ui.overlay

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.kavach.accessibility.AccessibilityRepositoryImpl
import com.kavach.ui.overlay.hud.HudModels
import com.kavach.ui.overlay.hud.HudStore
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class SingleHudV2Test {

    private lateinit var context: Context
    private lateinit var store: HudStore

    @Before
    fun setUp() {
        context = ApplicationProvider.getApplicationContext()
        store = HudStore(context)
    }

    @Test
    fun `updateState parses chess widget media carousel and hardware chip cleanly`() {
        val payload = JSONObject()
            .put("status", "WORKING")
            .put("title", "Chess Autopilot")
            .put("thinkingText", "Calculating Nf3 (+0.5)...")
            .put(
                "chess",
                JSONObject()
                    .put("fen", "rnbqkbnr/pppppppp/8/8/4P3/8/PPPP1PPP/RNBQKBNR")
                    .put("playerColor", "white")
                    .put("evalCp", "+0.5")
                    .put("bestMove", JSONObject().put("from", "g1").put("to", "f3"))
                    .put("turnLabel", "White to move")
            )
            .put(
                "mediaItems",
                JSONArray().put(
                    JSONObject()
                        .put("kind", "video")
                        .put("title", "Match Clip")
                        .put("uri", "https://example.org/clip.mp4")
                )
            )
            .put(
                "hardwareChip",
                JSONObject().put("label", "Battery").put("value", "84%")
            )

        store.updateState(payload)
        val state = store.uiState.value
        assertEquals(HudModels.HudStatus.WORKING, state.status)
        assertEquals("Chess Autopilot", state.title)
        assertEquals("Calculating Nf3 (+0.5)...", state.thinkingText)
        assertNotNull(state.chess)
        assertEquals("g1", state.chess?.bestMove?.from)
        assertEquals("f3", state.chess?.bestMove?.to)
        assertEquals(1, state.mediaItems.size)
        assertEquals("Battery", state.hardwareChip?.label)
        assertEquals("84%", state.hardwareChip?.value)
    }

    @Test
    fun `approval gate enters NEEDS_INPUT and clears cleanly`() {
        store.setApprovalGate(
            JSONObject()
                .put("id", "apr_99")
                .put("title", "Run Shell Command")
                .put("commandPreview", "rm -rf /sdcard/tmp")
                .put("riskLevel", "high")
        )
        val waiting = store.uiState.value
        assertEquals(HudModels.HudStatus.NEEDS_INPUT, waiting.status)
        assertFalse(waiting.isCollapsed)
        assertNotNull(waiting.approval)
        assertEquals("high", waiting.approval?.riskLevel)

        store.setApprovalGate(JSONObject().put("clear", true))
        assertNull(store.uiState.value.approval)
    }

    @Test
    fun `media controls toggle playPause and mute and HUD_NODE_TAG_PREFIX self-excludes cleanly`() {
        store.updateState(
            JSONObject()
                .put("status", "DONE")
                .put(
                    "mediaItems",
                    JSONArray().put(
                        JSONObject()
                            .put("kind", "audio")
                            .put("title", "Focus Track")
                            .put("uri", "https://example.org/track.mp3")
                    )
                )
        )
        assertFalse(store.uiState.value.mediaPlaying)
        assertFalse(store.uiState.value.mediaMuted)

        store.toggleMediaPlayPause()
        assertTrue(store.uiState.value.mediaPlaying)

        store.toggleMediaMute()
        assertTrue(store.uiState.value.mediaMuted)

        val repo = AccessibilityRepositoryImpl()
        assertTrue(repo.isAgyHudIdentifier(null, "${HudModels.HUD_NODE_TAG_PREFIX}window"))
        assertTrue(repo.isAgyHudIdentifier("com.kavach:id/${HudModels.HUD_NODE_TAG_PREFIX}input_pill", null))
        assertFalse(repo.isAgyHudIdentifier("com.termux:id/terminal_view", "Terminal"))
    }
}
