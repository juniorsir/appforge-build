package com.kavach.ui.overlay

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.view.View
import androidx.test.core.app.ApplicationProvider
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.shadows.ShadowSettings

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36], qualifiers = "w360dp-h800dp-xxhdpi")
class AgyDiagramAndVisualLeftWindowTest {

    private lateinit var context: Context
    private lateinit var floatingOverlayManager: FloatingOverlayManager
    private lateinit var taskMapManager: AgyTaskMapOverlayManager
    private lateinit var hudManager: AgyHudOverlayManager

    @Before
    fun setUp() {
        context = ApplicationProvider.getApplicationContext()
        ShadowSettings.setCanDrawOverlays(true)
        floatingOverlayManager = FloatingOverlayManager(context)
        taskMapManager = AgyTaskMapOverlayManager(context)
        hudManager = AgyHudOverlayManager(
            context = context,
            floatingOverlayManager = floatingOverlayManager
        ).apply {
            taskMapOverlayManager = taskMapManager
        }
    }

    @Test
    fun `DiagramTaskMapData parses Mermaid flowchart, sequence, pie, arrow chain, and metrics cleanly`() {
        val flowDiag = AgyHudDynamicModels.DiagramTaskMapData.fromMermaidOrStructure(
            "```mermaid\ngraph TD\nA[App] --> B[OAuth Server]\nB --> C[Token]\n```",
            "Auth Flow"
        )
        assertNotNull(flowDiag)
        assertEquals("flowchart", flowDiag!!.diagramType)
        assertEquals(3, flowDiag.nodes.size)
        assertEquals(2, flowDiag.edges.size)

        val seqDiag = AgyHudDynamicModels.DiagramTaskMapData.fromMermaidOrStructure(
            "```mermaid\nsequenceDiagram\nUser->>App: Tap Login\nApp-->>API: Exchange Code\n```",
            "Login Sequence"
        )
        assertNotNull(seqDiag)
        assertEquals("sequence", seqDiag!!.diagramType)
        assertEquals(3, seqDiag.nodes.size)
        assertEquals(2, seqDiag.edges.size)
        assertEquals("Tap Login", seqDiag.edges[0].label)

        val pieDiag = AgyHudDynamicModels.DiagramTaskMapData.fromMermaidOrStructure(
            "```mermaid\npie title Usage\n\"Images\" : 45\n\"Videos\" : 35\n\"Docs\" : 20\n```",
            "Breakdown"
        )
        assertNotNull(pieDiag)
        assertEquals("chart", pieDiag!!.diagramType)
        assertEquals("radial", pieDiag.subChartType)
        assertEquals(3, pieDiag.series.size)

        val arrowDiag = AgyHudDynamicModels.DiagramTaskMapData.fromMermaidOrStructure(
            "Client -> Gateway -> Worker -> Database",
            "Pipeline"
        )
        assertNotNull(arrowDiag)
        assertEquals(4, arrowDiag!!.nodes.size)
        assertEquals(3, arrowDiag.edges.size)

        val metricDiag = AgyHudDynamicModels.DiagramTaskMapData.fromMetrics(
            listOf(
                AgyHudDynamicModels.HudMetricItem("cpu", "CPU", "42%"),
                AgyHudDynamicModels.HudMetricItem("ram", "RAM", "68%"),
                AgyHudDynamicModels.HudMetricItem("gpu", "GPU", "51%")
            ),
            title = "Telemetry"
        )
        assertNotNull(metricDiag)
        assertEquals("chart", metricDiag!!.diagramType)
        assertEquals(3, metricDiag.series.size)
    }

    @Test
    fun `AgyDiagramPanelView renders flowchart, sequence, and bar line radial charts with zoom and snapshot`() {
        val theme = AgyHudDynamicModels.resolveTheme(
            AgyHudDynamicModels.HudThemeConfig(mode = "dark"),
            Color.parseColor("#6366F1")
        )
        val panel = AgyDiagramPanelView(context)
        val config = AgyHudDynamicModels.TaskMapConfig(
            active = true,
            mode = "diagram",
            title = "System Pipeline",
            diagram = AgyHudDynamicModels.DiagramTaskMapData(
                diagramType = "flowchart",
                subChartType = "bar",
                title = "System Pipeline",
                nodes = listOf(
                    AgyHudDynamicModels.DiagramNode("n1", "Client", role = "start", status = "done", layer = 0, value = 100f),
                    AgyHudDynamicModels.DiagramNode("n2", "Gateway", role = "decision", status = "doing", layer = 1, value = 65f),
                    AgyHudDynamicModels.DiagramNode("n3", "DB Store", role = "database", status = "pending", layer = 2, value = 40f)
                ),
                edges = listOf(
                    AgyHudDynamicModels.DiagramEdge("n1", "n2", label = "REQ", active = true),
                    AgyHudDynamicModels.DiagramEdge("n2", "n3", label = "SQL", dashed = true)
                ),
                activeNodeId = "n2",
                series = listOf(
                    AgyHudDynamicModels.DiagramSeriesPoint("Client", 100f, 100f, "done"),
                    AgyHudDynamicModels.DiagramSeriesPoint("Gateway", 65f, 100f, "doing"),
                    AgyHudDynamicModels.DiagramSeriesPoint("DB", 40f, 100f, "pending")
                )
            )
        )

        fun renderPass() {
            panel.measure(
                View.MeasureSpec.makeMeasureSpec(520, View.MeasureSpec.EXACTLY),
                View.MeasureSpec.makeMeasureSpec(640, View.MeasureSpec.AT_MOST)
            )
            assertTrue(panel.measuredWidth == 520)
            assertTrue(panel.measuredHeight > 0)
            panel.layout(0, 0, panel.measuredWidth, panel.measuredHeight)
            val bmp = Bitmap.createBitmap(520, panel.measuredHeight.coerceAtLeast(1), Bitmap.Config.ARGB_8888)
            panel.draw(Canvas(bmp))
        }

        panel.updateDiagram(config, theme)
        assertEquals("flowchart", panel.getCurrentDiagramType())
        renderPass()

        panel.selectNode("n3")
        assertEquals("n3", panel.getSelectedNodeId())
        panel.adjustZoom(0.35f)
        assertTrue(panel.getZoomScale() > 1.0f)
        renderPass()

        panel.switchVisualMode("sequence")
        assertEquals("sequence", panel.getCurrentDiagramType())
        renderPass()

        panel.switchVisualMode("chart")
        assertEquals("chart", panel.getCurrentDiagramType())
        renderPass()

        val chartBtn = panel.findViewWithTag<View>("${AgyHudOverlayManager.HUD_NODE_TAG_PREFIX}diagram_mode_chart")
        assertNotNull(chartBtn)
        chartBtn.performClick() // switches bar -> line
        renderPass()
        chartBtn.performClick() // switches line -> radial
        renderPass()

        val snapshot = panel.renderSnapshotBitmap(720, 580)
        assertEquals(720, snapshot.width)
        assertEquals(580, snapshot.height)
    }

    @Test
    fun `AgyResultsPanelView enforces visual-only hiding of summary card and launches video playback`() {
        val theme = AgyHudDynamicModels.resolveTheme(
            AgyHudDynamicModels.HudThemeConfig(mode = "dark"),
            Color.parseColor("#0EA5E9")
        )
        val panel = AgyResultsPanelView(context)
        var playedVideo: AgyHudDynamicModels.ResultMediaItem? = null
        panel.onVideoItemClicked = { item -> playedVideo = item }

        val cfg = AgyHudDynamicModels.TaskMapConfig(
            active = true,
            mode = "results",
            title = "Media",
            results = AgyHudDynamicModels.ResultsTaskMapData(
                query = "Show media",
                summaryTitle = "Should stay hidden",
                summaryText = "Plain text belongs exclusively in the Main HUD.",
                items = listOf(
                    AgyHudDynamicModels.ResultMediaItem(
                        id = "v1",
                        kind = "video",
                        title = "Demo Stream",
                        subtitle = "youtube.com",
                        uri = "https://www.youtube.com/watch?v=jfKfPfyJRdk"
                    )
                )
            )
        )
        panel.updateResults(cfg, theme)
        panel.measure(
            View.MeasureSpec.makeMeasureSpec(440, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(700, View.MeasureSpec.AT_MOST)
        )
        panel.layout(0, 0, panel.measuredWidth, panel.measuredHeight)

        assertFalse(panel.isSummaryCardVisible())
        val card = panel.findViewWithTag<View>("${AgyHudOverlayManager.HUD_NODE_TAG_PREFIX}result_card_0")
        assertNotNull(card)
        card.performClick()
        assertNotNull(playedVideo)
        assertEquals("v1", playedVideo?.id)
    }

    @Test
    fun `Diagram and Player panels measure cleanly inside FrameLayout and LinearLayout overlay card hierarchy`() {
        val theme = AgyHudDynamicModels.resolveTheme(
            AgyHudDynamicModels.HudThemeConfig(mode = "dark"),
            Color.parseColor("#6366F1")
        )
        val rootFrame = android.widget.FrameLayout(context)
        val cardLinear = android.widget.LinearLayout(context).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            layoutParams = android.widget.FrameLayout.LayoutParams(520, android.view.ViewGroup.LayoutParams.WRAP_CONTENT)
        }
        val diagramPanel = AgyDiagramPanelView(context).apply {
            layoutParams = android.widget.LinearLayout.LayoutParams(
                android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                500
            )
        }
        val playerPanel = AgyMediaPlayerPanelView(context).apply {
            layoutParams = android.widget.LinearLayout.LayoutParams(
                android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                android.view.ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }
        cardLinear.addView(diagramPanel)
        cardLinear.addView(playerPanel)
        rootFrame.addView(cardLinear)

        diagramPanel.updateDiagram(
            AgyHudDynamicModels.TaskMapConfig(
                active = true,
                mode = "diagram",
                diagram = AgyHudDynamicModels.DiagramTaskMapData(
                    diagramType = "sequence",
                    nodes = listOf(
                        AgyHudDynamicModels.DiagramNode("u", "User"),
                        AgyHudDynamicModels.DiagramNode("a", "Agy")
                    ),
                    edges = listOf(AgyHudDynamicModels.DiagramEdge("u", "a", "Prompt"))
                )
            ),
            theme
        )
        assertTrue(diagramPanel.layoutParams is android.widget.LinearLayout.LayoutParams)

        playerPanel.updatePlayer(
            AgyHudDynamicModels.TaskMapConfig(
                active = true,
                mode = "player",
                player = AgyHudDynamicModels.PlayerTaskMapData(
                    mediaMode = "video",
                    playing = false,
                    playlist = listOf(
                        AgyHudDynamicModels.PlayerTrackItem(
                            id = "t1",
                            title = "Clip",
                            uri = "https://example.org/clip.mp4",
                            isVideo = true
                        )
                    )
                )
            ),
            theme
        )

        rootFrame.measure(
            View.MeasureSpec.makeMeasureSpec(520, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(1200, View.MeasureSpec.AT_MOST)
        )
        rootFrame.layout(0, 0, rootFrame.measuredWidth, rootFrame.measuredHeight)
        assertTrue(rootFrame.measuredHeight > 0)
    }

    @Test
    fun `HUD auto-routes Mermaid to diagram, video results to player, and keeps plain text out of Left Window`() {
        // 1. Plain text-only results must NOT activate Window 3
        val plainRes = hudManager.updateState(
            JSONObject()
                .put("state", "DONE")
                .put("title", "What is Kotlin?")
                .put(
                    "results",
                    JSONObject()
                        .put("query", "What is Kotlin?")
                        .put("summaryText", "Kotlin is a statically typed programming language.")
                        .put("items", JSONArray())
                )
        )
        assertTrue(plainRes.optBoolean("success"))
        assertFalse(hudManager.hudState.value.taskMap.active)
        assertFalse(taskMapManager.isMapVisibleFlow.value)

        // 2. Video-only results auto-promote directly to playing video player
        val vidRes = hudManager.updateState(
            JSONObject()
                .put("state", "DONE")
                .put("title", "Watch Stream")
                .put(
                    "results",
                    JSONObject()
                        .put("query", "Play stream")
                        .put(
                            "items",
                            JSONArray().put(
                                JSONObject()
                                    .put("id", "yt1")
                                    .put("title", "Lofi Live")
                                    .put("uri", "https://youtu.be/jfKfPfyJRdk")
                            )
                        )
                )
        )
        assertTrue(vidRes.optBoolean("taskMapActive"))
        assertEquals("player", hudManager.hudState.value.taskMap.mode)
        assertEquals("video", hudManager.hudState.value.taskMap.player?.mediaMode)
        assertTrue(hudManager.hudState.value.taskMap.player?.playing == true)

        // 3. Multi-step tasks without explicit TaskMap auto-synthesize an interactive Diagram
        hudManager.resetState()
        val taskDiagRes = hudManager.updateState(
            JSONObject()
                .put("state", "WORKING")
                .put("title", "Deploy Build")
                .put(
                    "tasks",
                    JSONArray()
                        .put(JSONObject().put("id", "t1").put("label", "Compile APK").put("status", "done"))
                        .put(JSONObject().put("id", "t2").put("label", "Run Tests").put("status", "doing"))
                        .put(JSONObject().put("id", "t3").put("label", "Upload Artifact").put("status", "pending"))
                )
        )
        assertTrue(taskDiagRes.optBoolean("taskMapActive"))
        assertEquals("diagram", hudManager.hudState.value.taskMap.mode)
        assertEquals(3, hudManager.hudState.value.taskMap.diagram?.nodes?.size)

        // 4. Direct setDiagram / clearDiagram APIs
        val directDiagRes = hudManager.setDiagram(
            JSONObject()
                .put("diagramType", "sequence")
                .put("title", "Handshake")
                .put(
                    "nodes",
                    JSONArray()
                        .put(JSONObject().put("id", "a").put("label", "Client"))
                        .put(JSONObject().put("id", "b").put("label", "Server"))
                )
                .put(
                    "edges",
                    JSONArray().put(JSONObject().put("from", "a").put("to", "b").put("label", "SYN"))
                )
        )
        assertTrue(directDiagRes.optBoolean("success"))
        assertTrue(directDiagRes.optBoolean("diagramActive"))
        assertEquals("diagram", taskMapManager.taskMapStateFlow.value.mode)

        val cleared = hudManager.clearDiagram()
        assertFalse(cleared.optBoolean("diagramActive"))
        assertFalse(taskMapManager.isMapVisibleFlow.value)
    }

    @Test
    fun `AgyDiagramPanelView preserves bottom dock safe-zone clearance and resets zoom-pan-selection via FIT_RESET`() {
        val theme = AgyHudDynamicModels.resolveTheme(
            AgyHudDynamicModels.HudThemeConfig(mode = "dark"),
            Color.parseColor("#6366F1")
        )
        val panel = AgyDiagramPanelView(context)
        val config = AgyHudDynamicModels.TaskMapConfig(
            active = true,
            mode = "diagram",
            title = "Pipeline",
            diagram = AgyHudDynamicModels.DiagramTaskMapData(
                diagramType = "flowchart",
                title = "Pipeline",
                nodes = listOf(
                    AgyHudDynamicModels.DiagramNode("n1", "Input", status = "done", layer = 0),
                    AgyHudDynamicModels.DiagramNode("n2", "Process", status = "doing", layer = 1),
                    AgyHudDynamicModels.DiagramNode("n3", "Store", status = "pending", layer = 2),
                    AgyHudDynamicModels.DiagramNode("n4", "Emit", status = "pending", layer = 3)
                ),
                edges = listOf(
                    AgyHudDynamicModels.DiagramEdge("n1", "n2"),
                    AgyHudDynamicModels.DiagramEdge("n2", "n3"),
                    AgyHudDynamicModels.DiagramEdge("n3", "n4")
                )
            )
        )
        panel.updateDiagram(config, theme)
        panel.measure(
            View.MeasureSpec.makeMeasureSpec(520, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(640, View.MeasureSpec.EXACTLY)
        )
        panel.layout(0, 0, panel.measuredWidth, panel.measuredHeight)
        val bmp = Bitmap.createBitmap(520, 640, Bitmap.Config.ARGB_8888)
        panel.draw(Canvas(bmp))

        val safeBounds = panel.getLastSafeContentBounds()
        val dockTop = panel.getBottomDockReservedTopY()
        assertTrue("Safe bounds bottom must stay above bottom glass dock", safeBounds.bottom <= dockTop + 1f)
        val renderedNodes = panel.getLastRenderedNodeBounds()
        assertEquals(4, renderedNodes.size)
        renderedNodes.values.forEach { rect ->
            assertTrue("Node bottom (${rect.bottom}) must clear bottom dock ($dockTop)", rect.bottom <= dockTop + 1f)
        }

        // Modify zoom and selection, then click FIT_RESET button
        panel.selectNode("n2")
        panel.adjustZoom(0.45f)
        assertEquals("n2", panel.getSelectedNodeId())
        assertTrue(panel.getZoomScale() > 1.0f)

        val fitResetBtn = panel.findViewWithTag<View>("${AgyHudOverlayManager.HUD_NODE_TAG_PREFIX}diagram_fit_reset")
        assertNotNull(fitResetBtn)
        fitResetBtn.performClick()
        assertEquals(1.0f, panel.getZoomScale(), 0.001f)
        assertEquals(0f to 0f, panel.getPanOffset())
        assertEquals("", panel.getSelectedNodeId())
    }

    @Test
    fun `AgyVisualWindowRouter extracts radial and bar charts from text percentages and preserves clearDiagram hysteresis`() {
        // 3 percentage metrics -> radial chart
        val radialRes = hudManager.updateState(
            JSONObject()
                .put("state", "DONE")
                .put("title", "System Telemetry")
                .put("detailedOutput", "CPU: 42%, RAM: 78%, Disk: 90%")
        )
        assertTrue(radialRes.optBoolean("taskMapActive"))
        assertEquals("diagram", hudManager.hudState.value.taskMap.mode)
        assertEquals("chart", hudManager.hudState.value.taskMap.diagram?.diagramType)
        assertEquals("radial", hudManager.hudState.value.taskMap.diagram?.subChartType)
        assertEquals(3, hudManager.hudState.value.taskMap.diagram?.series?.size)

        // 4 percentage metrics -> bar chart
        val barRes = hudManager.updateState(
            JSONObject()
                .put("state", "DONE")
                .put("title", "Cluster Load")
                .put("detailedOutput", "CPU: 42%, RAM: 78%, Disk: 90%, GPU: 64%")
        )
        assertTrue(barRes.optBoolean("taskMapActive"))
        assertEquals("bar", hudManager.hudState.value.taskMap.diagram?.subChartType)
        assertEquals(4, hudManager.hudState.value.taskMap.diagram?.series?.size)

        // Dismissing auto-synthesized diagram keeps it hidden on identical heartbeat patches
        hudManager.clearDiagram()
        assertFalse(hudManager.hudState.value.taskMap.active)
        hudManager.patchState(JSONObject().put("elapsedSeconds", 15))
        assertFalse("Dismissed diagram must not flicker back on unrelated patch", hudManager.hudState.value.taskMap.active)
    }
}
