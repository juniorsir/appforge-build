package com.kavach

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.kavach.security.AuraSecurityShield
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class AuraSecurityShieldTest {

    private lateinit var context: Context
    private lateinit var shield: AuraSecurityShield

    @Before
    fun setup() {
        context = ApplicationProvider.getApplicationContext()
        context.getSharedPreferences("aura_security_shield_v2", Context.MODE_PRIVATE)
            .edit().clear().commit()
        shield = AuraSecurityShield(context)
    }

    @Test
    fun `defaults to STRICT mode and rejects OPEN downgrade`() {
        assertEquals(AuraSecurityShield.AUTH_MODE_STRICT, shield.authMode)
        shield.authMode = AuraSecurityShield.AUTH_MODE_OPEN
        assertEquals(AuraSecurityShield.AUTH_MODE_STRICT, shield.authMode)
    }

    @Test
    fun `STRICT rejects unauthenticated loopback and remote requests`() {
        assertFalse(shield.verifyRequest("127.0.0.1", null, null, hasProxyHeaders = false))
        assertFalse(shield.verifyRequest("192.168.1.50", null, null, hasProxyHeaders = false))
        assertTrue(
            shield.verifyRequest(
                "127.0.0.1",
                "Bearer ${shield.masterApiToken}",
                null,
                hasProxyHeaders = false
            )
        )
    }

    @Test
    fun `LOCAL_TRUST allows direct loopback only and blocks remote or proxied requests`() {
        shield.authMode = AuraSecurityShield.AUTH_MODE_LOCAL_TRUST
        assertTrue(shield.verifyRequest("127.0.0.1", null, null, hasProxyHeaders = false))
        assertFalse(shield.verifyRequest("127.0.0.1", null, null, hasProxyHeaders = true))
        assertFalse(shield.verifyRequest("192.168.1.25", null, null, hasProxyHeaders = false))
    }

    @Test
    fun `WebSocket verification always requires valid token even in LOCAL_TRUST`() {
        shield.authMode = AuraSecurityShield.AUTH_MODE_LOCAL_TRUST
        assertFalse(shield.verifyWebSocketRequest(null))
        assertFalse(shield.verifyWebSocketRequest(""))
        assertFalse(shield.verifyWebSocketRequest("invalid_token"))
        assertTrue(shield.verifyWebSocketRequest(shield.masterApiToken))
    }

    @Test
    fun `Panic lockdown freezes all HTTP and WebSocket verification`() {
        shield.isPanicLockdown = true
        assertFalse(shield.verifyRequest("127.0.0.1", "Bearer ${shield.masterApiToken}", null))
        assertFalse(shield.verifyWebSocketRequest(shield.masterApiToken))
        shield.isPanicLockdown = false
        assertTrue(shield.verifyRequest("127.0.0.1", "Bearer ${shield.masterApiToken}", null))
    }

    @Test
    fun `pairing approval requires matching deviceId on poll and scrubs token once consumed`() {
        val pending = shield.createPendingPairRequest("Termux", "127.0.0.1", "SEC-DEV-1234")
        val (approved, token) = shield.approvePendingPairRequest(pending.requestId)
        assertTrue(approved)
        assertNotNull(token)

        assertNull(shield.getPendingPairRequestForPoll(pending.requestId, "WRONG-DEV"))
        val matched = shield.getPendingPairRequestForPoll(pending.requestId, "SEC-DEV-1234")
        assertNotNull(matched)
        assertEquals(token, matched?.clientToken)

        shield.consumeApprovedPairToken(pending.requestId)
        assertNull(shield.getPendingPairRequestForPoll(pending.requestId, "SEC-DEV-1234")?.clientToken)
    }

    @Test
    fun `rotateMasterTokenAndRevokeAll invalidates old master and paired tokens`() {
        val oldMaster = shield.masterApiToken
        val pending = shield.createPendingPairRequest("Laptop", "192.168.1.10", "DEV-ABC")
        val (_, clientTok) = shield.approvePendingPairRequest(pending.requestId)
        assertTrue(shield.verifyToken(clientTok!!, "192.168.1.10"))

        val newMaster = shield.rotateMasterTokenAndRevokeAll()
        assertNotEquals(oldMaster, newMaster)
        assertFalse(shield.verifyToken(oldMaster, "127.0.0.1"))
        assertFalse(shield.verifyToken(clientTok, "192.168.1.10"))
        assertTrue(shield.verifyToken(newMaster, "127.0.0.1"))
        assertTrue(shield.listPairedDevices().isEmpty())
    }

    @Test
    fun `markApprovedPairTokenDelivered permits retry polls and verifyToken scrubs pending token on first use`() {
        val pending = shield.createPendingPairRequest("Termux", "127.0.0.1", "SEC-DEV-RETRY")
        val (approved, token) = shield.approvePendingPairRequest(pending.requestId)
        assertTrue(approved)
        assertNotNull(token)

        shield.markApprovedPairTokenDelivered(pending.requestId)
        val retryPoll = shield.getPendingPairRequestForPoll(pending.requestId, "SEC-DEV-RETRY")
        assertEquals(token, retryPoll?.clientToken)

        assertTrue(shield.verifyToken(token!!, "127.0.0.1"))
        assertNull(shield.getPendingPairRequestForPoll(pending.requestId, "SEC-DEV-RETRY")?.clientToken)
    }
}
