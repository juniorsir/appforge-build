package com.kavach.ui.overlay

import android.content.Context
import android.graphics.Rect
import androidx.test.core.app.ApplicationProvider
import com.kavach.accessibility.AccessibilityRepositoryImpl
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class AgyHudOverlayManagerTest {

    private lateinit var context: Context
    private lateinit var floatingOverlayManager: FloatingOverlayManager
    private lateinit var hudManager: AgyHudOverlayManager
    private val broadcastedCommands = mutableListOf<JSONObject>()

    @Before
    fun setUp() {
        context = ApplicationProvider.getApplicationContext()
        floatingOverlayManager = FloatingOverlayManager(context)
        broadcastedCommands.clear()
        hudManager = AgyHudOverlayManager(
            context = context,
            floatingOverlayManager = floatingOverlayManager,
            onCommandBroadcast = { cmd -> broadcastedCommands.add(cmd) }
        )
    }

    @Test
    fun `updateState parses tasks, question, autoCollapseSeconds, and screenWatch wireframe`() {
        val payload = JSONObject().apply {
            put("state", "WORKING")
            put("title", "Configure Termux Bridge")
            put("currentAction", "Tapping Connect button")
            put("nextAction", "Verify WebSocket live")
            put("autoCollapseSeconds", 5)
            put("tasks", JSONArray().apply {
                put(JSONObject().put("id", "t1").put("label", "Inspect screen").put("status", "done"))
                put(JSONObject().put("id", "t2").put("label", "Tap Connect").put("status", "doing"))
                put(JSONObject().put("id", "t3").put("label", "Verify reply").put("status", "pending"))
            })
            put("screenWatch", JSONObject().apply {
                put("active", true)
                put("label", "Settings Screen")
                put("screenWidth", 1080)
                put("screenHeight", 2400)
                put("zones", JSONArray().apply {
                    put(
                        JSONObject()
                            .put("x1", 700).put("y1", 400)
                            .put("x2", 1000).put("y2", 520)
                            .put("role", "target").put("tag", "Connect")
                    )
                })
                put(
                    "actionVector",
                    JSONObject()
                        .put("type", "TAP")
                        .put("x1", 850).put("y1", 460)
                        .put("x2", 850).put("y2", 460)
                )
            })
        }

        val res = hudManager.updateState(payload)
        assertTrue(res.optBoolean("success"))
        assertEquals("WORKING", res.optString("state"))
        assertEquals(3, res.optInt("taskCount"))
        assertTrue(res.optBoolean("screenWatchActive"))

        val stored = hudManager.hudState.value
        assertEquals("Configure Termux Bridge", stored.title)
        assertEquals(5, stored.autoCollapseSeconds)
        assertEquals("done", stored.tasks[0].status)
        assertEquals("doing", stored.tasks[1].status)
        assertEquals("pending", stored.tasks[2].status)
        assertTrue(stored.screenWatch.active)
        assertEquals(1, stored.screenWatch.zones.size)
        assertNotNull(stored.screenWatch.actionVector)
        assertEquals("TAP", stored.screenWatch.actionVector?.type)
    }

    @Test
    fun `remote PROMPT and STOP commands broadcast over WS callback and drain via poll`() {
        val promptRes = hudManager.handleRemoteCommand(
            JSONObject().put("action", "PROMPT").put("text", "List files in Termux")
        )
        assertTrue(promptRes.optBoolean("success"))

        val stopRes = hudManager.handleRemoteCommand(
            JSONObject().put("action", "STOP")
        )
        assertTrue(stopRes.optBoolean("success"))

        assertEquals(2, broadcastedCommands.size)
        assertEquals("HUD_COMMAND", broadcastedCommands[0].optString("type"))
        assertEquals("PROMPT", broadcastedCommands[0].optString("action"))
        assertEquals("List files in Termux", broadcastedCommands[0].optString("text"))
        assertEquals("STOP", broadcastedCommands[1].optString("action"))

        val poll1 = hudManager.pollCommands()
        assertTrue(poll1.optBoolean("success"))
        assertEquals(2, poll1.optInt("count"))
        val cmds = poll1.getJSONArray("commands")
        assertEquals("PROMPT", cmds.getJSONObject(0).optString("action"))
        assertEquals("STOP", cmds.getJSONObject(1).optString("action"))

        // Second poll should be empty (atomic drain)
        val poll2 = hudManager.pollCommands()
        assertEquals(0, poll2.optInt("count"))
    }

    @Test
    fun `accessibility repository self-excludes agy_hud_ prefixed nodes`() {
        val repo = AccessibilityRepositoryImpl()
        assertTrue(repo.isAgyHudIdentifier("com.kavach:id/agy_hud_window2", null))
        assertTrue(repo.isAgyHudIdentifier(null, "agy_hud_prompt_input"))
        assertTrue(repo.isAgyHudIdentifier("AGY_HUD_WIREFRAME", null))
        assertFalse(repo.isAgyHudIdentifier("com.termux:id/terminal_view", "Terminal"))
    }

    @Test
    fun `touch collision overlap detects TAP and SWIPE intersecting overlay bounds`() {
        val hudRect = listOf(Rect(650, 1800, 1050, 2320))
        // TAP inside HUD
        assertTrue(hudManager.coordinatesOverlapRects(800f, 2000f, 800f, 2000f, hudRect))
        // TAP outside HUD
        assertFalse(hudManager.coordinatesOverlapRects(200f, 400f, 200f, 400f, hudRect))
        // SWIPE crossing through HUD
        assertTrue(hudManager.coordinatesOverlapRects(500f, 2100f, 950f, 2100f, hudRect))
        // SWIPE completely above HUD
        assertFalse(hudManager.coordinatesOverlapRects(100f, 500f, 900f, 500f, hudRect))
    }

    @Test
    fun `mini wireframe view collapses to 0dp when screenWatch is inactive`() {
        val wf = MiniScreenWireframeView(context)
        wf.updateScreenWatch(
            AgyHudOverlayManager.ScreenWatchState(active = false),
            wireframeVisible = true
        )
        assertEquals(android.view.View.GONE, wf.visibility)
        wf.measure(
            android.view.View.MeasureSpec.makeMeasureSpec(400, android.view.View.MeasureSpec.AT_MOST),
            android.view.View.MeasureSpec.makeMeasureSpec(400, android.view.View.MeasureSpec.AT_MOST)
        )
        assertEquals(0, wf.measuredHeight)
        assertEquals(0, wf.measuredWidth)

        wf.updateScreenWatch(
            AgyHudOverlayManager.ScreenWatchState(
                active = true,
                screenWidth = 1080,
                screenHeight = 2400
            ),
            wireframeVisible = true
        )
        assertEquals(android.view.View.VISIBLE, wf.visibility)
        wf.measure(
            android.view.View.MeasureSpec.makeMeasureSpec(400, android.view.View.MeasureSpec.AT_MOST),
            android.view.View.MeasureSpec.makeMeasureSpec(400, android.view.View.MeasureSpec.AT_MOST)
        )
        assertTrue(wf.measuredHeight > 0)
        assertTrue(wf.measuredWidth > 0)
    }

    @Test
    fun `app icon resolver maps yt, youtube, whatsapp, chrome, termux, and generic tasks cleanly`() {
        val ytShort = AgyAppIconResolver.resolve(context, explicitIcon = "yt", explicitPackage = "", fallbackText = "")
        assertEquals(AgyAppIconResolver.BadgeKind.YOUTUBE, ytShort.kind)
        assertEquals("com.google.android.youtube", ytShort.packageName)

        val ytText = AgyAppIconResolver.resolve(context, explicitIcon = "", explicitPackage = "", fallbackText = "Open YouTube playlist")
        assertEquals(AgyAppIconResolver.BadgeKind.YOUTUBE, ytText.kind)

        val wa = AgyAppIconResolver.resolve(context, explicitIcon = "", explicitPackage = "", fallbackText = "Send WhatsApp summary")
        assertEquals(AgyAppIconResolver.BadgeKind.WHATSAPP, wa.kind)

        val chrome = AgyAppIconResolver.resolve(context, explicitIcon = "chrome", explicitPackage = "", fallbackText = "")
        assertEquals(AgyAppIconResolver.BadgeKind.CHROME, chrome.kind)

        val termux = AgyAppIconResolver.resolve(context, explicitIcon = "", explicitPackage = "", fallbackText = "Run bash script in Termux")
        assertEquals(AgyAppIconResolver.BadgeKind.TERMUX, termux.kind)

        val fallback = AgyAppIconResolver.resolve(context, explicitIcon = "", explicitPackage = "", fallbackText = "General assistance")
        assertEquals(AgyAppIconResolver.BadgeKind.SPARK_AI, fallback.kind)
    }

    @Test
    fun `updateState parses detailedOutput, outputLogs, quickActions, and per-task icon metadata`() {
        val payload = JSONObject().apply {
            put("state", "DONE")
            put("title", "YouTube Automation")
            put("icon", "youtube")
            put("appPackage", "com.google.android.youtube")
            put("currentAction", "Queued 4 videos")
            put("detailedOutput", "Added 4 AI & Android talks to Watch Later.")
            put("outputLogs", JSONArray().apply {
                put("[12:01:02] Opened YouTube")
                put("[12:01:05] Saved 4 videos")
            })
            put("quickActions", JSONArray().apply {
                put(JSONObject().put("label", "Copy Output").put("actionType", "COPY_OUTPUT"))
                put(JSONObject().put("label", "Run Again").put("commandText", "Run YouTube task again").put("actionType", "PROMPT"))
            })
            put("tasks", JSONArray().apply {
                put(
                    JSONObject()
                        .put("id", "t1")
                        .put("label", "Open YouTube")
                        .put("status", "done")
                        .put("icon", "yt")
                        .put("appPackage", "com.google.android.youtube")
                        .put("detail", "com.google.android.youtube")
                )
            })
        }

        val res = hudManager.updateState(payload)
        assertTrue(res.optBoolean("success"))

        val stored = hudManager.hudState.value
        assertEquals("youtube", stored.icon)
        assertEquals("com.google.android.youtube", stored.appPackage)
        assertEquals("Added 4 AI & Android talks to Watch Later.", stored.detailedOutput)
        assertEquals(2, stored.outputLogs.size)
        assertEquals(2, stored.quickActions.size)
        assertEquals("COPY_OUTPUT", stored.quickActions[0].actionType)
        assertEquals("yt", stored.tasks[0].icon)
        assertEquals("com.google.android.youtube", stored.tasks[0].appPackage)
        assertEquals("com.google.android.youtube", stored.tasks[0].detail)

        val copyText = hudManager.getFullOutputCopyText(stored)
        assertTrue(copyText.contains("Added 4 AI & Android talks"))
        assertTrue(copyText.contains("[12:01:02] Opened YouTube"))
    }

    @Test
    fun `TOGGLE_OUTPUT command toggles expanded drawer and formatElapsed formats seconds and minutes`() {
        assertFalse(hudManager.isOutputExpandedFlow.value)

        val toggleOn = hudManager.handleRemoteCommand(JSONObject().put("action", "TOGGLE_OUTPUT"))
        assertTrue(toggleOn.optBoolean("success"))
        assertTrue(hudManager.isOutputExpandedFlow.value)

        val toggleOff = hudManager.handleRemoteCommand(JSONObject().put("action", "TOGGLE_OUTPUT"))
        assertTrue(toggleOff.optBoolean("success"))
        assertFalse(hudManager.isOutputExpandedFlow.value)

        assertEquals("00:00.0", hudManager.formatElapsed(0L))
        assertEquals("00:04.2", hudManager.formatElapsed(4200L))
        assertEquals("01:05", hudManager.formatElapsed(65_000L))
        assertEquals("Done 4.2s", hudManager.formatElapsed(4200L, isDone = true))
    }

    @Test
    fun `collapsed live running pill resolves dynamic step, icon, and preserves collapse across WORKING updates`() {
        // 1. Entering WORKING from IDLE auto-expands the HUD
        hudManager.updateState(
            JSONObject().apply {
                put("state", "WORKING")
                put("title", "Focus Automation")
                put("currentAction", "Opening YouTube")
                put("tasks", JSONArray().apply {
                    put(
                        JSONObject()
                            .put("id", "s1")
                            .put("label", "Open YouTube & search playlist")
                            .put("status", "doing")
                            .put("icon", "youtube")
                            .put("appPackage", "com.google.android.youtube")
                    )
                    put(
                        JSONObject()
                            .put("id", "s2")
                            .put("label", "Scroll Chrome & extract summary")
                            .put("status", "pending")
                            .put("icon", "chrome")
                    )
                })
            }
        )
        assertFalse(hudManager.isCollapsedFlow.value)
        assertFalse(hudManager.isCollapsedLiveRunningMode())

        // 2. User collapses HUD during active run -> enters live running step pill mode
        hudManager.handleRemoteCommand(JSONObject().put("action", "COLLAPSE"))
        assertTrue(hudManager.isCollapsedFlow.value)
        assertTrue(hudManager.isCollapsedLiveRunningMode())

        val step1 = hudManager.resolveCollapsedRunningStep()
        assertEquals("Open YouTube & search playlist", step1.label)
        assertEquals(AgyAppIconResolver.BadgeKind.YOUTUBE, step1.icon.kind)

        // 3. Subsequent WORKING telemetry update preserves collapsed state & dynamically updates step + icon
        hudManager.updateState(
            JSONObject().apply {
                put("state", "WORKING")
                put("title", "Focus Automation")
                put("currentAction", "Scrolling Chrome article")
                put("tasks", JSONArray().apply {
                    put(JSONObject().put("id", "s1").put("label", "Open YouTube & search playlist").put("status", "done").put("icon", "youtube"))
                    put(
                        JSONObject()
                            .put("id", "s2")
                            .put("label", "Scroll Chrome & extract summary")
                            .put("status", "doing")
                            .put("icon", "chrome")
                            .put("appPackage", "com.android.chrome")
                    )
                })
            }
        )
        assertTrue(hudManager.isCollapsedFlow.value)
        assertTrue(hudManager.isCollapsedLiveRunningMode())

        val step2 = hudManager.resolveCollapsedRunningStep()
        assertEquals("Scroll Chrome & extract summary", step2.label)
        assertEquals(AgyAppIconResolver.BadgeKind.CHROME, step2.icon.kind)

        // 4. Fallback to currentAction when no doing task exists
        val fallbackStep = hudManager.resolveCollapsedRunningStep(
            AgyHudOverlayManager.AgyHudState(
                state = "WORKING",
                title = "Background Sync",
                currentAction = "Sending WhatsApp report",
                tasks = emptyList()
            )
        )
        assertEquals("Sending WhatsApp report", fallbackStep.label)
        assertEquals(AgyAppIconResolver.BadgeKind.WHATSAPP, fallbackStep.icon.kind)

        // 5. NEEDS_INPUT expands card and exits collapsed live running mode
        hudManager.updateState(
            JSONObject().apply {
                put("state", "NEEDS_INPUT")
                put("title", "Confirm Share")
                put("question", "Send link now?")
            }
        )
        assertFalse(hudManager.isCollapsedFlow.value)
        assertFalse(hudManager.isCollapsedLiveRunningMode())
    }

    @Test
    fun `PAUSE and RESUME transition state cleanly, preserve collapsed live mode, and broadcast commands`() {
        hudManager.updateState(
            JSONObject().apply {
                put("state", "WORKING")
                put("title", "Deploy Pipeline")
                put("currentAction", "Uploading APK artifact")
                put("tasks", JSONArray().apply {
                    put(JSONObject().put("id", "p1").put("label", "Upload APK").put("status", "doing").put("icon", "termux"))
                })
            }
        )
        hudManager.handleRemoteCommand(JSONObject().put("action", "COLLAPSE"))
        assertTrue(hudManager.isCollapsedLiveRunningMode())

        // Pause via remote command
        val pauseRes = hudManager.handleRemoteCommand(JSONObject().put("action", "PAUSE"))
        assertTrue(pauseRes.optBoolean("success"))
        assertEquals("PAUSED", hudManager.hudState.value.state)
        assertTrue(hudManager.isCollapsedFlow.value)
        assertTrue(hudManager.isCollapsedLiveRunningMode())
        assertTrue(broadcastedCommands.any { it.optString("action") == "PAUSE" })

        // Quick actions while paused should expose Resume
        val pausedActions = hudManager.resolveQuickActions(hudManager.hudState.value)
        assertTrue(pausedActions.any { it.actionType == "RESUME" })

        // Resume via quick action chip
        val resumeChip = pausedActions.first { it.actionType == "RESUME" }
        hudManager.executeQuickAction(resumeChip)
        assertEquals("WORKING", hudManager.hudState.value.state)
        assertTrue(hudManager.isCollapsedLiveRunningMode())
        assertTrue(broadcastedCommands.any { it.optString("action") == "RESUME" })
    }

    @Test
    fun `TOGGLE_EDGE_SNAP toggles magnetic edge-snap state and setPinnedMacros updates flow`() {
        assertTrue(hudManager.edgeSnapEnabledFlow.value)

        val offRes = hudManager.handleRemoteCommand(JSONObject().put("action", "TOGGLE_EDGE_SNAP"))
        assertTrue(offRes.optBoolean("success"))
        assertFalse(hudManager.edgeSnapEnabledFlow.value)

        val onRes = hudManager.handleRemoteCommand(JSONObject().put("action", "TOGGLE_EDGE_SNAP"))
        assertTrue(onRes.optBoolean("success"))
        assertTrue(hudManager.edgeSnapEnabledFlow.value)

        val shortcuts = listOf(
            AgyHudOverlayManager.MacroShortcut("m1", "YouTube Focus", "Open YouTube lofi", "youtube"),
            AgyHudOverlayManager.MacroShortcut("m2", "Termux Status", "Check termux daemon", "termux")
        )
        hudManager.setPinnedMacros(shortcuts)
        assertEquals(2, hudManager.pinnedMacrosFlow.value.size)
        assertEquals("YouTube Focus", hudManager.pinnedMacrosFlow.value[0].title)
    }

    @Test
    fun `onRunRecorded fires automatically on DONE completion and on STOP during active run`() {
        val recorded = mutableListOf<AgyHudOverlayManager.RunRecord>()
        val recordingManager = AgyHudOverlayManager(
            context = context,
            floatingOverlayManager = floatingOverlayManager,
            onRunRecorded = { recorded.add(it) }
        )

        // Start a run via prompt + WORKING -> DONE
        recordingManager.enqueueAndBroadcastCommand("Summarize Chrome tabs", "PROMPT")
        recordingManager.updateState(
            JSONObject().apply {
                put("state", "WORKING")
                put("title", "Chrome Summary")
                put("icon", "chrome")
                put("tasks", JSONArray().apply {
                    put(JSONObject().put("id", "t1").put("label", "Read tabs").put("status", "doing"))
                })
            }
        )
        recordingManager.updateState(
            JSONObject().apply {
                put("state", "DONE")
                put("title", "Chrome Summary")
                put("icon", "chrome")
                put("detailedOutput", "Summarized 5 open tabs cleanly.")
                put("outputLogs", JSONArray().put("[00:01] Done"))
                put("tasks", JSONArray().apply {
                    put(JSONObject().put("id", "t1").put("label", "Read tabs").put("status", "done"))
                })
            }
        )
        assertEquals(1, recorded.size)
        assertEquals("DONE", recorded[0].finalState)
        assertEquals("Chrome Summary", recorded[0].title)
        assertEquals("Summarize Chrome tabs", recorded[0].promptText)
        assertTrue(recorded[0].detailedOutput.contains("Summarized 5 open tabs"))

        // Second run stopped mid-flight -> records STOPPED entry
        recordingManager.enqueueAndBroadcastCommand("Run backup script", "PROMPT")
        recordingManager.updateState(
            JSONObject().apply {
                put("state", "WORKING")
                put("title", "Backup Script")
                put("icon", "termux")
            }
        )
        recordingManager.enqueueAndBroadcastCommand("STOP", "STOP")
        assertEquals(2, recorded.size)
        assertEquals("STOPPED", recorded[1].finalState)
        assertEquals("Backup Script", recorded[1].title)
    }

    @Test
    fun `unified single-HUD OPEN_INPUT, CLOSE_INPUT, EXPAND, and COLLAPSE synchronize card and composer state`() {
        // Start collapsed
        hudManager.handleRemoteCommand(JSONObject().put("action", "COLLAPSE"))
        assertTrue(hudManager.isCollapsedFlow.value)
        assertFalse(hudManager.isInputVisible.value)

        // OPEN_INPUT expands the unified card and activates the built-in bottom composer
        val openRes = hudManager.handleRemoteCommand(JSONObject().put("action", "OPEN_INPUT"))
        assertTrue(openRes.optBoolean("success"))
        assertFalse(hudManager.isCollapsedFlow.value)
        assertTrue(hudManager.isInputVisible.value)

        // CLOSE_INPUT releases composer focus without forcing a second window
        val closeRes = hudManager.handleRemoteCommand(JSONObject().put("action", "CLOSE_INPUT"))
        assertTrue(closeRes.optBoolean("success"))
        assertFalse(hudManager.isInputVisible.value)

        // EXPAND shows the unified card (including built-in bottom composer)
        hudManager.handleRemoteCommand(JSONObject().put("action", "COLLAPSE"))
        assertTrue(hudManager.isCollapsedFlow.value)
        val expandRes = hudManager.handleRemoteCommand(JSONObject().put("action", "EXPAND"))
        assertTrue(expandRes.optBoolean("success"))
        assertFalse(hudManager.isCollapsedFlow.value)
        assertTrue(hudManager.isInputVisible.value)

        // COLLAPSE folds unified card back to compact pill and clears input focus flag
        val collapseRes = hudManager.handleRemoteCommand(JSONObject().put("action", "COLLAPSE"))
        assertTrue(collapseRes.optBoolean("success"))
        assertTrue(hudManager.isCollapsedFlow.value)
        assertFalse(hudManager.isInputVisible.value)
    }

    @Test
    fun `aurora card layout supports INPUT_ACTIVE, VOICE_LISTENING, and emerald completion pulse cleanly`() {
        val card = AgyAuroraCardLayout(context)
        card.setRimMode(AgyAuroraCardLayout.RimMode.INPUT_ACTIVE)
        card.setRimMode(AgyAuroraCardLayout.RimMode.VOICE_LISTENING)
        card.setRimMode(AgyAuroraCardLayout.RimMode.WORKING)
        card.setRimMode(AgyAuroraCardLayout.RimMode.DONE)
        card.playCompletionPulse()
        card.setRimMode(AgyAuroraCardLayout.RimMode.IDLE)

        // Measure and dispatch draw to a bitmap canvas to ensure custom glow halo & rim rendering never throws
        card.measure(
            android.view.View.MeasureSpec.makeMeasureSpec(320, android.view.View.MeasureSpec.EXACTLY),
            android.view.View.MeasureSpec.makeMeasureSpec(240, android.view.View.MeasureSpec.EXACTLY)
        )
        card.layout(0, 0, 320, 240)
        val bmp = android.graphics.Bitmap.createBitmap(320, 240, android.graphics.Bitmap.Config.ARGB_8888)
        val canvas = android.graphics.Canvas(bmp)
        card.setRimMode(AgyAuroraCardLayout.RimMode.INPUT_ACTIVE)
        card.draw(canvas)
        card.setRimMode(AgyAuroraCardLayout.RimMode.VOICE_LISTENING)
        card.draw(canvas)
        card.setRimMode(AgyAuroraCardLayout.RimMode.DONE)
        card.playCompletionPulse()
        card.draw(canvas)
        assertTrue(card.width == 320 && card.height == 240)
    }

    @Test
    fun `opaque default opacity, temporary suppression, and drawn glyph buttons work cleanly`() {
        // Default opacity should be 100% crisp opaque so underlying screen text never bleeds through
        assertEquals(1.0f, AgyHudOverlayManager.OPACITY_LEVELS[0], 0.001f)

        // Temporary suppression for Simulator modal should toggle cleanly without crashing
        hudManager.setTemporarilySuppressed(true)
        hudManager.setTemporarilySuppressed(false)

        // All 5 custom Canvas-drawn composer glyphs should measure, layout, and draw cleanly
        val bmp = android.graphics.Bitmap.createBitmap(64, 64, android.graphics.Bitmap.Config.ARGB_8888)
        val canvas = android.graphics.Canvas(bmp)
        AgyGlyphButtonView.Glyph.values().forEach { glyph ->
            val btn = AgyGlyphButtonView(context, glyph)
            btn.setStyle(
                glyph = glyph,
                bgFill = android.graphics.Color.parseColor("#FFF0F4F9"),
                bgStroke = android.graphics.Color.parseColor("#FFD2E3FC"),
                iconTint = android.graphics.Color.parseColor("#FF1A73E8")
            )
            btn.measure(
                android.view.View.MeasureSpec.makeMeasureSpec(64, android.view.View.MeasureSpec.EXACTLY),
                android.view.View.MeasureSpec.makeMeasureSpec(64, android.view.View.MeasureSpec.EXACTLY)
            )
            btn.layout(0, 0, 64, 64)
            btn.draw(canvas)
            assertEquals(64, btn.width)
            assertEquals(64, btn.height)
        }
    }

    @Test
    fun `two-stage Stop transitions WORKING to STOPPING on first tap and FORCE_STOP to STOPPED on second tap with single history record`() {
        val recorded = mutableListOf<AgyHudOverlayManager.RunRecord>()
        val cmds = mutableListOf<JSONObject>()
        val mgr = AgyHudOverlayManager(
            context = context,
            floatingOverlayManager = floatingOverlayManager,
            onCommandBroadcast = { cmds.add(it) },
            onRunRecorded = { recorded.add(it) }
        )

        mgr.updateState(
            JSONObject().apply {
                put("state", "WORKING")
                put("title", "Long Build")
                put("currentAction", "Compiling module")
                put("tasks", JSONArray().apply {
                    put(JSONObject().put("id", "t1").put("label", "Prepare").put("status", "done"))
                    put(JSONObject().put("id", "t2").put("label", "Compile").put("status", "doing"))
                })
            }
        )
        assertEquals("WORKING", mgr.hudState.value.state)

        // Tap 1: STOP -> immediate STOPPING state + broadcasts STOP
        val res1 = mgr.handleRemoteCommand(JSONObject().put("action", "STOP"))
        assertTrue(res1.optBoolean("success"))
        assertEquals("STOPPING", mgr.hudState.value.state)
        assertEquals(1, cmds.size)
        assertEquals("STOP", cmds[0].optString("action"))

        // Tap 2 while STOPPING -> FORCE_STOP -> immediate STOPPED locally, doing task marked stopped, single history record
        val res2 = mgr.handleRemoteCommand(JSONObject().put("action", "STOP"))
        assertTrue(res2.optBoolean("success"))
        assertEquals("STOPPED", mgr.hudState.value.state)
        assertEquals(2, cmds.size)
        assertEquals("FORCE_STOP", cmds[1].optString("action"))
        assertEquals("done", mgr.hudState.value.tasks[0].status)
        assertEquals("stopped", mgr.hudState.value.tasks[1].status)
        assertEquals(1, recorded.size)
        assertEquals("STOPPED", recorded[0].finalState)
    }

    @Test
    fun `graceful Agy confirmation from STOPPING transitions cleanly to DONE`() {
        hudManager.updateState(
            JSONObject()
                .put("state", "WORKING")
                .put("title", "Sync Task")
                .put("currentAction", "Uploading")
        )
        hudManager.handleRemoteCommand(JSONObject().put("action", "STOP"))
        assertEquals("STOPPING", hudManager.hudState.value.state)

        // Agy finishes gracefully and confirms DONE
        hudManager.updateState(
            JSONObject()
                .put("state", "DONE")
                .put("title", "Sync Task")
                .put("currentAction", "Gracefully cancelled and cleaned up")
        )
        assertEquals("DONE", hudManager.hudState.value.state)
        assertEquals("Gracefully cancelled and cleaned up", hudManager.hudState.value.currentAction)
    }

    @Test
    fun `full dynamic schema parses theme, layout, progress, metrics, banner, blocks, custom status, and styled quickActions`() {
        val payload = JSONObject().apply {
            put("state", "WORKING")
            put("statusLabel", "Deploying")
            put("customEmoji", "🚀")
            put("timerVisible", true)
            put("customTimerText", "ETA 12s")
            put("title", "Dynamic Dark Build")
            put("currentAction", "Pushing release bundle")
            put("theme", JSONObject().apply {
                put("mode", "dark")
                put("accentColor", "#38BDF8")
                put("auroraColors", JSONArray().put("#38BDF8").put("#8B5CF6"))
                put("auroraEnabled", true)
                put("cornerRadiusDp", 20)
                put("opacity", 0.92)
            })
            put("layout", JSONObject().apply {
                put("collapsed", false)
                put("detailsExpanded", true)
                put("showComposer", true)
                put("showMic", false)
                put("showMacros", false)
                put("showStopButton", true)
                put("inputPlaceholder", "Send override…")
                put("position", "top")
                put("widthFraction", 0.86)
            })
            put("progress", JSONObject().apply {
                put("visible", true)
                put("value", 62.5)
                put("label", "Chunks 5/8")
                put("color", "#38BDF8")
            })
            put("metrics", JSONArray().apply {
                put(JSONObject().put("id", "cpu").put("label", "CPU").put("value", "41%").put("accentColor", "#38BDF8"))
                put(JSONObject().put("id", "ram").put("label", "RAM").put("value", "1.2GB"))
            })
            put("banner", JSONObject().apply {
                put("visible", true)
                put("level", "warning")
                put("title", "Rate Limit")
                put("message", "Backing off 2s")
            })
            put("blocks", JSONArray().apply {
                put(JSONObject().apply {
                    put("id", "b_kv")
                    put("type", "kv")
                    put("title", "Target")
                    put("items", JSONArray().put(JSONObject().put("key", "Env").put("value", "Prod")))
                })
                put(JSONObject().apply {
                    put("id", "b_code")
                    put("type", "code")
                    put("body", "echo ok")
                    put("inDetails", true)
                })
            })
            put("buttons", JSONArray().apply {
                put(JSONObject()
                    .put("id", "btn_boost")
                    .put("label", "Boost")
                    .put("style", "primary")
                    .put("actionType", "CUSTOM")
                    .put("payload", JSONObject().put("workers", 8)))
            })
        }

        val res = hudManager.updateState(payload)
        assertTrue(res.optBoolean("success"))

        val s = hudManager.hudState.value
        assertEquals("Deploying", s.statusLabel)
        assertEquals("🚀", s.customEmoji)
        assertEquals("ETA 12s", s.customTimerText)
        assertEquals("dark", s.theme.mode)
        assertEquals("#38BDF8", s.theme.accentColor)
        assertEquals(20f, s.theme.cornerRadiusDp ?: 0f, 0.01f)
        assertEquals(0.92f, s.theme.opacity ?: 0f, 0.01f)
        assertFalse(s.layout.showMic)
        assertEquals("Send override…", s.layout.inputPlaceholder)
        assertEquals("top", s.layout.position)
        assertTrue(s.progress.visible)
        assertEquals(62.5f, s.progress.value, 0.01f)
        assertEquals(2, s.metrics.size)
        assertEquals("41%", s.metrics[0].value)
        assertTrue(s.banner.visible)
        assertEquals("warning", s.banner.level)
        assertEquals(2, s.blocks.size)
        assertEquals("kv", s.blocks[0].type)
        assertTrue(s.blocks[1].inDetails)
        assertEquals(1, s.quickActions.size)
        assertEquals("btn_boost", s.quickActions[0].id)
        assertEquals("primary", s.quickActions[0].style)

        // Roundtrip serialization check
        val roundtrip = hudManager.parseHudStateFromJson(s.toJson())
        assertEquals(s.statusLabel, roundtrip.statusLabel)
        assertEquals(s.customEmoji, roundtrip.customEmoji)
        assertEquals(s.theme.mode, roundtrip.theme.mode)
        assertEquals(s.progress.value, roundtrip.progress.value, 0.01f)
        assertEquals(s.metrics.size, roundtrip.metrics.size)
        assertEquals(s.blocks.size, roundtrip.blocks.size)
    }

    @Test
    fun `patchState applies surgical partial updates without wiping untouched fields and resetState restores defaults`() {
        hudManager.updateState(
            JSONObject().apply {
                put("state", "WORKING")
                put("title", "Data Pipeline")
                put("currentAction", "Stage 1")
                put("theme", JSONObject().put("mode", "dark").put("accentColor", "#8B5CF6"))
                put("tasks", JSONArray().apply {
                    put(JSONObject().put("id", "s1").put("label", "Extract").put("status", "doing"))
                    put(JSONObject().put("id", "s2").put("label", "Transform").put("status", "pending"))
                })
                put("metrics", JSONArray().apply {
                    put(JSONObject().put("id", "rows").put("label", "Rows").put("value", "100"))
                })
                put("outputLogs", JSONArray().put("[00:01] Started"))
            }
        )

        // Patch progress, upsertTask, appendLog, upsertMetric, setBanner, upsertBlock, setTheme, setLayout
        val patchRes = hudManager.patchState(
            JSONObject().apply {
                put("setProgress", JSONObject().put("visible", true).put("value", 75).put("label", "75% complete"))
                put("upsertTask", JSONObject().put("id", "s1").put("label", "Extract").put("status", "done"))
                put("appendLogs", JSONArray().put("[00:02] Extracted").put("[00:03] Transforming"))
                put("upsertMetric", JSONObject().put("id", "rows").put("label", "Rows").put("value", "420"))
                put("setBanner", JSONObject().put("visible", true).put("level", "success").put("message", "Halfway!"))
                put("upsertBlock", JSONObject().put("id", "blk1").put("type", "text").put("body", "Streaming OK"))
                put("setTheme", JSONObject().put("cornerRadiusDp", 18))
                put("setLayout", JSONObject().put("inputPlaceholder", "Filter rows…"))
            }
        )
        assertTrue(patchRes.optBoolean("success"))

        val patched = hudManager.hudState.value
        // Untouched fields preserved!
        assertEquals("Data Pipeline", patched.title)
        assertEquals("dark", patched.theme.mode)
        assertEquals("#8B5CF6", patched.theme.accentColor)
        // Patched fields applied!
        assertEquals(18f, patched.theme.cornerRadiusDp ?: 0f, 0.01f)
        assertEquals("Filter rows…", patched.layout.inputPlaceholder)
        assertEquals(75f, patched.progress.value, 0.01f)
        assertEquals("done", patched.tasks.first { it.id == "s1" }.status)
        assertEquals(2, patched.tasks.size)
        assertEquals(3, patched.outputLogs.size)
        assertEquals("420", patched.metrics.first { it.id == "rows" }.value)
        assertTrue(patched.banner.visible)
        assertEquals(1, patched.blocks.size)

        // Remove task + removeMetric + clearWidgets
        hudManager.patchState(
            JSONObject()
                .put("removeTask", "s2")
                .put("removeMetric", "rows")
                .put("clearWidgets", true)
        )
        assertEquals(1, hudManager.hudState.value.tasks.size)
        assertTrue(hudManager.hudState.value.metrics.isEmpty())
        assertFalse(hudManager.hudState.value.banner.visible)
        assertTrue(hudManager.hudState.value.blocks.isEmpty())

        // Reset restores clean default state (Apple Liquid Glass Dark)
        val resetRes = hudManager.resetState()
        assertTrue(resetRes.optBoolean("success"))
        assertEquals("IDLE", hudManager.hudState.value.state)
        assertEquals("dark", hudManager.hudState.value.theme.mode)
    }

    @Test
    fun `executeQuickAction on custom styled button broadcasts HUD_COMMAND with buttonId and payload`() {
        val chip = AgyHudOverlayManager.QuickActionChip(
            label = "Boost Workers",
            commandText = "boost_workers",
            actionType = "CUSTOM",
            id = "btn_boost_8",
            style = "primary",
            payload = JSONObject().put("workers", 8).put("priority", "high")
        )
        hudManager.executeQuickAction(chip)

        assertEquals(1, broadcastedCommands.size)
        val cmd = broadcastedCommands[0]
        assertEquals("HUD_COMMAND", cmd.optString("type"))
        assertEquals("CUSTOM", cmd.optString("action"))
        assertEquals("btn_boost_8", cmd.optString("buttonId"))
        val payloadObj = cmd.optJSONObject("payload")
        assertNotNull(payloadObj)
        assertEquals(8, payloadObj?.optInt("workers"))
        assertEquals("high", payloadObj?.optString("priority"))
    }

    @Test
    fun `weighted AgyAppIconResolver avoids generic verb hijacks and resolves ActionKind sub-badges`() {
        val chess = AgyAppIconResolver.resolve(
            context = context,
            fallbackText = "Write a python script to play chess"
        )
        assertEquals(AgyAppIconResolver.BadgeKind.CHESS, chess.kind)
        assertEquals("com.chess", chess.packageName)

        val yt = AgyAppIconResolver.resolve(
            context = context,
            fallbackText = "Open YouTube and watch lo-fi video",
            actionKindHint = "playing"
        )
        assertEquals(AgyAppIconResolver.BadgeKind.YOUTUBE, yt.kind)
        assertEquals(AgyAppIconResolver.ActionKind.PLAYING, yt.actionKind)

        val cam = AgyAppIconResolver.resolve(
            context = context,
            fallbackText = "Take a photo with camera"
        )
        assertEquals(AgyAppIconResolver.BadgeKind.CAMERA, cam.kind)

        val nonTermux = AgyAppIconResolver.resolve(
            context = context,
            explicitPackage = "com.chess",
            fallbackText = "python script",
            actionKindHint = "coding"
        )
        assertEquals(AgyAppIconResolver.BadgeKind.CHESS, nonTermux.kind)
        assertEquals(AgyAppIconResolver.ActionKind.CODING, nonTermux.actionKind)

        // Render AgyIconBadgeView with corner sub-badge onto a Bitmap Canvas
        val badgeView = AgyIconBadgeView(context)
        badgeView.setIcon(nonTermux, subBadgeRingColor = android.graphics.Color.WHITE)
        badgeView.measure(
            android.view.View.MeasureSpec.makeMeasureSpec(68, android.view.View.MeasureSpec.EXACTLY),
            android.view.View.MeasureSpec.makeMeasureSpec(68, android.view.View.MeasureSpec.EXACTLY)
        )
        badgeView.layout(0, 0, 68, 68)
        val bmp = android.graphics.Bitmap.createBitmap(68, 68, android.graphics.Bitmap.Config.ARGB_8888)
        badgeView.draw(android.graphics.Canvas(bmp))
        assertEquals(68, badgeView.width)
    }

    @Test
    fun `AgyTaskMapView measures and draws chess, media, telemetry, and app_pane modes cleanly`() {
        val theme = AgyHudDynamicModels.resolveTheme(
            AgyHudDynamicModels.HudThemeConfig(mode = "dark"),
            android.graphics.Color.parseColor("#0095F6")
        )
        val view = AgyTaskMapView(context)
        val bmp = android.graphics.Bitmap.createBitmap(340, 420, android.graphics.Bitmap.Config.ARGB_8888)
        val canvas = android.graphics.Canvas(bmp)

        val configs = listOf(
            AgyHudDynamicModels.TaskMapConfig(
                active = true,
                mode = "chess",
                title = "Chess",
                chess = AgyHudDynamicModels.ChessTaskMapData(
                    fen = "rnbqkbnr/pppppppp/8/8/4P3/8/PPPP1PPP/RNBQKBNR",
                    playerColor = "black",
                    evalCp = "-1.2",
                    lastMove = AgyHudDynamicModels.ChessMoveSquare("e2", "e4"),
                    bestMove = AgyHudDynamicModels.ChessMoveSquare("c7", "c5"),
                    turnLabel = "Black to move"
                )
            ),
            AgyHudDynamicModels.TaskMapConfig(
                active = true,
                mode = "media",
                title = "YouTube",
                media = AgyHudDynamicModels.MediaTaskMapData(
                    provider = "youtube",
                    title = "Lofi Beats Stream",
                    subtitle = "Lofi Girl",
                    appPackage = "com.google.android.youtube",
                    progressPercent = 45f,
                    elapsedText = "1:20",
                    durationText = "3:00",
                    playing = true
                )
            ),
            AgyHudDynamicModels.TaskMapConfig(
                active = true,
                mode = "telemetry",
                title = "APK Audit",
                telemetry = AgyHudDynamicModels.TelemetryTaskMapData(
                    title = "Permissions Scan",
                    percent = 72f,
                    accentColor = "#7C3AED",
                    metrics = listOf("Risk" to "Low", "SDK" to "35")
                )
            ),
            AgyHudDynamicModels.TaskMapConfig(
                active = true,
                mode = "app_pane",
                title = "Settings",
                paneMode = "pane",
                splitLabel = "SPLIT R • 90°",
                paneBounds = AgyHudDynamicModels.TaskMapPaneBounds(1200, 0, 2400, 1080, 2400, 1080),
                appPane = AgyHudDynamicModels.AppPaneTaskMapData(
                    targetPackage = "com.android.settings",
                    screenWidth = 2400,
                    screenHeight = 1080,
                    zones = listOf(
                        AgyHudDynamicModels.TaskMapZone(1240f, 80f, 2340f, 180f, "search_bar", "Search"),
                        AgyHudDynamicModels.TaskMapZone(1240f, 240f, 2340f, 340f, "toggle", "Wi-Fi", checked = true),
                        AgyHudDynamicModels.TaskMapZone(1900f, 420f, 2300f, 520f, "target", "Connect")
                    ),
                    actionVector = AgyHudDynamicModels.TaskMapActionVector("TAP", 2100f, 470f, 2100f, 470f)
                )
            )
        )

        configs.forEach { cfg ->
            view.updateTaskMap(cfg, theme)
            view.measure(
                android.view.View.MeasureSpec.makeMeasureSpec(340, android.view.View.MeasureSpec.EXACTLY),
                android.view.View.MeasureSpec.makeMeasureSpec(420, android.view.View.MeasureSpec.AT_MOST)
            )
            assertTrue(view.measuredWidth == 340)
            assertTrue(view.measuredHeight > 0)
            view.layout(0, 0, view.measuredWidth, view.measuredHeight)
            view.draw(canvas)
        }
    }

    @Test
    fun `AgyTaskMapOverlayManager opacity cycler, collapse, pane toggle, hide and HUD exclusion work cleanly`() {
        val taskMapMgr = AgyTaskMapOverlayManager(context)
        assertEquals(1.00f, taskMapMgr.opacityFlow.value, 0.001f)
        taskMapMgr.cycleOpacity()
        assertEquals(0.85f, taskMapMgr.opacityFlow.value, 0.001f)
        taskMapMgr.cycleOpacity()
        assertEquals(0.65f, taskMapMgr.opacityFlow.value, 0.001f)
        taskMapMgr.cycleOpacity()
        assertEquals(1.00f, taskMapMgr.opacityFlow.value, 0.001f)

        assertFalse(taskMapMgr.isCollapsedFlow.value)
        taskMapMgr.toggleCollapse()
        assertTrue(taskMapMgr.isCollapsedFlow.value)
        taskMapMgr.toggleCollapse()
        assertFalse(taskMapMgr.isCollapsedFlow.value)

        taskMapMgr.updateTaskMap(
            AgyHudDynamicModels.TaskMapConfig(
                active = true,
                mode = "app_pane",
                paneMode = "pane",
                paneBounds = AgyHudDynamicModels.TaskMapPaneBounds(0, 0, 540, 2400, 1080, 2400)
            ),
            AgyHudDynamicModels.HudThemeConfig()
        )
        assertEquals("pane", taskMapMgr.taskMapStateFlow.value.paneMode)
        taskMapMgr.togglePaneOrSize()
        assertEquals("full", taskMapMgr.taskMapStateFlow.value.paneMode)
        taskMapMgr.hideMap()
        assertFalse(taskMapMgr.isMapVisibleFlow.value)

        val repo = AccessibilityRepositoryImpl()
        assertTrue(repo.isAgyHudIdentifier(AgyTaskMapOverlayManager.TASK_MAP_NODE_TAG, null))
        assertTrue(repo.isAgyHudIdentifier(null, AgyPointerOverlayManager.POINTER_NODE_TAG))
    }

    @Test
    fun `HUD parses taskMap, actionKind, pointerShowLabel, and converts legacy screenWatch cleanly`() {
        val pointerMgr = AgyPointerOverlayManager(context)
        val taskMapMgr = AgyTaskMapOverlayManager(context)
        val integratedHud = AgyHudOverlayManager(
            context = context,
            floatingOverlayManager = floatingOverlayManager
        ).apply {
            pointerOverlayManager = pointerMgr
            taskMapOverlayManager = taskMapMgr
        }

        val res = integratedHud.updateState(
            JSONObject().apply {
                put("state", "WORKING")
                put("title", "Play Chess")
                put("actionKind", "playing")
                put("pointerEnabled", true)
                put("pointerShowLabel", false)
                put("taskMap", JSONObject().apply {
                    put("active", true)
                    put("mode", "chess")
                    put("splitLabel", "PORTRAIT")
                    put("chess", JSONObject().apply {
                        put("fen", "rnbqkbnr/pppppppp/8/8/4P3/8/PPPP1PPP/RNBQKBNR")
                        put("playerColor", "white")
                        put("evalCp", "+0.3")
                    })
                })
            }
        )
        assertTrue(res.optBoolean("success"))
        assertFalse(res.optBoolean("pointerShowLabel"))
        assertFalse(pointerMgr.isShowLabelEnabled())
        assertEquals("playing", integratedHud.hudState.value.actionKind)
        assertTrue(integratedHud.hudState.value.taskMap.active)
        assertEquals("chess", integratedHud.hudState.value.taskMap.mode)
        assertEquals("chess", taskMapMgr.taskMapStateFlow.value.mode)

        // Switching to DONE automatically clears active TaskMap
        integratedHud.updateState(JSONObject().put("state", "DONE").put("title", "Game Finished"))
        assertFalse(taskMapMgr.isMapVisibleFlow.value)
    }

    @Test
    fun `ResultsTaskMapData parses images, videos, files, base64 URIs, and persists across DONE`() {
        val payload = JSONObject().apply {
            put("state", "WORKING")
            put("title", "Who is Miya?")
            put("results", JSONObject().apply {
                put("query", "who is miya")
                put("summaryTitle", "Miya")
                put("summaryText", "Miya is an AI researcher and digital artist known for generative visuals.")
                put("sourceLabel", "3 items")
                put("loading", false)
                put("items", JSONArray().apply {
                    put(JSONObject().put("id", "i1").put("title", "Portrait").put("uri", "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNk+A8AAQUBAScY42YAAAAASUVORK5CYII="))
                    put(JSONObject().put("id", "v1").put("title", "Keynote Clip").put("uri", "https://example.org/miya_talk.mp4"))
                    put(JSONObject().put("id", "f1").put("title", "Bio Notes").put("uri", "/sdcard/Download/miya_bio.pdf").put("fileSizeLabel", "420 KB"))
                })
            })
        }

        val res = hudManager.updateState(payload)
        assertTrue(res.optBoolean("success"))
        assertTrue(res.optBoolean("taskMapActive"))
        val tm = hudManager.hudState.value.taskMap
        assertEquals("results", tm.mode)
        assertTrue(tm.persistOnDone)
        assertEquals(224f, tm.widthDp, 0.01f)
        val results = tm.results
        assertNotNull(results)
        assertEquals(3, results?.items?.size)
        assertEquals("image", results?.items?.get(0)?.kind)
        assertEquals("video", results?.items?.get(1)?.kind)
        assertEquals("file", results?.items?.get(2)?.kind)
        assertEquals("PDF", AgyResultsMediaLoader.fileExtensionBadge(results!!.items[2]))

        // Transitioning to DONE must preserve results TaskMap (persistOnDone = true)
        val doneRes = hudManager.updateState(
            JSONObject().put("state", "DONE").put("currentAction", "Found Miya profile & media")
        )
        assertTrue(doneRes.optBoolean("taskMapActive"))
        assertTrue(hudManager.hudState.value.taskMap.active)
        assertEquals("results", hudManager.hudState.value.taskMap.mode)
    }

    @Test
    fun `AgyResultsPanelView renders summary card, horizontal carousel navigation, and card click lightbox launch`() {
        val theme = AgyHudDynamicModels.resolveTheme(
            AgyHudDynamicModels.HudThemeConfig(mode = "light"),
            android.graphics.Color.parseColor("#0EA5E9")
        )
        val panel = AgyResultsPanelView(context)
        var clickedIndex = -1
        var clickedCount = 0
        panel.onItemClicked = { list, idx ->
            clickedCount = list.size
            clickedIndex = idx
        }

        val longSummary = "Miya is an AI researcher, speaker, and creator. ".repeat(5)
        val cfg = AgyHudDynamicModels.TaskMapConfig(
            active = true,
            mode = "results",
            title = "Who is Miya?",
            widthDp = 224f,
            results = AgyHudDynamicModels.ResultsTaskMapData(
                query = "Who is Miya?",
                summaryTitle = "Miya",
                summaryText = longSummary,
                sourceLabel = "3 items",
                items = listOf(
                    AgyHudDynamicModels.ResultMediaItem("1", "image", "Photo 1", "example.org", "https://example.org/1.jpg"),
                    AgyHudDynamicModels.ResultMediaItem("2", "video", "Talk Clip", "example.org", "https://example.org/2.mp4"),
                    AgyHudDynamicModels.ResultMediaItem("3", "file", "notes.txt", "Local file", "/sdcard/notes.txt", previewText = "Line 1\nLine 2")
                )
            )
        )

        panel.updateResults(cfg, theme)
        panel.measure(
            android.view.View.MeasureSpec.makeMeasureSpec(420, android.view.View.MeasureSpec.EXACTLY),
            android.view.View.MeasureSpec.makeMeasureSpec(900, android.view.View.MeasureSpec.AT_MOST)
        )
        panel.layout(0, 0, panel.measuredWidth, panel.measuredHeight)
        val bmp = android.graphics.Bitmap.createBitmap(420, panel.measuredHeight.coerceAtLeast(1), android.graphics.Bitmap.Config.ARGB_8888)
        panel.draw(android.graphics.Canvas(bmp))

        assertEquals(3, panel.getItemCount())
        assertEquals(0, panel.getCurrentIndex())
        panel.selectIndex(2, smooth = false)
        assertEquals(2, panel.getCurrentIndex())

        assertFalse(panel.isSummaryCardVisible())
        assertFalse(panel.isSummaryExpanded())
        panel.toggleSummaryExpanded()
        assertTrue(panel.isSummaryExpanded())

        val secondCard = panel.findViewWithTag<android.view.View>("${AgyHudOverlayManager.HUD_NODE_TAG_PREFIX}result_card_1")
        assertNotNull(secondCard)
        secondCard.performClick()
        assertEquals(3, clickedCount)
        assertEquals(1, clickedIndex)
    }

    @Test
    fun `AgyResultLightboxOverlay and results dismiss lifecycle exclude HUD tags cleanly`() {
        val repo = AccessibilityRepositoryImpl()
        assertTrue(repo.isAgyHudIdentifier(AgyResultLightboxOverlay.LIGHTBOX_NODE_TAG, null))
        assertTrue(repo.isAgyHudIdentifier(null, "${AgyHudOverlayManager.HUD_NODE_TAG_PREFIX}results_panel"))

        org.robolectric.shadows.ShadowSettings.setCanDrawOverlays(true)
        try {
            val taskMapMgr = AgyTaskMapOverlayManager(context)
            val hud = AgyHudOverlayManager(
                context = context,
                floatingOverlayManager = floatingOverlayManager
            ).apply {
                taskMapOverlayManager = taskMapMgr
            }

            hud.patchState(
                JSONObject()
                    .put("state", "WORKING")
                    .put("setResults", JSONObject()
                        .put("query", "who is miya")
                        .put("summaryTitle", "Miya")
                        .put("summaryText", "Creator & engineer")
                        .put("items", JSONArray().put(
                            JSONObject().put("id", "r1").put("kind", "image").put("title", "Miya").put("uri", "https://example.org/a.jpg")
                        )))
            )
            assertTrue(taskMapMgr.isMapVisibleFlow.value)

            // Upsert a second result item via patchState
            hud.patchState(
                JSONObject().put(
                    "upsertResultItem",
                    JSONObject().put("id", "r2").put("kind", "file").put("title", "CV.pdf").put("uri", "/sdcard/CV.pdf")
                )
            )
            assertEquals(2, taskMapMgr.taskMapStateFlow.value.results?.items?.size)

            // Transition to DONE keeps Window 3 visible
            hud.updateState(JSONObject().put("state", "DONE"))
            assertTrue(taskMapMgr.isMapVisibleFlow.value)

            // Open lightbox and step between items
            taskMapMgr.openLightbox(0)
            assertTrue(taskMapMgr.lightboxOverlay.isOpenFlow.value)
            assertEquals(0, taskMapMgr.lightboxOverlay.currentIndexFlow.value)
            taskMapMgr.lightboxOverlay.step(1)
            assertEquals(1, taskMapMgr.lightboxOverlay.currentIndexFlow.value)

            // User dismiss hides both Window 3 and lightbox, and subsequent identical state stays dismissed
            taskMapMgr.dismissByUser()
            assertFalse(taskMapMgr.isMapVisibleFlow.value)
            assertFalse(taskMapMgr.lightboxOverlay.isOpenFlow.value)
            hud.updateState(JSONObject().put("state", "DONE"))
            assertFalse(taskMapMgr.isMapVisibleFlow.value)

            // Plain text-only query stays in Main HUD (Window 3 remains hidden)
            hud.patchState(
                JSONObject().put(
                    "setResults",
                    JSONObject().put("query", "new topic").put("summaryText", "Fresh summary")
                )
            )
            assertFalse(taskMapMgr.isMapVisibleFlow.value)

            // A new visual media query replaces dismissed results and re-shows Window 3
            hud.patchState(
                JSONObject().put(
                    "setResults",
                    JSONObject()
                        .put("query", "new visual topic")
                        .put("items", JSONArray().put(
                            JSONObject().put("id", "r3").put("kind", "image").put("title", "Chart").put("uri", "https://example.org/chart.png")
                        ))
                )
            )
            assertTrue(taskMapMgr.isMapVisibleFlow.value)

            hud.resetState()
            assertFalse(taskMapMgr.isMapVisibleFlow.value)
        } finally {
            org.robolectric.shadows.ShadowSettings.setCanDrawOverlays(false)
        }
    }

    @Test
    fun `Apple Liquid Glass Dark is default and supports explicit light and custom overrides`() {
        val defaultTheme = AgyHudDynamicModels.resolveTheme(
            AgyHudDynamicModels.HudThemeConfig(),
            android.graphics.Color.parseColor("#0095F6")
        )
        assertTrue(defaultTheme.isDark)
        assertEquals(android.graphics.Color.parseColor("#FA0C1220"), defaultTheme.surface)
        assertEquals(android.graphics.Color.parseColor("#FF172136"), defaultTheme.secondarySurface)
        assertEquals(android.graphics.Color.parseColor("#F8FAFC"), defaultTheme.textPrimary)

        val lightTheme = AgyHudDynamicModels.resolveTheme(
            AgyHudDynamicModels.HudThemeConfig(mode = "light"),
            android.graphics.Color.parseColor("#0095F6")
        )
        assertFalse(lightTheme.isDark)
        assertEquals(android.graphics.Color.parseColor("#F5FFFFFF"), lightTheme.surface)

        val customTheme = AgyHudDynamicModels.resolveTheme(
            AgyHudDynamicModels.HudThemeConfig(
                mode = "custom",
                surfaceColor = "#121826",
                accentColor = "#7C3AED",
                textPrimaryColor = "#E2E8F0"
            ),
            android.graphics.Color.parseColor("#0095F6")
        )
        assertTrue(customTheme.isDark)
        assertEquals(android.graphics.Color.parseColor("#121826"), customTheme.surface)
        assertEquals(android.graphics.Color.parseColor("#7C3AED"), customTheme.accent)
        assertEquals(android.graphics.Color.parseColor("#E2E8F0"), customTheme.textPrimary)
    }

    @Test
    fun `AgyStatusOrbView, AgyWaveformBarsView, and AgyAnimatedCheckView measure, animate, and draw cleanly`() {
        val bmp = android.graphics.Bitmap.createBitmap(120, 120, android.graphics.Bitmap.Config.ARGB_8888)
        val canvas = android.graphics.Canvas(bmp)

        val orb = AgyStatusOrbView(context)
        listOf("IDLE", "WORKING", "NEEDS_INPUT", "DONE", "PAUSED", "STOPPING").forEach { st ->
            orb.setOrbState(st, android.graphics.Color.parseColor("#0095F6"), active = true)
            orb.measure(
                android.view.View.MeasureSpec.makeMeasureSpec(48, android.view.View.MeasureSpec.EXACTLY),
                android.view.View.MeasureSpec.makeMeasureSpec(48, android.view.View.MeasureSpec.EXACTLY)
            )
            orb.layout(0, 0, 48, 48)
            orb.draw(canvas)
        }
        orb.setOrbState("IDLE", android.graphics.Color.parseColor("#818CF8"), active = false)
        assertFalse(orb.isAnimating())

        val wave = AgyWaveformBarsView(context, barCount = 6)
        wave.setColors(
            android.graphics.Color.parseColor("#E11D48"),
            android.graphics.Color.parseColor("#8B5CF6")
        )
        wave.setAnimating(true)
        assertTrue(wave.isAnimating())
        wave.measure(
            android.view.View.MeasureSpec.makeMeasureSpec(80, android.view.View.MeasureSpec.EXACTLY),
            android.view.View.MeasureSpec.makeMeasureSpec(36, android.view.View.MeasureSpec.EXACTLY)
        )
        wave.layout(0, 0, 80, 36)
        wave.draw(canvas)
        wave.setAnimating(false)
        assertFalse(wave.isAnimating())
        wave.draw(canvas)

        val check = AgyAnimatedCheckView(context)
        listOf("pending", "doing", "done", "needs_input", "error").forEach { status ->
            check.setStatus(
                nextStatus = status,
                color = android.graphics.Color.parseColor("#0095F6"),
                animateCheck = (status == "done")
            )
            check.measure(
                android.view.View.MeasureSpec.makeMeasureSpec(36, android.view.View.MeasureSpec.EXACTLY),
                android.view.View.MeasureSpec.makeMeasureSpec(36, android.view.View.MeasureSpec.EXACTLY)
            )
            check.layout(0, 0, 36, 36)
            check.draw(canvas)
        }
    }

    @Test
    fun `AgyAuroraCardLayout sheen, AgyLoadingBarView shimmer, and new AgyAppleVectorIconView glyphs render without error`() {
        val bmp = android.graphics.Bitmap.createBitmap(320, 120, android.graphics.Bitmap.Config.ARGB_8888)
        val canvas = android.graphics.Canvas(bmp)

        val card = AgyAuroraCardLayout(context)
        card.applyDynamicTheme(
            surfaceColor = android.graphics.Color.parseColor("#E30B1120"),
            idleBorderColor = android.graphics.Color.parseColor("#3DFFFFFF"),
            accentColor = android.graphics.Color.parseColor("#0095F6"),
            customAuroraColors = null,
            auroraEnabled = true,
            cornerRadiusDp = 24f
        )
        card.setRimMode(AgyAuroraCardLayout.RimMode.WORKING)
        card.playSheenSweep()
        card.playCompletionPulse()
        card.measure(
            android.view.View.MeasureSpec.makeMeasureSpec(320, android.view.View.MeasureSpec.EXACTLY),
            android.view.View.MeasureSpec.makeMeasureSpec(120, android.view.View.MeasureSpec.EXACTLY)
        )
        card.layout(0, 0, 320, 120)
        card.draw(canvas)
        card.setRimMode(AgyAuroraCardLayout.RimMode.IDLE)
        card.stopAurora()

        val bar = AgyLoadingBarView(context)
        bar.setColors(
            accentColor = android.graphics.Color.parseColor("#0095F6"),
            trackColor = android.graphics.Color.parseColor("#29FFFFFF")
        )
        bar.setDeterminateProgress(null)
        bar.setAnimating(true)
        bar.measure(
            android.view.View.MeasureSpec.makeMeasureSpec(300, android.view.View.MeasureSpec.EXACTLY),
            android.view.View.MeasureSpec.makeMeasureSpec(12, android.view.View.MeasureSpec.EXACTLY)
        )
        bar.layout(0, 0, 300, 12)
        bar.draw(canvas)
        bar.setDeterminateProgress(0.68f)
        bar.draw(canvas)

        val iconView = AgyAppleVectorIconView(context)
        listOf(
            AgyAppleVectorIconView.IconType.ELLIPSIS,
            AgyAppleVectorIconView.IconType.SPARKLES,
            AgyAppleVectorIconView.IconType.SCISSORS,
            AgyAppleVectorIconView.IconType.CHEVRON_UP,
            AgyAppleVectorIconView.IconType.CHEVRON_DOWN,
            AgyAppleVectorIconView.IconType.STOP_SQUARE
        ).forEach { kind ->
            iconView.iconType = kind
            iconView.iconTint = android.graphics.Color.WHITE
            iconView.measure(
                android.view.View.MeasureSpec.makeMeasureSpec(48, android.view.View.MeasureSpec.EXACTLY),
                android.view.View.MeasureSpec.makeMeasureSpec(48, android.view.View.MeasureSpec.EXACTLY)
            )
            iconView.layout(0, 0, 48, 48)
            iconView.draw(canvas)
        }
    }
}
