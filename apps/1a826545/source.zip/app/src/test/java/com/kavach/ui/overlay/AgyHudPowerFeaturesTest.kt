package com.kavach.ui.overlay

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.view.View
import androidx.test.core.app.ApplicationProvider
import com.kavach.accessibility.AccessibilityRepositoryImpl
import com.kavach.accessibility.models.AccessibilityNodeModel
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows
import org.robolectric.annotation.Config
import java.time.Duration

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36], qualifiers = "w360dp-h800dp-xxhdpi")
class AgyHudPowerFeaturesTest {

    private lateinit var context: Context
    private lateinit var floatingOverlayManager: FloatingOverlayManager
    private lateinit var hudManager: AgyHudOverlayManager
    private lateinit var edgeManager: AgyEdgeHandleOverlayManager
    private lateinit var spotlightManager: AgySpotlightOverlayManager
    private lateinit var snipManager: AgyRegionSnipOverlayManager

    private val broadcastedCommands = mutableListOf<JSONObject>()
    private val savedMacros = mutableListOf<Triple<String, String, String>>()

    @Before
    fun setUp() {
        context = ApplicationProvider.getApplicationContext()
        floatingOverlayManager = FloatingOverlayManager(context)
        broadcastedCommands.clear()
        savedMacros.clear()
        edgeManager = AgyEdgeHandleOverlayManager(context)
        spotlightManager = AgySpotlightOverlayManager(context)
        snipManager = AgyRegionSnipOverlayManager(context)

        hudManager = AgyHudOverlayManager(
            context = context,
            floatingOverlayManager = floatingOverlayManager,
            onCommandBroadcast = { cmd -> broadcastedCommands.add(cmd) },
            onSaveMacro = { title, prompt, icon -> savedMacros.add(Triple(title, prompt, icon)) }
        ).apply {
            edgeHandleOverlayManager = edgeManager
            spotlightOverlayManager = spotlightManager
            regionSnipOverlayManager = snipManager
        }
    }

    // -------------------------------------------------------------------------
    // 1. Interactive Safety Approval Gate
    // -------------------------------------------------------------------------

    @Test
    fun `approval gate sets NEEDS_INPUT and emits APPROVAL_RESPONSE on approve and edit`() {
        val gateRes = hudManager.setApprovalGate(
            JSONObject().apply {
                put("id", "apr_shell_1")
                put("title", "Delete temporary folder?")
                put("description", "Removes 12 files in /sdcard/tmp")
                put("commandPreview", "rm -rf /sdcard/tmp")
                put("riskLevel", "high")
                put("allowEdit", true)
            }
        )
        assertTrue(gateRes.optBoolean("success"))
        assertTrue(gateRes.optBoolean("approvalActive"))
        assertEquals("NEEDS_INPUT", hudManager.hudState.value.state)
        assertEquals("high", hudManager.hudState.value.approvalGate.riskLevel)
        assertEquals("apr_shell_1", hudManager.hudState.value.approvalGate.id)

        val approveRes = hudManager.respondToApproval(decision = "approve")
        assertTrue(approveRes.optBoolean("success"))
        assertFalse(hudManager.hudState.value.approvalGate.active)

        val lastCmd = broadcastedCommands.last()
        assertEquals("APPROVAL_RESPONSE", lastCmd.optString("action"))
        assertEquals("apr_shell_1", lastCmd.optString("buttonId"))
        assertEquals("approve", lastCmd.optJSONObject("payload")?.optString("decision"))

        // Remote edit response via handleRemoteCommand
        hudManager.setApprovalGate(JSONObject().put("id", "apr_edit_2").put("title", "Run command"))
        val editRes = hudManager.handleRemoteCommand(
            JSONObject().apply {
                put("action", "APPROVAL_RESPONSE")
                put("approvalId", "apr_edit_2")
                put("decision", "edit")
                put("editedText", "ls -la /sdcard/tmp")
            }
        )
        assertTrue(editRes.optBoolean("success"))
        val editCmd = broadcastedCommands.last()
        assertEquals("APPROVAL_RESPONSE", editCmd.optString("action"))
        assertEquals("edit", editCmd.optJSONObject("payload")?.optString("decision"))
        assertEquals("ls -la /sdcard/tmp", editCmd.optJSONObject("payload")?.optString("editedText"))
    }

    @Test
    fun `approval gate countdown safely auto-denies when timeout expires`() {
        hudManager.setApprovalGate(
            JSONObject().apply {
                put("id", "apr_timeout_1")
                put("title", "Send payment")
                put("riskLevel", "high")
                put("timeoutSeconds", 2)
            }
        )
        assertTrue(hudManager.hudState.value.approvalGate.active)

        // Advance main looper past 2 seconds
        Shadows.shadowOf(context.mainLooper).idleFor(Duration.ofSeconds(3))

        assertFalse(hudManager.hudState.value.approvalGate.active)
        val denyCmd = broadcastedCommands.lastOrNull { it.optString("action") == "APPROVAL_RESPONSE" }
        assertNotNull(denyCmd)
        assertEquals("apr_timeout_1", denyCmd?.optJSONObject("payload")?.optString("approvalId"))
        assertEquals("deny", denyCmd?.optJSONObject("payload")?.optString("decision"))
    }

    // -------------------------------------------------------------------------
    // 2. Screen Region Snip to Ask
    // -------------------------------------------------------------------------

    @Test
    fun `region snip extracts intersecting UI nodes, filters HUD nodes, and attaches to next prompt`() {
        val sampleTree = listOf(
            AccessibilityNodeModel(
                text = null,
                contentDescription = null,
                viewId = "com.android.settings:id/root",
                className = "android.widget.FrameLayout",
                isClickable = false,
                isScrollable = false,
                isEditable = false,
                isFocused = false,
                bounds = "[0,0][1080,2400]",
                packageName = "com.android.settings",
                children = listOf(
                    AccessibilityNodeModel(
                        text = "Battery Saver",
                        contentDescription = null,
                        viewId = "com.android.settings:id/battery_saver",
                        className = "android.widget.TextView",
                        isClickable = true,
                        isScrollable = false,
                        isEditable = false,
                        isFocused = false,
                        bounds = "[100,400][600,520]",
                        packageName = "com.android.settings"
                    ),
                    AccessibilityNodeModel(
                        text = "HUD Secret Pill",
                        contentDescription = "agy_hud_collapsed_expand_btn",
                        viewId = "agy_hud_root",
                        className = "android.widget.TextView",
                        isClickable = true,
                        isScrollable = false,
                        isEditable = false,
                        isFocused = false,
                        bounds = "[120,410][500,500]",
                        packageName = "com.kavach"
                    ),
                    AccessibilityNodeModel(
                        text = "Outside Footer",
                        contentDescription = null,
                        viewId = "com.android.settings:id/footer",
                        className = "android.widget.TextView",
                        isClickable = false,
                        isScrollable = false,
                        isEditable = false,
                        isFocused = false,
                        bounds = "[100,1900][600,2050]",
                        packageName = "com.android.settings"
                    )
                )
            )
        )

        val ctx = AgyRegionSnipOverlayManager.extractNodesInRegion(
            roots = sampleTree,
            x1 = 80,
            y1 = 360,
            x2 = 640,
            y2 = 560,
            screenWidth = 1080,
            screenHeight = 2400
        )

        assertEquals("com.android.settings", ctx.packageName)
        assertEquals(1, ctx.nodes.size)
        assertEquals("Battery Saver", ctx.nodes.first().text)
        assertEquals(350, ctx.nodes.first().centerX)
        assertEquals(460, ctx.nodes.first().centerY)
        assertEquals("✂ Region (1 items)", ctx.summaryChipLabel())

        // Attach to HUD and submit a prompt -> payload.regionContext must be included and then cleared
        hudManager.attachRegionContext(ctx)
        assertNotNull(hudManager.attachedRegionContextFlow.value)

        val sendRes = hudManager.submitOrQueuePrompt("What does this toggle do?")
        assertTrue(sendRes.optBoolean("success"))
        assertFalse(sendRes.optBoolean("queued"))
        assertNull(hudManager.attachedRegionContextFlow.value)

        val cmd = broadcastedCommands.last()
        assertEquals("PROMPT", cmd.optString("action"))
        val attachedJson = cmd.optJSONObject("payload")?.optJSONObject("regionContext")
        assertNotNull(attachedJson)
        assertEquals(80, attachedJson?.optInt("x1"))
        assertEquals(1, attachedJson?.optJSONArray("nodes")?.length())

        // Attach region WITH cropped screenshot base64 -> summary label & JSON roundtrip include screenshot
        val sampleB64 = "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNk+A8AAQUBAScY42YAAAAASUVORK5CYII="
        val shotCtx = ctx.copy(
            screenshotBase64 = sampleB64,
            screenshotWidth = 560,
            screenshotHeight = 200,
            screenshotMimeType = "image/jpeg"
        )
        assertTrue(shotCtx.hasScreenshot)
        assertEquals("✂ Snip (1 items)", shotCtx.summaryChipLabel())
        val roundtrip = AgyHudDynamicModels.SnippedRegionContext.fromJson(shotCtx.toJson())
        assertEquals(sampleB64, roundtrip?.screenshotBase64)
        assertEquals(560, roundtrip?.screenshotWidth)
        assertEquals(200, roundtrip?.screenshotHeight)

        hudManager.attachRegionContext(shotCtx)
        hudManager.submitOrQueuePrompt("Describe this snipped screenshot")
        val shotCmd = broadcastedCommands.last()
        val shotRegion = shotCmd.optJSONObject("payload")?.optJSONObject("regionContext")
        assertEquals(sampleB64, shotRegion?.optString("screenshotBase64"))
        assertEquals(560, shotRegion?.optInt("screenshotWidth"))
    }

    // -------------------------------------------------------------------------
    // 3. Prompt Queue & One-Tap Run-to-Macro
    // -------------------------------------------------------------------------

    @Test
    fun `prompt queue buffers while WORKING, supports promote and remove, and auto-dispatches on DONE`() {
        hudManager.updateState(JSONObject().put("state", "WORKING").put("title", "Initial task"))
        broadcastedCommands.clear()

        val q1 = hudManager.submitOrQueuePrompt("First follow-up")
        val q2 = hudManager.submitOrQueuePrompt("Second follow-up")
        val q3 = hudManager.submitOrQueuePrompt("Third follow-up")
        assertTrue(q1.optBoolean("queued"))
        assertTrue(q2.optBoolean("queued"))
        assertTrue(q3.optBoolean("queued"))
        assertEquals(3, hudManager.queuedPromptsFlow.value.size)
        assertTrue(broadcastedCommands.isEmpty())

        // Promote #2 to top, remove #3
        val secondId = hudManager.queuedPromptsFlow.value[1].id
        val thirdId = hudManager.queuedPromptsFlow.value[2].id
        assertTrue(hudManager.promoteQueuedPrompt(secondId))
        assertEquals("Second follow-up", hudManager.queuedPromptsFlow.value.first().text)
        assertTrue(hudManager.removeQueuedPrompt(thirdId))
        assertEquals(2, hudManager.queuedPromptsFlow.value.size)

        // Transition to DONE -> auto-dequeue after grace delay
        hudManager.updateState(JSONObject().put("state", "DONE").put("title", "Initial task"))
        Shadows.shadowOf(context.mainLooper).idleFor(Duration.ofMillis(900))

        assertEquals(1, hudManager.queuedPromptsFlow.value.size)
        assertEquals("First follow-up", hudManager.queuedPromptsFlow.value.first().text)
        assertEquals(1, broadcastedCommands.size)
        assertEquals("Second follow-up", broadcastedCommands.first().optString("text"))
    }

    @Test
    fun `saveLastPromptAsMacro persists the most recent prompt via onSaveMacro callback`() {
        hudManager.submitOrQueuePrompt("Check battery temperature and top apps")
        hudManager.updateState(JSONObject().put("state", "DONE").put("title", "Battery Check").put("icon", "settings"))

        val saved = hudManager.saveLastPromptAsMacro()
        assertTrue(saved)
        assertEquals(1, savedMacros.size)
        assertEquals("Check battery temperature", savedMacros.first().first)
        assertEquals("Check battery temperature and top apps", savedMacros.first().second)
        assertEquals("settings", savedMacros.first().third)
    }

    // -------------------------------------------------------------------------
    // 4. App-Aware Smart Suggestion Chips
    // -------------------------------------------------------------------------

    @Test
    fun `smart suggestions adapt to foreground package and honor explicit overrides`() {
        val yt = AgySmartSuggestionsResolver.resolve("com.google.android.youtube")
        assertEquals(3, yt.size)
        assertTrue(yt.any { it.label.contains("Summarize", ignoreCase = true) })

        val chrome = AgySmartSuggestionsResolver.resolve("com.android.chrome")
        assertTrue(chrome.any { it.label.contains("TL;DR", ignoreCase = true) })

        val wa = AgySmartSuggestionsResolver.resolve("com.whatsapp")
        assertTrue(wa.any { it.label.contains("Draft reply", ignoreCase = true) })

        val chess = AgySmartSuggestionsResolver.resolve("com.chess")
        assertTrue(chess.any { it.label.contains("Best move", ignoreCase = true) })

        val termux = AgySmartSuggestionsResolver.resolve("com.termux")
        assertTrue(termux.any { it.label.contains("Explain output", ignoreCase = true) })

        val generic = AgySmartSuggestionsResolver.resolve(null)
        assertEquals(3, generic.size)

        // Explicit suggestions pushed via patchState override app defaults
        hudManager.foregroundPackageProvider = { "com.google.android.youtube" }
        hudManager.patchState(
            JSONObject().put(
                "setSuggestions",
                JSONArray().put(JSONObject().put("label", "Custom Tip").put("prompt", "Run custom check"))
            )
        )
        val effective = hudManager.resolveEffectiveSmartSuggestions()
        assertEquals(1, effective.size)
        assertEquals("Custom Tip", effective.first().label)
    }

    // -------------------------------------------------------------------------
    // 5. Edge Swipe Handle, Co-Pilot Spotlight, & Accessibility Self-Exclusion
    // -------------------------------------------------------------------------

    @Test
    fun `edge handle park and summon transitions update state cleanly`() {
        val parkRes = hudManager.handleRemoteCommand(JSONObject().put("action", "PARK_EDGE").put("side", "right"))
        assertTrue(parkRes.optBoolean("success"))
        assertTrue(hudManager.isEdgeParkedFlow.value)
        assertTrue(edgeManager.isVisibleFlow.value)

        val summonRes = hudManager.handleRemoteCommand(JSONObject().put("action", "SUMMON_EDGE").put("focus", true))
        assertTrue(summonRes.optBoolean("success"))
        assertFalse(hudManager.isEdgeParkedFlow.value)
        assertFalse(edgeManager.isVisibleFlow.value)
    }

    @Test
    fun `co-pilot spotlight parses targets, draws canvas cleanly, and clears on request`() {
        val spotRes = hudManager.setSpotlight(
            JSONObject().apply {
                put("title", "Wi-Fi Setup Guide")
                put("dimAlpha", 0.55)
                put(
                    "targets",
                    JSONArray()
                        .put(
                            JSONObject().apply {
                                put("x1", 120)
                                put("y1", 320)
                                put("x2", 900)
                                put("y2", 460)
                                put("label", "1. Tap Network & Internet")
                                put("stepNumber", 1)
                            }
                        )
                        .put(
                            JSONObject().apply {
                                put("x", 540)
                                put("y", 900)
                                put("radius", 80)
                                put("label", "2. Enable Wi-Fi toggle")
                                put("stepNumber", 2)
                                put("accentColor", "#16A34A")
                            }
                        )
                )
            }
        )
        assertTrue(spotRes.optBoolean("success"))
        assertTrue(spotRes.optBoolean("spotlightActive"))
        assertEquals(2, spotRes.optInt("targetCount"))
        assertTrue(spotlightManager.spotlightFlow.value.active)

        // Verify custom SpotlightCanvasView draws onto a Canvas without throwing
        val canvasView = AgySpotlightOverlayManager.SpotlightCanvasView(context)
        canvasView.setSpotlightConfig(spotlightManager.spotlightFlow.value)
        val widthSpec = View.MeasureSpec.makeMeasureSpec(1080, View.MeasureSpec.EXACTLY)
        val heightSpec = View.MeasureSpec.makeMeasureSpec(2400, View.MeasureSpec.EXACTLY)
        canvasView.measure(widthSpec, heightSpec)
        canvasView.layout(0, 0, 1080, 2400)
        val bmp = Bitmap.createBitmap(1080, 2400, Bitmap.Config.ARGB_8888)
        canvasView.draw(Canvas(bmp))
        bmp.recycle()

        val clearRes = hudManager.clearSpotlight()
        assertFalse(clearRes.optBoolean("spotlightActive"))
        assertFalse(spotlightManager.spotlightFlow.value.active)
    }

    @Test
    fun `accessibility repository excludes all new agy_hud power overlays from UI tree inspection`() {
        val repo = AccessibilityRepositoryImpl()
        assertTrue(repo.isAgyHudIdentifier(null, AgyRegionSnipOverlayManager.NODE_TAG))
        assertTrue(repo.isAgyHudIdentifier(null, AgyEdgeHandleOverlayManager.NODE_TAG))
        assertTrue(repo.isAgyHudIdentifier(null, AgySpotlightOverlayManager.NODE_TAG))
        assertTrue(repo.isAgyHudIdentifier(null, AgySpotlightOverlayManager.DISMISS_NODE_TAG))
        assertFalse(repo.isAgyHudIdentifier("com.android.settings:id/title", "Network & internet"))
    }
}
