package com.kavach.security

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import java.io.File

@RunWith(RobolectricTestRunner::class)
class AdultContentShieldManagerTest {

    private lateinit var context: Context
    private lateinit var shield: AdultContentShieldManager

    @Before
    fun setUp() {
        context = ApplicationProvider.getApplicationContext()
        context.getSharedPreferences("aero_adult_content_shield_prefs", Context.MODE_PRIVATE)
            .edit().clear().commit()
        shield = AdultContentShieldManager(context)
    }

    @Test
    fun `blocks adult reading manga stories and nsfw forum urls`() {
        val literotica = shield.evaluateUrlOrSearchQuery("https://www.literotica.com/s/sample-story", "com.android.chrome")
        assertTrue(literotica.blocked)
        assertEquals("READING_MANGA", literotica.channel)

        val nhentai = shield.evaluateUrlOrSearchQuery("https://nhentai.net/g/177013/", "com.android.chrome")
        assertTrue(nhentai.blocked)
        assertEquals("READING_MANGA", nhentai.channel)

        val redditNsfw = shield.evaluateUrlOrSearchQuery("https://www.reddit.com/r/gonewild/comments/123", "com.android.chrome")
        assertTrue(redditNsfw.blocked)
        assertEquals("READING_MANGA", redditNsfw.channel)

        val f95 = shield.evaluateUrlOrSearchQuery("https://f95zone.to/threads/game.123", "com.android.chrome")
        assertTrue(f95.blocked)
        assertEquals("READING_MANGA", f95.channel)
    }

    @Test
    fun `blocks explicit adult search queries while allowing safe scunthorpe words`() {
        val googlePornSearch = shield.evaluateUrlOrSearchQuery(
            "https://www.google.com/search?q=free+porn+videos&hl=en",
            "com.android.chrome"
        )
        assertTrue(googlePornSearch.blocked)
        assertEquals("SEARCH_QUERY", googlePornSearch.channel)

        val rawHentaiQuery = shield.evaluateRawSearchText("uncensored hentai manga")
        assertTrue(rawHentaiQuery.blocked)
        assertEquals("SEARCH_QUERY", rawHentaiQuery.channel)

        // Safe words containing substrings ("sex", "anal", "cum", "ass", "tit") must NOT be blocked
        val safeEssex = shield.evaluateRawSearchText("essex county weather and analytics document")
        assertFalse(safeEssex.blocked)

        val safeScunthorpe = shield.evaluateUrlOrSearchQuery("https://www.google.com/search?q=scunthorpe+united+assistant+manager")
        assertFalse(safeScunthorpe.blocked)
    }

    @Test
    fun `detects on-screen adult reading and store pages via live screen scanner`() {
        val screenReadingVerdict = shield.evaluateOnScreenContent(
            packageName = "org.mozilla.firefox",
            detectedUrl = "https://archive.example.org/work/123",
            detectedTitle = "Chapter 1 - Archive Warning: Explicit",
            focusedSearchText = "",
            screenTextSample = "Rating: Explicit. This work contains explicit sexual content and 18+ adult fiction."
        )
        assertTrue(screenReadingVerdict.blocked)
        assertEquals("READING_MANGA", screenReadingVerdict.channel)

        val installerVerdict = shield.evaluateOnScreenContent(
            packageName = "com.google.android.packageinstaller",
            detectedUrl = "",
            detectedTitle = "Install NHentai Viewer",
            focusedSearchText = "",
            screenTextSample = "Do you want to install this application?"
        )
        assertTrue(installerVerdict.blocked)
        assertEquals("APP_APK", installerVerdict.channel)
    }

    @Test
    fun `blocks adult packages and unauthorized bypass vpn apps`() {
        val adultApp = shield.evaluateInstalledOrLaunchingPackage("com.pornhub.app", "Pornhub")
        assertTrue(adultApp.blocked)
        assertEquals("APP_APK", adultApp.channel)

        val bypassVpn = shield.evaluateInstalledOrLaunchingPackage("com.psiphon3", "Psiphon Pro")
        assertTrue(bypassVpn.blocked)
        assertEquals("BYPASS_ATTEMPT", bypassVpn.channel)

        val torBrowser = shield.evaluateInstalledOrLaunchingPackage("org.torproject.torbrowser", "Tor Browser")
        assertTrue(torBrowser.blocked)
        assertEquals("BYPASS_ATTEMPT", torBrowser.channel)

        val safeCalculator = shield.evaluateInstalledOrLaunchingPackage("com.google.android.calculator", "Calculator")
        assertFalse(safeCalculator.blocked)
    }

    @Test
    fun `quarantines downloaded adult apk and manga files`() {
        val tempFile = File(context.cacheDir, "nhentai_reader_v2.apk")
        tempFile.writeText("dummy apk payload")
        assertTrue(tempFile.exists())

        val verdict = shield.inspectFileForAdultOrBypassContent(tempFile)
        assertTrue(verdict.blocked)
        assertEquals("APP_APK", verdict.channel)

        val qEntry = shield.quarantineFile(tempFile, verdict.reason, verdict.channel, "com.android.chrome")
        assertNotNull(qEntry)
        assertFalse("Original adult APK must be removed from original path", tempFile.exists())
        assertEquals(1, shield.getQuarantineListJson().optInt("count"))
    }

    @Test
    fun `rewrites google youtube and bing domains to safesearch vip ips`() {
        assertArrayEquals(
            AdultContentShieldManager.GOOGLE_SAFESEARCH_VIP,
            shield.getSafeSearchVipForDomain("www.google.com")
        )
        assertArrayEquals(
            AdultContentShieldManager.GOOGLE_SAFESEARCH_VIP,
            shield.getSafeSearchVipForDomain("www.google.co.in")
        )
        assertArrayEquals(
            AdultContentShieldManager.GOOGLE_SAFESEARCH_VIP,
            shield.getSafeSearchVipForDomain("m.youtube.com")
        )
        assertArrayEquals(
            AdultContentShieldManager.BING_SAFESEARCH_VIP,
            shield.getSafeSearchVipForDomain("www.bing.com")
        )
        assertArrayEquals(
            AdultContentShieldManager.DUCKDUCKGO_SAFESEARCH_VIP,
            shield.getSafeSearchVipForDomain("duckduckgo.com")
        )
        assertArrayEquals(
            AdultContentShieldManager.DUCKDUCKGO_SAFESEARCH_VIP,
            shield.getSafeSearchVipForDomain("html.duckduckgo.com")
        )
        assertNull(shield.getSafeSearchVipForDomain("wikipedia.org"))
    }

    @Test
    fun `catches leetspeak zero-width obfuscation adult ai generators and magnet links`() {
        // Leetspeak & zero-width obfuscated queries
        val leetQuery = shield.evaluateRawSearchText("u\u200Bncensored h3nt4i & p0rnhub videos")
        assertTrue(leetQuery.blocked)
        assertEquals("SEARCH_QUERY", leetQuery.channel)

        // NSFW AI generator & deepfake sites
        val aiRoleplay = shield.evaluateUrlOrSearchQuery("https://janitorai.com/characters/123", "com.android.chrome")
        assertTrue(aiRoleplay.blocked)

        val undressAi = shield.evaluateUrlOrSearchQuery("https://undress.ai/upload", "com.android.chrome")
        assertTrue(undressAi.blocked)
        assertEquals("WEB_VIDEO", undressAi.channel)

        // Adult torrent magnet URI
        val magnetVerdict = shield.evaluateUrlOrSearchQuery(
            "magnet:?xt=urn:btih:1234567890abcdef&dn=Uncensored+JAV+XXX+1080p",
            "com.android.chrome"
        )
        assertTrue(magnetVerdict.blocked)
    }

    @Test
    fun `blocks incognito tabs and unauthorized system settings tampering`() {
        // Incognito tab via UI node or marker text
        val incognitoVerdict = shield.evaluateOnScreenContent(
            packageName = "com.android.chrome",
            detectedUrl = "",
            detectedTitle = "New Incognito tab",
            focusedSearchText = "",
            screenTextSample = "You've gone Incognito. Now you can browse privately.",
            hasIncognitoUiNode = true
        )
        assertTrue(incognitoVerdict.blocked)
        assertEquals("BYPASS_ATTEMPT", incognitoVerdict.channel)

        // System Settings tampering with AeroShare (Force stop / Uninstall / VPN disconnect)
        val settingsTamperVerdict = shield.evaluateOnScreenContent(
            packageName = "com.android.settings",
            detectedUrl = "",
            detectedTitle = "App info",
            focusedSearchText = "",
            screenTextSample = "AeroShare Uninstall Force stop Clear storage"
        )
        assertTrue(settingsTamperVerdict.blocked)
        assertEquals("BYPASS_ATTEMPT", settingsTamperVerdict.channel)

        // Unlocking Admin maintenance window temporarily allows Settings access
        val unlockRes = shield.unlockAdminSession(pin = "1234", durationMinutes = 5)
        assertTrue(unlockRes.optBoolean("success"))
        assertTrue(shield.isAdminSessionTemporarilyUnlocked())

        val allowedAfterUnlock = shield.evaluateOnScreenContent(
            packageName = "com.android.settings",
            detectedUrl = "",
            detectedTitle = "App info",
            focusedSearchText = "",
            screenTextSample = "AeroShare Uninstall Force stop Clear storage"
        )
        assertFalse(allowedAfterUnlock.blocked)
    }

    @Test
    fun `scrubs adult urls and base64 encoded adult links from clipboard`() {
        val directClip = shield.inspectAndSanitizeClipboard("Check this out https://www.pornhub.com/view_video.php?viewkey=123")
        assertTrue(directClip.blocked)

        // Base64 encoded "https://nhentai.net/g/12345" -> "aHR0cHM6Ly9uaGVudGFpLm5ldC9nLzEyMzQ1"
        val base64Clip = shield.inspectAndSanitizeClipboard("Paste link: aHR0cHM6Ly9uaGVudGFpLm5ldC9nLzEyMzQ1")
        assertTrue(base64Clip.blocked)

        val safeClip = shield.inspectAndSanitizeClipboard("Meeting notes at https://docs.google.com/document/d/123")
        assertFalse(safeClip.blocked)
    }

    @Test
    fun `inspects disguised zip and cbz archives containing adult apks or manga without decompressing`() {
        val disguisedZip = File(context.cacheDir, "homework_notes_2026.zip")
        java.util.zip.ZipOutputStream(disguisedZip.outputStream()).use { zos ->
            zos.putNextEntry(java.util.zip.ZipEntry("readme.txt"))
            zos.write("benign text".toByteArray())
            zos.closeEntry()
            zos.putNextEntry(java.util.zip.ZipEntry("nested/f95zone_uncensored_game.apk"))
            zos.write("apk header".toByteArray())
            zos.closeEntry()
        }

        val verdict = shield.inspectFileForAdultOrBypassContent(disguisedZip)
        assertTrue(verdict.blocked)
        assertEquals("APP_APK", verdict.channel)
        disguisedZip.delete()
    }

    @Test
    fun `enforces admin pin lock when attempting to weaken or disable shield`() {
        // Attempt to disable without PIN must fail
        val deniedRes = shield.updateShieldPolicy(strictMode = false, pin = "wrong_pin")
        assertFalse(deniedRes.optBoolean("success"))
        assertTrue(deniedRes.optBoolean("requiresAdminAuth"))
        assertTrue(shield.strictModeEnabled)

        // Default PIN "1234" allows disabling
        val allowedRes = shield.updateShieldPolicy(strictMode = false, pin = "1234")
        assertTrue(allowedRes.optBoolean("success"))
        assertFalse(shield.strictModeEnabled)

        // Re-enabling does not require PIN
        val reEnableRes = shield.updateShieldPolicy(strictMode = true)
        assertTrue(reEnableRes.optBoolean("success"))
        assertTrue(shield.strictModeEnabled)

        // Set custom PIN "9876"
        val setPinRes = shield.setAdminPin("1234", "9876")
        assertTrue(setPinRes.optBoolean("success"))
        assertFalse(shield.verifyAdminPin("1234"))
        assertTrue(shield.verifyAdminPin("9876"))
    }
}
