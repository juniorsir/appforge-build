package com.kavach

import android.content.Context
import android.content.Intent
import android.os.Looper
import androidx.test.core.app.ApplicationProvider
import com.kavach.accessibility.AccessibilityRepositoryImpl
import com.kavach.data.repository.WebSocketRepositoryImpl
import com.kavach.services.RealtimeConnectionService
import com.kavach.util.AndroidLogger
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.cancelChildren
import kotlinx.coroutines.runBlocking
import okhttp3.OkHttpClient
import org.junit.After
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows
import org.robolectric.annotation.Config
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicReference

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class AppLifecycleCrashTest {

    @After
    fun tearDown() {
        val app = ApplicationProvider.getApplicationContext<BaseApplication>()
        runBlocking {
            try {
                app.container.webSocketRepository.disconnect()
            } catch (_: Throwable) {}
        }
        try {
            app.container.httpServer.stop()
        } catch (_: Throwable) {}
        try {
            app.container.applicationScope.coroutineContext.cancelChildren()
        } catch (_: Throwable) {}
        try {
            Shadows.shadowOf(Looper.getMainLooper()).idle()
        } catch (_: Throwable) {}
    }

    @Test
    fun `application and main activity launch cleanly without crashing`() {
        val app = ApplicationProvider.getApplicationContext<BaseApplication>()
        assertNotNull(app.container)

        val controller = Robolectric.buildActivity(MainActivity::class.java).setup()
        val activity = controller.get()
        assertNotNull(activity)
        controller.pause().stop().destroy()
    }

    @Test
    fun `app visibility sync does not crash when hidden persisted in background`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val prefs = context.getSharedPreferences("aero_visibility_prefs", Context.MODE_PRIVATE)
        prefs.edit().putBoolean("is_app_hidden", true).commit()

        val app = ApplicationProvider.getApplicationContext<BaseApplication>()
        app.container.appVisibilityManager.syncPersistedState(allowBridgeStart = false)
        assertTrue(app.container.appVisibilityManager.refreshState())

        // Restore default visibility state
        app.container.appVisibilityManager.setAppHidden(false, ensureBridgeService = false)
    }

    @Test
    fun `realtime connection service handles all actions and start_sticky null intent without RECORD_AUDIO permission`() {
        val serviceController = Robolectric.buildService(RealtimeConnectionService::class.java)
        val service = serviceController.create().get()

        // Null intent (START_STICKY process restart)
        service.onStartCommand(null, 0, 1)

        // Ensure bridge
        service.onStartCommand(Intent(service, RealtimeConnectionService::class.java).apply {
            action = RealtimeConnectionService.ACTION_ENSURE_BRIDGE
        }, 0, 2)

        // Connect
        service.onStartCommand(Intent(service, RealtimeConnectionService::class.java).apply {
            action = RealtimeConnectionService.ACTION_CONNECT
            putExtra(RealtimeConnectionService.EXTRA_SERVER_URL, "ws://127.0.0.1:8080/ws")
        }, 0, 3)

        // Start audio FGS WITHOUT RECORD_AUDIO granted (previously crashed with SecurityException on Android 14+)
        service.onStartCommand(Intent(service, RealtimeConnectionService::class.java).apply {
            action = RealtimeConnectionService.ACTION_START
            putExtra(RealtimeConnectionService.EXTRA_SERVER_URL, "ws://127.0.0.1:8080/ws")
        }, 0, 4)

        // Pause, resume, disconnect, stop
        service.onStartCommand(Intent(service, RealtimeConnectionService::class.java).apply {
            action = RealtimeConnectionService.ACTION_PAUSE
        }, 0, 5)
        service.onStartCommand(Intent(service, RealtimeConnectionService::class.java).apply {
            action = RealtimeConnectionService.ACTION_RESUME
        }, 0, 6)
        service.onStartCommand(Intent(service, RealtimeConnectionService::class.java).apply {
            action = RealtimeConnectionService.ACTION_DISCONNECT
        }, 0, 7)
        service.onStartCommand(Intent(service, RealtimeConnectionService::class.java).apply {
            action = RealtimeConnectionService.ACTION_STOP
        }, 0, 8)

        serviceController.destroy()
    }

    @Test
    fun `concurrent logging in WebSocketRepositoryImpl and AccessibilityRepositoryImpl is thread-safe`() {
        val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
        val wsRepo = WebSocketRepositoryImpl(
            client = OkHttpClient(),
            logger = AndroidLogger(),
            scope = scope
        )
        val a11yRepo = AccessibilityRepositoryImpl()

        val threads = 8
        val iterations = 150
        val executor = Executors.newFixedThreadPool(threads)
        val latch = CountDownLatch(threads)
        val failure = AtomicReference<Throwable?>(null)

        for (t in 0 until threads) {
            executor.submit {
                try {
                    for (i in 0 until iterations) {
                        wsRepo.addLog("thread-$t-msg-$i")
                        a11yRepo.addLog("a11y-$t-msg-$i")
                    }
                } catch (e: Throwable) {
                    failure.compareAndSet(null, e)
                } finally {
                    latch.countDown()
                }
            }
        }

        assertTrue("Concurrent logging timed out", latch.await(15, TimeUnit.SECONDS))
        executor.shutdownNow()
        scope.cancel()

        val err = failure.get()
        if (err != null) {
            throw AssertionError("Concurrent logging threw exception", err)
        }
        assertTrue(wsRepo.connectionLogs.value.isNotEmpty())
        assertTrue(a11yRepo.logs.value.isNotEmpty())
    }

    @Test
    fun `candidate discovery prioritizes authenticated tunnel and includes local fallback while skipping incomplete paths`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val prefs = context.getSharedPreferences("termux_bridge_prefs", Context.MODE_PRIVATE)
        prefs.edit()
            .putString("key_saved_url", "wss://private-relay-bridge.onrender.com/p/")
            .putString("key_last_auth_tunnel_url", "wss://private-relay-bridge.onrender.com/p/test-auth-key/ws")
            .commit()

        val candidates = RealtimeConnectionService.getCandidateUrls(context)
        assertTrue(candidates.contains("wss://private-relay-bridge.onrender.com/p/test-auth-key/ws"))
        assertTrue(candidates.contains(RealtimeConnectionService.LOCAL_WS_URL))
        assertTrue(candidates.none { it.trimEnd('/').endsWith("/p") || it.contains(":8080") })
        assertTrue(
            candidates.indexOf("wss://private-relay-bridge.onrender.com/p/test-auth-key/ws") <
                candidates.indexOf(RealtimeConnectionService.LOCAL_WS_URL)
        )

        prefs.edit().clear().commit()
    }

    @Test
    fun `webSocketRepository connectBestAvailable skips invalid endpoints and connects first valid candidate`() {
        val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
        val wsRepo = WebSocketRepositoryImpl(
            client = OkHttpClient(),
            logger = AndroidLogger(),
            scope = scope
        )

        runBlocking {
            wsRepo.connectBestAvailable(
                listOf(
                    "wss://private-relay-bridge.onrender.com/p/",
                    "ws://127.0.0.1:8080/ws",
                    "wss://private-relay-bridge.onrender.com/p/valid-key/ws",
                    "ws://127.0.0.1:8000/ws"
                )
            )
            assertTrue(
                wsRepo.activeUrlFlow.value == "wss://private-relay-bridge.onrender.com/p/valid-key/ws"
            )
            wsRepo.disconnect()
        }
        scope.cancel()
    }

    @Test
    fun `app visibility toggle synchronously disables LauncherAlias and reports synthetic icon status accurately`() {
        val app = ApplicationProvider.getApplicationContext<BaseApplication>()
        val manager = app.container.appVisibilityManager

        assertTrue(manager.setAppHidden(true, ensureBridgeService = false))
        val hiddenStatus = manager.getStatusJson()
        assertTrue(hiddenStatus.getBoolean("hidden"))
        assertTrue(hiddenStatus.getBoolean("osSyntheticIconFallback"))
        assertTrue(!hiddenStatus.getBoolean("fullyHidden"))
        assertTrue(manager.queryLauncherEntriesCount() == 0)

        assertTrue(manager.setAppHidden(false, ensureBridgeService = false))
        val visibleStatus = manager.getStatusJson()
        assertTrue(!visibleStatus.getBoolean("hidden"))
        assertTrue(visibleStatus.getBoolean("visible"))
        assertTrue(!visibleStatus.getBoolean("osSyntheticIconFallback"))
        assertTrue(manager.queryLauncherEntriesCount() >= 1)
    }
}
