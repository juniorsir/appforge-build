package com.kavach.ui.overlay

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Rect
import android.view.accessibility.AccessibilityNodeInfo
import androidx.test.core.app.ApplicationProvider
import com.kavach.accessibility.AccessibilityRepository
import com.kavach.accessibility.AccessibilityRepositoryImpl
import com.kavach.accessibility.AccessibilityServiceRegistry
import com.kavach.accessibility.models.AccessibilityEventModel
import com.kavach.accessibility.models.AccessibilityNodeModel
import com.kavach.accessibility.models.AccessibilityServiceStatus
import com.kavach.accessibility.models.GestureRequestModel
import com.kavach.hardware.DeviceBridgeManager
import com.kavach.hardware.DisplayPowerManager
import com.kavach.hardware.NetworkTelemetryManager
import com.kavach.hardware.VolumeManager
import com.kavach.ui.overlay.hud.HudStore
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import org.json.JSONObject
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.Mockito.mock
import org.mockito.Mockito.`when`
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class AgyPointerOverlayManagerTest {

    private lateinit var context: Context
    private lateinit var pointerManager: AgyPointerOverlayManager
    private lateinit var hudStore: HudStore
    private lateinit var accessibilityRepo: AccessibilityRepositoryImpl

    @Before
    fun setUp() {
        context = ApplicationProvider.getApplicationContext()
        pointerManager = AgyPointerOverlayManager(context)
        hudStore = HudStore(context = context).also {
            it.pointerOverlayManager = pointerManager
        }
        accessibilityRepo = AccessibilityRepositoryImpl().also {
            it.pointerVisualizer = pointerManager
        }
    }

    @After
    fun tearDown() {
        AccessibilityServiceRegistry.activeService = null
    }

    @Test
    fun `agy_hud_pointer tag is automatically excluded by AccessibilityRepositoryImpl self-exclusion filter`() {
        assertTrue(
            accessibilityRepo.isAgyHudIdentifier(
                viewId = null,
                contentDescription = AgyPointerOverlayManager.POINTER_NODE_TAG
            )
        )
        assertTrue(
            accessibilityRepo.isAgyHudIdentifier(
                viewId = "com.kavach:id/${AgyPointerOverlayManager.POINTER_NODE_TAG}",
                contentDescription = null
            )
        )

        val mockRoot = mock(AccessibilityNodeInfo::class.java)
        `when`(mockRoot.viewIdResourceName).thenReturn("com.termux:id/root")
        `when`(mockRoot.contentDescription).thenReturn("Termux Window")
        `when`(mockRoot.childCount).thenReturn(2)

        val pointerOverlayNode = mock(AccessibilityNodeInfo::class.java)
        `when`(pointerOverlayNode.viewIdResourceName).thenReturn(null)
        `when`(pointerOverlayNode.contentDescription).thenReturn("agy_hud_pointer")

        val realButtonNode = mock(AccessibilityNodeInfo::class.java)
        `when`(realButtonNode.viewIdResourceName).thenReturn("com.termux:id/play_btn")
        `when`(realButtonNode.text).thenReturn("Play")
        `when`(realButtonNode.isClickable).thenReturn(true)
        `when`(realButtonNode.childCount).thenReturn(0)

        `when`(mockRoot.getChild(0)).thenReturn(pointerOverlayNode)
        `when`(mockRoot.getChild(1)).thenReturn(realButtonNode)

        val converted = accessibilityRepo.convertNodeInfo(mockRoot)
        assertEquals(1, converted?.children?.size)
        assertEquals("Play", converted?.children?.first()?.text)
    }

    @Test
    fun `TAP, LONG_PRESS, SWIPE, INPUT_TEXT, and KEY actions update pointer overlay state via DeviceBridgeManager`() {
        val mockService = mock(AccessibilityService::class.java)
        AccessibilityServiceRegistry.activeService = mockService

        val capturedGestures = mutableListOf<GestureRequestModel>()
        val fakeRepo = object : AccessibilityRepository {
            override val serviceStatus = MutableStateFlow(AccessibilityServiceStatus(isEnabled = true))
            override val recentEvents = MutableStateFlow<List<AccessibilityEventModel>>(emptyList())
            override val logs = MutableStateFlow<List<String>>(emptyList())

            override fun triggerGesture(gesture: GestureRequestModel, onComplete: (Boolean) -> Unit) {
                capturedGestures.add(gesture)
                onComplete(true)
            }

            override fun clickNodeByText(text: String, onComplete: (Boolean) -> Unit) {
                pointerManager.showTap(620f, 880f, "Tap \"$text\"")
                onComplete(true)
            }

            override fun performScroll(forward: Boolean, onComplete: (Boolean) -> Unit) {
                pointerManager.showSwipe(500f, 1400f, 500f, 300f, 250L, if (forward) "Scroll Down" else "Scroll Up")
                onComplete(true)
            }

            override fun inputText(text: String, targetLabel: String?, onComplete: (Boolean) -> Unit) {
                pointerManager.showTyping(480f, 710f, text)
                onComplete(true)
            }

            override fun getFullNodeTree(): List<AccessibilityNodeModel> = emptyList()
            override fun searchNodes(text: String?, contentDescription: String?, viewId: String?): List<AccessibilityNodeModel> = emptyList()
            override fun addLog(message: String) {}
            override fun addEvent(event: AccessibilityEventModel) {}
        }

        val bridge = DeviceBridgeManager(
            context = context,
            accessibilityRepository = fakeRepo,
            displayPowerManager = mock(DisplayPowerManager::class.java),
            volumeManager = mock(VolumeManager::class.java),
            networkTelemetryManager = mock(NetworkTelemetryManager::class.java),
            agyHudOverlayManager = hudManager,
            agyPointerOverlayManager = pointerManager
        )

        // 1. TAP
        val tapRes = bridge.handleUiAction(JSONObject().put("action", "TAP").put("x", 320).put("y", 940))
        assertTrue(tapRes.optBoolean("success"))
        with(pointerManager.pointerStateFlow.value) {
            assertTrue(visible)
            assertEquals(AgyPointerOverlayManager.PointerMode.TAP, mode)
            assertEquals(320f, cursorX, 0.01f)
            assertEquals(940f, cursorY, 0.01f)
            assertEquals("Tap 320,940", label)
            assertFalse(isAmber)
        }

        // 2. LONG_PRESS (amber accent)
        bridge.handleUiAction(JSONObject().put("action", "LONG_PRESS").put("x", 410).put("y", 520))
        with(pointerManager.pointerStateFlow.value) {
            assertEquals(AgyPointerOverlayManager.PointerMode.LONG_PRESS, mode)
            assertTrue(isAmber)
            assertEquals("Long Press", label)
        }

        // 3. DRAG / SWIPE
        val dragRes = bridge.handleUiAction(
            JSONObject()
                .put("action", "DRAG")
                .put("x1", 200).put("y1", 1500)
                .put("x2", 1139).put("y2", 297)
        )
        assertTrue(dragRes.optBoolean("success"))
        with(pointerManager.pointerStateFlow.value) {
            assertEquals(AgyPointerOverlayManager.PointerMode.SWIPE, mode)
            assertEquals(200f, startX, 0.01f)
            assertEquals(1500f, startY, 0.01f)
            assertEquals(1139f, endX, 0.01f)
            assertEquals(297f, endY, 0.01f)
            assertEquals("Drag 1139,297", label)
        }

        // 4. CLICK_TEXT
        val clickTextRes = bridge.handleUiAction(JSONObject().put("action", "CLICK_TEXT").put("text", "Play"))
        assertTrue(clickTextRes.optBoolean("success"))
        with(pointerManager.pointerStateFlow.value) {
            assertEquals(AgyPointerOverlayManager.PointerMode.TAP, mode)
            assertEquals(620f, cursorX, 0.01f)
            assertEquals(880f, cursorY, 0.01f)
            assertEquals("Tap \"Play\"", label)
        }

        // 5. INPUT_TEXT
        val typeRes = bridge.handleUiAction(JSONObject().put("action", "INPUT_TEXT").put("text", "Lo-Fi Beats"))
        assertTrue(typeRes.optBoolean("success"))
        with(pointerManager.pointerStateFlow.value) {
            assertEquals(AgyPointerOverlayManager.PointerMode.TYPING, mode)
            assertEquals(480f, cursorX, 0.01f)
            assertEquals(710f, cursorY, 0.01f)
            assertTrue(label.contains("Typing"))
        }

        // 6. KEY keeps last cursor coordinate and displays Key badge
        val keyRes = bridge.handleUiAction(JSONObject().put("action", "KEY").put("key", "BACK"))
        assertTrue(keyRes.optBoolean("success"))
        with(pointerManager.pointerStateFlow.value) {
            assertEquals(AgyPointerOverlayManager.PointerMode.KEY_BADGE, mode)
            assertEquals(480f, cursorX, 0.01f)
            assertEquals(710f, cursorY, 0.01f)
            assertEquals("Key: BACK", label)
        }
        assertEquals(4, capturedGestures.size)
    }

    @Test
    fun `AccessibilityRepositoryImpl clickNodeByText resolves bounds center and triggers pointer tap`() {
        val mockService = mock(AccessibilityService::class.java)
        val rootNode = mock(AccessibilityNodeInfo::class.java)
        val playNode = mock(AccessibilityNodeInfo::class.java)

        `when`(playNode.text).thenReturn("Play")
        `when`(playNode.contentDescription).thenReturn("Play Video")
        `when`(playNode.viewIdResourceName).thenReturn("com.google.android.youtube:id/play")
        `when`(playNode.isClickable).thenReturn(true)
        `when`(playNode.childCount).thenReturn(0)
        `when`(playNode.getBoundsInScreen(org.mockito.ArgumentMatchers.any(Rect::class.java))).thenAnswer { inv ->
            val rect = inv.getArgument<Rect>(0)
            rect.set(700, 900, 900, 1100)
            null
        }

        `when`(rootNode.viewIdResourceName).thenReturn("com.google.android.youtube:id/root")
        `when`(rootNode.childCount).thenReturn(1)
        `when`(rootNode.getChild(0)).thenReturn(playNode)
        `when`(mockService.rootInActiveWindow).thenReturn(rootNode)
        AccessibilityServiceRegistry.activeService = mockService

        accessibilityRepo.clickNodeByText("Play") {}

        val st = pointerManager.pointerStateFlow.value
        assertTrue(st.visible)
        assertEquals(AgyPointerOverlayManager.PointerMode.TAP, st.mode)
        assertEquals(800f, st.cursorX, 0.01f)
        assertEquals(1000f, st.cursorY, 0.01f)
        assertEquals("Tap \"Play\"", st.label)
    }

    @Test
    fun `pointerEnabled toggle via HUD state and TOGGLE_POINTER command disables and re-enables pointer updates`() {
        assertTrue(pointerManager.isPointerEnabled())
        assertTrue(hudStore.pointerEnabledFlow.value)

        // Disable via HUD state payload
        val stateRes = hudStore.updateState(
            JSONObject()
                .put("state", "WORKING")
                .put("title", "Silent Run")
                .put("pointerEnabled", false)
        )
        assertFalse(stateRes.optBoolean("pointerEnabled", true))
        assertFalse(pointerManager.isPointerEnabled())
        assertFalse(hudStore.pointerEnabledFlow.value)

        // While disabled, tap dispatches should not mark pointer visible
        pointerManager.showTap(100f, 200f, "Ignored Tap")
        assertFalse(pointerManager.pointerStateFlow.value.visible)

        // Re-enable via remote command
        val toggleRes = hudStore.handleRemoteCommand(JSONObject().put("action", "TOGGLE_POINTER").put("enabled", true))
        assertTrue(toggleRes.optBoolean("pointerEnabled"))
        assertTrue(pointerManager.isPointerEnabled())

        pointerManager.showTap(150f, 250f, "Active Tap")
        assertTrue(pointerManager.pointerStateFlow.value.visible)
        assertEquals("Active Tap", pointerManager.pointerStateFlow.value.label)
    }

    @Test
    fun `AgyPointerCanvasView renders TAP, SWIPE, TYPING, and KEY_BADGE frames on Canvas without throwing`() {
        val view = AgyPointerCanvasView(context)
        view.measure(
            android.view.View.MeasureSpec.makeMeasureSpec(1080, android.view.View.MeasureSpec.EXACTLY),
            android.view.View.MeasureSpec.makeMeasureSpec(2400, android.view.View.MeasureSpec.EXACTLY)
        )
        view.layout(0, 0, 1080, 2400)

        val bmp = Bitmap.createBitmap(1080, 2400, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)

        view.startGesture(
            mode = AgyPointerOverlayManager.PointerMode.TAP,
            fromX = 100f,
            fromY = 100f,
            startX = 540f,
            startY = 1200f,
            endX = 540f,
            endY = 1200f,
            gestureDurationMs = 400L,
            label = "Tap \"Play\"",
            isAmber = false
        )
        view.draw(canvas)

        view.startGesture(
            mode = AgyPointerOverlayManager.PointerMode.SWIPE,
            fromX = 540f,
            fromY = 1200f,
            startX = 540f,
            startY = 1800f,
            endX = 540f,
            endY = 400f,
            gestureDurationMs = 300L,
            label = "Scroll Down",
            isAmber = false
        )
        view.draw(canvas)

        view.startGesture(
            mode = AgyPointerOverlayManager.PointerMode.KEY_BADGE,
            fromX = 540f,
            fromY = 400f,
            startX = 540f,
            startY = 400f,
            endX = 540f,
            endY = 400f,
            gestureDurationMs = 300L,
            label = "Key: BACK",
            isAmber = false
        )
        view.draw(canvas)

        assertEquals(1080, view.width)
        assertEquals(2400, view.height)
    }
}
