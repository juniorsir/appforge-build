package com.kavach

import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.kavach.data.local.CompanionDatabase
import com.kavach.data.local.DeviceSnapshotEntity
import com.kavach.data.local.LocationPointEntity
import com.kavach.data.local.TelemetryVaultDao
import com.kavach.data.local.TimelineEventEntity
import com.kavach.data.local.VaultCategory
import com.kavach.data.local.VaultSyncStatus
import com.kavach.domain.model.NetworkMessage
import com.kavach.domain.model.SessionState
import com.kavach.domain.repository.WebSocketRepository
import com.kavach.hardware.NetworkTelemetryManager
import com.kavach.telemetry.OfflineTelemetryVaultManager
import com.kavach.telemetry.TelemetryVaultExporter
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class OfflineTelemetryVaultTest {

    private lateinit var database: CompanionDatabase
    private lateinit var dao: TelemetryVaultDao
    private lateinit var fakeWsRepo: FakeWebSocketRepository
    private lateinit var vaultManager: OfflineTelemetryVaultManager

    private class FakeWebSocketRepository : WebSocketRepository {
        val mutableState = MutableStateFlow(SessionState.ConnectionState.DISCONNECTED)
        val sentPayloads = mutableListOf<String>()

        override val connectionState: StateFlow<SessionState.ConnectionState> = mutableState
        override val latencyMs: StateFlow<Long> = MutableStateFlow(0L)
        override val incomingMessages: SharedFlow<NetworkMessage> = MutableSharedFlow()
        override val incomingRawMessages: SharedFlow<String> = MutableSharedFlow()
        override val sessionId: StateFlow<String?> = MutableStateFlow("test-session")
        override val lastConnectedAt: StateFlow<Long?> = MutableStateFlow(null)
        override val lastFailureReason: StateFlow<String?> = MutableStateFlow(null)
        override val activeUrlFlow: StateFlow<String> = MutableStateFlow("ws://127.0.0.1:8000/ws")
        override val connectionLogs: StateFlow<List<String>> = MutableStateFlow(emptyList())
        override val retryCount: StateFlow<Int> = MutableStateFlow(0)
        override val bytesSent: StateFlow<Long> = MutableStateFlow(0L)
        override val bytesReceived: StateFlow<Long> = MutableStateFlow(0L)
        override val queueSize: StateFlow<Int> = MutableStateFlow(0)

        override suspend fun connect(url: String) {}
        override suspend fun connectBestAvailable(candidates: List<String>, forceSwitch: Boolean) {}
        override suspend fun disconnect() { mutableState.value = SessionState.ConnectionState.DISCONNECTED }
        override suspend fun sendMessage(message: NetworkMessage) {}
        override suspend fun sendRaw(text: String): Boolean {
            if (mutableState.value != SessionState.ConnectionState.CONNECTED) return false
            sentPayloads.add(text)
            return true
        }
        override fun addLog(entry: String) {}
        override fun clearLogs() {}
    }

    @Before
    fun setUp() {
        val context = ApplicationProvider.getApplicationContext<android.content.Context>()
        database = Room.inMemoryDatabaseBuilder(context, CompanionDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        dao = database.telemetryVaultDao()
        fakeWsRepo = FakeWebSocketRepository()
        vaultManager = OfflineTelemetryVaultManager(
            context = context,
            dao = dao,
            webSocketRepository = fakeWsRepo,
            networkTelemetryManager = NetworkTelemetryManager(context)
        )
    }

    @After
    fun tearDown() {
        vaultManager.stop()
        database.close()
    }

    @Test
    fun `offline records queue locally then sync and start 20-day retention window`() = runBlocking {
        val t0 = 1_700_000_000_000L
        dao.insertEvent(
            TimelineEventEntity(
                id = "evt_dns_1",
                timestamp = t0,
                category = VaultCategory.DNS,
                subType = "DNS_BLOCKED",
                title = "Blocked: doubleclick.net",
                detail = "CATEGORY_ADS",
                domain = "doubleclick.net",
                severity = "BLOCKED",
                syncStatus = VaultSyncStatus.PENDING
            )
        )
        dao.insertEvent(
            TimelineEventEntity(
                id = "evt_app_1",
                timestamp = t0 + 1000L,
                category = VaultCategory.APP,
                subType = "APP_LAUNCH",
                title = "Opened Maps",
                detail = "com.google.android.apps.maps",
                packageName = "com.google.android.apps.maps",
                syncStatus = VaultSyncStatus.PENDING
            )
        )
        dao.insertLocationPoint(
            LocationPointEntity(
                id = "loc_1",
                timestamp = t0,
                latitude = 37.7749,
                longitude = -122.4194,
                accuracyMeters = 8f,
                provider = "gps",
                syncStatus = VaultSyncStatus.PENDING
            )
        )
        dao.insertDeviceSnapshot(
            DeviceSnapshotEntity(
                id = "snap_1",
                timestamp = t0,
                batteryPercent = 84,
                isCharging = false,
                batteryTempC = 29.5f,
                networkConnected = false,
                networkTransport = "OFFLINE",
                syncStatus = VaultSyncStatus.PENDING
            )
        )

        // While disconnected, sync must keep everything queued
        val offlineRes = vaultManager.syncPendingBatchesInternal(manual = true)
        assertEquals(false, offlineRes.optBoolean("success"))
        assertEquals(4, offlineRes.optInt("pendingCount"))
        assertEquals(0, fakeWsRepo.sentPayloads.size)

        // Simulate internet/relay reconnect
        fakeWsRepo.mutableState.value = SessionState.ConnectionState.CONNECTED
        val onlineRes = vaultManager.syncPendingBatchesInternal(manual = false)
        assertTrue(onlineRes.optBoolean("success"))
        assertEquals(2, onlineRes.optInt("syncedEvents"))
        assertEquals(1, onlineRes.optInt("syncedLocations"))
        assertEquals(1, onlineRes.optInt("syncedSnapshots"))
        assertEquals(1, fakeWsRepo.sentPayloads.size)
        assertTrue(fakeWsRepo.sentPayloads.first().contains("TELEMETRY_BATCH_SYNC"))

        val syncedRows = dao.queryEvents(sinceMs = 0L, untilMs = Long.MAX_VALUE)
        assertEquals(2, syncedRows.size)
        assertTrue(syncedRows.all { it.syncStatus == VaultSyncStatus.SYNCED && it.syncedAt != null && it.expiresAt != null })

        val sampleSyncedAt = syncedRows.first().syncedAt!!
        val sampleExpiresAt = syncedRows.first().expiresAt!!
        assertEquals(OfflineTelemetryVaultManager.RETENTION_AFTER_SYNC_MS, sampleExpiresAt - sampleSyncedAt)

        // Insert a brand-new offline PENDING record dated 40 days ago (simulating long outage before sync)
        dao.insertEvent(
            TimelineEventEntity(
                id = "evt_old_unsynced",
                timestamp = sampleSyncedAt - (40L * 86_400_000L),
                category = VaultCategory.UNLOCK,
                subType = "DEVICE_UNLOCKED",
                title = "Device Unlocked",
                detail = "Offline unlock",
                syncStatus = VaultSyncStatus.PENDING
            )
        )

        // Day 19 after sync -> nothing should be pruned
        val day19Pruned = vaultManager.pruneExpiredSyncedInternal(nowMs = sampleExpiresAt - 86_400_000L)
        assertEquals(0, day19Pruned)
        assertEquals(3, dao.countAllEvents())

        // Day 20+1ms after sync -> synced records pruned, old unsynced record strictly preserved
        val day20Pruned = vaultManager.pruneExpiredSyncedInternal(nowMs = sampleExpiresAt + 1L)
        assertEquals(4, day20Pruned)
        assertEquals(1, dao.countAllEvents())
        assertEquals(1, dao.countPendingEvents())
        assertEquals(0, dao.countAllLocations())
        assertEquals(0, dao.countAllSnapshots())
    }

    @Test
    fun `location path distance and GPX CSV JSON exports are accurate`() {
        val p1 = LocationPointEntity(
            id = "p1",
            timestamp = 1_700_000_000_000L,
            latitude = 37.7749,
            longitude = -122.4194,
            accuracyMeters = 6f,
            speedMps = 2.0f
        )
        val p2 = LocationPointEntity(
            id = "p2",
            timestamp = 1_700_000_060_000L,
            latitude = 37.7759,
            longitude = -122.4194,
            accuracyMeters = 6f,
            speedMps = 3.0f
        )
        val dist = TelemetryVaultExporter.computeTotalDistanceMeters(listOf(p1, p2))
        // ~111 meters per 0.001 degree latitude
        assertTrue("Expected ~111m but got $dist", dist in 100f..125f)

        val gpxExport = TelemetryVaultExporter.exportToDownloadsAndPayload(
            format = "gpx",
            category = "LOCATION",
            events = emptyList(),
            locations = listOf(p1, p2),
            snapshots = emptyList()
        )
        assertTrue(gpxExport.optBoolean("success"))
        assertTrue(gpxExport.optString("content").contains("<trkpt lat=\"37.7749\" lon=\"-122.4194\">"))
    }

    @Test
    fun `memory trim callbacks run cleanly without throwing`() {
        val app = ApplicationProvider.getApplicationContext<BaseApplication>()
        vaultManager.trimCaches(aggressive = false)
        vaultManager.trimCaches(aggressive = true)
        app.onTrimMemory(android.content.ComponentCallbacks2.TRIM_MEMORY_UI_HIDDEN)
        app.onLowMemory()
    }
}
