package com.kavach.ui.overlay

import android.content.Context
import android.os.Looper
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.test.core.app.ApplicationProvider
import java.time.Duration
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows
import org.robolectric.annotation.Config
import org.robolectric.shadows.ShadowSettings

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36], qualifiers = "w360dp-h800dp-xxhdpi")
class AgyMediaPlayerPanelTest {

    private lateinit var context: Context
    private lateinit var floatingOverlayManager: FloatingOverlayManager
    private lateinit var taskMapManager: AgyTaskMapOverlayManager
    private lateinit var hudManager: AgyHudOverlayManager

    @Before
    fun setUp() {
        context = ApplicationProvider.getApplicationContext()
        ShadowSettings.setCanDrawOverlays(true)
        floatingOverlayManager = FloatingOverlayManager(context)
        taskMapManager = AgyTaskMapOverlayManager(context)
        hudManager = AgyHudOverlayManager(
            context = context,
            floatingOverlayManager = floatingOverlayManager
        ).apply {
            taskMapOverlayManager = taskMapManager
        }
    }

    @Test
    fun `PlayerTrackItem and PlayerTaskMapData parse local, stream, YouTube, and playlists accurately`() {
        val ytItem = AgyHudDynamicModels.PlayerTrackItem.fromJson(
            JSONObject()
                .put("url", "https://www.youtube.com/watch?v=jfKfPfyJRdk")
                .put("title", "Lofi Hip Hop Radio")
                .put("artist", "Lofi Girl")
        )
        assertNotNull(ytItem)
        assertTrue(ytItem!!.isWebEmbed)
        assertEquals("jfKfPfyJRdk", AgyHudDynamicModels.PlayerTrackItem.extractYouTubeVideoId(ytItem.uri))
        assertTrue(
            AgyHudDynamicModels.PlayerTrackItem.resolveWebEmbedUrl(ytItem.uri)
                .startsWith("https://www.youtube.com/embed/jfKfPfyJRdk")
        )

        val mp3Item = AgyHudDynamicModels.PlayerTrackItem.fromJson(
            JSONObject()
                .put("path", "/sdcard/Music/coding_beats.mp3")
                .put("title", "Coding Beats")
                .put("durationSeconds", 185)
        )
        assertNotNull(mp3Item)
        assertFalse(mp3Item!!.isVideo)
        assertFalse(mp3Item.isWebEmbed)
        assertEquals(185_000L, mp3Item.durationMs)

        val tm = AgyHudDynamicModels.TaskMapConfig.fromJson(
            JSONObject()
                .put("mode", "player")
                .put("bg", true)
                .put(
                    "playlist",
                    JSONArray()
                        .put(mp3Item.toJson())
                        .put(ytItem.toJson())
                )
        )
        assertTrue(tm.active)
        assertEquals("player", tm.mode)
        assertTrue(tm.persistOnDone)
        assertNotNull(tm.player)
        assertEquals("audio", tm.player!!.mediaMode)
        assertTrue(tm.player!!.backgroundMode)
        assertEquals(2, tm.player!!.playlist.size)
    }

    @Test
    fun `setPlayer launches left-window custom player, persists across DONE, and supports Video and Audio-Only switching`() {
        val res = hudManager.setPlayer(
            JSONObject()
                .put("title", "Demo Clip")
                .put("uri", "https://example.org/demo.mp4")
                .put("durationMs", 120_000L)
                .put("mediaMode", "video")
        )
        assertTrue(res.optBoolean("success"))
        assertTrue(res.optBoolean("playerActive"))
        assertEquals("video", res.optString("mediaMode"))
        assertEquals("player", hudManager.hudState.value.taskMap.mode)
        assertTrue(hudManager.hudState.value.taskMap.persistOnDone)

        val ctrl = taskMapManager.getPlayerController()
        assertNotNull(ctrl)
        assertEquals("video", ctrl!!.currentSnapshot().mediaMode)
        assertTrue(ctrl.currentSnapshot().isPlaying)

        // Seek to 42s and switch to Audio-Only mode — position & play state must be preserved
        ctrl.seekTo(42_000L)
        assertEquals(42_000L, ctrl.currentSnapshot().positionMs)

        ctrl.toggleMediaMode()
        assertEquals("audio", ctrl.currentSnapshot().mediaMode)
        assertEquals(42_000L, ctrl.currentSnapshot().positionMs)
        assertTrue(ctrl.currentSnapshot().isPlaying)

        // Transition HUD to DONE — player must remain active because persistOnDone is true
        hudManager.updateState(
            JSONObject()
                .put("state", "DONE")
                .put("currentAction", "Finished task")
        )
        assertEquals("DONE", hudManager.hudState.value.state)
        assertTrue(hudManager.resolveEffectiveTaskMap().active)
        assertEquals("player", hudManager.resolveEffectiveTaskMap().mode)
    }

    @Test
    fun `background mode collapses left window to interactive mini-pill while continuing playback`() {
        hudManager.setPlayer(
            JSONObject()
                .put(
                    "playlist",
                    JSONArray()
                        .put(
                            JSONObject()
                                .put("title", "Synthwave Track 1")
                                .put("uri", "/sdcard/Music/track1.mp3")
                                .put("durationMs", 200_000L)
                        )
                        .put(
                            JSONObject()
                                .put("title", "Synthwave Track 2")
                                .put("uri", "/sdcard/Music/track2.mp3")
                                .put("durationMs", 180_000L)
                        )
                )
                .put("mediaMode", "audio")
                .put("bg", true)
        )

        assertTrue(taskMapManager.isCollapsedFlow.value)
        val ctrl = taskMapManager.getPlayerController()!!
        assertTrue(ctrl.currentSnapshot().backgroundMode)
        assertTrue(ctrl.currentSnapshot().isPlaying)
        assertEquals(0, ctrl.currentSnapshot().currentIndex)

        // Control playback via partial /api/hud/player command while in BG mode
        val pauseRes = hudManager.setPlayer(JSONObject().put("action", "pause"))
        assertFalse(pauseRes.optBoolean("playing"))
        assertFalse(ctrl.currentSnapshot().isPlaying)

        val nextRes = hudManager.setPlayer(JSONObject().put("action", "next").put("playing", true))
        assertEquals(1, nextRes.optInt("currentIndex"))
        assertEquals("Synthwave Track 2", ctrl.currentSnapshot().currentTrack?.title)
        assertTrue(ctrl.currentSnapshot().isPlaying)

        // Expand out of BG mode back to full player window
        hudManager.setPlayer(JSONObject().put("bg", false))
        assertFalse(taskMapManager.isCollapsedFlow.value)
        assertFalse(ctrl.currentSnapshot().backgroundMode)
    }

    @Test
    fun `transport controls handle speed cycling, loop, mute-volume, seek, and queue navigation`() {
        val panel = AgyMediaPlayerPanelView(context)
        val theme = AgyHudDynamicModels.resolveTheme(
            AgyHudDynamicModels.HudThemeConfig(),
            android.graphics.Color.parseColor("#EC4899")
        )
        val config = AgyHudDynamicModels.TaskMapConfig.fromJson(
            JSONObject()
                .put("mode", "player")
                .put(
                    "playlist",
                    JSONArray()
                        .put(
                            JSONObject()
                                .put("title", "Track Alpha")
                                .put("uri", "https://example.org/a.mp3")
                                .put("durationMs", 100_000L)
                        )
                        .put(
                            JSONObject()
                                .put("title", "Track Beta")
                                .put("uri", "https://example.org/b.mp4")
                                .put("durationMs", 240_000L)
                        )
                )
        )
        panel.updatePlayer(config, theme)

        val ctrl = panel.controller
        assertEquals("audio", ctrl.currentSnapshot().mediaMode)
        assertEquals(1.0f, ctrl.currentSnapshot().speed, 0.01f)

        // Cycle speed: 1.0x -> 1.25x -> 1.5x -> 2.0x -> 0.75x -> 1.0x
        assertEquals(1.25f, ctrl.cycleSpeed(), 0.01f)
        assertEquals(1.5f, ctrl.cycleSpeed(), 0.01f)
        assertEquals(2.0f, ctrl.cycleSpeed(), 0.01f)
        assertEquals(0.75f, ctrl.cycleSpeed(), 0.01f)
        assertEquals(1.0f, ctrl.cycleSpeed(), 0.01f)

        // Loop toggle
        assertFalse(ctrl.currentSnapshot().isLooping)
        assertTrue(ctrl.toggleLoop())
        assertTrue(ctrl.currentSnapshot().isLooping)

        // Mute & volume controls
        assertFalse(ctrl.currentSnapshot().isMuted)
        assertTrue(ctrl.toggleMute())
        assertTrue(ctrl.currentSnapshot().isMuted)
        ctrl.setVolume(0.65f)
        assertFalse(ctrl.currentSnapshot().isMuted)
        assertEquals(0.65f, ctrl.currentSnapshot().volume, 0.01f)

        // Seek by permille (500 / 1000 of 100_000ms = 50_000ms = 00:50)
        ctrl.seekByPermille(500)
        assertEquals(50_000L, ctrl.currentSnapshot().positionMs)
        assertEquals("00:50", ctrl.currentSnapshot().elapsedLabel)
        assertEquals("01:40", ctrl.currentSnapshot().durationLabel)

        // UI button clicks on panel (Apple SF vector SVG buttons)
        val audioBtn = panel.findViewWithTag<AgyAppleVectorIconView>("${AgyMediaPlayerPanelView.PLAYER_TAG_PREFIX}_mode_audio")
        val videoBtn = panel.findViewWithTag<AgyAppleVectorIconView>("${AgyMediaPlayerPanelView.PLAYER_TAG_PREFIX}_mode_video")
        val queueToggle = panel.findViewWithTag<AgyAppleVectorIconView>("${AgyMediaPlayerPanelView.PLAYER_TAG_PREFIX}_queue_toggle_btn")
        assertNotNull(audioBtn)
        assertNotNull(videoBtn)
        assertNotNull(queueToggle)
        assertEquals(AgyAppleVectorIconView.IconType.MUSIC_NOTE, audioBtn.iconType)
        assertEquals(AgyAppleVectorIconView.IconType.VIDEO_FILL, videoBtn.iconType)
        assertEquals(AgyAppleVectorIconView.IconType.LIST_BULLET, queueToggle.iconType)

        videoBtn.performClick()
        assertEquals("video", ctrl.currentSnapshot().mediaMode)

        queueToggle.performClick()
        val queueItem1 = panel.findViewWithTag<View>("${AgyMediaPlayerPanelView.PLAYER_TAG_PREFIX}_queue_item_1")
        assertNotNull(queueItem1)
        queueItem1.performClick()
        assertEquals(1, ctrl.currentSnapshot().currentIndex)
        assertEquals("Track Beta", ctrl.currentSnapshot().currentTrack?.title)
    }

    @Test
    fun `left window defaults to 100 percent full opacity, docks just left of main HUD on large screens, and auto-collapses to BG mini-pill when a new task starts`() {
        // 1. Default opacity is 100% (1.0f)
        assertEquals(1.0f, taskMapManager.opacityFlow.value, 0.001f)

        // 2. Launch video player in DONE state
        hudManager.updateState(JSONObject().put("state", "DONE").put("title", "Idle Ready"))
        hudManager.setPlayer(
            JSONObject()
                .put("title", "Apple Keynote Clip")
                .put("uri", "https://example.org/keynote.mp4")
                .put("mediaMode", "video")
                .put("bg", false)
        )
        assertFalse(taskMapManager.isCollapsedFlow.value)
        assertTrue(hudManager.resolveEffectiveTaskMap().active)
        assertEquals("player", hudManager.resolveEffectiveTaskMap().mode)

        // 3. When a new Agy task starts (state transitions from DONE -> WORKING with daemon's default inactive app_pane taskMap),
        // the player is NOT closed; instead it stays active and automatically collapses into the background mini-pill!
        hudManager.updateState(
            JSONObject()
                .put("state", "WORKING")
                .put("title", "Running New Automation Task")
                .put("currentAction", "Opening target app...")
                .put("taskMap", JSONObject().put("active", false).put("mode", "app_pane"))
        )
        assertEquals("WORKING", hudManager.hudState.value.state)
        assertTrue("Active player must remain active when a new task starts", hudManager.resolveEffectiveTaskMap().active)
        assertEquals("player", hudManager.resolveEffectiveTaskMap().mode)
        assertTrue("Player must auto-collapse to the background mini-pill on new task start", taskMapManager.isCollapsedFlow.value)
        assertTrue(taskMapManager.getPlayerController()!!.currentSnapshot().backgroundMode)
        assertTrue(taskMapManager.getPlayerController()!!.currentSnapshot().isPlaying)

        // 4. Verify auto-follow docking just left of the main HUD window on a large screen / tablet viewport
        val largeViewport = AgyOverlayLayoutCoordinator.buildViewportSafeBounds(
            screenWidth = 2200,
            screenHeight = 1400,
            density = 2f
        )
        val mainHudBox = AgyOverlayLayoutCoordinator.WindowBoxState(
            id = AgyOverlayLayoutCoordinator.ManagedWindowId.HUD,
            visible = true,
            rect = android.graphics.Rect(1300, 420, 2020, 920),
            expandedWidth = 720,
            expandedHeight = 500,
            collapsedWidth = 420,
            collapsedHeight = 110,
            isCollapsed = false,
            autoCollapsedByCoordinator = false,
            userManuallyCollapsed = false,
            priority = AgyOverlayLayoutCoordinator.InteractionPriority.USER_INTERACTED,
            lastInteractionSeq = 10L
        )
        val leftPlayerBox = AgyOverlayLayoutCoordinator.WindowBoxState(
            id = AgyOverlayLayoutCoordinator.ManagedWindowId.TASK_MAP,
            visible = true,
            rect = android.graphics.Rect(largeViewport.safeLeft, 120, largeViewport.safeLeft + 456, 680),
            expandedWidth = 456,
            expandedHeight = 560,
            collapsedWidth = 356,
            collapsedHeight = 80,
            isCollapsed = false,
            autoCollapsedByCoordinator = false,
            userManuallyCollapsed = false,
            priority = AgyOverlayLayoutCoordinator.InteractionPriority.PASSIVE,
            lastInteractionSeq = 1L,
            autoFollowHud = true
        )
        val dockedResolution = AgyOverlayLayoutCoordinator.solve(mainHudBox, leftPlayerBox, largeViewport)
        assertNotNull("Left window at far-left edge must auto-follow to dock just left of main HUD", dockedResolution.secondaryAdjustment)
        val adj = dockedResolution.secondaryAdjustment!!
        assertEquals(
            "Left window should dock exactly gapPx (12dp) to the left of main HUD",
            mainHudBox.rect.left - largeViewport.gapPx - leftPlayerBox.expandedWidth,
            adj.targetLeft
        )
        assertEquals(
            "Left window top should align with main HUD top",
            mainHudBox.rect.top,
            adj.targetTop
        )
    }

    @Test
    fun `player glass controls auto-hide on video play, double-tap seeks +-10s with badge, and surface adapts aspect ratio safely`() {
        val parentCard = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
        }
        val panel = AgyMediaPlayerPanelView(context)
        parentCard.addView(panel)
        val theme = AgyHudDynamicModels.resolveTheme(
            AgyHudDynamicModels.HudThemeConfig(mode = "dark"),
            android.graphics.Color.parseColor("#EC4899")
        )
        val videoConfig = AgyHudDynamicModels.TaskMapConfig.fromJson(
            JSONObject()
                .put("mode", "player")
                .put("mediaMode", "video")
                .put("playing", true)
                .put(
                    "playlist",
                    JSONArray().put(
                        JSONObject()
                            .put("id", "v_smart")
                            .put("title", "Smart Glass Demo")
                            .put("uri", "https://example.org/demo.mp4")
                            .put("durationMs", 90_000L)
                            .put("isVideo", true)
                    )
                )
        )
        panel.updatePlayer(videoConfig, theme)
        parentCard.measure(
            View.MeasureSpec.makeMeasureSpec(520, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(900, View.MeasureSpec.AT_MOST)
        )
        parentCard.layout(0, 0, parentCard.measuredWidth, parentCard.measuredHeight)

        // 1. Controls start visible, then auto-hide after idle timeout while playing video
        assertTrue(panel.areGlassControlsVisible())
        Shadows.shadowOf(Looper.getMainLooper())
            .idleFor(Duration.ofMillis(AgyMediaPlayerPanelView.AUTO_HIDE_CONTROLS_MS + 150L))
        assertFalse("Glass controls should auto-hide after idle delay during video playback", panel.areGlassControlsVisible())

        // Single tap wakes controls back up
        panel.handleSurfaceSingleTap()
        assertTrue("Single tap must wake hidden glass controls", panel.areGlassControlsVisible())

        // Pausing or switching to audio mode keeps controls permanently visible even after idle timeout
        panel.controller.setPlaying(false)
        Shadows.shadowOf(Looper.getMainLooper())
            .idleFor(Duration.ofMillis(AgyMediaPlayerPanelView.AUTO_HIDE_CONTROLS_MS + 150L))
        assertTrue("Paused video must keep glass controls visible", panel.areGlassControlsVisible())

        panel.controller.setPlaying(true)
        panel.controller.setMediaMode("audio")
        Shadows.shadowOf(Looper.getMainLooper())
            .idleFor(Duration.ofMillis(AgyMediaPlayerPanelView.AUTO_HIDE_CONTROLS_MS + 150L))
        assertTrue("Audio-only mode must keep glass controls visible", panel.areGlassControlsVisible())

        // 2. Double-tap gestures seek +-10s and display skip badge
        panel.controller.setMediaMode("video")
        panel.controller.seekTo(20_000L)
        panel.handleSurfaceDoubleTap(isRightSide = true)
        assertEquals(30_000L, panel.controller.currentSnapshot().positionMs)
        assertEquals("+10s", panel.getSkipFeedbackText())

        panel.handleSurfaceDoubleTap(isRightSide = false)
        assertEquals(20_000L, panel.controller.currentSnapshot().positionMs)
        assertEquals("-10s", panel.getSkipFeedbackText())

        // 3. Adaptive aspect-ratio viewport height (4:3 taller than 16:9) without breaking LinearLayout.LayoutParams
        panel.controller.setVideoDimensions(1280, 960)
        val height4x3 = panel.getSurfaceViewportHeightPx()
        panel.controller.setVideoDimensions(1920, 1080)
        val height16x9 = panel.getSurfaceViewportHeightPx()
        assertTrue("4:3 video viewport ($height4x3) should be taller than 16:9 ($height16x9)", height4x3 > height16x9)

        val surface = panel.findViewWithTag<View>("${AgyMediaPlayerPanelView.PLAYER_TAG_PREFIX}_video_viewport")
        assertNotNull(surface)
        assertTrue("Media surface must retain LinearLayout.LayoutParams", surface.layoutParams is LinearLayout.LayoutParams)
        parentCard.measure(
            View.MeasureSpec.makeMeasureSpec(520, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(900, View.MeasureSpec.AT_MOST)
        )
        parentCard.layout(0, 0, parentCard.measuredWidth, parentCard.measuredHeight)
        assertTrue(parentCard.measuredHeight > 0)
    }
}
