package com.kavach.ui.overlay

import android.content.Context
import android.graphics.Rect
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import androidx.test.core.app.ApplicationProvider
import java.time.Duration
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import org.robolectric.shadows.ShadowSettings

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36], qualifiers = "w360dp-h800dp-xxhdpi")
class AgyOverlayLayoutCoordinatorTest {

    private lateinit var context: Context

    @Before
    fun setUp() {
        context = ApplicationProvider.getApplicationContext()
    }

    private fun portraitViewport(
        screenW: Int = 1080,
        screenH: Int = 2400,
        density: Float = 3f,
        imeVisible: Boolean = false,
        imeHeightPx: Int = 0
    ): AgyOverlayLayoutCoordinator.ViewportSafeBounds {
        return AgyOverlayLayoutCoordinator.buildViewportSafeBounds(
            screenWidth = screenW,
            screenHeight = screenH,
            density = density,
            statusBarHeightPx = (28 * density).toInt(),
            navBarHeightPx = (24 * density).toInt(),
            imeVisible = imeVisible,
            imeHeightPx = imeHeightPx
        )
    }

    @Test
    fun `simultaneous expanded windows with clear vertical separation produce no overlap or collapse`() {
        val vp = portraitViewport()
        val hud = AgyOverlayLayoutCoordinator.WindowBoxState(
            id = AgyOverlayLayoutCoordinator.ManagedWindowId.HUD,
            visible = true,
            rect = Rect(144, 1650, 1056, 2250),
            expandedWidth = 912,
            expandedHeight = 600,
            collapsedWidth = 540,
            collapsedHeight = 132,
            isCollapsed = false,
            autoCollapsedByCoordinator = false,
            userManuallyCollapsed = false
        )
        val map = AgyOverlayLayoutCoordinator.WindowBoxState(
            id = AgyOverlayLayoutCoordinator.ManagedWindowId.TASK_MAP,
            visible = true,
            rect = Rect(24, 150, 696, 1100),
            expandedWidth = 672,
            expandedHeight = 950,
            collapsedWidth = 340,
            collapsedHeight = 120,
            isCollapsed = false,
            autoCollapsedByCoordinator = false,
            userManuallyCollapsed = false
        )

        val res = AgyOverlayLayoutCoordinator.solve(hud, map, vp)
        assertFalse(res.hadCollision)
        assertNull(res.secondaryAdjustment)
        assertFalse(AgyOverlayLayoutCoordinator.rectsOverlapWithGap(hud.rect, map.rect, vp.gapPx))
    }

    @Test
    fun `tight portrait viewport auto-collapses secondary window into pill with at least 12dp gap and restores when space opens`() {
        val vp = portraitViewport(screenW = 1080, screenH = 1920, density = 3f)
        // HUD expanded tall (e.g. Steps + Output drawer open): occupies y = 680..1820 (height 1140)
        val tallHud = AgyOverlayLayoutCoordinator.WindowBoxState(
            id = AgyOverlayLayoutCoordinator.ManagedWindowId.HUD,
            visible = true,
            rect = Rect(144, 680, 1056, 1820),
            expandedWidth = 912,
            expandedHeight = 1140,
            collapsedWidth = 540,
            collapsedHeight = 132,
            isCollapsed = false,
            autoCollapsedByCoordinator = false,
            userManuallyCollapsed = false,
            priority = AgyOverlayLayoutCoordinator.InteractionPriority.USER_INTERACTED,
            lastInteractionSeq = 5L
        )
        // Left Results panel (height 980) cannot fit above HUD (safeTop=102..680-36=644 -> only 542px!)
        val tallMap = AgyOverlayLayoutCoordinator.WindowBoxState(
            id = AgyOverlayLayoutCoordinator.ManagedWindowId.TASK_MAP,
            visible = true,
            rect = Rect(24, 102, 696, 1082),
            expandedWidth = 672,
            expandedHeight = 980,
            collapsedWidth = 348,
            collapsedHeight = 120,
            isCollapsed = false,
            autoCollapsedByCoordinator = false,
            userManuallyCollapsed = false,
            priority = AgyOverlayLayoutCoordinator.InteractionPriority.PASSIVE,
            lastInteractionSeq = 2L
        )

        val res = AgyOverlayLayoutCoordinator.solve(tallHud, tallMap, vp)
        assertTrue(res.hadCollision)
        assertEquals(AgyOverlayLayoutCoordinator.ManagedWindowId.TASK_MAP, res.secondaryId)
        val adj = res.secondaryAdjustment
        assertNotNull(adj)
        assertTrue(adj!!.targetCollapsed)
        assertTrue(adj.autoCollapsedByCoordinator)

        val pillRect = Rect(
            adj.targetLeft,
            adj.targetTop,
            adj.targetLeft + tallMap.collapsedWidth,
            adj.targetTop + tallMap.collapsedHeight
        )
        assertFalse(
            "Auto-collapsed pill must clear HUD by at least 12dp (${vp.gapPx}px)",
            AgyOverlayLayoutCoordinator.rectsOverlapWithGap(pillRect, tallHud.rect, vp.gapPx)
        )
        assertTrue(pillRect.left >= vp.safeLeft)
        assertTrue(pillRect.top >= vp.safeTop)
        assertTrue(pillRect.right <= vp.safeRight)
        assertTrue(pillRect.bottom <= vp.safeBottom)

        // Now HUD shrinks back (Steps/Output closed: height 480, y = 1340..1820) -> auto-collapsed Task Map restores!
        val compactHud = tallHud.copy(
            rect = Rect(144, 1340, 1056, 1820),
            expandedHeight = 480
        )
        val collapsedAutoMap = tallMap.copy(
            rect = pillRect,
            isCollapsed = true,
            autoCollapsedByCoordinator = true,
            userManuallyCollapsed = false
        )
        val restoreRes = AgyOverlayLayoutCoordinator.solve(compactHud, collapsedAutoMap, vp)
        val restoreAdj = restoreRes.secondaryAdjustment
        assertNotNull(restoreAdj)
        assertFalse("Previously auto-collapsed window must restore when space opens", restoreAdj!!.targetCollapsed)
        assertFalse(restoreAdj.autoCollapsedByCoordinator)
    }

    @Test
    fun `manual user collapse is never overridden when space opens up`() {
        val vp = portraitViewport()
        val compactHud = AgyOverlayLayoutCoordinator.WindowBoxState(
            id = AgyOverlayLayoutCoordinator.ManagedWindowId.HUD,
            visible = true,
            rect = Rect(144, 1700, 1056, 2240),
            expandedWidth = 912,
            expandedHeight = 540,
            collapsedWidth = 540,
            collapsedHeight = 132,
            isCollapsed = false,
            autoCollapsedByCoordinator = false,
            userManuallyCollapsed = false
        )
        val manuallyCollapsedMap = AgyOverlayLayoutCoordinator.WindowBoxState(
            id = AgyOverlayLayoutCoordinator.ManagedWindowId.TASK_MAP,
            visible = true,
            rect = Rect(24, 120, 344, 240),
            expandedWidth = 672,
            expandedHeight = 720,
            collapsedWidth = 320,
            collapsedHeight = 120,
            isCollapsed = true,
            autoCollapsedByCoordinator = false,
            userManuallyCollapsed = true
        )

        val res = AgyOverlayLayoutCoordinator.solve(compactHud, manuallyCollapsedMap, vp)
        assertNull("Manually collapsed window should stay collapsed untouched", res.secondaryAdjustment)
    }

    @Test
    fun `dragging HUD into Task Map triggers live auto-dodge above or below inside safe bounds`() {
        val vp = portraitViewport(screenW = 1080, screenH = 2400, density = 3f)
        // Step 1: HUD dragged upward into middle (y = 1050..1550) colliding with Task Map (y = 650..1150)
        val draggedHudMid = AgyOverlayLayoutCoordinator.WindowBoxState(
            id = AgyOverlayLayoutCoordinator.ManagedWindowId.HUD,
            visible = true,
            rect = Rect(144, 1050, 1056, 1550),
            expandedWidth = 912,
            expandedHeight = 500,
            collapsedWidth = 540,
            collapsedHeight = 132,
            isCollapsed = false,
            autoCollapsedByCoordinator = false,
            userManuallyCollapsed = false,
            priority = AgyOverlayLayoutCoordinator.InteractionPriority.DRAGGING,
            lastInteractionSeq = 10L
        )
        val mapAtMid = AgyOverlayLayoutCoordinator.WindowBoxState(
            id = AgyOverlayLayoutCoordinator.ManagedWindowId.TASK_MAP,
            visible = true,
            rect = Rect(24, 650, 624, 1150),
            expandedWidth = 600,
            expandedHeight = 500,
            collapsedWidth = 300,
            collapsedHeight = 120,
            isCollapsed = false,
            autoCollapsedByCoordinator = false,
            userManuallyCollapsed = false,
            priority = AgyOverlayLayoutCoordinator.InteractionPriority.PASSIVE,
            lastInteractionSeq = 1L
        )

        val dodgeUp = AgyOverlayLayoutCoordinator.solve(draggedHudMid, mapAtMid, vp)
        assertTrue(dodgeUp.hadCollision)
        val upAdj = dodgeUp.secondaryAdjustment!!
        assertFalse("Should dodge expanded without collapsing when room exists above", upAdj.targetCollapsed)
        assertEquals(draggedHudMid.rect.top - vp.gapPx - mapAtMid.expandedHeight, upAdj.targetTop)
        assertTrue(upAdj.targetTop >= vp.safeTop)

        // Step 2: HUD dragged all the way to top (y = 120..620) -> no room above, Task Map dodges BELOW HUD!
        val draggedHudTop = draggedHudMid.copy(rect = Rect(144, 120, 1056, 620))
        val mapNearTop = mapAtMid.copy(rect = Rect(24, 120, 624, 620))
        val dodgeDown = AgyOverlayLayoutCoordinator.solve(draggedHudTop, mapNearTop, vp)
        assertTrue(dodgeDown.hadCollision)
        val downAdj = dodgeDown.secondaryAdjustment!!
        assertFalse(downAdj.targetCollapsed)
        assertEquals(draggedHudTop.rect.bottom + vp.gapPx, downAdj.targetTop)
        assertTrue(downAdj.targetTop + mapNearTop.expandedHeight <= vp.safeBottom)
    }

    @Test
    fun `explicit tap on Task Map raises priority so HUD yields in tight space`() {
        val vp = portraitViewport(screenW = 1080, screenH = 1800, density = 3f)
        val hud = AgyOverlayLayoutCoordinator.WindowBoxState(
            id = AgyOverlayLayoutCoordinator.ManagedWindowId.HUD,
            visible = true,
            rect = Rect(144, 700, 1056, 1700),
            expandedWidth = 912,
            expandedHeight = 1000,
            collapsedWidth = 520,
            collapsedHeight = 132,
            isCollapsed = false,
            autoCollapsedByCoordinator = false,
            userManuallyCollapsed = false,
            priority = AgyOverlayLayoutCoordinator.InteractionPriority.USER_INTERACTED,
            lastInteractionSeq = 3L
        )
        val newlyExpandedMap = AgyOverlayLayoutCoordinator.WindowBoxState(
            id = AgyOverlayLayoutCoordinator.ManagedWindowId.TASK_MAP,
            visible = true,
            rect = Rect(24, 102, 696, 1022),
            expandedWidth = 672,
            expandedHeight = 920,
            collapsedWidth = 340,
            collapsedHeight = 120,
            isCollapsed = false,
            autoCollapsedByCoordinator = false,
            userManuallyCollapsed = false,
            priority = AgyOverlayLayoutCoordinator.InteractionPriority.USER_INTERACTED,
            lastInteractionSeq = 9L // User just tapped Task Map pill!
        )

        val res = AgyOverlayLayoutCoordinator.solve(hud, newlyExpandedMap, vp)
        assertEquals(AgyOverlayLayoutCoordinator.ManagedWindowId.TASK_MAP, res.primaryId)
        assertEquals(AgyOverlayLayoutCoordinator.ManagedWindowId.HUD, res.secondaryId)
        val hudAdj = res.secondaryAdjustment!!
        assertTrue("HUD should auto-collapse into compact dock pill so expanded Task Map stays unobstructed", hudAdj.targetCollapsed)
        assertTrue(hudAdj.autoCollapsedByCoordinator)
        val hudPillRect = Rect(
            hudAdj.targetLeft,
            hudAdj.targetTop,
            hudAdj.targetLeft + hud.collapsedWidth,
            hudAdj.targetTop + hud.collapsedHeight
        )
        assertFalse(AgyOverlayLayoutCoordinator.rectsOverlapWithGap(hudPillRect, newlyExpandedMap.rect, vp.gapPx))
    }

    @Test
    fun `gravity conversions round-trip accurately for TOP_START, BOTTOM_END, and CENTER_VERTICAL`() {
        val screenW = 1080
        val screenH = 2400
        val w = 600
        val h = 420
        val targetLeft = 320
        val targetTop = 1240

        val gravities = listOf(
            Gravity.TOP or Gravity.START,
            Gravity.BOTTOM or Gravity.END,
            Gravity.CENTER_VERTICAL or Gravity.START,
            Gravity.TOP or Gravity.CENTER_HORIZONTAL
        )
        gravities.forEach { grav ->
            val (px, py) = AgyOverlayLayoutCoordinator.screenTopLeftToWindowOffset(
                gravity = grav,
                targetLeft = targetLeft,
                targetTop = targetTop,
                width = w,
                height = h,
                screenWidth = screenW,
                screenHeight = screenH
            )
            val params = WindowManager.LayoutParams().apply {
                gravity = grav
                x = px
                y = py
            }
            val rect = AgyOverlayLayoutCoordinator.windowParamsToScreenRect(
                params = params,
                width = w,
                height = h,
                screenWidth = screenW,
                screenHeight = screenH
            )
            assertEquals("Left mismatch for gravity $grav", targetLeft, rect.left)
            assertEquals("Top mismatch for gravity $grav", targetTop, rect.top)
        }
    }

    @Test
    fun `IME focus shifts or auto-collapses Task Map and restores pre-IME state on blur`() {
        val coordinator = AgyOverlayLayoutCoordinator(context)
        var hudRect = Rect(144, 1720, 1056, 2260)
        var hudCollapsed = false
        var mapRect = Rect(24, 700, 696, 1500)
        var mapCollapsed = false
        var mapAutoCollapsed = false

        coordinator.registerEndpoint(object : AgyOverlayLayoutCoordinator.ManagedOverlayEndpoint {
            override val windowId = AgyOverlayLayoutCoordinator.ManagedWindowId.HUD
            override fun captureBoxState(viewport: AgyOverlayLayoutCoordinator.ViewportSafeBounds) =
                AgyOverlayLayoutCoordinator.WindowBoxState(
                    id = windowId,
                    visible = true,
                    rect = if (coordinator.isImeVisible()) {
                        Rect(144, (viewport.safeBottom - 540).coerceAtLeast(viewport.safeTop), 1056, viewport.safeBottom)
                    } else hudRect,
                    expandedWidth = 912,
                    expandedHeight = 540,
                    collapsedWidth = 520,
                    collapsedHeight = 132,
                    isCollapsed = hudCollapsed,
                    autoCollapsedByCoordinator = false,
                    userManuallyCollapsed = false
                )
            override fun applyAdjustment(
                adjustment: AgyOverlayLayoutCoordinator.WindowAdjustment,
                viewport: AgyOverlayLayoutCoordinator.ViewportSafeBounds,
                animate: Boolean
            ) {
                hudCollapsed = adjustment.targetCollapsed
                hudRect = Rect(
                    adjustment.targetLeft,
                    adjustment.targetTop,
                    adjustment.targetLeft + if (hudCollapsed) 520 else 912,
                    adjustment.targetTop + if (hudCollapsed) 132 else 540
                )
            }
            override fun clampPosition(
                targetLeft: Int,
                targetTop: Int,
                viewport: AgyOverlayLayoutCoordinator.ViewportSafeBounds,
                animate: Boolean
            ) {
                hudRect = Rect(targetLeft, targetTop, targetLeft + hudRect.width(), targetTop + hudRect.height())
            }
        })

        coordinator.registerEndpoint(object : AgyOverlayLayoutCoordinator.ManagedOverlayEndpoint {
            override val windowId = AgyOverlayLayoutCoordinator.ManagedWindowId.TASK_MAP
            override fun captureBoxState(viewport: AgyOverlayLayoutCoordinator.ViewportSafeBounds) =
                AgyOverlayLayoutCoordinator.WindowBoxState(
                    id = windowId,
                    visible = true,
                    rect = mapRect,
                    expandedWidth = 672,
                    expandedHeight = 800,
                    collapsedWidth = 340,
                    collapsedHeight = 120,
                    isCollapsed = mapCollapsed,
                    autoCollapsedByCoordinator = mapAutoCollapsed,
                    userManuallyCollapsed = false
                )
            override fun applyAdjustment(
                adjustment: AgyOverlayLayoutCoordinator.WindowAdjustment,
                viewport: AgyOverlayLayoutCoordinator.ViewportSafeBounds,
                animate: Boolean
            ) {
                mapCollapsed = adjustment.targetCollapsed
                mapAutoCollapsed = adjustment.autoCollapsedByCoordinator
                val w = if (mapCollapsed) 340 else 672
                val h = if (mapCollapsed) 120 else 800
                mapRect = Rect(adjustment.targetLeft, adjustment.targetTop, adjustment.targetLeft + w, adjustment.targetTop + h)
            }
            override fun clampPosition(
                targetLeft: Int,
                targetTop: Int,
                viewport: AgyOverlayLayoutCoordinator.ViewportSafeBounds,
                animate: Boolean
            ) {
                mapRect = Rect(targetLeft, targetTop, targetLeft + mapRect.width(), targetTop + mapRect.height())
            }
        })

        // Open keyboard -> HUD rises above IME, Task Map dodges or auto-collapses clear of HUD + keyboard
        coordinator.notifyImeFocusChanged(focused = true, estimatedImeHeightPx = 920)
        assertTrue(coordinator.isImeVisible())
        val imeVp = coordinator.currentViewportSafeBounds()
        val activeHudRect = Rect(144, (imeVp.safeBottom - 540).coerceAtLeast(imeVp.safeTop), 1056, imeVp.safeBottom)
        assertFalse(
            "Task Map must not overlap HUD while keyboard is open",
            AgyOverlayLayoutCoordinator.rectsOverlapWithGap(mapRect, activeHudRect, imeVp.gapPx)
        )

        // Close keyboard -> Task Map smoothly restores expanded state
        coordinator.notifyImeFocusChanged(focused = false)
        assertFalse(coordinator.isImeVisible())
        assertFalse("Task Map should restore expanded after keyboard closes", mapCollapsed)
        assertFalse(mapAutoCollapsed)
    }

    @Test
    fun `HUD and TaskMap managers wire shared coordinator and expose combined overlay bounds`() {
        ShadowSettings.setCanDrawOverlays(true)
        try {
            val floatingMgr = FloatingOverlayManager(context)
            val taskMapMgr = AgyTaskMapOverlayManager(context)
            val hudMgr = AgyHudOverlayManager(
                context = context,
                floatingOverlayManager = floatingMgr
            ).apply {
                taskMapOverlayManager = taskMapMgr
            }

            hudMgr.updateState(
                JSONObject().apply {
                    put("state", "WORKING")
                    put("title", "Search Miya")
                    put("results", JSONObject().apply {
                        put("query", "who is miya")
                        put("summaryTitle", "Miya")
                        put("summaryText", "Engineer and artist")
                        put("items", JSONArray().put(
                            JSONObject().put("id", "i1").put("kind", "image").put("title", "Photo").put("uri", "https://example.org/1.jpg")
                        ))
                    })
                }
            )
            shadowOf(android.os.Looper.getMainLooper()).idle()

            assertTrue(hudMgr.isHudVisible.value)
            assertTrue(taskMapMgr.isMapVisibleFlow.value)

            val mapRect = taskMapMgr.getOverlayRect()
            assertNotNull("TaskMap should report non-null screen rect when visible", mapRect)
            val combinedBounds = hudMgr.getOverlayBounds()
            assertTrue(
                "Combined overlay bounds must include both HUD and Task Map",
                combinedBounds.size >= 2
            )

            // Verify HUD + TaskMap do not overlap with 12dp gap after layout reconciliation
            val vp = hudMgr.layoutCoordinator.currentViewportSafeBounds()
            val hudRect = combinedBounds.first()
            val finalMapRect = taskMapMgr.getOverlayRect()!!
            assertFalse(
                "HUD ($hudRect) and Task Map ($finalMapRect) must not overlap after reconciliation",
                AgyOverlayLayoutCoordinator.rectsOverlapWithGap(hudRect, finalMapRect, vp.gapPx)
            )

            hudMgr.hideAll()
            shadowOf(android.os.Looper.getMainLooper()).idle()
        } finally {
            ShadowSettings.setCanDrawOverlays(false)
        }
    }

    @Test
    fun `landscape wide viewport positions HUD and Task Map side by side without collapsing`() {
        val landscapeVp = portraitViewport(screenW = 2400, screenH = 1080, density = 3f)
        val hud = AgyOverlayLayoutCoordinator.WindowBoxState(
            id = AgyOverlayLayoutCoordinator.ManagedWindowId.HUD,
            visible = true,
            rect = Rect(1440, 360, 2352, 980),
            expandedWidth = 912,
            expandedHeight = 620,
            collapsedWidth = 520,
            collapsedHeight = 132,
            isCollapsed = false,
            autoCollapsedByCoordinator = false,
            userManuallyCollapsed = false,
            priority = AgyOverlayLayoutCoordinator.InteractionPriority.USER_INTERACTED,
            lastInteractionSeq = 2L
        )
        // Task Map dragged onto HUD horizontally in landscape -> should dodge left cleanly without collapsing!
        val collidingMap = AgyOverlayLayoutCoordinator.WindowBoxState(
            id = AgyOverlayLayoutCoordinator.ManagedWindowId.TASK_MAP,
            visible = true,
            rect = Rect(1200, 300, 1872, 940),
            expandedWidth = 672,
            expandedHeight = 640,
            collapsedWidth = 340,
            collapsedHeight = 120,
            isCollapsed = false,
            autoCollapsedByCoordinator = false,
            userManuallyCollapsed = false,
            priority = AgyOverlayLayoutCoordinator.InteractionPriority.PASSIVE,
            lastInteractionSeq = 1L
        )

        val res = AgyOverlayLayoutCoordinator.solve(hud, collidingMap, landscapeVp)
        assertTrue(res.hadCollision)
        val adj = res.secondaryAdjustment!!
        assertFalse("Wide landscape screen has ample horizontal space — should dodge without collapsing", adj.targetCollapsed)
        val dodgedRect = Rect(adj.targetLeft, adj.targetTop, adj.targetLeft + collidingMap.expandedWidth, adj.targetTop + collidingMap.expandedHeight)
        assertFalse(AgyOverlayLayoutCoordinator.rectsOverlapWithGap(dodgedRect, hud.rect, landscapeVp.gapPx))
        assertTrue(dodgedRect.right + landscapeVp.gapPx <= hud.rect.left)
    }

    @Test
    fun `second window docks directly left of HUD when horizontal space fits or just up above HUD on portrait screens`() {
        val portraitVp = portraitViewport(screenW = 1080, screenH = 2400, density = 3f)
        val hudBottomRight = AgyOverlayLayoutCoordinator.WindowBoxState(
            id = AgyOverlayLayoutCoordinator.ManagedWindowId.HUD,
            visible = true,
            rect = Rect(144, 1650, 1056, 2250),
            expandedWidth = 912,
            expandedHeight = 600,
            collapsedWidth = 540,
            collapsedHeight = 132,
            isCollapsed = false,
            autoCollapsedByCoordinator = false,
            userManuallyCollapsed = false,
            priority = AgyOverlayLayoutCoordinator.InteractionPriority.USER_INTERACTED,
            lastInteractionSeq = 5L
        )
        // Stranded at top-left, but autoFollowHud = true -> must snap just UP above HUD (flush-right)!
        val strandedMap = AgyOverlayLayoutCoordinator.WindowBoxState(
            id = AgyOverlayLayoutCoordinator.ManagedWindowId.TASK_MAP,
            visible = true,
            rect = Rect(24, 150, 708, 850),
            expandedWidth = 684,
            expandedHeight = 700,
            collapsedWidth = 340,
            collapsedHeight = 120,
            isCollapsed = false,
            autoCollapsedByCoordinator = false,
            userManuallyCollapsed = false,
            priority = AgyOverlayLayoutCoordinator.InteractionPriority.PASSIVE,
            lastInteractionSeq = 1L,
            autoFollowHud = true
        )

        val aboveRes = AgyOverlayLayoutCoordinator.solve(hudBottomRight, strandedMap, portraitVp)
        val aboveAdj = aboveRes.secondaryAdjustment
        assertNotNull("Auto-follow second window should move directly above HUD on portrait screen", aboveAdj)
        assertFalse(aboveAdj!!.targetCollapsed)
        assertEquals(hudBottomRight.rect.right - strandedMap.expandedWidth, aboveAdj.targetLeft)
        assertEquals(hudBottomRight.rect.top - portraitVp.gapPx - strandedMap.expandedHeight, aboveAdj.targetTop)

        // When HUD moves all the way to the top (no room above), second window stacks just BELOW HUD
        val hudTopRight = hudBottomRight.copy(rect = Rect(144, 120, 1056, 720))
        val belowRes = AgyOverlayLayoutCoordinator.solve(hudTopRight, strandedMap, portraitVp)
        val belowAdj = belowRes.secondaryAdjustment!!
        assertEquals(hudTopRight.rect.right - strandedMap.expandedWidth, belowAdj.targetLeft)
        assertEquals(hudTopRight.rect.bottom + portraitVp.gapPx, belowAdj.targetTop)

        // When compact HUD pill sits at bottom-right and compact TaskMap pill fits to its left -> docks LEFT of HUD
        val collapsedHudRight = hudBottomRight.copy(
            rect = Rect(556, 2118, 1056, 2250),
            isCollapsed = true,
            expandedWidth = 912,
            collapsedWidth = 500
        )
        val collapsedMapPill = strandedMap.copy(
            isCollapsed = true,
            collapsedWidth = 340,
            collapsedHeight = 120
        )
        val sideBySidePillRes = AgyOverlayLayoutCoordinator.solve(collapsedHudRight, collapsedMapPill, portraitVp)
        val pillAdj = sideBySidePillRes.secondaryAdjustment!!
        assertEquals(collapsedHudRight.rect.left - portraitVp.gapPx - collapsedMapPill.collapsedWidth, pillAdj.targetLeft)
        assertEquals(collapsedHudRight.rect.top, pillAdj.targetTop)
    }

    @Test
    fun `long press unlocks and moves second window separately while short drags stay with child views`() {
        ShadowSettings.setCanDrawOverlays(true)
        try {
            val floatingMgr = FloatingOverlayManager(context)
            val taskMapMgr = AgyTaskMapOverlayManager(context)
            val hudMgr = AgyHudOverlayManager(
                context = context,
                floatingOverlayManager = floatingMgr
            ).apply {
                taskMapOverlayManager = taskMapMgr
            }

            hudMgr.updateState(
                JSONObject()
                    .put("state", "WORKING")
                    .put("title", "Architecture Flow")
                    .put("detailedOutput", "```mermaid\ngraph TD\nA[App] --> B[Router]\nB --> C[Player]\n```")
            )
            shadowOf(Looper.getMainLooper()).idle()

            assertTrue(taskMapMgr.isMapVisibleFlow.value)
            assertTrue(taskMapMgr.autoFollowHud)
            val rootView = taskMapMgr.getRootWindowViewForTesting() as LongPressDraggableFrameLayout
            rootView.measure(
                android.view.View.MeasureSpec.makeMeasureSpec(700, android.view.View.MeasureSpec.AT_MOST),
                android.view.View.MeasureSpec.makeMeasureSpec(900, android.view.View.MeasureSpec.AT_MOST)
            )
            rootView.layout(0, 0, rootView.measuredWidth.coerceAtLeast(300), rootView.measuredHeight.coerceAtLeast(300))

            val initialRect = taskMapMgr.getOverlayRect()!!

            // 1. Short swipe immediately (< 240ms) must NOT trigger window drag
            val t0 = SystemClock.uptimeMillis()
            val quickDown = MotionEvent.obtain(t0, t0, MotionEvent.ACTION_DOWN, 120f, 120f, 0)
            rootView.dispatchTouchEvent(quickDown)
            val quickMove = MotionEvent.obtain(t0, t0 + 30, MotionEvent.ACTION_MOVE, 210f, 120f, 0)
            rootView.dispatchTouchEvent(quickMove)
            val quickUp = MotionEvent.obtain(t0, t0 + 50, MotionEvent.ACTION_UP, 210f, 120f, 0)
            rootView.dispatchTouchEvent(quickUp)
            quickDown.recycle()
            quickMove.recycle()
            quickUp.recycle()

            assertFalse(rootView.isHoldDragging())
            assertTrue("Short quick swipe must keep autoFollowHud enabled", taskMapMgr.autoFollowHud)

            // 2. Long press (>= 240ms hold) unlocks dragging and detaches second window cleanly
            val t1 = SystemClock.uptimeMillis()
            val holdDown = MotionEvent.obtain(t1, t1, MotionEvent.ACTION_DOWN, 150f, 150f, 0)
            rootView.dispatchTouchEvent(holdDown)
            shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMillis(260))

            assertTrue("Long press must activate hold-drag mode", rootView.isHoldDragging())
            assertFalse("Long-press drag must detach autoFollowHud so window stays separate", taskMapMgr.autoFollowHud)

            // Move finger smoothly while long-press drag is active
            val holdMove1 = MotionEvent.obtain(t1, t1 + 270, MotionEvent.ACTION_MOVE, 60f, 80f, 0)
            rootView.dispatchTouchEvent(holdMove1)
            val holdMove2 = MotionEvent.obtain(t1, t1 + 290, MotionEvent.ACTION_MOVE, 30f, 40f, 0)
            rootView.dispatchTouchEvent(holdMove2)
            val holdUp = MotionEvent.obtain(t1, t1 + 310, MotionEvent.ACTION_UP, 30f, 40f, 0)
            rootView.dispatchTouchEvent(holdUp)
            holdDown.recycle()
            holdMove1.recycle()
            holdMove2.recycle()
            holdUp.recycle()
            shadowOf(Looper.getMainLooper()).idle()

            assertFalse(rootView.isHoldDragging())
            val movedRect = taskMapMgr.getOverlayRect()!!
            assertTrue(
                "Second window should have moved separately from $initialRect to $movedRect",
                movedRect.left != initialRect.left || movedRect.top != initialRect.top
            )

            // 3. Subsequent HUD state updates & reconciliation keep second window at its separate spot
            hudMgr.patchState(JSONObject().put("elapsedSeconds", 12))
            shadowOf(Looper.getMainLooper()).idle()
            val afterHudPatchRect = taskMapMgr.getOverlayRect()!!
            assertEquals(movedRect.left, afterHudPatchRect.left)
            assertEquals(movedRect.top, afterHudPatchRect.top)
            assertFalse(taskMapMgr.autoFollowHud)

            // 4. User dismiss or HUD reset restores autoFollowHud for future sessions
            taskMapMgr.dismissByUser()
            assertTrue(taskMapMgr.autoFollowHud)
            hudMgr.hideAll()
            shadowOf(Looper.getMainLooper()).idle()
        } finally {
            ShadowSettings.setCanDrawOverlays(false)
        }
    }
}
