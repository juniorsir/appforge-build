# AI-Powered Operating System (AIOS) & Termux Automation Bridge

A state-of-the-art, high-performance Android application built with modern Jetpack Compose, Kotlin Coroutines, and local JVM testing paradigms. The app serves as a dual-purpose system:
1. **Sandboxed Multi-Agent Operating System (AIOS)** orchestrating complex tasks with 45+ hardware capabilities.
2. **Termux WebSocket Remote Bridge** providing bi-directional telemetry, real-time PCM audio streaming, live screen inspection, and remote gesture automation (taps, swipes, hardware keys) across any Android application.

---

## 🏛️ System Architecture

```text
                     ┌────────────────────────────────────────────────────────┐
                     │                     ANDROID DEVICE                     │
                     │                                                        │
                     │   ┌───────────────────────────┐                        │
                     │   │   Target Android Apps     │                        │
                     │   │  (Instagram, YouTube, UI) │                        │
                     │   └─────────────▲─────────────┘                        │
                     │                 │ Accessibility Events & Gestures      │
                     │   ┌─────────────┴──────────────────────────────────┐   │
                     │   │     Termux Assistant Accessibility Service      │   │
                     │   │   • Screen Node Tree Extraction                │   │
                     │   │   • Gesture Dispatcher (Click, Swipe, Scroll)   │   │
                     │   │   • Global Actions (Back, Home, Recents)        │   │
                     │   └─────────────▲──────────────────────────────────┘   │
                     │                 │ Internal Event Bus                   │
                     │   ┌─────────────┴──────────────────────────────────┐   │
                     │   │          AIOS Companion Core App               │   │
                     │   │   • WebSocket Repository (OkHttp wss://)       │   │
                     │   │   • Realtime Connection & PCM Audio Engine     │   │
                     │   │   • 45+ Device Capabilities (Sensors, Apps)    │   │
                     │   └─────────────▲──────────────────────────────────┘   │
                     └─────────────────┼──────────────────────────────────────┘
                                       │ Secure WebSocket (WSS / Cloudflare Tunnel)
                                       ▼
                     ┌────────────────────────────────────────────────────────┐
                     │                  TERMUX LINUX RUNTIME                  │
                     │                                                        │
                     │   ┌────────────────────────────────────────────────┐   │
                     │   │       Cloudflare Tunnel (cloudflared)          │   │
                     │   │   Exposes http://127.0.0.1:8000 via HTTPS/WSS  │   │
                     │   └─────────────────────▲──────────────────────────┘   │
                     │                         │                              │
                     │   ┌─────────────────────┴──────────────────────────┐   │
                     │   │       Termux WebSocket Server (mock_server.py) │   │
                     │   │   • Heartbeat PING/PONG & RTT latency monitor  │   │
                     │   │   • Bidirectional Message & Telemetry Relay    │   │
                     │   └─────────────▲──────────────────────────────────┘   │
                     │                 │ Local IPC (ws://127.0.0.1:8000)      │
                     │   ┌─────────────┴──────────────────────────────────┐   │
                     │   │       CLI Controller (send_cmd.py) / Scripts   │   │
                     │   │   • inspect, click, swipe, tap, back, home     │   │
                     │   │   • Automated Python & Bash bots               │   │
                     │   └────────────────────────────────────────────────┘   │
                     └────────────────────────────────────────────────────────┘
```

---

## 🚀 Key Subsystems

### 1. Termux Assistant Accessibility Service
* **Zero-Touch Node Extraction**: Reads the complete UI accessibility hierarchy (`AccessibilityNodeInfo`) of the foreground window, extracting text, content descriptions, clickable states, and screen bounding boxes.
* **Coordinate Mapping**: Automatically calculates the center point `(X, Y)` for all interactive elements.
* **Remote Gesture Execution**: Dispatches simulated input strokes (`dispatchGesture`) directly to the Android display server for taps, swipes, and drags.
* **System Hardware Actions**: Dispatches native Android global actions (`GLOBAL_ACTION_BACK`, `GLOBAL_ACTION_HOME`, `GLOBAL_ACTION_RECENTS`, `GLOBAL_ACTION_NOTIFICATIONS`).

### 2. Bi-directional WebSocket Protocol
* **Resilient Connection Loop**: Implements OkHttp WebSocket listeners with exponential backoff reconnects and cleartext HTTP/HTTPS/WSS support.
* **Heartbeat & Latency Tracking**: Continuous `PING`/`PONG` round-trip measurement displayed in the Developer Terminal.
* **Typed Serialization**: Strict schema validation via `kotlinx.serialization` for 14+ message models.

### 3. Real-Time Audio Streaming Engine
* **Low-Latency PCM Capture**: 16-bit, 16kHz linear PCM recorded via `AudioRecord` in an Android Foreground Service.
* **Chunk Streaming**: Raw audio frames are encoded in Base64 and streamed in real time to Termux for external STT/AI ingestion.

### 4. Sandboxed Multi-Agent AIOS Engine
* **15 Specialized Agents**: Processes for code generation, local databases, camera, calendar, translation, and notifications.
* **Task Planning Engine**: Generates dependency-aligned DAGs from unstructured prompts, supporting parallel/sequential execution clusters.
* **Security & Capability Registry**: 45+ Android hardware capabilities (Battery, Haptics, Flashlight, Location, Installed Packages, Clipboard) accessible via unified APIs.

---

## 💻 Termux Setup & Usage Guide

### Prerequisites
Inside Termux, install Python and Cloudflare Tunnel:
```bash
pkg update -y
pkg install -y python cloudflared nano
pip install websockets
```

---

### Step 1: Start the Cloudflare Tunnel
In Termux (Session 1):
```bash
cloudflared tunnel --url http://127.0.0.1:8000
```
*Note the generated public URL, e.g.:*
`https://your-tunnel-name.trycloudflare.com`

---

### Step 2: Start the Termux WebSocket Server
In Termux (Session 2), create and launch `mock_server.py`:
```bash
python mock_server.py
```

#### Complete `mock_server.py` Code:
```python
import asyncio
import json
import time
import websockets

CONNECTED_CLIENTS = set()

def get_ms():
    return int(time.time() * 1000)

async def handle_incoming_message(websocket, raw_data, session_state):
    try:
        data = json.loads(raw_data)
    except Exception:
        return

    msg_type = data.get("type", "UNKNOWN")
    session_id = data.get("sessionId", "termux-session")

    # 1. Heartbeat PING -> PONG
    if msg_type == "PING":
        pong = {
            "type": "PONG",
            "timestamp": get_ms(),
            "sessionId": session_id,
            "pingId": data.get("pingId", "1"),
            "requestTimestamp": data.get("timestamp", get_ms())
        }
        await websocket.send(json.dumps(pong))
        return

    # 2. Forward CLI commands to the Android App
    if msg_type in ["ACCESSIBILITY_GESTURE", "ACCESSIBILITY_INSPECT", "AI_STREAM"]:
        other_clients = [c for c in CONNECTED_CLIENTS if c != websocket]
        for client in other_clients:
            await client.send(raw_data)
        return

    # 3. Handle response from Android Phone
    if msg_type == "ACCESSIBILITY_INSPECT_RESULT":
        nodes = data.get("nodes", [])
        print(f"\n[INSPECT RESULT] Phone returned {len(nodes)} root node(s)")
        # Forward result back to CLI
        for client in [c for c in CONNECTED_CLIENTS if c != websocket]:
            await client.send(raw_data)
        return

    # 4. Audio streaming frames
    if msg_type == "AUDIO_STREAM":
        session_state["audio_packets"] += 1
        if session_state["audio_packets"] % 50 == 1:
            print(f"\r[AUDIO] Streaming active | Packets: {session_state['audio_packets']}", end="", flush=True)
        return

    if msg_type == "AUDIO_END":
        print(f"\n[AUDIO] Stream ended. Total frames: {session_state['audio_packets']}")
        session_state["audio_packets"] = 0
        return

async def ws_handler(websocket, *args):
    CONNECTED_CLIENTS.add(websocket)
    client_ip = getattr(websocket, 'remote_address', 'client')
    print(f"\n[CONNECTED] Client connected from {client_ip} (Total active: {len(CONNECTED_CLIENTS)})")
    
    session_state = {"audio_packets": 0}
    await websocket.send(json.dumps({
        "type": "HELLO",
        "timestamp": get_ms(),
        "sessionId": "termux",
        "clientName": "TermuxServer",
        "deviceId": "termux",
        "protocolVersion": "1.0"
    }))

    try:
        async for message in websocket:
            await handle_incoming_message(websocket, message, session_state)
    except websockets.exceptions.ConnectionClosed:
        pass
    finally:
        CONNECTED_CLIENTS.discard(websocket)
        print(f"\n[DISCONNECTED] Client left (Remaining active: {len(CONNECTED_CLIENTS)})")

async def main():
    print("==================================================")
    print("  Termux WebSocket Relay Server Active")
    print("  Listening on ws://127.0.0.1:8000")
    print("==================================================")
    server = await websockets.serve(ws_handler, "127.0.0.1", 8000)
    await server.wait_closed()

if __name__ == "__main__":
    asyncio.run(main())
```

---

### Step 3: Connect from the Android App
1. Open the Android application.
2. Navigate to **Termux Link Monitor / Developer Screen** (tap `{ }` icon).
3. In **Server Configuration**, paste your Cloudflare WebSocket endpoint:
   `wss://your-tunnel-name.trycloudflare.com/ws`
4. Tap **Connect**.
5. Enable **Termux Assistant** in your Android device's **Settings ➔ Accessibility** to authorize remote screen inspection and gestures.

---

### Step 4: Control & Automate with the CLI (`send_cmd.py`)

Create `send_cmd.py` in Termux:

#### Complete `send_cmd.py` Code:
```python
import asyncio
import json
import re
import sys
import time
import websockets

SERVER_URL = "ws://127.0.0.1:8000/ws"

def parse_center(bounds_str):
    try:
        nums = [int(n) for n in re.findall(r'\d+', bounds_str)]
        if len(nums) == 4:
            return (nums[0] + nums[2]) // 2, (nums[1] + nums[3]) // 2
    except Exception:
        pass
    return None, None

def print_tree(node, depth=0, find_text=None, matched_targets=None):
    text = node.get("text") or node.get("contentDescription")
    cls_name = (node.get("className") or "View").split(".")[-1]
    bounds = node.get("bounds", "")
    cx, cy = parse_center(bounds)
    is_clickable = node.get("isClickable", False)

    indent = "  " * depth

    if find_text and text and find_text.lower() in text.lower():
        if matched_targets is not None and cx and cy:
            matched_targets.append((text, cx, cy))

    if text:
        click_hint = f"-> click {cx} {cy}" if (cx and is_clickable) else ""
        print(f"{indent}• [{cls_name}] \"{text}\" {click_hint}")
    elif is_clickable and cx and cy:
        print(f"{indent}• [{cls_name}] (clickable area) -> click {cx} {cy}")

    for child in node.get("children", []):
        print_tree(child, depth + 1, find_text, matched_targets)

async def main():
    if len(sys.argv) < 2:
        print("Usage:")
        print("  python send_cmd.py apps [filter] [--system] : List installed Android applications")
        print("  python send_cmd.py open <appName|pkg|url>   : Open / launch app or URL")
        print("  python send_cmd.py inspect [delay_sec]     : View phone screen UI hierarchy")
        print("  python send_cmd.py click <x> <y>          : Tap screen at (X, Y)")
        print("  python send_cmd.py tap <text>             : Tap element by label")
        print("  python send_cmd.py swipe <x1> <y1> <x2> <y2> [duration] : Swipe screen")
        print("  python send_cmd.py next                   : Scroll to next post/reel")
        print("  python send_cmd.py back                   : Trigger Android Back")
        print("  python send_cmd.py home                   : Trigger Android Home")
        print("  python send_cmd.py recents                : Open Recent Apps overview")
        print("  python send_cmd.py notifications          : Open Notification panel")
        print("  python send_cmd.py <message text>         : Pop up toast on phone")
        return

    cmd = sys.argv[1].lower()

    async with websockets.connect(SERVER_URL) as ws:
        try:
            await asyncio.wait_for(ws.recv(), timeout=1.0)
        except Exception:
            pass

        # 1. System Hardware Actions
        if cmd in ["back", "home", "recents", "notifications"]:
            payload = {
                "type": "ACCESSIBILITY_GESTURE",
                "timestamp": int(time.time() * 1000),
                "sessionId": "termux-cli",
                "gestureId": f"{cmd}-{int(time.time())}",
                "gestureType": cmd.upper(),
                "startX": 0.0,
                "startY": 0.0,
                "durationMs": 50
            }
            await ws.send(json.dumps(payload))
            print(f"Executed: {cmd.upper()}")

        # 2. Inspect UI Hierarchy
        elif cmd == "inspect":
            delay = int(sys.argv[2]) if len(sys.argv) > 2 and sys.argv[2].isdigit() else 0
            if delay > 0:
                print(f"Switch to target app! Inspecting in {delay}s...")
                for i in range(delay, 0, -1):
                    print(f" {i}...", end="", flush=True)
                    await asyncio.sleep(1)
                print(" Inspecting!")

            payload = {
                "type": "ACCESSIBILITY_INSPECT",
                "timestamp": int(time.time() * 1000),
                "sessionId": "termux-cli"
            }
            await ws.send(json.dumps(payload))
            reply = await asyncio.wait_for(ws.recv(), timeout=5.0)
            data = json.loads(reply)
            print("\n" + "="*50)
            print(" SCREEN UI HIERARCHY:")
            print("="*50)
            for root in data.get("nodes", []):
                print_tree(root)
            print("="*50)

        # 3. Next Post / Reel Scroll
        elif cmd == "next":
            payload = {
                "type": "ACCESSIBILITY_GESTURE",
                "timestamp": int(time.time() * 1000),
                "sessionId": "termux-cli",
                "gestureId": f"next-{int(time.time())}",
                "gestureType": "SWIPE",
                "startX": 500.0,
                "startY": 1400.0,
                "endX": 500.0,
                "endY": 300.0,
                "durationMs": 250
            }
            await ws.send(json.dumps(payload))
            print("Scrolled to next post/reel!")

        # 4. Click Coordinates
        elif cmd == "click" and len(sys.argv) >= 4:
            x, y = float(sys.argv[2]), float(sys.argv[3])
            payload = {
                "type": "ACCESSIBILITY_GESTURE",
                "timestamp": int(time.time() * 1000),
                "sessionId": "termux-cli",
                "gestureId": f"click-{int(time.time())}",
                "gestureType": "CLICK",
                "startX": x,
                "startY": y,
                "durationMs": 100
            }
            await ws.send(json.dumps(payload))
            print(f"Tapped at ({x}, {y})")

        # 5. Tap by Text Label
        elif cmd == "tap" and len(sys.argv) >= 3:
            target_name = " ".join(sys.argv[2:])
            payload = {
                "type": "ACCESSIBILITY_INSPECT",
                "timestamp": int(time.time() * 1000),
                "sessionId": "termux-cli"
            }
            await ws.send(json.dumps(payload))
            reply = await asyncio.wait_for(ws.recv(), timeout=5.0)
            data = json.loads(reply)
            matches = []
            for root in data.get("nodes", []):
                print_tree(root, find_text=target_name, matched_targets=matches)

            if matches:
                found_text, tx, ty = matches[0]
                click_payload = {
                    "type": "ACCESSIBILITY_GESTURE",
                    "timestamp": int(time.time() * 1000),
                    "sessionId": "termux-cli",
                    "gestureId": f"click-{int(time.time())}",
                    "gestureType": "CLICK",
                    "startX": float(tx),
                    "startY": float(ty),
                    "durationMs": 100
                }
                await ws.send(json.dumps(click_payload))
                print(f"Tapped \"{found_text}\" at ({tx}, {ty})")
            else:
                print(f"Could not find element matching \"{target_name}\" on screen.")

        # 6. Toast Notification
        else:
            msg = " ".join(sys.argv[1:])
            payload = {
                "type": "AI_STREAM",
                "timestamp": int(time.time() * 1000),
                "sessionId": "termux-cli",
                "textChunk": msg,
                "isFinal": True
            }
            await ws.send(json.dumps(payload))
            print(f"Toast displayed on phone: \"{msg}\"")

if __name__ == "__main__":
    asyncio.run(main())
```

---

## 📖 CLI Command Reference

| Command | Arguments | Description | Example |
|---|---|---|---|
| `apps` | `[filter] [--system] [--json]` | Lists installed Android applications with package name, version, and type. | `python send_cmd.py apps termux` |
| `open` | `<app_name \| packageName \| url>` | Launches an app by name, package name, or opens a URL in the browser. | `python send_cmd.py open YouTube` |
| `inspect` | `[delay_seconds]` | Scans foreground window and prints all UI elements with calculated click coordinates. | `python send_cmd.py inspect 3` |
| `click` | `<x> <y>` | Taps exact screen pixel coordinates. | `python send_cmd.py click 500 800` |
| `tap` | `<label>` | Finds UI component matching text/contentDescription and taps it. | `python send_cmd.py tap Like` |
| `next` | *None* | Dispatches upward swipe gesture to scroll reels/feeds. | `python send_cmd.py next` |
| `back` | *None* | Performs native Android system Back keypress. | `python send_cmd.py back` |
| `home` | *None* | Performs native Android system Home keypress. | `python send_cmd.py home` |
| `recents` | *None* | Opens Android Recent Apps switcher. | `python send_cmd.py recents` |
| `notifications` | *None* | Pulls down Android notification drawer. | `python send_cmd.py notifications` |
| *`<any text>`* | *None* | Displays a live Android Toast message on the phone screen. | `python send_cmd.py "Hello!"` |

---

## 📡 WebSocket Protocol Specification

All WebSocket communication uses JSON with a common envelope:

| Message Type | Direction | Key Fields | Purpose |
|---|---|---|---|
| `HELLO` | Both | `clientName`, `protocolVersion` | Handshake initialization |
| `PING` / `PONG` | Client ➔ Server ➔ Client | `pingId`, `requestTimestamp` | Keepalive & round-trip latency (RTT) calculation |
| `ACCESSIBILITY_INSPECT` | Termux ➔ Phone | `searchByText`, `searchByDesc` | Requests screen UI node tree |
| `ACCESSIBILITY_INSPECT_RESULT` | Phone ➔ Termux | `nodes` (hierarchical array) | Returns UI element text, bounds, class names |
| `ACCESSIBILITY_GESTURE` | Termux ➔ Phone | `gestureType`, `startX`, `startY`, `endX`, `endY` | Triggers clicks, swipes, or global hardware buttons |
| `AUDIO_STREAM` | Phone ➔ Termux | `sequenceNumber`, `dataBase64` | 16kHz 16-bit linear PCM microphone frames |
| `AUDIO_END` | Phone ➔ Termux | *None* | Signals microphone stream termination |
| `AI_STREAM` | Termux ➔ Phone | `textChunk`, `isFinal` | Displays token text / pop-up messages on phone |

---

## 📁 Package Organization

```text
app/src/main/java/com/example/
├── accessibility/      # AccessibilityServiceRegistry, Gestures, Node Inspection
├── aios/               # Multi-Agent Virtual OS (Agents, Planning, Workflow Engine)
├── audio/              # PCM Audio Record capture & chunking engine
├── capabilities/       # 45+ Device capabilities (Sensors, Apps, Battery, GPS)
├── data/               # Room Database, Repositories, WebSocket Client
├── di/                 # Thread-safe Service Locator (AppContainer)
├── domain/             # Repository interfaces, Models, NetworkMessage types
├── presentation/       # Jetpack Compose Screens (Developer, Speech, Tools)
├── services/           # RealtimeConnectionService (Foreground Service)
├── tools/              # Developer Diagnostics and System Utilities
└── ui/                 # Material 3 Theme, Typography, Layout Components
```

---

## 🧪 Build and Test Commands

### Compile & Build Debug APK
```bash
gradle :app:assembleDebug
```

### Run JVM Unit and Integration Tests
```bash
gradle :app:testDebugUnitTest
```
