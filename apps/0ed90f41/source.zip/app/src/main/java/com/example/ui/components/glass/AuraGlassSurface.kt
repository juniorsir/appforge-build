package com.example.ui.components.glass

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.theme.AuraBorders
import com.example.ui.theme.AuraColors
import com.example.ui.theme.AuraGlassLevel
import com.example.ui.theme.AuraGlowLevel
import com.example.ui.theme.AuraMotion
import com.example.ui.theme.AuraShapes
import com.example.ui.theme.rememberReducedMotion

/**
 * AURA ASSISTANT — Core Liquid Glass Surface Primitive
 * Smoked dark translucent glass with subtle top highlight and micro-border stroke.
 */
@Composable
fun AuraGlassSurface(
    modifier: Modifier = Modifier,
    shape: Shape = AuraShapes.Large,
    level: AuraGlassLevel = AuraGlassLevel.LEVEL_2,
    customBgAlpha: Float? = null,
    customBorderAlpha: Float? = null,
    borderWidth: Dp = AuraBorders.WidthNormal,
    contentPadding: PaddingValues = PaddingValues(0.dp),
    showHighlight: Boolean = true,
    glowLevel: AuraGlowLevel = AuraGlowLevel.NONE,
    content: @Composable BoxScope.() -> Unit
) {
    val bgAlpha = customBgAlpha ?: level.bgAlpha
    val borderAlpha = customBorderAlpha ?: level.borderAlpha

    val backgroundColor = AuraColors.White.copy(alpha = bgAlpha.coerceIn(0f, 1f))
    val borderColor = AuraColors.White.copy(alpha = borderAlpha.coerceIn(0f, 1f))

    val highlightBrush = remember(level) { level.createHighlightBrush() }

    Box(
        modifier = modifier
            .clip(shape)
            .background(backgroundColor, shape)
            .then(
                if (showHighlight) {
                    Modifier.background(highlightBrush, shape)
                } else {
                    Modifier
                }
            )
            .border(
                BorderStroke(borderWidth, borderColor),
                shape
            )
            .padding(contentPadding),
        content = content
    )
}

/**
 * Interactive Aura Glass Card with tactile soft press micro-interaction and focus.
 */
@Composable
fun AuraGlassCard(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    shape: Shape = AuraShapes.Large,
    level: AuraGlassLevel = AuraGlassLevel.LEVEL_2,
    borderWidth: Dp = AuraBorders.WidthNormal,
    contentPadding: PaddingValues = PaddingValues(16.dp),
    showHighlight: Boolean = true,
    content: @Composable BoxScope.() -> Unit
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val isFocused by interactionSource.collectIsFocusedAsState()
    val reducedMotion = rememberReducedMotion()

    val scale by animateFloatAsState(
        targetValue = if (isPressed && enabled) AuraMotion.PressScalePressed else AuraMotion.PressScaleNormal,
        animationSpec = if (reducedMotion) AuraMotion.microTween() else AuraMotion.PressSpring,
        label = "AuraCardPressScale"
    )

    val currentLevel = when {
        !enabled -> AuraGlassLevel.LEVEL_1 // Disabled
        isPressed -> AuraGlassLevel.ACTIVE
        isFocused -> AuraGlassLevel.LEVEL_3
        else -> level
    }
    
    val baseBorderAlpha = currentLevel.borderAlpha
    val focusedBorderAlpha = if (isFocused) baseBorderAlpha + 0.1f else baseBorderAlpha
    val finalBgAlpha = if (!enabled) currentLevel.bgAlpha * 0.5f else currentLevel.bgAlpha

    val animatedBgAlpha by animateFloatAsState(
        targetValue = finalBgAlpha,
        animationSpec = AuraMotion.microTween(),
        label = "BgAlphaAnim"
    )
    
    val animatedBorderAlpha by animateFloatAsState(
        targetValue = focusedBorderAlpha,
        animationSpec = AuraMotion.microTween(),
        label = "BorderAlphaAnim"
    )

    AuraGlassSurface(
        modifier = modifier
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
                alpha = if (!enabled) 0.6f else 1f
            }
            .clickable(
                interactionSource = interactionSource,
                indication = null, // Handled softly via scale/glass shift
                enabled = enabled,
                onClick = onClick
            ),
        shape = shape,
        level = currentLevel,
        customBgAlpha = animatedBgAlpha,
        customBorderAlpha = animatedBorderAlpha,
        borderWidth = if (isFocused) AuraBorders.WidthFocused else borderWidth,
        contentPadding = contentPadding,
        showHighlight = showHighlight && enabled,
        content = content
    )
}
