package com.example.ui.components.engine

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.ui.theme.AuraColors
import com.example.ui.theme.MyApplicationTheme

/**
 * AURA ASSISTANT — Phase 6: Core Engine & Persistence Previews
 */
@Composable
private fun CoreEnginePreviewContainer(
    engineState: AuraCoreEngineState,
    provider: String = "Gemini Live",
    modelName: String = "gemini-2.5-flash",
    connectionText: String = "Connected",
    latencyOrDuration: String = "Real-time",
    actionText: String? = null,
    errorMessage: String? = null,
    persistenceState: AuraPersistenceState = AuraPersistenceState.SYNCED,
    historyCount: Int = 12,
    reducedMotion: Boolean = false
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(AuraColors.Background)
            .padding(16.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            AuraCoreEngineCard(
                engineState = engineState,
                provider = provider,
                modelName = modelName,
                connectionText = connectionText,
                latencyOrDuration = latencyOrDuration,
                actionText = actionText,
                onActionClick = {},
                errorMessage = errorMessage,
                reducedMotion = reducedMotion
            )

            AuraPersistenceCard(
                persistenceState = persistenceState,
                storageEngine = "Room SQLite v1",
                historyCount = historyCount,
                reducedMotion = reducedMotion
            )
        }
    }
}

@Preview(name = "1. Engine Ready (411dp)", widthDp = 411, heightDp = 380)
@Composable
fun PreviewAuraEngineReady() {
    MyApplicationTheme {
        CoreEnginePreviewContainer(
            engineState = AuraCoreEngineState.READY,
            provider = "Gemini Live",
            modelName = "gemini-2.5-flash",
            connectionText = "Connected",
            latencyOrDuration = "38 ms",
            actionText = "End Stream",
            persistenceState = AuraPersistenceState.SYNCED,
            historyCount = 24
        )
    }
}

@Preview(name = "2. Engine Connecting (411dp)", widthDp = 411, heightDp = 380)
@Composable
fun PreviewAuraEngineConnecting() {
    MyApplicationTheme {
        CoreEnginePreviewContainer(
            engineState = AuraCoreEngineState.CONNECTING,
            provider = "Gemini Live",
            modelName = "gemini-2.5-flash",
            connectionText = "Connecting...",
            latencyOrDuration = "—",
            actionText = "Connecting...",
            persistenceState = AuraPersistenceState.SYNCED,
            historyCount = 10
        )
    }
}

@Preview(name = "3. Engine Processing (411dp)", widthDp = 411, heightDp = 380)
@Composable
fun PreviewAuraEngineProcessing() {
    MyApplicationTheme {
        CoreEnginePreviewContainer(
            engineState = AuraCoreEngineState.PROCESSING,
            provider = "Gemini Live",
            modelName = "gemini-2.5-flash",
            connectionText = "Connected",
            latencyOrDuration = "42 ms",
            actionText = "Interrupt",
            persistenceState = AuraPersistenceState.ACTIVE,
            historyCount = 15
        )
    }
}

@Preview(name = "4. Engine Disconnected (411dp)", widthDp = 411, heightDp = 380)
@Composable
fun PreviewAuraEngineDisconnected() {
    MyApplicationTheme {
        CoreEnginePreviewContainer(
            engineState = AuraCoreEngineState.DISCONNECTED,
            provider = "Gemini Live",
            modelName = "gemini-2.5-flash",
            connectionText = "Standby",
            latencyOrDuration = "—",
            actionText = "Start Stream",
            persistenceState = AuraPersistenceState.IDLE,
            historyCount = 0
        )
    }
}

@Preview(name = "5. Engine Error (411dp)", widthDp = 411, heightDp = 420)
@Composable
fun PreviewAuraEngineError() {
    MyApplicationTheme {
        CoreEnginePreviewContainer(
            engineState = AuraCoreEngineState.ERROR,
            provider = "Gemini Live",
            modelName = "gemini-2.5-flash",
            connectionText = "Disconnected",
            latencyOrDuration = "—",
            actionText = "Reconnect",
            errorMessage = "WebSocket handshake failed (SSL_ERROR_WANT_READ)",
            persistenceState = AuraPersistenceState.ERROR,
            historyCount = 5
        )
    }
}

@Preview(name = "6. Persistence Enabled / Synced (411dp)", widthDp = 411, heightDp = 180)
@Composable
fun PreviewAuraPersistenceEnabled() {
    MyApplicationTheme {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(AuraColors.Background)
                .padding(16.dp)
        ) {
            AuraPersistenceCard(
                persistenceState = AuraPersistenceState.SYNCED,
                storageEngine = "Room SQLite v1",
                historyCount = 38
            )
        }
    }
}

@Preview(name = "7. Persistence Idle / Empty (411dp)", widthDp = 411, heightDp = 180)
@Composable
fun PreviewAuraPersistenceDisabled() {
    MyApplicationTheme {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(AuraColors.Background)
                .padding(16.dp)
        ) {
            AuraPersistenceCard(
                persistenceState = AuraPersistenceState.IDLE,
                storageEngine = "Room SQLite v1",
                historyCount = 0
            )
        }
    }
}

@Preview(name = "8. Narrow Phone (340dp)", widthDp = 340, heightDp = 450)
@Composable
fun PreviewAuraEngineNarrowPhone() {
    MyApplicationTheme {
        CoreEnginePreviewContainer(
            engineState = AuraCoreEngineState.READY,
            provider = "Gemini Live",
            modelName = "gemini-2.5-flash",
            connectionText = "Connected",
            latencyOrDuration = "35 ms",
            actionText = "End Stream",
            persistenceState = AuraPersistenceState.SYNCED,
            historyCount = 18
        )
    }
}

@Preview(name = "9. Tablet (800dp)", widthDp = 800, heightDp = 350)
@Composable
fun PreviewAuraEngineTablet() {
    MyApplicationTheme {
        CoreEnginePreviewContainer(
            engineState = AuraCoreEngineState.READY,
            provider = "Gemini Live",
            modelName = "gemini-2.5-flash",
            connectionText = "Connected",
            latencyOrDuration = "28 ms",
            actionText = "End Stream",
            persistenceState = AuraPersistenceState.SYNCED,
            historyCount = 42
        )
    }
}

@Preview(name = "10. Landscape (700dp)", widthDp = 700, heightDp = 350)
@Composable
fun PreviewAuraEngineLandscape() {
    MyApplicationTheme {
        CoreEnginePreviewContainer(
            engineState = AuraCoreEngineState.READY,
            provider = "Gemini Live",
            modelName = "gemini-2.5-flash",
            connectionText = "Connected",
            latencyOrDuration = "32 ms",
            actionText = "End Stream",
            persistenceState = AuraPersistenceState.SYNCED,
            historyCount = 30
        )
    }
}
