package com.example.domain.repository

import com.example.domain.model.BrainConversation
import com.example.domain.model.BrainMessage
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.StateFlow

interface ConversationRepository {

    /**
     * Currently active conversation. Emits updates when active conversation changes or is reset.
     */
    val activeConversation: StateFlow<BrainConversation?>

    /**
     * Maximum history length of messages to keep before trimming.
     */
    var maxHistoryLength: Int

    /**
     * Sets the active conversation ID.
     */
    suspend fun setActiveConversation(conversationId: String)

    /**
     * Creates a new conversation and sets it as the active conversation.
     */
    suspend fun createNewConversation(title: String): BrainConversation

    /**
     * Returns a Flow of all conversations.
     */
    fun getAllConversations(): Flow<List<BrainConversation>>

    /**
     * Retrieves messages for the active conversation.
     */
    fun getMessagesFlow(conversationId: String): Flow<List<BrainMessage>>

    /**
     * Synchronously/Suspend gets messages list for context building.
     */
    suspend fun getMessages(conversationId: String): List<BrainMessage>

    /**
     * Adds a user or assistant message to the conversation.
     * Automatically triggers [trimHistoryIfNeeded] to keep conversation length under [maxHistoryLength].
     */
    suspend fun addMessage(message: BrainMessage)

    /**
     * Trims messages if they exceed [maxHistoryLength], leaving older messages or optionally summarizing them.
     */
    suspend fun trimHistoryIfNeeded(conversationId: String)

    /**
     * Resets/clears the conversation history (deletes messages or archives them).
     */
    suspend fun resetConversation(conversationId: String)

    /**
     * Triggers a summarization of older messages in the conversation.
     * This replaces messages before the trim cutoff with a single system-level summary.
     */
    suspend fun summarizeOlderMessages(conversationId: String, keepCount: Int)
}
