package com.example.data.repository

import com.example.data.local.ChatMessageEntity
import com.example.data.local.CompanionConfigEntity
import com.example.data.local.CompanionDao
import com.example.data.remote.RealtimeWebSocketClient
import com.example.domain.model.ChatMessage
import com.example.domain.model.CompanionConfig
import com.example.domain.model.SessionState
import com.example.domain.repository.CompanionRepository
import com.example.util.AppLogger
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.UUID

/**
 * Concrete implementation of [CompanionRepository].
 * Mediates data access between the local Room DB storage and remote WebSocket channels.
 */
class CompanionRepositoryImpl(
    private val companionDao: CompanionDao,
    private val webSocketClient: RealtimeWebSocketClient,
    private val logger: AppLogger,
    private val scope: CoroutineScope
) : CompanionRepository {

    private val tag = "CompanionRepo"

    // Backing memory state flow for active session telemetry metrics
    private val _sessionState = MutableStateFlow(SessionState(sessionId = UUID.randomUUID().toString()))
    override fun getSessionState(): Flow<SessionState> = _sessionState.asStateFlow()

    init {
        // Collect real-time WebSocket connection state updates and map to repository state
        scope.launch {
            webSocketClient.connectionState.collect { connectionState ->
                val current = _sessionState.value
                val updatedState = when (connectionState) {
                    SessionState.ConnectionState.CONNECTED -> {
                        logger.i(tag, "Streaming connected, starting timer tick...")
                        current.copy(connectionState = SessionState.ConnectionState.CONNECTED, error = null)
                    }
                    SessionState.ConnectionState.AUTHENTICATING -> {
                        current.copy(connectionState = SessionState.ConnectionState.AUTHENTICATING)
                    }
                    SessionState.ConnectionState.CONNECTING -> {
                        current.copy(connectionState = SessionState.ConnectionState.CONNECTING)
                    }
                    SessionState.ConnectionState.RECONNECTING -> {
                        current.copy(connectionState = SessionState.ConnectionState.RECONNECTING)
                    }
                    SessionState.ConnectionState.DISCONNECTED -> {
                        current.copy(connectionState = SessionState.ConnectionState.DISCONNECTED)
                    }
                    SessionState.ConnectionState.ERROR -> {
                        current.copy(connectionState = SessionState.ConnectionState.ERROR, error = "Connection lost.")
                    }
                }
                _sessionState.value = updatedState
            }
        }

        // Collect incoming assistant streams from WebSocket and append to database transcripts
        scope.launch {
            webSocketClient.incomingMessages.collect { text ->
                logger.i(tag, "Received real-time response from assistant, persisting to Room database.")
                val message = ChatMessage(
                    id = UUID.randomUUID().toString(),
                    sender = ChatMessage.Sender.ASSISTANT,
                    text = text,
                    timestamp = System.currentTimeMillis()
                )
                addChatMessage(message)
            }
        }
    }

    // --- Configuration Layer ---

    override fun getCompanionConfig(): Flow<CompanionConfig> {
        return companionDao.getCompanionConfigFlow().map { entity ->
            if (entity == null) {
                logger.d(tag, "No configuration found in database. Initializing default.")
                // Initialize default database record asynchronously
                scope.launch { saveCompanionConfig(CompanionConfig()) }
                CompanionConfig()
            } else {
                entity.toDomain()
            }
        }
    }

    override suspend fun saveCompanionConfig(config: CompanionConfig) {
        logger.d(tag, "Saving Companion Configuration to Room DB: $config")
        companionDao.insertCompanionConfig(config.toEntity())
    }

    // --- Conversation History Layer ---

    override fun getSessionHistory(): Flow<List<ChatMessage>> {
        return companionDao.getChatMessagesFlow().map { list ->
            list.map { it.toDomain() }
        }
    }

    override suspend fun addChatMessage(message: ChatMessage) {
        logger.d(tag, "Persisting chat entry of sender=${message.sender} to Room Database.")
        companionDao.insertChatMessage(message.toEntity())
    }

    override suspend fun clearSessionHistory() {
        logger.i(tag, "Purging conversation transcripts from Room database.")
        companionDao.clearChatMessages()
    }

    // --- Stream Control APIs ---

    override suspend fun updateSessionState(state: SessionState) {
        _sessionState.value = state
    }

    override suspend fun connectStream() {
        val serverUrl = "wss://api.example.com/v1/assistant/stream"
        webSocketClient.connect(serverUrl)
    }

    override suspend fun disconnectStream() {
        webSocketClient.disconnect()
    }

    override suspend fun sendStreamMessage(text: String) {
        webSocketClient.send(text)
    }

    // --- Entity Mappers ---

    private fun CompanionConfigEntity.toDomain() = CompanionConfig(
        id = id,
        modelName = modelName,
        systemInstruction = systemInstruction,
        voiceName = voiceName,
        speechRate = speechRate,
        isMicMuted = isMicMuted,
        isCameraEnabled = isCameraEnabled,
        lastUpdated = lastUpdated
    )

    private fun CompanionConfig.toEntity() = CompanionConfigEntity(
        id = id,
        modelName = modelName,
        systemInstruction = systemInstruction,
        voiceName = voiceName,
        speechRate = speechRate,
        isMicMuted = isMicMuted,
        isCameraEnabled = isCameraEnabled,
        lastUpdated = lastUpdated
    )

    private fun ChatMessageEntity.toDomain() = ChatMessage(
        id = id,
        sender = ChatMessage.Sender.valueOf(sender),
        text = text,
        timestamp = timestamp
    )

    private fun ChatMessage.toEntity() = ChatMessageEntity(
        id = id,
        sender = sender.name,
        text = text,
        timestamp = timestamp
    )
}
