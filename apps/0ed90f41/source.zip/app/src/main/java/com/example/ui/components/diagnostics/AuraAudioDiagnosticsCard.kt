package com.example.ui.components.diagnostics

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.glass.AuraGlassSurface
import com.example.ui.theme.AuraBorders
import com.example.ui.theme.AuraColors
import com.example.ui.theme.AuraDimensions
import com.example.ui.theme.AuraGlassLevel
import com.example.ui.theme.AuraMotion
import com.example.ui.theme.AuraShapes
import com.example.ui.theme.AuraSpacing
import com.example.ui.theme.AuraTypography
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.sin

/**
 * Real UI status enum for Audio Engine diagnostics.
 */
enum class AuraAudioStatus(
    val badgeLabel: String,
    val isPulsing: Boolean
) {
    ACTIVE(badgeLabel = "ACTIVE", isPulsing = true),
    IDLE(badgeLabel = "IDLE", isPulsing = false),
    PAUSED(badgeLabel = "PAUSED", isPulsing = false),
    NO_PERMISSION(badgeLabel = "NO PERMISSION", isPulsing = true),
    UNAVAILABLE(badgeLabel = "UNAVAILABLE", isPulsing = false),
    ERROR(badgeLabel = "ERROR", isPulsing = true);

    val tag: String get() = badgeLabel
}

/**
 * AURA ASSISTANT — Phase 5: Audio Diagnostics + Real-Time Signal Visualization
 *
 * Precision monochrome instrument card displaying live signal waveform,
 * audio telemetry metrics grid, and primary audio engine controls.
 */
@Composable
fun AuraAudioDiagnosticsCard(
    status: AuraAudioStatus,
    modifier: Modifier = Modifier,
    sampleRate: Int = 16000,
    bufferSize: Int = 0,
    rms: Double = 0.0,
    errorMessage: String? = null,
    hasPermission: Boolean = true,
    onStartClick: (() -> Unit)? = null,
    onPauseClick: (() -> Unit)? = null,
    onStopClick: (() -> Unit)? = null,
    onRestartClick: (() -> Unit)? = null,
    reducedMotion: Boolean = false
) {
    // Calculated live dB FS level
    val dbVal = if (status == AuraAudioStatus.ACTIVE && rms > 0.0) {
        val calculated = 20.0 * log10((rms / 32767.0).coerceAtLeast(1e-4))
        calculated.coerceIn(-60.0, 0.0)
    } else if (status == AuraAudioStatus.ACTIVE) {
        -60.0
    } else null

    // Normalized audio level L in [0, 1]
    val normalizedLevel = if (dbVal != null) {
        ((dbVal + 60.0) / 60.0).coerceIn(0.0, 1.0).toFloat()
    } else 0f

    val levelText = if (dbVal != null) {
        String.format("%.1f dB", dbVal)
    } else "—"

    BoxWithConstraints(
        modifier = modifier
            .fillMaxWidth()
            .widthIn(max = AuraSpacing.MaxContentWidth)
            .testTag("audio_telemetry_card")
            .semantics {
                val dbDesc = if (dbVal != null) "Input level ${String.format("%.1f", dbVal)} decibels." else ""
                contentDescription = "Audio diagnostics. Microphone ${status.badgeLabel.lowercase()}. $dbDesc ${sampleRate / 1000} kilohertz mono."
            }
    ) {
        val availableWidth = maxWidth
        val isNarrow = availableWidth < 540.dp
        val isTablet = availableWidth >= 600.dp

        AuraGlassSurface(
            modifier = Modifier.fillMaxWidth(),
            shape = AuraShapes.Large,
            level = when (status) {
                AuraAudioStatus.ACTIVE -> AuraGlassLevel.LEVEL_2
                AuraAudioStatus.ERROR, AuraAudioStatus.NO_PERMISSION -> AuraGlassLevel.LEVEL_2
                else -> AuraGlassLevel.LEVEL_1
            },
            borderWidth = AuraBorders.WidthNormal,
            showHighlight = true
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(
                        horizontal = if (isTablet) 24.dp else 18.dp,
                        vertical = if (isTablet) 20.dp else 16.dp
                    ),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // 1. Header Row
                AuraAudioDiagnosticsHeader(
                    status = status,
                    hasPermission = hasPermission,
                    reducedMotion = reducedMotion
                )

                // 2. Real-Time Precision Signal Waveform
                AuraAudioWaveform(
                    status = status,
                    normalizedLevel = normalizedLevel,
                    rms = rms,
                    reducedMotion = reducedMotion,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(if (isNarrow) 48.dp else if (isTablet) 64.dp else 54.dp)
                )

                // 3. Telemetry Metrics Grid
                AuraAudioMetricGrid(
                    sampleRate = sampleRate,
                    bufferSize = bufferSize,
                    levelText = levelText,
                    status = status,
                    isNarrow = isNarrow,
                    isTablet = isTablet
                )

                // 4. Primary Engine Controls Row
                AuraAudioControlsRow(
                    status = status,
                    onStartClick = onStartClick,
                    onPauseClick = onPauseClick,
                    onStopClick = onStopClick,
                    onRestartClick = onRestartClick,
                    isNarrow = isNarrow
                )

                // 5. Error Banner (if any)
                if (errorMessage != null) {
                    AuraAudioErrorBanner(errorMessage = errorMessage)
                }
            }
        }
    }
}

/**
 * Diagnostics Header displaying Title, Subtitle, and Live Status Badge.
 */
@Composable
private fun AuraAudioDiagnosticsHeader(
    status: AuraAudioStatus,
    hasPermission: Boolean,
    reducedMotion: Boolean,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(
                text = "AUDIO DIAGNOSTICS",
                style = AuraTypography.SectionTitle.copy(
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold,
                    letterSpacing = 0.5.sp
                ),
                color = AuraColors.TextPrimary
            )
            Text(
                text = if (hasPermission) "Live microphone telemetry & capture stream" else "Microphone permission required",
                style = AuraTypography.Caption.copy(fontSize = 11.5.sp),
                color = AuraColors.TextSecondary
            )
        }

        // Live Status Indicator + Badge
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(7.dp)
        ) {
            val infiniteTransition = rememberInfiniteTransition(label = "AudioStatusPulse")
            val pulseAlpha by infiniteTransition.animateFloat(
                initialValue = if (status.isPulsing && !reducedMotion) 0.45f else 1.0f,
                targetValue = 1.0f,
                animationSpec = infiniteRepeatable(
                    animation = tween(2400, easing = FastOutSlowInEasing),
                    repeatMode = RepeatMode.Reverse
                ),
                label = "PulseAlpha"
            )

            // Status Dot
            Box(
                modifier = Modifier
                    .size(7.dp)
                    .clip(CircleShape)
                    .background(
                        when (status) {
                            AuraAudioStatus.ACTIVE -> AuraColors.White.copy(alpha = pulseAlpha)
                            AuraAudioStatus.ERROR, AuraAudioStatus.NO_PERMISSION -> AuraColors.StatusError.copy(alpha = pulseAlpha)
                            AuraAudioStatus.PAUSED -> AuraColors.StatusWarning
                            else -> AuraColors.TextMuted.copy(alpha = 0.6f)
                        }
                    )
            )

            // Micro-pill status label
            Box(
                modifier = Modifier
                    .clip(AuraShapes.Pill)
                    .background(
                        when (status) {
                            AuraAudioStatus.ACTIVE -> AuraColors.White.copy(alpha = 0.10f)
                            AuraAudioStatus.ERROR, AuraAudioStatus.NO_PERMISSION -> AuraColors.StatusError.copy(alpha = 0.12f)
                            AuraAudioStatus.PAUSED -> AuraColors.StatusWarning.copy(alpha = 0.12f)
                            else -> AuraColors.White.copy(alpha = 0.05f)
                        }
                    )
                    .padding(horizontal = 8.dp, vertical = 2.5.dp)
            ) {
                AnimatedContent(
                    targetState = status.badgeLabel,
                    transitionSpec = {
                        fadeIn(animationSpec = tween(AuraMotion.DurationMicro)) togetherWith
                                fadeOut(animationSpec = tween(AuraMotion.DurationMicro))
                    },
                    label = "AudioBadgeCrossfade"
                ) { label ->
                    Text(
                        text = label,
                        style = AuraTypography.TechnicalLabel.copy(
                            fontSize = 9.5.sp,
                            letterSpacing = 0.8.sp,
                            fontWeight = FontWeight.Bold
                        ),
                        color = when (status) {
                            AuraAudioStatus.ACTIVE -> AuraColors.TextPrimary
                            AuraAudioStatus.ERROR, AuraAudioStatus.NO_PERMISSION -> AuraColors.StatusError
                            AuraAudioStatus.PAUSED -> AuraColors.StatusWarning
                            else -> AuraColors.TextSecondary
                        }
                    )
                }
            }
        }
    }
}

/**
 * Precision Monochrome Signal Waveform Canvas.
 * Driven by real audio amplitude level, smoothed with exponential dampening,
 * displaying subtle silence baseline animation when active, and static clean line when idle.
 */
@Composable
fun AuraAudioWaveform(
    status: AuraAudioStatus,
    normalizedLevel: Float,
    rms: Double,
    modifier: Modifier = Modifier,
    reducedMotion: Boolean = false
) {
    // Smoothed audio level S_t = alpha * X_t + (1 - alpha) * S_(t-1)
    val animatedLevel = remember { Animatable(0f) }
    // Exponential smoothing applied implicitly by spring or decelerated tween
    LaunchedEffect(normalizedLevel, status) {
        val target = if (status == AuraAudioStatus.ACTIVE) {
            max(normalizedLevel, 0.04f)
        } else if (status == AuraAudioStatus.PAUSED) {
            0.02f
        } else 0.0f

        animatedLevel.animateTo(
            targetValue = target,
            animationSpec = spring(dampingRatio = 0.8f, stiffness = 150f)
        )
    }

    // Continuous time phase for signal movement
    val infiniteTransition = rememberInfiniteTransition(label = "WaveformPhase")
    val phase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = (2 * PI).toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = if (reducedMotion) 8000 else 3200,
                easing = LinearEasing
            ),
            repeatMode = RepeatMode.Restart
        ),
        label = "PhaseValue"
    )

    // Reusable Path to avoid allocations per frame
    val primaryWavePath = remember { Path() }
    val secondaryWavePath = remember { Path() }

    Box(
        modifier = modifier
            .clip(AuraShapes.Medium)
            .background(AuraColors.White.copy(alpha = 0.025f))
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val width = size.width
            val height = size.height
            if (width <= 0f || height <= 0f) return@Canvas

            val midY = height / 2f
            val currentLevel = animatedLevel.value

            // 1. Precision Oscilloscope Reticle & Baseline
            drawLine(
                color = AuraColors.White.copy(alpha = if (status == AuraAudioStatus.ACTIVE) 0.12f else 0.16f),
                start = Offset(0f, midY),
                end = Offset(width, midY),
                strokeWidth = 1.dp.toPx()
            )

            // Reticle tick marks at 25%, 50%, 75%
            val tickH = 3.5.dp.toPx()
            drawLine(
                color = AuraColors.White.copy(alpha = 0.12f),
                start = Offset(width * 0.25f, midY - tickH),
                end = Offset(width * 0.25f, midY + tickH),
                strokeWidth = 1.dp.toPx()
            )
            drawLine(
                color = AuraColors.White.copy(alpha = 0.20f),
                start = Offset(width * 0.50f, midY - tickH * 1.5f),
                end = Offset(width * 0.50f, midY + tickH * 1.5f),
                strokeWidth = 1.dp.toPx()
            )
            drawLine(
                color = AuraColors.White.copy(alpha = 0.12f),
                start = Offset(width * 0.75f, midY - tickH),
                end = Offset(width * 0.75f, midY + tickH),
                strokeWidth = 1.dp.toPx()
            )

            // If completely idle/unavailable/error, draw subtle standby wave trace
            val isIdle = status != AuraAudioStatus.ACTIVE && status != AuraAudioStatus.PAUSED

            // 2. Sample Points based on available width (clamp W/4dp, 60..140)
            val pointCount = (width / 4.dp.toPx()).toInt().coerceIn(60, 140)
            val stepX = width / pointCount

            primaryWavePath.reset()
            secondaryWavePath.reset()

            val maxAmp = if (isIdle) {
                (height * 0.08f) // Subtle standby wave height
            } else {
                (height * 0.42f) * currentLevel
            }
            val t = if (reducedMotion) 0f else phase

            for (i in 0..pointCount) {
                val x = i * stepX
                val normX = (x / width).coerceIn(0f, 1f)

                // Window envelope to smoothly taper edges
                val envelope = sin(normX * PI.toFloat()).coerceAtLeast(0f)

                // Precision multi-frequency waveform
                val sample1 = (0.75f * sin(2f * PI.toFloat() * 2.4f * normX + t) +
                        0.25f * sin(2f * PI.toFloat() * 5.8f * normX - 0.6f * t))
                val y1 = midY + envelope * maxAmp * sample1

                val sample2 = (0.60f * sin(2f * PI.toFloat() * 3.6f * normX - 0.8f * t + 1.2f) +
                        0.40f * sin(2f * PI.toFloat() * 7.2f * normX + 0.4f * t))
                val y2 = midY + envelope * (maxAmp * 0.65f) * sample2

                if (i == 0) {
                    primaryWavePath.moveTo(x, y1)
                    secondaryWavePath.moveTo(x, y2)
                } else {
                    primaryWavePath.lineTo(x, y1)
                    secondaryWavePath.lineTo(x, y2)
                }
            }

            // 3. Secondary subtle waveform layer (15–25% White)
            drawPath(
                path = secondaryWavePath,
                color = AuraColors.White.copy(alpha = if (isIdle) 0.08f else 0.18f * (currentLevel.coerceIn(0.3f, 1f))),
                style = Stroke(width = 1.2.dp.toPx())
            )

            // 4. Primary precision waveform (75–90% White) + glow halo
            if (!isIdle) {
                drawPath(
                    path = primaryWavePath,
                    color = AuraColors.White.copy(alpha = 0.12f * (currentLevel.coerceIn(0.3f, 1f))),
                    style = Stroke(width = 4.0.dp.toPx())
                )
            }
            drawPath(
                path = primaryWavePath,
                color = AuraColors.White.copy(alpha = if (isIdle) 0.35f else 0.85f),
                style = Stroke(width = if (isIdle) 1.2.dp.toPx() else 1.8.dp.toPx())
            )
        }
    }
}

/**
 * Precision Telemetry Metrics Grid (2 columns on narrow, 4 columns on standard/wide).
 */
@Composable
private fun AuraAudioMetricGrid(
    sampleRate: Int,
    bufferSize: Int,
    levelText: String,
    status: AuraAudioStatus,
    isNarrow: Boolean,
    isTablet: Boolean,
    modifier: Modifier = Modifier
) {
    val sampleRateStr = String.format(java.util.Locale.US, "%.1f kHz", sampleRate / 1000.0)
    val channelStr = "1-CH PCM"
    val bufferStr = if (bufferSize > 0) "${bufferSize} B" else "30 ms"

    if (isNarrow) {
        Column(
            modifier = modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                AuraMetricCell(label = "SAMPLE RATE", value = sampleRateStr, modifier = Modifier.weight(1f))
                AuraMetricCell(label = "CHANNEL", value = channelStr, modifier = Modifier.weight(1f))
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                AuraMetricCell(
                    label = "LEVEL (RMS)",
                    value = levelText,
                    isHighlighted = status == AuraAudioStatus.ACTIVE,
                    modifier = Modifier.weight(1f)
                )
                AuraMetricCell(
                    label = "BUFFER",
                    value = bufferStr,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    } else {
        Row(
            modifier = modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            AuraMetricCell(label = "SAMPLE RATE", value = sampleRateStr, modifier = Modifier.weight(1f))
            AuraMetricCell(label = "CHANNEL", value = channelStr, modifier = Modifier.weight(1f))
            AuraMetricCell(
                label = "LEVEL (RMS)",
                value = levelText,
                isHighlighted = status == AuraAudioStatus.ACTIVE,
                modifier = Modifier.weight(1f)
            )
            AuraMetricCell(
                label = "BUFFER",
                value = bufferStr,
                modifier = Modifier.weight(1f)
            )
        }
    }
}

/**
 * Single Precision Instrument Metric Cell.
 */
@Composable
private fun AuraMetricCell(
    label: String,
    value: String,
    modifier: Modifier = Modifier,
    isHighlighted: Boolean = false
) {
    Box(
        modifier = modifier
            .clip(AuraShapes.Small)
            .background(AuraColors.White.copy(alpha = 0.03f))
            .padding(horizontal = 10.dp, vertical = 7.dp)
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(
                text = label,
                style = AuraTypography.TechnicalLabel.copy(
                    fontSize = 9.sp,
                    letterSpacing = 0.6.sp
                ),
                color = AuraColors.TextMuted,
                maxLines = 1,
                softWrap = false
            )
            Text(
                text = value,
                style = AuraTypography.TechnicalMono.copy(
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold
                ),
                color = if (isHighlighted) AuraColors.TextPrimary else AuraColors.TextSecondary,
                maxLines = 1,
                softWrap = false
            )
        }
    }
}

/**
 * Compact Monochrome Glass Controls Row for Audio Engine.
 */
@Composable
private fun AuraAudioControlsRow(
    status: AuraAudioStatus,
    onStartClick: (() -> Unit)?,
    onPauseClick: (() -> Unit)?,
    onStopClick: (() -> Unit)?,
    onRestartClick: (() -> Unit)?,
    isNarrow: Boolean,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        val isRecording = status == AuraAudioStatus.ACTIVE || status == AuraAudioStatus.PAUSED
        val isPaused = status == AuraAudioStatus.PAUSED

        if (!isRecording) {
            // Start Capture Button
            AuraAudioButton(
                text = "START CAPTURE",
                icon = Icons.Default.PlayArrow,
                contentDescription = "Start audio capture",
                onClick = onStartClick ?: {},
                enabled = onStartClick != null,
                modifier = Modifier.weight(1f).testTag("audio_start_button")
            )
        } else {
            // Pause / Resume Button
            AuraAudioButton(
                text = if (isPaused) "RESUME" else "PAUSE",
                icon = if (isPaused) Icons.Default.PlayArrow else Icons.Default.Pause,
                contentDescription = if (isPaused) "Resume audio capture" else "Pause audio capture",
                onClick = onPauseClick ?: {},
                enabled = onPauseClick != null,
                modifier = Modifier.weight(1f).testTag("audio_pause_button")
            )

            // Stop Button
            AuraAudioButton(
                text = "STOP",
                icon = Icons.Default.Stop,
                contentDescription = "Stop audio capture",
                onClick = onStopClick ?: {},
                enabled = onStopClick != null,
                modifier = Modifier.weight(1f).testTag("audio_stop_button")
            )
        }

        // Restart / Re-init Button
        if (onRestartClick != null) {
            AuraAudioIconButton(
                icon = Icons.Default.Refresh,
                contentDescription = "Force re-initialize audio engine",
                onClick = onRestartClick,
                enabled = isRecording,
                modifier = Modifier.testTag("audio_restart_button")
            )
        }
    }
}

/**
 * Compact Monochrome Glass Button with Icon and Minimum 48dp Touch Target.
 */
@Composable
private fun AuraAudioButton(
    text: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    contentDescription: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()

    val scale by androidx.compose.animation.core.animateFloatAsState(
        targetValue = if (isPressed && enabled) AuraMotion.PressScalePressed else AuraMotion.PressScaleNormal,
        animationSpec = AuraMotion.PressSpring,
        label = "AudioBtnScale"
    )

    AuraGlassSurface(
        modifier = modifier
            .defaultMinSize(minHeight = AuraDimensions.MinTouchTarget)
            .height(40.dp)
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            }
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                enabled = enabled,
                role = Role.Button,
                onClick = onClick
            )
            .semantics {
                role = Role.Button
                this.contentDescription = contentDescription
            },
        shape = AuraShapes.Medium,
        level = if (isPressed) AuraGlassLevel.ACTIVE else AuraGlassLevel.LEVEL_2,
        borderWidth = AuraBorders.WidthNormal,
        showHighlight = true
    ) {
        Row(
            modifier = Modifier
                .align(Alignment.Center)
                .padding(horizontal = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (enabled) AuraColors.TextPrimary else AuraColors.TextMuted,
                modifier = Modifier.size(15.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = text,
                style = AuraTypography.TechnicalLabel.copy(
                    fontSize = 11.5.sp,
                    letterSpacing = 0.8.sp,
                    fontWeight = FontWeight.Bold
                ),
                color = if (enabled) AuraColors.TextPrimary else AuraColors.TextMuted
            )
        }
    }
}

/**
 * Compact Monochrome Glass Icon Button.
 */
@Composable
private fun AuraAudioIconButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    contentDescription: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()

    val scale by androidx.compose.animation.core.animateFloatAsState(
        targetValue = if (isPressed && enabled) AuraMotion.PressScalePressed else AuraMotion.PressScaleNormal,
        animationSpec = AuraMotion.PressSpring,
        label = "AudioIconBtnScale"
    )

    AuraGlassSurface(
        modifier = modifier
            .size(AuraDimensions.MinTouchTarget)
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            }
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                enabled = enabled,
                role = Role.Button,
                onClick = onClick
            )
            .semantics {
                role = Role.Button
                this.contentDescription = contentDescription
            },
        shape = AuraShapes.Medium,
        level = if (isPressed) AuraGlassLevel.ACTIVE else AuraGlassLevel.LEVEL_2,
        borderWidth = AuraBorders.WidthNormal,
        showHighlight = true
    ) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (enabled) AuraColors.TextPrimary else AuraColors.TextMuted,
                modifier = Modifier.size(16.dp)
            )
        }
    }
}

/**
 * Subtle Monochrome Error Banner.
 */
@Composable
private fun AuraAudioErrorBanner(
    errorMessage: String,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(AuraShapes.Small)
            .background(AuraColors.StatusError.copy(alpha = 0.08f))
            .padding(horizontal = 12.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Icon(
            imageVector = Icons.Default.Warning,
            contentDescription = null,
            tint = AuraColors.StatusError,
            modifier = Modifier.size(15.dp)
        )
        Text(
            text = "ERROR: $errorMessage",
            style = AuraTypography.TechnicalMono.copy(fontSize = 11.sp),
            color = AuraColors.StatusError,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis
        )
    }
}
