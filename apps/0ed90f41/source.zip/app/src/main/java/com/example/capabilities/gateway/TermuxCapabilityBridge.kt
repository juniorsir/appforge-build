package com.example.capabilities.gateway

import android.util.Log
import com.example.capabilities.core.CapabilityRegistry
import com.example.capabilities.core.CapabilityRequest
import com.example.capabilities.core.CapabilityResponse
import org.json.JSONObject
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class TermuxCapabilityBridge @Inject constructor(
    private val registry: CapabilityRegistry
) {
    private val TAG = "TermuxCapabilityBridge"

    fun getCapabilitiesManifestJson(): String {
        val caps = registry.capabilities.value
        val array = org.json.JSONArray()
        for (c in caps) {
            val obj = JSONObject().apply {
                put("id", c.id)
                put("name", c.name)
                put("description", c.description)
                put("category", c.category.name)
                put("availability", c.availability.name)
                put("minSdkVersion", c.minSdkVersion)
                put("hardwareFeature", c.hardwareFeature ?: JSONObject.NULL)
                put("requiredPermissions", org.json.JSONArray(c.requiredPermissions))
                put("confirmationLevel", c.confirmationLevel.name)
            }
            array.put(obj)
        }
        return JSONObject().put("capabilities", array).toString()
    }

    suspend fun handleJsonRequest(jsonPayload: String): String {
        return try {
            val json = JSONObject(jsonPayload)
            val capabilityId = json.optString("capabilityId", "")
            val action = json.optString("action", "execute")
            val reqId = json.optString("requestId", java.util.UUID.randomUUID().toString())
            val confirmed = json.optBoolean("confirmed", false)

            val paramsMap = mutableMapOf<String, Any?>()
            val paramsObj = json.optJSONObject("parameters")
            if (paramsObj != null) {
                val keys = paramsObj.keys()
                while (keys.hasNext()) {
                    val key = keys.next()
                    paramsMap[key] = paramsObj.get(key)
                }
            }

            val request = CapabilityRequest(
                requestId = reqId,
                capabilityId = capabilityId,
                action = action,
                parameters = paramsMap,
                requiresConfirmation = confirmed
            )

            val response: CapabilityResponse = registry.executeCapability(request)

            JSONObject().apply {
                put("requestId", response.requestId)
                put("capabilityId", response.capabilityId)
                put("success", response.success)
                put("data", response.data?.toString() ?: JSONObject.NULL)
                put("errorCode", response.errorCode?.name ?: JSONObject.NULL)
                put("errorMessage", response.errorMessage ?: JSONObject.NULL)
                put("timestamp", response.timestamp)
                put("durationMs", response.durationMs)
            }.toString()
        } catch (e: Exception) {
            Log.e(TAG, "Bridge JSON handling error: ${e.message}", e)
            JSONObject().apply {
                put("success", false)
                put("errorMessage", "Malformed capability request: ${e.message}")
            }.toString()
        }
    }
}
