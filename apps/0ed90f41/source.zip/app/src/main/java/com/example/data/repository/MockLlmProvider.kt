package com.example.data.repository

import com.example.domain.model.AiResponseEvent
import com.example.domain.model.LlmConfig
import com.example.domain.model.LlmMessage
import com.example.domain.model.LlmProviderType
import com.example.domain.repository.LlmProvider
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.isActive
import java.util.UUID

class MockLlmProvider : LlmProvider {
    override val type: LlmProviderType = LlmProviderType.LOCAL

    override fun streamResponse(
        config: LlmConfig,
        systemPrompt: String,
        developerPrompt: String,
        messages: List<LlmMessage>,
        userMessage: String,
        sessionId: String,
        conversationId: String,
        messageId: String
    ): Flow<AiResponseEvent> = flow {
        val startTime = System.currentTimeMillis()
        
        // 1. Emit Start Event
        emit(AiResponseEvent.Start(sessionId, conversationId, messageId, startTime))
        
        // Check for empty API keys if remote is selected
        if (config.providerType != LlmProviderType.LOCAL && config.providerType != LlmProviderType.OLLAMA && config.apiKey.isBlank()) {
            emit(
                AiResponseEvent.Error(
                    sessionId = sessionId,
                    conversationId = conversationId,
                    messageId = messageId,
                    error = "Missing API key for provider ${config.providerType}. Please check your system credentials in settings."
                )
            )
            return@flow
        }

        // Check for empty message
        if (userMessage.isBlank()) {
            emit(
                AiResponseEvent.Error(
                    sessionId = sessionId,
                    conversationId = conversationId,
                    messageId = messageId,
                    error = "Unable to process empty user prompt."
                )
            )
            return@flow
        }

        // 2. Generate Simulated Response text based on provider and input
        val responseTemplate = buildString {
            append("This is a live-streamed response powered by the ${config.providerType} Integration Module (Model: ${config.modelName}).\n\n")
            append("I have evaluated your context:\n")
            append("- System Role: \"${systemPrompt.take(50)}...\"\n")
            append("- Rules: \"${developerPrompt.take(50)}...\"\n")
            append("- History Length: ${messages.size} message(s) cached.\n\n")
            
            val normalizedInput = userMessage.lowercase().trim()
            when {
                normalizedInput.contains("hello") || normalizedInput.contains("hi") -> {
                    append("Hello there! I am Aura, your empathetic AI Companion. How is your day going? I'm listening closely to your voice stream and am ready to support you with whatever you need.")
                }
                normalizedInput.contains("help") -> {
                    append("I'm here to help! As an AI Companion, I can process continuous spoken transcripts, manage your conversation memory buffers, and simulate high-fidelity responses with low latency.")
                }
                normalizedInput.contains("error") -> {
                    // Trigger a forced simulated failure
                    emit(
                        AiResponseEvent.Error(
                            sessionId = sessionId,
                            conversationId = conversationId,
                            messageId = messageId,
                            error = "Simulated downstream inference timeout (504 Gateway Timeout)."
                        )
                    )
                    return@flow
                }
                else -> {
                    append("Understood perfectly. You said: \"$userMessage\". Let me break that down for you and respond thoughtfully. Our continuous conversation buffer ensures no context is lost during active streams.")
                }
            }
        }

        // 3. Stream token by token (or word by word)
        val tokens = responseTemplate.split(" ")
        val accumulatedText = StringBuilder()
        
        try {
            // Initial network connection latency simulation (e.g. 150-300ms first token time)
            delay(200)

            for ((index, token) in tokens.withIndex()) {
                if (!currentCoroutineContext().isActive) {
                    emit(AiResponseEvent.Cancelled(sessionId, conversationId, messageId))
                    return@flow
                }

                // Add space if not first token
                val wordWithSpace = if (index == 0) token else " $token"
                accumulatedText.append(wordWithSpace)
                
                // Emit partial token
                emit(AiResponseEvent.Partial(sessionId, conversationId, messageId, wordWithSpace))
                
                // Simulate streaming rate: ~40ms to 80ms per word (or temperature based variation)
                val streamDelay = (40 + (config.temperature * 40)).toLong()
                delay(streamDelay)
            }

            val endTime = System.currentTimeMillis()
            val totalTime = endTime - startTime
            val totalTokens = responseTemplate.length / 4 // standard estimate

            // 4. Emit Final and End Events
            emit(AiResponseEvent.Final(sessionId, conversationId, messageId, accumulatedText.toString(), endTime))
            emit(
                AiResponseEvent.End(
                    sessionId = sessionId,
                    conversationId = conversationId,
                    messageId = messageId,
                    totalTokensPlaceholder = totalTokens,
                    responseTimeMs = totalTime,
                    timestamp = endTime
                )
            )

        } catch (e: Exception) {
            println("MockLlmProvider error: ${e.message}")
            emit(
                AiResponseEvent.Error(
                    sessionId = sessionId,
                    conversationId = conversationId,
                    messageId = messageId,
                    error = e.localizedMessage ?: "Unknown streaming interruption."
                )
            )
        } finally {
            println("MockLlmProvider flow completed")
        }
    }
}
