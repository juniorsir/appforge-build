package com.example.ui.overlay

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat

class ToastCustomizer(private val context: Context) {

    private val mainHandler = Handler(Looper.getMainLooper())
    private val windowManager by lazy {
        context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    }

    data class ToastOptions(
        val message: String,
        val duration: String = "SHORT", // "SHORT", "LONG", or millis
        val durationMs: Long? = null,
        val gravity: String = "BOTTOM", // "BOTTOM", "TOP", "CENTER", "CUSTOM"
        val xOffset: Int = 0,
        val yOffset: Int = 120,
        val backgroundColor: String? = null, // e.g. "#CC1E1E2E"
        val textColor: String? = null, // e.g. "#FFFFFF"
        val textSize: Float = 14f,
        val cornerRadius: Int = 24, // dp
        val icon: String? = null, // "info", "success", "warning", "error", "star"
        val alpha: Float = 0.95f,
        val useOverlay: Boolean = false // If true, uses WindowManager overlay for pixel-perfect custom UI
    )

    fun showToast(options: ToastOptions) {
        mainHandler.post {
            try {
                // If custom styling or overlay is requested and overlay permission exists, show custom overlay toast
                val hasCustomStyle = options.backgroundColor != null || options.textColor != null || 
                                     options.icon != null || options.useOverlay || options.durationMs != null
                
                if (hasCustomStyle && Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && android.provider.Settings.canDrawOverlays(context)) {
                    showOverlayToast(options)
                } else {
                    showStandardToast(options)
                }
            } catch (e: Exception) {
                // Fallback to absolute standard toast
                try {
                    Toast.makeText(context, options.message, Toast.LENGTH_SHORT).show()
                } catch (ignored: Exception) {}
            }
        }
    }

    private fun showStandardToast(options: ToastOptions) {
        val duration = if (options.duration.equals("LONG", ignoreCase = true)) Toast.LENGTH_LONG else Toast.LENGTH_SHORT
        val toast = Toast.makeText(context, options.message, duration)
        
        val grav = when (options.gravity.uppercase()) {
            "TOP" -> Gravity.TOP or Gravity.CENTER_HORIZONTAL
            "CENTER" -> Gravity.CENTER
            "CUSTOM" -> Gravity.NO_GRAVITY
            else -> Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
        }
        
        val density = context.resources.displayMetrics.density
        val x = (options.xOffset * density).toInt()
        val y = (options.yOffset * density).toInt()
        
        toast.setGravity(grav, x, y)
        toast.show()
    }

    private fun showOverlayToast(options: ToastOptions) {
        val density = context.resources.displayMetrics.density
        val layout = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            val padH = (18 * density).toInt()
            val padV = (12 * density).toInt()
            setPadding(padH, padV, padH, padV)
            this.alpha = options.alpha.coerceIn(0.1f, 1.0f)

            val bg = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = options.cornerRadius * density
                val colorInt = try {
                    Color.parseColor(options.backgroundColor ?: "#E6212121")
                } catch (e: Exception) {
                    Color.parseColor("#E6212121")
                }
                setColor(colorInt)
                setStroke((1 * density).toInt(), Color.parseColor("#33FFFFFF"))
            }
            background = bg
            elevation = 12 * density
        }

        // Optional Icon indicator
        if (!options.icon.isNullOrBlank()) {
            val iconView = TextView(context).apply {
                textSize = options.textSize + 2
                val iconSymbol = when (options.icon.lowercase()) {
                    "success", "check" -> "✓ "
                    "warning" -> "⚠ "
                    "error" -> "✕ "
                    "info" -> "ℹ "
                    "star" -> "★ "
                    "bell" -> "🔔 "
                    else -> "• "
                }
                text = iconSymbol
                val iconColor = when (options.icon.lowercase()) {
                    "success", "check" -> "#4CAF50"
                    "warning" -> "#FFC107"
                    "error" -> "#FF5252"
                    "info" -> "#2196F3"
                    else -> options.textColor ?: "#FFFFFF"
                }
                try { setTextColor(Color.parseColor(iconColor)) } catch (e: Exception) { setTextColor(Color.WHITE) }
            }
            layout.addView(iconView)
        }

        val textView = TextView(context).apply {
            text = options.message
            textSize = options.textSize
            typeface = Typeface.DEFAULT_BOLD
            val colorInt = try {
                Color.parseColor(options.textColor ?: "#FFFFFF")
            } catch (e: Exception) {
                Color.WHITE
            }
            setTextColor(colorInt)
            maxLines = 4
        }
        layout.addView(textView)

        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val grav = when (options.gravity.uppercase()) {
            "TOP" -> Gravity.TOP or Gravity.CENTER_HORIZONTAL
            "CENTER" -> Gravity.CENTER
            "CUSTOM" -> Gravity.NO_GRAVITY
            else -> Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = grav
            x = (options.xOffset * density).toInt()
            y = (options.yOffset * density).toInt()
        }

        try {
            windowManager.addView(layout, params)
            val showTimeMs = options.durationMs ?: if (options.duration.equals("LONG", ignoreCase = true)) 3500L else 2000L
            mainHandler.postDelayed({
                try {
                    layout.animate()
                        .alpha(0f)
                        .setDuration(300)
                        .withEndAction {
                            try { windowManager.removeView(layout) } catch (ignored: Exception) {}
                        }
                        .start()
                } catch (e: Exception) {
                    try { windowManager.removeView(layout) } catch (ignored: Exception) {}
                }
            }, showTimeMs)
        } catch (e: Exception) {
            showStandardToast(options)
        }
    }
}
