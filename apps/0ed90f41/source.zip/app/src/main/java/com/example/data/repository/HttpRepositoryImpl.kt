package com.example.data.repository

import com.example.domain.repository.HealthCheckResult
import com.example.domain.repository.HttpRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody

class HttpRepositoryImpl(
    private val client: OkHttpClient,
    private val baseUrl: String = "http://127.0.0.1:8000/"
) : HttpRepository {

    override suspend fun checkServerHealth(customUrl: String?): Boolean {
        return checkServerHealthDetailed(customUrl).isSuccess
    }

    override suspend fun checkServerHealthDetailed(customUrl: String?): HealthCheckResult = withContext(Dispatchers.IO) {
        val targetUrl = customUrl ?: baseUrl
        try {
            val request = Request.Builder()
                .url(targetUrl)
                .get()
                .build()

            client.newCall(request).execute().use { response ->
                val bodyStr = try { response.body?.string()?.take(200) } catch (e: Exception) { null }
                // Accept 200 OK or 426 Upgrade Required / 400 Bad Request which indicates active HTTP/WS listener
                val isOk = response.isSuccessful || response.code == 426 || response.code == 400
                HealthCheckResult(
                    isSuccess = isOk,
                    statusCode = response.code,
                    statusMessage = response.message,
                    rawBody = bodyStr,
                    error = if (!isOk) "HTTP ${response.code} ${response.message}" else null
                )
            }
        } catch (e: java.net.ConnectException) {
            HealthCheckResult(
                isSuccess = false,
                error = "Connection refused: Server not running or not listening on ${targetUrl.substringAfter("://").substringBefore("/")}"
            )
        } catch (e: java.net.UnknownServiceException) {
            HealthCheckResult(
                isSuccess = false,
                error = "Cleartext HTTP traffic not permitted by Android Network Security Policy: ${e.message}"
            )
        } catch (e: java.net.SocketTimeoutException) {
            HealthCheckResult(
                isSuccess = false,
                error = "Timeout: Server at $targetUrl took longer than 5s to respond"
            )
        } catch (e: java.net.UnknownHostException) {
            HealthCheckResult(
                isSuccess = false,
                error = "Unknown host: ${e.message}"
            )
        } catch (e: Exception) {
            HealthCheckResult(
                isSuccess = false,
                error = "${e.javaClass.simpleName}: ${e.localizedMessage ?: e.message ?: "Network error"}"
            )
        }
    }

    override suspend fun authenticateClient(token: String): Boolean = withContext(Dispatchers.IO) {
        try {
            val jsonMedia = "application/json; charset=utf-8".toMediaType()
            val bodyJson = "{\"token\":\"$token\"}"
            val request = Request.Builder()
                .url("${baseUrl}api/auth")
                .post(bodyJson.toRequestBody(jsonMedia))
                .build()

            client.newCall(request).execute().use { response ->
                response.isSuccessful
            }
        } catch (e: Exception) {
            false
        }
    }

    override suspend fun sendTextPrompt(text: String): String = withContext(Dispatchers.IO) {
        try {
            val jsonMedia = "application/json; charset=utf-8".toMediaType()
            val bodyJson = "{\"prompt\":\"$text\"}"
            val request = Request.Builder()
                .url("${baseUrl}api/prompt")
                .post(bodyJson.toRequestBody(jsonMedia))
                .build()

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    response.body?.string() ?: "Empty body response"
                } else {
                    "Error: Code ${response.code}"
                }
            }
        } catch (e: Exception) {
            "Network Error: ${e.localizedMessage ?: "Unknown error"}"
        }
    }
}
