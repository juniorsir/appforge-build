package com.example.ui.components.buttons

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.components.glass.AuraGlassSurface
import com.example.ui.theme.AuraBorders
import com.example.ui.theme.AuraColors
import com.example.ui.theme.AuraDimensions
import com.example.ui.theme.AuraGlassLevel
import com.example.ui.theme.AuraMotion
import com.example.ui.theme.AuraShapes
import com.example.ui.theme.AuraTypography

/**
 * AURA ASSISTANT — Primary Action Button
 * Dominant high-contrast pure white solid pill with black typography.
 */
@Composable
fun AuraPrimaryButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    height: Dp = AuraDimensions.ButtonHeightNormal,
    shape: Shape = AuraShapes.XL,
    contentDescriptionText: String? = null,
    content: @Composable RowScope.() -> Unit
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()

    val scale by animateFloatAsState(
        targetValue = if (isPressed && enabled) AuraMotion.PressScalePressed else AuraMotion.PressScaleNormal,
        animationSpec = AuraMotion.PressSpring,
        label = "PrimaryBtnScale"
    )

    val bgColor = if (enabled) AuraColors.ButtonPrimaryBg else AuraColors.White.copy(alpha = 0.25f)
    val contentColor = if (enabled) AuraColors.ButtonPrimaryContent else AuraColors.Black.copy(alpha = 0.5f)

    Box(
        modifier = modifier
            .defaultMinSize(minWidth = 120.dp, minHeight = AuraDimensions.MinTouchTarget)
            .height(height)
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            }
            .clip(shape)
            .background(bgColor, shape)
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                enabled = enabled,
                role = Role.Button,
                onClick = onClick
            )
            .semantics {
                role = Role.Button
                contentDescriptionText?.let { contentDescription = it }
            }
            .padding(horizontal = 24.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally),
            verticalAlignment = Alignment.CenterVertically,
            content = content
        )
    }
}

/**
 * AURA ASSISTANT — Secondary Action Button
 * Liquid smoked glass surface with white border and white typography.
 */
@Composable
fun AuraSecondaryButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    height: Dp = AuraDimensions.ButtonHeightNormal,
    shape: Shape = AuraShapes.XL,
    contentDescriptionText: String? = null,
    content: @Composable RowScope.() -> Unit
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()

    val scale by animateFloatAsState(
        targetValue = if (isPressed && enabled) AuraMotion.PressScalePressed else AuraMotion.PressScaleNormal,
        animationSpec = AuraMotion.PressSpring,
        label = "SecondaryBtnScale"
    )

    AuraGlassSurface(
        modifier = modifier
            .defaultMinSize(minWidth = 100.dp, minHeight = AuraDimensions.MinTouchTarget)
            .height(height)
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            }
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                enabled = enabled,
                role = Role.Button,
                onClick = onClick
            )
            .semantics {
                role = Role.Button
                contentDescriptionText?.let { contentDescription = it }
            },
        shape = shape,
        level = if (isPressed) AuraGlassLevel.ACTIVE else AuraGlassLevel.LEVEL_2,
        contentPadding = PaddingValues(horizontal = 20.dp)
    ) {
        Row(
            modifier = Modifier.align(Alignment.Center),
            horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally),
            verticalAlignment = Alignment.CenterVertically,
            content = content
        )
    }
}

/**
 * AURA ASSISTANT — Tertiary Action Button
 * Transparent background with subtle text / icon affordance.
 */
@Composable
fun AuraTertiaryButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    contentDescriptionText: String? = null,
    content: @Composable RowScope.() -> Unit
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()

    val scale by animateFloatAsState(
        targetValue = if (isPressed && enabled) AuraMotion.PressScalePressed else AuraMotion.PressScaleNormal,
        animationSpec = AuraMotion.PressSpring,
        label = "TertiaryBtnScale"
    )

    Box(
        modifier = modifier
            .defaultMinSize(minWidth = 48.dp, minHeight = AuraDimensions.MinTouchTarget)
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            }
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                enabled = enabled,
                role = Role.Button,
                onClick = onClick
            )
            .semantics {
                role = Role.Button
                contentDescriptionText?.let { contentDescription = it }
            }
            .padding(horizontal = 14.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(
            horizontalArrangement = Arrangement.spacedBy(6.dp, Alignment.CenterHorizontally),
            verticalAlignment = Alignment.CenterVertically,
            content = content
        )
    }
}

/**
 * AURA ASSISTANT — Standard Glass Icon Button
 * Accessible 48dp touch target with tactile press animation.
 */
@Composable
fun AuraIconButton(
    icon: ImageVector,
    contentDescription: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    tint: Color = AuraColors.TextPrimary,
    shape: Shape = AuraShapes.Medium,
    level: AuraGlassLevel = AuraGlassLevel.LEVEL_1
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()

    val scale by animateFloatAsState(
        targetValue = if (isPressed && enabled) AuraMotion.PressScalePressed else AuraMotion.PressScaleNormal,
        animationSpec = AuraMotion.PressSpring,
        label = "IconButtonScale"
    )

    AuraGlassSurface(
        modifier = modifier
            .size(AuraDimensions.IconButtonSize)
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            }
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                enabled = enabled,
                role = Role.Button,
                onClick = onClick
            )
            .semantics {
                role = Role.Button
                this.contentDescription = contentDescription
            },
        shape = shape,
        level = if (isPressed) AuraGlassLevel.ACTIVE else level
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null, // Handled by container semantics
            tint = if (enabled) tint else tint.copy(alpha = 0.35f),
            modifier = Modifier
                .size(AuraDimensions.IconNormal)
                .align(Alignment.Center)
        )
    }
}
