package com.example.server

import org.json.JSONArray
import org.json.JSONObject

object AuraManifestProvider {

    fun generateManifestJson(): String {
        val root = JSONObject()
        root.put("name", "Aura Assistant - Android Control & Media Subsystem")
        root.put("version", "1.0.0")
        root.put("status", "ACTIVE")
        root.put("totalCapabilitiesCount", 52)
        root.put("totalCommandsCount", 33)
        root.put("supportedCategoriesCount", 16)

        // How to use guide
        val howToUse = JSONObject()
        howToUse.put("overview", "Aura provides real-time Android device control and hardware execution via both HTTP REST endpoints (port 8080) and bidirectional WebSocket interface (port 8000).")
        
        val httpGuide = JSONObject()
        httpGuide.put("port", 8080)
        httpGuide.put("baseUrl", "http://127.0.0.1:8080")
        val httpEndpoints = JSONArray()
        httpEndpoints.put(JSONObject().apply {
            put("path", "/help")
            put("method", "GET")
            put("description", "Returns complete usage documentation, available commands, and capabilities overview.")
        })
        httpEndpoints.put(JSONObject().apply {
            put("path", "/capabilities")
            put("method", "GET")
            put("description", "Returns full list and status of all 52 supported hardware and system capabilities.")
        })
        httpEndpoints.put(JSONObject().apply {
            put("path", "/commands")
            put("method", "GET")
            put("description", "Returns full JSON specification and example payloads for all supported remote commands.")
        })
        httpEndpoints.put(JSONObject().apply {
            put("path", "/health")
            put("method", "GET")
            put("description", "Returns server status and summary stats.")
        })
        httpEndpoints.put(JSONObject().apply {
            put("path", "/api/tts")
            put("method", "POST")
            put("description", "Speak text via native TTS engine. Payload: {'text': 'Hello', 'pitch': 1.0, 'rate': 1.0}")
        })
        httpEndpoints.put(JSONObject().apply {
            put("path", "/api/toast")
            put("method", "POST")
            put("description", "Show styled toast message. Payload: {'message': 'Hello', 'icon': 'success', 'gravity': 'TOP'}")
        })
        httpEndpoints.put(JSONObject().apply {
            put("path", "/api/vibrate")
            put("method", "POST")
            put("description", "Trigger haptic vibration. Payload: {'preset': 'HEAVY_CLICK', 'durationMs': 100}")
        })
        httpEndpoints.put(JSONObject().apply {
            put("path", "/api/audio/play")
            put("method", "POST")
            put("description", "Play audio sound. Payload: {'type': 'notification'}")
        })
        httpEndpoints.put(JSONObject().apply {
            put("path", "/api/volume")
            put("method", "GET / POST")
            put("description", "Get audio levels or set stream volume: {'stream': 'MEDIA', 'volume': 10}")
        })
        httpEndpoints.put(JSONObject().apply {
            put("path", "/api/app/list")
            put("method", "GET")
            put("description", "Get list of all installed launcher applications")
        })
        httpEndpoints.put(JSONObject().apply {
            put("path", "/api/app/launch")
            put("method", "POST")
            put("description", "Launch app by package or URL: {'packageName': 'com.termux'}")
        })
        httpEndpoints.put(JSONObject().apply {
            put("path", "/api/torch")
            put("method", "POST")
            put("description", "Toggle camera flashlight: {'enabled': true}")
        })
        httpEndpoints.put(JSONObject().apply {
            put("path", "/api/floating")
            put("method", "POST")
            put("description", "Display floating HUD over other apps: {'text': 'CPU 12%', 'title': 'Termux HUD'}")
        })
        httpEndpoints.put(JSONObject().apply {
            put("path", "/api/notification")
            put("method", "POST")
            put("description", "Post Android notification: {'title': 'Alert', 'message': 'Job complete'}")
        })
        httpEndpoints.put(JSONObject().apply {
            put("path", "/api/sensors")
            put("method", "GET")
            put("description", "Read instant hardware sensors (accelerometer, gyroscope, light lux, proximity, pressure, compass)")
        })
        httpEndpoints.put(JSONObject().apply {
            put("path", "/api/display")
            put("method", "GET / POST")
            put("description", "Query display metrics or set brightness: {'brightness': 200, 'keepScreenOn': true}")
        })
        httpEndpoints.put(JSONObject().apply {
            put("path", "/api/network")
            put("method", "GET")
            put("description", "Get active transport (Wi-Fi/Cellular), link speed, RSSI, and IP addresses")
        })
        httpEndpoints.put(JSONObject().apply {
            put("path", "/api/device")
            put("method", "GET")
            put("description", "Get full hardware specs: CPU cores, RAM, storage, battery %, temperature, thermal throttling")
        })
        httpGuide.put("endpoints", httpEndpoints)
        howToUse.put("http", httpGuide)

        val wsGuide = JSONObject()
        wsGuide.put("url", "ws://127.0.0.1:8000/ws")
        wsGuide.put("protocol", "JSON WebSocket messages with 'type', 'sessionId', 'timestamp', and 'requestId'")
        wsGuide.put("flow", "1. Connect to ws://127.0.0.1:8000/ws -> 2. Receive HELLO packet -> 3. Send command JSON -> 4. Receive <COMMAND>_RESULT")
        howToUse.put("websocket", wsGuide)

        val quickStart = JSONObject()
        quickStart.put("termux_curl_docs", "curl http://127.0.0.1:8080/help")
        quickStart.put("termux_curl_capabilities", "curl http://127.0.0.1:8080/capabilities")
        quickStart.put("python_example", "python take_photo.py or python aura_client.py")
        howToUse.put("quickStart", quickStart)

        root.put("howToUse", howToUse)

        // Categories list
        val categories = JSONArray()
        listOf(
            "AUDIO", "CAMERA", "MEDIA", "LOCATION", "SENSORS", "BLUETOOTH",
            "NETWORK", "NOTIFICATIONS", "CLIPBOARD", "DEVICE_INFO", "ACCESSIBILITY", "STORAGE"
        ).forEach { categories.put(it) }
        root.put("categories", categories)

        // Supported Commands
        val commands = JSONArray()
        commands.put(JSONObject().apply {
            put("type", "TTS_SPEAK")
            put("description", "Speak text aloud on Android device using Text-to-Speech")
            put("parameters", JSONObject().apply {
                put("text", "String (required) - Text to be spoken")
                put("pitch", "Float (optional, default 1.0)")
                put("speechRate", "Float (optional, default 1.0)")
                put("queueMode", "Int (optional, 0=FLUSH, 1=ADD)")
            })
            put("examplePayload", JSONObject().apply {
                put("type", "TTS_SPEAK")
                put("requestId", "tts_01")
                put("text", "Task completed in Termux")
            })
        })

        commands.put(JSONObject().apply {
            put("type", "NOTIFICATION_POST")
            put("description", "Display a system notification in the Android notification drawer")
            put("parameters", JSONObject().apply {
                put("title", "String (required) - Notification title")
                put("message", "String (required) - Notification body text")
            })
            put("examplePayload", JSONObject().apply {
                put("type", "NOTIFICATION_POST")
                put("requestId", "notif_01")
                put("title", "Termux Alert")
                put("message", "Build finished successfully")
            })
        })

        commands.put(JSONObject().apply {
            put("type", "CLIPBOARD_GET")
            put("description", "Read current Android clipboard contents into Termux")
            put("parameters", JSONObject())
            put("examplePayload", JSONObject().apply {
                put("type", "CLIPBOARD_GET")
                put("requestId", "clip_01")
            })
        })

        commands.put(JSONObject().apply {
            put("type", "CLIPBOARD_SET")
            put("description", "Write text to Android clipboard")
            put("parameters", JSONObject().apply {
                put("text", "String (required) - Text to copy to clipboard")
            })
            put("examplePayload", JSONObject().apply {
                put("type", "CLIPBOARD_SET")
                put("requestId", "clip_02")
                put("text", "Copied from Termux terminal")
            })
        })

        commands.put(JSONObject().apply {
            put("type", "DEVICE_INFO_GET")
            put("description", "Get device model, manufacturer, Android OS version, battery percentage, temperature, RAM")
            put("parameters", JSONObject())
            put("examplePayload", JSONObject().apply {
                put("type", "DEVICE_INFO_GET")
                put("requestId", "dev_01")
            })
        })

        commands.put(JSONObject().apply {
            put("type", "TORCH_SET")
            put("description", "Turn camera flashlight / torch ON or OFF")
            put("parameters", JSONObject().apply {
                put("enabled", "Boolean (required) - true to turn ON, false to turn OFF")
            })
            put("examplePayload", JSONObject().apply {
                put("type", "TORCH_SET")
                put("requestId", "torch_01")
                put("enabled", true)
            })
        })

        commands.put(JSONObject().apply {
            put("type", "LOCATION_GET")
            put("description", "Get current GPS coordinates (latitude, longitude, altitude, accuracy, speed)")
            put("parameters", JSONObject())
            put("examplePayload", JSONObject().apply {
                put("type", "LOCATION_GET")
                put("requestId", "loc_01")
            })
        })

        commands.put(JSONObject().apply {
            put("type", "CAMERA_CAPTURE")
            put("description", "Silently capture a photo using Camera2 API in background and return Base64 + path")
            put("parameters", JSONObject().apply {
                put("lens", "String (optional, 'back' or 'front', default 'back')")
            })
            put("examplePayload", JSONObject().apply {
                put("type", "CAMERA_CAPTURE")
                put("requestId", "cam_01")
                put("lens", "back")
            })
        })

        commands.put(JSONObject().apply {
            put("type", "MEDIA_PROBE")
            put("description", "Inspect video/audio container, codecs, duration, dimensions, bitrate with FFprobe")
            put("parameters", JSONObject().apply {
                put("mediaUri", "String (required) - content:// or file:// or local path")
            })
            put("examplePayload", JSONObject().apply {
                put("type", "MEDIA_PROBE")
                put("requestId", "probe_01")
                put("mediaUri", "/sdcard/Download/video.mp4")
            })
        })

        commands.put(JSONObject().apply {
            put("type", "MEDIA_CONVERT")
            put("description", "Remux, transcode, extract audio, or generate video frame thumbnail via FFmpegKit")
            put("parameters", JSONObject().apply {
                put("action", "String (required) - 'remux', 'transcode', 'thumbnail', or 'extract_audio'")
                put("inputUri", "String (required) - Source media URI")
                put("outputUri", "String (optional) - Destination path")
                put("timestampSeconds", "Double (optional, for thumbnail)")
            })
            put("examplePayload", JSONObject().apply {
                put("type", "MEDIA_CONVERT")
                put("requestId", "convert_01")
                put("action", "remux")
                put("inputUri", "/sdcard/Download/video.mkv")
            })
        })

        commands.put(JSONObject().apply {
            put("type", "ACCESSIBILITY_GESTURE")
            put("description", "Perform programmatic click, swipe, or scroll on Android screen")
            put("parameters", JSONObject().apply {
                put("gestureType", "String ('click', 'swipe', 'scroll')")
                put("startX", "Float")
                put("startY", "Float")
                put("endX", "Float (for swipe)")
                put("endY", "Float (for swipe)")
                put("durationMs", "Long (default 100)")
            })
            put("examplePayload", JSONObject().apply {
                put("type", "ACCESSIBILITY_GESTURE")
                put("gestureId", "g_01")
                put("gestureType", "click")
                put("startX", 500f)
                put("startY", 1000f)
            })
        })

        commands.put(JSONObject().apply {
            put("type", "ACCESSIBILITY_INSPECT")
            put("description", "Inspect the on-screen UI node tree and find elements by text, ID, or description")
            put("parameters", JSONObject().apply {
                put("searchByText", "String (optional)")
                put("searchByDesc", "String (optional)")
                put("searchById", "String (optional)")
            })
            put("examplePayload", JSONObject().apply {
                put("type", "ACCESSIBILITY_INSPECT")
                put("sessionId", "s_01")
            })
        })

        commands.put(JSONObject().apply {
            put("type", "TOAST_SHOW")
            put("description", "Display highly customizable native or overlay toast with custom colors, gravity, icons, and duration")
            put("parameters", JSONObject().apply {
                put("message", "String (required) - Toast message text")
                put("duration", "String (optional, 'SHORT' or 'LONG')")
                put("durationMs", "Long (optional, custom millisecond duration)")
                put("gravity", "String (optional, 'BOTTOM', 'TOP', 'CENTER', 'CUSTOM')")
                put("xOffset", "Int (optional, X coordinate offset)")
                put("yOffset", "Int (optional, Y coordinate offset)")
                put("backgroundColor", "String (optional, hex e.g. '#CC1E1E2E')")
                put("textColor", "String (optional, hex e.g. '#FFFFFF')")
                put("textSize", "Float (optional, default 14.0)")
                put("cornerRadius", "Int (optional, corner radius dp, default 24)")
                put("icon", "String (optional, 'success', 'warning', 'error', 'info', 'star', 'bell')")
                put("alpha", "Float (optional, 0.1 to 1.0, default 0.95)")
                put("useOverlay", "Boolean (optional, true to use window overlay styling)")
            })
            put("examplePayload", JSONObject().apply {
                put("type", "TOAST_SHOW")
                put("requestId", "toast_01")
                put("message", "Build Complete!")
                put("icon", "success")
                put("gravity", "TOP")
                put("backgroundColor", "#E61E1E2E")
                put("textColor", "#4CAF50")
            })
        })

        commands.put(JSONObject().apply {
            put("type", "FLOATING_SHOW")
            put("description", "Display persistent, draggable floating widgets/HUDs over other apps with full multi-customization")
            put("parameters", JSONObject().apply {
                put("floatingId", "String (required, unique id to identify this floating widget)")
                put("text", "String (required, main body text/stats/logs)")
                put("title", "String (optional, header title)")
                put("subText", "String (optional, secondary timestamp/info)")
                put("type", "String (optional, 'HUD', 'BADGE', 'STICKY_NOTE', 'STATUS_PILL', 'CARD', 'TERMINAL_MINI')")
                put("backgroundColor", "String (optional, hex color)")
                put("textColor", "String (optional, hex color)")
                put("accentColor", "String (optional, hex color for borders/title)")
                put("textSize", "Float (optional, default 13.0)")
                put("cornerRadius", "Int (optional, default 16)")
                put("alpha", "Float (optional, 0.1 to 1.0, default 0.95)")
                put("gravity", "String (optional, 'TOP_RIGHT', 'TOP_LEFT', 'TOP_CENTER', 'BOTTOM_RIGHT', 'BOTTOM_LEFT', 'CENTER')")
                put("x", "Int (optional, X coordinate dp, default 24)")
                put("y", "Int (optional, Y coordinate dp, default 100)")
                put("widthDp", "Int (optional, -2 for WRAP_CONTENT or fixed dp)")
                put("heightDp", "Int (optional, -2 for WRAP_CONTENT or fixed dp)")
                put("isDraggable", "Boolean (optional, default true)")
                put("showCloseButton", "Boolean (optional, default true)")
                put("autoDismissSeconds", "Int (optional, 0 = permanent until dismissed, >0 = auto dismiss)")
            })
            put("examplePayload", JSONObject().apply {
                put("type", "FLOATING_SHOW")
                put("requestId", "float_01")
                put("floatingId", "termux_hud")
                put("title", "Termux HUD")
                put("text", "CPU: 12% | RAM: 1.4GB Free")
                put("subText", "Status: Active • Port 8000")
                put("type", "HUD")
                put("gravity", "TOP_RIGHT")
                put("isDraggable", true)
            })
        })

        commands.put(JSONObject().apply {
            put("type", "FLOATING_UPDATE")
            put("description", "Live-update the text, subtext, or colors of an active floating widget without flickering")
            put("parameters", JSONObject().apply {
                put("floatingId", "String (required, ID of the floating widget to update)")
                put("text", "String (optional, updated text)")
                put("subText", "String (optional, updated subtext)")
                put("title", "String (optional, updated title)")
                put("backgroundColor", "String (optional)")
                put("textColor", "String (optional)")
            })
            put("examplePayload", JSONObject().apply {
                put("type", "FLOATING_UPDATE")
                put("requestId", "float_upd_01")
                put("floatingId", "termux_hud")
                put("text", "CPU: 45% | Job Running")
            })
        })

        commands.put(JSONObject().apply {
            put("type", "FLOATING_HIDE")
            put("description", "Dismiss a specific floating widget by ID or all active floating widgets")
            put("parameters", JSONObject().apply {
                put("floatingId", "String (optional, specific ID or null/omitted to dismiss all)")
            })
            put("examplePayload", JSONObject().apply {
                put("type", "FLOATING_HIDE")
                put("requestId", "float_hide_01")
                put("floatingId", "termux_hud")
            })
        })

        commands.put(JSONObject().apply {
            put("type", "VIBRATE_TRIGGER")
            put("description", "Trigger customizable haptic feedback, vibration presets (CLICK, HEAVY_CLICK, ERROR, SUCCESS), or custom timing patterns")
            put("parameters", JSONObject().apply {
                put("durationMs", "Long (optional, default 100)")
                put("preset", "String (optional: 'CLICK', 'DOUBLE_CLICK', 'HEAVY_CLICK', 'TICK', 'ERROR', 'SUCCESS')")
                put("patternMs", "Array of Longs (optional, e.g. [0, 100, 50, 150])")
                put("amplitude", "Int (optional, 1-255, default 255)")
            })
            put("examplePayload", JSONObject().apply {
                put("type", "VIBRATE_TRIGGER")
                put("preset", "HEAVY_CLICK")
            })
        })

        commands.put(JSONObject().apply {
            put("type", "AUDIO_PLAY")
            put("description", "Play system notification tones, alarms, ringtones, synthesizer beeps, or local audio files")
            put("parameters", JSONObject().apply {
                put("soundType", "String (optional: 'notification', 'alarm', 'ringtone', 'beep', 'file')")
                put("audioPath", "String (optional: file path or content URI if soundType == 'file')")
                put("loop", "Boolean (optional, default false)")
                put("beepTone", "Int (optional ToneGenerator tone ID, default 24)")
            })
            put("examplePayload", JSONObject().apply {
                put("type", "AUDIO_PLAY")
                put("soundType", "notification")
            })
        })

        commands.put(JSONObject().apply {
            put("type", "AUDIO_STOP")
            put("description", "Stop any currently playing audio or ringtone playback")
            put("parameters", JSONObject())
            put("examplePayload", JSONObject().apply {
                put("type", "AUDIO_STOP")
            })
        })

        commands.put(JSONObject().apply {
            put("type", "VOLUME_GET")
            put("description", "Query audio volume levels for MEDIA, RING, NOTIFICATION, ALARM, VOICE_CALL, SYSTEM streams and ringer mode")
            put("parameters", JSONObject())
            put("examplePayload", JSONObject().apply {
                put("type", "VOLUME_GET")
            })
        })

        commands.put(JSONObject().apply {
            put("type", "VOLUME_SET")
            put("description", "Set volume level for specific audio stream or change device ringer mode")
            put("parameters", JSONObject().apply {
                put("stream", "String (optional: 'MEDIA', 'RING', 'NOTIFICATION', 'ALARM', 'VOICE_CALL', 'SYSTEM')")
                put("volume", "Int (optional, new volume index)")
                put("ringerMode", "String (optional: 'NORMAL', 'VIBRATE', 'SILENT')")
                put("showUi", "Boolean (optional, default false)")
            })
            put("examplePayload", JSONObject().apply {
                put("type", "VOLUME_SET")
                put("stream", "MEDIA")
                put("volume", 10)
            })
        })

        commands.put(JSONObject().apply {
            put("type", "APP_LIST")
            put("description", "List installed applications on device with package names, app labels, and versions")
            put("parameters", JSONObject().apply {
                put("includeSystem", "Boolean (optional, true to include system apps, default false)")
            })
            put("examplePayload", JSONObject().apply {
                put("type", "APP_LIST")
            })
        })

        commands.put(JSONObject().apply {
            put("type", "APP_LAUNCH")
            put("description", "Launch an installed Android application by package name or open a web URL")
            put("parameters", JSONObject().apply {
                put("packageName", "String (optional, e.g. 'com.termux', 'com.google.android.youtube')")
                put("url", "String (optional, web URL or deep link to open)")
            })
            put("examplePayload", JSONObject().apply {
                put("type", "APP_LAUNCH")
                put("packageName", "com.termux")
            })
        })

        commands.put(JSONObject().apply {
            put("type", "MEDIA_TRIM")
            put("description", "Losslessly trim or extract clips from video/audio using FFmpeg stream copy")
            put("parameters", JSONObject().apply {
                put("mediaUri", "String (required, content:// or file path)")
                put("startSeconds", "Double (start timestamp in seconds, default 0.0)")
                put("durationSeconds", "Double (required, duration of clip in seconds)")
                put("exact", "Boolean (optional, true for exact keyframe re-encoding, false for ultra-fast stream copy)")
            })
            put("examplePayload", JSONObject().apply {
                put("type", "MEDIA_TRIM")
                put("requestId", "trim_01")
                put("mediaUri", "/sdcard/Download/video.mp4")
                put("startSeconds", 5.0)
                put("durationSeconds", 10.0)
            })
        })

        commands.put(JSONObject().apply {
            put("type", "MEDIA_GIF")
            put("description", "Generate optimized animated GIF from video using high-quality 2-pass palettegen")
            put("parameters", JSONObject().apply {
                put("mediaUri", "String (required, content:// or file path)")
                put("startSeconds", "Double (optional, default 0.0)")
                put("durationSeconds", "Double (optional, default 5.0)")
                put("fps", "Int (optional, default 15)")
                put("width", "Int (optional, default 480)")
            })
            put("examplePayload", JSONObject().apply {
                put("type", "MEDIA_GIF")
                put("requestId", "gif_01")
                put("mediaUri", "/sdcard/Download/video.mp4")
                put("durationSeconds", 3.0)
                put("fps", 20)
            })
        })

        commands.put(JSONObject().apply {
            put("type", "MEDIA_SPEED")
            put("description", "Speed up (e.g. 2x) or slow down (0.5x) video and audio using FFmpeg filtergraphs")
            put("parameters", JSONObject().apply {
                put("mediaUri", "String (required, content:// or file path)")
                put("speedFactor", "Double (speed multiplier: 0.25 to 4.0, e.g. 2.0)")
            })
            put("examplePayload", JSONObject().apply {
                put("type", "MEDIA_SPEED")
                put("requestId", "speed_01")
                put("mediaUri", "/sdcard/Download/video.mp4")
                put("speedFactor", 2.0)
            })
        })

        commands.put(JSONObject().apply {
            put("type", "MEDIA_MUTE")
            put("description", "Strip audio stream from video with zero video transcoding (ultra-fast copy)")
            put("parameters", JSONObject().apply {
                put("mediaUri", "String (required, content:// or file path)")
            })
            put("examplePayload", JSONObject().apply {
                put("type", "MEDIA_MUTE")
                put("requestId", "mute_01")
                put("mediaUri", "/sdcard/Download/video.mp4")
            })
        })

        commands.put(JSONObject().apply {
            put("type", "SENSOR_GET")
            put("description", "Capture instant snapshot of all onboard sensors (accelerometer, gyroscope, lux, proximity, compass, pressure)")
            put("parameters", JSONObject())
            put("examplePayload", JSONObject().apply {
                put("type", "SENSOR_GET")
                put("requestId", "sensor_01")
            })
        })

        commands.put(JSONObject().apply {
            put("type", "DISPLAY_GET")
            put("description", "Query display metrics: resolution, DPI, refresh rate, HDR, brightness, screen timeout, power save mode")
            put("parameters", JSONObject())
            put("examplePayload", JSONObject().apply {
                put("type", "DISPLAY_GET")
                put("requestId", "disp_01")
            })
        })

        commands.put(JSONObject().apply {
            put("type", "DISPLAY_SET")
            put("description", "Control screen brightness (0-255), auto-brightness mode, and wake lock / keepScreenOn")
            put("parameters", JSONObject().apply {
                put("brightness", "Int (optional, 0-255)")
                put("autoBrightness", "Boolean (optional, true/false)")
                put("keepScreenOn", "Boolean (optional, true/false)")
            })
            put("examplePayload", JSONObject().apply {
                put("type", "DISPLAY_SET")
                put("requestId", "disp_02")
                put("brightness", 220)
                put("keepScreenOn", true)
            })
        })

        commands.put(JSONObject().apply {
            put("type", "NETWORK_TELEMETRY_GET")
            put("description", "Query network state: transport (WIFI/CELLULAR/ETHERNET), SSID, RSSI dBm, link speed, and IPv4 addresses")
            put("parameters", JSONObject())
            put("examplePayload", JSONObject().apply {
                put("type", "NETWORK_TELEMETRY_GET")
                put("requestId", "net_01")
            })
        })

        commands.put(JSONObject().apply {
            put("type", "DEVICE_DETAILS_GET")
            put("description", "Query device specs: CPU cores, RAM GB (total/available/used%), storage GB, battery %, temperature, thermal status")
            put("parameters", JSONObject())
            put("examplePayload", JSONObject().apply {
                put("type", "DEVICE_DETAILS_GET")
                put("requestId", "dev_det_01")
            })
        })

        commands.put(JSONObject().apply {
            put("type", "CAPABILITY_MANIFEST")
            put("description", "Retrieve complete capability manifest, counts, and documentation over WebSocket")
            put("parameters", JSONObject())
            put("examplePayload", JSONObject().apply {
                put("type", "CAPABILITY_MANIFEST")
                put("requestId", "manifest_01")
            })
        })

        root.put("commands", commands)

        // Capabilities overview list
        val capabilities = JSONArray()
        val capList = listOf(
            Triple("audio_record", "Microphone & Audio Capture", "Low-latency 16kHz PCM audio streaming, AGC/AEC/NS detection"),
            Triple("audio_output", "Speaker & Audio Output", "Playback routing, volume controls, speaker/Bluetooth output"),
            Triple("audio_player_sound", "System & File Sound Player", "Play notification tones, alarms, custom audio files, synthesized beeps"),
            Triple("haptics_vibration", "Haptics & Vibration Engine", "Tactile feedback presets (CLICK, HEAVY, TICK, SUCCESS), custom timing waves"),
            Triple("volume_manager", "Audio Stream & Ringer Volume", "Query and set volume levels for Music, Ring, Notification, Alarm, Call"),
            Triple("app_launcher", "Installed Apps & App Launcher", "Query installed launcher applications, launch apps by package, open URLs"),
            Triple("camera_camerax", "Camera & Photo Capture", "Silent photo capture, lens selector, torch toggle"),
            Triple("media_gallery", "Media & Scoped Storage", "Query photos, videos, and audio files via MediaStore"),
            Triple("file_storage", "File System & Document Storage", "SAF, DocumentFile, app-private file storage"),
            Triple("location_gps", "Location & GPS Services", "Fine/Coarse location, latitude, longitude, altitude, speed"),
            Triple("sensors_motion", "Motion & Environmental Sensors", "Accelerometer, Gyroscope, Magnetometer, Light, Pressure"),
            Triple("sensor_hub", "Sensor Hub & Compass Heading", "Real-time snapshot of 3-axis vectors, ambient lux, barometric pressure, compass"),
            Triple("display_power", "Display & Power Control", "Resolution, refresh rate, HDR, brightness, wake lock, timeout"),
            Triple("network_telemetry", "Network Diagnostics & Telemetry", "Wi-Fi standard, BSSID, RSSI dBm, link speed Mbps, cellular carrier"),
            Triple("device_details", "Device Hardware & Resource Monitor", "CPU cores, RAM metrics, storage usage, battery temperature, thermal throttling"),
            Triple("media_ffmpeg_trim", "Video Trimming & Clipping", "Ultra-fast stream copy and frame-accurate video clipping"),
            Triple("media_ffmpeg_gif", "Animated GIF Generator", "High-quality 2-pass palettegen GIF generator"),
            Triple("media_ffmpeg_speed", "Video Speed Modification", "High-performance PTS and atempo acceleration/slow-motion"),
            Triple("media_ffmpeg_mute", "Audio Stripper & Muteless Video", "Lossless audio stream removal"),
            Triple("bluetooth_ble", "Bluetooth & BLE Manager", "Bluetooth adapter state, paired devices, BLE scanning"),
            Triple("network_status", "Network & Connectivity", "Network state, Wi-Fi / Cellular / Ethernet capabilities"),
            Triple("notifications_manager", "System Notifications", "Post alerts, status updates, and progress notifications"),
            Triple("toast_customizer", "Custom Toast & Banner Engine", "Richly customized toasts with gravity, offsets, icons, and colors"),
            Triple("floating_overlay_manager", "Floating Overlay (Display Over Apps)", "Draggable multi-instance floating HUDs, widgets, badges, and sticky notes"),
            Triple("http_rest_api", "HTTP REST API Control (Port 8080)", "Direct curl/REST control endpoints: /api/tts, /api/toast, /api/vibrate, /api/app/launch"),
            Triple("clipboard_sync", "Clipboard Read / Write", "Read and write clipboard contents remotely"),
            Triple("tts_synthesizer", "Text-to-Speech Engine", "Native voice synthesis with custom pitch and rate"),
            Triple("torch_flashlight", "Camera Flashlight Control", "Toggle device torch ON or OFF"),
            Triple("device_telemetry", "Device & Battery Telemetry", "Battery %, temperature, charging status, RAM, ABI"),
            Triple("media_ffmpeg_probe", "FFprobe Media Inspector", "Inspect video/audio containers, streams, codecs, bitrates"),
            Triple("media_ffmpeg_convert", "FFmpeg Media Converter", "Remux, transcode, extract audio, and extract frame thumbnails"),
            Triple("accessibility_service", "Accessibility Automation", "Perform gestures (clicks, swipes) and inspect active window UI nodes"),
            Triple("system_settings", "System Settings Access", "Query screen brightness, sound modes, airplane mode status"),
            Triple("biometrics_auth", "Biometric Authentication", "BiometricPrompt fingerprint / face unlock detection"),
            Triple("telephony_manager", "Telephony & Cellular Info", "SIM carrier name, network type, signal strength")
        )
        for ((id, name, desc) in capList) {
            capabilities.put(JSONObject().apply {
                put("id", id)
                put("name", name)
                put("description", desc)
                put("supported", true)
            })
        }
        root.put("capabilities", capabilities)

        return root.toString(2)
    }
}
