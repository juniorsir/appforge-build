package com.example.presentation.dashboard

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.BaseApplication
import com.example.audio.AudioCaptureEngine
import com.example.domain.model.AudioCaptureState
import com.example.domain.model.ChatMessage
import com.example.domain.model.CompanionConfig
import com.example.domain.model.SessionState
import com.example.domain.usecase.GetCompanionConfigUseCase
import com.example.domain.usecase.GetSessionHistoryUseCase
import com.example.domain.usecase.GetSessionStateUseCase
import com.example.domain.usecase.SaveCompanionConfigUseCase
import com.example.domain.usecase.SendMessageUseCase
import com.example.domain.usecase.ToggleStreamConnectionUseCase
import com.example.services.RealtimeConnectionService
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

/**
 * Unified UI State for the Dashboard screen.
 */
data class DashboardUiState(
    val config: CompanionConfig = CompanionConfig(),
    val sessionState: SessionState = SessionState(sessionId = ""),
    val history: List<ChatMessage> = emptyList(),
    val isMicMuted: Boolean = false,
    val isCameraEnabled: Boolean = false,
    val textInput: String = ""
)

/**
 * MVVM ViewModel for handling Dashboard events, audio capture states, and settings flows.
 */
class DashboardViewModel(
    private val getCompanionConfigUseCase: GetCompanionConfigUseCase,
    private val saveCompanionConfigUseCase: SaveCompanionConfigUseCase,
    private val getSessionHistoryUseCase: GetSessionHistoryUseCase,
    private val sendMessageUseCase: SendMessageUseCase,
    private val getSessionStateUseCase: GetSessionStateUseCase,
    private val toggleStreamConnectionUseCase: ToggleStreamConnectionUseCase,
    private val audioCaptureEngine: AudioCaptureEngine,
    val permissionEventBus: com.example.capabilities.permissions.PermissionEventBus
) : ViewModel() {

    /**
     * Observable stream of permission alert events emitted from background / WebSocket subsystems.
     */
    val permissionAlerts = permissionEventBus.permissionAlerts

    // Manage user's text field buffer state locally inside ViewModel
    private val _textInput = MutableStateFlow("")

    /**
     * Expose the live telemetry state of the Real-Time Audio Capture Engine.
     */
    val audioState: StateFlow<AudioCaptureState> = audioCaptureEngine.state

    /**
     * Unified state stream combining DB configurations, live connection metrics,
     * conversation logs, and micro-interaction states.
     */
    val uiState: StateFlow<DashboardUiState> = combine(
        getCompanionConfigUseCase(),
        getSessionStateUseCase(),
        getSessionHistoryUseCase(),
        _textInput
    ) { config, sessionState, history, textInput ->
        DashboardUiState(
            config = config,
            sessionState = sessionState,
            history = history,
            isMicMuted = config.isMicMuted,
            isCameraEnabled = config.isCameraEnabled,
            textInput = textInput
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = DashboardUiState()
    )

    fun onTextInputChange(text: String) {
        _textInput.value = text
    }

    /**
     * Starts continuous low-latency audio capture via the Foreground Service.
     */
    fun startAudioCapture(context: Context) {
        RealtimeConnectionService.start(context)
    }

    /**
     * Stops audio capture and stops the Foreground Service.
     */
    fun stopAudioCapture(context: Context) {
        RealtimeConnectionService.stop(context)
    }

    /**
     * Pauses or resumes audio capture inside the running Foreground Service.
     */
    fun toggleAudioPause(context: Context) {
        val current = audioState.value
        if (current.isRecording) {
            if (current.isPaused) {
                RealtimeConnectionService.resume(context)
            } else {
                RealtimeConnectionService.pause(context)
            }
        }
    }

    /**
     * Stops and immediately restarts the audio capture engine to trigger re-initialization.
     */
    fun restartAudioCapture(context: Context) {
        viewModelScope.launch {
            RealtimeConnectionService.stop(context)
            // Small delay to allow clean native resource release before binding again
            kotlinx.coroutines.delay(400)
            RealtimeConnectionService.start(context)
        }
    }

    /**
     * Toggles the connection to the real-time AI assistant stream.
     */
    fun toggleConnection() {
        viewModelScope.launch {
            val isConnected = uiState.value.sessionState.connectionState == SessionState.ConnectionState.CONNECTED
            toggleStreamConnectionUseCase(!isConnected)
        }
    }

    /**
     * Toggles local microphone capture settings.
     */
    fun toggleMicrophone() {
        viewModelScope.launch {
            val currentConfig = uiState.value.config
            saveCompanionConfigUseCase(currentConfig.copy(isMicMuted = !currentConfig.isMicMuted))
        }
    }

    /**
     * Toggles preview video/camera streaming.
     */
    fun toggleCamera() {
        viewModelScope.launch {
            val currentConfig = uiState.value.config
            saveCompanionConfigUseCase(currentConfig.copy(isCameraEnabled = !currentConfig.isCameraEnabled))
        }
    }

    /**
     * Sends a text transcription packet to the active WebSocket stream.
     */
    fun sendMessage() {
        val text = _textInput.value.trim()
        if (text.isEmpty()) return

        viewModelScope.launch {
            _textInput.value = ""
            sendMessageUseCase(text)
        }
    }

    /**
     * Factory class to instantiate the ViewModel via Manual DI lookup.
     */
    companion object {
        val Factory: ViewModelProvider.Factory = viewModelFactory {
            initializer {
                val app = this[ViewModelProvider.AndroidViewModelFactory.APPLICATION_KEY] as BaseApplication
                val container = app.container
                DashboardViewModel(
                    getCompanionConfigUseCase = container.getCompanionConfigUseCase,
                    saveCompanionConfigUseCase = container.saveCompanionConfigUseCase,
                    getSessionHistoryUseCase = container.getSessionHistoryUseCase,
                    sendMessageUseCase = container.sendMessageUseCase,
                    getSessionStateUseCase = container.getSessionStateUseCase,
                    toggleStreamConnectionUseCase = container.toggleStreamConnectionUseCase,
                    audioCaptureEngine = container.audioCaptureEngine,
                    permissionEventBus = container.permissionEventBus
                )
            }
        }
    }
}
