package com.example.aios.sdk

object AiosSdk {
    const val SDK_VERSION = "2.1.0"
    const val DOCUMENTATION = """
### AIOS Architecture Guidelines
The AI Operating System (AIOS) forms an administrative orchestration plane managing agent task trees, shared context memory buffers, message channels, scheduled alarms, and diagnostic logs.

#### Architectural Layout:
1. Multi-Agent core: Coordinates 15 dedicated specialists under explicit user validation.
2. Event Bus protocol: Subscribes broadcast queues and point-to-point agent communication packets.
3. Hierarchical Task Planning: Explores multi-hop breakdown, evaluates sequence/parallel dependency trees.
4. Security boundaries: Isolates permission matrices per agent category. Destructive triggers request confirmation.
5. Observability telemetry: Emits profiling timeline metrics, system auditable history, and scheduling logs.
    """
}
