package com.example.ui.theme

import android.provider.Settings
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.Easing
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext

/**
 * AURA ASSISTANT — Centralized Motion & Animation Tokens
 */
@Immutable
object AuraMotion {
    // Animation Durations (ms)
    const val DurationMicro: Int = 150
    const val DurationStandard: Int = 300
    const val DurationExtended: Int = 450
    const val DurationLiquid: Int = 6000
    const val DurationStateTransition: Int = 500

    // Press Scale Values
    const val PressScaleNormal: Float = 1.0f
    const val PressScalePressed: Float = 0.98f

    // Standard Easings
    val EasingStandard: Easing = CubicBezierEasing(0.2f, 0.0f, 0.0f, 1.0f)
    val EasingEmphasized: Easing = FastOutSlowInEasing
    val EasingDecelerate: Easing = LinearOutSlowInEasing
    val EasingLinear: Easing = LinearEasing

    // Animation Specs
    fun <T> microTween() = tween<T>(durationMillis = DurationMicro, easing = EasingStandard)
    fun <T> standardTween() = tween<T>(durationMillis = DurationStandard, easing = EasingStandard)
    fun <T> extendedTween() = tween<T>(durationMillis = DurationExtended, easing = EasingStandard)
    fun <T> stateTransitionTween() = tween<T>(durationMillis = DurationStateTransition, easing = EasingStandard)

    // Soft Press Spring Spec
    val PressSpring = spring<Float>(
        dampingRatio = 0.85f,
        stiffness = 500f
    )
}

@Composable
fun rememberReducedMotion(): Boolean {
    val context = LocalContext.current
    return remember(context) {
        val durationScale = Settings.Global.getFloat(
            context.contentResolver, 
            Settings.Global.ANIMATOR_DURATION_SCALE, 
            1.0f
        )
        durationScale == 0f
    }
}
