package com.example.capabilities.settings

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import com.example.capabilities.CapabilityResult
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

interface SystemSettingsRepository {
    fun openSettings(settingType: String): CapabilityResult<Boolean>
}

@Singleton
class SystemSettingsRepositoryImpl @Inject constructor(
    @ApplicationContext private val context: Context
) : SystemSettingsRepository {

    override fun openSettings(settingType: String): CapabilityResult<Boolean> {
        return try {
            val action = when (settingType.uppercase()) {
                "WIFI" -> Settings.ACTION_WIFI_SETTINGS
                "BLUETOOTH" -> Settings.ACTION_BLUETOOTH_SETTINGS
                "LOCATION" -> Settings.ACTION_LOCATION_SOURCE_SETTINGS
                "DISPLAY" -> Settings.ACTION_DISPLAY_SETTINGS
                "SOUND" -> Settings.ACTION_SOUND_SETTINGS
                "ACCESSIBILITY" -> Settings.ACTION_ACCESSIBILITY_SETTINGS
                "DATE" -> Settings.ACTION_DATE_SETTINGS
                "NFC" -> Settings.ACTION_NFC_SETTINGS
                "BATTERY_SAVER" -> if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP_MR1) {
                    Settings.ACTION_BATTERY_SAVER_SETTINGS
                } else Settings.ACTION_SETTINGS
                "APP_DETAILS" -> Settings.ACTION_APPLICATION_DETAILS_SETTINGS
                else -> Settings.ACTION_SETTINGS
            }

            val intent = Intent(action).apply {
                if (action == Settings.ACTION_APPLICATION_DETAILS_SETTINGS) {
                    data = Uri.fromParts("package", context.packageName, null)
                }
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            CapabilityResult.Success(true)
        } catch (e: Exception) {
            CapabilityResult.Error("Failed to open settings '$settingType': ${e.message}", e)
        }
    }
}
