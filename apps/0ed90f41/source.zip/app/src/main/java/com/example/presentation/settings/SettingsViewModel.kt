package com.example.presentation.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.BaseApplication
import com.example.domain.model.CompanionConfig
import com.example.domain.repository.WebSocketRepository
import com.example.domain.usecase.GetCompanionConfigUseCase
import com.example.domain.usecase.SaveCompanionConfigUseCase
import com.example.util.ConfigurationManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

/**
 * UI State for the Settings screen.
 */
data class SettingsUiState(
    val config: CompanionConfig = CompanionConfig(),
    val webSocketUrl: String = "",
    val isSavedSuccessfully: Boolean = false,
    val logs: List<String> = emptyList()
)

/**
 * MVVM ViewModel for adjusting AI companion settings and network profiles.
 */
class SettingsViewModel(
    private val getCompanionConfigUseCase: GetCompanionConfigUseCase,
    private val saveCompanionConfigUseCase: SaveCompanionConfigUseCase,
    private val configManager: ConfigurationManager,
    private val webSocketRepository: WebSocketRepository
) : ViewModel() {

    private val _webSocketUrl = MutableStateFlow(configManager.getWebSocketServerUrl())
    private val _isSavedSuccessfully = MutableStateFlow(false)

    val logs: StateFlow<List<String>> = webSocketRepository.connectionLogs

    val uiState: StateFlow<SettingsUiState> = combine(
        getCompanionConfigUseCase(),
        _webSocketUrl,
        _isSavedSuccessfully,
        webSocketRepository.connectionLogs
    ) { config, url, saved, connectionLogs ->
        SettingsUiState(
            config = config,
            webSocketUrl = url,
            isSavedSuccessfully = saved,
            logs = connectionLogs
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = SettingsUiState()
    )

    fun onWebSocketUrlChange(url: String) {
        _webSocketUrl.value = url
    }

    fun onSystemInstructionChange(instruction: String) {
        viewModelScope.launch {
            val current = uiState.value.config
            saveCompanionConfigUseCase(current.copy(systemInstruction = instruction))
        }
    }

    fun onVoiceChange(voice: String) {
        viewModelScope.launch {
            val current = uiState.value.config
            saveCompanionConfigUseCase(current.copy(voiceName = voice))
        }
    }

    fun onSpeechRateChange(rate: Float) {
        viewModelScope.launch {
            val current = uiState.value.config
            saveCompanionConfigUseCase(current.copy(speechRate = rate))
        }
    }

    fun clearLogs() {
        webSocketRepository.clearLogs()
    }

    /**
     * Persists custom connection properties and signals feedback state.
     */
    fun saveConnectionSettings() {
        viewModelScope.launch {
            val url = _webSocketUrl.value.trim()
            if (url.isNotEmpty()) {
                configManager.setWebSocketServerUrl(url)
                _isSavedSuccessfully.value = true
                kotlinx.coroutines.delay(1500)
                _isSavedSuccessfully.value = false
            }
        }
    }

    companion object {
        val Factory: ViewModelProvider.Factory = viewModelFactory {
            initializer {
                val app = this[ViewModelProvider.AndroidViewModelFactory.APPLICATION_KEY] as BaseApplication
                val container = app.container
                SettingsViewModel(
                    getCompanionConfigUseCase = container.getCompanionConfigUseCase,
                    saveCompanionConfigUseCase = container.saveCompanionConfigUseCase,
                    configManager = container.configManager,
                    webSocketRepository = container.webSocketRepository
                )
            }
        }
    }
}

