package com.example.capabilities.permissions

import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Event representing an external or background request that failed due to a missing runtime or system permission.
 */
data class PermissionAlertEvent(
    val permission: String,
    val featureName: String,
    val reasonMessage: String,
    val timestamp: Long = System.currentTimeMillis()
)

/**
 * Thread-safe EventBus to propagate permission alerts from background engines (like Termux WebSocket,
 * Camera2 background capture, Background Audio, Accessibility, etc.) directly into the UI layer.
 */
@Singleton
class PermissionEventBus @Inject constructor() {

    private val _permissionAlerts = MutableSharedFlow<PermissionAlertEvent>(
        extraBufferCapacity = 10,
        replay = 1
    )
    val permissionAlerts: SharedFlow<PermissionAlertEvent> = _permissionAlerts.asSharedFlow()

    fun postAlert(event: PermissionAlertEvent) {
        _permissionAlerts.tryEmit(event)
    }

    fun postAlert(permission: String, featureName: String, reasonMessage: String) {
        _permissionAlerts.tryEmit(
            PermissionAlertEvent(
                permission = permission,
                featureName = featureName,
                reasonMessage = reasonMessage
            )
        )
    }
}
