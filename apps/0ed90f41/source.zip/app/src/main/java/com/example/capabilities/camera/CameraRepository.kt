package com.example.capabilities.camera

import com.example.capabilities.CapabilityResult

interface CameraRepository {
    suspend fun takePicture(): CapabilityResult<String> // Returns local file URI string
    suspend fun recordVideo(): CapabilityResult<String>
}
