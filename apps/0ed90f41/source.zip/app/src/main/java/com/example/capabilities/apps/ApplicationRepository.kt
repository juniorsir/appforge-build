package com.example.capabilities.apps

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import com.example.capabilities.CapabilityResult
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

data class AppItem(
    val packageName: String,
    val appName: String,
    val versionName: String,
    val versionCode: Long,
    val isSystemApp: Boolean,
    val targetSdkVersion: Int,
    val isEnabled: Boolean
)

interface ApplicationRepository {
    fun getInstalledApps(includeSystemApps: Boolean = false): CapabilityResult<List<AppItem>>
    fun isAppInstalled(packageName: String): CapabilityResult<Boolean>
    fun openApp(packageName: String): CapabilityResult<Boolean>
    fun openAppSettings(packageName: String): CapabilityResult<Boolean>
}

@Singleton
class ApplicationRepositoryImpl @Inject constructor(
    @ApplicationContext private val context: Context
) : ApplicationRepository {

    override fun getInstalledApps(includeSystemApps: Boolean): CapabilityResult<List<AppItem>> {
        return try {
            val pm = context.packageManager
            val flags = PackageManager.GET_META_DATA
            val packages = pm.getInstalledApplications(flags)
            val result = mutableListOf<AppItem>()

            for (appInfo in packages) {
                val isSystem = (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0
                if (!includeSystemApps && isSystem) continue

                val pkgInfo = try {
                    pm.getPackageInfo(appInfo.packageName, 0)
                } catch (e: Exception) {
                    null
                }

                val verCode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                    pkgInfo?.longVersionCode ?: 0L
                } else {
                    @Suppress("DEPRECATION")
                    pkgInfo?.versionCode?.toLong() ?: 0L
                }

                result.add(
                    AppItem(
                        packageName = appInfo.packageName,
                        appName = pm.getApplicationLabel(appInfo).toString(),
                        versionName = pkgInfo?.versionName ?: "Unknown",
                        versionCode = verCode,
                        isSystemApp = isSystem,
                        targetSdkVersion = appInfo.targetSdkVersion,
                        isEnabled = appInfo.enabled
                    )
                )
            }
            CapabilityResult.Success(result.sortedBy { it.appName.lowercase() })
        } catch (e: Exception) {
            CapabilityResult.Error("Failed to query installed apps: ${e.message}", e)
        }
    }

    override fun isAppInstalled(packageName: String): CapabilityResult<Boolean> {
        return try {
            context.packageManager.getPackageInfo(packageName, 0)
            CapabilityResult.Success(true)
        } catch (e: PackageManager.NameNotFoundException) {
            CapabilityResult.Success(false)
        } catch (e: Exception) {
            CapabilityResult.Error("Failed to check app: ${e.message}", e)
        }
    }

    override fun openApp(packageName: String): CapabilityResult<Boolean> {
        return try {
            val launchIntent = context.packageManager.getLaunchIntentForPackage(packageName)
            if (launchIntent != null) {
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(launchIntent)
                CapabilityResult.Success(true)
            } else {
                CapabilityResult.Error("No launch intent found for $packageName")
            }
        } catch (e: Exception) {
            CapabilityResult.Error("Failed to launch app $packageName: ${e.message}", e)
        }
    }

    override fun openAppSettings(packageName: String): CapabilityResult<Boolean> {
        return try {
            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                data = Uri.fromParts("package", packageName, null)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            CapabilityResult.Success(true)
        } catch (e: Exception) {
            CapabilityResult.Error("Failed to open app settings for $packageName: ${e.message}", e)
        }
    }
}
