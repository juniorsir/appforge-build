package com.example.capabilities.storage

import android.content.Context
import android.net.Uri
import android.os.Environment
import com.example.capabilities.CapabilityResult
import dagger.hilt.android.qualifiers.ApplicationContext
import java.io.File
import javax.inject.Inject

class StorageRepositoryImpl @Inject constructor(
    @ApplicationContext private val context: Context
) : StorageRepository {

    override suspend fun readTextFile(uriString: String): CapabilityResult<String> {
        return try {
            val content = if (uriString.startsWith("content://") || uriString.startsWith("file://")) {
                val uri = Uri.parse(uriString)
                context.contentResolver.openInputStream(uri)?.use { stream ->
                    stream.bufferedReader().use { it.readText() }
                } ?: return CapabilityResult.Error("Unable to open stream for $uriString")
            } else {
                val file = File(uriString)
                if (file.exists() && file.canRead()) {
                    file.readText()
                } else {
                    return CapabilityResult.Error("File not found or unreadable at path: $uriString")
                }
            }
            CapabilityResult.Success(content)
        } catch (e: Exception) {
            CapabilityResult.Error("Failed to read file: ${e.message}", e)
        }
    }

    override suspend fun writeTextFile(fileName: String, content: String): CapabilityResult<String> {
        return try {
            // Prefer direct external storage root (/sdcard or Documents) for direct access
            val documentsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS)
            val targetDir = if (documentsDir.exists() || documentsDir.mkdirs()) {
                documentsDir
            } else {
                Environment.getExternalStorageDirectory()
            }
            val targetFile = File(targetDir, fileName)
            targetFile.writeText(content)
            CapabilityResult.Success(targetFile.absolutePath)
        } catch (e: Exception) {
            try {
                val fallbackFile = File(context.filesDir, fileName)
                fallbackFile.writeText(content)
                CapabilityResult.Success(fallbackFile.absolutePath)
            } catch (ex: Exception) {
                CapabilityResult.Error("Failed to write file: ${ex.message}", ex)
            }
        }
    }

    override suspend fun deleteFile(uriString: String): CapabilityResult<Boolean> {
        return try {
            if (uriString.startsWith("content://")) {
                val count = context.contentResolver.delete(Uri.parse(uriString), null, null)
                CapabilityResult.Success(count > 0)
            } else {
                val file = File(uriString)
                val deleted = if (file.exists()) file.delete() else false
                CapabilityResult.Success(deleted)
            }
        } catch (e: Exception) {
            CapabilityResult.Error("Failed to delete file: ${e.message}", e)
        }
    }
}

