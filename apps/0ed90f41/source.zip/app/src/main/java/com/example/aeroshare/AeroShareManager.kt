package com.example.aeroshare

import android.content.Context
import android.os.Environment
import com.example.aeroshare.models.AeroDevice
import com.example.aeroshare.models.AeroTransfer
import com.example.aeroshare.models.DeviceType
import com.example.aeroshare.models.TransferDirection
import com.example.aeroshare.models.TransferStatus
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.InetAddress
import java.net.NetworkInterface
import java.net.URL
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

class AeroShareManager(
    private val context: Context,
    private val scope: CoroutineScope
) {
    private val _discoveredDevices = MutableStateFlow<List<AeroDevice>>(emptyList())
    val discoveredDevices: StateFlow<List<AeroDevice>> = _discoveredDevices.asStateFlow()

    private val _activeTransfers = MutableStateFlow<List<AeroTransfer>>(emptyList())
    val activeTransfers: StateFlow<List<AeroTransfer>> = _activeTransfers.asStateFlow()

    private val _transferHistory = MutableStateFlow<List<AeroTransfer>>(emptyList())
    val transferHistory: StateFlow<List<AeroTransfer>> = _transferHistory.asStateFlow()

    private val _isRadarActive = MutableStateFlow(true)
    val isRadarActive: StateFlow<Boolean> = _isRadarActive.asStateFlow()

    var isAutoAcceptEnabled: Boolean = true

    private val transferJobs = ConcurrentHashMap<String, Job>()
    private var discoveryJob: Job? = null

    val localDeviceName: String by lazy {
        val model = android.os.Build.MODEL
        val brand = android.os.Build.BRAND.replaceFirstChar { it.uppercase() }
        "$brand $model"
    }

    init {
        startDiscovery()
    }

    fun startDiscovery() {
        _isRadarActive.value = true
        discoveryJob?.cancel()
        discoveryJob = scope.launch(Dispatchers.IO) {
            while (isActive && _isRadarActive.value) {
                scanLocalPeers()
                delay(8000)
            }
        }
    }

    fun stopDiscovery() {
        _isRadarActive.value = false
        discoveryJob?.cancel()
    }

    fun getLocalIpAddress(): String? {
        try {
            val interfaces = NetworkInterface.getNetworkInterfaces()
            while (interfaces.hasMoreElements()) {
                val iface = interfaces.nextElement()
                if (iface.isLoopback || !iface.isUp) continue
                val addresses = iface.inetAddresses
                while (addresses.hasMoreElements()) {
                    val addr = addresses.nextElement()
                    if (!addr.isLoopbackAddress && addr is java.net.Inet4Address) {
                        return addr.hostAddress
                    }
                }
            }
        } catch (ignored: Exception) {}
        return null
    }

    private suspend fun scanLocalPeers() = withContext(Dispatchers.IO) {
        val localIp = getLocalIpAddress() ?: return@withContext
        val subnet = localIp.substringBeforeLast(".")
        val currentList = _discoveredDevices.value.toMutableList()

        // Maintain or prune expired devices (>30s old)
        val now = System.currentTimeMillis()
        currentList.removeAll { now - it.lastSeenTimestamp > 35000 }

        // Probe local network hosts or default broadcast peers
        val candidateIps = mutableListOf<String>()
        val localLastOctet = localIp.substringAfterLast(".").toIntOrNull() ?: 100
        for (i in (localLastOctet - 2)..(localLastOctet + 2)) {
            if (i in 1..254 && i != localLastOctet) {
                candidateIps.add("$subnet.$i")
            }
        }

        for (ip in candidateIps) {
            try {
                val url = URL("http://$ip:8080/api/device")
                val conn = url.openConnection() as HttpURLConnection
                conn.connectTimeout = 600
                conn.readTimeout = 600
                conn.requestMethod = "GET"
                if (conn.responseCode == 200) {
                    val body = conn.inputStream.bufferedReader().readText()
                    val json = org.json.JSONObject(body)
                    val devName = "${json.optString("manufacturer", "")} ${json.optString("model", "Peer")}".trim()
                    val id = "dev-$ip"
                    val dev = AeroDevice(
                        id = id,
                        name = if (devName.isNotBlank()) devName else "Aero Device ($ip)",
                        ip = ip,
                        port = 8080,
                        deviceType = DeviceType.PHONE,
                        rssi = -40,
                        isSecure = true,
                        lastSeenTimestamp = System.currentTimeMillis()
                    )
                    currentList.removeAll { it.ip == ip }
                    currentList.add(0, dev)
                }
                conn.disconnect()
            } catch (ignored: Exception) {
                // Host not reachable or not running Aura/AeroShare
            }
        }

        _discoveredDevices.value = currentList
    }

    fun registerPeer(peer: AeroDevice) {
        val list = _discoveredDevices.value.toMutableList()
        list.removeAll { it.ip == peer.ip || it.id == peer.id }
        list.add(0, peer)
        _discoveredDevices.value = list
    }

    fun sendFile(
        file: File,
        targetIp: String,
        targetPort: Int = 8080,
        peerName: String = "Remote Peer"
    ): String {
        val transferId = "tx-${UUID.randomUUID().toString().take(8)}"
        val transfer = AeroTransfer(
            id = transferId,
            fileName = file.name,
            sizeBytes = file.length(),
            status = TransferStatus.PENDING,
            direction = TransferDirection.SEND,
            peerName = peerName,
            peerIp = targetIp,
            localFilePath = file.absolutePath
        )

        updateActiveTransfers(transfer)

        val job = scope.launch(Dispatchers.IO) {
            try {
                transfer.status = TransferStatus.CONNECTING
                updateActiveTransfers(transfer)

                val url = URL("http://$targetIp:$targetPort/api/share/upload?filename=${file.name}&size=${file.length()}&sender=${localDeviceName}&id=$transferId")
                val conn = url.openConnection() as HttpURLConnection
                conn.doOutput = true
                conn.requestMethod = "POST"
                conn.setRequestProperty("Content-Type", "application/octet-stream")
                conn.setChunkedStreamingMode(65536)
                conn.connectTimeout = 8000
                conn.readTimeout = 60000

                transfer.status = TransferStatus.TRANSFERRING
                updateActiveTransfers(transfer)

                var totalBytesSent = 0L
                val startTime = System.currentTimeMillis()
                var lastSampleTime = startTime
                var lastSampleBytes = 0L

                file.inputStream().use { input ->
                    conn.outputStream.use { output ->
                        val buffer = ByteArray(65536)
                        var bytesRead: Int
                        while (input.read(buffer).also { bytesRead = it } != -1) {
                            if (!isActive) {
                                transfer.status = TransferStatus.CANCELLED
                                updateActiveTransfers(transfer)
                                return@launch
                            }
                            output.write(buffer, 0, bytesRead)
                            totalBytesSent += bytesRead
                            transfer.transferredBytes = totalBytesSent

                            val now = System.currentTimeMillis()
                            val deltaSec = (now - lastSampleTime) / 1000.0
                            if (deltaSec >= 0.5) {
                                val speed = ((totalBytesSent - lastSampleBytes) / deltaSec).toLong()
                                transfer.speedBytesPerSec = speed
                                val remaining = file.length() - totalBytesSent
                                transfer.etaSeconds = if (speed > 0) remaining / speed else 0
                                lastSampleTime = now
                                lastSampleBytes = totalBytesSent
                                updateActiveTransfers(transfer)
                            }
                        }
                        output.flush()
                    }
                }

                val code = conn.responseCode
                if (code in 200..299) {
                    transfer.status = TransferStatus.COMPLETED
                    transfer.completedAt = System.currentTimeMillis()
                    finishTransfer(transfer)
                } else {
                    transfer.status = TransferStatus.FAILED
                    finishTransfer(transfer, "HTTP error $code: ${conn.responseMessage}")
                }
                conn.disconnect()
            } catch (e: Exception) {
                transfer.status = TransferStatus.FAILED
                finishTransfer(transfer, e.message ?: "Transfer error")
            } finally {
                transferJobs.remove(transferId)
            }
        }

        transferJobs[transferId] = job
        return transferId
    }

    fun handleIncomingFileStream(
        fileName: String,
        sizeBytes: Long,
        senderName: String,
        senderIp: String,
        transferId: String,
        inputStream: InputStream
    ): File? {
        val destDir = File(context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: context.filesDir, "AeroShare").apply {
            if (!exists()) mkdirs()
        }
        val targetFile = File(destDir, fileName)

        val transfer = AeroTransfer(
            id = transferId,
            fileName = fileName,
            sizeBytes = sizeBytes,
            transferredBytes = 0L,
            status = TransferStatus.TRANSFERRING,
            direction = TransferDirection.RECEIVE,
            peerName = senderName,
            peerIp = senderIp,
            localFilePath = targetFile.absolutePath
        )

        updateActiveTransfers(transfer)

        var totalReceived = 0L
        val startTime = System.currentTimeMillis()
        var lastSampleTime = startTime
        var lastSampleBytes = 0L

        try {
            FileOutputStream(targetFile).use { output ->
                val buffer = ByteArray(65536)
                var bytesRead: Int
                while (inputStream.read(buffer).also { bytesRead = it } != -1) {
                    output.write(buffer, 0, bytesRead)
                    totalReceived += bytesRead
                    transfer.transferredBytes = totalReceived

                    val now = System.currentTimeMillis()
                    val deltaSec = (now - lastSampleTime) / 1000.0
                    if (deltaSec >= 0.5) {
                        val speed = ((totalReceived - lastSampleBytes) / deltaSec).toLong()
                        transfer.speedBytesPerSec = speed
                        val remaining = sizeBytes - totalReceived
                        transfer.etaSeconds = if (speed > 0) remaining / speed else 0
                        lastSampleTime = now
                        lastSampleBytes = totalReceived
                        updateActiveTransfers(transfer)
                    }
                }
                output.flush()
            }

            transfer.status = TransferStatus.COMPLETED
            transfer.completedAt = System.currentTimeMillis()
            finishTransfer(transfer)
            return targetFile
        } catch (e: Exception) {
            transfer.status = TransferStatus.FAILED
            finishTransfer(transfer, e.message ?: "Failed while receiving")
            return null
        }
    }

    fun sendTextSnippet(text: String, targetIp: String, targetPort: Int = 8080): Boolean {
        return try {
            val url = URL("http://$targetIp:$targetPort/api/share/clip")
            val conn = url.openConnection() as HttpURLConnection
            conn.doOutput = true
            conn.requestMethod = "POST"
            conn.setRequestProperty("Content-Type", "application/json")
            val payload = org.json.JSONObject().apply {
                put("text", text)
                put("sender", localDeviceName)
            }.toString()
            conn.outputStream.use { it.write(payload.toByteArray()) }
            val ok = conn.responseCode in 200..299
            conn.disconnect()
            ok
        } catch (e: Exception) {
            false
        }
    }

    fun cancelTransfer(id: String): Boolean {
        val job = transferJobs.remove(id)
        job?.cancel()
        val current = _activeTransfers.value.find { it.id == id }
        if (current != null) {
            current.status = TransferStatus.CANCELLED
            finishTransfer(current, "Cancelled by user")
            return true
        }
        return false
    }

    private fun updateActiveTransfers(transfer: AeroTransfer) {
        val list = _activeTransfers.value.toMutableList()
        val index = list.indexOfFirst { it.id == transfer.id }
        if (index >= 0) {
            list[index] = transfer.copy(
                transferredBytes = transfer.transferredBytes,
                speedBytesPerSec = transfer.speedBytesPerSec,
                etaSeconds = transfer.etaSeconds,
                status = transfer.status
            )
        } else {
            list.add(0, transfer)
        }
        _activeTransfers.value = list
    }

    private fun finishTransfer(transfer: AeroTransfer, error: String? = null) {
        val active = _activeTransfers.value.toMutableList()
        active.removeAll { it.id == transfer.id }
        _activeTransfers.value = active

        val history = _transferHistory.value.toMutableList()
        val finalItem = transfer.copy(
            status = transfer.status,
            errorMessage = error,
            completedAt = System.currentTimeMillis()
        )
        history.add(0, finalItem)
        _transferHistory.value = history
    }
}
