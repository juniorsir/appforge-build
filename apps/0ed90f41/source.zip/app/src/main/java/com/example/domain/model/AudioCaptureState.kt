package com.example.domain.model

/**
 * Domain model representing the live telemetry and state of the Real-Time Audio Capture Engine.
 */
data class AudioCaptureState(
    val isRecording: Boolean = false,
    val isPaused: Boolean = false,
    val sampleRate: Int = 16000,
    val bufferSize: Int = 0,
    val rms: Double = 0.0,
    val timestamp: Long = 0L,
    val error: String? = null
)
