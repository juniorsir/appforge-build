package com.example.util

import android.content.Context
import com.example.BuildConfig

/**
 * Handles application configuration options, API keys, and environment variables.
 * Injects keys securely through [BuildConfig] using the Secrets Gradle Plugin conventions.
 */
class ConfigurationManager(private val context: Context) {

    /**
     * Gets the Gemini API key from secure configurations.
     */
    fun getGeminiApiKey(): String {
        return try {
            // Injected via Secrets Gradle Plugin matching .env / .env.example
            BuildConfig.GEMINI_API_KEY
        } catch (e: Exception) {
            ""
        }
    }

    /**
     * Gets the WebSocket server URL for the real-time AI assistant stream.
     * Defaults to a development server URL.
     */
    fun getWebSocketServerUrl(): String {
        val sharedPrefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return sharedPrefs.getString(KEY_WEBSOCKET_URL, "wss://api.example.com/v1/assistant/stream") 
            ?: "wss://api.example.com/v1/assistant/stream"
    }

    /**
     * Sets a custom WebSocket server URL (e.g., from settings screen).
     */
    fun setWebSocketServerUrl(url: String) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_WEBSOCKET_URL, url)
            .apply()
    }

    /**
     * Checks if the secure environment keys are configured.
     */
    fun isApiKeyConfigured(): Boolean {
        return getGeminiApiKey().isNotEmpty() && getGeminiApiKey() != "MY_GEMINI_API_KEY"
    }

    companion object {
        private const val PREFS_NAME = "ai_companion_configs"
        private const val KEY_WEBSOCKET_URL = "websocket_server_url"
    }
}
