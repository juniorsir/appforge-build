package com.example.hardware

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.util.Log
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow

class SensorHubManager(private val context: Context) {

    private val TAG = "SensorHubManager"
    private val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as? SensorManager

    data class SensorSnapshot(
        val timestamp: Long = System.currentTimeMillis(),
        val accelerometer: Vector3D? = null,
        val gyroscope: Vector3D? = null,
        val magneticField: Vector3D? = null,
        val compassHeadingDegrees: Float? = null,
        val compassCardinal: String? = null,
        val ambientLightLux: Float? = null,
        val proximityCm: Float? = null,
        val isNear: Boolean? = null,
        val pressureHpa: Float? = null,
        val ambientTemperatureC: Float? = null,
        val relativeHumidityPct: Float? = null,
        val stepCount: Float? = null,
        val availableSensorNames: List<String> = emptyList()
    )

    data class Vector3D(val x: Float, val y: Float, val z: Float)

    // Current cached values
    private var lastAcc: FloatArray? = null
    private var lastGyro: FloatArray? = null
    private var lastMag: FloatArray? = null
    private var lastLight: Float? = null
    private var lastProx: Float? = null
    private var lastPressure: Float? = null
    private var lastTemp: Float? = null
    private var lastHumidity: Float? = null
    private var lastSteps: Float? = null

    private val activeListeners = mutableListOf<SensorEventListener>()

    init {
        registerBaseListeners()
    }

    private fun registerBaseListeners() {
        val sm = sensorManager ?: return
        val listener = object : SensorEventListener {
            override fun onSensorChanged(event: SensorEvent?) {
                if (event == null) return
                when (event.sensor.type) {
                    Sensor.TYPE_ACCELEROMETER -> lastAcc = event.values.clone()
                    Sensor.TYPE_GYROSCOPE -> lastGyro = event.values.clone()
                    Sensor.TYPE_MAGNETIC_FIELD -> lastMag = event.values.clone()
                    Sensor.TYPE_LIGHT -> lastLight = event.values[0]
                    Sensor.TYPE_PROXIMITY -> lastProx = event.values[0]
                    Sensor.TYPE_PRESSURE -> lastPressure = event.values[0]
                    Sensor.TYPE_AMBIENT_TEMPERATURE -> lastTemp = event.values[0]
                    Sensor.TYPE_RELATIVE_HUMIDITY -> lastHumidity = event.values[0]
                    Sensor.TYPE_STEP_COUNTER -> lastSteps = event.values[0]
                }
            }
            override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
        }

        val sensorTypes = listOf(
            Sensor.TYPE_ACCELEROMETER,
            Sensor.TYPE_GYROSCOPE,
            Sensor.TYPE_MAGNETIC_FIELD,
            Sensor.TYPE_LIGHT,
            Sensor.TYPE_PROXIMITY,
            Sensor.TYPE_PRESSURE,
            Sensor.TYPE_AMBIENT_TEMPERATURE,
            Sensor.TYPE_RELATIVE_HUMIDITY,
            Sensor.TYPE_STEP_COUNTER
        )

        for (type in sensorTypes) {
            sm.getDefaultSensor(type)?.let { sensor ->
                sm.registerListener(listener, sensor, SensorManager.SENSOR_DELAY_UI)
            }
        }
        activeListeners.add(listener)
    }

    fun getAvailableSensors(): List<String> {
        val sm = sensorManager ?: return emptyList()
        return sm.getSensorList(Sensor.TYPE_ALL).map { it.name }
    }

    fun getSnapshot(): SensorSnapshot {
        val accVec = lastAcc?.let { Vector3D(it[0], it[1], it[2]) }
        val gyroVec = lastGyro?.let { Vector3D(it[0], it[1], it[2]) }
        val magVec = lastMag?.let { Vector3D(it[0], it[1], it[2]) }

        var headingDeg: Float? = null
        var headingCard: String? = null

        if (lastAcc != null && lastMag != null) {
            val r = FloatArray(9)
            val i = FloatArray(9)
            if (SensorManager.getRotationMatrix(r, i, lastAcc, lastMag)) {
                val orientation = FloatArray(3)
                SensorManager.getOrientation(r, orientation)
                val azimuthRad = orientation[0]
                var azimuthDeg = Math.toDegrees(azimuthRad.toDouble()).toFloat()
                if (azimuthDeg < 0) azimuthDeg += 360f
                headingDeg = ((azimuthDeg * 10).toInt() / 10f)
                headingCard = when {
                    azimuthDeg >= 337.5 || azimuthDeg < 22.5 -> "N"
                    azimuthDeg in 22.5..67.5 -> "NE"
                    azimuthDeg in 67.5..112.5 -> "E"
                    azimuthDeg in 112.5..157.5 -> "SE"
                    azimuthDeg in 157.5..202.5 -> "S"
                    azimuthDeg in 202.5..247.5 -> "SW"
                    azimuthDeg in 247.5..292.5 -> "W"
                    else -> "NW"
                }
            }
        }

        val prox = lastProx
        val isNear = prox?.let { it < 3.0f }

        return SensorSnapshot(
            accelerometer = accVec,
            gyroscope = gyroVec,
            magneticField = magVec,
            compassHeadingDegrees = headingDeg,
            compassCardinal = headingCard,
            ambientLightLux = lastLight,
            proximityCm = prox,
            isNear = isNear,
            pressureHpa = lastPressure,
            ambientTemperatureC = lastTemp,
            relativeHumidityPct = lastHumidity,
            stepCount = lastSteps,
            availableSensorNames = getAvailableSensors()
        )
    }

    fun cleanUp() {
        val sm = sensorManager ?: return
        for (l in activeListeners) {
            sm.unregisterListener(l)
        }
        activeListeners.clear()
    }
}
