package com.example.ui.components.header

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.ui.theme.AuraColors
import com.example.ui.theme.AuraSpacing
import com.example.ui.theme.MyApplicationTheme

/**
 * AURA ASSISTANT — Phase 2 Header Previews across all engine states
 */
@Composable
private fun HeaderPreviewContainer(
    state: AuraEngineState
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(AuraColors.Background)
    ) {
        AuraHeader(
            engineState = state,
            onNavigateToSpeechDiagnostics = {},
            onNavigateToConversationEngine = {},
            onNavigateToDeveloper = {},
            onNavigateToSettings = {},
            enableEntranceAnimation = false
        )
    }
}

@Preview(name = "1. Engine Standby (411dp)", widthDp = 411, heightDp = 120)
@Composable
fun PreviewAuraHeaderStandby() {
    MyApplicationTheme {
        HeaderPreviewContainer(state = AuraEngineState.STANDBY)
    }
}

@Preview(name = "2. Engine Connecting (411dp)", widthDp = 411, heightDp = 120)
@Composable
fun PreviewAuraHeaderConnecting() {
    MyApplicationTheme {
        HeaderPreviewContainer(state = AuraEngineState.CONNECTING)
    }
}

@Preview(name = "3. Engine Listening (411dp)", widthDp = 411, heightDp = 120)
@Composable
fun PreviewAuraHeaderListening() {
    MyApplicationTheme {
        HeaderPreviewContainer(state = AuraEngineState.LISTENING)
    }
}

@Preview(name = "4. Engine Processing (411dp)", widthDp = 411, heightDp = 120)
@Composable
fun PreviewAuraHeaderProcessing() {
    MyApplicationTheme {
        HeaderPreviewContainer(state = AuraEngineState.PROCESSING)
    }
}

@Preview(name = "5. Engine Speaking (411dp)", widthDp = 411, heightDp = 120)
@Composable
fun PreviewAuraHeaderSpeaking() {
    MyApplicationTheme {
        HeaderPreviewContainer(state = AuraEngineState.SPEAKING)
    }
}

@Preview(name = "6. Engine Paused (411dp)", widthDp = 411, heightDp = 120)
@Composable
fun PreviewAuraHeaderPaused() {
    MyApplicationTheme {
        HeaderPreviewContainer(state = AuraEngineState.PAUSED)
    }
}

@Preview(name = "7. Engine Error (411dp)", widthDp = 411, heightDp = 120)
@Composable
fun PreviewAuraHeaderError() {
    MyApplicationTheme {
        HeaderPreviewContainer(state = AuraEngineState.ERROR)
    }
}

@Preview(name = "8. Compact Phone Width (340dp)", widthDp = 340, heightDp = 120)
@Composable
fun PreviewAuraHeaderCompactPhone() {
    MyApplicationTheme {
        HeaderPreviewContainer(state = AuraEngineState.LISTENING)
    }
}

@Preview(name = "9. Tablet Expanded Width (800dp)", widthDp = 800, heightDp = 120)
@Composable
fun PreviewAuraHeaderTablet() {
    MyApplicationTheme {
        HeaderPreviewContainer(state = AuraEngineState.LISTENING)
    }
}

@Preview(name = "10. Landscape Layout (740dp)", widthDp = 740, heightDp = 100)
@Composable
fun PreviewAuraHeaderLandscape() {
    MyApplicationTheme {
        HeaderPreviewContainer(state = AuraEngineState.LISTENING)
    }
}
