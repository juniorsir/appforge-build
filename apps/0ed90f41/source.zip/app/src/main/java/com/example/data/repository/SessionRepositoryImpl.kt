package com.example.data.repository

import android.content.Context
import android.provider.Settings
import com.example.domain.model.SessionData
import com.example.domain.repository.SessionRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.UUID

class SessionRepositoryImpl(
    private val context: Context
) : SessionRepository {

    private val sharedPrefs = context.getSharedPreferences("session_prefs", Context.MODE_PRIVATE)

    private val cachedDeviceId: String by lazy {
        val savedId = sharedPrefs.getString("device_id", null)
        if (savedId != null) {
            savedId
        } else {
            // Fallback to secure android ID or random UUID
            val secureId = Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID)
            val finalId = if (!secureId.isNullOrBlank() && secureId != "9774d56d682e549c") {
                secureId
            } else {
                UUID.randomUUID().toString()
            }
            sharedPrefs.edit().putString("device_id", finalId).apply()
            finalId
        }
    }

    private val _currentSession = MutableStateFlow(
        SessionData(
            sessionId = UUID.randomUUID().toString(),
            conversationId = UUID.randomUUID().toString(),
            deviceId = "" // Set dynamically in constructor or initializer
        )
    )
    override val currentSession: StateFlow<SessionData> = _currentSession.asStateFlow()

    init {
        // Correctly populate the device id
        _currentSession.value = _currentSession.value.copy(deviceId = cachedDeviceId)
    }

    override suspend fun createNewSession(): SessionData {
        val newSession = SessionData(
            sessionId = UUID.randomUUID().toString(),
            conversationId = UUID.randomUUID().toString(),
            deviceId = cachedDeviceId
        )
        _currentSession.value = newSession
        return newSession
    }

    override fun getDeviceId(): String = cachedDeviceId

    override fun getUserIdPlaceholder(): String = "local-user-999"
}
