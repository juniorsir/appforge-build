package com.example.domain.repository

import com.example.domain.model.AiResponseEvent
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.StateFlow

interface AiResponseRepository {

    /**
     * Stream of all AI Response events for real-time telemetry rendering.
     */
    val responseEvents: Flow<AiResponseEvent>

    /**
     * Logs an AI stream event, recording metrics like token usage, response times, and connection states.
     */
    suspend fun logEvent(event: AiResponseEvent)

    /**
     * Gets the generation latency of the last stream session in milliseconds.
     */
    val lastResponseLatencyMs: StateFlow<Long>

    /**
     * Gets the generated token count placeholder of the last streaming session.
     */
    val lastTokenCount: StateFlow<Int>

    /**
     * Gets any currently logged streaming errors.
     */
    val lastError: StateFlow<String?>
}
