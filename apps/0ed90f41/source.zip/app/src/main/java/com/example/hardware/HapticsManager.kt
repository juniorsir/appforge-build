package com.example.hardware

import android.content.Context
import android.os.Build
import android.os.CombinedVibration
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.util.Log

class HapticsManager(private val context: Context) {

    private val TAG = "HapticsManager"

    private val vibrator: Vibrator? by lazy {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
            vibratorManager?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        }
    }

    fun vibrate(
        durationMs: Long = 100L,
        preset: String? = null,
        pattern: List<Long>? = null,
        amplitude: Int = 255
    ): Boolean {
        val vib = vibrator ?: return false
        if (!vib.hasVibrator()) return false

        try {
            if (pattern != null && pattern.isNotEmpty()) {
                val patternArray = pattern.toLongArray()
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    val effect = VibrationEffect.createWaveform(patternArray, -1)
                    vib.vibrate(effect)
                } else {
                    @Suppress("DEPRECATION")
                    vib.vibrate(patternArray, -1)
                }
                return true
            }

            if (!preset.isNullOrBlank()) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    val effectId = when (preset.uppercase()) {
                        "CLICK" -> VibrationEffect.EFFECT_CLICK
                        "DOUBLE_CLICK" -> VibrationEffect.EFFECT_DOUBLE_CLICK
                        "HEAVY_CLICK" -> VibrationEffect.EFFECT_HEAVY_CLICK
                        "TICK" -> VibrationEffect.EFFECT_TICK
                        else -> VibrationEffect.EFFECT_CLICK
                    }
                    vib.vibrate(VibrationEffect.createPredefined(effectId))
                    return true
                } else {
                    val (dur, amp) = when (preset.uppercase()) {
                        "CLICK" -> Pair(20L, 100)
                        "DOUBLE_CLICK" -> {
                            vibrate(pattern = listOf(0L, 25L, 50L, 25L))
                            return true
                        }
                        "HEAVY_CLICK" -> Pair(60L, 255)
                        "TICK" -> Pair(10L, 60)
                        "ERROR" -> {
                            vibrate(pattern = listOf(0L, 70L, 60L, 70L, 60L, 120L))
                            return true
                        }
                        "SUCCESS" -> {
                            vibrate(pattern = listOf(0L, 35L, 60L, 70L))
                            return true
                        }
                        else -> Pair(durationMs, amplitude)
                    }
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        vib.vibrate(VibrationEffect.createOneShot(dur, amp.coerceIn(1, 255)))
                    } else {
                        @Suppress("DEPRECATION")
                        vib.vibrate(dur)
                    }
                    return true
                }
            }

            // Standard one-shot vibration
            val safeAmp = amplitude.coerceIn(1, 255)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vib.vibrate(VibrationEffect.createOneShot(durationMs, safeAmp))
            } else {
                @Suppress("DEPRECATION")
                vib.vibrate(durationMs)
            }
            return true
        } catch (e: Exception) {
            Log.e(TAG, "Vibration failed: ${e.message}", e)
            return false
        }
    }

    fun cancel() {
        try {
            vibrator?.cancel()
        } catch (e: Exception) {
            Log.w(TAG, "Failed to cancel vibration: ${e.message}")
        }
    }
}
