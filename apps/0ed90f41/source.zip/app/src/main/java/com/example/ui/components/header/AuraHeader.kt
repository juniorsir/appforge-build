package com.example.ui.components.header

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AuraBreakpoints
import com.example.ui.theme.AuraColors
import com.example.ui.theme.AuraMotion
import com.example.ui.theme.AuraSpacing
import com.example.ui.theme.AuraTypography

/**
 * AURA ASSISTANT — Redesigned Top Application Header (Phase 2)
 *
 * Implements a clean, high-contrast monochrome header floating on pure black:
 * [ AURA Logo ]  AURA ASSISTANT               [ STATUS ] [ PERMISSIONS ] [ MIC ] [ AI ] [ TERM ] [ SETTINGS ]
 */
@Composable
fun AuraHeader(
    engineState: AuraEngineState,
    onNavigateToSpeechDiagnostics: () -> Unit,
    onNavigateToConversationEngine: () -> Unit,
    onNavigateToDeveloper: () -> Unit,
    onNavigateToSettings: () -> Unit,
    onNavigateToPermissions: () -> Unit = {},
    modifier: Modifier = Modifier,
    enableEntranceAnimation: Boolean = true
) {
    // Subtle entrance animation: opacity 0 -> 1, offsetY -4dp -> 0dp
    val alphaAnim = remember { Animatable(if (enableEntranceAnimation) 0f else 1f) }
    val offsetYAnim = remember { Animatable(if (enableEntranceAnimation) -4f else 0f) }

    LaunchedEffect(Unit) {
        if (enableEntranceAnimation) {
            alphaAnim.animateTo(
                targetValue = 1f,
                animationSpec = tween(durationMillis = AuraMotion.DurationStandard, easing = AuraMotion.EasingStandard)
            )
        }
    }

    LaunchedEffect(Unit) {
        if (enableEntranceAnimation) {
            offsetYAnim.animateTo(
                targetValue = 0f,
                animationSpec = tween(durationMillis = AuraMotion.DurationStandard, easing = AuraMotion.EasingStandard)
            )
        }
    }

    val statusBarTopPadding = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()

    BoxWithConstraints(
        modifier = modifier
            .fillMaxWidth()
            .background(AuraColors.Background)
            .padding(top = statusBarTopPadding)
            .graphicsLayer {
                alpha = alphaAnim.value
                translationY = offsetYAnim.value.dp.toPx()
            }
    ) {
        val availableWidth = maxWidth
        val horizontalMargin = AuraSpacing.computeScreenMargin(availableWidth)
        val isCompact = availableWidth < AuraBreakpoints.NormalMin
        val isTablet = availableWidth >= AuraBreakpoints.ExpandedMin

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = horizontalMargin),
            contentAlignment = Alignment.Center
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = AuraSpacing.MaxContentWidth)
                    .height(if (isCompact) 52.dp else 58.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Left: Logo + Application Title (Primary Identity Group)
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(if (isCompact) 8.dp else 12.dp)
                ) {
                    AuraLogo(
                        size = if (isCompact) 30.dp else 34.dp
                    )

                    Column(
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text(
                            text = "AURA ASSISTANT",
                            style = if (isCompact) {
                                AuraTypography.AppTitle.copy(fontSize = 16.sp, lineHeight = 20.sp, letterSpacing = 0.5.sp)
                            } else {
                                AuraTypography.AppTitle.copy(fontSize = 18.sp, lineHeight = 22.sp, letterSpacing = 0.5.sp)
                            },
                            color = AuraColors.TextPrimary
                        )
                        Text(
                            text = "REALTIME AI SUBSYSTEM",
                            style = AuraTypography.TechnicalLabel.copy(
                                fontSize = 9.sp,
                                letterSpacing = 0.8.sp
                            ),
                            color = AuraColors.TextMuted
                        )
                    }
                }

                // Right: Status Indicator + Secondary Action Buttons
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(if (isCompact) 2.dp else 4.dp)
                ) {
                    // Status Indicator
                    AuraHeaderStatus(
                        engineState = engineState,
                        height = if (isCompact) 26.dp else 28.dp
                    )

                    Spacer(modifier = Modifier.width(if (isCompact) 2.dp else 4.dp))

                    // Secondary Header Action Buttons
                    AuraHeaderAction(
                        icon = Icons.Default.Shield,
                        contentDescriptionText = "Manage All 45+ System Permissions",
                        testTag = "permissions_button",
                        onClick = onNavigateToPermissions,
                        size = if (isCompact) 34.dp else 36.dp,
                        iconSize = if (isCompact) 14.dp else 16.dp,
                        isProminent = true
                    )

                    AuraHeaderAction(
                        icon = Icons.Default.Mic,
                        contentDescriptionText = "Navigate to Speech Diagnostics",
                        testTag = "speech_diagnostics_navigate_button",
                        onClick = onNavigateToSpeechDiagnostics,
                        size = if (isCompact) 34.dp else 36.dp,
                        iconSize = if (isCompact) 14.dp else 16.dp
                    )

                    AuraHeaderAction(
                        icon = Icons.Default.Psychology,
                        contentDescriptionText = "Navigate to AI Conversation Engine",
                        testTag = "conversation_engine_navigate_button",
                        onClick = onNavigateToConversationEngine,
                        size = if (isCompact) 34.dp else 36.dp,
                        iconSize = if (isCompact) 14.dp else 16.dp
                    )

                    if (!isCompact || availableWidth >= 340.dp) {
                        AuraHeaderAction(
                            icon = Icons.Default.Terminal,
                            contentDescriptionText = "Navigate to Developer Console",
                            testTag = "developer_navigate_button",
                            onClick = onNavigateToDeveloper,
                            size = if (isCompact) 34.dp else 36.dp,
                            iconSize = if (isCompact) 14.dp else 16.dp
                        )
                    }

                    AuraHeaderAction(
                        icon = Icons.Default.Settings,
                        contentDescriptionText = "Navigate to Application Settings",
                        testTag = "settings_navigate_button",
                        onClick = onNavigateToSettings,
                        size = if (isCompact) 34.dp else 36.dp,
                        iconSize = if (isCompact) 14.dp else 16.dp
                    )
                }
            }
        }
    }
}
