package com.example.capabilities.intents

import android.content.Context
import android.content.Intent
import android.net.Uri
import com.example.capabilities.CapabilityResult
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

interface IntentRepository {
    fun canHandleIntent(intent: Intent): Boolean
    fun openUrl(url: String): CapabilityResult<Boolean>
    fun shareText(text: String, title: String = "Share via"): CapabilityResult<Boolean>
    fun openMaps(queryOrCoordinates: String): CapabilityResult<Boolean>
    fun sendEmail(recipient: String, subject: String, body: String): CapabilityResult<Boolean>
}

@Singleton
class IntentRepositoryImpl @Inject constructor(
    @ApplicationContext private val context: Context
) : IntentRepository {

    override fun canHandleIntent(intent: Intent): Boolean {
        val activities = context.packageManager.queryIntentActivities(intent, 0)
        return activities.isNotEmpty()
    }

    override fun openUrl(url: String): CapabilityResult<Boolean> {
        return try {
            val formattedUrl = if (!url.startsWith("http://") && !url.startsWith("https://")) {
                "https://$url"
            } else url
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(formattedUrl)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            CapabilityResult.Success(true)
        } catch (e: Exception) {
            CapabilityResult.Error("Failed to open URL: ${e.message}", e)
        }
    }

    override fun shareText(text: String, title: String): CapabilityResult<Boolean> {
        return try {
            val sendIntent = Intent().apply {
                action = Intent.ACTION_SEND
                putExtra(Intent.EXTRA_TEXT, text)
                type = "text/plain"
            }
            val shareIntent = Intent.createChooser(sendIntent, title).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(shareIntent)
            CapabilityResult.Success(true)
        } catch (e: Exception) {
            CapabilityResult.Error("Failed to share text: ${e.message}", e)
        }
    }

    override fun openMaps(queryOrCoordinates: String): CapabilityResult<Boolean> {
        return try {
            val uri = Uri.parse("geo:0,0?q=${Uri.encode(queryOrCoordinates)}")
            val mapIntent = Intent(Intent.ACTION_VIEW, uri).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(mapIntent)
            CapabilityResult.Success(true)
        } catch (e: Exception) {
            CapabilityResult.Error("Failed to open maps: ${e.message}", e)
        }
    }

    override fun sendEmail(recipient: String, subject: String, body: String): CapabilityResult<Boolean> {
        return try {
            val emailIntent = Intent(Intent.ACTION_SENDTO).apply {
                data = Uri.parse("mailto:${Uri.encode(recipient)}")
                putExtra(Intent.EXTRA_SUBJECT, subject)
                putExtra(Intent.EXTRA_TEXT, body)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(emailIntent)
            CapabilityResult.Success(true)
        } catch (e: Exception) {
            CapabilityResult.Error("Failed to send email: ${e.message}", e)
        }
    }
}
