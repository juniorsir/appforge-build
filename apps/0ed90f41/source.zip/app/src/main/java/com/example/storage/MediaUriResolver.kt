package com.example.storage

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import com.arthenica.ffmpegkit.FFmpegKitConfig
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.util.UUID

object MediaUriResolver {
    
    data class ResolvedPath(val path: String, val isTemporary: Boolean)

    /**
     * Resolves an Android Uri to a direct file path if possible.
     * If it's a content:// URI that doesn't map to a direct file,
     * copies it to a temporary file using optimized 80KB buffering.
     */
    fun resolveForFFmpeg(context: Context, uri: Uri): ResolvedPath {
        if (uri.scheme == "file") {
            return ResolvedPath(uri.path ?: "", false)
        }

        // Direct path check if path is already an accessible file
        val uriStr = uri.toString()
        if (uriStr.startsWith("/") && File(uriStr).exists()) {
            return ResolvedPath(uriStr, false)
        }
        val rawPath = uri.path
        if (rawPath != null && File(rawPath).exists()) {
            return ResolvedPath(rawPath, false)
        }

        if (uri.scheme == "content") {
            // Check if FFmpegKit can map SAF directly with zero copy
            try {
                val safPath = FFmpegKitConfig.getSafParameterForRead(context, uri)
                if (!safPath.isNullOrBlank()) {
                    return ResolvedPath(safPath, false)
                }
            } catch (e: Throwable) {
                // Fallback to fast stream copy
            }

            val fileName = getFileName(context, uri) ?: UUID.randomUUID().toString()
            val tempFile = File(context.cacheDir, "ffmpeg_temp_${UUID.randomUUID()}_$fileName")
            
            try {
                context.contentResolver.openInputStream(uri)?.use { input ->
                    FileOutputStream(tempFile).use { output ->
                        input.copyTo(output, bufferSize = 81920)
                        output.flush()
                    }
                }
                return ResolvedPath(tempFile.absolutePath, true)
            } catch (e: Exception) {
                // Return URI path as fallback
                return ResolvedPath(uri.toString(), false)
            }
        }
        
        return ResolvedPath(uri.toString(), false)
    }

    private fun getFileName(context: Context, uri: Uri): String? {
        var result: String? = null
        if (uri.scheme == "content") {
            val cursor = context.contentResolver.query(uri, null, null, null, null)
            try {
                if (cursor != null && cursor.moveToFirst()) {
                    val index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (index >= 0) {
                        result = cursor.getString(index)
                    }
                }
            } finally {
                cursor?.close()
            }
        }
        if (result == null) {
            result = uri.path?.let { path ->
                val cut = path.lastIndexOf('/')
                if (cut != -1) path.substring(cut + 1) else path
            }
        }
        return result
    }
}

