package com.example.domain.repository

import com.example.domain.model.PromptTemplate
import kotlinx.coroutines.flow.Flow

interface PromptRepository {

    /**
     * Emits the active multi-tier prompt templates.
     */
    fun getPromptTemplate(id: String = "default"): Flow<PromptTemplate>

    /**
     * Synchronously gets the prompt templates.
     */
    suspend fun getPromptTemplateSync(id: String = "default"): PromptTemplate

    /**
     * Saves or updates prompt templates.
     */
    suspend fun savePromptTemplate(template: PromptTemplate)

    /**
     * Dynamically builds a fully populated user prompt using a template and a map of variables.
     */
    fun buildUserPrompt(template: String, variables: Map<String, String>): String
}
