package com.example.capabilities.events

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import com.example.capabilities.CapabilityResult
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import javax.inject.Inject
import javax.inject.Singleton

data class SystemEventModel(
    val eventType: String,
    val timestamp: Long = System.currentTimeMillis(),
    val data: Map<String, Any> = emptyMap()
)

interface SystemEventsRepository {
    fun getSystemEventsFlow(): Flow<SystemEventModel>
    fun getLastKnownBatteryState(): CapabilityResult<Map<String, Any>>
}

@Singleton
class SystemEventsRepositoryImpl @Inject constructor(
    @ApplicationContext private val context: Context
) : SystemEventsRepository {

    override fun getSystemEventsFlow(): Flow<SystemEventModel> = callbackFlow {
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context, intent: Intent) {
                val action = intent.action ?: return
                val event = when (action) {
                    Intent.ACTION_BATTERY_LOW -> SystemEventModel("BATTERY_LOW")
                    Intent.ACTION_BATTERY_OKAY -> SystemEventModel("BATTERY_OKAY")
                    Intent.ACTION_POWER_CONNECTED -> SystemEventModel("POWER_CONNECTED")
                    Intent.ACTION_POWER_DISCONNECTED -> SystemEventModel("POWER_DISCONNECTED")
                    Intent.ACTION_SCREEN_ON -> SystemEventModel("SCREEN_ON")
                    Intent.ACTION_SCREEN_OFF -> SystemEventModel("SCREEN_OFF")
                    Intent.ACTION_TIMEZONE_CHANGED -> SystemEventModel("TIMEZONE_CHANGED")
                    Intent.ACTION_LOCALE_CHANGED -> SystemEventModel("LOCALE_CHANGED")
                    else -> SystemEventModel("SYSTEM_EVENT", data = mapOf("action" to action))
                }
                trySend(event)
            }
        }

        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_BATTERY_LOW)
            addAction(Intent.ACTION_BATTERY_OKAY)
            addAction(Intent.ACTION_POWER_CONNECTED)
            addAction(Intent.ACTION_POWER_DISCONNECTED)
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_TIMEZONE_CHANGED)
            addAction(Intent.ACTION_LOCALE_CHANGED)
        }

        context.registerReceiver(receiver, filter)

        awaitClose {
            try {
                context.unregisterReceiver(receiver)
            } catch (e: Exception) {
                // Ignore if already unregistered
            }
        }
    }

    override fun getLastKnownBatteryState(): CapabilityResult<Map<String, Any>> {
        return try {
            val filter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
            val intent = context.registerReceiver(null, filter)
            val level = intent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scale = intent?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
            val status = intent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
            val plugged = intent?.getIntExtra(BatteryManager.EXTRA_PLUGGED, -1) ?: -1

            CapabilityResult.Success(
                mapOf(
                    "level" to level,
                    "scale" to scale,
                    "percentage" to if (scale > 0) (level * 100 / scale) else -1,
                    "isCharging" to (status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL),
                    "plugged" to plugged
                )
            )
        } catch (e: Exception) {
            CapabilityResult.Error("Failed to query battery state: ${e.message}", e)
        }
    }
}
