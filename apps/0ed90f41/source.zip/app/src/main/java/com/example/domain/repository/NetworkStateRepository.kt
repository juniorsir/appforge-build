package com.example.domain.repository

import kotlinx.coroutines.flow.StateFlow

interface NetworkStateRepository {
    /**
     * Flow of general internet connectivity state.
     */
    val isNetworkAvailable: StateFlow<Boolean>

    /**
     * Flow representing if the Termux local server endpoint is reachable.
     */
    val isLocalhostReachable: StateFlow<Boolean>

    /**
     * Triggers an active reachability check (e.g. pinging the HTTP server).
     */
    suspend fun checkLocalhostReachability(host: String, port: Int): Boolean
}
