package com.example.capabilities.sms

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.telephony.SmsManager
import com.example.capabilities.CapabilityResult
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

data class SmsCapabilityInfo(
    val hasTelephony: Boolean,
    val canSendSmsDirectly: Boolean,
    val isDefaultSmsApp: Boolean
)

interface SmsRepository {
    fun getSmsCapabilityInfo(): CapabilityResult<SmsCapabilityInfo>
    fun composeSmsIntent(phoneNumber: String, message: String): CapabilityResult<Boolean>
}

@Singleton
class SmsRepositoryImpl @Inject constructor(
    @ApplicationContext private val context: Context
) : SmsRepository {

    override fun getSmsCapabilityInfo(): CapabilityResult<SmsCapabilityInfo> {
        val hasTelephony = context.packageManager.hasSystemFeature(android.content.pm.PackageManager.FEATURE_TELEPHONY)
        val defaultSmsPackage = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            android.provider.Telephony.Sms.getDefaultSmsPackage(context)
        } else null
        val isDefault = defaultSmsPackage == context.packageName

        return CapabilityResult.Success(
            SmsCapabilityInfo(
                hasTelephony = hasTelephony,
                canSendSmsDirectly = hasTelephony && context.checkSelfPermission(android.Manifest.permission.SEND_SMS) == android.content.pm.PackageManager.PERMISSION_GRANTED,
                isDefaultSmsApp = isDefault
            )
        )
    }

    override fun composeSmsIntent(phoneNumber: String, message: String): CapabilityResult<Boolean> {
        return try {
            val intent = Intent(Intent.ACTION_SENDTO).apply {
                data = Uri.parse("smsto:${Uri.encode(phoneNumber)}")
                putExtra("sms_body", message)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            CapabilityResult.Success(true)
        } catch (e: Exception) {
            CapabilityResult.Error("Failed to launch SMS composer: ${e.message}", e)
        }
    }
}
