package com.example.ffmpeg

import android.content.Context
import android.net.Uri
import android.util.Log
import com.arthenica.ffmpegkit.FFprobeKit
import com.example.media.AudioStreamInfo
import com.example.media.MediaInfo
import com.example.media.VideoStreamInfo
import com.example.storage.MediaUriResolver
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object MediaProbe {
    private const val TAG = "MediaProbe"

    suspend fun probe(context: Context, uri: Uri): MediaInfo? = withContext(Dispatchers.IO) {
        var tempFile: String? = null
        try {
            // Resolve Android Uri to a file path FFmpeg can read
            val resolvedPath = MediaUriResolver.resolveForFFmpeg(context, uri)
            if (resolvedPath.isTemporary) {
                tempFile = resolvedPath.path
            }

            val session = FFprobeKit.execute("-v error -show_format -show_streams -print_format json \"${resolvedPath.path}\"")
            if (!session.returnCode.isValueSuccess) {
                Log.e(TAG, "FFprobe failed for $uri: ${session.allLogsAsString}")
                return@withContext null
            }

            val jsonOutput = session.allLogsAsString ?: ""
            // Simple parsing to avoid adding heavy JSON libraries if not already present.
            // But we should use JSONObject or Moshi. We can use org.json.JSONObject.
            
            val json = org.json.JSONObject(jsonOutput)
            val format = json.optJSONObject("format")
            val streams = json.optJSONArray("streams")

            val container = format?.optString("format_name")
            val duration = format?.optDouble("duration", 0.0) ?: 0.0
            val size = format?.optLong("size", 0L) ?: 0L

            var videoStream: VideoStreamInfo? = null
            var audioStream: AudioStreamInfo? = null
            val streamCount = streams?.length() ?: 0

            for (i in 0 until streamCount) {
                val stream = streams!!.getJSONObject(i)
                val codecType = stream.optString("codec_type")
                val codecName = stream.optString("codec_name")

                if (codecType == "video" && videoStream == null) {
                    val width = stream.optInt("width", 0)
                    val height = stream.optInt("height", 0)
                    val bitRate = stream.optLong("bit_rate", 0L)
                    val rFrameRate = stream.optString("r_frame_rate", "0/1")
                    val frameRate = parseFrameRate(rFrameRate)
                    videoStream = VideoStreamInfo(codecName, width, height, frameRate, bitRate)
                } else if (codecType == "audio" && audioStream == null) {
                    val sampleRate = stream.optInt("sample_rate", 0)
                    val channels = stream.optInt("channels", 0)
                    val bitRate = stream.optLong("bit_rate", 0L)
                    audioStream = AudioStreamInfo(codecName, sampleRate, channels, bitRate)
                }
            }

            MediaInfo(
                uri = uri.toString(),
                container = container,
                durationSeconds = duration,
                videoStream = videoStream,
                audioStream = audioStream,
                streamCount = streamCount,
                sizeBytes = size
            )
        } catch (e: Exception) {
            Log.e(TAG, "Exception probing media $uri", e)
            null
        } finally {
            tempFile?.let {
                try {
                    java.io.File(it).delete()
                } catch (e: Exception) {}
            }
        }
    }

    private fun parseFrameRate(fpsStr: String): Double {
        return try {
            val parts = fpsStr.split("/")
            if (parts.size == 2) {
                parts[0].toDouble() / parts[1].toDouble()
            } else {
                fpsStr.toDouble()
            }
        } catch (e: Exception) {
            0.0
        }
    }
}
