package com.example.domain.repository

import com.example.domain.model.ConversationRequest
import kotlinx.coroutines.flow.StateFlow

interface SpeechRepository {
    val partialTranscript: StateFlow<String>
    val finalTranscript: StateFlow<String>
    val currentLanguage: StateFlow<String>
    val speechDurationMs: StateFlow<Long>
    val streamingLatencyMs: StateFlow<Long>
    val recognitionState: StateFlow<RecognitionState>
    val errorState: StateFlow<String?>

    suspend fun startStt(sampleRate: Int = 16000, language: String? = null)
    suspend fun stopStt()
    suspend fun cancelStt()
    fun clearTranscript()
    fun prepareConversationRequest(): ConversationRequest?

    enum class RecognitionState {
        IDLE,
        STARTING,
        LISTENING,
        PROCESSING,
        ERROR
    }
}
