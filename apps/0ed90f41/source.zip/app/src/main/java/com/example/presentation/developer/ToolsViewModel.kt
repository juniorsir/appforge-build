package com.example.presentation.developer

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.tools.core.Tool
import com.example.tools.repository.*
import com.example.tools.execution.ConfirmationManager
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class ToolsViewModel @Inject constructor(
    toolRegistry: ToolRegistryRepository,
    executionHistory: ExecutionHistoryRepository,
    confirmationRepository: ConfirmationRepository,
    private val confirmationManager: ConfirmationManager
) : ViewModel() {

    val tools: StateFlow<List<Tool>> = toolRegistry.getTools()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val executionHistory: StateFlow<List<ExecutionLog>> = executionHistory.getHistory()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val pendingConfirmations: StateFlow<List<ConfirmationRequest>> = confirmationRepository.getPendingRequests()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun approveTool(executionId: String) {
        viewModelScope.launch {
            confirmationManager.approve(executionId)
        }
    }

    fun rejectTool(executionId: String) {
        viewModelScope.launch {
            confirmationManager.reject(executionId)
        }
    }
}
