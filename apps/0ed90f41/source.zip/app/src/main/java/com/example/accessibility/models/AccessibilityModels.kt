package com.example.accessibility.models

import kotlinx.serialization.Serializable

@Serializable
data class AccessibilityEventModel(
    val eventType: String,
    val packageName: String?,
    val className: String?,
    val text: String?,
    val contentDescription: String?,
    val viewId: String?,
    val timestamp: Long = System.currentTimeMillis()
)

@Serializable
data class GestureRequestModel(
    val id: String,
    val type: String, // "CLICK", "SWIPE", "DRAG"
    val startX: Float,
    val startY: Float,
    val endX: Float = 0f,
    val endY: Float = 0f,
    val durationMs: Long = 100
)

@Serializable
data class AccessibilityNodeModel(
    val text: String?,
    val contentDescription: String?,
    val viewId: String?,
    val className: String?,
    val isClickable: Boolean,
    val isScrollable: Boolean,
    val isEditable: Boolean,
    val isFocused: Boolean,
    val bounds: String,
    val children: List<AccessibilityNodeModel> = emptyList()
)

@Serializable
data class AccessibilityServiceStatus(
    val isEnabled: Boolean = false,
    val lastConnectedTime: Long = 0L,
    val recentEventsCount: Int = 0,
    val recentGesturesCount: Int = 0
)
