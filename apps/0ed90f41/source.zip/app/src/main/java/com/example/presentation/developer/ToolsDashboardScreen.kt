package com.example.presentation.developer

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.aios.core.Agent
import com.example.aios.core.AgentState
import com.example.aios.core.HealthStatus
import com.example.aios.planning.Goal
import com.example.aios.planning.GoalStatus
import com.example.aios.planning.Task
import com.example.aios.planning.TaskStatus
import com.example.aios.workflows.Workflow
import com.example.aios.scheduler.ScheduledTask
import com.example.aios.observability.AuditLogEntry
import com.example.aios.communication.AiosEvent
import com.example.aios.sdk.AiosSdk

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ToolsDashboardScreen(
    onNavigateBack: () -> Unit = {},
    viewModel: AiosViewModel = viewModel(factory = AiosViewModel.Factory)
) {
    var selectedTab by remember { mutableStateOf(0) }
    val agents by viewModel.agents.collectAsState()
    val activeGoals by viewModel.activeGoals.collectAsState()
    val workflows by viewModel.workflows.collectAsState()
    val schedules by viewModel.schedules.collectAsState()
    val auditLogs by viewModel.auditLogs.collectAsState()
    val eventLogs by viewModel.eventLogs.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("AI Operating System (AIOS) Control Center", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(
                        onClick = onNavigateBack,
                        modifier = Modifier.testTag("aios_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Default.ArrowBack,
                            contentDescription = "Navigate Back"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer
                )
            )
        },
        modifier = Modifier.testTag("aios_control_center")
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
        ) {
            ScrollableTabRow(
                selectedTabIndex = selectedTab,
                edgePadding = 16.dp,
                containerColor = MaterialTheme.colorScheme.surfaceVariant
            ) {
                Tab(selected = selectedTab == 0, onClick = { selectedTab = 0 }, text = { Text("15 Agents") })
                Tab(selected = selectedTab == 1, onClick = { selectedTab = 1 }, text = { Text("Planner") })
                Tab(selected = selectedTab == 2, onClick = { selectedTab = 2 }, text = { Text("Workflows") })
                Tab(selected = selectedTab == 3, onClick = { selectedTab = 3 }, text = { Text("Scheduler") })
                Tab(selected = selectedTab == 4, onClick = { selectedTab = 4 }, text = { Text("Event Bus") })
                Tab(selected = selectedTab == 5, onClick = { selectedTab = 5 }, text = { Text("Audit Trail") })
                Tab(selected = selectedTab == 6, onClick = { selectedTab = 6 }, text = { Text("SDK Doc") })
            }

            Box(modifier = Modifier.fillMaxSize().weight(1f)) {
                when (selectedTab) {
                    0 -> AgentsTab(agents)
                    1 -> PlannerTab(activeGoals, viewModel::triggerGoal)
                    2 -> WorkflowsTab(workflows, viewModel::triggerWorkflow, viewModel::addCustomWorkflow)
                    3 -> SchedulerTab(schedules, viewModel::toggleSchedule, viewModel::addCustomSchedule)
                    4 -> EventsTab(eventLogs)
                    5 -> AuditTrailTab(auditLogs)
                    6 -> SdkDocTab()
                }
            }
        }
    }
}

@Composable
fun AgentsTab(agents: List<Agent>) {
    LazyVerticalGrid(
        columns = GridCells.Adaptive(minSize = 300.dp),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        horizontalArrangement = Arrangement.spacedBy(16.dp),
        modifier = Modifier.fillMaxSize().testTag("agents_grid")
    ) {
        items(agents) { agent ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(
                        1.dp,
                        MaterialTheme.colorScheme.outlineVariant,
                        RoundedCornerShape(12.dp)
                    ),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = agent.identity.name,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Badge(
                                containerColor = when (agent.healthStatus) {
                                    HealthStatus.HEALTHY -> Color(0xFF2E7D32)
                                    HealthStatus.WARNING -> Color(0xFFEF6C00)
                                    HealthStatus.CRITICAL -> Color(0xFFC62828)
                                }
                            ) {
                                Text(
                                    agent.healthStatus.name,
                                    color = Color.White,
                                    style = MaterialTheme.typography.labelSmall,
                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Badge(
                                containerColor = when (agent.state) {
                                    AgentState.IDLE -> MaterialTheme.colorScheme.secondaryContainer
                                    AgentState.BUSY -> MaterialTheme.colorScheme.tertiaryContainer
                                    AgentState.OFFLINE -> MaterialTheme.colorScheme.errorContainer
                                    AgentState.ERROR -> MaterialTheme.colorScheme.error
                                }
                            ) {
                                Text(
                                    agent.state.name,
                                    style = MaterialTheme.typography.labelSmall,
                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = agent.identity.description,
                        style = MaterialTheme.typography.bodyMedium,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )

                    Spacer(modifier = Modifier.height(12.dp))
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "Capabilities",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        agent.identity.capabilities.forEach { cap ->
                            SuggestionChip(
                                onClick = {},
                                label = { Text(cap, style = MaterialTheme.typography.labelSmall) }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Required Tools",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = if (agent.identity.requiredTools.isEmpty()) "None" else agent.identity.requiredTools.joinToString(),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.secondary
                    )
                }
            }
        }
    }
}

@Composable
fun PlannerTab(
    goals: List<Goal>,
    onTriggerGoal: (String) -> Unit
) {
    var goalInput by remember { mutableStateOf("") }

    Column(modifier = Modifier.fillMaxSize()) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "Goal Decomposition Planning Engine",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = goalInput,
                    onValueChange = { goalInput = it },
                    label = { Text("Enter complex target goal") },
                    placeholder = { Text("e.g. Code modular database backend or Morning Briefing") },
                    modifier = Modifier.fillMaxWidth().testTag("goal_input_field")
                )
                Spacer(modifier = Modifier.height(12.dp))
                Button(
                    onClick = {
                        if (goalInput.isNotBlank()) {
                            onTriggerGoal(goalInput)
                            goalInput = ""
                        }
                    },
                    modifier = Modifier.align(Alignment.End).testTag("trigger_goal_button")
                ) {
                    Icon(Icons.Default.PlayArrow, contentDescription = "Run")
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Decompose & Execute Goal")
                }
            }
        }

        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            modifier = Modifier.fillMaxWidth().weight(1f).testTag("planner_goals_list")
        ) {
            items(goals) { goal ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "Goal: ${goal.description}",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.weight(1f)
                            )
                            Badge(
                                containerColor = when (goal.status) {
                                    GoalStatus.PENDING -> MaterialTheme.colorScheme.surfaceVariant
                                    GoalStatus.RUNNING -> MaterialTheme.colorScheme.primaryContainer
                                    GoalStatus.COMPLETED -> Color(0xFF2E7D32)
                                    GoalStatus.FAILED -> Color(0xFFC62828)
                                }
                            ) {
                                Text(
                                    goal.status.name,
                                    style = MaterialTheme.typography.labelMedium,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "Orchestrated Subtask Breakdown:",
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.secondary
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        goal.tasks.forEach { task ->
                            Column(modifier = Modifier.padding(vertical = 4.dp)) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                        Icon(
                                            imageVector = when (task.status) {
                                                TaskStatus.PENDING -> Icons.Default.Info
                                                TaskStatus.RUNNING -> Icons.Default.Refresh
                                                TaskStatus.COMPLETED -> Icons.Default.CheckCircle
                                                TaskStatus.FAILED -> Icons.Default.Warning
                                                TaskStatus.CANCELLED -> Icons.Default.Close
                                            },
                                            contentDescription = null,
                                            tint = when (task.status) {
                                                TaskStatus.COMPLETED -> Color(0xFF2E7D32)
                                                TaskStatus.FAILED -> Color(0xFFC62828)
                                                else -> MaterialTheme.colorScheme.primary
                                            }
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Column {
                                            Text(
                                                text = task.title,
                                                style = MaterialTheme.typography.bodyMedium,
                                                fontWeight = FontWeight.SemiBold
                                            )
                                            Text(
                                                text = "Assigned: ${task.assignedAgentId ?: "None"}",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.secondary
                                            )
                                        }
                                    }
                                    Text(
                                        text = "${(task.progress * 100).toInt()}%",
                                        style = MaterialTheme.typography.labelSmall
                                    )
                                }
                                LinearProgressIndicator(
                                    progress = { task.progress },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(top = 4.dp)
                                        .clip(RoundedCornerShape(4.dp)),
                                    color = MaterialTheme.colorScheme.primary,
                                    trackColor = MaterialTheme.colorScheme.outlineVariant
                                )
                                if (task.error != null) {
                                    Text(
                                        text = "Error: ${task.error}",
                                        color = MaterialTheme.colorScheme.error,
                                        style = MaterialTheme.typography.bodySmall,
                                        modifier = Modifier.padding(top = 4.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun WorkflowsTab(
    workflows: List<Workflow>,
    onTriggerWorkflow: (String) -> Unit,
    onAddCustom: (String, String, List<String>) -> Unit
) {
    var showDialog by remember { mutableStateOf(false) }
    var workflowName by remember { mutableStateOf("") }
    var workflowDesc by remember { mutableStateOf("") }
    var step1 by remember { mutableStateOf("") }
    var step2 by remember { mutableStateOf("") }

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Predefined & Custom Workflows",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            Button(
                onClick = { showDialog = true },
                modifier = Modifier.testTag("create_workflow_button")
            ) {
                Icon(Icons.Default.Add, contentDescription = "Add")
                Spacer(modifier = Modifier.width(4.dp))
                Text("Author Workflow")
            }
        }

        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            modifier = Modifier.fillMaxWidth().weight(1f).testTag("workflows_list")
        ) {
            items(workflows) { wf ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = wf.name,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = wf.description,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.secondary
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "Constituent Steps:",
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Bold
                        )
                        wf.stepGoals.forEachIndexed { index, step ->
                            Text(
                                text = "${index + 1}. $step",
                                style = MaterialTheme.typography.bodySmall,
                                modifier = Modifier.padding(start = 8.dp, top = 2.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))
                        Button(
                            onClick = { onTriggerWorkflow(wf.id) },
                            modifier = Modifier.align(Alignment.End).testTag("trigger_wf_${wf.id}")
                        ) {
                            Icon(Icons.Default.PlayArrow, contentDescription = "Trigger")
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Launch Multi-Agent Sync")
                        }
                    }
                }
            }
        }
    }

    if (showDialog) {
        AlertDialog(
            onDismissRequest = { showDialog = false },
            title = { Text("Author Reusable Workflow") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = workflowName,
                        onValueChange = { workflowName = it },
                        label = { Text("Workflow Name") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = workflowDesc,
                        onValueChange = { workflowDesc = it },
                        label = { Text("Description") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = step1,
                        onValueChange = { step1 = it },
                        label = { Text("Step 1 Goal") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = step2,
                        onValueChange = { step2 = it },
                        label = { Text("Step 2 Goal") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (workflowName.isNotBlank() && step1.isNotBlank()) {
                            val steps = listOf(step1).toMutableList()
                            if (step2.isNotBlank()) steps.add(step2)
                            onAddCustom(workflowName, workflowDesc, steps)
                            showDialog = false
                            workflowName = ""
                            workflowDesc = ""
                            step1 = ""
                            step2 = ""
                        }
                    }
                ) {
                    Text("Save Workflow")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
fun SchedulerTab(
    schedules: List<ScheduledTask>,
    onToggle: (String) -> Unit,
    onAdd: (String, String, String) -> Unit
) {
    var showDialog by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf("") }
    var cron by remember { mutableStateOf("") }
    var workflowId by remember { mutableStateOf("morning_routine") }

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Cron & Condition Schedules",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            Button(
                onClick = { showDialog = true },
                modifier = Modifier.testTag("create_schedule_button")
            ) {
                Icon(Icons.Default.Add, contentDescription = "Add")
                Spacer(modifier = Modifier.width(4.dp))
                Text("Schedule Event")
            }
        }

        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            modifier = Modifier.fillMaxWidth().weight(1f).testTag("schedules_list")
        ) {
            items(schedules) { task ->
                Card(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier
                            .padding(16.dp)
                            .fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = task.name,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Cron: ${task.cronExpression}",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.secondary
                            )
                            Text(
                                text = "Target: ${task.workflowId}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        Switch(
                            checked = task.isEnabled,
                            onCheckedChange = { onToggle(task.id) },
                            modifier = Modifier.testTag("toggle_${task.id}")
                        )
                    }
                }
            }
        }
    }

    if (showDialog) {
        AlertDialog(
            onDismissRequest = { showDialog = false },
            title = { Text("Create Cron Schedule") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text("Task Name") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = cron,
                        onValueChange = { cron = it },
                        label = { Text("Cron Expression") },
                        placeholder = { Text("e.g. 0 9 * * *") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (name.isNotBlank() && cron.isNotBlank()) {
                            onAdd(name, cron, workflowId)
                            showDialog = false
                            name = ""
                            cron = ""
                        }
                    }
                ) {
                    Text("Add Schedule")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
fun EventsTab(events: List<AiosEvent>) {
    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text(
            text = "AIOS Internal Event Bus (Real-time Broadcast Logs)",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(12.dp))

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth().weight(1f).testTag("events_list")
        ) {
            if (events.isEmpty()) {
                item {
                    Text(
                        text = "Listening for broadcast packets... Send a Goal or Launch a Workflow to generate packets.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.secondary
                    )
                }
            } else {
                items(events) { ev ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "Topic: ${ev.topic}",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Text(
                                    text = "Priority: ${ev.priority}",
                                    style = MaterialTheme.typography.labelSmall
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Payload: ${ev.payload}",
                                style = MaterialTheme.typography.bodySmall,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AuditTrailTab(logs: List<AuditLogEntry>) {
    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text(
            text = "Security Audit Trail & Isolation Boundaries",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(12.dp))

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth().weight(1f).testTag("audit_list")
        ) {
            if (logs.isEmpty()) {
                item {
                    Text(
                        text = "No audit logs. Actions dispatched will appear here.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.secondary
                    )
                }
            } else {
                items(logs) { entry ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp).fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = if (entry.isApproved) Icons.Default.Lock else Icons.Default.Warning,
                                contentDescription = null,
                                tint = if (entry.isApproved) Color(0xFF2E7D32) else Color(0xFFC62828),
                                modifier = Modifier.size(28.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "[${entry.action}] - Agent: ${entry.agentId}",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = entry.details,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.secondary
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SdkDocTab() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "AIOS Developer SDK Specification",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
        )

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
        ) {
            Row(
                modifier = Modifier.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Build,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onPrimaryContainer,
                    modifier = Modifier.size(36.dp)
                )
                Spacer(modifier = Modifier.width(16.dp))
                Column {
                    Text(
                        text = "SDK Version active: ${AiosSdk.SDK_VERSION}",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                    Text(
                        text = "Production stable release matching JVM & Android architecture bounds.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
            }
        }

        Text(
            text = "Architecture & Lifecycle Guides",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
        )

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = AiosSdk.DOCUMENTATION.trimIndent(),
                    style = MaterialTheme.typography.bodyMedium,
                    fontFamily = FontFamily.SansSerif
                )
            }
        }
    }
}
