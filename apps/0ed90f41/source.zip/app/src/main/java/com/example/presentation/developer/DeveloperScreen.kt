package com.example.presentation.developer

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.NetworkCheck
import androidx.compose.material.icons.filled.Power
import androidx.compose.material.icons.filled.PowerOff
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.SessionState

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun DeveloperScreen(
    onNavigateBack: () -> Unit,
    viewModel: DeveloperViewModel,
    onNavigateToCapabilities: () -> Unit = {},
    onNavigateToToolsFramework: () -> Unit = {},
    onNavigateToAccessibility: () -> Unit = {}
) {
    val context = LocalContext.current
    val connectionState by viewModel.connectionState.collectAsState()
    val latencyMs by viewModel.latencyMs.collectAsState()
    val bytesSent by viewModel.bytesSent.collectAsState()
    val bytesReceived by viewModel.bytesReceived.collectAsState()
    val queueSize by viewModel.queueSize.collectAsState()
    val retryCount by viewModel.retryCount.collectAsState()
    val connectionLogs by viewModel.connectionLogs.collectAsState()
    val session by viewModel.currentSession.collectAsState()
    val isNetworkAvailable by viewModel.isNetworkAvailable.collectAsState()
    val isLocalhostReachable by viewModel.isLocalhostReachable.collectAsState()
    val isTestingConnection by viewModel.isTestingConnection.collectAsState()
    val testConnectionResult by viewModel.testConnectionResult.collectAsState()
    val lastFailureReason by viewModel.lastFailureReason.collectAsState()
    val serverUrl by viewModel.serverUrl.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.BugReport,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Termux Link Monitor",
                            fontWeight = FontWeight.Bold,
                            fontSize = 20.sp
                        )
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = onNavigateBack,
                        modifier = Modifier.testTag("dev_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Default.ArrowBack,
                            contentDescription = "Navigate Back"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
                .padding(16.dp)
        ) {
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // 1. Status Hero Header Card
                item {
                    StatusHeroCard(
                        connectionState = connectionState,
                        isNetworkAvailable = isNetworkAvailable,
                        isLocalhostReachable = isLocalhostReachable,
                        lastFailureReason = lastFailureReason
                    )
                }

                // 2. HTTP Health Verification Result Panel
                if (testConnectionResult != null) {
                    item {
                        Card(
                            colors = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.4f)
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                if (isTestingConnection) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(16.dp),
                                        strokeWidth = 2.dp,
                                        color = MaterialTheme.colorScheme.secondary
                                    )
                                } else {
                                    Icon(
                                        imageVector = Icons.Default.NetworkCheck,
                                        contentDescription = null,
                                        tint = if (testConnectionResult?.startsWith("SUCCESS") == true) Color(0xFF10B981) else Color(0xFFEF4444),
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = testConnectionResult ?: "",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.SemiBold,
                                    fontFamily = FontFamily.Monospace,
                                    color = MaterialTheme.colorScheme.onSecondaryContainer
                                )
                            }
                        }
                    }
                }

                item {
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                "Server Configuration",
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.padding(bottom = 8.dp)
                            )
                            OutlinedTextField(
                                value = serverUrl,
                                onValueChange = { viewModel.updateServerUrl(it) },
                                label = { Text("WebSocket URL (Localhost)") },
                                placeholder = { Text("ws://127.0.0.1:8000/ws") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                            Text(
                                text = "Use ws://127.0.0.1:8000/ws for Termux on this device",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(top = 4.dp, start = 4.dp)
                            )
                        }
                    }
                }

                // 3. Action Buttons Section
                item {
                    ActionButtonsSection(
                        connectionState = connectionState,
                        isTestingConnection = isTestingConnection,
                        onConnect = { viewModel.connect() },
                        onDisconnect = { viewModel.disconnect() },
                        onReconnect = { viewModel.reconnect() },
                        onTestConnection = { viewModel.testConnection() }
                    )
                }

                // 3.5 Capability Dashboard Button
                item {
                    Column {
                        Button(
                            onClick = onNavigateToCapabilities,
                            modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)
                        ) {
                            Text("View Device Capabilities Dashboard")
                        }
                        Button(
                            onClick = onNavigateToToolsFramework,
                            modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)
                        ) {
                            Text("View Tools Framework Dashboard")
                        }
                        Button(
                            onClick = onNavigateToAccessibility,
                            modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp).testTag("navigate_to_accessibility_btn")
                        ) {
                            Text("Configure Accessibility Settings")
                        }
                    }
                }

                // 4. Session Telemetry Details Card
                item {
                    SessionTelemetryCard(
                        sessionId = session.sessionId,
                        conversationId = session.conversationId,
                        deviceId = session.deviceId,
                        userId = session.userIdPlaceholder,
                        onCopy = { label, text ->
                            copyToClipboard(context, label, text)
                        }
                    )
                }

                // 5. Diagnostics Metrics Grid
                item {
                    DiagnosticsGrid(
                        latencyMs = latencyMs,
                        bytesSent = bytesSent,
                        bytesReceived = bytesReceived,
                        queueSize = queueSize,
                        retryCount = retryCount
                    )
                }

                // 6. Terminal Output Console
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Live Terminal Logs",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        IconButton(
                            onClick = { viewModel.clearLogs() },
                            modifier = Modifier.testTag("clear_logs_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.DeleteSweep,
                                contentDescription = "Clear logs",
                                tint = MaterialTheme.colorScheme.error
                            )
                        }
                    }
                }

                if (connectionLogs.isEmpty()) {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(12.dp))
                                .background(Color(0xFF0F172A))
                                .padding(24.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "Terminal is idle. Trigger actions above to view diagnostics...",
                                color = Color.Gray,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 12.sp,
                                modifier = Modifier.alpha(0.7f)
                            )
                        }
                    }
                } else {
                    items(connectionLogs) { log ->
                        LogLineItem(log = log)
                    }
                }
            }
        }
    }
}

@Composable
fun StatusHeroCard(
    connectionState: SessionState.ConnectionState,
    isNetworkAvailable: Boolean,
    isLocalhostReachable: Boolean,
    lastFailureReason: String? = null
) {
    val isConnected = connectionState == SessionState.ConnectionState.CONNECTED
    val isConnecting = connectionState == SessionState.ConnectionState.CONNECTING ||
                       connectionState == SessionState.ConnectionState.AUTHENTICATING ||
                       connectionState == SessionState.ConnectionState.RECONNECTING
    val isError = connectionState == SessionState.ConnectionState.ERROR

    val infiniteTransition = rememberInfiniteTransition(label = "Pulse animation")
    val alphaAnim by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000),
            repeatMode = RepeatMode.Reverse
        ),
        label = "Alpha pulsing"
    )

    val (statusText, statusColor, statusIcon) = when (connectionState) {
        SessionState.ConnectionState.CONNECTED -> Triple("CONNECTED", Color(0xFF10B981), Icons.Default.CloudDone)
        SessionState.ConnectionState.AUTHENTICATING -> Triple("AUTHENTICATING...", Color(0xFF3B82F6), Icons.Default.Power)
        SessionState.ConnectionState.CONNECTING -> Triple("CONNECTING...", Color(0xFFF59E0B), Icons.Default.Power)
        SessionState.ConnectionState.RECONNECTING -> Triple("RECONNECTING...", Color(0xFFF97316), Icons.Default.Refresh)
        SessionState.ConnectionState.DISCONNECTED -> Triple("DISCONNECTED", Color(0xFF64748B), Icons.Default.CloudOff)
        SessionState.ConnectionState.ERROR -> Triple("ERROR", Color(0xFFEF4444), Icons.Default.PowerOff)
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.8f)
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Termux WebSocket Session",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .clip(CircleShape)
                                .background(statusColor.copy(alpha = if (isConnecting || isError) alphaAnim else 1f))
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = statusText,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.ExtraBold,
                            color = statusColor
                        )
                    }
                }
                Icon(
                    imageVector = statusIcon,
                    contentDescription = null,
                    tint = statusColor,
                    modifier = Modifier.size(32.dp)
                )
            }

            if (isError && !lastFailureReason.isNullOrBlank()) {
                Spacer(modifier = Modifier.height(12.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFFFEF2F2))
                        .border(1.dp, Color(0xFFF87171), RoundedCornerShape(8.dp))
                        .padding(horizontal = 10.dp, vertical = 8.dp)
                ) {
                    Column {
                        Text(
                            text = "SOCKET EXCEPTION:",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF991B1B)
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = lastFailureReason,
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFFB91C1C)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                HardwareIndicatorChip(
                    label = "Internet Link",
                    isActive = isNetworkAvailable,
                    activeColor = Color(0xFF10B981),
                    modifier = Modifier.weight(1f)
                )
                HardwareIndicatorChip(
                    label = "Termux HTTP Port",
                    isActive = isLocalhostReachable,
                    activeColor = Color(0xFF10B981),
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
fun HardwareIndicatorChip(
    label: String,
    isActive: Boolean,
    activeColor: Color,
    modifier: Modifier = Modifier
) {
    val bgColor = if (isActive) activeColor.copy(alpha = 0.15f) else Color.Red.copy(alpha = 0.1f)
    val contentColor = if (isActive) activeColor else Color.Red

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(bgColor)
            .border(1.dp, contentColor.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
            .padding(vertical = 8.dp, horizontal = 12.dp)
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
            Text(
                text = label,
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium,
                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = if (isActive) "ONLINE" else "OFFLINE",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = contentColor
            )
        }
    }
}

@Composable
fun ActionButtonsSection(
    connectionState: SessionState.ConnectionState,
    isTestingConnection: Boolean,
    onConnect: () -> Unit,
    onDisconnect: () -> Unit,
    onReconnect: () -> Unit,
    onTestConnection: () -> Unit
) {
    val isConnected = connectionState == SessionState.ConnectionState.CONNECTED
    val isConnecting = connectionState == SessionState.ConnectionState.CONNECTING ||
                       connectionState == SessionState.ConnectionState.AUTHENTICATING ||
                       connectionState == SessionState.ConnectionState.RECONNECTING

    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = onConnect,
                enabled = !isConnected && !isConnecting,
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp)
                    .testTag("dev_connect_button"),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF10B981),
                    disabledContainerColor = Color(0xFF10B981).copy(alpha = 0.3f)
                )
            ) {
                Icon(Icons.Default.Power, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Connect", fontWeight = FontWeight.Bold)
            }

            OutlinedButton(
                onClick = onDisconnect,
                enabled = isConnected || isConnecting,
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp)
                    .testTag("dev_disconnect_button"),
                colors = ButtonDefaults.outlinedButtonColors(
                    contentColor = MaterialTheme.colorScheme.error
                )
            ) {
                Icon(Icons.Default.PowerOff, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Disconnect", fontWeight = FontWeight.Bold)
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = onReconnect,
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp)
                    .testTag("dev_reconnect_button"),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.secondary
                )
            ) {
                Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Reconnect", fontWeight = FontWeight.Bold)
            }

            Button(
                onClick = onTestConnection,
                enabled = !isTestingConnection,
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp)
                    .testTag("dev_test_connection_button"),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.tertiary
                )
            ) {
                if (isTestingConnection) {
                    CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp, color = Color.White)
                } else {
                    Icon(Icons.Default.NetworkCheck, contentDescription = null, modifier = Modifier.size(16.dp))
                }
                Spacer(modifier = Modifier.width(6.dp))
                Text("Test Health", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun SessionTelemetryCard(
    sessionId: String,
    conversationId: String,
    deviceId: String,
    userId: String,
    onCopy: (String, String) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
        )
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(
                text = "Session Context Metadata",
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(10.dp))

            SessionMetaRow(label = "Session ID", value = sessionId, onCopy = onCopy)
            Spacer(modifier = Modifier.height(6.dp))
            SessionMetaRow(label = "Conversation ID", value = conversationId, onCopy = onCopy)
            Spacer(modifier = Modifier.height(6.dp))
            SessionMetaRow(label = "Device ID", value = deviceId, onCopy = onCopy)
            Spacer(modifier = Modifier.height(6.dp))
            SessionMetaRow(label = "User ID Holder", value = userId, onCopy = onCopy)
        }
    }
}

@Composable
fun SessionMetaRow(
    label: String,
    value: String,
    onCopy: (String, String) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = label,
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = value,
                fontSize = 13.sp,
                fontFamily = FontFamily.Monospace,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        IconButton(
            onClick = { onCopy(label, value) },
            modifier = Modifier.size(28.dp)
        ) {
            Icon(
                imageVector = Icons.Default.ContentCopy,
                contentDescription = "Copy $label",
                modifier = Modifier.size(16.dp),
                tint = MaterialTheme.colorScheme.primary
            )
        }
    }
}

@Composable
fun DiagnosticsGrid(
    latencyMs: Long,
    bytesSent: Long,
    bytesReceived: Long,
    queueSize: Int,
    retryCount: Int
) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            MetricCard(
                label = "Latency",
                value = if (latencyMs == 0L) "-- ms" else "$latencyMs ms",
                accentColor = if (latencyMs in 1..99) Color(0xFF10B981) else if (latencyMs >= 100) Color(0xFFF59E0B) else Color.Gray,
                modifier = Modifier.weight(1f)
            )
            MetricCard(
                label = "Offline Buffer Size",
                value = "$queueSize pkts",
                accentColor = if (queueSize > 0) Color(0xFFEF4444) else Color(0xFF10B981),
                modifier = Modifier.weight(1f)
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            MetricCard(
                label = "Data Transmitted",
                value = formatBytes(bytesSent),
                accentColor = MaterialTheme.colorScheme.primary,
                modifier = Modifier.weight(1f)
            )
            MetricCard(
                label = "Data Received",
                value = formatBytes(bytesReceived),
                accentColor = MaterialTheme.colorScheme.secondary,
                modifier = Modifier.weight(1f)
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            MetricCard(
                label = "Reconnect Retries",
                value = "$retryCount attempts",
                accentColor = if (retryCount > 0) Color(0xFFF59E0B) else Color(0xFF10B981),
                modifier = Modifier.weight(1f)
            )
            MetricCard(
                label = "Communication Protocol",
                value = "JSON-WS",
                accentColor = Color(0xFF818CF8),
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
fun MetricCard(
    label: String,
    value: String,
    accentColor: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.25f)
        ),
        border = BorderStroke(0.5.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(
                text = label,
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = value,
                fontSize = 16.sp,
                fontWeight = FontWeight.ExtraBold,
                fontFamily = FontFamily.Monospace,
                color = accentColor
            )
        }
    }
}

@Composable
fun LogLineItem(log: String) {
    val color = when {
        log.contains("CRITICAL") || log.contains("ERROR") -> Color(0xFFEF4444)
        log.contains("HEARTBEAT") || log.contains("PONG") -> Color(0xFFF59E0B)
        log.contains("SENT") -> Color(0xFF38BDF8)
        log.contains("RECONNECTING") -> Color(0xFF818CF8)
        log.contains("Connected") || log.contains("ONLINE") -> Color(0xFF10B981)
        else -> MaterialTheme.colorScheme.onSurfaceVariant
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(4.dp))
            .background(Color(0xFF0F172A))
            .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
        Text(
            text = log,
            color = color,
            fontFamily = FontFamily.Monospace,
            fontSize = 10.5.sp,
            lineHeight = 14.sp
        )
    }
}

private fun formatBytes(bytes: Long): String {
    if (bytes < 1024) return "$bytes B"
    val kb = bytes / 1024.0
    if (kb < 1024) return String.format("%.2f KB", kb)
    val mb = kb / 1024.0
    return String.format("%.2f MB", mb)
}

private fun copyToClipboard(context: Context, label: String, text: String) {
    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    val clip = ClipData.newPlainText(label, text)
    clipboard.setPrimaryClip(clip)
    Toast.makeText(context, "$label copied to clipboard!", Toast.LENGTH_SHORT).show()
}

// Custom simple BorderStroke since some old compose variations might require full package resolution
private fun BorderStroke(width: androidx.compose.ui.unit.Dp, color: Color) =
    androidx.compose.foundation.BorderStroke(width, color)
