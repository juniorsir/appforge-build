package com.example.domain.usecase

import com.example.domain.model.ChatMessage
import com.example.domain.model.CompanionConfig
import com.example.domain.model.SessionState
import com.example.domain.repository.CompanionRepository
import kotlinx.coroutines.flow.Flow
import java.util.UUID

/**
 * UseCase to retrieve the reactive Companion Configuration.
 */
class GetCompanionConfigUseCase(private val repository: CompanionRepository) {
    operator fun invoke(): Flow<CompanionConfig> = repository.getCompanionConfig()
}

/**
 * UseCase to save/update Companion Configuration parameters.
 */
class SaveCompanionConfigUseCase(private val repository: CompanionRepository) {
    suspend operator fun invoke(config: CompanionConfig) = repository.saveCompanionConfig(config)
}

/**
 * UseCase to get real-time conversation history.
 */
class GetSessionHistoryUseCase(private val repository: CompanionRepository) {
    operator fun invoke(): Flow<List<ChatMessage>> = repository.getSessionHistory()
}

/**
 * UseCase to send a chat message, appending to history and sending through the connection stream.
 */
class SendMessageUseCase(private val repository: CompanionRepository) {
    suspend operator fun invoke(text: String) {
        val chatMessage = ChatMessage(
            id = UUID.randomUUID().toString(),
            sender = ChatMessage.Sender.USER,
            text = text,
            timestamp = System.currentTimeMillis()
        )
        // Add to local history
        repository.addChatMessage(chatMessage)
        // Forward message to active live stream channel
        repository.sendStreamMessage(text)
    }
}

/**
 * UseCase to retrieve live streaming connection state.
 */
class GetSessionStateUseCase(private val repository: CompanionRepository) {
    operator fun invoke(): Flow<SessionState> = repository.getSessionState()
}

/**
 * UseCase to trigger real-time AI session connection.
 */
class ToggleStreamConnectionUseCase(private val repository: CompanionRepository) {
    suspend operator fun invoke(connect: Boolean) {
        if (connect) {
            repository.connectStream()
        } else {
            repository.disconnectStream()
        }
    }
}
