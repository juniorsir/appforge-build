package com.example.domain.model

enum class LlmProviderType {
    LOCAL,
    OPENAI,
    GEMINI,
    CLAUDE,
    OLLAMA,
    VLLM
}

data class LlmMessage(
    val role: Role,
    val content: String,
    val timestamp: Long = System.currentTimeMillis()
) {
    enum class Role {
        SYSTEM,
        DEVELOPER,
        USER,
        ASSISTANT
    }
}

data class LlmConfig(
    val providerType: LlmProviderType = LlmProviderType.GEMINI,
    val apiKey: String = "",
    val baseUrl: String = "",
    val modelName: String = "gemini-1.5-flash",
    val maxTokens: Int = 1024,
    val temperature: Float = 0.7f
)

data class PromptTemplate(
    val id: String = "default",
    val systemPrompt: String = "You are Aura, an empathetic real-time AI companion. Keep your responses concise, conversational, and direct.",
    val developerPrompt: String = "Formatting rule: Do not use Markdown styling. Speak in natural plain text. Use occasional verbal fillers like 'hmm' or 'well' to sound human.",
    val userPromptTemplate: String = "{user_message}"
)

sealed class AiResponseEvent {
    data class Start(
        val sessionId: String,
        val conversationId: String,
        val messageId: String,
        val timestamp: Long = System.currentTimeMillis()
    ) : AiResponseEvent()

    data class Partial(
        val sessionId: String,
        val conversationId: String,
        val messageId: String,
        val text: String,
        val timestamp: Long = System.currentTimeMillis()
    ) : AiResponseEvent()

    data class Final(
        val sessionId: String,
        val conversationId: String,
        val messageId: String,
        val text: String,
        val timestamp: Long = System.currentTimeMillis()
    ) : AiResponseEvent()

    data class End(
        val sessionId: String,
        val conversationId: String,
        val messageId: String,
        val totalTokensPlaceholder: Int = 0,
        val responseTimeMs: Long = 0,
        val timestamp: Long = System.currentTimeMillis()
    ) : AiResponseEvent()

    data class Cancelled(
        val sessionId: String,
        val conversationId: String,
        val messageId: String,
        val timestamp: Long = System.currentTimeMillis()
    ) : AiResponseEvent()

    data class Error(
        val sessionId: String,
        val conversationId: String,
        val messageId: String,
        val error: String,
        val timestamp: Long = System.currentTimeMillis()
    ) : AiResponseEvent()
}
