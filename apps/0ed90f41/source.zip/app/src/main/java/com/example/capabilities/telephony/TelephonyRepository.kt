package com.example.capabilities.telephony

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.telephony.TelephonyManager
import com.example.capabilities.CapabilityResult
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

data class TelephonyInfo(
    val hasTelephonyHardware: Boolean,
    val simState: String,
    val networkOperatorName: String,
    val phoneType: String
)

interface TelephonyRepository {
    fun getTelephonyInfo(): CapabilityResult<TelephonyInfo>
    fun openDialer(phoneNumber: String): CapabilityResult<Boolean>
}

@Singleton
class TelephonyRepositoryImpl @Inject constructor(
    @ApplicationContext private val context: Context
) : TelephonyRepository {

    override fun getTelephonyInfo(): CapabilityResult<TelephonyInfo> {
        return try {
            val tm = context.getSystemService(Context.TELEPHONY_SERVICE) as? TelephonyManager
            val hasFeature = context.packageManager.hasSystemFeature(android.content.pm.PackageManager.FEATURE_TELEPHONY)

            if (tm == null) {
                return CapabilityResult.Success(
                    TelephonyInfo(
                        hasTelephonyHardware = hasFeature,
                        simState = "UNAVAILABLE",
                        networkOperatorName = "Unknown",
                        phoneType = "NONE"
                    )
                )
            }

            val simStateStr = when (tm.simState) {
                TelephonyManager.SIM_STATE_ABSENT -> "ABSENT"
                TelephonyManager.SIM_STATE_READY -> "READY"
                TelephonyManager.SIM_STATE_PIN_REQUIRED -> "PIN_REQUIRED"
                TelephonyManager.SIM_STATE_PUK_REQUIRED -> "PUK_REQUIRED"
                TelephonyManager.SIM_STATE_NETWORK_LOCKED -> "NETWORK_LOCKED"
                else -> "UNKNOWN"
            }

            val phoneTypeStr = when (tm.phoneType) {
                TelephonyManager.PHONE_TYPE_GSM -> "GSM"
                TelephonyManager.PHONE_TYPE_CDMA -> "CDMA"
                TelephonyManager.PHONE_TYPE_SIP -> "SIP"
                else -> "NONE"
            }

            CapabilityResult.Success(
                TelephonyInfo(
                    hasTelephonyHardware = hasFeature,
                    simState = simStateStr,
                    networkOperatorName = tm.networkOperatorName.ifEmpty { "N/A" },
                    phoneType = phoneTypeStr
                )
            )
        } catch (e: Exception) {
            CapabilityResult.Error("Failed to query telephony: ${e.message}", e)
        }
    }

    override fun openDialer(phoneNumber: String): CapabilityResult<Boolean> {
        return try {
            val intent = Intent(Intent.ACTION_DIAL).apply {
                data = Uri.parse("tel:${Uri.encode(phoneNumber)}")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            CapabilityResult.Success(true)
        } catch (e: Exception) {
            CapabilityResult.Error("Failed to open dialer: ${e.message}", e)
        }
    }
}
