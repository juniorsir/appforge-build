package com.example.tools.execution

import com.example.tools.core.Tool
import com.example.tools.repository.ConfirmationRepository
import com.example.tools.repository.ConfirmationRequest
import com.example.tools.repository.ConfirmationStatus
import kotlinx.coroutines.flow.first
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ConfirmationManager @Inject constructor(
    private val confirmationRepository: ConfirmationRepository
) {
    suspend fun requestConfirmation(executionId: String, tool: Tool, params: Map<String, Any>): Boolean {
        val request = ConfirmationRequest(
            executionId = executionId,
            toolId = tool.id,
            params = params,
            riskLevel = tool.riskLevel,
            status = ConfirmationStatus.PENDING
        )
        confirmationRepository.addRequest(request)
        
        // Wait for user confirmation logic would go here.
        // For a real app, this might suspend until UI updates it.
        // For now, we will just return false as it requires manual approval.
        return false
    }

    suspend fun approve(executionId: String) {
        confirmationRepository.updateStatus(executionId, ConfirmationStatus.APPROVED)
    }

    suspend fun reject(executionId: String) {
        confirmationRepository.updateStatus(executionId, ConfirmationStatus.REJECTED)
    }
}
