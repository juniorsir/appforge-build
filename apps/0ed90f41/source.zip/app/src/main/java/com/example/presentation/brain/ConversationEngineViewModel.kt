package com.example.presentation.brain

import android.content.Context
import android.content.Intent
import android.util.Log
import android.widget.Toast
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.BaseApplication
import com.example.domain.model.*
import com.example.domain.repository.*
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.UUID

class ConversationEngineViewModel(
    private val conversationRepository: ConversationRepository,
    private val promptRepository: PromptRepository,
    private val llmProvider: LlmProvider,
    private val aiResponseRepository: AiResponseRepository,
    private val sessionRepository: SessionRepository
) : ViewModel() {

    // Active Conversation Metadata
    val activeConversation: StateFlow<BrainConversation?> = conversationRepository.activeConversation

    // Chat History in the active conversation
    val messages: StateFlow<List<BrainMessage>> = activeConversation
        .flatMapLatest { conv ->
            if (conv != null) {
                conversationRepository.getMessagesFlow(conv.id)
            } else {
                flowOf(emptyList())
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // UI Configuration & Prompt State
    val llmConfig = MutableStateFlow(LlmConfig())
    val promptTemplate = promptRepository.getPromptTemplate()
        .stateIn(viewModelScope, SharingStarted.Eagerly, PromptTemplate())

    // Generation State Telemetry
    private val _streamingResponse = MutableStateFlow("")
    val streamingResponse: StateFlow<String> = _streamingResponse.asStateFlow()

    private val _generationState = MutableStateFlow(GenerationState.IDLE)
    val generationState: StateFlow<GenerationState> = _generationState.asStateFlow()

    val tokenCountPlaceholder = aiResponseRepository.lastTokenCount
    val lastResponseLatencyMs = aiResponseRepository.lastResponseLatencyMs
    val errorState = aiResponseRepository.lastError

    val sessionId: StateFlow<String> = sessionRepository.currentSession
        .map { it.sessionId }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "")

    private var activeGenerationJob: Job? = null
    private var lastUserMessageText: String = ""

    fun updateConfig(config: LlmConfig) {
        llmConfig.value = config
    }

    fun updatePromptTemplate(systemPrompt: String, developerPrompt: String) {
        viewModelScope.launch {
            val current = promptTemplate.value
            promptRepository.savePromptTemplate(
                current.copy(
                    systemPrompt = systemPrompt,
                    developerPrompt = developerPrompt
                )
            )
        }
    }

    /**
     * Executes the conversational logic chain:
     * Saves user input -> Builds multi-tier prompts -> Invokes LLM Stream -> Renders responses in real-time.
     */
    fun startGeneration(userInput: String) {
        println("startGeneration called with: $userInput")
        if (userInput.isBlank()) {
            println("Returning because userInput is blank")
            return
        }
        if (_generationState.value == GenerationState.GENERATING) {
            println("Returning because already GENERATING")
            return
        }

        val conversation = activeConversation.value
        if (conversation == null) {
            println("Returning because activeConversation is null")
            return
        }
        val currentSessionId = sessionId.value
        println("Starting generation for conversation: ${conversation.id}, session: $currentSessionId")
        lastUserMessageText = userInput

        activeGenerationJob = viewModelScope.launch {
            println("Inside viewModelScope.launch")
            _generationState.value = GenerationState.GENERATING
            _streamingResponse.value = ""

            val userMessageId = UUID.randomUUID().toString()
            val assistantMessageId = UUID.randomUUID().toString()

            // 1. Persist User Message
            println("Persisting user message")
            val userMsg = BrainMessage(
                id = userMessageId,
                conversationId = conversation.id,
                role = LlmMessage.Role.USER,
                content = userInput,
                timestamp = System.currentTimeMillis()
            )
            conversationRepository.addMessage(userMsg)

            // 2. Load and build context (recent conversation + system prompts)
            val currentPrompts = promptTemplate.value
            val history = conversationRepository.getMessages(conversation.id)
            
            // Map domain BrainMessages to LLM-understandable format
            val llmMessages = history.map {
                LlmMessage(role = it.role, content = it.content, timestamp = it.timestamp)
            }

            // Dynamically construct final user prompt using the template
            val builtUserPrompt = promptRepository.buildUserPrompt(
                currentPrompts.userPromptTemplate,
                mapOf("user_message" to userInput)
            )

            // 3. Initiate LLM stream
            llmProvider.streamResponse(
                config = llmConfig.value,
                systemPrompt = currentPrompts.systemPrompt,
                developerPrompt = currentPrompts.developerPrompt,
                messages = llmMessages,
                userMessage = builtUserPrompt,
                sessionId = currentSessionId,
                conversationId = conversation.id,
                messageId = assistantMessageId
            ).collect { event ->
                // Log and process event
                aiResponseRepository.logEvent(event)

                when (event) {
                    is AiResponseEvent.Start -> {
                        _generationState.value = GenerationState.GENERATING
                    }
                    is AiResponseEvent.Partial -> {
                        _streamingResponse.value += event.text
                    }
                    is AiResponseEvent.Final -> {
                        _streamingResponse.value = event.text
                    }
                    is AiResponseEvent.End -> {
                        println("Received AiResponseEvent.End")
                        // Stream completed successfully. Persist the complete response
                        val assistantMsg = BrainMessage(
                            id = assistantMessageId,
                            conversationId = conversation.id,
                            role = LlmMessage.Role.ASSISTANT,
                            content = _streamingResponse.value,
                            timestamp = event.timestamp,
                            tokenCountPlaceholder = event.totalTokensPlaceholder,
                            responseTimeMs = event.responseTimeMs
                        )
                        conversationRepository.addMessage(assistantMsg)
                        _generationState.value = GenerationState.SUCCESS
                        println("GenerationState set to SUCCESS")
                    }
                    is AiResponseEvent.Cancelled -> {
                        println("Received AiResponseEvent.Cancelled")
                        _generationState.value = GenerationState.CANCELLED
                    }
                    is AiResponseEvent.Error -> {
                        println("Received AiResponseEvent.Error: ${event.error}")
                        _generationState.value = GenerationState.ERROR
                    }
                }
            }
        }
    }

    fun stopGeneration() {
        activeGenerationJob?.cancel()
        viewModelScope.launch {
            val conv = activeConversation.value
            if (conv != null) {
                aiResponseRepository.logEvent(
                    AiResponseEvent.Cancelled(
                        sessionId = sessionId.value,
                        conversationId = conv.id,
                        messageId = UUID.randomUUID().toString()
                    )
                )
            }
            _generationState.value = GenerationState.CANCELLED
        }
    }

    fun retry() {
        if (lastUserMessageText.isNotBlank()) {
            startGeneration(lastUserMessageText)
        }
    }

    fun clearConversation() {
        val conv = activeConversation.value ?: return
        viewModelScope.launch {
            conversationRepository.resetConversation(conv.id)
            _streamingResponse.value = ""
            _generationState.value = GenerationState.IDLE
        }
    }

    fun createNewConversation(title: String) {
        viewModelScope.launch {
            conversationRepository.createNewConversation(title)
            _streamingResponse.value = ""
            _generationState.value = GenerationState.IDLE
        }
    }

    fun exportConversation(context: Context) {
        val history = messages.value
        if (history.isEmpty()) {
            Toast.makeText(context, "No messages to export", Toast.LENGTH_SHORT).show()
            return
        }
        val formattedText = buildString {
            append("Conversation Export\n")
            append("Conversation ID: ${activeConversation.value?.id ?: "N/A"}\n")
            append("=====================================\n\n")
            history.forEach { msg ->
                val timeStr = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault())
                    .format(java.util.Date(msg.timestamp))
                append("[$timeStr] ${msg.role.name}: ${msg.content}\n\n")
            }
        }

        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "Aura AI Chat Export")
            putExtra(Intent.EXTRA_TEXT, formattedText)
        }
        val chooser = Intent.createChooser(shareIntent, "Export Chat History")
        chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(chooser)
    }

    companion object {
        val Factory: ViewModelProvider.Factory = viewModelFactory {
            initializer {
                val app = this[ViewModelProvider.AndroidViewModelFactory.APPLICATION_KEY] as BaseApplication
                val container = app.container
                ConversationEngineViewModel(
                    conversationRepository = container.brainConversationRepository,
                    promptRepository = container.promptRepository,
                    llmProvider = container.llmProvider,
                    aiResponseRepository = container.aiResponseRepository,
                    sessionRepository = container.sessionRepository
                )
            }
        }
    }
}
