package com.example.capabilities.core

data class CapabilityDefinition(
    val id: String,
    val name: String,
    val description: String,
    val category: CapabilityCategory,
    val requiredPermissions: List<String> = emptyList(),
    val minSdkVersion: Int = 26,
    val hardwareFeature: String? = null,
    val confirmationLevel: ConfirmationLevel = ConfirmationLevel.NONE,
    val availability: CapabilityAvailability = CapabilityAvailability.AVAILABLE,
    val currentState: CapabilityState = CapabilityState.IDLE,
    val lastExecutionTimeMs: Long = 0L,
    val lastError: String? = null,
    val implementationStatus: String = "Implemented"
)

data class CapabilityRequest(
    val requestId: String = java.util.UUID.randomUUID().toString(),
    val capabilityId: String,
    val action: String = "execute",
    val parameters: Map<String, Any?> = emptyMap(),
    val timestamp: Long = System.currentTimeMillis(),
    val requiresConfirmation: Boolean = false
)

data class CapabilityResponse(
    val requestId: String,
    val capabilityId: String,
    val success: Boolean,
    val data: Any? = null,
    val errorCode: CapabilityErrorCode? = null,
    val errorMessage: String? = null,
    val timestamp: Long = System.currentTimeMillis(),
    val durationMs: Long = 0L
)

interface Capability {
    val definition: CapabilityDefinition
    fun checkAvailability(): CapabilityAvailability
    suspend fun execute(request: CapabilityRequest): CapabilityResponse
}
