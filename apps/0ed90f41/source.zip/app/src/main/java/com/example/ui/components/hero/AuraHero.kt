package com.example.ui.components.hero

import android.graphics.BlurMaskFilter
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Paint
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.glass.AuraGlassSurface
import com.example.ui.components.header.AuraEngineState
import com.example.ui.theme.AuraBorders
import com.example.ui.theme.AuraColors
import com.example.ui.theme.AuraDimensions
import com.example.ui.theme.AuraGlassLevel
import com.example.ui.theme.AuraMotion
import com.example.ui.theme.AuraShapes
import com.example.ui.theme.AuraSpacing
import com.example.ui.theme.AuraTypography
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * Deterministic particle configuration for atmospheric movement.
 */
private data class AuraParticle(
    val relX: Float,
    val relY: Float,
    val radiusDp: Float,
    val alpha: Float,
    val ampX: Float,
    val ampY: Float,
    val speedX: Float,
    val speedY: Float,
    val phaseX: Float,
    val phaseY: Float
)

// 8 deterministic ambient particles
private val STATIC_PARTICLES = listOf(
    AuraParticle(0.18f, 0.40f, 2.0f, 0.16f, 14f, 8f, 0.7f, 0.5f, 0.0f, 1.2f),
    AuraParticle(0.32f, 0.65f, 2.5f, 0.22f, 18f, 12f, -0.6f, 0.8f, 1.8f, 0.4f),
    AuraParticle(0.48f, 0.35f, 1.5f, 0.12f, 10f, 6f, 0.9f, -0.7f, 3.1f, 2.2f),
    AuraParticle(0.62f, 0.58f, 3.0f, 0.25f, 20f, 10f, -0.5f, 0.6f, 0.8f, 1.9f),
    AuraParticle(0.78f, 0.42f, 2.0f, 0.18f, 12f, 14f, 0.8f, -0.4f, 2.4f, 0.9f),
    AuraParticle(0.24f, 0.28f, 1.5f, 0.10f, 8f, 6f, -0.7f, 0.9f, 4.0f, 3.1f),
    AuraParticle(0.85f, 0.68f, 2.5f, 0.15f, 16f, 10f, 0.6f, -0.8f, 1.2f, 4.5f),
    AuraParticle(0.52f, 0.72f, 2.0f, 0.14f, 12f, 8f, -0.8f, 0.5f, 5.2f, 1.1f)
)

/**
 * AURA ASSISTANT — Phase 3: Liquid Hero + Real-time Engine Visualizer
 *
 * Implements a liquid energy wave system floating in smoked glass, reacting to real engine state
 * and live microphone amplitude.
 */
@Composable
fun AuraHero(
    engineState: AuraEngineState,
    modifier: Modifier = Modifier,
    rms: Double = 0.0,
    reducedMotion: Boolean = false
) {
    BoxWithConstraints(
        modifier = modifier
            .fillMaxWidth()
            .semantics(mergeDescendants = true) {
                contentDescription = when (engineState) {
                    AuraEngineState.STANDBY -> "AURA Engine is in standby"
                    AuraEngineState.CONNECTING -> "AURA Engine is connecting"
                    AuraEngineState.LISTENING -> "AURA Engine is listening"
                    AuraEngineState.PROCESSING -> "AURA Engine is processing"
                    AuraEngineState.SPEAKING -> "AURA Engine is speaking"
                    AuraEngineState.PAUSED -> "AURA Engine is paused"
                    AuraEngineState.ERROR -> "AURA Engine error detected"
                }
            }
    ) {
        val availableWidth = maxWidth
        val isNarrow = availableWidth < 360.dp

        // Responsive height calculation: clamp(180dp, 0.27 * available, 240dp)
        val computedHeight: Dp = when {
            isNarrow -> 180.dp
            availableWidth >= 600.dp -> 240.dp
            else -> 210.dp
        }

        AuraGlassSurface(
            modifier = Modifier
                .fillMaxWidth()
                .height(computedHeight),
            shape = AuraShapes.Hero,
            level = when (engineState) {
                AuraEngineState.LISTENING, AuraEngineState.SPEAKING -> AuraGlassLevel.LEVEL_3
                AuraEngineState.PROCESSING -> AuraGlassLevel.LEVEL_2
                else -> AuraGlassLevel.LEVEL_2
            },
            borderWidth = if (engineState == AuraEngineState.LISTENING || engineState == AuraEngineState.SPEAKING) {
                AuraBorders.WidthActive
            } else {
                AuraBorders.WidthNormal
            },
            showHighlight = true
        ) {
            Box(modifier = Modifier.fillMaxSize()) {
                // 1. Subtle background liquid radial glow (White <= 4%)
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.radialGradient(
                                colors = listOf(
                                    AuraColors.White.copy(
                                        alpha = when (engineState) {
                                            AuraEngineState.SPEAKING -> 0.045f
                                            AuraEngineState.LISTENING -> 0.035f
                                            AuraEngineState.PROCESSING -> 0.030f
                                            AuraEngineState.CONNECTING -> 0.025f
                                            else -> 0.015f
                                        }
                                    ),
                                    Color.Transparent
                                ),
                                radius = 450f
                            )
                        )
                )

                // 2. Liquid Waveform + Particle Canvas
                AuraLiquidVisualizer(
                    engineState = engineState,
                    rms = rms,
                    reducedMotion = reducedMotion,
                    isNarrow = isNarrow,
                    modifier = Modifier.fillMaxSize()
                )

                // 3. Hero Status Pill positioned in the bottom-center
                AuraHeroStatus(
                    engineState = engineState,
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(bottom = if (isNarrow) 12.dp else 16.dp)
                )
            }
        }
    }
}

/**
 * Renders the multi-layered interference waves and deterministic particle field.
 */
@Composable
fun AuraLiquidVisualizer(
    engineState: AuraEngineState,
    modifier: Modifier = Modifier,
    rms: Double = 0.0,
    reducedMotion: Boolean = false,
    isNarrow: Boolean = false
) {
    val density = LocalDensity.current

    // State-based target amplitude multiplier
    val targetStateMultiplier = when (engineState) {
        AuraEngineState.STANDBY -> 0.45f
        AuraEngineState.CONNECTING -> 0.55f
        AuraEngineState.LISTENING -> 0.85f
        AuraEngineState.PROCESSING -> 0.70f
        AuraEngineState.SPEAKING -> 1.00f
        AuraEngineState.PAUSED -> 0.25f
        AuraEngineState.ERROR -> 0.15f
    }

    // Smooth state amplitude interpolation
    val animatedStateMultiplier = remember { Animatable(targetStateMultiplier) }
    LaunchedEffect(targetStateMultiplier) {
        animatedStateMultiplier.animateTo(
            targetValue = targetStateMultiplier,
            animationSpec = if (reducedMotion) AuraMotion.microTween() else AuraMotion.stateTransitionTween()
        )
    }

    // Microphone audio level normalization & smoothing
    // L = clamp((dB + 60) / 60, 0, 1). Using rms value safely clamped:
    val normalizedMic = remember(rms) {
        if (rms > 0.0) {
            val db = 20.0 * kotlin.math.log10((rms / 32767.0).coerceAtLeast(1e-4))
            ((db + 60.0) / 60.0).coerceIn(0.0, 1.0).toFloat()
        } else 0f
    }

    val animatedMicLevel = remember { Animatable(0f) }
    LaunchedEffect(normalizedMic) {
        animatedMicLevel.animateTo(
            targetValue = normalizedMic,
            animationSpec = if (reducedMotion) AuraMotion.microTween() else AuraMotion.stateTransitionTween() //durationMillis = 80, easing = LinearEasing)
        )
    }

    // Continuous time animation (infinite transition)
    val infiniteTransition = rememberInfiniteTransition(label = "LiquidTimeTransition")
    val time by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = (2 * PI).toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = if (reducedMotion) 12000 else 6000,
                easing = LinearEasing
            ),
            repeatMode = RepeatMode.Restart
        ),
        label = "LiquidTime"
    )

    // Reusable Path objects to prevent allocations per frame
    val wavePath1 = remember { Path() }
    val wavePath2 = remember { Path() }
    val wavePath3 = remember { Path() }
    val fillPath1 = remember { Path() }

    Canvas(modifier = modifier) {
        val width = size.width
        val height = size.height
        if (width <= 0f || height <= 0f) return@Canvas

        val midY = height / 2f - 10f // slight optical adjustment above status pill
        val stateAmp = animatedStateMultiplier.value
        val micLevel = animatedMicLevel.value

        // Combine state multiplier and microphone reactivity: amplitude = base * state * (0.7 + 0.3 * L)
        val micGain = if (engineState == AuraEngineState.LISTENING || engineState == AuraEngineState.SPEAKING) {
            0.70f + 0.30f * micLevel
        } else {
            1.0f
        }

        val effectiveAmp = stateAmp * micGain * (if (isNarrow) 0.82f else 1.0f)
        val speedMultiplier = when (engineState) {
            AuraEngineState.SPEAKING -> 1.35f
            AuraEngineState.PROCESSING -> 1.20f
            AuraEngineState.LISTENING -> 1.00f
            AuraEngineState.CONNECTING -> 0.85f
            AuraEngineState.PAUSED -> 0.20f
            AuraEngineState.ERROR -> 0.10f
            else -> 0.65f
        }

        val t = time * (if (reducedMotion) 0.3f else speedMultiplier)

        // 1. Draw deterministic particles (atmosphere)
        if (!reducedMotion) {
            val particleActivity = when (engineState) {
                AuraEngineState.SPEAKING -> 1.0f
                AuraEngineState.LISTENING -> 0.8f
                AuraEngineState.PROCESSING -> 0.6f
                AuraEngineState.CONNECTING -> 0.4f
                AuraEngineState.STANDBY -> 0.3f
                AuraEngineState.PAUSED -> 0.1f
                AuraEngineState.ERROR -> 0.05f
            }

            val maxParticles = if (isNarrow) 5 else STATIC_PARTICLES.size
            for (i in 0 until maxParticles) {
                val p = STATIC_PARTICLES[i]
                val driftX = p.ampX * particleActivity * sin(p.speedX * t + p.phaseX)
                val driftY = p.ampY * particleActivity * cos(p.speedY * t + p.phaseY)
                val px = (p.relX * width) + driftX
                val py = (p.relY * height) + driftY

                drawCircle(
                    color = AuraColors.White.copy(alpha = p.alpha * particleActivity),
                    radius = p.radiusDp * density.density,
                    center = Offset(px, py)
                )
            }
        }

        // 2. Sample Points for Liquid Waves (120 points for smooth performance)
        val sampleCount = if (isNarrow) 90 else 130
        val stepX = width / sampleCount

        wavePath1.reset()
        wavePath2.reset()
        wavePath3.reset()
        fillPath1.reset()

        fillPath1.moveTo(0f, height)

        val baseH = height
        val a1 = 0.055f * baseH * effectiveAmp
        val a2 = 0.020f * baseH * effectiveAmp
        val a3 = 0.010f * baseH * effectiveAmp

        for (i in 0..sampleCount) {
            val x = i * stepX
            val normX = (x / width).coerceIn(0f, 1f)

            // Natural edge envelope tapering to prevent clipping through rounded corners
            val envelope = sin(normX * PI.toFloat()).coerceAtLeast(0f)

            // Wave 1: Primary liquid wave (f1 = 1.15, w1 = 0.75)
            val y1 = midY + envelope * (
                    a1 * sin(2f * PI.toFloat() * 1.15f * normX + 0.75f * t) +
                            a2 * sin(2f * PI.toFloat() * 3.10f * normX - 0.42f * t)
                    )

            // Wave 2: Interference secondary wave (f2 = 2.4, w2 = -0.55)
            val y2 = midY + envelope * (
                    (a1 * 0.70f) * sin(2f * PI.toFloat() * 1.85f * normX - 0.55f * t + 1.2f) +
                            (a2 * 0.85f) * sin(2f * PI.toFloat() * 3.80f * normX + 0.35f * t)
                    )

            // Wave 3: Subtle harmonic ripple (f3 = 4.6, w3 = 0.40)
            val y3 = midY + envelope * (
                    (a1 * 0.45f) * sin(2f * PI.toFloat() * 2.60f * normX + 0.40f * t + 2.5f) +
                            a3 * sin(2f * PI.toFloat() * 5.20f * normX - 0.25f * t)
                    )

            if (i == 0) {
                wavePath1.moveTo(x, y1)
                wavePath2.moveTo(x, y2)
                wavePath3.moveTo(x, y3)
                fillPath1.lineTo(x, y1)
            } else {
                wavePath1.lineTo(x, y1)
                wavePath2.lineTo(x, y2)
                wavePath3.lineTo(x, y3)
                fillPath1.lineTo(x, y1)
            }
        }

        fillPath1.lineTo(width, height)
        fillPath1.close()

        // 3. Render Subtle Liquid Fill (3–6% White)
        drawPath(
            path = fillPath1,
            brush = Brush.verticalGradient(
                colors = listOf(
                    AuraColors.White.copy(alpha = 0.05f * effectiveAmp.coerceIn(0.35f, 1f)),
                    Color.Transparent
                ),
                startY = midY - 20f,
                endY = height
            )
        )

        // 4. Layer 3: Subtle harmonic liquid wave (Opacity 10-18%)
        drawPath(
            path = wavePath3,
            color = AuraColors.White.copy(alpha = 0.14f * effectiveAmp.coerceIn(0.4f, 1f)),
            style = Stroke(width = 1.2.dp.toPx())
        )

        // 5. Layer 2: Interference liquid wave (Opacity 24-36%)
        drawPath(
            path = wavePath2,
            color = AuraColors.White.copy(alpha = 0.28f * effectiveAmp.coerceIn(0.4f, 1f)),
            style = Stroke(width = 1.8.dp.toPx())
        )

        // 6. Layer 1: Primary sharp wave + subtle low-alpha glow halo (Opacity 45-65%)
        // Subtle glow halo
        drawPath(
            path = wavePath1,
            color = AuraColors.White.copy(alpha = 0.16f * effectiveAmp.coerceIn(0.4f, 1f)),
            style = Stroke(width = 4.5.dp.toPx())
        )

        // Sharp primary wave
        drawPath(
            path = wavePath1,
            color = AuraColors.White.copy(alpha = 0.55f * effectiveAmp.coerceIn(0.4f, 1f)),
            style = Stroke(width = 2.0.dp.toPx())
        )
    }
}

/**
 * Compact glass status pill integrated directly into the Hero bottom center.
 */
@Composable
fun AuraHeroStatus(
    engineState: AuraEngineState,
    modifier: Modifier = Modifier
) {
    AuraGlassSurface(
        modifier = modifier
            .height(34.dp)
            .semantics(mergeDescendants = true) {
                contentDescription = "Engine state: ${engineState.label}"
            },
        shape = AuraShapes.Pill,
        level = AuraGlassLevel.LEVEL_1,
        borderWidth = AuraBorders.WidthNormal
    ) {
        Row(
            modifier = Modifier
                .align(Alignment.Center)
                .padding(horizontal = 14.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Animated Status Dot
            val infiniteTransition = rememberInfiniteTransition(label = "HeroStatusDot")
            val alpha by infiniteTransition.animateFloat(
                initialValue = if (engineState.isPulsing) 0.4f else 1.0f,
                targetValue = 1.0f,
                animationSpec = infiniteRepeatable(
                    animation = tween(engineState.pulseDurationMs, easing = LinearEasing),
                    repeatMode = RepeatMode.Reverse
                ),
                label = "HeroStatusDotAlpha"
            )

            Box(
                modifier = Modifier
                    .size(7.dp)
                    .clip(CircleShape)
                    .background(
                        engineState.dotColor.copy(
                            alpha = if (engineState.isPulsing) alpha else engineState.dotColor.alpha
                        )
                    )
            )

            AnimatedContent(
                targetState = engineState,
                transitionSpec = {
                    fadeIn(animationSpec = tween(AuraMotion.DurationStandard)) togetherWith
                            fadeOut(animationSpec = tween(AuraMotion.DurationStandard))
                },
                label = "HeroStatusText"
            ) { targetState ->
                Text(
                    text = targetState.label,
                    style = AuraTypography.TechnicalLabel.copy(
                        fontSize = 11.sp,
                        letterSpacing = 1.0.sp
                    ),
                    color = targetState.textColor
                )
            }
        }
    }
}
