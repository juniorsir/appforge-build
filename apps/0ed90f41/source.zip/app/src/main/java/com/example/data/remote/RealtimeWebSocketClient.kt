package com.example.data.remote

import com.example.domain.model.SessionState
import com.example.util.AppLogger
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.UUID

/**
 * Interface defining the Real-time AI Assistant stream channel.
 * Designed to encapsulate both Audio streams and Chat transcript streams.
 */
interface RealtimeWebSocketClient {
    val connectionState: StateFlow<SessionState.ConnectionState>
    val incomingMessages: SharedFlow<String>
    
    suspend fun connect(url: String)
    suspend fun disconnect()
    suspend fun send(message: String)
}

/**
 * Robust stub implementation of [RealtimeWebSocketClient] for phase 1 architecture.
 * Implements mock delayed connection loops, periodic assistant auto-response ticks,
 * and standard event emission for testing layout state transformations.
 */
class RealtimeWebSocketClientStub(
    private val logger: AppLogger,
    private val scope: CoroutineScope
) : RealtimeWebSocketClient {

    private val _connectionState = MutableStateFlow(SessionState.ConnectionState.DISCONNECTED)
    override val connectionState: StateFlow<SessionState.ConnectionState> = _connectionState.asStateFlow()

    private val _incomingMessages = MutableSharedFlow<String>()
    override val incomingMessages: SharedFlow<String> = _incomingMessages.asSharedFlow()

    private val tag = "RealtimeWSStub"

    override suspend fun connect(url: String) {
        if (_connectionState.value == SessionState.ConnectionState.CONNECTED ||
            _connectionState.value == SessionState.ConnectionState.CONNECTING) {
            return
        }

        logger.i(tag, "Connecting to AI Assistant real-time stream endpoint: $url")
        _connectionState.value = SessionState.ConnectionState.CONNECTING
        
        // Simulate WebSocket handshake delay
        scope.launch(Dispatchers.Default) {
            delay(1500)
            _connectionState.value = SessionState.ConnectionState.CONNECTED
            logger.i(tag, "WebSocket session established successfully.")
            
            // Emit a mock greeting message from the real-time AI assistant
            delay(1000)
            _incomingMessages.emit("Hello! I am connected and streaming audio in real-time. How can I assist you today?")
        }
    }

    override suspend fun disconnect() {
        if (_connectionState.value == SessionState.ConnectionState.DISCONNECTED) {
            return
        }
        logger.i(tag, "Disconnecting from active streaming session...")
        _connectionState.value = SessionState.ConnectionState.DISCONNECTED
    }

    override suspend fun send(message: String) {
        if (_connectionState.value != SessionState.ConnectionState.CONNECTED) {
            logger.w(tag, "Attempted to send a message but streaming channel is disconnected!")
            return
        }
        logger.i(tag, "Sending text stream packet: $message")
        
        // Mock automatic assistant replies for a real-time responsive feel
        scope.launch(Dispatchers.Default) {
            delay(1200)
            val responses = listOf(
                "Got your stream packet! I'm processing that right now.",
                "Yes, that makes total sense. Tell me more about it.",
                "Based on what you just said, I would recommend setting up a task worker.",
                "Fascinating! Let's continue investigating this AI companion foundation."
            )
            val randomResponse = responses.random()
            _incomingMessages.emit(randomResponse)
        }
    }
}
