package com.example.capabilities.bluetooth

import android.content.Context
import com.example.capabilities.CapabilityResult
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject

data class BluetoothStatus(
    val isEnabled: Boolean,
    val hasPermission: Boolean
)

interface BluetoothRepository {
    fun getBluetoothStatus(): CapabilityResult<BluetoothStatus>
}

class BluetoothRepositoryImpl @Inject constructor(
    @ApplicationContext private val context: Context
) : BluetoothRepository {
    override fun getBluetoothStatus(): CapabilityResult<BluetoothStatus> {
        // Implementation stub for Bluetooth
        return CapabilityResult.Success(BluetoothStatus(isEnabled = false, hasPermission = false))
    }
}
