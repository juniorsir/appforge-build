package com.example.capabilities.core

import kotlinx.coroutines.flow.StateFlow

interface CapabilityRegistry {
    val capabilities: StateFlow<List<CapabilityDefinition>>
    fun getCapability(id: String): CapabilityDefinition?
    fun getCapabilitiesByCategory(category: CapabilityCategory): List<CapabilityDefinition>
    fun refreshAvailability()
    fun registerCapability(definition: CapabilityDefinition)
    fun updateCapabilityState(id: String, state: CapabilityState, lastError: String? = null)
    suspend fun executeCapability(request: CapabilityRequest): CapabilityResponse
}
