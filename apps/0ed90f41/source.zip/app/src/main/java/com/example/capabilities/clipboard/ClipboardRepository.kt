package com.example.capabilities.clipboard

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Handler
import android.os.Looper
import com.example.capabilities.CapabilityResult
import dagger.hilt.android.qualifiers.ApplicationContext
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import javax.inject.Inject

interface ClipboardRepository {
    fun readClipboard(): CapabilityResult<String>
    fun writeClipboard(text: String): CapabilityResult<Unit>
}

class ClipboardRepositoryImpl @Inject constructor(
    @ApplicationContext private val context: Context
) : ClipboardRepository {
    private val clipboardManager by lazy {
        context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    }
    private val mainHandler = Handler(Looper.getMainLooper())
    private val prefs = context.getSharedPreferences("aura_clipboard_cache", Context.MODE_PRIVATE)

    @Volatile
    private var inMemoryCachedText: String = prefs.getString("last_clipboard_text", "") ?: ""

    init {
        mainHandler.post {
            try {
                clipboardManager.addPrimaryClipChangedListener {
                    try {
                        val clip = clipboardManager.primaryClip
                        if (clip != null && clip.itemCount > 0) {
                            val item = clip.getItemAt(0)
                            val txt = item?.text?.toString() ?: ""
                            if (txt.isNotBlank()) {
                                inMemoryCachedText = txt
                                prefs.edit().putString("last_clipboard_text", txt).apply()
                            }
                        }
                    } catch (ignored: Exception) {}
                }
            } catch (ignored: Exception) {}
        }
    }

    override fun readClipboard(): CapabilityResult<String> {
        var systemClipText: String? = null
        val latch = CountDownLatch(1)

        mainHandler.post {
            try {
                if (clipboardManager.hasPrimaryClip()) {
                    val clip = clipboardManager.primaryClip
                    if (clip != null && clip.itemCount > 0) {
                        systemClipText = clip.getItemAt(0)?.text?.toString()
                    }
                }
            } catch (e: Exception) {
                // Background access restriction on Android 10+ (API 29+)
            } finally {
                latch.countDown()
            }
        }

        try {
            latch.await(300, TimeUnit.MILLISECONDS)
        } catch (ignored: Exception) {}

        val resultText = if (!systemClipText.isNullOrBlank()) {
            inMemoryCachedText = systemClipText!!
            prefs.edit().putString("last_clipboard_text", systemClipText).apply()
            systemClipText!!
        } else {
            inMemoryCachedText
        }

        return CapabilityResult.Success(resultText)
    }

    override fun writeClipboard(text: String): CapabilityResult<Unit> {
        inMemoryCachedText = text
        prefs.edit().putString("last_clipboard_text", text).apply()

        mainHandler.post {
            try {
                val clip = ClipData.newPlainText("Copied Text", text)
                clipboardManager.setPrimaryClip(clip)
            } catch (ignored: Exception) {}
        }

        return CapabilityResult.Success(Unit)
    }
}
