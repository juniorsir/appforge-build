package com.example.capabilities.core

import android.content.Context
import android.os.Build
import android.util.Log
import com.example.capabilities.permissions.PermissionManager
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class CapabilityGateway @Inject constructor(
    @ApplicationContext private val context: Context,
    private val permissionManager: PermissionManager
) {
    private val TAG = "CapabilityGateway"

    suspend fun execute(
        definition: CapabilityDefinition,
        request: CapabilityRequest,
        executor: suspend (CapabilityRequest) -> Any?
    ): CapabilityResponse {
        val startTime = System.currentTimeMillis()

        // 1. Min SDK check
        if (Build.VERSION.SDK_INT < definition.minSdkVersion) {
            return CapabilityResponse(
                requestId = request.requestId,
                capabilityId = definition.id,
                success = false,
                errorCode = CapabilityErrorCode.ANDROID_VERSION_UNSUPPORTED,
                errorMessage = "Requires Android SDK ${definition.minSdkVersion}, current is ${Build.VERSION.SDK_INT}",
                durationMs = System.currentTimeMillis() - startTime
            )
        }

        // 2. Hardware feature check
        if (definition.hardwareFeature != null) {
            if (!permissionManager.hasHardwareFeature(definition.hardwareFeature)) {
                return CapabilityResponse(
                    requestId = request.requestId,
                    capabilityId = definition.id,
                    success = false,
                    errorCode = CapabilityErrorCode.HARDWARE_UNAVAILABLE,
                    errorMessage = "Hardware feature '${definition.hardwareFeature}' is not available on this device",
                    durationMs = System.currentTimeMillis() - startTime
                )
            }
        }

        // 3. Permission checks
        if (definition.requiredPermissions.isNotEmpty()) {
            val missing = permissionManager.getMissingPermissions(definition.requiredPermissions)
            if (missing.isNotEmpty()) {
                return CapabilityResponse(
                    requestId = request.requestId,
                    capabilityId = definition.id,
                    success = false,
                    errorCode = CapabilityErrorCode.PERMISSION_REQUIRED,
                    errorMessage = "Missing required permissions: ${missing.joinToString(", ")}",
                    durationMs = System.currentTimeMillis() - startTime
                )
            }
        }

        // 4. Confirmation requirement check
        if (definition.confirmationLevel != ConfirmationLevel.NONE && !request.requiresConfirmation) {
            // Can be passed if confirmed in request or execute safely
            Log.d(TAG, "Executing capability ${definition.id} with confirmation level ${definition.confirmationLevel}")
        }

        // 5. Execute action
        return try {
            val result = executor(request)
            CapabilityResponse(
                requestId = request.requestId,
                capabilityId = definition.id,
                success = true,
                data = result,
                durationMs = System.currentTimeMillis() - startTime
            )
        } catch (e: Exception) {
            Log.e(TAG, "Execution failed for ${definition.id}: ${e.message}", e)
            CapabilityResponse(
                requestId = request.requestId,
                capabilityId = definition.id,
                success = false,
                errorCode = CapabilityErrorCode.EXECUTION_FAILED,
                errorMessage = e.message ?: "Unknown execution failure",
                durationMs = System.currentTimeMillis() - startTime
            )
        }
    }
}
