package com.example.domain.model

data class SessionData(
    val sessionId: String,
    val conversationId: String,
    val deviceId: String,
    val userIdPlaceholder: String = "local-user-999",
    val connectionMetadata: Map<String, String> = emptyMap(),
    val createdAt: Long = System.currentTimeMillis()
)
