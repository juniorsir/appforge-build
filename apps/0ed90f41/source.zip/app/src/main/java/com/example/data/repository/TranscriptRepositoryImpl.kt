package com.example.data.repository

import com.example.domain.model.Transcript
import com.example.domain.repository.TranscriptRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class TranscriptRepositoryImpl : TranscriptRepository {

    private val _liveTranscript = MutableStateFlow<Transcript?>(null)
    override val liveTranscript: StateFlow<Transcript?> = _liveTranscript.asStateFlow()

    private val _transcriptHistory = MutableStateFlow<List<Transcript>>(emptyList())
    override val transcriptHistory: StateFlow<List<Transcript>> = _transcriptHistory.asStateFlow()

    override fun addTranscript(transcript: Transcript) {
        if (transcript.isFinal) {
            _transcriptHistory.value = _transcriptHistory.value + transcript
            _liveTranscript.value = null
        } else {
            _liveTranscript.value = transcript
        }
    }

    override fun updateLiveTranscript(transcript: Transcript?) {
        _liveTranscript.value = transcript
    }

    override fun clearHistory() {
        _liveTranscript.value = null
        _transcriptHistory.value = emptyList()
    }
}
