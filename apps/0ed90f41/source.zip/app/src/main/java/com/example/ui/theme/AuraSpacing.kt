package com.example.ui.theme

import androidx.compose.runtime.Immutable
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * AURA ASSISTANT — Centralized Spacing Tokens
 * Built on a strict 4dp base grid.
 */
@Immutable
object AuraSpacing {
    val XS: Dp = 4.dp
    val SM: Dp = 8.dp
    val MD: Dp = 12.dp
    val LG: Dp = 16.dp
    val XL: Dp = 20.dp
    val XXL: Dp = 24.dp
    val XXXL: Dp = 32.dp
    val HUGE: Dp = 40.dp
    val MAX: Dp = 48.dp

    // Surface & Card Internal Padding Levels
    val PaddingCompact: Dp = 12.dp
    val PaddingNormal: Dp = 16.dp
    val PaddingLarge: Dp = 20.dp

    // Screen-level Margin Bounds
    val ScreenMarginMin: Dp = 20.dp
    val ScreenMarginMax: Dp = 40.dp

    // Max Content Width for Tablet / Expanded Displays
    val MaxContentWidth: Dp = 1040.dp

    /**
     * Computes the adaptive screen margin based on available width:
     * clamp(20dp, 0.06 * availableWidth, 40dp)
     */
    fun computeScreenMargin(availableWidth: Dp): Dp {
        val calculated = availableWidth * 0.06f
        return calculated.coerceIn(ScreenMarginMin, ScreenMarginMax)
    }
}
