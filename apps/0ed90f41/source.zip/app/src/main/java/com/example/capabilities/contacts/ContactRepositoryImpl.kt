package com.example.capabilities.contacts

import android.content.Context
import android.provider.ContactsContract
import com.example.capabilities.CapabilityResult
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject

class ContactRepositoryImpl @Inject constructor(
    @ApplicationContext private val context: Context
) : ContactRepository {

    override suspend fun getContacts(): CapabilityResult<List<ContactInfo>> {
        return try {
            val contacts = mutableListOf<ContactInfo>()
            val projection = arrayOf(
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER
            )
            val uri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI
            val sortOrder = "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} ASC"

            context.contentResolver.query(uri, projection, null, null, sortOrder)?.use { cursor ->
                val nameIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
                val numberIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
                while (cursor.moveToNext() && contacts.size < 50) {
                    val name = if (nameIdx != -1) cursor.getString(nameIdx) ?: "Unknown" else "Unknown"
                    val number = if (numberIdx != -1) cursor.getString(numberIdx) else null
                    contacts.add(ContactInfo(name = name, phoneNumber = number))
                }
            }
            CapabilityResult.Success(contacts)
        } catch (e: Exception) {
            CapabilityResult.Error("Failed to query contacts: ${e.message}", e)
        }
    }

    override suspend fun searchContacts(query: String): CapabilityResult<List<ContactInfo>> {
        return try {
            val contacts = mutableListOf<ContactInfo>()
            val projection = arrayOf(
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER
            )
            val uri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI
            val selection = "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?"
            val selectionArgs = arrayOf("%$query%")

            context.contentResolver.query(uri, projection, selection, selectionArgs, null)?.use { cursor ->
                val nameIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
                val numberIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
                while (cursor.moveToNext() && contacts.size < 20) {
                    val name = if (nameIdx != -1) cursor.getString(nameIdx) ?: "Unknown" else "Unknown"
                    val number = if (numberIdx != -1) cursor.getString(numberIdx) else null
                    contacts.add(ContactInfo(name = name, phoneNumber = number))
                }
            }
            CapabilityResult.Success(contacts)
        } catch (e: Exception) {
            CapabilityResult.Error("Failed to search contacts: ${e.message}", e)
        }
    }
}
