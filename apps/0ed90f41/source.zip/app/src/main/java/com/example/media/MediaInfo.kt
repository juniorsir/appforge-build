package com.example.media

data class MediaInfo(
    val uri: String,
    val container: String?,
    val durationSeconds: Double,
    val videoStream: VideoStreamInfo?,
    val audioStream: AudioStreamInfo?,
    val streamCount: Int,
    val sizeBytes: Long
)

data class VideoStreamInfo(
    val codec: String?,
    val width: Int,
    val height: Int,
    val frameRate: Double,
    val bitrate: Long
)

data class AudioStreamInfo(
    val codec: String?,
    val sampleRate: Int,
    val channels: Int,
    val bitrate: Long
)
