package com.example.domain.model

data class BrainConversation(
    val id: String,
    val title: String,
    val createdAt: Long = System.currentTimeMillis(),
    val isArchived: Boolean = false
)

data class BrainMessage(
    val id: String,
    val conversationId: String,
    val role: LlmMessage.Role,
    val content: String,
    val timestamp: Long = System.currentTimeMillis(),
    val tokenCountPlaceholder: Int = 0,
    val responseTimeMs: Long = 0
)

enum class GenerationState {
    IDLE,
    GENERATING,
    SUCCESS,
    ERROR,
    CANCELLED
}
