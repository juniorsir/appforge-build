package com.example.data.repository

import com.example.domain.model.*
import com.example.domain.repository.SessionRepository
import com.example.domain.repository.SessionTranscriptRepository
import com.example.domain.repository.SpeechRepository
import com.example.domain.repository.TranscriptRepository
import com.example.domain.repository.WebSocketRepository
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import java.util.UUID

class SpeechRepositoryImpl(
    private val webSocketRepository: WebSocketRepository,
    private val transcriptRepository: TranscriptRepository,
    private val sessionTranscriptRepository: SessionTranscriptRepository,
    private val sessionRepository: SessionRepository,
    private val scope: CoroutineScope = CoroutineScope(Dispatchers.Default + SupervisorJob())
) : SpeechRepository {

    private val _partialTranscript = MutableStateFlow("")
    override val partialTranscript: StateFlow<String> = _partialTranscript.asStateFlow()

    private val _finalTranscript = MutableStateFlow("")
    override val finalTranscript: StateFlow<String> = _finalTranscript.asStateFlow()

    private val _currentLanguage = MutableStateFlow("en")
    override val currentLanguage: StateFlow<String> = _currentLanguage.asStateFlow()

    private val _speechDurationMs = MutableStateFlow(0L)
    override val speechDurationMs: StateFlow<Long> = _speechDurationMs.asStateFlow()

    private val _streamingLatencyMs = MutableStateFlow(0L)
    override val streamingLatencyMs: StateFlow<Long> = _streamingLatencyMs.asStateFlow()

    private val _recognitionState = MutableStateFlow(SpeechRepository.RecognitionState.IDLE)
    override val recognitionState: StateFlow<SpeechRepository.RecognitionState> = _recognitionState.asStateFlow()

    private val _errorState = MutableStateFlow<String?>(null)
    override val errorState: StateFlow<String?> = _errorState.asStateFlow()

    // Configuration flags for diagnostic simulations
    val isSimulationMode = MutableStateFlow(true) // Enabled by default to ensure 100% testability offline
    val simulatePacketLoss = MutableStateFlow(false)
    val simulateNoise = MutableStateFlow(false)
    val simulateMultiLanguage = MutableStateFlow(false)

    private var durationJob: Job? = null
    private var simulationJob: Job? = null

    init {
        // Collect messages from the active WebSocket link
        scope.launch {
            webSocketRepository.incomingMessages.collect { message ->
                if (!isSimulationMode.value) {
                    handleIncomingNetworkMessage(message)
                }
            }
        }
    }

    private suspend fun handleIncomingNetworkMessage(message: NetworkMessage) {
        when (message) {
            is SttPartialMessage -> {
                _partialTranscript.value = message.text
                _streamingLatencyMs.value = System.currentTimeMillis() - message.timestamp
                _recognitionState.value = SpeechRepository.RecognitionState.LISTENING
            }
            is SttFinalMessage -> {
                _partialTranscript.value = ""
                _finalTranscript.value = message.text
                _currentLanguage.value = message.language
                _streamingLatencyMs.value = System.currentTimeMillis() - message.timestamp
                _recognitionState.value = SpeechRepository.RecognitionState.PROCESSING

                val domainTranscript = Transcript(
                    sessionId = message.sessionId,
                    text = message.text,
                    isFinal = true,
                    timestamp = message.timestamp,
                    confidence = message.confidence,
                    language = message.language
                )
                transcriptRepository.addTranscript(domainTranscript)
                sessionTranscriptRepository.saveTranscript(domainTranscript)

                _recognitionState.value = SpeechRepository.RecognitionState.LISTENING
            }
            is SttErrorMessage -> {
                _errorState.value = "STT Error (${message.errorCode}): ${message.reason}"
                _recognitionState.value = SpeechRepository.RecognitionState.ERROR
            }
            is SttEndMessage -> {
                stopStt()
            }
            else -> { /* Ignore other message types */ }
        }
    }

    override suspend fun startStt(sampleRate: Int, language: String?) {
        _errorState.value = null
        _recognitionState.value = SpeechRepository.RecognitionState.STARTING
        _speechDurationMs.value = 0L

        val currentSession = sessionRepository.currentSession.value
        val startMsg = SttStartMessage(
            timestamp = System.currentTimeMillis(),
            sessionId = currentSession.sessionId,
            sampleRate = sampleRate,
            language = language
        )

        if (!isSimulationMode.value) {
            webSocketRepository.sendMessage(startMsg)
        }

        _recognitionState.value = SpeechRepository.RecognitionState.LISTENING

        // Start timer thread
        durationJob?.cancel()
        durationJob = scope.launch {
            val startTime = System.currentTimeMillis()
            while (isActive) {
                _speechDurationMs.value = System.currentTimeMillis() - startTime
                delay(100)
            }
        }

        if (isSimulationMode.value) {
            startSimulation(currentSession.sessionId)
        }
    }

    override suspend fun stopStt() {
        durationJob?.cancel()
        simulationJob?.cancel()

        val currentSession = sessionRepository.currentSession.value
        val endMsg = SttEndMessage(
            timestamp = System.currentTimeMillis(),
            sessionId = currentSession.sessionId
        )

        if (!isSimulationMode.value) {
            webSocketRepository.sendMessage(endMsg)
        }

        // Handle remaining partial transcript as a final one if present
        val currentPartial = _partialTranscript.value
        if (currentPartial.isNotBlank()) {
            val finalTrans = Transcript(
                sessionId = currentSession.sessionId,
                text = currentPartial,
                isFinal = true,
                confidence = 0.92,
                language = _currentLanguage.value
            )
            transcriptRepository.addTranscript(finalTrans)
            sessionTranscriptRepository.saveTranscript(finalTrans)
            _finalTranscript.value = currentPartial
            _partialTranscript.value = ""
        }

        _recognitionState.value = SpeechRepository.RecognitionState.IDLE
    }

    override suspend fun cancelStt() {
        durationJob?.cancel()
        simulationJob?.cancel()

        val currentSession = sessionRepository.currentSession.value
        val cancelMsg = SttCancelMessage(
            timestamp = System.currentTimeMillis(),
            sessionId = currentSession.sessionId
        )

        if (!isSimulationMode.value) {
            webSocketRepository.sendMessage(cancelMsg)
        }

        _partialTranscript.value = ""
        _recognitionState.value = SpeechRepository.RecognitionState.IDLE
    }

    override fun clearTranscript() {
        _partialTranscript.value = ""
        _finalTranscript.value = ""
        transcriptRepository.clearHistory()
    }

    override fun prepareConversationRequest(): ConversationRequest? {
        val currentSession = sessionRepository.currentSession.value
        val allTranscripts = transcriptRepository.transcriptHistory.value
        if (allTranscripts.isEmpty()) return null

        val rawText = allTranscripts.joinToString(" ") { it.text }
        val cleanedText = sanitizeInput(rawText)
        val formattedText = "User: $cleanedText"

        return ConversationRequest(
            sessionId = currentSession.sessionId,
            rawText = rawText,
            cleanedText = cleanedText,
            formattedText = formattedText
        )
    }

    // --- HIGH-FIDELITY BACKEND STT SIMULATOR ---
    private fun startSimulation(sessionId: String) {
        simulationJob?.cancel()
        simulationJob = scope.launch {
            val languageSet = if (simulateMultiLanguage.value) {
                listOf(
                    Pair("en", listOf("Hello computer", "can you check the system latency", "this is flowing smoothly")),
                    Pair("es", listOf("Hola computadora", "¿puedes revisar la latencia?", "todo fluye perfectamente")),
                    Pair("fr", listOf("Bonjour ordinateur", "peux-tu vérifier la latence", "tout fonctionne correctement")),
                    Pair("ja", listOf("こんにちはコンピュータ", "システム遅延を確認してください", "スムーズに流れています"))
                ).random()
            } else {
                Pair("en", listOf("Aura system initial check", "establishing the Whisper-based Speech-to-Text connection", "streaming live audio over local WebSocket pipeline"))
            }

            val (lang, sentences) = languageSet
            _currentLanguage.value = lang

            for (sentence in sentences) {
                delay(1200) // Speaking pause

                val words = sentence.split(" ")
                var accumulated = ""

                for (i in words.indices) {
                    if (simulatePacketLoss.value && i % 3 == 0) {
                        // Simulate packet drop / latency spike
                        _streamingLatencyMs.value = (250..600).random().toLong()
                        delay(200)
                        continue
                    }

                    accumulated += (if (accumulated.isEmpty()) "" else " ") + words[i]
                    val partialText = if (simulateNoise.value && i == words.size / 2) {
                        "$accumulated [cough]"
                    } else {
                        accumulated
                    }

                    _partialTranscript.value = partialText
                    _streamingLatencyMs.value = (20..80).random().toLong()
                    delay(300) // Word-by-word spelling simulation
                }

                delay(400) // Speech-final pause
                _partialTranscript.value = ""
                _finalTranscript.value = sentence

                val domainTranscript = Transcript(
                    sessionId = sessionId,
                    text = sentence,
                    isFinal = true,
                    confidence = if (simulateNoise.value) 0.78 else 0.98,
                    language = lang
                )
                transcriptRepository.addTranscript(domainTranscript)
                sessionTranscriptRepository.saveTranscript(domainTranscript)
            }

            // Continuous background silent ticks
            while (isActive) {
                delay(1000)
            }
        }
    }
}
