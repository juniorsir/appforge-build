package com.example.domain.model

/**
 * Domain model representing the configuration of the real-time AI Companion.
 */
data class CompanionConfig(
    val id: String = "default",
    val modelName: String = "gemini-2.5-flash",
    val systemInstruction: String = "You are a helpful, empathetic, and responsive real-time AI assistant companion.",
    val voiceName: String = "Puck",
    val speechRate: Float = 1.0f,
    val isMicMuted: Boolean = false,
    val isCameraEnabled: Boolean = false,
    val lastUpdated: Long = System.currentTimeMillis()
)

/**
 * Domain model representing a chat message in the session history transcripts.
 */
data class ChatMessage(
    val id: String,
    val sender: Sender,
    val text: String,
    val timestamp: Long = System.currentTimeMillis()
) {
    enum class Sender {
        USER,
        ASSISTANT,
        SYSTEM
    }
}

/**
 * Domain model representing the active session/connection state of the real-time stream.
 */
data class SessionState(
    val sessionId: String,
    val connectionState: ConnectionState = ConnectionState.DISCONNECTED,
    val activeDurationSeconds: Long = 0,
    val error: String? = null
) {
    enum class ConnectionState {
        DISCONNECTED,
        CONNECTING,
        AUTHENTICATING,
        CONNECTED,
        RECONNECTING,
        ERROR
    }
}

/**
 * Shared immutable state representing the live connection between Android
 * RealtimeConnectionService and Termux AIOS server.
 */
data class RealtimeConnectionState(
    val status: SessionState.ConnectionState = SessionState.ConnectionState.DISCONNECTED,
    val sessionId: String? = null,
    val transport: String = "WebSocket (127.0.0.1:8000)",
    val rtt: Long? = null,
    val lastConnectedAt: Long? = null,
    val lastError: String? = null,
    val serverUrl: String = "ws://127.0.0.1:8000/ws",
    val reconnectAttempt: Int = 0,
    val isServiceRunning: Boolean = false,
    val bytesSent: Long = 0L,
    val bytesReceived: Long = 0L,
    val queueSize: Int = 0
)
