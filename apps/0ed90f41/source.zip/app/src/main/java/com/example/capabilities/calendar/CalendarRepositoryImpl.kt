package com.example.capabilities.calendar

import android.content.ContentValues
import android.content.Context
import android.provider.CalendarContract
import com.example.capabilities.CapabilityResult
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject

class CalendarRepositoryImpl @Inject constructor(
    @ApplicationContext private val context: Context
) : CalendarRepository {

    override suspend fun getEvents(startTime: Long, endTime: Long): CapabilityResult<List<CalendarEvent>> {
        return try {
            val events = mutableListOf<CalendarEvent>()
            val projection = arrayOf(
                CalendarContract.Events.TITLE,
                CalendarContract.Events.DESCRIPTION,
                CalendarContract.Events.DTSTART,
                CalendarContract.Events.DTEND
            )
            val uri = CalendarContract.Events.CONTENT_URI
            val selection = "(${CalendarContract.Events.DTSTART} >= ?) AND (${CalendarContract.Events.DTSTART} <= ?)"
            val selectionArgs = arrayOf(startTime.toString(), endTime.toString())
            val sortOrder = "${CalendarContract.Events.DTSTART} ASC"

            context.contentResolver.query(uri, projection, selection, selectionArgs, sortOrder)?.use { cursor ->
                val titleIdx = cursor.getColumnIndex(CalendarContract.Events.TITLE)
                val descIdx = cursor.getColumnIndex(CalendarContract.Events.DESCRIPTION)
                val startIdx = cursor.getColumnIndex(CalendarContract.Events.DTSTART)
                val endIdx = cursor.getColumnIndex(CalendarContract.Events.DTEND)

                while (cursor.moveToNext() && events.size < 50) {
                    val title = if (titleIdx != -1) cursor.getString(titleIdx) ?: "Untitled Event" else "Untitled Event"
                    val desc = if (descIdx != -1) cursor.getString(descIdx) ?: "" else ""
                    val start = if (startIdx != -1) cursor.getLong(startIdx) else startTime
                    val end = if (endIdx != -1) cursor.getLong(endIdx) else endTime

                    events.add(CalendarEvent(title = title, description = desc, startTime = start, endTime = end))
                }
            }
            CapabilityResult.Success(events)
        } catch (e: Exception) {
            CapabilityResult.Error("Failed to query calendar: ${e.message}", e)
        }
    }

    override suspend fun createEvent(event: CalendarEvent): CapabilityResult<Long> {
        return try {
            val values = ContentValues().apply {
                put(CalendarContract.Events.CALENDAR_ID, 1) // Default primary calendar
                put(CalendarContract.Events.TITLE, event.title)
                put(CalendarContract.Events.DESCRIPTION, event.description)
                put(CalendarContract.Events.DTSTART, event.startTime)
                put(CalendarContract.Events.DTEND, event.endTime)
                put(CalendarContract.Events.EVENT_TIMEZONE, java.util.TimeZone.getDefault().id)
            }
            val uri = context.contentResolver.insert(CalendarContract.Events.CONTENT_URI, values)
            val eventId = uri?.lastPathSegment?.toLongOrNull() ?: 1L
            CapabilityResult.Success(eventId)
        } catch (e: Exception) {
            CapabilityResult.Error("Failed to create calendar event: ${e.message}", e)
        }
    }
}
