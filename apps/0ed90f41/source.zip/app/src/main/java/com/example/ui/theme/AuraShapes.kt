package com.example.ui.theme

import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Immutable
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * AURA ASSISTANT — Centralized Shape & Corner-Radius Tokens
 */
@Immutable
object AuraShapes {
    // Corner Radius Dimensions
    val RadiusTiny: Dp = 10.dp
    val RadiusSmall: Dp = 14.dp
    val RadiusMedium: Dp = 18.dp
    val RadiusLarge: Dp = 24.dp
    val RadiusXL: Dp = 28.dp
    val RadiusHero: Dp = 32.dp
    val RadiusDock: Dp = 38.dp

    // Predefined Rounded Shapes
    val Tiny = RoundedCornerShape(RadiusTiny)
    val Small = RoundedCornerShape(RadiusSmall)
    val Medium = RoundedCornerShape(RadiusMedium)
    val Large = RoundedCornerShape(RadiusLarge)
    val XL = RoundedCornerShape(RadiusXL)
    val Hero = RoundedCornerShape(RadiusHero)
    val Dock = RoundedCornerShape(RadiusDock)
    val Pill = CircleShape
}
