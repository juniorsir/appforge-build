package com.example.tools.repository

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ConfirmationRepositoryImpl @Inject constructor() : ConfirmationRepository {
    private val _requests = MutableStateFlow<List<ConfirmationRequest>>(emptyList())

    override fun getPendingRequests(): Flow<List<ConfirmationRequest>> {
        return _requests.map { list -> list.filter { it.status == ConfirmationStatus.PENDING } }
    }

    override fun getAllRequests(): Flow<List<ConfirmationRequest>> = _requests

    override suspend fun addRequest(request: ConfirmationRequest) {
        val current = _requests.value.toMutableList()
        current.add(0, request)
        _requests.value = current
    }

    override suspend fun updateStatus(executionId: String, status: ConfirmationStatus) {
        val current = _requests.value.toMutableList()
        val index = current.indexOfFirst { it.executionId == executionId }
        if (index != -1) {
            val req = current[index]
            current[index] = req.copy(status = status)
            _requests.value = current
        }
    }
}
