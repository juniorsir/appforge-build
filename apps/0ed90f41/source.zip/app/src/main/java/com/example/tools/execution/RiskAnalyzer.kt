package com.example.tools.execution

import com.example.tools.core.RiskLevel
import com.example.tools.core.Tool
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class RiskAnalyzer @Inject constructor() {
    fun requiresConfirmation(tool: Tool): Boolean {
        return tool.riskLevel == RiskLevel.HIGH || tool.riskLevel == RiskLevel.CRITICAL
    }
    
    fun isAllowed(tool: Tool): Boolean {
        // Here we could block critical tools entirely in certain states, 
        // but for now allow all, just require confirmation for high/critical.
        return true
    }
}
