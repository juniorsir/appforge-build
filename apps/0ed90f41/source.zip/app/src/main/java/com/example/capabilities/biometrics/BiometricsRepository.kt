package com.example.capabilities.biometrics

import android.app.KeyguardManager
import android.content.Context
import android.os.Build
import com.example.capabilities.CapabilityResult
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

data class BiometricsInfo(
    val isHardwareAvailable: Boolean,
    val isDeviceSecure: Boolean,
    val canAuthenticate: Boolean,
    val statusDescription: String
)

interface BiometricsRepository {
    fun getBiometricsInfo(): CapabilityResult<BiometricsInfo>
}

@Singleton
class BiometricsRepositoryImpl @Inject constructor(
    @ApplicationContext private val context: Context
) : BiometricsRepository {

    override fun getBiometricsInfo(): CapabilityResult<BiometricsInfo> {
        return try {
            val keyguardManager = context.getSystemService(Context.KEYGUARD_SERVICE) as? KeyguardManager
            val isDeviceSecure = keyguardManager?.isDeviceSecure ?: false
            val hasFingerprintHardware = context.packageManager.hasSystemFeature(android.content.pm.PackageManager.FEATURE_FINGERPRINT)

            var canAuth = false
            var statusDesc = "Device lock configured: $isDeviceSecure"

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val biometricManager = context.getSystemService(Context.BIOMETRIC_SERVICE) as? android.hardware.biometrics.BiometricManager
                if (biometricManager != null) {
                    val status = biometricManager.canAuthenticate()
                    canAuth = status == android.hardware.biometrics.BiometricManager.BIOMETRIC_SUCCESS
                    statusDesc = when (status) {
                        android.hardware.biometrics.BiometricManager.BIOMETRIC_SUCCESS -> "Biometrics configured and ready"
                        android.hardware.biometrics.BiometricManager.BIOMETRIC_ERROR_NONE_ENROLLED -> "Hardware supported but no biometric credentials enrolled"
                        android.hardware.biometrics.BiometricManager.BIOMETRIC_ERROR_NO_HARDWARE -> "No biometric hardware present on this device"
                        android.hardware.biometrics.BiometricManager.BIOMETRIC_ERROR_HW_UNAVAILABLE -> "Biometric hardware is currently unavailable"
                        else -> "Biometric status: $status"
                    }
                }
            } else {
                canAuth = isDeviceSecure
            }

            CapabilityResult.Success(
                BiometricsInfo(
                    isHardwareAvailable = hasFingerprintHardware,
                    isDeviceSecure = isDeviceSecure,
                    canAuthenticate = canAuth,
                    statusDescription = statusDesc
                )
            )
        } catch (e: Exception) {
            CapabilityResult.Error("Failed to query biometrics: ${e.message}", e)
        }
    }
}
