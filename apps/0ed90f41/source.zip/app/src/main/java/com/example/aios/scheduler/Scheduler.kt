package com.example.aios.scheduler

import com.example.aios.workflows.WorkflowEngine
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton

data class ScheduledTask(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val cronExpression: String,
    val workflowId: String,
    val isEnabled: Boolean = true,
    val nextRunTimestamp: Long = System.currentTimeMillis() + 60000
)

@Singleton
class Scheduler @Inject constructor(
    private val workflowEngine: WorkflowEngine
) {
    private val _schedules = MutableStateFlow<List<ScheduledTask>>(emptyList())
    val schedules: StateFlow<List<ScheduledTask>> = _schedules

    init {
        _schedules.value = listOf(
            ScheduledTask(name = "Daily Morning Briefing", cronExpression = "0 8 * * *", workflowId = "morning_routine"),
            ScheduledTask(name = "Bi-hourly Project Sync", cronExpression = "0 */2 * * *", workflowId = "coding_session")
        )
    }

    fun addSchedule(task: ScheduledTask) {
        val list = _schedules.value.toMutableList()
        list.add(task)
        _schedules.value = list
    }

    fun toggleSchedule(taskId: String) {
        _schedules.value = _schedules.value.map {
            if (it.id == taskId) it.copy(isEnabled = !it.isEnabled) else it
        }
    }
}
