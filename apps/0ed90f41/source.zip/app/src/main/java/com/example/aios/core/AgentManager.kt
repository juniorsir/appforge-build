package com.example.aios.core

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class AgentManager @Inject constructor() {
    private val _agents = MutableStateFlow<Map<String, Agent>>(emptyMap())
    val agentsFlow: Flow<List<Agent>> = _agents.map { it.values.toList() }

    init {
        // Automatically Register All 15 Specialized Agents for Lifecycle & Discovery
        registerAgent(ConversationAgent())
        registerAgent(PlannerAgent())
        registerAgent(ResearchAgent())
        registerAgent(CodingAgent())
        registerAgent(BrowserAgent())
        registerAgent(VisionAgent())
        registerAgent(MemoryAgent())
        registerAgent(CalendarAgent())
        registerAgent(NotificationAgent())
        registerAgent(AutomationAgent())
        registerAgent(DocumentAgent())
        registerAgent(TranslationAgent())
        registerAgent(MediaAgent())
        registerAgent(CommunicationAgent())
        registerAgent(DeveloperAgent())
    }

    fun registerAgent(agent: Agent) {
        val current = _agents.value.toMutableMap()
        current[agent.identity.id] = agent
        _agents.value = current
    }

    fun unregisterAgent(agentId: String) {
        val current = _agents.value.toMutableMap()
        current.remove(agentId)
        _agents.value = current
    }

    fun getAgentById(agentId: String): Agent? {
        return _agents.value[agentId]
    }

    fun discoverAgentsByCapability(capability: String): List<Agent> {
        return _agents.value.values.filter { it.identity.capabilities.contains(capability) }
    }

    fun getHealthyAgents(): List<Agent> {
        return _agents.value.values.filter { it.healthStatus == HealthStatus.HEALTHY }
    }
}
