package com.example.aeroshare.models

import java.io.File

enum class DeviceType {
    PHONE, TABLET, DESKTOP, LAPTOP, UNKNOWN
}

enum class TransferStatus {
    PENDING,
    CONNECTING,
    TRANSFERRING,
    COMPLETED,
    FAILED,
    CANCELLED
}

enum class TransferDirection {
    SEND,
    RECEIVE
}

data class AeroDevice(
    val id: String,
    val name: String,
    val ip: String,
    val port: Int = 8080,
    val deviceType: DeviceType = DeviceType.PHONE,
    val rssi: Int = -55,
    val isSecure: Boolean = true,
    val lastSeenTimestamp: Long = System.currentTimeMillis()
)

data class AeroTransfer(
    val id: String,
    val fileName: String,
    val sizeBytes: Long,
    var transferredBytes: Long = 0L,
    var speedBytesPerSec: Long = 0L,
    var etaSeconds: Long = 0L,
    var status: TransferStatus = TransferStatus.PENDING,
    val direction: TransferDirection = TransferDirection.SEND,
    val peerName: String,
    val peerIp: String,
    val localFilePath: String? = null,
    val errorMessage: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    var completedAt: Long? = null
) {
    val progressPct: Float
        get() = if (sizeBytes > 0) (transferredBytes.toFloat() / sizeBytes.toFloat()).coerceIn(0f, 1f) else 0f
}
