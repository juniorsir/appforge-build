package com.example.hardware

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.util.Log

class AppLauncherManager(private val context: Context) {

    private val TAG = "AppLauncherManager"

    data class AppEntry(
        val appName: String,
        val packageName: String,
        val versionName: String?,
        val isSystemApp: Boolean
    )

    fun getInstalledApps(includeSystem: Boolean = false): List<AppEntry> {
        val pm = context.packageManager
        val intent = Intent(Intent.ACTION_MAIN, null).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }
        val resolveInfos = pm.queryIntentActivities(intent, 0)
        val result = mutableListOf<AppEntry>()

        for (ri in resolveInfos) {
            val pkg = ri.activityInfo.packageName
            val appInfo = ri.activityInfo.applicationInfo
            val isSystem = (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0
            if (!includeSystem && isSystem) continue

            val name = ri.loadLabel(pm).toString()
            val version = try {
                pm.getPackageInfo(pkg, 0).versionName
            } catch (e: Exception) { null }

            result.add(AppEntry(appName = name, packageName = pkg, versionName = version, isSystemApp = isSystem))
        }

        return result.sortedBy { it.appName.lowercase() }
    }

    fun launchApp(target: String): Boolean {
        if (target.isBlank()) return false
        val cleanTarget = target.trim()
        val pm = context.packageManager

        // 1. If it's a web URL, open directly in browser
        if (cleanTarget.startsWith("http://", ignoreCase = true) ||
            cleanTarget.startsWith("https://", ignoreCase = true) ||
            cleanTarget.startsWith("www.", ignoreCase = true)
        ) {
            val fullUrl = if (cleanTarget.startsWith("www.", ignoreCase = true)) "https://$cleanTarget" else cleanTarget
            return openUrl(fullUrl)
        }

        // 2. Try direct package launch
        val directIntent = pm.getLaunchIntentForPackage(cleanTarget)
        if (directIntent != null) {
            directIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            return try {
                context.startActivity(directIntent)
                true
            } catch (e: Exception) {
                Log.e(TAG, "Failed to launch package $cleanTarget: ${e.message}", e)
                false
            }
        }

        // 3. Search installed apps by exact or partial app name / package name
        val allApps = getInstalledApps(includeSystem = true)
        val matched = allApps.firstOrNull { it.appName.equals(cleanTarget, ignoreCase = true) }
            ?: allApps.firstOrNull { it.packageName.equals(cleanTarget, ignoreCase = true) }
            ?: allApps.firstOrNull { it.appName.contains(cleanTarget, ignoreCase = true) }
            ?: allApps.firstOrNull { it.packageName.contains(cleanTarget, ignoreCase = true) }

        if (matched != null) {
            val matchedIntent = pm.getLaunchIntentForPackage(matched.packageName)
            if (matchedIntent != null) {
                matchedIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                return try {
                    context.startActivity(matchedIntent)
                    true
                } catch (e: Exception) {
                    Log.e(TAG, "Failed to launch matched package ${matched.packageName}: ${e.message}", e)
                    false
                }
            }
        }

        return false
    }

    fun openUrl(url: String): Boolean {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return try {
            context.startActivity(intent)
            true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to open URL $url: ${e.message}", e)
            false
        }
    }
}
