package com.example.ui.components.hero

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.ui.components.header.AuraEngineState
import com.example.ui.theme.AuraColors
import com.example.ui.theme.MyApplicationTheme

/**
 * AURA ASSISTANT — Phase 3 Hero Previews across all engine states & viewports
 */
@Composable
private fun HeroPreviewContainer(
    state: AuraEngineState,
    rms: Double = 0.0,
    reducedMotion: Boolean = false
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(AuraColors.Background)
            .padding(16.dp)
    ) {
        AuraHero(
            engineState = state,
            rms = rms,
            reducedMotion = reducedMotion
        )
    }
}

@Preview(name = "1. Hero Standby (411dp)", widthDp = 411, heightDp = 260)
@Composable
fun PreviewAuraHeroStandby() {
    MyApplicationTheme {
        HeroPreviewContainer(state = AuraEngineState.STANDBY)
    }
}

@Preview(name = "2. Hero Connecting (411dp)", widthDp = 411, heightDp = 260)
@Composable
fun PreviewAuraHeroConnecting() {
    MyApplicationTheme {
        HeroPreviewContainer(state = AuraEngineState.CONNECTING)
    }
}

@Preview(name = "3. Hero Listening (411dp)", widthDp = 411, heightDp = 260)
@Composable
fun PreviewAuraHeroListening() {
    MyApplicationTheme {
        HeroPreviewContainer(state = AuraEngineState.LISTENING, rms = 4500.0)
    }
}

@Preview(name = "4. Hero Processing (411dp)", widthDp = 411, heightDp = 260)
@Composable
fun PreviewAuraHeroProcessing() {
    MyApplicationTheme {
        HeroPreviewContainer(state = AuraEngineState.PROCESSING)
    }
}

@Preview(name = "5. Hero Speaking (411dp)", widthDp = 411, heightDp = 260)
@Composable
fun PreviewAuraHeroSpeaking() {
    MyApplicationTheme {
        HeroPreviewContainer(state = AuraEngineState.SPEAKING, rms = 12000.0)
    }
}

@Preview(name = "6. Hero Paused (411dp)", widthDp = 411, heightDp = 260)
@Composable
fun PreviewAuraHeroPaused() {
    MyApplicationTheme {
        HeroPreviewContainer(state = AuraEngineState.PAUSED)
    }
}

@Preview(name = "7. Hero Error (411dp)", widthDp = 411, heightDp = 260)
@Composable
fun PreviewAuraHeroError() {
    MyApplicationTheme {
        HeroPreviewContainer(state = AuraEngineState.ERROR)
    }
}

@Preview(name = "8. Hero Compact Phone (340dp)", widthDp = 340, heightDp = 230)
@Composable
fun PreviewAuraHeroCompactPhone() {
    MyApplicationTheme {
        HeroPreviewContainer(state = AuraEngineState.LISTENING, rms = 3000.0)
    }
}

@Preview(name = "9. Hero Tablet (800dp)", widthDp = 800, heightDp = 290)
@Composable
fun PreviewAuraHeroTablet() {
    MyApplicationTheme {
        HeroPreviewContainer(state = AuraEngineState.LISTENING, rms = 6000.0)
    }
}

@Preview(name = "10. Hero Reduced Motion (411dp)", widthDp = 411, heightDp = 260)
@Composable
fun PreviewAuraHeroReducedMotion() {
    MyApplicationTheme {
        HeroPreviewContainer(state = AuraEngineState.LISTENING, reducedMotion = true)
    }
}
