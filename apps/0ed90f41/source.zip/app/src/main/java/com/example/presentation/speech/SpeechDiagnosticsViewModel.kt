package com.example.presentation.speech

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.BaseApplication
import com.example.data.repository.SpeechRepositoryImpl
import com.example.domain.model.Transcript
import com.example.domain.repository.SessionRepository
import com.example.domain.repository.SpeechRepository
import com.example.domain.repository.TranscriptRepository
import com.example.domain.repository.WebSocketRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class SpeechDiagnosticsViewModel(
    private val speechRepository: SpeechRepository,
    private val transcriptRepository: TranscriptRepository,
    private val webSocketRepository: WebSocketRepository,
    private val sessionRepository: SessionRepository
) : ViewModel() {

    val partialTranscript: StateFlow<String> = speechRepository.partialTranscript
    val finalTranscript: StateFlow<String> = speechRepository.finalTranscript
    val currentLanguage: StateFlow<String> = speechRepository.currentLanguage
    val speechDurationMs: StateFlow<Long> = speechRepository.speechDurationMs
    val streamingLatencyMs: StateFlow<Long> = speechRepository.streamingLatencyMs
    val recognitionState: StateFlow<SpeechRepository.RecognitionState> = speechRepository.recognitionState
    val errorState: StateFlow<String?> = speechRepository.errorState

    val transcriptHistory: StateFlow<List<Transcript>> = transcriptRepository.transcriptHistory
    val connectionState = webSocketRepository.connectionState

    val sessionId: StateFlow<String> = sessionRepository.currentSession
        .map { it.sessionId }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "")

    // Simulation settings (delegated to implementation if available)
    val isSimulationMode = MutableStateFlow(true)
    val simulatePacketLoss = MutableStateFlow(false)
    val simulateNoise = MutableStateFlow(false)
    val simulateMultiLanguage = MutableStateFlow(false)

    init {
        val impl = speechRepository as? SpeechRepositoryImpl
        if (impl != null) {
            viewModelScope.launch {
                isSimulationMode.collect { impl.isSimulationMode.value = it }
            }
            viewModelScope.launch {
                simulatePacketLoss.collect { impl.simulatePacketLoss.value = it }
            }
            viewModelScope.launch {
                simulateNoise.collect { impl.simulateNoise.value = it }
            }
            viewModelScope.launch {
                simulateMultiLanguage.collect { impl.simulateMultiLanguage.value = it }
            }
        }
    }

    fun startStt() {
        viewModelScope.launch {
            speechRepository.startStt()
        }
    }

    fun stopStt() {
        viewModelScope.launch {
            speechRepository.stopStt()
        }
    }

    fun cancelStt() {
        viewModelScope.launch {
            speechRepository.cancelStt()
        }
    }

    fun clearTranscript() {
        speechRepository.clearTranscript()
    }

    fun copyTranscript(context: Context) {
        val history = transcriptHistory.value
        if (history.isEmpty()) {
            Toast.makeText(context, "No transcripts to copy", Toast.LENGTH_SHORT).show()
            return
        }
        val fullText = history.joinToString("\n") { "[${it.language.uppercase()}] ${it.text}" }
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText("Speech Transcript", fullText)
        clipboard.setPrimaryClip(clip)
        Toast.makeText(context, "Transcript copied to clipboard!", Toast.LENGTH_SHORT).show()
    }

    fun exportTranscript(context: Context) {
        val history = transcriptHistory.value
        if (history.isEmpty()) {
            Toast.makeText(context, "No transcripts to export", Toast.LENGTH_SHORT).show()
            return
        }
        val fullText = history.joinToString("\n") { "[${it.language.uppercase()}] ${it.text}" }
        // For diagnostics, we share via Intent which is clean, visual, and highly functional!
        val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(android.content.Intent.EXTRA_SUBJECT, "Speech-to-Text Transcript Session")
            putExtra(android.content.Intent.EXTRA_TEXT, fullText)
        }
        val chooser = android.content.Intent.createChooser(intent, "Export Transcript")
        chooser.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(chooser)
    }

    companion object {
        val Factory: ViewModelProvider.Factory = viewModelFactory {
            initializer {
                val app = this[ViewModelProvider.AndroidViewModelFactory.APPLICATION_KEY] as BaseApplication
                val container = app.container
                SpeechDiagnosticsViewModel(
                    speechRepository = container.speechRepository,
                    transcriptRepository = container.transcriptRepository,
                    webSocketRepository = container.webSocketRepository,
                    sessionRepository = container.sessionRepository
                )
            }
        }
    }
}
