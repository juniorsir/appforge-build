package com.example.ui.components.voice

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.example.ui.theme.AuraColors
import com.example.ui.theme.MyApplicationTheme

@Composable
private fun VoiceDockPreviewContainer(
    state: AuraVoiceState,
    isCameraEnabled: Boolean = false,
    reducedMotion: Boolean = false
) {
    MyApplicationTheme {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(AuraColors.Background),
            contentAlignment = Alignment.BottomCenter
        ) {
            AuraVoiceDock(
                voiceState = state,
                isCameraEnabled = isCameraEnabled,
                onMicClick = {},
                onCameraClick = {},
                reducedMotion = reducedMotion
            )
        }
    }
}

@Preview(name = "1. Idle (411dp)", widthDp = 411)
@Composable
fun PreviewVoiceDockIdle() {
    VoiceDockPreviewContainer(AuraVoiceState.IDLE)
}

@Preview(name = "2. Listening (411dp)", widthDp = 411)
@Composable
fun PreviewVoiceDockListening() {
    VoiceDockPreviewContainer(AuraVoiceState.LISTENING)
}

@Preview(name = "3. Processing (411dp)", widthDp = 411)
@Composable
fun PreviewVoiceDockProcessing() {
    // Treating CONNECTING as PROCESSING visually for preview
    VoiceDockPreviewContainer(AuraVoiceState.CONNECTING)
}

@Preview(name = "4. Speaking (411dp)", widthDp = 411)
@Composable
fun PreviewVoiceDockSpeaking() {
    // In our actual implementation, we might not have a dedicated speaking state yet, 
    // but we can preview IDLE with an active camera
    VoiceDockPreviewContainer(AuraVoiceState.IDLE, isCameraEnabled = true)
}

@Preview(name = "5. Paused/Muted (411dp)", widthDp = 411)
@Composable
fun PreviewVoiceDockMuted() {
    VoiceDockPreviewContainer(AuraVoiceState.MUTED)
}

@Preview(name = "6. Error (411dp)", widthDp = 411)
@Composable
fun PreviewVoiceDockError() {
    VoiceDockPreviewContainer(AuraVoiceState.ERROR)
}

@Preview(name = "7. Disabled (411dp)", widthDp = 411)
@Composable
fun PreviewVoiceDockDisabled() {
    VoiceDockPreviewContainer(AuraVoiceState.UNAVAILABLE)
}

@Preview(name = "8. Narrow Phone (320dp)", widthDp = 320)
@Composable
fun PreviewVoiceDockNarrow() {
    VoiceDockPreviewContainer(AuraVoiceState.IDLE)
}

@Preview(name = "9. Tablet (800dp)", widthDp = 800)
@Composable
fun PreviewVoiceDockTablet() {
    VoiceDockPreviewContainer(AuraVoiceState.LISTENING, isCameraEnabled = true)
}
