package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)

// Modern Dark Obsidian & Neon Cyber Palette
val ObsidianBg = Color(0xFF090D16)
val ObsidianSurface = Color(0xFF111827)
val ObsidianSurfaceVariant = Color(0xFF182238)
val ObsidianSurfaceElevated = Color(0xFF1F2D48)

val NeonCyan = Color(0xFF38BDF8)
val NeonCyanBright = Color(0xFF00E5FF)
val ElectricViolet = Color(0xFF818CF8)
val ElectricPurple = Color(0xFFA855F7)
val NeonEmerald = Color(0xFF10B981)
val NeonAmber = Color(0xFFF59E0B)
val NeonRose = Color(0xFFF43F5E)

// High Density Palette Tokens
val HighDensityBackground = ObsidianBg
val HighDensitySurface = ObsidianSurface
val HighDensitySurfaceVariant = ObsidianSurfaceVariant
val HighDensityPrimary = Color(0xFF60A5FA)
val HighDensityOnPrimary = Color(0xFF0B192C)
val HighDensitySecondary = Color(0xFF1E293B)
val HighDensityOnSecondary = Color(0xFFE2E8F0)
val HighDensityTertiary = ElectricViolet
val HighDensityOnBackground = Color(0xFFF8FAFC)
val HighDensityOnSurface = Color(0xFFF1F5F9)
val HighDensityOnSurfaceVariant = Color(0xFF94A3B8)
val HighDensityOutline = Color(0xFF2A374F)

// Alert & status colors
val CrimsonBg = Color(0xFF241017)
val CrimsonBorder = Color(0xFF7F1D1D)
val CrimsonText = Color(0xFFFECDD3)
val CrimsonIndicator = Color(0xFFE11D48)

// Active/success mint colors
val MintIndicator = NeonEmerald
val MintBg = Color(0xFF062E20)
val MintBorder = Color(0xFF047857)
val MintText = Color(0xFFA7F3D0)


