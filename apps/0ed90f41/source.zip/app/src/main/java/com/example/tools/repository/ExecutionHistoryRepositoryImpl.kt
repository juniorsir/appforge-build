package com.example.tools.repository

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ExecutionHistoryRepositoryImpl @Inject constructor() : ExecutionHistoryRepository {
    private val _logs = MutableStateFlow<List<ExecutionLog>>(emptyList())

    override fun getHistory(): Flow<List<ExecutionLog>> = _logs

    override suspend fun logExecution(log: ExecutionLog) {
        val current = _logs.value.toMutableList()
        current.add(0, log) // Add to beginning for newest first
        _logs.value = current
    }

    override suspend fun getExecutionLog(executionId: String): ExecutionLog? {
        return _logs.value.find { it.executionId == executionId }
    }
}
