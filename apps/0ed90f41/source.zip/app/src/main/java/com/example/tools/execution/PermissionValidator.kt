package com.example.tools.execution

import com.example.capabilities.permissions.PermissionManager
import com.example.tools.core.Tool
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class PermissionValidator @Inject constructor(
    private val permissionManager: PermissionManager
) {
    fun validatePermissions(tool: Tool): List<String> {
        return permissionManager.getMissingPermissions(tool.requiredPermissions)
    }
}
