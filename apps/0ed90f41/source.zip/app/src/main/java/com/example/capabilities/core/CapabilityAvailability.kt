package com.example.capabilities.core

enum class CapabilityAvailability(val label: String) {
    AVAILABLE("Available"),
    PERMISSION_REQUIRED("Permission Required"),
    HARDWARE_MISSING("Hardware Unavailable"),
    ANDROID_VERSION_UNSUPPORTED("OS Version Unsupported"),
    SERVICE_DISABLED("Service Disabled"),
    UNAVAILABLE_TO_NORMAL_APP("Restricted to System Apps"),
    DISABLED("Disabled")
}

enum class CapabilityState {
    IDLE,
    INITIALIZING,
    ACTIVE,
    RUNNING,
    PAUSED,
    ERROR,
    TERMINATED
}

enum class ConfirmationLevel {
    NONE,
    CONFIRMATION,
    STRONG_CONFIRMATION
}
