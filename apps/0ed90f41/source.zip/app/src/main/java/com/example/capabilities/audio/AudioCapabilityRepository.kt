package com.example.capabilities.audio

import android.content.Context
import android.media.AudioDeviceInfo
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.AudioRecord
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.AutomaticGainControl
import android.media.audiofx.NoiseSuppressor
import android.os.Build
import com.example.capabilities.CapabilityResult
import com.example.capabilities.core.CapabilityErrorCode
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

data class AudioHardwareInfo(
    val hasMicrophone: Boolean,
    val isAcousticEchoCancelerAvailable: Boolean,
    val isNoiseSuppressorAvailable: Boolean,
    val isAutomaticGainControlAvailable: Boolean,
    val currentVolume: Int,
    val maxVolume: Int,
    val isMusicActive: Boolean,
    val isSpeakerphoneOn: Boolean,
    val isBluetoothScoOn: Boolean,
    val isWiredHeadsetOn: Boolean,
    val inputDevices: List<String>,
    val outputDevices: List<String>
)

interface AudioCapabilityRepository {
    fun getAudioHardwareInfo(): CapabilityResult<AudioHardwareInfo>
    fun setSpeakerphoneOn(on: Boolean): CapabilityResult<Boolean>
    fun setStreamVolume(streamType: Int, volume: Int): CapabilityResult<Boolean>
    fun getMicrophoneCapability(): CapabilityResult<Map<String, Any>>
}

@Singleton
class AudioCapabilityRepositoryImpl @Inject constructor(
    @ApplicationContext private val context: Context
) : AudioCapabilityRepository {

    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager

    override fun getAudioHardwareInfo(): CapabilityResult<AudioHardwareInfo> {
        return try {
            val am = audioManager ?: return CapabilityResult.Error(
                "AudioManager unavailable",
                errorCode = CapabilityErrorCode.SERVICE_DISABLED
            )

            val currentVol = am.getStreamVolume(AudioManager.STREAM_MUSIC)
            val maxVol = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            val isMusicActive = am.isMusicActive
            val isSpeakerphone = am.isSpeakerphoneOn
            val isBtSco = am.isBluetoothScoOn
            val isWiredHeadset = am.isWiredHeadsetOn

            val inputDevices = mutableListOf<String>()
            val outputDevices = mutableListOf<String>()

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                val devices = am.getDevices(AudioManager.GET_DEVICES_ALL)
                for (dev in devices) {
                    val name = "${dev.productName} (${getDeviceTypeName(dev.type)})"
                    if (dev.isSource) {
                        inputDevices.add(name)
                    }
                    if (dev.isSink) {
                        outputDevices.add(name)
                    }
                }
            }

            val aecAvailable = AcousticEchoCanceler.isAvailable()
            val nsAvailable = NoiseSuppressor.isAvailable()
            val agcAvailable = AutomaticGainControl.isAvailable()
            val hasMic = context.packageManager.hasSystemFeature(android.content.pm.PackageManager.FEATURE_MICROPHONE)

            CapabilityResult.Success(
                AudioHardwareInfo(
                    hasMicrophone = hasMic,
                    isAcousticEchoCancelerAvailable = aecAvailable,
                    isNoiseSuppressorAvailable = nsAvailable,
                    isAutomaticGainControlAvailable = agcAvailable,
                    currentVolume = currentVol,
                    maxVolume = maxVol,
                    isMusicActive = isMusicActive,
                    isSpeakerphoneOn = isSpeakerphone,
                    isBluetoothScoOn = isBtSco,
                    isWiredHeadsetOn = isWiredHeadset,
                    inputDevices = inputDevices,
                    outputDevices = outputDevices
                )
            )
        } catch (e: Exception) {
            CapabilityResult.Error("Failed to query audio hardware: ${e.message}", e)
        }
    }

    override fun setSpeakerphoneOn(on: Boolean): CapabilityResult<Boolean> {
        return try {
            val am = audioManager ?: return CapabilityResult.Error("AudioManager unavailable")
            am.isSpeakerphoneOn = on
            CapabilityResult.Success(am.isSpeakerphoneOn)
        } catch (e: Exception) {
            CapabilityResult.Error("Failed to set speakerphone: ${e.message}", e)
        }
    }

    override fun setStreamVolume(streamType: Int, volume: Int): CapabilityResult<Boolean> {
        return try {
            val am = audioManager ?: return CapabilityResult.Error("AudioManager unavailable")
            val maxVol = am.getStreamMaxVolume(streamType)
            val safeVol = volume.coerceIn(0, maxVol)
            am.setStreamVolume(streamType, safeVol, 0)
            CapabilityResult.Success(true)
        } catch (e: Exception) {
            CapabilityResult.Error("Failed to set volume: ${e.message}", e)
        }
    }

    override fun getMicrophoneCapability(): CapabilityResult<Map<String, Any>> {
        val hasMic = context.packageManager.hasSystemFeature(android.content.pm.PackageManager.FEATURE_MICROPHONE)
        val minBufferSize = AudioRecord.getMinBufferSize(
            16000,
            android.media.AudioFormat.CHANNEL_IN_MONO,
            android.media.AudioFormat.ENCODING_PCM_16BIT
        )
        return CapabilityResult.Success(
            mapOf(
                "hasMicrophone" to hasMic,
                "preferredSampleRate" to 16000,
                "preferredChannelConfig" to "MONO",
                "preferredEncoding" to "PCM_16BIT",
                "minBufferSize" to minBufferSize,
                "acousticEchoCancelerAvailable" to AcousticEchoCanceler.isAvailable(),
                "noiseSuppressorAvailable" to NoiseSuppressor.isAvailable(),
                "automaticGainControlAvailable" to AutomaticGainControl.isAvailable()
            )
        )
    }

    private fun getDeviceTypeName(type: Int): String {
        return when (type) {
            AudioDeviceInfo.TYPE_BUILTIN_EARPIECE -> "Built-in Earpiece"
            AudioDeviceInfo.TYPE_BUILTIN_SPEAKER -> "Built-in Speaker"
            AudioDeviceInfo.TYPE_WIRED_HEADSET -> "Wired Headset"
            AudioDeviceInfo.TYPE_WIRED_HEADPHONES -> "Wired Headphones"
            AudioDeviceInfo.TYPE_BLUETOOTH_SCO -> "Bluetooth SCO"
            AudioDeviceInfo.TYPE_BLUETOOTH_A2DP -> "Bluetooth A2DP"
            AudioDeviceInfo.TYPE_BUILTIN_MIC -> "Built-in Mic"
            AudioDeviceInfo.TYPE_USB_DEVICE -> "USB Device"
            AudioDeviceInfo.TYPE_USB_HEADSET -> "USB Headset"
            else -> "Audio Device ($type)"
        }
    }
}
