package com.example.presentation.accessibility

import android.content.Context
import android.content.Intent
import android.provider.Settings
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.BaseApplication
import com.example.accessibility.AccessibilityRepository
import com.example.accessibility.models.AccessibilityNodeModel
import com.example.accessibility.models.GestureRequestModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class AccessibilityViewModel(
    private val repository: AccessibilityRepository
) : ViewModel() {

    val serviceStatus = repository.serviceStatus
    val recentEvents = repository.recentEvents
    val logs = repository.logs

    private val _nodeTree = MutableStateFlow<List<AccessibilityNodeModel>>(emptyList())
    val nodeTree: StateFlow<List<AccessibilityNodeModel>> = _nodeTree.asStateFlow()

    private val _searchQueryText = MutableStateFlow("")
    val searchQueryText: StateFlow<String> = _searchQueryText.asStateFlow()

    fun updateSearchQuery(query: String) {
        _searchQueryText.value = query
    }

    fun openAccessibilitySettings(context: Context) {
        try {
            val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
            repository.addLog("Opened system Accessibility settings.")
        } catch (e: Exception) {
            repository.addLog("Error opening system settings: ${e.message}")
        }
    }

    fun triggerLocalClick(x: Float, y: Float) {
        viewModelScope.launch {
            val gesture = GestureRequestModel(
                id = "local_click_" + System.currentTimeMillis(),
                type = "CLICK",
                startX = x,
                startY = y,
                durationMs = 80L
            )
            repository.triggerGesture(gesture) { success ->
                repository.addLog("Local click gesture dispatch: success=$success")
            }
        }
    }

    fun triggerLocalSwipe(startX: Float, startY: Float, endX: Float, endY: Float) {
        viewModelScope.launch {
            val gesture = GestureRequestModel(
                id = "local_swipe_" + System.currentTimeMillis(),
                type = "SWIPE",
                startX = startX,
                startY = startY,
                endX = endX,
                endY = endY,
                durationMs = 400L
            )
            repository.triggerGesture(gesture) { success ->
                repository.addLog("Local swipe gesture dispatch: success=$success")
            }
        }
    }

    fun inspectActiveScreen() {
        viewModelScope.launch {
            repository.addLog("Manually inspecting active screen node tree...")
            val tree = repository.getFullNodeTree()
            _nodeTree.value = tree
            if (tree.isEmpty()) {
                repository.addLog("Inspection returned empty. Is the Accessibility service enabled?")
            } else {
                repository.addLog("Inspection successful: loaded ${countNodes(tree.firstOrNull())} elements.")
            }
        }
    }

    fun searchOnScreenNodes() {
        viewModelScope.launch {
            val query = _searchQueryText.value
            if (query.isBlank()) {
                inspectActiveScreen()
                return@launch
            }
            repository.addLog("Searching active screen for query '$query'...")
            val matches = repository.searchNodes(text = query, contentDescription = query, viewId = query)
            _nodeTree.value = matches
        }
    }

    private fun countNodes(node: AccessibilityNodeModel?): Int {
        if (node == null) return 0
        var count = 1
        for (child in node.children) {
            count += countNodes(child)
        }
        return count
    }

    companion object {
        val Factory: ViewModelProvider.Factory = viewModelFactory {
            initializer {
                val app = this[ViewModelProvider.AndroidViewModelFactory.APPLICATION_KEY] as BaseApplication
                AccessibilityViewModel(
                    repository = app.container.accessibilityRepository
                )
            }
        }
    }
}
