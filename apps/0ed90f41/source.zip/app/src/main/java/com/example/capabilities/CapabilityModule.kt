package com.example.capabilities

import com.example.capabilities.apps.ApplicationRepository
import com.example.capabilities.apps.ApplicationRepositoryImpl
import com.example.capabilities.audio.AudioCapabilityRepository
import com.example.capabilities.audio.AudioCapabilityRepositoryImpl
import com.example.capabilities.battery.BatteryRepository
import com.example.capabilities.battery.BatteryRepositoryImpl
import com.example.capabilities.biometrics.BiometricsRepository
import com.example.capabilities.biometrics.BiometricsRepositoryImpl
import com.example.capabilities.bluetooth.BluetoothRepository
import com.example.capabilities.bluetooth.BluetoothRepositoryImpl
import com.example.capabilities.calendar.CalendarRepository
import com.example.capabilities.calendar.CalendarRepositoryImpl
import com.example.capabilities.camera.CameraRepository
import com.example.capabilities.camera.CameraRepositoryImpl
import com.example.capabilities.clipboard.ClipboardRepository
import com.example.capabilities.clipboard.ClipboardRepositoryImpl
import com.example.capabilities.contacts.ContactRepository
import com.example.capabilities.contacts.ContactRepositoryImpl
import com.example.capabilities.core.CapabilityRegistry
import com.example.capabilities.core.CapabilityRegistryImpl
import com.example.capabilities.display.DisplayRepository
import com.example.capabilities.display.DisplayRepositoryImpl
import com.example.capabilities.events.SystemEventsRepository
import com.example.capabilities.events.SystemEventsRepositoryImpl
import com.example.capabilities.gallery.GalleryRepository
import com.example.capabilities.gallery.GalleryRepositoryImpl
import com.example.capabilities.gps.LocationRepository
import com.example.capabilities.gps.LocationRepositoryImpl
import com.example.capabilities.haptics.HapticsRepository
import com.example.capabilities.haptics.HapticsRepositoryImpl
import com.example.capabilities.info.DeviceInfoRepository
import com.example.capabilities.info.DeviceInfoRepositoryImpl
import com.example.capabilities.input.InputRepository
import com.example.capabilities.input.InputRepositoryImpl
import com.example.capabilities.intents.IntentRepository
import com.example.capabilities.intents.IntentRepositoryImpl
import com.example.capabilities.network.NetworkRepository
import com.example.capabilities.network.NetworkRepositoryImpl
import com.example.capabilities.nfc.NfcRepository
import com.example.capabilities.nfc.NfcRepositoryImpl
import com.example.capabilities.notifications.NotificationRepository
import com.example.capabilities.notifications.NotificationRepositoryImpl
import com.example.capabilities.sensors.SensorRepository
import com.example.capabilities.sensors.SensorRepositoryImpl
import com.example.capabilities.settings.SystemSettingsRepository
import com.example.capabilities.settings.SystemSettingsRepositoryImpl
import com.example.capabilities.share.ShareRepository
import com.example.capabilities.share.ShareRepositoryImpl
import com.example.capabilities.sms.SmsRepository
import com.example.capabilities.sms.SmsRepositoryImpl
import com.example.capabilities.storage.StorageRepository
import com.example.capabilities.storage.StorageRepositoryImpl
import com.example.capabilities.telephony.TelephonyRepository
import com.example.capabilities.telephony.TelephonyRepositoryImpl
import com.example.capabilities.usb.UsbRepository
import com.example.capabilities.usb.UsbRepositoryImpl
import com.example.capabilities.work.BackgroundWorkRepository
import com.example.capabilities.work.BackgroundWorkRepositoryImpl
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
abstract class CapabilityModule {

    @Binds
    @Singleton
    abstract fun bindCapabilityRegistry(impl: CapabilityRegistryImpl): CapabilityRegistry

    @Binds
    @Singleton
    abstract fun bindAudioCapabilityRepository(impl: AudioCapabilityRepositoryImpl): AudioCapabilityRepository

    @Binds
    @Singleton
    abstract fun bindBatteryRepository(impl: BatteryRepositoryImpl): BatteryRepository

    @Binds
    @Singleton
    abstract fun bindBluetoothRepository(impl: BluetoothRepositoryImpl): BluetoothRepository

    @Binds
    @Singleton
    abstract fun bindBiometricsRepository(impl: BiometricsRepositoryImpl): BiometricsRepository

    @Binds
    @Singleton
    abstract fun bindCalendarRepository(impl: CalendarRepositoryImpl): CalendarRepository

    @Binds
    @Singleton
    abstract fun bindCameraRepository(impl: CameraRepositoryImpl): CameraRepository

    @Binds
    @Singleton
    abstract fun bindClipboardRepository(impl: ClipboardRepositoryImpl): ClipboardRepository

    @Binds
    @Singleton
    abstract fun bindContactRepository(impl: ContactRepositoryImpl): ContactRepository

    @Binds
    @Singleton
    abstract fun bindDeviceInfoRepository(impl: DeviceInfoRepositoryImpl): DeviceInfoRepository

    @Binds
    @Singleton
    abstract fun bindDisplayRepository(impl: DisplayRepositoryImpl): DisplayRepository

    @Binds
    @Singleton
    abstract fun bindEventsRepository(impl: SystemEventsRepositoryImpl): SystemEventsRepository

    @Binds
    @Singleton
    abstract fun bindGalleryRepository(impl: GalleryRepositoryImpl): GalleryRepository

    @Binds
    @Singleton
    abstract fun bindHapticsRepository(impl: HapticsRepositoryImpl): HapticsRepository

    @Binds
    @Singleton
    abstract fun bindInputRepository(impl: InputRepositoryImpl): InputRepository

    @Binds
    @Singleton
    abstract fun bindIntentRepository(impl: IntentRepositoryImpl): IntentRepository

    @Binds
    @Singleton
    abstract fun bindLocationRepository(impl: LocationRepositoryImpl): LocationRepository

    @Binds
    @Singleton
    abstract fun bindNetworkRepository(impl: NetworkRepositoryImpl): NetworkRepository

    @Binds
    @Singleton
    abstract fun bindNfcRepository(impl: NfcRepositoryImpl): NfcRepository

    @Binds
    @Singleton
    abstract fun bindNotificationRepository(impl: NotificationRepositoryImpl): NotificationRepository

    @Binds
    @Singleton
    abstract fun bindApplicationRepository(impl: ApplicationRepositoryImpl): ApplicationRepository

    @Binds
    @Singleton
    abstract fun bindSensorRepository(impl: SensorRepositoryImpl): SensorRepository

    @Binds
    @Singleton
    abstract fun bindSettingsRepository(impl: SystemSettingsRepositoryImpl): SystemSettingsRepository

    @Binds
    @Singleton
    abstract fun bindShareRepository(impl: ShareRepositoryImpl): ShareRepository

    @Binds
    @Singleton
    abstract fun bindSmsRepository(impl: SmsRepositoryImpl): SmsRepository

    @Binds
    @Singleton
    abstract fun bindStorageRepository(impl: StorageRepositoryImpl): StorageRepository

    @Binds
    @Singleton
    abstract fun bindTelephonyRepository(impl: TelephonyRepositoryImpl): TelephonyRepository

    @Binds
    @Singleton
    abstract fun bindUsbRepository(impl: UsbRepositoryImpl): UsbRepository

    @Binds
    @Singleton
    abstract fun bindBackgroundWorkRepository(impl: BackgroundWorkRepositoryImpl): BackgroundWorkRepository
}
