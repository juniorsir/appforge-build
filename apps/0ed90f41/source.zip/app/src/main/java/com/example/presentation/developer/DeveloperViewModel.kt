package com.example.presentation.developer

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.BaseApplication
import com.example.domain.model.RealtimeConnectionState
import com.example.domain.model.SessionState
import com.example.domain.repository.HttpRepository
import com.example.domain.repository.NetworkStateRepository
import com.example.domain.repository.SessionRepository
import com.example.domain.repository.WebSocketRepository
import com.example.services.RealtimeConnectionService
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

/**
 * Developer ViewModel decoupled from WebSocket ownership.
 *
 * All connection operations and lifecycles are strictly delegated to
 * [RealtimeConnectionService]. The UI only observes service state.
 */
class DeveloperViewModel(
    private val appContext: Context,
    private val webSocketRepository: WebSocketRepository,
    private val httpRepository: HttpRepository,
    private val sessionRepository: SessionRepository,
    private val networkStateRepository: NetworkStateRepository
) : ViewModel() {

    // Unified service state exposed by the Foreground Service
    val serviceState: StateFlow<RealtimeConnectionState> = RealtimeConnectionService.serviceState

    val connectionState: StateFlow<SessionState.ConnectionState> = serviceState
        .map { it.status }
        .stateIn(viewModelScope, SharingStarted.Eagerly, serviceState.value.status)

    val latencyMs = webSocketRepository.latencyMs
    val bytesSent = webSocketRepository.bytesSent
    val bytesReceived = webSocketRepository.bytesReceived
    val queueSize = webSocketRepository.queueSize
    val retryCount = webSocketRepository.retryCount
    val connectionLogs = webSocketRepository.connectionLogs
    val lastFailureReason = webSocketRepository.lastFailureReason
    val currentSession = sessionRepository.currentSession
    val isNetworkAvailable = networkStateRepository.isNetworkAvailable
    val isLocalhostReachable = networkStateRepository.isLocalhostReachable

    private val _isTestingConnection = MutableStateFlow(false)
    val isTestingConnection: StateFlow<Boolean> = _isTestingConnection.asStateFlow()

    private val _testConnectionResult = MutableStateFlow<String?>(null)
    val testConnectionResult: StateFlow<String?> = _testConnectionResult.asStateFlow()

    private val _serverUrl = MutableStateFlow("ws://127.0.0.1:8000/ws")
    val serverUrl: StateFlow<String> = _serverUrl.asStateFlow()

    fun updateServerUrl(newUrl: String) {
        _serverUrl.value = newUrl
    }

    /**
     * Delegate connect request to the Foreground Service.
     * Does NOT create a WebSocket inside the ViewModel scope.
     */
    fun connect() {
        RealtimeConnectionService.connect(appContext, _serverUrl.value)
    }

    /**
     * Delegate disconnect request to the Foreground Service.
     */
    fun disconnect() {
        RealtimeConnectionService.disconnect(appContext)
    }

    /**
     * Delegate reconnect request to the Foreground Service.
     */
    fun reconnect() {
        RealtimeConnectionService.reconnect(appContext, _serverUrl.value)
    }

    fun clearLogs() {
        webSocketRepository.clearLogs()
    }

    fun testConnection() {
        _isTestingConnection.value = true
        val targetHttpUrl = _serverUrl.value
            .replace("wss://", "https://")
            .replace("ws://", "http://")
            .substringBefore("/ws")
            .let { if (it.endsWith("/")) it else "$it/" }

        _testConnectionResult.value = "Testing HTTP loopback at $targetHttpUrl..."
        webSocketRepository.addLog("HTTP LOOPBACK TEST: Sending GET request to $targetHttpUrl")
        viewModelScope.launch {
            val result = httpRepository.checkServerHealthDetailed(targetHttpUrl)
            _isTestingConnection.value = false
            _testConnectionResult.value = if (result.isSuccess) {
                "SUCCESS: HTTP ${result.statusCode ?: 200} OK from $targetHttpUrl"
            } else {
                "FAILED: ${result.error ?: "Connection failed"}"
            }
            webSocketRepository.addLog("HTTP TEST RESULT: ${_testConnectionResult.value}")
        }
    }

    companion object {
        val Factory: ViewModelProvider.Factory = viewModelFactory {
            initializer {
                val app = this[ViewModelProvider.AndroidViewModelFactory.APPLICATION_KEY] as BaseApplication
                val container = app.container
                DeveloperViewModel(
                    appContext = app.applicationContext,
                    webSocketRepository = container.webSocketRepository,
                    httpRepository = container.httpRepository,
                    sessionRepository = container.sessionRepository,
                    networkStateRepository = container.networkStateRepository
                )
            }
        }
    }
}
