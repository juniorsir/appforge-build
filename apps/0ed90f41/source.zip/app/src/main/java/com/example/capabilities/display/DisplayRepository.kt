package com.example.capabilities.display

import android.content.Context
import android.content.res.Configuration
import android.os.Build
import android.util.DisplayMetrics
import android.view.WindowManager
import com.example.capabilities.CapabilityResult
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

data class ScreenDisplayInfo(
    val widthPixels: Int,
    val heightPixels: Int,
    val densityDpi: Int,
    val densityScale: Float,
    val refreshRateHz: Float,
    val orientation: String,
    val isHdr: Boolean,
    val isWideColorGamut: Boolean
)

interface DisplayRepository {
    fun getDisplayInfo(): CapabilityResult<ScreenDisplayInfo>
}

@Singleton
class DisplayRepositoryImpl @Inject constructor(
    @ApplicationContext private val context: Context
) : DisplayRepository {

    override fun getDisplayInfo(): CapabilityResult<ScreenDisplayInfo> {
        return try {
            val metrics = context.resources.displayMetrics
            val config = context.resources.configuration
            val orientationStr = if (config.orientation == Configuration.ORIENTATION_LANDSCAPE) "LANDSCAPE" else "PORTRAIT"

            var refreshRate = 60.0f
            var isHdr = false
            var isWideGamut = false

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                val display = context.display
                if (display != null) {
                    refreshRate = display.refreshRate
                    isHdr = display.isHdr
                    isWideGamut = display.isWideColorGamut
                }
            } else {
                val wm = context.getSystemService(Context.WINDOW_SERVICE) as? WindowManager
                refreshRate = wm?.defaultDisplay?.refreshRate ?: 60.0f
            }

            CapabilityResult.Success(
                ScreenDisplayInfo(
                    widthPixels = metrics.widthPixels,
                    heightPixels = metrics.heightPixels,
                    densityDpi = metrics.densityDpi,
                    densityScale = metrics.density,
                    refreshRateHz = refreshRate,
                    orientation = orientationStr,
                    isHdr = isHdr,
                    isWideColorGamut = isWideGamut
                )
            )
        } catch (e: Exception) {
            CapabilityResult.Error("Failed to query display info: ${e.message}", e)
        }
    }
}
