package com.example.ui.components.service

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.ui.theme.AuraColors
import com.example.ui.theme.MyApplicationTheme

/**
 * AURA ASSISTANT — Phase 4 Foreground Service Status Previews
 */
@Composable
private fun ServiceStatusPreviewContainer(
    state: AuraServiceState,
    detail: String? = null,
    reducedMotion: Boolean = false
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(AuraColors.Background)
            .padding(16.dp)
    ) {
        AuraServiceStatusCard(
            state = state,
            statusDetail = detail,
            onActionClick = {},
            reducedMotion = reducedMotion
        )
    }
}

@Preview(name = "1. Service Running (411dp)", widthDp = 411, heightDp = 130)
@Composable
fun PreviewAuraServiceRunning() {
    MyApplicationTheme {
        ServiceStatusPreviewContainer(
            state = AuraServiceState.RUNNING,
            detail = "Active: Low-latency 16-bit PCM capture thread streaming"
        )
    }
}

@Preview(name = "2. Service Starting (411dp)", widthDp = 411, heightDp = 130)
@Composable
fun PreviewAuraServiceStarting() {
    MyApplicationTheme {
        ServiceStatusPreviewContainer(
            state = AuraServiceState.STARTING
        )
    }
}

@Preview(name = "3. Service Stopping (411dp)", widthDp = 411, heightDp = 130)
@Composable
fun PreviewAuraServiceStopping() {
    MyApplicationTheme {
        ServiceStatusPreviewContainer(
            state = AuraServiceState.STOPPING
        )
    }
}

@Preview(name = "4. Service Paused (411dp)", widthDp = 411, heightDp = 130)
@Composable
fun PreviewAuraServicePaused() {
    MyApplicationTheme {
        ServiceStatusPreviewContainer(
            state = AuraServiceState.PAUSED,
            detail = "Paused: Audio capture suspended on device"
        )
    }
}

@Preview(name = "5. Service Stopped (411dp)", widthDp = 411, heightDp = 130)
@Composable
fun PreviewAuraServiceStopped() {
    MyApplicationTheme {
        ServiceStatusPreviewContainer(
            state = AuraServiceState.STOPPED,
            detail = "Standby: WebSocket & capture engines idle"
        )
    }
}

@Preview(name = "6. Service Error (411dp)", widthDp = 411, heightDp = 130)
@Composable
fun PreviewAuraServiceError() {
    MyApplicationTheme {
        ServiceStatusPreviewContainer(
            state = AuraServiceState.ERROR,
            detail = "Permission missing: Microphone access required"
        )
    }
}

@Preview(name = "7. Service Compact Phone (340dp)", widthDp = 340, heightDp = 160)
@Composable
fun PreviewAuraServiceCompactPhone() {
    MyApplicationTheme {
        ServiceStatusPreviewContainer(
            state = AuraServiceState.RUNNING,
            detail = "Active: Low-latency 16-bit PCM streaming"
        )
    }
}

@Preview(name = "8. Service Tablet (800dp)", widthDp = 800, heightDp = 140)
@Composable
fun PreviewAuraServiceTablet() {
    MyApplicationTheme {
        ServiceStatusPreviewContainer(
            state = AuraServiceState.RUNNING,
            detail = "Active: Low-latency 16-bit PCM capture thread streaming"
        )
    }
}

@Preview(name = "9. Service Landscape (700dp)", widthDp = 700, heightDp = 130)
@Composable
fun PreviewAuraServiceLandscape() {
    MyApplicationTheme {
        ServiceStatusPreviewContainer(
            state = AuraServiceState.RUNNING,
            detail = "Active: Low-latency 16-bit PCM capture thread streaming"
        )
    }
}
