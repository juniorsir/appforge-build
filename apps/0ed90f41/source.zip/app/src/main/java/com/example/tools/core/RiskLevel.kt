package com.example.tools.core

enum class RiskLevel {
    SAFE, MEDIUM, HIGH, CRITICAL
}
