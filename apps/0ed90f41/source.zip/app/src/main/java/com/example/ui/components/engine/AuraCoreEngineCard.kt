package com.example.ui.components.engine

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.glass.AuraGlassSurface
import com.example.ui.components.status.AuraStatusBadge
import com.example.ui.components.status.AuraStatusType
import com.example.ui.theme.AuraBorders
import com.example.ui.theme.AuraColors
import com.example.ui.theme.AuraDimensions
import com.example.ui.theme.AuraGlassLevel
import com.example.ui.theme.AuraMotion
import com.example.ui.theme.AuraShapes
import com.example.ui.theme.AuraSpacing
import com.example.ui.theme.AuraTypography

/**
 * AURA ASSISTANT — Phase 6: Core Engine States
 * Models the live AI intelligence pipeline lifecycle.
 */
enum class AuraCoreEngineState(
    val badgeLabel: String,
    val statusType: AuraStatusType,
    val isPulsing: Boolean,
    val defaultDescription: String
) {
    READY(
        badgeLabel = "READY",
        statusType = AuraStatusType.READY,
        isPulsing = true,
        defaultDescription = "AI intelligence pipeline connected & active"
    ),
    CONNECTING(
        badgeLabel = "CONNECTING",
        statusType = AuraStatusType.IDLE,
        isPulsing = true,
        defaultDescription = "Establishing real-time bidirectional stream..."
    ),
    PROCESSING(
        badgeLabel = "PROCESSING",
        statusType = AuraStatusType.ACTIVE,
        isPulsing = true,
        defaultDescription = "Generating real-time assistant response..."
    ),
    DISCONNECTED(
        badgeLabel = "DISCONNECTED",
        statusType = AuraStatusType.IDLE,
        isPulsing = false,
        defaultDescription = "Stream standby • Ready to connect"
    ),
    ERROR(
        badgeLabel = "ERROR",
        statusType = AuraStatusType.ERROR,
        isPulsing = false,
        defaultDescription = "Connection interrupted or pipeline error"
    ),
    UNAVAILABLE(
        badgeLabel = "UNAVAILABLE",
        statusType = AuraStatusType.IDLE,
        isPulsing = false,
        defaultDescription = "Core engine unavailable"
    )
}

/**
 * AURA ASSISTANT — Phase 6: Persistence / Storage States
 */
enum class AuraPersistenceState(
    val badgeLabel: String,
    val statusType: AuraStatusType,
    val isPulsing: Boolean,
    val defaultDescription: String
) {
    SYNCED(
        badgeLabel = "SYNCED",
        statusType = AuraStatusType.READY,
        isPulsing = false,
        defaultDescription = "Local SQLite database synchronized"
    ),
    ACTIVE(
        badgeLabel = "ACTIVE",
        statusType = AuraStatusType.ACTIVE,
        isPulsing = true,
        defaultDescription = "Reading/writing conversation transcripts"
    ),
    IDLE(
        badgeLabel = "IDLE",
        statusType = AuraStatusType.IDLE,
        isPulsing = false,
        defaultDescription = "Local storage standby"
    ),
    ERROR(
        badgeLabel = "ERROR",
        statusType = AuraStatusType.ERROR,
        isPulsing = false,
        defaultDescription = "Database I/O failure"
    ),
    UNAVAILABLE(
        badgeLabel = "UNAVAILABLE",
        statusType = AuraStatusType.IDLE,
        isPulsing = false,
        defaultDescription = "Persistence engine unavailable"
    )
}

/**
 * AURA ASSISTANT — Primary Core Engine Card (Phase 6)
 *
 * Monochrome smoked liquid glass surface presenting real-time AI pipeline status,
 * model/provider telemetry, latency metrics, and connection controls without visual clutter.
 */
@Composable
fun AuraCoreEngineCard(
    engineState: AuraCoreEngineState,
    provider: String,
    modelName: String,
    connectionText: String,
    latencyOrDuration: String,
    modifier: Modifier = Modifier,
    actionText: String? = null,
    actionEnabled: Boolean = true,
    onActionClick: (() -> Unit)? = null,
    errorMessage: String? = null,
    reducedMotion: Boolean = false
) {
    val talkBackDescription = "Core Engine. ${engineState.badgeLabel}. Provider: $provider. Model: $modelName. Connection: $connectionText. Latency: $latencyOrDuration."

    AuraGlassSurface(
        modifier = modifier
            .testTag("core_engine_card")
            .semantics(mergeDescendants = true) {
                contentDescription = talkBackDescription
            },
        shape = AuraShapes.Large,
        level = AuraGlassLevel.LEVEL_2,
        contentPadding = PaddingValues(18.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Header Row: Title & Technical Status Badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(
                    verticalArrangement = Arrangement.spacedBy(2.dp)
                ) {
                    Text(
                        text = "CORE ENGINE",
                        style = AuraTypography.SectionTitle.copy(
                            fontSize = 17.sp,
                            fontWeight = FontWeight.SemiBold,
                            letterSpacing = 0.5.sp
                        ),
                        color = AuraColors.TextPrimary
                    )
                    Text(
                        text = "AI processing pipeline",
                        style = AuraTypography.Caption.copy(
                            fontSize = 12.5.sp
                        ),
                        color = AuraColors.TextMuted
                    )
                }

                AuraStatusBadge(
                    label = engineState.badgeLabel,
                    type = engineState.statusType,
                    isPulsing = !reducedMotion && engineState.isPulsing,
                    modifier = Modifier.testTag("core_engine_status_badge")
                )
            }

            // Adaptive Metric Grid (2-column on narrow, 4-column on standard/expanded)
            AuraEngineMetricGrid(
                provider = provider,
                model = modelName,
                connection = connectionText,
                latency = latencyOrDuration
            )

            // Optional Engine Action Button (e.g. Connect / Reconnect / Disconnect)
            if (actionText != null && onActionClick != null) {
                AuraEngineActionButton(
                    text = actionText,
                    enabled = actionEnabled,
                    onClick = onActionClick,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("core_engine_action_button")
                )
            }

            // Error Banner if present
            AnimatedVisibility(
                visible = errorMessage != null,
                enter = fadeIn(),
                exit = fadeOut()
            ) {
                errorMessage?.let { err ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(AuraShapes.Small)
                            .background(AuraColors.GlassLevel1)
                            .border(
                                AuraBorders.WidthNormal,
                                AuraColors.StatusError.copy(alpha = 0.4f),
                                AuraShapes.Small
                            )
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Warning,
                            contentDescription = "Engine Error Alert",
                            tint = AuraColors.StatusError,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = "ERROR: $err",
                            style = AuraTypography.TechnicalMono.copy(fontSize = 11.sp),
                            color = AuraColors.StatusError,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }
    }
}

/**
 * AURA ASSISTANT — Secondary Persistence / Storage Card (Phase 6)
 *
 * Compact smoked glass card presenting local Room database and transcript memory status.
 */
@Composable
fun AuraPersistenceCard(
    persistenceState: AuraPersistenceState,
    storageEngine: String = "Room SQLite v1",
    historyCount: Int = 0,
    isEncrypted: Boolean = true,
    modifier: Modifier = Modifier,
    actionText: String? = null,
    onActionClick: (() -> Unit)? = null,
    reducedMotion: Boolean = false
) {
    val talkBackDescription = "Persistence. ${persistenceState.badgeLabel}. Engine: $storageEngine. Cache: $historyCount messages. Local Encrypted."

    AuraGlassSurface(
        modifier = modifier
            .testTag("persistence_card")
            .semantics(mergeDescendants = true) {
                contentDescription = talkBackDescription
            },
        shape = AuraShapes.Large,
        level = AuraGlassLevel.LEVEL_2,
        contentPadding = PaddingValues(18.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Header Row: Title & Status Badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(
                    verticalArrangement = Arrangement.spacedBy(2.dp)
                ) {
                    Text(
                        text = "PERSISTENCE",
                        style = AuraTypography.SectionTitle.copy(
                            fontSize = 17.sp,
                            fontWeight = FontWeight.SemiBold,
                            letterSpacing = 0.5.sp
                        ),
                        color = AuraColors.TextPrimary
                    )
                    Text(
                        text = "Local database & conversation storage",
                        style = AuraTypography.Caption.copy(
                            fontSize = 12.5.sp
                        ),
                        color = AuraColors.TextMuted
                    )
                }

                AuraStatusBadge(
                    label = persistenceState.badgeLabel,
                    type = persistenceState.statusType,
                    isPulsing = !reducedMotion && persistenceState.isPulsing,
                    modifier = Modifier.testTag("persistence_status_badge")
                )
            }

            // Compact 3-Cell Persistence Grid
            AuraPersistenceMetricGrid(
                engine = storageEngine,
                historyCount = historyCount,
                isEncrypted = isEncrypted
            )

            // Optional action (e.g. Configure / Clear cache)
            if (actionText != null && onActionClick != null) {
                AuraEngineActionButton(
                    text = actionText,
                    enabled = true,
                    onClick = onActionClick,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("persistence_action_button")
                )
            }
        }
    }
}

/**
 * Adaptive 2x2 or 1x4 Metric Grid for Core Engine
 */
@Composable
fun AuraEngineMetricGrid(
    provider: String,
    model: String,
    connection: String,
    latency: String,
    modifier: Modifier = Modifier
) {
    BoxWithConstraints(modifier = modifier.fillMaxWidth()) {
        val availableWidth = maxWidth
        val isNarrow = availableWidth < 540.dp

        if (isNarrow) {
            // 2 Rows of 2 Columns
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    AuraEngineMetricPill(
                        label = "PROVIDER",
                        value = provider,
                        modifier = Modifier.weight(1f)
                    )
                    AuraEngineMetricPill(
                        label = "MODEL",
                        value = model,
                        modifier = Modifier.weight(1f)
                    )
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    AuraEngineMetricPill(
                        label = "CONNECTION",
                        value = connection,
                        modifier = Modifier.weight(1f)
                    )
                    AuraEngineMetricPill(
                        label = "LATENCY",
                        value = latency,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        } else {
            // 1 Row of 4 Columns
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                AuraEngineMetricPill(
                    label = "PROVIDER",
                    value = provider,
                    modifier = Modifier.weight(1f)
                )
                AuraEngineMetricPill(
                    label = "MODEL",
                    value = model,
                    modifier = Modifier.weight(1f)
                )
                AuraEngineMetricPill(
                    label = "CONNECTION",
                    value = connection,
                    modifier = Modifier.weight(1f)
                )
                AuraEngineMetricPill(
                    label = "LATENCY",
                    value = latency,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

/**
 * Adaptive Metric Grid for Persistence
 */
@Composable
fun AuraPersistenceMetricGrid(
    engine: String,
    historyCount: Int,
    isEncrypted: Boolean,
    modifier: Modifier = Modifier
) {
    BoxWithConstraints(modifier = modifier.fillMaxWidth()) {
        val availableWidth = maxWidth
        val isNarrow = availableWidth < 540.dp

        if (isNarrow) {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    AuraEngineMetricPill(
                        label = "ENGINE",
                        value = engine,
                        modifier = Modifier.weight(1f)
                    )
                    AuraEngineMetricPill(
                        label = "STORED",
                        value = "$historyCount items",
                        modifier = Modifier.weight(1f)
                    )
                }
                AuraEngineMetricPill(
                    label = "SECURITY",
                    value = if (isEncrypted) "Local • Encrypted" else "Local Storage",
                    modifier = Modifier.fillMaxWidth()
                )
            }
        } else {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                AuraEngineMetricPill(
                    label = "ENGINE",
                    value = engine,
                    modifier = Modifier.weight(1.1f)
                )
                AuraEngineMetricPill(
                    label = "STORED",
                    value = "$historyCount items",
                    modifier = Modifier.weight(0.9f)
                )
                AuraEngineMetricPill(
                    label = "SECURITY",
                    value = if (isEncrypted) "Local Encrypted" else "Local Storage",
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

/**
 * Individual Smoked Glass Metric Pill
 */
@Composable
fun AuraEngineMetricPill(
    label: String,
    value: String,
    modifier: Modifier = Modifier
) {
    AuraGlassSurface(
        modifier = modifier,
        shape = AuraShapes.Small,
        level = AuraGlassLevel.LEVEL_1,
        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 9.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(3.dp),
            horizontalAlignment = Alignment.Start
        ) {
            Text(
                text = label.uppercase(),
                style = AuraTypography.TechnicalLabel.copy(
                    fontSize = 9.5.sp,
                    letterSpacing = 0.8.sp
                ),
                color = AuraColors.TextMuted,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = value,
                style = AuraTypography.TechnicalMono.copy(
                    fontSize = 12.5.sp,
                    fontWeight = FontWeight.SemiBold
                ),
                color = AuraColors.TextPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

/**
 * Tactile Monochrome Action Button for Engine & Persistence Controls
 * Minimum 48dp touch target with 42dp visual height.
 */
@Composable
fun AuraEngineActionButton(
    text: String,
    enabled: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()

    val scale by animateFloatAsState(
        targetValue = if (isPressed && enabled) AuraMotion.PressScalePressed else AuraMotion.PressScaleNormal,
        animationSpec = AuraMotion.PressSpring,
        label = "EngineBtnScale"
    )

    Box(
        modifier = modifier
            .defaultMinSize(minHeight = AuraDimensions.MinTouchTarget)
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            }
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                enabled = enabled,
                role = Role.Button,
                onClick = onClick
            )
            .semantics {
                role = Role.Button
            },
        contentAlignment = Alignment.Center
    ) {
        AuraGlassSurface(
            modifier = Modifier
                .fillMaxWidth()
                .height(42.dp),
            shape = AuraShapes.Medium,
            level = if (isPressed) AuraGlassLevel.ACTIVE else AuraGlassLevel.LEVEL_1,
            contentPadding = PaddingValues(horizontal = 16.dp)
        ) {
            Text(
                text = text.uppercase(),
                style = AuraTypography.ButtonLabel.copy(
                    fontSize = 12.sp,
                    letterSpacing = 1.sp,
                    fontWeight = FontWeight.Bold
                ),
                color = if (enabled) AuraColors.TextPrimary else AuraColors.TextMuted,
                modifier = Modifier.align(Alignment.Center)
            )
        }
    }
}
