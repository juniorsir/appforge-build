package com.example.capabilities.haptics

import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import com.example.capabilities.CapabilityResult
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

data class HapticsInfo(
    val hasVibrator: Boolean,
    val hasAmplitudeControl: Boolean
)

interface HapticsRepository {
    fun getHapticsInfo(): CapabilityResult<HapticsInfo>
    fun vibrateOneShot(durationMs: Long, amplitude: Int = VibrationEffect.DEFAULT_AMPLITUDE): CapabilityResult<Boolean>
    fun performHapticFeedback(effectType: String): CapabilityResult<Boolean>
}

@Singleton
class HapticsRepositoryImpl @Inject constructor(
    @ApplicationContext private val context: Context
) : HapticsRepository {

    private val vibrator: Vibrator? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
        vibratorManager?.defaultVibrator
    } else {
        @Suppress("DEPRECATION")
        context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
    }

    override fun getHapticsInfo(): CapabilityResult<HapticsInfo> {
        val vib = vibrator ?: return CapabilityResult.Success(HapticsInfo(hasVibrator = false, hasAmplitudeControl = false))
        val hasVib = vib.hasVibrator()
        val hasAmp = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) vib.hasAmplitudeControl() else false
        return CapabilityResult.Success(HapticsInfo(hasVibrator = hasVib, hasAmplitudeControl = hasAmp))
    }

    override fun vibrateOneShot(durationMs: Long, amplitude: Int): CapabilityResult<Boolean> {
        return try {
            val vib = vibrator ?: return CapabilityResult.Error("No vibrator available")
            if (!vib.hasVibrator()) return CapabilityResult.Error("Device does not support vibration")

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val safeAmp = if (vib.hasAmplitudeControl()) amplitude.coerceIn(1, 255) else VibrationEffect.DEFAULT_AMPLITUDE
                val effect = VibrationEffect.createOneShot(durationMs.coerceAtLeast(10L), safeAmp)
                vib.vibrate(effect)
            } else {
                @Suppress("DEPRECATION")
                vib.vibrate(durationMs.coerceAtLeast(10L))
            }
            CapabilityResult.Success(true)
        } catch (e: Exception) {
            CapabilityResult.Error("Vibration failed: ${e.message}", e)
        }
    }

    override fun performHapticFeedback(effectType: String): CapabilityResult<Boolean> {
        return try {
            val vib = vibrator ?: return CapabilityResult.Error("No vibrator available")
            if (!vib.hasVibrator()) return CapabilityResult.Error("Device does not support vibration")

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val effectId = when (effectType.uppercase()) {
                    "CLICK" -> VibrationEffect.EFFECT_CLICK
                    "DOUBLE_CLICK" -> VibrationEffect.EFFECT_DOUBLE_CLICK
                    "HEAVY_CLICK" -> VibrationEffect.EFFECT_HEAVY_CLICK
                    "TICK" -> VibrationEffect.EFFECT_TICK
                    else -> VibrationEffect.EFFECT_CLICK
                }
                vib.vibrate(VibrationEffect.createPredefined(effectId))
            } else {
                vibrateOneShot(30L)
            }
            CapabilityResult.Success(true)
        } catch (e: Exception) {
            CapabilityResult.Error("Haptic feedback failed: ${e.message}", e)
        }
    }
}
