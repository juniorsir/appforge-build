package com.example.ffmpeg

import android.content.Context
import android.net.Uri
import android.util.Log
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.FFmpegSession
import com.arthenica.ffmpegkit.ReturnCode
import com.example.media.MediaConversionRequest
import com.example.media.MediaConversionResult
import com.example.storage.MediaUriResolver
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

class FFmpegEngine(private val context: Context) {

    private val TAG = "FFmpegEngine"
    private val activeSessions = ConcurrentHashMap<String, FFmpegSession>()

    suspend fun execute(request: MediaConversionRequest, onProgress: ((Int) -> Unit)? = null): MediaConversionResult = withContext(Dispatchers.IO) {
        val inputUri = Uri.parse(request.inputUri)
        val resolvedInput = MediaUriResolver.resolveForFFmpeg(context, inputUri)
        
        val sessionId = UUID.randomUUID().toString()
        val outputFile = File(context.cacheDir, "out_$sessionId.mp4")

        try {
            val cmdBuilder = StringBuilder()
            // Auto-detect multi-core CPU threading for maximum processing speed
            cmdBuilder.append("-y -threads 0 -i \"${resolvedInput.path}\" ")

            if (request.videoCodec != null && request.videoCodec != "copy") {
                cmdBuilder.append("-c:v ${request.videoCodec} -preset ultrafast ")
            } else if (request.videoCodec != null) {
                cmdBuilder.append("-c:v ${request.videoCodec} ")
            } else {
                cmdBuilder.append("-c:v copy ")
            }

            if (request.audioCodec != null) {
                cmdBuilder.append("-c:a ${request.audioCodec} ")
            } else {
                cmdBuilder.append("-c:a copy ")
            }

            cmdBuilder.append("\"${outputFile.absolutePath}\"")

            val command = cmdBuilder.toString()
            Log.d(TAG, "Executing FFmpeg (Optimized Multi-thread): $command")

            val session = FFmpegKit.execute(command)
            activeSessions[sessionId] = session

            val returnCode = session.returnCode
            
            if (ReturnCode.isSuccess(returnCode)) {
                MediaConversionResult.Success(outputFile.absolutePath)
            } else if (ReturnCode.isCancel(returnCode)) {
                outputFile.delete()
                MediaConversionResult.Cancelled
            } else {
                outputFile.delete()
                MediaConversionResult.Failure("FFmpeg failed with return code $returnCode", session.allLogsAsString)
            }
        } catch (e: Exception) {
            Log.e(TAG, "FFmpeg execution exception", e)
            outputFile.delete()
            MediaConversionResult.Failure(e.message ?: "Unknown error", "")
        } finally {
            if (resolvedInput.isTemporary) {
                try { File(resolvedInput.path).delete() } catch (e: Exception) {}
            }
            activeSessions.remove(sessionId)
        }
    }
    
    fun cancelAll() {
        try {
            FFmpegKit.cancel()
        } catch (e: Exception) {
            Log.w(TAG, "Failed to cancel FFmpegKit sessions: ${e.message}")
        }
        activeSessions.clear()
    }
    
    suspend fun generateThumbnail(uri: Uri, timestamp: Double): String? = withContext(Dispatchers.IO) {
        val resolvedInput = MediaUriResolver.resolveForFFmpeg(context, uri)
        val thumbnailFile = File(context.cacheDir, "thumb_${UUID.randomUUID()}.jpg")
        
        try {
            // Fast seeking: -ss before -i ensures sub-second keyframe lookup without decoding entire file
            val cmd = "-y -threads 0 -ss $timestamp -i \"${resolvedInput.path}\" -vframes 1 -q:v 2 \"${thumbnailFile.absolutePath}\""
            val session = FFmpegKit.execute(cmd)
            
            if (ReturnCode.isSuccess(session.returnCode)) {
                thumbnailFile.absolutePath
            } else {
                thumbnailFile.delete()
                null
            }
        } catch(e: Exception) {
            thumbnailFile.delete()
            null
        } finally {
            if (resolvedInput.isTemporary) {
                try { File(resolvedInput.path).delete() } catch (e: Exception) {}
            }
        }
    }
    
    suspend fun trimVideo(
        uri: Uri,
        startSeconds: Double,
        durationSeconds: Double,
        exact: Boolean = false
    ): String? = withContext(Dispatchers.IO) {
        val resolvedInput = MediaUriResolver.resolveForFFmpeg(context, uri)
        val outputFile = File(context.cacheDir, "trim_${UUID.randomUUID()}.mp4")

        try {
            val cmd = if (exact) {
                "-y -threads 0 -ss $startSeconds -i \"${resolvedInput.path}\" -t $durationSeconds -c:v libx264 -preset ultrafast -c:a aac \"${outputFile.absolutePath}\""
            } else {
                "-y -threads 0 -ss $startSeconds -i \"${resolvedInput.path}\" -t $durationSeconds -c:v copy -c:a copy \"${outputFile.absolutePath}\""
            }
            Log.d(TAG, "Executing FFmpeg Trim: $cmd")
            val session = FFmpegKit.execute(cmd)

            if (ReturnCode.isSuccess(session.returnCode)) {
                outputFile.absolutePath
            } else {
                outputFile.delete()
                null
            }
        } catch (e: Exception) {
            Log.e(TAG, "Trim exception: ${e.message}", e)
            outputFile.delete()
            null
        } finally {
            if (resolvedInput.isTemporary) {
                try { File(resolvedInput.path).delete() } catch (e: Exception) {}
            }
        }
    }

    suspend fun generateGif(
        uri: Uri,
        startSeconds: Double,
        durationSeconds: Double,
        fps: Int = 15,
        width: Int = 480
    ): String? = withContext(Dispatchers.IO) {
        val resolvedInput = MediaUriResolver.resolveForFFmpeg(context, uri)
        val outputFile = File(context.cacheDir, "anim_${UUID.randomUUID()}.gif")

        try {
            val safeFps = fps.coerceIn(1, 30)
            val safeWidth = width.coerceIn(120, 1920)
            // Two-pass palettegen filter for crisp color rendering and minimal artifacting
            val filter = "fps=$safeFps,scale=$safeWidth:-1:flags=lanczos,split[s0][s1];[s0]palettegen=max_colors=128[p];[s1][p]paletteuse=dither=bayer"
            val cmd = "-y -threads 0 -ss $startSeconds -t $durationSeconds -i \"${resolvedInput.path}\" -vf \"$filter\" \"${outputFile.absolutePath}\""
            Log.d(TAG, "Executing FFmpeg GIF: $cmd")
            val session = FFmpegKit.execute(cmd)

            if (ReturnCode.isSuccess(session.returnCode)) {
                outputFile.absolutePath
            } else {
                outputFile.delete()
                null
            }
        } catch (e: Exception) {
            Log.e(TAG, "GIF generation exception: ${e.message}", e)
            outputFile.delete()
            null
        } finally {
            if (resolvedInput.isTemporary) {
                try { File(resolvedInput.path).delete() } catch (e: Exception) {}
            }
        }
    }

    suspend fun changeSpeed(
        uri: Uri,
        speedFactor: Double
    ): String? = withContext(Dispatchers.IO) {
        val resolvedInput = MediaUriResolver.resolveForFFmpeg(context, uri)
        val outputFile = File(context.cacheDir, "speed_${UUID.randomUUID()}.mp4")

        try {
            val safeSpeed = speedFactor.coerceIn(0.25, 4.0)
            val videoPts = 1.0 / safeSpeed
            val audioTempo = safeSpeed

            val filter = "setpts=${videoPts}*PTS"
            val audioFilter = if (audioTempo in 0.5..2.0) {
                "-filter:a \"atempo=$audioTempo\""
            } else if (audioTempo > 2.0) {
                "-filter:a \"atempo=2.0,atempo=${audioTempo / 2.0}\""
            } else {
                "-filter:a \"atempo=0.5,atempo=${audioTempo / 0.5}\""
            }

            val cmd = "-y -threads 0 -i \"${resolvedInput.path}\" -filter:v \"$filter\" $audioFilter -c:v libx264 -preset ultrafast -c:a aac \"${outputFile.absolutePath}\""
            Log.d(TAG, "Executing FFmpeg Speed: $cmd")
            val session = FFmpegKit.execute(cmd)

            if (ReturnCode.isSuccess(session.returnCode)) {
                outputFile.absolutePath
            } else {
                outputFile.delete()
                null
            }
        } catch (e: Exception) {
            Log.e(TAG, "Speed modification exception: ${e.message}", e)
            outputFile.delete()
            null
        } finally {
            if (resolvedInput.isTemporary) {
                try { File(resolvedInput.path).delete() } catch (e: Exception) {}
            }
        }
    }

    suspend fun muteVideo(uri: Uri): String? = withContext(Dispatchers.IO) {
        val resolvedInput = MediaUriResolver.resolveForFFmpeg(context, uri)
        val outputFile = File(context.cacheDir, "mute_${UUID.randomUUID()}.mp4")

        try {
            val cmd = "-y -threads 0 -i \"${resolvedInput.path}\" -an -c:v copy \"${outputFile.absolutePath}\""
            Log.d(TAG, "Executing FFmpeg Mute: $cmd")
            val session = FFmpegKit.execute(cmd)

            if (ReturnCode.isSuccess(session.returnCode)) {
                outputFile.absolutePath
            } else {
                outputFile.delete()
                null
            }
        } catch (e: Exception) {
            Log.e(TAG, "Mute exception: ${e.message}", e)
            outputFile.delete()
            null
        } finally {
            if (resolvedInput.isTemporary) {
                try { File(resolvedInput.path).delete() } catch (e: Exception) {}
            }
        }
    }

    suspend fun extractAudio(uri: Uri, outputFormat: String = "mp3"): String? = withContext(Dispatchers.IO) {
        val resolvedInput = MediaUriResolver.resolveForFFmpeg(context, uri)
        val outputFile = File(context.cacheDir, "audio_${UUID.randomUUID()}.$outputFormat")
        
        try {
            val cmd = "-y -threads 0 -i \"${resolvedInput.path}\" -vn -c:a copy \"${outputFile.absolutePath}\""
            val session = FFmpegKit.execute(cmd)
            
            if (ReturnCode.isSuccess(session.returnCode)) {
                outputFile.absolutePath
            } else {
                outputFile.delete()
                null
            }
        } catch(e: Exception) {
            outputFile.delete()
            null
        } finally {
            if (resolvedInput.isTemporary) {
                try { File(resolvedInput.path).delete() } catch (e: Exception) {}
            }
        }
    }
}

