package com.example.domain.repository

import com.example.domain.model.ChatMessage
import com.example.domain.model.CompanionConfig
import com.example.domain.model.SessionState
import kotlinx.coroutines.flow.Flow

/**
 * Domain Repository Interface representing the contract for accessing and modifying
 * AI Companion data sources (local databases, real-time WebSocket streams, settings).
 */
interface CompanionRepository {
    
    // Companion Configuration
    fun getCompanionConfig(): Flow<CompanionConfig>
    suspend fun saveCompanionConfig(config: CompanionConfig)
    
    // Conversation & History
    fun getSessionHistory(): Flow<List<ChatMessage>>
    suspend fun addChatMessage(message: ChatMessage)
    suspend fun clearSessionHistory()
    
    // Live Stream Connection States
    fun getSessionState(): Flow<SessionState>
    suspend fun updateSessionState(state: SessionState)
    
    // WebSocket Control APIs (Stubs for phase 2 streaming)
    suspend fun connectStream()
    suspend fun disconnectStream()
    suspend fun sendStreamMessage(text: String)
}
