package com.example.ui.components.voice

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.VideocamOff
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.glass.AuraGlassSurface
import com.example.ui.theme.AuraBorders
import com.example.ui.theme.AuraColors
import com.example.ui.theme.AuraGlassLevel

/**
 * States for the secondary Microphone control.
 */
enum class AuraMicState {
    ENABLED,
    MUTED,
    UNAVAILABLE
}

/**
 * States for the secondary Video/Camera control.
 */
enum class AuraVideoState {
    ENABLED,
    DISABLED,
    UNAVAILABLE
}

/**
 * AURA MEDIA CONTROLS — Bottom Control Dock
 *
 * Dedicated bottom hardware-style control bar housing the MIC and CAM toggles.
 * Formatted as a full-width bottom section matching the card content width,
 * built with near-black glass, subtle white border, and soft internal contrast.
 *
 * Specifications:
 * - Container height: 96dp (within 88-120dp)
 * - Container width: matches content cards width
 * - Corner radius: 26dp (within 24-30dp)
 * - Divider: 1dp low-alpha white divider
 * - Control buttons: 110-150dp width, 60dp height, corner radius 18dp (within 16-22dp)
 * - Icons: 22dp monochrome white/light gray
 * - Labels: MIC / CAM (12sp semi-bold) + ON / OFF (10sp medium)
 */
@Composable
fun AuraMediaControls(
    micState: AuraMicState,
    videoState: AuraVideoState,
    onMicClick: () -> Unit,
    onVideoClick: () -> Unit,
    modifier: Modifier = Modifier,
    reducedMotion: Boolean = false
) {
    AuraGlassSurface(
        modifier = modifier
            .fillMaxWidth()
            .height(96.dp)
            .clip(RoundedCornerShape(26.dp))
            .testTag("aura_media_controls"),
        shape = RoundedCornerShape(26.dp),
        level = AuraGlassLevel.LEVEL_1,
        borderWidth = AuraBorders.WidthNormal,
        showHighlight = false
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            // Left Control: Microphone
            AuraMicControl(
                state = micState,
                onClick = onMicClick,
                reducedMotion = reducedMotion,
                modifier = Modifier
                    .weight(1f, fill = false)
                    .widthIn(min = 110.dp, max = 150.dp)
            )

            // Subtle 1dp low-alpha vertical divider: [ MIC | CAM ]
            Box(
                modifier = Modifier
                    .padding(horizontal = 14.dp)
                    .width(1.dp)
                    .height(36.dp)
                    .background(AuraColors.White.copy(alpha = 0.08f))
            )

            // Right Control: Camera
            AuraVideoControl(
                state = videoState,
                onClick = onVideoClick,
                reducedMotion = reducedMotion,
                modifier = Modifier
                    .weight(1f, fill = false)
                    .widthIn(min = 110.dp, max = 150.dp)
            )
        }
    }
}

/**
 * Secondary Microphone Control button.
 */
@Composable
fun AuraMicControl(
    state: AuraMicState,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    reducedMotion: Boolean = false
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()

    // Phase 9 press interaction: 0.98 scale, 120ms press / 160ms release
    val pressScale by animateFloatAsState(
        targetValue = if (isPressed && !reducedMotion) 0.98f else 1.0f,
        animationSpec = tween(durationMillis = if (isPressed) 120 else 160),
        label = "MicPressScale"
    )

    val isMuted = state == AuraMicState.MUTED
    val isEnabled = state == AuraMicState.ENABLED
    val isUnavailable = state == AuraMicState.UNAVAILABLE

    val iconAlpha by animateFloatAsState(
        targetValue = when {
            isUnavailable -> 0.35f
            isMuted -> 0.50f
            else -> 1.0f
        },
        animationSpec = tween(200),
        label = "MicIconAlpha"
    )

    val surfaceLevel = when {
        isPressed -> AuraGlassLevel.ACTIVE
        isEnabled -> AuraGlassLevel.LEVEL_2
        else -> AuraGlassLevel.LEVEL_1
    }

    val semanticsDescription = when (state) {
        AuraMicState.ENABLED -> "Microphone on. Tap to mute"
        AuraMicState.MUTED -> "Microphone muted. Tap to unmute"
        AuraMicState.UNAVAILABLE -> "Microphone unavailable"
    }

    Box(
        modifier = modifier
            .defaultMinSize(minWidth = 48.dp, minHeight = 48.dp)
            .height(60.dp)
            .scale(pressScale)
            .clip(RoundedCornerShape(18.dp))
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                role = Role.Button,
                enabled = !isUnavailable,
                onClick = onClick
            )
            .semantics {
                role = Role.Button
                contentDescription = semanticsDescription
            }
            .testTag("mic_control"),
        contentAlignment = Alignment.Center
    ) {
        AuraGlassSurface(
            modifier = Modifier
                .fillMaxSize()
                .clip(RoundedCornerShape(18.dp)),
            shape = RoundedCornerShape(18.dp),
            level = surfaceLevel,
            borderWidth = AuraBorders.WidthNormal,
            customBorderAlpha = if (isEnabled) 0.14f else 0.06f
        ) {
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 14.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = if (isMuted || isUnavailable) Icons.Default.MicOff else Icons.Default.Mic,
                    contentDescription = null, // Handled by parent semantics
                    tint = AuraColors.TextPrimary.copy(alpha = iconAlpha),
                    modifier = Modifier.size(22.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Column(
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.Start
                ) {
                    Text(
                        text = "MIC",
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            letterSpacing = 1.sp,
                            color = AuraColors.TextPrimary.copy(alpha = if (isUnavailable) 0.40f else 0.90f)
                        )
                    )
                    Text(
                        text = when (state) {
                            AuraMicState.ENABLED -> "ON"
                            AuraMicState.MUTED -> "OFF"
                            AuraMicState.UNAVAILABLE -> "N/A"
                        },
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Medium,
                            letterSpacing = 0.5.sp,
                            color = when (state) {
                                AuraMicState.ENABLED -> AuraColors.StatusReady
                                AuraMicState.MUTED -> AuraColors.TextMuted
                                AuraMicState.UNAVAILABLE -> AuraColors.TextMuted.copy(alpha = 0.5f)
                            }
                        )
                    )
                }
            }
        }
    }
}

/**
 * Secondary Video/Camera Control button.
 */
@Composable
fun AuraVideoControl(
    state: AuraVideoState,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    reducedMotion: Boolean = false
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()

    val pressScale by animateFloatAsState(
        targetValue = if (isPressed && !reducedMotion) 0.98f else 1.0f,
        animationSpec = tween(durationMillis = if (isPressed) 120 else 160),
        label = "VideoPressScale"
    )

    val isEnabled = state == AuraVideoState.ENABLED
    val isUnavailable = state == AuraVideoState.UNAVAILABLE

    val iconAlpha by animateFloatAsState(
        targetValue = when {
            isUnavailable -> 0.35f
            !isEnabled -> 0.50f
            else -> 1.0f
        },
        animationSpec = tween(200),
        label = "VideoIconAlpha"
    )

    val surfaceLevel = when {
        isPressed -> AuraGlassLevel.ACTIVE
        isEnabled -> AuraGlassLevel.LEVEL_2
        else -> AuraGlassLevel.LEVEL_1
    }

    val semanticsDescription = when (state) {
        AuraVideoState.ENABLED -> "Camera on. Tap to turn off"
        AuraVideoState.DISABLED -> "Camera off. Tap to turn on"
        AuraVideoState.UNAVAILABLE -> "Camera unavailable"
    }

    Box(
        modifier = modifier
            .defaultMinSize(minWidth = 48.dp, minHeight = 48.dp)
            .height(60.dp)
            .scale(pressScale)
            .clip(RoundedCornerShape(18.dp))
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                role = Role.Button,
                enabled = !isUnavailable,
                onClick = onClick
            )
            .semantics {
                role = Role.Button
                contentDescription = semanticsDescription
            }
            .testTag("video_control")
            .testTag("camera_toggle_secondary"),
        contentAlignment = Alignment.Center
    ) {
        AuraGlassSurface(
            modifier = Modifier
                .fillMaxSize()
                .clip(RoundedCornerShape(18.dp)),
            shape = RoundedCornerShape(18.dp),
            level = surfaceLevel,
            borderWidth = AuraBorders.WidthNormal,
            customBorderAlpha = if (isEnabled) 0.14f else 0.06f
        ) {
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 14.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = if (isEnabled) Icons.Default.Videocam else Icons.Default.VideocamOff,
                    contentDescription = null, // Handled by parent semantics
                    tint = AuraColors.TextPrimary.copy(alpha = iconAlpha),
                    modifier = Modifier.size(22.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Column(
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.Start
                ) {
                    Text(
                        text = "CAM",
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            letterSpacing = 1.sp,
                            color = AuraColors.TextPrimary.copy(alpha = if (isUnavailable) 0.40f else 0.90f)
                        )
                    )
                    Text(
                        text = when (state) {
                            AuraVideoState.ENABLED -> "ON"
                            AuraVideoState.DISABLED -> "OFF"
                            AuraVideoState.UNAVAILABLE -> "N/A"
                        },
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Medium,
                            letterSpacing = 0.5.sp,
                            color = when (state) {
                                AuraVideoState.ENABLED -> AuraColors.StatusReady
                                AuraVideoState.DISABLED -> AuraColors.TextMuted
                                AuraVideoState.UNAVAILABLE -> AuraColors.TextMuted.copy(alpha = 0.5f)
                            }
                        )
                    )
                }
            }
        }
    }
}
