package com.example.data.repository

import com.example.domain.model.NetworkMessage
import com.example.domain.model.PingMessage
import com.example.domain.model.PongMessage
import com.example.domain.model.SessionState
import com.example.domain.repository.WebSocketRepository
import com.example.util.AppLogger
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.serialization.json.Json
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import java.util.concurrent.ConcurrentLinkedQueue

class WebSocketRepositoryImpl(
    private val client: OkHttpClient,
    private val logger: AppLogger,
    private val scope: CoroutineScope
) : WebSocketRepository {

    private val tag = "WebSocketRepository"

    private val json = Json {
        ignoreUnknownKeys = true
        classDiscriminator = "type"
    }

    private var webSocket: WebSocket? = null
    private var activeUrl: String? = null
    private var isUserDisconnected = true

    // State Flows
    private val _connectionState = MutableStateFlow(SessionState.ConnectionState.DISCONNECTED)
    override val connectionState: StateFlow<SessionState.ConnectionState> = _connectionState.asStateFlow()

    private val _incomingMessages = MutableSharedFlow<NetworkMessage>()
    override val incomingMessages: SharedFlow<NetworkMessage> = _incomingMessages.asSharedFlow()

    private val _incomingRawMessages = MutableSharedFlow<String>()
    override val incomingRawMessages: SharedFlow<String> = _incomingRawMessages.asSharedFlow()

    private val _latencyMs = MutableStateFlow(0L)
    override val latencyMs: StateFlow<Long> = _latencyMs.asStateFlow()

    private val _bytesSent = MutableStateFlow(0L)
    override val bytesSent: StateFlow<Long> = _bytesSent.asStateFlow()

    private val _bytesReceived = MutableStateFlow(0L)
    override val bytesReceived: StateFlow<Long> = _bytesReceived.asStateFlow()

    private val _queueSize = MutableStateFlow(0)
    override val queueSize: StateFlow<Int> = _queueSize.asStateFlow()

    private val _retryCount = MutableStateFlow(0)
    override val retryCount: StateFlow<Int> = _retryCount.asStateFlow()

    private val _connectionLogs = MutableStateFlow<List<String>>(emptyList())
    override val connectionLogs: StateFlow<List<String>> = _connectionLogs.asStateFlow()

    private val _lastFailureReason = MutableStateFlow<String?>(null)
    override val lastFailureReason: StateFlow<String?> = _lastFailureReason.asStateFlow()

    private val _sessionId = MutableStateFlow<String?>(null)
    override val sessionId: StateFlow<String?> = _sessionId.asStateFlow()

    private val _lastConnectedAt = MutableStateFlow<Long?>(null)
    override val lastConnectedAt: StateFlow<Long?> = _lastConnectedAt.asStateFlow()

    private val _activeUrlFlow = MutableStateFlow("ws://127.0.0.1:8000/ws")
    override val activeUrlFlow: StateFlow<String> = _activeUrlFlow.asStateFlow()

    // Offline Queue
    private val messageQueue = ConcurrentLinkedQueue<NetworkMessage>()

    // Background Jobs
    private var heartbeatJob: Job? = null
    private var reconnectJob: Job? = null

    // Latency Tracking variables
    private var lastPingId: String? = null
    private var lastPingTimestamp = 0L

    // Date formatter for local diagnostics logging
    private val timeFormat = SimpleDateFormat("HH:mm:ss.SSS", Locale.US)

    override suspend fun connect(url: String) {
        isUserDisconnected = false
        activeUrl = url
        _activeUrlFlow.value = url
        reconnectJob?.cancel()
        _lastFailureReason.value = null
        
        if (_connectionState.value == SessionState.ConnectionState.CONNECTED ||
            _connectionState.value == SessionState.ConnectionState.CONNECTING ||
            _connectionState.value == SessionState.ConnectionState.AUTHENTICATING) {
            addLog("Connection request ignored: Already ${_connectionState.value}")
            return
        }

        establishConnection(url)
    }

    private fun establishConnection(url: String) {
        addLog("Initiating connection to $url")
        _connectionState.value = SessionState.ConnectionState.CONNECTING

        val request = Request.Builder()
            .url(url)
            .build()

        webSocket = client.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                _connectionState.value = SessionState.ConnectionState.AUTHENTICATING
                _lastFailureReason.value = null
                addLog("WebSocket Opened. Authenticating session with Termux AIOS...")
                logger.i(tag, "WebSocket Opened: $url - Authenticating...")

                // Send HELLO packet to initiate authenticated session
                val hello = com.example.domain.model.HelloMessage(
                    timestamp = System.currentTimeMillis(),
                    sessionId = _sessionId.value ?: UUID.randomUUID().toString(),
                    clientName = "CompanionAndroid",
                    deviceId = "android-localhost-bridge",
                    protocolVersion = "1.0.0"
                )
                sendActual(hello)

                // Start periodic Ping heartbeats
                startHeartbeat()

                // Resend queued offline messages
                flushQueue()
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                scope.launch {
                    try {
                        val len = text.toByteArray(Charsets.UTF_8).size.toLong()
                        _bytesReceived.value += len

                        val rootObj = try { org.json.JSONObject(text) } catch (e: Exception) { null }
                        val type = rootObj?.optString("type", "") ?: ""

                        // If we are AUTHENTICATING, transition to CONNECTED on incoming message
                        if (_connectionState.value == SessionState.ConnectionState.AUTHENTICATING) {
                            _connectionState.value = SessionState.ConnectionState.CONNECTED
                            _retryCount.value = 0
                            _lastConnectedAt.value = System.currentTimeMillis()
                            val sess = rootObj?.optString("sessionId", "session-" + System.currentTimeMillis()) ?: "session"
                            _sessionId.value = sess
                            addLog("Session Authenticated! SessionId: $sess")
                        }

                        // Always emit raw text to incomingRawMessages for ACAgent and dynamic relay handlers
                        _incomingRawMessages.emit(text)

                        // Attempt typed deserialization
                        var parsedMessage: NetworkMessage? = null
                        try {
                            parsedMessage = json.decodeFromString(NetworkMessage.serializer(), text)
                        } catch (e: Exception) {
                            // If typed decode failed, synthesize an AiStreamMessage if type is AI_STREAM
                            if (type.equals("AI_STREAM", ignoreCase = true) && rootObj != null) {
                                val act = if (rootObj.has("action")) rootObj.optString("action") else null
                                val txt = rootObj.optString("textChunk", rootObj.optString("text", rootObj.optString("message", "")))
                                val isFin = rootObj.optBoolean("isFinal", true)
                                val ts = rootObj.optLong("timestamp", System.currentTimeMillis())
                                val sId = rootObj.optString("sessionId", "ai-stream")
                                parsedMessage = com.example.domain.model.AiStreamMessage(
                                    timestamp = ts,
                                    sessionId = sId,
                                    textChunk = txt,
                                    isFinal = isFin,
                                    action = act,
                                    rawJson = text
                                )
                            }
                        }

                        if (parsedMessage != null) {
                            // Handle PONG specifically to compute round-trip latency
                            if (parsedMessage is PongMessage) {
                                if (parsedMessage.pingId == lastPingId) {
                                    val rtt = System.currentTimeMillis() - lastPingTimestamp
                                    _latencyMs.value = rtt
                                    addLog("HEARTBEAT PONG: latency=${rtt}ms")
                                }
                            } else {
                                addLog("RECV [${parsedMessage::class.simpleName ?: "Packet"}]")
                            }

                            _incomingMessages.emit(parsedMessage)
                        } else {
                            addLog("RECV RAW [type=$type, action=${rootObj?.optString("action")}]")
                        }
                    } catch (e: Exception) {
                        logger.e(tag, "Failed parsing JSON packet: ${e.message}", e)
                        addLog("PARSE ERROR: Failed parsing packet. ${e.message}")
                    }
                }
            }

            override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
                addLog("Server closing connection. Code: $code, Reason: $reason")
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                _connectionState.value = SessionState.ConnectionState.DISCONNECTED
                addLog("Connection closed. Code: $code")
                stopHeartbeat()
                handleUnexpectedDisconnect()
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                val failureDetail = when {
                    response != null -> "HTTP ${response.code} ${response.message}".trim()
                    t is java.net.ConnectException -> "Connection refused: Termux server is not listening on port 8000"
                    t is java.net.UnknownServiceException -> "Cleartext HTTP/WS not permitted: ${t.message}"
                    t is java.net.SocketTimeoutException -> "Connection timeout connecting to socket (${t.message})"
                    t is java.net.UnknownHostException -> "Unknown host (${t.message})"
                    t is java.net.ProtocolException -> "WebSocket handshake failed: ${t.message}"
                    t is java.net.SocketException && t.message?.contains("reset", ignoreCase = true) == true -> "Connection reset by peer (${t.message})"
                    else -> "${t.javaClass.simpleName}: ${t.localizedMessage ?: t.message ?: "Socket failure"}"
                }
                _lastFailureReason.value = failureDetail
                _connectionState.value = SessionState.ConnectionState.ERROR
                addLog("CRITICAL: Socket failure - $failureDetail")
                logger.e(tag, "Socket failure: $failureDetail", t)
                stopHeartbeat()
                handleUnexpectedDisconnect()
            }
        })
    }

    override suspend fun disconnect() {
        isUserDisconnected = true
        activeUrl = null
        reconnectJob?.cancel()
        stopHeartbeat()
        
        webSocket?.close(1000, "User disconnected")
        webSocket = null
        _connectionState.value = SessionState.ConnectionState.DISCONNECTED
        addLog("User triggered Manual Disconnect.")
    }

    override suspend fun sendMessage(message: NetworkMessage) {
        if (!message.validate()) {
            addLog("VALIDATION ERROR: Blocked invalid ${message.type} packet")
            return
        }

        if (_connectionState.value != SessionState.ConnectionState.CONNECTED) {
            // Queue messages while disconnected
            messageQueue.add(message)
            _queueSize.value = messageQueue.size
            addLog("OFFLINE: Queued ${message.type} packet in buffer.")
            return
        }

        sendActual(message)
    }

    override suspend fun sendRaw(text: String): Boolean {
        val ws = webSocket
        return if (ws != null && _connectionState.value == SessionState.ConnectionState.CONNECTED) {
            val ok = ws.send(text)
            if (ok) {
                _bytesSent.value += text.toByteArray(Charsets.UTF_8).size.toLong()
            }
            ok
        } else {
            false
        }
    }

    private fun sendActual(message: NetworkMessage): Boolean {
        return try {
            val jsonStr = json.encodeToString(NetworkMessage.serializer(), message)
            val isSuccess = webSocket?.send(jsonStr) ?: false
            if (isSuccess) {
                val packetBytes = jsonStr.toByteArray(Charsets.UTF_8).size.toLong()
                _bytesSent.value += packetBytes
                if (message !is PingMessage) {
                    addLog("SENT: ${message.type} packet (${packetBytes} B)")
                }
            } else {
                addLog("FAILED SEND: WebSocket send buffer rejected packet")
            }
            isSuccess
        } catch (e: Exception) {
            addLog("FAILED SEND: ${e.localizedMessage}")
            false
        }
    }

    private fun flushQueue() {
        scope.launch(Dispatchers.Default) {
            if (messageQueue.isEmpty()) return@launch
            addLog("ONLINE: Reconnected! Flushing ${messageQueue.size} queued packets...")
            
            while (connectionState.value == SessionState.ConnectionState.CONNECTED && !messageQueue.isEmpty()) {
                val nextMsg = messageQueue.peek() ?: break
                val success = sendActual(nextMsg)
                if (success) {
                    messageQueue.poll()
                    _queueSize.value = messageQueue.size
                } else {
                    addLog("FLUSH ABORT: Interrupted during drain. Retrying later.")
                    break
                }
            }
        }
    }

    private fun handleUnexpectedDisconnect() {
        if (isUserDisconnected || activeUrl == null) return

        reconnectJob?.cancel()
        _connectionState.value = SessionState.ConnectionState.RECONNECTING
        reconnectJob = scope.launch(Dispatchers.Default) {
            val retries = _retryCount.value + 1
            _retryCount.value = retries
            val backoffMs = calculateExponentialBackoff(retries)
            
            addLog("RECONNECTING: Waiting ${backoffMs / 1000}s (Retry #$retries)...")
            delay(backoffMs)

            if (!isUserDisconnected && activeUrl != null) {
                establishConnection(activeUrl!!)
            }
        }
    }

    private fun calculateExponentialBackoff(attempt: Int): Long {
        return when (attempt) {
            1 -> 1000L   // 1s
            2 -> 2000L   // 2s
            3 -> 4000L   // 4s
            4 -> 8000L   // 8s
            5 -> 16000L  // 16s
            else -> 30000L // 30s maximum
        }
    }

    private fun startHeartbeat() {
        heartbeatJob?.cancel()
        heartbeatJob = scope.launch(Dispatchers.Default) {
            while (_connectionState.value == SessionState.ConnectionState.CONNECTED) {
                delay(5000) // Heartbeat check every 5 seconds
                if (_connectionState.value == SessionState.ConnectionState.CONNECTED) {
                    val pingId = UUID.randomUUID().toString()
                    lastPingId = pingId
                    lastPingTimestamp = System.currentTimeMillis()

                    val ping = PingMessage(
                        timestamp = lastPingTimestamp,
                        sessionId = "heartbeat-session",
                        pingId = pingId
                    )
                    sendActual(ping)
                }
            }
        }
    }

    private fun stopHeartbeat() {
        heartbeatJob?.cancel()
        heartbeatJob = null
    }

    override fun clearLogs() {
        _connectionLogs.value = emptyList()
    }

    override fun addLog(entry: String) {
        val timeStamp = timeFormat.format(Date())
        val formatted = "[$timeStamp] $entry"
        val current = _connectionLogs.value.toMutableList()
        current.add(0, formatted) // Prepend to show latest log at the top
        if (current.size > 200) {
            current.removeAt(current.size - 1) // Cap log limit at 200 elements
        }
        _connectionLogs.value = current
    }
}
