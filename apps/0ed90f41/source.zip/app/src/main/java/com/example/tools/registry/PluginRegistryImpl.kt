package com.example.tools.registry

import com.example.tools.plugins.Plugin
import com.example.tools.repository.PluginRegistryRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class PluginRegistryImpl @Inject constructor() : PluginRegistryRepository {
    private val _plugins = MutableStateFlow<Map<String, Plugin>>(emptyMap())

    override fun getPlugins(): Flow<List<Plugin>> {
        return _plugins.map { it.values.toList() }
    }

    override suspend fun registerPlugin(plugin: Plugin): Boolean {
        val current = _plugins.value.toMutableMap()
        current[plugin.manifest.pluginId] = plugin
        _plugins.value = current
        return true
    }

    override suspend fun unregisterPlugin(pluginId: String): Boolean {
        val current = _plugins.value.toMutableMap()
        val removed = current.remove(pluginId)
        if (removed != null) {
            _plugins.value = current
            return true
        }
        return false
    }

    override suspend fun getPluginById(pluginId: String): Plugin? {
        return _plugins.value[pluginId]
    }
}
