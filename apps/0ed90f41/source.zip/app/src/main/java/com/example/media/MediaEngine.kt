package com.example.media

import android.content.Context
import android.net.Uri
import com.example.ffmpeg.FFmpegDiagnostics
import com.example.ffmpeg.FFmpegEngine
import com.example.ffmpeg.MediaProbe
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class MediaEngine(private val context: Context) {
    
    private val ffmpegEngine = FFmpegEngine(context)

    suspend fun initialize(): FFmpegDiagnostics.DiagnosticResult {
        return FFmpegDiagnostics.runSelfTest(context)
    }

    suspend fun probe(uri: Uri): MediaInfo? {
        return MediaProbe.probe(context, uri)
    }

    suspend fun remux(inputUri: Uri): MediaConversionResult {
        val request = MediaConversionRequest(
            inputUri = inputUri.toString(),
            outputUri = "", // Resolved in engine
            videoCodec = "copy",
            audioCodec = "copy"
        )
        return ffmpegEngine.execute(request)
    }

    suspend fun transcode(request: MediaConversionRequest, onProgress: ((Int) -> Unit)? = null): MediaConversionResult {
        return ffmpegEngine.execute(request, onProgress)
    }

    suspend fun generateThumbnail(uri: Uri, timestamp: Double): String? {
        return ffmpegEngine.generateThumbnail(uri, timestamp)
    }

    suspend fun extractAudio(uri: Uri): String? {
        return ffmpegEngine.extractAudio(uri)
    }

    suspend fun trimVideo(uri: Uri, startSeconds: Double, durationSeconds: Double, exact: Boolean = false): String? {
        return ffmpegEngine.trimVideo(uri, startSeconds, durationSeconds, exact)
    }

    suspend fun generateGif(uri: Uri, startSeconds: Double, durationSeconds: Double, fps: Int = 15, width: Int = 480): String? {
        return ffmpegEngine.generateGif(uri, startSeconds, durationSeconds, fps, width)
    }

    suspend fun changeSpeed(uri: Uri, speedFactor: Double): String? {
        return ffmpegEngine.changeSpeed(uri, speedFactor)
    }

    suspend fun muteVideo(uri: Uri): String? {
        return ffmpegEngine.muteVideo(uri)
    }

    fun cancelAll() {
        ffmpegEngine.cancelAll()
    }
}
