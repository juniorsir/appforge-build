package com.example.aios.core

enum class AgentState {
    IDLE, BUSY, OFFLINE, ERROR
}

enum class HealthStatus {
    HEALTHY, WARNING, CRITICAL
}
