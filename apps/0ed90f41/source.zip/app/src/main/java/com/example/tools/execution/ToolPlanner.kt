package com.example.tools.execution

import com.example.tools.core.Tool
import com.example.tools.repository.ToolRegistryRepository
import javax.inject.Inject
import javax.inject.Singleton

data class PlannedExecution(
    val tool: Tool,
    val params: Map<String, Any>,
    val requiresConfirmation: Boolean,
    val estimatedTimeMs: Long
)

@Singleton
class ToolPlanner @Inject constructor(
    private val toolRegistry: ToolRegistryRepository,
    private val riskAnalyzer: RiskAnalyzer
) {
    suspend fun plan(toolId: String, params: Map<String, Any>): PlannedExecution? {
        val tool = toolRegistry.getToolById(toolId) ?: return null
        
        val requiresConfirmation = riskAnalyzer.requiresConfirmation(tool)
        
        return PlannedExecution(
            tool = tool,
            params = params,
            requiresConfirmation = requiresConfirmation,
            estimatedTimeMs = tool.timeoutMs
        )
    }
}
