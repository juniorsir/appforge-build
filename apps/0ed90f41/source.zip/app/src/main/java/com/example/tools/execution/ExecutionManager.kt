package com.example.tools.execution

import com.example.tools.core.ToolContext
import com.example.tools.core.ToolResult
import com.example.tools.repository.ExecutionHistoryRepository
import com.example.tools.repository.ExecutionLog
import kotlinx.coroutines.withTimeoutOrNull
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ExecutionManager @Inject constructor(
    private val planner: ToolPlanner,
    private val permissionValidator: PermissionValidator,
    private val riskAnalyzer: RiskAnalyzer,
    private val confirmationManager: ConfirmationManager,
    private val resultValidator: ResultValidator,
    private val historyRepository: ExecutionHistoryRepository
) {
    suspend fun execute(toolId: String, params: Map<String, Any>, context: ToolContext? = null): ToolResult {
        val executionId = UUID.randomUUID().toString()
        val currentContext = context ?: ToolContext(
            conversationId = "sys_internal",
            sessionId = "sys_internal",
            executionId = executionId
        )

        val start = System.currentTimeMillis()
        val plan = planner.plan(toolId, params)
        if (plan == null) {
            return logAndReturn(executionId, toolId, params, start, ToolResult.ValidationFailed("Tool not found: $toolId"))
        }

        val missingPermissions = permissionValidator.validatePermissions(plan.tool)
        if (missingPermissions.isNotEmpty()) {
            return logAndReturn(executionId, toolId, params, start, ToolResult.ValidationFailed("Missing permissions: $missingPermissions"))
        }

        if (!riskAnalyzer.isAllowed(plan.tool)) {
            return logAndReturn(executionId, toolId, params, start, ToolResult.ValidationFailed("Tool execution blocked by risk analyzer"))
        }

        if (plan.requiresConfirmation) {
            val confirmed = confirmationManager.requestConfirmation(executionId, plan.tool, params)
            if (!confirmed) {
                return logAndReturn(executionId, toolId, params, start, ToolResult.RequiresConfirmation(executionId))
            }
        }

        val initSuccess = plan.tool.initialize()
        if (!initSuccess) {
            return logAndReturn(executionId, toolId, params, start, ToolResult.Failure("Tool failed to initialize"))
        }

        val validParams = plan.tool.validateInput(params)
        if (!validParams) {
            return logAndReturn(executionId, toolId, params, start, ToolResult.ValidationFailed("Invalid parameters for tool"))
        }

        val rawResult = try {
            withTimeoutOrNull(plan.tool.timeoutMs) {
                plan.tool.execute(currentContext, params)
            } ?: ToolResult.Failure("Execution timed out")
        } catch (e: Exception) {
            ToolResult.Failure("Execution threw exception", e)
        } finally {
            plan.tool.cleanup()
        }

        val validatedResult = resultValidator.validate(rawResult)
        return logAndReturn(executionId, toolId, params, start, validatedResult)
    }

    private suspend fun logAndReturn(
        executionId: String,
        toolId: String,
        params: Map<String, Any>,
        start: Long,
        result: ToolResult
    ): ToolResult {
        val duration = System.currentTimeMillis() - start
        val status = when (result) {
            is ToolResult.Success -> "SUCCESS"
            is ToolResult.PartialSuccess -> "PARTIAL_SUCCESS"
            is ToolResult.Failure -> "FAILURE"
            is ToolResult.Cancelled -> "CANCELLED"
            is ToolResult.ValidationFailed -> "VALIDATION_FAILED"
            is ToolResult.RequiresConfirmation -> "REQUIRES_CONFIRMATION"
        }
        
        historyRepository.logExecution(
            ExecutionLog(
                executionId = executionId,
                toolId = toolId,
                timestamp = start,
                durationMs = duration,
                status = status,
                params = params,
                result = result
            )
        )
        return result
    }
}
