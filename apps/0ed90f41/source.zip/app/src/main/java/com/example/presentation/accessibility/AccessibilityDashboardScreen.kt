package com.example.presentation.accessibility

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.accessibility.models.AccessibilityNodeModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AccessibilityDashboardScreen(
    onNavigateBack: () -> Unit,
    viewModel: AccessibilityViewModel
) {
    val context = LocalContext.current
    val keyboardController = LocalSoftwareKeyboardController.current

    val status by viewModel.serviceStatus.collectAsState()
    val events by viewModel.recentEvents.collectAsState()
    val logs by viewModel.logs.collectAsState()
    val nodes by viewModel.nodeTree.collectAsState()
    val searchQuery by viewModel.searchQueryText.collectAsState()

    var activeTab by remember { mutableIntStateOf(0) } // 0: Control, 1: Inspect, 2: Logs

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Accessibility Settings", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(
                        onClick = onNavigateBack,
                        modifier = Modifier.testTag("accessibility_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Navigate Back"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant,
                    titleContentColor = MaterialTheme.colorScheme.onSurfaceVariant
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Status Header Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (status.isEnabled) {
                        MaterialTheme.colorScheme.primaryContainer
                    } else {
                        MaterialTheme.colorScheme.errorContainer
                    }
                )
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (status.isEnabled) "Service Active" else "Service Inactive",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = if (status.isEnabled) {
                                MaterialTheme.colorScheme.onPrimaryContainer
                            } else {
                                MaterialTheme.colorScheme.onErrorContainer
                            }
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (status.isEnabled) {
                                "Termux remote client is authorized to interact with screen."
                            } else {
                                "Accessibility permission is required for virtual input dispatch."
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = if (status.isEnabled) {
                                MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                            } else {
                                MaterialTheme.colorScheme.onErrorContainer.copy(alpha = 0.8f)
                            }
                        )
                    }
                    Button(
                        onClick = { viewModel.openAccessibilitySettings(context) },
                        modifier = Modifier
                            .testTag("open_accessibility_settings_btn")
                            .padding(start = 8.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (status.isEnabled) {
                                MaterialTheme.colorScheme.primary
                            } else {
                                MaterialTheme.colorScheme.error
                            }
                        )
                    ) {
                        Text(if (status.isEnabled) "Modify" else "Enable")
                    }
                }
            }

            // Tabs Header
            TabRow(selectedTabIndex = activeTab) {
                Tab(
                    selected = activeTab == 0,
                    onClick = { activeTab = 0 },
                    text = { Text("Controls") }
                )
                Tab(
                    selected = activeTab == 1,
                    onClick = { activeTab = 1 },
                    text = { Text("Inspect Screen") }
                )
                Tab(
                    selected = activeTab == 2,
                    onClick = { activeTab = 2 },
                    text = { Text("Live Logs") }
                )
            }

            // Content Area based on Tab
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                ) {
                when (activeTab) {
                    0 -> ControlTabContent(
                        isEnabled = status.isEnabled,
                        onTriggerClick = { x, y -> viewModel.triggerLocalClick(x, y) },
                        onTriggerSwipe = { sx, sy, ex, ey -> viewModel.triggerLocalSwipe(sx, sy, ex, ey) }
                    )
                    1 -> InspectTabContent(
                        isEnabled = status.isEnabled,
                        nodes = nodes,
                        searchQuery = searchQuery,
                        onSearchQueryChange = { viewModel.updateSearchQuery(it) },
                        onInspect = { viewModel.inspectActiveScreen() },
                        onSearch = { 
                            keyboardController?.hide()
                            viewModel.searchOnScreenNodes() 
                        }
                    )
                    2 -> LogsTabContent(logs = logs)
                }
            }
        }
    }
}

@Composable
fun ControlTabContent(
    isEnabled: Boolean,
    onTriggerClick: (Float, Float) -> Unit,
    onTriggerSwipe: (Float, Float, Float, Float) -> Unit
) {
    var clickX by remember { mutableStateOf("500") }
    var clickY by remember { mutableStateOf("1000") }
    var swipeSx by remember { mutableStateOf("500") }
    var swipeSy by remember { mutableStateOf("1500") }
    var swipeEx by remember { mutableStateOf("500") }
    var swipeEy by remember { mutableStateOf("500") }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "Virtual Touch Emulator",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = "Simulate input interactions locally to test if gesture injection has been authorized correctly.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                elevation = CardDefaults.cardElevation(2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Emulate Click",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        OutlinedTextField(
                            value = clickX,
                            onValueChange = { clickX = it },
                            label = { Text("X Pixels") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = clickY,
                            onValueChange = { clickY = it },
                            label = { Text("Y Pixels") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                    Button(
                        onClick = {
                            val x = clickX.toFloatOrNull() ?: 500f
                            val y = clickY.toFloatOrNull() ?: 1000f
                            onTriggerClick(x, y)
                        },
                        enabled = isEnabled,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("emulate_click_btn")
                    ) {
                        Icon(imageVector = Icons.Default.TouchApp, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Send Virtual Click")
                    }
                }
            }
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                elevation = CardDefaults.cardElevation(2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Emulate Swipe / Drag",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        OutlinedTextField(
                            value = swipeSx,
                            onValueChange = { swipeSx = it },
                            label = { Text("Start X") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = swipeSy,
                            onValueChange = { swipeSy = it },
                            label = { Text("Start Y") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        OutlinedTextField(
                            value = swipeEx,
                            onValueChange = { swipeEx = it },
                            label = { Text("End X") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = swipeEy,
                            onValueChange = { swipeEy = it },
                            label = { Text("End Y") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                    Button(
                        onClick = {
                            val sx = swipeSx.toFloatOrNull() ?: 500f
                            val sy = swipeSy.toFloatOrNull() ?: 1500f
                            val ex = swipeEx.toFloatOrNull() ?: 500f
                            val ey = swipeEy.toFloatOrNull() ?: 500f
                            onTriggerSwipe(sx, sy, ex, ey)
                        },
                        enabled = isEnabled,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("emulate_swipe_btn")
                    ) {
                        Icon(imageVector = Icons.Default.SwapVert, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Send Virtual Swipe")
                    }
                }
            }
        }
    }
}

@Composable
fun InspectTabContent(
    isEnabled: Boolean,
    nodes: List<AccessibilityNodeModel>,
    searchQuery: String,
    onSearchQueryChange: (String) -> Unit,
    onInspect: () -> Unit,
    onSearch: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            text = "Active Screen Inspector",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
        )
        Text(
            text = "Parse active UI components to search text or identify clickable view targets programmatically.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(modifier = Modifier.height(12.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = onSearchQueryChange,
                placeholder = { Text("Search text, ID or desc...") },
                modifier = Modifier
                    .weight(1f)
                    .testTag("node_search_query_input"),
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { onSearch() })
            )
            IconButton(
                onClick = onSearch,
                enabled = isEnabled,
                modifier = Modifier
                    .background(MaterialTheme.colorScheme.secondaryContainer, RoundedCornerShape(8.dp))
                    .size(48.dp)
                    .testTag("node_search_submit_btn")
            ) {
                Icon(imageVector = Icons.Default.Search, contentDescription = "Search UI")
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        Button(
            onClick = onInspect,
            enabled = isEnabled,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("inspect_full_screen_btn"),
            colors = ButtonDefaults.buttonColors(
                containerColor = MaterialTheme.colorScheme.tertiary
            )
        ) {
            Icon(imageVector = Icons.Default.Visibility, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text("Capture Full Layout Tree")
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (!isEnabled) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    "Enable Accessibility Service first to run inspectors.",
                    color = MaterialTheme.colorScheme.error,
                    fontWeight = FontWeight.SemiBold
                )
            }
        } else if (nodes.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Text("No elements loaded. Click Capture or Search.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(8.dp))
                    .padding(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(nodes) { node ->
                    NodeItemView(node = node, depth = 0)
                }
            }
        }
    }
}

@Composable
fun NodeItemView(node: AccessibilityNodeModel, depth: Int) {
    var isExpanded by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(start = (depth * 8).dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clickable(enabled = node.children.isNotEmpty()) { isExpanded = !isExpanded }
                .padding(vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (node.children.isNotEmpty()) {
                Icon(
                    imageVector = if (isExpanded) Icons.Default.ExpandMore else Icons.Default.ChevronRight,
                    contentDescription = null,
                    modifier = Modifier.size(16.dp)
                )
            } else {
                Spacer(modifier = Modifier.width(16.dp))
            }
            Spacer(modifier = Modifier.width(4.dp))
            Column {
                val label = buildString {
                    append(node.className?.substringAfterLast('.') ?: "View")
                    if (!node.text.isNullOrBlank()) append(" - \"${node.text}\"")
                    if (!node.contentDescription.isNullOrBlank()) append(" [desc: ${node.contentDescription}]")
                    if (!node.viewId.isNullOrBlank()) append(" (id: ${node.viewId.substringAfterLast('/')})")
                }
                Text(
                    text = label,
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = if (node.isClickable) FontWeight.Bold else FontWeight.Normal,
                    color = if (node.isClickable) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "Bounds: ${node.bounds} | clickable=${node.isClickable}",
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        if (isExpanded) {
            node.children.forEach { child ->
                NodeItemView(node = child, depth = depth + 1)
            }
        }
    }
}

@Composable
fun LogsTabContent(logs: List<String>) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            text = "System & Automation Activity Logs",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
        )
        Text(
            text = "Recent events captured by the service and programmatic gestures emulated via Termux companion.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(modifier = Modifier.height(12.dp))

        if (logs.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Text("Logs are empty. Run gestures to populate.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(8.dp))
                    .background(Color(0xFF1E1E1E), RoundedCornerShape(8.dp))
                    .padding(8.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                items(logs) { log ->
                    Text(
                        text = log,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        color = Color.LightGray,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }
    }
}
