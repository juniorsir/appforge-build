package com.example.domain.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
sealed class NetworkMessage {
    abstract val timestamp: Long
    abstract val sessionId: String

    val type: String get() = when (this) {
        is HelloMessage -> "HELLO"
        is AuthMessage -> "AUTH"
        is AudioStreamMessage -> "AUDIO_STREAM"
        is AudioEndMessage -> "AUDIO_END"
        is SttResultMessage -> "STT_RESULT"
        is AiRequestMessage -> "AI_REQUEST"
        is AiStreamMessage -> "AI_STREAM"
        is AiEndMessage -> "AI_END"
        is TtsStreamMessage -> "TTS_STREAM"
        is ErrorMessage -> "ERROR"
        is HeartbeatMessage -> "HEARTBEAT"
        is StatusMessage -> "STATUS"
        is PingMessage -> "PING"
        is PongMessage -> "PONG"
        is SttStartMessage -> "STT_START"
        is SttPartialMessage -> "STT_PARTIAL"
        is SttFinalMessage -> "STT_FINAL"
        is SttEndMessage -> "STT_END"
        is SttCancelMessage -> "STT_CANCEL"
        is SttErrorMessage -> "STT_ERROR"
        is AccessibilityGestureMessage -> "ACCESSIBILITY_GESTURE"
        is AccessibilityInspectMessage -> "ACCESSIBILITY_INSPECT"
        is AccessibilityInspectResultMessage -> "ACCESSIBILITY_INSPECT_RESULT"
        is AccessibilityScreenUpdateMessage -> "ACCESSIBILITY_SCREEN_UPDATE"
        is CameraCaptureMessage -> "CAMERA_CAPTURE"
        is CameraCaptureResultMessage -> "CAMERA_CAPTURE_RESULT"
        is CapabilityExecuteMessage -> "CAPABILITY_EXECUTE"
        is CapabilityExecuteResultMessage -> "CAPABILITY_EXECUTE_RESULT"
        is CapabilityManifestMessage -> "CAPABILITY_MANIFEST"
        is CapabilityManifestResultMessage -> "CAPABILITY_MANIFEST_RESULT"
        is TtsSpeakMessage -> "TTS_SPEAK"
        is TtsSpeakResultMessage -> "TTS_SPEAK_RESULT"
        is NotificationPostMessage -> "NOTIFICATION_POST"
        is NotificationPostResultMessage -> "NOTIFICATION_POST_RESULT"
        is ClipboardGetMessage -> "CLIPBOARD_GET"
        is ClipboardGetResultMessage -> "CLIPBOARD_GET_RESULT"
        is ClipboardSetMessage -> "CLIPBOARD_SET"
        is ClipboardSetResultMessage -> "CLIPBOARD_SET_RESULT"
        is DeviceInfoGetMessage -> "DEVICE_INFO_GET"
        is DeviceInfoResultMessage -> "DEVICE_INFO_RESULT"
        is TorchSetMessage -> "TORCH_SET"
        is TorchSetResultMessage -> "TORCH_SET_RESULT"
        is LocationGetMessage -> "LOCATION_GET"
        is LocationGetResultMessage -> "LOCATION_GET_RESULT"
        is MediaProbeRequestMessage -> "MEDIA_PROBE"
        is MediaProbeResultMessage -> "MEDIA_PROBE_RESULT"
        is MediaConvertRequestMessage -> "MEDIA_CONVERT"
        is MediaConvertResultMessage -> "MEDIA_CONVERT_RESULT"
        is ToastShowMessage -> "TOAST_SHOW"
        is ToastShowResultMessage -> "TOAST_SHOW_RESULT"
        is FloatingShowMessage -> "FLOATING_SHOW"
        is FloatingUpdateMessage -> "FLOATING_UPDATE"
        is FloatingHideMessage -> "FLOATING_HIDE"
        is FloatingResultMessage -> "FLOATING_RESULT"
        is VibrateTriggerMessage -> "VIBRATE_TRIGGER"
        is VibrateTriggerResultMessage -> "VIBRATE_TRIGGER_RESULT"
        is AudioPlayMessage -> "AUDIO_PLAY"
        is AudioPlayResultMessage -> "AUDIO_PLAY_RESULT"
        is AudioStopMessage -> "AUDIO_STOP"
        is AudioStopResultMessage -> "AUDIO_STOP_RESULT"
        is VolumeGetMessage -> "VOLUME_GET"
        is VolumeGetResultMessage -> "VOLUME_GET_RESULT"
        is VolumeSetMessage -> "VOLUME_SET"
        is VolumeSetResultMessage -> "VOLUME_SET_RESULT"
        is AppListMessage -> "APP_LIST"
        is AppListResultMessage -> "APP_LIST_RESULT"
        is AppLaunchMessage -> "APP_LAUNCH"
        is AppLaunchResultMessage -> "APP_LAUNCH_RESULT"
        is MediaTrimMessage -> "MEDIA_TRIM"
        is MediaTrimResultMessage -> "MEDIA_TRIM_RESULT"
        is MediaGifMessage -> "MEDIA_GIF"
        is MediaGifResultMessage -> "MEDIA_GIF_RESULT"
        is MediaSpeedMessage -> "MEDIA_SPEED"
        is MediaSpeedResultMessage -> "MEDIA_SPEED_RESULT"
        is MediaMuteMessage -> "MEDIA_MUTE"
        is MediaMuteResultMessage -> "MEDIA_MUTE_RESULT"
        is SensorGetMessage -> "SENSOR_GET"
        is SensorGetResultMessage -> "SENSOR_GET_RESULT"
        is DisplayGetMessage -> "DISPLAY_GET"
        is DisplayGetResultMessage -> "DISPLAY_GET_RESULT"
        is DisplaySetMessage -> "DISPLAY_SET"
        is DisplaySetResultMessage -> "DISPLAY_SET_RESULT"
        is NetworkTelemetryGetMessage -> "NETWORK_TELEMETRY_GET"
        is NetworkTelemetryGetResultMessage -> "NETWORK_TELEMETRY_GET_RESULT"
        is DeviceDetailsGetMessage -> "DEVICE_DETAILS_GET"
        is DeviceDetailsGetResultMessage -> "DEVICE_DETAILS_GET_RESULT"
    }

    /**
     * Basic sanitization & validation rules.
     */
    fun validate(): Boolean {
        if (timestamp <= 0) return false
        if (sessionId.isBlank()) return false
        return when (this) {
            is HelloMessage -> clientName.isNotBlank() && deviceId.isNotBlank()
            is AuthMessage -> token.isNotBlank() && userId.isNotBlank()
            is AudioStreamMessage -> dataBase64.isNotBlank()
            is AiRequestMessage -> text.isNotBlank() && conversationId.isNotBlank()
            is ErrorMessage -> errorCode.isNotBlank()
            is PingMessage -> pingId.isNotBlank()
            is PongMessage -> pingId.isNotBlank()
            is SttStartMessage -> sampleRate > 0
            is SttPartialMessage -> text.isNotBlank()
            is SttFinalMessage -> text.isNotBlank()
            is SttErrorMessage -> reason.isNotBlank()
            is AccessibilityGestureMessage -> gestureId.isNotBlank() && startX >= 0 && startY >= 0
            is AccessibilityInspectMessage -> true
            is AccessibilityInspectResultMessage -> true
            is AccessibilityScreenUpdateMessage -> true
            else -> true
        }
    }
}

@Serializable
@SerialName("HELLO")
data class HelloMessage(
    override val timestamp: Long,
    override val sessionId: String,
    val clientName: String = "CompanionAndroid",
    val deviceId: String,
    val protocolVersion: String = "1.0"
) : NetworkMessage()

@Serializable
@SerialName("AUTH")
data class AuthMessage(
    override val timestamp: Long,
    override val sessionId: String,
    val token: String,
    val userId: String
) : NetworkMessage()

@Serializable
@SerialName("AUDIO_STREAM")
data class AudioStreamMessage(
    override val timestamp: Long,
    override val sessionId: String,
    val sequenceNumber: Long,
    val dataBase64: String, // Base64 encoded raw PCM bytes
    val format: String = "PCM_16BIT"
) : NetworkMessage()

@Serializable
@SerialName("AUDIO_END")
data class AudioEndMessage(
    override val timestamp: Long,
    override val sessionId: String,
    val totalPackets: Long
) : NetworkMessage()

@Serializable
@SerialName("STT_RESULT")
data class SttResultMessage(
    override val timestamp: Long,
    override val sessionId: String,
    val text: String,
    val isFinal: Boolean
) : NetworkMessage()

@Serializable
@SerialName("AI_REQUEST")
data class AiRequestMessage(
    override val timestamp: Long,
    override val sessionId: String,
    val text: String,
    val conversationId: String
) : NetworkMessage()

@Serializable
@SerialName("AI_STREAM")
data class AiStreamMessage(
    override val timestamp: Long = System.currentTimeMillis(),
    override val sessionId: String = "ai-stream",
    val textChunk: String = "",
    val isFinal: Boolean = true,
    val action: String? = null,
    val text: String? = null,
    val message: String? = null,
    val rawJson: String? = null
) : NetworkMessage()

@Serializable
@SerialName("AI_END")
data class AiEndMessage(
    override val timestamp: Long,
    override val sessionId: String,
    val conversationId: String,
    val fullResponseText: String
) : NetworkMessage()

@Serializable
@SerialName("TTS_STREAM")
data class TtsStreamMessage(
    override val timestamp: Long,
    override val sessionId: String,
    val audioDataBase64: String? = null,
    val url: String? = null,
    val mimeType: String = "audio/mpeg"
) : NetworkMessage()

@Serializable
@SerialName("ERROR")
data class ErrorMessage(
    override val timestamp: Long,
    override val sessionId: String,
    val errorCode: String,
    val message: String
) : NetworkMessage()

@Serializable
@SerialName("HEARTBEAT")
data class HeartbeatMessage(
    override val timestamp: Long,
    override val sessionId: String,
    val seq: Long
) : NetworkMessage()

@Serializable
@SerialName("STATUS")
data class StatusMessage(
    override val timestamp: Long,
    override val sessionId: String,
    val backendState: String, // e.g. "IDLE", "THINKING", "SPEAKING"
    val cpuUsage: Double = 0.0,
    val ramUsage: Double = 0.0
) : NetworkMessage()

@Serializable
@SerialName("PING")
data class PingMessage(
    override val timestamp: Long,
    override val sessionId: String,
    val pingId: String
) : NetworkMessage()

@Serializable
@SerialName("PONG")
data class PongMessage(
    override val timestamp: Long,
    override val sessionId: String,
    val pingId: String,
    val requestTimestamp: Long
) : NetworkMessage()

// --- PHASE 5 STT MESSAGE PROTOCOL EXTENSIONS ---

@Serializable
@SerialName("STT_START")
data class SttStartMessage(
    override val timestamp: Long,
    override val sessionId: String,
    val sampleRate: Int = 16000,
    val language: String? = null,
    val modelSize: String = "base"
) : NetworkMessage()

@Serializable
@SerialName("STT_PARTIAL")
data class SttPartialMessage(
    override val timestamp: Long,
    override val sessionId: String,
    val text: String,
    val durationMs: Long = 0
) : NetworkMessage()

@Serializable
@SerialName("STT_FINAL")
data class SttFinalMessage(
    override val timestamp: Long,
    override val sessionId: String,
    val text: String,
    val confidence: Double = 0.95,
    val language: String = "en",
    val durationMs: Long = 0
) : NetworkMessage()

@Serializable
@SerialName("STT_END")
data class SttEndMessage(
    override val timestamp: Long,
    override val sessionId: String,
    val reason: String = "completed"
) : NetworkMessage()

@Serializable
@SerialName("STT_CANCEL")
data class SttCancelMessage(
    override val timestamp: Long,
    override val sessionId: String
) : NetworkMessage()

@Serializable
@SerialName("STT_ERROR")
data class SttErrorMessage(
    override val timestamp: Long,
    override val sessionId: String,
    val errorCode: String,
    val reason: String
) : NetworkMessage()

@Serializable
@SerialName("ACCESSIBILITY_GESTURE")
data class AccessibilityGestureMessage(
    override val timestamp: Long = System.currentTimeMillis(),
    override val sessionId: String = "gesture",
    val gestureId: String = "gesture-" + System.currentTimeMillis(),
    val gestureType: String = "CLICK",
    val action: String? = null,
    val startX: Float = 0f,
    val startY: Float = 0f,
    val endX: Float = 0f,
    val endY: Float = 0f,
    val x: Float = 0f,
    val y: Float = 0f,
    val text: String? = null,
    val label: String? = null,
    val durationMs: Long = 100
) : NetworkMessage()

@Serializable
@SerialName("ACCESSIBILITY_INSPECT")
data class AccessibilityInspectMessage(
    override val timestamp: Long,
    override val sessionId: String,
    val searchByText: String? = null,
    val searchByDesc: String? = null,
    val searchById: String? = null
) : NetworkMessage()

@Serializable
@SerialName("ACCESSIBILITY_INSPECT_RESULT")
data class AccessibilityInspectResultMessage(
    override val timestamp: Long,
    override val sessionId: String,
    val nodes: List<com.example.accessibility.models.AccessibilityNodeModel>,
    val queryExecuted: String
) : NetworkMessage()

@Serializable
@SerialName("ACCESSIBILITY_SCREEN_UPDATE")
data class AccessibilityScreenUpdateMessage(
    override val timestamp: Long,
    override val sessionId: String,
    val eventType: String,
    val packageName: String?,
    val nodes: List<com.example.accessibility.models.AccessibilityNodeModel>
) : NetworkMessage()

@Serializable
@SerialName("CAMERA_CAPTURE")
data class CameraCaptureMessage(
    override val timestamp: Long,
    override val sessionId: String,
    val requestId: String = "cam_req",
    val lens: String = "back" // "back" or "front"
) : NetworkMessage()

@Serializable
@SerialName("CAMERA_CAPTURE_RESULT")
data class CameraCaptureResultMessage(
    override val timestamp: Long,
    override val sessionId: String,
    val requestId: String,
    val success: Boolean,
    val filePath: String? = null,
    val fileSize: Long = 0,
    val imageBase64: String? = null,
    val errorMessage: String? = null
) : NetworkMessage()

@Serializable
@SerialName("CAPABILITY_EXECUTE")
data class CapabilityExecuteMessage(
    override val timestamp: Long,
    override val sessionId: String,
    val requestId: String = "cap_req",
    val capabilityId: String,
    val action: String = "execute",
    val parametersJson: String? = null
) : NetworkMessage()

@Serializable
@SerialName("CAPABILITY_EXECUTE_RESULT")
data class CapabilityExecuteResultMessage(
    override val timestamp: Long,
    override val sessionId: String,
    val requestId: String,
    val capabilityId: String,
    val success: Boolean,
    val dataJson: String? = null,
    val errorMessage: String? = null
) : NetworkMessage()

@Serializable
@SerialName("CAPABILITY_MANIFEST")
data class CapabilityManifestMessage(
    override val timestamp: Long,
    override val sessionId: String,
    val requestId: String = "manifest_req"
) : NetworkMessage()

@Serializable
@SerialName("CAPABILITY_MANIFEST_RESULT")
data class CapabilityManifestResultMessage(
    override val timestamp: Long,
    override val sessionId: String,
    val requestId: String,
    val manifestJson: String
) : NetworkMessage()

@Serializable
@SerialName("TTS_SPEAK")
data class TtsSpeakMessage(
    override val timestamp: Long,
    override val sessionId: String,
    val requestId: String = "tts_req",
    val text: String,
    val queueMode: Int = 0, // 0 = flush, 1 = add
    val pitch: Float = 1.0f,
    val speechRate: Float = 1.0f
) : NetworkMessage()

@Serializable
@SerialName("TTS_SPEAK_RESULT")
data class TtsSpeakResultMessage(
    override val timestamp: Long,
    override val sessionId: String,
    val requestId: String,
    val success: Boolean,
    val errorMessage: String? = null
) : NetworkMessage()

@Serializable
@SerialName("NOTIFICATION_POST")
data class NotificationPostMessage(
    override val timestamp: Long,
    override val sessionId: String,
    val requestId: String = "notif_req",
    val title: String,
    val message: String
) : NetworkMessage()

@Serializable
@SerialName("NOTIFICATION_POST_RESULT")
data class NotificationPostResultMessage(
    override val timestamp: Long,
    override val sessionId: String,
    val requestId: String,
    val success: Boolean,
    val errorMessage: String? = null
) : NetworkMessage()

@Serializable
@SerialName("CLIPBOARD_GET")
data class ClipboardGetMessage(
    override val timestamp: Long,
    override val sessionId: String,
    val requestId: String = "clip_get_req"
) : NetworkMessage()

@Serializable
@SerialName("CLIPBOARD_GET_RESULT")
data class ClipboardGetResultMessage(
    override val timestamp: Long,
    override val sessionId: String,
    val requestId: String,
    val text: String,
    val success: Boolean = true
) : NetworkMessage()

@Serializable
@SerialName("CLIPBOARD_SET")
data class ClipboardSetMessage(
    override val timestamp: Long,
    override val sessionId: String,
    val requestId: String = "clip_set_req",
    val text: String
) : NetworkMessage()

@Serializable
@SerialName("CLIPBOARD_SET_RESULT")
data class ClipboardSetResultMessage(
    override val timestamp: Long,
    override val sessionId: String,
    val requestId: String,
    val success: Boolean,
    val errorMessage: String? = null
) : NetworkMessage()

@Serializable
@SerialName("DEVICE_INFO_GET")
data class DeviceInfoGetMessage(
    override val timestamp: Long,
    override val sessionId: String,
    val requestId: String = "dev_info_req"
) : NetworkMessage()

@Serializable
@SerialName("DEVICE_INFO_RESULT")
data class DeviceInfoResultMessage(
    override val timestamp: Long,
    override val sessionId: String,
    val requestId: String,
    val model: String,
    val manufacturer: String,
    val androidVersion: String,
    val sdkVersion: Int,
    val batteryPercentage: Float,
    val isCharging: Boolean,
    val batteryTemperature: Float,
    val cpuAbi: String,
    val availableMemoryMb: Long,
    val totalMemoryMb: Long
) : NetworkMessage()

@Serializable
@SerialName("TORCH_SET")
data class TorchSetMessage(
    override val timestamp: Long,
    override val sessionId: String,
    val requestId: String = "torch_req",
    val enabled: Boolean
) : NetworkMessage()

@Serializable
@SerialName("TORCH_SET_RESULT")
data class TorchSetResultMessage(
    override val timestamp: Long,
    override val sessionId: String,
    val requestId: String,
    val enabled: Boolean,
    val success: Boolean,
    val errorMessage: String? = null
) : NetworkMessage()

@Serializable
@SerialName("LOCATION_GET")
data class LocationGetMessage(
    override val timestamp: Long,
    override val sessionId: String,
    val requestId: String = "loc_req"
) : NetworkMessage()

@Serializable
@SerialName("LOCATION_GET_RESULT")
data class LocationGetResultMessage(
    override val timestamp: Long,
    override val sessionId: String,
    val requestId: String,
    val success: Boolean,
    val latitude: Double = 0.0,
    val longitude: Double = 0.0,
    val altitude: Double = 0.0,
    val accuracy: Float = 0f,
    val speed: Float = 0f,
    val errorMessage: String? = null
) : NetworkMessage()

@Serializable
@SerialName("MEDIA_PROBE")
data class MediaProbeRequestMessage(
    override val timestamp: Long,
    override val sessionId: String,
    val requestId: String = "probe_req",
    val mediaUri: String
) : NetworkMessage()

@Serializable
@SerialName("MEDIA_PROBE_RESULT")
data class MediaProbeResultMessage(
    override val timestamp: Long,
    override val sessionId: String,
    val requestId: String,
    val success: Boolean,
    val container: String? = null,
    val durationMs: Long = 0,
    val videoCodec: String? = null,
    val audioCodec: String? = null,
    val width: Int = 0,
    val height: Int = 0,
    val bitrate: Long = 0,
    val errorMessage: String? = null
) : NetworkMessage()

@Serializable
@SerialName("MEDIA_CONVERT")
data class MediaConvertRequestMessage(
    override val timestamp: Long,
    override val sessionId: String,
    val requestId: String = "convert_req",
    val action: String = "remux", // "remux", "transcode", "thumbnail", "extract_audio"
    val inputUri: String,
    val outputUri: String = "",
    val videoCodec: String? = null,
    val audioCodec: String? = null,
    val timestampSeconds: Double = 0.0
) : NetworkMessage()

@Serializable
@SerialName("MEDIA_CONVERT_RESULT")
data class MediaConvertResultMessage(
    override val timestamp: Long,
    override val sessionId: String,
    val requestId: String,
    val success: Boolean,
    val outputPath: String? = null,
    val errorMessage: String? = null
) : NetworkMessage()

@Serializable
@SerialName("TOAST_SHOW")
data class ToastShowMessage(
    override val timestamp: Long,
    override val sessionId: String,
    val requestId: String = "toast_req",
    val message: String,
    val duration: String = "SHORT", // "SHORT", "LONG"
    val durationMs: Long? = null,
    val gravity: String = "BOTTOM", // "BOTTOM", "TOP", "CENTER", "CUSTOM"
    val xOffset: Int = 0,
    val yOffset: Int = 120,
    val backgroundColor: String? = null, // e.g., "#CC1E1E2E", "#FF43A047"
    val textColor: String? = null,
    val textSize: Float = 14f,
    val cornerRadius: Int = 24,
    val icon: String? = null, // "info", "success", "warning", "error", "star", "bell"
    val alpha: Float = 0.95f,
    val useOverlay: Boolean = false
) : NetworkMessage()

@Serializable
@SerialName("TOAST_SHOW_RESULT")
data class ToastShowResultMessage(
    override val timestamp: Long,
    override val sessionId: String,
    val requestId: String,
    val success: Boolean,
    val errorMessage: String? = null
) : NetworkMessage()

@Serializable
@SerialName("FLOATING_SHOW")
data class FloatingShowMessage(
    override val timestamp: Long,
    override val sessionId: String,
    val requestId: String = "float_req",
    val floatingId: String = "default_floating",
    val title: String? = null,
    val text: String,
    val subText: String? = null,
    val overlayType: String = "HUD", // "BADGE", "HUD", "STICKY_NOTE", "STATUS_PILL", "CARD", "TERMINAL_MINI"
    val backgroundColor: String? = null,
    val textColor: String? = null,
    val accentColor: String? = null,
    val textSize: Float = 13f,
    val cornerRadius: Int = 16,
    val alpha: Float = 0.95f,
    val gravity: String = "TOP_RIGHT",
    val x: Int = 24,
    val y: Int = 100,
    val widthDp: Int = -2,
    val heightDp: Int = -2,
    val isDraggable: Boolean = true,
    val showCloseButton: Boolean = true,
    val autoDismissSeconds: Int = 0
) : NetworkMessage()

@Serializable
@SerialName("FLOATING_UPDATE")
data class FloatingUpdateMessage(
    override val timestamp: Long,
    override val sessionId: String,
    val requestId: String = "float_upd",
    val floatingId: String = "default_floating",
    val text: String? = null,
    val title: String? = null,
    val subText: String? = null,
    val backgroundColor: String? = null,
    val textColor: String? = null
) : NetworkMessage()

@Serializable
@SerialName("FLOATING_HIDE")
data class FloatingHideMessage(
    override val timestamp: Long,
    override val sessionId: String,
    val requestId: String = "float_hide",
    val floatingId: String? = null // null to hide all
) : NetworkMessage()

@Serializable
@SerialName("FLOATING_RESULT")
data class FloatingResultMessage(
    override val timestamp: Long,
    override val sessionId: String,
    val requestId: String,
    val success: Boolean,
    val floatingId: String? = null,
    val permissionRequired: Boolean = false,
    val errorMessage: String? = null
) : NetworkMessage()

@Serializable
@SerialName("VIBRATE_TRIGGER")
data class VibrateTriggerMessage(
    override val timestamp: Long,
    override val sessionId: String,
    val requestId: String = "vib_req",
    val durationMs: Long = 100L,
    val preset: String? = null, // "CLICK", "DOUBLE_CLICK", "HEAVY_CLICK", "TICK", "ERROR", "SUCCESS"
    val patternMs: List<Long>? = null, // e.g. [0, 100, 50, 100]
    val amplitude: Int = 255
) : NetworkMessage()

@Serializable
@SerialName("VIBRATE_TRIGGER_RESULT")
data class VibrateTriggerResultMessage(
    override val timestamp: Long,
    override val sessionId: String,
    val requestId: String,
    val success: Boolean,
    val errorMessage: String? = null
) : NetworkMessage()

@Serializable
@SerialName("AUDIO_PLAY")
data class AudioPlayMessage(
    override val timestamp: Long,
    override val sessionId: String,
    val requestId: String = "audio_play_req",
    val soundType: String? = "notification", // "notification", "alarm", "ringtone", "beep", "file"
    val audioPath: String? = null, // filepath or uri if soundType == "file"
    val loop: Boolean = false,
    val beepTone: Int = 24 // ToneGenerator.TONE_PROP_BEEP
) : NetworkMessage()

@Serializable
@SerialName("AUDIO_PLAY_RESULT")
data class AudioPlayResultMessage(
    override val timestamp: Long,
    override val sessionId: String,
    val requestId: String,
    val success: Boolean,
    val errorMessage: String? = null
) : NetworkMessage()

@Serializable
@SerialName("AUDIO_STOP")
data class AudioStopMessage(
    override val timestamp: Long,
    override val sessionId: String,
    val requestId: String = "audio_stop_req"
) : NetworkMessage()

@Serializable
@SerialName("AUDIO_STOP_RESULT")
data class AudioStopResultMessage(
    override val timestamp: Long,
    override val sessionId: String,
    val requestId: String,
    val success: Boolean
) : NetworkMessage()

@Serializable
@SerialName("VOLUME_GET")
data class VolumeGetMessage(
    override val timestamp: Long,
    override val sessionId: String,
    val requestId: String = "vol_get_req"
) : NetworkMessage()

@Serializable
data class StreamVolumeData(
    val stream: String,
    val currentVolume: Int,
    val maxVolume: Int,
    val minVolume: Int,
    val percentage: Int
)

@Serializable
@SerialName("VOLUME_GET_RESULT")
data class VolumeGetResultMessage(
    override val timestamp: Long,
    override val sessionId: String,
    val requestId: String,
    val ringerMode: String,
    val isMusicActive: Boolean,
    val isSpeakerphoneOn: Boolean,
    val streams: List<StreamVolumeData>
) : NetworkMessage()

@Serializable
@SerialName("VOLUME_SET")
data class VolumeSetMessage(
    override val timestamp: Long,
    override val sessionId: String,
    val requestId: String = "vol_set_req",
    val stream: String = "MEDIA", // "MEDIA", "RING", "NOTIFICATION", "ALARM", "VOICE_CALL", "SYSTEM"
    val volume: Int? = null,
    val ringerMode: String? = null, // "NORMAL", "VIBRATE", "SILENT"
    val showUi: Boolean = false
) : NetworkMessage()

@Serializable
@SerialName("VOLUME_SET_RESULT")
data class VolumeSetResultMessage(
    override val timestamp: Long,
    override val sessionId: String,
    val requestId: String,
    val success: Boolean,
    val errorMessage: String? = null
) : NetworkMessage()

@Serializable
@SerialName("APP_LIST")
data class AppListMessage(
    override val timestamp: Long,
    override val sessionId: String,
    val requestId: String = "app_list_req",
    val includeSystem: Boolean = false
) : NetworkMessage()

@Serializable
data class AppEntryData(
    val appName: String,
    val packageName: String,
    val versionName: String?,
    val isSystemApp: Boolean
)

@Serializable
@SerialName("APP_LIST_RESULT")
data class AppListResultMessage(
    override val timestamp: Long,
    override val sessionId: String,
    val requestId: String,
    val totalApps: Int,
    val apps: List<AppEntryData>
) : NetworkMessage()

@Serializable
@SerialName("APP_LAUNCH")
data class AppLaunchMessage(
    override val timestamp: Long,
    override val sessionId: String,
    val requestId: String = "app_launch_req",
    val packageName: String? = null,
    val url: String? = null
) : NetworkMessage()

@Serializable
@SerialName("APP_LAUNCH_RESULT")
data class AppLaunchResultMessage(
    override val timestamp: Long,
    override val sessionId: String,
    val requestId: String,
    val success: Boolean,
    val launchedTarget: String? = null,
    val errorMessage: String? = null
) : NetworkMessage()

@Serializable
@SerialName("MEDIA_TRIM")
data class MediaTrimMessage(
    override val timestamp: Long,
    override val sessionId: String,
    val requestId: String = "trim_req",
    val mediaUri: String,
    val startSeconds: Double = 0.0,
    val durationSeconds: Double,
    val exact: Boolean = false
) : NetworkMessage()

@Serializable
@SerialName("MEDIA_TRIM_RESULT")
data class MediaTrimResultMessage(
    override val timestamp: Long,
    override val sessionId: String,
    val requestId: String,
    val success: Boolean,
    val outputPath: String? = null,
    val errorMessage: String? = null
) : NetworkMessage()

@Serializable
@SerialName("MEDIA_GIF")
data class MediaGifMessage(
    override val timestamp: Long,
    override val sessionId: String,
    val requestId: String = "gif_req",
    val mediaUri: String,
    val startSeconds: Double = 0.0,
    val durationSeconds: Double = 5.0,
    val fps: Int = 15,
    val width: Int = 480
) : NetworkMessage()

@Serializable
@SerialName("MEDIA_GIF_RESULT")
data class MediaGifResultMessage(
    override val timestamp: Long,
    override val sessionId: String,
    val requestId: String,
    val success: Boolean,
    val outputPath: String? = null,
    val errorMessage: String? = null
) : NetworkMessage()

@Serializable
@SerialName("MEDIA_SPEED")
data class MediaSpeedMessage(
    override val timestamp: Long,
    override val sessionId: String,
    val requestId: String = "speed_req",
    val mediaUri: String,
    val speedFactor: Double = 1.5 // 0.25 to 4.0
) : NetworkMessage()

@Serializable
@SerialName("MEDIA_SPEED_RESULT")
data class MediaSpeedResultMessage(
    override val timestamp: Long,
    override val sessionId: String,
    val requestId: String,
    val success: Boolean,
    val outputPath: String? = null,
    val errorMessage: String? = null
) : NetworkMessage()

@Serializable
@SerialName("MEDIA_MUTE")
data class MediaMuteMessage(
    override val timestamp: Long,
    override val sessionId: String,
    val requestId: String = "mute_req",
    val mediaUri: String
) : NetworkMessage()

@Serializable
@SerialName("MEDIA_MUTE_RESULT")
data class MediaMuteResultMessage(
    override val timestamp: Long,
    override val sessionId: String,
    val requestId: String,
    val success: Boolean,
    val outputPath: String? = null,
    val errorMessage: String? = null
) : NetworkMessage()

@Serializable
data class SensorVectorData(val x: Float, val y: Float, val z: Float)

@Serializable
@SerialName("SENSOR_GET")
data class SensorGetMessage(
    override val timestamp: Long,
    override val sessionId: String,
    val requestId: String = "sensor_req"
) : NetworkMessage()

@Serializable
@SerialName("SENSOR_GET_RESULT")
data class SensorGetResultMessage(
    override val timestamp: Long,
    override val sessionId: String,
    val requestId: String,
    val accelerometer: SensorVectorData? = null,
    val gyroscope: SensorVectorData? = null,
    val magneticField: SensorVectorData? = null,
    val compassHeadingDegrees: Float? = null,
    val compassCardinal: String? = null,
    val ambientLightLux: Float? = null,
    val proximityCm: Float? = null,
    val isNear: Boolean? = null,
    val pressureHpa: Float? = null,
    val ambientTemperatureC: Float? = null,
    val relativeHumidityPct: Float? = null,
    val stepCount: Float? = null,
    val availableSensors: List<String> = emptyList()
) : NetworkMessage()

@Serializable
@SerialName("DISPLAY_GET")
data class DisplayGetMessage(
    override val timestamp: Long,
    override val sessionId: String,
    val requestId: String = "disp_get_req"
) : NetworkMessage()

@Serializable
@SerialName("DISPLAY_GET_RESULT")
data class DisplayGetResultMessage(
    override val timestamp: Long,
    override val sessionId: String,
    val requestId: String,
    val widthPixels: Int,
    val heightPixels: Int,
    val densityDpi: Int,
    val densityScale: Float,
    val refreshRateHz: Float,
    val orientation: String,
    val isHdr: Boolean,
    val currentBrightness: Int,
    val isAutoBrightness: Boolean,
    val screenTimeoutMs: Int,
    val isInteractive: Boolean,
    val isPowerSaveMode: Boolean
) : NetworkMessage()

@Serializable
@SerialName("DISPLAY_SET")
data class DisplaySetMessage(
    override val timestamp: Long,
    override val sessionId: String,
    val requestId: String = "disp_set_req",
    val brightness: Int? = null, // 0-255
    val autoBrightness: Boolean? = null,
    val keepScreenOn: Boolean? = null
) : NetworkMessage()

@Serializable
@SerialName("DISPLAY_SET_RESULT")
data class DisplaySetResultMessage(
    override val timestamp: Long,
    override val sessionId: String,
    val requestId: String,
    val success: Boolean,
    val errorMessage: String? = null
) : NetworkMessage()

@Serializable
data class WifiInfoData(
    val ssid: String,
    val bssid: String,
    val rssiDbm: Int,
    val signalLevel: Int,
    val linkSpeedMbps: Int,
    val frequencyMhz: Int,
    val wifiStandard: String,
    val ipAddress: String?
)

@Serializable
data class CellularInfoData(
    val carrierName: String,
    val networkType: String,
    val isRoaming: Boolean,
    val simState: String
)

@Serializable
@SerialName("NETWORK_TELEMETRY_GET")
data class NetworkTelemetryGetMessage(
    override val timestamp: Long,
    override val sessionId: String,
    val requestId: String = "net_telem_req"
) : NetworkMessage()

@Serializable
@SerialName("NETWORK_TELEMETRY_GET_RESULT")
data class NetworkTelemetryGetResultMessage(
    override val timestamp: Long,
    override val sessionId: String,
    val requestId: String,
    val activeTransport: String,
    val isConnected: Boolean,
    val isMetered: Boolean,
    val wifi: WifiInfoData? = null,
    val cellular: CellularInfoData? = null,
    val localIpv4Addresses: List<String> = emptyList()
) : NetworkMessage()

@Serializable
@SerialName("DEVICE_DETAILS_GET")
data class DeviceDetailsGetMessage(
    override val timestamp: Long,
    override val sessionId: String,
    val requestId: String = "dev_det_req"
) : NetworkMessage()

@Serializable
@SerialName("DEVICE_DETAILS_GET_RESULT")
data class DeviceDetailsGetResultMessage(
    override val timestamp: Long,
    override val sessionId: String,
    val requestId: String,
    val manufacturer: String,
    val model: String,
    val brand: String,
    val board: String,
    val hardware: String,
    val androidVersion: String,
    val sdkInt: Int,
    val securityPatch: String,
    val primaryAbi: String,
    val supportedAbis: List<String>,
    val cpuCores: Int,
    val ramTotalGb: Double,
    val ramAvailableGb: Double,
    val ramUsedPct: Int,
    val storageTotalGb: Double,
    val storageFreeGb: Double,
    val storageUsedPct: Int,
    val uptimeSeconds: Long,
    val batteryPct: Int,
    val isCharging: Boolean,
    val batteryTempC: Double,
    val isThermalThrottling: Boolean
) : NetworkMessage()

/**
 * Basic input sanitization.
 */
fun sanitizeInput(text: String): String {
    return text.replace(Regex("[\\x00-\\x1F\\x7F]"), "") // Strip non-printable ASCII
        .trim()
}
