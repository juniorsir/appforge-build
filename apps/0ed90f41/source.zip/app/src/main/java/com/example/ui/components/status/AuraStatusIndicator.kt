package com.example.ui.components.status

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.components.glass.AuraGlassSurface
import com.example.ui.theme.AuraColors
import com.example.ui.theme.AuraDimensions
import com.example.ui.theme.AuraGlassLevel
import com.example.ui.theme.AuraMotion
import com.example.ui.theme.AuraShapes
import com.example.ui.theme.AuraTypography

enum class AuraStatusType(
    val dotColor: Color,
    val textColor: Color
) {
    READY(dotColor = AuraColors.StatusReady, textColor = AuraColors.TextPrimary),
    ACTIVE(dotColor = AuraColors.StatusActive, textColor = AuraColors.TextPrimary),
    IDLE(dotColor = AuraColors.StatusIdle, textColor = AuraColors.TextSecondary),
    WARNING(dotColor = AuraColors.StatusWarning, textColor = AuraColors.TextSecondary),
    ERROR(dotColor = AuraColors.StatusError, textColor = AuraColors.TextSecondary)
}

/**
 * AURA ASSISTANT — Status Dot with optional soft monochrome beacon pulsing.
 */
@Composable
fun AuraStatusDot(
    modifier: Modifier = Modifier,
    type: AuraStatusType = AuraStatusType.READY,
    isPulsing: Boolean = true,
    size: Dp = AuraDimensions.StatusDotSize
) {
    val infiniteTransition = rememberInfiniteTransition(label = "StatusDotPulse")
    val alpha by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "DotPulseAlpha"
    )

    Box(
        modifier = modifier
            .size(size)
            .clip(CircleShape)
            .background(type.dotColor.copy(alpha = if (isPulsing) alpha else 1.0f))
    )
}

/**
 * AURA ASSISTANT — Technical Status Badge
 * e.g., [ ● READY ] or [ ● ACTIVE ]
 */
@Composable
fun AuraStatusBadge(
    label: String,
    modifier: Modifier = Modifier,
    type: AuraStatusType = AuraStatusType.READY,
    isPulsing: Boolean = true
) {
    AuraGlassSurface(
        modifier = modifier.semantics(mergeDescendants = true) {},
        shape = AuraShapes.Small,
        level = AuraGlassLevel.LEVEL_1,
        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 5.dp)
    ) {
        Row(
            modifier = Modifier.align(Alignment.Center),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            AuraStatusDot(type = type, isPulsing = isPulsing)
            AnimatedContent(
                targetState = label,
                transitionSpec = {
                    fadeIn(animationSpec = AuraMotion.stateTransitionTween()) togetherWith
                            fadeOut(animationSpec = AuraMotion.stateTransitionTween())
                },
                label = "StatusBadgeText"
            ) { text ->
                Text(
                    text = text.uppercase(),
                    style = AuraTypography.TechnicalLabel,
                    color = type.textColor
                )
            }
        }
    }
}
