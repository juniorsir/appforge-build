package com.example.ui.components.header

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.components.glass.AuraGlassSurface
import com.example.ui.theme.AuraBorders
import com.example.ui.theme.AuraColors
import com.example.ui.theme.AuraDimensions
import com.example.ui.theme.AuraGlassLevel
import com.example.ui.theme.AuraMotion

/**
 * AURA ASSISTANT — Secondary Header Action Button
 * Compact circular glass button with accessible 48dp touch target and soft tactile press.
 */
@Composable
fun AuraHeaderAction(
    icon: ImageVector,
    contentDescriptionText: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    testTag: String? = null,
    enabled: Boolean = true,
    size: Dp = AuraDimensions.HeaderActionSize,
    iconSize: Dp = AuraDimensions.HeaderIconSize,
    tint: Color = AuraColors.TextSecondary,
    isProminent: Boolean = false
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()

    val scale by animateFloatAsState(
        targetValue = if (isPressed && enabled) AuraMotion.PressScalePressed else AuraMotion.PressScaleNormal,
        animationSpec = AuraMotion.PressSpring,
        label = "HeaderActionScale"
    )

    val activeTint = when {
        !enabled -> tint.copy(alpha = 0.35f)
        isPressed || isProminent -> AuraColors.TextPrimary
        else -> tint
    }

    Box(
        modifier = modifier
            .defaultMinSize(minWidth = AuraDimensions.MinTouchTarget, minHeight = AuraDimensions.MinTouchTarget)
            .then(if (testTag != null) Modifier.testTag(testTag) else Modifier),
        contentAlignment = Alignment.Center
    ) {
        AuraGlassSurface(
            modifier = Modifier
                .size(size)
                .graphicsLayer {
                    scaleX = scale
                    scaleY = scale
                }
                .clickable(
                    interactionSource = interactionSource,
                    indication = null,
                    enabled = enabled,
                    role = Role.Button,
                    onClick = onClick
                )
                .semantics {
                    role = Role.Button
                    contentDescription = contentDescriptionText
                },
            shape = CircleShape,
            level = when {
                isPressed -> AuraGlassLevel.ACTIVE
                isProminent -> AuraGlassLevel.LEVEL_2
                else -> AuraGlassLevel.LEVEL_1
            },
            borderWidth = AuraBorders.WidthSubtle
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null, // Set on the container semantics
                tint = activeTint,
                modifier = Modifier
                    .size(iconSize)
                    .align(Alignment.Center)
            )
        }
    }
}
