package com.example.tools

import com.example.tools.repository.*
import com.example.tools.registry.*
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
abstract class ToolsModule {

    @Binds
    @Singleton
    abstract fun bindToolRegistryRepository(impl: ToolRegistryImpl): ToolRegistryRepository

    @Binds
    @Singleton
    abstract fun bindPluginRegistryRepository(impl: PluginRegistryImpl): PluginRegistryRepository

    @Binds
    @Singleton
    abstract fun bindExecutionHistoryRepository(impl: ExecutionHistoryRepositoryImpl): ExecutionHistoryRepository

    @Binds
    @Singleton
    abstract fun bindConfirmationRepository(impl: ConfirmationRepositoryImpl): ConfirmationRepository
}
