package com.example.workers

import android.content.Context
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.example.util.AndroidLogger
import com.example.util.AppLogger
import java.util.concurrent.TimeUnit

/**
 * WorkManager Background task to simulate periodic synchronization of companion telemetry diagnostic logs.
 */
class TelemetrySyncWorker(
    context: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(context, workerParams) {

    private val logger: AppLogger = AndroidLogger()
    private val tag = "TelemetrySyncWorker"

    override suspend fun doWork(): Result {
        logger.i(tag, "Initiating background telemetry logs sync task...")
        
        return try {
            // Simulate networking latency for logs synchronization
            kotlinx.coroutines.delay(2000)
            logger.i(tag, "Telemetry analytics successfully uploaded to companion cloud endpoints.")
            Result.success()
        } catch (e: Exception) {
            logger.e(tag, "Telemetry sync failed with exception: ${e.message}", e)
            Result.retry()
        }
    }

    companion object {
        private const val SYNC_TAG = "telemetry_periodic_sync"

        /**
         * Schedules a recurring telemetry sync job.
         * Runs every 12 hours under standard constraints: Network connected, device charging, battery not low.
         */
        fun enqueuePeriodicSync(context: Context) {
            val constraints = Constraints.Builder()
                .setRequiredNetworkType(NetworkType.CONNECTED)
                .setRequiresCharging(true)
                .setRequiresBatteryNotLow(true)
                .build()

            val syncRequest = PeriodicWorkRequestBuilder<TelemetrySyncWorker>(
                12, TimeUnit.HOURS,
                15, TimeUnit.MINUTES // Flex interval
            ).setConstraints(constraints)
                .addTag(SYNC_TAG)
                .build()

            WorkManager.getInstance(context).enqueue(syncRequest)
        }

        /**
         * Dispatches a single execution pass of the sync task.
         */
        fun enqueueOneTimeSync(context: Context) {
            val constraints = Constraints.Builder()
                .setRequiredNetworkType(NetworkType.CONNECTED)
                .build()

            val syncRequest = OneTimeWorkRequestBuilder<TelemetrySyncWorker>()
                .setConstraints(constraints)
                .build()

            WorkManager.getInstance(context).enqueue(syncRequest)
        }
    }
}
