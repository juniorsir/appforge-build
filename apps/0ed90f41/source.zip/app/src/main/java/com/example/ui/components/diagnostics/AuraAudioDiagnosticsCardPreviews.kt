package com.example.ui.components.diagnostics

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.ui.theme.AuraColors
import com.example.ui.theme.MyApplicationTheme

/**
 * AURA ASSISTANT — Phase 5 Audio Diagnostics Previews
 */
@Composable
private fun AudioDiagnosticsPreviewContainer(
    status: AuraAudioStatus,
    sampleRate: Int = 16000,
    bufferSize: Int = 640,
    rms: Double = 0.0,
    errorMessage: String? = null,
    hasPermission: Boolean = true,
    reducedMotion: Boolean = false
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(AuraColors.Background)
            .padding(16.dp)
    ) {
        AuraAudioDiagnosticsCard(
            status = status,
            sampleRate = sampleRate,
            bufferSize = bufferSize,
            rms = rms,
            errorMessage = errorMessage,
            hasPermission = hasPermission,
            onStartClick = {},
            onPauseClick = {},
            onStopClick = {},
            onRestartClick = {},
            reducedMotion = reducedMotion
        )
    }
}

@Preview(name = "1. Active Speech (411dp)", widthDp = 411, heightDp = 220)
@Composable
fun PreviewAuraAudioActiveSpeech() {
    MyApplicationTheme {
        AudioDiagnosticsPreviewContainer(
            status = AuraAudioStatus.ACTIVE,
            sampleRate = 16000,
            bufferSize = 640,
            rms = 6800.0 // approx -13.6 dB
        )
    }
}

@Preview(name = "2. Active Silence (411dp)", widthDp = 411, heightDp = 220)
@Composable
fun PreviewAuraAudioActiveSilence() {
    MyApplicationTheme {
        AudioDiagnosticsPreviewContainer(
            status = AuraAudioStatus.ACTIVE,
            sampleRate = 16000,
            bufferSize = 640,
            rms = 35.0 // approx -59.4 dB
        )
    }
}

@Preview(name = "3. Idle (411dp)", widthDp = 411, heightDp = 220)
@Composable
fun PreviewAuraAudioIdle() {
    MyApplicationTheme {
        AudioDiagnosticsPreviewContainer(
            status = AuraAudioStatus.IDLE,
            sampleRate = 16000,
            bufferSize = 0,
            rms = 0.0
        )
    }
}

@Preview(name = "4. Paused (411dp)", widthDp = 411, heightDp = 220)
@Composable
fun PreviewAuraAudioPaused() {
    MyApplicationTheme {
        AudioDiagnosticsPreviewContainer(
            status = AuraAudioStatus.PAUSED,
            sampleRate = 16000,
            bufferSize = 640,
            rms = 0.0
        )
    }
}

@Preview(name = "5. Permission Denied (411dp)", widthDp = 411, heightDp = 220)
@Composable
fun PreviewAuraAudioPermissionDenied() {
    MyApplicationTheme {
        AudioDiagnosticsPreviewContainer(
            status = AuraAudioStatus.NO_PERMISSION,
            sampleRate = 16000,
            bufferSize = 0,
            rms = 0.0,
            hasPermission = false
        )
    }
}

@Preview(name = "6. Unavailable (411dp)", widthDp = 411, heightDp = 220)
@Composable
fun PreviewAuraAudioUnavailable() {
    MyApplicationTheme {
        AudioDiagnosticsPreviewContainer(
            status = AuraAudioStatus.UNAVAILABLE,
            sampleRate = 16000,
            bufferSize = 0,
            rms = 0.0
        )
    }
}

@Preview(name = "7. Error (411dp)", widthDp = 411, heightDp = 260)
@Composable
fun PreviewAuraAudioError() {
    MyApplicationTheme {
        AudioDiagnosticsPreviewContainer(
            status = AuraAudioStatus.ERROR,
            sampleRate = 16000,
            bufferSize = 0,
            rms = 0.0,
            errorMessage = "AudioRecord initialization failed (E_HARDWARE_BUSY)"
        )
    }
}

@Preview(name = "8. High Input Level (411dp)", widthDp = 411, heightDp = 220)
@Composable
fun PreviewAuraAudioHighInput() {
    MyApplicationTheme {
        AudioDiagnosticsPreviewContainer(
            status = AuraAudioStatus.ACTIVE,
            sampleRate = 16000,
            bufferSize = 640,
            rms = 28000.0 // approx -1.3 dB
        )
    }
}

@Preview(name = "9. Low Input Level (411dp)", widthDp = 411, heightDp = 220)
@Composable
fun PreviewAuraAudioLowInput() {
    MyApplicationTheme {
        AudioDiagnosticsPreviewContainer(
            status = AuraAudioStatus.ACTIVE,
            sampleRate = 16000,
            bufferSize = 640,
            rms = 350.0 // approx -39.4 dB
        )
    }
}

@Preview(name = "10. Compact Phone (340dp)", widthDp = 340, heightDp = 250)
@Composable
fun PreviewAuraAudioCompactPhone() {
    MyApplicationTheme {
        AudioDiagnosticsPreviewContainer(
            status = AuraAudioStatus.ACTIVE,
            sampleRate = 16000,
            bufferSize = 640,
            rms = 4200.0
        )
    }
}

@Preview(name = "11. Tablet (800dp)", widthDp = 800, heightDp = 240)
@Composable
fun PreviewAuraAudioTablet() {
    MyApplicationTheme {
        AudioDiagnosticsPreviewContainer(
            status = AuraAudioStatus.ACTIVE,
            sampleRate = 16000,
            bufferSize = 640,
            rms = 5100.0
        )
    }
}

@Preview(name = "12. Landscape (700dp)", widthDp = 700, heightDp = 220)
@Composable
fun PreviewAuraAudioLandscape() {
    MyApplicationTheme {
        AudioDiagnosticsPreviewContainer(
            status = AuraAudioStatus.ACTIVE,
            sampleRate = 16000,
            bufferSize = 640,
            rms = 5100.0
        )
    }
}
