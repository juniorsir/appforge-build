package com.example.domain.model

import java.util.UUID

/**
 * Data model representing a speech-to-text transcript segment.
 */
data class Transcript(
    val id: String = UUID.randomUUID().toString(),
    val sessionId: String,
    val text: String,
    val isFinal: Boolean,
    val timestamp: Long = System.currentTimeMillis(),
    val confidence: Double = 1.0,
    val language: String = "en"
)

/**
 * Pre-formatted text and structure ready to be handed off to an LLM in the future.
 */
data class ConversationRequest(
    val sessionId: String,
    val rawText: String,
    val cleanedText: String,
    val formattedText: String,
    val timestamp: Long = System.currentTimeMillis()
) {
    fun validate(): Boolean {
        return cleanedText.isNotBlank() && sessionId.isNotBlank()
    }
}
