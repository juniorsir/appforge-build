package com.example.ui.theme

import androidx.compose.runtime.Immutable
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * AURA ASSISTANT — Centralized Responsive Layout Breakpoints
 */
@Immutable
object AuraBreakpoints {
    val CompactMax: Dp = 359.dp
    val NormalMin: Dp = 360.dp
    val NormalMax: Dp = 599.dp
    val ExpandedMin: Dp = 600.dp
    val LargeTabletMin: Dp = 840.dp

    /**
     * Determines the responsive window size class.
     */
    fun classify(width: Dp): AuraWindowSizeClass {
        return when {
            width < NormalMin -> AuraWindowSizeClass.COMPACT
            width < ExpandedMin -> AuraWindowSizeClass.NORMAL
            else -> AuraWindowSizeClass.EXPANDED
        }
    }
}

enum class AuraWindowSizeClass {
    COMPACT,
    NORMAL,
    EXPANDED
}
