package com.example.domain.repository

import com.example.domain.model.Transcript
import kotlinx.coroutines.flow.StateFlow

interface TranscriptRepository {
    val liveTranscript: StateFlow<Transcript?>
    val transcriptHistory: StateFlow<List<Transcript>>

    fun addTranscript(transcript: Transcript)
    fun updateLiveTranscript(transcript: Transcript?)
    fun clearHistory()
}
