package com.example.capabilities.core

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import com.example.capabilities.audio.AudioCapabilityRepository
import com.example.capabilities.battery.BatteryRepository
import com.example.capabilities.bluetooth.BluetoothRepository
import com.example.capabilities.calendar.CalendarRepository
import com.example.capabilities.camera.CameraRepository
import com.example.capabilities.clipboard.ClipboardRepository
import com.example.capabilities.contacts.ContactRepository
import com.example.capabilities.display.DisplayRepository
import com.example.capabilities.events.SystemEventsRepository
import com.example.capabilities.gallery.GalleryRepository
import com.example.capabilities.gps.LocationRepository
import com.example.capabilities.haptics.HapticsRepository
import com.example.capabilities.biometrics.BiometricsRepository
import com.example.capabilities.info.DeviceInfoRepository
import com.example.capabilities.input.InputRepository
import com.example.capabilities.intents.IntentRepository
import com.example.capabilities.network.NetworkRepository
import com.example.capabilities.nfc.NfcRepository
import com.example.capabilities.notifications.NotificationRepository
import com.example.capabilities.apps.ApplicationRepository
import com.example.capabilities.permissions.PermissionManager
import com.example.capabilities.sensors.SensorRepository
import com.example.capabilities.settings.SystemSettingsRepository
import com.example.capabilities.share.ShareRepository
import com.example.capabilities.sms.SmsRepository
import com.example.capabilities.storage.StorageRepository
import com.example.capabilities.telephony.TelephonyRepository
import com.example.capabilities.usb.UsbRepository
import com.example.capabilities.work.BackgroundWorkRepository
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class CapabilityRegistryImpl @Inject constructor(
    @ApplicationContext private val context: Context,
    private val permissionManager: PermissionManager,
    private val gateway: CapabilityGateway,
    private val audioRepo: AudioCapabilityRepository,
    private val batteryRepo: BatteryRepository,
    private val bluetoothRepo: BluetoothRepository,
    private val calendarRepo: CalendarRepository,
    private val cameraRepo: CameraRepository,
    private val clipboardRepo: ClipboardRepository,
    private val contactRepo: ContactRepository,
    private val displayRepo: DisplayRepository,
    private val eventsRepo: SystemEventsRepository,
    private val galleryRepo: GalleryRepository,
    private val locationRepo: LocationRepository,
    private val hapticsRepo: HapticsRepository,
    private val biometricsRepo: BiometricsRepository,
    private val deviceInfoRepo: DeviceInfoRepository,
    private val inputRepo: InputRepository,
    private val intentRepo: IntentRepository,
    private val networkRepo: NetworkRepository,
    private val nfcRepo: NfcRepository,
    private val notificationRepo: NotificationRepository,
    private val appRepo: ApplicationRepository,
    private val sensorRepo: SensorRepository,
    private val settingsRepo: SystemSettingsRepository,
    private val shareRepo: ShareRepository,
    private val smsRepo: SmsRepository,
    private val storageRepo: StorageRepository,
    private val telephonyRepo: TelephonyRepository,
    private val usbRepo: UsbRepository,
    private val workRepo: BackgroundWorkRepository
) : CapabilityRegistry {

    private val _capabilities = MutableStateFlow<List<CapabilityDefinition>>(emptyList())
    override val capabilities: StateFlow<List<CapabilityDefinition>> = _capabilities.asStateFlow()

    init {
        initializeRegistry()
        refreshAvailability()
    }

    private fun initializeRegistry() {
        val list = listOf(
            CapabilityDefinition(
                id = "audio_record",
                name = "Microphone & Audio Capture",
                description = "Low-latency 16kHz PCM audio streaming, AGC/AEC/NS hardware audio effects detection",
                category = CapabilityCategory.AUDIO,
                requiredPermissions = listOf(android.Manifest.permission.RECORD_AUDIO),
                hardwareFeature = PackageManager.FEATURE_MICROPHONE
            ),
            CapabilityDefinition(
                id = "audio_output",
                name = "Speaker & Audio Output",
                description = "Audio playback routing, volume controls, speaker/headset/Bluetooth output routing",
                category = CapabilityCategory.AUDIO
            ),
            CapabilityDefinition(
                id = "camera_camerax",
                name = "Camera & Image Analysis",
                description = "CameraX preview, lens selector, photo capture, torch toggle, image analysis pipeline",
                category = CapabilityCategory.CAMERA,
                requiredPermissions = listOf(android.Manifest.permission.CAMERA),
                hardwareFeature = PackageManager.FEATURE_CAMERA_ANY,
                confirmationLevel = ConfirmationLevel.CONFIRMATION
            ),
            CapabilityDefinition(
                id = "media_gallery",
                name = "Media & Direct Storage Gallery",
                description = "Query photos, videos, and audio files via direct MediaStore and storage access",
                category = CapabilityCategory.MEDIA
            ),
            CapabilityDefinition(
                id = "file_storage",
                name = "File System & Direct Device Storage",
                description = "Direct external storage access (/sdcard), All-Files manager, and device file system operations",
                category = CapabilityCategory.FILE_SYSTEM
            ),
            CapabilityDefinition(
                id = "location_gps",
                name = "Location & GPS Services",
                description = "Fine/Coarse location, latitude, longitude, altitude, speed, bearing, and geofencing",
                category = CapabilityCategory.LOCATION,
                requiredPermissions = listOf(
                    android.Manifest.permission.ACCESS_FINE_LOCATION,
                    android.Manifest.permission.ACCESS_COARSE_LOCATION
                ),
                hardwareFeature = PackageManager.FEATURE_LOCATION
            ),
            CapabilityDefinition(
                id = "sensors_motion",
                name = "Motion & Environmental Sensors",
                description = "Accelerometer, Gyroscope, Magnetometer, Light, Pressure, Step Counter readings",
                category = CapabilityCategory.SENSORS,
                hardwareFeature = PackageManager.FEATURE_SENSOR_ACCELEROMETER
            ),
            CapabilityDefinition(
                id = "bluetooth_ble",
                name = "Bluetooth & BLE Manager",
                description = "Bluetooth adapter state, paired devices, BLE scanning and GATT service discovery",
                category = CapabilityCategory.BLUETOOTH,
                requiredPermissions = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    listOf(
                        android.Manifest.permission.BLUETOOTH_SCAN,
                        android.Manifest.permission.BLUETOOTH_CONNECT
                    )
                } else {
                    listOf(android.Manifest.permission.BLUETOOTH)
                },
                hardwareFeature = PackageManager.FEATURE_BLUETOOTH
            ),
            CapabilityDefinition(
                id = "network_status",
                name = "Network & Connectivity Monitor",
                description = "Network state, Wi-Fi / Cellular / Ethernet transport capabilities, bandwidth estimates",
                category = CapabilityCategory.NETWORK
            ),
            CapabilityDefinition(
                id = "notification_manager",
                name = "Notification System",
                description = "Post system notifications with channels, actions, ongoing status and progress bars",
                category = CapabilityCategory.NOTIFICATIONS,
                requiredPermissions = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    listOf(android.Manifest.permission.POST_NOTIFICATIONS)
                } else emptyList()
            ),
            CapabilityDefinition(
                id = "contacts_provider",
                name = "Contacts Provider",
                description = "Query contact names, phone numbers, and email addresses via ContactsContract",
                category = CapabilityCategory.CONTACTS,
                requiredPermissions = listOf(android.Manifest.permission.READ_CONTACTS),
                confirmationLevel = ConfirmationLevel.CONFIRMATION
            ),
            CapabilityDefinition(
                id = "calendar_provider",
                name = "Calendar & Events Provider",
                description = "Query, search, create, update, and manage calendar events via CalendarContract",
                category = CapabilityCategory.CALENDAR,
                requiredPermissions = listOf(
                    android.Manifest.permission.READ_CALENDAR,
                    android.Manifest.permission.WRITE_CALENDAR
                ),
                confirmationLevel = ConfirmationLevel.CONFIRMATION
            ),
            CapabilityDefinition(
                id = "telephony_manager",
                name = "Telephony & SIM Status",
                description = "Telephony network operator, SIM state, dialer launch and telephony capabilities",
                category = CapabilityCategory.TELEPHONY,
                hardwareFeature = PackageManager.FEATURE_TELEPHONY
            ),
            CapabilityDefinition(
                id = "sms_manager",
                name = "SMS & Messaging Dispatcher",
                description = "Compose SMS messages via system intents or send SMS directly if default SMS app",
                category = CapabilityCategory.SMS,
                confirmationLevel = ConfirmationLevel.STRONG_CONFIRMATION
            ),
            CapabilityDefinition(
                id = "clipboard_manager",
                name = "Clipboard Manager",
                description = "Read, write, and monitor system clipboard contents safely with MIME inspection",
                category = CapabilityCategory.CLIPBOARD
            ),
            CapabilityDefinition(
                id = "application_manager",
                name = "Installed Applications Manager",
                description = "Inspect installed applications, package names, target SDKs, and launch intents",
                category = CapabilityCategory.APPLICATION
            ),
            CapabilityDefinition(
                id = "device_info",
                name = "Device Hardware & OS Info",
                description = "Manufacturer, model, Android version, SDK, CPU ABIs, RAM, storage, and timezone",
                category = CapabilityCategory.DEVICE_INFO
            ),
            CapabilityDefinition(
                id = "battery_power",
                name = "Battery & Power Management",
                description = "Battery level, charging status, temperature, voltage, and power-saving modes",
                category = CapabilityCategory.BATTERY
            ),
            CapabilityDefinition(
                id = "display_manager",
                name = "Screen & Display Metrics",
                description = "Resolution, density DPI, refresh rate, orientation, HDR, and wide color gamut",
                category = CapabilityCategory.DISPLAY
            ),
            CapabilityDefinition(
                id = "haptics_vibration",
                name = "Haptics & Vibration Engine",
                description = "Vibration motor control, amplitude scaling, click/tick/double-click haptic effects",
                category = CapabilityCategory.HAPTICS,
                requiredPermissions = listOf(android.Manifest.permission.VIBRATE)
            ),
            CapabilityDefinition(
                id = "biometrics_security",
                name = "Biometrics & Device Credentials",
                description = "BiometricPrompt capability, fingerprint / face unlock availability and lock status",
                category = CapabilityCategory.BIOMETRICS
            ),
            CapabilityDefinition(
                id = "nfc_manager",
                name = "NFC & NDEF Controller",
                description = "Near Field Communication adapter state, NDEF tag discovery and push support",
                category = CapabilityCategory.NFC,
                requiredPermissions = listOf(android.Manifest.permission.NFC),
                hardwareFeature = PackageManager.FEATURE_NFC
            ),
            CapabilityDefinition(
                id = "usb_host",
                name = "USB Host & Peripherals",
                description = "USB Host device detection, vendor/product IDs, interfaces, and endpoint discovery",
                category = CapabilityCategory.USB,
                hardwareFeature = PackageManager.FEATURE_USB_HOST
            ),
            CapabilityDefinition(
                id = "input_devices",
                name = "Input Devices & Game Controllers",
                description = "Detect external keyboards, mice, gamepads, joysticks, and touchscreen capabilities",
                category = CapabilityCategory.INPUT_DEVICES
            ),
            CapabilityDefinition(
                id = "accessibility_service",
                name = "Accessibility Subsystem",
                description = "Accessibility service status, window state inspection, and navigation gestures",
                category = CapabilityCategory.ACCESSIBILITY
            ),
            CapabilityDefinition(
                id = "screen_capture",
                name = "Screen Capture & MediaProjection",
                description = "User-approved screen capture, screenshot buffer readiness and frame pipeline",
                category = CapabilityCategory.SCREEN_CAPTURE,
                minSdkVersion = 21,
                confirmationLevel = ConfirmationLevel.STRONG_CONFIRMATION
            ),
            CapabilityDefinition(
                id = "web_browser",
                name = "Web Browser & Custom Tabs",
                description = "Launch URLs via Chrome Custom Tabs or external browsers with intent resolution",
                category = CapabilityCategory.WEB_BROWSER
            ),
            CapabilityDefinition(
                id = "intent_manager",
                name = "Intent Dispatcher & Resolver",
                description = "Safely resolve and launch system intents (email, dial, maps, share, documents)",
                category = CapabilityCategory.INTENTS
            ),
            CapabilityDefinition(
                id = "system_settings",
                name = "System Settings Opener",
                description = "Direct navigation to Wi-Fi, Bluetooth, Location, Sound, and App Settings screens",
                category = CapabilityCategory.SYSTEM_SETTINGS
            ),
            CapabilityDefinition(
                id = "background_work",
                name = "Background Work & WorkManager",
                description = "Schedule persistent background tasks via WorkManager with network/battery constraints",
                category = CapabilityCategory.BACKGROUND_WORK
            ),
            CapabilityDefinition(
                id = "system_events",
                name = "System Events & Broadcasts",
                description = "Real-time reactive flow for power, screen, locale, timezone, and battery events",
                category = CapabilityCategory.SYSTEM_EVENTS
            )
        )
        _capabilities.value = list
    }

    override fun getCapability(id: String): CapabilityDefinition? {
        return _capabilities.value.find { it.id == id }
    }

    override fun getCapabilitiesByCategory(category: CapabilityCategory): List<CapabilityDefinition> {
        return _capabilities.value.filter { it.category == category }
    }

    override fun registerCapability(definition: CapabilityDefinition) {
        val current = _capabilities.value.toMutableList()
        val index = current.indexOfFirst { it.id == definition.id }
        if (index >= 0) {
            current[index] = definition
        } else {
            current.add(definition)
        }
        _capabilities.value = current
    }

    override fun updateCapabilityState(id: String, state: CapabilityState, lastError: String?) {
        val current = _capabilities.value.toMutableList()
        val index = current.indexOfFirst { it.id == id }
        if (index >= 0) {
            current[index] = current[index].copy(
                currentState = state,
                lastError = lastError
            )
            _capabilities.value = current
        }
    }

    override fun refreshAvailability() {
        val updated = _capabilities.value.map { cap ->
            val availability = calculateAvailability(cap)
            cap.copy(availability = availability)
        }
        _capabilities.value = updated
    }

    private fun calculateAvailability(cap: CapabilityDefinition): CapabilityAvailability {
        if (Build.VERSION.SDK_INT < cap.minSdkVersion) {
            return CapabilityAvailability.ANDROID_VERSION_UNSUPPORTED
        }
        if (cap.hardwareFeature != null && !permissionManager.hasHardwareFeature(cap.hardwareFeature)) {
            return CapabilityAvailability.HARDWARE_MISSING
        }
        if (cap.requiredPermissions.isNotEmpty() && !permissionManager.hasAllPermissions(cap.requiredPermissions)) {
            return CapabilityAvailability.PERMISSION_REQUIRED
        }
        return CapabilityAvailability.AVAILABLE
    }

    override suspend fun executeCapability(request: CapabilityRequest): CapabilityResponse {
        val cap = getCapability(request.capabilityId)
            ?: return CapabilityResponse(
                requestId = request.requestId,
                capabilityId = request.capabilityId,
                success = false,
                errorCode = CapabilityErrorCode.NOT_AVAILABLE,
                errorMessage = "Capability '${request.capabilityId}' is not registered"
            )

        updateCapabilityState(cap.id, CapabilityState.RUNNING)

        val response = gateway.execute(cap, request) { req ->
            dispatchExecution(cap.id, req)
        }

        val newState = if (response.success) CapabilityState.IDLE else CapabilityState.ERROR
        val errorMsg = if (response.success) null else response.errorMessage

        val current = _capabilities.value.toMutableList()
        val index = current.indexOfFirst { it.id == cap.id }
        if (index >= 0) {
            current[index] = current[index].copy(
                currentState = newState,
                lastExecutionTimeMs = System.currentTimeMillis(),
                lastError = errorMsg
            )
            _capabilities.value = current
        }

        return response
    }

    private suspend fun dispatchExecution(capabilityId: String, req: CapabilityRequest): Any? {
        return when (capabilityId) {
            "audio_record" -> audioRepo.getMicrophoneCapability().getOrNull()
            "audio_output" -> audioRepo.getAudioHardwareInfo().getOrNull()
            "camera_camerax" -> mapOf("status" to "CameraX initialized", "lens" to "Back/Front camera available", "torch" to "Supported")
            "media_gallery" -> galleryRepo.pickMultipleImages().getOrNull() ?: mapOf("status" to "Direct MediaStore & external storage ready")
            "file_storage" -> {
                val externalDir = android.os.Environment.getExternalStorageDirectory()
                mapOf(
                    "status" to "Direct device storage ready (No Sandbox)",
                    "rootPath" to externalDir.absolutePath,
                    "state" to android.os.Environment.getExternalStorageState(),
                    "totalSpaceBytes" to externalDir.totalSpace,
                    "freeSpaceBytes" to externalDir.freeSpace
                )
            }
            "location_gps" -> locationRepo.getCurrentLocation().getOrNull()
            "sensors_motion" -> mapOf("accelerometer" to "Ready", "light" to "Ready", "gyroscope" to "Ready")
            "bluetooth_ble" -> bluetoothRepo.getBluetoothStatus().getOrNull()
            "network_status" -> networkRepo.getNetworkInfo().getOrNull()
            "notification_manager" -> mapOf("status" to "Notification channels active")
            "contacts_provider" -> contactRepo.getContacts().getOrNull()
            "calendar_provider" -> calendarRepo.getEvents(System.currentTimeMillis(), System.currentTimeMillis() + 86400000).getOrNull()
            "telephony_manager" -> telephonyRepo.getTelephonyInfo().getOrNull()
            "sms_manager" -> smsRepo.getSmsCapabilityInfo().getOrNull()
            "clipboard_manager" -> clipboardRepo.readClipboard().getOrNull()
            "application_manager" -> appRepo.getInstalledApps(false).getOrNull()
            "device_info" -> deviceInfoRepo.getDeviceInfo().getOrNull()
            "battery_power" -> batteryRepo.getBatteryInfo().getOrNull()
            "display_manager" -> displayRepo.getDisplayInfo().getOrNull()
            "haptics_vibration" -> {
                hapticsRepo.performHapticFeedback("CLICK")
                hapticsRepo.getHapticsInfo().getOrNull()
            }
            "biometrics_security" -> biometricsRepo.getBiometricsInfo().getOrNull()
            "nfc_manager" -> nfcRepo.getNfcInfo().getOrNull()
            "usb_host" -> usbRepo.getUsbInfo().getOrNull()
            "input_devices" -> inputRepo.getInputDevices().getOrNull()
            "accessibility_service" -> mapOf("enabled" to true, "service" to "TermuxAccessibilityService")
            "screen_capture" -> mapOf("supported" to true, "minSdk" to 21, "type" to "MediaProjection")
            "web_browser" -> mapOf("customTabsSupported" to true, "intentAvailable" to true)
            "intent_manager" -> mapOf("supportedActions" to listOf("VIEW", "SEND", "DIAL", "MAPS", "EMAIL"))
            "system_settings" -> mapOf("availableSettings" to listOf("WIFI", "BLUETOOTH", "LOCATION", "SOUND", "DISPLAY", "APP_DETAILS"))
            "background_work" -> workRepo.getWorkManagerStatus().getOrNull()
            "system_events" -> eventsRepo.getLastKnownBatteryState().getOrNull()
            else -> mapOf("status" to "Executed capability $capabilityId")
        }
    }
}
